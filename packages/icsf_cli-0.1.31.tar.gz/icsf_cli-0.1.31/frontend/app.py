import streamlit as st
import requests
import os
import pandas as pd
import json
import logging
import warnings
import math
import time
from src.vulnerability_ui import (
    display_vulnerability_flow, 
    display_fix_results, 
    render_individual_fix_details,
    render_atlas_report,
    render_test_generation_results  # NEW: Test results display
)

# Suppress WebSocket closed warnings from Streamlit/Tornado
# These occur when clients disconnect during long-running operations
logging.getLogger('tornado.access').setLevel(logging.ERROR)
logging.getLogger('tornado.application').setLevel(logging.ERROR)
logging.getLogger('tornado.general').setLevel(logging.ERROR)
warnings.filterwarnings('ignore', category=RuntimeWarning, message='.*WebSocket.*')

# App logger
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="ICSF – Intelligent Code Security & Fixing Platform",
    page_icon="🔐",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for modern, premium styling
st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

    :root {
        --bg-main: #0f172a;
        --bg-secondary: #1e293b;
        --bg-accent: #334155;
        --text-primary: #f8fafc;
        --text-secondary: #94a3b8;
        --accent-blue: #3b82f6;
        --accent-emerald: #10b981;
        --accent-indigo: #6366f1;
        --danger: #ef4444;
        --warning: #f59e0b;
        --success: #10b981;
        --border-color: rgba(255, 255, 255, 0.1);
    }

    /* Main Container */
    .stApp {
    /* Global Styles */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    html, body, [data-testid="stAppViewContainer"] {
        font-family: 'Inter', sans-serif;
    }

    /* Main Background & Gradient */
    .stApp {
        background-color: #0f172a;
        background-image: 
            radial-gradient(at 0% 0%, rgba(30, 58, 138, 0.15) 0px, transparent 50%),
            radial-gradient(at 100% 100%, rgba(17, 24, 39, 0.2) 0px, transparent 50%);
    }
    
    .main .block-container {
        padding: 2rem 3rem !important;
        max-width: 1200px;
    }

    /* Typography */
    h1, h2, h3, h4 {
        color: #f8fafc !important;
        font-weight: 700 !important;
        letter-spacing: -0.025em;
    }

    /* Main Header */
    .main-header {
        font-size: 2.75rem;
        font-weight: 800;
        background: linear-gradient(135deg, #3b82f6 0%, #2dd4bf 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 2rem;
        padding: 0.5rem 0;
    }

    /* Custom Top Navigation */
    .top-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.75rem 2rem;
        background: rgba(30, 41, 59, 0.7);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        margin-bottom: 2.5rem;
        border-radius: 0 0 16px 16px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .top-nav-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: #f8fafc;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Sidebar - Completely Hidden as per current design */
    section[data-testid="stSidebar"] { display: none !important; }
    [data-testid="collapsedControl"] { display: none !important; }

    /* Premium Card Styling */
    .repo-card-safe, .repo-card-vulnerable, .vuln-card, .metric-container {
        background: rgba(30, 41, 59, 0.5) !important;
        backdrop-filter: blur(4px);
        border: 1px solid rgba(255, 255, 255, 0.05) !important;
        border-radius: 12px !important;
        padding: 1.5rem !important;
        margin-bottom: 1rem !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .repo-card-safe:hover, .repo-card-vulnerable:hover {
        transform: translateY(-4px);
        border-color: rgba(255, 255, 255, 0.1) !important;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2);
    }

    .repo-card-safe { border-left: 5px solid #10b981 !important; }
    .repo-card-vulnerable { border-left: 5px solid #ef4444 !important; }
    .vuln-card { border-left: 5px solid #f59e0b !important; }

    /* Section Headers */
    .section-header {
        font-size: 1.25rem;
        font-weight: 600;
        color: #94a3b8;
        margin: 2.5rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    /* Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%) !important;
        color: #ffffff !important;
        border: none !important;
        padding: 0.5rem 1.5rem !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        transition: all 0.2s ease !important;
        box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.3) !important;
    }

    .stButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 10px 15px -3px rgba(59, 130, 246, 0.4) !important;
        background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%) !important;
    }

    /* Inputs & Selectboxes */
    .stTextInput input, .stSelectbox [data-baseweb="select"] {
        background-color: #1e293b !important;
        border: 1px solid #334155 !important;
        border-radius: 8px !important;
        color: #f8fafc !important;
    }

    .stTextInput label, .stSelectbox label, .stRadio label {
        color: #94a3b8 !important;
        font-weight: 500 !important;
        margin-bottom: 0.5rem !important;
    }

    /* Metric Values */
    [data-testid="stMetricValue"] {
        color: #f8fafc !important;
        font-size: 2rem !important;
        font-weight: 700 !important;
    }
    
    [data-testid="stMetricLabel"] {
        color: #94a3b8 !important;
        font-size: 0.875rem !important;
    }

    /* Badges */
    .badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        text-transform: uppercase;
    }
    .badge-danger { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
    .badge-success { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
    .badge-warning { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }

    /* Tables */
    .stDataFrame table { background-color: transparent !important; }
    .stDataFrame td { background-color: rgba(30, 41, 59, 0.4) !important; color: #cbd5e1 !important; border-bottom: 1px solid rgba(255, 255, 255, 0.05) !important; }
    .stDataFrame th { background-color: #1e293b !important; color: #f8fafc !important; font-weight: 600 !important; }

    /* Status Boxes */
    .stInfo, .stWarning, .stSuccess, .stError {
        background-color: rgba(30, 41, 59, 0.6) !important;
        border-radius: 10px !important;
        border: 1px solid rgba(255, 255, 255, 0.05) !important;
    }
    .stInfo { border-left: 4px solid #3b82f6 !important; }
    .stSuccess { border-left: 4px solid #10b981 !important; }
    .stWarning { border-left: 4px solid #f59e0b !important; }
    .stError { border-left: 4px solid #ef4444 !important; }

    /* Custom Metric Cards for Run History & Results */
    div[data-testid="stMetric"] {
        background-color: rgba(30, 41, 59, 0.6) !important;
        padding: 1.25rem 1.5rem;
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.05) !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
        transition: all 0.2s ease;
    }
    div[data-testid="stMetric"]:hover {
        border-color: rgba(255, 255, 255, 0.1) !important;
        background-color: rgba(30, 41, 59, 0.8) !important;
    }

    /* Expander UI Refinements */
    .streamlit-expanderHeader {
        background-color: rgba(30, 41, 59, 0.7) !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        color: #f8fafc !important;
        border: 1px solid rgba(255,255,255,0.05) !important;
    }

    /* Tabs Styling */
    button[data-baseweb="tab"] {
        background-color: transparent !important;
        border-radius: 8px !important;
        color: #94a3b8 !important;
        font-weight: 600 !important;
        margin-right: 0.5rem !important;
        padding: 0.75rem 1.5rem !important;
        border: 1px solid transparent !important;
    }
    button[data-baseweb="tab"][aria-selected="true"] {
        background-color: rgba(59, 130, 246, 0.15) !important;
        color: #3b82f6 !important;
        border: 1px solid rgba(59, 130, 246, 0.3) !important;
    }

    /* Hide Streamlit default UI elements */
    #MainMenu, footer, header { visibility: hidden; }
    </style>
""", unsafe_allow_html=True)

# API Configuration - detect from env vars with fallback
# Check both API_BASE_URL and BACKEND_URL for robustness
_api_url = os.getenv("API_BASE_URL") or os.getenv("BACKEND_URL")
if not _api_url:
    # If no env var, check if we're likely in a Docker container and use service name
    if os.path.exists("/.dockerenv"):
        _api_url = "http://backend:8000"
    else:
        _api_url = "http://localhost:8000"

DEFAULT_API_BASE_URL = _api_url


def extract_fixed_code_from_result(fix_result):
    """
    Extract fixed code map and files modified from a fix result.
    
    Args:
        fix_result: Fix result dictionary containing code_fix agent results
        
    Returns:
        Tuple of (files_modified list, fixed_code_map dict)
    """
    fixed_code_map = {}
    files_modified = []
    
    # Get code fix results
    result_data = fix_result.get('result', {}) if isinstance(fix_result, dict) else fix_result
    cf = result_data.get('code_fix', {}) if isinstance(result_data, dict) else {}
    
    if not cf:
        return files_modified, fixed_code_map
    
    # Get files modified
    files_modified = cf.get('files_modified', []) or []
    
    # Extract fixed code
    if cf.get('fixed_code'):
        fixed_code_content = cf['fixed_code']
        
        # Handle case where fixed_code is already a dictionary (file_path -> code)
        # Check for dict or dict-like objects
        if isinstance(fixed_code_content, dict) or (hasattr(fixed_code_content, 'keys') and hasattr(fixed_code_content, 'values')):
            # It's a dict-like object, use it directly
            if isinstance(fixed_code_content, dict):
                fixed_code_map = fixed_code_content.copy()
            else:
                # Convert dict-like object to regular dict
                fixed_code_map = dict(fixed_code_content)
        else:
            # Handle case where fixed_code is a string that needs parsing
            if not isinstance(fixed_code_content, str):
                # Convert to string if it's not already
                fixed_code_content = str(fixed_code_content)
            
        file_separator = "FIXED CODE FOR:"
        
        if file_separator in fixed_code_content:
            sections = fixed_code_content.split(f"\n{file_separator}")
            for section in sections:
                if not section.strip():
                    continue
                lines = section.split('\n')
                file_path = None
                code_start = 0
                
                # Find file path in first few lines
                for idx, line in enumerate(lines[:10]):
                    if file_separator in line:
                        file_path = line.split(file_separator)[-1].strip()
                        code_start = idx + 1
                        break
                
                if file_path:
                    # Extract code (skip separator lines)
                    code_lines = lines[code_start:]
                    clean_code = '\n'.join(code_lines).strip()
                    # Remove any remaining separators
                    clean_code = clean_code.replace('='*80, '').strip()
                    if clean_code:
                        fixed_code_map[file_path] = clean_code
        else:
            # Single file - use the first modified file path if available
            if files_modified:
                # Ensure fixed_code_content is a string before calling strip()
                if isinstance(fixed_code_content, str):
                    fixed_code_map[files_modified[0]] = fixed_code_content.strip()
                elif isinstance(fixed_code_content, dict):
                    # If it's a dict, merge it into fixed_code_map
                    fixed_code_map.update(fixed_code_content)
                else:
                    # Convert to string as fallback
                    fixed_code_map[files_modified[0]] = str(fixed_code_content).strip()
    
    # Final fallback: if parsing failed but we have fixed_code text and modified files
    if not fixed_code_map and files_modified and cf.get('fixed_code'):
        fallback_fixed_code = cf['fixed_code']
        if isinstance(fallback_fixed_code, dict):
            # If it's a dict, use it directly
            fixed_code_map = fallback_fixed_code.copy()
        elif isinstance(fallback_fixed_code, str):
            fixed_code_map[files_modified[0]] = fallback_fixed_code.strip()
        else:
            # Convert to string as last resort
            fixed_code_map[files_modified[0]] = str(fallback_fixed_code).strip()
    
    return files_modified, fixed_code_map


def batch_create_prs(api_url, successful_fixes, repo_owner, repo_name, repo_path, token, base_branch="main"):
    """
    Create multiple Pull Requests using the batch PR API endpoint.
    
    Args:
        api_url: Backend API URL
        successful_fixes: List of successful fix results, each containing:
            - vuln_idx: int
            - result: Dict with fix result
        repo_owner: Repository owner
        repo_name: Repository name
        repo_path: Path to repository
        token: GitHub token
        base_branch: Base branch for PRs
        
    Returns:
        Dictionary with batch PR creation results
    """
    try:
        url = f"{api_url}/api/fixes/batch-create-prs"
        
        # Prepare successful fixes for API
        fixes_for_api = []
        for fix_res in successful_fixes:
            fix_dict = {
                'vuln_idx': fix_res.get('vuln_idx', 0),
                'result': fix_res.get('result')
            }
            fixes_for_api.append(fix_dict)
        
        data = {
            "successful_fixes_json": json.dumps(fixes_for_api),
            "repo_owner": repo_owner,
            "repo_name": repo_name,
            "repo_path": repo_path,
            "token": token,
            "base_branch": base_branch
        }
        
        response = requests.post(url, data=data, timeout=1800)  # 30 min timeout for batch
        
        if response.status_code == 200:
            return response.json()
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return {
                "total": len(successful_fixes),
                "successful": 0,
                "failed": len(successful_fixes),
                "results": [{
                    'vuln_idx': fix_res.get('vuln_idx', idx + 1),
                    'status': 'failed',
                    'error': error_data.get("detail", f"Error {response.status_code}"),
                    'pr_result': None
                } for idx, fix_res in enumerate(successful_fixes)]
            }
    except requests.exceptions.Timeout:
        return {
            "total": len(successful_fixes),
            "successful": 0,
            "failed": len(successful_fixes),
            "results": [{
                'vuln_idx': fix_res.get('vuln_idx', idx + 1),
                'status': 'failed',
                'error': 'Request timed out. Batch PR creation is taking longer than expected.',
                'pr_result': None
            } for idx, fix_res in enumerate(successful_fixes)]
        }
    except requests.exceptions.ConnectionError:
        return {
            "total": len(successful_fixes),
            "successful": 0,
            "failed": len(successful_fixes),
            "results": [{
                'vuln_idx': fix_res.get('vuln_idx', idx + 1),
                'status': 'failed',
                'error': f'Cannot connect to API. Make sure the backend server is running on {api_url}',
                'pr_result': None
            } for idx, fix_res in enumerate(successful_fixes)]
        }
    except Exception as e:
        return {
            "total": len(successful_fixes),
            "successful": 0,
            "failed": len(successful_fixes),
            "results": [{
                'vuln_idx': fix_res.get('vuln_idx', idx + 1),
                'status': 'failed',
                'error': f'Unexpected error: {str(e)}',
                'pr_result': None
            } for idx, fix_res in enumerate(successful_fixes)]
        }


def check_pr_mergeability(api_url, repo_owner, repo_name, pr_number, token):
    """
    Check if a PR can be merged and detect conflicts.
    
    Args:
        api_url: Backend API URL
        repo_owner: Repository owner
        repo_name: Repository name
        pr_number: PR number
        token: GitHub token
        
    Returns:
        Dictionary with mergeability status or None, error message
    """
    try:
        url = f"{api_url}/api/fixes/check-pr-mergeability"
        data = {
            'repo_owner': repo_owner,
            'repo_name': repo_name,
            'pr_number': pr_number,
            'token': token
        }
        response = requests.post(url, data=data, timeout=30)
        if response.status_code == 200:
            return response.json(), None
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return None, error_data.get("detail", f"Error {response.status_code}")
    except requests.exceptions.Timeout:
        return None, "Request timed out. Please try again."
    except requests.exceptions.ConnectionError:
        return None, f"Cannot connect to API. Make sure the FastAPI server is running on {api_url}"
    except requests.exceptions.RequestException as e:
        return None, f"Network error: {str(e)}"
    except Exception as e:
        return None, f"Unexpected error: {str(e)}"


def merge_pr_with_conflict_resolution(api_url, repo_owner, repo_name, pr_number, repo_path, branch_name, token, base_branch="main", conflict_resolution_strategy="ours", merge_strategy="merge", commit_message=None):
    """
    Merge a PR with automatic conflict resolution.
    
    Args:
        api_url: Backend API URL
        repo_owner: Repository owner
        repo_name: Repository name
        pr_number: PR number to merge
        repo_path: Path to local repository
        branch_name: Branch name of the PR
        token: GitHub token
        base_branch: Base branch (default: "main")
        conflict_resolution_strategy: "ours", "theirs", or "both" (default: "ours")
        merge_strategy: "merge" or "rebase" (default: "merge")
        commit_message: Optional commit message for merge
        
    Returns:
        Dictionary with merge result or None, error message
    """
    try:
        url = f"{api_url}/api/fixes/merge-pr"
        data = {
            'repo_owner': repo_owner,
            'repo_name': repo_name,
            'pr_number': pr_number,
            'repo_path': repo_path,
            'branch_name': branch_name,
            'token': token,
            'base_branch': base_branch,
            'conflict_resolution_strategy': conflict_resolution_strategy,
            'merge_strategy': merge_strategy
        }
        if commit_message:
            data['commit_message'] = commit_message
        
        response = requests.post(url, data=data, timeout=300)  # 5 min timeout for merge operations
        if response.status_code == 200:
            return response.json(), None
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return None, error_data.get("detail", f"Error {response.status_code}")
    except requests.exceptions.Timeout:
        return None, "Request timed out. The merge operation is taking longer than expected. Please try again."
    except requests.exceptions.ConnectionError:
        return None, f"Cannot connect to API. Make sure the FastAPI server is running on {api_url}"
    except requests.exceptions.RequestException as e:
        return None, f"Network error: {str(e)}"
    except Exception as e:
        return None, f"Unexpected error: {str(e)}"


def create_pull_request(api_url, repo_owner, repo_name, repo_path, files_modified, fixed_code_map, vulnerability_type, vulnerability_description, fix_summary, token, base_branch="main"):
    """
    Create a Pull Request with fixed code.
    
    Args:
        api_url: Backend API URL
        repo_owner: Repository owner
        repo_name: Repository name
        repo_path: Path to repository
        files_modified: List of modified file paths
        fixed_code_map: Dictionary mapping file paths to fixed code
        vulnerability_type: Type of vulnerability
        vulnerability_description: Description of vulnerability
        fix_summary: Summary of fix
        token: GitHub token
        base_branch: Base branch for PR
        
    Returns:
        PR creation result dictionary
    """
    try:
        url = f"{api_url}/api/fixes/create-pr"
        
        data = {
            "repo_owner": repo_owner,
            "repo_name": repo_name,
            "repo_path": repo_path,
            "files_modified_json": json.dumps(files_modified),
            "fixed_code_json": json.dumps(fixed_code_map),
            "vulnerability_type": vulnerability_type,
            "vulnerability_description": vulnerability_description,
            "fix_summary": fix_summary,
            "token": token,
            "base_branch": base_branch
        }
        
        response = requests.post(url, data=data, timeout=300)
        
        if response.status_code == 200:
            return response.json()
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return {
                "success": False,
                "message": error_data.get("detail", f"Error {response.status_code}")
            }
    except requests.exceptions.Timeout:
        return {
            "success": False,
            "message": "Request timed out. The PR creation is taking longer than expected. Please try again."
            }
    except requests.exceptions.ConnectionError:
        return {
            "success": False,
            "message": "Could not connect to backend. Make sure the backend server is running."
        }
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "message": f"Network error: {str(e)}"
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Error creating PR: {str(e)}"
        }


def orchestrate_fix(api_url, vulnerability_type, description, severity, file_path, line_number, repo_path=None, repo_name=None, clone_url=None, token=None, recommendation=None):
    """Call the fix orchestration API endpoint"""
    try:
        url = f"{api_url}/api/fixes/orchestrate"
        data = {
            'vulnerability_type': vulnerability_type,
            'description': description,
            'severity': severity,
            'file_path': file_path,
            'line_number': line_number,
            'repo_name': repo_name or 'unknown-repo'
        }
        if repo_path:
            data['repo_path'] = repo_path
        if clone_url:
            data['clone_url'] = clone_url
        if token:
            data['token'] = token
        if recommendation:
            data['recommendation'] = recommendation
        response = requests.post(url, data=data, timeout=600)
        if response.status_code == 200:
            return response.json(), None
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return None, error_data.get("detail", f"Error {response.status_code}")
    except requests.exceptions.Timeout:
        return None, "Request timed out. The fix orchestration is taking longer than expected. Please try again or check the backend logs."
    except requests.exceptions.ConnectionError:
        return None, f"Cannot connect to API. Make sure the FastAPI server is running on {api_url}"
    except requests.exceptions.RequestException as e:
        return None, f"Network error: {str(e)}"
    except Exception as e:
        return None, f"Unexpected error: {str(e)}"


def batch_fix_vulnerabilities(api_url, vulnerabilities, selected_repo, token=None, progress_callback=None, auto_create_pr=False, repo_owner=None, base_branch="main", run_tests_after_fix=True):
    """
    Fix all vulnerabilities in a repository using the batch API endpoint.
    
    Args:
        api_url: Backend API URL
        vulnerabilities: List of vulnerability dictionaries
        selected_repo: Repository information dictionary
        token: GitHub token for private repos
        progress_callback: Optional callback function(current, total, status) for progress updates
        auto_create_pr: If True, automatically create PR after each successful fix
        repo_owner: Repository owner (required if auto_create_pr is True)
        base_branch: Base branch for PRs (default: "main")
        run_tests_after_fix: If True, run Atlas testing agent after fixes (default: True)
        
    Returns:
        Dictionary with results: {
            'total': int,
            'successful': int,
            'failed': int,
            'skipped': int,
            'results': list of result dictionaries,
            'pr_results': list of PR results (if auto_create_pr is True),
            'test_results': Atlas testing report (post-fix),
            'baseline_test_results': Atlas testing report (pre-fix)
        }
    """
    try:
        # Get repository info
        clone_url = selected_repo.get('clone_url') or selected_repo.get('html_url', '')
        repo_name = selected_repo.get('name', 'unknown')
        
        # Extract repo_owner from full_name or html_url if not provided
        if not repo_owner:
            full_name = selected_repo.get('full_name', '')
            if full_name and '/' in full_name:
                repo_owner = full_name.split('/')[0]
            elif clone_url and 'github.com' in clone_url:
                # Extract from URL: https://github.com/owner/repo
                parts = clone_url.replace('https://github.com/', '').replace('.git', '').split('/')
                if len(parts) >= 1:
                    repo_owner = parts[0]
        
        # Prepare vulnerabilities for batch API
        # The API expects vulnerabilities with specific fields
        vulnerabilities_for_api = []
        for vuln in vulnerabilities:
            vuln_dict = {
                'vulnerability': vuln.get('vulnerability', 'Unknown'),
                'description': vuln.get('description', ''),
                'severity': vuln.get('severity', 'high').lower() if vuln.get('severity') else 'high',
                'matched_file_path': vuln.get('matched_file_path') or vuln.get('file_path', ''),
                'line_no': vuln.get('line_no', 0),
                'recommendation': vuln.get('recommendation'),
                'file_found': vuln.get('file_found', False)
            }
            vulnerabilities_for_api.append(vuln_dict)
        
        # Call batch fix API endpoint
        url = f"{api_url}/api/fixes/batch"
        data = {
            'vulnerabilities_json': json.dumps(vulnerabilities_for_api),
            'repo_path': '',  # Let backend handle cloning
            'repo_name': repo_name,
            'clone_url': clone_url,
            'auto_create_pr': 'true' if auto_create_pr else 'false',
            'base_branch': base_branch,
            'run_tests_after_fix': 'true' if run_tests_after_fix else 'false'
        }
        if token:
            data['token'] = token
        if auto_create_pr and repo_owner:
            data['repo_owner'] = repo_owner
        
        if progress_callback:
            progress_callback(0, len(vulnerabilities), "Calling batch fix API...")
        
        response = requests.post(url, data=data, timeout=1800)  # 30 min timeout for batch
        
        if response.status_code == 200:
            api_result = response.json()
            batch_results = api_result.get('results', {}) or {}
            
            # Map results to expected format
            results = {
                'total': batch_results.get('total', 0),
                'successful': batch_results.get('successful', 0),
                'failed': batch_results.get('failed', 0),
                'skipped': batch_results.get('skipped', 0),
                'duration': batch_results.get('duration', 0),
                'results': []
            }
            
            # Add PR results if available
            if 'pr_results' in batch_results:
                results['pr_results'] = batch_results['pr_results']
            
            # Add Atlas testing results if available
            if 'test_results' in batch_results:
                results['test_results'] = batch_results['test_results']
            if 'baseline_test_results' in batch_results:
                results['baseline_test_results'] = batch_results['baseline_test_results']
            
            # Process results and enrich with repo + vulnerability details
            for idx, res in enumerate(batch_results.get('results', []), 1):
                vuln_idx = res.get('vuln_idx', idx)
                fix_result = res.get('result') or {}

                vuln_type = None
                file_path = None

                if isinstance(fix_result, dict):
                    # Attach repo info so downstream views/PR flows can use it
                    fix_result['repo_name'] = repo_name
                    fix_result['repo_path'] = api_result.get('repo_path', '')

                    # Try to get vulnerability_type and file_path from fix_result payload
                    inner_result = fix_result.get('result', {}) if isinstance(fix_result.get('result'), dict) else {}
                    vuln_type = (
                        fix_result.get('vulnerability_type')
                        or inner_result.get('vulnerability_type')
                    )
                    file_path = (
                        fix_result.get('file_path')
                        or inner_result.get('file_path')
                    )

                # Fallback: pull from original vulnerability list if still missing
                if (not vuln_type or vuln_type == 'Unknown') and idx <= len(vulnerabilities):
                    original_vuln = vulnerabilities[idx - 1]
                    vuln_type = (
                        original_vuln.get('vulnerability')
                        or original_vuln.get('vulnerability_type')
                        or vuln_type
                    )
                    file_path = (
                        file_path
                        or original_vuln.get('matched_file_path')
                        or original_vuln.get('file_path')
                    )

                # Carry through individual fix duration
                fix_duration = res.get('result', {}).get('duration', 0) if isinstance(res.get('result'), dict) else 0
                if isinstance(fix_result, dict):
                    fix_result['duration'] = fix_duration

                results['results'].append({
                    'vuln_idx': vuln_idx,
                    'vulnerability_type': vuln_type or 'Unknown',
                    'file_path': file_path or 'N/A',
                    'status': res.get('status', 'failed'),
                    'error': res.get('error'),
                    'result': fix_result if isinstance(fix_result, dict) else fix_result,
                    'duration': fix_duration,
                })
            
            return results
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            error_msg = error_data.get("detail", f"Error {response.status_code}")
            
            # Return error in expected format
            return {
                'total': len(vulnerabilities),
                'successful': 0,
                'failed': len(vulnerabilities),
                'skipped': 0,
                'results': [{
                    'vuln_idx': idx + 1,
                    'status': 'failed',
                    'error': error_msg,
                    'result': None
                } for idx in range(len(vulnerabilities))]
            }
            
    except requests.exceptions.Timeout:
        return {
            'total': len(vulnerabilities),
            'successful': 0,
            'failed': len(vulnerabilities),
            'skipped': 0,
            'results': [{
                'vuln_idx': idx + 1,
                'status': 'failed',
                'error': 'Request timed out. Batch fix is taking longer than expected.',
                'result': None
            } for idx in range(len(vulnerabilities))]
        }
    except requests.exceptions.ConnectionError:
        return {
            'total': len(vulnerabilities),
            'successful': 0,
            'failed': len(vulnerabilities),
            'skipped': 0,
            'results': [{
                'vuln_idx': idx + 1,
                'status': 'failed',
                'error': f'Cannot connect to API. Make sure the backend server is running on {api_url}',
                'result': None
            } for idx in range(len(vulnerabilities))]
        }
    except Exception as e:
        return {
            'total': len(vulnerabilities),
            'successful': 0,
            'failed': len(vulnerabilities),
            'skipped': 0,
            'results': [{
                'vuln_idx': idx + 1,
                'status': 'failed',
                'error': f'Unexpected error: {str(e)}',
                'result': None
            } for idx in range(len(vulnerabilities))]
        }


def display_lineage_graph(result, repo_name, vuln_idx):
    """
    Display a lineage graph showing file dependencies and files to be modified.
    
    Args:
        result: Fix result dictionary containing code_context and fix_strategy
        repo_name: Repository name
        vuln_idx: Vulnerability index
    """
    if not result:
        return
    
    # Extract data from result
    code_context = result.get('code_context', {})
    fix_strategy = result.get('fix_strategy', {})
    
    vulnerable_file = code_context.get('vulnerable_file', 'Unknown')
    raw_dependent_files_intra = code_context.get('dependent_files_intra', [])
    raw_dependent_files_inter = code_context.get('dependent_files_inter', [])
    files_to_modify_primary = fix_strategy.get('files_to_modify_primary', [])
    files_to_modify_secondary = fix_strategy.get('files_to_modify_secondary', [])

    # Normalize dependency entries – backend may send either strings or dicts
    def _extract_paths(items):
        paths = []
        for item in items:
            if isinstance(item, str):
                paths.append(item)
            elif isinstance(item, dict):
                path = item.get('file') or item.get('path') or ""
                if path:
                    paths.append(path)
        return paths

    dependent_files_intra = _extract_paths(raw_dependent_files_intra)
    dependent_files_inter = _extract_paths(raw_dependent_files_inter)
    
    # If no data available, show message
    if not vulnerable_file or vulnerable_file == 'Unknown':
        st.info("ℹ️ Lineage graph will be available after Agent 2 (Code Context) and Agent 3 (Fix Strategy) complete.")
        return
    
    # Check if we have any files to display
    total_files = (
        len(files_to_modify_primary)
        + len(files_to_modify_secondary)
        + len(dependent_files_intra)
        + len(dependent_files_inter)
    )
    if total_files == 0:
        st.info("ℹ️ No additional files identified. Only the vulnerable file will be modified.")
        # Show just the vulnerable file
        graph_html = f"""
        <div style="padding: 2rem; background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%); border-radius: 12px; margin: 1rem 0; border: 2px solid rgba(102, 126, 234, 0.2); text-align: center;">
            <h4 style="margin-bottom: 1.5rem; color: #667eea;">📊 File Lineage & Impact Graph</h4>
            <div style="display: inline-block; padding: 2rem; background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); border: 4px solid #b71c1c; border-radius: 12px; box-shadow: 0 8px 24px rgba(244, 67, 54, 0.4); color: white; max-width: 400px;">
                <div style="font-size: 2rem; margin-bottom: 0.5rem;">🎯</div>
                <div style="font-weight: 700; font-size: 1rem; margin-bottom: 0.5rem;">Vulnerable File</div>
                <div style="font-size: 0.85rem; word-break: break-all;">{vulnerable_file}</div>
                <div style="font-size: 0.75rem; margin-top: 0.5rem; opacity: 0.8;">Only this file will be modified</div>
            </div>
        </div>
        """
        st.markdown(graph_html, unsafe_allow_html=True)
        return
    
    # Create graph visualization HTML
    graph_html = f"""
    <div style="padding: 2rem; background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%); border-radius: 12px; margin: 1rem 0; border: 2px solid rgba(102, 126, 234, 0.2);">
        <h4 style="text-align: center; margin-bottom: 1.5rem; color: #667eea;">📊 File Lineage & Impact Graph</h4>
        <div style="position: relative; min-height: 400px; width: 100%;">
    """
    
    # Center node - Vulnerable file
    center_x = 50  # percentage
    center_y = 50  # percentage
    
    # Add center node (vulnerable file)
    graph_html += f"""
        <div style="
            position: absolute;
            left: {center_x}%;
            top: {center_y}%;
            transform: translate(-50%, -50%);
            width: 200px;
            padding: 1rem;
            background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
            border: 4px solid #b71c1c;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(244, 67, 54, 0.4);
            z-index: 10;
            text-align: center;
            color: white;
        ">
            <div style="font-size: 1.5rem; margin-bottom: 0.5rem;">🎯</div>
            <div style="font-weight: 700; font-size: 0.9rem; margin-bottom: 0.25rem;">Vulnerable File</div>
            <div style="font-size: 0.75rem; word-break: break-all; opacity: 0.9;">{vulnerable_file.split('/')[-1] if '/' in vulnerable_file else vulnerable_file}</div>
            <div style="font-size: 0.7rem; margin-top: 0.5rem; opacity: 0.8;">Vulnerability #{vuln_idx}</div>
        </div>
    """
    
    # Calculate positions for other nodes in a circular layout
    all_files = []
    
    # Primary files to modify
    for i, file_path in enumerate(files_to_modify_primary):
        all_files.append({
            'path': file_path,
            'type': 'primary_modify',
            'label': 'Primary Fix',
            'color': '#2196f3',
            'border': '#1976d2',
            'icon': '🔧'
        })
    
    # Secondary files to modify
    for i, file_path in enumerate(files_to_modify_secondary):
        all_files.append({
            'path': file_path,
            'type': 'secondary_modify',
            'label': 'Secondary Fix',
            'color': '#ff9800',
            'border': '#f57c00',
            'icon': '⚙️'
        })
    
    # Intra-repo dependencies
    for i, file_path in enumerate(dependent_files_intra[:5]):  # Limit to 5 for clarity
        if file_path not in [f['path'] for f in all_files]:
            all_files.append({
                'path': file_path,
                'type': 'intra_dep',
                'label': 'Intra-Repo Dep',
                'color': '#4caf50',
                'border': '#2e7d32',
                'icon': '🔗'
            })
    
    # Inter-repo dependencies
    for i, file_path in enumerate(dependent_files_inter[:3]):  # Limit to 3 for clarity
        if file_path not in [f['path'] for f in all_files]:
            all_files.append({
                'path': file_path,
                'type': 'inter_dep',
                'label': 'Inter-Repo Dep',
                'color': '#9c27b0',
                'border': '#7b1fa2',
                'icon': '🌐'
            })
    
    # Position nodes in a circle around the center
    num_nodes = len(all_files)
    radius = 35  # percentage from center
    
    # Calculate positions for each node
    node_positions = []
    for i, file_info in enumerate(all_files):
        if num_nodes == 1:
            # Single node - position above center
            node_x = center_x
            node_y = center_y - radius * 1.2
        else:
            # Multiple nodes - arrange in circle
            angle_deg = (i * 360 / num_nodes) - 90  # Start from top
            angle_rad = math.radians(angle_deg)
            # Adjust radius based on number of nodes
            radius_adj = radius * (1.3 if num_nodes <= 3 else 1.1 if num_nodes <= 6 else 1.0 if num_nodes <= 10 else 0.85)
            node_x = center_x + radius_adj * math.cos(angle_rad)
            node_y = center_y + radius_adj * math.sin(angle_rad)
        
        node_positions.append((node_x, node_y))
        
    # Create a single SVG element for all connection lines
    graph_html += """
        <svg style="position: absolute; left: 0; top: 0; width: 100%; height: 100%; z-index: 1; pointer-events: none;">
    """
    
    # Draw connections and nodes
    for i, (file_info, (node_x, node_y)) in enumerate(zip(all_files, node_positions)):
        file_name = file_info['path'].split('/')[-1] if '/' in file_info['path'] else file_info['path']
        if len(file_name) > 25:
            file_name = file_name[:22] + "..."
        
        # Add connection line from center to node (inside the single SVG)
        graph_html += f"""
            <line x1="{center_x}%" y1="{center_y}%" x2="{node_x}%" y2="{node_y}%" 
                  stroke="{file_info['border']}" stroke-width="2" stroke-dasharray="5,5" opacity="0.6"/>
        """
        
        # Add file node
        graph_html += f"""
        <div style="
            position: absolute;
            left: {node_x}%;
            top: {node_y}%;
            transform: translate(-50%, -50%);
            width: 160px;
            padding: 0.75rem;
            background: linear-gradient(135deg, {file_info['color']} 0%, {file_info['border']} 100%);
            border: 3px solid {file_info['border']};
            border-radius: 10px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.2);
            z-index: 5;
            text-align: center;
            color: white;
        " title="{file_info['path']}">
            <div style="font-size: 1.2rem; margin-bottom: 0.25rem;">{file_info['icon']}</div>
            <div style="font-weight: 600; font-size: 0.75rem; margin-bottom: 0.25rem; opacity: 0.9;">{file_info['label']}</div>
            <div style="font-size: 0.7rem; word-break: break-all; opacity: 0.95;">{file_name}</div>
        </div>
        """
    
    # Close the SVG element
    graph_html += """
        </svg>
        """
    
    graph_html += """
        </div>
    </div>
    """
    
    st.markdown(graph_html, unsafe_allow_html=True)
    
    # Add legend
    st.markdown("---")
    st.markdown("#### 📋 Legend")
    legend_cols = st.columns(4)
    
    with legend_cols[0]:
        st.markdown(
            '<div style="padding: 0.5rem; background: rgba(244, 67, 54, 0.1); border-left: 4px solid #f44336; border-radius: 4px;">'
            '<strong>🎯 Vulnerable File</strong><br>'
            '<span style="font-size: 0.85rem;">File with the security issue</span>'
            '</div>',
            unsafe_allow_html=True
        )
    
    with legend_cols[1]:
        st.markdown(
            '<div style="padding: 0.5rem; background: rgba(33, 150, 243, 0.1); border-left: 4px solid #2196f3; border-radius: 4px;">'
            '<strong>🔧 Primary Fix</strong><br>'
            '<span style="font-size: 0.85rem;">Files that must be modified</span>'
            '</div>',
            unsafe_allow_html=True
        )
    
    with legend_cols[2]:
        st.markdown(
            '<div style="padding: 0.5rem; background: rgba(255, 152, 0, 0.1); border-left: 4px solid #ff9800; border-radius: 4px;">'
            '<strong>⚙️ Secondary Fix</strong><br>'
            '<span style="font-size: 0.85rem;">Files that may need updates</span>'
            '</div>',
            unsafe_allow_html=True
        )
    
    with legend_cols[3]:
        st.markdown(
            '<div style="padding: 0.5rem; background: rgba(76, 175, 80, 0.1); border-left: 4px solid #4caf50; border-radius: 4px;">'
            '<strong>🔗 Dependencies</strong><br>'
            '<span style="font-size: 0.85rem;">Files that depend on this</span>'
            '</div>',
            unsafe_allow_html=True
        )
    
    # Add summary statistics
    st.markdown("---")
    summary_cols = st.columns(4)
    with summary_cols[0]:
        st.metric("Files to Modify", len(files_to_modify_primary) + len(files_to_modify_secondary))
    with summary_cols[1]:
        st.metric("Primary Files", len(files_to_modify_primary))
    with summary_cols[2]:
        st.metric("Dependencies", len(dependent_files_intra) + len(dependent_files_inter))
    with summary_cols[3]:
        st.metric("Inter-Repo Deps", len(dependent_files_inter))








@st.cache_data(ttl=300)
def fetch_repositories(api_base_url, username=None, email=None, token=None):
    """Fetch repositories from the FastAPI backend using credentials from backend config"""
    try:
        url = f"{api_base_url}/api/repos"
        # Credentials are now loaded from backend/credentials.yaml
        # Request parameters are optional and will override config if provided
        payload = {}
        
        if username:
            payload["username"] = username
        if email:
            payload["email"] = email
        if token:
            payload["token"] = token
        
        response = requests.post(url, json=payload, timeout=300)  # 5 minutes timeout
        
        if response.status_code == 200:
            return response.json(), None
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return None, error_data.get("detail", f"Error {response.status_code}")
    except requests.exceptions.Timeout:
        return None, "Request timed out. Please try again or check the backend server."
    except requests.exceptions.ConnectionError:
        return None, "Cannot connect to API. Make sure the FastAPI server is running on " + api_base_url
    except requests.exceptions.RequestException as e:
        return None, f"Network error: {str(e)}"
    except Exception as e:
        return None, f"Unexpected error: {str(e)}"

def process_active_batch_fix(selected_repo_id, api_url, github_token):
    """Process active batch fix request for a repository."""
    batch_fix_key = f"batch_fix_request_{selected_repo_id}"
    batch_result_key = f"batch_fix_result_{selected_repo_id}"
    
    if batch_fix_key in st.session_state:
        batch_fix_req = st.session_state[batch_fix_key]
        vulnerabilities = batch_fix_req['vulnerabilities']
        selected_repo = batch_fix_req['selected_repo']
        clone_url = selected_repo.get('clone_url', '') or selected_repo.get('html_url', '')
        api_url_val = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
        github_token = st.session_state.get('github_token')
                            
        # Create progress container
        progress_container = st.container()
        status_container = st.empty()
                            
        with progress_container:
            progress_bar = st.progress(0)
            status_text = st.empty()
                            
        # Process batch fix incrementally with progress tracking
        # Initialize batch results if not exists
            # Initialize batch results if not exists
            if batch_result_key not in st.session_state:
                # Filter fixable vulnerabilities
                fixable_vulns = [
                    (idx, vuln) for idx, vuln in enumerate(vulnerabilities, 1)
                    if vuln.get('file_found', False) and vuln.get('matched_file_path')
                ]
                                    
                st.session_state[batch_result_key] = {
                    'total': len(fixable_vulns),
                    'successful': 0,
                    'failed': 0,
                    'skipped': len(vulnerabilities) - len(fixable_vulns),
                    'results': [],
                    'fixable_vulns': fixable_vulns,
                    'current_index': 0,
                    'completed_indices': [],
                    'start_time': time.time(),
                    'duration': 0
                }
            
            # Ensure fixable_vulns is correctly populated even if loading from old state
            batch_results = st.session_state[batch_result_key]
            if not batch_results.get('fixable_vulns'):
                batch_results['fixable_vulns'] = [
                    (idx, vuln) for idx, vuln in enumerate(vulnerabilities, 1)
                    if vuln.get('file_found', False) and vuln.get('matched_file_path')
                ]

            fixable_vulns = batch_results.get('fixable_vulns', [])
            current_index = batch_results.get('current_index', 0)
            # Restore completed_indices from batch_results, ensuring it's a list
            completed_indices = batch_results.get('completed_indices', [])
            if not isinstance(completed_indices, list):
                completed_indices = []
            # Ensure we have a copy to avoid reference issues
            completed_indices = completed_indices.copy() if completed_indices else []
            auto_create_pr = batch_fix_req.get('auto_create_pr', False)
        
            # ------------------------------------------------------------------
            # AUTO PR MODE: process incrementally but create single batch PR at end
            # ------------------------------------------------------------------
            if auto_create_pr:
                # In auto PR mode, we process vulnerabilities incrementally (one at a time)
                # to show progress in the flow visualization, but we collect all successful
                # fixes and create a SINGLE batch PR at the end to avoid conflicts.
                                    
                # Derive the next index to process from completed_indices
                if fixable_vulns:
                    all_indices = set(range(len(fixable_vulns)))
                    remaining_indices = sorted(all_indices - set(completed_indices))
                    if remaining_indices:
                        current_index = remaining_indices[0]
                    else:
                        # All indices completed - create batch PR
                        current_index = len(fixable_vulns)
                    batch_results['current_index'] = current_index
                    st.session_state[batch_result_key] = batch_results
                                    
                # Check if all fixes are done - if so, run validation testing and create batch PR
                if current_index >= len(fixable_vulns):
                    logger.info(f"[BatchFix] All fixes done for {selected_repo_id}. Starting validation/PR block.")
                    
                    # --- Step 5b: Run Validation Testing on LOCAL fixed code ---
                    if not batch_results.get('validation_test_results') and not batch_results.get('test_results'):
                        # Find the local repository path where fixes were applied
                        repo_path = None
                        
                        # Try to get repo_path from the first successful fix result
                        for result_entry in batch_results.get('results', []):
                            if result_entry.get('status') == 'success' and result_entry.get('result'):
                                fix_result = result_entry['result']
                                if isinstance(fix_result, dict):
                                    repo_path = fix_result.get('repo_path')
                                    if repo_path:
                                        break
                        
                        # If not found in results, try to infer from shared volume or backend structure
                        if not repo_path:
                            repo_name_val = selected_repo.get('name', '')
                            if repo_name_val:
                                # Try common paths in order of likelihood
                                candidates = [
                                    os.path.join("/app", "temp_cloned_repos", repo_name_val),
                                    os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend', 'temp_cloned_repos', repo_name_val))
                                ]
                                for cand in candidates:
                                    if os.path.exists(cand):
                                        repo_path = cand
                                        logger.info(f"[BatchFix] Inferred repo path: {repo_path}")
                                        break
                        
                        if not repo_path:
                            logger.error(f"[BatchFix] Could not find repo path for {selected_repo.get('name')}")
                        
                        if repo_path and os.path.exists(repo_path):
                            status_text.info("🧪 Running validation testing on fixed code (this may take several minutes)...")
                            
                            # Call Atlas testing agent with LOCAL repository path
                            with st.spinner("🧪 Analyzing fixed code and running generated tests..."):
                                try:
                                    test_url = f"{api_url_val}/api/testing/jobs"
                                    test_data = {
                                        'repo_path': repo_path,
                                        'repo_url': selected_repo.get('clone_url') or selected_repo.get('html_url') or "local",
                                        'create_pr': False
                                    }
                                    
                                    # Retry logic for 409 Conflict (pipeline already running)
                                    max_retries = 6
                                    retry_delay = 30  # seconds between retries
                                    test_res = None
                                    last_error = None
                                    
                                    for attempt in range(max_retries + 1):
                                        test_response = requests.post(test_url, json=test_data, timeout=60)
                                        
                                        if test_response.status_code == 200:
                                            job_data = test_response.json()
                                            job_id = job_data.get("job_id")
                                            
                                            log_container = st.empty()
                                            stream_url = f"{api_url_val}/api/testing/jobs/{job_id}/stream"
                                            
                                            with requests.get(stream_url, stream=True, timeout=3600) as r:
                                                r.raise_for_status()
                                                for line in r.iter_lines():
                                                    if line:
                                                        decoded = line.decode('utf-8')
                                                        if decoded.startswith("data: "):
                                                            data_str = decoded[6:]
                                                            if data_str == "[DONE]":
                                                                break
                                                            try:
                                                                event_data = json.loads(data_str)
                                                                status = event_data.get("status", "RUNNING")
                                                                msg = event_data.get("message", "")
                                                                log_container.info(f"⏳ **{status}**: {msg}")
                                                            except json.JSONDecodeError:
                                                                pass
                                                                
                                            result_url = f"{api_url_val}/api/testing/jobs/{job_id}"
                                            result_response = requests.get(result_url, timeout=60)
                                            if result_response.status_code == 200:
                                                final_job = result_response.json()
                                                if final_job.get("status") == "COMPLETED":
                                                    test_res = final_job.get("result")
                                                    logger.info(f"[BatchFix] Validation testing successful for {selected_repo_id}")
                                                    batch_results['validation_test_results'] = test_res
                                                    log_container.empty()
                                                    break
                                                else:
                                                    last_error = final_job.get("error", "Job failed during execution")
                                                    logger.error(f"[BatchFix] Validation testing failed for {selected_repo_id}: {last_error}")
                                                    batch_results['validation_test_results'] = {'error': last_error}
                                                    log_container.empty()
                                                    break
                                            else:
                                                last_error = f"Failed to fetch job result: {result_response.status_code}"
                                                logger.error(f"[BatchFix] {last_error}")
                                                batch_results['validation_test_results'] = {'error': last_error}
                                                log_container.empty()
                                                break
                                                
                                        elif test_response.status_code == 409 and attempt < max_retries:
                                            # Pipeline already running — wait and retry
                                            logger.warning(f"[BatchFix] Pipeline busy (409), retrying in {retry_delay}s (attempt {attempt + 1}/{max_retries})")
                                            status_text.info(f"⏳ Testing pipeline busy, retrying in {retry_delay}s (attempt {attempt + 1}/{max_retries})...")
                                            time.sleep(retry_delay)
                                        else:
                                            error_data = test_response.json() if test_response.content else {}
                                            last_error = error_data.get('detail', f'HTTP {test_response.status_code}')
                                            logger.error(f"[BatchFix] Validation testing failed for {selected_repo_id}: {last_error}")
                                            batch_results['validation_test_results'] = {'error': last_error}
                                            break
                                    else:
                                        # All retries exhausted
                                        logger.error(f"[BatchFix] Validation testing exhausted all retries for {selected_repo_id}")
                                        batch_results['validation_test_results'] = {'error': 'Pipeline busy after all retries. Please re-run validation manually.'}
                                    
                                except Exception as e:
                                    logger.error(f"[BatchFix] Exception during validation testing: {e}")
                                    batch_results['validation_test_results'] = {'error': str(e)}
                                
                                # Save state immediately after testing
                                st.session_state[batch_result_key] = batch_results
                        else:
                            logger.warning(f"[BatchFix] Could not find local repo path for validation testing")
                            batch_results['validation_test_results'] = {'error': 'Local repository path not found'}

                    # Check if PR already exists for this batch
                    if batch_results.get('batch_pr_result'):
                        logger.info(f"[BatchFix] PR already exists for {selected_repo_id}. Finishing.")
                        # Already done, just clear request key and finish
                        if batch_fix_key in st.session_state:
                            del st.session_state[batch_fix_key]
                        st.session_state[batch_result_key] = batch_results
                        st.rerun()
                        return

                    # All fixes completed, now create single batch PR
                    successful_fixes = [
                        r for r in batch_results.get('results', [])
                        if r.get('status') == 'success' and r.get('result')
                    ]
                    
                    logger.info(f"[BatchFix] Successful fixes found: {len(successful_fixes)}/{len(fixable_vulns)}")
                    
                    if successful_fixes:
                        # Create batch PR using API endpoint
                        try:
                            # Robust repo owner determination 
                            repo_owner = None
                            full_name = selected_repo.get('full_name', '')
                            if full_name:
                                if '/' in full_name:
                                    repo_owner = full_name.split('/')[0]
                                else:
                                    repo_owner = full_name # Fallback for local/non-GitHub formats
                            
                            if not repo_owner and clone_url and 'github.com' in clone_url:
                                parts = clone_url.replace('https://github.com/', '').replace('.git', '').split('/')
                                if len(parts) >= 1:
                                    repo_owner = parts[0]
                            
                            if not repo_owner:
                                # Final fallback from login info or default
                                repo_owner = st.session_state.get('github_user') or 'unknown'
                            
                            logger.info(f"[BatchFix] repo_owner: {repo_owner}, token: {'Present' if github_token else 'Missing'}")
                                                
                            if repo_owner and github_token:
                                # Get repo_path from first successful fix
                                repo_path = None
                                for fix in successful_fixes:
                                    fix_result = fix.get('result', {})
                                    if isinstance(fix_result, dict):
                                        repo_path = fix_result.get('repo_path') or fix_result.get('result', {}).get('repo_path', '')
                                        if repo_path:
                                            logger.info(f"[BatchFix] Found repo_path: {repo_path}")
                                            # Check if path exists (might be backend path)
                                            # Try to infer if it's a backend path
                                            # If path doesn't exist locally (e.g. backend path), try inference
                                            if not os.path.exists(repo_path):
                                                repo_name_val = selected_repo.get('name', '')
                                                if repo_name_val:
                                                    candidates = [
                                                        os.path.join("/app", "temp_cloned_repos", repo_name_val),
                                                        os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend', 'temp_cloned_repos', repo_name_val))
                                                    ]
                                                    for cand in candidates:
                                                        if os.path.exists(cand):
                                                            repo_path = cand
                                                            logger.info(f"[BatchFix] Inferred PR path: {repo_path}")
                                                            break
                                            if repo_path and os.path.exists(repo_path):
                                                break
                                                    
                                if repo_path:
                                    status_text.info("🔀 Creating single batch PR for all successful fixes...")
                                                        
                                    # Prepare successful fixes in format expected by API
                                    fixes_for_pr = []
                                    for fix in successful_fixes:
                                        fixes_for_pr.append({
                                            'vuln_idx': fix.get('vuln_idx'),
                                            'result': fix.get('result')
                                        })
                                                        
                                    # Call backend API to create single batch PR
                                    try:
                                        pr_data = {
                                            'successful_fixes_json': json.dumps(fixes_for_pr),
                                            'repo_owner': str(repo_owner).strip(),
                                            'repo_name': str(selected_repo.get('name', '')).strip(),
                                            'repo_path': str(repo_path).strip(),
                                            'token': str(github_token).strip(),
                                            'base_branch': 'main'
                                        }
                                        
                                        # Include validation test results if available
                                        v_test_res = batch_results.get('validation_test_results') or batch_results.get('test_results')
                                        if v_test_res:
                                            pr_data['test_results_json'] = json.dumps(v_test_res)
                                                            
                                        pr_response = requests.post(
                                            f"{api_url_val}/api/fixes/create-single-batch-pr",
                                            data=pr_data,
                                            timeout=300
                                        )
                                                            
                                        if pr_response.status_code == 200:
                                            batch_pr = pr_response.json()
                                            if batch_pr and batch_pr.get('success'):
                                                batch_results['batch_pr_result'] = batch_pr
                                                status_text.success(
                                                    f"✅ **Batch Fix Complete!**\n\n"
                                                    f"✅ **Successful**: {batch_results['successful']}\n"
                                                    f"❌ **Failed**: {batch_results['failed']}\n"
                                                    f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                                    f"📊 **Total**: {batch_results['total']}\n\n"
                                                    f"🔗 **Batch PR Created**: PR #{batch_pr.get('pr_number', 'N/A')} - {batch_pr.get('pr_url', 'N/A')}\n\n"
                                                    f"*Review individual fix results below for details.*"
                                                )
                                            else:
                                                error_msg = batch_pr.get('message', 'Unknown error') if batch_pr else 'Failed to create batch PR'
                                                status_text.warning(
                                                    f"✅ **Batch Fix Complete!**\n\n"
                                                    f"✅ **Successful**: {batch_results['successful']}\n"
                                                    f"❌ **Failed**: {batch_results['failed']}\n"
                                                    f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                                    f"📊 **Total**: {batch_results['total']}\n\n"
                                                    f"⚠️ **PR Creation Failed**: {error_msg}\n\n"
                                                    f"*Review individual fix results below for details.*"
                                                )
                                        else:
                                            try:
                                                error_response = pr_response.json()
                                                error_detail = error_response.get('detail', 'Unknown error')
                                                if isinstance(error_detail, list):
                                                    error_messages = []
                                                    for err in error_detail:
                                                        if isinstance(err, dict):
                                                            loc = err.get('loc', [])
                                                            msg = err.get('msg', '')
                                                            error_messages.append(f"{'.'.join(str(x) for x in loc)}: {msg}")
                                                    error_detail = '; '.join(error_messages) if error_messages else 'Validation error'
                                            except:
                                                error_detail = pr_response.text[:500] if hasattr(pr_response, 'text') else f'HTTP {pr_response.status_code}'
                                                                
                                            status_text.warning(
                                                f"✅ **Batch Fix Complete!**\n\n"
                                                f"✅ **Successful**: {batch_results['successful']}\n"
                                                f"❌ **Failed**: {batch_results['failed']}\n"
                                                f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                                f"📊 **Total**: {batch_results['total']}\n\n"
                                                f"⚠️ **PR Creation Failed**: {error_detail}\n\n"
                                                f"*Review individual fix results below for details.*"
                                            )
                                    except requests.exceptions.RequestException as api_error:
                                        logger.error(f"API error creating batch PR: {str(api_error)}")
                                        status_text.warning(
                                            f"✅ **Batch Fix Complete!**\n\n"
                                            f"✅ **Successful**: {batch_results['successful']}\n"
                                            f"❌ **Failed**: {batch_results['failed']}\n"
                                            f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                            f"📊 **Total**: {batch_results['total']}\n\n"
                                            f"⚠️ **PR Creation Error**: {str(api_error)}\n\n"
                                            f"*Review individual fix results below for details.*"
                                        )
                                else:
                                    msg = "Repository path not found. Cannot create batch PR."
                                    status_text.warning(f"✅ All fixes completed, but {msg}")
                                    batch_results['batch_pr_result'] = {'success': False, 'message': msg}
                            elif not repo_owner:
                                msg = "Repository owner not found. Cannot create batch PR."
                                status_text.warning(f"✅ All fixes completed, but {msg}")
                                batch_results['batch_pr_result'] = {'success': False, 'message': msg}
                            elif not github_token:
                                msg = "GitHub token not available. Cannot create batch PR."
                                status_text.warning(f"✅ All fixes completed, but {msg}")
                                batch_results['batch_pr_result'] = {'success': False, 'message': msg}
                        except Exception as pr_error:
                            logger.error(f"Error creating batch PR: {str(pr_error)}")
                            status_text.warning(
                                f"✅ **Batch Fix Complete!**\n\n"
                                f"✅ **Successful**: {batch_results['successful']}\n"
                                f"❌ **Failed**: {batch_results['failed']}\n"
                                f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                f"📊 **Total**: {batch_results['total']}\n\n"
                                f"⚠️ **PR Creation Error**: {str(pr_error)}\n\n"
                                f"*Review individual fix results below for details.*"
                            )
                    else:
                        status_text.success(
                            f"✅ **Batch Fix Complete!**\n\n"
                            f"✅ **Successful**: {batch_results['successful']}\n"
                            f"❌ **Failed**: {batch_results['failed']}\n"
                            f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                            f"📊 **Total**: {batch_results['total']}\n\n"
                            f"*No successful fixes to create PR for.*"
                        )
                                        
                    # IMPORTANT: Clear the in-progress key to allow next repo to process
                    if batch_fix_key in st.session_state:
                        del st.session_state[batch_fix_key]
                    
                    # Calculate total duration if start_time exists
                    if batch_results.get('start_time'):
                        batch_results['duration'] = time.time() - batch_results['start_time']
                    
                    st.session_state[batch_result_key] = batch_results
                    st.rerun() # Refresh to show final summary or next repo
                else:
                    # Process current vulnerability (same as normal mode but without individual PRs)
                    vuln_idx, vuln = fixable_vulns[current_index]
                    vuln_type = vuln.get('vulnerability', 'Unknown')
                    file_path = vuln.get('matched_file_path', 'N/A')
                    line_no = vuln.get('line_no', 'N/A')
                                        
                    # Update progress
                    completed_count = len(completed_indices)
                    progress = (completed_count + 1) / batch_results['total'] if batch_results['total'] > 0 else 0
                    progress_bar.progress(progress)
                                        
                    # Clear status message showing current vulnerability
                    status_text.markdown(
                        f"**Fixing Vulnerability {current_index + 1}/{batch_results['total']}**\n\n"
                        f"🔹 **Vulnerability #{vuln_idx}**: {vuln_type}\n"
                        f"🔹 **File**: `{file_path}`\n"
                        f"🔹 **Line**: {line_no}\n\n"
                        f"**Running AI Agents:**\n"
                        f"1. 🔍 Code Context Agent\n"
                        f"2. 📋 Fix Strategy Agent\n"
                        f"3. 🔧 Code Fix Agent\n"
                        f"4. ✅ Safety Validator Agent\n\n"
                        f"*Check backend logs for detailed agent progress*\n"
                        f"*A single batch PR will be created after all fixes complete*"
                    )
                                        
                    # Display flow visualization
                    with status_container.container():
                        st.markdown("---")
                        st.markdown("### 🔄 Fix Progress Flow")
                        display_vulnerability_flow(fixable_vulns, current_index, completed_indices, batch_results)
                                        
                    clone_url = selected_repo.get('clone_url') or selected_repo.get('html_url', '')
                    repo_name = selected_repo.get('name', 'unknown')
                                        
                    # Call orchestrate_fix for individual vulnerability
                    with st.spinner(
                        f"🤖 Processing Vulnerability {completed_count + 1}/{batch_results['total']}: {vuln_type}\n"
                        f"Running AI agents sequentially... This may take 1-3 minutes."
                    ):
                        fix_start_time = time.time()
                        result, error = orchestrate_fix(
                            api_url=api_url_val,
                            vulnerability_type=vuln.get('vulnerability', 'Unknown'),
                            description=vuln.get('description', ''),
                            severity=vuln.get('severity', 'high').lower() if vuln.get('severity') else 'high',
                            file_path=vuln.get('matched_file_path'),
                            line_number=int(vuln.get('line_no', 0)) if str(vuln.get('line_no', '0')).isdigit() else 0,
                            repo_path=None,
                            repo_name=repo_name,
                            clone_url=clone_url,
                            token=github_token,
                            recommendation=vuln.get('recommendation')
                        )
                        fix_duration = time.time() - fix_start_time
                                        
                    # Process result (same as normal mode but skip individual PR creation)
                    if error:
                        batch_results['failed'] += 1
                        batch_results['results'].append({
                            'vuln_idx': vuln_idx,
                            'vulnerability_type': vuln_type,
                            'file_path': file_path,
                            'status': 'failed',
                            'error': error,
                            'result': None,
                            'duration': fix_duration
                        })
                        # Mark as completed (even though failed) for flow visualization
                        if current_index not in completed_indices:
                            completed_indices.append(current_index)
                                            
                        # Update batch_results with completed indices BEFORE moving to next
                        batch_results['completed_indices'] = completed_indices.copy()
                        batch_results['current_index'] = current_index + 1
                                            
                        # Save to session state IMMEDIATELY
                        st.session_state[batch_result_key] = batch_results
                                            
                        status_text.error(
                            f"❌ **Failed to fix Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                            f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                            f"**Error**: {error}\n\n"
                            f"Check backend logs for detailed error information."
                        )
                                            
                        # Update flow visualization AFTER state is saved
                        with status_container.container():
                            st.markdown("---")
                            st.markdown("### 🔄 Fix Progress Flow")
                            display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                                            
                        # Continue to next fix
                        st.rerun()
                    else:
                        # Add repo info to result
                        if result and isinstance(result, dict):
                            result['repo_name'] = repo_name
                            result['repo_path'] = result.get('repo_path', '') or result.get('result', {}).get('repo_path', '')
                            result['vulnerability_type'] = vuln_type
                            result['description'] = vuln.get('description', '')
                                            
                        batch_results['successful'] += 1
                        result_entry = {
                            'vuln_idx': vuln_idx,
                            'vulnerability_type': vuln_type,
                            'file_path': file_path,
                            'status': 'success',
                            'error': None,
                            'result': result,
                            'duration': fix_duration
                        }
                                            
                        batch_results['results'].append(result_entry)
                                            
                        # Store individual fix result for display
                        fix_result_key = f'fix_result_{selected_repo_id}_{vuln_idx}'
                        st.session_state[fix_result_key] = result
                                            
                        # Mark as completed
                        if current_index not in completed_indices:
                            completed_indices.append(current_index)
                                            
                        # Update batch_results with completed indices BEFORE moving to next
                        batch_results['completed_indices'] = completed_indices.copy()
                                            
                        # Move to next fix
                        batch_results['current_index'] = current_index + 1
                                            
                        # Save to session state IMMEDIATELY to ensure state is persisted
                        st.session_state[batch_result_key] = batch_results
                                            
                        status_text.success(
                            f"✅ **Successfully fixed Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                            f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                            f"**File**: `{file_path}`\n"
                            f"**Line**: {line_no}\n\n"
                            f"*A batch PR will be created after all fixes complete*"
                        )
                                            
                        # Update flow visualization AFTER state is saved
                        # Show current vulnerability as completed, next one as processing
                        with status_container.container():
                            st.markdown("---")
                            st.markdown("### 🔄 Fix Progress Flow")
                            display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                                            
                        # Continue to next fix
                st.rerun()
        
            # ------------------------------------------------------------------
            # NORMAL MODE (no auto PR): incremental per-vulnerability fixes
            # ------------------------------------------------------------------
            # Derive the next index to process from completed_indices so that
            # we never get stuck on a vulnerability due to stale state.
            if fixable_vulns:
                all_indices = set(range(len(fixable_vulns)))
                remaining_indices = sorted(all_indices - set(completed_indices))
                if remaining_indices:
                    current_index = remaining_indices[0]
                else:
                    # All indices completed
                    current_index = len(fixable_vulns)
                    batch_results['current_index'] = current_index
                st.session_state[batch_result_key] = batch_results
                                    
            # Process fixes one at a time with clear progress
            if current_index < len(fixable_vulns):
                if current_index >= len(fixable_vulns):
                    # All fixes completed
                    if batch_fix_key in st.session_state:
                        del st.session_state[batch_fix_key]
                    progress_bar.progress(1.0)
                    status_text.success(
                        f"🎉 **Batch Fix Complete!**\n\n"
                        f"✅ **Successful**: {batch_results['successful']}\n"
                        f"❌ **Failed**: {batch_results['failed']}\n"
                        f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                        f"📊 **Total**: {batch_results['total']}\n\n"
                        f"*Review individual fix results below for details.*"
                    )
                else:
                    # Process current vulnerability
                    vuln_idx, vuln = fixable_vulns[current_index]
                    vuln_type = vuln.get('vulnerability', 'Unknown')
                    file_path = vuln.get('matched_file_path', 'N/A')
                    line_no = vuln.get('line_no', 'N/A')
                                        
                    # Update progress
                    completed_count = len(completed_indices)
                    progress = (completed_count + 1) / batch_results['total'] if batch_results['total'] > 0 else 0
                    progress_bar.progress(progress)
                                        
                    # Clear status message showing current vulnerability
                    status_text.markdown(
                        f"**Fixing Vulnerability {current_index + 1}/{batch_results['total']}**\n\n"
                        f"🔹 **Vulnerability #{vuln_idx}**: {vuln_type}\n"
                        f"🔹 **File**: `{file_path}`\n"
                        f"🔹 **Line**: {line_no}\n\n"
                        f"**Running AI Agents:**\n"
                        f"1. 🔍 Code Context Agent\n"
                        f"2. 📋 Fix Strategy Agent\n"
                        f"3. 🔧 Code Fix Agent\n"
                        f"4. ✅ Safety Validator Agent\n\n"
                        f"*Check backend logs for detailed agent progress*"
                    )
                                        
                    # Display flow visualization
                    with status_container:
                        st.markdown("---")
                        st.markdown("### 🔄 Fix Progress Flow")
                        display_vulnerability_flow(fixable_vulns, current_index, completed_indices, batch_results)
                                        
                    clone_url = selected_repo.get('clone_url') or selected_repo.get('html_url', '')
                    repo_name = selected_repo.get('name', 'unknown')
                                        
                    # Call orchestrate_fix for individual vulnerability
                    with st.spinner(
                        f"🤖 Processing Vulnerability {completed_count + 1}/{batch_results['total']}: {vuln_type}\n"
                        f"Running AI agents sequentially... This may take 1-3 minutes."
                    ):
                        result, error = orchestrate_fix(
                            api_url=api_url_val,
                            vulnerability_type=vuln.get('vulnerability', 'Unknown'),
                            description=vuln.get('description', ''),
                            severity=vuln.get('severity', 'high').lower() if vuln.get('severity') else 'high',
                            file_path=vuln.get('matched_file_path'),
                            line_number=int(vuln.get('line_no', 0)) if str(vuln.get('line_no', '0')).isdigit() else 0,
                            repo_path=None,
                            repo_name=repo_name,
                            clone_url=clone_url,
                            token=github_token,
                            recommendation=vuln.get('recommendation')
                        )
                                        
                    # Initialize pr_result
                    pr_result = None
                                        
                    # Process result
                    if error:
                        batch_results['failed'] += 1
                        batch_results['results'].append({
                            'vuln_idx': vuln_idx,
                            'vulnerability_type': vuln_type,
                            'file_path': file_path,
                            'status': 'failed',
                            'error': error,
                            'result': None
                        })
                        # Mark as completed (even though failed) for flow visualization
                        if current_index not in completed_indices:
                            completed_indices.append(current_index)
                        
                        # Update batch_results with completed indices BEFORE moving to next
                        batch_results['completed_indices'] = completed_indices.copy()
                        batch_results['current_index'] = current_index + 1
                        
                        # Save to session state IMMEDIATELY
                        st.session_state[batch_result_key] = batch_results
                        
                        status_text.error(
                            f"❌ **Failed to fix Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                            f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                            f"**Error**: {error}\n\n"
                            f"Check backend logs for detailed error information."
                        )
                        
                        # Update flow visualization AFTER state is saved
                        with status_container:
                            st.markdown("---")
                            st.markdown("### 🔄 Fix Progress Flow")
                            display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                        
                        # Continue to next fix
                        if current_index + 1 < len(fixable_vulns):
                            st.rerun()
                        else:
                            # All fixes completed
                            if batch_fix_key in st.session_state:
                                del st.session_state[batch_fix_key]
                            progress_bar.progress(1.0)
                            status_text.success(
                                f"🎉 **Batch Fix Complete!**\n\n"
                                f"✅ **Successful**: {batch_results['successful']}\n"
                                f"❌ **Failed**: {batch_results['failed']}\n"
                                f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                f"📊 **Total**: {batch_results['total']}\n\n"
                                f"*Review individual fix results below for details.*"
                            )
                    else:
                        # Add repo info to result
                        if result and isinstance(result, dict):
                            result['repo_name'] = repo_name
                            # Get repo_path from top level (API returns it there) or from result data
                            result['repo_path'] = result.get('repo_path', '') or result.get('result', {}).get('repo_path', '')
                            result['vulnerability_type'] = vuln_type
                            result['description'] = vuln.get('description', '')
                                            
                        # If auto PR is enabled and fix was successful, create PR
                        if auto_create_pr and not error and result and result.get('success'):
                            status_text.success(
                                f"✅ **Successfully fixed Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                                f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                                f"**File**: `{file_path}`\n"
                                f"**Line**: {line_no}\n\n"
                                f"🔀 Creating Pull Request..."
                            )
                                                
                            # Get repository info for PR creation
                            repo_info = None
                            if 'repositories_data' in st.session_state:
                                repos_data = st.session_state['repositories_data']
                                for repo in repos_data.get('repositories', []):
                                    if repo.get('name') == selected_repo.get('name') or repo.get('id') == selected_repo_id:
                                        repo_info = repo
                                        break
                                                
                            repo_owner = selected_repo.get('full_name', '').split('/')[0] if '/' in selected_repo.get('full_name', '') else None
                                                
                            if repo_info:
                                # Extract repo owner if not already set
                                if not repo_owner:
                                    owner_data = repo_info.get('owner', {})
                                    if isinstance(owner_data, dict):
                                        repo_owner = owner_data.get('login', '') or owner_data.get('name', '')
                                    else:
                                        repo_owner = str(owner_data) if owner_data else ''
                                                    
                                if not repo_owner:
                                    full_name = repo_info.get('full_name', '')
                                    if isinstance(full_name, str) and "/" in full_name:
                                        repo_owner = full_name.split("/")[0]
                                                
                            if not repo_owner and clone_url and 'github.com' in clone_url:
                                parts = clone_url.replace('https://github.com/', '').replace('.git', '').split('/')
                                if len(parts) >= 1:
                                    repo_owner = parts[0]
                                                
                            if repo_owner and github_token:
                                # Extract required fields from fix result for PR creation
                                files_modified, fixed_code_map = extract_fixed_code_from_result(result)
                                                    
                                # Get vulnerability details
                                result_data = result.get('result', {}) if isinstance(result, dict) else result
                                code_fix = result_data.get('code_fix', {}) if isinstance(result_data, dict) else {}
                                                    
                                vuln_type_for_pr = result.get('vulnerability_type', vuln_type)
                                vuln_desc_for_pr = result.get('description', vuln.get('description', ''))
                                fix_summary = code_fix.get('change_summary', f'Fixed {vuln_type_for_pr} vulnerability') if code_fix else f'Fixed {vuln_type_for_pr} vulnerability'
                                                    
                                # Get repo_path - check multiple locations
                                # API returns repo_path at top level of response
                                repo_path_for_pr = result.get('repo_path', '')
                                if not repo_path_for_pr:
                                    # Try from result data
                                    repo_path_for_pr = result_data.get('repo_path', '') if isinstance(result_data, dict) else ''
                                                    
                                # If still missing, try to infer from backend temp_cloned_repos location
                                if not repo_path_for_pr or not os.path.exists(repo_path_for_pr):
                                    try:
                                        # Infer from standard backend structure
                                        frontend_dir = os.path.dirname(os.path.abspath(__file__))
                                        project_root = os.path.dirname(frontend_dir)
                                        backend_dir_local = os.path.join(project_root, "backend")
                                        repo_name_local = result.get('repo_name', repo_name)
                                        if repo_name_local:
                                            inferred_path = os.path.join(backend_dir_local, "temp_cloned_repos", repo_name_local)
                                            if os.path.exists(inferred_path):
                                                repo_path_for_pr = inferred_path
                                    except Exception:
                                        pass
                                                    
                                # Final validation - ensure repo_path exists
                                if repo_path_for_pr and not os.path.exists(repo_path_for_pr):
                                    # Path doesn't exist, try to find it
                                    repo_path_for_pr = ''
                                                    
                                # Validate we have required data
                                if not files_modified or not fixed_code_map:
                                    pr_result = {
                                        'success': False,
                                        'message': 'Missing files_modified or fixed_code in fix result. Cannot create PR.'
                                    }
                                    status_text.text(
                                        f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                        f"❌ PR Error: Missing fix data"
                                    )
                                elif not repo_path_for_pr:
                                    pr_result = {
                                        'success': False,
                                        'message': 'Repository path is missing. Cannot create PR.'
                                    }
                                    status_text.text(
                                        f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                        f"❌ PR Error: Missing repository path"
                                    )
                                elif not vuln_type_for_pr or not vuln_desc_for_pr:
                                    pr_result = {
                                        'success': False,
                                        'message': 'Vulnerability details are missing. Cannot create PR.'
                                    }
                                    status_text.text(
                                        f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                        f"❌ PR Error: Missing vulnerability details"
                                    )
                                else:
                                    # Create PR using the create_pr API
                                    try:
                                        api_url = api_url_val
                                                            
                                        # Ensure all required fields are strings and not empty
                                        pr_data = {
                                            'repo_owner': str(repo_owner).strip(),
                                            'repo_name': str(repo_name).strip(),
                                            'repo_path': str(repo_path_for_pr).strip(),
                                            'files_modified_json': json.dumps(files_modified),
                                            'fixed_code_json': json.dumps(fixed_code_map),
                                            'vulnerability_type': str(vuln_type_for_pr).strip(),
                                            'vulnerability_description': str(vuln_desc_for_pr).strip() or 'Security vulnerability fix',
                                            'fix_summary': str(fix_summary).strip() or f'Fixed {vuln_type_for_pr} vulnerability',
                                            'token': str(github_token).strip(),
                                            'base_branch': 'main'
                                        }
                                                            
                                        # Validate all required fields are present and non-empty
                                        # Check string fields
                                        required_string_fields = ['repo_owner', 'repo_name', 'repo_path', 'vulnerability_type', 'vulnerability_description', 'fix_summary', 'token']
                                        missing_fields = [field for field in required_string_fields if not pr_data.get(field) or (isinstance(pr_data.get(field), str) and not pr_data.get(field).strip())]
                                                            
                                        # Validate JSON fields separately
                                        if not files_modified or not pr_data.get('files_modified_json') or pr_data.get('files_modified_json') == '[]':
                                            missing_fields.append('files_modified_json')
                                        if not fixed_code_map or not pr_data.get('fixed_code_json') or pr_data.get('fixed_code_json') == '{}':
                                            missing_fields.append('fixed_code_json')
                                                            
                                        if missing_fields:
                                            missing_fields_str = ", ".join(missing_fields)
                                            pr_result = {
                                                'success': False,
                                                'message': f'Missing required fields: {missing_fields_str}'
                                            }
                                            status_text.text(
                                                f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                f"❌ PR Error: Missing fields: {missing_fields_str}"
                                            )
                                        else:
                                            # Debug: Log what we're sending (without token)
                                            debug_data = {k: v if k != 'token' else '***' for k, v in pr_data.items()}
                                            logger.debug(f"Creating PR with data: {debug_data}")
                                                                
                                            pr_response = requests.post(
                                                f"{api_url}/api/fixes/create-pr",
                                                data=pr_data,
                                                timeout=300
                                            )
                                                                
                                            if pr_response.status_code == 200:
                                                pr_result = pr_response.json()
                                                if pr_result.get('success'):
                                                    status_text.text(
                                                        f"✅ Fixed & PR Created: {completed_count + 1}/{batch_results['total']}\n"
                                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                        f"🔗 PR #{pr_result.get('pr_number', 'N/A')}"
                                                    )
                                                else:
                                                    pr_result = {'success': False, 'message': pr_result.get('message', 'Unknown error')}
                                                    status_text.text(
                                                        f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                        f"❌ PR Error: {pr_result.get('message', 'Unknown error')}"
                                                    )
                                            else:
                                                # Better error handling for 422 and other errors
                                                try:
                                                    error_response = pr_response.json()
                                                    error_detail = error_response.get('detail', 'Unknown error')
                                                    # If detail is a list (FastAPI validation errors), format it
                                                    if isinstance(error_detail, list):
                                                        error_messages = []
                                                        for err in error_detail:
                                                            if isinstance(err, dict):
                                                                loc = err.get('loc', [])
                                                                msg = err.get('msg', '')
                                                                error_messages.append(f"{'.'.join(str(x) for x in loc)}: {msg}")
                                                        error_detail = '; '.join(error_messages) if error_messages else 'Validation error'
                                                except:
                                                    error_detail = pr_response.text[:500] if hasattr(pr_response, 'text') else f'HTTP {pr_response.status_code}'
                                                                    
                                                pr_result = {'success': False, 'message': error_detail}
                                                logger.error(f"PR creation failed (HTTP {pr_response.status_code}): {error_detail}")
                                                status_text.text(
                                                    f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                    f"❌ PR Error: {error_detail}"
                                                )
                                    except Exception as pr_error:
                                        logger.error(f"Error creating PR: {str(pr_error)}")
                                        pr_result = {'success': False, 'message': str(pr_error)}
                                        status_text.text(
                                            f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                            f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                            f"❌ PR Exception: {str(pr_error)}"
                                        )
                            else:
                                # Missing repo_owner or token - skip PR creation
                                pr_result = None
                                if not repo_owner:
                                    status_text.text(
                                        f"✅ Fixed but PR Skipped: {completed_count + 1}/{batch_results['total']}\n"
                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                        f"⚠️ Missing repository owner"
                                    )
                                elif not github_token:
                                    status_text.text(
                                        f"✅ Fixed but PR Skipped: {completed_count + 1}/{batch_results['total']}\n"
                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                        f"⚠️ Missing GitHub token"
                                    )
                                            
                        batch_results['successful'] += 1
                        result_entry = {
                            'vuln_idx': vuln_idx,
                            'vulnerability_type': vuln_type,
                            'file_path': file_path,
                            'status': 'success',
                            'error': None,
                            'result': result
                        }
                                            
                        # Add PR result if auto PR was enabled and PR was created
                        if auto_create_pr and pr_result:
                            if not batch_results.get('pr_results'):
                                batch_results['pr_results'] = []
                                                
                            pr_entry = {
                                'vuln_idx': vuln_idx,
                                'status': 'success' if pr_result.get('success') else 'failed',
                                'error': None if pr_result.get('success') else pr_result.get('message', 'Unknown error'),
                                'pr_result': pr_result if pr_result.get('success') else None
                            }
                            batch_results['pr_results'].append(pr_entry)
                                                
                            # Store PR result in session state
                            if pr_result.get('success'):
                                pr_key = f'pr_result_{selected_repo_id}_{vuln_idx}'
                                st.session_state[pr_key] = pr_result
                                            
                        batch_results['results'].append(result_entry)
                                            
                        # Store individual fix result for display
                        fix_result_key = f'fix_result_{selected_repo_id}_{vuln_idx}'
                        st.session_state[fix_result_key] = result
                                            
                        # Mark as completed FIRST
                        if current_index not in completed_indices:
                            completed_indices.append(current_index)
                        
                        # Update batch_results with completed indices BEFORE moving to next
                        batch_results['completed_indices'] = completed_indices.copy()
                        
                        # Move to next fix
                        batch_results['current_index'] = current_index + 1
                        
                        # Save to session state IMMEDIATELY to ensure state is persisted
                        st.session_state[batch_result_key] = batch_results
                        
                        # Update flow visualization AFTER state is saved
                        # Show current vulnerability as completed, next one as processing
                        with status_container:
                            st.markdown("---")
                            st.markdown("### 🔄 Fix Progress Flow")
                            display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                        
                        # Continue to next fix
                        if current_index + 1 < len(fixable_vulns):
                            st.rerun()
                        else:
                            # All fixes completed
                            if batch_fix_key in st.session_state:
                                del st.session_state[batch_fix_key]
                            progress_bar.progress(1.0)
                            pr_success_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'success'])
                            pr_failed_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'failed'])
                            status_msg = f"✅ Completed: {batch_results['successful']} successful, {batch_results['failed']} failed, {batch_results['skipped']} skipped"
                            # In the new design we expect a single batch PR per repository.
                            if pr_success_count > 0:
                                status_msg += f", 1 batch PR created"
                            if pr_failed_count > 0:
                                status_msg += f", PR creation failed"
                            status_text.text(status_msg)
            else:
                # All fixes completed
                if batch_fix_key in st.session_state:
                    del st.session_state[batch_fix_key]
                progress_bar.progress(1.0)
                pr_success_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'success'])
                pr_failed_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'failed'])
                status_msg = f"✅ Completed: {batch_results['successful']} successful, {batch_results['failed']} failed, {batch_results['skipped']} skipped"
                if pr_success_count > 0:
                    status_msg += f", 1 batch PR created"
                if pr_failed_count > 0:
                    status_msg += f", PR creation failed"
                status_text.text(status_msg)
                            
        # Add cancel button if processing
        if batch_fix_key in st.session_state:
            batch_fix_req_check = st.session_state[batch_fix_key]
            current_idx_check = batch_fix_req_check.get('current_index', 0)
            if batch_result_key in st.session_state:
                batch_results_check = st.session_state[batch_result_key]
                fixable_vulns_check = batch_results_check.get('fixable_vulns', [])
                if current_idx_check < len(fixable_vulns_check):
                    col1, col2, col3 = st.columns([1, 1, 1])
                    with col2:
                        if st.button("🛑 Cancel Batch Fix", key=f"cancel_batch_fix_{selected_repo_id}", width='stretch'):
                            # Clear request but keep results
                            if batch_fix_key in st.session_state:
                                del st.session_state[batch_fix_key]
                            st.rerun()
                            




def display_setup_progress(current_step):
    """
    Displays a progress tracker for the initial setup stages:
    1. Upload Report
    2. Fetch Projects
    3. Map Results
    """
    st.markdown("""
    <style>
    .setup-progress-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        position: relative;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .setup-step {
        display: flex;
        flex-direction: column;
        align-items: center;
        z-index: 2;
        width: 100px;
    }
    
    .setup-circle {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        margin-bottom: 8px;
        background-color: #1e1e1e;
        border: 2px solid #555;
        color: #aaa;
        transition: all 0.3s ease;
    }
    
    .setup-label {
        font-size: 0.8rem;
        color: #aaa;
        font-weight: 500;
        text-align: center;
    }
    
    .setup-step.active .setup-circle {
        background-color: #2196F3;
        border-color: #64B5F6;
        color: white;
        box-shadow: 0 0 10px rgba(33, 150, 243, 0.5);
    }
    
    .setup-step.active .setup-label {
        color: #2196F3;
        font-weight: bold;
    }
    
    .setup-step.completed .setup-circle {
        background-color: #4CAF50;
        border-color: #81C784;
        color: white;
    }
    
    .setup-step.completed .setup-label {
        color: #4CAF50;
    }
    
    .setup-line-bg {
        position: absolute;
        top: 16px;
        left: 50px;
        right: 50px;
        height: 2px;
        background-color: #333;
        z-index: 1;
    }
    
    .setup-line-fill {
        position: absolute;
        top: 16px;
        left: 50px;
        height: 2px;
        background-color: #4CAF50;
        z-index: 1;
        transition: width 0.5s ease;
    }
    </style>
    """, unsafe_allow_html=True)
    
    steps = [
        {"id": 1, "label": "Upload Report"},
        {"id": 2, "label": "Fetch Projects"},
        {"id": 3, "label": "Map Results"},
        {"id": 4, "label": "Baseline Testing"},  # NEW: Test before fixes
        {"id": 5, "label": "Fix Vulnerabilities"},
        {"id": 6, "label": "Validation Testing"},  # NEW: Test after fixes
        {"id": 7, "label": "Create PR"}  # NEW: PR creation as final step
    ]
    
    fill_pct = 0
    if current_step >= 8:
        fill_pct = 100
    elif current_step == 7:
        fill_pct = 100
    elif current_step == 6:
        fill_pct = 86  # 6/7 = ~86%
    elif current_step == 5:
        fill_pct = 71  # 5/7 = ~71%
    elif current_step == 4:
        fill_pct = 57  # 4/7 = ~57%
    elif current_step == 3:
        fill_pct = 43  # 3/7 = ~43%
    elif current_step == 2:
        fill_pct = 29  # 2/7 = ~29%
    elif current_step == 1:
        fill_pct = 14  # 1/7 = ~14%
    elif current_step == 0:
        fill_pct = 0
        
    # Generate HTML for steps
    steps_html = []
    
    # Calculate width for fill line based entirely on CSS/HTML structure
    # This is a simplified visual representation
    
    for step in steps:
        status_class = ""
        icon = str(step["id"])
        
        if current_step > step["id"]: # Completed
            status_class = "completed"
            icon = "✓"
        elif current_step == step["id"]: # Active
            status_class = "active"
        
        steps_html.append(
            f'<div class="setup-step {status_class}">'
            f'<div class="setup-circle">{icon}</div>'
            f'<div class="setup-label">{step["label"]}</div>'
            '</div>'
        )
    
    # Override: Set to 100% when workflow is complete (step 7 or beyond)
    if current_step >= 7:
        fill_pct = 100
        
    st.markdown(
        f'<div class="setup-progress-container">'
        f'<div class="setup-line-bg"></div>'
        f'<div class="setup-line-fill" style="width: {fill_pct}%;"></div>'
        f'{"".join(steps_html)}'
        '</div>',
        unsafe_allow_html=True
    )






def display_vulnerability_workflow(api_url):
    """
    Display the dedicated Vulnerability Workflow mode.
    Streamlines: Upload -> Map -> Test -> Fix -> Verify
    """
    st.markdown('<h2 class="main-header">🛡️ Vulnerability Workflow</h2>', unsafe_allow_html=True)
    st.markdown('<p style="color: #b0b0b0; margin-bottom: 2rem;">End-to-end workflow for identifying, testing, and fixing security vulnerabilities.</p>', unsafe_allow_html=True)
    
    # Determine current step for progress bar
    # Steps: 1=Upload Report, 2=Fetch Projects, 3=Map Results, 4=Baseline Testing,
    #         5=Fix Vulnerabilities, 6=Validation Testing, 7=Create PR, 8=All Done
    current_step = 1
    if st.session_state.get('workflow_uploader'):
        current_step = 2
        if st.session_state.get('repositories_data'):
            current_step = 3
            if st.session_state.get('workflow_mapping_results'):
                current_step = 4
                if st.session_state.get('workflow_testing_results'):
                    current_step = 5
                    
                    # Check for Step 5→6→7 progression based on fix/validation/PR state
                    if st.session_state.get('auto_fix_all_initiated'):
                        mapping_res = st.session_state.get('workflow_mapping_results', {})
                        mapped_vulns_check = mapping_res.get('mapped_vulnerabilities', {})
                        vulnerable_repos = [tid for tid, info in mapped_vulns_check.items() if info.get('vulnerabilities')]
                        active_fixes = [tid for tid in vulnerable_repos if f'batch_fix_request_{tid}' in st.session_state]
                        
                        if vulnerable_repos and not active_fixes:
                            # All fixes are done → at least step 6 (Validation Testing)
                            current_step = 6
                            
                            # Check if validation testing has completed for all repos
                            all_validation_done = True
                            for tid in vulnerable_repos:
                                br = st.session_state.get(f'batch_fix_result_{tid}', {})
                                if not br.get('validation_test_results') and not br.get('test_results'):
                                    all_validation_done = False
                                    break
                            
                            if all_validation_done:
                                # Validation testing done → step 7 (Create PR)
                                current_step = 7
                                
                                # Check if PR creation has completed for all repos
                                all_prs_done = True
                                for tid in vulnerable_repos:
                                    br = st.session_state.get(f'batch_fix_result_{tid}', {})
                                    if not br.get('batch_pr_result'):
                                        all_prs_done = False
                                        break
                                
                                if all_prs_done:
                                    # All PRs created → step 8 (All complete)
                                    current_step = 8
                
    display_setup_progress(current_step)
    
    # --- Step 1: Upload Report ---
    if current_step == 1:
        st.markdown("### 1️⃣ Upload Scanner Report")
        st.info("Upload your security scanner report (CSV) to begin the automated workflow.")
    
    uploaded_file = st.file_uploader("Upload Scanner Report (CSV)", type=['csv'], key="workflow_uploader")
    
    if not uploaded_file:
        if current_step == 1: # Only show warning if explicitly in step 1 w/o file
             st.warning("👆 Please upload a CSV report to proceed.")
        return

    # --- Step 2: Auto-Fetch & Map ---
    # Check if we need to fetch repos first
    if 'repositories_data' not in st.session_state:
        with st.spinner("🔄 Auto-fetching repositories information from GitHub..."):
            # Use credentials from backend config
            data, error = fetch_repositories(api_url)
            if data:
                st.session_state['repositories_data'] = data
                st.success("✅ Repositories fetched successfully")
                
                # Also fetch token from backend config
                try:
                    creds_response = requests.get(f"{api_url}/api/config/github-credentials", timeout=10)
                    if creds_response.status_code == 200:
                        creds_data = creds_response.json()
                        st.session_state['github_token'] = creds_data.get('token', '')
                except Exception:
                    pass
                    
                st.rerun() # Rerun to update progress bar
            else:
                st.error(f"❌ Failed to fetch repositories: {error}")
                return
    
    # Define keys early
    mapping_key = 'workflow_mapping_results'
    mapping_uploaded_key = 'workflow_mapping_uploaded'

    # Check if mapping is needed (new file or no mapping)
    should_remap = (
        mapping_key not in st.session_state or 
        st.session_state.get(mapping_uploaded_key) != uploaded_file.name
    )
    
    if should_remap:
        with st.spinner("📊 Mapping vulnerabilities to repositories..."):
            token = st.session_state.get('github_token')
            mapping_result, error = map_vulnerabilities(api_url, st.session_state['repositories_data'], uploaded_file, token)
            
            if mapping_result:
                st.session_state[mapping_key] = mapping_result
                st.session_state[mapping_uploaded_key] = uploaded_file.name
                st.rerun() # Rerun to update progress bar
            else:
                st.error(f"❌ Mapping failed: {error}")
                return

    mapping_result = st.session_state.get(mapping_key)
    mapped_vulns = mapping_result.get('mapped_vulnerabilities', {}) if mapping_result else {}
    total_mapped = mapping_result.get('total_mapped', 0) if mapping_result else 0
    total_unmatched = mapping_result.get('unmatched_vulnerabilities', []) if mapping_result else []
    
    if not mapped_vulns:
        if total_unmatched:
            st.warning(f"⚠️ {len(total_unmatched)} vulnerabilities found but none matched your repositories.")
            # Show unmatched
            st.dataframe(pd.DataFrame(total_unmatched), width='stretch', hide_index=True)
        else:
            st.warning("⚠️ No vulnerabilities found in the report.")
        return

    # Display Mapped Projects Summary
    st.markdown("### 📋 Mapped Projects & Files")
    
    col_map1, col_map2 = st.columns(2)
    with col_map1:
        st.success(f"✅ **{total_mapped}** Repositories Matched")
    with col_map2:
        if total_unmatched:
            st.warning(f"⚠️ **{len(total_unmatched)}** Unmatched Vulnerabilities")
        else:
            st.success("✅ All Vulnerabilities Matched")

    # Detailed view per repository
    if not mapped_vulns:
        st.info("No repositories mapped.")
    else:
        for repo_id, info in mapped_vulns.items():
            repo = info.get('repo', {})
            vulns = info.get('vulnerabilities', [])
            repo_name = repo.get('name', 'Unknown')
            repo_url = repo.get('html_url', '#')
            
            # Group vulnerabilities by file
            files_map = {}
            for v in vulns:
                # Try multiple keys for file path
                fpath = v.get('file_name') or v.get('file_path') or v.get('file', 'Unknown')
                if fpath not in files_map:
                    files_map[fpath] = []
                files_map[fpath].append(v)
            
            # Create expander for each repo with file count
            file_count = len(files_map)
            vuln_count = len(vulns)
            
            with st.expander(f"📦 {repo_name}  (📄 {file_count} Files | 🛡️ {vuln_count} Vulnerabilities)", expanded=False):
                # Summary metrics
                m1, m2, m3 = st.columns([2, 1, 1])
                with m1:
                    st.markdown(f"**Repository:** [{repo_name}]({repo_url})")
                with m2:
                     st.metric("Files Affected", file_count)
                with m3:
                     st.metric("Total Issues", vuln_count)
                
                # Prepare distinct vulnerability data
                vuln_data = []
                for v in vulns:
                    fpath = v.get('file_name') or v.get('file_path') or v.get('file', 'Unknown')
                    vuln_type = v.get('vulnerability', 'Unknown')
                    severity = v.get('severity', 'Unknown')
                    line = v.get('line', 'N/A')
                    
                    vuln_data.append({
                        "Type": vuln_type,
                        "Severity": severity,
                        "File": fpath,
                        "Line": line
                    })
                
                if vuln_data:
                    df = pd.DataFrame(vuln_data)
                    st.dataframe(
                        df,
                        column_config={
                            "Type": st.column_config.TextColumn("Vulnerability", width="medium"),
                            "Severity": st.column_config.TextColumn("Severity", width="small"),
                            "File": st.column_config.TextColumn("File Path", width="large", help="Location of the vulnerability"),
                            "Line": st.column_config.TextColumn("Line", width="small")
                        },
                        hide_index=True,
                        width='stretch'
                    )
                else:
                    st.warning("No vulnerabilities found for this repository.")

    if total_unmatched:
        st.markdown("---")
        with st.expander(f"⚠️ View Unmatched Vulnerabilities ({len(total_unmatched)})", expanded=False):
             st.table(pd.DataFrame(total_unmatched))
             st.info("Tip: Check if the repository URLs in your CSV match your actual GitHub repositories.")
    
    # --- Automated Testing Step ---
    st.markdown("---")
    st.markdown("### 🧪 Automated Testing Agent")
    
    testing_key = 'workflow_testing_results'
    
    # Check if testing is already done
    testing_results = st.session_state.get(testing_key)
    
    # Auto-run testing if not done and not already in progress
    if not testing_results and mapped_vulns and not st.session_state.get('auto_testing_running', False):
        st.session_state['auto_testing_running'] = True
        st.info("🔄 Automatically running AI Testing Agent for mapped repositories...")
        
        # Use a container for progress to avoid full rerun flicker issues if possible
        result_container = st.container()
        
        try:
            with result_container:
                results = {}
                # Progress bar for visual feedback
                progress_text = "Operation in progress. Please wait."
                my_bar = st.progress(0, text=progress_text)
                
                import concurrent.futures
                
                total_repos = len(mapped_vulns)
                
                def process_test(repo_id_inner, info_inner):
                    repo_inner = info_inner.get('repo', {})
                    r_name = repo_inner.get('name', 'Unknown')
                    r_url = repo_inner.get('clone_url') or repo_inner.get('html_url')
                    r_res, r_err = run_testing_agent(api_url, r_url)
                    return repo_id_inner, r_name, r_res, r_err
                
                my_bar.progress(0.1, text=f"🧪 Initiating concurrent testing for {total_repos} repositories...")
                
                with concurrent.futures.ThreadPoolExecutor(max_workers=min(total_repos, 5)) as executor:
                    future_to_repo = {
                        executor.submit(process_test, repo_id, info): repo_id 
                        for repo_id, info in mapped_vulns.items()
                    }
                    
                    completed = 0
                    for future in concurrent.futures.as_completed(future_to_repo):
                        completed += 1
                        try:
                            r_id, r_name, res, err = future.result()
                            results[r_id] = {
                                "repo_name": r_name,
                                "status": "Pass" if res else "Fail",
                                "details": res if res else err
                            }
                        except Exception as exc:
                            repo_id_err = future_to_repo[future]
                            repo_name_err = mapped_vulns.get(repo_id_err, {}).get('repo', {}).get('name', 'Unknown')
                            results[repo_id_err] = {
                                "repo_name": repo_name_err,
                                "status": "Fail",
                                "details": str(exc)
                            }
                        my_bar.progress(completed / total_repos, text=f"🧪 Completed {completed}/{total_repos} tests...")
                
                my_bar.progress(1.0, text="✅ Testing Complete!")
                st.session_state[testing_key] = results
        finally:
            st.session_state['auto_testing_running'] = False
            st.rerun()
            
    elif testing_results:
        # Display Results
        st.success("✅ Automated Testing Complete")
        
        # Summary Metrics
        passed = sum(1 for r in testing_results.values() if r['status'] == "Pass")
        failed = len(testing_results) - passed
        
        c1, c2 = st.columns(2)
        c1.metric("Tests Passed", passed)
        c2.metric("Tests Failed", failed)
        
        # Detailed Results
        st.markdown("### 📝 Detailed Test Reports")
        
        for r_id, res in testing_results.items():
            repo_name = res.get('repo_name', 'Unknown Repository')
            status = res.get('status')
            details = res.get('details')
            
            icon = "✅" if status == "Pass" else "❌"
            
            with st.expander(f"{icon} {repo_name}", expanded=False):
                if status == "Pass" and isinstance(details, dict):
                    report = details.get('report', {})
                    if not report:
                         # Fallback if report missing but success (e.g. valid structure but empty report key)
                         st.warning("No detailed report available.")
                         st.json(details)
                         continue
                         
                    # Render the high-fidelity Atlas report
                    render_atlas_report(report)

                    with st.expander("Show Raw JSON Report"):
                        st.json(report)
                elif status == "Pass":
                     # Pass but details not dict
                     st.success("Test passed successfully.")
                     st.write(details)
                else:
                    st.error("Test Execution Failed")
                    st.markdown(f"**Error Details:**")
                    st.code(str(details), language="text")
        
        if st.button("🧪 Re-run All Tests"):
            del st.session_state[testing_key]
            st.rerun()

    # --- Step 5: Automated Fix & PR Creation ---
    if current_step >= 5:
        st.markdown("---")
        st.markdown("### 🛠️ Step 5: Automated Fix & PR Creation")
        
        # Auto-trigger logic
        # Auto-trigger logic
        if not st.session_state.get('auto_fix_all_initiated'):
            st.info("🔄 Automatically initiating batch fix process for all vulnerable repositories...")
            for repo_id, info in mapped_vulns.items():
                if info.get('vulnerabilities'):
                    batch_request_key = f'batch_fix_request_{repo_id}'
                    if batch_request_key not in st.session_state:
                         # Check if already completed (result exists but request doesn't)
                         batch_result_key = f'batch_fix_result_{repo_id}'
                         if batch_result_key not in st.session_state or not st.session_state[batch_result_key].get('results'):
                            st.session_state[batch_request_key] = {
                                'vulnerabilities': info['vulnerabilities'],
                                'selected_repo': info['repo'],
                                'current_index': 0,
                                'completed_indices': [],
                                'auto_create_pr': True
                            }
            st.session_state['auto_fix_all_initiated'] = True
            st.rerun()

        # Progress Dashboard for all active fixes
        st.markdown("#### 📊 Batch Fix Progress Dashboard")
        vulnerable_repos = [tid for tid in mapped_vulns if mapped_vulns[tid].get('vulnerabilities')]
        active_fixes = [tid for tid in vulnerable_repos if f'batch_fix_request_{tid}' in st.session_state]
        
        if not vulnerable_repos:
            st.info("No vulnerabilities found to fix.")
        elif not active_fixes:
            st.balloons()
            st.success("✅ **Mission Accomplished!** All repositories have been automatically processed and fixed.")
            
            # Show summary of all PRs created with flow visuals
            for tid in vulnerable_repos:
                br_key = f'batch_fix_result_{tid}'
                br = st.session_state.get(br_key, {})
                bpr = br.get('batch_pr_result')
                r_info = mapped_vulns[tid]
                rname = r_info['repo'].get('name', 'Unknown')
                
                with st.expander(f"📦 {rname} Summary", expanded=True):
                    if bpr and bpr.get('success'):
                        # Show the final flow for this repo
                        fixable_v = list(enumerate(r_info['vulnerabilities']))
                        completed = [r.get('vuln_idx', 0)-1 for r in br.get('results', []) if r.get('status') == 'success']
                        display_vulnerability_flow(fixable_v, -1, completed, br)
                    elif br.get('successful', 0) > 0:
                        pr_msg = bpr.get('message', 'PR creation failed') if bpr else 'PR creation was skipped or failed'
                        st.warning(f"Fixes successful for {rname}, but {pr_msg}.")
                        st.json(br.get('results', []))
                    else:
                        st.info(f"No fixes were possible for {rname}.")

            if st.button("🔄 Restart Automated Fix Pipeline"):
                for tid in vulnerable_repos:
                    br_key = f'batch_fix_result_{tid}'
                    if br_key in st.session_state: del st.session_state[br_key]
                st.session_state['auto_fix_all_initiated'] = False
                st.rerun()
        else:
            # Display summary metrics
            c1, c2, c3 = st.columns(3)
            total_v = sum(len(mapped_vulns[tid]['vulnerabilities']) for tid in vulnerable_repos)
            total_done = 0
            total_success = 0
            for tid in vulnerable_repos:
                br = st.session_state.get(f'batch_fix_result_{tid}', {})
                total_success += br.get('successful', 0)
                total_done += (br.get('successful', 0) + br.get('failed', 0))
            
            c1.metric("Repos Remaining", len(active_fixes))
            c2.metric("Total Progress", f"{total_done}/{total_v}")
            c3.metric("Successful Fixes", total_success)
            
            # Find the first active repo and process it
            next_repo_id = active_fixes[0]
            repo_name = mapped_vulns[next_repo_id]['repo'].get('name', 'Unknown')
            st.info(f"🤖 Currently processing: **{repo_name}**...")
            
            # Show grid of all repos
            cols = st.columns(min(len(vulnerable_repos), 4))
            for i, repo_id in enumerate(vulnerable_repos):
                with cols[i % 4]:
                    r_info = mapped_vulns[repo_id]
                    r_name = r_info['repo'].get('name', 'Unknown')
                    br_key = f'batch_fix_result_{repo_id}'
                    br = st.session_state.get(br_key, {})
                    
                    t = len(r_info['vulnerabilities'])
                    s = br.get('successful', 0)
                    f = br.get('failed', 0)
                    d = s + f
                    
                    st.markdown(f"**{r_name[:20]}**")
                    st.progress(d / t if t > 0 else 0)
                    st.caption(f"{d}/{t} fixed")

            # Call the incremental processor for the next repo in queue
            process_active_batch_fix(next_repo_id, api_url, st.session_state.get('github_token'))

    # --- Step 6: Validation Results & Final Report ---
    if current_step >= 6:
        st.markdown("---")
        st.markdown("### 🏁 Step 6: Validation Results & Final Report")
        
        # Summary of all repositories
        mapping_result = st.session_state.get('workflow_mapping_results', {})
        mapped_vulns = mapping_result.get('mapped_vulnerabilities', {})
        vulnerable_repos = [tid for tid in mapped_vulns if mapped_vulns[tid].get('vulnerabilities')]
        
        st.success("✨ **All Automated Security Fixes & Validations Complete!**")
        
        # Overall Metrics
        total_repos = len(vulnerable_repos)
        total_success_vulns = 0
        total_failed_vulns = 0
        total_prs = 0
        
        for repo_id in vulnerable_repos:
            br = st.session_state.get(f'batch_fix_result_{repo_id}', {})
            total_success_vulns += br.get('successful', 0)
            total_failed_vulns += br.get('failed', 0)
            if br.get('batch_pr_result') and br.get('batch_pr_result', {}).get('success'):
                total_prs += 1
        
        col_f1, col_f2, col_f3 = st.columns(3)
        col_f1.metric("Repositories Processed", total_repos)
        col_f2.metric("Successful Fixes", total_success_vulns, f"{total_failed_vulns} failed" if total_failed_vulns > 0 else None)
        col_f3.metric("Pull Requests Created", total_prs)
        
        st.markdown("#### 📝 Detailed Validation Reports")
        
        # Detailed report for each repo
        for repo_id in vulnerable_repos:
            repo_info = mapped_vulns[repo_id]
            repo_name = repo_info['repo'].get('name', 'Unknown')
            br = st.session_state.get(f'batch_fix_result_{repo_id}', {})
            
            status_icon = "✅" if br.get('successful', 0) > 0 else "❌"
            
            with st.expander(f"📦 {repo_name} - Validation & Fix Summary", expanded=False):
                # 1. PR Info
                bpr = br.get('batch_pr_result')
                if bpr and bpr.get('success'):
                    st.info(f"🔗 **Pull Request Created:** [PR #{bpr.get('pr_number')}]({bpr.get('pr_url')})")
                elif bpr:
                    st.warning(f"⚠️ PR Creation Issue: {bpr.get('message', 'Unknown failure')}")
                
                # 2. Atlas Report
                display_fix_results(br, repo_id)
        
        if st.button("🔄 Start New Analysis"):
            # Clear all relevant session state keys
            keys_to_clear = [
                'workflow_mapping_results', 'workflow_mapping_uploaded', 'auto_fix_all_initiated',
                'workflow_testing_results', 'repositories_data'
            ]
            for repo_id in vulnerable_repos:
                keys_to_clear.append(f'batch_fix_result_{repo_id}')
                keys_to_clear.append(f'batch_fix_request_{repo_id}')
                
            for k in keys_to_clear:
                if k in st.session_state: del st.session_state[k]
            st.rerun()

    # --- Step 6: Repository Detailed Processing ---
    st.markdown("---")
    st.markdown("### 📋 3️⃣ Repository Detail View")
    
    # Repository Selector
    # Create descriptive labels for dropdown
    repo_options = {}
    for repo_id, info in mapped_vulns.items():
        repo_name = info['repo'].get('name', 'Unknown')
        vuln_count = len(info['vulnerabilities'])
        label = f"{repo_name} ({vuln_count} vulns)"
        repo_options[label] = repo_id
    
    col_sel1, col_sel2 = st.columns([2, 1])
    with col_sel1:
        selected_repo_label = st.selectbox("Select Repository to Process", options=list(repo_options.keys()))
    
    selected_repo_id = repo_options[selected_repo_label]
    selected_repo_info = mapped_vulns[selected_repo_id]
    selected_repo = selected_repo_info['repo']
    vulnerabilities = selected_repo_info['vulnerabilities']
    
    # 3.1 Testing Agent Section
    st.markdown("#### 🧪 Automated Testing Pipeline")
    with st.expander("Run Testing Agent (Pre/Post Fix)", expanded=False):
        st.markdown("Run the AI testing agent to generate tests and establish a baseline.")
        col_t1, col_t2 = st.columns([1, 2])
        repo_testing_url = selected_repo.get('clone_url') or selected_repo.get('html_url')
        
        with col_t1:
            test_btn_key = f"wf_test_{selected_repo_id}"
            if st.button("▶️ Run Testing Agent", key=test_btn_key, type="primary"):
                 with st.spinner("🧪 Running testing pipeline... (This may take several minutes)"):
                    res, err = run_testing_agent(api_url, repo_testing_url)
                    if res:
                        st.session_state[f"wf_test_res_{selected_repo_id}"] = res
                        st.success("Testing completed!")
                    else:
                        st.error(f"Testing failed: {err}")
        
        # Display latest test results if available
        test_res = st.session_state.get(f"wf_test_res_{selected_repo_id}")
        if test_res:
            report = test_res.get('report', {})
            st.info(f"Last Run ID: {test_res.get('run_id')}")
            # Render the high-fidelity Atlas report
            render_atlas_report(report)

    # 3.2 Fix Workflow Section
    st.markdown("---")
    st.markdown("#### 🔄 Fix & Verification Cycle")
    
    # Visualization Data Prep
    batch_result_key = f'batch_fix_result_{selected_repo_id}'
    batch_results = st.session_state.get(batch_result_key, {})
    batch_results_list = batch_results.get('results', [])
    
    # Calculate progress
    completed_indices = [
        r.get('vuln_idx', -1) - 1 # Convert 1-based to 0-based
        for r in batch_results_list 
        if r.get('status') == 'success'
    ]
    
    # Check for active processing
    batch_request_key = f'batch_fix_request_{selected_repo_id}'
    is_fixing = batch_request_key in st.session_state
    
    current_processing_idx = -1
    if is_fixing:
        process_active_batch_fix(selected_repo_id, api_url, st.session_state.get('github_token'))
    # Display Circular Flow Visualization
    # Use 1-based indexing for consistency with the processing loop
    fixable_vulns_with_idx = [
        (idx, vuln) for idx, vuln in enumerate(vulnerabilities, 1)
        if vuln.get('file_found', False) and vuln.get('matched_file_path')
    ]
    if not fixable_vulns_with_idx:
        # Fallback to all vulns if none specifically marked as fixable yet
        fixable_vulns_with_idx = list(enumerate(vulnerabilities, 1))

    display_vulnerability_flow(fixable_vulns_with_idx, current_processing_idx, completed_indices, batch_results)
    
    # Fix Actions
    st.markdown("##### Actions")
    col_f1, col_f2 = st.columns([1, 2])
    with col_f1:
        if st.button(
            f"🚀 Fix All ({len(vulnerabilities)}) Vulnerabilities", 
            key=f"wf_fix_all_{selected_repo_id}", 
            type="primary",
            disabled=is_fixing or len(completed_indices) == len(vulnerabilities),
            help="Start the multi-agent fix process for all vulnerabilities sequentially"
        ):
            # Init batch fix
            st.session_state[batch_request_key] = {
                'vulnerabilities': vulnerabilities,
                'selected_repo': selected_repo,
                'current_index': 0,
                'completed_indices': [],
                'auto_create_pr': True # Default to True for streamlined workflow
            }
            # Also clear old results for fresh run if needed
            if len(completed_indices) == len(vulnerabilities):
                 st.session_state[batch_result_key] = {'results': []}
            
            st.rerun()
            
    if is_fixing:
        st.info("🤖 Auto-fixing in progress... Please wait.")
        # Progress bar
        progress = len(completed_indices) / len(vulnerabilities)
        st.progress(progress)
        st.write(f"Completed: {len(completed_indices)} / {len(vulnerabilities)}")
    
    # NEW: Display results
    if batch_results and batch_results.get('results'):
         from src.lineage import render_interactive_lineage
         st.markdown("##### 🧬 Fix Lineage")
         with st.expander("View Interactive Lineage Graph", expanded=True):
             render_interactive_lineage(batch_results)
             
         display_fix_results(batch_results, selected_repo_id)

def display_run_history(api_url):
    """Fetch and display the pipeline run history."""
    st.markdown('<div class="section-header">📜 Pipeline Run History</div>', unsafe_allow_html=True)
    st.info("View recent validation testing pipeline runs and their results.")
    
    try:
        url = f"{api_url}/api/runs"
        response = requests.get(url, timeout=30)
        
        if response.status_code == 200:
            runs = response.json()
            if not runs:
                st.warning("No run history found.")
                return
                
            # Keep track of expanded runs
            for idx, run in enumerate(runs):
                run_time = run.get('start_time', 'N/A')
                status = run.get('status', 'RUNNING')
                
                # Determine icon/color
                if status == 'COMPLETED':
                    icon = "✅"
                    color = "#4caf50"
                elif status == 'FAILED':
                    icon = "❌"
                    color = "#f44336"
                else:
                    icon = "⏳"
                    color = "#2196f3"
                    
                repo = run.get('repo_url') or run.get('repo_path') or 'unknown-repo'
                
                with st.expander(f"{icon} Run: {repo} - {run_time} ({status})"):
                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown(f"**Run ID:** `{run.get('run_id', 'N/A')}`")
                        st.markdown(f"**Status:** `{status}`")
                    with col2:
                        st.markdown(f"**Cost:** `${run.get('total_cost', 0.0):.4f}`")
                        end_time = run.get('end_time')
                        if end_time:
                            st.markdown(f"**Logs & Results fetched at:** `{end_time}`")
                    
                    # Token usage breakdown
                    in_tok = run.get('input_tokens', 0) or 0
                    out_tok = run.get('output_tokens', 0) or 0
                    total_tok = in_tok + out_tok
                    if total_tok > 0:
                        tc1, tc2, tc3 = st.columns(3)
                        tc1.metric("Input Tokens", f"{in_tok:,}")
                        tc2.metric("Output Tokens", f"{out_tok:,}")
                        tc3.metric("Total Tokens", f"{total_tok:,}")
                            
                    if run.get('error_message'):
                        st.error(f"Error: {run.get('error_message')}")
                        
                    result = run.get('result_data')
                    if result:
                        st.markdown("#### Test Results")
                        # Basic breakdown
                        passed = result.get('passed', 0)
                        failed = result.get('failed', 0)
                        total = result.get('total', 0)
                        
                        m1, m2, m3 = st.columns(3)
                        m1.metric("Tests Passed", passed)
                        m2.metric("Tests Failed", failed)
                        m3.metric("Total Tests", total)
                        
                        if 'coverage' in result and result['coverage'] is not None:
                            st.metric("Line Coverage %", f"{result['coverage']}%")
                            
                        # Dump full JSON for advanced inspection
                        with st.expander("Show Full Report JSON"):
                            st.json(result)
        else:
            st.error(f"Failed to fetch run history. API returned {response.status_code}")
    except Exception as e:
        st.error(f"Error connecting to the API: {str(e)}")


def main():
    # Top Navigation Bar with Settings Icon
    col1, col2 = st.columns([9, 1])
    with col1:
        st.markdown('<div class="top-nav-title">🔐 ICSF Platform</div>', unsafe_allow_html=True)
    with col2:
        if st.button("⚙️", help="Settings"):
            st.session_state['show_settings'] = not st.session_state.get('show_settings', False)
    
    # Settings Panel (Collapsible)
    if st.session_state.get('show_settings', False):
        with st.expander("⚙️ Application Settings", expanded=True):
            st.markdown("### Backend Configuration")
            api_url = st.text_input(
                "API Base URL",
                value=st.session_state.get('api_url', DEFAULT_API_BASE_URL),
                help="URL of the FastAPI backend server"
            )
            st.session_state['api_url'] = api_url
            
            st.markdown("---")
            st.info("""
            **🔐 Authentication Setup**
            
            Credentials are configured in the backend `credentials.yaml` file.
            To set up:
            1. Copy `credentials.yaml.example` to `credentials.yaml`
            2. Add your GitHub token and username/email
            3. Restart the backend server
            """)
            
            if st.button("Close Settings"):
                st.session_state['show_settings'] = False
                st.rerun()

    # Get API URL from session state
    api_url = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
    
    tab1, tab2 = st.tabs(["🛡️ Vulnerability Fixes", "📜 Run History"])
    
    with tab1:
        display_vulnerability_workflow(api_url)
        
    with tab2:
        display_run_history(api_url)


@st.cache_data(ttl=300)
def map_vulnerabilities(api_url, repositories_data, csv_file, token=None):
    """Map vulnerabilities from CSV to repositories"""
    try:
        url = f"{api_url}/api/vulnerabilities/map"
        
        # Prepare form data
        files = {'file': (csv_file.name, csv_file.getvalue(), 'text/csv')}
        data = {'repositories_json': json.dumps(repositories_data)}
        
        # Add token if available for file matching
        if token:
            data['token'] = token
        
        response = requests.post(url, files=files, data=data, timeout=600)  # 10 minutes timeout
        
        if response.status_code == 200:
            return response.json(), None
        else:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return None, error_data.get("detail", f"Error {response.status_code}")
    except requests.exceptions.Timeout:
        return None, "Request timed out. Vulnerability mapping is taking longer than expected. Please try again."
    except requests.exceptions.ConnectionError:
        return None, "Cannot connect to API. Make sure the FastAPI server is running on " + api_url
    except requests.exceptions.RequestException as e:
        return None, f"Network error: {str(e)}"
    except Exception as e:
        return None, f"Unexpected error: {str(e)}"


def run_testing_agent(api_url, repo_url, create_pr=False):
    """Call the async testing agent backend endpoint and stream progress."""
    try:
        url = f"{api_url}/api/testing/jobs"
        payload = {
            "repo_url": repo_url,
            "create_pr": bool(create_pr),
        }
        
        # Start the background job
        response = requests.post(url, json=payload, timeout=60)
        
        if response.status_code != 200:
            error_data = response.json() if response.content else {"detail": "Unknown error"}
            return None, error_data.get("detail", f"Start job failed: Error {response.status_code}")
            
        job_data = response.json()
        job_id = job_data.get("job_id")
        
        if not job_id:
            return None, "No job_id returned from backend"
            
        # Display progress container
        log_container = st.empty()
        
        # Stream events
        stream_url = f"{api_url}/api/testing/jobs/{job_id}/stream"
        
        with requests.get(stream_url, stream=True, timeout=3600) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if line:
                    decoded = line.decode('utf-8')
                    if decoded.startswith("data: "):
                        data_str = decoded[6:]
                        if data_str == "[DONE]":
                            break
                        try:
                            event_data = json.loads(data_str)
                            status = event_data.get("status", "RUNNING")
                            msg = event_data.get("message", "")
                            
                            # Give visual feedback
                            log_container.info(f"⏳ **{status}**: {msg}")
                        except json.JSONDecodeError:
                            pass
                            
        # Once stream ends, fetch the final job result
        result_url = f"{api_url}/api/testing/jobs/{job_id}"
        result_response = requests.get(result_url, timeout=60)
        
        if result_response.status_code == 200:
            final_job = result_response.json()
            if final_job.get("status") == "COMPLETED":
                log_container.empty()
                return final_job.get("result"), None
            else:
                log_container.empty()
                return None, final_job.get("error", "Job failed during execution")
        else:
            return None, f"Failed to fetch job result: {result_response.status_code}"
            
    except requests.exceptions.Timeout:
        return None, "Testing pipeline timed out. It may still be running in the background; please check backend logs."
    except requests.exceptions.ConnectionError:
        return None, f"Cannot connect to API. Make sure the FastAPI server is running on {api_url}"
    except requests.exceptions.RequestException as e:
        return None, f"Network error while calling testing agent: {str(e)}"
    except Exception as e:
        return None, f"Unexpected error while running testing agent: {str(e)}"

def display_repositories(data):
    """Display repositories with optional vulnerability mapping"""
    username = data.get("username", "Unknown")
    repositories = data.get("repositories", [])
    
    if not repositories:
        st.warning("⚠️ No repositories found for this user.")
        return
    
    # Header with metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("👤 User", username)
    with col2:
        st.metric("📦 Total Repos", len(repositories))
    with col3:
        public_count = sum(1 for r in repositories if not r.get("is_private", False))
        st.metric("🌐 Public", public_count)
    with col4:
        private_count = len(repositories) - public_count
        st.metric("🔒 Private", private_count)
    
    st.markdown("---")
    
    # Security Report Upload Section
    st.markdown('<div class="section-header">🔒 Security Report Upload</div>', unsafe_allow_html=True)
    
    # Info box
    st.info("📋 Upload a CSV file containing vulnerability data. The file should include repository names/URLs and vulnerability details.")
    
    # Template download and format info
    col1, col2 = st.columns([2, 1])
    with col1:
        st.markdown("**📝 Expected CSV Format:**")
        st.code("repo_name, link, file_name, line_no, vulnerability, description, recommendation", language="text")
    with col2:
        # Create sample CSV data
        sample_csv = """repo_name,link,file_name,line_no,vulnerability,description,recommendation
my-repo,https://github.com/user/my-repo,src/main.py,42,SQL Injection,User input is directly concatenated into SQL query,Use parameterized queries
another-repo,https://github.com/user/another-repo,config.py,15,XSS Vulnerability,Unescaped user input rendered in HTML,Sanitize user input"""
        st.download_button(
            "📥 Download Template CSV",
            data=sample_csv,
            file_name="security_report_template.csv",
            mime="text/csv",
            width='stretch'
        )
    
    uploaded_file = st.file_uploader(
        "Upload Security Report (CSV)",
        type=['csv'],
        help="Upload your security report CSV file"
    )
    
    mapped_vulns = {}
    unmatched_vulns = []
    
    # Use session state to cache mapping results and prevent remapping during batch fixes
    mapping_key = 'vulnerability_mapping_results'
    mapping_uploaded_key = 'vulnerability_mapping_uploaded'
    
    # Check if batch fix is in progress (to prevent remapping during fixes)
    batch_fix_in_progress = any(
        key.startswith('batch_fix_request_') for key in st.session_state.keys()
    )
    
    stored_mapping = st.session_state.get(mapping_key)
    last_uploaded = st.session_state.get(mapping_uploaded_key)
    
    # Add refresh button if mapping exists and not in batch fix
    refresh_mapping = False
    if stored_mapping is not None and uploaded_file is not None and not batch_fix_in_progress:
        col1, col2 = st.columns([3, 1])
        with col2:
            if st.button("🔄 Remap Vulnerabilities", key="refresh_mapping", help="Force remap vulnerabilities (may take several minutes)"):
                refresh_mapping = True
                # Clear cached mapping to force remap
                if mapping_key in st.session_state:
                    del st.session_state[mapping_key]
                if mapping_uploaded_key in st.session_state:
                    del st.session_state[mapping_uploaded_key]
                stored_mapping = None
    
    # Check if we should remap (new file or no cached mapping or refresh requested)
    should_remap = (
        uploaded_file is not None and 
        (stored_mapping is None or last_uploaded != uploaded_file.name or refresh_mapping) and
        not batch_fix_in_progress
    )
    
    if should_remap:
        # Get API URL from session state or use default
        api_url = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
        # Get token from session state if available (for file matching)
        token = st.session_state.get('github_token', None)
        
        with st.spinner("📊 Parsing security report and mapping vulnerabilities (including file matching)..."):
            mapping_result, error = map_vulnerabilities(api_url, data, uploaded_file, token)
            
            if error:
                st.error(f"❌ {error}")
            elif mapping_result:
                mapped_vulns = mapping_result.get("mapped_vulnerabilities", {})
                unmatched_vulns = mapping_result.get("unmatched_vulnerabilities", [])
                
                # Store mapping results in session state
                st.session_state[mapping_key] = {
                    'mapped_vulnerabilities': mapped_vulns,
                    'unmatched_vulnerabilities': unmatched_vulns,
                    'total_mapped': mapping_result.get("total_mapped", 0),
                    'total_unmatched': mapping_result.get("total_unmatched", 0),
                    'file_tree_stats': mapping_result.get("file_tree_stats", {})
                }
                st.session_state[mapping_uploaded_key] = uploaded_file.name
                
                total_mapped = mapping_result.get("total_mapped", 0)
                total_unmatched = mapping_result.get("total_unmatched", 0)
                file_tree_stats = mapping_result.get("file_tree_stats", {})
                
                # Display mapping results
                if total_mapped > 0 or total_unmatched > 0:
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.success(f"✅ **{total_mapped}** repositories with vulnerabilities mapped")
                    with col2:
                        if total_unmatched > 0:
                            st.warning(f"⚠️ **{total_unmatched}** vulnerabilities unmatched")
                    with col3:
                        if file_tree_stats:
                            total_files_fetched = sum(stat.get("file_count", 0) for stat in file_tree_stats.values())
                            st.info(f"📁 **{len(file_tree_stats)}** repos with file trees ({total_files_fetched} files)")
    elif stored_mapping is not None and uploaded_file is not None:
        # Use cached mapping results (during batch fix or same file)
        mapped_vulns = stored_mapping.get("mapped_vulnerabilities", {})
        unmatched_vulns = stored_mapping.get("unmatched_vulnerabilities", [])
        
        # Only show info if not in batch fix mode (to avoid cluttering UI)
        if not batch_fix_in_progress:
            total_mapped = stored_mapping.get("total_mapped", 0)
            if total_mapped > 0:
                st.info(f"📋 Using cached vulnerability mapping: {total_mapped} repositories mapped")
    
    st.markdown("---")
    st.markdown('<div class="section-header">📋 Repository List</div>', unsafe_allow_html=True)
    
    # Statistics if vulnerabilities are mapped
    if mapped_vulns:
        total_vulns = sum(len(v['vulnerabilities']) for v in mapped_vulns.values())
        repos_with_vulns = len(mapped_vulns)
        repos_safe = len(repositories) - repos_with_vulns
        
        stat_col1, stat_col2, stat_col3 = st.columns(3)
        with stat_col1:
            st.metric("🔴 Repos with Vulnerabilities", repos_with_vulns)
        with stat_col2:
            st.metric("✅ Safe Repositories", repos_safe)
        with stat_col3:
            st.metric("⚠️ Total Vulnerabilities", total_vulns)
        st.markdown("---")
    
    # Prepare data for table
    table_data = []
    for repo in repositories:
        repo_name = repo.get("name", "N/A")
        repo_url = repo.get("html_url", "#")
        repo_id = str(repo.get("id"))
        repo_desc = repo.get("description", "") or "No description"
        repo_lang = repo.get("language", "") or "N/A"
        is_private = repo.get("is_private", False)
        stars = repo.get("stars", 0)
        forks = repo.get("forks", 0)
        
        # Check if this repo has vulnerabilities
        has_vulns = repo_id in mapped_vulns
        vuln_count = len(mapped_vulns[repo_id]['vulnerabilities']) if has_vulns else 0
        
        # Create clickable repository name
        repo_link = f"[{repo_name}]({repo_url})"
        
        # Status indicator
        if has_vulns:
            status = f"🔴 {vuln_count} vulnerability/vulnerabilities"
        else:
            status = "✅ No vulnerabilities"
        
        visibility = "🔒 Private" if is_private else "🌐 Public"
        
        table_data.append({
            "Repository": repo_link,
            "Status": status,
            "Language": repo_lang,
            "Visibility": visibility,
            "Stars": stars,
            "Forks": forks,
            "Description": repo_desc[:50] + "..." if len(repo_desc) > 50 else repo_desc,
            "Repo ID": repo_id,  # Hidden column for reference
            "Has Vulnerabilities": has_vulns  # Hidden column for filtering
        })
    
    # Create DataFrame
    repos_df = pd.DataFrame(table_data)
    
    # Filter options
    col1, col2 = st.columns([1, 3])
    with col1:
        filter_option = st.selectbox(
            "Filter by Status:",
            ["All", "With Vulnerabilities", "Safe"],
            help="Filter repositories by vulnerability status"
        )
    
    # Apply filter
    if filter_option == "With Vulnerabilities":
        repos_df = repos_df[repos_df["Has Vulnerabilities"] == True]
    elif filter_option == "Safe":
        repos_df = repos_df[repos_df["Has Vulnerabilities"] == False]
    
    # Display table
    st.dataframe(
        repos_df[["Repository", "Status", "Language", "Visibility", "Stars", "Forks", "Description"]],
        width='stretch',
        hide_index=True,
        height=400
    )
    
    st.markdown("---")
    st.markdown("### 🔍 Vulnerability Details")
    
    # Display vulnerabilities for selected repositories
    if mapped_vulns:
        # Create a selectbox to choose repository for detailed view
        repo_options = {repo.get("name"): str(repo.get("id")) for repo in repositories if str(repo.get("id")) in mapped_vulns}
        
        if repo_options:
            selected_repo_name = st.selectbox(
                "Select a repository to view vulnerabilities:",
                options=list(repo_options.keys()),
                help="Choose a repository to see detailed vulnerability information"
            )
            
            selected_repo_id = repo_options[selected_repo_name]
            selected_repo = next((r for r in repositories if str(r.get("id")) == selected_repo_id), None)
            
            if selected_repo and selected_repo_id in mapped_vulns:
                st.markdown(f"### 📋 Vulnerabilities in [{selected_repo.get('name')}]({selected_repo.get('html_url')})")

                # ------------------------------------------------------------------
                # 🧪 Testing Agent controls (run tests on this repository)
                # ------------------------------------------------------------------
                api_url_val = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
                testing_result_key = f"testing_result_{selected_repo_id}"

                repo_testing_url = (
                    selected_repo.get('clone_url')
                    or selected_repo.get('ssh_url')
                    or selected_repo.get('html_url')
                )

                with st.expander("🧪 Testing Agent - Run Tests After Fixes", expanded=False):
                    if not repo_testing_url:
                        st.warning("⚠️ No clone URL found for this repository. Cannot run testing agent.")
                    else:
                        st.markdown(
                            "Run the ICSF testing agent to build the project, generate AI-powered tests, "
                            "run them, and collect coverage metrics for this repository."
                        )

                        create_tests_pr = st.checkbox(
                            "Create PR with generated tests",
                            key=f"testing_create_pr_{selected_repo_id}",
                            value=False,
                            help="If enabled and GitHub credentials are configured in backend/.env, "
                                 "the testing agent will create a PR containing the generated tests."
                        )

                        col_t1, col_t2 = st.columns([1, 2])
                        with col_t1:
                            run_tests = st.button(
                                "🧪 Run Testing Agent",
                                key=f"run_testing_agent_{selected_repo_id}",
                                type="primary",
                                width='stretch',
                            )

                        if run_tests:
                            with st.spinner("🧪 Running testing pipeline... this may take several minutes."):
                                testing_result, testing_error = run_testing_agent(
                                    api_url=api_url_val,
                                    repo_url=repo_testing_url,
                                    create_pr=create_tests_pr,
                                )
                            if testing_error:
                                st.error(f"❌ Testing pipeline failed: {testing_error}")
                                st.session_state[testing_result_key] = {
                                    "success": False,
                                    "error": testing_error,
                                }
                            elif testing_result:
                                st.session_state[testing_result_key] = testing_result

                    # Display last testing result if available
                    testing_state = st.session_state.get(testing_result_key)
                    if testing_state:
                        st.markdown("---")
                        st.markdown("#### 📊 Latest Testing Result")
                        if not testing_state.get("success", False):
                            st.error(f"❌ Testing run failed: {testing_state.get('error', 'Unknown error')}")
                        else:
                            report = testing_state.get("report", {}) or {}
                            run_id = testing_state.get("run_id", "N/A")
                            repo_url = testing_state.get("repo_url", repo_testing_url or "N/A")

                            st.success(f"✅ Testing pipeline completed successfully (Run ID: `{run_id}`)")
                            # Render the high-fidelity Atlas report
                            render_atlas_report(report)
                            
                            # PR Link (check both report level and top level)
                            pr_url = report.get("pr_url") or testing_state.get("pr_url")
                            if pr_url:
                                st.markdown("---")
                                st.success(f"🔗 **Pull Request Created**: [View PR]({pr_url})")

                            # Expandable sections for detailed view
                            with st.expander("🔍 Full Testing Report (JSON)", expanded=False):
                                st.json(report)

                            logs = testing_state.get("logs")
                            if logs:
                                with st.expander("📜 Testing Pipeline Logs", expanded=False):
                                    st.text("\n".join(logs))
                
                # Create vulnerabilities table
                vuln_table_data = []
                for idx, vuln in enumerate(mapped_vulns[selected_repo_id]['vulnerabilities'], 1):
                    file_found = vuln.get('file_found', False)
                    file_status = "✅ Found" if file_found else "❌ Not Found"
                    
                    # Safely get description, recommendation, and vulnerability type, handling None values
                    description = vuln.get('description') or ''
                    recommendation = vuln.get('recommendation') or ''
                    vulnerability_type = vuln.get('vulnerability') or vuln.get('vulnerability_type') or ''
                    
                    vuln_table_data.append({
                        "#": idx,
                        "File": vuln.get('file_name', 'N/A'),
                        "File Status": file_status,
                        "Line": vuln.get('line_no', 'N/A'),
                        "Type": vulnerability_type if vulnerability_type else 'N/A',
                        "Description": (description[:100] + "..." if len(description) > 100 else description) if description else 'N/A',
                        "Recommendation": (recommendation[:100] + "..." if len(recommendation) > 100 else recommendation) if recommendation else 'N/A',
                        "Full Description": vuln.get('description', 'N/A'),  # Hidden
                        "Full Recommendation": vuln.get('recommendation', 'N/A'),  # Hidden
                        "Link": vuln.get('link', 'N/A'),  # Hidden
                        "File Found": file_found  # Hidden for filtering
                    })
                
                vuln_df = pd.DataFrame(vuln_table_data)
                
                # Filter options for vulnerabilities
                col1, col2 = st.columns([1, 3])
                with col1:
                    file_filter = st.selectbox(
                        "Filter by File Status:",
                        ["All", "Found", "Not Found"],
                        key="file_filter",
                        help="Filter vulnerabilities by file existence status"
                    )
                
                # Apply file filter
                if file_filter == "Found":
                    vuln_df = vuln_df[vuln_df["File Found"] == True]
                elif file_filter == "Not Found":
                    vuln_df = vuln_df[vuln_df["File Found"] == False]
                
                # Count statistics
                total_vulns = len(vuln_table_data)
                found_count = sum(1 for v in mapped_vulns[selected_repo_id]['vulnerabilities'] if v.get('file_found', False))
                not_found_count = total_vulns - found_count
                
                if total_vulns > 0:
                    stat_col1, stat_col2, stat_col3 = st.columns(3)
                    with stat_col1:
                        st.metric("✅ Files Found", found_count)
                    with stat_col2:
                        st.metric("❌ Files Not Found", not_found_count)
                    with stat_col3:
                        st.metric("🔧 Fixable", found_count)
                    
                    # Fix All Vulnerabilities Button
                    if found_count > 0:
                        st.markdown("---")
                        
                        # Auto PR creation toggle
                        auto_pr_key = f"auto_create_pr_{selected_repo_id}"
                        auto_create_pr = st.checkbox(
                            "🔀 Auto-create PR after each fix",
                            value=st.session_state.get(auto_pr_key, False),
                            key=auto_pr_key,
                            help="Automatically create a Pull Request after each successful fix. Disables the separate 'PR for all fixes' button."
                        )
                        # Note: Don't manually set session_state here - the checkbox widget handles it automatically
                        
                        col1, col2, col3 = st.columns([2, 1, 2])
                        with col2:
                            fix_all_key = f"fix_all_{selected_repo_id}"
                            batch_fix_request_key = f'batch_fix_request_{selected_repo_id}'
                            batch_fix_in_progress = batch_fix_request_key in st.session_state
                            
                            if st.button(
                                f"🚀 Fix All Vulnerabilities ({found_count})",
                                key=fix_all_key,
                                type="primary",
                                width='stretch',
                                disabled=batch_fix_in_progress
                            ):
                                # Prevent duplicate requests
                                if not batch_fix_in_progress:
                                    # Store batch fix request with auto PR setting
                                    st.session_state[batch_fix_request_key] = {
                                    'vulnerabilities': mapped_vulns[selected_repo_id]['vulnerabilities'],
                                        'selected_repo': selected_repo,
                                        'current_index': 0,  # Track current processing index
                                        'completed_indices': [],  # Track completed fixes
                                        'auto_create_pr': auto_create_pr  # Store auto PR setting
                                }
                                    st.rerun()
                
                st.dataframe(
                    vuln_df[["#", "File", "File Status", "Line", "Type", "Description", "Recommendation"]],
                    width='stretch',
                    hide_index=True,
                    height=300
                )
                
                # Process batch fix request
                batch_fix_key = f'batch_fix_request_{selected_repo_id}'
                batch_result_key = f'batch_fix_result_{selected_repo_id}'
                
                if batch_fix_key in st.session_state:
                    batch_fix_req = st.session_state[batch_fix_key]
                    vulnerabilities = batch_fix_req['vulnerabilities']
                    selected_repo = batch_fix_req['selected_repo']
                    api_url_val = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
                    github_token = st.session_state.get('github_token')
                    
                    # Create progress container
                    progress_container = st.container()
                    status_container = st.container()
                    
                    with progress_container:
                        progress_bar = st.progress(0)
                        status_text = st.empty()
                    
                    # Process batch fix incrementally with progress tracking
                    with status_container:
                        # Initialize batch results if not exists
                        if batch_result_key not in st.session_state:
                            # Filter fixable vulnerabilities
                            fixable_vulns = [
                                (idx, vuln) for idx, vuln in enumerate(vulnerabilities, 1)
                                if vuln.get('file_found', False) and vuln.get('matched_file_path')
                            ]
                            
                            st.session_state[batch_result_key] = {
                                'total': len(fixable_vulns),
                                'successful': 0,
                                'failed': 0,
                                'skipped': len(vulnerabilities) - len(fixable_vulns),
                                'results': [],
                                'fixable_vulns': fixable_vulns,
                                'current_index': 0,
                                'completed_indices': []
                            }
                        
                        batch_results = st.session_state[batch_result_key]
                        fixable_vulns = batch_results.get('fixable_vulns', [])
                        current_index = batch_results.get('current_index', 0)
                        # Restore completed_indices from batch_results, ensuring it's a list
                        completed_indices = batch_results.get('completed_indices', [])
                        if not isinstance(completed_indices, list):
                            completed_indices = []
                        # Ensure we have a copy to avoid reference issues
                        completed_indices = completed_indices.copy() if completed_indices else []
                        auto_create_pr = batch_fix_req.get('auto_create_pr', False)

                        # ------------------------------------------------------------------
                        # AUTO PR MODE: process incrementally but create single batch PR at end
                        # ------------------------------------------------------------------
                        if auto_create_pr:
                            # In auto PR mode, we process vulnerabilities incrementally (one at a time)
                            # to show progress in the flow visualization, but we collect all successful
                            # fixes and create a SINGLE batch PR at the end to avoid conflicts.
                            
                            # Derive the next index to process from completed_indices
                            if fixable_vulns:
                                all_indices = set(range(len(fixable_vulns)))
                                remaining_indices = sorted(all_indices - set(completed_indices))
                                if remaining_indices:
                                    current_index = remaining_indices[0]
                                else:
                                    # All indices completed - create batch PR
                                    current_index = len(fixable_vulns)
                                batch_results['current_index'] = current_index
                                st.session_state[batch_result_key] = batch_results
                            
                            # Check if all fixes are done - if so, create batch PR
                            if current_index >= len(fixable_vulns):
                                # All fixes completed, now create single batch PR
                                successful_fixes = [
                                    r for r in batch_results.get('results', [])
                                    if r.get('status') == 'success' and r.get('result')
                                ]
                                
                                if successful_fixes:
                                    # Create batch PR using API endpoint
                                    try:
                                        repo_owner = selected_repo.get('full_name', '').split('/')[0] if '/' in selected_repo.get('full_name', '') else None
                                        if not repo_owner and clone_url and 'github.com' in clone_url:
                                            parts = clone_url.replace('https://github.com/', '').replace('.git', '').split('/')
                                            if len(parts) >= 1:
                                                repo_owner = parts[0]
                                        
                                        if repo_owner and github_token:
                                            # Get repo_path from first successful fix
                                            repo_path = None
                                            for fix in successful_fixes:
                                                fix_result = fix.get('result', {})
                                                if isinstance(fix_result, dict):
                                                    repo_path = fix_result.get('repo_path') or fix_result.get('result', {}).get('repo_path', '')
                                                    if repo_path:
                                                        # Check if path exists (might be backend path)
                                                        # Try to infer if it's a backend path
                                                        if not os.path.exists(repo_path):
                                                            # Try to infer from standard backend structure
                                                            try:
                                                                frontend_dir = os.path.dirname(os.path.abspath(__file__))
                                                                project_root = os.path.dirname(frontend_dir)
                                                                backend_dir_local = os.path.join(project_root, "backend")
                                                                repo_name_local = selected_repo.get('name', '')
                                                                if repo_name_local:
                                                                    inferred_path = os.path.join(backend_dir_local, "temp_cloned_repos", repo_name_local)
                                                                    if os.path.exists(inferred_path):
                                                                        repo_path = inferred_path
                                                            except Exception:
                                                                pass
                                                        if repo_path:
                                                            break
                                            
                                            if repo_path:
                                                status_text.info("🔀 Creating single batch PR for all successful fixes...")
                                                
                                                # Prepare successful fixes in format expected by API
                                                fixes_for_pr = []
                                                for fix in successful_fixes:
                                                    fixes_for_pr.append({
                                                        'vuln_idx': fix.get('vuln_idx'),
                                                        'result': fix.get('result')
                                                    })
                                                
                                                # Call backend API to create single batch PR
                                                try:
                                                    pr_data = {
                                                        'successful_fixes_json': json.dumps(fixes_for_pr),
                                                        'repo_owner': str(repo_owner).strip(),
                                                        'repo_name': str(selected_repo.get('name', '')).strip(),
                                                        'repo_path': str(repo_path).strip(),
                                                        'token': str(github_token).strip(),
                                                        'base_branch': 'main'
                                                    }
                                                    
                                                    pr_response = requests.post(
                                                        f"{api_url_val}/api/fixes/create-single-batch-pr",
                                                        data=pr_data,
                                                        timeout=300
                                                    )
                                                    
                                                    if pr_response.status_code == 200:
                                                        batch_pr = pr_response.json()
                                                        if batch_pr and batch_pr.get('success'):
                                                            batch_results['batch_pr_result'] = batch_pr
                                                            status_text.success(
                                                                f"✅ **Batch Fix Complete!**\n\n"
                                                                f"✅ **Successful**: {batch_results['successful']}\n"
                                                                f"❌ **Failed**: {batch_results['failed']}\n"
                                                                f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                                                f"📊 **Total**: {batch_results['total']}\n\n"
                                                                f"🔗 **Batch PR Created**: PR #{batch_pr.get('pr_number', 'N/A')} - {batch_pr.get('pr_url', 'N/A')}\n\n"
                                                                f"*Review individual fix results below for details.*"
                                                            )
                                                        else:
                                                            error_msg = batch_pr.get('message', 'Unknown error') if batch_pr else 'Failed to create batch PR'
                                                            status_text.warning(
                                                                f"✅ **Batch Fix Complete!**\n\n"
                                                                f"✅ **Successful**: {batch_results['successful']}\n"
                                                                f"❌ **Failed**: {batch_results['failed']}\n"
                                                                f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                                                f"📊 **Total**: {batch_results['total']}\n\n"
                                                                f"⚠️ **PR Creation Failed**: {error_msg}\n\n"
                                                                f"*Review individual fix results below for details.*"
                                                            )
                                                    else:
                                                        try:
                                                            error_response = pr_response.json()
                                                            error_detail = error_response.get('detail', 'Unknown error')
                                                            if isinstance(error_detail, list):
                                                                error_messages = []
                                                                for err in error_detail:
                                                                    if isinstance(err, dict):
                                                                        loc = err.get('loc', [])
                                                                        msg = err.get('msg', '')
                                                                        error_messages.append(f"{'.'.join(str(x) for x in loc)}: {msg}")
                                                                error_detail = '; '.join(error_messages) if error_messages else 'Validation error'
                                                        except:
                                                            error_detail = pr_response.text[:500] if hasattr(pr_response, 'text') else f'HTTP {pr_response.status_code}'
                                                        
                                                        status_text.warning(
                                                            f"✅ **Batch Fix Complete!**\n\n"
                                                            f"✅ **Successful**: {batch_results['successful']}\n"
                                                            f"❌ **Failed**: {batch_results['failed']}\n"
                                                            f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                                            f"📊 **Total**: {batch_results['total']}\n\n"
                                                            f"⚠️ **PR Creation Failed**: {error_detail}\n\n"
                                                            f"*Review individual fix results below for details.*"
                                                        )
                                                except requests.exceptions.RequestException as api_error:
                                                    logger.error(f"API error creating batch PR: {str(api_error)}")
                                                    status_text.warning(
                                                        f"✅ **Batch Fix Complete!**\n\n"
                                                        f"✅ **Successful**: {batch_results['successful']}\n"
                                                        f"❌ **Failed**: {batch_results['failed']}\n"
                                                        f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                                        f"📊 **Total**: {batch_results['total']}\n\n"
                                                        f"⚠️ **PR Creation Error**: {str(api_error)}\n\n"
                                                        f"*Review individual fix results below for details.*"
                                                    )
                                            else:
                                                status_text.warning("✅ All fixes completed, but repository path not found. Cannot create batch PR.")
                                        elif not repo_owner:
                                            status_text.warning("✅ All fixes completed, but repository owner not found. Cannot create batch PR.")
                                        elif not github_token:
                                            status_text.warning("✅ All fixes completed, but GitHub token not available. Cannot create batch PR.")
                                    except Exception as pr_error:
                                        logger.error(f"Error creating batch PR: {str(pr_error)}")
                                        status_text.warning(
                                            f"✅ **Batch Fix Complete!**\n\n"
                                            f"✅ **Successful**: {batch_results['successful']}\n"
                                            f"❌ **Failed**: {batch_results['failed']}\n"
                                            f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                            f"📊 **Total**: {batch_results['total']}\n\n"
                                            f"⚠️ **PR Creation Error**: {str(pr_error)}\n\n"
                                            f"*Review individual fix results below for details.*"
                                        )
                                else:
                                    status_text.success(
                                        f"✅ **Batch Fix Complete!**\n\n"
                                        f"✅ **Successful**: {batch_results['successful']}\n"
                                        f"❌ **Failed**: {batch_results['failed']}\n"
                                        f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                        f"📊 **Total**: {batch_results['total']}\n\n"
                                        f"*No successful fixes to create PR for.*"
                                    )
                                
                                # Clear the in-progress key
                                if batch_fix_key in st.session_state:
                                    del st.session_state[batch_fix_key]
                                progress_bar.progress(1.0)
                                
                                # Don't display flow here - it will be shown in the summary section below
                                # to avoid duplication
                                
                                st.session_state[batch_result_key] = batch_results
                            else:
                                # Process current vulnerability (same as normal mode but without individual PRs)
                                vuln_idx, vuln = fixable_vulns[current_index]
                                vuln_type = vuln.get('vulnerability', 'Unknown')
                                file_path = vuln.get('matched_file_path', 'N/A')
                                line_no = vuln.get('line_no', 'N/A')
                                
                                # Update progress
                                completed_count = len(completed_indices)
                                progress = (completed_count + 1) / batch_results['total'] if batch_results['total'] > 0 else 0
                                progress_bar.progress(progress)
                                
                                # Clear status message showing current vulnerability
                                status_text.markdown(
                                    f"**Fixing Vulnerability {current_index + 1}/{batch_results['total']}**\n\n"
                                    f"🔹 **Vulnerability #{vuln_idx}**: {vuln_type}\n"
                                    f"🔹 **File**: `{file_path}`\n"
                                    f"🔹 **Line**: {line_no}\n\n"
                                    f"**Running 6 AI Agents:**\n"
                                   f"1. 🤖 Vulnerability Analyzer\n"
                                   f"2. 🔍 Code Context Agent\n"
                                   f"3. 📋 Fix Strategy Agent\n"
                                   f"4. 🔧 Code Fix Agent\n"
                                   f"5. ✅ Safety Validator Agent\n"
                                   f"6. 📝 Explanation Agent\n\n"
                                    f"*Check backend logs for detailed agent progress*\n"
                                    f"*A single batch PR will be created after all fixes complete*"
                                )
                                
                                # Display flow visualization
                                with status_container:
                                    st.markdown("---")
                                    st.markdown("### 🔄 Fix Progress Flow")
                                    display_vulnerability_flow(fixable_vulns, current_index, completed_indices, batch_results)
                                
                                clone_url = selected_repo.get('clone_url') or selected_repo.get('html_url', '')
                                repo_name = selected_repo.get('name', 'unknown')
                                
                                # Call orchestrate_fix for individual vulnerability
                                with st.spinner(
                                    f"🤖 Processing Vulnerability {completed_count + 1}/{batch_results['total']}: {vuln_type}\n"
                                    f"Running 6 AI agents sequentially... This may take 1-3 minutes."
                                ):
                                    result, error = orchestrate_fix(
                                    api_url=api_url_val,
                                        vulnerability_type=vuln.get('vulnerability', 'Unknown'),
                                        description=vuln.get('description', ''),
                                        severity=vuln.get('severity', 'high').lower() if vuln.get('severity') else 'high',
                                        file_path=vuln.get('matched_file_path'),
                                        line_number=int(vuln.get('line_no', 0)) if str(vuln.get('line_no', '0')).isdigit() else 0,
                                        repo_path=None,
                                        repo_name=repo_name,
                                        clone_url=clone_url,
                                    token=github_token,
                                        recommendation=vuln.get('recommendation')
                                    )
                                
                                # Process result (same as normal mode but skip individual PR creation)
                                if error:
                                    batch_results['failed'] += 1
                                    batch_results['results'].append({
                                        'vuln_idx': vuln_idx,
                                        'vulnerability_type': vuln_type,
                                        'file_path': file_path,
                                        'status': 'failed',
                                        'error': error,
                                        'result': None
                                    })
                                    # Mark as completed (even though failed) for flow visualization
                                    if current_index not in completed_indices:
                                        completed_indices.append(current_index)
                                    
                                    # Update batch_results with completed indices BEFORE moving to next
                                    batch_results['completed_indices'] = completed_indices.copy()
                                    batch_results['current_index'] = current_index + 1
                                    
                                    # Save to session state IMMEDIATELY
                                    st.session_state[batch_result_key] = batch_results
                                    
                                    status_text.error(
                                        f"❌ **Failed to fix Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                                        f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                                        f"**Error**: {error}\n\n"
                                        f"Check backend logs for detailed error information."
                                    )
                                    
                                    # Update flow visualization AFTER state is saved
                                    with status_container:
                                        st.markdown("---")
                                        st.markdown("### 🔄 Fix Progress Flow")
                                        display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                                    
                                    # Continue to next fix
                                    st.rerun()
                                else:
                                    # Add repo info to result
                                    if result and isinstance(result, dict):
                                        result['repo_name'] = repo_name
                                        result['repo_path'] = result.get('repo_path', '') or result.get('result', {}).get('repo_path', '')
                                        result['vulnerability_type'] = vuln_type
                                        result['description'] = vuln.get('description', '')
                                    
                                    batch_results['successful'] += 1
                                    result_entry = {
                                        'vuln_idx': vuln_idx,
                                        'vulnerability_type': vuln_type,
                                        'file_path': file_path,
                                        'status': 'success',
                                        'error': None,
                                        'result': result
                                    }
                                    
                                    batch_results['results'].append(result_entry)
                                    
                                    # Store individual fix result for display
                                    fix_result_key = f'fix_result_{selected_repo_id}_{vuln_idx}'
                                    st.session_state[fix_result_key] = result
                                    
                                    # Mark as completed
                                    if current_index not in completed_indices:
                                        completed_indices.append(current_index)
                                    
                                    # Update batch_results with completed indices BEFORE moving to next
                                    batch_results['completed_indices'] = completed_indices.copy()
                                    
                                    # Move to next fix
                                    batch_results['current_index'] = current_index + 1
                                    
                                    # Save to session state IMMEDIATELY to ensure state is persisted
                                    st.session_state[batch_result_key] = batch_results
                                    
                                    status_text.success(
                                        f"✅ **Successfully fixed Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                                        f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                                        f"**File**: `{file_path}`\n"
                                        f"**Line**: {line_no}\n\n"
                                        f"*A batch PR will be created after all fixes complete*"
                                    )
                                    
                                    # Update flow visualization AFTER state is saved
                                    # Show current vulnerability as completed, next one as processing
                                    with status_container:
                                        st.markdown("---")
                                        st.markdown("### 🔄 Fix Progress Flow")
                                        display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                                    
                                    # Continue to next fix
                            st.rerun()

                        # ------------------------------------------------------------------
                        # NORMAL MODE (no auto PR): incremental per-vulnerability fixes
                        # ------------------------------------------------------------------
                        # Derive the next index to process from completed_indices so that
                        # we never get stuck on a vulnerability due to stale state.
                        if fixable_vulns:
                            all_indices = set(range(len(fixable_vulns)))
                            remaining_indices = sorted(all_indices - set(completed_indices))
                            if remaining_indices:
                                current_index = remaining_indices[0]
                            else:
                                # All indices completed
                                current_index = len(fixable_vulns)
                                batch_results['current_index'] = current_index
                            st.session_state[batch_result_key] = batch_results
                            
                        # Process fixes one at a time with clear progress
                        if current_index < len(fixable_vulns):
                            if current_index >= len(fixable_vulns):
                                # All fixes completed
                                if batch_fix_key in st.session_state:
                                    del st.session_state[batch_fix_key]
                                progress_bar.progress(1.0)
                                status_text.success(
                                    f"🎉 **Batch Fix Complete!**\n\n"
                                    f"✅ **Successful**: {batch_results['successful']}\n"
                                    f"❌ **Failed**: {batch_results['failed']}\n"
                                    f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                    f"📊 **Total**: {batch_results['total']}\n\n"
                                    f"*Review individual fix results below for details.*"
                                )
                            else:
                                # Process current vulnerability
                                vuln_idx, vuln = fixable_vulns[current_index]
                                vuln_type = vuln.get('vulnerability', 'Unknown')
                                file_path = vuln.get('matched_file_path', 'N/A')
                                line_no = vuln.get('line_no', 'N/A')
                                
                                # Update progress
                                completed_count = len(completed_indices)
                                progress = (completed_count + 1) / batch_results['total'] if batch_results['total'] > 0 else 0
                                progress_bar.progress(progress)
                                
                                # Clear status message showing current vulnerability
                                status_text.markdown(
                                    f"**Fixing Vulnerability {current_index + 1}/{batch_results['total']}**\n\n"
                                    f"🔹 **Vulnerability #{vuln_idx}**: {vuln_type}\n"
                                    f"🔹 **File**: `{file_path}`\n"
                                    f"🔹 **Line**: {line_no}\n\n"
                                    f"**Running 6 AI Agents:**\n"
                                    f"1. 🤖 Vulnerability Analyzer\n"
                                    f"2. 🔍 Code Context Agent\n"
                                    f"3. 📋 Fix Strategy Agent\n"
                                    f"4. 🔧 Code Fix Agent\n"
                                    f"5. ✅ Safety Validator Agent\n"
                                    f"6. 📝 Explanation Agent\n\n"
                                    f"*Check backend logs for detailed agent progress*"
                                )
                                
                                # Display flow visualization
                                with status_container:
                                    st.markdown("---")
                                    st.markdown("### 🔄 Fix Progress Flow")
                                    display_vulnerability_flow(fixable_vulns, current_index, completed_indices, batch_results)
                                
                                clone_url = selected_repo.get('clone_url') or selected_repo.get('html_url', '')
                                repo_name = selected_repo.get('name', 'unknown')
                                
                                # Call orchestrate_fix for individual vulnerability
                                with st.spinner(
                                    f"🤖 Processing Vulnerability {completed_count + 1}/{batch_results['total']}: {vuln_type}\n"
                                    f"Running 6 AI agents sequentially... This may take 1-3 minutes."
                                ):
                                    result, error = orchestrate_fix(
                                        api_url=api_url_val,
                                        vulnerability_type=vuln.get('vulnerability', 'Unknown'),
                                        description=vuln.get('description', ''),
                                        severity=vuln.get('severity', 'high').lower() if vuln.get('severity') else 'high',
                                        file_path=vuln.get('matched_file_path'),
                                        line_number=int(vuln.get('line_no', 0)) if str(vuln.get('line_no', '0')).isdigit() else 0,
                                        repo_path=None,
                                        repo_name=repo_name,
                                        clone_url=clone_url,
                                        token=github_token,
                                        recommendation=vuln.get('recommendation')
                                    )
                                
                                # Initialize pr_result
                                pr_result = None
                                
                                # Process result
                                if error:
                                    batch_results['failed'] += 1
                                    batch_results['results'].append({
                                        'vuln_idx': vuln_idx,
                                        'vulnerability_type': vuln_type,
                                        'file_path': file_path,
                                        'status': 'failed',
                                        'error': error,
                                        'result': None
                                    })
                                    # Mark as completed (even though failed) for flow visualization
                                    if current_index not in completed_indices:
                                        completed_indices.append(current_index)
                                    
                                    # Update batch_results with completed indices BEFORE moving to next
                                    batch_results['completed_indices'] = completed_indices.copy()
                                    batch_results['current_index'] = current_index + 1
                                    
                                    # Save to session state IMMEDIATELY
                                    st.session_state[batch_result_key] = batch_results
                                    
                                    status_text.error(
                                        f"❌ **Failed to fix Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                                        f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                                        f"**Error**: {error}\n\n"
                                        f"Check backend logs for detailed error information."
                                    )
                                    
                                    # Update flow visualization AFTER state is saved
                                    with status_container:
                                        st.markdown("---")
                                        st.markdown("### 🔄 Fix Progress Flow")
                                        display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                                    
                                    # Continue to next fix
                                    if current_index + 1 < len(fixable_vulns):
                                        st.rerun()
                                    else:
                                        # All fixes completed
                                        if batch_fix_key in st.session_state:
                                            del st.session_state[batch_fix_key]
                                        progress_bar.progress(1.0)
                                        status_text.success(
                                            f"🎉 **Batch Fix Complete!**\n\n"
                                            f"✅ **Successful**: {batch_results['successful']}\n"
                                            f"❌ **Failed**: {batch_results['failed']}\n"
                                            f"⏭️  **Skipped**: {batch_results['skipped']}\n"
                                            f"📊 **Total**: {batch_results['total']}\n\n"
                                            f"*Review individual fix results below for details.*"
                                        )
                                else:
                                    # Add repo info to result
                                    if result and isinstance(result, dict):
                                        result['repo_name'] = repo_name
                                        # Get repo_path from top level (API returns it there) or from result data
                                        result['repo_path'] = result.get('repo_path', '') or result.get('result', {}).get('repo_path', '')
                                        result['vulnerability_type'] = vuln_type
                                        result['description'] = vuln.get('description', '')
                                    
                                    # If auto PR is enabled and fix was successful, create PR
                                    if auto_create_pr and not error and result and result.get('success'):
                                        status_text.success(
                                            f"✅ **Successfully fixed Vulnerability {completed_count + 1}/{batch_results['total']}**\n\n"
                                            f"**Vulnerability #{vuln_idx}**: {vuln_type}\n"
                                            f"**File**: `{file_path}`\n"
                                            f"**Line**: {line_no}\n\n"
                                            f"🔀 Creating Pull Request..."
                                        )
                                        
                                        # Get repository info for PR creation
                                        repo_info = None
                                        if 'repositories_data' in st.session_state:
                                            repos_data = st.session_state['repositories_data']
                                            for repo in repos_data.get('repositories', []):
                                                if repo.get('name') == selected_repo.get('name') or repo.get('id') == selected_repo_id:
                                                    repo_info = repo
                                                    break
                                        
                                        repo_owner = selected_repo.get('full_name', '').split('/')[0] if '/' in selected_repo.get('full_name', '') else None
                                        
                                        if repo_info:
                                            # Extract repo owner if not already set
                                            if not repo_owner:
                                                owner_data = repo_info.get('owner', {})
                                                if isinstance(owner_data, dict):
                                                    repo_owner = owner_data.get('login', '') or owner_data.get('name', '')
                                                else:
                                                    repo_owner = str(owner_data) if owner_data else ''
                                            
                                            if not repo_owner:
                                                full_name = repo_info.get('full_name', '')
                                                if isinstance(full_name, str) and "/" in full_name:
                                                    repo_owner = full_name.split("/")[0]
                                        
                                        if not repo_owner and clone_url and 'github.com' in clone_url:
                                            parts = clone_url.replace('https://github.com/', '').replace('.git', '').split('/')
                                            if len(parts) >= 1:
                                                repo_owner = parts[0]
                                        
                                        if repo_owner and github_token:
                                            # Extract required fields from fix result for PR creation
                                            files_modified, fixed_code_map = extract_fixed_code_from_result(result)
                                            
                                            # Get vulnerability details
                                            result_data = result.get('result', {}) if isinstance(result, dict) else result
                                            code_fix = result_data.get('code_fix', {}) if isinstance(result_data, dict) else {}
                                            
                                            vuln_type_for_pr = result.get('vulnerability_type', vuln_type)
                                            vuln_desc_for_pr = result.get('description', vuln.get('description', ''))
                                            fix_summary = code_fix.get('change_summary', f'Fixed {vuln_type_for_pr} vulnerability') if code_fix else f'Fixed {vuln_type_for_pr} vulnerability'
                                            
                                            # Get repo_path - check multiple locations
                                            # API returns repo_path at top level of response
                                            repo_path_for_pr = result.get('repo_path', '')
                                            if not repo_path_for_pr:
                                                # Try from result data
                                                repo_path_for_pr = result_data.get('repo_path', '') if isinstance(result_data, dict) else ''
                                            
                                            # If still missing, try to infer from backend temp_cloned_repos location
                                            if not repo_path_for_pr or not os.path.exists(repo_path_for_pr):
                                                try:
                                                    # Infer from standard backend structure
                                                    frontend_dir = os.path.dirname(os.path.abspath(__file__))
                                                    project_root = os.path.dirname(frontend_dir)
                                                    backend_dir_local = os.path.join(project_root, "backend")
                                                    repo_name_local = result.get('repo_name', repo_name)
                                                    if repo_name_local:
                                                        inferred_path = os.path.join(backend_dir_local, "temp_cloned_repos", repo_name_local)
                                                        if os.path.exists(inferred_path):
                                                            repo_path_for_pr = inferred_path
                                                except Exception:
                                                    pass
                                            
                                            # Final validation - ensure repo_path exists
                                            if repo_path_for_pr and not os.path.exists(repo_path_for_pr):
                                                # Path doesn't exist, try to find it
                                                repo_path_for_pr = ''
                                            
                                            # Validate we have required data
                                            if not files_modified or not fixed_code_map:
                                                pr_result = {
                                                    'success': False,
                                                    'message': 'Missing files_modified or fixed_code in fix result. Cannot create PR.'
                                                }
                                                status_text.text(
                                                    f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                    f"❌ PR Error: Missing fix data"
                                                )
                                            elif not repo_path_for_pr:
                                                pr_result = {
                                                    'success': False,
                                                    'message': 'Repository path is missing. Cannot create PR.'
                                                }
                                                status_text.text(
                                                    f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                    f"❌ PR Error: Missing repository path"
                                                )
                                            elif not vuln_type_for_pr or not vuln_desc_for_pr:
                                                pr_result = {
                                                    'success': False,
                                                    'message': 'Vulnerability details are missing. Cannot create PR.'
                                                }
                                                status_text.text(
                                                    f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                    f"❌ PR Error: Missing vulnerability details"
                                                )
                                            else:
                                                # Create PR using the create_pr API
                                                try:
                                                    api_url = api_url_val
                                                    
                                                    # Ensure all required fields are strings and not empty
                                                    pr_data = {
                                                        'repo_owner': str(repo_owner).strip(),
                                                        'repo_name': str(repo_name).strip(),
                                                        'repo_path': str(repo_path_for_pr).strip(),
                                                        'files_modified_json': json.dumps(files_modified),
                                                        'fixed_code_json': json.dumps(fixed_code_map),
                                                        'vulnerability_type': str(vuln_type_for_pr).strip(),
                                                        'vulnerability_description': str(vuln_desc_for_pr).strip() or 'Security vulnerability fix',
                                                        'fix_summary': str(fix_summary).strip() or f'Fixed {vuln_type_for_pr} vulnerability',
                                                        'token': str(github_token).strip(),
                                                        'base_branch': 'main'
                                                    }
                                                    
                                                    # Validate all required fields are present and non-empty
                                                    # Check string fields
                                                    required_string_fields = ['repo_owner', 'repo_name', 'repo_path', 'vulnerability_type', 'vulnerability_description', 'fix_summary', 'token']
                                                    missing_fields = [field for field in required_string_fields if not pr_data.get(field) or (isinstance(pr_data.get(field), str) and not pr_data.get(field).strip())]
                                                    
                                                    # Validate JSON fields separately
                                                    if not files_modified or not pr_data.get('files_modified_json') or pr_data.get('files_modified_json') == '[]':
                                                        missing_fields.append('files_modified_json')
                                                    if not fixed_code_map or not pr_data.get('fixed_code_json') or pr_data.get('fixed_code_json') == '{}':
                                                        missing_fields.append('fixed_code_json')
                                                    
                                                    if missing_fields:
                                                        missing_fields_str = ", ".join(missing_fields)
                                                        pr_result = {
                                                            'success': False,
                                                            'message': f'Missing required fields: {missing_fields_str}'
                                                        }
                                                        status_text.text(
                                                            f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                            f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                            f"❌ PR Error: Missing fields: {missing_fields_str}"
                                                        )
                                                    else:
                                                        # Debug: Log what we're sending (without token)
                                                        debug_data = {k: v if k != 'token' else '***' for k, v in pr_data.items()}
                                                        logger.debug(f"Creating PR with data: {debug_data}")
                                                        
                                                        pr_response = requests.post(
                                                            f"{api_url}/api/fixes/create-pr",
                                                            data=pr_data,
                                                            timeout=300
                                                        )
                                                        
                                                        if pr_response.status_code == 200:
                                                            pr_result = pr_response.json()
                                                            if pr_result.get('success'):
                                                                status_text.text(
                                                                    f"✅ Fixed & PR Created: {completed_count + 1}/{batch_results['total']}\n"
                                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                                    f"🔗 PR #{pr_result.get('pr_number', 'N/A')}"
                                                                )
                                                            else:
                                                                pr_result = {'success': False, 'message': pr_result.get('message', 'Unknown error')}
                                                                status_text.text(
                                                                    f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                                    f"❌ PR Error: {pr_result.get('message', 'Unknown error')}"
                                                                )
                                                        else:
                                                            # Better error handling for 422 and other errors
                                                            try:
                                                                error_response = pr_response.json()
                                                                error_detail = error_response.get('detail', 'Unknown error')
                                                                # If detail is a list (FastAPI validation errors), format it
                                                                if isinstance(error_detail, list):
                                                                    error_messages = []
                                                                    for err in error_detail:
                                                                        if isinstance(err, dict):
                                                                            loc = err.get('loc', [])
                                                                            msg = err.get('msg', '')
                                                                            error_messages.append(f"{'.'.join(str(x) for x in loc)}: {msg}")
                                                                    error_detail = '; '.join(error_messages) if error_messages else 'Validation error'
                                                            except:
                                                                error_detail = pr_response.text[:500] if hasattr(pr_response, 'text') else f'HTTP {pr_response.status_code}'
                                                            
                                                            pr_result = {'success': False, 'message': error_detail}
                                                            logger.error(f"PR creation failed (HTTP {pr_response.status_code}): {error_detail}")
                                                            status_text.text(
                                                                f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                                f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                                f"❌ PR Error: {error_detail}"
                                                            )
                                                except Exception as pr_error:
                                                    logger.error(f"Error creating PR: {str(pr_error)}")
                                                    pr_result = {'success': False, 'message': str(pr_error)}
                                                    status_text.text(
                                                        f"✅ Fixed but PR Failed: {completed_count + 1}/{batch_results['total']}\n"
                                                        f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                        f"❌ PR Exception: {str(pr_error)}"
                                                    )
                                        else:
                                            # Missing repo_owner or token - skip PR creation
                                            pr_result = None
                                            if not repo_owner:
                                                status_text.text(
                                                    f"✅ Fixed but PR Skipped: {completed_count + 1}/{batch_results['total']}\n"
                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                    f"⚠️ Missing repository owner"
                                                )
                                            elif not github_token:
                                                status_text.text(
                                                    f"✅ Fixed but PR Skipped: {completed_count + 1}/{batch_results['total']}\n"
                                                    f"📋 Vulnerability #{vuln_idx}: {vuln_type}\n"
                                                    f"⚠️ Missing GitHub token"
                                                )
                                    
                                    batch_results['successful'] += 1
                                    result_entry = {
                                        'vuln_idx': vuln_idx,
                                        'vulnerability_type': vuln_type,
                                        'file_path': file_path,
                                        'status': 'success',
                                        'error': None,
                                        'result': result
                                    }
                                    
                                    # Add PR result if auto PR was enabled and PR was created
                                    if auto_create_pr and pr_result:
                                        if not batch_results.get('pr_results'):
                                            batch_results['pr_results'] = []
                                        
                                        pr_entry = {
                                            'vuln_idx': vuln_idx,
                                            'status': 'success' if pr_result.get('success') else 'failed',
                                            'error': None if pr_result.get('success') else pr_result.get('message', 'Unknown error'),
                                            'pr_result': pr_result if pr_result.get('success') else None
                                        }
                                        batch_results['pr_results'].append(pr_entry)
                                        
                                        # Store PR result in session state
                                        if pr_result.get('success'):
                                            pr_key = f'pr_result_{selected_repo_id}_{vuln_idx}'
                                            st.session_state[pr_key] = pr_result
                                    
                                    batch_results['results'].append(result_entry)
                                    
                                    # Store individual fix result for display
                                    fix_result_key = f'fix_result_{selected_repo_id}_{vuln_idx}'
                                    st.session_state[fix_result_key] = result
                                    
                                    # Mark as completed FIRST
                                    if current_index not in completed_indices:
                                        completed_indices.append(current_index)
                                    
                                    # Update batch_results with completed indices BEFORE moving to next
                                    batch_results['completed_indices'] = completed_indices.copy()
                                    
                                    # Move to next fix
                                    batch_results['current_index'] = current_index + 1
                                    
                                    # Save to session state IMMEDIATELY to ensure state is persisted
                                    st.session_state[batch_result_key] = batch_results
                                    
                                    # Update flow visualization AFTER state is saved
                                    # Show current vulnerability as completed, next one as processing
                                    with status_container:
                                        st.markdown("---")
                                        st.markdown("### 🔄 Fix Progress Flow")
                                        display_vulnerability_flow(fixable_vulns, current_index + 1, completed_indices, batch_results)
                                    
                                    # Continue to next fix
                                    if current_index + 1 < len(fixable_vulns):
                                        st.rerun()
                                    else:
                                        # All fixes completed
                                        if batch_fix_key in st.session_state:
                                            del st.session_state[batch_fix_key]
                                        progress_bar.progress(1.0)
                                        pr_success_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'success'])
                                        pr_failed_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'failed'])
                                        status_msg = f"✅ Completed: {batch_results['successful']} successful, {batch_results['failed']} failed, {batch_results['skipped']} skipped"
                                        # In the new design we expect a single batch PR per repository.
                                        if pr_success_count > 0:
                                            status_msg += f", 1 batch PR created"
                                        if pr_failed_count > 0:
                                            status_msg += f", PR creation failed"
                                        status_text.text(status_msg)
                        else:
                            # All fixes completed
                            if batch_fix_key in st.session_state:
                                del st.session_state[batch_fix_key]
                            progress_bar.progress(1.0)
                            pr_success_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'success'])
                            pr_failed_count = len([r for r in batch_results.get('pr_results', []) if r.get('status') == 'failed'])
                            status_msg = f"✅ Completed: {batch_results['successful']} successful, {batch_results['failed']} failed, {batch_results['skipped']} skipped"
                            if pr_success_count > 0:
                                status_msg += f", 1 batch PR created"
                            if pr_failed_count > 0:
                                status_msg += f", PR creation failed"
                            status_text.text(status_msg)
                    
                    # Add cancel button if processing
                    if batch_fix_key in st.session_state:
                        batch_fix_req_check = st.session_state[batch_fix_key]
                        current_idx_check = batch_fix_req_check.get('current_index', 0)
                        if batch_result_key in st.session_state:
                            batch_results_check = st.session_state[batch_result_key]
                            fixable_vulns_check = batch_results_check.get('fixable_vulns', [])
                            if current_idx_check < len(fixable_vulns_check):
                                col1, col2, col3 = st.columns([1, 1, 1])
                                with col2:
                                    if st.button("🛑 Cancel Batch Fix", key=f"cancel_batch_fix_{selected_repo_id}", width='stretch'):
                                        # Clear request but keep results
                                        if batch_fix_key in st.session_state:
                                            del st.session_state[batch_fix_key]
                                        st.rerun()
                    
                    # Display batch fix summary
                    if batch_result_key in st.session_state:
                        batch_results = st.session_state[batch_result_key]
                        batch_fix_still_running = batch_fix_key in st.session_state

                        # ------------------------------------------------------------------
                        # Derive completed indices from results (source of truth) so that
                        # the flow visualization is always accurate, even across reruns.
                        # ------------------------------------------------------------------
                        fixable_vulns = batch_results.get('fixable_vulns', [])
                        results_list = batch_results.get('results', [])
                        if fixable_vulns and results_list:
                            idx_by_vuln = {vuln_idx: i for i, (vuln_idx, _v) in enumerate(fixable_vulns, 0)}
                            auto_completed_indices = []
                            for res in results_list:
                                res_vuln_idx = res.get('vuln_idx')
                                if res_vuln_idx in idx_by_vuln:
                                    auto_completed_indices.append(idx_by_vuln[res_vuln_idx])
                            auto_completed_indices = sorted(set(auto_completed_indices))
                            batch_results['completed_indices'] = auto_completed_indices
                            st.session_state[batch_result_key] = batch_results

                        # Show progress if still running
                        if batch_fix_still_running:
                            current_idx = batch_results.get('current_index', 0)
                            completed_indices = batch_results.get('completed_indices', []) or []
                            completed_count = len(completed_indices)
                            total = batch_results.get('total', 0)
                            
                            st.markdown("---")
                            st.markdown("### 🔄 Batch Fix in Progress")
                            
                            # Display circular flow visualization
                            if fixable_vulns:
                                display_vulnerability_flow(fixable_vulns, current_idx, completed_indices, batch_results)
                            
                            # Additional metrics
                            st.markdown("---")
                            col1, col2, col3, col4 = st.columns(4)
                            with col1:
                                st.metric("Total", total)
                            with col2:
                                st.metric("✅ Completed", completed_count, delta=None)
                            with col3:
                                st.metric("🔄 In Progress", 1 if current_idx < total else 0, delta=None)
                            with col4:
                                remaining = total - completed_count
                                st.metric("⏳ Remaining", remaining, delta=None)
                        else:
                            st.markdown("---")
                            st.markdown("### 📊 Batch Fix Summary")

                            # Show final flow visualization with all completed statuses
                            fixable_vulns_summary = batch_results.get('fixable_vulns', [])
                            completed_indices_summary = batch_results.get('completed_indices')
                            if completed_indices_summary is None and fixable_vulns_summary:
                                completed_indices_summary = list(range(len(fixable_vulns_summary)))
                            if fixable_vulns_summary and completed_indices_summary is not None:
                                st.markdown("### 🔄 Fix Progress Flow")
                                display_vulnerability_flow(
                                    fixable_vulns_summary,
                                    len(fixable_vulns_summary),
                                    completed_indices_summary,
                                    batch_results,
                                )
                            
                            display_fix_results(batch_results, selected_repo_id)


                            
                            # Create PR for All button - only show if batch fix is complete and auto PR is disabled
                            batch_fix_key_check = f'batch_fix_request_{selected_repo_id}'
                            batch_fix_still_running = batch_fix_key_check in st.session_state
                            auto_pr_enabled = st.session_state.get(f"auto_create_pr_{selected_repo_id}", False)
                            
                            # Check if PRs were already created (from auto PR)
                            pr_results = batch_results.get('pr_results', [])
                            if not pr_results:
                                # Try to get from batch_result if it was stored differently
                                if 'pr_results' in batch_results:
                                    pr_results = batch_results['pr_results']
                            
                            prs_created = len([r for r in pr_results if r.get('status') == 'success']) if pr_results else 0
                            prs_failed = len([r for r in pr_results if r.get('status') == 'failed']) if pr_results else 0
                            
                            # Show PR results if auto PR was enabled and we have PR results
                            if pr_results and len(pr_results) > 0:
                                st.markdown("---")
                                if prs_created > 0:
                                    st.markdown("### ✅ Pull Requests Created")
                                    st.success(f"🎉 Successfully created {prs_created} Pull Request(s) automatically!")
                                    
                                    # Display PR links with merge options
                                    for pr_res in pr_results:
                                        if pr_res.get('status') == 'success':
                                            pr_result = pr_res.get('pr_result', {})
                                            vuln_idx = pr_res.get('vuln_idx', 0)
                                            pr_url = pr_result.get('pr_url', '')
                                            pr_number = pr_result.get('pr_number', '')
                                            branch_name = pr_result.get('branch_name', '')
                                            
                                            if pr_url:
                                                col1, col2, col3 = st.columns([3, 1, 1])
                                                with col1:
                                                    st.markdown(f"**Vulnerability #{vuln_idx}**: [PR #{pr_number}]({pr_url})")
                                                
                                                with col2:
                                                    # Quick mergeability check
                                                    if st.button(
                                                        "🔍 Check",
                                                        key=f"quick_check_{selected_repo_id}_{vuln_idx}",
                                                        width='stretch'
                                                    ):
                                                        with st.spinner("Checking..."):
                                                            api_url = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
                                                            repo_info = selected_repo
                                                            repo_owner = None
                                                            if repo_info:
                                                                owner_data = repo_info.get('owner', {})
                                                                if isinstance(owner_data, dict):
                                                                    repo_owner = owner_data.get('login', '') or owner_data.get('name', '')
                                                                else:
                                                                    repo_owner = str(owner_data) if owner_data else ''
                                                                
                                                                if not repo_owner:
                                                                    full_name = repo_info.get('full_name', '')
                                                                    if isinstance(full_name, str) and "/" in full_name:
                                                                        repo_owner = full_name.split("/")[0]
                                                            
                                                            repo_name = repo_info.get('name', '') if repo_info else ''
                                                            
                                                            if repo_owner and repo_name:
                                                                mergeability_result, error = check_pr_mergeability(
                                                                    api_url=api_url,
                                                                    repo_owner=repo_owner,
                                                                    repo_name=repo_name,
                                                                    pr_number=pr_number,
                                                                    token=st.session_state.get('github_token', '')
                                                                )
                                                                if mergeability_result:
                                                                    if mergeability_result.get('merged'):
                                                                        st.success("✅ Merged")
                                                                    elif mergeability_result.get('mergeable'):
                                                                        st.success("✅ Ready")
                                                                    elif mergeability_result.get('has_conflicts'):
                                                                        st.warning("⚠️ Conflicts")
                                                                    else:
                                                                        st.info(f"ℹ️ {mergeability_result.get('mergeable_state', 'unknown')}")
                                                
                                                with col3:
                                                    # Quick merge button
                                                    if st.button(
                                                        "🔀 Merge",
                                                        key=f"quick_merge_{selected_repo_id}_{vuln_idx}",
                                                        type="primary",
                                                        width='stretch'
                                                    ):
                                                        with st.spinner("Merging..."):
                                                            api_url = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
                                                            repo_info = selected_repo
                                                            repo_owner = None
                                                            if repo_info:
                                                                owner_data = repo_info.get('owner', {})
                                                                if isinstance(owner_data, dict):
                                                                    repo_owner = owner_data.get('login', '') or owner_data.get('name', '')
                                                                else:
                                                                    repo_owner = str(owner_data) if owner_data else ''
                                                                
                                                                if not repo_owner:
                                                                    full_name = repo_info.get('full_name', '')
                                                                    if isinstance(full_name, str) and "/" in full_name:
                                                                        repo_owner = full_name.split("/")[0]
                                                            
                                                            repo_name = repo_info.get('name', '') if repo_info else ''
                                                            repo_path = batch_results.get('repo_path', '')
                                                            
                                                            if repo_owner and repo_name and repo_path and branch_name:
                                                                merge_result, error = merge_pr_with_conflict_resolution(
                                                                    api_url=api_url,
                                                                    repo_owner=repo_owner,
                                                                    repo_name=repo_name,
                                                                    pr_number=pr_number,
                                                                    repo_path=repo_path,
                                                                    branch_name=branch_name,
                                                                    token=st.session_state.get('github_token', ''),
                                                                    base_branch=base_branch,
                                                                    conflict_resolution_strategy="ours",
                                                                    merge_strategy="merge"
                                                                )
                                                                if merge_result and merge_result.get('success'):
                                                                    st.success("✅ Merged!")
                                                                    st.rerun()
                                                                else:
                                                                    st.error(f"❌ {error or merge_result.get('message', 'Failed')}")
                                            else:
                                                st.info(f"**Vulnerability #{vuln_idx}**: PR created (details not available)")
                                
                                if prs_failed > 0:
                                    st.warning(f"⚠️ {prs_failed} PR creation(s) failed. Check logs for details.")
                                    # Show failed PRs
                                    with st.expander("Show failed PRs"):
                                        for pr_res in pr_results:
                                            if pr_res.get('status') == 'failed':
                                                vuln_idx = pr_res.get('vuln_idx', 0)
                                                error = pr_res.get('error', 'Unknown error')
                                                st.error(f"**Vulnerability #{vuln_idx}**: {error}")
                            
                            # Also check if auto PR was enabled but no PR results yet (might still be processing)
                            elif auto_pr_enabled and not batch_fix_still_running:
                                st.info("ℹ️ Auto PR creation was enabled. Check the batch fix results above for PR creation status.")
                            
                            # Only show PR button if batch fix is complete and auto PR is disabled
                            if not batch_fix_still_running and not auto_pr_enabled:
                                successful_fixes = [
                                    r
                                    for r in batch_results['results']
                                    if r.get('status') == 'success' and r.get('result')
                                ]
                                
                                # Debug: Show count if there's a mismatch
                                if len(successful_fixes) == 0 and batch_results['successful'] > 0:
                                    st.warning(
                                        f"⚠️ Found {batch_results['successful']} successful fixes but no results with 'result' field. "
                                        "Check fix result structure."
                                    )
                                    # Try to show what we have
                                    with st.expander("Debug: Show all results"):
                                        for idx, res in enumerate(batch_results['results']):
                                            st.write(
                                                f"Result {idx}: status={res.get('status')}, "
                                                f"has_result={res.get('result') is not None}"
                                            )
                                
                        if successful_fixes:
                            st.markdown("---")
                            st.markdown("### 🚀 Create Pull Requests for All Fixes")
                            
                            # Get repository info
                            repo_info = None
                            if 'repositories_data' in st.session_state:
                                repos_data = st.session_state['repositories_data']
                                for repo in repos_data.get('repositories', []):
                                    if repo.get('name') == selected_repo.get('name') or repo.get('id') == selected_repo_id:
                                        repo_info = repo
                                        break
                            
                            if repo_info:
                                # Extract repo owner
                                owner_data = repo_info.get('owner', {})
                                if isinstance(owner_data, dict):
                                    repo_owner = owner_data.get('login', '') or owner_data.get('name', '')
                                else:
                                    repo_owner = str(owner_data) if owner_data else ''
                                
                                # Fallback: extract owner from full_name
                                if not repo_owner:
                                    full_name = repo_info.get('full_name', '')
                                    if isinstance(full_name, str) and "/" in full_name:
                                        repo_owner = full_name.split("/")[0]
                                
                                repo_name = repo_info.get('name', '')
                                
                                if repo_owner:
                                    col1, col2 = st.columns([1, 1])
                                    with col1:
                                        base_branch = st.selectbox(
                                            "Base Branch for All PRs",
                                            ["main", "master", "develop"],
                                            key=f"batch_base_branch_{selected_repo_id}",
                                            help="Select the branch to merge all fixes into"
                                        )
                                    
                                    with col2:
                                        st.write("")  # Spacing
                                        st.write("")  # Spacing
                                        batch_pr_button_key = f"batch_create_prs_{selected_repo_id}"
                                        batch_pr_request_key = f'batch_pr_request_{selected_repo_id}'
                                        batch_pr_result_key = f'batch_pr_result_{selected_repo_id}'
                                        
                                        # Check if PR creation is already in progress or completed
                                        pr_in_progress = batch_pr_request_key in st.session_state
                                        
                                        if st.button(
                                            f"📝 Create PRs for All ({len(successful_fixes)} fixes)",
                                            key=batch_pr_button_key,
                                            type="primary",
                                            width='stretch',
                                            disabled=pr_in_progress
                                        ):
                                            # Prevent duplicate requests
                                            if not pr_in_progress:
                                                # Store batch PR creation request
                                                st.session_state[batch_pr_request_key] = {
                                                    'successful_fixes': successful_fixes,
                                                    'repo_info': repo_info,
                                                    'repo_owner': repo_owner,
                                                    'repo_name': repo_name,
                                                    'base_branch': base_branch
                                                }
                                                st.rerun()
                                else:
                                    st.warning("⚠️ Repository owner information is missing. Cannot create PRs.")
                            else:
                                st.warning("⚠️ Repository information not found. Cannot create PRs.")
                        
                        # Process batch PR creation using batch API
                        batch_pr_request_key = f'batch_pr_request_{selected_repo_id}'
                        batch_pr_result_key = f'batch_pr_result_{selected_repo_id}'
                        
                        if batch_pr_request_key in st.session_state:
                            batch_pr_req = st.session_state[batch_pr_request_key]
                            successful_fixes = batch_pr_req['successful_fixes']
                            repo_owner = batch_pr_req['repo_owner']
                            repo_name = batch_pr_req['repo_name']
                            base_branch = batch_pr_req['base_branch']
                            api_url_val = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
                            github_token = st.session_state.get('github_token', '')
                            
                            # Get repo path from first successful fix
                            repo_path = ''
                            if successful_fixes and successful_fixes[0].get('result'):
                                fix_result = successful_fixes[0].get('result')
                                if isinstance(fix_result, dict):
                                    result_data = fix_result.get('result', {})
                                    if not result_data:
                                        result_data = fix_result
                                    repo_path = result_data.get('repo_path', '') or fix_result.get('repo_path', '')
                            
                            # Fallback: infer repo path
                            if not repo_path:
                                try:
                                    frontend_dir = os.path.dirname(os.path.abspath(__file__))
                                    project_root = os.path.dirname(frontend_dir)
                                    backend_dir_local = os.path.join(project_root, "backend")
                                    if repo_name:
                                        inferred_path = os.path.join(backend_dir_local, "temp_cloned_repos", repo_name)
                                        repo_path = inferred_path
                                except Exception:
                                    pass
                            
                            # Create progress container
                            pr_progress_container = st.container()
                            pr_status_container = st.container()
                            
                            with pr_progress_container:
                                pr_progress_bar = st.progress(0)
                                pr_status_text = st.empty()
                            
                            # Process batch PR creation using batch API
                            with pr_status_container:
                                if batch_pr_result_key not in st.session_state:
                                    # Call batch PR creation API
                                    pr_status_text.text("📝 Creating Pull Requests for all fixes... This may take a while.")
                                    pr_progress_bar.progress(0.5)
                                    
                                    pr_results = batch_create_prs(
                                                api_url=api_url_val,
                                        successful_fixes=successful_fixes,
                                                repo_owner=repo_owner,
                                                repo_name=repo_name,
                                                repo_path=repo_path,
                                                token=github_token,
                                                base_branch=base_branch
                                            )
                                            
                                    # Store results
                                    st.session_state[batch_pr_result_key] = pr_results
                                    # Delete request to prevent reprocessing
                                    if batch_pr_request_key in st.session_state:
                                        del st.session_state[batch_pr_request_key]
                                    
                                    pr_progress_bar.progress(1.0)
                                    pr_status_text.text(f"✅ Completed: {pr_results['successful']} PRs created, {pr_results['failed']} failed")
                        
                        # Display batch PR creation summary
                        if batch_pr_result_key in st.session_state:
                            pr_results = st.session_state[batch_pr_result_key]
                            st.markdown("---")
                            st.markdown("### 📊 Batch PR Creation Summary")
                            
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                st.metric("Total", pr_results['total'])
                            with col2:
                                st.metric("✅ Successful", pr_results['successful'], delta=None)
                            with col3:
                                st.metric("❌ Failed", pr_results['failed'], delta=None)
                            
                            # Show detailed PR results
                            if pr_results['results']:
                                st.markdown("#### PR Creation Results")
                                for pr_res in pr_results['results']:
                                    status_icon = "✅" if pr_res['status'] == 'success' else "❌"
                                    with st.expander(f"{status_icon} Vulnerability #{pr_res['vuln_idx']} - PR Creation", expanded=False):
                                        if pr_res['status'] == 'success':
                                            pr_result = pr_res['pr_result']
                                            st.success(f"✅ Pull Request created successfully for vulnerability #{pr_res['vuln_idx']}")
                                            st.markdown(f"**PR #{pr_result.get('pr_number')}:** [{pr_result.get('pr_url')}]({pr_result.get('pr_url')})")
                                        else:
                                            st.error(f"❌ Failed to create PR for vulnerability #{pr_res['vuln_idx']}")
                                            st.error(f"Error: {pr_res['error']}")
                            
                            # Add button to clear results if needed
                            if st.button("🔄 Clear PR Results", key=f"clear_pr_results_{selected_repo_id}"):
                                del st.session_state[batch_pr_result_key]
                                st.rerun()
                        
                        # Show detailed results with better UI
                        if batch_results.get('results'):
                            st.markdown("---")
                            st.markdown("#### 📋 Detailed Fix Results")
                            
                            # Group results by status
                            successful_results = [r for r in batch_results['results'] if r.get('status') == 'success']
                            failed_results = [r for r in batch_results['results'] if r.get('status') == 'failed']
                            
                            if successful_results:
                                st.success(f"✅ **{len(successful_results)} vulnerabilities fixed successfully**")
                                for res in successful_results:
                                    status_icon = "✅"
                                    vuln_idx = res.get('vuln_idx', 'Unknown')
                                    vuln_type = res.get('vulnerability_type', 'Unknown Vulnerability')
                                    file_path = res.get('file_path', 'N/A')
                                    
                                    with st.expander(f"{status_icon} Vulnerability #{vuln_idx}: {vuln_type} - {file_path}", expanded=False):
                                        st.success(f"✅ Successfully fixed vulnerability #{vuln_idx}")
                                        
                                        # Show fix result if available
                                        fix_result = res.get('result')
                                        if fix_result and isinstance(fix_result, dict):
                                            # Quick preview of key info
                                            inner_result = fix_result.get('result', {}) if isinstance(fix_result.get('result'), dict) else fix_result
                                            
                                            # Show quick metrics
                                            col1, col2 = st.columns(2)
                                            with col1:
                                                if inner_result.get('code_fix'):
                                                    cf = inner_result['code_fix']
                                                    files_count = len(cf.get('files_modified', []))
                                                    st.metric("Files Modified", files_count)
                                            with col2:
                                                if inner_result.get('code_fix'):
                                                    cf = inner_result['code_fix']
                                                    lines_count = len(cf.get('changed_lines', []))
                                                    st.metric("Lines Changed", lines_count)
                                        else:
                                            st.warning("⚠️ Fix result data not available for detailed display.")
                                        
                                        # Link to view full results in individual section
                                        st.markdown(
                                            f"📍 **Alternative:** Scroll down to vulnerability #{vuln_idx} "
                                            f"in the individual vulnerability section below."
                                        )
                            
                            if failed_results:
                                st.error(f"❌ **{len(failed_results)} vulnerabilities failed to fix**")
                                for res in failed_results:
                                    status_icon = "❌"
                                    vuln_idx = res.get('vuln_idx', 'Unknown')
                                    vuln_type = res.get('vulnerability_type', 'Unknown Vulnerability')
                                    file_path = res.get('file_path', 'N/A')
                                    
                                    with st.expander(f"{status_icon} Vulnerability #{vuln_idx}: {vuln_type} - {file_path}", expanded=True):
                                        st.error(f"❌ Failed to fix vulnerability #{vuln_idx}")
                                        error_msg = res.get('error', 'Unknown error')
                                        st.error(f"**Error:** {error_msg}")
                                        
                                        # Show fix result if available (might have partial results)
                                        fix_result = res.get('result')
                                        if fix_result:
                                            st.warning("⚠️ Partial results may be available. Check the individual vulnerability section below.")
                            else:
                                st.info("ℹ️ No failed fixes. All vulnerabilities were processed successfully!")
                
                # Add summary of vulnerabilities with fix results
                batch_result_key_summary = f'batch_fix_result_{selected_repo_id}'
                if batch_result_key_summary in st.session_state:
                    batch_results_summary = st.session_state[batch_result_key_summary]
                    results_list_summary = batch_results_summary.get('results', [])
                    
                    if results_list_summary:
                        st.markdown("---")
                        st.markdown("### 📊 Fix Results Summary")
                        st.info(f"💡 **{len(results_list_summary)} vulnerabilities have fix results available.** Expand the individual vulnerability sections below to view complete agent analysis (Agent 1-6) for each fix.")
                        
                        # Quick summary table
                        summary_rows = []
                        for res in results_list_summary:
                            vuln_idx = res.get('vuln_idx', 'N/A')
                            status = res.get('status', 'unknown')
                            status_icon = "✅" if status == 'success' else "❌" if status == 'failed' else "⚠️"
                            summary_rows.append({
                                "#": vuln_idx,
                                "Status": f"{status_icon} {status}",
                                "Type": res.get('vulnerability_type', 'Unknown'),
                                "File": res.get('file_path', 'N/A')[:50] + "..." if len(res.get('file_path', '')) > 50 else res.get('file_path', 'N/A')
                            })
                        
                        if summary_rows:
                            try:
                                summary_df = pd.DataFrame(summary_rows)
                                st.dataframe(
                                    summary_df,
                                    width='stretch',
                                    hide_index=True,
                                    height=min(300, 40 + 25 * len(summary_rows))
                                )
                            except Exception:
                                # Fallback display
                                for row in summary_rows:
                                    st.markdown(f"- **#{row['#']}**: {row['Status']} - {row['Type']} - `{row['File']}`")
                
                # Show full details in expander
                for idx, vuln in enumerate(mapped_vulns[selected_repo_id]['vulnerabilities'], 1):
                    file_found = vuln.get('file_found', False)
                    matched_file_path = vuln.get('matched_file_path')
                    file_name = vuln.get('file_name', 'N/A')
                    
                    # Check if fix results are available for this vulnerability
                    fix_result_key_check = f'fix_result_{selected_repo_id}_{idx}'
                    has_fix_results = fix_result_key_check in st.session_state
                    
                    # Also check batch results
                    if not has_fix_results:
                        batch_result_key_check = f'batch_fix_result_{selected_repo_id}'
                        if batch_result_key_check in st.session_state:
                            batch_results_check = st.session_state[batch_result_key_check]
                            batch_results_list = batch_results_check.get('results', [])
                            for batch_res in batch_results_list:
                                batch_vuln_idx = batch_res.get('vuln_idx')
                                batch_file = batch_res.get('file_path', '')
                                batch_type = batch_res.get('vulnerability_type', '')
                                
                                # Match by index, file path, or vulnerability type
                                if (batch_vuln_idx == idx) or \
                                   (matched_file_path and batch_file and matched_file_path in batch_file) or \
                                   (vuln.get('vulnerability') and batch_type and vuln.get('vulnerability') in batch_type):
                                    has_fix_results = True
                                    break
                    
                    # Add fix status indicator to expander title
                    fix_status_indicator = " ✅ **Fix Results Available**" if has_fix_results else ""
                    
                    file_status_badge = "✅ **File Found in Repository**" if file_found else "❌ **File Not Found in Repository**"
                    file_status_color = "#4caf50" if file_found else "#f44336"
                    
                    with st.expander(f"🔍 View Full Details - Vulnerability #{idx}: {vuln.get('vulnerability', 'N/A')}{fix_status_indicator}", expanded=has_fix_results):
                        # File status indicator
                        st.markdown(f'<div style="padding: 0.75rem; background: {"rgba(76, 175, 80, 0.15)" if file_found else "rgba(244, 67, 54, 0.15)"}; border-left: 4px solid {file_status_color}; border-radius: 6px; margin-bottom: 1rem;">{file_status_badge}</div>', unsafe_allow_html=True)
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.markdown(f"**📄 File (Report):** `{file_name}`")
                            if file_found and matched_file_path:
                                st.markdown(f"**✅ File (Found in Repo):** `{matched_file_path}`")
                            st.markdown(f"**📍 Line:** `{vuln.get('line_no', 'N/A')}`")
                            st.markdown(f"**⚠️ Type:** `{vuln.get('vulnerability', 'N/A')}`")
                        with col2:
                            if vuln.get('link') and vuln.get('link') != 'N/A':
                                st.markdown(f"**🔗 Link:** [{vuln.get('link')}]({vuln.get('link')})")
                            if vuln.get('matched_by_file'):
                                st.markdown("**🔗 Matched by:** File name")
                            else:
                                st.markdown("**🔗 Matched by:** Repository name/URL")
                        st.markdown(f"**📋 Description:** {vuln.get('description', 'N/A')}")
                        st.markdown(f"**💡 Recommendation:** {vuln.get('recommendation', 'N/A')}")
                        
                        if not file_found:
                            st.warning(f"⚠️ The file `{file_name}` was not found in this repository. Please verify the file path in your security report matches the actual file structure in the repository.")
                        elif matched_file_path and matched_file_path != file_name:
                            st.info(f"ℹ️ File matched: Report shows `{file_name}`, but found as `{matched_file_path}` in the repository.")
                        
                        # Dependency Lineage Preview (if available from previous analysis)
                        st.markdown("---")
                        st.markdown("### 📊 File Impact Preview")
                        
                        # Check if we have dependency analysis results for this vulnerability
                        dep_analysis_key = f'dep_analysis_{selected_repo_id}_{idx}'
                        if dep_analysis_key in st.session_state:
                            dep_data = st.session_state[dep_analysis_key]
                            st.info("💡 Dependency analysis available. The lineage graph will show full details after fixing.")
                            # Could show a preview here if needed
                        
                        # Show a preview message
                        st.info(f"💡 **After fixing**, you'll see a complete lineage graph showing:\n"
                               f"- 🎯 The vulnerable file: `{matched_file_path if matched_file_path else file_name}`\n"
                               f"- 🔧 Files that will be modified (primary and secondary)\n"
                               f"- 🔗 Files that depend on the vulnerable code\n"
                               f"- 📊 Visual connections showing relationships")
                        
                        # Fix Vulnerability Section
                        st.markdown("---")
                        st.markdown("### 🤖 Auto-Fix Vulnerability")
                        
                        if file_found and matched_file_path:
                            fix_button_key = f"fix_vuln_{selected_repo_id}_{idx}"
                            if st.button(f"🔧 Auto-Fix Vulnerability #{idx}", key=fix_button_key, type="primary"):
                                # Store fix request
                                st.session_state[f'fix_request_{selected_repo_id}_{idx}'] = {
                                    'vuln': vuln,
                                    'matched_file_path': matched_file_path,
                                    'selected_repo': selected_repo
                                }
                        
                        # Process and display fix results
                        fix_result_key = f'fix_result_{selected_repo_id}_{idx}'
                        fix_request_key = f'fix_request_{selected_repo_id}_{idx}'
                        
                        if fix_request_key in st.session_state:
                            # Process fix request
                            with st.spinner("🤖 Running multi-agent fix orchestration (Agent 1→6)... This may take a few minutes."):
                                fix_req = st.session_state[fix_request_key]
                                vuln_data = fix_req['vuln']
                                selected_repo = fix_req['selected_repo']
                                api_url_val = st.session_state.get('api_url', DEFAULT_API_BASE_URL)
                                
                                # Get clone URL from repository info
                                clone_url = selected_repo.get('clone_url') or selected_repo.get('html_url', '')
                                repo_name = selected_repo.get('name', 'unknown')
                                github_token = st.session_state.get('github_token')
                                
                                result, error = orchestrate_fix(
                                    api_url=api_url_val,
                                    vulnerability_type=vuln_data.get('vulnerability', 'Unknown'),
                                    description=vuln_data.get('description', ''),
                                    severity=vuln_data.get('severity', 'high').lower() if vuln_data.get('severity') else 'high',
                                    file_path=fix_req['matched_file_path'],
                                    line_number=int(vuln_data.get('line_no', 0)) if str(vuln_data.get('line_no', '0')).isdigit() else 0,
                                    repo_path=None,  # Let backend clone the repo
                                    repo_name=repo_name,
                                    clone_url=clone_url,  # Pass clone URL for backend to clone
                                    token=github_token,  # Pass token for private repos
                                    recommendation=vuln_data.get('recommendation')
                                )
                                
                                if error:
                                    st.session_state[fix_result_key] = {'error': error, 'success': False}
                                else:
                                    # Add repo info to result for PR creation
                                    if result and isinstance(result, dict):
                                        result['repo_name'] = repo_name
                                        result['repo_path'] = result.get('result', {}).get('repo_path', '')
                                        result['vulnerability_type'] = vuln_data.get('vulnerability', 'Unknown')
                                        result['description'] = vuln_data.get('description', '')
                                    st.session_state[fix_result_key] = result
                                del st.session_state[fix_request_key]
                        
                        # Display fix results if available
                        # Try multiple keys to find results (batch fixes might use different indexing)
                        fix_result_data = None
                        possible_keys = [
                            f'fix_result_{selected_repo_id}_{idx}',  # Standard key
                            f'fix_result_{selected_repo_id}_{idx - 1}',  # 0-based index
                            f'fix_result_{selected_repo_id}_{idx + 1}',  # 1-off
                        ]
                        
                        # Also try to find by matching vulnerability details
                        for key in possible_keys:
                            if key in st.session_state:
                                fix_result_data = st.session_state[key]
                                break
                        
                        # If still not found, search all fix_result keys for this repo
                        if not fix_result_data:
                            for session_key in st.session_state.keys():
                                if session_key.startswith(f'fix_result_{selected_repo_id}_'):
                                    # Check if this result matches the current vulnerability
                                    candidate_result = st.session_state[session_key]
                                    if isinstance(candidate_result, dict):
                                        # Try to match by file path or vulnerability type
                                        result_file = candidate_result.get('file_path') or candidate_result.get('result', {}).get('code_context', {}).get('vulnerable_file', '')
                                        result_vuln_type = candidate_result.get('vulnerability_type') or vuln.get('vulnerability', '')
                                        
                                        # Match if file path or vulnerability type matches
                                        if (matched_file_path and result_file and matched_file_path in result_file) or \
                                           (vuln.get('vulnerability') and result_vuln_type and vuln.get('vulnerability') in result_vuln_type):
                                            fix_result_data = candidate_result
                                            break
                        
                        # Also check batch results for this specific vulnerability
                        if not fix_result_data:
                            batch_result_key = f'batch_fix_result_{selected_repo_id}'
                            if batch_result_key in st.session_state:
                                batch_results = st.session_state[batch_result_key]
                                batch_results_list = batch_results.get('results', [])
                                
                                # Try to find this vulnerability in batch results
                                for batch_res in batch_results_list:
                                    batch_vuln_idx = batch_res.get('vuln_idx')
                                    batch_file = batch_res.get('file_path', '')
                                    batch_type = batch_res.get('vulnerability_type', '')
                                    
                                    # Match by index, file path, or vulnerability type
                                    if (batch_vuln_idx == idx) or \
                                       (matched_file_path and batch_file and matched_file_path in batch_file) or \
                                       (vuln.get('vulnerability') and batch_type and vuln.get('vulnerability') in batch_type):
                                        batch_fix_result = batch_res.get('result')
                                        if batch_fix_result:
                                            fix_result_data = batch_fix_result
                                            # Also store it for future reference
                                            fix_result_key = f'fix_result_{selected_repo_id}_{idx}'
                                            st.session_state[fix_result_key] = batch_fix_result
                                        break
                        
                        if fix_result_data:
                            # Check if result exists and is valid
                            if fix_result_data:
                                st.markdown("---")
                                # Prominent header with success indicator
                                st.markdown(
                                    f'<div style="padding: 1rem; background: rgba(76, 175, 80, 0.2); border-left: 5px solid #4caf50; border-radius: 8px; margin: 1rem 0;">'
                                    f'<h3 style="margin: 0; color: #4caf50;">✅ Fix Results Available for Vulnerability #{idx}</h3>'
                                    f'<p style="margin: 0.5rem 0 0 0; color: #666;">Complete agent analysis with code fixes, explanations, and PR options</p>'
                                    f'</div>',
                                    unsafe_allow_html=True
                                )
                                render_individual_fix_details(fix_result_data)
                            else:
                                st.warning("⚠️ Fix results are being processed. Please wait...")
                        else:
                            # Check if this vulnerability was part of a batch fix
                            batch_result_key = f'batch_fix_result_{selected_repo_id}'
                            if batch_result_key in st.session_state:
                                batch_results = st.session_state[batch_result_key]
                                batch_results_list = batch_results.get('results', [])
                                
                                # Try to find this vulnerability in batch results
                                found_in_batch = False
                                for batch_res in batch_results_list:
                                    batch_vuln_idx = batch_res.get('vuln_idx')
                                    batch_file = batch_res.get('file_path', '')
                                    batch_type = batch_res.get('vulnerability_type', '')
                                    
                                    # Match by index, file path, or vulnerability type
                                    if (batch_vuln_idx == idx) or \
                                       (matched_file_path and batch_file and matched_file_path in batch_file) or \
                                       (vuln.get('vulnerability') and batch_type and vuln.get('vulnerability') in batch_type):
                                        found_in_batch = True
                                        
                                        # Get the fix result from batch
                                        batch_fix_result = batch_res.get('result')
                                        if batch_fix_result:
                                            st.markdown("---")
                                            st.markdown("### 🤖 Fix Results (from Batch Fix)")
                                            render_individual_fix_details(batch_fix_result)
                                        else:
                                            st.info(f"✅ This vulnerability was fixed in batch (Status: {batch_res.get('status', 'unknown')})")
                                        break
                                
                                if not found_in_batch:
                                    st.info("💡 Click the '🔧 Auto-Fix Vulnerability' button above to start the multi-agent fix orchestration.")
                            else:
                                # Show a helpful message if no fix has been attempted yet
                                st.info("💡 Click the '🔧 Auto-Fix Vulnerability' button above to start the multi-agent fix orchestration.")
                        
                        # Dependency Analysis Section
                        st.markdown("---")
                        st.markdown("### 🔗 Dependency Analysis")
                        
                        if file_found and matched_file_path:
                            if st.button(f"🔍 Analyze Dependencies for Vulnerability #{idx}", key=f"analyze_dep_{selected_repo_id}_{idx}"):
                                with st.spinner("Analyzing dependencies... This may take a few moments."):
                                    try:
                                        # Get repository data
                                        repo_data = mapped_vulns[selected_repo_id]['repo']
                                        repo_id = repo_data.get('id')
                                        
                                        # Prepare repositories JSON
                                        repos_list = st.session_state.get('repositories_data', {}).get('repositories', [])
                                        repos_json = json.dumps({"repositories": repos_list})
                                        
                                        # Call dependency analysis API
                                        api_url = st.session_state.get('api_url', 'http://localhost:8000')
                                        response = requests.post(
                                            f"{api_url}/api/dependencies/analyze",
                                            data={
                                                'repo_id': repo_id,
                                                'vulnerable_file': matched_file_path,
                                                'vulnerable_line': int(vuln.get('line_no', 0)) if str(vuln.get('line_no', '0')).isdigit() else 0,
                                                'repositories_json': repos_json,
                                                'token': st.session_state.get('github_token', '')
                                            },
                                            timeout=600  # Increased timeout to 10 minutes for complex analysis
                                        )
                                        
                                        if response.status_code == 200:
                                            dep_data = response.json()
                                            dep_map = dep_data.get('dependency_map', {})
                                            
                                            # Get enhanced dependency information
                                            dependents = dep_map.get('dependents', [])
                                            dependency_summary = dep_map.get('dependency_summary', {})
                                            dependency_paths = dep_map.get('dependency_paths', [])
                                            dependency_tree = dep_map.get('dependency_tree', {})
                                            inter_repo_deps = dep_map.get('inter_repo_deps', [])
                                            cross_repo_dependents = dep_map.get('cross_repo_dependents', []) or []
                                            dependency_chains = dep_map.get('dependency_chains', []) or []
                                            intra_repo_dependents = dep_map.get('intra_repo_dependents', [])
                                            inter_repo_dependents = dep_map.get('inter_repo_dependents', [])
                                            
                                            # Debug: Show what we received (can be removed later)
                                            # st.write(f"Debug - cross_repo_dependents count: {len(cross_repo_dependents)}")
                                            # st.write(f"Debug - dependency_chains count: {len(dependency_chains)}")
                                            # st.write(f"Debug - dep_map keys: {list(dep_map.keys())}")
                                            
                                            if dependents or inter_repo_deps or cross_repo_dependents:
                                                # Summary Statistics
                                                st.success(f"✅ Dependency Analysis Complete!")
                                                
                                                # Display summary metrics
                                                col1, col2, col3, col4 = st.columns(4)
                                                with col1:
                                                    st.metric("Total Dependents", dependency_summary.get('total_dependents', len(dependents)))
                                                with col2:
                                                    st.metric("Direct Dependents", dependency_summary.get('direct_dependents', len([d for d in dependents if d.get('depth', 0) == 1])))
                                                with col3:
                                                    st.metric("Transitive Dependents", dependency_summary.get('transitive_dependents', len([d for d in dependents if d.get('depth', 0) > 1])))
                                                with col4:
                                                    inter_repo_count = dependency_summary.get('inter_repo_count', len(inter_repo_dependents))
                                                    st.metric("🌐 Inter-Repo Files", inter_repo_count)
                                                
                                                # Add cross-repo metrics if available
                                                if cross_repo_dependents:
                                                    col5, col6, col7 = st.columns(3)
                                                    with col5:
                                                        st.metric("🌐 Cross-Repo Files", len(cross_repo_dependents))
                                                    with col6:
                                                        st.metric("🔗 Dependency Chains", len(dependency_chains))
                                                    with col7:
                                                        # Show total affected repositories
                                                        affected_repos = dependency_summary.get('total_affected_repos', len(set(dep.get('repo') for dep in cross_repo_dependents)))
                                                        st.metric("📦 Affected Repos", affected_repos)
                                                
                                                # Dependency type breakdown
                                                by_type = dependency_summary.get('by_type', {})
                                                if by_type:
                                                    st.markdown("#### 📊 Dependency Types Breakdown")
                                                    type_cols = st.columns(len(by_type))
                                                    for idx, (dep_type, count) in enumerate(by_type.items()):
                                                        with type_cols[idx]:
                                                            st.metric(dep_type.replace('_', ' ').title(), count)
                                                
                                                st.markdown("---")
                                                
                                                # Group dependents by depth
                                                direct_deps = [d for d in dependents if d.get('depth', 0) == 1]
                                                transitive_deps = [d for d in dependents if d.get('depth', 0) > 1]
                                                
                                                # Direct Dependents Section
                                                if direct_deps:
                                                    st.markdown("#### 📁 Direct Dependents (Depth 1)")
                                                    direct_dep_list = []
                                                    for dep in direct_deps:
                                                        direct_dep_list.append({
                                                            'File': dep.get('file', 'N/A'),
                                                            'Type': dep.get('type', dep.get('dependency_type', 'N/A')),
                                                            'Class/Interface': dep.get('class', 'N/A'),
                                                            'Depth': dep.get('depth', 1)
                                                        })
                                                    direct_df = pd.DataFrame(direct_dep_list)
                                                    st.dataframe(direct_df, width='stretch', hide_index=True)
                                                
                                                # Separate intra-repo and inter-repo transitive dependents
                                                intra_transitive = [d for d in transitive_deps if d.get('scope') == 'intra-repo']
                                                inter_transitive = [d for d in transitive_deps if d.get('scope') == 'inter-repo']
                                                
                                                # Intra-Repo Transitive Dependents Section
                                                if intra_transitive:
                                                    st.markdown("#### 🔗 Intra-Repository Transitive Dependents (Depth 2+)")
                                                    
                                                    # Group by depth
                                                    depth_groups = {}
                                                    for dep in intra_transitive:
                                                        depth = dep.get('depth', 2)
                                                        if depth not in depth_groups:
                                                            depth_groups[depth] = []
                                                        depth_groups[depth].append(dep)
                                                    
                                                    for depth in sorted(depth_groups.keys()):
                                                        st.markdown(f"**Depth {depth}:**")
                                                        trans_dep_list = []
                                                        for dep in depth_groups[depth]:
                                                            trans_dep_list.append({
                                                                'File': dep.get('file', 'N/A'),
                                                                'Type': dep.get('type', dep.get('dependency_type', 'N/A')),
                                                                'Class/Interface': dep.get('class', 'N/A'),
                                                                'Repository': dep.get('repo', 'Same Repo'),
                                                                'Path': ' → '.join(dep.get('path', [])) if dep.get('path') else 'N/A'
                                                            })
                                                        trans_df = pd.DataFrame(trans_dep_list)
                                                        st.dataframe(trans_df, width='stretch', hide_index=True)
                                                
                                                # Inter-Repo Transitive Dependents Section
                                                if inter_transitive:
                                                    st.markdown("#### 🌐 Inter-Repository Transitive Dependents (Depth 2+)")
                                                    
                                                    # Group by depth
                                                    inter_depth_groups = {}
                                                    for dep in inter_transitive:
                                                        depth = dep.get('depth', 2)
                                                        if depth not in inter_depth_groups:
                                                            inter_depth_groups[depth] = []
                                                        inter_depth_groups[depth].append(dep)
                                                    
                                                    for depth in sorted(inter_depth_groups.keys()):
                                                        st.markdown(f"**Depth {depth}:**")
                                                        inter_trans_dep_list = []
                                                        for dep in inter_depth_groups[depth]:
                                                            inter_trans_dep_list.append({
                                                                'Repository': dep.get('repo', 'N/A'),
                                                                'File': dep.get('file', 'N/A'),
                                                                'Type': dep.get('type', dep.get('dependency_type', 'N/A')),
                                                                'Class/Interface': dep.get('class', 'N/A'),
                                                                'Maven Artifact': dep.get('maven_artifact', 'N/A'),
                                                                'Path': ' → '.join(dep.get('path', [])) if dep.get('path') else 'N/A'
                                                            })
                                                        inter_trans_df = pd.DataFrame(inter_trans_dep_list)
                                                        st.dataframe(inter_trans_df, width='stretch', hide_index=True)
                                                
                                                # Dependency Paths Visualization
                                                if dependency_paths:
                                                    st.markdown("#### 🛤️ Dependency Paths")
                                                    st.markdown("Full paths showing how files depend on the vulnerable file:")
                                                    
                                                    # Show paths in expandable sections
                                                    for path_info in dependency_paths[:10]:  # Show first 10 paths
                                                        path = path_info.get('path', [])
                                                        if len(path) > 1:
                                                            path_str = ' → '.join([os.path.basename(p) for p in path])
                                                            with st.expander(f"Path {path_info.get('depth', 0)}: {path_str}", expanded=False):
                                                                st.code('\n'.join([f"{i+1}. {p}" for i, p in enumerate(path)]), language='text')
                                                    
                                                    if len(dependency_paths) > 10:
                                                        st.info(f"Showing first 10 of {len(dependency_paths)} dependency paths. Use the API to get all paths.")
                                                
                                                # Dependency Tree Visualization
                                                if dependency_tree:
                                                    st.markdown("#### 🌳 Dependency Tree Structure")
                                                    
                                                    def render_tree(node, level=0):
                                                        """Recursively render dependency tree"""
                                                        if not node or not isinstance(node, dict):
                                                            return ""
                                                        
                                                        file_name = os.path.basename(node.get('file', ''))
                                                        indent = "  " * level
                                                        tree_str = f"{indent}├─ {file_name}"
                                                        
                                                        dep_type = node.get('type', '')
                                                        if dep_type:
                                                            tree_str += f" [{dep_type}]"
                                                        
                                                        tree_str += "\n"
                                                        
                                                        dependents = node.get('dependents', [])
                                                        for i, dep in enumerate(dependents):
                                                            is_last = i == len(dependents) - 1
                                                            subtree = dep.get('subtree', {})
                                                            if subtree:
                                                                subtree_str = render_tree(subtree, level + 1)
                                                                tree_str += subtree_str
                                                        
                                                        return tree_str
                                                    
                                                    tree_visualization = render_tree(dependency_tree)
                                                    if tree_visualization:
                                                        st.code(tree_visualization, language='text')
                                                
                                                # Inter-Repository Dependents Section (from inter_repo_dependents field)
                                                if inter_repo_dependents:
                                                    st.markdown("---")
                                                    st.markdown("#### 🌐 Inter-Repository Dependent Files")
                                                    st.info("📋 Files in other repositories that depend on the vulnerable file")
                                                    
                                                    inter_repo_data_list = []
                                                    for dep in inter_repo_dependents:
                                                        imports_info = dep.get('imports', [])
                                                        imports_display = ', '.join(imports_info) if imports_info else 'N/A'
                                                        if len(imports_display) > 150:
                                                            imports_display = imports_display[:150] + '...'
                                                        
                                                        classes_used_info = dep.get('classes_used', [])
                                                        classes_display = ', '.join(classes_used_info) if classes_used_info else 'N/A'
                                                        
                                                        inter_repo_data_list.append({
                                                            'Repository': dep.get('repo', 'N/A'),
                                                            'File': dep.get('file', 'N/A'),
                                                            'Type': dep.get('type', dep.get('dependency_type', 'N/A')),
                                                            'Vulnerable Package': dep.get('vulnerable_package', 'N/A'),
                                                            'Classes Used': classes_display,
                                                            'Matching Imports': imports_display,
                                                            'Maven Artifact': dep.get('maven_artifact', 'N/A'),
                                                            'Depth': dep.get('depth', 1)
                                                        })
                                                    inter_repo_df = pd.DataFrame(inter_repo_data_list)
                                                    st.dataframe(inter_repo_df, width='stretch', hide_index=True)
                                                
                                                # Cross-Repository Dependencies Section (legacy - from cross_repo_dependents field)
                                                # Always show this section if the field exists (even if empty)
                                                if 'cross_repo_dependents' in dep_map:
                                                    st.markdown("---")
                                                    st.markdown("#### 🌐 Cross-Repository Dependent Files (Legacy)")
                                                    
                                                    if cross_repo_dependents:
                                                        st.info("📋 Files in other repositories that depend on the vulnerable file via Maven dependencies")
                                                        
                                                        cross_repo_data_list = []
                                                        for dep in cross_repo_dependents:
                                                            imports_list = dep.get('imports', [])
                                                            imports_str = ', '.join(imports_list) if imports_list else 'N/A'
                                                            if len(imports_str) > 150:
                                                                imports_str = imports_str[:150] + '...'
                                                            
                                                            classes_used_list = dep.get('classes_used', [])
                                                            classes_str = ', '.join(classes_used_list) if classes_used_list else 'N/A'
                                                            
                                                            cross_repo_data_list.append({
                                                                'Repository': dep.get('repo', 'N/A'),
                                                                'File': dep.get('file', 'N/A'),
                                                                'Maven Artifact': dep.get('maven_artifact', 'N/A'),
                                                                'Vulnerable Package': dep.get('vulnerable_package', 'N/A'),
                                                                'Vulnerable Classes': ', '.join(dep.get('vulnerable_classes', [])) if dep.get('vulnerable_classes') else 'N/A',
                                                                'Classes Used': classes_str,
                                                                'Matching Imports': imports_str,
                                                                'Depth': dep.get('depth', 1)
                                                            })
                                                        cross_repo_df = pd.DataFrame(cross_repo_data_list)
                                                        st.dataframe(cross_repo_df, width='stretch', hide_index=True)
                                                    else:
                                                        # Show message if inter-repo message exists
                                                        inter_repo_msg = dep_map.get('inter_repo_message')
                                                        if inter_repo_msg:
                                                            st.info(f"ℹ️ {inter_repo_msg}")
                                                        else:
                                                            st.info("ℹ️ Cross-repository dependency analysis completed. No files in other repositories depend on this vulnerable file via Maven dependencies.")
                                                            st.markdown("**Note:** This means either:")
                                                            st.markdown("- No other repositories in your list depend on this repository's Maven artifact")
                                                            st.markdown("- The dependent repositories were not cloned successfully")
                                                            st.markdown("- The dependent repositories' pom.xml files don't declare this dependency")
                                                
                                                # Dependency Chains Section
                                                # Always show this section if the field exists (even if empty)
                                                if 'dependency_chains' in dep_map:
                                                    st.markdown("---")
                                                    st.markdown("#### 🔗 Cross-Repository Dependency Chains")
                                                    
                                                    if dependency_chains:
                                                        st.info("📊 Complete dependency chains showing how vulnerabilities propagate across repositories")
                                                        
                                                        # Group chains by depth
                                                        chains_by_depth = {}
                                                        for chain in dependency_chains:
                                                            depth = chain.get('depth', 1)
                                                            if depth not in chains_by_depth:
                                                                chains_by_depth[depth] = []
                                                            chains_by_depth[depth].append(chain)
                                                        
                                                        for depth in sorted(chains_by_depth.keys()):
                                                            st.markdown(f"**Depth {depth} Chains:**")
                                                            for chain in chains_by_depth[depth]:
                                                                chain_repos = chain.get('chain', [])
                                                                chain_str = ' → '.join(chain_repos) if chain_repos else 'N/A'
                                                                
                                                                with st.expander(f"🔗 {chain_str} ({len(chain.get('files', []))} files)", expanded=False):
                                                                    st.markdown(f"**From:** {chain.get('from_repo', 'N/A')} ({chain.get('from_artifact', 'N/A')})")
                                                                    st.markdown(f"**To:** {chain.get('to_repo', 'N/A')} ({chain.get('to_artifact', 'N/A')})")
                                                                    
                                                                    if chain.get('intermediate_repos'):
                                                                        st.markdown(f"**Intermediate Repositories:** {', '.join(chain['intermediate_repos'])}")
                                                                    
                                                                    files = chain.get('files', [])
                                                                    if files:
                                                                        st.markdown(f"**Affected Files ({len(files)}):**")
                                                                        # Show first 10 files
                                                                        for file_info in files[:10]:
                                                                            st.code(f"{file_info.get('repo', 'N/A')}:{file_info.get('file', 'N/A')}", language='text')
                                                                        if len(files) > 10:
                                                                            st.info(f"Showing first 10 of {len(files)} files")
                                                    else:
                                                        st.info("ℹ️ No dependency chains found. This means there are no transitive dependencies across repositories.")
                                                
                                                # Legacy Inter-repo dependencies (for backward compatibility)
                                                if inter_repo_deps:
                                                    st.markdown("---")
                                                    st.markdown("#### 📦 Inter-Repository Dependencies (Maven)")
                                                    inter_dep_data_list = []
                                                    for dep in inter_repo_deps:
                                                        inter_dep_data_list.append({
                                                            'Repository': dep.get('repo', 'N/A'),
                                                            'Maven Artifact': dep.get('maven_artifact', 'N/A'),
                                                            'Dependency Type': dep.get('dependency_type', 'N/A')
                                                        })
                                                    inter_dep_df = pd.DataFrame(inter_dep_data_list)
                                                    st.dataframe(inter_dep_df, width='stretch', hide_index=True)
                                                
                                                # All Dependents Table (Complete List)
                                                st.markdown("---")
                                                st.markdown("#### 📋 Complete Dependency List")
                                                all_dep_list = []
                                                for dep in dependents:
                                                    all_dep_list.append({
                                                        'File': dep.get('file', 'N/A'),
                                                        'Type': dep.get('type', dep.get('dependency_type', 'N/A')),
                                                        'Class/Interface': dep.get('class', 'N/A'),
                                                        'Depth': dep.get('depth', 0),
                                                        'Path': ' → '.join(dep.get('path', [])) if dep.get('path') else 'Direct'
                                                    })
                                                all_dep_df = pd.DataFrame(all_dep_list)
                                                st.dataframe(all_dep_df, width='stretch', hide_index=True, height=400)
                                            else:
                                                st.info("ℹ️ No dependencies found. This file doesn't appear to be used by other files.")
                                        else:
                                            error_data = response.json() if response.content else {"detail": "Unknown error"}
                                            st.error(f"❌ Error analyzing dependencies: {error_data.get('detail', response.text)}")
                                    except requests.exceptions.Timeout:
                                        st.error("❌ Request timed out. Dependency analysis is taking longer than expected. Please try again.")
                                    except requests.exceptions.ConnectionError:
                                        st.error(f"❌ Cannot connect to API. Make sure the FastAPI server is running on {api_url}")
                                    except requests.exceptions.RequestException as e:
                                        st.error(f"❌ Network error: {str(e)}")
                                    except Exception as e:
                                        st.error(f"❌ Error: {str(e)}")
                        else:
                            st.info("ℹ️ File must be found in repository to analyze dependencies.")
    else:
        st.info("ℹ️ Upload a security report CSV to see vulnerability details.")
    
    # Display unmatched vulnerabilities
    if unmatched_vulns:
        st.markdown("---")
        st.markdown('<div class="section-header">⚠️ Unmatched Vulnerabilities</div>', unsafe_allow_html=True)
        st.warning(f"⚠️ **{len(unmatched_vulns)}** vulnerabilities could not be matched to any repository. Please check the repository names/URLs in your CSV file.")
        
        unmatched_df = pd.DataFrame(unmatched_vulns)
        st.dataframe(
            unmatched_df, 
            width='stretch', 
            hide_index=True,
            height=300
        )
        
        st.info("💡 **Tip:** Make sure the `repo_name` or `link` column in your CSV matches the repository names or URLs from GitHub.")





if __name__ == "__main__":
    main()
