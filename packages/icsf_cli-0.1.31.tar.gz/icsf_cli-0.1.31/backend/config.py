import os
import yaml
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# Load environment variables from the backend/.env file explicitly.
# This makes Config work correctly even when the package is installed
# and used from another working directory (e.g., when running `icsf`
# from anywhere on the system).
_BACKEND_DIR = Path(__file__).resolve().parent
_ENV_PATH = _BACKEND_DIR / ".env"
load_dotenv(dotenv_path=_ENV_PATH, override=True)


def _load_bedrock_model_ids() -> tuple[str, str]:
    """
    Load Bedrock model IDs from credentials.yaml (aws section) if present,
    otherwise fall back to environment variables or hard-coded defaults.
    """
    default_model = "anthropic.claude-3-5-sonnet-20240620-v1:0"
    default_embed = "amazon.titan-embed-text-v1"

    cred_path = _BACKEND_DIR / "credentials.yaml"
    if cred_path.exists():
        try:
            raw = cred_path.read_text(encoding="utf-8")
            try:
                data = yaml.safe_load(raw) or {}
            except Exception:
                # Tolerate accidental dotenv lines appended to YAML.
                yaml_lines = []
                for line in raw.splitlines():
                    s = line.strip()
                    if not s or s.startswith("#"):
                        yaml_lines.append(line)
                        continue
                    if "=" in s and (":" not in s.split("=", 1)[0]):
                        continue
                    yaml_lines.append(line)
                data = yaml.safe_load("\n".join(yaml_lines)) or {}
            aws = data.get("aws") or {}
            model_id = (aws.get("bedrock_model_id") or "").strip()
            embed_id = (aws.get("bedrock_embed_model_id") or "").strip()
            if model_id or embed_id:
                return (
                    model_id or os.getenv("BEDROCK_MODEL_ID", default_model).strip() or default_model,
                    embed_id or os.getenv("BEDROCK_EMBED_MODEL_ID", default_embed).strip() or default_embed,
                )
        except Exception:
            pass

    return (
        os.getenv("BEDROCK_MODEL_ID", default_model).strip() or default_model,
        os.getenv("BEDROCK_EMBED_MODEL_ID", default_embed).strip() or default_embed,
    )


_BEDROCK_MODEL_ID, _BEDROCK_EMBED_MODEL_ID = _load_bedrock_model_ids()


class Config:
    # AWS Credentials
    AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID", "").strip() or None
    AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "").strip() or None
    AWS_REGION = os.getenv("AWS_REGION", "us-east-1").strip() or "us-east-1"
    AWS_SESSION_TOKEN = os.getenv("AWS_SESSION_TOKEN", "").strip() or None
    
    # Model IDs (prefer credentials.yaml -> env -> defaults)
    BEDROCK_MODEL_ID = _BEDROCK_MODEL_ID
    BEDROCK_EMBED_MODEL_ID = _BEDROCK_EMBED_MODEL_ID

    @staticmethod
    def get_github_credentials(force_reload=False):
        """
        Load GitHub credentials from credentials.yaml.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        # In a real scenario, force_reload might clear a cache, but here we just read the file.
        credentials_path = Path(__file__).parent / "credentials.yaml"
        
        if not credentials_path.exists():
            logger.warning(f"GitHub credentials file not found at: {credentials_path}")
            return {"token": None, "username": None, "email": None}
        
        try:
            with open(credentials_path, "r") as f:
                data = yaml.safe_load(f)
                github_data = data.get("github", {})
                token = github_data.get("token")
                logger.info(f"Successfully loaded GitHub credentials from {credentials_path}")
                if token:
                    logger.info(f"GitHub token loaded (ends with: ...{token[-4:] if len(token) > 4 else '***'})")
                else:
                    logger.warning("GitHub token is missing in credentials.yaml")
                
                return {
                    "token": token,
                    "username": github_data.get("username"),
                    "email": github_data.get("email")
                }
        except Exception as e:
            logger.error(f"Error loading GitHub credentials from {credentials_path}: {str(e)}")
            return {"token": None, "username": None, "email": None}

    @staticmethod
    def validate_bedrock_credentials():
        """
        Validate that AWS credentials are provided.
        Returns (is_valid, error_msg).
        """
        cfg = Config.get_bedrock_config()
        if not cfg.get("access_key") or not cfg.get("secret_key"):
            return False, "Missing AWS credentials. Set them in credentials.yaml (aws:) or .env."
        return True, ""

    @staticmethod
    def get_bedrock_config(credentials_path: Optional[Path] = None):
        """
        Return Bedrock configuration as a dictionary.
        Precedence: credentials.yaml (aws section) if present, else .env / environment.
        credentials_path: optional path to credentials file (used by CLI); if None, uses backend/credentials.yaml.
        """
        path = credentials_path or (_BACKEND_DIR / "credentials.yaml")
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f) or {}
                aws = data.get("aws") or {}
                ak = (aws.get("access_key_id") or "").strip()
                sk = (aws.get("secret_access_key") or "").strip()
                if ak and sk:
                    return {
                        "access_key": ak,
                        "secret_key": sk,
                        "region": (aws.get("region") or "us-east-1").strip() or "us-east-1",
                    }
            except Exception:
                pass
        return {
            "access_key": (os.getenv("AWS_ACCESS_KEY_ID", "") or "").strip() or None,
            "secret_key": (os.getenv("AWS_SECRET_ACCESS_KEY", "") or "").strip() or None,
            "region": (os.getenv("AWS_REGION", "us-east-1") or "us-east-1").strip() or "us-east-1",
        }
