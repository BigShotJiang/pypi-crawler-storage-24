"""
ICSF Command-Line Interface entrypoint.

This module exposes a small CLI wrapper around the core `cli_api` helpers.
Users install the package and then run:

    icsf run --credentials backend/credentials.yaml --csv report.csv --auto-pr --run-tests

to execute an end-to-end flow that mirrors the web application:
mapping → baseline testing → fixing → validation testing → PR creation.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import secrets
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import yaml
from dotenv import load_dotenv

from . import cli_api
from .html_report import render_run_report_html
from .cli_output import (
    Spinner,
    print_banner,
    print_build_status,
    print_error,
    print_final_summary,
    print_fix_result,
    print_fix_start,
    print_info,
    print_kv,
    print_ok,
    print_section,
    print_step,
    print_vuln_table,
    print_warn,
    c,
    _CYAN, _DIM, _GREEN, _RED, _YELLOW, _WHITE, _BOLD,
)


# ── Logging setup ────────────────────────────────────────────────────────────

class _CliLogFormatter(logging.Formatter):
    """
    Compact formatter for CLI output.

    - Strips the logger name prefix (too noisy for users)
    - Colours by level
    - Suppresses internal botocore / urllib3 / httpx chatter unless verbose
    """

    _LEVEL_STYLES = {
        logging.DEBUG:    ("\033[2m", "DEBUG"),
        logging.INFO:     ("\033[36m", " INFO"),
        logging.WARNING:  ("\033[33m", " WARN"),
        logging.ERROR:    ("\033[31m", "ERROR"),
        logging.CRITICAL: ("\033[35m", "CRIT "),
    }

    _RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:  # noqa: D102
        from .cli_output import _COLOR
        col, tag = self._LEVEL_STYLES.get(record.levelno, ("", " INFO"))
        msg = record.getMessage()
        if _COLOR:
            prefix = f"{col}[{tag}]{self._RESET}"
        else:
            prefix = f"[{tag}]"
        return f"  {prefix}  {msg}"


_NOISY_LOGGERS = [
    "botocore",
    "boto3",
    "urllib3",
    "httpx",
    "httpcore",
    "git",
    "charset_normalizer",
    "asyncio",
]


def _configure_logging(verbose: bool) -> None:
    """
    Configure logging for CLI use:
    - User-level messages (INFO+) shown with pretty formatter
    - Internal library noise suppressed unless --verbose
    """
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)

    # Remove any handlers already attached (e.g. by basicConfig elsewhere)
    root.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(_CliLogFormatter())
    handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    root.addHandler(handler)

    # Quiet down noisy library loggers
    suppress_level = logging.DEBUG if verbose else logging.WARNING
    for name in _NOISY_LOGGERS:
        logging.getLogger(name).setLevel(suppress_level)


# ── Argument parser ──────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="icsf",
        description="ICSF – Intelligent Code Security & Fixing Platform (CLI)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  icsf run --credentials creds.yaml --csv vulns.csv --auto-pr\n"
            "  icsf run --credentials creds.yaml --csv vulns.csv --no-run-tests\n"
            "  icsf run --credentials creds.yaml --csv vulns.csv --repo-filter myapp\n"
        ),
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── run command ──────────────────────────────────────────────────────────
    run_parser = subparsers.add_parser(
        "run",
        help="Run end-to-end mapping, fixing, testing, and PR creation.",
        description="Map vulnerability CSV → fix code → validate build → create PR",
    )
    run_parser.add_argument(
        "--credentials",
        type=str,
        default=None,
        help=(
            "Path to credentials YAML containing GitHub token/username/email. "
            "If omitted, backend/credentials.yaml is used."
        ),
    )
    run_parser.add_argument(
        "--env",
        type=str,
        default=None,
        help=(
            "Path to .env file for AWS (Bedrock) and other env vars. "
            "If omitted, .env in the same directory as --credentials is loaded when present."
        ),
    )
    run_parser.add_argument(
        "--clone-root",
        type=str,
        default=None,
        help=(
            "Base directory to store temporary cloned repositories. "
            "If omitted, the CLI chooses a per-user location automatically. "
            "On Windows, you can point this to a specific drive/folder."
        ),
    )
    run_parser.add_argument(
        "--csv",
        type=str,
        required=True,
        help="Path to vulnerability CSV report.",
    )
    run_parser.add_argument(
        "--auto-pr",
        action="store_true",
        help="Automatically create a single batch PR per repository.",
    )
    run_parser.add_argument(
        "--no-auto-pr",
        dest="auto_pr",
        action="store_false",
        help="Do not create PRs (default).",
    )
    run_parser.set_defaults(auto_pr=False)

    run_parser.add_argument(
        "--run-tests",
        action="store_true",
        help="Run baseline + validation testing via Atlas (default: on).",
    )
    run_parser.add_argument(
        "--no-run-tests",
        dest="run_tests",
        action="store_false",
        help="Skip all testing (baseline & validation).",
    )
    run_parser.set_defaults(run_tests=True)

    run_parser.add_argument(
        "--repo-filter",
        type=str,
        default=None,
        help=(
            "Only process repositories whose name or full_name contains this "
            "substring (case-insensitive)."
        ),
    )
    run_parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Optional path to write a full JSON report of the run.",
    )
    run_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging (shows internal debug messages).",
    )

    return parser


# ── Credential bootstrapping ──────────────────────────────────────────────────

def _load_aws_credentials(
    credentials_path: Optional[Path],
    env_path: Optional[Path] = None,
) -> None:
    """
    Load AWS credentials from credentials.yaml and/or .env into os.environ.

    This MUST be called before any BedrockService / atlas_service is used,
    because those objects read os.environ at construction time.

    Precedence (highest → lowest):
      1. credentials.yaml  aws: section
      2. explicit --env file
      3. .env in same directory as credentials.yaml
      4. existing os.environ (unchanged)
    """
    # Load .env first (lowest priority override)
    if env_path and env_path.exists():
        load_dotenv(dotenv_path=env_path, override=True)
    elif credentials_path and credentials_path.parent:
        default_env = credentials_path.parent / ".env"
        if default_env.exists():
            load_dotenv(dotenv_path=default_env, override=True)

    # Now load from credentials YAML aws: section (higher priority)
    if credentials_path and credentials_path.exists():
        try:
            raw = credentials_path.read_text(encoding="utf-8")
            # Tolerate mixed dotenv lines in YAML
            try:
                data = yaml.safe_load(raw) or {}
            except Exception:
                yaml_lines = []
                for line in raw.splitlines():
                    s = line.strip()
                    if not s or s.startswith("#"):
                        yaml_lines.append(line)
                        continue
                    if "=" in s and (":" not in s.split("=", 1)[0]):
                        continue
                    yaml_lines.append(line)
                data = yaml.safe_load("\n".join(yaml_lines)) or {}

            aws = data.get("aws") or {}
            if aws.get("access_key_id"):
                os.environ["AWS_ACCESS_KEY_ID"] = str(aws["access_key_id"]).strip()
            if aws.get("secret_access_key"):
                os.environ["AWS_SECRET_ACCESS_KEY"] = str(aws["secret_access_key"]).strip()
            if aws.get("region"):
                os.environ["AWS_REGION"] = str(aws["region"]).strip()
            if aws.get("session_token"):
                os.environ["AWS_SESSION_TOKEN"] = str(aws["session_token"]).strip()
            if aws.get("bedrock_model_id"):
                os.environ["BEDROCK_MODEL_ID"] = str(aws["bedrock_model_id"]).strip()
            if aws.get("bedrock_embed_model_id"):
                os.environ["BEDROCK_EMBED_MODEL_ID"] = str(aws["bedrock_embed_model_id"]).strip()
        except Exception:
            pass  # Fall through to env vars already set above


# ── Pre-flight checks ────────────────────────────────────────────────────────


def _run_preflight_checks(
    credentials_path: Path,
    csv_path: Path,
    env_path: Optional[Path],
    clone_root: Optional[Path],
    repo_filter: Optional[str],
) -> bool:
    """
    Run basic pre-flight checks before starting the heavy pipeline.

    Checks:
      - Inputs: credentials.yaml and CSV existence
      - AWS credentials presence
      - GitHub credentials presence
      - External tools: git, mvn, java
      - Clone root directory writability (if provided)
    """
    print_section("Pre-flight checks", "✅")

    all_ok = True

    # 1. Inputs
    if not credentials_path.exists():
        print_error(f"Credentials file not found: {credentials_path}")
        all_ok = False
    else:
        print_ok(f"Credentials file found: {credentials_path}")

    if not csv_path.exists():
        print_error(f"CSV file not found: {csv_path}")
        all_ok = False
    else:
        print_ok(f"CSV file found: {csv_path}")

    # 2. AWS / Bedrock credentials (presence only)
    _load_aws_credentials(credentials_path, env_path)
    from .config import Config as _Cfg

    bedrock_cfg = _Cfg.get_bedrock_config(credentials_path)
    ak = bedrock_cfg.get("access_key")
    sk = bedrock_cfg.get("secret_key")
    if ak and sk:
        print_ok("AWS credentials: present")
    else:
        print_warn(
            "AWS credentials: missing access_key_id / secret_access_key "
            "(Bedrock / testing will fail until configured)."
        )
        all_ok = False

    # 3. GitHub credentials
    try:
        token, username, email = cli_api.load_github_credentials_from_file(
            credentials_path
        )
        ident = username or email or "unknown"
        if token:
            print_ok(f"GitHub credentials: token loaded for {ident}")
        else:
            print_warn("GitHub credentials: token missing in credentials.yaml")
            all_ok = False
    except Exception as exc:
        print_error(f"GitHub credentials: failed to load ({exc})")
        all_ok = False

    # 4. External tools
    missing_tools = []
    for tool in ("git", "mvn", "java"):
        path = shutil.which(tool)
        if not path:
            missing_tools.append(tool)
        else:
            print_ok(f"Tool '{tool}' found at {path}")
    if missing_tools:
        print_error(
            "Missing required tools on PATH: " + ", ".join(missing_tools)
        )
        all_ok = False

    # 5. Clone root
    if clone_root is not None:
        try:
            clone_root.mkdir(parents=True, exist_ok=True)
            test_path = clone_root / ".icsf_write_test"
            with test_path.open("w", encoding="utf-8") as f:
                f.write("ok")
            test_path.unlink(missing_ok=True)  # type: ignore[arg-type]
            print_ok(f"Clone root writable: {clone_root}")
        except Exception as exc:
            print_error(f"Clone root not writable ({clone_root}): {exc}")
            all_ok = False
    else:
        print_info("Clone root: auto (per-user temp_cloned_repos location)")

    if repo_filter:
        print_info(f"Repo filter will be applied: {repo_filter}")

    print()
    return all_ok


# ── Command handler ──────────────────────────────────────────────────────────


def _handle_run(args: argparse.Namespace) -> int:
    _configure_logging(verbose=args.verbose)

    run_start = time.time()

    print_banner()

    # ── Resolve paths ────────────────────────────────────────────────────────
    credentials_path: Optional[Path]
    if args.credentials:
        credentials_path = Path(args.credentials).resolve()
    else:
        credentials_path = Path(__file__).resolve().parent / "credentials.yaml"

    env_path: Optional[Path] = None
    if getattr(args, "env", None):
        env_path = Path(args.env).resolve()
        if not env_path.exists():
            print_error(f"Env file not found: {env_path}")
            return 1

    csv_path = Path(args.csv).resolve()
    if not csv_path.exists():
        print_error(f"CSV file not found: {csv_path}")
        return 1

    # ── Configuration summary ────────────────────────────────────────────────
    print_section("Configuration", "⚙️")
    print_kv("Credentials file", str(credentials_path))
    print_kv("Vulnerability CSV", str(csv_path))
    if env_path:
        print_kv("Env override file", str(env_path))

    # Allow interactive toggles when running in a real terminal.
    # We separate baseline, fixes, and validation for more control.
    auto_pr = args.auto_pr
    want_baseline = args.run_tests
    want_fixes = True
    want_validation = args.run_tests

    if sys.stdin.isatty():
        def _prompt_bool(question: str, default: bool) -> bool:
            suffix = "[Y/n]" if default else "[y/N]"
            resp = input(f"{question} {suffix} ").strip().lower()
            if not resp:
                return default
            if resp in ("y", "yes"):
                return True
            if resp in ("n", "no"):
                return False
            return default

        auto_pr = _prompt_bool("Create PRs automatically after fixes?", auto_pr)
        want_baseline = _prompt_bool(
            "Run baseline testing (build + existing tests before fixes)?",
            want_baseline,
        )
        want_fixes = _prompt_bool(
            "Apply code fixes for mapped vulnerabilities?", want_fixes
        )
        want_validation = _prompt_bool(
            "Run validation testing after fixes (AI-powered tests)?",
            want_validation,
        )

    # If user disabled fixes but enabled validation, validation alone doesn't make sense.
    if not want_fixes and want_validation:
        print_warn(
            "Validation testing requires fixes. Validation will be skipped because fixes are disabled."
        )
        want_validation = False

    print_kv("Auto-PR creation", "Yes ✔" if auto_pr else "No")
    print_kv("Baseline testing", "Yes ✔" if want_baseline else "No")
    print_kv("Code fixes", "Yes ✔" if want_fixes else "No")
    print_kv("Validation testing", "Yes ✔" if want_validation else "No")
    if args.repo_filter:
        print_kv("Repo filter", args.repo_filter)
    if args.verbose:
        print_kv("Verbose logging", "On")
    print()

    # Optional clone root selection. On Windows in interactive mode, let the user
    # choose which drive/folder to use for temp_cloned_repos, unless --clone-root
    # was provided explicitly.
    clone_root: Optional[Path] = None
    if getattr(args, "clone_root", None):
        clone_root = Path(args.clone_root).resolve()
    elif os.name == "nt" and sys.stdin.isatty():
        import string

        drives = []
        for letter in string.ascii_uppercase:
            root = f"{letter}:\\"
            if os.path.isdir(root) and os.access(root, os.W_OK):
                drives.append(letter)
        if drives:
            print_step(
                "Select drive for ICSF temp_cloned_repos "
                f"(default: {drives[0]}:)"
            )
            choice = input(
                f"Available drives: {', '.join(drives)}. Enter drive letter: "
            ).strip().upper()
            if not choice:
                choice = drives[0]
            if choice in drives:
                clone_root = (
                    Path(f"{choice}:\\") / "icsf-cli" / "temp_cloned_repos"
                )

    # ── Pre-flight checks ────────────────────────────────────────────────────
    preflight_ok = _run_preflight_checks(
        credentials_path=credentials_path,
        csv_path=csv_path,
        env_path=env_path,
        clone_root=clone_root,
        repo_filter=args.repo_filter,
    )
    if not preflight_ok:
        if sys.stdin.isatty():
            resp = input(
                "One or more pre-flight checks failed. Continue anyway? [y/N] "
            ).strip().lower()
            if resp not in ("y", "yes"):
                print_error("Aborting due to failed pre-flight checks.")
                return 1
        else:
            print_error("Pre-flight checks failed. Aborting.")
            return 1

    # Unique run ID for this invocation (per-run clones and report filenames)
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(4)

    # ── Async runner ─────────────────────────────────────────────────────────
    async def _run() -> int:
        # ── STEP 0: Load AWS credentials into env BEFORE any service init ────
        # This must happen first because atlas_service / BedrockService are
        # singletons that read env vars at construction time.
        _load_aws_credentials(credentials_path, env_path)

        print_info(f"Run ID:  {c(run_id, _CYAN, _BOLD)}")
        print()

        # Phase 1: Credentials + GitHub auth
        print_section("Phase 1 — GitHub Authentication", "🔑")
        try:
            with Spinner("Verifying GitHub token…"):
                token, username, email = cli_api.load_github_credentials_from_file(
                    credentials_path
                )
            print_ok(f"Authenticated as  {c(username or email or 'unknown', _CYAN, _BOLD)}")
        except Exception as exc:
            print_error(f"GitHub authentication failed: {exc}")
            return 1

        # Phase 2: Fetch repositories
        print_section("Phase 2 — Repository Discovery", "🔍")
        try:
            with Spinner("Fetching repositories from GitHub…"):
                repos = await cli_api.fetch_repositories_for_cli(token, username, email)
            print_ok(f"Found {c(str(len(repos)), _WHITE, _BOLD)} repositories")
        except Exception as exc:
            print_error(f"Repository fetch failed: {exc}")
            return 1

        # Phase 3: Map vulnerabilities from CSV
        print_section("Phase 3 — Vulnerability Mapping", "🗺️")
        try:
            with Spinner(f"Mapping vulnerabilities from  {csv_path.name}…"):
                mapping = cli_api.map_vulnerabilities_from_csv_for_cli(csv_path, repos)
        except Exception as exc:
            print_error(f"CSV mapping failed: {exc}")
            return 1

        total_mapped   = mapping.get("total_mapped", 0)
        total_unmapped = mapping.get("total_unmatched", 0)
        print_ok(f"Mapped {c(str(total_mapped), _WHITE, _BOLD)} repositories with vulnerability hits")
        if total_unmapped:
            print_warn(f"{total_unmapped} vulnerabilities could not be matched to a repository file")

        if total_mapped == 0:
            print_warn("No actionable vulnerabilities found — nothing to fix.")
            return 0

        # Phase 4: Per-repo pipeline
        mapped = mapping.get("mapped_vulnerabilities", {})

        repo_id_to_repo = {int(r["id"]): r for r in repos if "id" in r}

        def _repo_matches(repo_dict):
            if not args.repo_filter:
                return True
            name = (repo_dict.get("name") or "").lower()
            full = (repo_dict.get("full_name") or "").lower()
            return args.repo_filter.lower() in name or args.repo_filter.lower() in full

        end_to_end_results = []
        total_fixable_repos = 0

        for repo_id_str, payload in mapped.items():
            try:
                repo_id = int(repo_id_str)
            except ValueError:
                continue

            repo = repo_id_to_repo.get(repo_id) or payload.get("repo")
            if not repo or not _repo_matches(repo):
                continue

            vulnerabilities = payload.get("vulnerabilities", [])
            if not vulnerabilities:
                continue

            total_fixable_repos += 1
            full_name = repo.get("full_name") or repo.get("name") or "unknown"

            print_section(f"Repo: {full_name}", "📦")

            # Show vulnerability table
            print_vuln_table(vulnerabilities, full_name)

            # Clone / update repo
            print_step("Cloning repository", "📥")
            try:
                backend_root = Path(__file__).resolve().parent
                with Spinner(f"Cloning {full_name}…"):
                    repo_path = cli_api._ensure_repo_cloned_for_cli(
                        repo, token, backend_root, clone_root=clone_root, run_id=run_id
                    )
                print_ok(f"Repository ready at  {c(str(repo_path), _DIM)}")
            except Exception as exc:
                print_error(f"Clone failed: {exc}")
                continue

            # Prepare vulnerability lists
            fixable = [v for v in vulnerabilities if v.get("file_found") and v.get("matched_file_path")]
            skippable = [v for v in vulnerabilities if not (v.get("file_found") and v.get("matched_file_path"))]
            if skippable:
                print_warn(f"{len(skippable)} vulnerabilities skipped (file not found in repo)")

            # Import services only when needed
            from .services.bedrock_service import BedrockService
            from .services.batch_fix_service import BatchFixService
            from .services.atlas_service import atlas_service as _atlas_svc
            from .config import Config

            bedrock_cfg = Config.get_bedrock_config(credentials_path)
            ak  = bedrock_cfg["access_key"]
            sk  = bedrock_cfg["secret_key"]
            reg = bedrock_cfg["region"]

            if not ak or not sk:
                print_error(
                    "AWS credentials not found. Please add aws: access_key_id / "
                    "secret_access_key to your credentials.yaml file."
                )
                continue

            # Re-initialize the atlas_service bedrock_service now that we have explicit credentials
            try:
                _atlas_svc.bedrock_service = BedrockService(
                    access_key=ak, secret_key=sk, region=reg
                )
            except Exception:
                pass  # Non-fatal; batch_service has its own client

            bedrock_service = BedrockService(access_key=ak, secret_key=sk, region=reg)
            batch_service = BatchFixService(bedrock_service)

            repo_name_str = repo.get("name", "")
            owner = full_name.split("/")[0] if "/" in full_name else None

            # Orchestrate baseline / fixes / validation based on user choices.
            batch_results: dict

            # Case 1: baseline only
            if want_baseline and not want_fixes and not want_validation:
                print_step("Baseline Testing (before fix)", "📊")
                print_info("Running build + existing tests (no fixes, no AI) …")
                try:
                    baseline_result = await _atlas_svc.run_baseline_only(
                        repo_path=str(repo_path),
                        repo_url=repo.get("clone_url") or repo.get("html_url", ""),
                    )
                    batch_results = {
                        "baseline_test_results": baseline_result,
                        "results": [],
                        "successful": 0,
                        "failed": 0,
                        "skipped": len(skippable),
                    }
                except Exception as exc:
                    err_msg = str(exc)
                    print_error(f"Baseline testing failed: {err_msg[:120]}")
                    batch_results = {
                        "baseline_test_results": None,
                        "results": [],
                        "successful": 0,
                        "failed": 0,
                        "skipped": len(skippable),
                        "error": err_msg,
                    }

            # Case 2: baseline + fixes, no validation
            elif want_baseline and want_fixes and not want_validation:
                print_step("Baseline Testing (before fix)", "📊")
                print_info("Running build + existing tests (no AI) …")
                try:
                    baseline_result = await _atlas_svc.run_baseline_only(
                        repo_path=str(repo_path),
                        repo_url=repo.get("clone_url") or repo.get("html_url", ""),
                    )
                except Exception as exc:
                    err_msg = str(exc)
                    print_error(f"Baseline testing failed: {err_msg[:120]}")
                    baseline_result = None

                print_step(f"Applying Fixes  ({len(vulnerabilities)} vulnerabilities)", "🤖")
                print_info("← 6-agent pipeline: Analyzer → Context → Strategy → Fix → Validator → Explanation")
                print()

                try:
                    batch_results = await batch_service.fix_batch_vulnerabilities(
                        vulnerabilities=vulnerabilities,
                        repo_path=str(repo_path),
                        repo_name=repo_name_str,
                        clone_url=repo.get("clone_url") or repo.get("html_url", ""),
                        token=token,
                        max_concurrent=1,
                        auto_create_pr=auto_pr,
                        repo_owner=owner,
                        base_branch="main",
                        run_tests_after_fix=False,
                    )
                    batch_results["baseline_test_results"] = baseline_result
                except Exception as exc:
                    err_msg = str(exc)
                    print_error(f"Batch fix pipeline failed: {err_msg[:120]}")
                    batch_results = {
                        "baseline_test_results": baseline_result,
                        "successful": 0,
                        "failed": len(fixable),
                        "skipped": len(skippable),
                        "results": [],
                        "error": err_msg,
                    }

            # Case 3: fixes + validation (includes baseline internally)
            elif want_fixes and want_validation:
                print_step("Applying Fixes  (with full testing)", "🤖")
                print_info("Baseline + validation will run via Atlas during the batch pipeline.")
                print()
                try:
                    batch_results = await batch_service.fix_batch_vulnerabilities(
                        vulnerabilities=vulnerabilities,
                        repo_path=str(repo_path),
                        repo_name=repo_name_str,
                        clone_url=repo.get("clone_url") or repo.get("html_url", ""),
                        token=token,
                        max_concurrent=1,
                        auto_create_pr=auto_pr,
                        repo_owner=owner,
                        base_branch="main",
                        run_tests_after_fix=True,
                    )
                except Exception as exc:
                    err_msg = str(exc)
                    print_error(f"Batch fix pipeline failed: {err_msg[:120]}")
                    batch_results = {
                        "successful": 0,
                        "failed": len(fixable),
                        "skipped": len(skippable),
                        "results": [],
                        "error": err_msg,
                    }

            # Case 4: fixes only (no baseline, no validation)
            elif want_fixes and not want_baseline and not want_validation:
                print_step(f"Applying Fixes  ({len(vulnerabilities)} vulnerabilities)", "🤖")
                print_info("Running fixing pipeline without any testing (no baseline, no validation).")
                print()
                try:
                    batch_results = await batch_service.fix_batch_vulnerabilities(
                        vulnerabilities=vulnerabilities,
                        repo_path=str(repo_path),
                        repo_name=repo_name_str,
                        clone_url=repo.get("clone_url") or repo.get("html_url", ""),
                        token=token,
                        max_concurrent=1,
                        auto_create_pr=auto_pr,
                        repo_owner=owner,
                        base_branch="main",
                        run_tests_after_fix=False,
                    )
                except Exception as exc:
                    err_msg = str(exc)
                    print_error(f"Batch fix pipeline failed: {err_msg[:120]}")
                    batch_results = {
                        "successful": 0,
                        "failed": len(fixable),
                        "skipped": len(skippable),
                        "results": [],
                        "error": err_msg,
                    }

            # Case 5: nothing selected (should be rare)
            else:
                print_warn("Neither baseline, fixes, nor validation were selected. Skipping repository.")
                batch_results = {
                    "successful": 0,
                    "failed": 0,
                    "skipped": len(vulnerabilities),
                    "results": [],
                }

            # ── Fix results ──────────────────────────────────────────────────
            print_step("Fix Results", "📋")
            for entry in batch_results.get("results", []):
                v_idx  = entry.get("vuln_idx", "?")
                status = entry.get("status", "failed")
                vuln_list = [v for v in vulnerabilities]
                # Best-effort vuln lookup
                vuln_for_entry = vuln_list[v_idx - 1] if isinstance(v_idx, int) and v_idx <= len(vuln_list) else {}
                vuln_type = vuln_for_entry.get("vulnerability", f"Vuln #{v_idx}")
                fix_result = entry.get("result") or {}
                duration   = fix_result.get("duration", 0) if isinstance(fix_result, dict) else 0

                if status == "success":
                    print_ok(f"{vuln_type}")
                elif status == "skipped":
                    print_warn(f"{vuln_type}  (skipped — file not found)")
                else:
                    err = entry.get("error") or "unknown error"
                    print_error(f"{vuln_type}  —  {err[:80]}")

            successful = batch_results.get("successful", 0)
            failed     = batch_results.get("failed", 0)
            skipped_n  = batch_results.get("skipped", 0)
            print()
            print_info(f"Fixes applied:   {c(str(successful), _GREEN, _BOLD)} succeeded   "
                       f"{c(str(failed), _RED) if failed else c('0', _DIM)} failed   "
                       f"{c(str(skipped_n), _DIM) if skipped_n else c('0', _DIM)} skipped")

            # ── Build verification ───────────────────────────────────────────
            build_verif = batch_results.get("build_verification") or {}
            if build_verif:
                print_step("Build Verification", "🔨")
                print_build_status(
                    ok=build_verif.get("build_ok", False),
                    retries=build_verif.get("retries", 0),
                    auto_fixed=build_verif.get("auto_fixed", False),
                )
                if not build_verif.get("build_ok"):
                    for err_line in (build_verif.get("build_errors") or [])[:5]:
                        print_info(c(err_line, _RED), indent=4)

            # ── PR result ────────────────────────────────────────────────────
            if auto_pr:
                print_step("Pull Request", "🔗")
                batch_pr = batch_results.get("batch_pr_result") or {}
                if batch_pr.get("success"):
                    pr_url = batch_pr.get("pr_url", "N/A")
                    pr_num = batch_pr.get("pr_number", "N/A")
                    print_ok(f"PR #{pr_num} created successfully")
                    print_info(f"{c(pr_url, _CYAN)}")
                else:
                    err = batch_pr.get("message") or batch_pr.get("error") or "No error detail"
                    print_warn(f"PR creation skipped or failed: {err[:100]}")

            end_to_end_results.append({"repo": repo, "batch_results": batch_results})

        # ── Final summary ────────────────────────────────────────────────────
        summary = {
            "run_id": run_id,
            "total_repos_with_vulns": len(mapped),
            "total_repos_processed": total_fixable_repos,
            "mapping": mapping,
            "results": end_to_end_results,
        }
        duration = time.time() - run_start
        print_final_summary(summary, auto_pr=auto_pr, duration_secs=duration)

        # Write JSON reports inside a dedicated results folder.
        # Layout:
        #   <base_parent>/results/
        #       icsf-run-<run_id>.json
        #       icsf-run-<run_id>-baseline.json
        #       icsf-run-<run_id>-fixes.json
        #       icsf-run-<run_id>-validation.json
        #       <run_id>-<repo_name>/... (per-repo slices)
        if args.output:
            p = Path(args.output).resolve()
            base_parent = p if p.is_dir() else p.parent
        else:
            base_parent = Path.cwd()

        results_root = base_parent / "results"
        results_root.mkdir(parents=True, exist_ok=True)

        base_name = f"icsf-run-{run_id}"
        out_path = results_root / f"{base_name}.json"

        out_path.write_text(cli_api.to_pretty_json(summary), encoding="utf-8")
        print_ok(f"Full JSON report written to  {c(str(out_path), _DIM)}")

        # User-friendly HTML report (single file, open in browser).
        html_path = results_root / f"{base_name}.html"
        html_path.write_text(
            render_run_report_html(summary, duration), encoding="utf-8"
        )
        print_ok(f"HTML report written to  {c(str(html_path), _DIM)}")

        # Baseline: per repo baseline_test_results if present.
        baseline_report = {
            "repos": [
                {
                    "repo": r.get("repo"),
                    "baseline_test_results": (r.get("batch_results") or {}).get(
                        "baseline_test_results"
                    ),
                }
                for r in end_to_end_results
            ]
        }
        baseline_path = results_root / f"{base_name}-baseline.json"
        baseline_path.write_text(
            cli_api.to_pretty_json(baseline_report), encoding="utf-8"
        )
        print_ok(f"Baseline report written to  {c(str(baseline_path), _DIM)}")

        # Fixes: per repo fix results (per vulnerability) and build verification.
        fixes_report = {
            "repos": [
                {
                    "repo": r.get("repo"),
                    "fix_results": (r.get("batch_results") or {}).get("results"),
                    "build_verification": (r.get("batch_results") or {}).get(
                        "build_verification"
                    ),
                }
                for r in end_to_end_results
            ]
        }
        fixes_path = results_root / f"{base_name}-fixes.json"
        fixes_path.write_text(
            cli_api.to_pretty_json(fixes_report), encoding="utf-8"
        )
        print_ok(f"Code-fix report written to  {c(str(fixes_path), _DIM)}")

        # Validation: per repo validation testing results (after_fix).
        validation_report = {
            "repos": [
                {
                    "repo": r.get("repo"),
                    "test_results": (r.get("batch_results") or {}).get(
                        "test_results"
                    ),
                }
                for r in end_to_end_results
            ]
        }
        validation_path = results_root / f"{base_name}-validation.json"
        validation_path.write_text(
            cli_api.to_pretty_json(validation_report), encoding="utf-8"
        )
        print_ok(
            f"Validation-testing report written to  {c(str(validation_path), _DIM)}"
        )

        # Additionally, create per-repo result folders: results/<run_id>-<repo_name>/...
        for repo_entry in end_to_end_results:
            repo_obj = repo_entry.get("repo") or {}
            batch_results = repo_entry.get("batch_results") or {}

            full_name = repo_obj.get("full_name") or repo_obj.get("name") or "repo"
            safe_repo = full_name.replace("/", "__").replace("\\", "__")
            repo_dir = results_root / f"{run_id}-{safe_repo}"
            repo_dir.mkdir(parents=True, exist_ok=True)

            # Per-repo summary
            per_repo_summary = {
                "run_id": run_id,
                "repo": repo_obj,
                "batch_results": batch_results,
            }
            (repo_dir / "summary.json").write_text(
                cli_api.to_pretty_json(per_repo_summary), encoding="utf-8"
            )

            # Baseline-only view
            per_repo_baseline = {
                "run_id": run_id,
                "repo": repo_obj,
                "baseline_test_results": batch_results.get("baseline_test_results"),
            }
            (repo_dir / "baseline.json").write_text(
                cli_api.to_pretty_json(per_repo_baseline), encoding="utf-8"
            )

            # Fixes-only view
            per_repo_fixes = {
                "run_id": run_id,
                "repo": repo_obj,
                "fix_results": batch_results.get("results"),
                "build_verification": batch_results.get("build_verification"),
            }
            (repo_dir / "fixes.json").write_text(
                cli_api.to_pretty_json(per_repo_fixes), encoding="utf-8"
            )

            # Validation-only view
            per_repo_validation = {
                "run_id": run_id,
                "repo": repo_obj,
                "test_results": batch_results.get("test_results"),
            }
            (repo_dir / "validation.json").write_text(
                cli_api.to_pretty_json(per_repo_validation), encoding="utf-8"
            )
        print()

        return 0

    return asyncio.run(_run())


# ── Entry point ──────────────────────────────────────────────────────────────

def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "run":
        return _handle_run(args)

    parser.print_help()
    return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
