import httpx
import json

token = "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"
headers = {
    "Authorization": f"token {token}",
    "Accept": "application/vnd.github.v3+json",
}

try:
    r = httpx.get("https://api.github.com/user", headers=headers)
    print(f"Status Code: {r.status_code}")
    print(f"Response Headers: {json.dumps(dict(r.headers), indent=2)}")
    print(f"Response Body: {r.text}")
except Exception as e:
    print(f"Error: {e}")
