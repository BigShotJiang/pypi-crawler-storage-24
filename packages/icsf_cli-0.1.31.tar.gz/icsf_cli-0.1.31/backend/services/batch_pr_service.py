"""
Batch PR Service

Handles batch creation of multiple Pull Requests for fixed vulnerabilities.
Supports both individual and batch PR creation.
"""

import logging
from typing import List, Dict, Any, Optional
from pathlib import Path

from .pr_manager_service import PRManagerService

logger = logging.getLogger(__name__)


class BatchPRService:
    """Service for batch PR creation"""
    
    def __init__(self, token: str):
        """
        Initialize Batch PR Service.
        
        Args:
            token: GitHub personal access token
        """
        self.token = token
        self.pr_manager = PRManagerService(token)
        logger.info("[BatchPRService] Initialized")
    
    def _extract_files_and_code(
        self,
        fix_result: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Extract files_modified, fixed_code_map and metadata from a single fix result.

        This is used both for single-PR and batch-PR creation so we don't duplicate parsing logic.
        """
        # Extract fix data from result
        result_data = fix_result.get('result', {})
        if not result_data:
            result_data = fix_result

        code_fix = result_data.get('code_fix', {})
        if not code_fix:
            return {
                'success': False,
                'message': 'Code fix data not found in result'
            }

        # Extract files modified
        files_modified = code_fix.get('files_modified', []) or []
        fixed_code_content = code_fix.get('fixed_code')

        fixed_code_map: Dict[str, str] = {}

        # Handle dict format directly
        if isinstance(fixed_code_content, dict):
            fixed_code_map = fixed_code_content.copy()
        else:
            # Handle string format with optional separators
            if not isinstance(fixed_code_content, str):
                fixed_code_content = str(fixed_code_content) if fixed_code_content is not None else ""

            file_separator = "FIXED CODE FOR:"

            if fixed_code_content and file_separator in fixed_code_content:
                sections = fixed_code_content.split(f"\n{file_separator}")
                for section in sections:
                    if not section.strip():
                        continue
                    lines = section.split('\n')
                    file_path = None
                    code_start = 0

                    for idx, line in enumerate(lines[:10]):
                        if file_separator in line:
                            file_path = line.split(file_separator)[-1].strip()
                            code_start = idx + 1
                            break

                    if file_path:
                        code_lines = lines[code_start:]
                        clean_code = '\n'.join(code_lines).strip()
                        clean_code = clean_code.replace('=' * 80, '').strip()
                        if clean_code:
                            fixed_code_map[file_path] = clean_code
            else:
                # Single file - map the whole fixed_code_content to the first modified file
                if files_modified and fixed_code_content:
                    fixed_code_map[files_modified[0]] = fixed_code_content.strip()

        # Fallback: if parsing failed but we have fixed_code and files_modified
        if not fixed_code_map and files_modified and fixed_code_content:
            fixed_code_map[files_modified[0]] = (
                fixed_code_content.strip()
                if isinstance(fixed_code_content, str)
                else str(fixed_code_content).strip()
            )

        if not files_modified or not fixed_code_map:
            return {
                'success': False,
                'message': 'Missing files_modified or fixed_code in code_fix'
            }

        # Get vulnerability details
        vuln_type = fix_result.get('vulnerability_type', 'Security Vulnerability')
        vuln_desc = fix_result.get('description', '') or result_data.get('description', '')
        fix_summary = code_fix.get('change_summary', '')

        return {
            'success': True,
            'files_modified': files_modified,
            'fixed_code_map': fixed_code_map,
            'vulnerability_type': vuln_type,
            'vulnerability_description': vuln_desc,
            'fix_summary': fix_summary,
        }

    async def create_single_pr(
        self,
        fix_result: Dict[str, Any],
        repo_owner: str,
        repo_name: str,
        repo_path: str,
        base_branch: str = "main"
    ) -> Dict[str, Any]:
        """
        Create a single PR for a fixed vulnerability.
        """
        try:
            extracted = self._extract_files_and_code(fix_result)
            if not extracted.get('success'):
                return {
                    'success': False,
                    'message': extracted.get('message', 'Failed to extract fixed code'),
                    'pr_number': None,
                    'pr_url': None
                }

            files_modified = extracted['files_modified']
            fixed_code_map = extracted['fixed_code_map']
            vuln_type = extracted['vulnerability_type']
            vuln_desc = extracted['vulnerability_description']
            fix_summary = extracted['fix_summary']

            # Validate repository path
            repo_path_obj = Path(repo_path)
            if not repo_path_obj.exists():
                return {
                    'success': False,
                    'message': f'Repository path does not exist: {repo_path}',
                    'pr_number': None,
                    'pr_url': None
                }

            # Create PR
            pr_result = await self.pr_manager.create_pr_for_fix(
                repo_path=str(repo_path_obj),
                repo_owner=repo_owner,
                repo_name=repo_name,
                files_modified=files_modified,
                fixed_code_map=fixed_code_map,
                vulnerability_type=vuln_type,
                vulnerability_description=vuln_desc,
                fix_summary=fix_summary,
                base_branch=base_branch,
                include_all_repo_changes=True  # Ensure all repo changes (pom.xml, etc) are captured
            )

            return pr_result

        except Exception as e:
            logger.error(f"[BatchPRService] Error creating PR: {str(e)}")
            return {
                'success': False,
                'message': f'Exception during PR creation: {str(e)}',
                'pr_number': None,
                'pr_url': None
            }
    
    async def create_batch_prs(
        self,
        successful_fixes: List[Dict[str, Any]],
        repo_owner: str,
        repo_name: str,
        repo_path: str,
        base_branch: str = "main"
    ) -> Dict[str, Any]:
        """
        Create multiple PRs for batch fixes.
        
        Args:
            successful_fixes: List of successful fix results, each containing:
                - vuln_idx: int
                - result: Dict with fix result
            repo_owner: Repository owner
            repo_name: Repository name
            repo_path: Path to repository
            base_branch: Base branch for PRs
            
        Returns:
            Dictionary with batch PR results:
            {
                'total': int,
                'successful': int,
                'failed': int,
                'results': List[Dict]
            }
        """
        logger.info(f"[BatchPRService] Starting batch PR creation for {len(successful_fixes)} fixes")
        
        results = {
            'total': len(successful_fixes),
            'successful': 0,
            'failed': 0,
            'results': []
        }
        
        # Process PRs sequentially
        for fix_res in successful_fixes:
            vuln_idx = fix_res.get('vuln_idx', 0)
            fix_result = fix_res.get('result')
            
            if not fix_result:
                results['failed'] += 1
                results['results'].append({
                    'vuln_idx': vuln_idx,
                    'status': 'failed',
                    'error': 'Fix result not found',
                    'pr_result': None
                })
                continue
            
            logger.info(f"[BatchPRService] Creating PR for vulnerability #{vuln_idx}")
            
            pr_result = await self.create_single_pr(
                fix_result=fix_result,
                repo_owner=repo_owner,
                repo_name=repo_name,
                repo_path=repo_path,
                base_branch=base_branch
            )
            
            if pr_result and pr_result.get('success'):
                results['successful'] += 1
                results['results'].append({
                    'vuln_idx': vuln_idx,
                    'status': 'success',
                    'error': None,
                    'pr_result': pr_result
                })
            else:
                results['failed'] += 1
                error_msg = pr_result.get('message', 'Unknown error') if pr_result else 'Failed to create PR'
                results['results'].append({
                    'vuln_idx': vuln_idx,
                    'status': 'failed',
                    'error': error_msg,
                    'pr_result': None
                })
        
        logger.info(
            f"[BatchPRService] Batch PR creation completed: "
            f"{results['successful']} successful, {results['failed']} failed"
        )
        
        return results

    async def create_single_batch_pr(
        self,
        successful_fixes: List[Dict[str, Any]],
        repo_owner: str,
        repo_name: str,
        repo_path: str,
        base_branch: str = "main",
        test_results: Optional[Dict[str, Any]] = None  # NEW: Test generation results
    ) -> Dict[str, Any]:
        """
        Create a SINGLE PR that contains all successful fixes.

        This aggregates:
        - files_modified across all fixes
        - fixed_code_map across all fixes
        and then calls PRManagerService.create_pr_for_fix once.
        """
        if not successful_fixes:
            return {
                'success': False,
                'message': 'No successful fixes to create PR for',
                'pr_number': None,
                'pr_url': None
            }

        try:
            all_files: List[str] = []
            combined_fixed_code_map: Dict[str, str] = {}
            vuln_summaries: List[str] = []

            for fix_res in successful_fixes:
                fix_result = fix_res.get('result')
                vuln_idx = fix_res.get('vuln_idx', 0)

                if not fix_result:
                    continue

                extracted = self._extract_files_and_code(fix_result)
                if not extracted.get('success'):
                    logger.warning(
                        f"[BatchPRService] Skipping vulnerability #{vuln_idx} in batch PR: "
                        f"{extracted.get('message')}"
                    )
                    continue

                files_modified = extracted['files_modified']
                fixed_code_map = extracted['fixed_code_map']
                vuln_type = extracted['vulnerability_type']
                vuln_desc = extracted['vulnerability_description']

                # Track files
                for f in files_modified:
                    if f not in all_files:
                        all_files.append(f)

                # Merge code maps (last one wins if same file appears multiple times)
                for path, code in fixed_code_map.items():
                    combined_fixed_code_map[path] = code

                vuln_summaries.append(
                    f"- Vulnerability #{vuln_idx}: {vuln_type} - {vuln_desc}"
                )

            if not all_files or not combined_fixed_code_map:
                return {
                    'success': False,
                    'message': 'No valid fixed code found across successful fixes',
                    'pr_number': None,
                    'pr_url': None
                }

            # Build aggregated metadata
            vuln_type_agg = "Multiple security vulnerabilities"
            vuln_desc_agg = (
                "This PR fixes multiple security vulnerabilities:\n\n" +
                "\n".join(vuln_summaries)
            )
            fix_summary_agg = (
                "Batch security fix: combined changes from multiple automatically "
                "generated vulnerability fixes."
            )
            
            # Validate repository path
            repo_path_obj = Path(repo_path)
            if not repo_path_obj.exists():
                return {
                    'success': False,
                    'message': f'Repository path does not exist: {repo_path}',
                    'pr_number': None,
                    'pr_url': None
                }

            # NEW: Add test generation info if available
            if test_results and test_results.get('success'):
                tests_generated = test_results.get('tests_generated', 0)
                test_files = test_results.get('test_files', [])
                coverage = test_results.get('coverage', 'N/A')
                
                vuln_desc_agg += (
                    "\n\n## 🧪 Generated Tests\n\n"
                    f"- **Tests Generated:** {tests_generated}\n"
                    f"- **Coverage:** {coverage}\n"
                    f"- **Test Files:**\n"
                )
                for test_file in test_files[:10]:  # Limit to first 10
                    vuln_desc_agg += f"  - `{test_file}`\n"
                if len(test_files) > 10:
                    vuln_desc_agg += f"  - ... and {len(test_files) - 10} more\n"
                
                # Add test files to files_modified list AND fixed_code_map
                for test_file in test_files:
                    if test_file not in all_files:
                        all_files.append(test_file)
                    
                    # Read the generated test file content and add to map
                    try:
                        abs_test_path = repo_path_obj / test_file
                        if abs_test_path.exists():
                            with open(abs_test_path, 'r', encoding='utf-8') as f:
                                test_content = f.read()
                                combined_fixed_code_map[test_file] = test_content
                                logger.info(f"[BatchPRService] Added generated test file to PR map: {test_file}")
                    except Exception as e:
                        logger.error(f"[BatchPRService] Error reading generated test file {test_file}: {str(e)}")

            elif test_results and not test_results.get('success'):
                # Test generation failed, add warning
                vuln_desc_agg += (
                    "\n\n## ⚠️ Test Generation\n\n"
                    f"Test generation was attempted but failed: {test_results.get('error', 'Unknown error')}\n"
                )


            # Create a single aggregated PR
            pr_result = await self.pr_manager.create_pr_for_fix(
                repo_path=str(repo_path_obj),
                repo_owner=repo_owner,
                repo_name=repo_name,
                files_modified=all_files,
                fixed_code_map=combined_fixed_code_map,
                vulnerability_type=vuln_type_agg,
                vulnerability_description=vuln_desc_agg,
                fix_summary=fix_summary_agg,
                base_branch=base_branch,
                include_all_repo_changes=True  # Ensure all repo changes (pom.xml, etc) are captured
            )

            return pr_result

        except Exception as e:
            logger.error(f"[BatchPRService] Error creating single batch PR: {str(e)}")
            return {
                'success': False,
                'message': f'Exception during batch PR creation: {str(e)}',
                'pr_number': None,
                'pr_url': None
            }

