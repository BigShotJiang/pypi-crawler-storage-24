import asyncio
import logging
import json
import uuid
from typing import Dict, Any, Generator

logger = logging.getLogger(__name__)

class JobManagerService:
    def __init__(self):
        # Maps job_id -> status dict
        self.jobs: Dict[str, Dict[str, Any]] = {}
        # Maps job_id -> asyncio.Queue for SSE streaming
        self.job_queues: Dict[str, asyncio.Queue] = {}

    def create_job(self) -> str:
        """Create a new job and return its ID."""
        job_id = str(uuid.uuid4())
        self.jobs[job_id] = {
            "status": "QUEUED",
            "progress": 0,
            "message": "Job queued for execution",
            "result": None,
            "error": None
        }
        self.job_queues[job_id] = asyncio.Queue()
        return job_id

    def update_job(self, job_id: str, status: str, message: str, progress: int = None, result: Any = None, error: Any = None):
        """Update job status and notify SSE listeners."""
        if job_id not in self.jobs:
            return
            
        job = self.jobs[job_id]
        job["status"] = status
        job["message"] = message
        if progress is not None:
            job["progress"] = progress
        if result is not None:
            job["result"] = result
        if error is not None:
            job["error"] = error
            
        # Push to SSE queue
        if job_id in self.job_queues:
            event_data = json.dumps({
                "status": job["status"],
                "message": job["message"],
                "progress": job["progress"]
            })
            # Put without blocking (queue is unbounded by default in python)
            self.job_queues[job_id].put_nowait(f"data: {event_data}\n\n")

    def end_job(self, job_id: str):
        """Signal that the job is complete so SSE can close."""
        if job_id in self.job_queues:
            self.job_queues[job_id].put_nowait("[DONE]")

    def get_job(self, job_id: str) -> Dict[str, Any]:
        """Get current job status."""
        return self.jobs.get(job_id)

    async def stream_job_events(self, job_id: str):
        """Async generator for SSE StreamingResponse."""
        if job_id not in self.job_queues:
            # Send initial state if queue was already cleaned up (or doesn't exist)
            job = self.get_job(job_id)
            if job:
                yield f"data: {json.dumps(job)}\n\n"
            yield "data: [DONE]\n\n"
            return
            
        queue = self.job_queues[job_id]
        try:
            while True:
                message = await queue.get()
                if message == "[DONE]":
                    yield "data: [DONE]\n\n"
                    break
                yield message
        except asyncio.CancelledError:
            logger.info(f"[JobManager] Client disconnected from SSE for job {job_id}")
            raise

job_manager = JobManagerService()
