"""
AWS Bedrock Service for Multi-Agent Vulnerability Fixing System

This service provides a wrapper around AWS Bedrock API for invoking
Claude and Llama models to perform security vulnerability analysis and code fixes.
"""

import asyncio
import json
import logging
import os
from typing import Dict, Optional, Any, List
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class BedrockService:
    """Service class for interacting with AWS Bedrock models"""
    
    # Supported models (using standard on-demand model IDs)
    CLAUDE_3_5_SONNET = "anthropic.claude-3-5-sonnet-20240620-v1:0"
    CLAUDE_3_SONNET = "anthropic.claude-3-sonnet-20240229-v1:0"
    CLAUDE_3_HAIKU = "anthropic.claude-3-haiku-20240307-v1:0"
    LLAMA_3_70B = "meta.llama3-70b-instruct-v1:0"
    
    def __init__(
        self,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        region: Optional[str] = None
    ):
        """
        Initialize Bedrock service with AWS credentials.
        
        Credentials can be provided as parameters or loaded from environment variables.
        Priority: Parameters > Environment Variables
        
        Args:
            access_key: AWS access key ID (optional, will use AWS_ACCESS_KEY_ID env var if not provided)
            secret_key: AWS secret access key (optional, will use AWS_SECRET_ACCESS_KEY env var if not provided)
            region: AWS region (optional, will use AWS_REGION env var or default to us-east-1)
        """
        # Use parameters if provided, otherwise fall back to environment variables
        self.access_key = (access_key or os.getenv('AWS_ACCESS_KEY_ID', '')).strip()
        self.secret_key = (secret_key or os.getenv('AWS_SECRET_ACCESS_KEY', '')).strip()
        
        # Security: Permanent credentials (AKIA) must NOT use a session token.
        # Temporary credentials (ASIA) REQUIRED a session token.
        env_token = os.getenv('AWS_SESSION_TOKEN', '').strip()
        if self.access_key.startswith('AKIA'):
            self.session_token = None
        else:
            self.session_token = env_token or None
            
        self.region = (region or os.getenv('AWS_REGION', 'us-east-1')).strip()
        
        # Validate credentials are set
        if not self.access_key or not self.secret_key:
            raise ValueError(
                "AWS credentials not provided. "
                "Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables, "
                "or pass them as parameters to BedrockService."
            )
        
        # Initialize Bedrock runtime client with explicit credentials
        # via a Session to ensure absolute isolation from environment variables.
        session_kwargs = {
            'aws_access_key_id': self.access_key,
            'aws_secret_access_key': self.secret_key,
            'aws_session_token': self.session_token,
            'region_name': self.region
        }
            
        session = boto3.Session(**session_kwargs)
        
        self.client = session.client(
            service_name='bedrock-runtime',
            config=Config(
                retries={'max_attempts': 10, 'mode': 'adaptive'},
                read_timeout=300  # 5 minutes
            )
        )
        
        logger.info(f"BedrockService initialized for region: {self.region}")
    
    def invoke_claude(
        self,
        prompt: str,
        model_id: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        system_prompt: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Invoke Claude model (Claude 3.5 Sonnet or Claude 3 Haiku).
        
        Args:
            prompt: User prompt/message
            model_id: Model ID (default: CLAUDE_3_5_SONNET)
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature (0.0-1.0)
            system_prompt: Optional system prompt
            
        Returns:
            Dictionary with response content and metadata
        """
        if model_id is None:
            model_id = self.CLAUDE_3_5_SONNET
        
        # Build message structure
        messages = []
        if system_prompt:
            messages.append({
                "role": "user",
                "content": system_prompt
            })
        messages.append({
            "role": "user",
            "content": prompt
        })
        
        # Prepare request body
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": messages
        }
        
        try:
            logger.info(f"Invoking Claude model: {model_id}")
            response = self.client.invoke_model(
                modelId=model_id,
                body=json.dumps(body),
                contentType="application/json",
                accept="application/json"
            )
            
            # Parse response
            response_body = json.loads(response['body'].read())
            
            # Extract content
            content = response_body.get('content', [])
            if content and len(content) > 0:
                text_content = content[0].get('text', '')
            else:
                text_content = ''
            
            return {
                'success': True,
                'content': text_content,
                'model_id': model_id,
                'usage': response_body.get('usage', {}),
                'stop_reason': response_body.get('stop_reason', 'unknown')
            }
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            logger.error(f"Bedrock API error: {error_code} - {error_message}")
            return {
                'success': False,
                'error_code': error_code,
                'error_message': error_message,
                'content': None
            }
            return {
                'success': False,
                'error_code': 'UNKNOWN_ERROR',
                'error_message': str(e),
                'content': None
            }

    async def ainvoke_claude(
        self,
        prompt: str,
        model_id: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        system_prompt: Optional[str] = None
    ) -> Dict[str, Any]:
        """Async version of invoke_claude using asyncio.to_thread."""
        return await asyncio.to_thread(
            self.invoke_claude,
            prompt=prompt,
            model_id=model_id,
            max_tokens=max_tokens,
            temperature=temperature,
            system_prompt=system_prompt
        )
    
    def invoke_llama(
        self,
        prompt: str,
        model_id: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ) -> Dict[str, Any]:
        """
        Invoke Llama model (Llama 3 70B).
        
        Args:
            prompt: User prompt/message
            model_id: Model ID (default: LLAMA_3_70B)
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature (0.0-1.0)
            
        Returns:
            Dictionary with response content and metadata
        """
        if model_id is None:
            model_id = self.LLAMA_3_70B
        
        # Build prompt format for Llama
        formatted_prompt = f"<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n{prompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
        
        # Prepare request body
        body = {
            "prompt": formatted_prompt,
            "max_gen_len": max_tokens,
            "temperature": temperature
        }
        
        try:
            logger.info(f"Invoking Llama model: {model_id}")
            response = self.client.invoke_model(
                modelId=model_id,
                body=json.dumps(body),
                contentType="application/json",
                accept="application/json"
            )
            
            # Parse response
            response_body = json.loads(response['body'].read())
            
            # Extract content
            text_content = response_body.get('generation', '')
            
            return {
                'success': True,
                'content': text_content,
                'model_id': model_id,
                'usage': {
                    'prompt_tokens': response_body.get('prompt_token_count', 0),
                    'completion_tokens': response_body.get('generation_token_count', 0)
                }
            }
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            logger.error(f"Bedrock API error: {error_code} - {error_message}")
            return {
                'success': False,
                'error_code': error_code,
                'error_message': error_message,
                'content': None
            }
            return {
                'success': False,
                'error_code': 'UNKNOWN_ERROR',
                'error_message': str(e),
                'content': None
            }

    async def ainvoke_llama(
        self,
        prompt: str,
        model_id: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ) -> Dict[str, Any]:
        """Async version of invoke_llama using asyncio.to_thread."""
        return await asyncio.to_thread(
            self.invoke_llama,
            prompt=prompt,
            model_id=model_id,
            max_tokens=max_tokens,
            temperature=temperature
        )
    
    def embed_text(
        self,
        text: str,
        embed_model_id: Optional[str] = None
    ) -> List[float]:
        """
        Generate text embeddings using Amazon Titan Embeddings model.
        
        Args:
            text: Text to embed
            embed_model_id: Embedding model ID (default: amazon.titan-embed-text-v1)
            
        Returns:
            List of float values representing the embedding vector
        """
        if embed_model_id is None:
            embed_model_id = "amazon.titan-embed-text-v1"
        
        try:
            body = json.dumps({"inputText": text})
            response = self.client.invoke_model(
                modelId=embed_model_id,
                contentType="application/json",
                accept="application/json",
                body=body
            )
            
            response_body = json.loads(response['body'].read())
            embedding = response_body.get("embedding", [])
            
            if not isinstance(embedding, list):
                raise ValueError(f"Unexpected embedding response format: {response_body}")
            
            return [float(x) for x in embedding]
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            logger.error(f"Bedrock embedding API error: {error_code} - {error_message}")
            raise Exception(f"Embedding failed: {error_message}")
        except Exception as e:
            logger.error(f"Unexpected error generating embedding: {str(e)}")
            raise
    
    def invoke_model(
        self,
        model_id: str,
        prompt: str,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        system_prompt: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Generic method to invoke any supported model.
        Automatically selects the appropriate invocation method based on model ID.
        
        Args:
            model_id: Model ID (Claude or Llama)
            prompt: User prompt/message
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature (0.0-1.0)
            system_prompt: Optional system prompt (Claude only)
            
        Returns:
            Dictionary with response content and metadata
        """
        if model_id.startswith('anthropic'):
            return self.invoke_claude(
                prompt=prompt,
                model_id=model_id,
                max_tokens=max_tokens,
                temperature=temperature,
                system_prompt=system_prompt
            )
        elif model_id.startswith('meta'):
            return self.invoke_llama(
                prompt=prompt,
                model_id=model_id,
                max_tokens=max_tokens,
                temperature=temperature
            )
        else:
            logger.error(f"Unsupported model ID: {model_id}")
            return {
                'success': False,
                'error_code': 'UNSUPPORTED_MODEL',
                'error_message': f"Model {model_id} is not supported",
                'content': None
            }

    async def ainvoke_model(
        self,
        model_id: str,
        prompt: str,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        system_prompt: Optional[str] = None
    ) -> Dict[str, Any]:
        """Async version of invoke_model using asyncio.to_thread."""
        return await asyncio.to_thread(
            self.invoke_model,
            model_id=model_id,
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            system_prompt=system_prompt
        )
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test Bedrock connection by invoking a simple prompt.
        
        Returns:
            Dictionary with test result
        """
        test_prompt = "Say 'Hello, Bedrock service is working!' if you can read this."
        
        try:
            # Try Claude 3.5 Sonnet first, fallback to Haiku if not available
            result = self.invoke_model(
                model_id=self.CLAUDE_3_5_SONNET,
                prompt=test_prompt,
                max_tokens=100
            )
            
            # If Claude 3.5 Sonnet fails, try Claude 3 Haiku as fallback
            if not result['success']:
                logger.warning(f"Claude 3.5 Sonnet not available, trying Claude 3 Haiku...")
                result = self.invoke_model(
                    model_id=self.CLAUDE_3_HAIKU,
                    prompt=test_prompt,
                    max_tokens=100
                )
            
            if result['success']:
                return {
                    'success': True,
                    'message': 'Bedrock connection successful',
                    'response': result['content']
                }
            else:
                return {
                    'success': False,
                    'message': 'Bedrock connection failed',
                    'error': result.get('error_message', 'Unknown error')
                }
                
        except Exception as e:
            return {
                'success': False,
                'message': 'Bedrock connection test failed',
                'error': str(e)
            }

