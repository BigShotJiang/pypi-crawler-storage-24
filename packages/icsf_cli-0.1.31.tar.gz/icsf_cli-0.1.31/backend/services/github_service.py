import httpx
from typing import List, Dict, Optional


class GitHubService:
    """Service class to interact with GitHub API"""
    
    BASE_URL = "https://api.github.com"
    
    def __init__(self, token: str):
        """
        Initialize GitHub service with authentication token.
        
        Args:
            token: GitHub personal access token
        """
        self.token = token.strip() if token else ""
        # For classic PATs (ghp_...), 'token' prefix is standard.
        # For GitHub Apps or fine-grained PATs, 'Bearer' is often preferred.
        # We'll use 'token' as default for classic PATs.
        prefix = "token" if self.token.startswith("ghp_") else "Bearer"
        self.headers = {
            "Authorization": f"{prefix} {self.token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "GitHub-Repo-Fetcher"
        }
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"GitHubService initialized with {prefix} authentication")
    
    async def verify_token_and_get_user(self, username: Optional[str] = None) -> Dict:
        """
        Verify the token and get user information.
        
        Args:
            username: GitHub username (optional). If provided, verifies it matches authenticated user.
            
        Returns:
            User information dictionary
            
        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.BASE_URL}/user",
                headers=self.headers,
                timeout=30.0
            )
            response.raise_for_status()
            user_data = response.json()
            
            # If username is provided, verify it matches the authenticated user
            if username:
                authenticated_username = user_data.get("login", "").lower()
                if authenticated_username != username.lower():
                    # Allow anyway - token might have permissions to access other users' repos
                    pass
            
            return user_data
    
    async def get_user_by_username(self, username: str) -> Dict:
        """
        Get user information by username (public API, doesn't require token for public users).
        
        Args:
            username: GitHub username
            
        Returns:
            User information dictionary
            
        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.BASE_URL}/users/{username}",
                headers=self.headers,
                timeout=30.0
            )
            response.raise_for_status()
            return response.json()
    
    async def get_username_from_email(self, email: str) -> Optional[str]:
        """
        Try to find GitHub username from email address using authenticated user's info.
        
        Note: GitHub API doesn't provide a direct way to search by email for other users.
        This method checks if the provided email matches the authenticated user's email.
        
        Args:
            email: Email address
            
        Returns:
            Username if found (matches authenticated user), None otherwise
        """
        try:
            # Get the authenticated user's information
            async with httpx.AsyncClient() as client:
                # Get user info
                response = await client.get(
                    f"{self.BASE_URL}/user",
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                user_data = response.json()
                
                # Get user emails (requires user:email scope)
                emails_response = await client.get(
                    f"{self.BASE_URL}/user/emails",
                    headers=self.headers,
                    timeout=30.0
                )
                
                # Check if email matches authenticated user's email
                user_email = user_data.get("email", "").lower()
                provided_email = email.lower()
                
                if user_email == provided_email:
                    return user_data.get("login")
                
                # Check in user's email list if available
                if emails_response.status_code == 200:
                    emails = emails_response.json()
                    for email_obj in emails:
                        if isinstance(email_obj, dict):
                            email_addr = email_obj.get("email", "").lower()
                            if email_addr == provided_email:
                                return user_data.get("login")
                
                return None
                
        except httpx.HTTPStatusError:
            # If we can't access email information, return None
            return None
        except Exception:
            return None
    
    async def get_user_organizations(self) -> List[Dict]:
        """
        Get all organizations the authenticated user belongs to.
        
        Returns:
            List of organization dictionaries
            
        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        orgs = []
        page = 1
        per_page = 100
        
        async with httpx.AsyncClient() as client:
            while True:
                response = await client.get(
                    f"{self.BASE_URL}/user/orgs",
                    headers=self.headers,
                    params={
                        "per_page": per_page,
                        "page": page
                    },
                    timeout=30.0
                )
                response.raise_for_status()
                
                page_orgs = response.json()
                
                if not page_orgs:
                    break
                
                orgs.extend(page_orgs)
                
                if len(page_orgs) < per_page:
                    break
                
                page += 1
        
        return orgs
    
    async def get_organization_repositories(self, org_name: str) -> List[Dict]:
        """
        Get all repositories for an organization.
        
        Args:
            org_name: Organization name
            
        Returns:
            List of repository dictionaries
            
        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        repos = []
        page = 1
        per_page = 100
        
        async with httpx.AsyncClient() as client:
            while True:
                response = await client.get(
                    f"{self.BASE_URL}/orgs/{org_name}/repos",
                    headers=self.headers,
                    params={
                        "per_page": per_page,
                        "page": page,
                        "sort": "updated",
                        "direction": "desc"
                    },
                    timeout=30.0
                )
                response.raise_for_status()
                
                page_repos = response.json()
                
                if not page_repos:
                    break
                
                repos.extend(page_repos)
                
                if len(page_repos) < per_page:
                    break
                
                page += 1
        
        return repos
    
    async def get_all_repositories(self, username: str, include_private: bool = True, authenticated_username: Optional[str] = None, include_orgs: bool = True) -> List[Dict]:
        """
        Get all repositories for a user including organization repositories.
        
        Args:
            username: GitHub username to fetch repos for
            include_private: Whether to include private repositories (requires appropriate token)
            authenticated_username: The username of the authenticated user (from token)
            include_orgs: Whether to include repositories from organizations the user belongs to
            
        Returns:
            List of repository dictionaries
            
        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        repos = []
        page = 1
        per_page = 100  # GitHub API max is 100
        
        # Check if we're fetching repos for the authenticated user
        is_authenticated_user = authenticated_username and username.lower() == authenticated_username.lower()
        
        async with httpx.AsyncClient() as client:
            while True:
                # Use /user/repos for authenticated user's repos (includes private)
                # Use /users/{username}/repos for public repos of any user
                if include_private and is_authenticated_user:
                    # Fetch all repos (including private) for authenticated user
                    # Use comma-separated affiliation to get: owner, collaborator, and organization_member repos
                    url = f"{self.BASE_URL}/user/repos"
                    params = {
                        "per_page": per_page,
                        "page": page,
                        "affiliation": "owner,collaborator,organization_member",  # Get all repo types
                        "sort": "updated",
                        "direction": "desc"
                    }
                else:
                    # Fetch public repos for specified username
                    url = f"{self.BASE_URL}/users/{username}/repos"
                    params = {
                        "per_page": per_page,
                        "page": page,
                        "sort": "updated",
                        "direction": "desc"
                    }
                
                response = await client.get(
                    url,
                    headers=self.headers,
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                
                page_repos = response.json()
                
                if not page_repos:
                    break
                
                # If we're fetching for a specific user, filter by owner
                if not is_authenticated_user:
                    page_repos = [repo for repo in page_repos if repo.get("owner", {}).get("login", "").lower() == username.lower()]
                
                repos.extend(page_repos)
                
                # Check if there are more pages
                if len(page_repos) < per_page:
                    break
                
                page += 1
        
        # If authenticated user and include_orgs is True, also fetch organization repositories
        # Note: This is in addition to affiliation-based fetching above
        # Some organization repos might not be returned via affiliation, so we fetch them directly
        if include_orgs and is_authenticated_user:
            try:
                # Get user's organizations
                orgs = await self.get_user_organizations()
                
                # Fetch repositories from each organization
                for org in orgs:
                    org_name = org.get("login")
                    if org_name:
                        try:
                            org_repos = await self.get_organization_repositories(org_name)
                            if org_repos:
                                repos.extend(org_repos)
                        except httpx.HTTPStatusError as e:
                            # If we can't access org repos (403 = permission issue, 404 = not found)
                            # This can happen if token doesn't have org:read permission or org doesn't exist
                            # Skip this org and continue
                            if e.response.status_code not in (403, 404):
                                # Re-raise if it's a different error
                                raise
                        except Exception:
                            # Other errors, skip this org
                            pass
            except httpx.HTTPStatusError as e:
                # If we can't fetch organizations (403 = permission issue)
                # This can happen if token doesn't have read:org scope
                # Continue without organizations - affiliation-based repos should still be returned
                if e.response.status_code != 403:
                    # Re-raise if it's not a permission issue
                    raise
            except Exception:
                # Other errors fetching orgs, continue without them
                pass
        
        # Remove duplicates (in case a repo appears in both user repos and org repos)
        seen = set()
        unique_repos = []
        for repo in repos:
            repo_id = repo.get("id")
            if repo_id and repo_id not in seen:
                seen.add(repo_id)
                unique_repos.append(repo)
        
        return unique_repos
    
    async def get_repository_details(self, owner: str, repo_name: str) -> Dict:
        """
        Get detailed information about a specific repository.
        
        Args:
            owner: Repository owner username
            repo_name: Repository name
            
        Returns:
            Repository details dictionary
            
        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.BASE_URL}/repos/{owner}/{repo_name}",
                headers=self.headers,
                timeout=30.0
            )
            response.raise_for_status()
            return response.json()
    
    async def get_repository_file_tree(self, owner: str, repo_name: str, branch: str = "main") -> List[str]:
        """
        Get list of file paths in a repository.
        
        Args:
            owner: Repository owner username
            repo_name: Repository name
            branch: Branch name (default: main)
            
        Returns:
            List of file paths in the repository
            
        Raises:
            httpx.HTTPStatusError: If the request fails
        """
        file_paths = []
        
        async def fetch_tree_recursive(sha: str, path: str = ""):
            """Recursively fetch tree contents"""
            async with httpx.AsyncClient() as client:
                # Try recursive first (more efficient)
                try:
                    response = await client.get(
                        f"{self.BASE_URL}/repos/{owner}/{repo_name}/git/trees/{sha}?recursive=1",
                        headers=self.headers,
                        timeout=60.0  # Increased timeout for large repositories
                    )
                    
                    if response.status_code == 200:
                        tree_data = response.json()
                        for item in tree_data.get("tree", []):
                            if item.get("type") == "blob":  # Only files, not directories
                                file_path = item.get("path", "")
                                if file_path:
                                    file_paths.append(file_path)
                        return  # Success, exit early
                except Exception:
                    pass  # Fall through to non-recursive method
                
                # Fallback: Try without recursive parameter
                try:
                    response = await client.get(
                        f"{self.BASE_URL}/repos/{owner}/{repo_name}/git/trees/{sha}",
                        headers=self.headers,
                        timeout=60.0  # Increased timeout for large repositories
                    )
                    if response.status_code == 200:
                        tree_data = response.json()
                        for item in tree_data.get("tree", []):
                            if item.get("type") == "blob":
                                file_path = item.get("path", "")
                                if file_path:
                                    file_paths.append(file_path)
                            elif item.get("type") == "tree":
                                # Recursively fetch subdirectories
                                await fetch_tree_recursive(item.get("sha"), item.get("path", ""))
                except Exception:
                    pass
        
        try:
            # Get the branch SHA
            async with httpx.AsyncClient() as client:
                # Try main branch first, then master, then default branch
                for branch_name in [branch, "main", "master"]:
                    try:
                        response = await client.get(
                            f"{self.BASE_URL}/repos/{owner}/{repo_name}/branches/{branch_name}",
                            headers=self.headers,
                            timeout=60.0  # Increased timeout
                        )
                        if response.status_code == 200:
                            branch_data = response.json()
                            commit_sha = branch_data.get("commit", {}).get("sha")
                            if commit_sha:
                                await fetch_tree_recursive(commit_sha)
                                break
                    except:
                        continue
        except Exception:
            # If tree fetch fails, return empty list
            pass
        
        return file_paths

