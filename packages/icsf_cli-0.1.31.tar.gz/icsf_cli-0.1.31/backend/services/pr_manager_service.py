"""
Pull Request Manager Service

Handles Git operations and GitHub Pull Request creation:
- Create branch
- Commit fixed code
- Push to GitHub
- Create Pull Request
"""

import os
import subprocess
import logging
import httpx
import re
from typing import Dict, Optional, List, Tuple, Any
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


class PRManagerService:
    """Service for managing Git operations and GitHub Pull Requests"""
    
    BASE_URL = "https://api.github.com"
    
    def __init__(self, token: Optional[str] = None):
        """
        Initialize PR Manager Service.
        
        Args:
            token: GitHub personal access token (optional, required for GitHub API operations)
        """
        self.token = token
        if token:
            self.headers = {
                "Authorization": f"token {token}",
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "ICSF-PR-Manager"
            }
        else:
            self.headers = {
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "ICSF-PR-Manager"
            }
    
    def _run_git_command(self, repo_path: str, command: List[str], timeout: int = 60) -> Dict[str, any]:
        """
        Run a git command in the repository.
        
        Args:
            repo_path: Path to repository
            command: Git command as list (e.g., ['git', 'checkout', '-b', 'branch-name'])
            timeout: Command timeout in seconds
            
        Returns:
            Dictionary with success status, stdout, and stderr
        """
        try:
            import sys
            result = subprocess.run(
                command,
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=timeout,
                shell=(sys.platform == "win32")
            )
            
            return {
                'success': result.returncode == 0,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'returncode': result.returncode
            }
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'stdout': '',
                'stderr': f'Command timed out after {timeout} seconds',
                'returncode': -1
            }
        except Exception as e:
            return {
                'success': False,
                'stdout': '',
                'stderr': str(e),
                'returncode': -1
            }
    
    def create_branch(self, repo_path: str, branch_name: str, base_branch: str = "main") -> Dict[str, any]:
        """
        Create a new branch from base branch.
        
        Args:
            repo_path: Path to repository
            branch_name: Name of new branch
            base_branch: Base branch to create from (default: "main")
            
        Returns:
            Dictionary with success status and message
        """
        # First, fetch latest changes
        self._run_git_command(repo_path, ['git', 'fetch', 'origin'])
        
        # Try to checkout base branch
        checkout_base = self._run_git_command(repo_path, ['git', 'checkout', base_branch])
        if not checkout_base['success']:
            # Try 'master' if 'main' doesn't exist
            if base_branch == "main":
                checkout_base = self._run_git_command(repo_path, ['git', 'checkout', 'master'])
                if checkout_base['success']:
                    base_branch = "master"
            # If still failed, try to checkout from remote
            if not checkout_base['success']:
                checkout_base = self._run_git_command(repo_path, ['git', 'checkout', '-b', base_branch, f'origin/{base_branch}'])
                if not checkout_base['success']:
                    # Try master from remote
                    checkout_base = self._run_git_command(repo_path, ['git', 'checkout', '-b', 'master', 'origin/master'])
                    if checkout_base['success']:
                        base_branch = "master"
        
        # Pull latest changes (if we successfully checked out)
        if checkout_base['success']:
            self._run_git_command(repo_path, ['git', 'pull', 'origin', base_branch])
        
        # Create and checkout new branch from current branch
        create_branch = self._run_git_command(repo_path, ['git', 'checkout', '-b', branch_name])
        
        if create_branch['success']:
            return {
                'success': True,
                'message': f'Branch {branch_name} created successfully',
                'branch_name': branch_name
            }
        else:
            return {
                'success': False,
                'message': f'Failed to create branch: {create_branch["stderr"]}',
                'error': create_branch['stderr']
            }
    
    def commit_changes(
        self,
        repo_path: str,
        files_to_commit: List[str],
        commit_message: str,
        author_name: str = "ICSF Security Fix Bot",
        author_email: str = "security-fix-bot@icsf.local",
        include_all: bool = False
    ) -> Dict[str, any]:
        """
        Commit changes to the repository.
        
        Args:
            repo_path: Path to repository
            files_to_commit: List of file paths to commit (relative to repo root)
            commit_message: Commit message
            author_name: Author name for commit
            author_email: Author email for commit
            include_all: If True, stage ALL changes in repo regardless of files_to_commit
            
        Returns:
            Dictionary with success status and message
        """
        # Configure git user if not already set (required for commits)
        try:
            # Check if user.name is set
            name_check = self._run_git_command(repo_path, ['git', 'config', 'user.name'])
            if not name_check['success'] or not name_check['stdout'].strip():
                self._run_git_command(repo_path, ['git', 'config', 'user.name', author_name])
                logger.info(f"[PRManagerService] Configured git user.name: {author_name}")
            
            # Check if user.email is set
            email_check = self._run_git_command(repo_path, ['git', 'config', 'user.email'])
            if not email_check['success'] or not email_check['stdout'].strip():
                self._run_git_command(repo_path, ['git', 'config', 'user.email', author_email])
                logger.info(f"[PRManagerService] Configured git user.email: {author_email}")
        except Exception as e:
            logger.warning(f"[PRManagerService] Error configuring git user: {str(e)}")
        
        # Stage files
        staged_count = 0
        if include_all:
            add_result = self._run_git_command(repo_path, ['git', 'add', '-A'])
            if add_result['success']:
                staged_count = 1 # Mark as having staged something
                logger.info("[PRManagerService] Staged all changes using git add -A")
            else:
                logger.warning(f"[PRManagerService] Failed to stage all changes: {add_result['stderr']}")
        else:
            for file_path in files_to_commit:
                full_path = os.path.join(repo_path, file_path)
                if os.path.exists(full_path):
                    add_result = self._run_git_command(repo_path, ['git', 'add', file_path])
                    if add_result['success']:
                        staged_count += 1
                        logger.debug(f"[PRManagerService] Staged {file_path}")
                    else:
                        error_msg = add_result['stderr'].strip() if add_result['stderr'].strip() else 'Unknown error'
                        logger.warning(f"[PRManagerService] Failed to stage {file_path}: {error_msg}")
                else:
                    logger.warning(f"[PRManagerService] File does not exist: {full_path}")
        
        if staged_count == 0:
            return {
                'success': False,
                'message': 'No files were staged for commit',
                'error': 'None of the specified files exist or could be staged'
            }
        
        # Check if there are changes to commit
        status_result = self._run_git_command(repo_path, ['git', 'status', '--porcelain'])
        if not status_result['stdout'].strip():
            return {
                'success': False,
                'message': 'No changes to commit',
                'error': 'All files are already committed or unchanged. Files may have been committed in a previous run.'
            }
        
        # Commit changes
        commit_result = self._run_git_command(
            repo_path,
            [
                'git', 'commit',
                '-m', commit_message,
                '--author', f'{author_name} <{author_email}>'
            ]
        )
        
        if commit_result['success']:
            commit_hash = commit_result['stdout'].strip() if commit_result['stdout'].strip() else 'N/A'
            logger.info(f"[PRManagerService] Successfully committed changes: {commit_hash}")
            return {
                'success': True,
                'message': 'Changes committed successfully',
                'commit_hash': commit_hash
            }
        else:
            # Provide more detailed error message
            error_msg = commit_result['stderr'].strip() if commit_result['stderr'].strip() else ''
            if not error_msg:
                error_msg = commit_result['stdout'].strip() if commit_result['stdout'].strip() else 'Unknown commit error'
            
            # If still empty, provide a default message
            if not error_msg:
                error_msg = 'Commit failed with no error message. Check git configuration and repository state.'
            
            logger.error(f"[PRManagerService] Commit failed: {error_msg}")
            return {
                'success': False,
                'message': f'Failed to commit: {error_msg}',
                'error': error_msg
            }
    
    def push_branch(self, repo_path: str, branch_name: str, remote: str = "origin") -> Dict[str, any]:
        """
        Push branch to remote repository.
        
        Args:
            repo_path: Path to repository
            branch_name: Name of branch to push
            remote: Remote name (default: "origin")
            
        Returns:
            Dictionary with success status and message
        """
        push_result = self._run_git_command(
            repo_path,
            ['git', 'push', '-u', remote, branch_name],
            timeout=120  # Longer timeout for push
        )
        
        if push_result['success']:
            return {
                'success': True,
                'message': f'Branch {branch_name} pushed successfully',
                'branch_name': branch_name
            }
        else:
            return {
                'success': False,
                'message': f'Failed to push branch: {push_result["stderr"]}',
                'error': push_result['stderr']
            }
    
    async def create_pull_request(
        self,
        owner: str,
        repo: str,
        title: str,
        body: str,
        head_branch: str,
        base_branch: str = "main"
    ) -> Dict[str, any]:
        """
        Create a Pull Request on GitHub.
        
        Args:
            owner: Repository owner (username or organization)
            repo: Repository name
            title: PR title
            body: PR description/body
            head_branch: Branch with changes
            base_branch: Base branch to merge into (default: "main")
            
        Returns:
            Dictionary with PR details or error
        """
        if not self.token:
            return {
                'success': False,
                'message': 'GitHub token is required to create a pull request',
                'error': 'Token not provided during PRManagerService initialization'
            }
        
        url = f"{self.BASE_URL}/repos/{owner}/{repo}/pulls"
        
        payload = {
            "title": title,
            "body": body,
            "head": head_branch,
            "base": base_branch
        }
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    headers=self.headers,
                    json=payload,
                    timeout=30.0
                )
                
                if response.status_code == 201:
                    pr_data = response.json()
                    return {
                        'success': True,
                        'pr_number': pr_data.get('number'),
                        'pr_url': pr_data.get('html_url'),
                        'pr_id': pr_data.get('id'),
                        'message': f'Pull Request #{pr_data.get("number")} created successfully',
                        'pr_data': pr_data
                    }
                else:
                    error_data = response.json() if response.content else {}
                    return {
                        'success': False,
                        'message': f'Failed to create PR: {error_data.get("message", response.text)}',
                        'error': error_data.get("message", f"HTTP {response.status_code}"),
                        'status_code': response.status_code
                    }
        except Exception as e:
            return {
                'success': False,
                'message': f'Error creating PR: {str(e)}',
                'error': str(e)
            }
    
    def _validate_compilation(self, repo_path: str, files_modified: List[str]) -> Dict[str, Any]:

        """
        Validate that the modified Java files can compile (if it's a Maven/Gradle project).
        This is a best-effort check - doesn't fail PR creation if compilation check fails.
        
        Args:
            repo_path: Path to repository
            files_modified: List of modified file paths
            
        Returns:
            Dictionary with validation result
        """
        # Only check Java files
        java_files = [f for f in files_modified if f.endswith('.java')]
        if not java_files:
            return {'success': True, 'message': 'No Java files to validate'}
        
        # Check if it's a Maven project
        pom_path = os.path.join(repo_path, 'pom.xml')
        is_maven = os.path.exists(pom_path)
        
        if not is_maven:
            # Not a Maven project, skip compilation check
            return {'success': True, 'message': 'Not a Maven project, skipping compilation check'}
        
        try:
            # Try to compile (dry run or compile check)
            # Note: This might take time, so we do it as a best-effort check
            import sys
            result = subprocess.run(
                ['mvn', 'compile', '-q'],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=60,  # 1 minute timeout
                shell=(sys.platform == "win32")
            )
            
            if result.returncode == 0:
                return {
                    'success': True,
                    'message': 'Code compiles successfully'
                }
            else:
                # Extract meaningful error message from compilation output
                error_msg = result.stderr.strip() if result.stderr else result.stdout.strip()
                # Get first few lines of error for clarity
                error_lines = error_msg.split('\n')[:10]
                error_summary = '\n'.join(error_lines)
                
                return {
                    'success': False,
                    'message': f'Compilation check failed. See error details below.',
                    'error': error_summary,
                    'full_error': result.stderr  # Keep full error for debugging
                }

        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'message': 'Compilation check timed out (this is non-blocking)'
            }
        except FileNotFoundError:
            # Maven not installed, skip check
            return {
                'success': True,
                'message': 'Maven not found, skipping compilation check'
            }
        except Exception as e:
            # Any other error - don't fail the PR creation
            logger.warning(f"[PRManagerService] Compilation check error: {str(e)}")
            return {
                'success': True,  # Don't fail on compilation check errors
                'message': f'Compilation check error (non-blocking): {str(e)}'
            }
    
    def _clean_code_before_validation(self, code: str) -> str:
        """
        Clean code to remove markdown artifacts, separator lines, and other non-code content.
        This is called before validation to ensure we're validating actual code.
        
        Args:
            code: Raw code content that may contain artifacts
            
        Returns:
            Cleaned code content
        """
        if not code:
            return code
        
        lines = code.split('\n')
        cleaned_lines = []
        code_started = False
        
        for line in lines:
            line_stripped = line.strip()
            
            # Skip empty lines before code starts
            if not line_stripped and not code_started:
                continue
            
            # Remove separator lines (===, ---, ___, etc.)
            if re.match(r'^[=\-_]{3,}$', line_stripped):
                continue
            
            # Remove markdown code block markers
            if line_stripped.startswith('```') or line_stripped == '```':
                continue
            
            # Remove markdown headers
            if re.match(r'^#+\s+', line_stripped):
                continue
            
            # Remove file path markers like "FILE:", "FIXED CODE FOR:", etc.
            if re.match(r'^(FILE|FIXED CODE FOR|FILE PATH|PATH):\s*', line_stripped, re.IGNORECASE):
                continue
            
            # Detect start of Java code
            java_start_patterns = [
                r'^package\s+',
                r'^import\s+',
                r'^(public|private|protected|static|final|abstract)\s+',
                r'^(class|interface|enum|@interface)\s+',
                r'^@\w+',
                r'^//',
                r'^/\*',
            ]
            
            if not code_started:
                if any(re.match(pattern, line_stripped) for pattern in java_start_patterns):
                    code_started = True
                elif any(char in line_stripped for char in ['{', '}', ';', '(', ')', '=', '@']):
                    # Has Java syntax characters
                    code_started = True
                else:
                    # Skip non-Java lines before code starts
                    continue
            
            # Once code has started, include the line
            if code_started:
                cleaned_lines.append(line)
        
        cleaned_code = '\n'.join(cleaned_lines)
        
        # Remove any remaining markdown artifacts
        cleaned_code = re.sub(r'```java', '', cleaned_code, flags=re.IGNORECASE)
        cleaned_code = re.sub(r'```', '', cleaned_code)
        cleaned_code = re.sub(r'^#+\s+.*$', '', cleaned_code, flags=re.MULTILINE)
        
        # Remove separator lines that might still be present
        lines = cleaned_code.split('\n')
        cleaned_lines = [line for line in lines if not re.match(r'^[=\-_]{3,}$', line.strip())]
        cleaned_code = '\n'.join(cleaned_lines)
        
        # Find the actual start of Java code
        lines = cleaned_code.split('\n')
        start_idx = 0
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            if any(re.match(pattern, line_stripped) for pattern in [
                r'^package\s+',
                r'^import\s+',
                r'^(public|private|protected|static|final|abstract)\s+',
                r'^(class|interface|enum|@interface)\s+',
                r'^@\w+',
                r'^//',
                r'^/\*',
            ]):
                start_idx = i
                break
        
        cleaned_code = '\n'.join(lines[start_idx:])
        
        return cleaned_code.strip()
    
    def _validate_java_code(self, code: str, file_path: str, already_cleaned: bool = False) -> Tuple[bool, Optional[str]]:
        """
        Validate that the Java code is clean and has basic structure.
        
        Args:
            code: Code content to validate
            file_path: File path for context
            already_cleaned: Whether the code has already been cleaned (to avoid redundant cleaning)
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not code or not code.strip():
            return False, "Code is empty"
        
        # Clean the code first to remove any artifacts (unless already cleaned)
        if not already_cleaned:
            code = self._clean_code_before_validation(code)
        
        if not code or not code.strip():
            return False, "Code is empty after cleaning"
        
        code = code.strip()
        
        # For Java files, check basic structure
        if file_path.endswith('.java'):
            # Should start with package, import, or class/interface/enum
            first_line = code.split('\n')[0].strip()
            java_start_patterns = [
                r'^package\s+',
                r'^import\s+',
                r'^(public|private|protected|static|final|abstract)\s+',
                r'^(class|interface|enum|@interface)\s+',
                r'^@\w+',
                r'^//',
                r'^/\*',
            ]
            
            if not any(re.match(pattern, first_line) for pattern in java_start_patterns):
                return False, f"Java file doesn't start with valid Java construct. First line: {first_line[:50]}"
            
            # Check for balanced braces (basic validation)
            open_braces = code.count('{')
            close_braces = code.count('}')
            if open_braces != close_braces:
                return False, f"Unbalanced braces: {open_braces} opening, {close_braces} closing"
            
            # Check for class/interface/enum declaration
            if not re.search(r'\b(class|interface|enum|@interface)\s+\w+', code):
                return False, "Java file doesn't contain class, interface, or enum declaration"
        
        return True, None
    
    def apply_fixed_code(
        self,
        repo_path: str,
        files_modified: List[str],
        fixed_code_map: Dict[str, str]
    ) -> Dict[str, any]:
        """
        Apply fixed code to files in the repository with validation.
        Ensures code is clean and maintains end-to-end functionality.
        
        Args:
            repo_path: Path to repository
            files_modified: List of file paths that were modified
            fixed_code_map: Dictionary mapping file paths to fixed code content
            
        Returns:
            Dictionary with success status and details
        """
        applied_files = []
        failed_files = []
        
        for file_path in files_modified:
            full_path = os.path.join(repo_path, file_path)
            
            if file_path not in fixed_code_map:
                failed_files.append({
                    'file': file_path,
                    'error': 'Fixed code not provided'
                })
                continue
            
            try:
                original_code = fixed_code_map[file_path]
                
                # Clean the code first to remove any markdown artifacts or separator lines
                cleaned_code = self._clean_code_before_validation(original_code)
                
                # Validate the cleaned code before applying (already cleaned, so pass already_cleaned=True)
                is_valid, validation_error = self._validate_java_code(cleaned_code, file_path, already_cleaned=True)
                if not is_valid:
                    failed_files.append({
                        'file': file_path,
                        'error': f'Code validation failed: {validation_error}'
                    })
                    logger.warning(f"[PRManagerService] Code validation failed for {file_path}: {validation_error}")
                    logger.debug(f"[PRManagerService] Original code preview (first 200 chars): {original_code[:200]}")
                    continue
                
                # Use cleaned code for writing
                fixed_code = cleaned_code
                
                # Create directory if it doesn't exist
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                
                # Backup original file if it exists (for safety)
                backup_path = None
                if os.path.exists(full_path):
                    backup_path = f"{full_path}.backup"
                    try:
                        with open(full_path, 'r', encoding='utf-8') as original:
                            with open(backup_path, 'w', encoding='utf-8') as backup:
                                backup.write(original.read())
                    except Exception as backup_error:
                        logger.warning(f"[PRManagerService] Failed to create backup for {file_path}: {backup_error}")
                
                # Write fixed code to file
                with open(full_path, 'w', encoding='utf-8') as f:
                    f.write(fixed_code)
                
                # Verify the file was written correctly
                if not os.path.exists(full_path) or os.path.getsize(full_path) == 0:
                    # Restore backup if write failed
                    if backup_path and os.path.exists(backup_path):
                        with open(backup_path, 'r', encoding='utf-8') as backup:
                            with open(full_path, 'w', encoding='utf-8') as f:
                                f.write(backup.read())
                        os.remove(backup_path)
                    failed_files.append({
                        'file': file_path,
                        'error': 'File write failed or file is empty after write'
                    })
                    continue
                
                # Clean up backup if write was successful
                if backup_path and os.path.exists(backup_path):
                    try:
                        os.remove(backup_path)
                    except Exception:
                        pass  # Ignore backup cleanup errors
                
                applied_files.append(file_path)
                logger.info(f"[PRManagerService] Successfully applied fix to {file_path}")
                
            except Exception as e:
                failed_files.append({
                    'file': file_path,
                    'error': str(e)
                })
                logger.error(f"[PRManagerService] Error applying fix to {file_path}: {str(e)}")
        
        return {
            'success': len(failed_files) == 0,
            'applied_files': applied_files,
            'failed_files': failed_files,
            'message': f'Applied fixes to {len(applied_files)} file(s)'
        }
    
    async def create_pr_for_fix(
        self,
        repo_path: str,
        repo_owner: str,
        repo_name: str,
        files_modified: List[str],
        fixed_code_map: Dict[str, str],
        vulnerability_type: str,
        vulnerability_description: str,
        fix_summary: str,
        base_branch: str = "main",
        include_all_repo_changes: bool = False
    ) -> Dict[str, any]:
        """
        Complete workflow: Apply fixes, create branch, commit, push, and create PR.
        
        Args:
            repo_path: Path to repository
            repo_owner: Repository owner (username or organization)
            repo_name: Repository name
            files_modified: List of file paths that were modified
            fixed_code_map: Dictionary mapping file paths to fixed code content
            vulnerability_type: Type of vulnerability fixed
            vulnerability_description: Description of vulnerability
            fix_summary: Summary of the fix
            base_branch: Base branch to create PR against (default: "main")
            include_all_repo_changes: If True, commit ALL changes in repo, not just fixed_code_map
            
        Returns:
            Dictionary with PR creation result
        """
        try:
            # Filter to only files that actually have fixed code to avoid failures like
            # "Fixed code not provided" for some paths
            files_with_code = [f for f in files_modified if f in fixed_code_map]

            # If nothing has code, we can't create a meaningful PR
            if not files_with_code:
                return {
                    'success': False,
                    'step': 'prepare_fixes',
                    'message': 'No fixed code available for any of the modified files. Cannot create PR.',
                    'error': 'fixed_code_map is empty for all files_modified.'
                }

            # Generate branch name
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            branch_name = f"security-fix-{vulnerability_type.lower().replace(' ', '-')}-{timestamp}"
            
            # Step 1: Create branch
            branch_result = self.create_branch(repo_path, branch_name, base_branch)
            if not branch_result['success']:
                return {
                    'success': False,
                    'step': 'create_branch',
                    'message': branch_result.get('message', 'Failed to create branch'),
                    'error': branch_result.get('error')
                }
            
            # Step 2: Apply fixed code (only to files that actually have code)
            apply_result = self.apply_fixed_code(repo_path, files_with_code, fixed_code_map)
            if not apply_result['success']:
                return {
                    'success': False,
                    'step': 'apply_fixes',
                    'message': apply_result.get('message', 'Failed to apply fixes'),
                    'error': f"Failed files: {apply_result.get('failed_files', [])}"
                }
            
            # Step 2.5: Validate code compilation (for Java projects)
            # This is a best-effort check - doesn't block PR creation
            compilation_check = self._validate_compilation(repo_path, files_with_code)
            compilation_status = "✅ Code validated and applied successfully"
            if not compilation_check.get('success', True):
                error_detail = compilation_check.get('error', compilation_check.get('message', 'Unknown error'))
                logger.warning(
                    f"[PRManagerService] Compilation validation failed:\n"
                    f"Message: {compilation_check.get('message')}\n"
                    f"Error: {error_detail}"
                )
                compilation_status = f"⚠️ Code applied with warnings: {compilation_check.get('message', 'Compilation check had issues')}"
                # End-to-end requirement: ALLOW PR creation even if local compilation fails
                # The CI/CD pipeline on the PR will do the definitive check.
                # We don't want to block PR creation due to environment differences.
                logger.warning("[PRManagerService] Proceeding with PR creation despite compilation warnings.")
                # Do NOT return failure here

            
            # Step 3: Commit changes
            commit_message = f"Security fix: {vulnerability_type}\n\n{vulnerability_description}\n\n{fix_summary}"
            commit_result = self.commit_changes(repo_path, files_with_code, commit_message, include_all=include_all_repo_changes)
            if not commit_result['success']:
                return {
                    'success': False,
                    'step': 'commit',
                    'message': commit_result.get('message', 'Failed to commit changes'),
                    'error': commit_result.get('error')
                }
            
            # Step 4: Push branch
            push_result = self.push_branch(repo_path, branch_name)
            if not push_result['success']:
                return {
                    'success': False,
                    'step': 'push',
                    'message': push_result.get('message', 'Failed to push branch'),
                    'error': push_result.get('error')
                }
            
            # Step 5: Create Pull Request
            pr_title = f"Security Fix: {vulnerability_type}"
            
            pr_body = f"""## Security Vulnerability Fix

**Vulnerability Type:** {vulnerability_type}

**Description:**
{vulnerability_description}

**Files Modified:**
{chr(10).join(f"- {file}" for file in files_with_code)}

**Fix Summary:**
{fix_summary}

**Validation Status:**
{compilation_status}

**End-to-End Functionality:**
✅ This fix has been designed to maintain all existing application functionality
✅ Method signatures and code structure have been preserved
✅ Only security-related changes have been added, no refactoring
✅ The application should run end-to-end after merging this PR

**Next Steps:**
1. Review the changes in this PR
2. Test the application to ensure it runs correctly
3. Merge the PR after approval
4. Re-scan the repository to verify the vulnerability is fixed

---
*This PR was automatically created by ICSF Security Fix System*
*The fix maintains backward compatibility and preserves all existing functionality*
"""
            
            pr_result = await self.create_pull_request(
                owner=repo_owner,
                repo=repo_name,
                title=pr_title,
                body=pr_body,
                head_branch=branch_name,
                base_branch=base_branch
            )
            
            if pr_result['success']:
                return {
                    'success': True,
                    'pr_number': pr_result.get('pr_number'),
                    'pr_url': pr_result.get('pr_url'),
                    'branch_name': branch_name,
                    'message': f'Pull Request #{pr_result.get("pr_number")} created successfully',
                    'files_modified': files_with_code,
                    'commit_message': commit_message
                }
            else:
                return {
                    'success': False,
                    'step': 'create_pr',
                    'message': pr_result.get('message', 'Failed to create PR'),
                    'error': pr_result.get('error'),
                    'branch_name': branch_name,  # Branch was created and pushed, but PR failed
                    'note': 'Branch was created and pushed, but PR creation failed. You can create the PR manually.'
                }
        
        except Exception as e:
            logger.error(f"[PRManagerService] Error in create_pr_for_fix: {str(e)}")
            return {
                'success': False,
                'step': 'unknown',
                'message': f'Error creating PR: {str(e)}',
                'error': str(e)
            }
    
    async def check_pr_mergeability(
        self,
        owner: str,
        repo: str,
        pr_number: int
    ) -> Dict[str, any]:
        """
        Check if a PR can be merged and detect conflicts.
        
        Args:
            owner: Repository owner
            repo: Repository name
            pr_number: PR number
            
        Returns:
            Dictionary with mergeability status
        """
        if not self.token:
            return {
                'success': False,
                'message': 'GitHub token is required',
                'error': 'Token not provided'
            }
        
        url = f"{self.BASE_URL}/repos/{owner}/{repo}/pulls/{pr_number}"
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, headers=self.headers, timeout=30.0)
                
                if response.status_code == 200:
                    pr_data = response.json()
                    mergeable = pr_data.get('mergeable')
                    mergeable_state = pr_data.get('mergeable_state', 'unknown')
                    merged = pr_data.get('merged', False)
                    head_sha = pr_data.get('head', {}).get('sha', '')
                    base_sha = pr_data.get('base', {}).get('sha', '')
                    
                    return {
                        'success': True,
                        'mergeable': mergeable,
                        'mergeable_state': mergeable_state,  # clean, dirty, unstable, blocked, behind, draft
                        'merged': merged,
                        'head_sha': head_sha,
                        'base_sha': base_sha,
                        'has_conflicts': mergeable_state == 'dirty' or mergeable is False,
                        'message': f'PR mergeability: {mergeable_state}'
                    }
                else:
                    error_data = response.json() if response.content else {}
                    return {
                        'success': False,
                        'message': f'Failed to check PR mergeability: {error_data.get("message", response.text)}',
                        'error': error_data.get("message", f"HTTP {response.status_code}")
                    }
        except Exception as e:
            return {
                'success': False,
                'message': f'Error checking PR mergeability: {str(e)}',
                'error': str(e)
            }
    
    def update_branch_with_base(
        self,
        repo_path: str,
        branch_name: str,
        base_branch: str = "main",
        strategy: str = "merge"
    ) -> Dict[str, any]:
        """
        Update branch with latest changes from base branch to resolve conflicts.
        
        Args:
            repo_path: Path to repository
            branch_name: Branch to update
            base_branch: Base branch to merge/rebase from
            strategy: "merge" or "rebase" (default: "merge")
            
        Returns:
            Dictionary with update result
        """
        try:
            # Fetch latest changes
            fetch_result = self._run_git_command(repo_path, ['git', 'fetch', 'origin', base_branch])
            if not fetch_result['success']:
                return {
                    'success': False,
                    'message': f'Failed to fetch {base_branch}: {fetch_result.get("stderr", "Unknown error")}',
                    'error': fetch_result.get('stderr')
                }
            
            # Checkout the branch
            checkout_result = self._run_git_command(repo_path, ['git', 'checkout', branch_name])
            if not checkout_result['success']:
                return {
                    'success': False,
                    'message': f'Failed to checkout branch {branch_name}: {checkout_result.get("stderr", "Unknown error")}',
                    'error': checkout_result.get('stderr')
                }
            
            if strategy == "rebase":
                # Rebase onto base branch
                rebase_result = self._run_git_command(
                    repo_path,
                    ['git', 'rebase', f'origin/{base_branch}'],
                    timeout=120
                )
                
                if not rebase_result['success']:
                    # Check if there are conflicts
                    status_result = self._run_git_command(repo_path, ['git', 'status', '--porcelain'])
                    has_conflicts = 'UU' in status_result.get('stdout', '') or 'AA' in status_result.get('stdout', '')
                    
                    if has_conflicts:
                        return {
                            'success': False,
                            'has_conflicts': True,
                            'message': 'Rebase conflicts detected',
                            'error': rebase_result.get('stderr'),
                            'conflict_files': self._get_conflict_files(repo_path)
                        }
                    else:
                        return {
                            'success': False,
                            'has_conflicts': False,
                            'message': f'Rebase failed: {rebase_result.get("stderr", "Unknown error")}',
                            'error': rebase_result.get('stderr')
                        }
                
                # Push rebased branch (force push required after rebase)
                push_result = self._run_git_command(
                    repo_path,
                    ['git', 'push', 'origin', branch_name, '--force-with-lease'],
                    timeout=120
                )
                
                return {
                    'success': True,
                    'strategy': 'rebase',
                    'message': 'Branch rebased successfully',
                    'push_result': push_result
                }
            else:
                # Merge base branch into current branch
                merge_result = self._run_git_command(
                    repo_path,
                    ['git', 'merge', f'origin/{base_branch}'],
                    timeout=120
                )
                
                if not merge_result['success']:
                    # Check if there are conflicts
                    status_result = self._run_git_command(repo_path, ['git', 'status', '--porcelain'])
                    has_conflicts = 'UU' in status_result.get('stdout', '') or 'AA' in status_result.get('stdout', '')
                    
                    if has_conflicts:
                        return {
                            'success': False,
                            'has_conflicts': True,
                            'message': 'Merge conflicts detected',
                            'error': merge_result.get('stderr'),
                            'conflict_files': self._get_conflict_files(repo_path)
                        }
                    else:
                        return {
                            'success': False,
                            'has_conflicts': False,
                            'message': f'Merge failed: {merge_result.get("stderr", "Unknown error")}',
                            'error': merge_result.get('stderr')
                        }
                
                # Push merged branch
                push_result = self._run_git_command(
                    repo_path,
                    ['git', 'push', 'origin', branch_name],
                    timeout=120
                )
                
                return {
                    'success': True,
                    'strategy': 'merge',
                    'message': 'Branch merged successfully',
                    'push_result': push_result
                }
                
        except Exception as e:
            logger.error(f"[PRManagerService] Error updating branch: {str(e)}")
            return {
                'success': False,
                'message': f'Error updating branch: {str(e)}',
                'error': str(e)
            }
    
    def _get_conflict_files(self, repo_path: str) -> List[str]:
        """Get list of files with merge conflicts."""
        try:
            status_result = self._run_git_command(repo_path, ['git', 'diff', '--name-only', '--diff-filter=U'])
            conflict_files = [
                line.strip() for line in status_result.get('stdout', '').split('\n')
                if line.strip()
            ]
            return conflict_files
        except Exception as e:
            logger.error(f"[PRManagerService] Error getting conflict files: {str(e)}")
            return []
    
    def resolve_conflicts(
        self,
        repo_path: str,
        conflict_files: List[str],
        strategy: str = "ours"
    ) -> Dict[str, any]:
        """
        Resolve merge conflicts automatically.
        
        Args:
            repo_path: Path to repository
            conflict_files: List of files with conflicts
            strategy: Resolution strategy:
                - "ours": Keep our changes (the branch being merged)
                - "theirs": Keep their changes (the base branch)
                - "both": Keep both (may require manual editing)
                
        Returns:
            Dictionary with resolution result
        """
        try:
            resolved_files = []
            failed_files = []
            
            for file_path in conflict_files:
                full_path = os.path.join(repo_path, file_path)
                
                if not os.path.exists(full_path):
                    failed_files.append({'file': file_path, 'error': 'File not found'})
                    continue
                
                try:
                    if strategy == "ours":
                        # Keep our version (the branch changes)
                        checkout_result = self._run_git_command(
                            repo_path,
                            ['git', 'checkout', '--ours', file_path]
                        )
                        if checkout_result['success']:
                            self._run_git_command(repo_path, ['git', 'add', file_path])
                            resolved_files.append(file_path)
                        else:
                            failed_files.append({'file': file_path, 'error': checkout_result.get('stderr')})
                    
                    elif strategy == "theirs":
                        # Keep their version (the base branch changes)
                        checkout_result = self._run_git_command(
                            repo_path,
                            ['git', 'checkout', '--theirs', file_path]
                        )
                        if checkout_result['success']:
                            self._run_git_command(repo_path, ['git', 'add', file_path])
                            resolved_files.append(file_path)
                        else:
                            failed_files.append({'file': file_path, 'error': checkout_result.get('stderr')})
                    
                    elif strategy == "both":
                        # This would require manual editing - mark as needing attention
                        failed_files.append({
                            'file': file_path,
                            'error': 'Both strategy requires manual resolution',
                            'needs_manual_resolution': True
                        })
                    
                except Exception as e:
                    failed_files.append({'file': file_path, 'error': str(e)})
            
            # Check if all conflicts are resolved
            status_result = self._run_git_command(repo_path, ['git', 'status', '--porcelain'])
            remaining_conflicts = 'UU' in status_result.get('stdout', '') or 'AA' in status_result.get('stdout', '')
            
            return {
                'success': len(failed_files) == 0 and not remaining_conflicts,
                'resolved_files': resolved_files,
                'failed_files': failed_files,
                'remaining_conflicts': remaining_conflicts,
                'message': f'Resolved {len(resolved_files)} file(s), {len(failed_files)} failed'
            }
            
        except Exception as e:
            logger.error(f"[PRManagerService] Error resolving conflicts: {str(e)}")
            return {
                'success': False,
                'message': f'Error resolving conflicts: {str(e)}',
                'error': str(e)
            }
    
    async def merge_pr_with_conflict_resolution(
        self,
        owner: str,
        repo: str,
        pr_number: int,
        repo_path: str,
        branch_name: str,
        base_branch: str = "main",
        conflict_resolution_strategy: str = "ours",
        merge_strategy: str = "merge",
        commit_message: Optional[str] = None
    ) -> Dict[str, any]:
        """
        Merge a PR with automatic conflict resolution.
        
        This method:
        1. Checks if PR is mergeable
        2. If conflicts exist, updates branch with base branch
        3. Resolves conflicts automatically
        4. Commits resolution
        5. Merges the PR
        
        Args:
            owner: Repository owner
            repo: Repository name
            pr_number: PR number
            repo_path: Path to local repository
            branch_name: Branch name of the PR
            base_branch: Base branch (default: "main")
            conflict_resolution_strategy: "ours", "theirs", or "both" (default: "ours")
            merge_strategy: "merge" or "rebase" for updating branch (default: "merge")
            commit_message: Optional commit message for merge
            
        Returns:
            Dictionary with merge result
        """
        if not self.token:
            return {
                'success': False,
                'message': 'GitHub token is required',
                'error': 'Token not provided'
            }
        
        try:
            # Step 1: Check PR mergeability
            logger.info(f"[PRManagerService] Checking mergeability for PR #{pr_number}")
            mergeability = await self.check_pr_mergeability(owner, repo, pr_number)
            
            if not mergeability.get('success'):
                return mergeability
            
            if mergeability.get('merged'):
                return {
                    'success': True,
                    'message': 'PR is already merged',
                    'already_merged': True
                }
            
            # Step 2: If PR has conflicts, resolve them
            if mergeability.get('has_conflicts') or mergeability.get('mergeable_state') == 'dirty':
                logger.info(f"[PRManagerService] PR has conflicts, attempting to resolve...")
                
                # Update branch with base branch
                update_result = self.update_branch_with_base(
                    repo_path=repo_path,
                    branch_name=branch_name,
                    base_branch=base_branch,
                    strategy=merge_strategy
                )
                
                if update_result.get('has_conflicts'):
                    # Resolve conflicts
                    conflict_files = update_result.get('conflict_files', [])
                    logger.info(f"[PRManagerService] Resolving conflicts in {len(conflict_files)} file(s)...")
                    
                    resolution_result = self.resolve_conflicts(
                        repo_path=repo_path,
                        conflict_files=conflict_files,
                        strategy=conflict_resolution_strategy
                    )
                    
                    if not resolution_result.get('success'):
                        return {
                            'success': False,
                            'message': 'Failed to resolve conflicts',
                            'conflict_files': conflict_files,
                            'resolution_result': resolution_result,
                            'error': 'Some conflicts could not be resolved automatically'
                        }
                    
                    # Commit the resolution
                    if resolution_result.get('resolved_files'):
                        commit_msg = commit_message or f"Resolve merge conflicts using {conflict_resolution_strategy} strategy"
                        commit_result = self._run_git_command(
                            repo_path,
                            ['git', 'commit', '-m', commit_msg]
                        )
                        
                        if not commit_result['success']:
                            return {
                                'success': False,
                                'message': 'Failed to commit conflict resolution',
                                'error': commit_result.get('stderr')
                            }
                        
                        # Push resolved changes
                        push_result = self._run_git_command(
                            repo_path,
                            ['git', 'push', 'origin', branch_name],
                            timeout=120
                        )
                        
                        if not push_result['success']:
                            return {
                                'success': False,
                                'message': 'Failed to push conflict resolution',
                                'error': push_result.get('stderr')
                            }
                        
                        logger.info(f"[PRManagerService] Conflicts resolved and pushed")
                        
                        # Wait a moment for GitHub to update PR status
                        import asyncio
                        await asyncio.sleep(2)
                        
                        # Re-check mergeability
                        mergeability = await self.check_pr_mergeability(owner, repo, pr_number)
            
            # Step 3: Merge the PR
            if not mergeability.get('mergeable') and not mergeability.get('has_conflicts'):
                return {
                    'success': False,
                    'message': f'PR is not mergeable: {mergeability.get("mergeable_state", "unknown")}',
                    'mergeable_state': mergeability.get('mergeable_state'),
                    'error': 'PR cannot be merged'
                }
            
            merge_url = f"{self.BASE_URL}/repos/{owner}/{repo}/pulls/{pr_number}/merge"
            merge_payload = {
                "commit_title": commit_message or f"Merge PR #{pr_number}",
                "commit_message": f"Automatically merged PR #{pr_number} with conflict resolution"
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.put(
                    merge_url,
                    headers=self.headers,
                    json=merge_payload,
                    timeout=30.0
                )
                
                if response.status_code == 200:
                    merge_data = response.json()
                    return {
                        'success': True,
                        'message': f'PR #{pr_number} merged successfully',
                        'merged': True,
                        'sha': merge_data.get('sha'),
                        'merged_at': merge_data.get('merged_at')
                    }
                elif response.status_code == 405:
                    # Method not allowed - PR might not be mergeable
                    error_data = response.json() if response.content else {}
                    return {
                        'success': False,
                        'message': f'Cannot merge PR: {error_data.get("message", "PR is not mergeable")}',
                        'error': error_data.get("message", "Method not allowed"),
                        'mergeable_state': mergeability.get('mergeable_state')
                    }
                else:
                    error_data = response.json() if response.content else {}
                    return {
                        'success': False,
                        'message': f'Failed to merge PR: {error_data.get("message", response.text)}',
                        'error': error_data.get("message", f"HTTP {response.status_code}"),
                        'status_code': response.status_code
                    }
                    
        except Exception as e:
            logger.error(f"[PRManagerService] Error merging PR with conflict resolution: {str(e)}")
            return {
                'success': False,
                'message': f'Error merging PR: {str(e)}',
                'error': str(e)
            }

