"""
Fix Orchestrator Service

Coordinates the multi-agent vulnerability fixing workflow:
Agent 1 (Vulnerability Analyzer) → Agent 2 (Code Context) → 
Agent 3 (Fix Strategy) → Agent 4 (Code Fix) → 
Agent 5 (Safety Validator) → Agent 6 (Explanation)

This orchestrator manages the flow of data between agents and tracks the overall fix process.

NOTE: This does NOT run the testing agent. The testing agent is a separate service
at /api/testing/run and should be run independently for test generation and coverage analysis.
"""
import logging
import time
from typing import Dict, Any, Optional, List
from pathlib import Path

# Package-relative imports so this orchestrator works from both source and installed wheel.
from ..models.agent_models import (
    VulnerabilityFixRequest,
    VulnerabilityAnalysis,
    CodeContext,
    FixStrategy,
    CodeFix,
    SafetyValidation,
    FixExplanation,
    FixOrchestrationResult,
    VulnerabilitySeverity,
)
from .bedrock_service import BedrockService
from ..agents.code_context_agent import CodeContextAgent
from ..agents.fix_strategy_agent import FixStrategyAgent
from ..agents.code_fix_agent import CodeFixAgent
from ..agents.safety_validator_agent import SafetyValidatorAgent
from .fix_validator_service import FixValidatorService
from .pr_manager_service import PRManagerService

logger = logging.getLogger(__name__)


class FixOrchestrator:
    """Orchestrator for multi-agent vulnerability fixing workflow"""
    
    def __init__(self, bedrock_service: BedrockService):
        """
        Initialize Fix Orchestrator.
        
        Args:
            bedrock_service: BedrockService instance for all agents
        """
        self.bedrock_service = bedrock_service
        self.orchestrator_name = "FixOrchestrator"
        
        # Initialize agents (Agent 1 & 6 removed as redundant)
        self.agent2 = CodeContextAgent(bedrock_service)
        self.agent3 = FixStrategyAgent(bedrock_service)
        self.agent4 = CodeFixAgent(bedrock_service)
        self.agent5 = SafetyValidatorAgent(bedrock_service)
        
        # Initialize validation service
        self.fix_validator = FixValidatorService(bedrock_service)
        self.pr_manager = PRManagerService()
        
        logger.info(f"[{self.orchestrator_name}] Initialized with core fixing agents and validation service")
    
    async def orchestrate_fix(
        self,
        request: VulnerabilityFixRequest,
        stop_at_agent: Optional[int] = None,
        validate_fix: bool = False,
        max_validation_retries: int = 1,
        all_repositories_info: Optional[List[Dict]] = None
    ) -> FixOrchestrationResult:
        """
        Orchestrate the complete vulnerability fixing workflow.
        
        Args:
            request: VulnerabilityFixRequest with vulnerability details
            stop_at_agent: Optional agent number to stop at (for testing/incremental processing)
            validate_fix: Whether to validate fixes with build/tests (default: False, non-blocking)
            max_validation_retries: Number of validation retry attempts (default: 1)
            all_repositories_info: Optional list of dictionaries containing information about all repositories in the workspace.
            
        Returns:
            FixOrchestrationResult with results from all executed agents
        """
        start_time = time.time()
        
        # Enhanced logging with vulnerability context
        vuln_type = getattr(request, 'vulnerability_type', 'Unknown')
        vuln_desc = getattr(request, 'description', '')[:100] if hasattr(request, 'description') else ''
        logger.info(
            f"[{self.orchestrator_name}] ========================================"
        )
        logger.info(
            f"[{self.orchestrator_name}] 🚀 STARTING FIX ORCHESTRATION"
        )
        logger.info(
            f"[{self.orchestrator_name}] Vulnerability Type: {vuln_type}"
        )
        logger.info(
            f"[{self.orchestrator_name}] File: {request.file_path}:{request.line_number}"
        )
        logger.info(
            f"[{self.orchestrator_name}] Repository: {Path(request.repo_path).name}"
        )
        if vuln_desc:
            logger.info(
                f"[{self.orchestrator_name}] Description: {vuln_desc}..."
            )
        logger.info(
            f"[{self.orchestrator_name}] ========================================"
        )
        
        result = FixOrchestrationResult(
            vulnerability_request=request,
            overall_status="pending"
        )
        
        errors = []
        
        # Validate repository path exists
        if not Path(request.repo_path).exists():
            error_msg = f"Repository path does not exist: {request.repo_path}"
            logger.error(f"[{self.orchestrator_name}] {error_msg}")
            result.overall_status = "failed"
            result.errors = [error_msg]
            return result
        
        # Validate vulnerable file exists
        vulnerable_file_path = Path(request.repo_path) / request.file_path
        if not vulnerable_file_path.exists():
            error_msg = f"Vulnerable file does not exist: {vulnerable_file_path}"
            logger.error(f"[{self.orchestrator_name}] {error_msg}")
            result.overall_status = "failed"
            result.errors = [error_msg]
            return result
        
        # =================================================================
        # AGENT 1: Vulnerability Analyzer (REMOVED - Using skeleton)
        # =================================================================
        logger.info(f"[{self.orchestrator_name}] ⏩ Skipping Agent 1 (Using direct request context)")
        vulnerability_analysis = self._create_skeleton_analysis(request)
        result.vulnerability_analysis = vulnerability_analysis
        
        # =================================================================
        # AGENT 2: Code Context Agent
        # =================================================================
        if stop_at_agent is None or stop_at_agent >= 2:
            try:
                logger.info(f"[{self.orchestrator_name}] ┌─────────────────────────────────────────┐")
                logger.info(f"[{self.orchestrator_name}] │ 🔍 AGENT 2: Code Context Agent          │")
                logger.info(f"[{self.orchestrator_name}] └─────────────────────────────────────────┘")
                logger.info(f"[{self.orchestrator_name}] 📋 Task: Analyzing code context and dependencies")
                logger.info(f"[{self.orchestrator_name}] 🔍 File: {request.file_path}")
                logger.info(f"[{self.orchestrator_name}] 🔗 Finding intra-repo and inter-repo dependencies...")
                agent2_start = time.time()
                
                # AGENT 2: Code Context Agent
                logger.info("Step 2: Analyzing code context...")
                code_context = await self.agent2.analyze(
                    request=request,
                    vulnerability_analysis=vulnerability_analysis,
                    all_repositories_info=all_repositories_info
                )
                result.code_context = code_context
                
                agent2_time = time.time() - agent2_start
                logger.info(
                    f"[{self.orchestrator_name}] ✅ Agent 2 completed in {agent2_time:.2f}s"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Intra-repo dependencies: {len(code_context.dependent_files_intra)}"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Inter-repo dependencies: {len(code_context.dependent_files_inter)}"
                )
                if code_context.class_name:
                    logger.info(
                        f"[{self.orchestrator_name}]    └─ Class: {code_context.class_name}"
                    )
                if code_context.method_name:
                    logger.info(
                        f"[{self.orchestrator_name}]    └─ Method: {code_context.method_name}"
                    )
                
            except Exception as e:
                error_msg = f"Agent 2 (Code Context Agent) failed: {str(e)}"
                logger.error(f"[{self.orchestrator_name}] {error_msg}")
                errors.append(error_msg)
                result.overall_status = "failed"
                result.errors = errors
                return result
        else:
            code_context = result.code_context # Ensure code_context is defined for later agents
        
        # =================================================================
        # AGENT 3: Fix Strategy Agent
        # =================================================================
        if stop_at_agent is None or stop_at_agent >= 3:
            try:
                # Check prerequisites
                if not vulnerability_analysis:
                    error_msg = "Agent 3 requires Agent 1 (Vulnerability Analyzer) results"
                    logger.error(f"[{self.orchestrator_name}] {error_msg}")
                    errors.append(error_msg)
                    result.overall_status = "failed"
                    result.errors = errors
                    return result
                
                if not code_context:
                    error_msg = "Agent 3 requires Agent 2 (Code Context) results"
                    logger.error(f"[{self.orchestrator_name}] {error_msg}")
                    errors.append(error_msg)
                    result.overall_status = "failed"
                    result.errors = errors
                    return result
                
                logger.info(f"[{self.orchestrator_name}] ┌─────────────────────────────────────────┐")
                logger.info(f"[{self.orchestrator_name}] │ 📋 AGENT 3: Fix Strategy Agent          │")
                logger.info(f"[{self.orchestrator_name}] └─────────────────────────────────────────┘")
                logger.info(f"[{self.orchestrator_name}] 📋 Task: Designing comprehensive fix strategy")
                logger.info(f"[{self.orchestrator_name}] 🎯 Identifying files to modify (primary & secondary)...")
                agent3_start = time.time()
                
                # AGENT 3: Fix Strategy Agent
                logger.info("Step 3: Developing fix strategy...")
                fix_strategy = await self.agent3.analyze(
                    request=request,
                    vulnerability_analysis=vulnerability_analysis,
                    code_context=code_context
                )
                result.fix_strategy = fix_strategy
                
                agent3_time = time.time() - agent3_start
                logger.info(
                    f"[{self.orchestrator_name}] ✅ Agent 3 completed in {agent3_time:.2f}s"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Primary files to modify: {len(fix_strategy.files_to_modify_primary)}"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Secondary files to modify: {len(fix_strategy.files_to_modify_secondary)}"
                )
                if fix_strategy.files_to_modify_primary:
                    logger.info(
                        f"[{self.orchestrator_name}]    └─ Primary: {', '.join(fix_strategy.files_to_modify_primary[:3])}"
                        + ("..." if len(fix_strategy.files_to_modify_primary) > 3 else "")
                    )
                
            except Exception as e:
                error_msg = f"Agent 3 (Fix Strategy Agent) failed: {str(e)}"
                logger.error(f"[{self.orchestrator_name}] {error_msg}")
                errors.append(error_msg)
                result.overall_status = "failed"
                result.errors = errors
                return result
        else:
            fix_strategy = result.fix_strategy # Ensure fix_strategy is defined for later agents
        
        # =================================================================
        # AGENT 4: Code Fix Agent
        # =================================================================
        if stop_at_agent is None or stop_at_agent >= 4:
            try:
                # Check prerequisites
                if not fix_strategy:
                    error_msg = "Agent 4 requires Agent 3 (Fix Strategy) results"
                    logger.error(f"[{self.orchestrator_name}] {error_msg}")
                    errors.append(error_msg)
                    result.overall_status = "failed"
                    result.errors = errors
                    return result
                
                logger.info(f"[{self.orchestrator_name}] ┌─────────────────────────────────────────┐")
                logger.info(f"[{self.orchestrator_name}] │ 🔧 AGENT 4: Code Fix Agent              │")
                logger.info(f"[{self.orchestrator_name}] └─────────────────────────────────────────┘")
                logger.info(f"[{self.orchestrator_name}] 📋 Task: Generating actual code fixes")
                logger.info(f"[{self.orchestrator_name}] 💻 Applying fixes to identified files...")
                agent4_start = time.time()
                
                # AGENT 4: Code Fix Agent
                logger.info("Step 4: Generating code fix...")
                code_fix = await self.agent4.fix_code(
                    request=request,
                    vulnerability_analysis=vulnerability_analysis,
                    code_context=code_context,
                    fix_strategy=fix_strategy
                )
                result.code_fix = code_fix
                
                agent4_time = time.time() - agent4_start
                logger.info(
                    f"[{self.orchestrator_name}] ✅ Agent 4 completed in {agent4_time:.2f}s"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Files modified: {len(code_fix.files_modified)}"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Lines changed: {len(code_fix.changed_lines)}"
                )
                if code_fix.files_modified:
                    logger.info(
                        f"[{self.orchestrator_name}]    └─ Modified files: {', '.join(code_fix.files_modified[:3])}"
                        + ("..." if len(code_fix.files_modified) > 3 else "")
                    )
                
                # =================================================================
                # APPLY FIXES TO DISK IMMEDIATELY
                # This ensures fixes are written to the local repository even when
                # validation is disabled, allowing the Atlas testing agent to test
                # the fixed code (not the original code).
                # =================================================================
                if code_fix.files_modified and code_fix.fixed_code:
                    logger.info(f"[{self.orchestrator_name}] 📝 Applying fixes to local repository...")
                    apply_result = self.pr_manager.apply_fixed_code(
                        repo_path=request.repo_path,
                        files_modified=code_fix.files_modified,
                        fixed_code_map=code_fix.fixed_code
                    )
                    
                    if not apply_result['success']:
                        error_msg = f"Failed to apply fixes to disk: {apply_result.get('message', 'Unknown error')}"
                        logger.error(f"[{self.orchestrator_name}] {error_msg}")
                        errors.append(error_msg)
                        result.overall_status = "failed"
                        result.errors = errors
                        return result
                    
                    logger.info(
                        f"[{self.orchestrator_name}] ✅ Successfully applied fixes to {len(apply_result['applied_files'])} file(s)"
                    )
                    if apply_result['applied_files']:
                        logger.info(
                            f"[{self.orchestrator_name}]    └─ Applied files: {', '.join(apply_result['applied_files'][:3])}"
                            + ("..." if len(apply_result['applied_files']) > 3 else "")
                        )
                
                # =================================================================
                # VALIDATION: Validate fixes don't break build/tests (OPTIONAL)
                # NOTE: This is build/test validation, NOT the testing agent.
                # The testing agent is a separate service at /api/testing/run
                # Validation is disabled by default to avoid blocking fixes.
                # =================================================================
                validation_attempt = 1
                if validate_fix and code_fix.files_modified and code_fix.fixed_code:
                    validation_passed = False
                    validation_attempt = 0
                    
                    while not validation_passed and validation_attempt <= max_validation_retries:
                        validation_attempt += 1
                        logger.info(
                            f"[{self.orchestrator_name}] Validation attempt {validation_attempt}/{max_validation_retries + 1}"
                        )
                        
                        # Fixes are already applied above, so we can directly validate
                        # (No need to re-apply fixes here)
                        
                        # Run validation
                        validation_result = self.fix_validator.validate_fix(
                            repo_path=request.repo_path,
                            files_modified=code_fix.files_modified
                        )
                        
                        if validation_result['success']:
                            validation_passed = True
                            logger.info(
                                f"[{self.orchestrator_name}] ✅ Validation passed: "
                                f"Build OK={validation_result['build_ok']}, "
                                f"Tests OK={validation_result['tests_ok']}"
                            )
                            # Store validation result in code_fix metadata
                            if code_fix.metadata is None:
                                code_fix.metadata = {}
                            code_fix.metadata['validation'] = validation_result
                        else:
                            # Validation failed - get feedback
                            feedback = self.fix_validator.get_validation_feedback(validation_result)
                            logger.warning(
                                f"[{self.orchestrator_name}] ⚠️ Validation failed: {validation_result['message']} "
                                f"(attempt {validation_attempt}/{max_validation_retries + 1})"
                            )
                            logger.debug(f"[{self.orchestrator_name}] Feedback: {feedback[:200]}...")
                            
                            # Store validation result even on failure (for debugging/reporting)
                            if code_fix.metadata is None:
                                code_fix.metadata = {}
                            code_fix.metadata['validation'] = validation_result
                            
                            # Only retry if we have attempts remaining
                            if validation_attempt <= max_validation_retries:
                                logger.info(
                                    f"[{self.orchestrator_name}] Retrying validation (attempt {validation_attempt + 1}/{max_validation_retries + 1})..."
                                )
                                # Don't add to errors list - validation failures are warnings, not blocking errors
                                continue
                            else:
                                # All retries exhausted - log warning but don't block the fix
                                logger.warning(
                                    f"[{self.orchestrator_name}] ⚠️ Validation failed after {max_validation_retries + 1} attempts. "
                                    f"Continuing with fix anyway. Build errors: {validation_result.get('message', 'Unknown')}"
                                )
                                # Don't add to errors - validation is informational, not blocking
                                break
                
            except Exception as e:
                error_msg = f"Agent 4 (Code Fix Agent) failed: {str(e)}"
                logger.error(f"[{self.orchestrator_name}] {error_msg}")
                errors.append(error_msg)
                result.overall_status = "failed"
                result.errors = errors
                return result
        else:
            code_fix = result.code_fix # Ensure code_fix is defined for later agents
        
        # =================================================================
        # AGENT 5: Safety Validator Agent
        # =================================================================
        if stop_at_agent is None or stop_at_agent >= 5:
            try:
                # Check prerequisites
                if not code_fix:
                    error_msg = "Agent 5 requires Agent 4 (Code Fix) results"
                    logger.error(f"[{self.orchestrator_name}] {error_msg}")
                    errors.append(error_msg)
                    result.overall_status = "failed"
                    result.errors = errors
                    return result
                
                logger.info(f"[{self.orchestrator_name}] ┌─────────────────────────────────────────┐")
                logger.info(f"[{self.orchestrator_name}] │ ✅ AGENT 5: Safety Validator Agent      │")
                logger.info(f"[{self.orchestrator_name}] └─────────────────────────────────────────┘")
                logger.info(f"[{self.orchestrator_name}] 📋 Task: Validating fix safety and correctness")
                logger.info(f"[{self.orchestrator_name}] 🔒 Checking for breaking changes and security issues...")
                agent5_start = time.time()
                
                # AGENT 5: Safety Validator Agent
                logger.info(f"Step 5: Validating code fix (Try {validation_attempt}/{max_validation_retries + 1})...") # Using validation_attempt from previous block
                safety_validation = await self.agent5.validate(
                    request=request,
                    vulnerability_analysis=vulnerability_analysis,
                    code_context=code_context,
                    fix_strategy=fix_strategy,
                    code_fix=code_fix
                )
                result.safety_validation = safety_validation
                
                agent5_time = time.time() - agent5_start
                validation_status = safety_validation.validation_status.value
                logger.info(
                    f"[{self.orchestrator_name}] ✅ Agent 5 completed in {agent5_time:.2f}s"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Validation status: {validation_status.upper()}"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Correctness score: {safety_validation.correctness_score:.2f}/1.00"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Breaking changes: {'Yes' if safety_validation.breaking_changes else 'No'}"
                )
                logger.info(
                    f"[{self.orchestrator_name}]    └─ Backward compatible: {'Yes' if safety_validation.backward_compatible else 'No'}"
                )
                
            except Exception as e:
                error_msg = f"Agent 5 (Safety Validator Agent) failed: {str(e)}"
                logger.error(f"[{self.orchestrator_name}] {error_msg}")
                errors.append(error_msg)
                result.overall_status = "failed"
                result.errors = errors
                return result
        
        # =================================================================
        # AGENT 6: Explanation Agent (REMOVED)
        # =================================================================
        # skip_explanation is now implicitly true as agent is removed
        
        # =================================================================
        # Finalize result
        # =================================================================
        total_time = time.time() - start_time
        
        if errors:
            result.overall_status = "failed"
            result.errors = errors
        else:
            result.overall_status = "success"
        
        logger.info(f"[{self.orchestrator_name}] ========================================")
        logger.info(f"[{self.orchestrator_name}] 🎯 FIX ORCHESTRATION COMPLETE")
        logger.info(f"[{self.orchestrator_name}] ========================================")
        logger.info(
            f"[{self.orchestrator_name}] Vulnerability: {vuln_type} | {request.file_path}:{request.line_number}"
        )
        logger.info(
            f"[{self.orchestrator_name}] Status: {result.overall_status.upper()}"
        )
        logger.info(
            f"[{self.orchestrator_name}] Total time: {total_time:.2f}s"
        )
        if result.code_fix:
            logger.info(
                f"[{self.orchestrator_name}] Files modified: {len(result.code_fix.files_modified)}"
            )
            logger.info(
                f"[{self.orchestrator_name}] Lines changed: {len(result.code_fix.changed_lines)}"
            )
        if errors:
            logger.error(
                f"[{self.orchestrator_name}] Errors encountered: {len(errors)}"
            )
        logger.info(f"[{self.orchestrator_name}] ========================================")
        
        return result
    
    def get_orchestration_status(self, result: FixOrchestrationResult) -> Dict[str, Any]:
        """
        Get human-readable status of the orchestration.
        
        Args:
            result: FixOrchestrationResult from orchestrate_fix
            
        Returns:
            Dictionary with status information
        """
        status = {
            'overall_status': result.overall_status,
            'agents_completed': [],
            'agents_pending': [],
            'errors': result.errors
        }
        
        if result.code_fix:
            status['agents_completed'].append('Agent 4: Code Fix Agent')
        else:
            status['agents_pending'].append('Agent 4: Code Fix Agent')
        
        if result.safety_validation:
            status['agents_completed'].append('Agent 5: Safety Validator Agent')
        else:
            status['agents_pending'].append('Agent 5: Safety Validator Agent')
            
        return status

    def _create_skeleton_analysis(self, request: VulnerabilityFixRequest) -> VulnerabilityAnalysis:
        """Create a default analysis object from request data for downstream agents"""
        from ..models.agent_models import SecurityImpact
        return VulnerabilityAnalysis(
            vulnerability_type=request.vulnerability_type,
            severity=request.severity,
            description=request.description,
            security_impact=SecurityImpact(
                confidentiality="Impacted",
                integrity="Impacted",
                availability="Potential",
                overall_risk=request.severity.value
            ),
            root_causes=["Security vulnerability identified by scanner"],
            fix_category="Security Fix",
            security_guidelines=["OWASP Top 10", "CWE"],
            typical_fix_approach=request.recommendation or "Follow security best practices"
        )

