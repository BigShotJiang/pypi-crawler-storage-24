"""
Dependency Mapping Service for Java Projects
Analyzes Java source code and Maven dependencies to build dependency graphs.

Logging is kept lightweight: INFO for high-level progress, DEBUG for details.
"""
import os
import re
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Set, Tuple
from pathlib import Path
from collections import defaultdict
import subprocess
import tempfile
import shutil
import logging

logger = logging.getLogger(__name__)


class DependencyService:
    """Service for analyzing Java code dependencies and building dependency graphs"""
    
    @staticmethod
    def parse_java_file(file_path: str) -> Dict:
        """
        Parse a Java file to extract:
        - Package declaration
        - Imports (both same-package and external)
        - Class declarations (including interfaces)
        - Method declarations
        - Class/method references
        - Interface implementations
        - Method calls
        
        Args:
            file_path: Path to the Java file
            
        Returns:
            Dictionary containing parsed information
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            result = {
                'package': None,
                'imports': [],
                'imports_full': [],  # Full import paths
                'classes': [],
                'interfaces': [],
                'methods': [],
                'references': [],
                'instantiations': [],  # new ClassName() patterns
                'method_calls': [],  # Method invocations
                'implements': [],  # Interfaces implemented
                'extends': [],  # Classes extended
                'file_path': file_path
            }
            
            # Extract package declaration
            package_match = re.search(r'package\s+([\w.]+)\s*;', content)
            if package_match:
                result['package'] = package_match.group(1)
            
            # Extract imports (including static imports)
            import_pattern = re.compile(r'import\s+(?:static\s+)?([\w.]+(?:\.[*])?)\s*;')
            imports = import_pattern.findall(content)
            result['imports'] = [imp.replace('.*', '') for imp in imports]
            result['imports_full'] = imports
            
            # Extract class declarations (including public, private, protected, abstract, final)
            class_pattern = re.compile(r'(?:public\s+|private\s+|protected\s+)?(?:abstract\s+|final\s+)?class\s+(\w+)')
            classes = class_pattern.findall(content)
            result['classes'] = classes
            
            # Extract interface declarations
            interface_pattern = re.compile(r'(?:public\s+)?interface\s+(\w+)')
            interfaces = interface_pattern.findall(content)
            result['interfaces'] = interfaces
            
            # Extract implements clause
            implements_pattern = re.compile(r'implements\s+([\w\s,]+)')
            implements_match = implements_pattern.search(content)
            if implements_match:
                impl_classes = [c.strip() for c in implements_match.group(1).split(',')]
                result['implements'] = impl_classes
            
            # Extract extends clause
            extends_pattern = re.compile(r'extends\s+(\w+)')
            extends_match = extends_pattern.search(content)
            if extends_match:
                result['extends'] = [extends_match.group(1)]
            
            # Extract method declarations (improved pattern)
            method_pattern = re.compile(r'(?:public|private|protected|static)\s+(?:[\w<>\[\]]+\s+)?(\w+)\s*\([^)]*\)')
            methods = method_pattern.findall(content)
            result['methods'] = list(set(methods))  # Remove duplicates
            
            # Extract class instantiations (new ClassName() patterns)
            instantiation_pattern = re.compile(r'new\s+([A-Z]\w*)\s*\(')
            instantiations = instantiation_pattern.findall(content)
            result['instantiations'] = list(set(instantiations))
            
            # Extract class references (variable declarations, method parameters, return types)
            # Pattern: Type variableName or Type.method() or Type.field
            class_ref_pattern = re.compile(r'\b([A-Z]\w*)\s+(\w+)\s*[=;,\)]')
            refs = class_ref_pattern.findall(content)
            result['references'] = list(set([ref[0] for ref in refs]))
            
            # Extract method calls (ClassName.method() or object.method())
            method_call_pattern = re.compile(r'(\w+)\.(\w+)\s*\(')
            method_calls = method_call_pattern.findall(content)
            result['method_calls'] = list(set([mc[0] + '.' + mc[1] for mc in method_calls]))
            
            return result
            
        except Exception as e:
            return {
                'package': None,
                'imports': [],
                'imports_full': [],
                'classes': [],
                'interfaces': [],
                'methods': [],
                'references': [],
                'instantiations': [],
                'method_calls': [],
                'implements': [],
                'extends': [],
                'file_path': file_path,
                'error': str(e)
            }
    
    @staticmethod
    def parse_pom_xml(pom_path: str) -> Dict:
        """
        Parse Maven pom.xml to extract dependencies.
        
        Args:
            pom_path: Path to pom.xml file
            
        Returns:
            Dictionary containing Maven dependency information
        """
        try:
            tree = ET.parse(pom_path)
            root = tree.getroot()
            
            # Handle namespace
            ns = {'maven': 'http://maven.apache.org/POM/4.0.0'}
            if root.tag.startswith('{'):
                ns_uri = root.tag[1:].split('}')[0]
                ns = {'maven': ns_uri}
            
            result = {
                'groupId': None,
                'artifactId': None,
                'version': None,
                'dependencies': [],
                'parent': None
            }
            
            # Extract project info
            # Try with namespace first, then without
            group_id_elem = root.find('maven:groupId', ns)
            if group_id_elem is None:
                group_id_elem = root.find('{http://maven.apache.org/POM/4.0.0}groupId')
            if group_id_elem is None:
                group_id_elem = root.find('groupId')
            
            artifact_id_elem = root.find('maven:artifactId', ns)
            if artifact_id_elem is None:
                artifact_id_elem = root.find('{http://maven.apache.org/POM/4.0.0}artifactId')
            if artifact_id_elem is None:
                artifact_id_elem = root.find('artifactId')
            
            version_elem = root.find('maven:version', ns)
            if version_elem is None:
                version_elem = root.find('{http://maven.apache.org/POM/4.0.0}version')
            if version_elem is None:
                version_elem = root.find('version')
            
            if group_id_elem is not None:
                result['groupId'] = group_id_elem.text
            if artifact_id_elem is not None:
                result['artifactId'] = artifact_id_elem.text
            if version_elem is not None:
                result['version'] = version_elem.text
            
            # Extract parent info
            parent_elem = root.find('.//maven:parent', ns) or root.find('parent')
            if parent_elem is not None:
                parent_group = parent_elem.find('maven:groupId', ns) or parent_elem.find('groupId')
                parent_artifact = parent_elem.find('maven:artifactId', ns) or parent_elem.find('artifactId')
                parent_version = parent_elem.find('maven:version', ns) or parent_elem.find('version')
                
                if parent_group is not None and parent_artifact is not None:
                    result['parent'] = {
                        'groupId': parent_group.text,
                        'artifactId': parent_artifact.text,
                        'version': parent_version.text if parent_version is not None else None
                    }
            
            # Extract dependencies
            # Try with namespace first, then without
            deps_elem = root.find('maven:dependencies', ns)
            if deps_elem is None:
                deps_elem = root.find('{http://maven.apache.org/POM/4.0.0}dependencies')
            if deps_elem is None:
                deps_elem = root.find('dependencies')
            
            if deps_elem is not None:
                # Find all dependency elements
                dep_list = deps_elem.findall('maven:dependency', ns)
                if not dep_list:
                    dep_list = deps_elem.findall('{http://maven.apache.org/POM/4.0.0}dependency')
                if not dep_list:
                    dep_list = deps_elem.findall('dependency')
                
                for dep in dep_list:
                    dep_group = dep.find('maven:groupId', ns)
                    if dep_group is None:
                        dep_group = dep.find('{http://maven.apache.org/POM/4.0.0}groupId')
                    if dep_group is None:
                        dep_group = dep.find('groupId')
                    
                    dep_artifact = dep.find('maven:artifactId', ns)
                    if dep_artifact is None:
                        dep_artifact = dep.find('{http://maven.apache.org/POM/4.0.0}artifactId')
                    if dep_artifact is None:
                        dep_artifact = dep.find('artifactId')
                    
                    dep_version = dep.find('maven:version', ns)
                    if dep_version is None:
                        dep_version = dep.find('{http://maven.apache.org/POM/4.0.0}version')
                    if dep_version is None:
                        dep_version = dep.find('version')
                    
                    dep_scope = dep.find('maven:scope', ns)
                    if dep_scope is None:
                        dep_scope = dep.find('{http://maven.apache.org/POM/4.0.0}scope')
                    if dep_scope is None:
                        dep_scope = dep.find('scope')
                    
                    if dep_group is not None and dep_artifact is not None:
                        result['dependencies'].append({
                            'groupId': dep_group.text,
                            'artifactId': dep_artifact.text,
                            'version': dep_version.text if dep_version is not None else None,
                            'scope': dep_scope.text if dep_scope is not None else 'compile'
                        })
            
            return result
            
        except Exception as e:
            return {
                'groupId': None,
                'artifactId': None,
                'version': None,
                'dependencies': [],
                'parent': None,
                'error': str(e)
            }
    
    @staticmethod
    def find_java_files(repo_path: str) -> List[str]:
        """
        Find all Java files in a repository.
        
        Args:
            repo_path: Path to repository root
            
        Returns:
            List of Java file paths (relative to repo root)
        """
        java_files = []
        repo_path_obj = Path(repo_path)
        
        for java_file in repo_path_obj.rglob('*.java'):
            # Skip test files for now (can be made configurable)
            # Only skip if it's in a test directory (src/test) not package names like com.test
            java_file_str = str(java_file).replace('\\', '/').lower()
            # Skip only if it's in src/test directory, not in package names
            if 'src/test' in java_file_str:
                continue
            try:
                relative_path = java_file.relative_to(repo_path_obj)
                java_files.append(str(relative_path).replace('\\', '/'))
            except ValueError:
                continue
        
        return java_files
    
    @staticmethod
    def find_pom_files(repo_path: str) -> List[str]:
        """
        Find all pom.xml files in a repository.
        
        Args:
            repo_path: Path to repository root
            
        Returns:
            List of pom.xml file paths (relative to repo root)
        """
        pom_files = []
        repo_path_obj = Path(repo_path)
        
        for pom_file in repo_path_obj.rglob('pom.xml'):
            try:
                relative_path = pom_file.relative_to(repo_path_obj)
                pom_files.append(str(relative_path).replace('\\', '/'))
            except ValueError:
                continue
        
        return pom_files
    
    @staticmethod
    def build_global_dependency_graph(
        all_repos: List[Dict],
        artifact_index: Optional[Dict[Tuple[str, str], Dict]] = None
    ) -> Tuple[Dict[str, List[Dict]], Dict[str, List[Dict]]]:
        """
        Build global dependency graph with both intra-repo and inter-repo edges (PART 3).
        
        Node identity: (repo_name, file_path)
        
        Args:
            all_repos: List of all repositories with clone_path
            artifact_index: Pre-built Maven artifact index (optional, will build if not provided)
            
        Returns:
            Tuple of (forward_graph, reverse_graph)
            forward_graph: {(repo_name, file_path): [dependencies]}
            reverse_graph: {(repo_name, file_path): [dependents]}
        """
        if artifact_index is None:
            artifact_index = DependencyService.build_maven_artifact_index(all_repos)
        
        forward_graph = defaultdict(list)
        reverse_graph = defaultdict(list)
        
        # Build class-to-file maps for each repository
        repo_class_maps = {}
        repo_parsed_files = {}
        
        for repo in all_repos:
            repo_path = repo.get('clone_path')
            repo_name = repo.get('full_name', repo.get('name', 'unknown'))
            
            if not repo_path or not os.path.exists(repo_path):
                continue
            
            java_files = DependencyService.find_java_files(repo_path)
            parsed_files = {}
            class_to_file_map = {}
            
            for java_file in java_files:
                full_path = os.path.join(repo_path, java_file)
                parsed = DependencyService.parse_java_file(full_path)
                parsed_files[java_file] = parsed
                
                file_package = parsed.get('package', '')
                classes = parsed.get('classes', [])
                interfaces = parsed.get('interfaces', [])
                
                for cls in classes:
                    full_class_name = f"{file_package}.{cls}" if file_package else cls
                    class_to_file_map[cls] = java_file
                    class_to_file_map[full_class_name] = java_file
                
                for iface in interfaces:
                    full_iface_name = f"{file_package}.{iface}" if file_package else iface
                    class_to_file_map[iface] = java_file
                    class_to_file_map[full_iface_name] = java_file
            
            repo_class_maps[repo_name] = class_to_file_map
            repo_parsed_files[repo_name] = parsed_files
        
        # Build dependencies for each file in each repository
        for repo in all_repos:
            repo_path = repo.get('clone_path')
            repo_name = repo.get('full_name', repo.get('name', 'unknown'))
            
            if not repo_path or not os.path.exists(repo_path):
                continue
            
            parsed_files = repo_parsed_files.get(repo_name, {})
            class_to_file_map = repo_class_maps.get(repo_name, {})
            
            for file_path, parsed in parsed_files.items():
                from_node = (repo_name, file_path)
                file_package = parsed.get('package', '')
                
                # Process imports
                for imp_full in parsed.get('imports_full', []):
                    imp = imp_full.replace('.*', '').strip()
                    import_parts = imp.split('.')
                    class_name = import_parts[-1] if import_parts else imp
                    
                    # Try intra-repo first
                    resolved, is_ambiguous, has_maven = DependencyService._resolve_symbol_inter_repo(
                        class_name, imp, class_to_file_map, artifact_index, all_repos, repo_path
                    )
                    
                    if resolved:
                        to_node = (resolved['repo_name'], resolved['file_path'])
                        scope = resolved['scope']
                        
                        confidence = DependencyService._calculate_confidence_score(
                            'import', scope, is_ambiguous, has_maven
                        )
                        
                        edge = {
                            'repo': resolved['repo_name'],
                            'file': resolved['file_path'],
                            'type': 'import',
                            'class': class_name,
                            'scope': scope,
                            'confidence': confidence,
                            'is_ambiguous': is_ambiguous
                        }
                        
                        forward_graph[from_node].append(edge)
                        reverse_graph[to_node].append({
                            **edge,
                            'repo': repo_name,
                            'file': file_path
                        })
                
                # Process instantiations
                for inst_class in parsed.get('instantiations', []):
                    resolved, is_ambiguous, has_maven = DependencyService._resolve_symbol_inter_repo(
                        inst_class, file_package, class_to_file_map, artifact_index, all_repos, repo_path
                    )
                    
                    if resolved and resolved.get('file_path'):
                        to_node = (resolved['repo_name'], resolved['file_path'])
                        scope = resolved['scope']
                        
                        confidence = DependencyService._calculate_confidence_score(
                            'instantiation', scope, is_ambiguous, has_maven
                        )
                        
                        edge = {
                            'repo': resolved['repo_name'],
                            'file': resolved['file_path'],
                            'type': 'instantiation',
                            'class': inst_class,
                            'scope': scope,
                            'confidence': confidence,
                            'is_ambiguous': is_ambiguous
                        }
                        
                        forward_graph[from_node].append(edge)
                        reverse_graph[to_node].append({
                            **edge,
                            'repo': repo_name,
                            'file': file_path
                        })
                
                # Process class references
                for ref_class in parsed.get('references', []):
                    resolved, is_ambiguous, has_maven = DependencyService._resolve_symbol_inter_repo(
                        ref_class, file_package, class_to_file_map, artifact_index, all_repos, repo_path
                    )
                    
                    if resolved and resolved.get('file_path'):
                        to_node = (resolved['repo_name'], resolved['file_path'])
                        scope = resolved['scope']
                        
                        confidence = DependencyService._calculate_confidence_score(
                            'class_reference', scope, is_ambiguous, has_maven
                        )
                        
                        edge = {
                            'repo': resolved['repo_name'],
                            'file': resolved['file_path'],
                            'type': 'class_reference',
                            'class': ref_class,
                            'scope': scope,
                            'confidence': confidence,
                            'is_ambiguous': is_ambiguous
                        }
                        
                        forward_graph[from_node].append(edge)
                        reverse_graph[to_node].append({
                            **edge,
                            'repo': repo_name,
                            'file': file_path
                        })
                
                # Process implements
                for impl in parsed.get('implements', []):
                    impl = impl.strip()
                    resolved, is_ambiguous, has_maven = DependencyService._resolve_symbol_inter_repo(
                        impl, file_package, class_to_file_map, artifact_index, all_repos, repo_path
                    )
                    
                    if resolved and resolved.get('file_path'):
                        to_node = (resolved['repo_name'], resolved['file_path'])
                        scope = resolved['scope']
                        
                        confidence = DependencyService._calculate_confidence_score(
                            'implements', scope, is_ambiguous, has_maven
                        )
                        
                        edge = {
                            'repo': resolved['repo_name'],
                            'file': resolved['file_path'],
                            'type': 'implements',
                            'interface': impl,
                            'scope': scope,
                            'confidence': confidence,
                            'is_ambiguous': is_ambiguous
                        }
                        
                        forward_graph[from_node].append(edge)
                        reverse_graph[to_node].append({
                            **edge,
                            'repo': repo_name,
                            'file': file_path
                        })
                
                # Process extends
                for ext in parsed.get('extends', []):
                    resolved, is_ambiguous, has_maven = DependencyService._resolve_symbol_inter_repo(
                        ext, file_package, class_to_file_map, artifact_index, all_repos, repo_path
                    )
                    
                    if resolved and resolved.get('file_path'):
                        to_node = (resolved['repo_name'], resolved['file_path'])
                        scope = resolved['scope']
                        
                        confidence = DependencyService._calculate_confidence_score(
                            'extends', scope, is_ambiguous, has_maven
                        )
                        
                        edge = {
                            'repo': resolved['repo_name'],
                            'file': resolved['file_path'],
                            'type': 'extends',
                            'class': ext,
                            'scope': scope,
                            'confidence': confidence,
                            'is_ambiguous': is_ambiguous
                        }
                        
                        forward_graph[from_node].append(edge)
                        reverse_graph[to_node].append({
                            **edge,
                            'repo': repo_name,
                            'file': file_path
                        })
        
        return dict(forward_graph), dict(reverse_graph)
    
    @staticmethod
    def build_intra_repo_dependencies(repo_path: str) -> Dict[str, List[Dict]]:
        """
        Build intra-repository dependency map (file-to-file dependencies within same repo).
        
        Args:
            repo_path: Path to repository root
            
        Returns:
            Dictionary mapping file paths to their dependencies
            Format: {file_path: [{'file': dep_file, 'type': dep_type}, ...]}
        """
        java_files = DependencyService.find_java_files(repo_path)
        dependency_map = defaultdict(list)
        
        # Parse all Java files
        parsed_files = {}
        for java_file in java_files:
            full_path = os.path.join(repo_path, java_file)
            parsed = DependencyService.parse_java_file(full_path)
            parsed_files[java_file] = parsed
        
        # Build a map of class names to files for faster lookup
        class_to_file_map = {}
        for file_path, parsed in parsed_files.items():
            file_package = parsed.get('package', '')
            classes = parsed.get('classes', [])
            interfaces = parsed.get('interfaces', [])
            
            # Map class names to files (with package context)
            for cls in classes:
                full_class_name = f"{file_package}.{cls}" if file_package else cls
                class_to_file_map[cls] = file_path  # Simple name
                class_to_file_map[full_class_name] = file_path  # Full name
            
            for iface in interfaces:
                full_iface_name = f"{file_package}.{iface}" if file_package else iface
                class_to_file_map[iface] = file_path
                class_to_file_map[full_iface_name] = file_path
        
        # Build dependency map
        for file_path, parsed in parsed_files.items():
            file_package = parsed.get('package', '')
            file_classes = parsed.get('classes', [])
            file_interfaces = parsed.get('interfaces', [])
            
            # Check imports to find dependencies
            for imp_full in parsed.get('imports_full', []):
                imp = imp_full.replace('.*', '')
                # Try to find which file this import refers to
                for other_file, other_parsed in parsed_files.items():
                    if other_file == file_path:
                        continue
                    
                    other_package = other_parsed.get('package', '')
                    other_classes = other_parsed.get('classes', [])
                    other_interfaces = other_parsed.get('interfaces', [])
                    
                    # Check if import matches this file's package/class
                    if imp.startswith(other_package) or imp == other_package:
                        # Extract class name from import
                        import_parts = imp.split('.')
                        class_name = import_parts[-1] if import_parts else imp
                        
                        if class_name in other_classes or class_name in other_interfaces:
                            dependency_map[file_path].append({
                                'file': other_file,
                                'type': 'import',
                                'class': class_name,
                                'package': other_package
                            })
            
            # Check instantiations (new ClassName())
            for inst_class in parsed.get('instantiations', []):
                if inst_class in class_to_file_map:
                    dep_file = class_to_file_map[inst_class]
                    if dep_file != file_path:
                        dependency_map[file_path].append({
                            'file': dep_file,
                            'type': 'instantiation',
                            'class': inst_class,
                            'scope': 'intra-repo',
                            'confidence': DependencyService._calculate_confidence_score('instantiation', 'intra-repo')
                        })
            
            # Check class references (variable declarations, parameters)
            for ref_class in parsed.get('references', []):
                if ref_class in class_to_file_map:
                    dep_file = class_to_file_map[ref_class]
                    if dep_file != file_path:
                        dependency_map[file_path].append({
                            'file': dep_file,
                            'type': 'class_reference',
                            'class': ref_class,
                            'scope': 'intra-repo',
                            'confidence': DependencyService._calculate_confidence_score('class_reference', 'intra-repo')
                        })
            
            # Check interface implementations
            for impl in parsed.get('implements', []):
                impl = impl.strip()
                if impl in class_to_file_map:
                    dep_file = class_to_file_map[impl]
                    if dep_file != file_path:
                        dependency_map[file_path].append({
                            'file': dep_file,
                            'type': 'implements',
                            'interface': impl,
                            'scope': 'intra-repo',
                            'confidence': DependencyService._calculate_confidence_score('implements', 'intra-repo')
                        })
            
            # Check class extensions
            for ext in parsed.get('extends', []):
                if ext in class_to_file_map:
                    dep_file = class_to_file_map[ext]
                    if dep_file != file_path:
                        dependency_map[file_path].append({
                            'file': dep_file,
                            'type': 'extends',
                            'class': ext,
                            'scope': 'intra-repo',
                            'confidence': DependencyService._calculate_confidence_score('extends', 'intra-repo')
                        })
            
            # Check same-package dependencies (files in same package can reference each other)
            if file_package:
                for other_file, other_parsed in parsed_files.items():
                    if other_file == file_path:
                        continue
                    other_package = other_parsed.get('package', '')
                    if other_package == file_package:
                        # Same package - check if classes are referenced
                        other_classes = other_parsed.get('classes', [])
                        for cls in other_classes:
                            if cls in parsed.get('references', []) or cls in parsed.get('instantiations', []):
                                dependency_map[file_path].append({
                                    'file': other_file,
                                    'type': 'same_package',
                                    'class': cls,
                                    'scope': 'intra-repo',
                                    'confidence': DependencyService._calculate_confidence_score('same_package', 'intra-repo')
                                })
        
        return dict(dependency_map)
    
    @staticmethod
    def find_maven_artifact_for_file(file_path: str, repo_path: str) -> Optional[Dict]:
        """
        Find the Maven artifact (groupId:artifactId) for a given file in the repository.
        
        Args:
            file_path: Path to file (relative to repo root)
            repo_path: Path to repository root
            
        Returns:
            Dictionary with groupId, artifactId, version, or None if not found
        """
        # Normalize paths for comparison
        repo_path = os.path.normpath(os.path.abspath(repo_path))
        
        # Find the nearest pom.xml file (walk up the directory tree)
        file_full_path = os.path.join(repo_path, file_path)
        file_full_path = os.path.normpath(os.path.abspath(file_full_path))
        current_dir = os.path.dirname(file_full_path)
        current_dir = os.path.normpath(os.path.abspath(current_dir))
        
        # Search for pom.xml in parent directories
        max_depth = 10
        depth = 0
        while depth < max_depth:
            # Normalize current_dir for comparison
            current_dir_norm = os.path.normpath(os.path.abspath(current_dir))
            
            # Check if we've gone past the repo root
            try:
                os.path.relpath(current_dir_norm, repo_path)
                if not current_dir_norm.startswith(repo_path):
                    break
            except ValueError:
                break
            
            pom_path = os.path.join(current_dir_norm, 'pom.xml')
            if os.path.exists(pom_path):
                pom_data = DependencyService.parse_pom_xml(pom_path)
                if pom_data.get('groupId') and pom_data.get('artifactId'):
                    return pom_data
            
            # Move to parent directory
            parent_dir = os.path.dirname(current_dir_norm)
            if parent_dir == current_dir_norm:  # Reached root
                break
            current_dir = parent_dir
            depth += 1
        
        # If not found, try root pom.xml
        root_pom = os.path.join(repo_path, 'pom.xml')
        root_pom = os.path.normpath(os.path.abspath(root_pom))
        if os.path.exists(root_pom):
            pom_data = DependencyService.parse_pom_xml(root_pom)
            if pom_data.get('groupId') and pom_data.get('artifactId'):
                return pom_data
        
        return None
    
    @staticmethod
    def find_cross_repo_dependent_files(
        vulnerable_file: str,
        vulnerable_repo_path: str,
        vulnerable_repo_name: str,
        vulnerable_repo_id: int,
        all_repos: List[Dict],
        max_depth: int = 5
    ) -> Dict:
        """
        Find files in other repositories that depend on the vulnerable file.
        
        Args:
            vulnerable_file: Path to vulnerable file (relative to repo root)
            vulnerable_repo_path: Path to vulnerable repository root
            vulnerable_repo_name: Name of vulnerable repository
            vulnerable_repo_id: ID of vulnerable repository
            all_repos: List of all repositories with clone paths
            max_depth: Maximum depth to traverse dependencies
            
        Returns:
            Dictionary containing cross-repo dependent files and dependency chains
        """
        result = {
            'vulnerable_file': vulnerable_file,
            'vulnerable_repo': vulnerable_repo_name,
            'vulnerable_repo_id': vulnerable_repo_id,
            'cross_repo_dependents': [],
            'dependency_chains': [],
            'transitive_dependents': []
        }
        
        # Parse vulnerable file to get package and classes
        vulnerable_file_full_path = os.path.join(vulnerable_repo_path, vulnerable_file)
        if not os.path.exists(vulnerable_file_full_path):
            return result
        
        vulnerable_file_info = DependencyService.parse_java_file(vulnerable_file_full_path)
        vulnerable_package = vulnerable_file_info.get('package', '')
        vulnerable_classes = vulnerable_file_info.get('classes', [])
        vulnerable_interfaces = vulnerable_file_info.get('interfaces', [])
        all_vulnerable_classes = set(vulnerable_classes + vulnerable_interfaces)
        
        # Find Maven artifact for vulnerable file
        vulnerable_artifact = DependencyService.find_maven_artifact_for_file(
            vulnerable_file, vulnerable_repo_path
        )
        
        if not vulnerable_artifact:
            # If no Maven artifact found, still return result (with empty lists)
            # This allows the frontend to know cross-repo analysis was attempted
            return result
        
        vulnerable_group_id = vulnerable_artifact.get('groupId', '')
        vulnerable_artifact_id = vulnerable_artifact.get('artifactId', '')
        
        # Find repositories that depend on this Maven artifact
        dependent_repos = []
        
        # Log what we're looking for
        logger.info(
            f"[DependencyService] Looking for repos depending on Maven artifact: "
            f"{vulnerable_group_id}:{vulnerable_artifact_id}"
        )
        logger.info(
            f"[DependencyService] Checking {len(all_repos)} repositories from GitHub account "
            f"for cross-repo dependents..."
        )
        
        repos_checked = 0
        repos_with_pom = 0
        
        for repo in all_repos:
            repo_path = repo.get('clone_path')
            repo_name = repo.get('full_name', '')
            repo_id = repo.get('id')
            
            # Skip the vulnerable repository itself
            # Compare normalized paths to avoid issues with path format differences
            if repo_id == vulnerable_repo_id:
                continue
            
            # Also check by comparing normalized paths
            if repo_path and vulnerable_repo_path:
                repo_path_norm = os.path.normpath(os.path.abspath(repo_path))
                vulnerable_path_norm = os.path.normpath(os.path.abspath(vulnerable_repo_path))
                if repo_path_norm == vulnerable_path_norm:
                    continue
            
            repos_checked += 1
            
            if not repo_path:
                logger.debug(
                    f"[DependencyService] [{repos_checked}/{len(all_repos)}] "
                    f"Skipping {repo_name}: No clone_path"
                )
                continue
            
            if not os.path.exists(repo_path):
                logger.debug(
                    f"[DependencyService] [{repos_checked}/{len(all_repos)}] "
                    f"Skipping {repo_name}: Path does not exist: {repo_path}"
                )
                continue
            
            # Check if this repo depends on the vulnerable artifact
            pom_files = DependencyService.find_pom_files(repo_path)
            if not pom_files:
                logger.debug(
                    f"[DependencyService] [{repos_checked}/{len(all_repos)}] "
                    f"No pom.xml found in {repo_name} (skipping Maven dependency check)"
                )
                continue
            
            repos_with_pom += 1
            logger.debug(
                f"[DependencyService] [{repos_checked}/{len(all_repos)}] "
                f"Checking {repo_name} ({len(pom_files)} pom.xml files)..."
            )
            
            for pom_file in pom_files:
                pom_full_path = os.path.join(repo_path, pom_file)
                pom_data = DependencyService.parse_pom_xml(pom_full_path)
                
                # Check dependencies
                dependencies = pom_data.get('dependencies', [])
                logger.debug(
                    f"[DependencyService]   Found {len(dependencies)} dependencies in {pom_file}"
                )
                
                for dep in dependencies:
                    dep_group = dep.get('groupId', '')
                    dep_artifact = dep.get('artifactId', '')
                    
                    logger.debug(
                        f"[DependencyService]     Checking dependency: {dep_group}:{dep_artifact}"
                    )
                    
                    if dep_group == vulnerable_group_id and dep_artifact == vulnerable_artifact_id:
                        logger.info(
                            f"[DependencyService] ✅ MATCH FOUND! {repo_name} depends on "
                            f"{vulnerable_group_id}:{vulnerable_artifact_id}"
                        )
                        dependent_repos.append({
                            'repo': repo,
                            'repo_path': repo_path,
                            'repo_name': repo_name,
                            'repo_id': repo_id,
                            'pom_file': pom_file,
                            'dependency_type': 'maven_dependency',
                            'maven_artifact': f"{vulnerable_group_id}:{vulnerable_artifact_id}",
                            'depth': 1
                        })
                        break
        
        logger.info(
            f"[DependencyService] Checked {repos_checked} repositories, {repos_with_pom} had pom.xml files"
        )
        logger.info(
            f"[DependencyService] Found {len(dependent_repos)} dependent repositories"
        )
        
        # For each dependent repository, find files that use the vulnerable file's classes
        for dep_repo_info in dependent_repos:
            repo_path = dep_repo_info['repo_path']
            repo_name = dep_repo_info['repo_name']
            repo_id = dep_repo_info['repo_id']
            
            # Find all Java files in this dependent repository
            java_files = DependencyService.find_java_files(repo_path)
            
            for java_file in java_files:
                java_file_full_path = os.path.join(repo_path, java_file)
                parsed = DependencyService.parse_java_file(java_file_full_path)
                
                # Check if file imports from vulnerable package
                imports = parsed.get('imports_full', [])
                uses_vulnerable = False
                import_details = []
                classes_from_package = set()  # Track all classes imported from vulnerable package
                
                for imp in imports:
                    imp_clean = imp.replace('.*', '').strip()
                    
                    # Check if import matches vulnerable package
                    if vulnerable_package and imp_clean.startswith(vulnerable_package):
                        uses_vulnerable = True
                        # Extract class name from import
                        import_parts = imp_clean.split('.')
                        if import_parts:
                            imported_class = import_parts[-1]
                            if imported_class in all_vulnerable_classes or '*' in imp:
                                import_details.append({
                                    'import': imp,
                                    'class': imported_class if imported_class != '*' else 'wildcard'
                                })
                    
                    # Also check direct class name matches
                    for cls in all_vulnerable_classes:
                        if imp_clean.endswith(cls) or imp_clean == cls:
                            uses_vulnerable = True
                            import_details.append({
                                'import': imp,
                                'class': cls
                            })
                
                # Check instantiations and references
                instantiations = parsed.get('instantiations', [])
                references = parsed.get('references', [])
                
                for inst in instantiations:
                    if inst in all_vulnerable_classes:
                        uses_vulnerable = True
                        import_details.append({
                            'instantiation': inst,
                            'class': inst
                        })
                
                for ref in references:
                    if ref in all_vulnerable_classes:
                        uses_vulnerable = True
                        import_details.append({
                            'reference': ref,
                            'class': ref
                        })
                
                if uses_vulnerable:
                    # Extract all imports that match vulnerable package/classes
                    matching_imports = []
                    
                    for detail in import_details:
                        if 'import' in detail:
                            matching_imports.append(detail['import'])
                        elif 'instantiation' in detail:
                            inst_class = detail['instantiation']
                            matching_imports.append(f"new {inst_class}()")
                        elif 'reference' in detail:
                            ref_class = detail['reference']
                            matching_imports.append(f"{ref_class} (type reference)")
                    
                    # Also check all imports from the file to see which ones match vulnerable package
                    all_file_imports = parsed.get('imports_full', [])
                    vulnerable_imports = []
                    for imp in all_file_imports:
                        imp_clean = imp.replace('.*', '').strip()
                        # Check if import matches vulnerable package
                        if vulnerable_package and imp_clean.startswith(vulnerable_package):
                            vulnerable_imports.append(imp)
                            # Extract class name from import
                            import_parts = imp_clean.split('.')
                            if import_parts:
                                imported_class = import_parts[-1]
                                classes_from_package.add(imported_class)
                        # Check if import ends with any vulnerable class name
                        for cls in all_vulnerable_classes:
                            if imp_clean.endswith(cls) or imp_clean == cls:
                                vulnerable_imports.append(imp)
                                classes_from_package.add(cls)
                    
                    # Combine matching imports (remove duplicates)
                    all_matching_imports = list(set(matching_imports + vulnerable_imports))
                    # classes_used_list contains all classes imported from vulnerable package
                    classes_used_list = sorted(list(classes_from_package))
                    
                    result['cross_repo_dependents'].append({
                        'repo': repo_name,
                        'repo_id': repo_id,
                        'file': java_file,
                        'dependency_type': 'maven_dependency',
                        'maven_artifact': f"{vulnerable_group_id}:{vulnerable_artifact_id}",
                        'imports': all_matching_imports if all_matching_imports else [],
                        'classes_used': classes_used_list,
                        'vulnerable_classes': list(all_vulnerable_classes),
                        'vulnerable_package': vulnerable_package,
                        'depth': 1,
                        'path': [f"{vulnerable_repo_name}:{vulnerable_file}", f"{repo_name}:{java_file}"]
                    })
        
        # Build transitive dependency chains
        result['dependency_chains'] = DependencyService._build_cross_repo_dependency_chains(
            vulnerable_repo_name,
            vulnerable_artifact_id,
            vulnerable_group_id,
            dependent_repos,
            all_repos,
            vulnerable_repo_id,
            max_depth
        )
        
        # Extract transitive dependents from chains
        for chain in result['dependency_chains']:
            if chain.get('depth', 1) > 1:
                result['transitive_dependents'].extend(chain.get('files', []))
        
        return result
    
    @staticmethod
    def _build_cross_repo_dependency_chains(
        vulnerable_repo_name: str,
        vulnerable_artifact_id: str,
        vulnerable_group_id: str,
        direct_dependent_repos: List[Dict],
        all_repos: List[Dict],
        vulnerable_repo_id: int,
        max_depth: int = 5
    ) -> List[Dict]:
        """
        Build transitive dependency chains across repositories.
        
        Args:
            vulnerable_repo_name: Name of vulnerable repository
            vulnerable_artifact_id: Artifact ID of vulnerable Maven artifact
            vulnerable_group_id: Group ID of vulnerable Maven artifact
            direct_dependent_repos: List of repositories that directly depend on vulnerable repo
            all_repos: List of all repositories
            vulnerable_repo_id: ID of vulnerable repository
            max_depth: Maximum depth to traverse
            
        Returns:
            List of dependency chains
        """
        chains = []
        visited = set()
        
        # BFS to find transitive dependencies
        queue = []
        
        # Start with direct dependents (depth 1)
        for dep_repo_info in direct_dependent_repos:
            repo_name = dep_repo_info['repo_name']
            repo_id = dep_repo_info['repo_id']
            repo_path = dep_repo_info['repo_path']
            
            # Find Maven artifact for this dependent repository
            dep_artifact = DependencyService._find_repo_maven_artifact(repo_path)
            
            if dep_artifact:
                chain_entry = {
                    'from_repo': vulnerable_repo_name,
                    'from_artifact': f"{vulnerable_group_id}:{vulnerable_artifact_id}",
                    'to_repo': repo_name,
                    'to_artifact': f"{dep_artifact.get('groupId', '')}:{dep_artifact.get('artifactId', '')}",
                    'depth': 1,
                    'chain': [vulnerable_repo_name, repo_name],
                    'files': []
                }
                
                # Find files in this repo that use the vulnerable artifact
                java_files = DependencyService.find_java_files(repo_path)
                for java_file in java_files:
                    chain_entry['files'].append({
                        'repo': repo_name,
                        'repo_id': repo_id,
                        'file': java_file,
                        'depth': 1
                    })
                
                chains.append(chain_entry)
                queue.append((repo_name, repo_id, repo_path, dep_artifact, [vulnerable_repo_name, repo_name], 1))
                visited.add(repo_id)
        
        # Process transitive dependencies (depth 2+)
        while queue and len(chains) < 100:  # Limit to prevent infinite loops
            current_repo_name, current_repo_id, current_repo_path, current_artifact, current_chain, current_depth = queue.pop(0)
            
            if current_depth >= max_depth:
                continue
            
            # Find repositories that depend on the current repository
            current_group_id = current_artifact.get('groupId', '')
            current_artifact_id = current_artifact.get('artifactId', '')
            
            for repo in all_repos:
                repo_path = repo.get('clone_path')
                repo_name = repo.get('full_name', '')
                repo_id = repo.get('id')
                
                # Skip if already visited or is the vulnerable repo
                if repo_id in visited or repo_id == vulnerable_repo_id or repo_name == current_repo_name:
                    continue
                
                if not repo_path or not os.path.exists(repo_path):
                    continue
                
                # Check if this repo depends on current repo's artifact
                pom_files = DependencyService.find_pom_files(repo_path)
                depends_on_current = False
                
                for pom_file in pom_files:
                    pom_full_path = os.path.join(repo_path, pom_file)
                    pom_data = DependencyService.parse_pom_xml(pom_full_path)
                    
                    for dep in pom_data.get('dependencies', []):
                        dep_group = dep.get('groupId', '')
                        dep_artifact = dep.get('artifactId', '')
                        
                        if dep_group == current_group_id and dep_artifact == current_artifact_id:
                            depends_on_current = True
                            break
                    
                    if depends_on_current:
                        break
                
                if depends_on_current:
                    # This is a transitive dependent
                    next_artifact = DependencyService._find_repo_maven_artifact(repo_path)
                    new_chain = current_chain + [repo_name]
                    
                    chain_entry = {
                        'from_repo': vulnerable_repo_name,
                        'from_artifact': f"{vulnerable_group_id}:{vulnerable_artifact_id}",
                        'to_repo': repo_name,
                        'to_artifact': f"{next_artifact.get('groupId', '')}:{next_artifact.get('artifactId', '')}" if next_artifact else 'unknown',
                        'depth': current_depth + 1,
                        'chain': new_chain,
                        'intermediate_repos': current_chain[1:] if len(current_chain) > 2 else [],
                        'files': []
                    }
                    
                    # Find files in this transitive dependent repo
                    java_files = DependencyService.find_java_files(repo_path)
                    for java_file in java_files:
                        chain_entry['files'].append({
                            'repo': repo_name,
                            'repo_id': repo_id,
                            'file': java_file,
                            'depth': current_depth + 1
                        })
                    
                    chains.append(chain_entry)
                    
                    if next_artifact:
                        queue.append((repo_name, repo_id, repo_path, next_artifact, new_chain, current_depth + 1))
                    visited.add(repo_id)
        
        return chains
    
    @staticmethod
    def _find_repo_maven_artifact(repo_path: str) -> Optional[Dict]:
        """Find the main Maven artifact for a repository by checking root pom.xml."""
        root_pom = os.path.join(repo_path, 'pom.xml')
        if os.path.exists(root_pom):
            pom_data = DependencyService.parse_pom_xml(root_pom)
            if pom_data.get('groupId') and pom_data.get('artifactId'):
                return pom_data
        return None
    
    @staticmethod
    def build_maven_artifact_index(all_repos: List[Dict]) -> Dict[Tuple[str, str], Dict]:
        """
        Build Maven Artifact → Repository Index (PART 1).
        
        Maps (groupId, artifactId) to repository information.
        Versions may differ; log warnings but continue.
        
        Args:
            all_repos: List of repository dictionaries with clone_path
            
        Returns:
            Dictionary mapping (groupId, artifactId) -> {
                'repo_path': str,
                'repo_name': str,
                'repo_id': any,
                'version': str,
                'candidates': List[Dict]  # If multiple repos match
            }
        """
        artifact_index = {}
        version_warnings = []
        
        for repo in all_repos:
            repo_path = repo.get('clone_path')
            if not repo_path or not os.path.exists(repo_path):
                continue
            
            repo_name = repo.get('full_name', repo.get('name', 'unknown'))
            repo_id = repo.get('id')
            
            # Find Maven artifact for this repository
            artifact = DependencyService._find_repo_maven_artifact(repo_path)
            if not artifact:
                continue
            
            group_id = artifact.get('groupId', '')
            artifact_id = artifact.get('artifactId', '')
            version = artifact.get('version', '')
            
            if not group_id or not artifact_id:
                continue
            
            key = (group_id, artifact_id)
            
            if key in artifact_index:
                # Multiple repos with same groupId:artifactId
                existing = artifact_index[key]
                if 'candidates' not in existing:
                    existing['candidates'] = [{
                        'repo_path': existing['repo_path'],
                        'repo_name': existing['repo_name'],
                        'repo_id': existing['repo_id'],
                        'version': existing['version']
                    }]
                
                existing['candidates'].append({
                    'repo_path': repo_path,
                    'repo_name': repo_name,
                    'repo_id': repo_id,
                    'version': version
                })
                
                # Log version mismatch warning
                versions = [c['version'] for c in existing['candidates']]
                if len(set(versions)) > 1:
                    version_warnings.append(
                        f"Multiple versions found for {group_id}:{artifact_id}: {versions}"
                    )
            else:
                artifact_index[key] = {
                    'repo_path': repo_path,
                    'repo_name': repo_name,
                    'repo_id': repo_id,
                    'version': version
                }
        
        if version_warnings:
            print(f"[WARNING] Version mismatches detected: {len(version_warnings)}")
            for warning in version_warnings[:5]:  # Show first 5
                print(f"  {warning}")
        
        return artifact_index
    
    @staticmethod
    def _calculate_confidence_score(
        dep_type: str,
        scope: str = 'intra-repo',
        is_ambiguous: bool = False,
        has_maven_match: bool = False
    ) -> float:
        """
        Calculate confidence score for a dependency edge (PART 2).
        
        Args:
            dep_type: Type of dependency (extends, implements, import, etc.)
            scope: 'intra-repo' or 'inter-repo'
            is_ambiguous: Whether resolution was ambiguous
            has_maven_match: Whether resolved via Maven artifact match
            
        Returns:
            Confidence score between 0.0 and 1.0
        """
        # Base confidence by dependency type
        base_scores = {
            'extends': 1.00,
            'implements': 1.00,
            'import': 0.90,
            'instantiation': 0.85,
            'class_reference': 0.70,
            'same_package': 0.60,
            'maven_dependency': 0.40  # External/artifact-only
        }
        
        confidence = base_scores.get(dep_type, 0.50)
        
        # Adjustments
        if is_ambiguous:
            confidence = min(confidence, 0.60)
        
        if has_maven_match and dep_type != 'maven_dependency':
            confidence = min(confidence + 0.05, 1.0)
        
        if scope == 'inter-repo':
            confidence = confidence * 0.95
        
        return round(confidence, 2)
    
    @staticmethod
    def _resolve_symbol_inter_repo(
        symbol: str,
        symbol_package: Optional[str],
        class_to_file_map: Dict[str, str],
        artifact_index: Dict[Tuple[str, str], Dict],
        all_repos: List[Dict],
        current_repo_path: str
    ) -> Tuple[Optional[Dict], bool, bool]:
        """
        Extended symbol resolution logic (PART 2).
        
        Resolution order:
        1. Intra-repo class_to_file_map
        2. If unresolved: Identify Maven dependency → find source repository
        3. Resolve class to source file in that repository
        
        Args:
            symbol: Class/interface name to resolve
            symbol_package: Package of the symbol (if known)
            class_to_file_map: Intra-repo class-to-file mapping
            artifact_index: Maven artifact → repo index
            all_repos: List of all repositories
            current_repo_path: Path to current repository
            
        Returns:
            Tuple of (resolved_info, is_ambiguous, has_maven_match)
            resolved_info: {
                'repo_path': str,
                'file_path': str,
                'repo_name': str,
                'scope': 'intra-repo' or 'inter-repo'
            } or None
        """
        # Step 1: Try intra-repo resolution first
        if symbol in class_to_file_map:
            file_path = class_to_file_map[symbol]
            return {
                'repo_path': current_repo_path,
                'file_path': file_path,
                'repo_name': os.path.basename(current_repo_path),
                'scope': 'intra-repo'
            }, False, False
        
        # Step 2: Try inter-repo resolution via Maven artifact
        # symbol_package could be the full import path (e.g., "models.User" or "models")
        if not symbol_package:
            return None, False, False
        
        # Extract base package (first part before first dot)
        base_package = symbol_package.split('.')[0] if '.' in symbol_package else symbol_package
        
        # Find which Maven artifact this package belongs to
        # Check artifact_index for matching packages
        matching_artifacts = []
        for (group_id, artifact_id), artifact_info in artifact_index.items():
            # Try to match package to artifact
            # Common patterns:
            # 1. Package starts with groupId (e.g., com.bank -> com.bank:core)
            # 2. Package matches artifactId (e.g., models -> maven-banking-app:maven-banking-app)
            # 3. Full package matches groupId
            if (symbol_package.startswith(group_id) or 
                base_package == artifact_id or 
                symbol_package.startswith(artifact_id) or
                group_id.endswith(base_package)):
                matching_artifacts.append((group_id, artifact_id, artifact_info))
        
        if not matching_artifacts:
            return None, False, False
        
        # If multiple matches, mark as ambiguous
        is_ambiguous = len(matching_artifacts) > 1
        
        # Use first match (or could use version to disambiguate)
        group_id, artifact_id, artifact_info = matching_artifacts[0]
        
        # Check if multiple candidate repos
        if 'candidates' in artifact_info:
            is_ambiguous = True
            # Use first candidate
            candidate = artifact_info['candidates'][0]
            target_repo_path = candidate['repo_path']
            target_repo_name = candidate['repo_name']
        else:
            target_repo_path = artifact_info['repo_path']
            target_repo_name = artifact_info['repo_name']
        
        # Now resolve symbol in target repository
        target_java_files = DependencyService.find_java_files(target_repo_path)
        target_parsed_files = {}
        target_class_to_file = {}
        
        for java_file in target_java_files:
            full_path = os.path.join(target_repo_path, java_file)
            parsed = DependencyService.parse_java_file(full_path)
            target_parsed_files[java_file] = parsed
            
            file_package = parsed.get('package', '')
            classes = parsed.get('classes', [])
            interfaces = parsed.get('interfaces', [])
            
            for cls in classes:
                full_class_name = f"{file_package}.{cls}" if file_package else cls
                if cls == symbol or full_class_name == symbol or full_class_name.endswith(f".{symbol}"):
                    target_class_to_file[symbol] = java_file
                    break
            
            for iface in interfaces:
                full_iface_name = f"{file_package}.{iface}" if file_package else iface
                if iface == symbol or full_iface_name == symbol or full_iface_name.endswith(f".{symbol}"):
                    target_class_to_file[symbol] = java_file
                    break
        
        if symbol in target_class_to_file:
            return {
                'repo_path': target_repo_path,
                'file_path': target_class_to_file[symbol],
                'repo_name': target_repo_name,
                'scope': 'inter-repo'
            }, is_ambiguous, True
        
        # Symbol not found in source - external/artifact-only
        return {
            'repo_path': None,
            'file_path': None,
            'repo_name': target_repo_name,
            'scope': 'external'
        }, is_ambiguous, True
    
    @staticmethod
    def _determine_fix_action(
        min_confidence: float,
        dependency_path: List[Dict],
        max_propagation_depth: int = 3
    ) -> str:
        """
        Determine fix action based on safety rules (PART 4).
        
        Args:
            min_confidence: Minimum confidence along the dependency path
            dependency_path: List of dependency edges in the path
            max_propagation_depth: Maximum allowed propagation depth
            
        Returns:
            'auto_fix', 'review_required', or 'no_propagation'
        """
        # Rule 1: Low confidence dependency
        if min_confidence < 0.65:
            return 'review_required'
        
        # Rule 2: External / artifact-only dependency
        for edge in dependency_path:
            if edge.get('scope') == 'external':
                return 'no_propagation'
        
        # Rule 3: Cross-repo boundary + non-structural dependency
        for edge in dependency_path:
            if edge.get('scope') == 'inter-repo':
                dep_type = edge.get('type', '')
                if dep_type not in ['extends', 'implements']:
                    return 'review_required'
        
        # Rule 4: Dependency path includes ambiguity
        for edge in dependency_path:
            if edge.get('is_ambiguous', False):
                return 'review_required'
        
        # Rule 5: Depth threshold exceeded
        if len(dependency_path) > max_propagation_depth:
            return 'no_propagation'
        
        # Rule 6: All checks passed - safe for auto-fix
        # Only if confidence is high AND all dependencies are structural OR intra-repo
        if min_confidence >= 0.85:
            # Check if all are structural (extends/implements) or intra-repo
            all_safe = True
            for edge in dependency_path:
                if edge.get('scope') == 'inter-repo':
                    dep_type = edge.get('type', '')
                    if dep_type not in ['extends', 'implements']:
                        all_safe = False
                        break
            
            if all_safe:
                return 'auto_fix'
        
        # Default: require review
        return 'review_required'
    
    @staticmethod
    def find_impact_with_confidence(
        vulnerable_file: str,
        vulnerable_repo_name: str,
        vulnerable_repo_path: str,
        all_repos: List[Dict],
        max_depth: int = 5,
        max_propagation_depth: int = 3
    ) -> Dict:
        """
        Find impact analysis with confidence scores and fix actions (PART 5).
        
        Args:
            vulnerable_file: Path to vulnerable file (relative to repo root)
            vulnerable_repo_name: Name of vulnerable repository
            vulnerable_repo_path: Path to vulnerable repository
            all_repos: List of all repositories
            max_depth: Maximum depth for BFS traversal
            max_propagation_depth: Maximum depth for fix propagation
            
        Returns:
            Dictionary with impact analysis including confidence and fix actions
        """
        # Build Maven artifact index
        artifact_index = DependencyService.build_maven_artifact_index(all_repos)
        
        # Build global dependency graph
        forward_graph, reverse_graph = DependencyService.build_global_dependency_graph(
            all_repos, artifact_index
        )
        
        # Find vulnerable file node
        vulnerable_node = (vulnerable_repo_name, vulnerable_file)
        
        if vulnerable_node not in reverse_graph:
            return {
                'impacted_files': [],
                'summary': {
                    'total_impacted': 0,
                    'auto_fix': 0,
                    'review_required': 0,
                    'no_propagation': 0
                }
            }
        
        # BFS traversal to find all dependents
        visited = set()
        queue = [(vulnerable_node, [], 0)]  # (node, path, depth)
        impacted_files = []
        
        while queue:
            current_node, current_path, depth = queue.pop(0)
            
            if current_node in visited or depth > max_depth:
                continue
            
            visited.add(current_node)
            
            # Get dependents from reverse graph
            dependents = reverse_graph.get(current_node, [])
            
            for dependent_edge in dependents:
                dependent_node = (dependent_edge['repo'], dependent_edge['file'])
                
                if dependent_node in visited:
                    continue
                
                # Build new path
                new_path = current_path + [dependent_edge]
                
                # Calculate minimum confidence along path
                min_confidence = min(
                    [edge.get('confidence', 0.0) for edge in new_path],
                    default=1.0
                )
                
                # Determine fix action
                fix_action = DependencyService._determine_fix_action(
                    min_confidence, new_path, max_propagation_depth
                )
                
                # Build path string representation
                path_strings = [f"{edge['repo']}:{edge['file']}" for edge in new_path]
                path_strings.insert(0, f"{vulnerable_repo_name}:{vulnerable_file}")
                
                impacted_files.append({
                    'repo': dependent_edge['repo'],
                    'file': dependent_edge['file'],
                    'depth': depth + 1,
                    'dependency_path': path_strings,
                    'min_confidence': min_confidence,
                    'fix_action': fix_action,
                    'dependency_type': dependent_edge.get('type', 'unknown'),
                    'scope': dependent_edge.get('scope', 'unknown')
                })
                
                # Add to queue for next level
                if depth + 1 < max_depth:
                    queue.append((dependent_node, new_path, depth + 1))
        
        # Build summary
        summary = {
            'total_impacted': len(impacted_files),
            'auto_fix': sum(1 for f in impacted_files if f['fix_action'] == 'auto_fix'),
            'review_required': sum(1 for f in impacted_files if f['fix_action'] == 'review_required'),
            'no_propagation': sum(1 for f in impacted_files if f['fix_action'] == 'no_propagation')
        }
        
        return {
            'impacted_files': impacted_files,
            'summary': summary
        }
    
    @staticmethod
    def build_inter_repo_dependencies(repo_path: str, all_repos: List[Dict]) -> Dict[str, List[Dict]]:
        """
        Build inter-repository dependency map using Maven pom.xml files.
        
        Args:
            repo_path: Path to current repository root
            all_repos: List of all repository dictionaries with clone paths
            
        Returns:
            Dictionary mapping file paths to inter-repo dependencies
        """
        pom_files = DependencyService.find_pom_files(repo_path)
        inter_repo_deps = defaultdict(list)
        
        # Parse pom.xml files
        for pom_file in pom_files:
            full_pom_path = os.path.join(repo_path, pom_file)
            pom_data = DependencyService.parse_pom_xml(full_pom_path)
            
            # Check each dependency against other repositories
            for dep in pom_data.get('dependencies', []):
                dep_group = dep.get('groupId', '')
                dep_artifact = dep.get('artifactId', '')
                
                # Try to match with other repositories
                for other_repo in all_repos:
                    other_repo_path = other_repo.get('clone_path')
                    if not other_repo_path or not os.path.exists(other_repo_path):
                        continue
                    
                    other_pom_files = DependencyService.find_pom_files(other_repo_path)
                    for other_pom in other_pom_files:
                        other_pom_path = os.path.join(other_repo_path, other_pom)
                        other_pom_data = DependencyService.parse_pom_xml(other_pom_path)
                        
                        if (other_pom_data.get('groupId') == dep_group and 
                            other_pom_data.get('artifactId') == dep_artifact):
                            inter_repo_deps[pom_file].append({
                                'repo': other_repo.get('full_name', ''),
                                'repo_id': other_repo.get('id'),
                                'type': 'maven_dependency',
                                'groupId': dep_group,
                                'artifactId': dep_artifact
                            })
        
        return dict(inter_repo_deps)
    
    @staticmethod
    def build_dependency_graph(repo_path: str) -> Dict[str, Dict]:
        """
        Build a complete dependency graph with forward and reverse mappings.
        
        Args:
            repo_path: Path to repository root
            
        Returns:
            Dictionary with 'forward' (file -> dependencies) and 'reverse' (file -> dependents) maps
        """
        intra_deps = DependencyService.build_intra_repo_dependencies(repo_path)
        
        # Build reverse map (what depends on each file)
        reverse_map = defaultdict(list)
        for file_path, deps in intra_deps.items():
            for dep in deps:
                dep_file = dep['file']
                reverse_map[dep_file].append({
                    'file': file_path,
                    'type': dep['type'],
                    'class': dep.get('class', dep.get('interface', ''))
                })
        
        return {
            'forward': intra_deps,  # file -> [dependencies]
            'reverse': dict(reverse_map)  # file -> [dependents]
        }
    
    @staticmethod
    def find_dependent_files_with_paths(
        vulnerable_file: str,
        repo_path: str,
        max_depth: int = 5
    ) -> Dict:
        """
        Find all files that depend on a vulnerable file with full dependency paths.
        
        Args:
            vulnerable_file: Path to vulnerable file (relative to repo root)
            repo_path: Path to repository root
            max_depth: Maximum depth to traverse dependencies
            
        Returns:
            Dictionary containing dependency map with paths
        """
        graph = DependencyService.build_dependency_graph(repo_path)
        reverse_map = graph['reverse']
        
        result = {
            'vulnerable_file': vulnerable_file,
            'direct_dependents': [],
            'transitive_dependents': [],
            'dependency_paths': [],  # Full paths from vulnerable file to dependents
            'dependency_tree': {}  # Hierarchical tree structure
        }
        
        # Find direct dependents
        if vulnerable_file in reverse_map:
            for dep in reverse_map[vulnerable_file]:
                result['direct_dependents'].append({
                    'file': dep['file'],
                    'type': dep['type'],
                    'class': dep.get('class', ''),
                    'depth': 1,
                    'path': [vulnerable_file, dep['file']]  # Add path for direct dependents too
                })
        
        # Find transitive dependents with paths using BFS
        visited = set()
        queue = [(vulnerable_file, [], 0)]  # (current_file, path, depth)
        
        while queue:
            current_file, path, depth = queue.pop(0)
            
            if depth >= max_depth or current_file in visited:
                continue
            
            visited.add(current_file)
            
            # Find files that depend on current_file
            if current_file in reverse_map:
                for dep in reverse_map[current_file]:
                    dep_file = dep['file']
                    if dep_file not in visited:
                        new_path = path + [current_file] if path else [current_file]
                        full_path = new_path + [dep_file]
                        
                        if depth == 0:
                            # Direct dependent - add to paths but already in direct_dependents
                            result['dependency_paths'].append({
                                'from': vulnerable_file,
                                'to': dep_file,
                                'path': full_path,
                                'depth': 1,
                                'type': dep['type']
                            })
                        else:
                            # Transitive dependent
                            result['transitive_dependents'].append({
                                'file': dep_file,
                                'type': dep['type'],
                                'class': dep.get('class', ''),
                                'depth': depth + 1,
                                'path': full_path
                            })
                            
                            result['dependency_paths'].append({
                                'from': vulnerable_file,
                                'to': dep_file,
                                'path': full_path,
                                'depth': depth + 1,
                                'type': dep['type']
                            })
                        
                        queue.append((dep_file, new_path, depth + 1))
        
        # Build hierarchical tree structure
        result['dependency_tree'] = DependencyService._build_dependency_tree(
            vulnerable_file, reverse_map, max_depth
        )
        
        return result
    
    @staticmethod
    def _build_dependency_tree(
        root_file: str,
        reverse_map: Dict,
        max_depth: int,
        current_depth: int = 0,
        visited: Optional[Set] = None
    ) -> Dict:
        """Build a hierarchical tree structure of dependencies."""
        if visited is None:
            visited = set()
        
        if current_depth >= max_depth or root_file in visited:
            return {}
        
        visited.add(root_file)
        
        tree = {
            'file': root_file,
            'dependents': [],
            'depth': current_depth
        }
        
        if root_file in reverse_map:
            for dep in reverse_map[root_file]:
                dep_file = dep['file']
                if dep_file not in visited:
                    subtree = DependencyService._build_dependency_tree(
                        dep_file, reverse_map, max_depth, current_depth + 1, visited.copy()
                    )
                    tree['dependents'].append({
                        'file': dep_file,
                        'type': dep['type'],
                        'class': dep.get('class', ''),
                        'subtree': subtree
                    })
        
        return tree
    
    @staticmethod
    def find_dependent_files(
        vulnerable_file: str,
        vulnerable_line: int,
        repo_path: str,
        all_repos: List[Dict],
        max_depth: int = 5
    ) -> Dict:
        """
        Find all files that depend on a vulnerable file (both intra and inter-repo).
        Enhanced version with clearer dependency mapping.
        
        Args:
            vulnerable_file: Path to vulnerable file (relative to repo root)
            vulnerable_line: Line number of vulnerability
            repo_path: Path to repository root
            all_repos: List of all repositories with their clone paths
            max_depth: Maximum depth to traverse dependencies
            
        Returns:
            Dictionary containing dependency map with clear structure
        """
        result = {
            'vulnerability': {
                'file': vulnerable_file,
                'line': vulnerable_line,
                'repo': os.path.basename(repo_path)
            },
            'dependents': [],
            'dependency_summary': {
                'total_dependents': 0,
                'direct_dependents': 0,
                'transitive_dependents': 0,
                'by_type': {}
            },
            'dependency_paths': [],
            'dependency_tree': {},
            'intra_repo_deps': [],
            'inter_repo_deps': [],
            'cross_repo_dependents': [],  # Always include, even if empty
            'dependency_chains': []  # Always include, even if empty
        }
        
        # Find vulnerable repo info from all_repos
        repo_path_normalized = os.path.normpath(os.path.abspath(repo_path))
        vulnerable_repo_info = None
        for repo in all_repos:
            clone_path = repo.get('clone_path')
            if clone_path:
                clone_path_normalized = os.path.normpath(os.path.abspath(clone_path))
                if clone_path_normalized == repo_path_normalized:
                    vulnerable_repo_info = repo
                    break
        
        vulnerable_repo_id = vulnerable_repo_info.get('id') if vulnerable_repo_info else None
        vulnerable_repo_name = vulnerable_repo_info.get('full_name', os.path.basename(repo_path)) if vulnerable_repo_info else os.path.basename(repo_path)
        
        # STEP 1: Get INTRA-REPO dependencies (files in same repository)
        dep_info = DependencyService.find_dependent_files_with_paths(
            vulnerable_file, repo_path, max_depth
        )
        
        # Mark all intra-repo dependents with scope
        intra_repo_dependents = []
        for dep in dep_info['direct_dependents'] + dep_info['transitive_dependents']:
            intra_repo_dependents.append({
                **dep,
                'scope': 'intra-repo',
                'repo': vulnerable_repo_name
            })
        
        # STEP 2: Get INTER-REPO dependencies (files in other repositories)
        inter_repo_dependents = []
        cross_repo_result = {
            'cross_repo_dependents': [],
            'dependency_chains': [],
            'transitive_dependents': []
        }
        
        if len(all_repos) > 1:
            try:
                cross_repo_result = DependencyService.find_cross_repo_dependent_files(
                    vulnerable_file=vulnerable_file,
                    vulnerable_repo_path=repo_path,
                    vulnerable_repo_name=vulnerable_repo_name,
                    vulnerable_repo_id=vulnerable_repo_id,
                    all_repos=all_repos,
                    max_depth=max_depth
                )
                
                # Mark all inter-repo dependents with scope
                cross_repo_deps = cross_repo_result.get('cross_repo_dependents', [])
                print(f"[DEBUG] Found {len(cross_repo_deps)} cross-repo dependents")
                
                for dep in cross_repo_deps:
                    classes_used = dep.get('classes_used', [])
                    if isinstance(classes_used, str):
                        classes_used = [classes_used]
                    
                    inter_repo_dependents.append({
                        'file': dep.get('file', ''),
                        'type': dep.get('dependency_type', 'maven_dependency'),
                        'class': ', '.join(classes_used) if classes_used else '',
                        'depth': dep.get('depth', 1),
                        'path': dep.get('path', []),
                        'scope': 'inter-repo',
                        'repo': dep.get('repo', 'Unknown'),
                        'repo_id': dep.get('repo_id'),
                        'maven_artifact': dep.get('maven_artifact', ''),
                        'imports': dep.get('imports', [])
                    })
                
                print(f"[DEBUG] Added {len(inter_repo_dependents)} inter-repo dependents to result")
            except Exception as e:
                print(f"[WARNING] Cross-repo analysis failed: {str(e)}")
                # Continue with intra-repo only
        
        # STEP 3: Combine BOTH intra-repo and inter-repo dependencies
        all_dependents = intra_repo_dependents + inter_repo_dependents
        
        # Update result with combined dependencies
        result['dependents'] = all_dependents
        result['dependency_paths'] = dep_info['dependency_paths']
        result['dependency_tree'] = dep_info['dependency_tree']
        
        # Separate lists for clarity
        result['intra_repo_dependents'] = intra_repo_dependents
        result['inter_repo_dependents'] = inter_repo_dependents
        
        # Build summary statistics (including both intra and inter)
        result['dependency_summary']['total_dependents'] = len(all_dependents)
        result['dependency_summary']['direct_dependents'] = len([d for d in all_dependents if d.get('depth', 1) == 1])
        result['dependency_summary']['transitive_dependents'] = len([d for d in all_dependents if d.get('depth', 1) > 1])
        result['dependency_summary']['intra_repo_count'] = len(intra_repo_dependents)
        result['dependency_summary']['inter_repo_count'] = len(inter_repo_dependents)
        
        # Count by dependency type
        type_counts = defaultdict(int)
        for dep in all_dependents:
            dep_type = dep.get('type', 'unknown')
            type_counts[dep_type] += 1
        result['dependency_summary']['by_type'] = dict(type_counts)
        
        # Always add cross-repo results (even if empty) to ensure frontend can display them
        result['cross_repo_dependents'] = cross_repo_result.get('cross_repo_dependents', [])
        result['dependency_chains'] = cross_repo_result.get('dependency_chains', [])
        result['transitive_dependents'] = cross_repo_result.get('transitive_dependents', [])
        
        # Update cross-repo summary statistics
        cross_repo_deps = cross_repo_result.get('cross_repo_dependents', [])
        if cross_repo_deps:
            result['dependency_summary']['cross_repo_dependents'] = len(cross_repo_deps)
            result['dependency_summary']['total_affected_repos'] = len(set(
                dep.get('repo') for dep in cross_repo_deps
            ))
        else:
            result['dependency_summary']['cross_repo_dependents'] = 0
            result['dependency_summary']['total_affected_repos'] = 0
        
        result['dependency_summary']['dependency_chains_count'] = len(cross_repo_result.get('dependency_chains', []))
        
        # Build inter-repo dependencies (legacy method for backward compatibility)
        inter_deps = DependencyService.build_inter_repo_dependencies(repo_path, all_repos)
        
        # Find inter-repo dependents
        pom_files = DependencyService.find_pom_files(repo_path)
        for pom_file in pom_files:
            if pom_file in inter_deps:
                for inter_dep in inter_deps[pom_file]:
                    result['inter_repo_deps'].append({
                        'repo': inter_dep['repo'],
                        'repo_id': inter_dep['repo_id'],
                        'dependency_type': inter_dep['type'],
                        'maven_artifact': f"{inter_dep['groupId']}:{inter_dep['artifactId']}"
                    })
        
        # Add message if inter-repo dependencies not found
        if len(all_repos) > 1 and len(inter_repo_dependents) == 0:
            result['inter_repo_message'] = "No inter-repository dependencies found. This could mean:\n- No other repositories depend on this repository's Maven artifact\n- Dependent repositories were not cloned successfully\n- Dependent repositories' pom.xml files don't declare this dependency"
        elif len(all_repos) == 1:
            result['inter_repo_message'] = "Only one repository available. Add more repositories to analyze inter-repository dependencies."
        else:
            result['inter_repo_message'] = None
        
        return result

