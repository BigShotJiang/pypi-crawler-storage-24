import sqlite3
import json
import os
import uuid
import logging
from datetime import datetime
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class RunHistoryService:
    def __init__(self, db_path: str = "data/runs.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._init_db()

    def _init_db(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                CREATE TABLE IF NOT EXISTS pipeline_runs (
                    run_id TEXT PRIMARY KEY,
                    repo_url TEXT,
                    repo_path TEXT,
                    status TEXT,
                    start_time TIMESTAMP,
                    end_time TIMESTAMP,
                    total_cost REAL,
                    input_tokens INTEGER DEFAULT 0,
                    output_tokens INTEGER DEFAULT 0,
                    test_report JSON,
                    coverage_report JSON,
                    regression_report JSON,
                    quality_gate_report JSON,
                    error_message TEXT
                )
                """)
                # Add token columns to existing tables (safe if already present)
                for col in ['input_tokens', 'output_tokens']:
                    try:
                        conn.execute(f"ALTER TABLE pipeline_runs ADD COLUMN {col} INTEGER DEFAULT 0")
                    except sqlite3.OperationalError:
                        pass  # Column already exists
                conn.commit()
        except Exception as e:
            logger.error(f"[RunHistory] Error initializing DB: {e}")

    def create_run(self, repo_url: str = None, repo_path: str = None) -> str:
        run_id = str(uuid.uuid4())
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                INSERT INTO pipeline_runs 
                (run_id, repo_url, repo_path, status, start_time) 
                VALUES (?, ?, ?, 'RUNNING', ?)
                """, (run_id, repo_url, repo_path, datetime.now().isoformat()))
                conn.commit()
        except Exception as e:
            logger.error(f"[RunHistory] Error creating run {run_id}: {e}")
            
        return run_id

    def update_run(self, run_id: str, status: str, result_data: Dict[str, Any] = None, error_msg: str = None, cost: float = 0.0, input_tokens: int = 0, output_tokens: int = 0):
        try:
            end_time = datetime.now().isoformat() if status in ["COMPLETED", "FAILED"] else None
            
            with sqlite3.connect(self.db_path) as conn:
                query = "UPDATE pipeline_runs SET status = ?, total_cost = ?, input_tokens = ?, output_tokens = ?"
                params = [status, cost, input_tokens, output_tokens]
                
                if end_time:
                    query += ", end_time = ?"
                    params.append(end_time)
                    
                if error_msg:
                    query += ", error_message = ?"
                    params.append(error_msg)
                    
                if result_data:
                    if 'tests' in result_data:
                        query += ", test_report = ?"
                        params.append(json.dumps(result_data['tests']))
                    if 'coverage' in result_data:
                        query += ", coverage_report = ?"
                        params.append(json.dumps(result_data['coverage']))
                    if 'regressions' in result_data:
                        query += ", regression_report = ?"
                        params.append(json.dumps(result_data['regressions']))
                    if 'quality_gate' in result_data:
                        query += ", quality_gate_report = ?"
                        params.append(json.dumps(result_data['quality_gate']))

                query += " WHERE run_id = ?"
                params.append(run_id)
                
                conn.execute(query, tuple(params))
                conn.commit()
        except Exception as e:
            logger.error(f"[RunHistory] Error updating run {run_id}: {e}")

    def get_recent_runs(self, limit: int = 50) -> List[Dict[str, Any]]:
        runs = []
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.execute("SELECT * FROM pipeline_runs ORDER BY start_time DESC LIMIT ?", (limit,))
                for row in cursor.fetchall():
                    run = dict(row)
                    # Parse JSON fields
                    for field in ['test_report', 'coverage_report', 'regression_report', 'quality_gate_report']:
                        if run.get(field):
                            try:
                                run[field] = json.loads(run[field])
                            except:
                                pass
                    runs.append(run)
        except Exception as e:
            logger.error(f"[RunHistory] Error fetching runs: {e}")
            
        return runs

run_history = RunHistoryService()
