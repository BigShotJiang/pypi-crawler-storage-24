"""
Fix Validator Service

Validates that fixes don't break the build or existing tests.
Uses testing agent components to run sanity checks, build, and tests.
"""

import logging
import os
from pathlib import Path
from typing import Dict, Any, Optional, List

from .bedrock_service import BedrockService
from atlas.analysis.java_maven import detect_repo_facts
from atlas.build.maven import mvn_clean_install, mvn_test_with_jacoco
from atlas.build.jacoco_injector import ensure_jacoco_in_poms
from atlas.reporting.parsers import parse_surefire_reports
from atlas.agents.build_mechanic import BuildMechanic
from atlas.analysis.java_maven import find_domain_models
from atlas.core.logging import RunLogger
from atlas.llm.bedrock import BedrockClient, BedrockConfig
from ..config import Config

logger = logging.getLogger(__name__)


class FixValidatorService:
    """Service for validating fixes don't break the build or tests."""
    
    def __init__(self, bedrock_service: BedrockService):
        """
        Initialize Fix Validator Service.
        
        Args:
            bedrock_service: BedrockService instance (for potential future use)
        """
        self.bedrock_service = bedrock_service
        self.service_name = "FixValidatorService"
        
        # No longer using redundant service classes
        # Initialize atlas functions as needed (currently they are plain functions)
        
        logger.info(f"[{self.service_name}] Initialized")
        # Use RunLogger wrapper for BuildMechanic compatibility
        self.atlas_logger = RunLogger(emit=lambda msg: logger.info(msg))
        
        # Create Atlas-compatible BedrockClient using backend service credentials/region
        atlas_llm = BedrockClient(BedrockConfig(
            region=self.bedrock_service.region,
            model_id=Config.BEDROCK_MODEL_ID,
            embed_model_id=Config.BEDROCK_EMBED_MODEL_ID,
            access_key=self.bedrock_service.access_key,
            secret_key=self.bedrock_service.secret_key,
            session_token=self.bedrock_service.session_token
        ))
        
        self.build_mechanic = BuildMechanic(
            llm=atlas_llm,
            logger=self.atlas_logger
        )
    
    def validate_fix(
        self,
        repo_path: str,
        files_modified: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Validate that fixes don't break the build or tests.
        
        Args:
            repo_path: Path to repository with fixes applied
            files_modified: Optional list of files that were modified (for targeted testing)
            
        Returns:
            Dictionary with validation results:
            {
                "success": bool,
                "build_ok": bool,
                "tests_ok": bool,
                "build_errors": List[str],
                "test_failures": List[str],
                "build_output": str,
                "test_output": str,
                "message": str
            }
        """
        logger.info(f"[{self.service_name}] Validating fixes in {repo_path}")
        
        result = {
            "success": False,
            "build_ok": False,
            "tests_ok": False,
            "build_errors": [],
            "test_failures": [],
            "build_output": "",
            "test_output": "",
            "message": ""
        }
        
        # Validate repo path exists
        if not Path(repo_path).exists():
            result["message"] = f"Repository path does not exist: {repo_path}"
            logger.error(f"[{self.service_name}] {result['message']}")
            return result
        
        # Step 1: Sanity checks - detect repository facts
        try:
            facts = detect_repo_facts(repo_path)
            logger.info(
                f"[{self.service_name}] Detected: build={facts.build_system}, "
                f"languages={facts.languages}, test_frameworks={facts.test_frameworks}"
            )
            
            # Only validate Maven/Java projects for now
            if facts.build_system != "maven" or "java" not in facts.languages:
                result["message"] = f"Validation skipped: Not a Maven/Java project (build={facts.build_system}, languages={facts.languages})"
                result["success"] = True  # Not a failure, just not supported
                logger.info(f"[{self.service_name}] {result['message']}")
                return result
            
            # Ensure JaCoCo is configured
            if facts.maven_poms:
                ensure_jacoco_in_poms(facts.maven_poms, logger)
        except Exception as e:
            logger.warning(f"[{self.service_name}] Error during sanity checks: {str(e)}")
            # Continue with validation even if sanity checks fail
        
        # Step 2: Build validation
        try:
            logger.info(f"[{self.service_name}] Running build validation (mvn clean install)")
            # mvn_clean_install doesn't take timeout_s in current atlas implementation, using default or adding if needed
            build_res = mvn_clean_install(repo_path)
            
            result["build_ok"] = build_res.ok
            result["build_output"] = (build_res.stdout or "") + "\n" + (build_res.stderr or "")
            
            if not build_res.ok:
                # Extract build errors
                combined_output = result["build_output"]
                error_lines = [
                    line.strip() for line in combined_output.splitlines()
                    if line.strip() and (
                        "ERROR" in line.upper() or
                        "FAILURE" in line.upper() or
                        "failed" in line.lower() or
                        "compilation failure" in line.lower()
                    )
                ]
                result["build_errors"] = error_lines[:20]  # Limit to 20 errors
                result["message"] = f"Build failed: {len(result['build_errors'])} error(s) found. Attempting automatic repair..."
                logger.info(f"[{self.service_name}] {result['message']}")
                
                # AUTOMATIC REPAIR LOOP
                for attempt in range(3):
                    diagnosis = self.build_mechanic.analyze(build_res.stdout, build_res.stderr)
                    if diagnosis.failure_type == "unknown":
                        break
                    
                    domain_models = find_domain_models(repo_path)
                    fix = self.build_mechanic.generate_fix(diagnosis, repo_path, domain_models=domain_models)
                    
                    if fix and fix.file_patches:
                        logger.info(f"[{self.service_name}] Applying automatic build fix (attempt {attempt+1}/3)...")
                        for patch in fix.file_patches:
                            with open(patch.path, "w", encoding="utf-8") as f:
                                f.write(patch.content)
                        
                        # Retry build
                        build_res = mvn_clean_install(repo_path)
                        result["build_ok"] = build_res.ok
                        result["build_output"] = (build_res.stdout or "") + "\n" + (build_res.stderr or "")
                        
                        if build_res.ok:
                            logger.info(f"[{self.service_name}] Build AUTO-REVEALED successfully!")
                            break
                    else:
                        break
                
                if not result["build_ok"]:
                    return result
            else:
                logger.info(f"[{self.service_name}] Build validation passed")
        except Exception as e:
            result["build_errors"] = [f"Build validation exception: {str(e)}"]
            result["message"] = f"Build validation failed with exception: {str(e)}"
            logger.error(f"[{self.service_name}] {result['message']}")
            return result
        
        # Step 3: Test validation (only if build passed)
        if result["build_ok"]:
            try:
                logger.info(f"[{self.service_name}] Running test validation (mvn test)")
                test_res = mvn_test_with_jacoco(repo_path)
                
                result["test_output"] = (test_res.stdout or "") + "\n" + (test_res.stderr or "")
                
                # Parse test results
                test_report = parse_surefire_reports(repo_path)
                result["tests_ok"] = test_report.ok
                
                if not test_report.ok:
                    # Extract test failures
                    result["test_failures"] = [
                        f"{t.get('classname', 'Unknown')}.{t.get('name', 'Unknown')}: {t.get('message', 'No message')}"
                        for t in test_report.failed_tests_list[:20]  # Limit to 20 failures
                    ]
                    result["message"] = (
                        f"Tests failed: {test_report.failed} failed, "
                        f"{test_report.errors} errors out of {test_report.total} total tests"
                    )
                    logger.warning(f"[{self.service_name}] {result['message']}")
                else:
                    logger.info(
                        f"[{self.service_name}] Test validation passed: "
                        f"{test_report.total - test_report.failed - test_report.errors}/{test_report.total} tests passed"
                    )
            except Exception as e:
                result["test_failures"] = [f"Test validation exception: {str(e)}"]
                result["message"] = f"Test validation failed with exception: {str(e)}"
                logger.error(f"[{self.service_name}] {result['message']}")
                # Don't fail overall if test parsing fails, but mark tests as not OK
                result["tests_ok"] = False
        
        # Overall success: build must pass, tests should pass (but we allow test failures if they're pre-existing)
        result["success"] = result["build_ok"]  # Build must pass, tests are nice-to-have
        
        if result["success"]:
            if result["tests_ok"]:
                result["message"] = "Validation passed: Build and tests successful"
            else:
                result["message"] = "Validation passed: Build successful, but some tests failed (may be pre-existing)"
        
        logger.info(f"[{self.service_name}] Validation complete: {result['message']}")
        return result
    
    def get_validation_feedback(self, validation_result: Dict[str, Any]) -> str:
        """
        Generate feedback message for the fix agent based on validation results.
        
        Args:
            validation_result: Result from validate_fix()
            
        Returns:
            Feedback string to help fix agent correct issues
        """
        if validation_result["success"]:
            return "Fix validation passed. No changes needed."
        
        feedback_parts = []
        
        if not validation_result["build_ok"]:
            feedback_parts.append("BUILD FAILED:")
            feedback_parts.append("The code changes broke the build. Common issues:")
            feedback_parts.append("- Syntax errors")
            feedback_parts.append("- Missing imports")
            feedback_parts.append("- Type mismatches")
            feedback_parts.append("- Missing dependencies")
            
            if validation_result["build_errors"]:
                feedback_parts.append("\nSpecific errors found:")
                for error in validation_result["build_errors"][:5]:
                    feedback_parts.append(f"- {error}")
        
        if not validation_result["tests_ok"] and validation_result["build_ok"]:
            feedback_parts.append("\nTESTS FAILED:")
            feedback_parts.append("The build succeeded but tests are failing. This may indicate:")
            feedback_parts.append("- Logic errors in the fix")
            feedback_parts.append("- Breaking changes to existing functionality")
            feedback_parts.append("- Missing null checks or edge cases")
            
            if validation_result["test_failures"]:
                feedback_parts.append("\nSpecific test failures:")
                for failure in validation_result["test_failures"][:5]:
                    feedback_parts.append(f"- {failure}")
        
        return "\n".join(feedback_parts)

