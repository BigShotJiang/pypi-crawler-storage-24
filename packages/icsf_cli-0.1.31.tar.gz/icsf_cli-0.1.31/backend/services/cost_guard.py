import logging
import os
from typing import Dict, Any

logger = logging.getLogger(__name__)

class CostGuardService:
    """
    Tracks and enforces limits on LLM usage to prevent runaway costs.
    """
    
    def __init__(self, max_cost_per_run: float = 5.0, max_runs_per_repo_daily: int = 15):
        self.max_cost_per_run = max_cost_per_run
        self.max_runs_per_repo_daily = max_runs_per_repo_daily
        self._current_run_costs: Dict[str, float] = {}

    def start_run(self, run_id: str) -> None:
        """Initialize cost tracking for a new run."""
        self._current_run_costs[run_id] = 0.0
        logger.info(f"[CostGuard] Started tracking run {run_id}, limit: ${self.max_cost_per_run:.2f}")

    def add_cost(self, run_id: str, prompt_tokens: int, completion_tokens: int, model_id: str) -> bool:
        """
        Record usage and check if budget is exceeded.
        Returns False if budget is exceeded (should abort).
        """
        if run_id not in self._current_run_costs:
            self._current_run_costs[run_id] = 0.0
            
        # Claude 3.5 Sonnet pricing (approximate, per 1K tokens)
        prompt_cost_per_1k = 0.003
        completion_cost_per_1k = 0.015
        
        cost = (prompt_tokens / 1000.0 * prompt_cost_per_1k) + (completion_tokens / 1000.0 * completion_cost_per_1k)
        self._current_run_costs[run_id] += cost
        
        total = self._current_run_costs[run_id]
        
        if total > self.max_cost_per_run:
            logger.error(f"[CostGuard] 🛑 RUN {run_id} EXCEEDED BUDGET: ${total:.2f} > ${self.max_cost_per_run:.2f}")
            return False
            
        logger.debug(f"[CostGuard] Run {run_id} cost: ${total:.2f} / ${self.max_cost_per_run:.2f}")
        return True

    def get_run_cost(self, run_id: str) -> float:
        return self._current_run_costs.get(run_id, 0.0)

cost_guard = CostGuardService()
