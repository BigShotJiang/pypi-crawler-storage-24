"""
Testing Agent Service - ICSF Implementation
"""

import logging
import os
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import HTTPException

from ..config import Config
from .bedrock_service import BedrockService

logger = logging.getLogger(__name__)


class TestingAgentService:
    """
    Testing Agent Service for ICSF backend.
    
    Responsibilities:
    - Run the full Java testing pipeline (clone -> sanity -> build -> generate tests -> test -> coverage).
    - Optionally create a GitHub PR with generated tests.
    - Return a JSON-serializable report that the frontend can display.
    """

    def __init__(self) -> None:
        """Initialize testing agent service."""
        self._logger = logger
        self._active_runs = set() # Track active repo_urls or repo_paths
        
        # Initialize BedrockService
        try:
            self.bedrock_service = BedrockService(
                access_key=Config.AWS_ACCESS_KEY_ID,
                secret_key=Config.AWS_SECRET_ACCESS_KEY,
                region=Config.AWS_REGION
            )
        except Exception as e:
            logger.warning(f"[TestingAgentService] BedrockService initialization failed: {str(e)}")
            self.bedrock_service = None

    def _check_required_tools(self) -> None:
        """Check if required tools (git, mvn, java) are available on PATH."""
        missing_tools = []
        
        # Check for git
        git_path = shutil.which("git")
        if not git_path:
            missing_tools.append("git")
        else:
            self._logger.debug(f"[TestingAgentService] Found git at: {git_path}")
        
        # Check for mvn
        mvn_path = shutil.which("mvn")
        if not mvn_path:
            missing_tools.append("mvn (Maven)")
        else:
            self._logger.debug(f"[TestingAgentService] Found mvn at: {mvn_path}")
        
        # Check for java
        java_path = shutil.which("java")
        if not java_path:
            missing_tools.append("java (JDK)")
        else:
            self._logger.debug(f"[TestingAgentService] Found java at: {java_path}")
        
        if missing_tools:
            tools_list = ", ".join(missing_tools)
            current_path = os.environ.get("PATH", "")
            path_entries = current_path.split(os.pathsep) if current_path else []
            path_preview = "\n".join(path_entries[:10])
            if len(path_entries) > 10:
                path_preview += f"\n... and {len(path_entries) - 10} more entries"
            
            error_msg = (
                f"Testing pipeline cannot start: the following tools are not found on PATH: {tools_list}. "
                f"\n\nBackend PATH (first 10 entries):\n{path_preview}\n\n"
                "This usually means:\n"
                "1. The backend server was started before PATH was updated, OR\n"
                "2. The backend is running in an environment that doesn't inherit system PATH.\n\n"
                "Solution: Restart the backend server (uvicorn) from the same PowerShell/terminal "
                "where 'git', 'mvn', and 'java' commands work."
            )
            self._logger.error(f"[TestingAgentService] {error_msg}")
            raise HTTPException(status_code=500, detail=error_msg)

    async def run_testing_pipeline(
        self, 
        repo_url: str, 
        create_pr: bool = False,
        job_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Run the testing pipeline on a remote respository.

        Args:
            repo_url: Git URL of the repository (HTTPS or SSH).
            create_pr: If True and GitHub credentials are configured, create a PR with generated tests.
            job_id: Optional job tracking ID.

        Returns:
            Dictionary with the full run report (build, tests, coverage, generation, breakage, pr_url, sanity, facts).
        """
        if not repo_url or not repo_url.strip():
            raise HTTPException(status_code=400, detail="repo_url is required")

        # Concurrency guard
        repo_url_clean = repo_url.strip()
        if repo_url_clean in self._active_runs:
            self._logger.warning(f"[TestingAgentService] Pipeline already running for {repo_url_clean}. Blocking redundant request.")
            raise HTTPException(status_code=409, detail=f"A testing pipeline is already running for {repo_url_clean}. Please wait for it to complete.")
        
        self._active_runs.add(repo_url_clean)

        try:
            # Validate required tools
            self._check_required_tools()
            
            # Validate BedrockService
            if not self.bedrock_service:
                raise HTTPException(
                    status_code=500,
                    detail="BedrockService not initialized. Check AWS credentials in .env file."
                )

            # Get App Config
            from atlas.core.config import load_config
            from atlas.orchestrator.run_pipeline import run_full_pipeline
            cfg = load_config()

            github_creds = Config.get_github_credentials()
            git_token = cfg.github_token or github_creds.get("token")
            git_user = cfg.github_username or github_creds.get("username")
            git_email = cfg.github_email or github_creds.get("email")

            import asyncio
            from atlas.core.logging import RunLogger
            from .job_manager import job_manager
            
            def _broadcast_log(msg: str):
                self._logger.info(msg)
                if job_id:
                    job_manager.update_job(job_id, "RUNNING", msg)
                    
            pipeline_logger = RunLogger(emit=_broadcast_log)
            
            # Run pipeline using the new Atlas orchestrator in a separate thread to avoid blocking
            report = await asyncio.to_thread(
                run_full_pipeline,
                repo_url=repo_url_clean,
                cfg_data_dir=cfg.data_dir,
                cfg_runs_dir=cfg.runs_dir,
                aws_region=cfg.aws_region,
                bedrock_model_id=cfg.bedrock_model_id,
                bedrock_embed_model_id=cfg.bedrock_embed_model_id,
                aws_access_key_id=cfg.aws_access_key_id,
                aws_secret_access_key=cfg.aws_secret_access_key,
                aws_session_token=cfg.aws_session_token,
                github_token=git_token,
                github_username=git_user,
                github_email=git_email,
                logger=pipeline_logger,
                create_pr=create_pr,
                quality_gate_min_coverage_pct=cfg.quality_gate_min_coverage_pct,
                quality_gate_max_failures=cfg.quality_gate_max_failures,
                create_github_issues_for_failures=cfg.create_github_issues_for_failures,
            )
            
            # Convert to dict
            from atlas.reporting.models import OrganizationRunReport
            def _to_json(obj: Any) -> Any:
                if hasattr(obj, "__dict__"):
                    return {k: _to_json(v) for k, v in obj.__dict__.items()}
                if isinstance(obj, list):
                    return [_to_json(x) for x in obj]
                if isinstance(obj, dict):
                    return {k: _to_json(v) for k, v in obj.items()}
                return obj

            report_dict = _to_json(report)
            
            return {
                "success": True,
                "repo_url": report.repo_url,
                "run_id": report.run_id,
                "report": report_dict,
                "logs": []  # Pipeline logs are captured in the RunLogger if needed
            }
            
        except FileNotFoundError as e:
            missing = e.filename or ""
            missing_tool = os.path.basename(missing) if missing else "required external command (git/mvn/java)"
            friendly = (
                f"Testing pipeline failed: tool '{missing_tool}' not found or could not be executed. "
                "Please ensure Git, Maven (mvn), and Java JDK are installed, available on PATH, "
                "and that the backend has permission to run them."
            )
            self._logger.error(f"[TestingAgentService] {friendly}", exc_info=True)
            raise HTTPException(status_code=500, detail=friendly)
        except HTTPException:
            raise
        except Exception as e:
            msg = str(e) or ""
            if "WinError 2" in msg or "The system cannot find the file specified" in msg:
                friendly = (
                    "Testing pipeline failed: required external tools were not found on the system PATH. "
                    "Please ensure Git, Maven (mvn), and a Java JDK are installed and available on PATH, "
                    "then restart the backend and try again."
                )
                self._logger.error(f"[TestingAgentService] {friendly} (original error: {msg})", exc_info=True)
                raise HTTPException(status_code=500, detail=friendly)

            self._logger.error(f"[TestingAgentService] Pipeline failed: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Testing pipeline failed: {msg}")
        finally:
            # Always remove from active runs
            if repo_url_clean in self._active_runs:
                self._active_runs.remove(repo_url_clean)

    async def run_testing_pipeline_local(
        self, 
        repo_path: str, 
        repo_url: str, 
        fixed_files: Optional[List[str]] = None,
        create_pr: bool = False,
        job_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Run the testing pipeline on a local repository path.

        Args:
            repo_path: Local path to the repository.
            repo_url: Git URL of the repository (for metadata/PR).
            fixed_files: Optional list of files that were modified (to target tests).
            create_pr: If True and GitHub credentials are configured, create a PR with generated tests.
            job_id: Optional job tracking ID.

        Returns:
            Dictionary with the full run report.
        """
        if not repo_path or not os.path.exists(repo_path):
            raise HTTPException(status_code=400, detail=f"Valid repo_path is required. Got: {repo_path}")

        # Concurrency guard
        identifier = repo_path or repo_url
        if identifier in self._active_runs:
            self._logger.warning(f"[TestingAgentService] Local pipeline already running for {identifier}. Blocking redundant request.")
            raise HTTPException(status_code=409, detail=f"A testing pipeline is already running for this repository. Please wait.")

        self._active_runs.add(identifier)

        try:
            # Validate required tools
            self._check_required_tools()
            
            # Validate BedrockService
            if not self.bedrock_service:
                raise HTTPException(
                    status_code=500,
                    detail="BedrockService not initialized. Check AWS credentials in .env file."
                )

            # Get App Config
            from atlas.core.config import load_config
            from atlas.orchestrator.run_pipeline import run_full_pipeline_local
            cfg = load_config()

            github_creds = Config.get_github_credentials()
            git_token = cfg.github_token or github_creds.get("token")
            git_user = cfg.github_username or github_creds.get("username")
            git_email = cfg.github_email or github_creds.get("email")

            # Map fixed_files to preferred_classes
            preferred_classes = []
            if fixed_files:
                for f in fixed_files:
                    # Basic heuristic to extract class name from file path
                    if f.endswith(".java"):
                        class_name = os.path.basename(f).replace(".java", "")
                        # We don't have the package easily, but the generator can handle it or we can try to find it
                        preferred_classes.append({"class": class_name})

            import asyncio
            from atlas.core.logging import RunLogger
            from .job_manager import job_manager
            
            def _broadcast_log(msg: str):
                self._logger.info(msg)
                if job_id:
                    job_manager.update_job(job_id, "RUNNING", msg)
                    
            pipeline_logger = RunLogger(emit=_broadcast_log)
            
            # Run pipeline using the new local orchestrator in a separate thread
            report = await asyncio.to_thread(
                run_full_pipeline_local,
                repo_path=repo_path,
                repo_url=repo_url.strip() if repo_url else "local",
                cfg_data_dir=cfg.data_dir,
                aws_region=cfg.aws_region,
                bedrock_model_id=cfg.bedrock_model_id,
                bedrock_embed_model_id=cfg.bedrock_embed_model_id,
                aws_access_key_id=cfg.aws_access_key_id,
                aws_secret_access_key=cfg.aws_secret_access_key,
                aws_session_token=cfg.aws_session_token,
                github_token=git_token,
                github_username=git_user,
                github_email=git_email,
                logger=pipeline_logger,
                create_pr=create_pr,
                quality_gate_min_coverage_pct=cfg.quality_gate_min_coverage_pct,
                quality_gate_max_failures=cfg.quality_gate_max_failures,
                create_github_issues_for_failures=cfg.create_github_issues_for_failures,
                preferred_classes=preferred_classes if preferred_classes else None,
            )
            
            # Convert to dict
            def _to_json(obj: Any) -> Any:
                if hasattr(obj, "__dict__"):
                    return {k: _to_json(v) for k, v in obj.__dict__.items()}
                if isinstance(obj, list):
                    return [_to_json(x) for x in obj]
                if isinstance(obj, dict):
                    return {k: _to_json(v) for k, v in obj.items()}
                return obj

            report_dict = _to_json(report)
            
            return {
                "success": True,
                "repo_path": repo_path,
                "run_id": report.run_id,
                "report": report_dict,
                "logs": []
            }
            
        except Exception as e:
            self._logger.error(f"[TestingAgentService] Local pipeline failed: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Testing pipeline failed: {str(e)}")
        finally:
            if identifier in self._active_runs:
                self._active_runs.remove(identifier)

    async def run_baseline_only(
        self,
        repo_path: str,
        repo_url: str = "local",
    ) -> Dict[str, Any]:
        """
        Run a lightweight baseline: build + existing tests + coverage only.
        NO AI test generation, NO RAG, NO LLM calls, NO test healing.
        Used for the 'before_fix' phase to establish a fast baseline.

        Args:
            repo_path: Local path to the repository.
            repo_url: Git URL of the repository (for metadata).

        Returns:
            Dictionary with the baseline run report.
        """
        if not repo_path or not os.path.exists(repo_path):
            raise HTTPException(status_code=400, detail=f"Valid repo_path is required. Got: {repo_path}")

        # Concurrency guard
        identifier = f"baseline:{repo_path}"
        if identifier in self._active_runs:
            self._logger.warning(f"[TestingAgentService] Baseline already running for {repo_path}. Blocking.")
            raise HTTPException(status_code=409, detail="A baseline is already running for this repository.")

        self._active_runs.add(identifier)

        try:
            # Validate required tools
            self._check_required_tools()

            from atlas.core.config import load_config
            from atlas.orchestrator.run_pipeline import run_baseline_only as _run_baseline
            cfg = load_config()

            import asyncio
            report = await asyncio.to_thread(
                _run_baseline,
                repo_path=repo_path,
                repo_url=repo_url.strip() if repo_url else "local",
                cfg_data_dir=cfg.data_dir,
                aws_region=cfg.aws_region,
                bedrock_model_id=cfg.bedrock_model_id,
                bedrock_embed_model_id=cfg.bedrock_embed_model_id,
                aws_access_key_id=cfg.aws_access_key_id,
                aws_secret_access_key=cfg.aws_secret_access_key,
                aws_session_token=cfg.aws_session_token,
                logger=logger,
            )

            # Convert to dict
            def _to_json(obj: Any) -> Any:
                if hasattr(obj, "__dict__"):
                    return {k: _to_json(v) for k, v in obj.__dict__.items()}
                if isinstance(obj, list):
                    return [_to_json(x) for x in obj]
                if isinstance(obj, dict):
                    return {k: _to_json(v) for k, v in obj.items()}
                return obj

            report_dict = _to_json(report)

            return {
                "success": True,
                "repo_path": repo_path,
                "run_id": report.run_id,
                "report": report_dict,
                "lightweight": True,
                "logs": []
            }

        except Exception as e:
            self._logger.error(f"[TestingAgentService] Baseline failed: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Baseline pipeline failed: {str(e)}")
        finally:
            if identifier in self._active_runs:
                self._active_runs.remove(identifier)


atlas_service = TestingAgentService()

