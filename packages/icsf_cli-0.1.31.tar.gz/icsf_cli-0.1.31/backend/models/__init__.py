"""
Models package for Multi-Agent Vulnerability Fixing System

Contains Pydantic models for agent inputs, outputs, and data structures.
"""

