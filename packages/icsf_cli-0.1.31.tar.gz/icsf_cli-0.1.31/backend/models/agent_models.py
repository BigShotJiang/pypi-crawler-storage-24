"""
Pydantic models for Multi-Agent Vulnerability Fixing System

Defines data structures for agent inputs, outputs, and intermediate results.
"""

from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from enum import Enum


class VulnerabilitySeverity(str, Enum):
    """Vulnerability severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class SecurityImpact(BaseModel):
    """Security impact assessment"""
    confidentiality: str = Field(..., description="Impact on confidentiality")
    integrity: str = Field(..., description="Impact on integrity")
    availability: str = Field(..., description="Impact on availability")
    overall_risk: str = Field(..., description="Overall risk level")


class VulnerabilityAnalysis(BaseModel):
    """Output from Agent 1: Vulnerability Analyzer"""
    vulnerability_type: str = Field(..., description="Type of vulnerability")
    severity: VulnerabilitySeverity = Field(..., description="Severity level")
    description: str = Field(..., description="Vulnerability description")
    security_impact: SecurityImpact = Field(..., description="Security impact assessment")
    root_causes: List[str] = Field(default_factory=list, description="Common root causes")
    fix_category: str = Field(..., description="Fix category/pattern (e.g., Input Validation)")
    security_guidelines: List[str] = Field(default_factory=list, description="References to OWASP/CWE")
    typical_fix_approach: str = Field(..., description="Typical fix approach for this vulnerability")


class CodeContext(BaseModel):
    """Output from Agent 2: Code Context Agent"""
    vulnerable_file: str = Field(..., description="Path to vulnerable file")
    vulnerable_line: int = Field(..., description="Line number of vulnerability")
    code_snippet: str = Field(..., description="Vulnerable code snippet")
    class_name: Optional[str] = Field(None, description="Class containing vulnerability")
    method_name: Optional[str] = Field(None, description="Method containing vulnerability")
    function_signature: Optional[str] = Field(None, description="Function/method signature")
    dependent_files_intra: List[Dict[str, Any]] = Field(default_factory=list, description="Intra-repo dependent files")
    dependent_files_inter: List[Dict[str, Any]] = Field(default_factory=list, description="Inter-repo dependent files")
    data_flow: Optional[str] = Field(None, description="Data flow analysis around vulnerability")
    usage_patterns: List[str] = Field(default_factory=list, description="Usage patterns")


class FixStrategy(BaseModel):
    """Output from Agent 3: Fix Strategy Agent"""
    fix_approach: str = Field(..., description="Overall fix approach")
    code_changes_plan: List[str] = Field(default_factory=list, description="Step-by-step code changes")
    files_to_modify_primary: List[str] = Field(default_factory=list, description="Primary files to modify")
    files_to_modify_secondary: List[str] = Field(default_factory=list, description="Secondary files that may need updates")
    risk_assessment: str = Field(..., description="Risk assessment of the fix")
    backward_compatibility: bool = Field(True, description="Whether fix maintains backward compatibility")
    testing_considerations: List[str] = Field(default_factory=list, description="Testing considerations")


class CodeFix(BaseModel):
    """Output from Agent 4: Code Fix Agent"""
    fixed_code: Dict[str, str] = Field(..., description="Dictionary mapping file paths to fixed code")
    original_code: Dict[str, str] = Field(default_factory=dict, description="Dictionary mapping file paths to original code (for diff display)")
    changed_lines: List[Dict[str, Any]] = Field(default_factory=list, description="Line-by-line changes")
    files_modified: List[str] = Field(default_factory=list, description="List of modified files")
    diff: str = Field(..., description="Code diff (before/after)")
    change_summary: str = Field(..., description="Summary of changes")
    reasoning: Optional[str] = Field(None, description="Reasoning/Chain of Thought for the fix")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional metadata (e.g., validation results)")



class ValidationResult(str, Enum):
    """Validation result status"""
    APPROVED = "approved"
    REJECTED = "rejected"
    NEEDS_REVIEW = "needs_review"


class SafetyValidation(BaseModel):
    """Output from Agent 5: Safety Validator Agent"""
    validation_status: ValidationResult = Field(..., description="Validation result")
    correctness_score: float = Field(..., ge=0.0, le=1.0, description="Correctness score (0-1)")
    breaking_changes: bool = Field(False, description="Whether fix introduces breaking changes")
    backward_compatible: bool = Field(True, description="Whether fix maintains backward compatibility")
    new_vulnerabilities: bool = Field(False, description="Whether fix introduces new vulnerabilities")
    code_style_consistent: bool = Field(True, description="Whether code style is consistent")
    issues_found: List[str] = Field(default_factory=list, description="Issues found during validation")
    suggestions: List[str] = Field(default_factory=list, description="Suggestions for improvement")


class FixExplanation(BaseModel):
    """Output from Agent 6: Explanation Agent"""
    vulnerability_summary: str = Field(..., description="What was the vulnerability")
    security_impact_explanation: str = Field(..., description="Why it was dangerous")
    fix_explanation: str = Field(..., description="How it was fixed")
    code_changes_explanation: str = Field(..., description="What changed in the code")
    developer_notes: str = Field(..., description="Notes for developers")
    markdown_report: str = Field(..., description="Complete markdown report")


class VulnerabilityFixRequest(BaseModel):
    """Input request for fixing a vulnerability"""
    vulnerability_type: str = Field(..., description="Type of vulnerability")
    description: str = Field(..., description="Vulnerability description")
    severity: VulnerabilitySeverity = Field(..., description="Severity level")
    recommendation: Optional[str] = Field(None, description="Scanner recommendation")
    file_path: str = Field(..., description="Path to vulnerable file")
    line_number: int = Field(..., description="Line number of vulnerability")
    repo_path: str = Field(..., description="Path to repository root")
    repo_name: str = Field(..., description="Repository name")


class AgentResponse(BaseModel):
    """Base response structure for agent outputs"""
    success: bool = Field(..., description="Whether operation succeeded")
    agent_name: str = Field(..., description="Name of the agent")
    output: Optional[Dict[str, Any]] = Field(None, description="Agent output")
    error: Optional[str] = Field(None, description="Error message if failed")
    execution_time: Optional[float] = Field(None, description="Execution time in seconds")


class FixOrchestrationResult(BaseModel):
    """Complete result from fix orchestration"""
    vulnerability_request: VulnerabilityFixRequest
    vulnerability_analysis: Optional[VulnerabilityAnalysis] = None
    code_context: Optional[CodeContext] = None
    fix_strategy: Optional[FixStrategy] = None
    code_fix: Optional[CodeFix] = None
    safety_validation: Optional[SafetyValidation] = None
    fix_explanation: Optional[FixExplanation] = None
    overall_status: str = Field(..., description="Overall status: pending/success/failed")
    errors: List[str] = Field(default_factory=list, description="List of errors encountered")

