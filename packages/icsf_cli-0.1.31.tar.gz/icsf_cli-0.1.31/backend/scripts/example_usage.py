"""
Example usage of the GitHub Repositories API

This file demonstrates how to use the API endpoints.
You can use this as a reference or test the API.
"""

import requests

# Base URL of the API
BASE_URL = "http://localhost:8000"


def example_post_request():
    """Example POST request to fetch repositories"""
    url = f"{BASE_URL}/api/repos"
    
    payload = {
        "username": "octocat",  # Replace with actual GitHub username
        "token": "your_github_token_here"  # Replace with your GitHub token
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        print(f"Found {data['total_repos']} repositories for user: {data['username']}")
        print(f"Public repos: {data['public_repos']}, Private repos: {data['private_repos']}")
        
        for repo in data['repositories'][:5]:  # Print first 5 repos
            print(f"\n- {repo['name']}")
            print(f"  Language: {repo.get('language', 'N/A')}")
            print(f"  Stars: {repo['stars']}, Forks: {repo['forks']}")
            print(f"  URL: {repo['html_url']}")
    else:
        print(f"Error: {response.status_code}")
        print(response.json())


def example_get_request():
    """Example GET request to fetch repositories"""
    url = f"{BASE_URL}/api/repos"
    
    params = {
        "username": "octocat",  # Replace with actual GitHub username
        "token": "your_github_token_here"  # Replace with your GitHub token
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        print(f"Found {data['total_repos']} repositories")
        return data
    else:
        print(f"Error: {response.status_code}")
        print(response.json())
        return None


def example_with_email():
    """Example using email instead of username"""
    url = f"{BASE_URL}/api/repos"
    
    payload = {
        "email": "user@example.com",  # Must match the authenticated user's email
        "token": "your_github_token_here"  # Replace with your GitHub token
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        print(f"Found {data['total_repos']} repositories")
        return data
    else:
        print(f"Error: {response.status_code}")
        print(response.json())
        return None


if __name__ == "__main__":
    print("GitHub Repositories API - Example Usage\n")
    print("Make sure the FastAPI server is running on http://localhost:8000")
    print("\nUncomment one of the examples below to test:\n")
    
    # Uncomment to test:
    # example_post_request()
    # example_get_request()
    # example_with_email()

