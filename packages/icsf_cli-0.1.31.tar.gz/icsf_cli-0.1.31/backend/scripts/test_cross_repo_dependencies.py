"""
Test script to test cross-repository dependency mapping
Tests how the dependent repository depends on the banking app repository
"""
import os
import sys
import json
from pathlib import Path

# Fix encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# Add backend directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.dependency_service import DependencyService

def main():
    # Paths to both repositories
    banking_repo_path = os.path.join(os.path.dirname(__file__), 'temp_analysis_repo')
    dependent_repo_path = os.path.join(os.path.dirname(__file__), 'test_dependent_repo')
    
    if not os.path.exists(banking_repo_path):
        print(f"❌ Banking repository not found at {banking_repo_path}")
        print("Please ensure the banking repository is cloned first")
        return
    
    if not os.path.exists(dependent_repo_path):
        print(f"❌ Dependent repository not found at {dependent_repo_path}")
        print("Please ensure the dependent repository is created")
        return
    
    print("=" * 80)
    print("CROSS-REPOSITORY DEPENDENCY MAPPING TEST")
    print("=" * 80)
    print()
    
    # Test 1: Find Maven artifact for a vulnerable file in banking app
    print("📋 Test 1: Finding Maven artifact for vulnerable file")
    print("-" * 80)
    vulnerable_file = "src/main/java/models/Account.java"
    vulnerable_file_full_path = os.path.join(banking_repo_path, vulnerable_file)
    
    if os.path.exists(vulnerable_file_full_path):
        artifact = DependencyService.find_maven_artifact_for_file(vulnerable_file, banking_repo_path)
        if artifact:
            print(f"✅ Vulnerable File: {vulnerable_file}")
            print(f"   Maven Artifact: {artifact.get('groupId')}:{artifact.get('artifactId')}:{artifact.get('version')}")
            group_id = artifact.get('groupId')
            artifact_id = artifact.get('artifactId')
        else:
            print(f"❌ Could not find Maven artifact for {vulnerable_file}")
            return
    else:
        print(f"❌ Vulnerable file not found: {vulnerable_file}")
        return
    
    print()
    
    # Test 2: Find cross-repo dependent files
    print("📋 Test 2: Finding cross-repository dependent files")
    print("-" * 80)
    
    # Prepare repository list with clone paths
    all_repos = [
        {
            'id': 1,
            'full_name': 'test/banking-app',
            'clone_path': banking_repo_path
        },
        {
            'id': 2,
            'full_name': 'test/banking-client-service',
            'clone_path': dependent_repo_path
        }
    ]
    
    cross_repo_result = DependencyService.find_cross_repo_dependent_files(
        vulnerable_file=vulnerable_file,
        vulnerable_repo_path=banking_repo_path,
        vulnerable_repo_name='test/banking-app',
        vulnerable_repo_id=1,
        all_repos=all_repos,
        max_depth=3
    )
    
    if cross_repo_result.get('cross_repo_dependents'):
        print(f"✅ Found {len(cross_repo_result['cross_repo_dependents'])} cross-repo dependent files")
        print()
        
        for dep in cross_repo_result['cross_repo_dependents']:
            print(f"📁 Repository: {dep.get('repo')}")
            print(f"   File: {dep.get('file')}")
            print(f"   Maven Artifact: {dep.get('maven_artifact')}")
            print(f"   Classes Used: {', '.join(dep.get('classes_used', []))}")
            print(f"   Imports: {', '.join(dep.get('imports', []))}")
            print(f"   Depth: {dep.get('depth')}")
            print()
    else:
        print("⚠️  No cross-repo dependent files found")
        print("   This might be because:")
        print("   1. The dependent repository's pom.xml doesn't match the artifact")
        print("   2. The Java files don't import from the vulnerable package")
        print()
    
    # Test 3: Check dependency chains
    print("📋 Test 3: Dependency Chains")
    print("-" * 80)
    
    if cross_repo_result.get('dependency_chains'):
        print(f"✅ Found {len(cross_repo_result['dependency_chains'])} dependency chains")
        print()
        
        for i, chain in enumerate(cross_repo_result['dependency_chains'], 1):
            print(f"Chain {i}:")
            print(f"   From: {chain.get('from_repo')} ({chain.get('from_artifact')})")
            print(f"   To: {chain.get('to_repo')} ({chain.get('to_artifact')})")
            print(f"   Depth: {chain.get('depth')}")
            print(f"   Chain: {' → '.join(chain.get('chain', []))}")
            if chain.get('intermediate_repos'):
                print(f"   Intermediate: {', '.join(chain['intermediate_repos'])}")
            print(f"   Affected Files: {len(chain.get('files', []))}")
            print()
    else:
        print("⚠️  No dependency chains found")
        print()
    
    # Test 4: Verify Maven dependency in dependent repo
    print("📋 Test 4: Verifying Maven dependency in dependent repository")
    print("-" * 80)
    
    dependent_pom = os.path.join(dependent_repo_path, 'pom.xml')
    if os.path.exists(dependent_pom):
        pom_data = DependencyService.parse_pom_xml(dependent_pom)
        dependencies = pom_data.get('dependencies', [])
        
        found_dependency = False
        for dep in dependencies:
            if dep.get('groupId') == group_id and dep.get('artifactId') == artifact_id:
                found_dependency = True
                print(f"✅ Found dependency in pom.xml:")
                print(f"   {dep.get('groupId')}:{dep.get('artifactId')}:{dep.get('version')}")
                break
        
        if not found_dependency:
            print(f"⚠️  Dependency {group_id}:{artifact_id} not found in dependent repository's pom.xml")
            print(f"   This is why cross-repo dependencies might not be detected")
    else:
        print(f"❌ pom.xml not found in dependent repository")
    
    print()
    
    # Test 5: Check Java files that use banking app classes
    print("📋 Test 5: Checking Java files that import banking app classes")
    print("-" * 80)
    
    java_files = DependencyService.find_java_files(dependent_repo_path)
    print(f"Found {len(java_files)} Java files in dependent repository")
    print()
    
    banking_package = "models"  # Package where Account.java is located
    files_using_banking = []
    
    for java_file in java_files:
        java_file_full_path = os.path.join(dependent_repo_path, java_file)
        parsed = DependencyService.parse_java_file(java_file_full_path)
        imports = parsed.get('imports_full', [])
        
        # Check if file imports from banking app package
        uses_banking = False
        banking_imports = []
        for imp in imports:
            if imp.startswith(banking_package) or 'models.' in imp or 'util.' in imp:
                uses_banking = True
                banking_imports.append(imp)
        
        if uses_banking:
            files_using_banking.append((java_file, banking_imports))
            print(f"✅ {java_file}")
            print(f"   Imports: {', '.join(banking_imports)}")
            print()
    
    if not files_using_banking:
        print("⚠️  No files found that import from banking app")
    
    print()
    print("=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    print(f"Cross-repo dependent files found: {len(cross_repo_result.get('cross_repo_dependents', []))}")
    print(f"Dependency chains found: {len(cross_repo_result.get('dependency_chains', []))}")
    print(f"Files using banking app: {len(files_using_banking)}")
    print()
    
    # Save results
    output_file = os.path.join(os.path.dirname(__file__), 'cross_repo_test_results.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            'vulnerable_file': vulnerable_file,
            'vulnerable_artifact': artifact,
            'cross_repo_dependents': cross_repo_result.get('cross_repo_dependents', []),
            'dependency_chains': cross_repo_result.get('dependency_chains', []),
            'files_using_banking': files_using_banking
        }, f, indent=2)
    
    print(f"Results saved to: {output_file}")

if __name__ == "__main__":
    main()

