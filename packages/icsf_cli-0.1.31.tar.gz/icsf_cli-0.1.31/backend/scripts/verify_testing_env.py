import os
import shutil
import subprocess
import yaml
from pathlib import Path

def check_tools():
    print("--- Checking External Tools ---")
    for tool in ["git", "mvn", "java"]:
        path = shutil.which(tool)
        if path:
            print(f"✅ {tool} found at: {path}")
            # Try to get version
            try:
                if tool == "java":
                    cmd = [tool, "-version"]
                else:
                    cmd = [tool, "--version"]
                res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                print(f"   Version: {res.stdout.strip() or res.stderr.strip().splitlines()[0]}")
            except Exception as e:
                print(f"   ⚠️ Could not get version: {e}")
        else:
            print(f"❌ {tool} NOT FOUND on PATH")

def check_dirs():
    print("\n--- Checking Directories ---")
    # Check for temp_cloned_repos
    dirs_to_check = [
        "/app/temp_cloned_repos",
        "/app/data/atlas",
        "/app/data/temp_test_runs"
    ]
    for d in dirs_to_check:
        if os.path.exists(d):
            print(f"✅ Directory exists: {d}")
            # Check writability
            if os.access(d, os.W_OK):
                print(f"   Writability: OK")
            else:
                print(f"   ❌ Writability: FAILED")
        else:
            print(f"⚠️ Directory DOES NOT exist: {d}")

def check_env():
    print("\n--- Checking Environment Variables ---")
    vars_to_check = [
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        "AWS_REGION",
        "APP_DATA_DIR",
        "APP_RUNS_DIR",
        "BEDROCK_MODEL_ID"
    ]
    for var in vars_to_check:
        val = os.getenv(var)
        if val:
            # Mask secret
            if "SECRET" in var or "KEY" in var:
                masked = val[:4] + "*" * (len(val) - 8) + val[-4:] if len(val) > 8 else "****"
                print(f"✅ {var} is set: {masked}")
            else:
                print(f"✅ {var} is set: {val}")
        else:
            print(f"❌ {var} is NOT SET")

if __name__ == "__main__":
    print("=== Testing Agent Environment Verification ===\n")
    check_tools()
    check_dirs()
    check_env()
    print("\n=== End of Verification ===")
