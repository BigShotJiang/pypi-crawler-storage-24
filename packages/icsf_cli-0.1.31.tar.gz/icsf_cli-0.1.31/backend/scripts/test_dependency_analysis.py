"""
Test script to analyze dependencies in the maven-banking-app repository
"""
import os
import sys
import json
from pathlib import Path

# Add backend directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.dependency_service import DependencyService

def main():
    # Path to cloned repository
    repo_path = os.path.join(os.path.dirname(__file__), 'temp_analysis_repo')
    
    if not os.path.exists(repo_path):
        print(f"Repository not found at {repo_path}")
        print("Please clone the repository first")
        return
    
    print("=" * 80)
    print("DEPENDENCY ANALYSIS FOR MAVEN-BANKING-APP")
    print("=" * 80)
    print()
    
    # Find all Java files
    java_files = DependencyService.find_java_files(repo_path)
    print(f"Found {len(java_files)} Java files")
    print()
    
    # Build dependency map
    print("Building dependency map...")
    dependency_map = DependencyService.build_intra_repo_dependencies(repo_path)
    print(f"Found dependencies for {len(dependency_map)} files")
    print()
    
    # Display dependencies for each file
    print("=" * 80)
    print("DEPENDENCY LISTING BY FILE")
    print("=" * 80)
    print()
    
    # Sort files by path
    sorted_files = sorted(dependency_map.keys())
    
    for file_path in sorted_files:
        deps = dependency_map[file_path]
        if deps:
            print(f"FILE: {file_path}")
            print(f"   -> Has {len(deps)} dependent file(s):")
            for dep in deps:
                dep_type = dep.get('type', 'unknown')
                dep_file = dep.get('file', 'N/A')
                dep_class = dep.get('class', dep.get('interface', ''))
                
                type_symbols = {
                    'import': '[IMPORT]',
                    'instantiation': '[NEW]',
                    'implements': '[IMPLEMENTS]',
                    'extends': '[EXTENDS]',
                    'class_reference': '[REF]',
                    'same_package': '[SAME_PKG]'
                }
                symbol = type_symbols.get(dep_type, '[UNKNOWN]')
                
                if dep_class:
                    print(f"      {symbol} -> {dep_file} (uses: {dep_class})")
                else:
                    print(f"      {symbol} -> {dep_file}")
            print()
    
    # Show files with no dependencies
    files_with_deps = set(dependency_map.keys())
    files_without_deps = [f for f in java_files if f not in files_with_deps]
    
    if files_without_deps:
        print("=" * 80)
        print("FILES WITH NO DEPENDENCIES (Leaf Nodes)")
        print("=" * 80)
        for file_path in sorted(files_without_deps):
            print(f"  - {file_path}")
        print()
    
    # Reverse mapping: Which files depend on each file?
    print("=" * 80)
    print("REVERSE DEPENDENCY MAP (What depends on each file?)")
    print("=" * 80)
    print()
    
    reverse_map = {}
    for file_path, deps in dependency_map.items():
        for dep in deps:
            dep_file = dep.get('file')
            if dep_file not in reverse_map:
                reverse_map[dep_file] = []
            reverse_map[dep_file].append({
                'file': file_path,
                'type': dep.get('type'),
                'class': dep.get('class', dep.get('interface', ''))
            })
    
    # Sort by number of dependents (most dependent files first)
    sorted_reverse = sorted(reverse_map.items(), key=lambda x: len(x[1]), reverse=True)
    
    for dep_file, dependents in sorted_reverse:
        print(f"FILE: {dep_file}")
        print(f"   <- Depended upon by {len(dependents)} file(s):")
        for dep in dependents:
            dep_type = dep.get('type', 'unknown')
            dependent_file = dep.get('file', 'N/A')
            dep_class = dep.get('class', '')
            
            type_symbols = {
                'import': '[IMPORT]',
                'instantiation': '[NEW]',
                'implements': '[IMPLEMENTS]',
                'extends': '[EXTENDS]',
                'class_reference': '[REF]',
                'same_package': '[SAME_PKG]'
            }
            symbol = type_symbols.get(dep_type, '[UNKNOWN]')
            
            if dep_class:
                print(f"      {symbol} <- {dependent_file} (uses: {dep_class})")
            else:
                print(f"      {symbol} <- {dependent_file}")
        print()
    
    # Summary statistics
    print("=" * 80)
    print("SUMMARY STATISTICS")
    print("=" * 80)
    print(f"Total Java files: {len(java_files)}")
    print(f"Files with dependencies: {len(dependency_map)}")
    print(f"Files with dependents: {len(reverse_map)}")
    print(f"Total dependency relationships: {sum(len(deps) for deps in dependency_map.values())}")
    
    # Dependency type breakdown
    type_counts = {}
    for deps in dependency_map.values():
        for dep in deps:
            dep_type = dep.get('type', 'unknown')
            type_counts[dep_type] = type_counts.get(dep_type, 0) + 1
    
    print()
    print("Dependency types breakdown:")
    for dep_type, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"  {dep_type}: {count}")
    
    # Save to JSON file
    output_file = os.path.join(os.path.dirname(__file__), 'dependency_analysis_results.json')
    output_data = {
        'total_files': len(java_files),
        'files_with_dependencies': len(dependency_map),
        'files_with_dependents': len(reverse_map),
        'dependency_map': dependency_map,
        'reverse_map': reverse_map,
        'type_counts': type_counts
    }
    
    with open(output_file, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print()
    print(f"Results saved to: {output_file}")

if __name__ == "__main__":
    main()

