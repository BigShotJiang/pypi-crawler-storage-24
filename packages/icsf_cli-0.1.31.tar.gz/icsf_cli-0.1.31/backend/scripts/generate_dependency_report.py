"""
Generate a comprehensive dependency report for all matched files
"""
import os
import sys
import json
from collections import defaultdict

# Add backend directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Fix encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

def main():
    analysis_file = os.path.join(os.path.dirname(__file__), 'all_matched_files_analysis.json')
    
    if not os.path.exists(analysis_file):
        print(f"❌ Analysis file not found: {analysis_file}")
        print("Please run analyze_all_matched_files.py first")
        return
    
    with open(analysis_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print("=" * 80)
    print("COMPREHENSIVE DEPENDENCY REPORT FOR ALL MATCHED FILES")
    print("=" * 80)
    print()
    
    summary = data.get('summary', {})
    results = data.get('results', {})
    
    print("SUMMARY")
    print("-" * 80)
    print(f"Total vulnerable files: {summary.get('total_vulnerable_files', 0)}")
    print(f"Total intra-repo dependents: {summary.get('total_intra_repo_dependents', 0)}")
    print(f"Total cross-repo dependents: {summary.get('total_cross_repo_dependents', 0)}")
    print(f"Unique dependent files: {summary.get('unique_dependent_files', 0)}")
    print()
    
    # Collect all unique dependent files
    all_intra_deps = set()
    all_cross_repo_deps = defaultdict(list)
    
    for file_path, result in results.items():
        for dep in result.get('intra_repo_dependents', []):
            all_intra_deps.add(dep['file'])
        
        for dep in result.get('cross_repo_dependents', []):
            repo = dep.get('repo', 'Unknown')
            file_key = f"{repo}:{dep.get('file')}"
            if file_key not in all_cross_repo_deps[repo]:
                all_cross_repo_deps[repo].append({
                    'file': dep.get('file'),
                    'maven_artifact': dep.get('maven_artifact'),
                    'classes_used': dep.get('classes_used', [])
                })
    
    print("=" * 80)
    print("ALL INTRA-REPOSITORY DEPENDENT FILES")
    print("=" * 80)
    print()
    print(f"Total unique files: {len(all_intra_deps)}")
    print()
    
    for dep_file in sorted(all_intra_deps):
        print(f"  - {dep_file}")
    print()
    
    print("=" * 80)
    print("ALL CROSS-REPOSITORY DEPENDENT FILES")
    print("=" * 80)
    print()
    
    for repo, deps in all_cross_repo_deps.items():
        print(f"Repository: {repo}")
        print(f"  Total files: {len(deps)}")
        print()
        for dep in deps:
            print(f"  - {dep['file']}")
            if dep.get('maven_artifact'):
                print(f"    Maven Artifact: {dep['maven_artifact']}")
            if dep.get('classes_used'):
                print(f"    Classes Used: {', '.join(dep['classes_used'])}")
        print()
    
    # Detailed breakdown by vulnerable file
    print("=" * 80)
    print("DETAILED BREAKDOWN BY VULNERABLE FILE")
    print("=" * 80)
    print()
    
    # Sort by total dependents
    sorted_results = sorted(
        results.items(),
        key=lambda x: len(x[1].get('intra_repo_dependents', [])) + len(x[1].get('cross_repo_dependents', [])),
        reverse=True
    )
    
    for file_path, result in sorted_results:
        intra_count = len(result.get('intra_repo_dependents', []))
        cross_count = len(result.get('cross_repo_dependents', []))
        
        if intra_count == 0 and cross_count == 0:
            continue  # Skip files with no dependents
        
        print(f"📁 {file_path}")
        print(f"   Package: {result.get('package', 'N/A')}")
        if result.get('maven_artifact'):
            print(f"   Maven Artifact: {result['maven_artifact']}")
        print(f"   Total Dependents: {intra_count + cross_count} (Intra: {intra_count}, Cross: {cross_count})")
        
        if intra_count > 0:
            print(f"   Intra-repo dependents:")
            for dep in result['intra_repo_dependents'][:10]:
                print(f"      - {dep['file']} [{dep.get('type', 'unknown')}]")
            if intra_count > 10:
                print(f"      ... and {intra_count - 10} more")
        
        if cross_count > 0:
            print(f"   Cross-repo dependents:")
            for dep in result['cross_repo_dependents']:
                print(f"      - {dep.get('repo')}:{dep.get('file')}")
        
        print()

if __name__ == "__main__":
    main()

