"""
Test script for Bedrock Service connectivity

This script tests the Bedrock service connection and Agent 1 (Vulnerability Analyzer).
"""

import os
import sys
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

# Load environment variables from .env file
from dotenv import load_dotenv
load_dotenv(dotenv_path=backend_dir / '.env')

from services.bedrock_service import BedrockService
# VulnerabilityAnalyzerAgent (Agent 1) has been removed as redundant
from models.agent_models import VulnerabilityFixRequest, VulnerabilitySeverity
from config import Config


def test_bedrock_connection():
    """Test basic Bedrock connectivity"""
    print("=" * 80)
    print("Testing Bedrock Service Connection")
    print("=" * 80)
    
    # Validate credentials from .env file
    is_valid, error_msg = Config.validate_bedrock_credentials()
    
    if not is_valid:
        print(f"\n❌ {error_msg}")
        print("\n⚠️  Please create a .env file in the backend directory with your AWS credentials.")
        print("\nSteps:")
        print("1. Copy .env.example to .env:")
        print("   cd backend")
        print("   copy .env.example .env")
        print("\n2. Edit .env file and add your credentials:")
        print("   AWS_ACCESS_KEY_ID=your_access_key")
        print("   AWS_SECRET_ACCESS_KEY=your_secret_key")
        print("   AWS_REGION=us-east-1")
        print("\n3. Save the file and run this test again.")
        print("\nNote: The .env file is already in .gitignore and will NOT be committed.")
        return False
    
    # Use credentials from .env/config
    bedrock_config = Config.get_bedrock_config()
    print(f"\n✅ Found AWS credentials from .env file")
    print(f"   Region: {bedrock_config['region']}")
    print(f"   Access Key ID: {bedrock_config['access_key'][:8]}...")  # Show first 8 chars only
    
    try:
        # Initialize Bedrock service
        print("\n📡 Initializing Bedrock Service...")
        bedrock_service = BedrockService(
            access_key=bedrock_config['access_key'],
            secret_key=bedrock_config['secret_key'],
            region=bedrock_config['region']
        )
        
        # Test connection
        print("🧪 Testing Bedrock connection...")
        test_result = bedrock_service.test_connection()
        
        if test_result['success']:
            print("✅ Bedrock connection successful!")
            print(f"   Response: {test_result['response']}")
            return True
        else:
            print(f"❌ Bedrock connection failed: {test_result.get('error', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"❌ Error testing Bedrock connection: {str(e)}")
        return False


def test_vulnerability_analyzer_agent():
    """Test Agent 1: Vulnerability Analyzer"""
    print("\n" + "=" * 80)
    print("Testing Vulnerability Analyzer Agent (Agent 1)")
    print("=" * 80)
    
    # Validate credentials from .env file
    is_valid, error_msg = Config.validate_bedrock_credentials()
    
    if not is_valid:
        print(f"\n❌ {error_msg}")
        print("\n⚠️  Please create a .env file in the backend directory with your AWS credentials.")
        print("See test_bedrock_connection() output above for instructions.")
        return False
    
    # Use credentials from .env/config
    bedrock_config = Config.get_bedrock_config()
    print(f"\n✅ Using AWS credentials from .env file")
    
    try:
        # Initialize services
        print("\n📡 Initializing services...")
        bedrock_service = BedrockService(
            access_key=bedrock_config['access_key'],
            secret_key=bedrock_config['secret_key'],
            region=bedrock_config['region']
        )
        
        agent = VulnerabilityAnalyzerAgent(bedrock_service)
        
        # Create test request
        print("\n🔍 Testing vulnerability analysis...")
        test_request = VulnerabilityFixRequest(
            vulnerability_type="SQL Injection",
            description="User input is directly concatenated into SQL query without sanitization, allowing potential SQL injection attacks.",
            severity=VulnerabilitySeverity.HIGH,
            recommendation="Use parameterized queries or prepared statements instead of string concatenation.",
            file_path="src/main/java/controllers/Login.java",
            line_number=42,
            repo_path="/path/to/repo",
            repo_name="test-repo"
        )
        
        # Run analysis
        print("🤖 Running vulnerability analysis...")
        analysis = agent.analyze(test_request)
        
        # Display results
        print("\n✅ Analysis complete!")
        print("\n" + "-" * 80)
        print("Vulnerability Analysis Results:")
        print("-" * 80)
        print(f"Vulnerability Type: {analysis.vulnerability_type}")
        print(f"Severity: {analysis.severity.value}")
        print(f"Fix Category: {analysis.fix_category}")
        print(f"\nSecurity Impact:")
        print(f"  - Confidentiality: {analysis.security_impact.confidentiality}")
        print(f"  - Integrity: {analysis.security_impact.integrity}")
        print(f"  - Availability: {analysis.security_impact.availability}")
        print(f"  - Overall Risk: {analysis.security_impact.overall_risk}")
        print(f"\nRoot Causes:")
        for i, cause in enumerate(analysis.root_causes, 1):
            print(f"  {i}. {cause}")
        print(f"\nSecurity Guidelines:")
        for guideline in analysis.security_guidelines:
            print(f"  - {guideline}")
        print(f"\nTypical Fix Approach:")
        print(f"  {analysis.typical_fix_approach}")
        print("-" * 80)
        
        return True
        
    except Exception as e:
        print(f"\n❌ Error testing Vulnerability Analyzer Agent: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests"""
    print("\n" + "=" * 80)
    print("Multi-Agent Vulnerability Fixing System - Phase 1 Tests")
    print("=" * 80)
    
    # Test 1: Bedrock connection
    connection_ok = test_bedrock_connection()
    
    if not connection_ok:
        print("\n⚠️  Bedrock connection test failed. Skipping agent tests.")
        return
    
    # Test 2: Vulnerability Analyzer Agent
    agent_ok = test_vulnerability_analyzer_agent()
    
    # Summary
    print("\n" + "=" * 80)
    print("Test Summary")
    print("=" * 80)
    print(f"Bedrock Connection: {'✅ PASS' if connection_ok else '❌ FAIL'}")
    print(f"Vulnerability Analyzer Agent: {'✅ PASS' if agent_ok else '❌ FAIL'}")
    print("=" * 80)


if __name__ == "__main__":
    main()

