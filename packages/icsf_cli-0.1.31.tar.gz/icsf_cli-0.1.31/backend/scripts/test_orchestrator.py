"""
Test script for Fix Orchestrator

Tests the orchestrator with Agent 1 and Agent 2 to verify the workflow.
"""

import os
import sys
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

# Load environment variables from .env file
from dotenv import load_dotenv
load_dotenv(dotenv_path=backend_dir / '.env')

from services.bedrock_service import BedrockService
from services.fix_orchestrator import FixOrchestrator
from models.agent_models import VulnerabilityFixRequest, VulnerabilitySeverity
from config import Config


def test_orchestrator():
    """Test the orchestrator with Agent 1 and Agent 2"""
    print("=" * 80)
    print("Testing Fix Orchestrator")
    print("=" * 80)
    
    # Validate credentials
    is_valid, error_msg = Config.validate_bedrock_credentials()
    
    if not is_valid:
        print(f"\n❌ {error_msg}")
        print("\n⚠️  Please create a .env file in the backend directory with your AWS credentials.")
        return False
    
    # Initialize Bedrock service
    print("\n📡 Initializing Bedrock Service...")
    bedrock_config = Config.get_bedrock_config()
    bedrock_service = BedrockService(
        access_key=bedrock_config['access_key'],
        secret_key=bedrock_config['secret_key'],
        region=bedrock_config['region']
    )
    
    # Initialize orchestrator
    print("🔧 Initializing Fix Orchestrator...")
    orchestrator = FixOrchestrator(bedrock_service)
    
    # Create test request
    # Note: Update these paths to match your actual test repository
    test_repo_path = backend_dir / "temp_analysis_repo"
    test_file_path = "src/main/java/models/User.java"
    test_line_number = 42
    
    # Check if test repo exists
    if not test_repo_path.exists():
        print(f"\n⚠️  Test repository not found: {test_repo_path}")
        print("   Using a sample request with mock paths...")
        test_repo_path = backend_dir / "test_data" / "sample_repo"
        test_file_path = "src/main/java/com/example/Login.java"
        
        # Create a minimal test scenario
        if not test_repo_path.exists():
            print("\n⚠️  Creating a minimal test file for demonstration...")
            test_repo_path.mkdir(parents=True, exist_ok=True)
            test_file_full = test_repo_path / test_file_path
            test_file_full.parent.mkdir(parents=True, exist_ok=True)
            
            # Create a simple test Java file
            test_code = """package com.example;

import java.sql.Connection;
import java.sql.Statement;

public class Login {
    public boolean authenticate(String username, String password) {
        String query = "SELECT * FROM users WHERE username='" + username + "' AND password='" + password + "';";
        // Line 9: SQL Injection vulnerability
        try {
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();
            stmt.executeQuery(query);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    private Connection getConnection() {
        return null; // Mock
    }
}
"""
            with open(test_file_full, 'w', encoding='utf-8') as f:
                f.write(test_code)
            test_line_number = 9
    
    test_request = VulnerabilityFixRequest(
        vulnerability_type="SQL Injection",
        description="User input is directly concatenated into SQL query without proper sanitization, leading to potential SQL Injection.",
        severity=VulnerabilitySeverity.HIGH,
        recommendation="Use parameterized queries or prepared statements.",
        file_path=test_file_path,
        line_number=test_line_number,
        repo_path=str(test_repo_path),
        repo_name="test-repo"
    )
    
    print(f"\n🔍 Testing orchestrator with:")
    print(f"   Repository: {test_request.repo_path}")
    print(f"   File: {test_request.file_path}")
    print(f"   Line: {test_request.line_number}")
    print(f"   Vulnerability: {test_request.vulnerability_type}")
    
    try:
        # Run orchestration (All 6 agents)
        print("\n🚀 Starting orchestration (Agent 1 → Agent 2 → Agent 3 → Agent 4 → Agent 5 → Agent 6)...")
        result = orchestrator.orchestrate_fix(test_request, stop_at_agent=None)
        
        # Display status
        print("\n" + "=" * 80)
        print("Orchestration Results")
        print("=" * 80)
        
        status = orchestrator.get_orchestration_status(result)
        print(f"\n📊 Overall Status: {status['overall_status'].upper()}")
        
        print(f"\n✅ Agents Completed:")
        for agent in status['agents_completed']:
            print(f"   - {agent}")
        
        if status['agents_pending']:
            print(f"\n⏳ Agents Pending:")
            for agent in status['agents_pending']:
                print(f"   - {agent}")
        
        if status['errors']:
            print(f"\n❌ Errors:")
            for error in status['errors']:
                print(f"   - {error}")
        
        # Display Agent 1 results
        if result.vulnerability_analysis:
            print("\n" + "-" * 80)
            print("Agent 1: Vulnerability Analysis")
            print("-" * 80)
            analysis = result.vulnerability_analysis
            print(f"Vulnerability Type: {analysis.vulnerability_type}")
            print(f"Severity: {analysis.severity.value}")
            print(f"Fix Category: {analysis.fix_category}")
            print(f"Security Impact:")
            print(f"  - Confidentiality: {analysis.security_impact.confidentiality}")
            print(f"  - Integrity: {analysis.security_impact.integrity}")
            print(f"  - Availability: {analysis.security_impact.availability}")
            print(f"  - Overall Risk: {analysis.security_impact.overall_risk}")
            print(f"\nRoot Causes:")
            for i, cause in enumerate(analysis.root_causes, 1):
                print(f"  {i}. {cause}")
            print(f"\nTypical Fix Approach: {analysis.typical_fix_approach}")
        
        # Display Agent 2 results
        if result.code_context:
            print("\n" + "-" * 80)
            print("Agent 2: Code Context Analysis")
            print("-" * 80)
            context = result.code_context
            print(f"Vulnerable File: {context.vulnerable_file}")
            print(f"Vulnerable Line: {context.vulnerable_line}")
            print(f"Class: {context.class_name or 'Unknown'}")
            print(f"Method: {context.method_name or 'Unknown'}")
            
            if context.function_signature:
                print(f"Function Signature: {context.function_signature}")
            
            print(f"\nDependencies:")
            print(f"  - Intra-repo: {len(context.dependent_files_intra)} files")
            print(f"  - Inter-repo: {len(context.dependent_files_inter)} files")
            
            if context.dependent_files_intra:
                print(f"\n  Intra-repo dependent files:")
                for dep in context.dependent_files_intra[:5]:  # Show first 5
                    dep_file = dep.get('file', 'Unknown')
                    dep_type = dep.get('dependency_type', 'Unknown')
                    print(f"    - {dep_file} (type: {dep_type})")
                if len(context.dependent_files_intra) > 5:
                    print(f"    ... and {len(context.dependent_files_intra) - 5} more")
            
            if context.data_flow:
                print(f"\nData Flow Analysis:")
                print(f"  {context.data_flow}")
            
            if context.usage_patterns:
                print(f"\nUsage Patterns:")
                for pattern in context.usage_patterns:
                    print(f"  - {pattern}")
        
        # Display Agent 3 results
        if result.fix_strategy:
            print("\n" + "-" * 80)
            print("Agent 3: Fix Strategy")
            print("-" * 80)
            strategy = result.fix_strategy
            print(f"Fix Approach:\n  {strategy.fix_approach}")
            print(f"\nCode Changes Plan:")
            for i, step in enumerate(strategy.code_changes_plan, 1):
                print(f"  {i}. {step}")
            print(f"\nPrimary Files to Modify ({len(strategy.files_to_modify_primary)}):")
            for file in strategy.files_to_modify_primary:
                print(f"  - {file}")
            if strategy.files_to_modify_secondary:
                print(f"\nSecondary Files to Modify ({len(strategy.files_to_modify_secondary)}):")
                for file in strategy.files_to_modify_secondary[:5]:  # Show first 5
                    print(f"  - {file}")
                if len(strategy.files_to_modify_secondary) > 5:
                    print(f"  ... and {len(strategy.files_to_modify_secondary) - 5} more")
            print(f"\nRisk Assessment:\n  {strategy.risk_assessment}")
            print(f"\nBackward Compatible: {strategy.backward_compatibility}")
            if strategy.testing_considerations:
                print(f"\nTesting Considerations:")
                for consideration in strategy.testing_considerations:
                    print(f"  - {consideration}")
        
        # Display Agent 4 results
        if result.code_fix:
            print("\n" + "-" * 80)
            print("Agent 4: Code Fix")
            print("-" * 80)
            fix = result.code_fix
            print(f"Change Summary: {fix.change_summary}")
            print(f"\nFiles Modified ({len(fix.files_modified)}):")
            for file in fix.files_modified:
                print(f"  - {file}")
            print(f"\nLines Changed: {len(fix.changed_lines)}")
            if fix.changed_lines:
                print(f"\nFirst 10 line changes:")
                for change in fix.changed_lines[:10]:
                    change_type = "ADDED" if change['type'] == 'added' else "REMOVED"
                    content_preview = change['content'][:60] + "..." if len(change['content']) > 60 else change['content']
                    print(f"  [{change_type}] Line {change['line_number']}: {content_preview}")
                if len(fix.changed_lines) > 10:
                    print(f"  ... and {len(fix.changed_lines) - 10} more changes")
            print(f"\nDiff Preview (first 500 chars):")
            diff_preview = fix.diff[:500] + "..." if len(fix.diff) > 500 else fix.diff
            print(diff_preview)
        
        # Display Agent 5 results
        if result.safety_validation:
            print("\n" + "-" * 80)
            print("Agent 5: Safety Validation")
            print("-" * 80)
            validation = result.safety_validation
            print(f"Validation Status: {validation.validation_status.value.upper()}")
            print(f"Correctness Score: {validation.correctness_score:.2f}/1.00")
            print(f"Breaking Changes: {'Yes' if validation.breaking_changes else 'No'}")
            print(f"Backward Compatible: {'Yes' if validation.backward_compatible else 'No'}")
            print(f"New Vulnerabilities: {'Yes' if validation.new_vulnerabilities else 'No'}")
            print(f"Code Style Consistent: {'Yes' if validation.code_style_consistent else 'No'}")
            if validation.issues_found:
                print(f"\nIssues Found:")
                for issue in validation.issues_found:
                    print(f"  - {issue}")
            if validation.suggestions:
                print(f"\nSuggestions:")
                for suggestion in validation.suggestions:
                    print(f"  - {suggestion}")
        
        # Display Agent 6 results
        if result.fix_explanation:
            print("\n" + "-" * 80)
            print("Agent 6: Fix Explanation")
            print("-" * 80)
            explanation = result.fix_explanation
            print(f"\nVulnerability Summary:\n{explanation.vulnerability_summary}")
            print(f"\nSecurity Impact:\n{explanation.security_impact_explanation}")
            print(f"\nFix Explanation:\n{explanation.fix_explanation}")
            print(f"\nCode Changes:\n{explanation.code_changes_explanation}")
            print(f"\nDeveloper Notes:\n{explanation.developer_notes}")
            print(f"\nMarkdown Report Preview (first 1000 chars):")
            report_preview = explanation.markdown_report[:1000] + "..." if len(explanation.markdown_report) > 1000 else explanation.markdown_report
            print(report_preview)
        
        print("\n" + "=" * 80)
        
        if result.overall_status == "success":
            print("✅ Orchestrator test PASSED!")
            return True
        else:
            print("❌ Orchestrator test FAILED!")
            return False
            
    except Exception as e:
        print(f"\n❌ Error during orchestration: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_orchestrator()
    sys.exit(0 if success else 1)

