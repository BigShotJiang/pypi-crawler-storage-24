"""
Test script to show which imports in inter-repo files match vulnerable files
"""
import os
import sys

# Fix encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.dependency_service import DependencyService

def main():
    # Repository paths
    banking_repo_path = os.path.abspath('temp_analysis_repo')
    dependent_repo_path = os.path.abspath('test_dependent_repo')
    
    if not os.path.exists(banking_repo_path):
        print(f"❌ Banking repository not found at {banking_repo_path}")
        return
    
    if not os.path.exists(dependent_repo_path):
        print(f"❌ Dependent repository not found at {dependent_repo_path}")
        return
    
    # Test with User.java (has inter-repo dependents)
    vulnerable_file = "src/main/java/models/User.java"
    
    print("=" * 80)
    print("INTER-REPO DEPENDENCY ANALYSIS WITH IMPORT DETAILS")
    print("=" * 80)
    print()
    print(f"Vulnerable File: {vulnerable_file}")
    print()
    
    # Prepare repository list
    all_repos = [
        {
            'id': 1,
            'full_name': 'test/banking-app',
            'clone_path': banking_repo_path
        },
        {
            'id': 2,
            'full_name': 'test/banking-client-service',
            'clone_path': dependent_repo_path
        }
    ]
    
    # Find cross-repo dependents
    cross_repo_result = DependencyService.find_cross_repo_dependent_files(
        vulnerable_file=vulnerable_file,
        vulnerable_repo_path=banking_repo_path,
        vulnerable_repo_name='test/banking-app',
        vulnerable_repo_id=1,
        all_repos=all_repos,
        max_depth=5
    )
    
    cross_repo_deps = cross_repo_result.get('cross_repo_dependents', [])
    
    print(f"Found {len(cross_repo_deps)} inter-repo dependent files")
    print()
    
    if not cross_repo_deps:
        print("❌ No inter-repo dependents found!")
        print("This could mean:")
        print("  - Maven artifact not found")
        print("  - Dependent repo doesn't declare the dependency")
        print("  - Java files don't import from vulnerable package")
        return
    
    # Parse vulnerable file to get package and classes
    vulnerable_file_full_path = os.path.join(banking_repo_path, vulnerable_file)
    vulnerable_file_info = DependencyService.parse_java_file(vulnerable_file_full_path)
    vulnerable_package = vulnerable_file_info.get('package', '')
    vulnerable_classes = vulnerable_file_info.get('classes', [])
    
    print(f"Vulnerable File Info:")
    print(f"  Package: {vulnerable_package}")
    print(f"  Classes: {', '.join(vulnerable_classes)}")
    print()
    
    print("=" * 80)
    print("DETAILED IMPORT ANALYSIS FOR EACH DEPENDENT FILE")
    print("=" * 80)
    print()
    
    for idx, dep in enumerate(cross_repo_deps, 1):
        repo_name = dep.get('repo', 'Unknown')
        file_path = dep.get('file', 'Unknown')
        imports = dep.get('imports', [])
        classes_used = dep.get('classes_used', [])
        
        print(f"[{idx}] {repo_name}:{file_path}")
        print("-" * 80)
        
        # Parse the dependent file to see all imports
        dep_file_full_path = os.path.join(dependent_repo_path, file_path)
        if os.path.exists(dep_file_full_path):
            dep_file_info = DependencyService.parse_java_file(dep_file_full_path)
            all_imports = dep_file_info.get('imports_full', [])
            
            print(f"All imports in this file:")
            for imp in all_imports:
                # Check if this import matches vulnerable package/classes
                imp_clean = imp.replace('.*', '').strip()
                is_match = False
                match_reason = ""
                
                if vulnerable_package and imp_clean.startswith(vulnerable_package):
                    is_match = True
                    match_reason = f"matches package '{vulnerable_package}'"
                
                for cls in vulnerable_classes:
                    if imp_clean.endswith(cls) or imp_clean == cls:
                        is_match = True
                        match_reason = f"matches class '{cls}'"
                        break
                
                if is_match:
                    print(f"  ✅ {imp} ({match_reason})")
                else:
                    print(f"     {imp}")
            
            print()
            print(f"Matching imports (from analysis): {', '.join(imports) if imports else 'None'}")
            print(f"Classes used: {', '.join(classes_used) if classes_used else 'None'}")
        else:
            print(f"  ⚠️  File not found: {dep_file_full_path}")
        
        print()
    
    print("=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print()
    print("For each dependent file, you can see:")
    print("  - All imports in that file")
    print("  - Which imports match the vulnerable package/classes (marked with ✅)")
    print("  - The specific matching imports identified by the analysis")
    print("  - Which classes from the vulnerable file are being used")

if __name__ == "__main__":
    main()



