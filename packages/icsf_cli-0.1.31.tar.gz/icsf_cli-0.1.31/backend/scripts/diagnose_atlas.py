import os
import sys
import shutil
import subprocess
import json
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

def check_tool(name):
    path = shutil.which(name)
    version = None
    error = None
    if path:
        try:
            res = subprocess.run([name, "--version"], shell=True, capture_output=True, text=True)
            version = res.stdout.strip()
        except Exception as e:
            error = str(e)
    return {"path": path, "version": version, "error": error}

def test_bedrock():
    from dotenv import load_dotenv
    # Force override to ensure .env is prioritized over system env
    load_dotenv(dotenv_path=backend_dir / '.env', override=True)
    
    access_key = os.getenv("AWS_ACCESS_KEY_ID", "").strip()
    secret_key = os.getenv("AWS_SECRET_ACCESS_KEY", "").strip()
    session_token = os.getenv("AWS_SESSION_TOKEN", "").strip()
    region = os.getenv("AWS_REGION", "us-east-1").strip()
    
    result = {
        "region": region,
        "access_key_found": access_key[:10] + "...",
        "has_session_token": bool(session_token),
        "secret_key_length": len(secret_key),
        "success": False,
        "error": None
    }
    
    if not access_key or not secret_key:
        result["error"] = "Missing credentials"
        return result

    import boto3
    from botocore.exceptions import ClientError
    
    try:
        kwargs = {
            "service_name": "bedrock-runtime",
            "aws_access_key_id": access_key,
            "aws_secret_access_key": secret_key,
            "region_name": region
        }
        
        # Mirror the production logic: ignore session token if permanent AKIA key is used
        if not access_key.startswith("AKIA") and session_token:
            kwargs["aws_session_token"] = session_token
            result["using_session_token"] = True
        else:
            result["using_session_token"] = False

        client = boto3.client(**kwargs)
        
        model_id = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0").strip()
        
        # Claude 3+ uses messages API
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 10,
            "messages": [{"role": "user", "content": "Verification"}]
        })
        
        response = client.invoke_model(
            modelId=model_id,
            body=body,
            contentType="application/json",
            accept="application/json"
        )
        result["success"] = True
    except ClientError as e:
        result["error"] = str(e)
    except Exception as e:
        result["error"] = str(e)
    
    return result

if __name__ == "__main__":
    diagnosis = {
        "cwd": os.getcwd(),
        "sys_path": sys.path,
        "tools": {
            "git": check_tool("git"),
            "mvn": check_tool("mvn"),
            "java": check_tool("java")
        },
        "bedrock": test_bedrock()
    }
    
    output_file = backend_dir / "data" / "diagnosis.json"
    with open(output_file, "w") as f:
        json.dump(diagnosis, f, indent=4)
    print(f"Diagnosis written to {output_file}")
