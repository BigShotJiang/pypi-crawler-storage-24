"""
Analyze all matched files from vulnerability report to find dependent files
Both intra-repo and cross-repo dependencies
"""
import os
import sys
import json
from pathlib import Path
from collections import defaultdict

# Fix encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.dependency_service import DependencyService

def main():
    # Repository paths
    banking_repo_path = os.path.abspath('temp_analysis_repo')
    dependent_repo_path = os.path.abspath('test_dependent_repo')
    
    if not os.path.exists(banking_repo_path):
        print(f"❌ Banking repository not found at {banking_repo_path}")
        return
    
    if not os.path.exists(dependent_repo_path):
        print(f"❌ Dependent repository not found at {dependent_repo_path}")
        return
    
    # Matched files from the report
    matched_files = [
        "src/main/java/servlet/MasterServlet.java",
        "src/main/java/controllers/Types.java",
        "src/main/java/controllers/Withdraw.java",
        "src/main/java/controllers/PassTime.java",
        "src/main/java/controllers/Deposit.java",
        "src/main/java/controllers/CurrentUser.java",
        "src/main/java/controllers/Users.java",
        "src/main/java/controllers/AccountsById.java",
        "src/main/java/controllers/AccountsByStatus.java",
        "src/main/java/controllers/UsersById.java",
        "src/main/java/controllers/Register.java",
        "src/main/java/controllers/Statuses.java",
        "src/main/java/controllers/UsersByAccount.java",
        "src/main/java/controllers/Roles.java",
        "src/main/java/controllers/Accounts.java",
        "src/main/java/controllers/AccountsByUser.java",
        "src/main/java/controllers/Transfer.java",
        "src/main/java/controllers/AccountLinks.java",
        "src/main/java/controllers/Login.java",
        "src/main/java/controllers/Home.java",
        "src/main/java/controllers/Logout.java",
        "src/main/java/models/User.java",
        "src/main/java/models/AccountLink.java",
        "src/main/java/launch/Main.java",
        "src/main/java/dao/BankDAO.java",
        "src/main/java/service/PostRequestHelper.java",
        "src/main/java/service/GetRequestHelper.java",
        "src/main/java/service/DeleteRequestHelper.java",
        "src/main/java/service/PutRequestHelper.java",
    ]
    
    # Remove duplicates and filter to only Java files that exist
    matched_files = list(set(matched_files))
    existing_files = []
    for file_path in matched_files:
        full_path = os.path.join(banking_repo_path, file_path)
        if os.path.exists(full_path) and file_path.endswith('.java'):
            existing_files.append(file_path)
    
    print("=" * 80)
    print("COMPREHENSIVE DEPENDENCY ANALYSIS FOR ALL MATCHED FILES")
    print("=" * 80)
    print()
    print(f"Total matched files: {len(matched_files)}")
    print(f"Existing Java files: {len(existing_files)}")
    print()
    
    # Prepare repository list
    all_repos = [
        {
            'id': 1,
            'full_name': 'test/banking-app',
            'clone_path': banking_repo_path
        },
        {
            'id': 2,
            'full_name': 'test/banking-client-service',
            'clone_path': dependent_repo_path
        }
    ]
    
    # Build intra-repo dependency graph once
    print("Building intra-repository dependency graph...")
    intra_deps = DependencyService.build_intra_repo_dependencies(banking_repo_path)
    print(f"✅ Built dependency graph with {len(intra_deps)} files")
    print()
    
    # Build reverse map (what depends on each file)
    reverse_map = defaultdict(list)
    for file_path, deps in intra_deps.items():
        for dep in deps:
            dep_file = dep['file']
            reverse_map[dep_file].append({
                'file': file_path,
                'type': dep['type'],
                'class': dep.get('class', dep.get('interface', ''))
            })
    print(f"✅ Built reverse dependency map with {len(reverse_map)} files")
    print()
    
    # Analyze each matched file
    all_results = {}
    all_dependent_files = set()
    all_cross_repo_deps = []
    
    print("=" * 80)
    print("ANALYZING EACH MATCHED FILE")
    print("=" * 80)
    print()
    
    for idx, vulnerable_file in enumerate(existing_files, 1):
        print(f"[{idx}/{len(existing_files)}] Analyzing: {vulnerable_file}")
        
        # Find intra-repo dependents
        intra_dependents = reverse_map.get(vulnerable_file, [])
        
        # Find cross-repo dependents
        vulnerable_file_full_path = os.path.join(banking_repo_path, vulnerable_file)
        if not os.path.exists(vulnerable_file_full_path):
            print(f"  ⚠️  File not found, skipping")
            continue
        
        # Parse vulnerable file
        vulnerable_file_info = DependencyService.parse_java_file(vulnerable_file_full_path)
        vulnerable_package = vulnerable_file_info.get('package', '')
        vulnerable_classes = vulnerable_file_info.get('classes', [])
        vulnerable_interfaces = vulnerable_file_info.get('interfaces', [])
        all_vulnerable_classes = set(vulnerable_classes + vulnerable_interfaces)
        
        # Find Maven artifact
        vulnerable_artifact = DependencyService.find_maven_artifact_for_file(
            vulnerable_file, banking_repo_path
        )
        
        cross_repo_dependents = []
        if vulnerable_artifact and len(all_repos) > 1:
            vulnerable_group_id = vulnerable_artifact.get('groupId', '')
            vulnerable_artifact_id = vulnerable_artifact.get('artifactId', '')
            
            # Find cross-repo dependents
            cross_repo_result = DependencyService.find_cross_repo_dependent_files(
                vulnerable_file=vulnerable_file,
                vulnerable_repo_path=banking_repo_path,
                vulnerable_repo_name='test/banking-app',
                vulnerable_repo_id=1,
                all_repos=all_repos,
                max_depth=5
            )
            cross_repo_dependents = cross_repo_result.get('cross_repo_dependents', [])
            all_cross_repo_deps.extend(cross_repo_dependents)
        
        # Store results
        all_results[vulnerable_file] = {
            'intra_repo_dependents': intra_dependents,
            'cross_repo_dependents': cross_repo_dependents,
            'package': vulnerable_package,
            'classes': vulnerable_classes,
            'maven_artifact': f"{vulnerable_artifact.get('groupId', '')}:{vulnerable_artifact.get('artifactId', '')}" if vulnerable_artifact else None
        }
        
        # Collect all dependent files
        for dep in intra_dependents:
            all_dependent_files.add(dep['file'])
        for dep in cross_repo_dependents:
            all_dependent_files.add(f"{dep.get('repo', '')}:{dep.get('file', '')}")
        
        print(f"  ✅ Found {len(intra_dependents)} intra-repo dependents, {len(cross_repo_dependents)} cross-repo dependents")
    
    print()
    print("=" * 80)
    print("SUMMARY STATISTICS")
    print("=" * 80)
    print()
    
    # Calculate statistics
    total_intra_deps = sum(len(r['intra_repo_dependents']) for r in all_results.values())
    total_cross_repo_deps = sum(len(r['cross_repo_dependents']) for r in all_results.values())
    unique_intra_deps = len(all_dependent_files)
    
    print(f"Total vulnerable files analyzed: {len(existing_files)}")
    print(f"Total intra-repo dependent files: {total_intra_deps}")
    print(f"Total cross-repo dependent files: {total_cross_repo_deps}")
    print(f"Unique dependent files: {unique_intra_deps}")
    print()
    
    # Files with most dependents
    print("=" * 80)
    print("TOP 10 FILES WITH MOST DEPENDENTS")
    print("=" * 80)
    print()
    
    files_by_dependents = sorted(
        all_results.items(),
        key=lambda x: len(x[1]['intra_repo_dependents']) + len(x[1]['cross_repo_dependents']),
        reverse=True
    )
    
    for file_path, result in files_by_dependents[:10]:
        intra_count = len(result['intra_repo_dependents'])
        cross_count = len(result['cross_repo_dependents'])
        total = intra_count + cross_count
        print(f"{file_path}")
        print(f"  Total dependents: {total} (Intra-repo: {intra_count}, Cross-repo: {cross_count})")
        print()
    
    # Cross-repo dependencies summary
    if all_cross_repo_deps:
        print("=" * 80)
        print("CROSS-REPOSITORY DEPENDENCIES SUMMARY")
        print("=" * 80)
        print()
        
        cross_repo_by_repo = defaultdict(list)
        for dep in all_cross_repo_deps:
            repo = dep.get('repo', 'Unknown')
            cross_repo_by_repo[repo].append(dep)
        
        for repo, deps in cross_repo_by_repo.items():
            print(f"Repository: {repo}")
            print(f"  Total dependent files: {len(deps)}")
            print(f"  Files:")
            for dep in deps[:10]:  # Show first 10
                print(f"    - {dep.get('file')}")
            if len(deps) > 10:
                print(f"    ... and {len(deps) - 10} more")
            print()
    
    # Save detailed results
    output_file = os.path.join(os.path.dirname(__file__), 'all_matched_files_analysis.json')
    output_data = {
        'summary': {
            'total_vulnerable_files': len(existing_files),
            'total_intra_repo_dependents': total_intra_deps,
            'total_cross_repo_dependents': total_cross_repo_deps,
            'unique_dependent_files': unique_intra_deps
        },
        'results': {}
    }
    
    for file_path, result in all_results.items():
        output_data['results'][file_path] = {
            'package': result['package'],
            'classes': result['classes'],
            'maven_artifact': result['maven_artifact'],
            'intra_repo_dependents_count': len(result['intra_repo_dependents']),
            'cross_repo_dependents_count': len(result['cross_repo_dependents']),
            'intra_repo_dependents': result['intra_repo_dependents'],
            'cross_repo_dependents': result['cross_repo_dependents']
        }
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Detailed results saved to: {output_file}")
    print()
    
    # Show detailed breakdown for a few key files
    print("=" * 80)
    print("DETAILED BREAKDOWN FOR KEY FILES")
    print("=" * 80)
    print()
    
    # Show top 5 files with most dependents
    for file_path, result in files_by_dependents[:5]:
        print(f"📁 {file_path}")
        print(f"   Package: {result['package']}")
        print(f"   Classes: {', '.join(result['classes'][:5])}")
        if result['maven_artifact']:
            print(f"   Maven Artifact: {result['maven_artifact']}")
        
        intra_deps = result['intra_repo_dependents']
        if intra_deps:
            print(f"   Intra-repo dependents ({len(intra_deps)}):")
            for dep in intra_deps[:5]:
                print(f"      - {dep['file']} [{dep['type']}]")
            if len(intra_deps) > 5:
                print(f"      ... and {len(intra_deps) - 5} more")
        
        cross_deps = result['cross_repo_dependents']
        if cross_deps:
            print(f"   Cross-repo dependents ({len(cross_deps)}):")
            for dep in cross_deps[:5]:
                print(f"      - {dep.get('repo')}:{dep.get('file')}")
            if len(cross_deps) > 5:
                print(f"      ... and {len(cross_deps) - 5} more")
        
        print()

if __name__ == "__main__":
    main()

