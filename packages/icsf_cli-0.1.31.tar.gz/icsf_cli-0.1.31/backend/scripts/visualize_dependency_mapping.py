"""
Visual demonstration of how intra-repository dependency mapping works
"""
import os
import sys
from pathlib import Path

# Fix encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.dependency_service import DependencyService

def visualize_dependency_mapping():
    """Visual demonstration of the dependency mapping process"""
    
    repo_path = os.path.abspath('temp_analysis_repo')
    
    if not os.path.exists(repo_path):
        print(f"❌ Repository not found at {repo_path}")
        return
    
    print("=" * 80)
    print("VISUAL DEMONSTRATION: How Intra-Repo Dependency Mapping Works")
    print("=" * 80)
    print()
    
    # Step 1: Find all Java files
    print("STEP 1: Finding All Java Files")
    print("-" * 80)
    java_files = DependencyService.find_java_files(repo_path)
    print(f"Found {len(java_files)} Java files")
    print(f"Example files:")
    for f in java_files[:5]:
        print(f"  - {f}")
    if len(java_files) > 5:
        print(f"  ... and {len(java_files) - 5} more")
    print()
    
    # Step 2: Parse a sample file
    print("=" * 80)
    print("STEP 2: Parsing Java Files (Example: User.java)")
    print("-" * 80)
    
    user_file = None
    for f in java_files:
        if 'User.java' in f and 'models' in f:
            user_file = f
            break
    
    if user_file:
        full_path = os.path.join(repo_path, user_file)
        parsed = DependencyService.parse_java_file(full_path)
        
        print(f"File: {user_file}")
        print(f"Package: {parsed.get('package', 'N/A')}")
        print(f"Classes: {parsed.get('classes', [])}")
        print(f"Interfaces: {parsed.get('interfaces', [])}")
        print()
        
        # Show what the parser extracts
        print("What the parser extracts:")
        print(f"  - Package declaration: {parsed.get('package')}")
        print(f"  - Classes defined: {parsed.get('classes')}")
        print(f"  - Imports: {len(parsed.get('imports', []))} imports")
        print(f"  - Instantiations: {parsed.get('instantiations', [])}")
        print(f"  - References: {parsed.get('references', [])[:5]}...")
        print()
    
    # Step 3: Build class-to-file map
    print("=" * 80)
    print("STEP 3: Building Class-to-File Mapping")
    print("-" * 80)
    
    parsed_files = {}
    for java_file in java_files[:10]:  # Parse first 10 for demo
        full_path = os.path.join(repo_path, java_file)
        parsed = DependencyService.parse_java_file(full_path)
        parsed_files[java_file] = parsed
    
    class_to_file_map = {}
    for file_path, parsed in parsed_files.items():
        file_package = parsed.get('package', '')
        classes = parsed.get('classes', [])
        interfaces = parsed.get('interfaces', [])
        
        for cls in classes:
            full_class_name = f"{file_package}.{cls}" if file_package else cls
            class_to_file_map[cls] = file_path
            class_to_file_map[full_class_name] = file_path
        
        for iface in interfaces:
            full_iface_name = f"{file_package}.{iface}" if file_package else iface
            class_to_file_map[iface] = file_path
            class_to_file_map[full_iface_name] = file_path
    
    print("Class-to-File Map (sample):")
    count = 0
    for cls, file_path in class_to_file_map.items():
        if count < 10:
            print(f"  '{cls}' → {file_path}")
            count += 1
        else:
            print(f"  ... and {len(class_to_file_map) - 10} more mappings")
            break
    print()
    
    # Step 4: Build dependency map
    print("=" * 80)
    print("STEP 4: Building Dependency Map")
    print("-" * 80)
    
    # Parse all files
    all_parsed = {}
    for java_file in java_files:
        full_path = os.path.join(repo_path, java_file)
        parsed = DependencyService.parse_java_file(full_path)
        all_parsed[java_file] = parsed
    
    # Build full class map
    full_class_map = {}
    for file_path, parsed in all_parsed.items():
        file_package = parsed.get('package', '')
        classes = parsed.get('classes', [])
        interfaces = parsed.get('interfaces', [])
        
        for cls in classes:
            full_class_name = f"{file_package}.{cls}" if file_package else cls
            full_class_map[cls] = file_path
            full_class_map[full_class_name] = file_path
        
        for iface in interfaces:
            full_iface_name = f"{file_package}.{iface}" if file_package else iface
            full_class_map[iface] = file_path
            full_class_map[full_iface_name] = file_path
    
    # Show example: How Accounts.java depends on User.java
    print("Example: How dependencies are detected")
    print()
    
    accounts_file = None
    for f in java_files:
        if 'Accounts.java' in f and 'controllers' in f:
            accounts_file = f
            break
    
    if accounts_file:
        accounts_parsed = all_parsed[accounts_file]
        print(f"File: {accounts_file}")
        print(f"Package: {accounts_parsed.get('package')}")
        print()
        print("This file has:")
        print(f"  Imports: {accounts_parsed.get('imports_full', [])[:5]}")
        print(f"  Instantiations: {accounts_parsed.get('instantiations', [])[:5]}")
        print(f"  References: {accounts_parsed.get('references', [])[:5]}")
        print()
        print("Dependency Detection Process:")
        print("  1. Check imports:")
        for imp in accounts_parsed.get('imports_full', [])[:3]:
            imp_clean = imp.replace('.*', '')
            print(f"     - Found import: {imp}")
            # Check if this matches User
            if 'User' in imp or 'models' in imp:
                print(f"       → Matches 'models.User'")
                print(f"       → Found in: models/User.java")
                print(f"       → Dependency type: 'import'")
        print()
        print("  2. Check instantiations:")
        for inst in accounts_parsed.get('instantiations', [])[:3]:
            if inst in full_class_map:
                print(f"     - Found: new {inst}()")
                print(f"       → Matches class '{inst}'")
                print(f"       → Found in: {full_class_map[inst]}")
                print(f"       → Dependency type: 'instantiation'")
        print()
        print("  3. Check class references:")
        for ref in accounts_parsed.get('references', [])[:3]:
            if ref in full_class_map:
                print(f"     - Found: {ref} (used as type)")
                print(f"       → Matches class '{ref}'")
                print(f"       → Found in: {full_class_map[ref]}")
                print(f"       → Dependency type: 'class_reference'")
        print()
    
    # Step 5: Build complete dependency map
    print("=" * 80)
    print("STEP 5: Building Complete Dependency Map")
    print("-" * 80)
    
    dependency_map = DependencyService.build_intra_repo_dependencies(repo_path)
    
    print(f"Total files with dependencies: {len(dependency_map)}")
    print()
    print("Sample dependencies:")
    count = 0
    for file_path, deps in dependency_map.items():
        if count < 5 and len(deps) > 0:
            print(f"\n{file_path}:")
            for dep in deps[:3]:
                print(f"  → Depends on: {dep['file']} [{dep['type']}]")
            if len(deps) > 3:
                print(f"  ... and {len(deps) - 3} more dependencies")
            count += 1
        elif count >= 5:
            break
    print()
    
    # Step 6: Build reverse map
    print("=" * 80)
    print("STEP 6: Building Reverse Dependency Map")
    print("-" * 80)
    print("(What depends on each file)")
    print()
    
    from collections import defaultdict
    reverse_map = defaultdict(list)
    
    for file_path, deps in dependency_map.items():
        for dep in deps:
            dep_file = dep['file']
            reverse_map[dep_file].append({
                'file': file_path,
                'type': dep['type'],
                'class': dep.get('class', dep.get('interface', ''))
            })
    
    print(f"Total files that are depended upon: {len(reverse_map)}")
    print()
    print("Example: What depends on User.java?")
    user_file_path = None
    for f in java_files:
        if 'User.java' in f and 'models' in f:
            user_file_path = f
            break
    
    if user_file_path and user_file_path in reverse_map:
        dependents = reverse_map[user_file_path]
        print(f"\n{user_file_path} is used by {len(dependents)} files:")
        for dep in dependents[:10]:
            print(f"  ← {dep['file']} [{dep['type']}]")
        if len(dependents) > 10:
            print(f"  ... and {len(dependents) - 10} more files")
    print()
    
    # Step 7: Visualize dependency chain
    print("=" * 80)
    print("STEP 7: Dependency Chain Visualization")
    print("-" * 80)
    print()
    
    if user_file_path and user_file_path in reverse_map:
        print("Example Dependency Chain:")
        print()
        print(f"  {user_file_path} (vulnerable file)")
        print("    ↓")
        print("  Direct Dependents (Depth 1):")
        for dep in reverse_map[user_file_path][:5]:
            print(f"    - {dep['file']} [{dep['type']}]")
        print()
        print("  Transitive Dependents (Depth 2+):")
        print("    (Files that depend on the direct dependents)")
        # Find transitive
        direct_deps = [d['file'] for d in reverse_map[user_file_path]]
        transitive_count = 0
        for direct_dep in direct_deps[:3]:
            if direct_dep in reverse_map:
                for trans_dep in reverse_map[direct_dep][:2]:
                    print(f"    - {trans_dep['file']} (via {direct_dep})")
                    transitive_count += 1
        print()
    
    print("=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print()
    print("The dependency mapping process:")
    print("  1. ✅ Finds all Java files in repository")
    print("  2. ✅ Parses each file to extract structure (package, imports, classes, etc.)")
    print("  3. ✅ Builds class-to-file mapping for fast lookups")
    print("  4. ✅ Matches imports, instantiations, references to find dependencies")
    print("  5. ✅ Builds forward dependency map (what each file depends on)")
    print("  6. ✅ Builds reverse dependency map (what depends on each file)")
    print("  7. ✅ Uses BFS to find all direct and transitive dependents")
    print()
    print("This gives you a complete picture of file dependencies! 🎯")

if __name__ == "__main__":
    visualize_dependency_mapping()

