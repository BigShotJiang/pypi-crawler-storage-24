import logging


def configure_logging():
    """
    Configure global logging for backend services.

    - Sets root level to INFO so service logs are visible.
    - Keeps uvicorn access logs behavior unchanged.
    """
    # Only configure if not already configured
    if not logging.getLogger().handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )


