"""
ICSF backend package.

This file makes the `backend` directory importable as a Python package so we
can expose a first-class CLI entrypoint (`icsf`) via `backend.cli:main`.

It also exposes the internal `backend.atlas` subtree under the top-level
module name `atlas`, so that imports written as `from atlas...` (used inside
the Atlas code) continue to work when this package is installed from PyPI.
"""

import sys as _sys

# Expose backend.atlas as a top-level "atlas" package alias if present.
try:
    from . import atlas as _atlas  # type: ignore[attr-defined]
except ImportError:
    _atlas = None

if _atlas is not None and "atlas" not in _sys.modules:
    _sys.modules["atlas"] = _atlas

