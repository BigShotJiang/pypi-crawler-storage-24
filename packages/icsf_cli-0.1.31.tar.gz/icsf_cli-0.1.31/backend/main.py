from fastapi import FastAPI, HTTPException, Query, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict
import httpx
import json
import asyncio
import math
import os
import sys
import tempfile
import shutil
import subprocess
import uuid as _uuid
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import logging

from logging_config import configure_logging

# Ensure project root (containing the external `app` package) is on sys.path
BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BACKEND_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

from services.github_service import GitHubService
from services.vulnerability_service import VulnerabilityService
from services.dependency_service import DependencyService
from services.bedrock_service import BedrockService
from services.fix_orchestrator import FixOrchestrator
from services.pr_manager_service import PRManagerService
from services.batch_fix_service import BatchFixService
from services.batch_pr_service import BatchPRService
from services.atlas_service import atlas_service
from models.agent_models import VulnerabilityFixRequest, VulnerabilitySeverity
from config import Config

# Configure global logging so ICSF service logs are visible in uvicorn output
configure_logging()
logger = logging.getLogger(__name__)

# Get backend directory for temporary clone locations
backend_dir = Path(__file__).parent

app = FastAPI(
    title="ICSF — Intelligent Code Security Fixer",
    description="Enterprise platform for automated vulnerability detection, remediation, and testing.",
    version="2.0.0"
)

# CORS middleware — restrict origins via ALLOWED_ORIGINS env var (comma-separated), default allows all for dev
_allowed_origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in _allowed_origins],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


# --- Startup validation & health ---
@app.on_event("startup")
async def _startup_validation():
    """Smoke-check critical credentials on boot."""
    warnings = []
    try:
        if not Config.AWS_ACCESS_KEY_ID:
            warnings.append("AWS_ACCESS_KEY_ID is not set")
        if not Config.BEDROCK_MODEL_ID:
            warnings.append("BEDROCK_MODEL_ID is not set")
        github_creds = Config.get_github_credentials()
        if not github_creds.get("token"):
            warnings.append("GitHub token is not configured in credentials.yaml or GITHUB_TOKEN")
    except Exception as e:
        warnings.append(f"Config validation logic failed: {e}")
    if warnings:
        for w in warnings:
            logger.warning(f"[Startup] ⚠  {w}")
    else:
        logger.info("[Startup] ✓  All credentials validated successfully")


@app.get("/api/health")
async def health_check():
    """Lightweight health check for Docker/LB probes."""
    return {"status": "ok", "version": app.version}


# --- Request ID middleware for log correlation ---
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request as StarletteRequest

class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: StarletteRequest, call_next):
        request_id = request.headers.get("X-Request-ID", _uuid.uuid4().hex[:12])
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

app.add_middleware(RequestIDMiddleware)


class GitHubRepoRequest(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    token: Optional[str] = None  # Optional - will use credentials.yaml if not provided


class Repository(BaseModel):
    id: int
    name: str
    full_name: str
    description: Optional[str]
    url: str
    html_url: str
    clone_url: str
    ssh_url: str
    language: Optional[str]
    stars: int
    forks: int
    is_private: bool
    created_at: str
    updated_at: str
    pushed_at: Optional[str]


class RepositoriesResponse(BaseModel):
    username: Optional[str] = None
    total_repos: int
    public_repos: int
    private_repos: int
    repositories: list[Repository]


class Vulnerability(BaseModel):
    file_name: str
    line_no: str


class TestingRequest(BaseModel):
    """Request body for running the testing agent pipeline."""
    repo_url: Optional[str] = None  # Git URL (for remote cloning)
    repo_path: Optional[str] = None  # Local repository path (for testing fixed code)
    fixed_files: Optional[List[str]] = None  # List of files that were fixed (for targeted testing)
    create_pr: bool = False

    # Optional vulnerability context from the mapped report. The external
    # testing pipeline currently only needs the repo URL, so these are not
    # required for now but are kept for future use and compatibility.
    vulnerability: Optional[str] = ""
    description: Optional[str] = ""
    recommendation: Optional[str] = ""
    link: Optional[str] = ""


class MappedVulnerability(BaseModel):
    repo: Repository
    vulnerabilities: List[Vulnerability]


class VulnerabilityMappingResponse(BaseModel):
    mapped_vulnerabilities: Dict[int, MappedVulnerability]
    unmatched_vulnerabilities: List[Dict]
    total_mapped: int
    total_unmatched: int


@app.get("/")
async def root():
    return {"message": "GitHub Repositories API", "version": "1.0.0"}


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


@app.get("/api/config/github-credentials")
async def get_github_credentials():
    """
    Get GitHub credentials from configuration.
    Returns token for use in frontend operations that require it.
    """
    # Force reload to get latest credentials
    credentials = Config.get_github_credentials(force_reload=True)
    token = credentials.get('token')
    username = credentials.get('username')
    email = credentials.get('email')
    
    if not token:
        raise HTTPException(
            status_code=404,
            detail="GitHub token not configured. Please set it in backend/credentials.yaml"
        )
    
    # Return only token (not username/email for security)
    # But include a check status
    return {
        "token": token,
        "configured": True,
        "has_username": bool(username),
        "has_email": bool(email)
    }


@app.get("/api/config/verify-credentials")
async def verify_credentials():
    """
    Verify that credentials are loaded correctly from credentials.yaml.
    Useful for debugging credential loading issues.
    """
    credentials = Config.get_github_credentials(force_reload=True)
    
    return {
        "token_configured": bool(credentials.get('token')),
        "username_configured": bool(credentials.get('username')),
        "email_configured": bool(credentials.get('email')),
        "username": credentials.get('username') if credentials.get('username') else None,
        "email": credentials.get('email') if credentials.get('email') else None,
        "token_preview": f"***{credentials.get('token')[-4:]}" if credentials.get('token') and len(credentials.get('token', '')) > 4 else None
    }


@app.post("/api/repos", response_model=RepositoriesResponse)
async def fetch_github_repos(request: Optional[GitHubRepoRequest] = None):
    """
    Fetch GitHub repositories using credentials from credentials.yaml.
    
    Credentials are loaded from backend/credentials.yaml file.
    Request parameters are optional and will override YAML config if provided.
    """
    # Get credentials from config (YAML file) - force reload to get latest values
    github_creds = Config.get_github_credentials(force_reload=True)
    token = github_creds.get('token') or (request.token if request else None)
    username = github_creds.get('username') or (request.username if request else None)
    email = github_creds.get('email') or (request.email if request else None)
    
    # Log what we're using (without exposing token)
    logger = logging.getLogger(__name__)
    logger.info(f"Using GitHub credentials: username={username}, email={email}, token={'***' if token else 'None'}")
    
    # Validate credentials
    if not token:
        raise HTTPException(
            status_code=400,
            detail="GitHub token is required. Please set it in backend/credentials.yaml file."
        )
    
    if not username and not email:
        raise HTTPException(
            status_code=400,
            detail="Either username or email must be set in backend/credentials.yaml file."
        )
    
    github_service = GitHubService(token)
    
    try:
        # Determine which identifier to use
        # If both are provided, prefer username
        if username and email:
            # Username takes precedence when both are provided
            final_username = username
            logger.info(f"Using username from config: {final_username}")
        elif username:
            # Only username provided
            final_username = username
            logger.info(f"Using username from config: {final_username}")
        else:
            # Only email provided, try to find the username from authenticated user
            logger.info(f"Email provided, attempting to get username from GitHub API for: {email}")
            final_username = await github_service.get_username_from_email(email)
            if not final_username:
                raise HTTPException(
                    status_code=404,
                    detail=f"Email {email} does not match the authenticated user's email. Please set username in credentials.yaml instead."
                )
            logger.info(f"Resolved username from email: {final_username}")
        
        # Verify the token is valid and get authenticated user info
        logger.info(f"Verifying token and fetching user info for: {final_username}")
        user_info = await github_service.verify_token_and_get_user(final_username)
        authenticated_username = user_info.get("login")
        
        if not authenticated_username:
            raise HTTPException(
                status_code=401,
                detail="Failed to authenticate with GitHub. Please check your token and username/email in credentials.yaml"
            )
        
        logger.info(f"Authenticated as: {authenticated_username}")
        
        # Fetch all repositories (including organization repositories)
        repos = await github_service.get_all_repositories(
            final_username, 
            include_private=True, 
            authenticated_username=authenticated_username,
            include_orgs=True  # Include repositories from organizations
        )
        
        # Transform repositories to our response model
        repository_list = [
            Repository(
                id=repo["id"],
                name=repo["name"],
                full_name=repo["full_name"],
                description=repo.get("description"),
                url=repo["url"],
                html_url=repo["html_url"],
                clone_url=repo["clone_url"],
                ssh_url=repo["ssh_url"],
                language=repo.get("language"),
                stars=repo.get("stargazers_count", 0),
                forks=repo.get("forks_count", 0),
                is_private=repo.get("private", False),
                created_at=repo.get("created_at", ""),
                updated_at=repo.get("updated_at", ""),
                pushed_at=repo.get("pushed_at"),
            )
            for repo in repos
        ]
        
        # Count public and private repos
        public_count = sum(1 for repo in repository_list if not repo.is_private)
        private_count = len(repository_list) - public_count
        
        return RepositoriesResponse(
            username=authenticated_username or username,
            total_repos=len(repository_list),
            public_repos=public_count,
            private_repos=private_count,
            repositories=repository_list
        )
        
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise HTTPException(
                status_code=401,
                detail="Invalid or expired GitHub token"
            )
        elif e.response.status_code == 404:
            raise HTTPException(
                status_code=404,
                detail=f"GitHub user '{username}' not found"
            )
        else:
            raise HTTPException(
                status_code=e.response.status_code,
                detail=f"GitHub API error: {e.response.text}"
            )
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        logger.error(f"Error in fetch_github_repos: {str(e)}\n{error_details}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}. Check backend logs for full traceback."
        )


@app.get("/api/repos", response_model=RepositoriesResponse)
async def fetch_github_repos_get(
    username: Optional[str] = Query(None, description="GitHub username (either username or email is required)"),
    email: Optional[str] = Query(None, description="GitHub account email (either username or email is required)"),
    token: str = Query(..., description="GitHub personal access token")
):
    """
    Fetch GitHub repositories using GET request (alternative to POST).
    
    Either username OR email must be provided (only one is needed). If both are provided, username will be used.
    """
    request = GitHubRepoRequest(username=username, email=email, token=token)
    return await fetch_github_repos(request)


@app.post("/api/vulnerabilities/map")
async def map_vulnerabilities_to_repos(
    file: UploadFile = File(..., description="CSV file containing vulnerability data"),
    repositories_json: str = Form(..., description="JSON string of repositories from RepositoriesResponse"),
    token: Optional[str] = Form(None, description="GitHub token for fetching file trees (optional but recommended for file matching)")
):
    """
    Map vulnerabilities from CSV file to repositories.
    Now supports matching by both repository name/URL and file names.
    
    Expected CSV columns:
    - repo_name: Repository name
    - link: Repository URL
    - file_name: File path where vulnerability exists
    - line_no: Line number
    - vulnerability: Type of vulnerability
    - description: Description of the vulnerability
    - recommendation: Recommendation to fix
    
    Args:
        file: CSV file upload
        repositories_json: JSON string containing repositories data (from RepositoriesResponse)
        token: GitHub token for fetching file trees (optional but recommended for file matching)
        
    Returns:
        Dictionary with mapped and unmatched vulnerabilities
    """
    try:
        # Read file content
        file_content = await file.read()
        
        # Parse CSV
        vuln_df, error = VulnerabilityService.parse_csv_file(file_content, file.filename)
        
        if error:
            raise HTTPException(status_code=400, detail=error)
        
        if vuln_df is None or vuln_df.empty:
            raise HTTPException(status_code=400, detail="CSV file is empty or invalid")
        
        # Parse repositories JSON
        repos_data = json.loads(repositories_json)
        repos_list = repos_data.get("repositories", [])
        
        if not repos_list:
            raise HTTPException(status_code=400, detail="No repositories provided")
        
        # Fetch file trees for repositories if token is provided (in parallel for better performance)
        # OPTIMIZATION: Only fetch file trees for repos that have vulnerabilities in CSV
        repo_files_map = {}
        if token:
            github_service = GitHubService(token)
            
            # OPTIMIZATION: First, do repo name matching to identify which repos need file trees
            # This avoids fetching file trees for repos that don't have vulnerabilities
            repos_needing_files = set()
            vuln_repo_names = set()
            for _, row in vuln_df.iterrows():
                repo_name = VulnerabilityService.normalize_repo_identifier(
                    row.get('repo_name'),
                    row.get('link')
                )
                if repo_name:
                    vuln_repo_names.add(repo_name.lower())
            
            # Find which repos match vulnerability report repo names
            for repo in repos_list:
                repo_id = repo.get("id")
                repo_name = repo.get("name", "").lower()
                full_name = repo.get("full_name", "").lower()
                repo_url = repo.get("html_url", "")
                url_repo_name = VulnerabilityService.extract_repo_name_from_url(repo_url)
                if url_repo_name:
                    url_repo_name = url_repo_name.lower()
                
                # Check if this repo matches any vulnerability report repo name
                if (repo_name in vuln_repo_names or 
                    full_name in vuln_repo_names or 
                    (url_repo_name and url_repo_name in vuln_repo_names) or
                    any(vrn in repo_name or vrn in full_name for vrn in vuln_repo_names)):
                    repos_needing_files.add(repo_id)
            
            # OPTIMIZATION: Only fetch file trees for repos that need them
            if repos_needing_files:
                repos_to_fetch = [repo for repo in repos_list if repo.get("id") in repos_needing_files]
                
                # Create tasks for parallel fetching (only for needed repos)
                async def fetch_repo_files(repo):
                    repo_id = repo.get("id")
                    full_name = repo.get("full_name", "")
                    if full_name:
                        try:
                            owner, repo_name = full_name.split("/", 1)
                            file_tree = await github_service.get_repository_file_tree(owner, repo_name)
                            return repo_id, file_tree if file_tree else None
                        except Exception:
                            # If file tree fetch fails, return None
                            return repo_id, None
                    return repo_id, None
                
                # Fetch file trees in parallel (limit concurrency to avoid rate limits)
                tasks = [fetch_repo_files(repo) for repo in repos_to_fetch]
                
                # Process in batches for optimal performance (increased batch size)
                batch_size = 30  # Increased batch size for faster processing
                for i in range(0, len(tasks), batch_size):
                    batch = tasks[i:i + batch_size]
                    try:
                        # Reduced timeout per batch for faster failure detection
                        results = await asyncio.wait_for(
                            asyncio.gather(*batch, return_exceptions=True),
                            timeout=60.0  # Reduced timeout for faster failure
                        )
                        
                        for result in results:
                            if isinstance(result, Exception):
                                continue
                            repo_id, file_tree = result
                            if file_tree:
                                repo_files_map[repo_id] = file_tree
                    except asyncio.TimeoutError:
                        # If batch times out, skip it and continue with next batch
                        continue
        
        # Map vulnerabilities with file matching support
        # Enable cloning for accurate file matching
        mapped_vulns, unmatched_vulns = VulnerabilityService.map_vulnerabilities_to_repos(
            vuln_df, repos_list, repo_files_map if repo_files_map else None, clone_repos=True
        )
        
        # Convert to response format
        mapped_response = {}
        for repo_id, data in mapped_vulns.items():
            mapped_response[str(repo_id)] = {
                "repo": data['repo'],
                "vulnerabilities": data['vulnerabilities']
            }
        
        # Add file tree statistics for debugging
        file_tree_stats = {}
        if repo_files_map:
            for repo_id, files in repo_files_map.items():
                repo = next((r for r in repos_list if r.get("id") == repo_id), None)
                if repo:
                    file_tree_stats[str(repo_id)] = {
                        "repo_name": repo.get("full_name", ""),
                        "file_count": len(files)
                    }
        
        def sanitize_nans(obj):
            """Recursively replace NaN, Infinity, -Infinity with None."""
            if isinstance(obj, dict):
                return {k: sanitize_nans(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [sanitize_nans(i) for i in obj]
            elif isinstance(obj, float):
                if math.isnan(obj) or math.isinf(obj):
                    return None
            return obj

        import math
        response_data = {
            "mapped_vulnerabilities": mapped_response,
            "unmatched_vulnerabilities": unmatched_vulns,
            "total_mapped": len(mapped_response),
            "total_unmatched": len(unmatched_vulns),
            "file_tree_stats": file_tree_stats  # Debug info
        }
        
        return sanitize_nans(response_data)
        
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON format for repositories")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing vulnerability mapping: {str(e)}"
        )


@app.post("/api/dependencies/analyze")
async def analyze_dependencies(
    repo_id: int = Form(...),
    vulnerable_file: str = Form(...),
    vulnerable_line: int = Form(...),
    repositories_json: str = Form(...),
    token: Optional[str] = Form(None)
):
    """
    Analyze dependencies for a vulnerable file.
    
    Args:
        repo_id: ID of the repository containing the vulnerable file
        vulnerable_file: Path to vulnerable file (relative to repo root)
        vulnerable_line: Line number of vulnerability
        repositories_json: JSON string containing all repositories
        token: GitHub token for cloning repositories
        
    Returns:
        Dependency map showing all affected files
    """
    try:
        # Parse repositories
        repos_data = json.loads(repositories_json)
        repos_list = repos_data.get("repositories", [])
        
        # Find the target repository
        target_repo = None
        for repo in repos_list:
            if repo.get("id") == repo_id:
                target_repo = repo
                break
        
        if not target_repo:
            raise HTTPException(status_code=404, detail=f"Repository with ID {repo_id} not found")
        
        # Clone the target repository
        repo_clone_url = target_repo.get('clone_url') or target_repo.get('html_url', '')
        if not repo_clone_url:
            raise HTTPException(status_code=400, detail="Repository URL not available")
        
        if 'github.com' in repo_clone_url and not repo_clone_url.endswith('.git'):
            repo_clone_url = repo_clone_url + '.git'
        
        # Create temp directory for cloning
        temp_clone_dir = tempfile.mkdtemp(prefix="dep_analysis_")
        repo_name = target_repo.get('full_name', 'repo').replace('/', '_')
        repo_clone_path = os.path.join(temp_clone_dir, repo_name)
        
        try:
            # Clone target repository asynchronously
            def run_clone_target():
                return subprocess.run(
                    ['git', 'clone', '--depth', '1', '--quiet', repo_clone_url, repo_clone_path],
                    check=True,
                    capture_output=True,
                    timeout=120,
                    shell=(os.name == 'nt')
                )
            
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, run_clone_target)
            
            # Clone all repositories for comprehensive inter-repo dependency analysis
            all_repos_with_paths = [{
                **target_repo,
                'clone_path': repo_clone_path
            }]
            
            # Clone other repositories in parallel (for cross-repo dependency analysis)
            async def clone_repo_async(repo, clone_dir):
                """Clone a repository asynchronously"""
                if repo.get("id") == repo_id:  # Skip target repo
                    return None
                
                repo_clone_url = repo.get('clone_url') or repo.get('html_url', '')
                if not repo_clone_url:
                    return None
                
                if 'github.com' in repo_clone_url and not repo_clone_url.endswith('.git'):
                    repo_clone_url = repo_clone_url + '.git'
                
                repo_name = repo.get('full_name', 'repo').replace('/', '_')
                repo_clone_path = os.path.join(clone_dir, repo_name)
                
                def run_clone():
                    return subprocess.run(
                        ['git', 'clone', '--depth', '1', '--quiet', repo_clone_url, repo_clone_path],
                        check=True,
                        capture_output=True,
                        timeout=120,
                        shell=(os.name == 'nt')
                    )
                
                try:
                    # Run git clone in executor (blocking I/O)
                    loop = asyncio.get_event_loop()
                    await asyncio.wait_for(
                        loop.run_in_executor(None, run_clone),
                        timeout=130  # Slightly longer than subprocess timeout
                    )
                    return {
                        **repo,
                        'clone_path': repo_clone_path
                    }
                except (asyncio.TimeoutError, subprocess.TimeoutExpired, subprocess.CalledProcessError):
                    # If cloning fails, return None
                    return None
                except Exception:
                    return None
            
            # Clone ALL repositories from the GitHub account (not just a subset)
            # This ensures we check all repositories for cross-repo dependencies
            other_repos = [repo for repo in repos_list if repo.get("id") != repo_id]
            
            print(f"[DEBUG] Will check {len(other_repos)} repositories from GitHub account for cross-repo dependencies")
            
            # Clone repositories in batches to avoid overwhelming the system
            # Process in batches of 5 to balance performance and thoroughness
            batch_size = 5
            cloned_count = 0
            
            for i in range(0, len(other_repos), batch_size):
                batch = other_repos[i:i + batch_size]
                print(f"[DEBUG] Cloning batch {i//batch_size + 1} ({len(batch)} repositories)...")
                
                clone_tasks = [clone_repo_async(repo, temp_clone_dir) for repo in batch]
                clone_results = await asyncio.gather(*clone_tasks, return_exceptions=True)
                
                for result in clone_results:
                    if result and isinstance(result, dict):
                        all_repos_with_paths.append(result)
                        cloned_count += 1
                        print(f"[DEBUG]   ✅ Cloned: {result.get('full_name', 'Unknown')}")
                    elif isinstance(result, Exception):
                        # Log error but continue
                        print(f"[DEBUG]   ❌ Failed to clone a repository: {type(result).__name__}")
                        pass
                
                # Small delay between batches to avoid rate limits
                if i + batch_size < len(other_repos):
                    await asyncio.sleep(1)
            
            print(f"[DEBUG] Successfully cloned {cloned_count} out of {len(other_repos)} repositories")

            # Also add local temporary dependent repositories if present (e.g., backend/test_dependent_repo)
            # This allows analyzing local test repos that are not in GitHub
            backend_dir = os.path.dirname(os.path.abspath(__file__))
            local_test_repo_path = os.path.join(backend_dir, "test_dependent_repo")
            if os.path.isdir(local_test_repo_path):
                local_entry = {
                    "id": "local_test_dependent_repo",
                    "full_name": "local/test_dependent_repo",
                    "clone_path": local_test_repo_path,
                    "name": "test_dependent_repo"
                }
                all_repos_with_paths.append(local_entry)
                print(f"[DEBUG] Added local test repository for analysis: {local_test_repo_path}")
            
            # Build dependency map with all cloned repositories (run in executor to avoid blocking)
            loop = asyncio.get_event_loop()
            
            def run_dependency_analysis():
                # Log which repositories will be checked
                print(f"[DEBUG] Running dependency analysis with {len(all_repos_with_paths)} repositories:")
                for repo in all_repos_with_paths:
                    repo_name = repo.get('full_name', repo.get('name', 'Unknown'))
                    repo_path = repo.get('clone_path', 'No path')
                    print(f"[DEBUG]   - {repo_name}: {repo_path}")
                
                return DependencyService.find_dependent_files(
                    vulnerable_file=vulnerable_file,
                    vulnerable_line=vulnerable_line,
                    repo_path=repo_clone_path,
                    all_repos=all_repos_with_paths,
                    max_depth=5
                )
            
            dependency_map = await loop.run_in_executor(None, run_dependency_analysis)
            
            return {
                "success": True,
                "dependency_map": dependency_map
            }
            
        finally:
            # Clean up
            if os.path.exists(temp_clone_dir):
                shutil.rmtree(temp_clone_dir, ignore_errors=True)
                
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=408, detail="Timeout cloning repository")
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=f"Failed to clone repository: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error analyzing dependencies: {str(e)}")


@app.post("/api/dependencies/batch-analyze")
async def batch_analyze_dependencies(
    vulnerabilities_json: str = Form(...),
    repositories_json: str = Form(...),
    token: Optional[str] = Form(None)
):
    """
    Analyze dependencies for multiple vulnerabilities at once.
    
    Args:
        vulnerabilities_json: JSON array of vulnerabilities with repo_id, file, line
        repositories_json: JSON string containing all repositories
        token: GitHub token for cloning repositories
        
    Returns:
        Dictionary mapping vulnerability IDs to their dependency maps
    """
    try:
        vulnerabilities = json.loads(vulnerabilities_json)
        repos_data = json.loads(repositories_json)
        repos_list = repos_data.get("repositories", [])
        
        results = {}
        
        # Group vulnerabilities by repository
        repo_vulns = defaultdict(list)
        for vuln in vulnerabilities:
            repo_id = vuln.get('repo_id')
            repo_vulns[repo_id].append(vuln)
        
        # Analyze each repository
        for repo_id, vulns in repo_vulns.items():
            target_repo = None
            for repo in repos_list:
                if repo.get("id") == repo_id:
                    target_repo = repo
                    break
            
            if not target_repo:
                continue
            
            # Clone repository once for all vulnerabilities
            repo_clone_url = target_repo.get('clone_url') or target_repo.get('html_url', '')
            if not repo_clone_url:
                continue
            
            if 'github.com' in repo_clone_url and not repo_clone_url.endswith('.git'):
                repo_clone_url = repo_clone_url + '.git'
            
            temp_clone_dir = tempfile.mkdtemp(prefix="dep_analysis_")
            repo_name = target_repo.get('full_name', 'repo').replace('/', '_')
            repo_clone_path = os.path.join(temp_clone_dir, repo_name)
            
            try:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, lambda: subprocess.run(
                    ['git', 'clone', '--depth', '1', '--quiet', repo_clone_url, repo_clone_path],
                    check=True,
                    capture_output=True,
                    timeout=120,
                    shell=(os.name == 'nt')
                ))
                
                all_repos_with_paths = [{
                    **target_repo,
                    'clone_path': repo_clone_path
                }]
                
                # Analyze each vulnerability
                for vuln in vulns:
                    vuln_id = vuln.get('id') or f"{repo_id}_{vuln.get('file')}_{vuln.get('line')}"
                    dependency_map = DependencyService.find_dependent_files(
                        vulnerable_file=vuln.get('file'),
                        vulnerable_line=vuln.get('line'),
                        repo_path=repo_clone_path,
                        all_repos=all_repos_with_paths,
                        max_depth=5
                    )
                    results[vuln_id] = dependency_map
                    
            finally:
                if os.path.exists(temp_clone_dir):
                    shutil.rmtree(temp_clone_dir, ignore_errors=True)
        
        return {
            "success": True,
            "results": results
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error in batch analysis: {str(e)}")


@app.post("/api/fixes/orchestrate")
async def orchestrate_fix(
    vulnerability_type: str = Form(...),
    description: str = Form(...),
    severity: str = Form(...),
    file_path: str = Form(...),
    line_number: int = Form(...),
    repo_path: Optional[str] = Form(None),
    repo_name: str = Form(...),
    clone_url: Optional[str] = Form(None),
    token: Optional[str] = Form(None),
    recommendation: Optional[str] = Form(None),
    validate_fix: Optional[bool] = Form(False),
    max_validation_retries: Optional[int] = Form(1)
):
    """
    Orchestrate the multi-agent vulnerability fixing workflow.
    
    This endpoint runs all 6 agents to analyze, fix, validate, and explain a vulnerability.
    
    Args:
        vulnerability_type: Type of vulnerability (e.g., "SQL Injection")
        description: Vulnerability description
        severity: Severity level (critical, high, medium, low, info)
        file_path: Path to vulnerable file (relative to repo root)
        line_number: Line number of vulnerability
        repo_path: Path to repository root directory (optional, will clone if not provided)
        repo_name: Repository name
        clone_url: Repository clone URL (required if repo_path is not provided)
        token: GitHub token for cloning private repos (optional)
        recommendation: Optional scanner recommendation
        
    Returns:
        FixOrchestrationResult with results from all agents
    """
    try:
        # Validate severity
        try:
            severity_enum = VulnerabilitySeverity(severity.lower())
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid severity: {severity}. Must be one of: critical, high, medium, low, info"
            )
        
        # Determine repository path - clone if needed
        if repo_path:
            repo_path_obj = Path(repo_path)
            if not repo_path_obj.exists():
                raise HTTPException(
                    status_code=404,
                    detail=f"Repository path does not exist: {repo_path}"
                )
            final_repo_path = repo_path
        elif clone_url:
            # Clone the repository to a temporary directory with optimized caching
            temp_clone_dir = Path(backend_dir) / "temp_cloned_repos" / repo_name
            temp_clone_dir.parent.mkdir(parents=True, exist_ok=True)
            
            # Check if repository is already cloned (cache check)
            git_dir = temp_clone_dir / ".git"
            if temp_clone_dir.exists() and git_dir.exists():
                # Repository exists, use cached version
                final_repo_path = str(temp_clone_dir)
            else:
                # Clone the repository
                repo_clone_url = clone_url
                if 'github.com' in repo_clone_url and not repo_clone_url.endswith('.git'):
                    repo_clone_url = repo_clone_url + '.git'
                
                # Add token to clone URL if provided (for private repos)
                if token and 'github.com' in repo_clone_url:
                    if repo_clone_url.startswith('https://'):
                        # Insert token into HTTPS URL
                        repo_clone_url = repo_clone_url.replace('https://', f'https://{token}@')
                    elif repo_clone_url.startswith('git@'):
                        # For SSH, token is not directly usable - would need SSH keys
                        pass  # Keep as-is for SSH
                
                # Remove existing directory if it exists but isn't a valid git repo
                if temp_clone_dir.exists():
                    shutil.rmtree(temp_clone_dir)
                
                # Clone repository with optimized flags (shallow, single branch, no history)
                # Using executor to avoid blocking event loop
                loop = asyncio.get_event_loop()
                clone_result = await loop.run_in_executor(
                    None,
                    lambda: subprocess.run(
                        [
                            'git', 'clone',
                            '--depth', '1',           # Shallow clone (only latest commit)
                            '--single-branch',         # Only clone main/master branch
                            '--filter=blob:none',      # Don't download file contents yet (faster)
                            '--quiet',                 # Quiet mode
                            repo_clone_url,
                            str(temp_clone_dir)
                        ],
                        capture_output=True,
                        text=True,
                        timeout=60,  # Reduced timeout since we're optimizing
                        shell=(os.name == 'nt')
                    )
                )
                
                if clone_result.returncode != 0:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Failed to clone repository: {clone_result.stderr}"
                    )
                
                final_repo_path = str(temp_clone_dir)
        else:
            raise HTTPException(
                status_code=400,
                detail="Either repo_path or clone_url must be provided"
            )
        
        # Create vulnerability fix request
        fix_request = VulnerabilityFixRequest(
            vulnerability_type=vulnerability_type,
            description=description,
            severity=severity_enum,
            recommendation=recommendation,
            file_path=file_path,
            line_number=line_number,
            repo_path=final_repo_path,
            repo_name=repo_name
        )
        
        # Initialize Bedrock service and orchestrator
        bedrock_config = Config.get_bedrock_config()
        bedrock_service = BedrockService(
            access_key=bedrock_config['access_key'],
            secret_key=bedrock_config['secret_key'],
            region=bedrock_config['region']
        )
        
        orchestrator = FixOrchestrator(bedrock_service)
        
        # Run orchestration (all agents)
        # Default to False for validate_fix to avoid blocking fixes with build issues
        result = await orchestrator.orchestrate_fix(
            fix_request, 
            stop_at_agent=None,
            validate_fix=validate_fix if validate_fix is not None else False,
            max_validation_retries=max_validation_retries if max_validation_retries is not None else 1
        )
        
        # Convert result to dict for JSON serialization
        result_dict = result.model_dump(mode='json', exclude_none=True)
        
        return {
            "success": result.overall_status == "success",
            "status": result.overall_status,
            "errors": result.errors,
            "result": result_dict,
            "repo_name": repo_name,
            "repo_path": final_repo_path,
            "vulnerability_type": vulnerability_type,
            "description": description
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error orchestrating fix: {str(e)}"
        )


@app.post("/api/fixes/create-pr")
async def create_pull_request(
    repo_owner: str = Form(...),
    repo_name: str = Form(...),
    repo_path: str = Form(...),
    files_modified_json: str = Form(...),
    fixed_code_json: str = Form(...),
    vulnerability_type: str = Form(...),
    vulnerability_description: str = Form(...),
    fix_summary: str = Form(...),
    token: str = Form(...),
    base_branch: str = Form("main")
):
    """
    Create a Pull Request with the fixed code.
    
    This endpoint:
    1. Creates a new branch
    2. Applies the fixed code to files
    3. Commits the changes
    4. Pushes to GitHub
    5. Creates a Pull Request
    
    Args:
        repo_owner: Repository owner (username or organization)
        repo_name: Repository name
        repo_path: Path to cloned repository
        files_modified_json: JSON string list of modified file paths
        fixed_code_json: JSON string mapping file paths to fixed code
        vulnerability_type: Type of vulnerability fixed
        vulnerability_description: Description of vulnerability
        fix_summary: Summary of the fix
        token: GitHub token for authentication
        base_branch: Base branch to create PR against (default: "main")
        
    Returns:
        Dictionary with PR creation result
    """
    try:
        # Parse JSON inputs
        files_modified = json.loads(files_modified_json)
        fixed_code_map = json.loads(fixed_code_json)
        
        # Validate repository path
        repo_path_obj = Path(repo_path)
        if not repo_path_obj.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Repository path does not exist: {repo_path}"
            )
        
        # Initialize PR Manager
        pr_manager = PRManagerService(token)
        
        # Create PR
        result = await pr_manager.create_pr_for_fix(
            repo_path=str(repo_path_obj),
            repo_owner=repo_owner,
            repo_name=repo_name,
            files_modified=files_modified,
            fixed_code_map=fixed_code_map,
            vulnerability_type=vulnerability_type,
            vulnerability_description=vulnerability_description,
            fix_summary=fix_summary,
            base_branch=base_branch
        )
        
        return result
        
    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid JSON format: {str(e)}"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error creating PR: {str(e)}"
        )


from services.job_manager import job_manager
from services.run_history import run_history
import asyncio
from fastapi.responses import StreamingResponse

@app.post("/api/testing/jobs")
async def start_testing_job(request: TestingRequest):
    """
    Start the external testing agent pipeline as a background job.
    Returns: { "job_id": "...", "run_id": "..." }
    """
    logger.info(f"[main] Received testing job request: repo_url={request.repo_url}, repo_path={request.repo_path}")
    
    if not request.repo_url and not request.repo_path:
        raise HTTPException(status_code=400, detail="Either repo_url or repo_path must be provided")
        
    job_id = job_manager.create_job()
    run_id = run_history.create_run(repo_url=request.repo_url, repo_path=request.repo_path)
    
    async def run_pipeline_task():
        try:
            job_manager.update_job(job_id, "RUNNING", "Initializing pipeline...", progress=5)
            
            if request.repo_path:
                if not request.repo_url:
                    request.repo_url = "local"
                report_data = await atlas_service.run_testing_pipeline_local(
                    repo_path=request.repo_path,
                    repo_url=request.repo_url,
                    fixed_files=request.fixed_files,
                    create_pr=request.create_pr,
                    job_id=job_id # Pass job_id down
                )
            else:
                report_data = await atlas_service.run_testing_pipeline(
                    repo_url=request.repo_url,
                    create_pr=request.create_pr,
                    job_id=job_id # Pass job_id down
                )
                
            def sanitize_nans_local(obj):
                import math
                if isinstance(obj, dict):
                    return {k: sanitize_nans_local(v) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [sanitize_nans_local(i) for i in obj]
                elif isinstance(obj, float):
                    if math.isnan(obj) or math.isinf(obj):
                        return None
                return obj

            sanitized_report = sanitize_nans_local(report_data)
            
            # Extract cost and token counts — the actual report is nested under "report" key
            cost = 0.0
            input_tokens = 0
            output_tokens = 0
            inner_report = sanitized_report.get("report", sanitized_report) or sanitized_report
            if isinstance(inner_report, dict):
                usage = inner_report.get("usage")
                if isinstance(usage, dict):
                    if "estimated_cost_usd" in usage:
                        cost = usage.get("estimated_cost_usd", 0.0) or 0.0
                    input_tokens = int(usage.get("input_tokens", 0) or 0)
                    output_tokens = int(usage.get("output_tokens", 0) or 0)
            # Fallback: check top-level keys too
            if cost == 0.0:
                if isinstance(sanitized_report.get("usage"), dict):
                    cost = sanitized_report["usage"].get("estimated_cost_usd", 0.0) or 0.0
                    if input_tokens == 0:
                        input_tokens = int(sanitized_report["usage"].get("input_tokens", 0) or 0)
                    if output_tokens == 0:
                        output_tokens = int(sanitized_report["usage"].get("output_tokens", 0) or 0)
                elif "total_cost" in sanitized_report:
                    cost = sanitized_report["total_cost"] or 0.0
                
            run_history.update_run(run_id, "COMPLETED", result_data=sanitized_report, cost=cost, input_tokens=input_tokens, output_tokens=output_tokens)
            job_manager.update_job(job_id, "COMPLETED", "Pipeline finished successfully", progress=100, result=sanitized_report)
            
        except Exception as e:
            logger.error(f"[main] Job {job_id} failed: {e}", exc_info=True)
            run_history.update_run(run_id, "FAILED", error_msg=str(e))
            job_manager.update_job(job_id, "FAILED", f"Error: {str(e)}", error=str(e))
        finally:
            job_manager.end_job(job_id)

    # Start the task in background
    asyncio.create_task(run_pipeline_task())
    
    return {"job_id": job_id, "run_id": run_id, "message": "Pipeline job started"}

@app.get("/api/testing/jobs/{job_id}")
async def get_testing_job(job_id: str):
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.get("/api/testing/jobs/{job_id}/stream")
async def stream_testing_job(job_id: str):
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return StreamingResponse(
        job_manager.stream_job_events(job_id),
        media_type="text/event-stream"
    )

@app.get("/api/runs")
async def get_recent_runs(limit: int = 50):
    return run_history.get_recent_runs(limit=limit)

# Kept for backward compatibility while UI updates to new job async flow
@app.post("/api/testing/run")
async def run_testing_pipeline(request: TestingRequest):
    raise HTTPException(
        status_code=400,
        detail="This endpoint is deprecated. Use POST /api/testing/jobs instead."
    )


@app.post("/api/fixes/batch")
async def batch_fix_vulnerabilities(
    vulnerabilities_json: str = Form(...),
    repo_path: Optional[str] = Form(""),
    repo_name: str = Form(...),
    clone_url: Optional[str] = Form(None),
    token: Optional[str] = Form(None),
    auto_create_pr: bool = Form(False),
    repo_owner: Optional[str] = Form(None),
    base_branch: str = Form("main"),
    run_tests_after_fix: bool = Form(True)  # NEW: Run testing agent after fixes
):
    """
    Fix multiple vulnerabilities in batch.
    
    Args:
        vulnerabilities_json: JSON string list of vulnerability dictionaries
        repo_path: Path to repository (if already cloned, optional)
        repo_name: Repository name
        clone_url: Clone URL (if repo needs to be cloned)
        token: GitHub token for private repos
        auto_create_pr: If True, automatically create PR after each successful fix
        repo_owner: Repository owner (required if auto_create_pr is True)
        base_branch: Base branch for PRs (default: "main")
        
    Returns:
        Dictionary with batch fix results (includes pr_results if auto_create_pr is True)
    """
    try:
        # Parse vulnerabilities
        vulnerabilities = json.loads(vulnerabilities_json)
        
        if not isinstance(vulnerabilities, list):
            raise HTTPException(
                status_code=400,
                detail="vulnerabilities_json must be a JSON array"
            )
        
        # Determine repository path - clone if needed
        final_repo_path = repo_path or ""
        
        # Check if we need to clone
        needs_clone = False
        if not final_repo_path:
            needs_clone = True
        elif not Path(final_repo_path).exists():
            needs_clone = True
        
        if needs_clone:
            if not clone_url:
                raise HTTPException(
                    status_code=400,
                    detail="Either repo_path must exist or clone_url must be provided"
                )
            
            # Clone the repository
            temp_clone_dir = Path(backend_dir) / "temp_cloned_repos" / repo_name
            temp_clone_dir.parent.mkdir(parents=True, exist_ok=True)
            
            git_dir = temp_clone_dir / ".git"
            if temp_clone_dir.exists() and git_dir.exists():
                final_repo_path = str(temp_clone_dir)
            else:
                repo_clone_url = clone_url
                if 'github.com' in repo_clone_url and not repo_clone_url.endswith('.git'):
                    repo_clone_url = repo_clone_url + '.git'
                
                if token and 'github.com' in repo_clone_url:
                    if repo_clone_url.startswith('https://'):
                        repo_clone_url = repo_clone_url.replace('https://', f'https://{token}@')
                
                if temp_clone_dir.exists():
                    shutil.rmtree(temp_clone_dir)
                
                loop = asyncio.get_event_loop()
                clone_result = await loop.run_in_executor(
                    None,
                    lambda: subprocess.run(
                        [
                            'git', 'clone',
                            '--depth', '1',
                            '--single-branch',
                            '--filter=blob:none',
                            '--quiet',
                            repo_clone_url,
                            str(temp_clone_dir)
                        ],
                        capture_output=True,
                        text=True,
                        timeout=60,
                        shell=(os.name == "nt")
                    )
                )
                
                if clone_result.returncode != 0:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Failed to clone repository: {clone_result.stderr}"
                    )
                
                final_repo_path = str(temp_clone_dir)
        
        # Validate that we have a valid repository path
        if not final_repo_path or not Path(final_repo_path).exists():
            raise HTTPException(
                status_code=404,
                detail=f"Repository path does not exist: {final_repo_path}"
            )
        
        # Initialize services
        bedrock_config = Config.get_bedrock_config()
        bedrock_service = BedrockService(
            access_key=bedrock_config['access_key'],
            secret_key=bedrock_config['secret_key'],
            region=bedrock_config['region']
        )
        
        batch_fix_service = BatchFixService(bedrock_service)
        
        # Process batch fixes with optimized concurrency
        # Always use at least 2 concurrent workers even for small batches.
        # Max concurrency capped at 3 to avoid overwhelming the LLM and the system.
        num_vulns = len(vulnerabilities)
        optimal_concurrency = min(3, max(2, num_vulns // 3)) if num_vulns > 2 else min(2, num_vulns)
        # Fallback safeguard: ensure optimal_concurrency is at least 1
        optimal_concurrency = max(1, optimal_concurrency)
        
        results = await batch_fix_service.fix_batch_vulnerabilities(
            vulnerabilities=vulnerabilities,
            repo_path=final_repo_path,
            repo_name=repo_name,
            clone_url=clone_url,
            token=token,
            max_concurrent=optimal_concurrency,  # Optimized: 2-3 concurrent fixes
            auto_create_pr=auto_create_pr,
            repo_owner=repo_owner,
            base_branch=base_branch,
            run_tests_after_fix=run_tests_after_fix  # NEW: Pass to service
        )
        
        return {
            "success": True,
            "results": results,
            "repo_name": repo_name,
            "repo_path": final_repo_path
        }
        
    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid JSON format: {str(e)}"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing batch fixes: {str(e)}"
        )


@app.post("/api/fixes/merge-pr")
async def merge_pr_with_conflict_resolution(
    repo_owner: str = Form(...),
    repo_name: str = Form(...),
    pr_number: int = Form(...),
    repo_path: str = Form(...),
    branch_name: str = Form(...),
    token: str = Form(...),
    base_branch: str = Form("main"),
    conflict_resolution_strategy: str = Form("ours"),
    merge_strategy: str = Form("merge"),
    commit_message: Optional[str] = Form(None)
):
    """
    Merge a PR with automatic conflict resolution.
    
    Args:
        repo_owner: Repository owner
        repo_name: Repository name
        pr_number: PR number to merge
        repo_path: Path to local repository
        branch_name: Branch name of the PR
        token: GitHub token
        base_branch: Base branch (default: "main")
        conflict_resolution_strategy: "ours", "theirs", or "both" (default: "ours")
        merge_strategy: "merge" or "rebase" for updating branch (default: "merge")
        commit_message: Optional commit message for merge
        
    Returns:
        Dictionary with merge result
    """
    try:
        # Validate repository path
        repo_path_obj = Path(repo_path)
        if not repo_path_obj.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Repository path does not exist: {repo_path}"
            )
        
        # Initialize PR Manager
        pr_manager = PRManagerService(token)
        
        # Merge PR with conflict resolution
        result = await pr_manager.merge_pr_with_conflict_resolution(
            owner=repo_owner,
            repo=repo_name,
            pr_number=pr_number,
            repo_path=str(repo_path_obj),
            branch_name=branch_name,
            base_branch=base_branch,
            conflict_resolution_strategy=conflict_resolution_strategy,
            merge_strategy=merge_strategy,
            commit_message=commit_message
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error merging PR: {str(e)}"
        )


@app.post("/api/fixes/check-pr-mergeability")
async def check_pr_mergeability(
    repo_owner: str = Form(...),
    repo_name: str = Form(...),
    pr_number: int = Form(...),
    token: str = Form(...)
):
    """
    Check if a PR can be merged and detect conflicts.
    
    Args:
        repo_owner: Repository owner
        repo_name: Repository name
        pr_number: PR number
        token: GitHub token
        
    Returns:
        Dictionary with mergeability status
    """
    try:
        pr_manager = PRManagerService(token)
        result = await pr_manager.check_pr_mergeability(repo_owner, repo_name, pr_number)
        return result
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error checking PR mergeability: {str(e)}"
        )


@app.post("/api/fixes/create-single-batch-pr")
async def create_single_batch_pr(
    successful_fixes_json: str = Form(...),
    repo_owner: str = Form(...),
    repo_name: str = Form(...),
    repo_path: str = Form(...),
    token: str = Form(...),
    base_branch: str = Form("main"),
    test_results_json: Optional[str] = Form(None)
):
    """
    Create a SINGLE Pull Request that contains all successful fixes.
    
    Args:
        successful_fixes_json: JSON string list of successful fix results
        repo_owner: Repository owner
        repo_name: Repository name
        repo_path: Path to repository
        token: GitHub token
        base_branch: Base branch for PRs
        test_results_json: Optional JSON string of Atlas test results
        
    Returns:
        Dictionary with single batch PR creation result:
        {
            'success': bool,
            'pr_number': int,
            'pr_url': str,
            'message': str
        }
    """
    try:
        # Parse successful fixes
        successful_fixes = json.loads(successful_fixes_json)
        
        if not isinstance(successful_fixes, list):
            raise HTTPException(
                status_code=400,
                detail="successful_fixes_json must be a JSON array"
            )
        
        # Parse test results if provided
        test_results = None
        if test_results_json:
            try:
                test_results = json.loads(test_results_json)
            except json.JSONDecodeError:
                logger.warning("[BatchPR] Failed to parse test_results_json, ignoring")
        
        # Validate repository path
        repo_path_obj = Path(repo_path)
        if not repo_path_obj.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Repository path does not exist: {repo_path}"
            )
        
        # Initialize batch PR service
        batch_pr_service = BatchPRService(token)
        
        # Create single batch PR
        result = await batch_pr_service.create_single_batch_pr(
            successful_fixes=successful_fixes,
            repo_owner=repo_owner,
            repo_name=repo_name,
            repo_path=str(repo_path_obj),
            base_branch=base_branch,
            test_results=test_results
        )
        
        return result
        
    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid JSON format: {str(e)}"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error creating single batch PR: {str(e)}"
        )


@app.post("/api/fixes/batch-create-prs")
async def batch_create_prs(
    successful_fixes_json: str = Form(...),
    repo_owner: str = Form(...),
    repo_name: str = Form(...),
    repo_path: str = Form(...),
    token: str = Form(...),
    base_branch: str = Form("main")
):
    """
    Create multiple Pull Requests for batch fixes.
    
    Args:
        successful_fixes_json: JSON string list of successful fix results
        repo_owner: Repository owner
        repo_name: Repository name
        repo_path: Path to repository
        token: GitHub token
        base_branch: Base branch for PRs
        
    Returns:
        Dictionary with batch PR creation results
    """
    try:
        # Parse successful fixes
        successful_fixes = json.loads(successful_fixes_json)
        
        if not isinstance(successful_fixes, list):
            raise HTTPException(
                status_code=400,
                detail="successful_fixes_json must be a JSON array"
            )
        
        # Validate repository path
        repo_path_obj = Path(repo_path)
        if not repo_path_obj.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Repository path does not exist: {repo_path}"
            )
        
        # Initialize batch PR service
        batch_pr_service = BatchPRService(token)
        
        # Create batch PRs
        results = await batch_pr_service.create_batch_prs(
            successful_fixes=successful_fixes,
            repo_owner=repo_owner,
            repo_name=repo_name,
            repo_path=str(repo_path_obj),
            base_branch=base_branch
        )
        
        return results
        
    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid JSON format: {str(e)}"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error creating batch PRs: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

