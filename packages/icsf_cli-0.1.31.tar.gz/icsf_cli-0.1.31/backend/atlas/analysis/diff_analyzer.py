from __future__ import annotations

import os
import logging
from git import Repo
from atlas.llm.bedrock import BedrockClient

logger = logging.getLogger(__name__)

class DiffAnalyzer:
    """
    Analyzes git diffs using an LLM to determine if changes are trivial or functional.
    """
    def __init__(self, llm: BedrockClient):
        self.llm = llm

    def get_diff(self, repo_path: str, baseline_commit: str) -> str:
        """
        Get the unified diff between baseline_commit and current working tree.
        Includes staged, unstaged, and untracked files.
        """
        try:
            repo = Repo(repo_path)
            # git diff <commit> includes staged + unstaged changes
            diff_text = repo.git.diff(baseline_commit, unified=3)
            
            # Include untracked files
            untracked_files = repo.untracked_files
            for f in untracked_files:
                if f.endswith('.java'): # Focus on Java files for Atlas
                    file_path = os.path.join(repo_path, f)
                    if os.path.exists(file_path):
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as fp:
                            content = fp.read()
                            diff_text += f"\n--- /dev/null\n+++ {f}\n@@ -0,0 +1,{len(content.splitlines())} @@\n"
                            for line in content.splitlines():
                                diff_text += f"+{line}\n"
            
            return diff_text
        except Exception as e:
            logger.error(f"Failed to get diff against {baseline_commit}: {e}")
            return ""

    def get_working_tree_hash(self, repo_path: str, baseline_commit: str) -> str:
        """
        Generate a hash of the current working tree changes relative to baseline.
        Used for idempotency checks.
        """
        import hashlib
        diff_text = self.get_diff(repo_path, baseline_commit)
        return hashlib.sha256(diff_text.encode('utf-8')).hexdigest()

    def analyze_functional_change(self, diff_text: str) -> dict:
        """
        Ask the LLM to classify the change.
        Returns a dict: {"classification": "TRIVIAL" | "FUNCTIONAL", "reason": str}
        """
        if not diff_text.strip():
            return {"classification": "TRIVIAL", "reason": "No changes detected."}

        # Truncate diff if it's too large for the context
        if len(diff_text) > 20000:
            diff_text = diff_text[:20000] + "\n... (diff truncated)"

        system_prompt = """You are an expert Java developer and QA engineer. 
Your task is to analyze a Git diff and determine if the changes involve meaningful functional logic updates or if they are purely trivial/aesthetic.

Classify the diff as:
- TRIVIAL: If the changes only involve whitespace, formatting (e.g. adding/removing brackets, commas), comments, documentation (Javadoc), or renaming variables without changing logic.
- FUNCTIONAL: If the changes involve adding new methods, changing conditional logic, updating business rules, changing algorithms, or modifying public APIs.

Respond ONLY with a JSON object in this format:
{
  "classification": "TRIVIAL" or "FUNCTIONAL",
  "reason": "a brief explanation of your decision"
}"""

        user_prompt = f"Analyze this git diff:\n\n```diff\n{diff_text}\n```"

        try:
            response = self.llm.generate_text(system=system_prompt, user=user_prompt)
            # Find JSON in response
            import json
            import re
            
            # Extract JSON block
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group(0))
                if result.get("classification") in ["TRIVIAL", "FUNCTIONAL"]:
                    return result

            # Fallback if parsing fails
            logger.warning(f"Failed to parse LLM response for diff analysis: {response}")
            return {"classification": "FUNCTIONAL", "reason": "Failed to parse analysis, defaulting to functional for safety."}
            
        except Exception as e:
            logger.error(f"Error during LLM diff analysis: {e}")
            return {"classification": "FUNCTIONAL", "reason": f"Error during analysis: {str(e)}"}

    def get_modified_java_files(self, repo_path: str, baseline_commit: str) -> list[str]:
        """
        Extract the list of modified or added Java files relative to baseline.
        """
        try:
            repo = Repo(repo_path)
            # Files modified or added (including staged/unstaged)
            diff = repo.git.diff(baseline_commit, name_only=True)
            files = diff.splitlines()
            
            # Add untracked files
            files.extend(repo.untracked_files)
            
            # Filter for Java files and ensure they are in src/main/java
            java_files = []
            for f in set(files): # unique
                if f.endswith(".java") and "src/main/java" in f and not f.endswith("Test.java"):
                    java_files.append(os.path.join(repo_path, f))
            return java_files
        except Exception as e:
            logger.error(f"Error extracting modified Java files: {e}")
            return []
