from __future__ import annotations

import os
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class RepoFacts:
    languages: list[str]
    build_system: str | None
    frameworks: list[str]
    test_frameworks: list[str]
    maven_poms: list[str]
    module_graph: dict[str, list[str]] = None
    main_class: str | None = None


def discover_module_graph(project_root: str) -> dict[str, list[str]]:
    """Builds a dependency graph of Maven modules within the repository."""
    import xml.etree.ElementTree as ET
    
    pom_files = []
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", ".gradle", "node_modules"}]
        if "pom.xml" in files:
            pom_files.append(os.path.join(root, "pom.xml"))
            
    # Step 1: Map artifactId to module path
    artifactId_to_module = {}
    pom_data = {} # path -> {artifactId, dependencies}
    
    ns = {"m": "http://maven.apache.org/POM/4.0.0"}
    
    for pom_path in pom_files:
        try:
            tree = ET.parse(pom_path)
            root = tree.getroot()
            
            # Helper to find tag with or without namespace
            def find_tag(element, tag_name):
                t = element.find(f"m:{tag_name}", ns)
                if t is None:
                    t = element.find(tag_name)
                return t

            artifactId_node = find_tag(root, "artifactId")
            if artifactId_node is not None:
                artifactId = artifactId_node.text.strip()
                artifactId_to_module[artifactId] = pom_path
                
                # Find direct dependencies
                dependencies = []
                deps_node = find_tag(root, "dependencies")
                if deps_node is not None:
                    for dep in deps_node.findall("m:dependency", ns) or deps_node.findall("dependency"):
                        dep_artifactId_node = find_tag(dep, "artifactId")
                        if dep_artifactId_node is not None:
                            dependencies.append(dep_artifactId_node.text.strip())
                
                pom_data[pom_path] = {
                    "artifactId": artifactId,
                    "dependencies": dependencies
                }
        except Exception:
            continue
            
    # Step 2: Build the graph filtering for local dependencies
    graph = {}
    local_artifactIds = set(artifactId_to_module.keys())
    
    for path, data in pom_data.items():
        aid = data["artifactId"]
        deps = [d for d in data["dependencies"] if d in local_artifactIds and d != aid]
        graph[aid] = sorted(list(set(deps)))
        
    return _topological_sort_with_cycles(graph)


def _topological_sort_with_cycles(graph: dict[str, list[str]]) -> dict[str, list[str]]:
    """
    Attempts topological sort. Returns original graph if cycles found, 
    but ensures we have a stable order for processing.
    """
    ordered = {}
    visited = set()
    temp_visited = set()

    def visit(node):
        if node in temp_visited:
            return  # Cycle detected; skip to keep it stable
        if node not in visited:
            temp_visited.add(node)
            for neighbor in graph.get(node, []):
                visit(neighbor)
            temp_visited.remove(node)
            visited.add(node)
            # We record the order in a way that respects dependencies
            ordered[node] = graph.get(node, [])

    for node in sorted(graph.keys()):
        visit(node)
        
    return ordered


def detect_repo_facts(repo_path: str) -> RepoFacts:
    maven_poms: list[str] = []
    languages: set[str] = set()
    frameworks: set[str] = set()
    test_frameworks: set[str] = set()
    build_system: str | None = None
    import logging
    logger = logging.getLogger(__name__)
    logger.info(f"[Analysis] Detecting repo facts for {repo_path}")

    for root, dirs, files in os.walk(repo_path):
        # Skip huge dirs
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", ".gradle", "node_modules"}]

        if "pom.xml" in files:
            pom_path = os.path.join(root, "pom.xml")
            logger.info(f"[Analysis] Found pom.xml at {pom_path}")
            maven_poms.append(pom_path)
            build_system = build_system or "maven"

        for f in files:
            if f.endswith(".java"):
                languages.add("java")
            elif f.endswith((".py",)):
                languages.add("python")
            elif f.endswith((".js", ".ts")):
                languages.add("javascript/typescript")

    # Heuristics by scanning pom.xml files
    for pom in maven_poms[:20]:
        try:
            text = open(pom, "r", encoding="utf-8", errors="ignore").read()
        except OSError:
            continue

        if re.search(r"<artifactId>\s*spring-boot", text):
            frameworks.add("spring-boot")
        if re.search(r"<artifactId>\s*junit-jupiter", text) or re.search(r"org\.junit\.jupiter", text):
            test_frameworks.add("junit5")
        if re.search(r"<artifactId>\s*junit</artifactId>", text) or "org.junit" in text:
            test_frameworks.add("junit4")
        if "org.testng" in text or re.search(r"<artifactId>\s*testng", text):
            test_frameworks.add("testng")
        if "mockito" in text:
            frameworks.add("mockito")
        if "jacoco-maven-plugin" in text:
            frameworks.add("jacoco")
        if "spring-boot-starter-web" in text or "spring-boot-starter-thymeleaf" in text:
            frameworks.add("spring-boot")

    main_class = find_main_application_class(repo_path)
    module_graph = discover_module_graph(repo_path)

    return RepoFacts(
        languages=sorted(languages) or ["unknown"],
        build_system=build_system,
        frameworks=sorted(frameworks),
        test_frameworks=sorted(test_frameworks),
        maven_poms=sorted(maven_poms),
        module_graph=module_graph,
        main_class=main_class,
    )


def find_main_application_class(project_root: str) -> str | None:
    """Search for the @SpringBootApplication class to use as a test context."""
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", ".gradle", "node_modules"}]
        if os.path.join("src", "main", "java") not in root:
            continue
        for f in files:
            if f.endswith(".java"):
                path = os.path.join(root, f)
                try:
                    text = open(path, "r", encoding="utf-8", errors="ignore").read()
                    if "@SpringBootApplication" in text:
                        pkg = _extract_package(text)
                        cls = _extract_public_class(text) or os.path.splitext(f)[0]
                        return f"{pkg}.{cls}" if pkg else cls
                except Exception:
                    continue
    return None


def find_test_roots(project_root: str) -> list[str]:
    roots: list[str] = []
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", ".gradle", "node_modules"}]
        # Maven standard
        if root.endswith(os.path.join("src", "test", "java")):
            roots.append(root)
    return sorted(set(roots))


def count_existing_tests(project_root: str) -> int:
    n = 0
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", ".gradle", "node_modules"}]
        for f in files:
            if f.endswith(".java") and ("Test" in f or f.endswith("Tests.java")):
                if os.path.join("src", "test", "java") in root:
                    n += 1
    return n


@dataclass(frozen=True)
class RestEndpoint:
    method: str  # GET, POST, etc.
    path: str
    annotation: str  # GetMapping, PostMapping, etc.


@dataclass(frozen=True)
class RestControllerInfo:
    package: str
    class_name: str
    base_path: str  # from @RequestMapping on class
    endpoints: list[RestEndpoint]
    file_path: str


def find_rest_controllers(project_root: str) -> list[RestControllerInfo]:
    """Find Spring REST controllers and their endpoints (for API/integration test generation)."""
    results: list[RestControllerInfo] = []
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", ".gradle", "node_modules"}]
        if os.path.join("src", "main", "java") not in root:
            continue
        for f in files:
            if not f.endswith(".java"):
                continue
            path = os.path.join(root, f)
            try:
                text = open(path, "r", encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            if "@RestController" not in text and "@Controller" not in text:
                continue
            if "RequestMapping" not in text and "GetMapping" not in text and "PostMapping" not in text:
                continue
            pkg = _extract_package(text)
            class_name = _extract_public_class(text) or os.path.splitext(f)[0]
            base = _extract_class_request_mapping(text)
            endpoints: list[RestEndpoint] = []
            for ann, method in [("GetMapping", "GET"), ("PostMapping", "POST"), ("PutMapping", "PUT"), ("DeleteMapping", "DELETE"), ("PatchMapping", "PATCH")]:
                for m in re.finditer(rf"@(?:{ann})\s*\(\s*[^)]*value\s*=\s*[\"']([^\"']+)[\"']", text):
                    endpoints.append(RestEndpoint(method=method, path=m.group(1), annotation=ann))
                for m in re.finditer(rf"@(?:{ann})\s*\(\s*[\"']([^\"']+)[\"']", text):
                    endpoints.append(RestEndpoint(method=method, path=m.group(1), annotation=ann))
                if re.search(rf"@(?:{ann})\s*[(\s]", text) and not any(e.annotation == ann for e in endpoints):
                    endpoints.append(RestEndpoint(method=method, path="", annotation=ann))
            if not endpoints:
                for m in re.finditer(r'@RequestMapping\s*\([^)]*value\s*=\s*["\']([^"\']+)["\']', text):
                    base = m.group(1)
                    break
                endpoints.append(RestEndpoint(method="GET", path=base or "/", annotation="RequestMapping"))
            results.append(RestControllerInfo(package=pkg, class_name=class_name, base_path=base, endpoints=endpoints, file_path=os.path.join(root, f)))
    return results


def find_domain_models(project_root: str) -> list[str]:
    """Find all potential domain model/DTO classes for better test import context."""
    models: list[str] = []
    # Packages often named domain, model, dto, entity, vo
    target_pkgs = {"domain", "model", "dto", "entity", "vo"}
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", ".gradle", "node_modules"}]
        if os.path.join("src", "main", "java") not in root:
            continue
        
        path_segments = root.replace("\\", "/").split("/")
        if not any(pkg in path_segments for pkg in target_pkgs):
            continue
            
        for f in files:
            if f.endswith(".java") and not f.endswith("Test.java"):
                try:
                    text = open(os.path.join(root, f), "r", encoding="utf-8", errors="ignore").read()
                    pkg = _extract_package(text)
                    cls = _extract_public_class(text) or os.path.splitext(f)[0]
                    if pkg and cls:
                        models.append(f"{pkg}.{cls}")
                except Exception:
                    continue
        if len(models) >= 100:
            break
    return sorted(list(set(models)))


def _extract_package(text: str) -> str:
    m = re.search(r"^\s*package\s+([a-zA-Z0-9_.]+)\s*;\s*$", text, re.MULTILINE)
    return m.group(1) if m else ""


def _extract_public_class(text: str) -> str | None:
    m = re.search(r"\bpublic\s+class\s+([A-Za-z0-9_]+)\b", text)
    return m.group(1) if m else None


def _extract_class_request_mapping(text: str) -> str:
    m = re.search(r"@RequestMapping\s*\([^)]*value\s*=\s*[\"']([^\"']+)[\"']", text)
    return m.group(1) if m else ""


@dataclass(frozen=True)
class ControllerEndpointMethod:
    """Production-level: one controller method with its request/response types for accurate test generation."""
    java_method_name: str
    http_method: str
    path: str
    request_body_type: str | None  # fully qualified or simple name
    return_type: str | None  # ResponseEntity<AccountResponse> or AccountResponse


def get_controller_endpoint_methods(controller_source: str) -> list[ControllerEndpointMethod]:
    """Parse controller source to get each endpoint method name, HTTP method, path, @RequestBody type, and return type. Production-level context for API tests."""
    results: list[ControllerEndpointMethod] = []
    # Find blocks: optional @GetMapping/@PostMapping etc. (with optional value), then public method line
    # Pattern: @GetMapping(...) or @PostMapping("...") then newlines then public ReturnType methodName(...)
    method_ann_re = re.compile(
        r"@(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping)\s*\(\s*(?:value\s*=\s*)?[\"']([^\"']*)[\"']\s*\)"
    )
    # Also match @RequestBody ParamType paramName
    request_body_re = re.compile(r"@RequestBody\s+(\w+(?:\.\w+)*)\s+\w+")
    lines = controller_source.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        for ann, method in [
            ("GetMapping", "GET"), ("PostMapping", "POST"), ("PutMapping", "PUT"),
            ("DeleteMapping", "DELETE"), ("PatchMapping", "PATCH"),
        ]:
            if f"@{ann}" in line:
                path = ""
                m = method_ann_re.search(line)
                if m:
                    path = (m.group(2) or "").strip()
                # Look ahead for public method (next non-empty, non-annotation line that contains "public")
                j = i + 1
                while j < len(lines) and j < i + 15:
                    next_line = lines[j]
                    if next_line.strip().startswith("@"):
                        j += 1
                        continue
                    # public ReturnType methodName( ... )
                    pub = re.search(r"public\s+(\S+)\s+(\w+)\s*\(", next_line)
                    if pub:
                        return_type = pub.group(1)
                        java_method_name = pub.group(2)
                        request_body_type = None
                        # Check this and previous lines for @RequestBody
                        for k in range(max(0, j - 3), j + 1):
                            if k < len(lines):
                                rb = request_body_re.search(lines[k])
                                if rb:
                                    request_body_type = rb.group(1)
                                    break
                        results.append(ControllerEndpointMethod(
                            java_method_name=java_method_name,
                            http_method=method,
                            path=path,
                            request_body_type=request_body_type,
                            return_type=return_type,
                        ))
                        break
                    if next_line.strip() and not next_line.strip().startswith("//"):
                        break
                    j += 1
                break
        i += 1
    return results


def get_dto_snippet(project_root: str, fully_qualified_class: str) -> str:
    """Return a short snippet for a DTO/request/response class: package, class name, and setter/field signatures so tests can be generated with correct API."""
    rel_path = fully_qualified_class.replace(".", os.sep) + ".java"
    candidate = os.path.join(project_root, "src", "main", "java", rel_path)
    if os.path.isfile(candidate):
        try:
            text = open(candidate, "r", encoding="utf-8", errors="ignore").read()
        except OSError:
            return ""
    else:
        # Search by class name (multi-module: class may be in any module)
        base_name = fully_qualified_class.split(".")[-1] + ".java"
        for root, dirs, files in os.walk(project_root):
            dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea"}]
            if os.path.join("src", "main", "java") not in root:
                continue
            if base_name in files:
                candidate = os.path.join(root, base_name)
                try:
                    text = open(candidate, "r", encoding="utf-8", errors="ignore").read()
                except OSError:
                    continue
                break
        else:
            return ""
    pkg = _extract_package(text)
    cls = _extract_public_class(text) or fully_qualified_class.split(".")[-1]
    setters = re.findall(r"public\s+void\s+(set\w+)\s*\(\s*([^)]+)\s*\)", text)
    fields = re.findall(r"private\s+(\S+)\s+(\w+)\s*;", text)
    parts = [f"package {pkg}; class {cls};"]
    for name, arg in setters:
        parts.append(f"  {name}({arg});")
    for typ, name in fields:
        parts.append(f"  {typ} {name};")
    return "\n".join(parts[:25])


def get_dto_snippets_for_request_response_types(project_root: str, type_names: list[str]) -> dict[str, str]:
    """Resolve type names (simple or FQN) to DTO snippets. Used to give API test generator exact request/response API."""
    simple_to_fqn: dict[str, str] = {}
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea"}]
        if os.path.join("src", "main", "java") not in root:
            continue
        for f in files:
            if not f.endswith(".java"):
                continue
            path = os.path.join(root, f)
            try:
                text = open(path, "r", encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            pkg = _extract_package(text)
            cls = _extract_public_class(text) or os.path.splitext(f)[0]
            if pkg and cls:
                simple_to_fqn[cls] = f"{pkg}.{cls}"
        if len(simple_to_fqn) > 200:
            break
    result: dict[str, str] = {}
    for name in type_names:
        if not name or name in ("void", "String", "Long", "Integer", "List", "Map"):
            continue
        fqn = name if "." in name else simple_to_fqn.get(name)
        if not fqn:
            for v in simple_to_fqn.values():
                if v.endswith("." + name):
                    fqn = v
                    break
        if fqn:
            snip = get_dto_snippet(project_root, fqn)
            if snip:
                result[name] = snip
    return result
