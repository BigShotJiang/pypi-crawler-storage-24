"""
Contract Extraction Service for Atlas.

Parses Java source to extract class contracts (constructors, fields, Lombok annotations,
builder patterns) so the test generator can use real signatures instead of hallucinating.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class ClassContract:
    """Structural contract of a Java class — what the LLM must respect when generating tests."""
    fqn: str                                     # e.g. com.banking.dto.TransactionRequest
    class_name: str                               # e.g. TransactionRequest
    constructors: list[list[str]] = field(default_factory=list)  # [[],["String","BigDecimal"]]
    fields: list[tuple[str, str]] = field(default_factory=list)  # [("accountId","String"),...]
    setters: list[tuple[str, str]] = field(default_factory=list) # [("setAccountId","String"),...]
    has_builder: bool = False                     # @Builder or @SuperBuilder
    has_all_args_constructor: bool = False         # @AllArgsConstructor
    has_no_arg_constructor: bool = False           # @NoArgsConstructor or explicit empty ctor
    has_setters: bool = False                     # has setter methods
    is_record: bool = False                       # Java record
    is_jpa_entity: bool = False                   # @Entity
    validation_constraints: dict[str, str] = field(default_factory=dict) # {fieldName: "@NotNull @Size(min=1)"}
    instantiation_strategy: str = "UNKNOWN"       # NO_ARG_WITH_SETTERS | ALL_ARGS | BUILDER | RECORD


def extract_class_contract(java_source: str) -> ClassContract | None:
    """Parse a single Java source file and extract its structural contract."""
    pkg = _extract_package(java_source)
    class_name = _extract_public_class(java_source)
    if not class_name:
        return None

    fqn = f"{pkg}.{class_name}" if pkg else class_name

    # Detect Lombok annotations (check class-level annotations)
    has_builder = bool(re.search(r"@(?:Super)?Builder\b", java_source))
    has_all_args = bool(re.search(r"@AllArgsConstructor\b", java_source))
    has_no_arg_lombok = bool(re.search(r"@NoArgsConstructor\b", java_source))
    has_data = bool(re.search(r"@Data\b", java_source))
    has_getter_setter = bool(re.search(r"@(?:Getter|Setter)\b", java_source))

    # Java record/entity detection
    is_record = bool(re.search(rf"\bpublic\s+record\s+{re.escape(class_name)}\b", java_source))
    is_jpa_entity = bool(re.search(r"@Entity\b", java_source))

    # Extract explicit constructors
    constructors = _extract_constructors(java_source, class_name)

    # For records: extract fields from the record header component list
    # (record components are NOT declared as private fields)
    record_fields = _extract_record_components(java_source, class_name) if is_record else []

    # Determine if there's an explicit no-arg constructor
    has_explicit_no_arg = any(len(params) == 0 for params in constructors)

    # Extract fields (private/protected for regular classes; record components for records)
    fields = record_fields if is_record else _extract_fields(java_source)

    # Synthesise the canonical record constructor from its components so
    # validate_constructor_usage and format_contracts_for_prompt can use it.
    if is_record and record_fields and not constructors:
        canonical_params = [t for _name, t in record_fields]
        constructors = [canonical_params]

    # Extract setter methods
    setters = _extract_setters(java_source)
    has_setters_detected = len(setters) > 0 or has_data or has_getter_setter

    # Determine no-arg availability
    # Java provides default no-arg if NO explicit constructors exist
    has_no_arg = has_no_arg_lombok or has_explicit_no_arg or (len(constructors) == 0)

    # Determine instantiation strategy
    strategy = _determine_strategy(
        has_builder=has_builder,
        has_all_args=has_all_args,
        has_no_arg=has_no_arg,
        has_setters=has_setters_detected,
        is_record=is_record,
        constructors=constructors,
    )

    return ClassContract(
        fqn=fqn,
        class_name=class_name,
        constructors=constructors,
        fields=fields,
        setters=setters,
        has_builder=has_builder,
        has_all_args_constructor=has_all_args,
        has_no_arg_constructor=has_no_arg,
        has_setters=has_setters_detected,
        is_record=is_record,
        is_jpa_entity=is_jpa_entity,
        validation_constraints=_extract_validation_constraints(java_source),
        instantiation_strategy=strategy,
    )


class RepoContractRegistry:
    """Pre-indexes every Java class in a repo to enable fast cross-module contract resolution."""
    def __init__(self, repo_path: str):
        self.repo_path = repo_path
        self.fqn_to_path: dict[str, str] = {}
        self.simple_to_fqns: dict[str, list[str]] = {}
        self._index()

    def _index(self):
        """Walk the repo once and map ClassName and FQN to file paths."""
        for root, dirs, files in os.walk(self.repo_path):
            dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", "node_modules"}]
            for f in files:
                if f.endswith(".java"):
                    path = os.path.join(root, f)
                    try:
                        # Fast-only: read just the first 100 lines for package
                        with open(path, "r", encoding="utf-8", errors="ignore") as file:
                            content_head = "".join([file.readline() for _ in range(100)])
                        pkg = _extract_package(content_head)
                        class_name = os.path.splitext(f)[0]
                        fqn = f"{pkg}.{class_name}" if pkg else class_name
                        
                        self.fqn_to_path[fqn] = path
                        if class_name not in self.simple_to_fqns:
                            self.simple_to_fqns[class_name] = []
                        self.simple_to_fqns[class_name].append(fqn)
                    except Exception:
                        continue

    def invalidate(self):
        """Force re-indexing of the repository."""
        self.fqn_to_path.clear()
        self.simple_to_fqns.clear()
        self._index()

    def get_source(self, fqn: str) -> str | None:
        path = self.fqn_to_path.get(fqn)
        if path and os.path.isfile(path):
            try:
                return open(path, "r", encoding="utf-8", errors="ignore").read()
            except OSError:
                return None
        return None

    def resolve_simple_name(self, simple_name: str, pkg_context: str | None = None) -> str | None:
        """Try to resolve a simple class name to an FQN using repo index."""
        fqns = self.simple_to_fqns.get(simple_name, [])
        if not fqns:
            return None
        if len(fqns) == 1:
            return fqns[0]
        if pkg_context:
            # Prefer the one in the same package
            for f in fqns:
                if f.startswith(pkg_context + "."):
                    return f
        return fqns[0] # Default to first found


def extract_referenced_contracts(source_code: str, repo_path: str, registry: RepoContractRegistry | None = None) -> dict[str, ClassContract]:
    """
    Find all types referenced in ``source_code`` (the class under test),
    resolve them in the repo, and extract their contracts.
    Returns {ClassName: ClassContract, ...}
    """
    if registry is None:
        registry = RepoContractRegistry(repo_path)

    # Extract import statements
    imports = re.findall(r"^\s*import\s+([\w.]+)\s*;", source_code, re.MULTILINE)
    
    # Extract package of current class
    current_pkg = _extract_package(source_code)

    # Simple name -> FQN map from imports
    import_map = {fqn.split(".")[-1]: fqn for fqn in imports}

    # Extract type names used in the code (new calls, types in fields/vars)
    # This regex is a heuristic for capitalized type names
    type_names = set(re.findall(r"\b([A-Z][A-Za-z0-9_]+)\b", source_code))
    
    # Filter out common Java keywords/types
    ignored = {"String", "Integer", "Long", "Double", "Float", "Boolean", "Byte", "Short", "Character",
               "List", "Map", "Set", "Optional", "Object", "BigDecimal", "Void", "Class", "Exception", 
               "Test", "Override", "SuppressWarnings", "ArrayList", "HashMap", "HashSet", "Iterable", "Collection"}
    type_names = {n for n in type_names if n not in ignored}

    contracts: dict[str, ClassContract] = {}

    for name in type_names:
        # 1. Check imports
        fqn = import_map.get(name)
        
        # 2. Check same package or repo-wide registry
        if not fqn:
            fqn = registry.resolve_simple_name(name, current_pkg)
            
        if fqn:
            # Skip standard libs even if they slipped through
            if fqn.startswith(("java.", "javax.", "jakarta.", "org.junit", "org.mockito", "org.springframework.test")):
                continue
                
            source = registry.get_source(fqn)
            if source:
                contract = extract_class_contract(source)
                if contract:
                    contracts[name] = contract

    return contracts

def validate_constructor_usage(test_code: str, registry: dict[str, ClassContract]) -> list[str]:
    """
    Deterministically validates that all 'new' calls in the generated test_code
    match the constructor signatures in the registry.
    Returns a list of violation messages.
    """
    violations = []
    if registry is None:
        return violations
    # Heuristic regex for 'new ClassName(...)'
    # We look for Capitalized names after 'new'
    matches = re.finditer(r"new\s+([A-Z][A-Za-z0-9_]*)\s*\(([\s\S]*?)\)", test_code)
    
    for m in matches:
        cls_name = m.group(1)
        args_content = m.group(2).strip()
        
        if cls_name in registry:
            contract = registry[cls_name]
            
            # Simple validation by argument count
            # To be more accurate, we need to split by commas not inside nested parens/quotes
            actual_count = 0
            if args_content:
                actual_count = _count_top_level_commas(args_content) + 1
            
            allowed_counts = [len(c) for c in contract.constructors]
            
            # Java provides a default no-arg constructor when no explicit constructors exist.
            # Also respect Lombok @NoArgsConstructor and explicit empty constructors.
            if contract.has_no_arg_constructor and 0 not in allowed_counts:
                allowed_counts.append(0)
            
            # If no constructors were found at all, skip validation for this class
            # because we can't reliably determine valid signatures.
            if not allowed_counts:
                continue
            
            if actual_count not in allowed_counts:
                # Build detailed signature strings for the LLM
                sig_details = []
                for ctor_params in contract.constructors:
                    sig_details.append(f"{cls_name}({', '.join(ctor_params)})")
                if contract.has_no_arg_constructor and not any(len(c) == 0 for c in contract.constructors):
                    sig_details.append(f"{cls_name}()")
                sig_str = "; ".join(sig_details) if sig_details else str(allowed_counts)
                violations.append(f"Constructor Hallucination: {cls_name} called with {actual_count} args, but valid constructors are: {sig_str}")
                
    return violations


def _count_top_level_commas(s: str) -> int:
    """Counts commas at depth 0 (ignoring those inside nested parentheses)."""
    count = 0
    depth = 0
    in_quote = False
    quote_char = ""
    
    i = 0
    while i < len(s):
        char = s[i]
        if not in_quote:
            if char in ("'", '"'):
                in_quote = True
                quote_char = char
            elif char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char == "," and depth == 0:
                count += 1
        else:
            if char == quote_char and (i == 0 or s[i-1] != "\\"):
                in_quote = False
        i += 1
    return count


def format_contracts_for_prompt(contracts: dict[str, ClassContract]) -> str:
    """Format extracted contracts as LLM-friendly text for prompt injection."""
    if not contracts:
        return ""

    parts = ["CLASS CONTRACTS — use ONLY these constructors and fields:"]
    for name, c in contracts.items():
        lines = [f"\n### {c.fqn}"]

        # Constructors
        if c.is_record:
            record_params = ", ".join(f"{t} {n}" for n, t in c.fields)
            lines.append(f"  Record constructor: {c.class_name}({record_params})")
        elif c.constructors:
            for params in c.constructors:
                if params:
                    lines.append(f"  Constructor: {c.class_name}({', '.join(params)})")
                else:
                    lines.append(f"  Constructor: {c.class_name}()  // no-arg")
        elif c.has_no_arg_constructor:
            lines.append(f"  Constructor: {c.class_name}()  // no-arg only")
        if c.has_all_args_constructor:
            all_params = ", ".join(f"{t} {n}" for n, t in c.fields)
            lines.append(f"  @AllArgsConstructor: {c.class_name}({all_params})")

        # Fields
        if c.fields:
            field_strs = []
            for n, t in c.fields[:20]:
                constraint = c.validation_constraints.get(n, "")
                field_strs.append(f"{t} {n} {constraint}".strip())
            lines.append(f"  Fields: {', '.join(field_strs)}")

        if c.is_jpa_entity:
            lines.append("  [WARNING] This is a JPA Entity. Avoid calling lazy-loaded getters in unit tests unless explicitly initialized.")

        # Setters
        if c.has_setters and c.setters:
            setter_strs = [f"{name}({t})" for name, t in c.setters[:10]]
            lines.append(f"  Setters: {', '.join(setter_strs)}")

        # Strategy
        lines.append(f"  → Instantiation: {c.instantiation_strategy}")

        parts.append("\n".join(lines))
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _extract_package(text: str) -> str:
    m = re.search(r"^\s*package\s+([\w.]+)\s*;", text, re.MULTILINE)
    return m.group(1) if m else ""


def _extract_public_class(text: str) -> str | None:
    m = re.search(r"\bpublic\s+(?:class|record|enum|interface)\s+([A-Za-z0-9_]+)", text)
    return m.group(1) if m else None


def _extract_constructors(source: str, class_name: str) -> list[list[str]]:
    """Extract explicit constructor parameter types."""
    constructors: list[list[str]] = []
    # Match: public ClassName( ... ) or ClassName( ... ) {
    pattern = rf"\b(?:public|protected|private)?\s*{re.escape(class_name)}\s*\(([^)]*)\)\s*(?:throws\s+\w+(?:\s*,\s*\w+)*)?\s*\{{"
    for m in re.finditer(pattern, source):
        params_str = m.group(1).strip()
        if not params_str:
            constructors.append([])
        else:
            params = []
            for p in params_str.split(","):
                p = p.strip()
                # Remove annotations like @NonNull
                p = re.sub(r"@\w+\s+", "", p).strip()
                parts = p.split()
                if len(parts) >= 2:
                    # Type is everything except last token (the name)
                    param_type = " ".join(parts[:-1])
                    # Simplify generics for readability
                    param_type = re.sub(r"<[^>]+>", "", param_type)
                    params.append(param_type.strip())
                elif len(parts) == 1:
                    params.append(parts[0])
            constructors.append(params)
    return constructors


def _extract_record_components(source: str, class_name: str) -> list[tuple[str, str]]:
    """Extract record component declarations from the record header.

    For  ``public record Foo(String a, int b, MyType c)``  this returns
    ``[("a", "String"), ("b", "int"), ("c", "MyType")]``.
    Handles nested parentheses and commas in annotations.
    """
    # Match: public record ClassName(
    header_start_m = re.search(rf"\brecord\s+{re.escape(class_name)}\s*\(", source)
    if not header_start_m:
        return []

    # Find the matching closing parenthesis for the record header
    start_idx = header_start_m.end()
    depth = 1
    end_idx = -1
    for i in range(start_idx, len(source)):
        if source[i] == '(':
            depth += 1
        elif source[i] == ')':
            depth -= 1
            if depth == 0:
                end_idx = i
                break

    if end_idx == -1:
        return []

    params_str = source[start_idx:end_idx].strip()
    if not params_str:
        return []

    components: list[tuple[str, str]] = []
    # Split by commas at the top level only (respecting nested parentheses in annotations)
    for param in _split_top_level_commas(params_str):
        param = param.strip()
        # Strip annotations like @NonNull, @Valid, @Size(min=1)
        # Handle balanced parentheses inside annotations
        param = _strip_annotations_robust(param)
        
        parts = param.split()
        if len(parts) >= 2:
            param_type = " ".join(parts[:-1])
            param_name = parts[-1]
            # Strip generics for readability in prompts
            param_type = re.sub(r"<[^>]+>", "", param_type).strip()
            components.append((param_name, param_type))
    return components


def _split_top_level_commas(s: str) -> list[str]:
    """Splits a string by commas, but only at depth 0 (ignoring nested parentheses)."""
    parts = []
    start = 0
    depth = 0
    in_quote = False
    quote_char = ""
    
    for i, char in enumerate(s):
        if not in_quote:
            if char in ("'", '"'):
                in_quote = True
                quote_char = char
            elif char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char == "," and depth == 0:
                parts.append(s[start:i])
                start = i + 1
        else:
            if char == quote_char and (i == 0 or s[i-1] != "\\"):
                in_quote = False
    
    parts.append(s[start:])
    return [p.strip() for p in parts if p.strip()]


def _strip_annotations_robust(s: str) -> str:
    """Removes annotations like @Size(min=1) or @NotBlank from a string."""
    # This is a bit complex as annotations can be chained and have parameters.
    # We'll use a simple state machine to remove everything starting with @ until the space after the annotation
    result = []
    i = 0
    while i < len(s):
        if s[i] == '@':
            # Skip until we hit a space that is NOT inside parentheses
            i += 1
            # Skip identifier
            while i < len(s) and (s[i].isalnum() or s[i] in '._'):
                i += 1
            # If there are parentheses, skip them
            if i < len(s) and s[i] == '(':
                depth = 1
                i += 1
                while i < len(s) and depth > 0:
                    if s[i] == '(': depth += 1
                    elif s[i] == ')': depth -= 1
                    i += 1
            # Skip any whitespace after the annotation
            while i < len(s) and s[i].isspace():
                i += 1
        else:
            result.append(s[i])
            i += 1
    return "".join(result).strip()


def _extract_fields(source: str) -> list[tuple[str, str]]:
    """Extract private/protected instance fields as (name, type) pairs."""
    fields: list[tuple[str, str]] = []
    for m in re.finditer(
        r"^\s+(?:private|protected)\s+([\w<>\[\]?,\s]+?)\s+(\w+)\s*[;=]",
        source, re.MULTILINE
    ):
        field_type = m.group(1).strip()
        field_name = m.group(2).strip()
        # Skip static fields
        if "static" in field_type:
            continue
        # Clean up type
        field_type = field_type.replace("final ", "").strip()
        fields.append((field_name, field_type))
    return fields


def _extract_validation_constraints(source: str) -> dict[str, str]:
    """Extract JSR-303/Jakarta Bean Validation annotations for each field."""
    constraints = {}
    # Captures annotations like @NotNull, @Size(min=1), @NotBlank etc. right before a field
    # Heuristic: Find all annotations on lines immediately preceding the field declaration
    field_blocks = re.finditer(r"((?:@\w+(?:\([^)]*\))?\s+)*)(?:private|protected|public)?\s+(?:final\s+)?([\w<>\[\]?]+)\s+(\w+)\s*[;=]", source)
    for m in field_blocks:
        annotations_text = m.group(1).strip()
        field_name = m.group(3)
        if annotations_text:
            # Filter specifically for validation annotations
            valid_parts = []
            for ann in re.findall(r"@\w+(?:\([^)]*\))?", annotations_text):
                if any(v in ann for v in ["NotNull", "NotBlank", "NotEmpty", "Size", "Min", "Max", "Email", "Pattern", "Range"]):
                    valid_parts.append(ann)
            if valid_parts:
                constraints[field_name] = " ".join(valid_parts)
    return constraints


def _extract_setters(source: str) -> list[tuple[str, str]]:
    """Extract setter methods as (methodName, paramType) pairs."""
    setters: list[tuple[str, str]] = []
    for m in re.finditer(
        r"\bpublic\s+void\s+(set\w+)\s*\(\s*(?:@\w+\s+)*([\w<>\[\]?]+)\s+\w+\s*\)",
        source
    ):
        setters.append((m.group(1), m.group(2)))
    return setters


def _find_java_source(repo_path: str, fqn: str) -> str | None:
    """Find and read the Java source file for a fully qualified class name."""
    rel_path = fqn.replace(".", os.sep) + ".java"

    # Try standard Maven locations
    for prefix in ("src/main/java", "src/test/java"):
        candidate = os.path.join(repo_path, prefix, rel_path)
        if os.path.isfile(candidate):
            try:
                return open(candidate, "r", encoding="utf-8", errors="ignore").read()
            except OSError:
                continue

    # Multi-module: search in all module dirs
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea", "node_modules"}]
        if os.path.join("src", "main", "java") not in root:
            continue
        candidate = os.path.join(root, rel_path.split(os.sep + "java" + os.sep)[-1] if (os.sep + "java" + os.sep) in rel_path else rel_path)
        # Simpler: just check if class name file exists
        simple_name = fqn.split(".")[-1] + ".java"
        if simple_name in files:
            full_path = os.path.join(root, simple_name)
            try:
                content = open(full_path, "r", encoding="utf-8", errors="ignore").read()
                # Verify package matches
                file_pkg = _extract_package(content)
                expected_pkg = ".".join(fqn.split(".")[:-1])
                if file_pkg == expected_pkg:
                    return content
            except OSError:
                continue
    return None


def _determine_strategy(
    *,
    has_builder: bool,
    has_all_args: bool,
    has_no_arg: bool,
    has_setters: bool,
    is_record: bool,
    constructors: list[list[str]],
) -> str:
    """Determine the safest instantiation strategy for test generation."""
    if is_record:
        return "RECORD"
    if has_builder:
        return "BUILDER"
    if has_all_args:
        return "ALL_ARGS"
    # If there's an explicit multi-arg constructor and no no-arg, use it
    non_empty_ctors = [c for c in constructors if len(c) > 0]
    if non_empty_ctors and not has_no_arg:
        return "ALL_ARGS"
    if has_no_arg and has_setters:
        return "NO_ARG_WITH_SETTERS"
    if has_no_arg:
        return "NO_ARG_WITH_SETTERS"  # Even without explicit setters, often works
    if non_empty_ctors:
        return "ALL_ARGS"
    return "NO_ARG_WITH_SETTERS"  # Default safest
