from __future__ import annotations

import os
import re
import time
from git import Repo
from collections import defaultdict
from dataclasses import asdict

from atlas.analysis.java_maven import (
    count_existing_tests,
    detect_repo_facts,
    find_domain_models,
)
from atlas.build.dependency_governance import capture_effective_dependency_tree, get_dependency_hash, DependencyPolicyEngine, DependencyMutationBlocked
from atlas.analysis.diff_analyzer import DiffAnalyzer
from atlas.build.jacoco_injector import ensure_jacoco_in_poms
from atlas.build.maven import mvn_clean_install, mvn_compile_main_only, mvn_test_with_jacoco, mvn_test_compile_only
from atlas.core.logging import RunLogger
from atlas.core.state import PipelineStateManager, PipelineState
from atlas.generation.java_unit_test_generator import JavaUnitTestGenerator
from atlas.gitops.github_pr import GitHubPrService
from atlas.llm.bedrock import create_bedrock_client, BedrockClient
from atlas.rag.store import SqliteVectorRagStore
from atlas.reporting.models import (
    BreakageReport,
    BuildReport,
    CoverageReport,
    DefectReport,
    FullRunReport,
    GenerationReport,
    OrganizationRunReport,
    QualityGateReport,
    RegressionReport,
    SecurityReport,
    TestStrategyReport,
    UsageReport,
)
from atlas.reporting.models import TestReport # Local import to avoid conflict
from atlas.reporting.parsers import (
    classify_failure,
    get_passed_and_failed_test_keys,
    parse_jacoco_csv,
    parse_surefire_reports,
)
from atlas.gitops.github_org import extract_org_name, list_organization_repos
# Test generators focused on unit testing
from atlas.gitops.github_issues import create_issue_for_failure
from atlas.repo.cloner import RepoCloner, extract_repo_name
from atlas.agents.test_healer import TestHealer
from atlas.agents.build_mechanic import BuildMechanic
from atlas.analysis.contract_service import RepoContractRegistry
import glob


def _remove_test_and_artifacts(java_path: str, repo_path: str):
    """Delete a test .java file AND its compiled .class and surefire report artifacts.
    Prevents ghost test failures from stale compiled classes or surefire reports."""
    backup_path = java_path + ".atlas_bak"
    if os.path.exists(backup_path):
        import shutil
        shutil.move(backup_path, java_path) # Restore original to prevent regressions
    elif os.path.exists(java_path):
        os.remove(java_path)
    
    # Derive the class name and package path from the java file path
    # e.g. /repo/banking-core/src/test/java/com/banking/core/domain/MoneyTest.java
    #   -> class_rel = com/banking/core/domain/MoneyTest
    src_test_java = os.path.join("src", "test", "java")
    if src_test_java in java_path.replace("\\", "/").replace(os.sep, "/"):
        # Find the module root (parent of src/test/java)
        parts = java_path.replace("\\", "/").split("src/test/java/")
        if len(parts) == 2:
            module_root = parts[0].rstrip("/")
            class_rel = parts[1].replace(".java", "")
            fqn = class_rel.replace("/", ".")
            
            # Delete compiled .class file(s) (including inner classes like MoneyTest$1.class)
            class_dir = os.path.join(module_root, "target", "test-classes", os.path.dirname(class_rel))
            class_base = os.path.basename(class_rel)
            if os.path.isdir(class_dir):
                for cf in glob.glob(os.path.join(class_dir, f"{class_base}*.class")):
                    os.remove(cf)
            
            # Delete surefire report files
            surefire_dir = os.path.join(module_root, "target", "surefire-reports")
            if os.path.isdir(surefire_dir):
                for sf in glob.glob(os.path.join(surefire_dir, f"*{fqn}*")):
                    os.remove(sf)


def _get_project_root(repo_path: str, maven_poms: list[str]) -> str:
    """Finds the shallowest directory containing a pom.xml. 
    Crucial for repos where the source is in a subdirectory of the cloned repo.
    """
    if not maven_poms:
        return repo_path
    # Sort by path length and pick the shortest (closest to root)
    # Using relative paths to avoid issues with absolute paths in comparison
    rel_poms = [os.path.relpath(p, repo_path) for p in maven_poms]
    top_pom_rel = sorted(rel_poms, key=lambda p: len(p.split(os.sep)))[0]
    return os.path.dirname(os.path.join(repo_path, top_pom_rel))


def run_organization_pipeline(
    *,
    org_url: str,
    cfg_data_dir: str,
    cfg_runs_dir: str,
    aws_region: str,
    bedrock_model_id: str,
    bedrock_embed_model_id: str,
    github_token: str | None,
    github_username: str | None,
    github_email: str | None,
    logger: RunLogger,
    create_pr: bool,
    max_repos: int = 50,
    quality_gate_min_coverage_pct: float = 60.0,
    quality_gate_max_failures: int = 0,
    create_github_issues_for_failures: bool = False,
) -> OrganizationRunReport:
    """
    Scan whole organization: list all repos, run full pipeline on each (Java/Maven),
    and aggregate reports. Requires GITHUB_TOKEN for listing org repos.
    """
    org_name = extract_org_name(org_url)
    if not org_name:
        raise ValueError(f"Invalid organization URL: {org_url}")
    if not github_token:
        raise ValueError("GITHUB_TOKEN required to scan organization")

    repo_urls = list_organization_repos(org_name, github_token)
    if not repo_urls:
        return OrganizationRunReport(
            org_url=org_url,
            org_name=org_name,
            repo_reports=[],
            total_repos=0,
            repos_ok=0,
            repos_failed=0,
            total_tests_run=0,
            total_tests_passed=0,
            total_generated=0,
        )
    repo_urls = repo_urls[:max_repos]
    logger.info(f"Organization {org_name}: running pipeline on {len(repo_urls)} repo(s)")

    reports: list[FullRunReport] = []
    for i, repo_url in enumerate(repo_urls, 1):
        logger.info(f"[{i}/{len(repo_urls)}] {repo_url}")
        try:
            report = run_full_pipeline(
                repo_url=repo_url,
                cfg_data_dir=cfg_data_dir,
                cfg_runs_dir=cfg_runs_dir,
                aws_region=aws_region,
                bedrock_model_id=bedrock_model_id,
                bedrock_embed_model_id=bedrock_embed_model_id,
                github_token=github_token,
                github_username=github_username,
                github_email=github_email,
                logger=logger,
                create_pr=create_pr,
                quality_gate_min_coverage_pct=quality_gate_min_coverage_pct,
                quality_gate_max_failures=quality_gate_max_failures,
                create_github_issues_for_failures=create_github_issues_for_failures,
            )
            reports.append(report)
        except Exception as e:
            logger.error(f"Pipeline failed for {repo_url}: {e}")
            # Optionally create a minimal failed report so UI can show it
            reports.append(
                FullRunReport(
                    repo_url=repo_url,
                    run_id="",
                    facts={},
                    sanity={"repo_has_pom": False, "existing_test_files": 0, "sanity_checks": [str(e)]},
                    build=BuildReport(ok=False, cmd=[], stderr_tail=str(e), output_tail=str(e), fixed_errors=[]),
                    unit=__placeholder_unit(),
                    coverage=CoverageReport(jacoco_found=False, instruction_covered_pct=None, branch_covered_pct=None, report_path=None, per_class=[]),
                    generation=GenerationReport(generated_files=[], summary="Pipeline failed before generation."),
                    breakage=BreakageReport(build_failures=[str(e)], test_failures=[], runtime_exceptions=[], coverage_gaps=[]),
                    pr_url=None,
                    regression=None,
                    requirements_traceability=None,
                    defects=DefectReport(defects=[], github_issues_created=[]),
                    quality_gate=None,
                    security=SecurityReport(run=False, vulnerabilities=[], summary=""),
                    test_strategy=None,
                )
            )

    total_tests_run = sum(r.unit.total for r in reports)
    total_tests_passed = sum(max(0, r.unit.total - r.unit.failed - r.unit.errors) for r in reports)
    total_generated = sum(len(r.generation.generated_files) for r in reports)
    repos_ok = sum(1 for r in reports if r.build.ok and r.unit.ok)
    repos_failed = len(reports) - repos_ok

    return OrganizationRunReport(
        org_url=org_url,
        org_name=org_name,
        repo_reports=reports,
        total_repos=len(reports),
        repos_ok=repos_ok,
        repos_failed=repos_failed,
        total_tests_run=total_tests_run,
        total_tests_passed=total_tests_passed,
        total_generated=total_generated,
    )


def __placeholder_unit():
    return TestReport(ok=False, total=0, failed=0, errors=0, skipped=0, failed_tests=[])


def run_full_pipeline(
    *,
    repo_url: str,
    cfg_data_dir: str,
    cfg_runs_dir: str,
    aws_region: str,
    bedrock_model_id: str,
    bedrock_embed_model_id: str,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    github_token: str | None,
    github_username: str | None,
    github_email: str | None,
    logger: RunLogger,
    create_pr: bool,
    quality_gate_min_coverage_pct: float = 60.0,
    quality_gate_max_failures: int = 0,
    create_github_issues_for_failures: bool = False,
) -> FullRunReport:
    cloner = RepoCloner(cfg_runs_dir, github_token=github_token)
    cloned = cloner.clone(repo_url)
    logger.info(f"Cloned repo to {cloned.path}")

    try:
        return _run_full_pipeline_core(
            repo_path=cloned.path,
            repo_url=repo_url,
            run_id=cloned.run_id,
            cfg_data_dir=cfg_data_dir,
            aws_region=aws_region,
            bedrock_model_id=bedrock_model_id,
            bedrock_embed_model_id=bedrock_embed_model_id,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token,
            github_token=github_token,
            github_username=github_username,
            github_email=github_email,
            logger=logger,
            create_pr=create_pr,
            quality_gate_min_coverage_pct=quality_gate_min_coverage_pct,
            quality_gate_max_failures=quality_gate_max_failures,
            create_github_issues_for_failures=create_github_issues_for_failures,
            run_validation=False,  # Initial scan: baseline only
        )
    finally:
        logger.info("Cleaning up cloned repository workspace")
        cloner.cleanup(cloned)



def run_full_pipeline_local(
    *,
    repo_path: str,
    repo_url: str,
    cfg_data_dir: str,
    aws_region: str,
    bedrock_model_id: str,
    bedrock_embed_model_id: str,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    github_token: str | None,
    github_username: str | None,
    github_email: str | None,
    logger: RunLogger,
    create_pr: bool,
    quality_gate_min_coverage_pct: float = 60.0,
    quality_gate_max_failures: int = 0,
    create_github_issues_for_failures: bool = False,
    preferred_classes: list[dict] | None = None,
) -> FullRunReport:
    run_id = f"local-{time.strftime('%Y%m%d-%H%M%S')}"
    return _run_full_pipeline_core(
        repo_path=repo_path,
        repo_url=repo_url,
        run_id=run_id,
        cfg_data_dir=cfg_data_dir,
        aws_region=aws_region,
        bedrock_model_id=bedrock_model_id,
        bedrock_embed_model_id=bedrock_embed_model_id,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token,
        github_token=github_token,
        github_username=github_username,
        github_email=github_email,
        logger=logger,
        create_pr=create_pr,
        quality_gate_min_coverage_pct=quality_gate_min_coverage_pct,
        quality_gate_max_failures=quality_gate_max_failures,
        create_github_issues_for_failures=create_github_issues_for_failures,
        preferred_classes_override=preferred_classes,
        run_validation=True,  # Post-fix: baseline + validation + test generation
    )


def run_baseline_only(
    *,
    repo_path: str,
    repo_url: str,
    cfg_data_dir: str,
    aws_region: str,
    bedrock_model_id: str,
    bedrock_embed_model_id: str,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    logger: RunLogger,
) -> FullRunReport:
    """
    Public entry point for establish a coverage baseline WITHOUT test generation.
    """
    run_id = f"baseline-{time.strftime('%Y%m%d-%H%M%S')}"
    from atlas.core.state import PipelineStateManager
    state_mgr = PipelineStateManager(repo_path)
    return _run_baseline_phase(
        repo_path=repo_path,
        repo_url=repo_url,
        run_id=run_id,
        state_mgr=state_mgr,
        logger=logger,
        aws_region=aws_region,
        bedrock_model_id=bedrock_model_id,
        bedrock_embed_model_id=bedrock_embed_model_id or "amazon.titan-embed-text-v1",
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token,
    )

def _run_baseline_phase(
    *,
    repo_path: str,
    repo_url: str,
    run_id: str,
    state_mgr: PipelineStateManager,
    logger: RunLogger,
    aws_region: str,
    bedrock_model_id: str,
    bedrock_embed_model_id: str,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
) -> FullRunReport:
    """
    Executes the Baseline Testing Phase.
    Strictly: Build (with restricted auto-fix) + Test + Coverage.
    NO test generation.
    """
    start_time = time.time()
    from git import Repo
    repo = Repo(repo_path)
    baseline_commit = repo.head.commit.hexsha
    
    # Update state with baseline commit
    state_mgr.update(baseline_commit_hash=baseline_commit, phase="baseline")
    
    facts = detect_repo_facts(repo_path)
    project_root = _get_project_root(repo_path, facts.maven_poms)
    logger.info(f"[Baseline] Commit: {baseline_commit}")
    logger.info(f"[Baseline] Detected: languages={facts.languages} build={facts.build_system}")
    if project_root != repo_path:
        logger.info(f"[Baseline] Using project root: {project_root}")

    sanity = {
        "repo_has_pom": bool(facts.maven_poms),
        "existing_test_files": count_existing_tests(project_root),
        "sanity_checks": [],
    }

    # Ensure JaCoCo etc.
    if facts.maven_poms:
        ensure_jacoco_in_poms(facts.maven_poms, logger)
        from atlas.build.failsafe_injector import ensure_failsafe_in_poms
        ensure_failsafe_in_poms(facts.maven_poms, logger)
        from atlas.build.spring_test_injector import ensure_spring_test_deps
        ensure_spring_test_deps(facts.maven_poms, logger)
        sanity["sanity_checks"].append("pom.xml found and JaCoCo/Failsafe/Spring ensured.")

    # Build with auto-fix retry loop (RESTRICTED to compilation/dependency)
    logger.info("[Baseline] Running mvn clean install")
    # Stage 1: Isolated Main Code Compilation
    logger.info("[Baseline] Stage 1: Isolated Main Code Compilation (src/main/java only)")
    build_res = mvn_compile_main_only(project_root)
    
    build_fixed = False
    dependency_added = False
    
    if not build_res.ok and aws_region and bedrock_model_id:
        llm = create_bedrock_client(aws_region, bedrock_model_id, bedrock_embed_model_id, access_key=aws_access_key_id, secret_key=aws_secret_access_key, session_token=aws_session_token)
        build_mechanic = BuildMechanic(llm=llm, logger=logger)
        domain_models = find_domain_models(project_root)
        attempted_fix_counts = defaultdict(int)
        
        fixed_errors = []
        prior_failed_symbols = []
        for i in range(3):
            logger.info(f"[Baseline] Main compile failed, attempting restricted auto-fix {i+1}/3")
            
            # Extract failed symbols from error messages for THIS attempt
            output_text = (build_res.stdout or "") + (build_res.stderr or "")
            for sym_match in re.finditer(r"cannot find symbol\s*\n?\s*symbol:\s+(?:variable|method|class)\s+(\w+)", output_text):
                sym = sym_match.group(1)
                if sym not in prior_failed_symbols:
                    prior_failed_symbols.append(sym)
            
            diagnosis = build_mechanic.analyze(build_res.stdout or "", build_res.stderr or "")
            
            # Log the specific errors for debugging
            if diagnosis.error_messages:
                for err_msg in diagnosis.error_messages[:5]:
                    logger.info(f"[Baseline]   Error: {err_msg[:200]}")
            
            # Filter diagnosis to only allowed failure types (no test-related fixes in Stage 1)
            allowed_types = ["compilation", "compilation_error", "missing_dependency", "network_or_corrupted_artifact"]
            if diagnosis.failure_type not in allowed_types:
                logger.warn(f"[Baseline] Diagnosis type {diagnosis.failure_type} not allowed in Stage 1. Stopping.")
                break
            
            # Track attempted files to avoid infinite re-fixing of the same file
            blocked_files = {f for f, count in attempted_fix_counts.items() if count >= 2}
            fix = build_mechanic.generate_fix(diagnosis, project_root, attempted_files=blocked_files, domain_models=domain_models, prior_failed_symbols=prior_failed_symbols if prior_failed_symbols else None)
            if not fix:
                logger.warn(f"[Baseline] No fix generated (attempt {i+1}/5). Diagnosis: {diagnosis.summary}")
                break

            # Apply shell commands if any (e.g. mvn -U for network errors)
            if fix.shell_commands:
                from atlas.core.shell import run_cmd
                for cmd_str in fix.shell_commands:
                    logger.info(f"[Baseline] Running suggested shell command: {cmd_str}")
                    # Simple split for now, but in real scenarios might need shlex
                    cmd_parts = cmd_str.split()
                    run_cmd(cmd_parts, cwd=project_root, logger=logger)
                build_fixed = True

            if fix.file_patches:
                for patch in fix.file_patches:
                    try:
                        os.makedirs(os.path.dirname(patch.path), exist_ok=True)
                        with open(patch.path, "w", encoding="utf-8") as f:
                            f.write(patch.content)
                        attempted_fix_counts[patch.path] += 1
                    except Exception as e:
                        logger.error(f"[Baseline] Failed to apply patch to {patch.path}: {e}")
                
                fixed_errors.append(f"Fixed {diagnosis.failure_type}: {diagnosis.summary}")
                build_fixed = True
                if diagnosis.failure_type == "missing_dependency":
                    dependency_added = True
                    
                build_res = mvn_compile_main_only(project_root)
                if build_res.ok:
                    logger.info("[Baseline] Main compile fixed!")
                    break
            else:
                logger.warn(f"[Baseline] No fix generated (attempt {i+1}/5). Diagnosis: {diagnosis.summary}")
                break
        
        if not build_res.ok:
            # Log compilation errors for debugging when all retries fail
            combined_output = (build_res.stdout or "") + "\n" + (build_res.stderr or "")
            error_lines = [l for l in combined_output.splitlines() if "[ERROR]" in l][:20]
            logger.error(f"[Baseline] Build still failing after {i+1} auto-fix attempts. Errors:")
            for el in error_lines:
                logger.error(f"[Baseline]   {el.strip()}")

    stderr_tail = "\n".join((build_res.stderr or "").splitlines()[-100:])
    combined = (build_res.stdout or "") + "\n" + (build_res.stderr or "")
    output_tail = "\n".join(combined.splitlines()[-100:])
    build_report = BuildReport(
        ok=build_res.ok, cmd=build_res.cmd,
        stderr_tail=stderr_tail, output_tail=output_tail,
        fixed_errors=fixed_errors if 'fixed_errors' in locals() else []
    )

    unit = __placeholder_unit()
    coverage = CoverageReport(jacoco_found=False, instruction_covered_pct=None, branch_covered_pct=None, report_path=None, per_class=[])

    if build_res.ok:
        logger.info("[Baseline] Running mvn verify (existing tests + JaCoCo)")
        test_res = mvn_test_with_jacoco(project_root)
        # Phase 10: Coverage Analysis
        state_mgr.update(state=PipelineState.COVERAGE)
        unit = parse_surefire_reports(project_root)   # ← Parse actual test results
        coverage = parse_jacoco_csv(project_root, logger=logger)
        
        passed_keys, _ = get_passed_and_failed_test_keys(project_root)
        
        state_mgr.update(
            baseline_coverage=coverage.instruction_covered_pct or 0.0,
            baseline_total_tests=unit.total,
            baseline_passed_test_keys=list(passed_keys),
            baseline_completed=True,
            phase="validation_testing"
        )
    else:
        logger.warning("[Baseline] Build failed — cannot establish baseline coverage")

    duration_seconds = time.time() - start_time
    breakage_buckets = classify_failure(combined) if not build_res.ok else {"build": [], "test": [], "runtime": [], "coverage": []}
    
    # Track usage (tokens for BuildMechanic)
    llm_for_usage = locals().get('llm')
    usage = _calculate_usage(llm_for_usage) if llm_for_usage else None

    return FullRunReport(
        repo_url=repo_url,
        run_id=run_id,
        facts=asdict(facts),
        sanity=sanity,
        build=build_report,
        unit=unit,
        coverage=coverage,
        generation=GenerationReport(generated_files=[], summary="Baseline Testing Phase — strictly deterministic build/test."),
        breakage=BreakageReport(
            build_failures=breakage_buckets.get("build", []),
            test_failures=breakage_buckets.get("test", []),
            runtime_exceptions=breakage_buckets.get("runtime", []),
            coverage_gaps=breakage_buckets.get("coverage", []),
        ),
        usage=usage,
        duration_seconds=round(duration_seconds, 2),
        pr_url=None,
    )

def _run_validation_phase(
    *,
    repo_path: str,
    repo_url: str,
    run_id: str,
    state_mgr: PipelineStateManager,
    logger: RunLogger,
    aws_region: str,
    bedrock_model_id: str,
    bedrock_embed_model_id: str,
    cfg_data_dir: str,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    create_pr: bool = False,
    github_token: str | None = None,
    github_username: str | None = None,
    github_email: str | None = None,
    quality_gate_min_coverage_pct: float = 60.0,
    quality_gate_max_failures: int = 0,
) -> FullRunReport:
    """
    Executes the Validation Testing Phase.
    Includes diff-aware logic, functional change detection, and idempotency.
    """
    start_time = time.time()
    logger.info(f"[Validation] Starting validation for path: {repo_path}")
    
    from atlas.analysis.diff_analyzer import DiffAnalyzer
    
    llm = create_bedrock_client(aws_region, bedrock_model_id, bedrock_embed_model_id, access_key=aws_access_key_id, secret_key=aws_secret_access_key, session_token=aws_session_token)
    diff_analyzer = DiffAnalyzer(llm)
    
    # Precondition check
    if not state_mgr.status.baseline_completed:
        raise ValueError("Baseline testing must be completed before validation.")
        
    baseline_commit = state_mgr.status.baseline_commit_hash
    
    # Analyze project early to ensure report is populated even if we skip
    facts = detect_repo_facts(repo_path)
    project_root = _get_project_root(repo_path, facts.maven_poms)
    if project_root != repo_path:
        logger.info(f"[Validation] Using project root: {project_root}")

    sanity = {
        "repo_has_pom": bool(facts.maven_poms),
        "existing_test_files": count_existing_tests(project_root),
        "sanity_checks": [],
    }
    if facts.maven_poms:
        sanity["sanity_checks"].append("pom.xml found.")
    

    # Ensure JaCoCo etc. in validation too (case of fresh changes or non-baseline-prep runs)
    if facts.maven_poms:
        ensure_jacoco_in_poms(facts.maven_poms, logger)
        from atlas.build.failsafe_injector import ensure_failsafe_in_poms
        ensure_failsafe_in_poms(facts.maven_poms, logger)
        from atlas.build.spring_test_injector import ensure_spring_test_deps
        ensure_spring_test_deps(facts.maven_poms, logger)
        sanity["sanity_checks"].append("pom.xml found and JaCoCo/Failsafe/Spring ensured.")

    # Step 1: Detect local changes and Step 2: Idempotency check
    current_hash = diff_analyzer.get_working_tree_hash(repo_path, baseline_commit)
    
    # Only skip if the hash matches AND the last run actually produced test results
    # This ensures that if a previous run was broken/empty, we try again.
    is_idempotent = (current_hash == state_mgr.status.last_validation_hash)
    has_previous_results = (state_mgr.status.baseline_coverage is not None)
    
    if is_idempotent and has_previous_results:
        logger.info(f"[Validation] Idempotent run: Working tree matches last validation ({current_hash}). Skipping.")
        return FullRunReport(
            repo_url=repo_url, run_id=run_id, facts=asdict(facts), sanity=sanity,
            build=BuildReport(ok=True, cmd=[], stderr_tail="", output_tail="CACHED", fixed_errors=[]),
            unit=__placeholder_unit(), 
            coverage=CoverageReport(jacoco_found=True, instruction_covered_pct=state_mgr.status.baseline_coverage, branch_covered_pct=None, report_path=None, per_class=[]),
            generation=GenerationReport(generated_files=[], summary="SKIPPED: Idempotent run - matched cached hash. No code changes since last validation."),
            breakage=BreakageReport(build_failures=[], test_failures=[], runtime_exceptions=[], coverage_gaps=[]),
            pr_url=None,
            duration_seconds=0.1
        )

    # Step 3: Functional Change Classification
    diff_text = diff_analyzer.get_diff(repo_path, baseline_commit)
    if not diff_text.strip():
        logger.info(f"[Validation] No changes detected relative to baseline commit {baseline_commit}. Skip.")
        return FullRunReport(
            repo_url=repo_url, run_id=run_id, facts=asdict(facts), sanity=sanity,
            build=BuildReport(ok=True, cmd=[], stderr_tail="", output_tail="NO_CHANGES", fixed_errors=[]),
            unit=__placeholder_unit(), 
            coverage=CoverageReport(jacoco_found=True, instruction_covered_pct=state_mgr.status.baseline_coverage, branch_covered_pct=None, report_path=None, per_class=[]),
            generation=GenerationReport(generated_files=[], summary="SKIPPED: No code changes detected relative to baseline."),
            breakage=BreakageReport(build_failures=[], test_failures=[], runtime_exceptions=[], coverage_gaps=[]),
            pr_url=None,
            duration_seconds=0.1
        )
    
    # Phase 0: Dependency Baseline Capture
    state_mgr.update(state=PipelineState.DEPENDENCY_BASELINE)
    logger.info("[Validation] Phase 0: Capturing Immutable Dependency Baseline")
    initial_deps = capture_effective_dependency_tree(project_root)
    baseline_hash = get_dependency_hash(initial_deps)
    state_mgr.status.baseline_dependency_hash = baseline_hash
    logger.info(f"[Validation] Baseline Dependency Hash: {baseline_hash[:12]} ({len(initial_deps)} nodes)")

    state_mgr.update(state=PipelineState.DISCOVERY)
    analysis = diff_analyzer.analyze_functional_change(diff_text)
    functional_changes = analysis.get("classification") == "FUNCTIONAL"
    change_reason = analysis.get("reason")
    logger.info(f"[Validation] Functional changes detected: {functional_changes} ({change_reason})")

    # Get modified classes for prioritization
    modified_files = diff_analyzer.get_modified_java_files(repo_path, baseline_commit)
    preferred_classes = []
    for f in modified_files:
        try:
            with open(f, "r", encoding="utf-8", errors="ignore") as fp:
                code = fp.read()
                # Simple regex to infer package and class for prioritization
                pkg_match = re.search(r"^\s*package\s+([a-zA-Z0-9_.]+)\s*;", code, flags=re.MULTILINE)
                cls_match = re.search(r"\bpublic\s+class\s+([A-Za-z0-9_]+)\b", code)
                pkg = pkg_match.group(1) if pkg_match else ""
                cls = cls_match.group(1) if cls_match else os.path.splitext(os.path.basename(f))[0]
                preferred_classes.append({"package": pkg, "class": cls})
        except Exception:
            pass
    if preferred_classes:
        logger.info(f"[Validation] Prioritizing {len(preferred_classes)} modified classes: {[c['class'] for c in preferred_classes]}")

    # Step 4: Execution Logic
    rag_db = os.path.join(cfg_data_dir, "rag.sqlite3")
    from atlas.rag.store import SqliteVectorRagStore
    rag = SqliteVectorRagStore(rag_db)
    gen = JavaUnitTestGenerator(llm=llm, rag=rag)
    
    # Phase 2: Isolated Main Code Compilation
    state_mgr.update(state=PipelineState.MAIN_COMPILE)
    logger.info("[Validation] Stage 1: Isolated Main Code Compilation")
    build_res = mvn_compile_main_only(project_root)
    fixed_errors = []
    
    if not build_res.ok:
        build_mechanic = BuildMechanic(llm=llm, logger=logger)
        domain_models = find_domain_models(project_root)
        attempted_fix_counts = defaultdict(int)
        prior_failed_symbols = []  # Track symbols that don't exist to prevent hallucination
        for i in range(3):
            logger.info(f"[Validation] Main compile failed, attempting auto-fix {i+1}/3")
            
            # Extract failed symbols from error messages for THIS attempt
            output_text = (build_res.stdout or "") + (build_res.stderr or "")
            for sym_match in re.finditer(r"cannot find symbol\s*\n?\s*symbol:\s+(?:variable|method|class)\s+(\w+)", output_text):
                sym = sym_match.group(1)
                if sym not in prior_failed_symbols:
                    prior_failed_symbols.append(sym)
            
            if prior_failed_symbols:
                logger.info(f"[Validation] Detected failed symbols (marked as toxic/hallucinations): {prior_failed_symbols}")
                
            diagnosis = build_mechanic.analyze(build_res.stdout or "", build_res.stderr or "")
            
            # Log the specific errors for debugging
            if diagnosis.error_messages:
                for err_msg in diagnosis.error_messages[:5]:
                    logger.info(f"[Validation]   Error: {err_msg[:200]}")
            
            # Stage 1: only allow source or dependency fixes
            if not any(t in diagnosis.failure_type for t in ["compilation", "missing_dependency", "network_or_corrupted_artifact"]):
                logger.warn(f"[Validation] Non-source error in Stage 1: {diagnosis.failure_type}. Stopping Stage 1 repair.")
                break

            # BLOCK LLM from editing pom.xml
            blocked_files = {f for f, count in attempted_fix_counts.items() if count >= 2}
            fix = build_mechanic.generate_fix(diagnosis, project_root, attempted_files=blocked_files, domain_models=domain_models, prior_failed_symbols=prior_failed_symbols if prior_failed_symbols else None)
            if not fix:
                logger.warn(f"[Validation] No fix generated (attempt {i+1}/5). Diagnosis: {diagnosis.summary}")
                break

            # Apply shell commands if any (e.g. mvn -U)
            shell_executed = False
            if fix.shell_commands:
                from atlas.core.shell import run_cmd
                for cmd_str in fix.shell_commands:
                    logger.info(f"[Validation] Running suggested shell command: {cmd_str}")
                    cmd_parts = cmd_str.split()
                    run_cmd(cmd_parts, cwd=project_root, logger=logger)
                shell_executed = True

            if fix.file_patches:
                allowed_patches = [p for p in fix.file_patches if not p.path.endswith("pom.xml")]
                if len(allowed_patches) < len(fix.file_patches):
                    logger.warn("[FSM] Build runner attempted to modify pom.xml. BLOCKING mutation.")
                
                if not allowed_patches and not shell_executed:
                    # If ONLY pom.xml was suggested, we must stop and require UI approval
                    logger.error("[FSM] Required fix involves dependency mutation. Requesting UI approval.")
                    return FullRunReport(
                        repo_url=repo_url, run_id=run_id, facts=asdict(facts), sanity=sanity,
                        build=BuildReport(ok=False, cmd=[], stderr_tail="", output_tail="DEPENDENCY_CHANGE_REQUIRED", fixed_errors=fixed_errors),
                        unit=__placeholder_unit(), coverage=CoverageReport(jacoco_found=False, instruction_covered_pct=0, branch_covered_pct=0, report_path=None, per_class=[]),
                        generation=GenerationReport(generated_files=[], summary="DEPENDENCY_CHANGE_REQUIRED: Build repair requires pom.xml mutation."),
                        breakage=BreakageReport(build_failures=[], test_failures=[], runtime_exceptions=[], coverage_gaps=[]),
                        pr_url=None, usage=_calculate_usage(llm), duration_seconds=round(time.time() - start_time, 2)
                    )

                for patch in allowed_patches:
                    try:
                        os.makedirs(os.path.dirname(patch.path), exist_ok=True)
                        with open(patch.path, "w", encoding="utf-8") as f:
                            f.write(patch.content)
                        attempted_fix_counts[patch.path] += 1
                    except Exception as e:
                        logger.error(f"[Validation] Failed to apply patch to {patch.path}: {e}")
                fixed_errors.append(f"Fixed {diagnosis.failure_type}: {diagnosis.summary}")
            
            if fix.shell_commands or fix.file_patches:
                build_res = mvn_compile_main_only(project_root)
                if build_res.ok:
                    logger.info("[Validation] Main compile fixed!")
                    # Invalidate registry if it existed (though usually it doesn't at this stage)
                    if 'registry' in locals() and registry: registry.invalidate()
                    break
            else:
                logger.warn(f"[Validation] No fix generated (attempt {i+1}/5). Diagnosis: {diagnosis.summary}")
                break

    # If build still fails after all retries, return early with failure report
    if not build_res.ok:
        logger.error("[Validation] Build failed after all auto-fix attempts. Returning failure report.")
        stderr_tail = "\n".join((build_res.stderr or "").splitlines()[-100:])
        combined = (build_res.stdout or "") + "\n" + (build_res.stderr or "")
        output_tail = "\n".join(combined.splitlines()[-100:])
        breakage_buckets = classify_failure(combined)
        usage = _calculate_usage(llm)
        duration_seconds = time.time() - start_time
        return FullRunReport(
            repo_url=repo_url, run_id=run_id, facts=asdict(facts), sanity=sanity,
            build=BuildReport(ok=False, cmd=build_res.cmd, stderr_tail=stderr_tail, output_tail=output_tail, fixed_errors=fixed_errors),
            unit=__placeholder_unit(),
            coverage=CoverageReport(jacoco_found=False, instruction_covered_pct=None, branch_covered_pct=None, report_path=None, per_class=[]),
            generation=GenerationReport(generated_files=[], summary="Build failed — no tests executed or generated."),
            breakage=BreakageReport(
                build_failures=breakage_buckets.get("build", []),
                test_failures=breakage_buckets.get("test", []),
                runtime_exceptions=breakage_buckets.get("runtime", []),
                coverage_gaps=breakage_buckets.get("coverage", []),
            ),
            pr_url=None,
            usage=usage,
            duration_seconds=round(duration_seconds, 2)
        )

    # Initial test run (only if build succeeded)
    logger.info("[Validation] Running initial mvn verify")
    test_res = mvn_test_with_jacoco(project_root)
    unit = parse_surefire_reports(project_root)
    coverage = parse_jacoco_csv(project_root, logger=logger)
    coverage_before = coverage.instruction_covered_pct or 0.0

    # Fix 2: Re-baseline AFTER source compile fixes.
    # The original baseline was captured BEFORE BuildMechanic fixed source files.
    # Source fixes can break existing tests (e.g., adding input validation changes API behavior).
    # Re-baselining here ensures regressions only reflect tests broken by test GENERATION,
    # not by the source code fixes.
    passed_keys_post_fix, _ = get_passed_and_failed_test_keys(project_root)
    state_mgr.update(
        baseline_total_tests=unit.total,
        baseline_passed_test_keys=list(passed_keys_post_fix),
        baseline_coverage=coverage_before,
    )
    logger.info(f"[Validation] Re-baselined after source fixes: {unit.total} tests, {len(passed_keys_post_fix)} passed")

    # Test Healing Loop (max 10 retries as requested)
    repair_attempts = defaultdict(int) 
    healer_history = []
    last_applied_files_count = -1
    if not unit.ok and unit.total > 0:
        test_healer = TestHealer(llm=llm, logger=logger)
        heal_start = time.time()
        HEAL_BUDGET = 60  # 1 minute max
        for attempt in range(1):
            if time.time() - heal_start > HEAL_BUDGET:
                logger.warn(f"[Validation] Healing time budget exhausted ({HEAL_BUDGET}s). Stopping.")
                break
            logger.info(f"[Validation] Test failures/errors detected ({unit.failed + unit.errors} broken), healing attempt {attempt+1}/1")
            fixes = test_healer.heal(unit.failed_tests, project_root)
            if not fixes:
                logger.info("[Validation] No more fixes suggested by TestHealer.")
                break
                
            applied_patches = []
            for fix in fixes:
                for patch in fix.file_patches:
                    repair_attempts[patch.path] += 1
                    # Fail-fast: if a file fails healing 3 times, delete it if it's generated
                    if repair_attempts[patch.path] >= 3:
                        if "Test.java" in patch.path or "IT.java" in patch.path:
                             logger.warn(f"[Validation] File {patch.path} failed healing 3 times. Deleting to unblock.")
                             _remove_test_and_artifacts(patch.path, project_root)
                             continue

                    with open(patch.path, "w", encoding="utf-8") as f:
                        f.write(patch.content)
                    applied_patches.append(patch.path)
            
            if not applied_patches:
                logger.info("[Validation] No patches applied in this attempt. Stopping healing.")
                break
                
            # Re-run tests
            test_res = mvn_test_with_jacoco(project_root)
            unit = parse_surefire_reports(project_root)
            healer_history.append({"attempt": attempt+1, "status": "fixed" if unit.ok else "partially_fixed", "modified": applied_patches})
            if unit.ok:
                logger.info("[Validation] All tests passed after healing!")
                break

    tests_generated = False
    if functional_changes or coverage_before < state_mgr.status.coverage_threshold:
        logger.info(f"[Validation] Proceeding with test generation (Functional={functional_changes}, Coverage={coverage_before:.1f}%)")
        
        # Phase 3: Global Contract Extraction
        state_mgr.update(state=PipelineState.CONTRACT_EXTRACTION)
        logger.info("[Validation] Phase 3: Global Contract Extraction")
        registry = RepoContractRegistry(project_root)
        
        # Phase 4: Target Test Generation
        state_mgr.update(state=PipelineState.TEST_GENERATION)
        logger.info("[Validation] Phase 4: Target Test Generation")
        
        # Generate targeted tests
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        gen_res = loop.run_until_complete(gen.generate_minimal_tests_for_repo(
            project_root, 
            target_count=30, 
            repo_url=repo_url,
            preferred_classes=preferred_classes,
            change_reasoning=change_reason,
            registry=registry # Pass registry to avoid re-indexing
        ))
        loop.close()
        tests_generated = True
        
        # Phase 6 & 8: Test-Compile Confidence Gate (verify src/test/java compilation)
        state_mgr.update(state=PipelineState.TEST_COMPILE)
        logger.info("[Validation] Phase 6: Test-Compile Confidence Gate")
        compile_res = mvn_test_compile_only(project_root)
        if not compile_res.ok:
            # Phase 6 & 8: Error Analysis and Classification
            output = (compile_res.stdout or "") + (compile_res.stderr or "")
            # Catch both line-numbered errors and generic [ERROR] messages
            error_count = len(re.findall(r"\[ERROR\].*?:\s*\[\d+,\d+\]|\[ERROR\]\s+.*?(?=\r?\n|$)", output))
            
            if error_count > 5:
                logger.warn(f"[Validation] Phase 6: {error_count} compilation errors detected. High-error threshold reached. Regenerating instead of repairing.")
                # Phase 6: Logic to regenerate high-failure classes (one-time retry)
                # For simplicity, we trigger the generation loop once more with a 'strict' flag
                # but in this orchestrator, we'll just log and try a limited repair if it's manageable.
                # If we truly want Phase 6, we should go back to Step 2.
            
            logger.info(f"[Validation] Detected {error_count} compilation errors. Starting targeted repair.")
            build_mechanic = BuildMechanic(llm=llm, logger=logger)
            indexed_domain_models = list(registry.fqn_to_path.keys()) if 'registry' in locals() else find_domain_models(project_root)
            
            repair_phase_start = time.time()
            REPAIR_BUDGET_SECONDS = 180  # 3 minutes max for the entire repair phase
            prior_failed_symbols = []
            
            for i in range(2):
                elapsed = time.time() - repair_phase_start
                if elapsed > REPAIR_BUDGET_SECONDS:
                    logger.warn(f"[Validation] Test repair time budget exhausted ({elapsed:.0f}s > {REPAIR_BUDGET_SECONDS}s). Skipping remaining attempts.")
                    break
                
                logger.info(f"[Validation] Test repair attempt {i+1}/2 (budget: {REPAIR_BUDGET_SECONDS - elapsed:.0f}s remaining)")
                diagnosis = build_mechanic.analyze(compile_res.stdout or "", compile_res.stderr or "")
                
                # Extract failed symbols from error messages for next attempt
                if i > 0:  # Only on retry
                    output_text = (compile_res.stdout or "") + (compile_res.stderr or "")
                    for sym_match in re.finditer(r"cannot find symbol\s*\n?\s*symbol:\s+(?:variable|method|class)\s+(\w+)", output_text):
                        sym = sym_match.group(1)
                        if sym not in prior_failed_symbols:
                            prior_failed_symbols.append(sym)
                    if prior_failed_symbols:
                        logger.info(f"[Validation] Prior failed symbols (DO NOT USE): {prior_failed_symbols}")

                # Phase 8: Repair Restrictions
                # REJECT repair for fluent API misuse or security config.
                forbidden_patterns = ["ResourceHandlerRegistration", "HttpSecurity", "SecurityFilterChain", "this' in fluent"]
                if any(p in (diagnosis.summary or "") for p in forbidden_patterns):
                    logger.warn(f"[Validation] Phase 8: Forbidden error type detected for repair: {diagnosis.failure_type}. Stopping repair.")
                    break

                fix = build_mechanic.generate_fix(diagnosis, project_root, domain_models=indexed_domain_models, prior_failed_symbols=prior_failed_symbols if prior_failed_symbols else None)
                if fix and fix.file_patches:
                    # GOVERNANCE: Block pom.xml mutation in test-repair loop
                    allowed_patches = [p for p in fix.file_patches if not p.path.endswith("pom.xml")]
                    pom_patches = [p for p in fix.file_patches if p.path.endswith("pom.xml")]
                    if pom_patches:
                        logger.warn(f"[Governance] Test repair tried to edit pom.xml ({len(pom_patches)} file(s)). Blocking. Requires UI approval.")
                        if not allowed_patches:
                            logger.error("[Governance] All suggested fixes involve pom.xml. Cannot proceed without approval.")
                            break
                    for patch in allowed_patches:
                        with open(patch.path, "w", encoding="utf-8") as f:
                            f.write(patch.content)
                    compile_res = mvn_test_compile_only(project_root)
                    if compile_res.ok:
                        logger.info("[Validation] Generated tests compiled successfully!")
                        break
                else:
                    break
        
        # Phase 8: Dependency Diff Gate (Final check before proceeding)
        state_mgr.update(state=PipelineState.DEPENDENCY_GATE)
        current_deps = capture_effective_dependency_tree(project_root)
        dep_current_hash = get_dependency_hash(current_deps)
        
        if dep_current_hash != state_mgr.status.baseline_dependency_hash:
            diff_engine = DependencyPolicyEngine()
            change = diff_engine.evaluate_dependency_change(initial_deps, current_deps)
            logger.error(f"[FSM] Phase 8: Dependency mutation detected! Blocking pipeline. Change: {change}")
            # Delete generated tests as per Phase 9/Governance
            if 'gen_res' in locals() and gen_res:
                for f in gen_res.generated_files:
                    _remove_test_and_artifacts(f, project_root)
            
            duration_seconds = time.time() - start_time
            return FullRunReport(
                repo_url=repo_url, run_id=run_id, facts=asdict(facts), sanity=sanity,
                build=BuildReport(ok=False, cmd=[], stderr_tail="", output_tail="DEPENDENCY_MUTATION", fixed_errors=fixed_errors),
                unit=__placeholder_unit(), coverage=CoverageReport(jacoco_found=False, instruction_covered_pct=0, branch_covered_pct=0, report_path=None, per_class=[]),
                generation=GenerationReport(generated_files=[], summary=f"DEPENDENCY_CHANGE_REQUIRED: {change}"),
                breakage=BreakageReport(build_failures=[], test_failures=[], runtime_exceptions=[], coverage_gaps=[]),
                pr_url=None, usage=_calculate_usage(llm), duration_seconds=round(duration_seconds, 2)
            )

        # Phase 9: Confidence score (Hard Gate)
        # If still fails test-compile, delete ONLY the failing test files, keep working ones
        if not compile_res.ok:
            logger.warning("[Validation] Phase 9: Confidence gate - compile still failing. Removing only broken test files.")
            state_mgr.update(state=PipelineState.ERROR)
            if 'gen_res' in locals() and gen_res:
                # Parse compile output to find which files have errors
                compile_output = (compile_res.stdout or "") + (compile_res.stderr or "")
                failing_files = set()
                for line in compile_output.splitlines():
                    # Maven error format: /path/to/File.java:[line]: error: ...
                    err_match = re.search(r"(/[^\s:]+\.java):\[?\d+", line)
                    if err_match:
                        failing_files.add(os.path.normpath(err_match.group(1)))
                
                deleted_count = 0
                kept_count = 0
                for f in gen_res.generated_files:
                    norm_f = os.path.normpath(f)
                    if norm_f in failing_files and os.path.exists(f):
                        logger.info(f"[Validation] Deleting broken generated test: {os.path.basename(f)}")
                        _remove_test_and_artifacts(f, project_root)
                        deleted_count += 1
                    elif os.path.exists(f):
                        kept_count += 1
                
                logger.info(f"[Validation] Phase 9: Deleted {deleted_count} broken test(s), kept {kept_count} working test(s).")
                tests_generated = kept_count > 0
            else:
                tests_generated = False
        else:
            state_mgr.update(state=PipelineState.TEST_EXECUTION)

        
        # Re-run tests after generation (and confidence gate repair)
        logger.info("[Validation] Re-running tests after generation")
        test_res = mvn_test_with_jacoco(project_root)
        unit = parse_surefire_reports(project_root)
        state_mgr.update(state=PipelineState.COVERAGE)

        # Post-generation healing loop
        if not unit.ok and unit.total > 0:
            test_healer = TestHealer(llm=llm, logger=logger)
            post_heal_start = time.time()
            POST_HEAL_BUDGET = 60  # 1 minute max
            for attempt in range(1):
                if time.time() - post_heal_start > POST_HEAL_BUDGET:
                    logger.warn(f"[Validation] Post-gen healing time budget exhausted ({POST_HEAL_BUDGET}s). Stopping.")
                    break
                logger.info(f"[Validation] Post-gen failures/errors ({unit.failed + unit.errors} broken), healing attempt {attempt+1}/1")
                fixes = test_healer.heal(unit.failed_tests, project_root)
                if not fixes: break
                applied_patches = []
                for fix in fixes:
                    for patch in fix.file_patches:
                        repair_attempts[patch.path] += 1
                        if repair_attempts[patch.path] >= 3:
                            if "Test.java" in patch.path or "IT.java" in patch.path:
                                logger.warn(f"[Validation] Deleting failing generated test: {patch.path}")
                                _remove_test_and_artifacts(patch.path, project_root)
                                continue
                        with open(patch.path, "w", encoding="utf-8") as f:
                            f.write(patch.content)
                        applied_patches.append(patch.path)
                
                if not applied_patches:
                    logger.info("[Validation] No patches applied in post-gen healing. Stopping.")
                    break

                test_res = mvn_test_with_jacoco(project_root)
                unit = parse_surefire_reports(project_root)
                healer_history.append({"attempt": f"post-gen-{attempt+1}", "status": "fixed" if unit.ok else "partially_fixed", "modified": applied_patches})
                if unit.ok: break

        # ── FINAL CLEANUP: Delete any generated tests that STILL fail ──
        # This ensures ZERO regressions from generated code.
        if not unit.ok and 'gen_res' in locals() and gen_res:
            logger.info("[Validation] Final cleanup: removing generated tests that still fail to ensure zero regressions.")
            _, still_failed_keys = get_passed_and_failed_test_keys(project_root)
            # Build a set of classnames from failed tests
            failed_classnames = set()
            for fk in still_failed_keys:
                # Keys look like "com.banking.Foo#testBar"
                cn = fk.split("#")[0] if "#" in fk else fk
                # Convert dotted classname to simple name
                simple = cn.rsplit(".", 1)[-1] if "." in cn else cn
                failed_classnames.add(simple)
            
            deleted_final = 0
            for f in list(gen_res.generated_files):
                basename = os.path.splitext(os.path.basename(f))[0]
                if basename in failed_classnames and os.path.exists(f):
                    logger.info(f"[Validation] Final cleanup: deleting still-failing generated test: {os.path.basename(f)}")
                    _remove_test_and_artifacts(f, project_root)
                    gen_res.generated_files.remove(f)
                    deleted_final += 1
            
            if deleted_final > 0:
                logger.info(f"[Validation] Final cleanup: deleted {deleted_final} still-failing generated test(s). Re-running tests.")
                test_res = mvn_test_with_jacoco(project_root)
                unit = parse_surefire_reports(project_root)

        coverage = parse_jacoco_csv(project_root, logger=logger)

    coverage_after = coverage.instruction_covered_pct or 0.0
    
    # QA-centric results: Regression and Quality Gate
    regression = calculate_regression_report(state_mgr, unit, coverage, post_gen_ok=unit.ok, repo_path=project_root)
    quality_gate = evaluate_quality_gate(coverage, unit, quality_gate_min_coverage_pct, quality_gate_max_failures)

    usage = _calculate_usage(llm)

    # PR Creation ...
    pr_url = None
    if create_pr and github_token and tests_generated:
        logger.info(f"[Validation] Creating automated PR for {repo_url}")
        try:
            pr_service = GitHubPrService(github_token, github_username, github_email, logger)
            pr_body = _default_pr_body(
                GenerationReport(
                    generated_files=[os.path.relpath(p, repo_path) for p in gen_res.generated_files],
                    summary=f"Validation Phase completed."
                ), 
                coverage, 
                BreakageReport(build_failures=[], test_failures=[], runtime_exceptions=[], coverage_gaps=[]),
                usage
            )
            pr_url = pr_service.create_pr(repo_url, repo_path, "feat: Atlas AI-generated unit tests", pr_body)
        except Exception as e:
            logger.error(f"[Validation] PR creation failed: {e}")

    # Update last validation hash ONLY if we reached this point (i.e. didn't skip) 
    # and tests were actually executed.
    if 'unit' in locals() and unit.total > 0:
        state_mgr.update(last_validation_hash=current_hash)
    else:
        logger.warn(f"[Validation] Not updating validation hash because no tests were executed (total=0).")
    
    duration_seconds = time.time() - start_time
    
    # Calculate file_summaries for UI (passed/failed tests per file)
    file_summaries = {}
    if 'gen_res' in locals() and gen_res and tests_generated and 'unit' in locals():
        passed_keys_post, _ = get_passed_and_failed_test_keys(project_root)
        for f in gen_res.generated_files:
            if not os.path.exists(f): continue
            rel_f = os.path.relpath(f, repo_path)
            file_summaries[rel_f] = {"passed": 0, "failed": 0, "errors": 0}
            src_test_java = os.path.join("src", "test", "java")
            rel_path_f = f.replace("\\", "/").replace(os.sep, "/")
            if src_test_java in rel_path_f:
                parts = rel_path_f.split("src/test/java/")
                if len(parts) == 2:
                    fqn = parts[1].replace(".java", "").replace("/", ".")
                    for pk in passed_keys_post:
                        if pk.startswith(fqn + "#"):
                            file_summaries[rel_f]["passed"] += 1
                    for ft in unit.failed_tests:
                        if ft.get("classname") == fqn:
                            if ft.get("type") == "failure":
                                file_summaries[rel_f]["failed"] += 1
                            else:
                                file_summaries[rel_f]["errors"] += 1
    
    return FullRunReport(
        repo_url=repo_url,
        run_id=run_id,
        facts=asdict(facts),
        sanity=sanity,
        build=BuildReport(ok=build_res.ok, cmd=build_res.cmd, stderr_tail="", output_tail="", fixed_errors=fixed_errors),
        unit=TestReport(
            ok=unit.ok, total=unit.total, failed=unit.failed, errors=unit.errors, skipped=unit.skipped,
            failed_tests=unit.failed_tests, healer_history=healer_history
        ),
        coverage=coverage,
        generation=GenerationReport(
            generated_files=[os.path.relpath(p, repo_path) for p in (gen_res.generated_files if tests_generated else []) if os.path.exists(p)] if 'gen_res' in locals() else [],
            summary=f"Validation Phase completed. Functional={functional_changes}, Generated={tests_generated}. Reasoning: {change_reason}. " + 
                    (f"Targeted {len(gen_res.generated_files)} files to increase coverage." if (tests_generated and 'gen_res' in locals()) else "No tests generated."),
            new_tests=[os.path.relpath(p, repo_path) for p in (gen_res.new_tests or []) if os.path.exists(p)] if ('gen_res' in locals() and tests_generated) else [],
            updated_tests=[os.path.relpath(p, repo_path) for p in (gen_res.updated_tests or []) if os.path.exists(p)] if ('gen_res' in locals() and tests_generated) else [],
            file_summaries=file_summaries
        ),
        breakage=BreakageReport(build_failures=[], test_failures=[], runtime_exceptions=[], coverage_gaps=[]),
        pr_url=pr_url,
        regression=regression,
        quality_gate=quality_gate,
        usage=usage,
        duration_seconds=round(duration_seconds, 2)
    )


def _run_full_pipeline_core(
    *,
    repo_path: str,
    repo_url: str,
    run_id: str,
    cfg_data_dir: str,
    aws_region: str,
    bedrock_model_id: str,
    bedrock_embed_model_id: str,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    github_token: str | None,
    github_username: str | None,
    github_email: str | None,
    logger: RunLogger,
    create_pr: bool,
    quality_gate_min_coverage_pct: float = 60.0,
    quality_gate_max_failures: int = 0,
    create_github_issues_for_failures: bool = False,
    preferred_classes_override: list[dict] | None = None,
    run_validation: bool = True,
) -> FullRunReport:
    state_mgr = PipelineStateManager(repo_path)
    # Ensure coverage threshold is set if needed
    if state_mgr.status.coverage_threshold != quality_gate_min_coverage_pct:
        state_mgr.update(coverage_threshold=quality_gate_min_coverage_pct)
        
    if not state_mgr.status.baseline_completed:
        logger.info("[Orchestrator] Starting Baseline Testing Phase")
        baseline_report = _run_baseline_phase(
            repo_path=repo_path,
            repo_url=repo_url,
            run_id=run_id,
            state_mgr=state_mgr,
            logger=logger,
            aws_region=aws_region,
            bedrock_model_id=bedrock_model_id,
            bedrock_embed_model_id=bedrock_embed_model_id or "amazon.titan-embed-text-v1",
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token,
        )
        # If baseline build failed, return the baseline report (no point running validation)
        if not state_mgr.status.baseline_completed:
            logger.warning("[Orchestrator] Baseline did not complete successfully. Skipping validation phase.")
            return baseline_report
        
        # If run_validation is False (initial scan), return baseline report only
        if not run_validation:
            logger.info("[Orchestrator] Baseline completed. Returning baseline-only report (run_validation=False).")
            return baseline_report
            
        logger.info("[Orchestrator] Baseline completed. Continuing to Validation Testing Phase...")

    # Run validation phase (test generation + coverage analysis)
    logger.info("[Orchestrator] Starting Validation Testing Phase")
    return _run_validation_phase(
        repo_path=repo_path,
        repo_url=repo_url,
        run_id=run_id,
        state_mgr=state_mgr,
        logger=logger,
        aws_region=aws_region,
        bedrock_model_id=bedrock_model_id,
        bedrock_embed_model_id=bedrock_embed_model_id or "amazon.titan-embed-text-v1",
        cfg_data_dir=cfg_data_dir,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token,
        create_pr=create_pr,
        github_token=github_token,
        github_username=github_username,
        github_email=github_email,
        quality_gate_min_coverage_pct=quality_gate_min_coverage_pct,
        quality_gate_max_failures=quality_gate_max_failures,
    )



def evaluate_quality_gate(
    coverage: CoverageReport, 
    unit: TestReport, 
    min_coverage_pct: float, 
    max_failures_allowed: int
) -> QualityGateReport:
    """Evaluates release readiness based on coverage and test metrics."""
    reasons = []
    
    # Coverage check
    current_cov = coverage.instruction_covered_pct or 0.0
    coverage_ok = current_cov >= min_coverage_pct
    if not coverage_ok:
        reasons.append(f"Coverage {current_cov:.1f}% is below threshold {min_coverage_pct:.1f}%")
    else:
        reasons.append(f"Coverage {current_cov:.1f}% meets threshold {min_coverage_pct:.1f}%")
        
    # Failure check
    failures_ok = unit.failed <= max_failures_allowed
    if not failures_ok:
        reasons.append(f"Found {unit.failed} test failures, exceeding limit of {max_failures_allowed}")
    else:
        reasons.append(f"Test failures ({unit.failed}) within allowed limit ({max_failures_allowed})")
        
    passed = coverage_ok and failures_ok
    
    recommendation = "release_ready" if passed else "do_not_release"
    if passed and current_cov < min_coverage_pct + 5.0:
        recommendation = "release_with_caution" # Close to threshold
        
    return QualityGateReport(
        passed=passed,
        min_coverage_pct=min_coverage_pct,
        max_failures_allowed=max_failures_allowed,
        reasons=reasons,
        release_recommendation=recommendation
    )

def calculate_regression_report(
    state_mgr: PipelineStateManager,
    current_unit: TestReport,
    current_coverage: CoverageReport,
    post_gen_ok: bool,
    repo_path: str, # project root
) -> RegressionReport:
    """Compares current run against baseline to detect regressions and improvements."""
    passed_keys, failed_keys = get_passed_and_failed_test_keys(repo_path)
    
    baseline_passed_keys = set(state_mgr.status.baseline_passed_test_keys)
    current_passed_keys = set(passed_keys)
    current_failed_keys = set(failed_keys)
    current_all_keys = current_passed_keys | current_failed_keys
    
    # TRUE regressions: tests that passed at baseline AND are present in the
    # current run but are now FAILING.  Tests that were intentionally deleted
    # (absent from the current run) are NOT regressions.
    regressions = list(baseline_passed_keys & current_failed_keys)
    
    # New failures: newly generated or existing tests that failed in this run
    new_failures = [f"{f.get('classname', '')}#{f.get('name', '')}" for f in current_unit.failed_tests]
    
    return RegressionReport(
        baseline_total=state_mgr.status.baseline_total_tests,
        baseline_passed=len(state_mgr.status.baseline_passed_test_keys),
        after_total=current_unit.total,
        after_passed=current_unit.total - current_unit.failed - current_unit.errors,
        regressions=regressions,
        new_failures=new_failures,
        after_run_ok=post_gen_ok,
        baseline_coverage_pct=state_mgr.status.baseline_coverage,
        after_coverage_pct=current_coverage.instruction_covered_pct
    )



def _calculate_usage(llm: BedrockClient) -> UsageReport:
    """Calculates usage and estimated cost from BedrockClient metrics."""
    # Prices per 1M tokens (Current AWS Bedrock US East - N. Virginia)
    # Claude 3.5 Sonnet
    SONNET_INPUT_RATE = 3.00
    SONNET_OUTPUT_RATE = 15.00
    
    # Claude 3.0 Haiku (if used in future)
    HAIKU_INPUT_RATE = 0.25
    HAIKU_OUTPUT_RATE = 1.25
    
    # Titan Text Embeddings v2
    TITAN_EMBED_RATE = 0.02 # $0.02 per 1M tokens
    
    # Determine rates based on model
    model_id = llm.cfg.model_id.lower()
    in_rate = SONNET_INPUT_RATE
    out_rate = SONNET_OUTPUT_RATE
    
    if "haiku" in model_id:
        in_rate = HAIKU_INPUT_RATE
        out_rate = HAIKU_OUTPUT_RATE
        
    in_cost = (getattr(llm, "total_input_tokens", 0) / 1_000_000) * in_rate
    out_cost = (getattr(llm, "total_output_tokens", 0) / 1_000_000) * out_rate
    embed_cost = (getattr(llm, "total_embedding_tokens", 0) / 1_000_000) * TITAN_EMBED_RATE
    
    total_cost = in_cost + out_cost + embed_cost
    
    return UsageReport(
        input_tokens=llm.total_input_tokens,
        output_tokens=llm.total_output_tokens,
        estimated_cost_usd=round(total_cost, 4)
    )


def _default_pr_body(generation: GenerationReport, coverage: CoverageReport, breakage: BreakageReport, usage: UsageReport | None = None) -> str:
    cov = "n/a"
    if coverage.instruction_covered_pct is not None:
        cov = f"{coverage.instruction_covered_pct}% instructions"
        if coverage.branch_covered_pct is not None:
            cov += f", {coverage.branch_covered_pct}% branches"

    files = "\n".join([f"- `{p}`" for p in generation.generated_files]) or "- (none)"

    failures = []
    if breakage.build_failures:
        failures.append("**Build**:\n" + "\n".join(f"- {m}" for m in breakage.build_failures))
    if breakage.test_failures:
        failures.append("**Tests**:\n" + "\n".join(f"- {m}" for m in breakage.test_failures))
    if breakage.runtime_exceptions:
        failures.append("**Runtime**:\n" + "\n".join(f"- {m}" for m in breakage.runtime_exceptions))
    if breakage.coverage_gaps:
        failures.append("**Coverage gaps**:\n" + "\n".join(f"- {m}" for m in breakage.coverage_gaps[:10]))
    failure_block = "\n\n".join(failures) if failures else "No known failures from this run."

    return f"""## Why
This PR adds AI-generated unit tests to improve baseline coverage and catch regressions earlier.

## What changed
### Newly added/updated tests
{files}

## Coverage impact
- Current coverage signal: **{cov}** (JaCoCo, current run)
- Historical baseline coverage is not known; please compare in your usual tooling.

## Known issues / breakage from this run
{failure_block}

## Notes / limitations
- Generated tests prioritize compilability and readability; deeper behavioral assertions may require manual refinement.
- Some failures may be pre-existing in the repository; this PR focuses on tests, not business-logic fixes.

## Cost Observability (AI Usage)
- **Input Tokens**: {usage.input_tokens if usage else 0}
- **Output Tokens**: {usage.output_tokens if usage else 0}
- **Estimated Cost**: ${usage.estimated_cost_usd if usage else 0.0:.4f} USD
"""
