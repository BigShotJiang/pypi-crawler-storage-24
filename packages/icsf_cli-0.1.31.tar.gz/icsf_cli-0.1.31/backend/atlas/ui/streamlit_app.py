from __future__ import annotations

import json
import os
import re
from typing import Any

import pandas as pd
import streamlit as st

from atlas.core.config import load_config
from atlas.core.logging import RunLogger
from atlas.gitops.github_org import is_organization_url
from atlas.orchestrator.run_pipeline import run_full_pipeline, run_organization_pipeline
from atlas.reporting.models import OrganizationRunReport


st.set_page_config(page_title="Atlas", layout="wide", initial_sidebar_state="expanded")

# Strip ANSI escape codes so Maven output is readable in the UI
_ANSI_ESCAPE = re.compile(r"\x1b\[[0-9;]*m|\u001b\[[0-9;]*m")

# Enterprise dashboard styling
_DASHBOARD_CSS = """
<style>
/* Dashboard container */
div[data-testid="stVerticalBlock"] > div:has(> div[data-testid="stMarkdown"]) .stMarkdown { font-family: 'Segoe UI', system-ui, sans-serif; }
/* Metric cards - subtle card feel */
[data-testid="stMetric"] {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    padding: 1rem 1.25rem;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}
[data-testid="stMetric"] label { font-size: 0.8rem; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.02em; }
[data-testid="stMetric"] [data-testid="stMetricValue"] { font-size: 1.5rem; font-weight: 700; color: #0f172a; }
/* Section headers */
h2.dashboard-section { font-size: 1.1rem; font-weight: 600; color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 0.5rem; margin-top: 1.5rem; margin-bottom: 1rem; }
h3.dashboard-sub { font-size: 1rem; font-weight: 600; color: #334155; margin-top: 1rem; margin-bottom: 0.5rem; }
/* Explanation text */
p.dashboard-desc { font-size: 0.9rem; color: #64748b; line-height: 1.5; margin-bottom: 1rem; }
/* Status badges */
span.status-ok { color: #059669; font-weight: 600; }
span.status-fail { color: #dc2626; font-weight: 600; }
span.status-warn { color: #d97706; font-weight: 600; }
/* Pipeline running animation */
@keyframes pipeline-spin { to { transform: rotate(360deg); } }
@keyframes pipeline-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
.pipeline-running-box {
    display: flex; align-items: center; gap: 1rem; padding: 1.25rem 1.5rem;
    background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
    border: 1px solid #a7f3d0; border-radius: 10px; margin: 0.5rem 0;
}
.pipeline-running-box .pipeline-spinner {
    width: 28px; height: 28px; border: 3px solid #d1fae5; border-top-color: #059669;
    border-radius: 50%; animation: pipeline-spin 0.9s linear infinite; flex-shrink: 0;
}
.pipeline-running-box .pipeline-text { font-weight: 600; color: #065f46; animation: pipeline-pulse 1.5s ease-in-out infinite; }
</style>
"""


def _strip_ansi(text: str) -> str:
    return _ANSI_ESCAPE.sub("", text) if text else ""


def _init_state() -> None:
    st.session_state.setdefault("last_report", None)
    st.session_state.setdefault("pipeline_error", None)


def main() -> None:
    _init_state()
    cfg = load_config()

    st.markdown(_DASHBOARD_CSS, unsafe_allow_html=True)
    st.title("Atlas")
    st.caption("Java Test & Coverage Platform — Run pipeline, view metrics, and analyze reports.")

    with st.sidebar:
        st.subheader("Configuration")
        st.text_input("AWS Region", value=cfg.aws_region, disabled=True)
        st.text_input("Bedrock Model", value=cfg.bedrock_model_id, disabled=True)
        st.text_input("Bedrock Embed Model", value=cfg.bedrock_embed_model_id, disabled=True)
        st.toggle("Create GitHub PR (requires GITHUB_TOKEN)", value=False, key="create_pr")
        st.toggle("Create GitHub issues for test failures (QA defect mgmt)", value=cfg.create_github_issues_for_failures, key="create_issues")

    repo_or_org_url = st.text_input(
        "Repository or Organization URL",
        placeholder="https://github.com/org/repo.git or https://github.com/orgname",
        help="Single repo: https://github.com/owner/repo. Whole org: https://github.com/orgname (scans all repos; needs GITHUB_TOKEN).",
    )

    # Run pipeline in the main thread: when it finishes, the same run renders the report (no refresh)
    if st.button("Run pipeline", type="primary", disabled=not repo_or_org_url):
        st.session_state["last_report"] = None
        st.session_state["pipeline_error"] = None
        logger = RunLogger(emit=lambda line: print(line, flush=True))
        url = repo_or_org_url.strip()
        is_org = is_organization_url(url)
        with st.spinner("Organization scan: listing repos…" if is_org else "Pipeline is running…"):
            try:
                if is_org:
                    report = run_organization_pipeline(
                        org_url=url,
                        cfg_data_dir=cfg.data_dir,
                        cfg_runs_dir=cfg.runs_dir,
                        aws_region=cfg.aws_region,
                        aws_access_key_id=cfg.aws_access_key_id,
                        aws_secret_access_key=cfg.aws_secret_access_key,
                        aws_session_token=cfg.aws_session_token,
                        bedrock_model_id=cfg.bedrock_model_id,
                        bedrock_embed_model_id=cfg.bedrock_embed_model_id,
                        github_token=cfg.github_token,
                        github_username=cfg.github_username,
                        github_email=cfg.github_email,
                        logger=logger,
                        create_pr=bool(st.session_state.get("create_pr", False)),
                        max_repos=50,
                        quality_gate_min_coverage_pct=0.0,
                        quality_gate_max_failures=0,
                        create_github_issues_for_failures=bool(st.session_state.get("create_issues", False)),
                    )
                else:
                    report = run_full_pipeline(
                        repo_url=url,
                        cfg_data_dir=cfg.data_dir,
                        cfg_runs_dir=cfg.runs_dir,
                        aws_region=cfg.aws_region,
                        aws_access_key_id=cfg.aws_access_key_id,
                        aws_secret_access_key=cfg.aws_secret_access_key,
                        aws_session_token=cfg.aws_session_token,
                        bedrock_model_id=cfg.bedrock_model_id,
                        bedrock_embed_model_id=cfg.bedrock_embed_model_id,
                        github_token=cfg.github_token,
                        github_username=cfg.github_username,
                        github_email=cfg.github_email,
                        logger=logger,
                        create_pr=bool(st.session_state.get("create_pr", False)),
                        quality_gate_min_coverage_pct=0.0,
                        quality_gate_max_failures=0,
                        create_github_issues_for_failures=bool(st.session_state.get("create_issues", False)),
                    )
                st.session_state["last_report"] = report
            except Exception as e:
                logger.error(f"Pipeline failed: {e}")
                st.session_state["pipeline_error"] = str(e)
        st.rerun()

    pipeline_error = st.session_state.get("pipeline_error")
    if pipeline_error:
        st.error(f"❌ Pipeline failed: {pipeline_error}")
        st.session_state["pipeline_error"] = None

    report = st.session_state.get("last_report")
    if report:
        if isinstance(report, OrganizationRunReport):
            _render_organization_report(report)
        else:
            _render_enterprise_report(report)


def _render_enterprise_report(report) -> None:
    """Render the full pipeline report as an enterprise-style dashboard with metrics and clear sections."""
    # ----- Header -----
    st.divider()
    st.markdown("## 📊 Pipeline Report")
    repo_col1, repo_col2 = st.columns([3, 1])
    with repo_col1:
        st.markdown(f"**Repository:** [{report.repo_url}]({report.repo_url})")
    with repo_col2:
        st.markdown(f"**Run ID:** `{report.run_id}`")
        if getattr(report, "duration_seconds", None):
            duration = report.duration_seconds
            if duration < 60:
                d_str = f"{duration:.1f}s"
            else:
                m = int(duration // 60)
                s = int(duration % 60)
                d_str = f"{m}m {s}s"
            st.markdown(f"**Run Time:** `{d_str}`")

    # ----- KPI Row -----
    total = report.unit.total
    passed = max(0, total - report.unit.failed - report.unit.errors)
    coverage_pct = report.coverage.instruction_covered_pct or 0.0
    pass_rate = (passed / total * 100) if total > 0 else 0.0

    kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
    with kpi1:
        st.metric(
            label="Build",
            value="Passed" if report.build.ok else "Failed",
            delta=None,
        )
    with kpi2:
        st.metric(
            label="Tests",
            value=report.unit.total,
            delta=f"{passed} passed" if total > 0 else None,
        )
    with kpi3:
        st.metric(
            label="Pass rate",
            value=f"{pass_rate:.1f}%" if total > 0 else "—",
            delta=f"{report.unit.failed + report.unit.errors} failed" if (report.unit.failed + report.unit.errors) > 0 else None,
        )
    with kpi4:
        st.metric(
            label="Instruction coverage",
            value=f"{coverage_pct:.1f}%" if report.coverage.jacoco_found else "—",
            delta=f"Branch: {report.coverage.branch_covered_pct:.1f}%" if report.coverage.branch_covered_pct is not None else None,
        )
    with kpi5:
        gen_count = len(report.generation.generated_files)
        new_count = len(getattr(report.generation, "new_tests", []))
        upd_count = len(getattr(report.generation, "updated_tests", []))
        st.metric(
            label="Generated unit tests",
            value=gen_count,
            delta=f"{new_count} new, {upd_count} updated" if gen_count > 0 else None,
        )

    # ----- Executive summary -----
    build_verb = "succeeded" if report.build.ok else "failed"
    test_verb = "all passed" if report.unit.ok else f"{report.unit.failed + report.unit.errors} failed"
    summary_lines = [
        f"The pipeline **build {build_verb}**. "
        f"Unit tests: **{test_verb}** ({report.unit.total} total). "
    ]
    if report.coverage.jacoco_found and report.coverage.instruction_covered_pct is not None:
        summary_lines.append(
            f"Instruction coverage is **{report.coverage.instruction_covered_pct:.1f}%**"
            + (f", branch coverage **{report.coverage.branch_covered_pct:.1f}%**." if report.coverage.branch_covered_pct is not None else ".")
        )
    else:
        summary_lines.append("Coverage data was not available for this run.")
    if report.pr_url:
        summary_lines.append(f" A [pull request]({report.pr_url}) was created.")
    if getattr(report, "quality_gate", None) and getattr(report.quality_gate, "release_recommendation", None):
        rec = report.quality_gate.release_recommendation
        if rec == "do_not_release":
            summary_lines.append(" **Release recommendation: Do not release.**")
        elif rec == "release_with_caution":
            summary_lines.append(" **Release recommendation: Release with caution.**")
        elif rec == "release_ready":
            summary_lines.append(" **Release recommendation: Release ready.**")
    st.info(" ".join(summary_lines))

    # ----- 1. Repository & configuration -----
    st.markdown("### 1. Repository & configuration")
    st.caption("Project setup: repository, build system, languages, and pre-flight checks. These are not test results—they confirm the project is ready for the pipeline.")
    r1, r2 = st.columns(2)
    with r1:
        with st.container():
            st.markdown("**Build & test stack**")
            build_system = report.facts.get("build_system") or "—"
            languages = report.facts.get("languages", []) or []
            test_frameworks = report.facts.get("test_frameworks", []) or []
            st.markdown(f"- Build system: `{build_system}`")
            st.markdown(f"- Languages: {', '.join(languages) or '—'}")
            st.markdown(f"- Test frameworks: {', '.join(test_frameworks) or '—'}")
            st.markdown(f"- Existing test files: **{report.sanity.get('existing_test_files', 0)}**")
    with r2:
        st.markdown("**Pre-flight checks**")
        repo_has_pom = report.sanity.get("repo_has_pom", False)
        st.markdown("✅ pom.xml found" if repo_has_pom else "❌ pom.xml not found")
        for check in report.sanity.get("sanity_checks", []):
            st.markdown(f"- {check}")

    # ----- 2. Build status -----
    st.markdown("### 2. Build status")
    st.caption("Result of `mvn clean install`. If the build failed, key error lines and full output are shown below.")
    if report.build.ok:
        st.success("Build completed successfully.")
        st.code(" ".join(report.build.cmd), language="bash")
    else:
        st.error("Build failed.")
        raw_output = getattr(report.build, "output_tail", None) or report.build.stderr_tail
        if raw_output:
            build_output = _strip_ansi(raw_output)
            all_error_lines = [
                line.strip() for line in build_output.splitlines()
                if line.strip() and re.search(r"ERROR|FAILURE|FAILED|Exception|error", line, re.IGNORECASE)
            ]
            compilation_lines = [
                line for line in all_error_lines
                if ".java:" in line or "COMPILATION ERROR" in line or "Compilation failure" in line
            ]
            key_lines = compilation_lines[:10] if compilation_lines else all_error_lines[-8:]
            if key_lines:
                st.markdown("**Key error messages (likely cause):**")
                for line in key_lines:
                    if len(line) < 500:
                        st.code(line, language=None)
            with st.expander("View full Maven build output (stdout + stderr)"):
                st.code(build_output, language=None)
        else:
            st.warning("No build output was captured. Check Docker or runner logs for Maven output.")

    # ----- 3. Test execution (after adding generated tests) -----
    st.markdown("### 3. Test execution — run after adding generated tests")
    st.caption("Counts from the run **after** new tests were added. Compare with **Baseline** and **Regressions** in section 6 below.")
    if total > 0:
        t1, t2 = st.columns([1, 1])
        with t1:
            st.markdown(f"- **Passed:** {passed}")
            st.markdown(f"- **Failed:** {report.unit.failed}")
            st.markdown(f"- **Errors:** {report.unit.errors}")
            if report.unit.skipped:
                st.markdown(f"- **Skipped:** {report.unit.skipped}")
        with t2:
            test_df = pd.DataFrame({
                "Status": ["Passed", "Failed", "Errors"],
                "Count": [passed, report.unit.failed, report.unit.errors],
            })
            st.bar_chart(test_df.set_index("Status")["Count"], color="#0ea5e9", height=220)
    else:
        st.info("No tests were executed (e.g. build failed or no tests found).")

    # ----- 4. Code coverage -----
    st.markdown("### 4. Code coverage")
    st.caption("JaCoCo instruction and branch coverage for this run. Use this to see where to add or improve tests.")
    if report.coverage.jacoco_found and report.coverage.instruction_covered_pct is not None:
        c1, c2 = st.columns(2)
        with c1:
            inst_cov = report.coverage.instruction_covered_pct
            st.markdown(f"**Instruction coverage: {inst_cov:.2f}%**")
            st.progress(inst_cov / 100.0)
            if inst_cov >= 80:
                st.success("Target coverage met (≥80%).")
            elif inst_cov >= 60:
                st.info("Moderate coverage; consider adding tests for uncovered paths.")
            else:
                st.warning("Low coverage; prioritize tests for critical and uncovered code.")
        with c2:
            branch_cov = report.coverage.branch_covered_pct
            if branch_cov is not None:
                st.markdown(f"**Branch coverage: {branch_cov:.2f}%**")
                st.progress(branch_cov / 100.0)
                if branch_cov >= 80:
                    st.success("Good branch coverage.")
                elif branch_cov >= 60:
                    st.info("Some branches uncovered.")
                else:
                    st.warning("Low branch coverage.")
            else:
                st.info("Branch coverage not available.")
    else:
        st.info("Coverage data was not produced (e.g. build failed or JaCoCo not run).")

    # ----- 5. Unit test generation details -----
    st.markdown("### 5. Unit test generation details")
    st.caption("AI-generated unit tests. 'New' = created new file; 'Updated' = appended methods to existing test file.")
    
    if report.generation.generated_files:
        tabs = st.tabs(["Summary", f"New ({len(getattr(report.generation, 'new_tests', []))})", f"Updated ({len(getattr(report.generation, 'updated_tests', []))})"])
        
        with tabs[0]:
            if report.generation.summary:
                st.info(report.generation.summary)
            st.success(f"Total {len(report.generation.generated_files)} unit test files processed.")
            
        with tabs[1]:
            new_list = getattr(report.generation, "new_tests", [])
            summaries = getattr(report.generation, "file_summaries", {})
            if new_list:
                for p in new_list:
                    s = summaries.get(p, {})
                    passed = s.get("passed", 0)
                    failed = s.get("failed", 0)
                    errors = s.get("errors", 0)
                    
                    if passed == 0 and failed == 0 and errors == 0:
                        badge = " :grey[(no executed tests found)]"
                    else:
                        badge = f" :green[({passed} passed)]" if passed > 0 else ""
                        if (failed + errors) > 0:
                            badge += f" :red[({failed+errors} failed)]"
                        elif passed == 0:
                            badge = " :grey[(0 passed)]" # Edge case if both branches skipped but want something shown
                            
                    st.markdown(f"🆕 `{p}`{badge}")
            else:
                st.caption("No new test files created.")
                
        with tabs[2]:
            upd_list = getattr(report.generation, "updated_tests", [])
            summaries = getattr(report.generation, "file_summaries", {})
            if upd_list:
                for p in upd_list:
                    s = summaries.get(p, {})
                    passed = s.get("passed", 0)
                    failed = s.get("failed", 0)
                    errors = s.get("errors", 0)
                    
                    if passed == 0 and failed == 0 and errors == 0:
                        badge = " :grey[(no executed tests found)]"
                    else:
                        badge = f" :green[({passed} passed)]" if passed > 0 else ""
                        if (failed + errors) > 0:
                            badge += f" :red[({failed+errors} failed)]"
                        elif passed == 0:
                            badge = " :grey[(0 passed)]"
                            
                    st.markdown(f"🆙 `{p}`{badge}")
            else:
                st.caption("No existing test files were updated.")
    else:
        st.info("No unit tests were generated or updated.")

    # ----- 6. Baseline → After → With regression -----
    if getattr(report, "regression", None):
        reg = report.regression
        st.markdown("### 6. Test results: Baseline → After → With regression")
        st.caption("Baseline = run before new tests. After = run with ALL tests (baseline + generated/updated). Regressions = tests that passed at baseline but failed after. Atlas heals failures; unfixable generated tests are removed to ensure a clean final run.")
        r1, r2, r3 = st.columns(3)
        with r1:
            st.markdown("**Baseline**")
            if reg.baseline_total == 0 and getattr(report, "build", None) and not getattr(report.build, "ok", True):
                st.warning("Not run (build failed before tests)")
            else:
                st.metric("Tests", reg.baseline_total, f"{reg.baseline_passed} passed")
        with r2:
            st.markdown("**After**")
            if reg.after_total > 0:
                st.metric("Tests", reg.after_total, f"{reg.after_passed} passed")
                if not getattr(reg, "after_run_ok", True):
                    st.caption("(some tests failed)")
            else:
                st.error("Run did not complete")
                st.caption("(compile or setup failure)")
        with r3:
            st.markdown("**With regression**")
            if reg.after_total == 0 and not getattr(reg, "after_run_ok", True):
                st.caption("N/A — after run failed")
            else:
                n = len(reg.regressions)
                st.metric("Regressions", n, "passed before, failed now" if n else "None", help="Regressions are EXISTING tests that passed at baseline but began failing after new tests were added.")
        if not reg.regressions and not reg.new_failures and reg.after_total > 0:
            st.success("No regressions detected; baseline behavior preserved.")
        elif getattr(reg, "after_run_ok", True) and reg.after_total == 0 and reg.baseline_total > 0:
            st.info("After run completed but no tests were reported (e.g. only integration tests ran).")

        # Consolidated Failure Summary Log
        all_failures = []
        # Add regressions
        for key in reg.regressions:
            reason = "No details found (existing test)."
            if report.defects and report.defects.defects:
                for d in report.defects.defects:
                    if d.get("test") == key.replace("#", "."):
                        reason = d.get("actual", reason)
                        break
            all_failures.append({"name": key.replace("#", "."), "type": "Regression", "reason": reason})
        
        # Add new failures
        for name in reg.new_failures:
            reason = "No details found."
            if report.defects and report.defects.defects:
                for d in report.defects.defects:
                    if d.get("test") == name:
                        reason = d.get("actual", reason)
                        break
            all_failures.append({"name": name, "type": "New Test Failure", "reason": reason})

        if all_failures:
            st.markdown("#### 📝 Failure Summary Log")
            st.caption("Consolidated log of all test failures and their root causes.")
            for f in all_failures:
                with st.expander(f"FAILED: {f['name']} ({f['type']})"):
                    st.error(f"**Failure Reason:**")
                    st.code(f['reason'], language="text")
    # Quality gate section removed as per user request to simplify and remove filters.
    if getattr(report, "test_strategy", None):
        ts = report.test_strategy
        st.markdown("### 7. Test strategy (QA)")
        st.caption("What was targeted and why — risk-based test design.")
        st.markdown(f"- **Low-coverage classes targeted:** {ts.targeted_low_coverage_classes}")
        st.info(ts.rationale)

    # ----- QA: Quality gate (release readiness) -----
    if getattr(report, "quality_gate", None):
        qg = report.quality_gate
        st.markdown("### 9. Quality gate — release readiness (QA)")
        st.caption("Pass/fail against configurable thresholds (sign-off).")
        st.metric("Result", "PASS" if qg.passed else "FAIL", None)
        rec = getattr(qg, "release_recommendation", None)
        if rec == "do_not_release":
            st.error("**Release recommendation: Do not release** — Build failed, regressions detected, and/or coverage decreased (must increase).")
        elif rec == "release_with_caution":
            st.warning("**Release recommendation: Release with caution** — Quality gate or defects present; verify before release.")
        elif rec == "release_ready":
            st.success("**Release recommendation: Release ready** — Quality gate passed, no regressions.")
        for r in qg.reasons:
            st.markdown(f"- {r}")

    # ----- QA: Defects (defect management) -----
    if getattr(report, "defects", None) and report.defects.defects:
        st.markdown("### 10. Defect report (QA)")
        st.caption("Structured defects from test failures; GitHub issues created if enabled.")
        for d in report.defects.defects[:15]:
            with st.expander(f"{d.get('title', '')[:60]} — {d.get('severity', '')}"):
                st.markdown(f"**Test:** `{d.get('test', '')}`")
                st.markdown("**Steps:**")
                st.markdown(d.get("steps", ""))  # may contain markdown (e.g. **To reproduce:**)
                st.markdown(f"**Expected:** {d.get('expected', '')}")
                st.markdown(f"**Actual:** {d.get('actual', '')[:500]}")
        if report.defects.github_issues_created:
            st.success(f"**GitHub issues created:** {len(report.defects.github_issues_created)} (capped at 10 to avoid repo spam)")
            for u in report.defects.github_issues_created[:5]:
                st.markdown(f"- [{u}]({u})")

    # ----- QA: Security -----
    if getattr(report, "security", None) and report.security.run:
        st.markdown("### 11. Security scan (QA)")
        st.caption("Dependency tree and optional OWASP dependency-check.")
        st.markdown(report.security.summary)
        if report.security.vulnerabilities:
            for v in report.security.vulnerabilities[:15]:
                sev = v.get("severity", "unknown")
                st.markdown(f"**{sev}:** `{v.get('cve', '')[:120]}`")

    # ----- 12. Failure & gap analysis -----
    st.markdown("### 12. Failure & gap analysis")
    st.caption("Classified build failures, test failures, runtime exceptions, and coverage gaps to help fix issues and prioritize tests.")
    has_failures = (
        report.breakage.build_failures
        or report.breakage.test_failures
        or report.breakage.runtime_exceptions
        or report.breakage.coverage_gaps
        or not report.build.ok
    )
    if not has_failures:
        st.success("No failures or gaps detected; build and tests passed.")
    else:
        if report.breakage.build_failures:
            st.error("**Build failures**")
            for m in report.breakage.build_failures:
                st.code(_strip_ansi(m), language=None)
        elif not report.build.ok:
            st.error("**Build failures** — see section 2 for key error messages and full output.")
        if report.breakage.test_failures:
            st.warning("**Test failures**")
            for m in report.breakage.test_failures:
                st.markdown(f"- {m}")
        if report.breakage.runtime_exceptions:
            st.error("**Runtime exceptions**")
            for m in report.breakage.runtime_exceptions:
                st.markdown(f"- {m}")
        if report.breakage.coverage_gaps:
            st.info("**Coverage gaps** (classes or areas with low coverage)")
            for m in report.breakage.coverage_gaps[:15]:
                st.markdown(f"- {m}")

    # ----- 13. Class-level coverage -----
    if report.coverage.per_class:
        st.markdown("### 13. Class-level coverage")
        st.caption("Per-class instruction and branch coverage. Lowest-covered classes are good candidates for new tests.")
        low = sorted(
            report.coverage.per_class[:25],
            key=lambda c: c.get("instruction_covered_pct") or 0.0,
        )[:10]
        if low:
            chart_data = []
            for cls in low:
                inst = cls.get("instruction_covered_pct") or 0.0
                branch = cls.get("branch_covered_pct") or 0.0
                name = (cls.get("class") or "N/A")
                chart_data.append({"Class": name, "Instruction %": inst, "Branch %": branch})
            df = pd.DataFrame(chart_data)
            st.bar_chart(df.set_index("Class")[["Instruction %", "Branch %"]], height=320)
            with st.expander("Detailed coverage table (package, class, instruction %, branch %)"):
                rows = []
                for cls in report.coverage.per_class[:25]:
                    pkg = cls.get("package", "N/A")
                    cl = cls.get("class", "N/A")
                    inst = cls.get("instruction_covered_pct")
                    br = cls.get("branch_covered_pct")
                    rows.append({
                        "Package": pkg,
                        "Class": cl,
                        "Instruction %": f"{inst:.2f}%" if inst is not None else "N/A",
                        "Branch %": f"{br:.2f}%" if br is not None else "N/A",
                    })
                st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)

    # ----- PR link -----
    if report.pr_url:
        st.success(f"**Pull request created:** [{report.pr_url}]({report.pr_url})")

    # ----- Raw JSON -----
    with st.expander("Raw report (JSON)"):
        st.code(json.dumps(_to_json(report), indent=2))


def _render_organization_report(org_report: OrganizationRunReport) -> None:
    """Render organization-wide scan: summary metrics and per-repo expanders."""
    st.divider()
    st.markdown("## 📊 Organization Scan Report")
    st.markdown(f"**Organization:** [{org_report.org_url}]({org_report.org_url}) — **{org_report.org_name}**")
    st.caption(f"Scanned **{org_report.total_repos}** repo(s). Regression-focused pipeline run on each.")

    # ----- Org-level KPIs -----
    k1, k2, k3, k4, k5 = st.columns(5)
    with k1:
        st.metric("Repos scanned", org_report.total_repos, None)
    with k2:
        st.metric("Repos OK", org_report.repos_ok, f"{org_report.repos_failed} failed" if org_report.repos_failed else None)
    with k3:
        st.metric("Total tests run", org_report.total_tests_run, None)
    with k4:
        passed_pct = (org_report.total_tests_passed / org_report.total_tests_run * 100) if org_report.total_tests_run else 0
        st.metric("Tests passed", org_report.total_tests_passed, f"{passed_pct:.1f}%" if org_report.total_tests_run else None)
    with k5:
        st.metric("Generated tests", org_report.total_generated, "new files" if org_report.total_generated else None)

    st.info(
        f"**Summary:** {org_report.repos_ok} repo(s) passed build and tests, {org_report.repos_failed} had failures. "
        f"Total **{org_report.total_tests_run}** tests run, **{org_report.total_tests_passed}** passed. "
        f"**{org_report.total_generated}** new test file(s) generated across the org."
    )

    # ----- Per-repo table / expanders -----
    st.markdown("### Per-repository results")
    st.caption("Expand a row to see full pipeline report for that repo (build, tests, coverage, regression, breakage).")
    for i, r in enumerate(org_report.repo_reports):
        passed = max(0, r.unit.total - r.unit.failed - r.unit.errors)
        status = "✅" if r.build.ok and r.unit.ok else "❌"
        with st.expander(f"{status} [{r.repo_url}]({r.repo_url}) — tests: {r.unit.total}, passed: {passed}, generated: {len(r.generation.generated_files)}"):
            _render_enterprise_report(r)


def _to_json(obj: Any) -> Any:
    if hasattr(obj, "__dict__"):
        return {k: _to_json(v) for k, v in obj.__dict__.items()}
    if isinstance(obj, list):
        return [_to_json(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _to_json(v) for k, v in obj.items()}
    return obj


if __name__ == "__main__":
    main()

