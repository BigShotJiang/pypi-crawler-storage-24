"""List repositories for a GitHub organization. Used for organization-wide scanning."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from github import Github

if TYPE_CHECKING:
    pass


def is_organization_url(url: str) -> bool:
    """
    Return True if the URL looks like an organization (or user) page,
    i.e. https://github.com/orgname with no repo name after.
    """
    url = (url or "").strip().rstrip("/")
    # github.com/owner/repo -> repo URL (at least two path segments after host)
    # github.com/owner or github.com/owner/ -> org/user
    m = re.match(r"https?://(?:www\.)?github\.com/([^/]+)/?$", url, re.IGNORECASE)
    if m:
        return True
    m = re.match(r"git@github\.com:([^/]+)/?$", url)
    return bool(m)


def is_repo_url(url: str) -> bool:
    """Return True if the URL looks like a single repository (owner/repo)."""
    url = (url or "").strip()
    m = re.search(r"github\.com[:/](?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?$", url, re.IGNORECASE)
    if not m:
        return False
    # repo part must look like a repo name (not "org", "settings", etc.)
    repo = m.group("repo")
    return repo != "" and "." not in repo.split("/")[0]


def extract_org_name(url: str) -> str | None:
    """Extract organization or user name from an org-style URL. None if not an org URL."""
    url = (url or "").strip().rstrip("/")
    m = re.match(r"https?://(?:www\.)?github\.com/([^/]+)/?$", url, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.match(r"git@github\.com:([^/]+)/?$", url)
    if m:
        return m.group(1)
    return None


def list_organization_repos(
    org_name: str,
    token: str,
    *,
    include_private: bool = False,
    only_with_pom: bool = False,
) -> list[str]:
    """
    Return a list of clone URLs (HTTPS) for all repositories in the organization.
    Repos are sorted by name. Only repos the token can access are included.
    include_private: if False, only public repos are considered (API still returns what token can see).
    only_with_pom: if True, we cannot filter by file content via API cheaply; leave False (filter during pipeline).
    """
    gh = Github(token)
    try:
        org = gh.get_organization(org_name)
        repos = list(org.get_repos())
    except Exception:
        # May be a user account, not an org
        try:
            user = gh.get_user(org_name)
            repos = list(user.get_repos())
        except Exception:
            return []

    out: list[str] = []
    for repo in repos:
        if not include_private and repo.private:
            continue
        try:
            clone_url = repo.clone_url or f"https://github.com/{repo.full_name}.git"
            out.append(clone_url)
        except Exception:
            continue
    out.sort(key=lambda u: u.lower())
    return out
