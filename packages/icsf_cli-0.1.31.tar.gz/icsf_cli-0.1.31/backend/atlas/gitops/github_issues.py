"""Create GitHub issues from test failures (QA: defect management)."""

from __future__ import annotations

import re
from dataclasses import dataclass

from github import Github


@dataclass(frozen=True)
class IssueResult:
    created: bool
    url: str | None


def _parse_owner_repo(repo_url: str) -> tuple[str, str] | None:
    m = re.search(r"github\.com[:/](?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?$", repo_url)
    if not m:
        return None
    return m.group("owner"), m.group("repo")


def create_issue_for_failure(
    token: str,
    repo_url: str,
    *,
    title: str,
    body: str,
    labels: list[str] | None = None,
) -> IssueResult:
    """Create a single GitHub issue in the given repo. Returns issue URL or None."""
    parsed = _parse_owner_repo(repo_url)
    if not parsed:
        return IssueResult(created=False, url=None)
    owner, name = parsed
    gh = Github(token)
    try:
        repo = gh.get_repo(f"{owner}/{name}")
        issue = repo.create_issue(title=title[:256], body=body, labels=labels or [])
        return IssueResult(created=True, url=issue.html_url)
    except Exception:
        return IssueResult(created=False, url=None)
