from __future__ import annotations

import logging
import os
import re
import subprocess
from dataclasses import dataclass

from atlas.core.resilience import RateLimiterConfig, rate_limit
from github import Github


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PrResult:
    created: bool
    pr_url: str | None


def _run(cmd: list[str], cwd: str) -> None:
    subprocess.run(cmd, cwd=cwd, check=True, text=True, capture_output=True)


def _parse_owner_repo(repo_url: str) -> tuple[str, str] | None:
    # https://github.com/owner/repo(.git)
    m = re.search(r"github\.com[:/](?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?$", repo_url)
    if not m:
        return None
    return m.group("owner"), m.group("repo")


class GitHubPrService:
    def __init__(self, token: str):
        self.gh = Github(token)
        self.token = token

    def create_branch_commit_pr(
        self,
        *,
        local_repo_path: str,
        repo_url: str,
        branch_name: str,
        commit_message: str,
        pr_title: str,
        pr_body: str,
        git_username: str | None = None,
        git_email: str | None = None,
    ) -> PrResult:
        parsed = _parse_owner_repo(repo_url)
        if not parsed:
            return PrResult(created=False, pr_url=None)
        owner, name = parsed

        # Local git operations (assumes repo was cloned)
        _run(["git", "checkout", "-b", branch_name], cwd=local_repo_path)
        _run(["git", "add", "-A"], cwd=local_repo_path)

        # Commit may fail if no changes
        p = subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=local_repo_path)
        if p.returncode == 0:
            return PrResult(created=False, pr_url=None)

        # Commit with an explicit identity when available so git does not fail
        # with "Please tell me who you are" inside the ephemeral container.
        if git_username and git_email:
            subprocess.run(
                [
                    "git",
                    "-c",
                    f"user.name={git_username}",
                    "-c",
                    f"user.email={git_email}",
                    "commit",
                    "-m",
                    commit_message,
                ],
                cwd=local_repo_path,
                check=True,
                text=True,
                capture_output=True,
            )
        else:
            _run(["git", "commit", "-m", commit_message], cwd=local_repo_path)
        
        # Configure remote URL with token for authentication
        # Construct authenticated HTTPS URL: https://<token>@github.com/owner/repo.git
        auth_url = f"https://{self.token}@github.com/{owner}/{name}.git"
        _run(["git", "remote", "set-url", "origin", auth_url], cwd=local_repo_path)
        
        _run(["git", "push", "-u", "origin", branch_name], cwd=local_repo_path)

        repo = self.gh.get_repo(f"{owner}/{name}")
        default_branch = repo.default_branch
        pr = repo.create_pull(title=pr_title, body=pr_body, head=f"{owner}:{branch_name}", base=default_branch)
        return PrResult(created=True, pr_url=pr.html_url)
