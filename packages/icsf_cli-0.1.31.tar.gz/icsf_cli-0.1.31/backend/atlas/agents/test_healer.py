from __future__ import annotations

import os
import re
from atlas.agents.models import AgentFix, FilePatch, AgentDiagnosis
from atlas.llm.bedrock import BedrockClient
from atlas.core.logging import RunLogger

PREFIX = "TestDoctor: "

class TestHealer:
    """
    Agent responsible for analyzing and fixing runtime test failures (assertion errors, exceptions).
    """

    def __init__(self, llm: BedrockClient, logger: RunLogger):
        self.llm = llm
        self.logger = logger

    def heal(self, failed_tests: list[dict], workspace_path: str) -> list[AgentFix]:
        """
        Analyze failed tests and propose fixes.
        failed_tests: list of dicts from parse_surefire_reports (classname, name, message, text, report_file)
        """
        fixes = []
        
        # Group failures by classname to batch LLM calls
        failures_by_class = {}
        for failure in failed_tests[:10]: # Look at top 10 failures to group
            cls = failure.get("classname")
            if not cls: continue
            if cls not in failures_by_class:
                failures_by_class[cls] = []
            if len(failures_by_class[cls]) < 5: # Max 5 failures per class in prompt
                failures_by_class[cls].append(failure)
                
        # Process a limited number of files (classes) to save tokens/time
        processed_classes = 0
        for classname, failures in failures_by_class.items():
            if processed_classes >= 3:
                break
            processed_classes += 1

            self.logger.info(f"{PREFIX}Analyzing {len(failures)} failure(s) in {classname}...")

            # locate file
            file_path = self._find_test_file(workspace_path, classname)
            if not file_path:
                self.logger.warn(f"{PREFIX}Could not find source file for {classname}")
                continue

            try:
                source_code = open(file_path, "r", encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
                
            # Format failures for prompt
            formatted_failures = ""
            summaries = []
            for f in failures:
                method = f.get("name", "UnknownMethod")
                error_msg = f.get("message") or ""
                stack_trace = f.get("text") or ""
                formatted_failures += f"\nTest: {classname}.{method}\nError: {error_msg}\nStack Trace:\n{stack_trace[:1000]}\n---"
                summaries.append(method)

            # Construct prompt
            prompt = f"""
            You are an expert Java Test Engineer. The following unit test(s) are failing in the same file. Fix the test code.
            
            FAILURES:
            {formatted_failures}

            SOURCE CODE (File: {file_path}):
            ```java
            {source_code}
            ```

            INSTRUCTIONS:
            1. Analyze why the tests failed and FIX THEM ALL in the FIRST TRY.
            2. Return the COMPLETE replacement content for the file. 
            3. Accuracy is paramount. Match DTO types (double vs Money) perfectly.
            4. If the test is testing a void method or verified behavior, ensure mocks are verified.
            5. CRITICAL API RULES:
               - DTOs (AccountCreateRequest, etc.) use 'double' for amounts, NOT 'Money'.
               - Money objects: 'new Money(val, "USD")'. NO no-arg constructor.
               - Account: NO builder(). Use constructor(id, type, balance).
               - TransactionService: methods take (accountId, Money, description).
               - ACCESSOR CONVENTION: Look at existing method calls in the tested file to determine whether to use standard getters (`getEmail()`) or record accessors (`email()`). DO NOT guess.
            6. ASSERTION GUIDELINES:
               - If status().isCreated() fails, try status().isOk().
               - Verify JSON paths carefully: '$.balance' is a double, NOT an object.
            7. SECURITY & 401/403 ERRORS:
               - Use @WithMockUser if auth is needed.
            8. STATIC MOCKING & SpringApplication:
               - When mocking `SpringApplication.run`, use `VerificationMode` carefully. 
               - If verification fails with "Arguments are different", note that `run(Class, String...)` varargs can be tricky. Use `any(String[].class)` or ensure args match exactly.
            9. Output ONLY the raw Java code for the entire file. No markdown blocks.
            """

            try:
                # Call LLM
                new_code = self.llm.generate_text(system="Output complete Java file only.", user=prompt)
                
                # Cleanup markdown formatting aggressively
                if "```java" in new_code:
                    match = re.search(r"```java\s*(.*?)\s*```", new_code, re.DOTALL | re.IGNORECASE)
                    if match:
                        new_code = match.group(1).strip()
                elif "```" in new_code:
                    match = re.search(r"```\w*\s*(.*?)\s*```", new_code, re.DOTALL)
                    if match:
                        new_code = match.group(1).strip()
                
                # Final fallback for backtick noise
                new_code = new_code.replace("```java", "").replace("```", "").strip()
                
                # Basic sanity check
                if "package " not in new_code or "class " not in new_code:
                    self.logger.warn(f"{PREFIX}LLM generated invalid code, skipping.")
                    continue
                
                methods_str = ", ".join(summaries)
                diagnosis = AgentDiagnosis(
                    root_cause=f"Multiple failures in {classname}",
                    confidence=0.8,
                    summary=f"Fixing failures in methods: {methods_str[:50]}..."
                )
                
                fixes.append(AgentFix(
                    diagnosis=diagnosis,
                    explanation=f"Healed tests in {classname}: {methods_str}",
                    file_patches=[FilePatch(path=file_path, content=new_code, mode="overwrite")]
                ))

            except Exception as e:
                self.logger.error(f"{PREFIX}Error healing tests for {classname}: {e}")

        return fixes

    def _find_test_file(self, root: str, classname: str) -> str | None:
        """Find the .java file for a generic classname."""
        path_suffix = classname.replace(".", "/") + ".java"
        for r, d, f in os.walk(root):
            for file in f:
                if file.endswith(".java"):
                    full_path = os.path.join(r, file)
                    if full_path.endswith(os.path.normpath(path_suffix)):
                        return full_path
        return None
