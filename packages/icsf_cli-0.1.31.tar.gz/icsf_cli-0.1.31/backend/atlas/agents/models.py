from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

@dataclass
class FilePatch:
    """Represents a change to a specific file."""
    path: str
    content: str
    mode: Literal["create", "overwrite", "patch"] = "overwrite"
    original_snippet: str | None = None  # For patch mode verification

@dataclass
class AgentDiagnosis:
    """Base class for agent diagnoses."""
    root_cause: str
    confidence: float
    summary: str

@dataclass
class BuildDiagnosis(AgentDiagnosis):
    """Specific diagnosis for build failures."""
    failure_type: Literal["compilation", "compilation_error", "missing_dependency", "missing_file", "dependency_conflict", "network_or_corrupted_artifact", "test_failure", "unknown"]
    error_messages: list[str] = field(default_factory=list)
    missing_files: list[str] = field(default_factory=list)

@dataclass
class AgentFix:
    """A proposed fix from an agent."""
    diagnosis: AgentDiagnosis
    explanation: str
    file_patches: list[FilePatch] = field(default_factory=list)
    shell_commands: list[str] = field(default_factory=list)
