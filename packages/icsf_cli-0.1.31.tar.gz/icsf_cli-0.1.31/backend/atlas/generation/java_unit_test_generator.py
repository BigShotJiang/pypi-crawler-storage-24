from __future__ import annotations

import hashlib
import logging
import os
import re
import uuid
from dataclasses import dataclass

from atlas.analysis.contract_service import extract_referenced_contracts, format_contracts_for_prompt, RepoContractRegistry, validate_constructor_usage
from atlas.llm.bedrock import BedrockClient
from atlas.rag.store import SqliteVectorRagStore

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class GenerationResult:
    generated_files: list[str]
    summary: str
    new_tests: list[str] = None
    updated_tests: list[str] = None


def _strip_code_fences(text: str) -> str:
    """Aggressively strip anything that looks like a markdown code block."""
    t = text.strip()
    # Remove ```java ... ``` blocks
    if "```java" in t:
        match = re.search(r"```java\s*(.*?)\s*```", t, re.DOTALL | re.IGNORECASE)
        if match:
            return match.group(1).strip()
    # Remove any other ``` ... ``` blocks
    if "```" in t:
        match = re.search(r"```\w*\s*(.*?)\s*```", t, re.DOTALL)
        if match:
            return match.group(1).strip()
    # If no blocks found, just strip common backtick noise
    return t.replace("```java", "").replace("```", "").strip()


def _find_module_root(repo_path: str, src_path: str) -> str:
    """Find the nearest directory containing a pom.xml starting from src_path up to repo_path."""
    curr = os.path.dirname(os.path.abspath(src_path))
    repo_abs = os.path.abspath(repo_path)
    while len(curr) >= len(repo_abs):
        if os.path.exists(os.path.join(curr, "pom.xml")):
            return curr
        parent = os.path.dirname(curr)
        if parent == curr:
            break
        curr = parent
    return repo_abs


class JavaUnitTestGenerator:
    """Uses pipeline-injected BedrockClient only (single AI provider). Do not add other AI clients."""

    def __init__(self, *, llm: BedrockClient, rag: SqliteVectorRagStore):
        import asyncio
        self.llm = llm
        self.rag = rag
        self.semaphore = asyncio.Semaphore(5)  # Limit concurrent LLM calls to 5

    async def generate_minimal_tests_for_repo(
        self,
        repo_path: str,
        *,
        target_count: int = 50,
        preferred_classes: list[dict] | None = None,
        repo_url: str | None = None,
        change_reasoning: str | None = None,
        registry: RepoContractRegistry | None = None,
    ) -> GenerationResult:
        """
        Find all main Java classes; update existing test files by adding new methods, or create one test file per class if none exists.
        New tests cover all functionalities (all public methods, branches, edge cases). No new separate files—only update existing *Test.java.
        """
        import asyncio

        main_java = []
        for root, dirs, files in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in {".git", "target", ".idea"}]
            if os.path.join("src", "main", "java") not in root:
                continue
            for f in files:
                if f.endswith(".java") and not f.endswith("Test.java") and not f.endswith("AiTest.java"):
                    main_java.append(os.path.join(root, f))

        # Prefer classes that have low coverage (preferred_classes = [{package, class}, ...])
        if preferred_classes:
            preferred_set = {
                (c.get("package", "").strip(), c.get("class", "").strip())
                for c in preferred_classes
                if c.get("class")
            }
            def score(path: str) -> tuple[int, str]:
                try:
                    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                        code = fh.read()
                except OSError:
                    return (1, path)
                pkg = _infer_package(code)
                cls = _infer_public_class(code) or os.path.splitext(os.path.basename(path))[0]
                return (0 if (pkg, cls) in preferred_set else 1, path)
            main_java.sort(key=score)

        # Cover all functionalities: take up to target_count classes (no skip for existing tests)
        main_java = main_java[: max(1, target_count)]

        generated: list[str] = []
        new_tests: list[str] = []
        updated_tests: list[str] = []

        # Initialize Repo-Wide Contract Registry for Phase 2 if not passed
        if registry is None:
            registry = RepoContractRegistry(repo_path)

        # Parallel generation with semaphore-based throttling
        results = await asyncio.gather(*[self._generate_single_test(src, repo_path, repo_url, change_reasoning, registry=registry) for src in main_java])
        
        for res_path, res_key, is_new in results:
            if res_path:
                generated.append(res_path)
                if is_new:
                    new_tests.append(res_path)
                else:
                    updated_tests.append(res_path)

        summary = f"Generated/Updated {len(generated)} unit tests ({len(new_tests)} New, {len(updated_tests)} Updated) covering all functionalities."
        if not generated:
            summary = "No test files generated or updated."
        return GenerationResult(
            generated_files=generated, 
            new_tests=new_tests, 
            updated_tests=updated_tests, 
            summary=summary
        )

    async def _generate_single_test(self, src: str, repo_path: str, repo_url: str | None, change_reasoning: str | None = None, registry: RepoContractRegistry | None = None) -> tuple[str | None, str | None, bool]:
        """Async helper to generate a single test file. Returns (generated_path, class_key, is_new) or (None, None, False)."""
        rel = os.path.relpath(src, repo_path)
        try:
            import asyncio
            loop = asyncio.get_running_loop()
            def _read_src():
                with open(src, "r", encoding="utf-8", errors="ignore") as fh:
                    return fh.read()
            code = await loop.run_in_executor(None, _read_src)
            current_sha = hashlib.sha256(code.encode("utf-8")).hexdigest()
        except OSError:
            return None, None, False

        pkg = _infer_package(code)
        class_name = _infer_public_class(code) or os.path.splitext(os.path.basename(src))[0]
        class_key = _class_key(repo_path, src)
        
        # FIX: Find the correct module root instead of assuming repo_path
        module_root = _find_module_root(repo_path, src)
        test_rel_dir = os.path.join("src", "test", "java", *(pkg.split(".") if pkg else []))
        test_abs_dir = os.path.join(module_root, test_rel_dir)
        os.makedirs(test_abs_dir, exist_ok=True)
        default_test_path = os.path.join(test_abs_dir, f"{class_name}Test.java")

        # CACHING: Check if test already exists and fingerprint matches
        if os.path.exists(default_test_path):
            fingerprint_id = f"test_fingerprint:{class_key}"
            hit = await loop.run_in_executor(None, lambda: self.rag.get_by_id(fingerprint_id))
            if hit and hit.metadata.get("sha256") == current_sha:
                return default_test_path, class_key, False

        async with self.semaphore:
            # --- Contract extraction (Phase 1 of contract-driven generation) ---
            contracts = await loop.run_in_executor(None, lambda: extract_referenced_contracts(code, repo_path, registry=registry))
            contracts_text = format_contracts_for_prompt(contracts)

            is_new = not os.path.exists(default_test_path)
            if not is_new:
                # Update existing test file: add new test methods for all functionalities not yet covered
                try:
                    existing_content = await loop.run_in_executor(None, lambda: open(default_test_path, "r", encoding="utf-8").read())
                except OSError:
                    return None, None, False
                    
                existing_methods = re.findall(r"@Test\s+(?:public\s+)?void\s+(\w+)\s*\(", existing_content, re.IGNORECASE)
                public_methods = re.findall(r"public\s+\w+(?:<[^>]+>)?\s+(\w+)\s*\(", code)
                
                query_text = f"JUnit5 unit test pattern and common failures for {pkg}.{class_name} in a Maven project"
                emb = await loop.run_in_executor(None, lambda: self.llm.embed_text(query_text))
                
                # Run RAG queries in thread pool
                pattern_hits = await loop.run_in_executor(None, lambda: self.rag.query(embedding=_to_np(emb), top_k=5, kind="java_test_pattern"))
                failure_hits = await loop.run_in_executor(None, lambda: self.rag.query(embedding=_to_np(emb), top_k=5, kind="java_test_failure"))
                coverage_hits = await loop.run_in_executor(None, lambda: self.rag.query(embedding=_to_np(emb), top_k=3, kind="coverage_gap"))
                
                rag_parts = []
                if pattern_hits or failure_hits:
                    rag_parts.append("\n".join([h.text[:1500] for h in pattern_hits + failure_hits]))
                if coverage_hits:
                    rag_parts.append("Focus coverage:\n" + "\n".join([h.text[:800] for h in coverage_hits]))
                rag_snippets = "\n\n---\n\n".join(rag_parts) if rag_parts else ""

                enhance_system = (
                    "You are a Senior Java Test Automation Architect. The test class already exists. "
                    "Generate ONLY NEW @Test methods that cover functionalities not yet tested. "
                    "Use JUnit 5, Arrange-Act-Assert, meaningful names. Cover all public methods and branches; add edge cases (null, empty, invalid). "
                    "If testing a Spring Controller, use @WithMockUser to avoid 401/403 errors. "
                    "Return ONLY the new test methods (with @Test annotation), no class wrapper, no duplicate of existing methods.\n\n"
                    "STRICT RULES FOR OBJECT INSTANTIATION:\n"
                    "- Do NOT invent constructors. Only use constructors exactly as defined in the CLASS CONTRACTS below.\n"
                    "- If only a no-arg constructor exists, use setters to populate fields.\n"
                    "- If @Builder is detected, use the builder pattern.\n"
                    "- If @AllArgsConstructor exists, use the all-args constructor with correct parameter order.\n"
                    "- NEVER guess constructor parameters — ONLY use what is documented in CLASS CONTRACTS.\n"
                    "- ACCESSOR CONVENTION: Match the accessor style specified in the CLASS CONTRACTS below. If the contract implies a record, use record accessors (`email()`). Otherwise default to standard getters (`getEmail()`)."
                )
                enhance_user = f"""
Existing test class: {class_name}Test. Already has these @Test methods: {', '.join(existing_methods) if existing_methods else 'none'}

{f'CRITICAL — Context (Reason for recent code changes): {change_reasoning}' if change_reasoning else ''}
{f'You MUST include test cases that specifically validate the behavior introduced by these changes (e.g., security fixes, input validation, error handling).' if change_reasoning else ''}

Class under test ({pkg}.{class_name}) public methods to cover: {', '.join(public_methods[:25]) if public_methods else 'N/A'}

{contracts_text if contracts_text else '(No referenced type contracts found)'}

RAG (optional): {rag_snippets[:2000] if rag_snippets else '(none)'}

Java source (excerpt):
{code[:15000]}

Generate ONLY NEW @Test methods for missing coverage. Every test MUST be self-contained and MUST pass when executed standalone.
Return ONLY raw Java code (methods with @Test), NO class declaration, NO markdown.
If everything is already well covered, return exactly: // All functionalities covered
"""
                new_methods = await loop.run_in_executor(None, lambda: _strip_code_fences(self.llm.generate_text(system=enhance_system, user=enhance_user)))
                
                if "@Test" in new_methods and "// All functionalities covered" not in new_methods:
                    last_brace_idx = existing_content.rfind("}")
                    if last_brace_idx != -1:
                        enhanced = (
                            existing_content[:last_brace_idx].rstrip()
                            + "\n\n    // --- AUTO-GENERATED: additional coverage ---\n"
                            + new_methods
                            + "\n"
                            + existing_content[last_brace_idx:]
                        )
                        backup_path = default_test_path + ".atlas_bak"
                        if not os.path.exists(backup_path):
                            import shutil
                            await loop.run_in_executor(None, lambda: shutil.copy2(default_test_path, backup_path))
                        
                        await loop.run_in_executor(None, lambda: self._write_file(default_test_path, enhanced))
                        # Update fingerprint
                        await self._set_fingerprint(class_key, current_sha, default_test_path)
                        return default_test_path, class_key, False
                
                # If no updates were needed, store the fingerprint to skip next time
                await self._set_fingerprint(class_key, current_sha, default_test_path)
                return None, class_key, False

            # Stage 7: Spring Configuration Rule Engine Discovery
            is_spring_config = any(x in code for x in ("@Configuration", "WebMvcConfigurer", "SecurityFilterChain"))
            
            query_text = f"JUnit5 unit test pattern and common failures for {pkg}.{class_name} in a Maven project"
            emb = await loop.run_in_executor(None, lambda: self.llm.embed_text(query_text))
            
            # Batched RAG queries: combine pattern+failure and build+coverage into 2 calls
            pattern_failure_hits = await loop.run_in_executor(None, lambda: self.rag.query(
                embedding=_to_np(emb), top_k=8, kinds=["java_test_pattern", "java_test_failure"]
            ))
            build_coverage_hits = await loop.run_in_executor(None, lambda: self.rag.query(
                embedding=_to_np(emb), top_k=5, kinds=["build_failure", "coverage_gap"]
            ))
            
            rag_parts = []
            if pattern_failure_hits:
                rag_parts.append("\n".join([h.text[:1500] for h in pattern_failure_hits]))
            build_hits = [h for h in build_coverage_hits if h.kind == "build_failure"]
            coverage_hits = [h for h in build_coverage_hits if h.kind == "coverage_gap"]
            if build_hits:
                rag_parts.append("Avoid these build errors (from past runs):\n" + "\n".join([h.text[:800] for h in build_hits]))
            if coverage_hits:
                rag_parts.append("Focus coverage on these classes (from past runs):\n" + "\n".join([h.text[:800] for h in coverage_hits]))
            rag_snippets = "\n\n---\n\n".join(rag_parts) if rag_parts else ""

            system = (
                "You are a Senior Java Test Automation Architect focused on regression testing. "
                "Generate JUnit 5 tests that compile in a Maven project and cover ALL functionalities of the class. "
                "Include test methods for every public method, branches, edge cases (null, empty, invalid inputs). "
                "Use concise Arrange-Act-Assert structure and meaningful method names. "
                "If mocking is needed, use Mockito only if already present; otherwise write simple tests. "
                "If testing a Controller, use @WithMockUser to bypass security. "
                "For SpringApplication.run static mocks: use `mockStatic(SpringApplication.class)` and when verifying, match varargs precisely (e.g., `any(String[].class)` if args can vary).\n\n"
                "STRICT RULES FOR OBJECT INSTANTIATION:\n"
                "- Do NOT invent constructors. Only use constructors exactly as defined in the CLASS CONTRACTS below.\n"
                "- If only a no-arg constructor exists, instantiate with new ClassName() and use setters to populate fields.\n"
                "- If @Builder is detected, use the builder pattern: ClassName.builder().field(value).build()\n"
                "- If @AllArgsConstructor exists, use the all-args constructor with correct parameter order and types.\n"
                "- NEVER guess constructor parameters — ONLY use what is documented in CLASS CONTRACTS.\n"
                "- ACCESSOR CONVENTION: Match the accessor style specified in the CLASS CONTRACTS below. If the contract implies a record, use record accessors (`email()`). Otherwise default to standard getters (`getEmail()`).\n\n"
                "ROBUSTNESS RULES (Phase 7 & 8):\n"
                "- DTO VALIDATION: If a field has validation annotations (e.g. @NotNull, @Size), ensure you inject a VALID sample value (e.g. non-null, correct length).\n"
                "- JPA ENTITIES: If a class is marked as a JPA Entity, avoid calling lazy-loaded fields or getters in the test unless you have explicitly initialized them with mock data."
            )
            
            if is_spring_config:
                system += (
                    "\n\nSPRING CONFIGURATION RULES (Phase 7):\n"
                    "- Do NOT mock fluent registry/configurer internals (CorsRegistry, InterceptorRegistry, HttpSecurity).\n"
                    "- Instead, instantiate the config class and call methods with REAL registry objects: `config.addCorsMappings(new CorsRegistry())`.\n"
                    "- Never mock a method that returns 'this' or a fluent chain object."
                )
            user = f"""
Repository context: Maven, JUnit 5.

{f'CRITICAL — Context (Reason for recent code changes): {change_reasoning}' if change_reasoning else ''}
{f'You MUST include test cases that specifically validate the behavior introduced by these changes. For example, if a security fix was applied, write tests that verify the fix works correctly (e.g., input sanitization, proper validation, correct error handling).' if change_reasoning else ''}

{contracts_text if contracts_text else '(No referenced type contracts found)'}

RAG: {rag_snippets if rag_snippets else "(none)"}

Task: Create ONE complete JUnit 5 test class for the following Java source. Cover ALL functionalities (all public methods and branches).
Return ONLY the Java source code for the test file (no explanations). Must compile. Place under src/test/java in matching package.
Use meaningful test names. Avoid integration tests; keep it unit-level.
Every test method MUST be self-contained and MUST pass when executed. Do NOT write tests that depend on external services, databases, or network calls unless properly mocked.

Java source path: {rel}
Java source:
{code[:20000]}
""".strip()

            # Phase 5: Generation with Deterministic Validation Loop
            java_code = ""
            for attempt in range(2):
                java_code = await loop.run_in_executor(None, lambda: _strip_code_fences(self.llm.generate_text(system=system, user=user)))
                violations = validate_constructor_usage(java_code, contracts)
                if not violations:
                    break
                logger.info(f"[Validation] Phase 5 Violation in {class_name}: {violations[0]}. Retrying...")
                user += f"\n\nREJECTION: Your previous generation had constructor hallucinations:\n" + "\n".join(violations) + "\nFIX: Use ONLY valid signatures from CLASS CONTRACTS."

            dest = default_test_path
            await loop.run_in_executor(None, lambda: self._write_file(dest, java_code.rstrip() + "\n"))

            rid = f"java_test_pattern:{uuid.uuid4().hex}"
            await loop.run_in_executor(None, lambda: self.rag.upsert(
                id=rid,
                kind="java_test_pattern",
                embedding=_to_np(emb),
                text=java_code[:8000],
                metadata={"source_java": rel, "test_path": os.path.relpath(default_test_path, repo_path)},
            ))

            # Update fingerprint for new test file
            await self._set_fingerprint(class_key, current_sha, default_test_path)

            if repo_url:
                gen_rid = "generated_for_repo:" + hashlib.md5(repo_url.encode()).hexdigest()
                try:
                    emb_url = await loop.run_in_executor(None, lambda: self.llm.embed_text(repo_url))
                    await loop.run_in_executor(None, lambda: self.rag.upsert(
                        id=gen_rid,
                        kind="generated_for_repo",
                        embedding=_to_np(emb_url),
                        text=repo_url,
                        metadata={"repo_url": repo_url, "classes": [class_key]},
                    ))
                except Exception:
                    pass
            
            return default_test_path, class_key, True

    async def _set_fingerprint(self, class_key: str, sha: str, test_path: str):
        """Update RAG with class source fingerprint."""
        import asyncio
        import numpy as np
        loop = asyncio.get_running_loop()
        # Fingerprint doesn't need a real embedding for lookup by ID, but upsert requires one.
        # We use a dummy zero vector.
        dummy_emb = np.zeros(1536, dtype=np.float32)
        await loop.run_in_executor(None, lambda: self.rag.upsert(
            id=f"test_fingerprint:{class_key}",
            kind="test_fingerprint",
            embedding=dummy_emb,
            text=f"Fingerprint for {class_key}",
            metadata={"sha256": sha, "test_path": test_path}
        ))

    def _write_file(self, path: str, content: str):
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)


def _to_np(v: list[float]):
    import numpy as np

    return np.array(v, dtype=np.float32)


def _class_key(repo_path: str, main_java_path: str) -> str:
    """Return 'package.ClassName' for a main Java file (for RAG tracking)."""
    try:
        code = open(main_java_path, "r", encoding="utf-8", errors="ignore").read()
    except OSError:
        return os.path.relpath(main_java_path, repo_path)
    pkg = _infer_package(code)
    cls = _infer_public_class(code) or os.path.splitext(os.path.basename(main_java_path))[0]
    return f"{pkg}.{cls}" if pkg else cls


def _has_existing_test(repo_path: str, main_java_path: str) -> bool:
    """
    Return True if a test file already exists for this main class (e.g. FooTest.java or FooAiTest.java).
    Used to skip classes on re-runs so we don't regenerate the same tests.
    Works for single-module and multi-module (e.g. module-a/src/main/java/... -> module-a/src/test/java/...).
    """
    rel = os.path.relpath(main_java_path, repo_path).replace("\\", "/")
    if "/src/main/java/" not in rel:
        return False
    # Replace src/main/java with src/test/java so multi-module paths are correct
    test_rel = rel.replace("/src/main/java/", "/src/test/java/", 1)
    test_dir = os.path.join(repo_path, os.path.dirname(test_rel))
    class_name = os.path.splitext(os.path.basename(main_java_path))[0]
    if os.path.isfile(os.path.join(test_dir, f"{class_name}Test.java")):
        return True
    if os.path.isfile(os.path.join(test_dir, f"{class_name}AiTest.java")):
        return True
    return False


def _infer_package(java_source: str) -> str:
    m = re.search(r"^\s*package\s+([a-zA-Z0-9_.]+)\s*;\s*$", java_source, flags=re.MULTILINE)
    return m.group(1) if m else ""


def _infer_public_class(java_source: str) -> str | None:
    m = re.search(r"\bpublic\s+class\s+([A-Za-z0-9_]+)\b", java_source)
    return m.group(1) if m else None
