"""
Single AI provider for the application: all LLM and embedding usage goes through Bedrock.
Do not add OpenAI, Anthropic, or other providers; use this client only (injected by the pipeline).
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any

import boto3
from botocore.config import Config

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class BedrockConfig:
    region: str
    model_id: str
    embed_model_id: str
    access_key: str | None = None
    secret_key: str | None = None
    session_token: str | None = None


def create_bedrock_client(
    region: str,
    model_id: str,
    embed_model_id: str,
    access_key: str | None = None,
    secret_key: str | None = None,
    session_token: str | None = None,
) -> "BedrockClient":
    """Single factory for Bedrock client. Use this (or pipeline-injected llm) everywhere AI is needed."""
    return BedrockClient(
        BedrockConfig(
            region=region,
            model_id=model_id,
            embed_model_id=embed_model_id,
            access_key=access_key,
            secret_key=secret_key,
            session_token=session_token,
        )
    )


class BedrockClient:
    def __init__(self, cfg: BedrockConfig):
        if not cfg.region:
            raise ValueError("AWS_REGION is required")
        if not cfg.model_id:
            raise ValueError("BEDROCK_MODEL_ID is required")
        if not cfg.embed_model_id:
            raise ValueError("BEDROCK_EMBED_MODEL_ID is required")

        self.cfg = cfg
        
        client_kwargs = {
            "service_name": "bedrock-runtime",
            "region_name": cfg.region,
        }
        if cfg.access_key:
            client_kwargs["aws_access_key_id"] = cfg.access_key
        if cfg.secret_key:
            client_kwargs["aws_secret_access_key"] = cfg.secret_key
            
        # Security: Permanent credentials (AKIA) must NOT use a session token.
        # Temporary credentials (ASIA) REQUIRE a session token.
        if cfg.access_key and cfg.access_key.startswith('AKIA'):
            client_kwargs["aws_session_token"] = None
        elif cfg.session_token:
            client_kwargs["aws_session_token"] = cfg.session_token
        else:
            # Explicitly set to None to override any environment inherited session token
            client_kwargs["aws_session_token"] = None
            
        retry_config = Config(
            retries={
                'max_attempts': 10,
                'mode': 'adaptive'
            },
            read_timeout=120,        # Prevent single call from blocking 12+ min
            connect_timeout=10,
        )
            
        self._runtime = boto3.client(**client_kwargs, config=retry_config)
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_embedding_tokens = 0

    def embed_text(self, text: str) -> list[float]:
        """
        Uses Titan Embeddings format (text -> embedding vector).
        """
        t0 = time.monotonic()
        body = json.dumps({"inputText": text})
        resp = self._runtime.invoke_model(
            modelId=self.cfg.embed_model_id,
            contentType="application/json",
            accept="application/json",
            body=body,
        )
        payload = json.loads(resp["body"].read().decode("utf-8"))
        # Titan output commonly: {"embedding":[...], "inputTextTokenCount":...}
        input_tokens = payload.get("inputTextTokenCount", 0)
        self.total_embedding_tokens += input_tokens
        
        emb = payload.get("embedding")
        if not isinstance(emb, list):
            raise RuntimeError(f"Unexpected embedding response: {payload}")
        elapsed = time.monotonic() - t0
        logger.debug(f"[Bedrock] embed_text: model={self.cfg.embed_model_id} tokens={input_tokens} latency={elapsed:.2f}s")
        return [float(x) for x in emb]

    def generate_text(self, *, system: str, user: str, max_tokens: int = 8192) -> str:
        """
        Bedrock 'converse' API shape varies by provider; we implement a robust default
        using Messages API-style payload for Anthropic Claude on Bedrock.
        max_tokens is required by the API; default 8192 allows full responses without artificial limiting.
        """
        t0 = time.monotonic()
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": [{"type": "text", "text": user}]}],
        }
        resp = self._runtime.invoke_model(
            modelId=self.cfg.model_id,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(body),
        )
        payload = json.loads(resp["body"].read().decode("utf-8"))
        
        # Track usage for Claude (common Bedrock payload)
        usage = payload.get("usage", {})
        in_tok = usage.get("input_tokens", 0)
        out_tok = usage.get("output_tokens", 0)
        self.total_input_tokens += in_tok
        self.total_output_tokens += out_tok

        # Claude style: {"content":[{"type":"text","text":"..."}], ...}
        content = payload.get("content", [])
        if isinstance(content, list):
            texts = [c.get("text", "") for c in content if isinstance(c, dict)]
            out = "".join(texts).strip()
            if out:
                elapsed = time.monotonic() - t0
                logger.debug(f"[Bedrock] generate_text: model={self.cfg.model_id} in={in_tok} out={out_tok} latency={elapsed:.2f}s")
                return out
        # Fallback common keys
        for k in ("outputText", "generation", "completion"):
            if isinstance(payload.get(k), str) and payload[k].strip():
                elapsed = time.monotonic() - t0
                logger.debug(f"[Bedrock] generate_text (fallback): model={self.cfg.model_id} latency={elapsed:.2f}s")
                return payload[k].strip()
        raise RuntimeError(f"Unexpected generation response: {payload}")

