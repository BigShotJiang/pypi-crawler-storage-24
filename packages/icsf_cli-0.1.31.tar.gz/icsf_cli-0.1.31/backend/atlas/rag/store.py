from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np

logger = logging.getLogger(__name__)

# Default TTL: 30 days (entries older than this are excluded from queries)
DEFAULT_TTL_SECONDS = 30 * 24 * 60 * 60

# Default minimum score threshold (cosine similarity) — skip irrelevant hits
DEFAULT_SCORE_THRESHOLD = 0.25


def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def _normalize(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    if n == 0:
        return v
    return v / n


@dataclass(frozen=True)
class RagHit:
    id: str
    kind: str
    score: float
    metadata: dict[str, Any]
    text: str


class SqliteVectorRagStore:
    """
    Lightweight persistent RAG store with enterprise optimizations:
    - SQLite for metadata + text
    - Embeddings stored as normalized float32 bytes
    - Cosine similarity via dot product in Python
    - Score threshold filtering to skip irrelevant results
    - TTL-based eviction to exclude stale entries from queries
    - Kind-based indexing for fast filtered lookups
    - Batch query support to reduce redundant DB round-trips
    """

    def __init__(self, db_path: str, *, ttl_seconds: int = DEFAULT_TTL_SECONDS):
        _ensure_dir(os.path.dirname(db_path))
        self.db_path = db_path
        self.ttl_seconds = ttl_seconds
        self._init()

    def _conn(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init(self) -> None:
        with self._conn() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS rag_items (
                  id TEXT PRIMARY KEY,
                  kind TEXT NOT NULL,
                  created_at INTEGER NOT NULL,
                  embedding BLOB NOT NULL,
                  metadata_json TEXT NOT NULL,
                  text TEXT NOT NULL
                )
                """
            )
            con.execute("CREATE INDEX IF NOT EXISTS idx_rag_kind ON rag_items(kind)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_rag_created ON rag_items(created_at)")

    def upsert(
        self,
        *,
        id: str,
        kind: str,
        embedding: np.ndarray,
        text: str,
        metadata: dict[str, Any],
    ) -> None:
        emb = _normalize(embedding.astype(np.float32)).tobytes()
        meta = json.dumps(metadata, ensure_ascii=False)
        now = int(time.time())
        with self._conn() as con:
            con.execute(
                """
                INSERT INTO rag_items(id, kind, created_at, embedding, metadata_json, text)
                VALUES(?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                  kind=excluded.kind,
                  created_at=excluded.created_at,
                  embedding=excluded.embedding,
                  metadata_json=excluded.metadata_json,
                  text=excluded.text
                """,
                (id, kind, now, emb, meta, text),
            )

    def query(
        self,
        *,
        embedding: np.ndarray,
        top_k: int = 8,
        kind: str | None = None,
        kinds: list[str] | None = None,
        score_threshold: float = DEFAULT_SCORE_THRESHOLD,
        include_expired: bool = False,
    ) -> list[RagHit]:
        """
        Query the RAG store for similar items.

        Args:
            embedding: Query embedding vector
            top_k: Maximum number of results to return
            kind: Filter by single kind (legacy API, use `kinds` for multi-kind)
            kinds: Filter by multiple kinds in one query (reduces DB round-trips)
            score_threshold: Minimum cosine similarity to include in results
            include_expired: If True, skip TTL filtering
        """
        q = _normalize(embedding.astype(np.float32))
        clauses: list[str] = []
        params: list[Any] = []

        # Kind filter (single or multi)
        if kinds:
            placeholders = ", ".join("?" for _ in kinds)
            clauses.append(f"kind IN ({placeholders})")
            params.extend(kinds)
        elif kind:
            clauses.append("kind = ?")
            params.append(kind)

        # TTL filter
        if not include_expired and self.ttl_seconds > 0:
            cutoff = int(time.time()) - self.ttl_seconds
            clauses.append("created_at >= ?")
            params.append(cutoff)

        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""

        with self._conn() as con:
            rows = con.execute(
                f"SELECT id, kind, embedding, metadata_json, text FROM rag_items {where}",
                params,
            ).fetchall()

        hits: list[RagHit] = []
        for rid, rkind, remb, rmeta, rtext in rows:
            rv = np.frombuffer(remb, dtype=np.float32)
            # rv is already normalized; cosine = dot(q, rv)
            score = float(np.dot(q, rv))
            if score < score_threshold:
                continue
            hits.append(
                RagHit(
                    id=rid,
                    kind=rkind,
                    score=score,
                    metadata=json.loads(rmeta),
                    text=rtext,
                )
            )
        hits.sort(key=lambda h: h.score, reverse=True)
        return hits[:top_k]

    def get_by_id(self, id: str) -> RagHit | None:
        """Return a single item by id, or None if not found."""
        with self._conn() as con:
            row = con.execute(
                "SELECT id, kind, embedding, metadata_json, text FROM rag_items WHERE id = ?",
                (id,),
            ).fetchone()
        if not row:
            return None
        return RagHit(
            id=row[0],
            kind=row[1],
            score=1.0,
            metadata=json.loads(row[3]),
            text=row[4],
        )

    def count(self, kind: str | None = None) -> int:
        """Return the number of items, optionally filtered by kind."""
        if kind:
            with self._conn() as con:
                row = con.execute("SELECT COUNT(*) FROM rag_items WHERE kind = ?", (kind,)).fetchone()
        else:
            with self._conn() as con:
                row = con.execute("SELECT COUNT(*) FROM rag_items").fetchone()
        return row[0] if row else 0

    def evict_expired(self) -> int:
        """Remove entries older than TTL. Returns count of deleted rows."""
        cutoff = int(time.time()) - self.ttl_seconds
        with self._conn() as con:
            cursor = con.execute("DELETE FROM rag_items WHERE created_at < ?", (cutoff,))
            deleted = cursor.rowcount
        if deleted > 0:
            logger.info(f"[RAG] Evicted {deleted} expired entries (TTL={self.ttl_seconds}s)")
        return deleted
