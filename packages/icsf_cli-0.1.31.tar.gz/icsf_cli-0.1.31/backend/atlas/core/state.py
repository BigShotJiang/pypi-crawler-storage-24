from __future__ import annotations

import json
import os
import logging
from dataclasses import dataclass, asdict, field
from enum import Enum
from typing import Literal

logger = logging.getLogger(__name__)

class PipelineState(str, Enum):
    IDLE = "IDLE"
    DEPENDENCY_BASELINE = "DEPENDENCY_BASELINE"  # Phase 0
    DISCOVERY = "DISCOVERY"
    MAIN_COMPILE = "MAIN_COMPILE"
    CONTRACT_EXTRACTION = "CONTRACT_EXTRACTION"
    TEST_GENERATION = "TEST_GENERATION"
    TEST_VALIDATION = "TEST_VALIDATION"  # Pre-compile AST check
    DEPENDENCY_GATE = "DEPENDENCY_GATE"        # Phase 8 (Governance check)
    TEST_COMPILE = "TEST_COMPILE"
    TEST_EXECUTION = "TEST_EXECUTION"
    COVERAGE = "COVERAGE"
    REPORTING = "REPORTING"
    PR = "PR"
    ERROR = "ERROR"
    AWAITING_APPROVAL = "AWAITING_APPROVAL"     # For dependency changes

@dataclass
class PipelineStatus:
    """
    Represents the current state of Atlas pipeline for a repository.
    """
    state: PipelineState = PipelineState.IDLE
    phase: Literal["baseline", "validation_testing"] = "baseline"
    baseline_completed: bool = False
    baseline_commit_hash: str = ""
    baseline_dependency_hash: str = ""
    baseline_coverage: float = 0.0
    baseline_total_tests: int = 0
    baseline_passed_test_keys: list[str] = field(default_factory=list)
    coverage_threshold: float = 70.0
    last_validation_hash: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> PipelineStatus:
        return cls(**data)


class PipelineStateManager:
    """
    Handles loading, saving, and updating pipeline_state.json.
    """
    def __init__(self, repo_path: str):
        self.repo_path = repo_path
        self.state_file = os.path.join(repo_path, ".atlas", "pipeline_state.json")
        self.status = self.load()

    def load(self) -> PipelineStatus:
        """Load state from .atlas/pipeline_state.json."""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return PipelineStatus.from_dict(data)
            except Exception as e:
                logger.error(f"Failed to load pipeline state from {self.state_file}: {e}")
        
        return PipelineStatus()

    def save(self):
        """Save current status to .atlas/pipeline_state.json."""
        try:
            os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
            with open(self.state_file, "w", encoding="utf-8") as f:
                json.dump(self.status.to_dict(), f, indent=2)
            logger.info(f"Saved pipeline state to {self.state_file}")
        except Exception as e:
            logger.error(f"Failed to save pipeline state to {self.state_file}: {e}")

    def update(self, **kwargs):
        """Update status fields and save immediately."""
        for key, value in kwargs.items():
            if hasattr(self.status, key):
                setattr(self.status, key, value)
            else:
                logger.warning(f"PipelineStatus has no field: {key}")
        self.save()
