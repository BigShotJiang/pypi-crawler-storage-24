from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from typing import Any


@dataclass
class CmdResult:
    cmd: list[str]
    returncode: int
    stdout: str
    stderr: str


import sys

def run_cmd(
    cmd: list[str],
    cwd: str | None = None,
    env: dict[str, str] | None = None,
    timeout_s: int | None = None,
    logger: Any | None = None,
) -> CmdResult:
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)

    # On Windows, shell=True is needed to resolve .cmd/.bat files in PATH (like mvn)
    is_windows = sys.platform == "win32"

    # We use Popen to stream output if a logger is provided
    # Otherwise we fall back to a simple blocking run
    if logger:
        p = subprocess.Popen(
            cmd,
            cwd=cwd,
            env=merged_env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, # Merge stderr into stdout for streaming
            text=True,
            shell=is_windows,
            bufsize=1, # Line buffered
        )
        
        full_stdout = []
        # Non-blocking read loop
        while True:
            line = p.stdout.readline()
            if not line and p.poll() is not None:
                break
            if line:
                clean_line = line.rstrip()
                full_stdout.append(line)
                logger.info(clean_line)
        
        returncode = p.wait(timeout=timeout_s)
        return CmdResult(cmd=cmd, returncode=returncode, stdout="".join(full_stdout), stderr="")
    else:
        p = subprocess.run(
            cmd,
            cwd=cwd,
            env=merged_env,
            text=True,
            capture_output=True,
            timeout=timeout_s,
            shell=is_windows,
        )
        return CmdResult(cmd=cmd, returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)

