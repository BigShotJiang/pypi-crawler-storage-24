from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Callable


@dataclass
class RunLogger:
    emit: Callable[[str], None]

    def info(self, msg: str) -> None:
        self.emit(f"[{dt.datetime.utcnow().isoformat()}Z] INFO  {msg}")

    def warn(self, msg: str) -> None:
        self.emit(f"[{dt.datetime.utcnow().isoformat()}Z] WARN  {msg}")

    # Alias to match standard logging API (logging.Logger uses .warning())
    def warning(self, msg: str) -> None:
        self.warn(msg)

    def error(self, msg: str) -> None:
        self.emit(f"[{dt.datetime.utcnow().isoformat()}Z] ERROR {msg}")

