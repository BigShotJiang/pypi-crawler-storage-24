"""Resilience patterns: retry with exponential backoff, circuit breaker, rate limiter.

This module provides resilience patterns for external service calls to improve
reliability and prevent cascading failures.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from functools import wraps
from typing import Any, Callable, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


@dataclass
class RetryConfig:
    """Configuration for retry logic."""
    max_attempts: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: bool = True
    retryable_exceptions: tuple[type[Exception], ...] = (
        ConnectionError,
        TimeoutError,
        OSError,
    )


class RetryException(Exception):
    """Exception raised when max retry attempts are exhausted."""

    def __init__(self, message: str, attempts: int, last_exception: Exception | None = None):
        self.message = message
        self.attempts = attempts
        self.last_exception = last_exception
        super().__init__(message)


def retry(config: RetryConfig | None = None) -> Callable:
    """
    Decorator for retry logic with exponential backoff.

    Args:
        config: Retry configuration, uses defaults if not provided

    Example:
        @retry(RetryConfig(max_attempts=5, base_delay=0.5))
        def call_external_api():
            ...
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        cfg = config or RetryConfig()

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            last_exception: Exception | None = None
            delay = cfg.base_delay

            for attempt in range(1, cfg.max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except cfg.retryable_exceptions as e:
                    last_exception = e
                    if attempt >= cfg.max_attempts:
                        logger.error(
                            f"Function {func.__name__} failed after {cfg.max_attempts} attempts"
                        )
                        raise RetryException(
                            f"Max retry attempts ({cfg.max_attempts}) exceeded for {func.__name__}",
                            cfg.max_attempts,
                            e,
                        ) from e

                    # Calculate delay with exponential backoff and optional jitter
                    jitter_amount = 0
                    if cfg.jitter:
                        jitter_amount = delay * 0.1 * (time.time() % 1)

                    actual_delay = min(delay + jitter_amount, cfg.max_delay)
                    logger.warning(
                        f"Function {func.__name__} failed (attempt {attempt}/{cfg.max_attempts}), "
                        f"retrying in {actual_delay:.2f}s. Error: {e}"
                    )
                    time.sleep(actual_delay)
                    delay = min(delay * cfg.exponential_base, cfg.max_delay)
                except Exception as e:
                    # Don't retry on non-retryable exceptions
                    logger.error(
                        f"Function {func.__name__} failed with non-retryable exception: {e}"
                    )
                    raise

            # This should never be reached, but for type safety
            raise RuntimeError("Retry logic error")  # pragma: no cover

        return wrapper

    return decorator


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker."""

    failure_threshold: int = 5
    success_threshold: int = 2
    timeout: float = 60.0  # seconds to wait in OPEN state
    half_open_max_calls: int = 1


@dataclass
class CircuitBreakerState:
    """Current state of a circuit breaker."""

    state: str = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    failures: int = 0
    successes: int = 0
    last_failure_time: datetime | None = None
    last_state_change: datetime = field(default_factory=datetime.utcnow)


class CircuitBreakerOpenException(Exception):
    """Exception raised when circuit breaker is OPEN."""

    def __init__(self, name: str, timeout_remaining: float | None = None):
        self.name = name
        self.timeout_remaining = timeout_remaining
        msg = f"Circuit breaker '{name}' is OPEN"
        if timeout_remaining:
            msg += f" ({timeout_remaining:.1f}s remaining)"
        super().__init__(msg)


class CircuitBreaker:
    """
    Circuit breaker pattern implementation.

    States:
    - CLOSED: Requests pass normally, failures are counted
    - OPEN: Requests fail immediately, no external calls made
    - HALF_OPEN: Limited requests pass, testing if service has recovered
    """

    _instances: dict[str, CircuitBreaker] = {}

    def __init__(self, name: str, config: CircuitBreakerConfig | None = None):
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self.state = CircuitBreakerState()
        self._lock: Any = None  # Could use threading.Lock in multi-threaded scenarios

    @classmethod
    def get(cls, name: str, config: CircuitBreakerConfig | None = None) -> CircuitBreaker:
        """Get or create a circuit breaker by name."""
        if name not in cls._instances:
            cls._instances[name] = CircuitBreaker(name, config)
        return cls._instances[name]

    @classmethod
    def reset_all(cls) -> None:
        """Reset all circuit breakers (for testing)."""
        cls._instances.clear()

    def _should_allow_request(self) -> bool:
        """Check if a request should be allowed based on current state."""
        now = datetime.utcnow()

        if self.state.state == "CLOSED":
            return True
        elif self.state.state == "OPEN":
            # Check if timeout has elapsed
            if self.state.last_state_change:
                elapsed = (now - self.state.last_state_change).total_seconds()
                if elapsed >= self.config.timeout:
                    # Transition to HALF_OPEN
                    self.state.state = "HALF_OPEN"
                    self.state.successes = 0
                    self.state.last_state_change = now
                    logger.info(f"Circuit breaker '{self.name}' transitioned to HALF_OPEN")
                    return True
                return False
            return True
        elif self.state.state == "HALF_OPEN":
            # Allow limited calls in HALF_OPEN state
            return True
        return False

    def _on_success(self) -> None:
        """Handle successful request."""
        now = datetime.utcnow()

        if self.state.state == "HALF_OPEN":
            self.state.successes += 1
            if self.state.successes >= self.config.success_threshold:
                # Reset to CLOSED
                self.state.state = "CLOSED"
                self.state.failures = 0
                self.state.successes = 0
                self.state.last_state_change = now
                logger.info(f"Circuit breaker '{self.name}' transitioned to CLOSED")
        elif self.state.state == "CLOSED":
            # Reset failure count on success
            self.state.failures = 0

    def _on_failure(self) -> None:
        """Handle failed request."""
        now = datetime.utcnow()

        if self.state.state == "HALF_OPEN":
            # Go back to OPEN immediately
            self.state.state = "OPEN"
            self.state.last_state_change = now
            logger.warning(f"Circuit breaker '{self.name}' transitioned to OPEN (HALF_OPEN failure)")
        elif self.state.state == "CLOSED":
            self.state.failures += 1
            self.state.last_failure_time = now
            if self.state.failures >= self.config.failure_threshold:
                # Transition to OPEN
                self.state.state = "OPEN"
                self.state.last_state_change = now
                logger.warning(
                    f"Circuit breaker '{self.name}' transitioned to OPEN "
                    f"(threshold: {self.config.failure_threshold})"
                )

    def call(self, func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
        """
        Execute a function through the circuit breaker.

        Args:
            func: Function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function

        Returns:
            Result of the function

        Raises:
            CircuitBreakerOpenException: If circuit is OPEN
            Exception: Any exception from the function itself
        """
        if not self._should_allow_request():
            timeout_remaining = None
            if self.state.last_state_change:
                elapsed = (datetime.utcnow() - self.state.last_state_change).total_seconds()
                timeout_remaining = self.config.timeout - elapsed
            raise CircuitBreakerOpenException(self.name, timeout_remaining)

        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception:
            self._on_failure()
            raise

    def get_status(self) -> dict[str, Any]:
        """Get current circuit breaker status."""
        status = {
            "name": self.name,
            "state": self.state.state,
            "failures": self.state.failures,
            "successes": self.state.successes,
            "last_failure_time": self.state.last_failure_time.isoformat()
            if self.state.last_failure_time
            else None,
            "last_state_change": self.state.last_state_change.isoformat()
            if self.state.last_state_change
            else None,
        }
        if self.state.state == "OPEN":
            elapsed = (datetime.utcnow() - self.state.last_state_change).total_seconds()
            status["timeout_remaining"] = max(0, self.config.timeout - elapsed)
        return status


def circuit_breaker(
    name: str, config: CircuitBreakerConfig | None = None
) -> Callable:
    """
    Decorator for circuit breaker pattern.

    Args:
        name: Name of the circuit breaker (shared across calls with same name)
        config: Circuit breaker configuration, uses defaults if not provided

    Example:
        @circuit_breaker("bedrock_api", CircuitBreakerConfig(failure_threshold=3))
        def call_bedrock():
            ...
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        cb = CircuitBreaker.get(name, config)

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            return cb.call(func, *args, **kwargs)

        return wrapper

    return decorator


@dataclass
class RateLimiterConfig:
    """Configuration for rate limiter."""

    max_calls: int = 10
    period: float = 60.0  # seconds


class RateLimiter:
    """
    Simple rate limiter using token bucket algorithm.

    This is a basic in-memory rate limiter. For distributed systems,
    consider using Redis or similar.
    """

    _instances: dict[str, RateLimiter] = {}

    def __init__(self, name: str, config: RateLimiterConfig | None = None):
        self.name = name
        self.config = config or RateLimiterConfig()
        self.calls: list[datetime] = []

    @classmethod
    def get(cls, name: str, config: RateLimiterConfig | None = None) -> RateLimiter:
        """Get or create a rate limiter by name."""
        if name not in cls._instances:
            cls._instances[name] = RateLimiter(name, config)
        return cls._instances[name]

    @classmethod
    def reset_all(cls) -> None:
        """Reset all rate limiters (for testing)."""
        cls._instances.clear()

    def acquire(self, raise_on_limit: bool = True) -> bool:
        """
        Attempt to acquire a token.

        Args:
            raise_on_limit: If True, raises RateLimitExceededException when limit reached

        Returns:
            True if token acquired, False if limit reached

        Raises:
            RateLimitExceededException: If rate limit exceeded and raise_on_limit=True
        """
        now = datetime.utcnow()
        cutoff = now - timedelta(seconds=self.config.period)

        # Remove old calls
        self.calls = [call_time for call_time in self.calls if call_time > cutoff]

        if len(self.calls) < self.config.max_calls:
            self.calls.append(now)
            return True

        if raise_on_limit:
            retry_after = (self.calls[0] + timedelta(seconds=self.config.period) - now).total_seconds()
            # Note: RateLimitExceededException (original name in acquire) 
            # vs RateLimitExceededError (defined in this file)
            # The atlasv4 code used RateLimiterExceededException in acquire but defined RateLimitExceededError.
            # I'll use RateLimitExceededError to match definition.
            raise RateLimitExceededError(
                f"Rate limit exceeded for '{self.name}': "
                f"{self.config.max_calls} calls per {self.config.period}s",
                retry_after=retry_after,
            )
        return False

    def get_remaining(self) -> int:
        """Get number of calls remaining in current period."""
        now = datetime.utcnow()
        cutoff = now - timedelta(seconds=self.config.period)
        recent_calls = sum(1 for call_time in self.calls if call_time > cutoff)
        return max(0, self.config.max_calls - recent_calls)


class RateLimitExceededError(Exception):
    """Exception raised when rate limit is exceeded."""

    def __init__(self, message: str, retry_after: float | None = None):
        self.message = message
        self.retry_after = retry_after
        msg = message
        if retry_after is not None:
            msg += f" (retry after {retry_after:.1f}s)"
        super().__init__(msg)


def rate_limit(
    name: str, config: RateLimiterConfig | None = None
) -> Callable:
    """
    Decorator for rate limiting.

    Args:
        name: Name of the rate limiter (shared across calls with same name)
        config: Rate limiter configuration, uses defaults if not provided

    Example:
        @rate_limit("github_api", RateLimiterConfig(max_calls=30, period=60))
        def call_github():
            ...
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        rl = RateLimiter.get(name, config)

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            rl.acquire(raise_on_limit=True)
            return func(*args, **kwargs)

        return wrapper

    return decorator


@dataclass
class ResilienceConfig:
    """Combined resilience configuration."""

    retry: RetryConfig | None = None
    circuit_breaker: CircuitBreakerConfig | None = None
    rate_limiter: RateLimiterConfig | None = None


def resilient(
    name: str,
    config: ResilienceConfig | None = None,
) -> Callable:
    """
    Combined decorator for all resilience patterns.

    Order of application (outer to inner):
    1. Rate limiter (first to reject)
    2. Circuit breaker (next to reject)
    3. Retry (last, wraps the actual call)

    Args:
        name: Name for the resilience components
        config: Combined configuration

    Example:
        @resilient("external_api", ResilienceConfig(
            retry=RetryConfig(max_attempts=3),
            circuit_breaker=CircuitBreakerConfig(failure_threshold=5),
            rate_limiter=RateLimiterConfig(max_calls=10, period=60)
        ))
        def call_external():
            ...
    """
    cfg = config or ResilienceConfig()

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        # Apply decorators in reverse order (innermost first)
        result = func

        if cfg.rate_limiter:
            result = rate_limit(f"{name}_rate", cfg.rate_limiter)(result)

        if cfg.circuit_breaker:
            result = circuit_breaker(f"{name}_cb", cfg.circuit_breaker)(result)

        if cfg.retry:
            result = retry(cfg.retry)(result)

        return result

    return decorator


def get_all_circuit_breakers_status() -> dict[str, dict[str, Any]]:
    """Get status of all circuit breakers."""
    return {
        name: cb.get_status() for name, cb in CircuitBreaker._instances.items()
    }


def get_all_rate_limiters_status() -> dict[str, dict[str, Any]]:
    """Get status of all rate limiters."""
    return {
        name: {
            "name": name,
            "max_calls": rl.config.max_calls,
            "period": rl.config.period,
            "remaining": rl.get_remaining(),
            "recent_calls": len(rl.calls),
        }
        for name, rl in RateLimiter._instances.items()
    }


def reset_all_resilience() -> None:
    """Reset all resilience components (for testing)."""
    CircuitBreaker.reset_all()
    RateLimiter.reset_all()
