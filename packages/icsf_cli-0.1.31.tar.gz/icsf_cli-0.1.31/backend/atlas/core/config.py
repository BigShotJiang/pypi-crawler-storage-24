from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class AppConfig:
    data_dir: str
    runs_dir: str
    aws_region: str
    aws_access_key_id: str | None
    aws_secret_access_key: str | None
    aws_session_token: str | None
    bedrock_model_id: str
    bedrock_embed_model_id: str
    github_token: str | None
    github_username: str | None
    github_email: str | None
    # QA: quality gate (release readiness)
    quality_gate_min_coverage_pct: float
    quality_gate_max_failures: int
    # QA: create GitHub issues for test failures (defect management)
    create_github_issues_for_failures: bool


def load_config() -> AppConfig:
    data_dir = os.getenv("APP_DATA_DIR", "/app/data").strip()
    runs_dir = os.getenv("APP_RUNS_DIR", "/tmp/ai-test-runs").strip()
    aws_region = os.getenv("AWS_REGION", "us-east-1").strip()
    aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID", "").strip() or None
    aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY", "").strip() or None
    aws_session_token = os.getenv("AWS_SESSION_TOKEN", "").strip() or None
    bedrock_model_id = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0").strip()
    bedrock_embed_model_id = os.getenv("BEDROCK_EMBED_MODEL_ID", "amazon.titan-embed-text-v1").strip()
    github_token = os.getenv("GITHUB_TOKEN", "").strip() or None
    github_username = os.getenv("GITHUB_USERNAME", "").strip() or None
    github_email = os.getenv("GITHUB_EMAIL", "").strip() or None
    quality_gate_min_coverage_pct = float(os.getenv("QUALITY_GATE_MIN_COVERAGE_PCT", "60").strip())
    quality_gate_max_failures = int(os.getenv("QUALITY_GATE_MAX_FAILURES", "0").strip())
    create_github_issues_for_failures = os.getenv("CREATE_GITHUB_ISSUES_FOR_FAILURES", "").strip().lower() in ("1", "true", "yes")

    return AppConfig(
        data_dir=data_dir,
        runs_dir=runs_dir,
        aws_region=aws_region,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token,
        bedrock_model_id=bedrock_model_id,
        bedrock_embed_model_id=bedrock_embed_model_id,
        github_token=github_token,
        github_username=github_username,
        github_email=github_email,
        quality_gate_min_coverage_pct=quality_gate_min_coverage_pct,
        quality_gate_max_failures=quality_gate_max_failures,
        create_github_issues_for_failures=create_github_issues_for_failures,
    )

