from __future__ import annotations

import glob
import os
import re
import xml.etree.ElementTree as ET

from atlas.reporting.models import CoverageReport, TestReport


def _safe_pct(num: float, den: float) -> float | None:
    if den <= 0:
        return None
    return round((num / den) * 100.0, 2)


def parse_surefire_reports(project_root: str) -> TestReport:
    """
    Parses Maven Surefire/Failsafe junit xml reports.
    """
    report_globs = [
        os.path.join(project_root, "**", "target", "surefire-reports", "TEST-*.xml"),
        os.path.join(project_root, "**", "target", "failsafe-reports", "TEST-*.xml"),
    ]
    files: list[str] = []
    for g in report_globs:
        found = glob.glob(g, recursive=True)
        files.extend(found)

    total = failed = errors = skipped = 0
    failed_tests: list[dict] = []
    for fp in files:
        try:
            root = ET.parse(fp).getroot()
        except Exception:
            continue

        if root.tag.endswith("testsuite"):
            total += int(root.attrib.get("tests", "0"))
            failed += int(root.attrib.get("failures", "0"))
            errors += int(root.attrib.get("errors", "0"))
            skipped += int(root.attrib.get("skipped", root.attrib.get("disabled", "0")))

            for tc in root.findall(".//testcase"):
                fn = tc.find("failure")
                en = tc.find("error")
                if fn is not None or en is not None:
                    msg_node = fn if fn is not None else en
                    failed_tests.append(
                        {
                            "classname": tc.attrib.get("classname"),
                            "name": tc.attrib.get("name"),
                            "message": (msg_node.attrib.get("message") if msg_node is not None else None),
                            "type": (msg_node.attrib.get("type") if msg_node is not None else None),
                            "text": (msg_node.text or "").strip()[:4000],
                            "report_file": fp,
                        }
                    )

    ok = (failed + errors) == 0 and total > 0
    return TestReport(ok=ok, total=total, failed=failed, errors=errors, skipped=skipped, failed_tests=failed_tests)


def get_passed_and_failed_test_keys(project_root: str) -> tuple[set[str], set[str]]:
    """
    Return (passed_keys, failed_keys) where each key is 'classname#name' for regression comparison.
    """
    report_globs = [
        os.path.join(project_root, "**", "target", "surefire-reports", "TEST-*.xml"),
        os.path.join(project_root, "**", "target", "failsafe-reports", "TEST-*.xml"),
    ]
    files: list[str] = []
    for g in report_globs:
        files.extend(glob.glob(g, recursive=True))

    passed: set[str] = set()
    failed: set[str] = set()
    for fp in files:
        try:
            root = ET.parse(fp).getroot()
        except Exception:
            continue
        if not root.tag.endswith("testsuite"):
            continue
        for tc in root.findall(".//testcase"):
            cn = tc.attrib.get("classname", "")
            nm = tc.attrib.get("name", "")
            key = f"{cn}#{nm}" if cn and nm else ""
            if not key:
                continue
            fn = tc.find("failure")
            en = tc.find("error")
            if fn is not None or en is not None:
                failed.add(key)
            else:
                passed.add(key)
    return passed, failed


def parse_jacoco_csv(project_root: str, logger: Any | None = None) -> CoverageReport:
    """
    Find all **/target/site/jacoco/jacoco.csv and aggregate for repo-wide (multi-module) coverage.
    """
    candidates = glob.glob(os.path.join(project_root, "**", "target", "site", "jacoco", "jacoco.csv"), recursive=True)
    if not candidates:
        if logger:
             logger.warn(f"[Analysis] JaCoCo CSV report not found in {project_root} (searched **/target/site/jacoco/jacoco.csv)")
        return CoverageReport(
            jacoco_found=False,
            instruction_covered_pct=None,
            branch_covered_pct=None,
            report_path=None,
            per_class=[],
        )

    ins_m = ins_c = br_m = br_c = 0.0
    per_class: list[dict] = []
    report_path_used: str | None = None

    for fp in candidates:
        try:
            lines = open(fp, "r", encoding="utf-8", errors="ignore").read().splitlines()
        except OSError:
            continue
        if not lines:
            continue
        header = lines[0].split(",")
        if "INSTRUCTION_MISSED" not in header:
            continue
        idx = {name: header.index(name) for name in header}
        if report_path_used is None:
            report_path_used = fp.replace("jacoco.csv", "index.html") if os.path.exists(fp.replace("jacoco.csv", "index.html")) else fp

        for row in lines[1:]:
            cols = row.split(",")
            try:
                ci_m = float(cols[idx["INSTRUCTION_MISSED"]])
                ci_c = float(cols[idx["INSTRUCTION_COVERED"]])
                cb_m = float(cols[idx.get("BRANCH_MISSED", -1)]) if "BRANCH_MISSED" in idx else 0.0
                cb_c = float(cols[idx.get("BRANCH_COVERED", -1)]) if "BRANCH_COVERED" in idx else 0.0
            except Exception:
                continue

            ins_m += ci_m
            ins_c += ci_c
            br_m += cb_m
            br_c += cb_c

            pkg = cols[idx.get("PACKAGE", -1)] if "PACKAGE" in idx else ""
            clazz = cols[idx.get("CLASS", -1)] if "CLASS" in idx else ""
            c_ins_pct = _safe_pct(ci_c, ci_m + ci_c)
            # Safe branch pct
            den_br = cb_m + cb_c
            c_br_pct = _safe_pct(cb_c, den_br) if den_br > 0 else None
            per_class.append(
                {
                    "package": pkg,
                    "class": clazz,
                    "instruction_covered_pct": c_ins_pct,
                    "branch_covered_pct": c_br_pct,
                }
            )

    if not per_class:
        return CoverageReport(
            jacoco_found=False,
            instruction_covered_pct=None,
            branch_covered_pct=None,
            report_path=None,
            per_class=[],
        )
    ins_pct = _safe_pct(ins_c, ins_m + ins_c)
    br_pct = _safe_pct(br_c, br_m + br_c) if (br_m + br_c) > 0 else None
    return CoverageReport(
        jacoco_found=True,
        instruction_covered_pct=ins_pct,
        branch_covered_pct=br_pct,
        report_path=report_path_used,
        per_class=sorted(
            per_class,
            key=lambda c: (c["instruction_covered_pct"] if c["instruction_covered_pct"] is not None else 0.0),
        ),
    )


def _strip_ansi(text: str) -> str:
    """Remove ANSI escape codes so stored messages are readable."""
    if not text:
        return ""
    return re.sub(r"\x1b\[[0-9;]*m|\u001b\[[0-9;]*m", "", text)


def classify_failure(out_or_err: str) -> dict[str, list[str]]:
    """
    Heuristic bucketing for breakage report.
    """
    out = {"build": [], "test": [], "runtime": [], "coverage": []}
    text = out_or_err or ""
    lines = text.splitlines()
    # Check the last 5000 chars for a more comprehensive tail
    tail = _strip_ansi(text[-5000:]) if len(text) > 5000 else _strip_ansi(text)
    full_text = tail.upper()

    # Build failures - check multiple patterns
    if "COMPILATION ERROR" in tail or "COMPILATION FAILURE" in full_text:
        out["build"].append("Compilation failure detected.")
    if "Failed to execute goal" in tail:
        # Extract the specific goal that failed (strip ANSI already done on tail)
        goal_match = re.search(r"Failed to execute goal\s+([^\s]+)", tail)
        if goal_match:
            out["build"].append(f"Failed to execute Maven goal: {_strip_ansi(goal_match.group(1))}")
        else:
            out["build"].append("Failed to execute Maven goal.")
    if "BUILD FAILURE" in full_text or "BUILD ERROR" in full_text:
        out["build"].append("Maven build failure detected.")
    if re.search(r"maven-compiler-plugin|compiler:compile|compiler:testCompile", tail, re.IGNORECASE):
        if "ERROR" in tail or "FAILURE" in tail:
            out["build"].append("Maven compiler plugin failure.")
    if "dependency" in tail.lower() and ("not found" in tail.lower() or "unresolved" in tail.lower()):
        out["build"].append("Dependency resolution failure.")
    if "plugin" in tail.lower() and ("not found" in tail.lower() or "unresolved" in tail.lower()):
        out["build"].append("Maven plugin resolution failure.")
    
    # Test failures
    if "There are test failures" in tail or "Surefire" in tail or "FAILURES!" in full_text:
        out["test"].append("Maven Surefire reported test failures.")
    
    # Runtime exceptions
    if re.search(r"Exception in thread|Caused by:|java\.lang\..*Exception", tail):
        out["runtime"].append("Runtime exception present in logs.")
    
    # Coverage failures
    if "jacoco-maven-plugin" in tail and ("execution" in tail and "failed" in tail):
        out["coverage"].append("JaCoCo execution failed.")
    
    # If no specific failures found but there are errors, try to extract key error lines
    if not any(out.values()) and lines:
        error_lines = [line for line in lines[-50:] if re.search(r"ERROR|FAILURE|FAILED|Exception", line, re.IGNORECASE)]
        if error_lines:
            # Take the most relevant error line
            key_error = error_lines[-1].strip()
            if len(key_error) < 200:  # Only if reasonable length
                out["build"].append(f"Build error: {key_error}")
    
    return out
