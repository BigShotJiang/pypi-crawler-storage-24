from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class BuildReport:
    ok: bool
    cmd: list[str]
    stderr_tail: str  # kept for backward compatibility
    output_tail: str  # last N lines of stdout + stderr combined (for failure diagnosis)
    fixed_errors: list[str] = field(default_factory=list) # errors identified and fixed by BuildMechanic


@dataclass
class TestReport:
    ok: bool
    total: int
    failed: int
    errors: int
    skipped: int
    failed_tests: list[dict[str, Any]] = field(default_factory=list)
    healer_history: list[dict[str, Any]] = field(default_factory=list) # history of healing attempts and results


@dataclass
class CoverageReport:
    jacoco_found: bool
    instruction_covered_pct: float | None
    branch_covered_pct: float | None
    report_path: str | None
    # Top-N per-class coverage details for identifying gaps
    per_class: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class GenerationReport:
    generated_files: list[str]
    summary: str
    new_tests: list[str] = field(default_factory=list)
    updated_tests: list[str] = field(default_factory=list)
    file_summaries: dict[str, dict[str, int]] = field(default_factory=dict) # {file_path: {"passed": N, "failed": M, "errors": K}}


@dataclass
class BreakageReport:
    build_failures: list[str]
    test_failures: list[str]
    runtime_exceptions: list[str]
    coverage_gaps: list[str]


@dataclass
class RegressionReport:
    """Baseline vs post-generation test comparison for regression focus."""
    baseline_total: int
    baseline_passed: int
    after_total: int
    after_passed: int
    regressions: list[str]  # test names that passed at baseline but failed after
    new_failures: list[str]  # newly generated tests that failed (for visibility)
    after_run_ok: bool = True  # False when post-generation mvn verify failed (compile/test)
    baseline_coverage_pct: float | None = None  # instruction coverage before new tests
    after_coverage_pct: float | None = None  # instruction coverage after new tests (must not decrease)


@dataclass
class RequirementsTraceability:
    """Maps requirement/spec IDs to generated tests (QA: requirements traceability)."""
    items: list[dict[str, Any]]  # [{"requirement_id": str, "description": str, "test_class": str, "test_method": str}, ...]


@dataclass
class DefectReport:
    """Structured defects from test failures (QA: defect management)."""
    defects: list[dict[str, Any]]  # [{"title": str, "test": str, "steps": str, "expected": str, "actual": str, "severity": str}, ...]
    github_issues_created: list[str] = field(default_factory=list)  # issue URLs if created


@dataclass
class QualityGateReport:
    """Release readiness: pass/fail against configurable thresholds (QA: sign-off)."""
    passed: bool
    min_coverage_pct: float
    max_failures_allowed: int
    reasons: list[str]  # why passed or failed
    release_recommendation: str  # "release_ready" | "release_with_caution" | "do_not_release"


@dataclass
class SecurityReport:
    """Dependency/security scan results (QA: security testing)."""
    run: bool
    vulnerabilities: list[dict[str, Any]] = field(default_factory=list)  # [{"cve": str, "artifact": str, "severity": str}, ...]
    summary: str = ""


@dataclass
class TestStrategyReport:
    """What we targeted and why (QA: test strategy visibility)."""
    targeted_low_coverage_classes: int
    targeted_requirements: int
    targeted_api_endpoints: int
    rationale: str


@dataclass
class UsageReport:
    """Token usage and cost tracking for the run."""
    input_tokens: int
    output_tokens: int
    estimated_cost_usd: float


@dataclass
class FullRunReport:
    repo_url: str
    run_id: str
    facts: dict[str, Any]
    sanity: dict[str, Any]
    build: BuildReport
    unit: TestReport
    coverage: CoverageReport
    generation: GenerationReport
    breakage: BreakageReport
    pr_url: str | None
    regression: RegressionReport | None = None
    requirements_traceability: RequirementsTraceability | None = None
    defects: DefectReport | None = None
    quality_gate: QualityGateReport | None = None
    security: SecurityReport | None = None
    test_strategy: TestStrategyReport | None = None
    usage: UsageReport | None = None
    duration_seconds: float | None = None


@dataclass
class OrganizationRunReport:
    """Aggregated report when scanning a whole organization."""
    org_url: str
    org_name: str
    repo_reports: list[FullRunReport]
    total_repos: int
    repos_ok: int
    repos_failed: int
    total_tests_run: int
    total_tests_passed: int
    total_generated: int
