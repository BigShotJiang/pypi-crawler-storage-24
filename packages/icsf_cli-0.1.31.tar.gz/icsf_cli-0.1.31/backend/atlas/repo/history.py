from __future__ import annotations

import json
import os
import logging
from typing import Dict

logger = logging.getLogger(__name__)

class AtlasHistoryRegistry:
    """
    Persistently stores the last successfully processed commit hash for a repository URL.
    This allows Atlas to detect if functionality has changed since the last test generation run.
    """
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.history_file = os.path.join(data_dir, "atlas_history.json")
        self._history: Dict[str, str] = {}
        self._load()

    def _load(self):
        """Load history from disk."""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, "r", encoding="utf-8") as f:
                    self._history = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load atlas history from {self.history_file}: {e}")
                self._history = {}
        else:
            self._history = {}

    def _save(self):
        """Save history to disk."""
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(self._history, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save atlas history to {self.history_file}: {e}")

    def get_last_commit(self, repo_url: str) -> str | None:
        """Get the last processed commit hash for a repo URL."""
        return self._history.get(repo_url)

    def update_last_commit(self, repo_url: str, commit_hash: str):
        """Update and save the last processed commit hash for a repo URL."""
        self._history[repo_url] = commit_hash
        self._save()
