from __future__ import annotations

import os
import re
import shutil
from datetime import datetime
from dataclasses import dataclass
from hashlib import md5

from git import Repo


@dataclass(frozen=True)
class ClonedRepo:
    run_id: str
    repo_url: str
    path: str


def extract_repo_name(repo_url: str) -> str:
    """Extract repository name from URL for use in IDs."""
    # Match patterns like: github.com/owner/repo or git@github.com:owner/repo
    m = re.search(r"(?:github\.com[:/]|git@github\.com:)([^/]+)/([^/]+?)(?:\.git)?$", repo_url)
    if m:
        return m.group(2).lower().replace("_", "-")
    # Fallback: use last part of URL or a default
    parts = repo_url.rstrip("/").split("/")
    if parts:
        name = parts[-1].replace(".git", "").lower().replace("_", "-")
        return name[:30]  # Limit length
    return "repo"


def _generate_run_id(repo_url: str) -> str:
    """Generate a simple, meaningful run ID based on timestamp and repo."""
    now = datetime.now()
    timestamp = now.strftime("%Y%m%d-%H%M%S")
    
    # Add short hash for uniqueness (in case multiple runs happen in same second)
    repo_hash = md5(repo_url.encode()).hexdigest()[:4]
    
    return f"{timestamp}-{repo_hash}"


class RepoCloner:
    def __init__(self, runs_dir: str, github_token: str | None = None):
        self.runs_dir = runs_dir
        self.github_token = github_token
        os.makedirs(self.runs_dir, exist_ok=True)

    def _authenticated_url(self, repo_url: str) -> str:
        """Embed GitHub token into HTTPS URL to avoid interactive credential prompts."""
        if self.github_token and repo_url.startswith("https://github.com/"):
            # https://github.com/owner/repo  ->  https://<token>@github.com/owner/repo
            return repo_url.replace("https://", f"https://{self.github_token}@", 1)
        return repo_url

    def clone(self, repo_url: str) -> ClonedRepo:
        run_id = _generate_run_id(repo_url)
        run_dir = os.path.join(self.runs_dir, run_id)
        os.makedirs(run_dir, exist_ok=True)

        repo_path = os.path.join(run_dir, "repo")
        clone_url = self._authenticated_url(repo_url)
        Repo.clone_from(clone_url, repo_path)
        return ClonedRepo(run_id=run_id, repo_url=repo_url, path=repo_path)

    def cleanup(self, cloned: ClonedRepo) -> None:
        # Delete entire run directory (repo + logs + outputs), RAG DB is elsewhere.
        run_dir = os.path.dirname(cloned.path)
        if os.path.exists(run_dir):
            shutil.rmtree(run_dir, ignore_errors=True)
