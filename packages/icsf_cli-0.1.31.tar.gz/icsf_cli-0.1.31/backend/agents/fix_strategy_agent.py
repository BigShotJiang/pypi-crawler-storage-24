"""
Agent 3: Fix Strategy Agent

This agent determines the best fix approach based on:
- Vulnerability analysis from Agent 1
- Code context and dependencies from Agent 2

It creates a detailed plan for code modifications, identifies files to modify,
and assesses risks and testing considerations.
"""

import json
import logging
import os
from typing import Dict, Any, Optional, List

from ..models.agent_models import (
    VulnerabilityFixRequest,
    VulnerabilityAnalysis,
    CodeContext,
    FixStrategy,
)
from ..services.bedrock_service import BedrockService
from .codebase_analysis_agent import CodebaseAnalysisAgent
from .agent_improvements import FrameworkDetector

logger = logging.getLogger(__name__)


class FixStrategyAgent:
    """Agent that determines the optimal fix strategy"""
    
    def __init__(self, bedrock_service: BedrockService):
        """
        Initialize Fix Strategy Agent.
        
        Args:
            bedrock_service: BedrockService instance for model invocation
        """
        self.bedrock_service = bedrock_service
        self.agent_name = "FixStrategyAgent"
        self.codebase_analyzer = CodebaseAnalysisAgent(bedrock_service)
        
        # Use Claude 3.5 Sonnet for strategy planning
        self.model_id = bedrock_service.CLAUDE_3_5_SONNET
        self.fallback_model_id = bedrock_service.CLAUDE_3_SONNET
    
    def _get_available_java_files(self, repo_path: str, max_files: int = 100) -> List[str]:
        """
        Get list of available Java files in the repository for validation.
        Handles monorepo structures and provides comprehensive file listing.
        
        Args:
            repo_path: Path to repository root
            max_files: Maximum number of files to return
            
        Returns:
            List of Java file paths relative to repo root
        """
        java_files = []
        try:
            repo_path_obj = os.path.abspath(repo_path)
            for root, dirs, files in os.walk(repo_path_obj):
                # Skip hidden directories and common build/test directories
                dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['target', 'build', 'out', 'node_modules', '.git']]
                
                for file in files:
                    if file.endswith('.java'):
                        full_path = os.path.join(root, file)
                        # Get relative path from repo root
                        rel_path = os.path.relpath(full_path, repo_path_obj)
                        # Normalize path separators
                        rel_path = rel_path.replace('\\', '/')
                        java_files.append(rel_path)
                        
                        if len(java_files) >= max_files:
                            return java_files
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Error getting Java files: {str(e)}")
        
        return java_files
    
    def _analyze_file_imports_and_usage(self, repo_path: str, file_path: str) -> List[str]:
        """
        Analyze imports and class usage in a file to identify which files might need changes.
        
        Args:
            repo_path: Repository root path
            file_path: Path to file to analyze
            
        Returns:
            List of file paths that are imported/used
        """
        imported_files = []
        try:
            full_path = os.path.join(repo_path, file_path)
            if not os.path.exists(full_path):
                return imported_files
            
            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Extract import statements
            import re
            import_pattern = re.compile(r'import\s+([\w.]+)\.(\w+);')
            imports = import_pattern.findall(content)
            
            # Extract class instantiations (e.g., new BankDAOImpl())
            instantiation_pattern = re.compile(r'new\s+(\w+)\s*\(')
            instantiations = instantiation_pattern.findall(content)
            
            # Find corresponding Java files
            for package, class_name in imports:
                # Convert package to path
                package_path = package.replace('.', '/')
                possible_paths = [
                    f"src/main/java/{package_path}/{class_name}.java",
                    f"src/{package_path}/{class_name}.java",
                    f"{package_path}/{class_name}.java",
                ]
                
                for possible_path in possible_paths:
                    if os.path.exists(os.path.join(repo_path, possible_path)):
                        if possible_path not in imported_files:
                            imported_files.append(possible_path)
                        break
            
            # Also check instantiations
            for class_name in instantiations:
                # Try to find the file
                possible_paths = [
                    f"src/main/java/dao/{class_name}.java",
                    f"src/main/java/service/{class_name}.java",
                    f"src/main/java/models/{class_name}.java",
                    f"src/main/java/{class_name}.java",
                ]
                
                for possible_path in possible_paths:
                    if os.path.exists(os.path.join(repo_path, possible_path)):
                        if possible_path not in imported_files:
                            imported_files.append(possible_path)
                        break
        
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Error analyzing imports: {str(e)}")
        
        return imported_files
    
    def _build_strategy_prompt(
        self,
        request: VulnerabilityFixRequest,
        vulnerability_analysis: VulnerabilityAnalysis,
        code_context: CodeContext
    ) -> str:
        """
        Build prompt for fix strategy determination.
        
        Args:
            request: VulnerabilityFixRequest
            vulnerability_analysis: Analysis from Agent 1
            code_context: Context from Agent 2
            
        Returns:
            Formatted prompt string
        """
        # Analyze imports and usage in vulnerable file
        imported_files = self._analyze_file_imports_and_usage(request.repo_path, request.file_path)
        imported_files_text = ""
        if imported_files:
            imported_files_text = f"\n\nFILES IMPORTED/USED BY VULNERABLE FILE (these may need changes if new methods are required):\n" + '\n'.join(f"  - {f}" for f in imported_files[:10])
        
        # Get available Java files in repository for reference
        available_files = self._get_available_java_files(request.repo_path, max_files=100)
        available_files_text = ""
        if available_files:
            # Show relevant files (those in same package or related directories)
            vulnerable_dir = '/'.join(request.file_path.split('/')[:-1]) if '/' in request.file_path else ''
            vulnerable_file_name = request.file_path.split('/')[-1] if '/' in request.file_path else request.file_path
            
            # Find files in same directory or related directories
            relevant_files = []
            for f in available_files:
                # Same directory
                if vulnerable_dir and vulnerable_dir in f:
                    relevant_files.append(f)
                # Related directories (config, security, etc.)
                elif any(keyword in f.lower() for keyword in ['config', 'security', 'controller', 'service', 'dao', 'model']):
                    if len(relevant_files) < 30:  # Limit to avoid too many files
                        relevant_files.append(f)
                # Files that might be related based on naming
                elif any(keyword in f.lower() for keyword in [vulnerable_file_name.replace('.java', '').lower(), 'security', 'config']):
                    if len(relevant_files) < 30:
                        relevant_files.append(f)
            
            # Remove duplicates and limit
            relevant_files = list(dict.fromkeys(relevant_files))[:30]
            
            if relevant_files:
                available_files_text = f"\n\nAVAILABLE JAVA FILES IN REPOSITORY (ONLY list files from this list - these are the files that ACTUALLY EXIST):\n" + '\n'.join(f"  - {f}" for f in relevant_files)
            else:
                available_files_text = f"\n\nAVAILABLE JAVA FILES IN REPOSITORY (ONLY list files from this list - these are the files that ACTUALLY EXIST):\n" + '\n'.join(f"  - {f}" for f in available_files[:30])
        
        # Build dependency summary with method-level details
        intra_dep_summary = f"{len(code_context.dependent_files_intra)} intra-repository files"
        inter_dep_summary = f"{len(code_context.dependent_files_inter)} inter-repository files"
        
        dependent_files_list = []
        affected_files_list = []
        
        if code_context.dependent_files_intra:
            dependent_files_list.append(f"\nIntra-repo dependent files ({len(code_context.dependent_files_intra)} total):")
            for dep in code_context.dependent_files_intra[:15]:  # Show first 15
                dep_file = dep.get('file', 'Unknown')
                dep_type = dep.get('dependency_type', 'Unknown')
                methods_used = dep.get('methods_used', [])
                will_be_affected = dep.get('will_be_affected', False)
                
                dep_info = f"  - {dep_file} (type: {dep_type})"
                if methods_used:
                    dep_info += f" [Uses methods: {', '.join(methods_used)}]"
                if will_be_affected:
                    dep_info += " ⚠️ WILL BE AFFECTED BY FIX"
                    affected_files_list.append(f"  - {dep_file} (uses: {', '.join(methods_used)})")
                else:
                    dep_info += " ✓ No changes needed (doesn't use vulnerable method)"
                dependent_files_list.append(dep_info)
        
        if code_context.dependent_files_inter:
            dependent_files_list.append(f"\nInter-repo dependent files ({len(code_context.dependent_files_inter)} total):")
            for dep in code_context.dependent_files_inter[:15]:  # Show first 15
                dep_file = dep.get('file', 'Unknown')
                dep_repo = dep.get('repo', 'Unknown')
                methods_used = dep.get('methods_used', [])
                will_be_affected = dep.get('will_be_affected', False)
                
                dep_info = f"  - {dep_repo}/{dep_file}"
                if methods_used:
                    dep_info += f" [Uses methods: {', '.join(methods_used)}]"
                if will_be_affected:
                    dep_info += " ⚠️ WILL BE AFFECTED BY FIX"
                    affected_files_list.append(f"  - {dep_repo}/{dep_file} (uses: {', '.join(methods_used)})")
                else:
                    dep_info += " ✓ No changes needed (doesn't use vulnerable method)"
                dependent_files_list.append(dep_info)
        
        dependencies_text = '\n'.join(dependent_files_list) if dependent_files_list else "No dependent files found."
        
        # Count affected files
        affected_count = len(affected_files_list)
        total_deps = len(code_context.dependent_files_intra) + len(code_context.dependent_files_inter)
        
        if affected_files_list:
            affected_files_text = f"⚠️ {affected_count} file(s) will be affected:\n" + '\n'.join(affected_files_list)
        else:
            if total_deps > 0:
                affected_files_text = f"✅ No dependent files need changes. Found {total_deps} dependent file(s), but none of them use the methods being changed. The fix can be applied to the vulnerable file only."
            else:
                affected_files_text = "✅ No dependent files found. The fix can be applied to the vulnerable file only."
        
        prompt = f"""You are a security expert determining the best fix strategy for a vulnerability.

VULNERABILITY DETAILS:
- Type: {request.vulnerability_type}
- Severity: {vulnerability_analysis.severity.value}
- Description: {request.description}
- Scanner Recommendation: {request.recommendation or 'None provided'}

VULNERABILITY ANALYSIS (from Agent 1):
- Fix Category: {vulnerability_analysis.fix_category}
- Security Impact:
  * Confidentiality: {vulnerability_analysis.security_impact.confidentiality}
  * Integrity: {vulnerability_analysis.security_impact.integrity}
  * Availability: {vulnerability_analysis.security_impact.availability}
  * Overall Risk: {vulnerability_analysis.security_impact.overall_risk}
- Typical Fix Approach: {vulnerability_analysis.typical_fix_approach}
- Root Causes: {', '.join(vulnerability_analysis.root_causes[:5])}

CODE CONTEXT (from Agent 2):
- Vulnerable File: {code_context.vulnerable_file}
- Line Number: {code_context.vulnerable_line}
- Class: {code_context.class_name or 'Unknown'}
- Method: {code_context.method_name or 'Unknown'}
- Data Flow: {code_context.data_flow or 'Not analyzed'}
- Usage Patterns: {', '.join(code_context.usage_patterns) if code_context.usage_patterns else 'None'}

CODE SNIPPET:
```java
{code_context.code_snippet}
```

DEPENDENCIES:
{dependencies_text}

FILES THAT WILL BE AFFECTED BY FIX:
{affected_files_text}

ANALYSIS OF CODE USAGE:
- The vulnerable file uses: {code_context.class_name or 'Unknown'} class
- It imports and uses: {', '.join(set([dep.get('file', '').split('/')[-1] for dep in code_context.dependent_files_intra[:10] if dep.get('file')])) if code_context.dependent_files_intra else 'No dependencies found'}
{imported_files_text}
- CRITICAL: If your fix plan mentions creating methods in imported classes (e.g., "Create hasAccountAccess method in BankDAOImpl"), that class file MUST be in files_to_modify_primary
- CRITICAL: If the vulnerable file uses a DAO/Service class and you need to add methods to it, include that file in files_to_modify_primary

DEPENDENT FILES ANALYSIS:
- Total intra-repo dependent files: {len(code_context.dependent_files_intra)}
- Total inter-repo dependent files: {len(code_context.dependent_files_inter)}
- Files that use methods being changed: {len([d for d in code_context.dependent_files_intra + code_context.dependent_files_inter if d.get('will_be_affected', False)])}
{available_files_text}

CRITICAL CONSIDERATION:
- The vulnerable method/function is: {code_context.method_name or 'Unknown'}
- If you change the method signature, return type, or behavior, the affected files listed above WILL BREAK
- You MUST either:
  1. Maintain backward compatibility (same signature, same behavior)
  2. OR identify which dependent files need to be updated
  3. OR provide a migration path for dependent files

IMPORTANT:
- If NO files use the methods being changed, clearly state: "No dependent files need to be modified - the fix only affects the vulnerable file internally"
- If dependent files exist but don't use the vulnerable method, state: "Dependent files exist but do not directly use the vulnerable method - no changes needed in dependent files"
- Only list files in "files_to_modify_secondary" if they ACTUALLY need changes

TASK:
Determine the optimal fix strategy and provide a detailed JSON response with:

1. "fix_approach": A clear, comprehensive description of the fix approach (2-3 paragraphs explaining the strategy)

2. "code_changes_plan": A step-by-step list of code modifications needed (e.g., ["Step 1: Replace string concatenation with PreparedStatement", "Step 2: Add input validation", "Step 3: Update error handling"])

3. "files_to_modify_primary": List of ALL primary files that MUST be modified for the fix to work end-to-end. This MUST include:
   - The vulnerable file (e.g., Withdraw.java)
   - ANY files where you mention creating new methods (e.g., if you say "Create method in BankDAOImpl", then BankDAOImpl.java MUST be in this list)
   - ANY files where you mention modifying existing methods
   - Example: If your plan says "Step 1: Create method in BankDAOImpl" and "Step 2: Modify Withdraw.java", then BOTH files must be listed: ["src/main/java/controllers/Withdraw.java", "src/main/java/dao/BankDAOImpl.java"]

4. "files_to_modify_secondary": List of secondary files that MUST be updated because they use the methods being changed (from the affected files list above). These files will break if not updated.

5. "risk_assessment": Assessment of risks associated with applying this fix (e.g., breaking changes, performance impact, compatibility issues)

6. "backward_compatibility": Boolean indicating whether the fix maintains backward compatibility (true/false)

7. "testing_considerations": List of testing considerations (e.g., ["Unit tests for input validation", "Integration tests for database queries", "Regression tests for dependent services"])

CRITICAL REQUIREMENT - END-TO-END FUNCTIONALITY:
- The application MUST run end-to-end after the fix is applied
- If you identify that multiple files need to be changed (e.g., controller + DAO), ALL must be listed in "files_to_modify_primary"
- Do NOT split files between primary and secondary - if a file is required for the fix to work, it MUST be in "files_to_modify_primary"
- Example: If Withdraw.java uses BankDAOImpl.java and both need changes, list BOTH in "files_to_modify_primary"
- The fix strategy should ensure the complete application works, not just the vulnerable file
- CRITICAL: If your code_changes_plan mentions creating or modifying methods in a specific file (e.g., "Create method in BankDAOImpl"), that file MUST be included in "files_to_modify_primary"
- CRITICAL: Every file mentioned in your code_changes_plan steps MUST be listed in "files_to_modify_primary"

IMPORTANT:
- Consider the dependent files (both intra and inter-repo) when determining which files to modify
- Ensure the fix addresses the root causes identified
- Consider data flow and usage patterns when planning changes
- Balance security with maintainability and performance
- List ALL files that need to be changed for the application to work end-to-end in "files_to_modify_primary"
- CRITICAL: Only list files that ACTUALLY EXIST in the repository. Do NOT suggest creating new files or listing files that don't exist.
- CRITICAL: ONLY use file paths from the "AVAILABLE JAVA FILES IN REPOSITORY" list above. Do NOT invent or guess file paths.
- CRITICAL: If a file is not in the available files list, DO NOT include it in files_to_modify_primary, even if you think it should exist.
- Use the exact file paths from the "AVAILABLE JAVA FILES IN REPOSITORY" list. Copy the paths exactly as shown.
- If you need to modify a file that's not in the list, you CANNOT modify it - only work with files that exist.

Respond with valid JSON only, without markdown code blocks."""
        
        return prompt
    
    def _parse_strategy_response(self, response_content: str) -> Dict[str, Any]:
        """
        Parse agent response into structured data.
        
        Args:
            response_content: Raw response content from model
            
        Returns:
            Parsed dictionary with strategy details
        """
        try:
            # Remove markdown code blocks if present
            content = response_content.strip()
            if content.startswith("```json"):
                content = content[7:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
            
            # Parse JSON with strict=False to allow control characters in strings
            parsed = json.loads(content, strict=False)
            return parsed
            
        except json.JSONDecodeError as e:
            logger.error(f"[{self.agent_name}] Failed to parse JSON response: {str(e)}")
            logger.debug(f"Response content: {response_content[:500]}")
            
            # Try to extract JSON from response using a more robust regex
            import re
            # Find the first { and the last }
            json_match = re.search(r'(\{.*\})', content, re.DOTALL)
            if json_match:
                try:
                    # Parse extracted JSON with strict=False
                    parsed = json.loads(json_match.group(1), strict=False)
                    return parsed
                except:
                    pass
            
            # Return default structure if parsing fails
            return {
                'fix_approach': 'Fix strategy analysis unavailable',
                'code_changes_plan': [],
                'files_to_modify_primary': [],
                'files_to_modify_secondary': [],
                'risk_assessment': 'Unable to assess risks',
                'backward_compatibility': True,
                'testing_considerations': []
            }
    
    async def analyze(
        self,
        request: VulnerabilityFixRequest,
        vulnerability_analysis: VulnerabilityAnalysis,
        code_context: CodeContext
    ) -> FixStrategy:
        """
        Determine the best fix strategy for a vulnerability.
        
        Args:
            request: VulnerabilityFixRequest with vulnerability details
            vulnerability_analysis: Analysis from Agent 1
            code_context: Context from Agent 2
            
        Returns:
            FixStrategy with detailed fix plan
        """
        logger.info(
            f"[{self.agent_name}] Determining fix strategy for "
            f"{request.vulnerability_type} in {request.file_path}:{request.line_number}"
        )
        
        # Enhanced analysis: Find additional dependent files using codebase analyzer
        logger.info(f"[{self.agent_name}] Performing enhanced dependent file analysis...")
        enhanced_deps = self.codebase_analyzer.find_dependent_files(
            repo_path=request.repo_path,
            target_file=request.file_path,
            max_depth=3
        )
        
        # Merge enhanced analysis results with existing code context
        # Add any new dependent files found
        existing_files = {dep.get('file') for dep in code_context.dependent_files_intra}
        for new_file in enhanced_deps.get('direct_dependents', []):
            if new_file not in existing_files:
                code_context.dependent_files_intra.append({
                    'file': new_file,
                    'type': 'enhanced_analysis',
                    'relationship': 'uses_class_or_method'
                })
        
        # Build prompt
        prompt = self._build_strategy_prompt(
            request=request,
            vulnerability_analysis=vulnerability_analysis,
            code_context=code_context
        )
        
        # Invoke Bedrock model
        result = await self.bedrock_service.ainvoke_claude(
            prompt=prompt,
            model_id=self.model_id,
            max_tokens=3072,  # Longer response needed for detailed strategy
            temperature=0.4  # Slightly higher for creative strategy thinking
        )
        
        # If Claude 3.5 Sonnet fails, try Claude 3 Sonnet
        if not result['success']:
            logger.warning(f"[{self.agent_name}] Claude 3.5 Sonnet not available, trying Claude 3 Sonnet...")
            result = await self.bedrock_service.ainvoke_claude(
                prompt=prompt,
                model_id=self.fallback_model_id,
                max_tokens=3072,
                temperature=0.4
            )
        
        if not result['success']:
            logger.error(f"[{self.agent_name}] Failed to invoke model: {result.get('error_message')}")
            raise Exception(f"Model invocation failed: {result.get('error_message')}")
        
        # Parse response
        strategy_data = self._parse_strategy_response(result['content'])
        
        # Ensure vulnerable file is in primary files
        primary_files = strategy_data.get('files_to_modify_primary', [])
        if request.file_path not in primary_files:
            primary_files.insert(0, request.file_path)
        
        # Extract file names mentioned in code_changes_plan and add them to primary files
        # This ensures files mentioned in steps (e.g., "Create method in BankDAOImpl") are included
        code_changes_plan = strategy_data.get('code_changes_plan', [])
        if isinstance(code_changes_plan, list):
            import re
            for step in code_changes_plan:
                step_str = str(step)
                # Look for file patterns like "BankDAOImpl.java", "dao/BankDAOImpl.java", etc.
                # Match patterns like: "in BankDAOImpl", "in BankDAOImpl.java", "BankDAOImpl class", etc.
                file_patterns = [
                    r'(\w+\.java)',  # Matches "BankDAOImpl.java"
                    r'in\s+(\w+\.java)',  # Matches "in BankDAOImpl.java"
                    r'in\s+(\w+)',  # Matches "in BankDAOImpl"
                    r'(\w+/\w+\.java)',  # Matches "dao/BankDAOImpl.java"
                    r'(\w+/\w+/\w+\.java)',  # Matches "src/main/java/dao/BankDAOImpl.java"
                ]
                
                for pattern in file_patterns:
                    matches = re.findall(pattern, step_str, re.IGNORECASE)
                    for match in matches:
                        if isinstance(match, tuple):
                            match = match[0]
                        
                        # Try to find the full path by searching available files
                        file_name = match
                        if not file_name.endswith('.java'):
                            file_name = match + '.java'
                        
                        # Get available files to search (use cached list if available)
                        available_files_for_search = self._get_available_java_files(request.repo_path, max_files=200)
                        
                        # Search for matching file in available files
                        found_file = None
                        class_name = file_name.replace('.java', '').lower()
                        
                        for available_file in available_files_for_search:
                            # Check if file name matches (case-insensitive)
                            if available_file.lower().endswith(file_name.lower()):
                                found_file = available_file
                                break
                            # Check if class name is in path
                            if class_name in available_file.lower() and available_file.endswith('.java'):
                                # Prefer exact matches
                                if available_file.lower().endswith(f"/{file_name.lower()}"):
                                    found_file = available_file
                                    break
                                elif not found_file:  # Use first match as fallback
                                    found_file = available_file
                        
                        # If found and not already in list, add it
                        if found_file and found_file not in primary_files:
                            logger.info(
                                f"[{self.agent_name}] Found file mentioned in plan: {found_file}, adding to primary files"
                            )
                            primary_files.append(found_file)
                        elif not found_file:
                            logger.debug(
                                f"[{self.agent_name}] File mentioned in plan ({file_name}) not found in repository, skipping"
                            )
        
        # Validate that all files actually exist in the repository
        validated_primary_files = []
        for file_path in primary_files:
            full_path = os.path.join(request.repo_path, file_path)
            if os.path.exists(full_path):
                validated_primary_files.append(file_path)
            else:
                logger.warning(
                    f"[{self.agent_name}] File from strategy does not exist: {file_path} "
                    f"(full path: {full_path}), removing from list"
                )
        
        # Ensure vulnerable file is always included (even if it doesn't exist, we'll handle that later)
        if request.file_path not in validated_primary_files:
            validated_primary_files.insert(0, request.file_path)
        
        primary_files = validated_primary_files
        
        # Normalize risk_assessment (convert list to string if needed)
        risk_assessment = strategy_data.get('risk_assessment', 'Risk assessment not available')
        if isinstance(risk_assessment, list):
            # Join list items with newlines
            risk_assessment = '\n'.join(str(item) for item in risk_assessment)
        elif not isinstance(risk_assessment, str):
            risk_assessment = str(risk_assessment)
        
        # Normalize fix_approach (convert list to string if needed)
        fix_approach = strategy_data.get('fix_approach', 'Fix strategy not determined')
        if isinstance(fix_approach, list):
            fix_approach = '\n'.join(str(item) for item in fix_approach)
        elif not isinstance(fix_approach, str):
            fix_approach = str(fix_approach)
        
        # Ensure code_changes_plan is a list
        code_changes_plan = strategy_data.get('code_changes_plan', [])
        if not isinstance(code_changes_plan, list):
            if isinstance(code_changes_plan, str):
                # Split string by lines if it's a string
                code_changes_plan = [line.strip() for line in code_changes_plan.split('\n') if line.strip()]
            else:
                code_changes_plan = []
        
        # Ensure files_to_modify_secondary is a list
        files_to_modify_secondary = strategy_data.get('files_to_modify_secondary', [])
        if not isinstance(files_to_modify_secondary, list):
            files_to_modify_secondary = []
        
        # Ensure testing_considerations is a list
        testing_considerations = strategy_data.get('testing_considerations', [])
        if not isinstance(testing_considerations, list):
            if isinstance(testing_considerations, str):
                # Split string by lines if it's a string
                testing_considerations = [line.strip() for line in testing_considerations.split('\n') if line.strip()]
            else:
                testing_considerations = []
        
        # Build FixStrategy object
        fix_strategy = FixStrategy(
            fix_approach=fix_approach,
            code_changes_plan=code_changes_plan,
            files_to_modify_primary=primary_files,
            files_to_modify_secondary=files_to_modify_secondary,
            risk_assessment=risk_assessment,
            backward_compatibility=bool(strategy_data.get('backward_compatibility', True)),
            testing_considerations=testing_considerations
        )
        
        logger.info(
            f"[{self.agent_name}] Strategy determined. "
            f"Primary files: {len(fix_strategy.files_to_modify_primary)}, "
            f"Secondary files: {len(fix_strategy.files_to_modify_secondary)}"
        )
        
        return fix_strategy

