"""
Agent 2: Code Context Agent

This agent analyzes the vulnerable file and its dependencies to understand
the code context, data flow, and impact of the vulnerability.
"""

import os
import re
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List

# Package-relative imports so this agent works from both source and installed wheel.
from ..models.agent_models import (
    VulnerabilityFixRequest,
    VulnerabilityAnalysis,
    CodeContext,
)
from ..services.bedrock_service import BedrockService
from ..services.dependency_service import DependencyService
from .codebase_analysis_agent import CodebaseAnalysisAgent

logger = logging.getLogger(__name__)


class CodeContextAgent:
    """Agent that analyzes code context and dependencies"""
    
    def __init__(self, bedrock_service: BedrockService):
        """
        Initialize Code Context Agent.
        
        Args:
            bedrock_service: BedrockService instance for model invocation
        """
        self.bedrock_service = bedrock_service
        self.agent_name = "CodeContextAgent"
        self.dependency_service = DependencyService()
        self.codebase_analyzer = CodebaseAnalysisAgent(bedrock_service)
        
        # Use Claude 3.5 Sonnet for analysis
        self.model_id = bedrock_service.CLAUDE_3_5_SONNET
        self.fallback_model_id = bedrock_service.CLAUDE_3_SONNET
    
    def _read_file_with_context(
        self,
        file_path: str,
        line_number: int,
        context_lines: int = 10
    ) -> Dict[str, Any]:
        """
        Read file and extract code snippet with context around vulnerable line.
        Enhanced to include class and method context even if vulnerable line is in imports.
        
        Args:
            file_path: Path to the file
            line_number: Line number of vulnerability
            context_lines: Number of lines before/after to include
            
        Returns:
            Dictionary with file content, snippet, and metadata
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            total_lines = len(lines)
            start_line = max(0, line_number - context_lines - 1)  # -1 for 0-indexing
            end_line = min(total_lines, line_number + context_lines)
            
            # Extract snippet
            snippet_lines = lines[start_line:end_line]
            snippet = ''.join(snippet_lines)
            
            # If snippet only contains package/import statements, expand to include class definition
            snippet_lower = snippet.lower()
            if ('package' in snippet_lower or 'import' in snippet_lower) and 'class' not in snippet_lower:
                # Find the first class definition in the file
                for i, line in enumerate(lines):
                    if 'class' in line.lower() and '{' in line:
                        # Include class definition and some methods
                        class_start = max(0, i - 2)
                        class_end = min(total_lines, i + 30)  # Include class and first few methods
                        snippet_lines = lines[class_start:class_end]
                        snippet = ''.join(snippet_lines)
                        start_line = class_start
                        end_line = class_end
                        break
            
            # Extract lines before and after
            lines_before = lines[max(0, start_line - context_lines):start_line]
            lines_after = lines[end_line:min(total_lines, end_line + context_lines)]
            
            return {
                'full_content': ''.join(lines),
                'snippet': snippet,
                'lines_before': ''.join(lines_before),
                'lines_after': ''.join(lines_after),
                'start_line': start_line + 1,  # Convert to 1-indexed
                'end_line': end_line,
                'total_lines': total_lines
            }
            
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error reading file {file_path}: {str(e)}")
            return {
                'full_content': '',
                'snippet': '',
                'lines_before': '',
                'lines_after': '',
                'start_line': 0,
                'end_line': 0,
                'total_lines': 0
            }
    
    def _extract_class_and_method(
        self,
        file_path: str,
        line_number: int,
        code_content: str
    ) -> Dict[str, Optional[str]]:
        """
        Extract class and method information from Java code.
        
        Args:
            file_path: Path to the file
            line_number: Line number of vulnerability
            code_content: Full file content
            
        Returns:
            Dictionary with class_name, method_name, and function_signature
        """
        class_name = None
        method_name = None
        function_signature = None
        
        try:
            lines = code_content.split('\n')
            current_class = None
            current_method = None
            brace_count = 0
            method_brace_count = 0
            
            # Find class and method containing the vulnerable line
            for i, line in enumerate(lines[:line_number], 1):
                # Extract class name
                class_match = re.search(r'^\s*(?:public|private|protected)?\s*class\s+(\w+)', line)
                if class_match:
                    current_class = class_match.group(1)
                    brace_count = 0
                
                # Track braces for class scope
                brace_count += line.count('{') - line.count('}')
                
                # Extract method signature (only within class scope)
                if current_class and brace_count > 0:
                    method_match = re.search(
                        r'^\s*(?:public|private|protected)?\s*(?:static)?\s*(?:[\w<>\[\]]+\s+)?(\w+)\s*\([^)]*\)\s*(?:\w+\s*)?\{?',
                        line
                    )
                    if method_match:
                        method_name = method_match.group(1)
                        # Extract full method signature
                        if '{' in line:
                            function_signature = line.strip()
                            method_brace_count = 1
                        else:
                            # Multi-line method signature
                            sig_lines = [line]
                            j = i
                            while j < len(lines) and '{' not in lines[j-1]:
                                sig_lines.append(lines[j-1])
                                j += 1
                            if j < len(lines):
                                sig_lines.append(lines[j-1])
                                function_signature = ' '.join(s.strip() for s in sig_lines)
                                method_brace_count = 1
                    
                    # Track method scope
                    if method_brace_count > 0:
                        method_brace_count += line.count('{') - line.count('}')
                        if method_brace_count == 0:
                            # Method ended, reset
                            if i < line_number:
                                method_name = None
                                function_signature = None
            
            if current_class:
                class_name = current_class
                
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Error extracting class/method: {str(e)}")
        
        return {
            'class_name': class_name,
            'method_name': method_name,
            'function_signature': function_signature
        }
    
    async def _analyze_data_flow_and_usage(
        self,
        code_snippet: str,
        vulnerability_type: str,
        class_name: Optional[str],
        method_name: Optional[str]
    ) -> Dict[str, Any]:
        """
        Use Bedrock to analyze data flow and usage patterns.
        
        Args:
            code_snippet: Vulnerable code snippet
            vulnerability_type: Type of vulnerability
            class_name: Class name
            method_name: Method name
            
        Returns:
            Dictionary with data_flow and usage_patterns
        """
        prompt = f"""Analyze this code snippet to understand data flow and usage patterns around a security vulnerability.

Vulnerability Type: {vulnerability_type}
Class: {class_name or "Unknown"}
Method: {method_name or "Unknown"}

Code Snippet:
```java
{code_snippet}
```

IMPORTANT: 
- If the snippet only shows package/import statements, analyze the class structure and method signatures shown
- Focus on the class and method context provided, even if the vulnerable line is in imports
- Provide meaningful analysis based on available context

Provide a JSON response with:
1. "data_flow": A concise description of how data flows around the vulnerable line (where data comes from, how it's used, where it goes). If only package/imports are visible, describe the class structure and potential data flow based on the class/method context.
2. "usage_patterns": A list of usage patterns (e.g., "Direct user input", "Database query construction", "String concatenation", "Class definition", "Method declaration")

Respond with valid JSON only, without markdown code blocks."""

        try:
            result = await self.bedrock_service.ainvoke_claude(
                prompt=prompt,
                model_id=self.model_id,
                max_tokens=1024,
                temperature=0.3
            )
            
            # If Claude 3.5 Sonnet fails, try Claude 3 Sonnet
            if not result['success']:
                logger.warning(f"[{self.agent_name}] Claude 3.5 Sonnet not available, trying Claude 3 Sonnet...")
                result = await self.bedrock_service.ainvoke_claude(
                    prompt=prompt,
                    model_id=self.fallback_model_id,
                    max_tokens=1024,
                    temperature=0.3
                )
            
            if result['success']:
                # Parse JSON response
                import json
                content = result['content'].strip()
                # Remove markdown code blocks if present
                if content.startswith("```json"):
                    content = content[7:]
                if content.startswith("```"):
                    content = content[3:]
                if content.endswith("```"):
                    content = content[:-3]
                content = content.strip()
                
                try:
                    parsed = json.loads(content, strict=False)
                    return {
                        'data_flow': parsed.get('data_flow', ''),
                        'usage_patterns': parsed.get('usage_patterns', [])
                    }
                except json.JSONDecodeError:
                    # Try to extract JSON from response
                    import re
                    # Look for { to } using DOTALL and greedy matching for the last }
                    json_match = re.search(r'(\{.*\})', content, re.DOTALL)
                    if json_match:
                        try:
                            parsed = json.loads(json_match.group(1), strict=False)
                            return {
                                'data_flow': parsed.get('data_flow', ''),
                                'usage_patterns': parsed.get('usage_patterns', [])
                            }
                        except:
                            pass
            
            # Fallback if parsing fails
            return {
                'data_flow': 'Data flow analysis unavailable',
                'usage_patterns': []
            }
            
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error analyzing data flow: {str(e)}")
            return {
                'data_flow': 'Data flow analysis failed',
                'usage_patterns': []
            }
    
    def _analyze_method_usage_in_dependents(
        self,
        vulnerable_class: Optional[str],
        vulnerable_method: Optional[str],
        vulnerable_file_path: str,
        dependent_files_intra: List[Dict],
        dependent_files_inter: List[Dict],
        repo_path: str
    ) -> Dict[str, List[Dict]]:
        """
        Analyze which specific methods/functions from the vulnerable file are used by dependent files.
        This helps determine if the fix will break dependent files.
        
        Args:
            vulnerable_class: Class name in vulnerable file
            vulnerable_method: Method name in vulnerable file
            vulnerable_file_path: Full path to vulnerable file
            dependent_files_intra: List of intra-repo dependent files
            dependent_files_inter: List of inter-repo dependent files
            repo_path: Repository root path
            
        Returns:
            Dictionary mapping method names to list of files that use them
        """
        methods_usage = {}
        
        try:
            # Read vulnerable file to extract all public methods
            with open(vulnerable_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                vulnerable_content = f.read()
            
            # Extract all public methods from vulnerable class
            if vulnerable_class:
                # Find the class definition
                class_pattern = re.compile(rf'class\s+{re.escape(vulnerable_class)}\s*[^{{]*\{{')
                class_match = class_pattern.search(vulnerable_content)
                
                if class_match:
                    # Extract methods from the class (public and protected)
                    method_pattern = re.compile(
                        r'(?:public|protected)\s+(?:static\s+)?(?:[\w<>\[\]]+\s+)?(\w+)\s*\([^)]*\)'
                    )
                    methods = method_pattern.findall(vulnerable_content)
                    
                    # Also include the vulnerable method if it exists
                    if vulnerable_method and vulnerable_method not in methods:
                        methods.append(vulnerable_method)
                    
                    # Check each dependent file for usage of these methods
                    all_dependents = dependent_files_intra + dependent_files_inter
                    
                    for method in methods:
                        if method not in methods_usage:
                            methods_usage[method] = []
                        
                        for dep in all_dependents:
                            dep_file = dep.get('file', '')
                            if not dep_file:
                                continue
                            
                            # Construct full path to dependent file
                            if dep.get('scope') == 'intra-repo':
                                dep_full_path = os.path.join(repo_path, dep_file)
                            else:
                                # Inter-repo: need to find the repo path
                                dep_repo = dep.get('repo', '')
                                # Try to find repo in temp_cloned_repos
                                temp_repos_dir = Path(repo_path).parent
                                if 'temp_cloned_repos' in str(temp_repos_dir):
                                    dep_repo_path = temp_repos_dir / dep_repo
                                    if dep_repo_path.exists():
                                        dep_full_path = os.path.join(str(dep_repo_path), dep_file)
                                    else:
                                        continue
                                else:
                                    continue
                            
                            if os.path.exists(dep_full_path):
                                try:
                                    with open(dep_full_path, 'r', encoding='utf-8', errors='ignore') as df:
                                        dep_content = df.read()
                                    
                                    # Check if this method is used in the dependent file
                                    # Pattern: ClassName.method() or object.method() or method()
                                    method_usage_patterns = [
                                        rf'{re.escape(vulnerable_class)}\.{re.escape(method)}\s*\(',
                                        rf'\.{re.escape(method)}\s*\(',
                                        rf'\b{re.escape(method)}\s*\('
                                    ]
                                    
                                    for pattern in method_usage_patterns:
                                        if re.search(pattern, dep_content):
                                            methods_usage[method].append({
                                                'file': dep_file,
                                                'repo': dep.get('repo', ''),
                                                'scope': dep.get('scope', 'unknown'),
                                                'dependency_type': dep.get('type', 'unknown')
                                            })
                                            break  # Found usage, no need to check other patterns
                                except Exception:
                                    continue
            
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Error analyzing method usage: {str(e)}")
        
        return methods_usage
    
    def _discover_other_repositories(self, current_repo_path: str) -> List[Dict]:
        """
        Discover other repositories in the same temp_cloned_repos directory for cross-repo analysis.
        
        Args:
            current_repo_path: Path to current repository
            
        Returns:
            List of repository info dictionaries with clone_path
        """
        all_repos = []
        
        try:
            # Get the temp_cloned_repos parent directory
            current_repo_path_obj = Path(current_repo_path).resolve()
            
            # Check if we're in temp_cloned_repos directory
            if 'temp_cloned_repos' in str(current_repo_path_obj):
                # Get parent directory (temp_cloned_repos)
                parent_dir = current_repo_path_obj.parent
                
                # Scan for other repositories in the same directory
                if parent_dir.exists():
                    for repo_dir in parent_dir.iterdir():
                        if repo_dir.is_dir() and repo_dir != current_repo_path_obj:
                            git_dir = repo_dir / ".git"
                            if git_dir.exists():
                                # Found another repository
                                all_repos.append({
                                    'name': repo_dir.name,
                                    'clone_path': str(repo_dir),
                                    'id': f"local_{repo_dir.name}"  # Local ID for discovered repos
                                })
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Error discovering repositories: {str(e)}")
        
        return all_repos
    
    async def analyze(
        self,
        request: VulnerabilityFixRequest,
        vulnerability_analysis: Optional[VulnerabilityAnalysis] = None,
        all_repositories_info: Optional[List[Dict]] = None
    ) -> CodeContext:
        """
        Analyze code context for a vulnerability.
        
        Args:
            request: VulnerabilityFixRequest with vulnerability details
            vulnerability_analysis: Optional analysis from Agent 1
            all_repositories_info: Optional list of all repositories for cross-repo analysis
            
        Returns:
            CodeContext with code analysis and dependencies
        """
        logger.info(f"[{self.agent_name}] Analyzing code context for {request.file_path}:{request.line_number}")
        
        # Construct full file path
        file_path = os.path.join(request.repo_path, request.file_path)
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Vulnerable file not found: {file_path}")
        
        # 0. Enhanced codebase analysis for smarter understanding
        logger.info(f"[{self.agent_name}] Performing enhanced codebase analysis...")
        codebase_analysis = self.codebase_analyzer.analyze_codebase_structure(
            repo_path=request.repo_path,
            focus_file=request.file_path
        )
        
        # Find dependent files using enhanced analysis
        dependent_files_info = self.codebase_analyzer.find_dependent_files(
            repo_path=request.repo_path,
            target_file=request.file_path,
            max_depth=3
        )
        
        # Analyze code flow
        code_flow = self.codebase_analyzer.analyze_code_flow(
            repo_path=request.repo_path,
            file_path=request.file_path,
            line_number=request.line_number
        )
        
        # 1. Read file with context
        file_data = self._read_file_with_context(file_path, request.line_number)
        
        # 2. Extract class and method information
        class_method_info = self._extract_class_and_method(
            file_path,
            request.line_number,
            file_data['full_content']
        )
        
        # 3. Prepare all_repos list for dependency analysis
        # Start with provided repositories or discover from filesystem
        all_repos = all_repositories_info or []
        
        # Add current repository to the list if not present
        current_repo_info = {
            "name": request.repo_name,
            "clone_path": str(request.repo_path),
            "id": "current_repo"
        }
        
        # Check if current repo is already in all_repos by clone_path
        current_repo_path_norm = os.path.normpath(os.path.abspath(str(request.repo_path)))
        repo_exists = any(
            os.path.normpath(os.path.abspath(repo.get('clone_path', ''))) == current_repo_path_norm
            for repo in all_repos
        )
        
        if not repo_exists:
            all_repos.insert(0, current_repo_info)
        
        # If no repos provided, discover other repositories from filesystem
        if len(all_repos) <= 1:
            discovered_repos = self._discover_other_repositories(str(request.repo_path))
            # Add discovered repos that aren't already in the list
            for disc_repo in discovered_repos:
                disc_path_norm = os.path.normpath(os.path.abspath(disc_repo['clone_path']))
                if not any(
                    os.path.normpath(os.path.abspath(r.get('clone_path', ''))) == disc_path_norm
                    for r in all_repos
                ):
                    all_repos.append(disc_repo)
        
        # 4. Find dependent files (intra and inter-repo) with method-level analysis
        dependent_files_intra = []
        dependent_files_inter = []
        methods_used_by_dependents = {}  # Track which methods are used by which files
        
        try:
            # Use DependencyService to find dependencies with all repository info
            dep_result = self.dependency_service.find_dependent_files(
                vulnerable_file=request.file_path,
                vulnerable_line=request.line_number,
                repo_path=str(request.repo_path),
                all_repos=all_repos,  # Pass all repos for inter-repo analysis
                max_depth=5
            )
            
            # Extract intra-repo dependents
            if 'intra_repo_dependents' in dep_result:
                dependent_files_intra = dep_result['intra_repo_dependents']
            
            # Extract inter-repo dependents
            if 'inter_repo_dependents' in dep_result:
                dependent_files_inter = dep_result['inter_repo_dependents']
            
            # Merge enhanced codebase analysis results
            # Add files found by enhanced analysis that might not be in dependency service results
            enhanced_dependents = dependent_files_info.get('direct_dependents', [])
            for enhanced_file in enhanced_dependents:
                # Check if already in dependent_files_intra
                if not any(dep.get('file') == enhanced_file for dep in dependent_files_intra):
                    dependent_files_intra.append({
                        'file': enhanced_file,
                        'type': 'enhanced_analysis',
                        'relationship': 'uses_class_or_method'
                    })
            
            # Add related files from enhanced analysis
            related_files = dependent_files_info.get('related_files', [])
            for related_file in related_files:
                if not any(dep.get('file') == related_file for dep in dependent_files_intra):
                    dependent_files_intra.append({
                        'file': related_file,
                        'type': 'related',
                        'relationship': 'same_package_or_similar'
                    })
            
            # 5. Analyze method-level usage in dependent files
            # Check which specific methods/functions from vulnerable file are used by dependents
            vulnerable_class = class_method_info['class_name']
            vulnerable_method = class_method_info['method_name']
            
            if vulnerable_class or vulnerable_method:
                methods_used_by_dependents = self._analyze_method_usage_in_dependents(
                    vulnerable_class=vulnerable_class,
                    vulnerable_method=vulnerable_method,
                    vulnerable_file_path=file_path,
                    dependent_files_intra=dependent_files_intra,
                    dependent_files_inter=dependent_files_inter,
                    repo_path=str(request.repo_path)
                )
                
                # Add method usage info to dependent files
                for dep in dependent_files_intra + dependent_files_inter:
                    dep_file = dep.get('file', '')
                    # Check which methods are used by this dependent file
                    methods_used = []
                    for method, files_using in methods_used_by_dependents.items():
                        if any(f.get('file') == dep_file for f in files_using):
                            methods_used.append(method)
                    dep['methods_used'] = methods_used
                    dep['will_be_affected'] = len(methods_used) > 0
                
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Error finding dependencies: {str(e)}")
        
        # 4. Analyze data flow and usage patterns
        analysis_result = await self._analyze_data_flow_and_usage(
            code_snippet=file_data['snippet'],
            vulnerability_type=request.vulnerability_type,
            class_name=class_method_info['class_name'],
            method_name=class_method_info['method_name']
        )
        
        # Build CodeContext
        code_context = CodeContext(
            vulnerable_file=request.file_path,
            vulnerable_line=request.line_number,
            code_snippet=file_data['snippet'],
            class_name=class_method_info['class_name'],
            method_name=class_method_info['method_name'],
            function_signature=class_method_info['function_signature'],
            dependent_files_intra=dependent_files_intra,
            dependent_files_inter=dependent_files_inter,
            data_flow=analysis_result['data_flow'],
            usage_patterns=analysis_result['usage_patterns']
        )
        
        logger.info(
            f"[{self.agent_name}] Analysis complete. "
            f"Found {len(dependent_files_intra)} intra-repo and {len(dependent_files_inter)} inter-repo dependencies."
        )
        
        return code_context

