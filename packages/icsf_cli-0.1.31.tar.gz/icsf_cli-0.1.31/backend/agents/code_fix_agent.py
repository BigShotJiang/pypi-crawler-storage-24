"""
Agent 4: Code Fix Agent

This agent generates the actual fixed code based on the fix strategy from Agent 3.
It reads the vulnerable file(s), applies the fix, and generates a diff.
"""

import os
import logging
import difflib
import re
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

from ..models.agent_models import (
    VulnerabilityFixRequest,
    VulnerabilityAnalysis,
    CodeContext,
    FixStrategy,
    CodeFix,
)
from ..services.bedrock_service import BedrockService
from .codebase_analysis_agent import CodebaseAnalysisAgent
from .agent_improvements import ImportManager, SyntaxValidator, FrameworkDetector

logger = logging.getLogger(__name__)


class CodeFixAgent:
    """Agent that generates fixed code"""
    
    def __init__(self, bedrock_service: BedrockService):
        """
        Initialize Code Fix Agent.
        
        Args:
            bedrock_service: BedrockService instance for model invocation
        """
        self.bedrock_service = bedrock_service
        self.agent_name = "CodeFixAgent"
        self.codebase_analyzer = CodebaseAnalysisAgent(bedrock_service)
        
        # Use Claude 3.5 Sonnet for code generation
        self.model_id = bedrock_service.CLAUDE_3_5_SONNET
        self.fallback_model_id = bedrock_service.CLAUDE_3_SONNET
    
    def _read_file(self, file_path: str) -> str:
        """
        Read file content.
        
        Args:
            file_path: Path to the file
            
        Returns:
            File content as string
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error reading file {file_path}: {str(e)}")
            return ""

    def _find_nearest_pom_xml(self, repo_path: str, file_rel_path: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Find the nearest pom.xml for a given file, walking up directories to repo root.
        Returns (pom_path, pom_content).
        """
        try:
            repo_root = os.path.abspath(str(repo_path))
            file_abs = os.path.abspath(os.path.join(repo_root, file_rel_path))

            # Walk up from file directory to repo root looking for pom.xml
            cur_dir = os.path.dirname(file_abs)
            while True:
                pom_path = os.path.join(cur_dir, "pom.xml")
                if os.path.exists(pom_path):
                    with open(pom_path, "r", encoding="utf-8", errors="ignore") as f:
                        return pom_path, f.read()

                if os.path.abspath(cur_dir) == repo_root:
                    break
                parent = os.path.dirname(cur_dir)
                if parent == cur_dir:
                    break
                cur_dir = parent

            # Fallback: repo root pom.xml
            pom_path = os.path.join(repo_root, "pom.xml")
            if os.path.exists(pom_path):
                with open(pom_path, "r", encoding="utf-8", errors="ignore") as f:
                    return pom_path, f.read()
        except Exception:
            pass
        return None, None

    def _project_allows_spring_security(self, repo_path: str, file_rel_path: str, original_code: str) -> bool:
        """
        Decide whether it's safe to generate code that references org.springframework.security.*.
        We only allow this if pom.xml indicates Spring Security, OR the original file already used it.
        """
        try:
            # If the original file already imports Spring Security, keep it allowed.
            if re.search(r'^\s*import\s+org\.springframework\.security\.', original_code, re.MULTILINE):
                return True

            _, pom_content = self._find_nearest_pom_xml(repo_path, file_rel_path)
            if not pom_content:
                return False

            # Very lightweight check for common Spring Security artifacts / groupId
            pom_lower = pom_content.lower()
            if "spring-boot-starter-security" in pom_lower:
                return True
            if "spring-security-web" in pom_lower:
                return True
            if "<groupid>org.springframework.security</groupid>" in pom_lower:
                return True
        except Exception:
            return False
        return False

    def _dependency_constraints_text(self, repo_path: str, file_rel_path: str, original_code: str) -> str:
        pom_path, _ = self._find_nearest_pom_xml(repo_path, file_rel_path)
        allows_security = self._project_allows_spring_security(repo_path, file_rel_path, original_code)
        return (
            "PROJECT DEPENDENCY CONSTRAINTS:\n"
            f"- Nearest pom.xml: {pom_path or 'Not found'}\n"
            f"- Spring Security allowed: {'YES' if allows_security else 'NO'}\n"
            "RULES:\n"
            "- DO NOT introduce new framework dependencies or new Maven artifacts.\n"
            "- DO NOT add imports from frameworks not already present in this project.\n"
            "- In particular: DO NOT add org.springframework.security.* (e.g., CsrfToken) unless Spring Security is already present.\n"
            "- Do NOT implement CSRF token handling inside controllers unless the original project already uses it.\n"
        )

    def _postprocess_for_project_dependencies(self, code: str, repo_path: str, file_rel_path: str, original_code: str) -> str:
        """
        Deterministic safety net: remove Spring Security-only constructs if project doesn't include it.
        Prevents end-to-end compilation failures like missing CsrfToken classes.
        """
        if self._project_allows_spring_security(repo_path, file_rel_path, original_code):
            return code

        cleaned = code

        # Remove Spring Security imports
        cleaned = re.sub(
            r'^\s*import\s+org\.springframework\.security\.[^;]+;\s*\n',
            '',
            cleaned,
            flags=re.MULTILINE
        )

        # Remove CsrfToken parameters from method signatures (best-effort)
        cleaned = re.sub(r',\s*CsrfToken\s+\w+\s*', '', cleaned)
        cleaned = re.sub(r'\(\s*CsrfToken\s+\w+\s*\)', '()', cleaned)

        # Remove ResponseEntity header injection for X-CSRF-TOKEN (best-effort)
        cleaned = re.sub(
            r'\s*\.header\(\s*\"X-CSRF-TOKEN\"\s*,\s*\w+\.getToken\(\)\s*\)\s*\n',
            '',
            cleaned
        )

        # Remove @ModelAttribute CSRF token methods (best-effort)
        cleaned = re.sub(
            r'^\s*@ModelAttribute\s*\n\s*public\s+void\s+\w+\s*\(\s*CsrfToken\s+\w+\s*\)\s*\{\s*[\s\S]*?\}\s*\n',
            '',
            cleaned,
            flags=re.MULTILINE
        )

        # Remove ModelAttribute("_csrf") params that were added solely for CSRF (best-effort)
        cleaned = re.sub(r',\s*@ModelAttribute\(\s*\"_csrf\"\s*\)\s*String\s+\w+\s*', '', cleaned)

        return cleaned
    
    def _generate_diff(self, original: str, fixed: str, file_path: str) -> str:
        """
        Generate unified diff between original and fixed code.
        
        Args:
            original: Original code
            fixed: Fixed code
            file_path: Path to the file
            
        Returns:
            Unified diff string
        """
        original_lines = original.splitlines()
        fixed_lines = fixed.splitlines()
        
        diff = difflib.unified_diff(
            original_lines,
            fixed_lines,
            fromfile=f'original/{file_path}',
            tofile=f'fixed/{file_path}',
            lineterm=''
        )
        
        return '\n'.join(diff)
    
    def _format_dependent_files_info(self, code_context: CodeContext) -> str:
        """
        Format dependent files information for the prompt.
        
        Args:
            code_context: CodeContext from Agent 2
            
        Returns:
            Formatted string with dependent files info
        """
        info_lines = []
        
        # Get affected files (those that use methods being changed)
        affected_intra = [dep for dep in code_context.dependent_files_intra if dep.get('will_be_affected', False)]
        affected_inter = [dep for dep in code_context.dependent_files_inter if dep.get('will_be_affected', False)]
        
        if affected_intra:
            info_lines.append("Intra-repo files that use methods being changed:")
            for dep in affected_intra[:10]:
                methods = dep.get('methods_used', [])
                info_lines.append(f"  - {dep.get('file')} (uses: {', '.join(methods)})")
        
        if affected_inter:
            info_lines.append("Inter-repo files that use methods being changed:")
            for dep in affected_inter[:10]:
                methods = dep.get('methods_used', [])
                info_lines.append(f"  - {dep.get('repo')}/{dep.get('file')} (uses: {', '.join(methods)})")
        
        total_deps = len(code_context.dependent_files_intra) + len(code_context.dependent_files_inter)
        
        if not info_lines:
            if total_deps > 0:
                return f"✅ No dependent files need changes. Found {total_deps} dependent file(s), but none of them use the methods being changed. The fix can be applied to the vulnerable file only."
            else:
                return "✅ No dependent files found. The fix can be applied to the vulnerable file only."
        
        return '\n'.join(info_lines)
    
    def _get_relevant_steps_for_file(self, code_changes_plan: List[str], file_to_fix: str) -> str:
        """
        Get relevant steps from code_changes_plan for a specific file.
        
        Args:
            code_changes_plan: List of code change steps
            file_to_fix: Path to the file being fixed
            
        Returns:
            Formatted string with relevant steps
        """
        relevant_steps = []
        file_lower = file_to_fix.lower()
        file_basename = file_to_fix.split('/')[-1].lower() if '/' in file_to_fix else file_to_fix.lower()
        
        # Determine if this is a DAO/Service/Model file
        is_dao_or_service = 'dao' in file_lower or 'impl' in file_lower or 'service' in file_lower or 'model' in file_lower
        
        for i, step in enumerate(code_changes_plan):
            step_str = str(step)
            step_lower = step_str.lower()
            
            # Check if step mentions this file or its basename
            if file_lower in step_lower or file_basename in step_lower:
                relevant_steps.append(f"{i+1}. {step_str}")
            # If this is a DAO/Service file, include steps mentioning DAO/Service/Impl
            elif is_dao_or_service and any(keyword in step_lower for keyword in ['dao', 'impl', 'service', 'model']):
                relevant_steps.append(f"{i+1}. {step_str}")
        
        if relevant_steps:
            return '\n'.join(relevant_steps)
        else:
            # If no specific steps found, return all steps
            return '\n'.join(f"{i+1}. {step}" for i, step in enumerate(code_changes_plan))
    
    def _clean_generated_code(self, code: str, file_path: str = "") -> str:
        """
        Clean generated code to remove markdown, explanations, and ensure valid syntax.
        For Java files, uses aggressive cleaning to extract only valid Java code.
        
        Args:
            code: Raw code from model response (may include <thinking> blocks)
            file_path: Path to the target file to determine language logic
            
        Returns:
            Cleaned code
        """
        if not code:
            return code
        
        # Step 0: Remove <thinking> blocks if present
        # Use DOTALL to match across newlines
        code = re.sub(r'<thinking>.*?</thinking>', '', code, flags=re.DOTALL | re.IGNORECASE)
        
        # Step 1: Remove markdown code blocks (handle various formats)
        code = code.strip()
        
        is_java = file_path.endswith('.java') or not file_path
        
        if not is_java:
            # For non-Java files (js, html, etc.), just do basic markdown stripping
            code = re.sub(r'```[a-zA-Z]*\s*\n?', '', code, flags=re.IGNORECASE)
            code = re.sub(r'```\s*\n?', '', code)
            code = re.sub(r'\n?```\s*$', '', code)
            return code.strip()
            
        # Remove ```java ... ``` blocks
        code = re.sub(r'```java\s*\n?', '', code, flags=re.IGNORECASE)
        code = re.sub(r'```\s*\n?', '', code)
        code = re.sub(r'\n?```\s*$', '', code)
        
        # Step 2: Remove markdown headers and horizontal rules
        lines = code.split('\n')
        cleaned_lines = []
        code_started = False
        brace_count = 0
        
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            
            # Skip completely empty lines before code starts
            if not code_started and not line_stripped:
                continue
            
            # Aggressively skip markdown headers (any number of #)
            if re.match(r'^#+\s', line_stripped):
                continue
            
            # Skip markdown horizontal rules
            if re.match(r'^[-=]{3,}\s*$', line_stripped):
                continue
            
            # Skip lines that are clearly markdown lists or formatting
            if re.match(r'^[-*+]\s+', line_stripped) and not code_started:
                continue
            
            # Skip lines that look like explanations (contain explanation words but no Java syntax)
            if not code_started:
                explanation_patterns = [
                    r'^(here|below|above|note|important|warning|example|explanation|changes|fix|fixed)',
                    r'^(the|this|following|above|below).*(code|file|class|method)',
                    r'^return.*code',
                    r'^complete.*code'
                ]
                is_explanation = any(re.match(pattern, line_stripped.lower()) for pattern in explanation_patterns)
                
                if is_explanation and not any(char in line_stripped for char in ['{', '}', ';', '(', ')', '=', '@']):
                    continue
            
            # Detect start of Java code
            java_start_patterns = [
                r'^\s*package\s+',  # package statement
                r'^\s*import\s+',   # import statement
                r'^\s*(public|private|protected|static|final|abstract)\s+',  # modifiers
                r'^\s*(class|interface|enum|@interface)\s+',  # type declarations
                r'^\s*@\w+',  # annotations
                r'^\s*//',  # single-line comment
                r'^\s*/\*',  # multi-line comment start
                r'^\s*\*',  # comment continuation
            ]
            
            if not code_started:
                if any(re.match(pattern, line_stripped) for pattern in java_start_patterns):
                    code_started = True
                elif any(char in line_stripped for char in ['{', '}', ';', '(', ')', '=', '@']):
                    # Has Java syntax characters
                    code_started = True
                else:
                    # Skip non-Java lines before code starts
                    continue
            
            # Once code has started, track braces and include lines
            if code_started:
                # Count braces to detect end of code
                brace_count += line.count('{') - line.count('}')
                cleaned_lines.append(line)
                
                # If we've closed all braces and hit non-code content, stop
                if brace_count <= 0 and i < len(lines) - 1:
                    # Check if next lines look like code continuation
                    next_lines = lines[i+1:i+3]
                    next_looks_like_code = False
                    for next_line in next_lines:
                        next_stripped = next_line.strip()
                        if not next_stripped:
                            continue
                        if any(re.match(pattern, next_stripped) for pattern in java_start_patterns):
                            next_looks_like_code = True
                            break
                        if any(char in next_stripped for char in ['{', '}', ';', '(', ')', '=', '@', '//', '/*', '*']):
                            next_looks_like_code = True
                            break
                    
                    if not next_looks_like_code and brace_count == 0:
                        # We've reached the end of the class/file
                        break
        
        cleaned_code = '\n'.join(cleaned_lines)
        
        # Step 3: Remove any remaining markdown artifacts
        cleaned_code = re.sub(r'```java', '', cleaned_code, flags=re.IGNORECASE)
        cleaned_code = re.sub(r'```', '', cleaned_code)
        cleaned_code = re.sub(r'^#+\s+.*$', '', cleaned_code, flags=re.MULTILINE)
        
        # Step 4: Find the actual start of Java code (package/import/class)
        lines = cleaned_code.split('\n')
        start_idx = 0
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            if any(re.match(pattern, line_stripped) for pattern in [
                r'^package\s+',
                r'^import\s+',
                r'^(public|private|protected|static|final|abstract)\s+',
                r'^(class|interface|enum|@interface)\s+',
                r'^@\w+',
                r'^//',
                r'^/\*',
            ]):
                start_idx = i
                break
        
        cleaned_code = '\n'.join(lines[start_idx:])
        
        # Step 5: Ensure we have balanced braces (find the last closing brace of the main class)
        lines = cleaned_code.split('\n')
        brace_count = 0
        end_idx = len(lines)
        
        for i, line in enumerate(lines):
            brace_count += line.count('{') - line.count('}')
            # If we've closed all braces, this might be the end
            if brace_count == 0 and i > 0:
                # Check if remaining lines look like code or markdown
                remaining = '\n'.join(lines[i+1:]).strip()
                if not remaining or re.match(r'^#+|^```|^---', remaining, re.MULTILINE):
                    end_idx = i + 1
                    break
        
        cleaned_code = '\n'.join(lines[:end_idx])
        
        # Step 6: Final validation - ensure it starts with valid Java
        cleaned_code = cleaned_code.strip()
        
        # If still doesn't start with valid Java, try to extract from markdown code block
        if cleaned_code and not any(re.match(pattern, cleaned_code.split('\n')[0].strip()) for pattern in [
            r'^package\s+',
            r'^import\s+',
            r'^(public|private|protected|static|final|abstract)\s+',
            r'^(class|interface|enum|@interface)\s+',
            r'^@\w+',
            r'^//',
            r'^/\*',
        ]):
            # Try to find Java code block using regex
            java_block_pattern = r'(?:```java\s*\n?)?(package\s+[\w.]+;.*?)(?:```)?'
            match = re.search(java_block_pattern, code, re.DOTALL | re.IGNORECASE)
            if match:
                cleaned_code = match.group(1).strip()
        
        # Step 7: Final validation - ensure we have at least a class/interface/enum declaration
        cleaned_code = cleaned_code.strip()
        
        if cleaned_code:
            # Check if we have at least one class, interface, or enum
            has_class = bool(re.search(r'\b(class|interface|enum|@interface)\s+\w+', cleaned_code))
            
            # If no class found, try to extract from the original code more aggressively
            if not has_class:
                # Look for class declaration in original code
                class_pattern = r'(package\s+[\w.]+\s*;)?\s*(import\s+[\w.*]+\s*;?\s*)*\s*(public\s+)?(class|interface|enum)\s+\w+.*?\{.*\}'
                match = re.search(class_pattern, code, re.DOTALL)
                if match:
                    cleaned_code = match.group(0).strip()
                else:
                    # Last resort: find lines between first package/import and last }
                    lines = code.split('\n')
                    start_idx = 0
                    end_idx = len(lines)
                    
                    for i, line in enumerate(lines):
                        if re.match(r'^\s*(package|import)\s+', line.strip()):
                            start_idx = i
                            break
                    
                    for i in range(len(lines) - 1, -1, -1):
                        if '}' in lines[i]:
                            end_idx = i + 1
                            break
                    
                    if start_idx < end_idx:
                        cleaned_code = '\n'.join(lines[start_idx:end_idx]).strip()
        
        # ===== PHASE 1 IMPROVEMENTS: Import Management & Syntax Validation =====
        
        # Add missing imports
        try:
            cleaned_code, added_imports = ImportManager.add_missing_imports(cleaned_code)
            if added_imports:
                logger.info(f"[{self.agent_name}] Added {len(added_imports)} missing imports")
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Import management failed: {e}")
        
        # Validate syntax
        try:
            is_valid, error_msg = SyntaxValidator.validate(cleaned_code)
            if not is_valid:
                logger.warning(f"[{self.agent_name}] Syntax validation warning: {error_msg}")
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Syntax validation failed: {e}")
        
        # ===== END PHASE 1 IMPROVEMENTS =====
        
        return cleaned_code.strip()
    
    async def _generate_fixed_code(
        self,
        original_code: str,
        request: VulnerabilityFixRequest,
        vulnerability_analysis: VulnerabilityAnalysis,
        code_context: CodeContext,
        fix_strategy: FixStrategy
    ) -> Tuple[str, Optional[str]]:
        """
        Use Bedrock to generate fixed code.
        
        Args:
            original_code: Original code content
            request: VulnerabilityFixRequest
            vulnerability_analysis: Analysis from Agent 1
            code_context: Context from Agent 2
            fix_strategy: Strategy from Agent 3
            
        Returns:
            Tuple[str, Optional[str]]: (Fixed code content, Reasoning)
        """
        repo_path_str = str(request.repo_path)
        dependency_constraints = self._dependency_constraints_text(
            repo_path=repo_path_str,
            file_rel_path=code_context.vulnerable_file,
            original_code=original_code
        )
        # Build prompt for code generation
        prompt = f"""You are a security expert fixing a code vulnerability. 
        
        First, analyze the problem and plan your fix in a <thinking> block.
        Then, generate the complete fixed Java code.

VULNERABILITY DETAILS:
- Type: {request.vulnerability_type}
- Severity: {vulnerability_analysis.severity.value}
- Description: {request.description}
- Scanner Recommendation: {request.recommendation or 'None provided'}

FIX STRATEGY:
{fix_strategy.fix_approach}

{dependency_constraints}

CODE CHANGES PLAN:
{chr(10).join(f"{i+1}. {step}" for i, step in enumerate(fix_strategy.code_changes_plan))}

FILES THAT MUST BE MODIFIED (for end-to-end functionality):
{', '.join(fix_strategy.files_to_modify_primary)}

IMPORTANT: The fix strategy mentions modifying multiple files. This file ({code_context.vulnerable_file}) is one of them. 
Other files that need to be fixed: {', '.join([f for f in fix_strategy.files_to_modify_primary if f != code_context.vulnerable_file])}

VULNERABLE CODE CONTEXT:
- File: {code_context.vulnerable_file}
- Line: {code_context.vulnerable_line}
- Class: {code_context.class_name or 'Unknown'}
- Method: {code_context.method_name or 'Unknown'}

DEPENDENT FILES THAT USE THIS METHOD:
{self._format_dependent_files_info(code_context)}

DATA FLOW:
{code_context.data_flow or 'Not available'}

ORIGINAL CODE:
```java
{original_code}
```

CRITICAL REQUIREMENT - PRESERVE APPLICATION FUNCTIONALITY:
- The application MUST run end-to-end after this fix is applied
- DO NOT break any existing functionality - all existing features must continue to work
- Make MINIMAL changes - only add security fixes, don't refactor or restructure code
- Preserve ALL existing method signatures, return types, and parameters EXACTLY as they are
- Keep ALL existing imports - only add new imports if absolutely necessary for the security fix
- Maintain the EXACT same class structure, field names, method names, and code organization
- Preserve ALL existing business logic - only add security validation/checks, don't remove or change existing logic
- If you need to add validation, add it BEFORE the existing logic, not instead of it
- Keep the same code style, indentation, and formatting as the original
- Preserve all existing comments and documentation
- Ensure the code compiles without errors and the application runs successfully
- Test your fix mentally: Will the application still work after this change? If not, adjust the fix
- MINIMAL CHANGE PRINCIPLE: Only change what's necessary to fix the security issue, keep everything else identical
- ACCESSOR CONVENTION: Match the existing accessor style of the class. If it uses `email()`, you MUST use `email()`. If it uses getters like `getEmail()`, you MUST use `getEmail()`. DO NOT GUESS!

TASK:
Generate the complete fixed code that:
1. Applies all steps from the code changes plan that relate to THIS file ({code_context.vulnerable_file})
2. Fixes the security vulnerability WITHOUT breaking existing functionality
3. Maintains backward compatibility: {fix_strategy.backward_compatibility}
4. Preserves ALL existing method signatures, return types, parameters, and behavior
5. Keeps ALL existing imports and only adds new ones if necessary for the security fix
6. Preserves the overall structure, logic, and flow of the original code
7. Adds security validation/checks WITHOUT removing or changing existing business logic
8. Follows Java best practices and coding conventions
9. Adds proper error handling if needed, but preserves existing error handling patterns
10. If the code calls methods from other files (e.g., bDao.hasAccountAccess()), assume those methods will be implemented in those files
11. Ensures the application compiles and runs end-to-end after the fix

CRITICAL REQUIREMENT - MULTI-FILE FIX:
- Multiple files need to be fixed: {', '.join(fix_strategy.files_to_modify_primary)}
- This file ({code_context.vulnerable_file}) is the PRIMARY file
- Other files will be fixed separately, so you can reference methods that will be created in those files
- Example: If you call bDao.hasAccountAccess(), that method will be implemented in BankDAOImpl.java

CRITICAL REQUIREMENT - DEPENDENT FILES AND METHOD SIGNATURES:
- Total dependent files found: {len(code_context.dependent_files_intra) + len(code_context.dependent_files_inter)}
- Files that use methods being changed: {len([d for d in code_context.dependent_files_intra + code_context.dependent_files_inter if d.get('will_be_affected', False)])}

- CRITICAL: You MUST maintain EXACT method signatures (name, return type, parameters, modifiers)
- CRITICAL: You MUST maintain EXACT method behavior - only add security checks, don't change logic
- If dependent files use the methods being changed, you MUST NOT change method signatures AT ALL
- If you change method signatures, return types, or parameters, dependent files WILL BREAK and the application will fail
- The fix must be 100% backward compatible - existing code calling these methods must work unchanged
- Even if NO dependent files are found, still maintain method signatures to ensure the application works
- Preserve all existing method calls, field accesses, and class structure
- The application must compile and run successfully after your fix

CRITICAL OUTPUT REQUIREMENTS:
- START with a <thinking> block where you explain your reasoning:
  <thinking>
  1. Analyze the vulnerability...
  2. Plan the fix...
  3. Verify side effects...
  </thinking>
- THEN return ONLY the complete fixed Java code
- Do NOT include markdown code blocks (no ```java or ```)
- Do NOT include markdown headers (no #, ##, ###)
- Do NOT include explanations outside the <thinking> block
- Do NOT include line numbers or diff markers
- Do NOT include comments like "Here's the fixed code:" or "The changes are:"
- Start directly with package/import statements or class declaration
- End with the closing brace of the class/interface/enum
- Ensure the code is syntactically correct and complete Java code that will compile
- Preserve code style and formatting similar to the original
- If you add new imports, include them at the top with the existing imports
- Maintain method signatures if dependent files use them (unless breaking change is acceptable)
- Only include valid Java syntax - no markdown, no explanations (except <thinking>), no extra text

Return the response starting with <thinking>..."""
        
        try:
            result = await self.bedrock_service.ainvoke_claude(
                prompt=prompt,
                model_id=self.model_id,
                max_tokens=4096,  # Large response for full file code
                temperature=0.3  # Lower temperature for more consistent code generation
            )
            
            # If Claude 3.5 Sonnet fails, try Claude 3 Sonnet
            if not result['success']:
                logger.warning(f"[{self.agent_name}] Claude 3.5 Sonnet not available, trying Claude 3 Sonnet...")
                result = self.bedrock_service.invoke_claude(
                    prompt=prompt,
                    model_id=self.fallback_model_id,
                    max_tokens=4096,
                    temperature=0.3
                )
            
            if not result['success']:
                logger.error(f"[{self.agent_name}] Failed to invoke model: {result.get('error_message')}")
                raise Exception(f"Model invocation failed: {result.get('error_message')}")
            
            # Extract code from response
            content = result['content'].strip()
            
            # Extract reasoning
            reasoning = None
            thinking_match = re.search(r'<thinking>(.*?)</thinking>', content, re.DOTALL | re.IGNORECASE)
            if thinking_match:
                reasoning = thinking_match.group(1).strip()
            
            # Clean the code to remove markdown, explanations, thinking blocks, and ensure it's valid code
            fixed_code = self._clean_generated_code(content, code_context.vulnerable_file)

            # Post-process to avoid introducing missing dependencies (e.g., Spring Security in non-security projects)
            fixed_code = self._postprocess_for_project_dependencies(
                code=fixed_code,
                repo_path=repo_path_str,
                file_rel_path=code_context.vulnerable_file,
                original_code=original_code
            )
            
            return fixed_code, reasoning
            
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error generating fixed code: {str(e)}")
            raise
    
    def _analyze_line_changes(self, original: str, fixed: str) -> List[Dict[str, Any]]:
        """
        Analyze line-by-line changes between original and fixed code.
        
        Args:
            original: Original code
            fixed: Fixed code
            
        Returns:
            List of line change dictionaries
        """
        original_lines = original.splitlines()
        fixed_lines = fixed.splitlines()
        
        changes = []
        
        # Use difflib to find differences
        diff = difflib.unified_diff(
            original_lines,
            fixed_lines,
            lineterm='',
            n=0  # No context lines
        )
        
        diff_list = list(diff)
        line_num = 0
        
        for i, line in enumerate(diff_list):
            if line.startswith('@@'):
                # Extract line numbers from diff header
                import re
                match = re.search(r'\+(\d+)', line)
                if match:
                    line_num = int(match.group(1)) - 1
            elif line.startswith('-') and not line.startswith('---'):
                changes.append({
                    'line_number': line_num + 1,
                    'type': 'removed',
                    'content': line[1:]  # Remove '-' prefix
                })
                line_num += 1
            elif line.startswith('+') and not line.startswith('+++'):
                changes.append({
                    'line_number': line_num + 1,
                    'type': 'added',
                    'content': line[1:]  # Remove '+' prefix
                })
                line_num += 1
        
        return changes
    
    async def fix_code(
        self,
        request: VulnerabilityFixRequest,
        vulnerability_analysis: VulnerabilityAnalysis,
        code_context: CodeContext,
        fix_strategy: FixStrategy
    ) -> CodeFix:
        """
        Generate fixed code for a vulnerability.
        Fixes ALL files listed in fix_strategy.files_to_modify_primary.
        
        Args:
            request: VulnerabilityFixRequest with vulnerability details
            vulnerability_analysis: Analysis from Agent 1
            code_context: Context from Agent 2
            fix_strategy: Strategy from Agent 3
            
        Returns:
            CodeFix with fixed code and changes for all required files
        """
        logger.info(
            f"[{self.agent_name}] Generating fixed code for "
            f"{request.file_path}:{request.line_number}"
        )
        
        # Enhanced analysis: Understand file relationships using codebase analyzer
        logger.info(f"[{self.agent_name}] Analyzing file relationships for better fixes...")
        codebase_analysis = self.codebase_analyzer.analyze_codebase_structure(
            repo_path=request.repo_path,
            focus_file=request.file_path
        )
        
        # Get all files that need to be fixed (from fix strategy)
        files_to_fix = fix_strategy.files_to_modify_primary or [request.file_path]
        
        # Ensure vulnerable file is included
        if request.file_path not in files_to_fix:
            files_to_fix.insert(0, request.file_path)
        
        # Validate and filter files that actually exist
        validated_files_to_fix = []
        for file_to_fix in files_to_fix:
            file_path = os.path.join(request.repo_path, file_to_fix)
            if os.path.exists(file_path):
                validated_files_to_fix.append(file_to_fix)
            else:
                logger.warning(
                    f"[{self.agent_name}] File from strategy does not exist: {file_to_fix} "
                    f"(full path: {file_path}), skipping"
                )
        
        # Ensure vulnerable file is always attempted (even if it doesn't exist, we'll handle the error)
        if request.file_path not in validated_files_to_fix:
            validated_files_to_fix.insert(0, request.file_path)
        
        files_to_fix = validated_files_to_fix
        
        logger.info(
            f"[{self.agent_name}] Fixing {len(files_to_fix)} file(s): {', '.join(files_to_fix)}"
        )
        
        # Fix each file
        all_fixed_code = {}
        all_original_code = {}
        all_diffs = []
        all_changed_lines = []
        all_files_modified = []
        
        for file_to_fix in files_to_fix:
            file_path = os.path.join(request.repo_path, file_to_fix)
            
            if not os.path.exists(file_path):
                logger.warning(f"[{self.agent_name}] File not found: {file_path}, skipping...")
                continue
            
            original_code = self._read_file(file_path)
            
            if not original_code:
                logger.warning(f"[{self.agent_name}] Could not read file: {file_path}, skipping...")
                continue
            
            if file_to_fix == request.file_path:
                # Use original vulnerability context for the vulnerable file
                # Generate fixed code using model
                fixed_code, reasoning = await self._generate_fixed_code(
                    original_code=original_code,
                    request=request,
                    vulnerability_analysis=vulnerability_analysis,
                    code_context=code_context,
                    fix_strategy=fix_strategy
                )
            else:
                # For dependent files, generate fix based on the fix strategy
                # Note: dependent file generation doesn't return reasoning yet, so we just get code
                fixed_code = self._generate_fixed_code_for_dependent_file(
                    original_code=original_code,
                    file_to_fix=file_to_fix,
                    request=request,
                    vulnerability_analysis=vulnerability_analysis,
                    code_context=code_context,
                    fix_strategy=fix_strategy
                )
            
            # Generate diff for this file
            diff = self._generate_diff(original_code, fixed_code, file_to_fix)
            # Format diff with clear file separator
            file_diff = f"\n{'='*80}\nFILE: {file_to_fix}\n{'='*80}\n{diff}\n"
            all_diffs.append(file_diff)
            
            # Analyze line-by-line changes
            changed_lines = self._analyze_line_changes(original_code, fixed_code)
            all_changed_lines.extend(changed_lines)
            
            # Store fixed code and original code for this file
            all_fixed_code[file_to_fix] = fixed_code
            all_original_code[file_to_fix] = original_code
            all_files_modified.append(file_to_fix)
        
        # Combine all fixed code with clear separators
        combined_fixed_code_parts = []
        for file_path_key in files_to_fix:
            if file_path_key in all_fixed_code:
                combined_fixed_code_parts.append(
                    f"{'='*80}\n"
                    f"FIXED CODE FOR: {file_path_key}\n"
                    f"{'='*80}\n"
                    f"{all_fixed_code[file_path_key]}\n"
                )
        
        combined_fixed_code = '\n\n'.join(combined_fixed_code_parts) if combined_fixed_code_parts else ""
        
        # Combine all diffs with clear headers
        combined_diff = '\n'.join(all_diffs)
        
        # Add summary header to diff
        if combined_diff:
            diff_header = (
                f"{'='*80}\n"
                f"CODE DIFF SUMMARY\n"
                f"{'='*80}\n"
                f"Total Files Modified: {len(all_files_modified)}\n"
                f"Files: {', '.join(all_files_modified)}\n"
                f"Total Lines Changed: {len(all_changed_lines)}\n"
                f"{'='*80}\n\n"
            )
            combined_diff = diff_header + combined_diff
        
        # Build change summary
        change_summary = (
            f"Fixed {request.vulnerability_type} vulnerability by modifying {len(all_files_modified)} file(s): "
            f"{', '.join(all_files_modified)}. "
            f"Applied {len(fix_strategy.code_changes_plan)} code changes. "
            f"Total {len(all_changed_lines)} lines modified."
        )
        
        # Build CodeFix object
        # fixed_code should be a dict mapping file paths to fixed code content
        code_fix = CodeFix(
            fixed_code=all_fixed_code,  # Dict[str, str] mapping file paths to fixed code
            original_code=all_original_code,  # Dict[str, str] mapping file paths to original code
            changed_lines=all_changed_lines,
            files_modified=all_files_modified,
            diff=combined_diff,
            change_summary=change_summary,
            metadata={}  # Initialize empty metadata
        )
        
        logger.info(
            f"[{self.agent_name}] Code fix generated. "
            f"Modified {len(all_changed_lines)} lines in {len(code_fix.files_modified)} file(s): {', '.join(all_files_modified)}"
        )
        
        return code_fix
    
    def _generate_fixed_code_for_dependent_file(
        self,
        original_code: str,
        file_to_fix: str,
        request: VulnerabilityFixRequest,
        vulnerability_analysis: VulnerabilityAnalysis,
        code_context: CodeContext,
        fix_strategy: FixStrategy
    ) -> str:
        """
        Generate fixed code for a dependent file that needs to be updated.
        
        Args:
            original_code: Original code content of the dependent file
            file_to_fix: Path to the file being fixed
            request: VulnerabilityFixRequest
            vulnerability_analysis: Analysis from Agent 1
            code_context: Context from Agent 2
            fix_strategy: Strategy from Agent 3
            
        Returns:
            Fixed code content
        """
        repo_path_str = str(request.repo_path)
        dependency_constraints = self._dependency_constraints_text(
            repo_path=repo_path_str,
            file_rel_path=file_to_fix,
            original_code=original_code
        )
        prompt = f"""You are a security expert fixing a dependent file that needs to be updated due to a security fix in another file.

PRIMARY VULNERABILITY FIX:
- Type: {request.vulnerability_type}
- Severity: {vulnerability_analysis.severity.value}
- Vulnerable File: {code_context.vulnerable_file}
- Description: {request.description}

FIX STRATEGY:
{fix_strategy.fix_approach}

{dependency_constraints}

CODE CHANGES PLAN:
{chr(10).join(f"{i+1}. {step}" for i, step in enumerate(fix_strategy.code_changes_plan))}

DEPENDENT FILE TO FIX:
- File: {file_to_fix}
- This file needs to be updated because it uses methods/classes from the vulnerable file that were changed

ORIGINAL CODE OF DEPENDENT FILE:
```java
{original_code}
```

CODE CHANGES PLAN (relevant steps for this file):
{self._get_relevant_steps_for_file(fix_strategy.code_changes_plan, file_to_fix)}

CRITICAL REQUIREMENT - PRESERVE APPLICATION FUNCTIONALITY:
- The application MUST run end-to-end after this fix is applied
- DO NOT break any existing functionality - all existing features must continue to work
- Make MINIMAL changes - only add security fixes, don't refactor or restructure code
- Preserve ALL existing method signatures, return types, and parameters EXACTLY as they are
- Keep ALL existing imports - only add new imports if absolutely necessary
- Maintain the EXACT same class structure, field names, method names, and code organization
- Preserve ALL existing business logic - only add security-related code, don't remove existing logic
- Keep the same code style, indentation, and formatting as the original
- Preserve all existing comments and documentation
- Ensure the code compiles without errors and the application runs successfully
- If creating new methods, ensure they follow the exact signatures mentioned in the plan
- Test your fix mentally: Will the application still work after this change? If not, adjust the fix
- MINIMAL CHANGE PRINCIPLE: Only change what's necessary to fix the security issue, keep everything else identical

TASK:
Generate the complete fixed code for this dependent file that:
1. Implements ALL changes mentioned in the code_changes_plan for this file
2. If the plan mentions creating a new method (e.g., "Create method hasAccountAccess"), implement that method completely with the EXACT signature mentioned
3. Works seamlessly with the updated methods/classes from the primary fix
4. Maintains full compatibility with the security fix applied to {code_context.vulnerable_file}
5. Follows the fix strategy: {fix_strategy.fix_approach}
6. Ensures the application runs end-to-end after all files are fixed
7. Preserves ALL existing functionality and method signatures
8. Follows Java best practices and coding conventions
9. Maintains backward compatibility - existing code must work unchanged

CRITICAL OUTPUT REQUIREMENTS:
- Return ONLY the complete fixed Java code, nothing else
- Do NOT include markdown code blocks (no ```java or ```)
- Do NOT include markdown headers (no #, ##, ###)
- Do NOT include explanations, descriptions, or notes before or after the code
- Do NOT include line numbers or diff markers
- Do NOT include comments like "Here's the fixed code:" or "The changes are:"
- Start directly with package/import statements or class declaration
- End with the closing brace of the class/interface/enum
- Ensure the code is syntactically correct and complete Java code that will compile
- Preserve code style and formatting similar to the original
- Make sure this file works with the fixed version of {code_context.vulnerable_file}
- If the plan mentions creating a new method, implement it completely with proper logic
- Include all necessary imports and dependencies
- Only include valid Java syntax - no markdown, no explanations, no extra text

Return ONLY the complete fixed Java code starting with package/import/class:"""
        
        try:
            result = self.bedrock_service.invoke_claude(
                prompt=prompt,
                model_id=self.model_id,
                max_tokens=4096,
                temperature=0.3
            )
            
            # If Claude 3.5 Sonnet fails, try Claude 3 Sonnet
            if not result['success']:
                logger.warning(f"[{self.agent_name}] Claude 3.5 Sonnet not available, trying Claude 3 Sonnet...")
                result = self.bedrock_service.invoke_claude(
                    prompt=prompt,
                    model_id=self.fallback_model_id,
                    max_tokens=4096,
                    temperature=0.3
                )
            
            if not result['success']:
                logger.error(f"[{self.agent_name}] Failed to invoke model: {result.get('error_message')}")
                raise Exception(f"Model invocation failed: {result.get('error_message')}")
            
            # Extract code from response
            fixed_code = result['content'].strip()
            
            # Clean the code to remove markdown, explanations, and ensure it's valid Java
            fixed_code = self._clean_generated_code(fixed_code)

            fixed_code = self._postprocess_for_project_dependencies(
                code=fixed_code,
                repo_path=repo_path_str,
                file_rel_path=file_to_fix,
                original_code=original_code
            )
            
            return fixed_code
            
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error generating fixed code for dependent file {file_to_fix}: {str(e)}")
            # Return original code if fix generation fails
            return original_code

