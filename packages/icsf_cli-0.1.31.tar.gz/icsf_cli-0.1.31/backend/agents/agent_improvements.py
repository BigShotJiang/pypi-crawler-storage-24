"""
Phase 1 Agent Improvements: Helper Functions

This module contains helper functions for Phase 1 agent improvements:
- Import management
- Syntax validation  
- Framework detection
- Enhanced context extraction
"""

import re
import os
from typing import List, Tuple, Optional, Dict, Any
from pathlib import Path


class ImportManager:
    """Manages Java import statements"""
    
    # Common security-related classes and their imports
    COMMON_SECURITY_IMPORTS = {
        'HttpServletRequest': 'import javax.servlet.http.HttpServletRequest;',
        'HttpServletResponse': 'import javax.servlet.http.HttpServletResponse;',
        'PreparedStatement': 'import java.sql.PreparedStatement;',
        'Connection': 'import java.sql.Connection;',
        'SQLException': 'import java.sql.SQLException;',
        'Pattern': 'import java.util.regex.Pattern;',
        'Matcher': 'import java.util.regex.Matcher;',
        'List': 'import java.util.List;',
        'ArrayList': 'import java.util.ArrayList;',
        'Map': 'import java.util.Map;',
        'HashMap': 'import java.util.HashMap;',
        'Set': 'import java.util.Set;',
        'HashSet': 'import java.util.HashSet;',
        'Logger': 'import org.slf4j.Logger;',
        'LoggerFactory': 'import org.slf4j.LoggerFactory;',
        'StringUtils': 'import org.apache.commons.lang3.StringUtils;',
        'Objects': 'import java.util.Objects;',
        'Optional': 'import java.util.Optional;',
        'Stream': 'import java.util.stream.Stream;',
        'Collectors': 'import java.util.stream.Collectors;',
    }
    
    @staticmethod
    def extract_imports(code: str) -> List[str]:
        """
        Extract all import statements from Java code.
        
        Args:
            code: Java code content
            
        Returns:
            List of import statements
        """
        imports = []
        for line in code.split('\n'):
            line_stripped = line.strip()
            if line_stripped.startswith('import ') and line_stripped.endswith(';'):
                imports.append(line_stripped)
        return imports
    
    @staticmethod
    def detect_missing_imports(code: str, existing_imports: List[str]) -> List[str]:
        """
        Detect missing imports by analyzing class/interface usage in code.
        
        Args:
            code: Generated Java code
            existing_imports: Imports already in the code
            
        Returns:
            List of missing import statements that should be added
        """
        missing_imports = []
        
        # Check which classes are used in code but not imported
        for class_name, import_stmt in ImportManager.COMMON_SECURITY_IMPORTS.items():
            # Check if class is used in code
            if re.search(rf'\b{class_name}\b', code):
                # Check if already imported
                if not any(class_name in imp for imp in existing_imports):
                    missing_imports.append(import_stmt)
        
        return missing_imports
    
    @staticmethod
    def add_missing_imports(code: str) -> Tuple[str, List[str]]:
        """
        Add missing imports to generated code.
        
        Args:
            code: Generated Java code
            
        Returns:
            Tuple[str, List[str]]: (Code with imports added, List of added imports)
        """
        # Extract existing imports
        existing_imports = ImportManager.extract_imports(code)
        
        # Detect missing imports
        missing_imports = ImportManager.detect_missing_imports(code, existing_imports)
        
        if not missing_imports:
            return code, []
        
        # Find where to insert imports (after package statement, before class declaration)
        lines = code.split('\n')
        insert_index = 0
        
        # Find package statement
        for i, line in enumerate(lines):
            if line.strip().startswith('package '):
                insert_index = i + 1
                # Add blank line after package if not present
                if insert_index < len(lines) and lines[insert_index].strip():
                    lines.insert(insert_index, '')
                    insert_index += 1
                break
        
        # Find last import statement
        for i in range(insert_index, len(lines)):
            if lines[i].strip().startswith('import '):
                insert_index = i + 1
        
        # Insert missing imports
        for imp in missing_imports:
            lines.insert(insert_index, imp)
            insert_index += 1
        
        return '\n'.join(lines), missing_imports


class SyntaxValidator:
    """Validates Java syntax"""
    
    @staticmethod
    def validate(code: str) -> Tuple[bool, Optional[str]]:
        """
        Validate Java syntax by checking for common syntax errors.
        This is a basic validation - not a full parser.
        
        Args:
            code: Java code to validate
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        errors = []
        
        # Check for balanced braces
        brace_count = code.count('{') - code.count('}')
        if brace_count != 0:
            errors.append(f"Unbalanced braces: {abs(brace_count)} {'opening' if brace_count > 0 else 'closing'} brace(s) missing")
        
        # Check for balanced parentheses
        paren_count = code.count('(') - code.count(')')
        if paren_count != 0:
            errors.append(f"Unbalanced parentheses: {abs(paren_count)} {'opening' if paren_count > 0 else 'closing'} parenthesis missing")
        
        # Check for class/interface/enum declaration
        has_type_declaration = bool(re.search(r'\b(class|interface|enum)\s+\w+', code))
        if not has_type_declaration:
            errors.append("No class, interface, or enum declaration found")
        
        # Check for unclosed strings (simple check)
        quote_count = code.count('"') - code.count('\\"')
        if quote_count % 2 != 0:
            errors.append("Unclosed string literal detected")
        
        # Check for semicolons after method declarations (common error)
        if re.search(r'\)\s*;[\s\n]*\{', code):
            errors.append("Semicolon found after method declaration before opening brace")
        
        if errors:
            return False, "; ".join(errors)
        return True, None


class FrameworkDetector:
    """Detects frameworks and technologies used in a project"""
    
    @staticmethod
    def detect_frameworks(repo_path: str, pom_content: Optional[str] = None) -> Dict[str, bool]:
        """
        Detect which frameworks are used in the project.
        
        Args:
            repo_path: Path to repository root
            pom_content: Optional pom.xml content
            
        Returns:
            Dictionary with framework names as keys and boolean values
        """
        frameworks = {
            'spring_boot': False,
            'spring_security': False,
            'spring_mvc': False,
            'jakarta_ee': False,
            'javax_servlet': False,
            'hibernate': False,
            'jpa': False,
            'slf4j': False,
            'log4j': False,
        }
        
        # Read pom.xml if not provided
        if pom_content is None:
            pom_path = Path(repo_path) / 'pom.xml'
            if pom_path.exists():
                try:
                    with open(pom_path, 'r', encoding='utf-8') as f:
                        pom_content = f.read()
                except Exception:
                    pass
        
        if pom_content:
            # Check for Spring Boot
            if 'spring-boot' in pom_content.lower():
                frameworks['spring_boot'] = True
            
            # Check for Spring Security
            if 'spring-security' in pom_content.lower():
                frameworks['spring_security'] = True
            
            # Check for Spring MVC
            if 'spring-webmvc' in pom_content.lower() or 'spring-web' in pom_content.lower():
                frameworks['spring_mvc'] = True
            
            # Check for Jakarta EE
            if 'jakarta.servlet' in pom_content or 'jakarta.persistence' in pom_content:
                frameworks['jakarta_ee'] = True
            
            # Check for javax.servlet
            if 'javax.servlet' in pom_content:
                frameworks['javax_servlet'] = True
            
            # Check for Hibernate
            if 'hibernate' in pom_content.lower():
                frameworks['hibernate'] = True
            
            # Check for JPA
            if 'javax.persistence' in pom_content or 'jakarta.persistence' in pom_content:
                frameworks['jpa'] = True
            
            # Check for SLF4J
            if 'slf4j' in pom_content.lower():
                frameworks['slf4j'] = True
            
            # Check for Log4j
            if 'log4j' in pom_content.lower():
                frameworks['log4j'] = True
        
        return frameworks
    
    @staticmethod
    def get_framework_specific_recommendations(frameworks: Dict[str, bool], vulnerability_type: str) -> List[str]:
        """
        Get framework-specific fix recommendations.
        
        Args:
            frameworks: Dictionary of detected frameworks
            vulnerability_type: Type of vulnerability
            
        Returns:
            List of recommendations
        """
        recommendations = []
        
        # SQL Injection recommendations
        if 'sql injection' in vulnerability_type.lower():
            if frameworks.get('jpa') or frameworks.get('hibernate'):
                recommendations.append("Use JPA/Hibernate parameterized queries instead of raw SQL")
            recommendations.append("Use PreparedStatement with parameterized queries")
        
        # XSS recommendations
        if 'xss' in vulnerability_type.lower() or 'cross-site scripting' in vulnerability_type.lower():
            if frameworks.get('spring_mvc'):
                recommendations.append("Use Spring's HtmlUtils.htmlEscape() for output encoding")
            recommendations.append("Use OWASP Java Encoder for context-aware output encoding")
        
        # Authentication/Authorization recommendations
        if 'auth' in vulnerability_type.lower() or 'access control' in vulnerability_type.lower():
            if frameworks.get('spring_security'):
                recommendations.append("Use Spring Security's @PreAuthorize or @Secured annotations")
                recommendations.append("Leverage Spring Security's SecurityContext for user authentication")
            elif frameworks.get('jakarta_ee'):
                recommendations.append("Use Jakarta EE security annotations (@RolesAllowed, @PermitAll)")
        
        return recommendations


class ContextEnhancer:
    """Enhances code context extraction"""
    
    @staticmethod
    def extract_full_method(code: str, line_number: int) -> Tuple[str, int, int]:
        """
        Extract the full method containing the specified line.
        
        Args:
            code: Full file content
            line_number: Line number within the method
            
        Returns:
            Tuple[str, int, int]: (method_code, start_line, end_line)
        """
        lines = code.split('\n')
        if line_number < 1 or line_number > len(lines):
            return "", 0, 0
        
        # Find method start (look backwards for method signature)
        start_line = line_number
        brace_count = 0
        found_method = False
        
        for i in range(line_number - 1, -1, -1):
            line = lines[i].strip()
            
            # Look for method signature patterns
            if re.match(r'(public|private|protected|static|final|synchronized|\s)+\s+\w+\s+\w+\s*\(', line):
                start_line = i + 1
                found_method = True
                break
            
            # Stop if we hit another method or class declaration
            if re.match(r'(public|private|protected)\s+(class|interface|enum)', line):
                break
        
        if not found_method:
            start_line = max(1, line_number - 20)
        
        # Find method end (look forwards for closing brace)
        end_line = line_number
        brace_count = 0
        in_method = False
        
        for i in range(start_line - 1, len(lines)):
            line = lines[i]
            brace_count += line.count('{') - line.count('}')
            
            if '{' in line:
                in_method = True
            
            if in_method and brace_count == 0:
                end_line = i + 1
                break
        
        if end_line == line_number:
            end_line = min(len(lines), line_number + 20)
        
        method_code = '\n'.join(lines[start_line-1:end_line])
        return method_code, start_line, end_line
    
    @staticmethod
    def extract_full_class(code: str) -> str:
        """
        Extract the full class definition.
        
        Args:
            code: Full file content
            
        Returns:
            Full class code
        """
        # For now, return the full code
        # In the future, could extract just the class definition
        return code
