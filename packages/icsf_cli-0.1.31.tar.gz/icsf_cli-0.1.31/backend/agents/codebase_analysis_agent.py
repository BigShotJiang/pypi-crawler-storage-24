"""
Codebase Analysis Agent

Advanced codebase analysis similar to AI coding assistants (Cursor, Antigravity, etc.).
Analyzes codebase structure, dependencies, patterns, and relationships.
"""

import os
import re
import ast
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List, Set, Tuple
from collections import defaultdict

from ..services.bedrock_service import BedrockService

logger = logging.getLogger(__name__)


class CodebaseAnalysisAgent:
    """Advanced codebase analysis agent for intelligent code understanding"""
    
    # Class-level cache shared across instances for the same repo
    _cache: Dict[str, Any] = {}
    _cache_timestamps: Dict[str, float] = {}
    CACHE_TTL = 300  # 5 minutes
    
    def __init__(self, bedrock_service: BedrockService):
        """
        Initialize Codebase Analysis Agent.
        
        Args:
            bedrock_service: BedrockService instance for AI operations
        """
        self.bedrock_service = bedrock_service
        self.agent_name = "CodebaseAnalysisAgent"
        self.model_id = bedrock_service.CLAUDE_3_5_SONNET
        
    def analyze_codebase_structure(
        self,
        repo_path: str,
        focus_file: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Analyze codebase structure, architecture, and patterns.
        Uses in-memory cache with TTL to avoid re-analyzing the same repo.
        """
        import time as _time
        cache_key = f"{repo_path}:{focus_file or ''}"
        
        # Check cache
        if cache_key in self._cache:
            age = _time.time() - self._cache_timestamps.get(cache_key, 0)
            if age < self.CACHE_TTL:
                logger.info(f"[{self.agent_name}] Cache HIT for {repo_path} (age={age:.0f}s)")
                return self._cache[cache_key]
        
        logger.info(f"[{self.agent_name}] Analyzing codebase structure for {repo_path}")
        
        analysis = {
            'architecture': {},
            'dependencies': {},
            'patterns': {},
            'file_relationships': {},
            'code_quality': {}
        }
        
        try:
            # Find all source files
            java_files = self._find_java_files(repo_path)
            
            # Analyze architecture
            analysis['architecture'] = self._analyze_architecture(repo_path, java_files)
            
            # Build dependency graph
            analysis['dependencies'] = self._build_dependency_graph(repo_path, java_files)
            
            # Detect design patterns
            analysis['patterns'] = self._detect_patterns(repo_path, java_files)
            
            # Analyze file relationships
            analysis['file_relationships'] = self._analyze_file_relationships(
                repo_path, java_files, focus_file
            )
            
            # Code quality metrics
            analysis['code_quality'] = self._analyze_code_quality(repo_path, java_files)
            
            logger.info(f"[{self.agent_name}] Codebase analysis completed")
            
            # Store in cache
            self._cache[cache_key] = analysis
            self._cache_timestamps[cache_key] = _time.time()
            
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error analyzing codebase: {str(e)}")
            analysis['error'] = str(e)
        
        return analysis

    
    def find_dependent_files(
        self,
        repo_path: str,
        target_file: str,
        max_depth: int = 3
    ) -> Dict[str, Any]:
        """
        Find all files that depend on or are related to the target file.
        
        Args:
            repo_path: Path to repository
            target_file: Target file path (relative to repo root)
            max_depth: Maximum depth to search for dependencies
            
        Returns:
            Dictionary with dependent files and relationships
        """
        logger.info(f"[{self.agent_name}] Finding dependent files for {target_file}")
        
        dependencies = {
            'direct_dependents': [],
            'indirect_dependents': [],
            'related_files': [],
            'imports': [],
            'exports': []
        }
        
        try:
            java_files = self._find_java_files(repo_path)
            target_full_path = os.path.join(repo_path, target_file)
            
            if not os.path.exists(target_full_path):
                return dependencies
            
            # Parse target file
            target_info = self._parse_java_file(target_full_path)
            
            # Find files that import/use this file
            dependencies['direct_dependents'] = self._find_files_using_class(
                repo_path, java_files, target_info
            )
            
            # Find files imported by target
            dependencies['imports'] = self._extract_imports(target_full_path)
            
            # Find classes exported by target
            dependencies['exports'] = target_info.get('classes', []) + target_info.get('interfaces', [])
            
            # Find related files (same package, similar functionality)
            dependencies['related_files'] = self._find_related_files(
                repo_path, target_file, java_files
            )
            
            logger.info(
                f"[{self.agent_name}] Found {len(dependencies['direct_dependents'])} direct dependents, "
                f"{len(dependencies['related_files'])} related files"
            )
            
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error finding dependencies: {str(e)}")
            dependencies['error'] = str(e)
        
        return dependencies
    
    def analyze_code_flow(
        self,
        repo_path: str,
        file_path: str,
        line_number: int
    ) -> Dict[str, Any]:
        """
        Analyze code flow and data flow for a specific location.
        
        Args:
            repo_path: Path to repository
            file_path: File path relative to repo root
            line_number: Line number to analyze
            
        Returns:
            Dictionary with code flow analysis
        """
        logger.info(f"[{self.agent_name}] Analyzing code flow for {file_path}:{line_number}")
        
        flow_analysis = {
            'data_flow': [],
            'control_flow': [],
            'method_calls': [],
            'variable_usage': [],
            'side_effects': []
        }
        
        try:
            full_path = os.path.join(repo_path, file_path)
            if not os.path.exists(full_path):
                return flow_analysis
            
            # Read file
            with open(full_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Analyze context around the line
            context_start = max(0, line_number - 20)
            context_end = min(len(lines), line_number + 20)
            context = ''.join(lines[context_start:context_end])
            
            # Extract method calls
            flow_analysis['method_calls'] = self._extract_method_calls(context)
            
            # Extract variable usage
            flow_analysis['variable_usage'] = self._extract_variable_usage(
                context, lines[line_number - 1] if line_number <= len(lines) else ''
            )
            
            # Analyze data flow
            flow_analysis['data_flow'] = self._analyze_data_flow(
                full_path, line_number, lines
            )
            
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error analyzing code flow: {str(e)}")
            flow_analysis['error'] = str(e)
        
        return flow_analysis
    
    def _find_java_files(self, repo_path: str) -> List[str]:
        """Find all Java files in repository"""
        java_files = []
        try:
            for root, dirs, files in os.walk(repo_path):
                # Skip hidden and build directories
                dirs[:] = [d for d in dirs if not d.startswith('.') and 
                          d not in ['target', 'build', 'out', 'node_modules', '.git']]
                
                for file in files:
                    if file.endswith('.java'):
                        full_path = os.path.join(root, file)
                        rel_path = os.path.relpath(full_path, repo_path)
                        java_files.append(rel_path.replace('\\', '/'))
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error finding Java files: {str(e)}")
        
        return java_files
    
    def _analyze_architecture(
        self,
        repo_path: str,
        java_files: List[str]
    ) -> Dict[str, Any]:
        """Analyze codebase architecture"""
        architecture = {
            'layers': [],
            'packages': {},
            'modules': [],
            'entry_points': []
        }
        
        try:
            # Analyze package structure
            packages = defaultdict(list)
            for file_path in java_files:
                full_path = os.path.join(repo_path, file_path)
                parsed = self._parse_java_file(full_path)
                package = parsed.get('package', '')
                if package:
                    packages[package].append(file_path)
            
            architecture['packages'] = dict(packages)
            
            # Detect layers (controller, service, dao, model)
            for package, files in packages.items():
                if any(layer in package.lower() for layer in ['controller', 'servlet', 'rest']):
                    architecture['layers'].append({'type': 'presentation', 'package': package, 'files': files})
                elif any(layer in package.lower() for layer in ['service', 'business']):
                    architecture['layers'].append({'type': 'business', 'package': package, 'files': files})
                elif any(layer in package.lower() for layer in ['dao', 'repository', 'data']):
                    architecture['layers'].append({'type': 'data', 'package': package, 'files': files})
                elif any(layer in package.lower() for layer in ['model', 'entity', 'domain']):
                    architecture['layers'].append({'type': 'domain', 'package': package, 'files': files})
            
            # Find entry points (main methods, servlets, controllers)
            for file_path in java_files:
                full_path = os.path.join(repo_path, file_path)
                if self._has_entry_point(full_path):
                    architecture['entry_points'].append(file_path)
        
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error analyzing architecture: {str(e)}")
        
        return architecture
    
    def _build_dependency_graph(
        self,
        repo_path: str,
        java_files: List[str]
    ) -> Dict[str, List[str]]:
        """Build dependency graph between files"""
        graph = defaultdict(list)
        
        try:
            # Parse all files first
            file_info = {}
            for file_path in java_files:
                full_path = os.path.join(repo_path, file_path)
                file_info[file_path] = self._parse_java_file(full_path)
            
            # Build graph
            for file_path, info in file_info.items():
                imports = info.get('imports', [])
                for imp in imports:
                    # Find files that provide this import
                    for other_file, other_info in file_info.items():
                        if other_file != file_path:
                            classes = other_info.get('classes', []) + other_info.get('interfaces', [])
                            package = other_info.get('package', '')
                            
                            # Check if import matches
                            for cls in classes:
                                full_class = f"{package}.{cls}" if package else cls
                                if imp == full_class or imp.endswith(f".{cls}"):
                                    if other_file not in graph[file_path]:
                                        graph[file_path].append(other_file)
                                    break
        
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error building dependency graph: {str(e)}")
        
        return dict(graph)
    
    def _detect_patterns(
        self,
        repo_path: str,
        java_files: List[str]
    ) -> Dict[str, List[str]]:
        """Detect design patterns in codebase"""
        patterns = {
            'singleton': [],
            'factory': [],
            'builder': [],
            'observer': [],
            'strategy': []
        }
        
        try:
            for file_path in java_files:
                full_path = os.path.join(repo_path, file_path)
                content = self._read_file(full_path)
                
                # Detect Singleton
                if re.search(r'private\s+static\s+\w+\s+instance', content, re.IGNORECASE):
                    if 'getInstance' in content:
                        patterns['singleton'].append(file_path)
                
                # Detect Factory
                if 'Factory' in os.path.basename(file_path) or 'create' in content.lower():
                    if re.search(r'public\s+\w+\s+create\w*\(', content):
                        patterns['factory'].append(file_path)
                
                # Detect Builder
                if 'Builder' in os.path.basename(file_path) or 'build()' in content:
                    patterns['builder'].append(file_path)
        
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error detecting patterns: {str(e)}")
        
        return patterns
    
    def _analyze_file_relationships(
        self,
        repo_path: str,
        java_files: List[str],
        focus_file: Optional[str] = None
    ) -> Dict[str, Any]:
        """Analyze relationships between files"""
        relationships = {
            'imports': {},
            'inheritance': {},
            'composition': {},
            'same_package': {}
        }
        
        try:
            if focus_file:
                focus_full = os.path.join(repo_path, focus_file)
                focus_info = self._parse_java_file(focus_full)
                focus_package = focus_info.get('package', '')
                focus_classes = focus_info.get('classes', [])
                
                # Find files in same package
                for file_path in java_files:
                    if file_path != focus_file:
                        file_info = self._parse_java_file(os.path.join(repo_path, file_path))
                        if file_info.get('package') == focus_package:
                            if focus_package not in relationships['same_package']:
                                relationships['same_package'][focus_package] = []
                            relationships['same_package'][focus_package].append(file_path)
        
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error analyzing relationships: {str(e)}")
        
        return relationships
    
    def _analyze_code_quality(
        self,
        repo_path: str,
        java_files: List[str]
    ) -> Dict[str, Any]:
        """Analyze code quality metrics"""
        quality = {
            'complexity': {},
            'duplication': [],
            'code_smells': []
        }
        
        try:
            for file_path in java_files[:50]:  # Limit for performance
                full_path = os.path.join(repo_path, file_path)
                content = self._read_file(full_path)
                
                # Calculate complexity (simple metric)
                methods = len(re.findall(r'public\s+\w+\s+\w+\s*\(', content))
                nested = len(re.findall(r'\{\s*\{', content))
                quality['complexity'][file_path] = {
                    'methods': methods,
                    'nesting_depth': nested,
                    'lines': len(content.split('\n'))
                }
        
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error analyzing quality: {str(e)}")
        
        return quality
    
    def _parse_java_file(self, file_path: str) -> Dict[str, Any]:
        """Parse Java file to extract structure"""
        info = {
            'package': '',
            'imports': [],
            'classes': [],
            'interfaces': [],
            'methods': []
        }
        
        try:
            content = self._read_file(file_path)
            
            # Extract package
            package_match = re.search(r'package\s+([\w.]+);', content)
            if package_match:
                info['package'] = package_match.group(1)
            
            # Extract imports
            imports = re.findall(r'import\s+([\w.]+);', content)
            info['imports'] = imports
            
            # Extract classes
            classes = re.findall(r'(?:public\s+)?class\s+(\w+)', content)
            info['classes'] = classes
            
            # Extract interfaces
            interfaces = re.findall(r'interface\s+(\w+)', content)
            info['interfaces'] = interfaces
            
            # Extract methods
            methods = re.findall(r'(?:public|private|protected)\s+\w+\s+(\w+)\s*\(', content)
            info['methods'] = methods
        
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error parsing file {file_path}: {str(e)}")
        
        return info
    
    def _find_files_using_class(
        self,
        repo_path: str,
        java_files: List[str],
        target_info: Dict[str, Any]
    ) -> List[str]:
        """Find files that use classes from target file"""
        dependents = []
        target_classes = target_info.get('classes', []) + target_info.get('interfaces', [])
        target_package = target_info.get('package', '')
        
        for file_path in java_files:
            full_path = os.path.join(repo_path, file_path)
            content = self._read_file(full_path)
            
            # Check if file imports or uses target classes
            for cls in target_classes:
                # Check import
                if f"import {target_package}.{cls}" in content or cls in content:
                    if file_path not in dependents:
                        dependents.append(file_path)
                    break
        
        return dependents
    
    def _extract_imports(self, file_path: str) -> List[str]:
        """Extract import statements from file"""
        try:
            content = self._read_file(file_path)
            imports = re.findall(r'import\s+([\w.]+);', content)
            return imports
        except Exception:
            return []
    
    def _find_related_files(
        self,
        repo_path: str,
        target_file: str,
        java_files: List[str]
    ) -> List[str]:
        """Find files related to target (same package, similar name)"""
        related = []
        target_name = os.path.basename(target_file).replace('.java', '')
        target_dir = os.path.dirname(target_file)
        
        for file_path in java_files:
            if file_path != target_file:
                file_name = os.path.basename(file_path).replace('.java', '')
                file_dir = os.path.dirname(file_path)
                
                # Same directory
                if file_dir == target_dir:
                    related.append(file_path)
                # Similar name (e.g., UserService, UserController)
                elif target_name in file_name or file_name in target_name:
                    related.append(file_path)
        
        return related
    
    def _extract_method_calls(self, code: str) -> List[str]:
        """Extract method calls from code"""
        method_calls = re.findall(r'(\w+)\s*\(', code)
        return list(set(method_calls))
    
    def _extract_variable_usage(self, context: str, line: str) -> List[str]:
        """Extract variable usage"""
        variables = re.findall(r'\b([a-z][a-zA-Z0-9]*)\s*=', context)
        return list(set(variables))
    
    def _analyze_data_flow(
        self,
        file_path: str,
        line_number: int,
        lines: List[str]
    ) -> List[Dict[str, Any]]:
        """Analyze data flow around a line"""
        data_flow = []
        
        try:
            # Simple analysis: find variable assignments and usages
            target_line = lines[line_number - 1] if line_number <= len(lines) else ''
            
            # Find variables in target line
            vars_in_line = re.findall(r'\b([a-z][a-zA-Z0-9]*)\b', target_line)
            
            # Find where these variables are assigned/used
            for var in vars_in_line:
                for i, line in enumerate(lines[max(0, line_number-50):line_number+50], max(1, line_number-49)):
                    if f"{var} =" in line or f"{var}=" in line:
                        data_flow.append({
                            'variable': var,
                            'line': i,
                            'type': 'assignment'
                        })
        
        except Exception as e:
            logger.error(f"[{self.agent_name}] Error analyzing data flow: {str(e)}")
        
        return data_flow
    
    def _has_entry_point(self, file_path: str) -> bool:
        """Check if file has entry point (main method, servlet, etc.)"""
        try:
            content = self._read_file(file_path)
            return (
                'public static void main' in content or
                'extends HttpServlet' in content or
                '@RestController' in content or
                '@Controller' in content
            )
        except Exception:
            return False
    
    def _read_file(self, file_path: str) -> str:
        """Read file content"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception:
            return ""

