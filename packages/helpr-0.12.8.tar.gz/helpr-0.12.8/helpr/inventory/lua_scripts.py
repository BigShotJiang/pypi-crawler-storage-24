"""
LUA Scripts for Atomic Inventory Operations.

These scripts execute atomically in Redis, ensuring no race conditions
between checking availability and reserving inventory.

Key Schema:
    inv:{warehouse_id}:{sku} -> HASH {
        "available": int,              # What can be sold (calculated)
        "erp_quantity": int,           # Latest snapshot from ERP
        "initial_erp_quantity": int,   # Baseline for reconciliation (set when confirmations clear)
        "reserved_medusa": int,        # Reserved by Medusa orders (total)
        "reserved_shopify": int,       # Reserved by Shopify orders (total)
        "confirmed_medusa": int,       # Confirmed/handed off to ERP (Medusa)
        "confirmed_shopify": int       # Confirmed/handed off to ERP (Shopify)
    }
"""
# RESERVE_SCRIPT
# Atomically checks availability and reserves inventory.
# Returns JSON with success status and current state.
#
# KEYS[1] = inv:{warehouse_id}:{sku}
# ARGV[1] = quantity to reserve (int)
# ARGV[2] = source ("medusa" or "shopify")
RESERVE_SCRIPT = """
local key = KEYS[1]
local qty = tonumber(ARGV[1])
local source = ARGV[2]

-- Validate inputs
if qty <= 0 then
    return cjson.encode({
        success = false,
        reason = "invalid_quantity",
        message = "Quantity must be positive"
    })
end

-- Get current state
local available = tonumber(redis.call('HGET', key, 'available') or '0')
local reserved_key = 'reserved_' .. source
local current_reserved = tonumber(redis.call('HGET', key, reserved_key) or '0')

-- Check if enough available
if available < qty then
    return cjson.encode({
        success = false,
        reason = "insufficient_stock",
        available = available,
        requested = qty,
        reserved = current_reserved,
        source = source
    })
end

-- Atomic reserve: decrement available, increment reserved
redis.call('HINCRBY', key, 'available', -qty)
redis.call('HINCRBY', key, reserved_key, qty)

-- Get updated values
local new_available = tonumber(redis.call('HGET', key, 'available'))
local new_reserved = tonumber(redis.call('HGET', key, reserved_key))
local reserved_medusa = tonumber(redis.call('HGET', key, 'reserved_medusa') or '0')
local reserved_shopify = tonumber(redis.call('HGET', key, 'reserved_shopify') or '0')

return cjson.encode({
    success = true,
    available = new_available,
    reserved = new_reserved,
    reserved_medusa = reserved_medusa,
    reserved_shopify = reserved_shopify,
    source = source,
    quantity_reserved = qty
})
"""

# RELEASE_SCRIPT
# Atomically releases reserved inventory.
# For cancellation: returns items to available stock.
# For fulfillment: items are shipped out, available stays unchanged, erp_quantity decreases.
#
# KEYS[1] = inv:{warehouse_id}:{sku}
# ARGV[1] = quantity to release (int)
# ARGV[2] = source ("medusa" or "shopify")
# ARGV[3] = reason ("fulfilled", "cancelled", "expired")
RELEASE_SCRIPT = """
local key = KEYS[1]
local qty = tonumber(ARGV[1])
local source = ARGV[2]
local reason = ARGV[3] or 'cancelled'

-- Validate inputs
if qty <= 0 then
    return cjson.encode({
        success = false,
        reason = "invalid_quantity",
        message = "Quantity must be positive"
    })
end

-- Get current reserved for this source
local reserved_key = 'reserved_' .. source
local current_reserved = tonumber(redis.call('HGET', key, reserved_key) or '0')

-- Can't release more than reserved
local release_qty = math.min(qty, current_reserved)

if release_qty == 0 then
    -- Nothing to release
    local available = tonumber(redis.call('HGET', key, 'available') or '0')
    local erp_quantity = tonumber(redis.call('HGET', key, 'erp_quantity') or '0')
    return cjson.encode({
        success = true,
        released = 0,
        available = available,
        reserved = current_reserved,
        erp_quantity = erp_quantity,
        source = source,
        reason = reason,
        message = "Nothing to release"
    })
end

-- Always decrement reserved count
redis.call('HINCRBY', key, reserved_key, -release_qty)

-- Get confirmed key
local confirmed_key = 'confirmed_' .. source
local current_confirmed = tonumber(redis.call('HGET', key, confirmed_key) or '0')

-- Handle based on reason
if reason == 'fulfilled' then
    -- Fulfillment: items are shipped out
    -- DON'T decrement confirmed - ERP tracking needs it to calculate erp_processed
    -- DON'T change available - items are gone
    -- The confirmed count will be cleared when ERP sends reduced quantity
    -- and the reconciliation formula detects erp_processed >= total_confirmed
else
    -- Cancellation/Expiry: items return to available stock
    -- Decrement confirmed since order won't be processed by ERP
    local confirmed_to_release = math.min(release_qty, current_confirmed)
    if confirmed_to_release > 0 then
        redis.call('HINCRBY', key, confirmed_key, -confirmed_to_release)
    end
    -- Return items to available
    redis.call('HINCRBY', key, 'available', release_qty)
end

-- Get updated values
local new_available = tonumber(redis.call('HGET', key, 'available'))
local new_reserved = tonumber(redis.call('HGET', key, reserved_key))
local new_confirmed = tonumber(redis.call('HGET', key, confirmed_key))
local new_erp_quantity = tonumber(redis.call('HGET', key, 'erp_quantity') or '0')
local reserved_medusa = tonumber(redis.call('HGET', key, 'reserved_medusa') or '0')
local reserved_shopify = tonumber(redis.call('HGET', key, 'reserved_shopify') or '0')

return cjson.encode({
    success = true,
    released = release_qty,
    available = new_available,
    reserved = new_reserved,
    reserved_medusa = reserved_medusa,
    reserved_shopify = reserved_shopify,
    confirmed = new_confirmed,
    erp_quantity = new_erp_quantity,
    source = source,
    reason = reason
})
"""

# CONFIRM_RESERVATION_SCRIPT
# Called when ERP confirms/accepts an order (handoff).
# Moves reservation from 'unconfirmed' to 'confirmed' state.
# Does NOT change available - that's handled by SET_INVENTORY when ERP updates.
#
# KEYS[1] = inv:{warehouse_id}:{sku}
# ARGV[1] = quantity to confirm (int)
# ARGV[2] = source ("medusa" or "shopify")
CONFIRM_RESERVATION_SCRIPT = """
local key = KEYS[1]
local qty = tonumber(ARGV[1])
local source = ARGV[2]

-- Validate inputs
if qty <= 0 then
    return cjson.encode({
        success = false,
        reason = "invalid_quantity",
        message = "Quantity must be positive"
    })
end

-- Get current reserved and confirmed for this source
local reserved_key = 'reserved_' .. source
local confirmed_key = 'confirmed_' .. source
local current_reserved = tonumber(redis.call('HGET', key, reserved_key) or '0')
local current_confirmed = tonumber(redis.call('HGET', key, confirmed_key) or '0')

-- Calculate how much we can confirm (can't confirm more than unconfirmed)
local unconfirmed = current_reserved - current_confirmed
local confirm_qty = math.min(qty, unconfirmed)

if confirm_qty <= 0 then
    -- Nothing to confirm
    local available = tonumber(redis.call('HGET', key, 'available') or '0')
    return cjson.encode({
        success = true,
        confirmed = 0,
        available = available,
        reserved = current_reserved,
        confirmed_total = current_confirmed,
        source = source,
        message = "Nothing to confirm"
    })
end

-- Increment confirmed count (reservation moves from unconfirmed to confirmed)
redis.call('HINCRBY', key, confirmed_key, confirm_qty)

-- Get current available (don't recalculate - let SET_INVENTORY handle it)
local available = tonumber(redis.call('HGET', key, 'available') or '0')
local new_confirmed_this_source = current_confirmed + confirm_qty

return cjson.encode({
    success = true,
    confirmed = confirm_qty,
    available = available,
    reserved = current_reserved,
    confirmed_total = new_confirmed_this_source,
    unconfirmed = current_reserved - new_confirmed_this_source,
    source = source
})
"""

# SET_INVENTORY_SCRIPT
# Called by Storehouse when ERP sends inventory updates.
# Uses reconciliation formula to prevent overselling during intermediate ERP snapshots.
#
# The formula tracks how many confirmed orders ERP has processed by comparing
# current ERP quantity against a baseline (initial_erp_quantity).
#
# Formula:
#   erp_processed = max(0, initial_erp - current_erp)
#   pending_confirmations = max(0, total_confirmed - erp_processed)
#   available = max(0, current_erp - pending_confirmations - unconfirmed)
#
# When all confirmations are processed (pending=0 and confirmed=0), reset baseline.
#
# KEYS[1] = inv:{warehouse_id}:{sku}
# ARGV[1] = erp_quantity (int) - the sellable quantity from ERP
SET_INVENTORY_SCRIPT = """
local key = KEYS[1]
local erp_qty = tonumber(ARGV[1])

-- Validate input
if erp_qty < 0 then
    return cjson.encode({
        success = false,
        reason = "invalid_quantity",
        message = "ERP quantity cannot be negative"
    })
end

-- Get current values to check if anything changed
local old_erp_qty = tonumber(redis.call('HGET', key, 'erp_quantity') or '0')
local old_available = tonumber(redis.call('HGET', key, 'available') or '0')

-- Get current reservations and confirmed counts
local reserved_medusa = tonumber(redis.call('HGET', key, 'reserved_medusa') or '0')
local reserved_shopify = tonumber(redis.call('HGET', key, 'reserved_shopify') or '0')
local confirmed_medusa = tonumber(redis.call('HGET', key, 'confirmed_medusa') or '0')
local confirmed_shopify = tonumber(redis.call('HGET', key, 'confirmed_shopify') or '0')

-- Calculate totals
local total_reserved = reserved_medusa + reserved_shopify
local total_confirmed = confirmed_medusa + confirmed_shopify

-- Calculate unconfirmed reservations (orders not yet sent to ERP)
local unconfirmed_medusa = math.max(0, reserved_medusa - confirmed_medusa)
local unconfirmed_shopify = math.max(0, reserved_shopify - confirmed_shopify)
local total_unconfirmed = unconfirmed_medusa + unconfirmed_shopify

-- Get or initialize baseline for reconciliation
-- initial_erp_quantity is the ERP snapshot when confirmations were last cleared
local initial_erp = tonumber(redis.call('HGET', key, 'initial_erp_quantity') or '0')

-- If no baseline exists (first time or after reset), use current erp_qty
if initial_erp == 0 then
    initial_erp = erp_qty
end

-- Calculate how many confirmed orders ERP has processed
-- erp_processed = how much ERP quantity decreased since baseline
local erp_processed = math.max(0, initial_erp - erp_qty)

-- pending_confirmations = confirmed orders not yet reflected in ERP quantity
local pending_confirmations = math.max(0, total_confirmed - erp_processed)

-- Calculate available using reconciliation formula
-- available = erp_snapshot - pending_confirmations - unconfirmed_reservations
local new_available = math.max(0, erp_qty - pending_confirmations - total_unconfirmed)

-- Reset baseline when no active reservations AND either:
--   1. No pending confirmations (ERP caught up), OR
--   2. ERP quantity increased (restock - assume previous orders processed)
-- This handles: fulfilled orders, idle periods, and restocks
local should_reset = false
if total_reserved == 0 then
    if pending_confirmations == 0 then
        -- ERP caught up with all confirmed orders
        should_reset = true
    elseif erp_qty > initial_erp then
        -- ERP restocked (quantity went UP) with no active orders
        -- Assume previous confirmed orders were already processed
        should_reset = true
    end
end

if should_reset then
    initial_erp = erp_qty
    -- Reset confirmed counters since there are no active orders
    redis.call('HSET', key, 'confirmed_medusa', 0)
    redis.call('HSET', key, 'confirmed_shopify', 0)
    -- Update local vars for return value
    confirmed_medusa = 0
    confirmed_shopify = 0
    total_confirmed = 0
    -- Recalculate with reset values
    pending_confirmations = 0
    new_available = math.max(0, erp_qty - total_unconfirmed)
end

-- Update hash fields
redis.call('HSET', key, 'erp_quantity', erp_qty)
redis.call('HSET', key, 'initial_erp_quantity', initial_erp)
redis.call('HSET', key, 'available', new_available)

-- Check if anything actually changed
local changed = (erp_qty ~= old_erp_qty) or (new_available ~= old_available)

return cjson.encode({
    success = true,
    changed = changed,
    erp_quantity = erp_qty,
    old_erp_quantity = old_erp_qty,
    initial_erp_quantity = initial_erp,
    available = new_available,
    old_available = old_available,
    reserved_medusa = reserved_medusa,
    reserved_shopify = reserved_shopify,
    confirmed_medusa = confirmed_medusa,
    confirmed_shopify = confirmed_shopify,
    unconfirmed_medusa = unconfirmed_medusa,
    unconfirmed_shopify = unconfirmed_shopify,
    total_unconfirmed = total_unconfirmed,
    total_confirmed = total_confirmed,
    erp_processed = erp_processed,
    pending_confirmations = pending_confirmations
})
"""

# CHECK_AVAILABLE_SCRIPT
# Simple read of current available quantity.
# Can be used for pre-checkout availability checks.
#
# KEYS[1] = inv:{warehouse_id}:{sku}
CHECK_AVAILABLE_SCRIPT = """
local key = KEYS[1]
local available = tonumber(redis.call('HGET', key, 'available') or '0')
return available
"""

# GET_INVENTORY_STATE_SCRIPT
# Returns full inventory state for a SKU/warehouse.
# Useful for debugging and monitoring.
#
# KEYS[1] = inv:{warehouse_id}:{sku}
GET_INVENTORY_STATE_SCRIPT = """
local key = KEYS[1]

local available = tonumber(redis.call('HGET', key, 'available') or '0')
local erp_quantity = tonumber(redis.call('HGET', key, 'erp_quantity') or '0')
local initial_erp_quantity = tonumber(redis.call('HGET', key, 'initial_erp_quantity') or '0')
local reserved_medusa = tonumber(redis.call('HGET', key, 'reserved_medusa') or '0')
local reserved_shopify = tonumber(redis.call('HGET', key, 'reserved_shopify') or '0')
local confirmed_medusa = tonumber(redis.call('HGET', key, 'confirmed_medusa') or '0')
local confirmed_shopify = tonumber(redis.call('HGET', key, 'confirmed_shopify') or '0')

-- Calculate derived values
local total_confirmed = confirmed_medusa + confirmed_shopify
local erp_processed = math.max(0, initial_erp_quantity - erp_quantity)
local pending_confirmations = math.max(0, total_confirmed - erp_processed)

return cjson.encode({
    available = available,
    erp_quantity = erp_quantity,
    initial_erp_quantity = initial_erp_quantity,
    reserved_medusa = reserved_medusa,
    reserved_shopify = reserved_shopify,
    confirmed_medusa = confirmed_medusa,
    confirmed_shopify = confirmed_shopify,
    total_reserved = reserved_medusa + reserved_shopify,
    total_confirmed = total_confirmed,
    unconfirmed_medusa = math.max(0, reserved_medusa - confirmed_medusa),
    unconfirmed_shopify = math.max(0, reserved_shopify - confirmed_shopify),
    erp_processed = erp_processed,
    pending_confirmations = pending_confirmations
})
"""

# BULK_SET_INVENTORY_SCRIPT
# Sets inventory for multiple SKUs in a single atomic operation.
# Uses the same reconciliation formula as SET_INVENTORY_SCRIPT.
# Used during bulk ERP updates.
#
# KEYS = list of inv:{warehouse_id}:{sku} keys
# ARGV = list of erp quantities (same order as KEYS)
BULK_SET_INVENTORY_SCRIPT = """
local results = {}

for i, key in ipairs(KEYS) do
    local erp_qty = tonumber(ARGV[i])
    
    if erp_qty and erp_qty >= 0 then
        -- Get current reservations and confirmed counts
        local reserved_medusa = tonumber(redis.call('HGET', key, 'reserved_medusa') or '0')
        local reserved_shopify = tonumber(redis.call('HGET', key, 'reserved_shopify') or '0')
        local confirmed_medusa = tonumber(redis.call('HGET', key, 'confirmed_medusa') or '0')
        local confirmed_shopify = tonumber(redis.call('HGET', key, 'confirmed_shopify') or '0')
        
        -- Calculate totals
        local total_reserved = reserved_medusa + reserved_shopify
        local total_confirmed = confirmed_medusa + confirmed_shopify
        
        -- Calculate unconfirmed reservations (orders not yet sent to ERP)
        local unconfirmed_medusa = math.max(0, reserved_medusa - confirmed_medusa)
        local unconfirmed_shopify = math.max(0, reserved_shopify - confirmed_shopify)
        local total_unconfirmed = unconfirmed_medusa + unconfirmed_shopify
        
        -- Get or initialize baseline for reconciliation
        local initial_erp = tonumber(redis.call('HGET', key, 'initial_erp_quantity') or '0')
        if initial_erp == 0 then
            initial_erp = erp_qty
        end
        
        -- Calculate how many confirmed orders ERP has processed
        local erp_processed = math.max(0, initial_erp - erp_qty)
        
        -- pending_confirmations = confirmed orders not yet reflected in ERP quantity
        local pending_confirmations = math.max(0, total_confirmed - erp_processed)
        
        -- Calculate available using reconciliation formula
        local new_available = math.max(0, erp_qty - pending_confirmations - total_unconfirmed)
        
        -- Reset baseline when no active reservations AND either:
        --   1. No pending confirmations, OR 2. ERP quantity increased (restock)
        local should_reset = false
        if total_reserved == 0 then
            if pending_confirmations == 0 then
                should_reset = true
            elseif erp_qty > initial_erp then
                should_reset = true
            end
        end
        
        if should_reset then
            initial_erp = erp_qty
            redis.call('HSET', key, 'confirmed_medusa', 0)
            redis.call('HSET', key, 'confirmed_shopify', 0)
            pending_confirmations = 0
            new_available = math.max(0, erp_qty - total_unconfirmed)
        end
        
        -- Update hash
        redis.call('HSET', key, 'erp_quantity', erp_qty)
        redis.call('HSET', key, 'initial_erp_quantity', initial_erp)
        redis.call('HSET', key, 'available', new_available)
        
        table.insert(results, {
            key = key,
            success = true,
            available = new_available,
            initial_erp_quantity = initial_erp,
            pending_confirmations = pending_confirmations,
            total_unconfirmed = total_unconfirmed
        })
    else
        table.insert(results, {
            key = key,
            success = false,
            reason = "invalid_quantity"
        })
    end
end

return cjson.encode(results)
"""

# GET_KIT_AVAILABILITY_SCRIPT
# Atomically reads all component availabilities and computes kit availability.
# Formula: min(floor(component_available / required_qty)) for all components
#
# KEYS = list of component keys (inv:{warehouse_id}:{child_sku})
# ARGV = list of required quantities per kit (same order as KEYS)
#
# Returns: number of complete kits that can be assembled
GET_KIT_AVAILABILITY_SCRIPT = """
local min_kits = nil

for i, key in ipairs(KEYS) do
    local available = tonumber(redis.call('HGET', key, 'available') or '0')
    local required = tonumber(ARGV[i])
    
    if required and required > 0 then
        local kits_from_this = math.floor(available / required)
        if min_kits == nil or kits_from_this < min_kits then
            min_kits = kits_from_this
        end
    end
end

if min_kits == nil then
    return 0
end
return min_kits
"""

# RESERVE_KIT_SCRIPT
# Atomically reserves inventory for a kit by reserving all component SKUs.
# First checks availability of all components, then reserves all or none.
#
# KEYS = list of component keys (inv:{warehouse_id}:{child_sku})
# ARGV[1] = source ("medusa" or "shopify")
# ARGV[2..n] = quantities to reserve for each component (same order as KEYS)
#
# Returns: JSON with success status and component states
RESERVE_KIT_SCRIPT = """
local source = ARGV[1]
local reserved_key = 'reserved_' .. source
local num_components = #KEYS

-- Phase 1: Check all components have sufficient availability
local component_states = {}
for i, key in ipairs(KEYS) do
    local qty = tonumber(ARGV[i + 1])  -- +1 because ARGV[1] is source
    local available = tonumber(redis.call('HGET', key, 'available') or '0')
    
    if qty <= 0 then
        return cjson.encode({
            success = false,
            reason = "invalid_quantity",
            message = "Component quantity must be positive",
            component_index = i
        })
    end
    
    if available < qty then
        return cjson.encode({
            success = false,
            reason = "insufficient_stock",
            component_key = key,
            component_index = i,
            available = available,
            requested = qty,
            source = source
        })
    end
    
    table.insert(component_states, {
        key = key,
        qty = qty,
        available_before = available
    })
end

-- Phase 2: All checks passed, atomically reserve all components
local results = {}
for i, state in ipairs(component_states) do
    redis.call('HINCRBY', state.key, 'available', -state.qty)
    redis.call('HINCRBY', state.key, reserved_key, state.qty)
    
    local new_available = tonumber(redis.call('HGET', state.key, 'available'))
    local new_reserved = tonumber(redis.call('HGET', state.key, reserved_key))
    
    table.insert(results, {
        key = state.key,
        quantity_reserved = state.qty,
        available = new_available,
        reserved = new_reserved
    })
end

return cjson.encode({
    success = true,
    source = source,
    components_reserved = #results,
    components = results
})
"""

# RELEASE_KIT_SCRIPT
# Atomically releases reserved inventory for all components of a kit.
# Used for kit cancellation or fulfillment.
#
# KEYS = list of component keys (inv:{warehouse_id}:{child_sku})
# ARGV[1] = source ("medusa" or "shopify")
# ARGV[2] = reason ("fulfilled", "cancelled", "expired")
# ARGV[3..n] = quantities to release for each component (same order as KEYS)
#
# Returns: JSON with success status and component states
RELEASE_KIT_SCRIPT = """
local source = ARGV[1]
local reason = ARGV[2] or 'cancelled'
local reserved_key = 'reserved_' .. source
local confirmed_key = 'confirmed_' .. source

local results = {}
for i, key in ipairs(KEYS) do
    local qty = tonumber(ARGV[i + 2])  -- +2 because ARGV[1] is source, ARGV[2] is reason
    local current_reserved = tonumber(redis.call('HGET', key, reserved_key) or '0')
    local current_confirmed = tonumber(redis.call('HGET', key, confirmed_key) or '0')
    
    -- Can't release more than reserved
    local release_qty = math.min(qty, current_reserved)
    local confirmed_released = 0
    
    if release_qty > 0 then
        -- Always decrement reserved count
        redis.call('HINCRBY', key, reserved_key, -release_qty)
        
        -- Handle based on reason
        if reason == 'fulfilled' or reason == 'erp_handoff' then
            -- Fulfillment: items shipped out
            -- DON'T decrement confirmed - let ERP naturally reduce quantity
            -- DON'T decrement erp_quantity - ERP will send the updated value
            -- The reconciliation formula will handle it when ERP sends reduced qty
            confirmed_released = 0
        else
            -- Cancellation: item returns to available stock
            -- Decrement confirmed (order won't be processed by ERP)
            local confirmed_to_release = math.min(release_qty, current_confirmed)
            if confirmed_to_release > 0 then
                redis.call('HINCRBY', key, confirmed_key, -confirmed_to_release)
                confirmed_released = confirmed_to_release
            end
            -- Return items to available
            redis.call('HINCRBY', key, 'available', release_qty)
        end
    end
    
    local new_available = tonumber(redis.call('HGET', key, 'available'))
    local new_reserved = tonumber(redis.call('HGET', key, reserved_key))
    local new_confirmed = tonumber(redis.call('HGET', key, confirmed_key))
    
    table.insert(results, {
        key = key,
        released = release_qty,
        available = new_available,
        reserved = new_reserved,
        confirmed = new_confirmed,
        confirmed_released = confirmed_released
    })
end

return cjson.encode({
    success = true,
    source = source,
    reason = reason,
    components_released = #results,
    components = results
})
"""
