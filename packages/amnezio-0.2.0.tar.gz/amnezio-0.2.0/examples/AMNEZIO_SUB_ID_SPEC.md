# Amnezio API/SDK: операции по sub_id

Чтобы не хранить `user_id` в БД бота, в панели и SDK нужно поддержать либо получение user по sub_id, либо действия по sub_id.

## Вариант 1: один эндпоинт «получить user по sub_id»

**API:** `GET /api/users/by-sub-id/:sub_id` → 200 `{ "id": 123, "sub_id": "456", ... }` или 404.

**SDK:** `get_by_sub_id(sub_id: str) -> User | None`

Остальные методы остаются по `user_id`; бот один раз вызывает `get_by_sub_id(sub_id)`, берёт `user.id` и дальше работает по `user_id`.

## Вариант 2: действия напрямую по sub_id (удобнее для бота)

**API:**

| Метод | Путь | Тело/ответ |
|-------|------|-----------|
| GET | `/api/users/by-sub-id/:sub_id` | 200: user JSON, 404 |
| POST | `/api/users/by-sub-id/:sub_id/renew` | body: `{ "paid_for": "YYYY-MM-DD" }` |
| POST | `/api/users/by-sub-id/:sub_id/enable` | — |
| POST | `/api/users/by-sub-id/:sub_id/disable` | — |
| DELETE | `/api/users/by-sub-id/:sub_id` | — |
| GET | `/api/users/by-sub-id/:sub_id/config` | 200: WG config (text или JSON) |

**SDK (методы у `client.users`):**

- `get_by_sub_id(sub_id: str)` → user или None
- `renew_subscription_by_sub_id(sub_id: str, paid_for: date)`
- `enable_by_sub_id(sub_id: str)`
- `disable_by_sub_id(sub_id: str)`
- `delete_by_sub_id(sub_id: str)`
- `get_config_by_sub_id(sub_id: str)` → config

Тип `sub_id` в API — строка (в боте subid — int, передаём `str(subid)`).

Коннектор в этом репозитории уже рассчитан на вызов этих методов по sub_id с fallback на поиск через list и действия по user_id.
