"""Пример использования SDK с API токеном."""

import asyncio
from datetime import date, timedelta
from amnezio import AmnezioClient


async def main():
    """
    Пример работы с API через токен.
    
    API токен безопаснее, чем логин/пароль:
    - Можно отзывать отдельно
    - Можно задать срок действия
    - Лучший аудит
    """
    
    # Создание клиента с API токеном
    async with AmnezioClient(
        base_url="https://panel.codembo.ru",
        api_token="amz_xxxxxxxxxxxxxxxxxx"  # Получить в панели: API Токены → Создать
    ) as client:
        
        # 1. Генерация ключей для нового пользователя
        print("Генерация ключей...")
        keypair = await client.users.generate_keypair()
        print(f"Private key: {keypair.private_key[:20]}...")
        print(f"Public key: {keypair.public_key[:20]}...")
        
        # 2. Создание пользователя
        print("\nСоздание пользователя...")
        user = await client.users.create(
            sub_id="token_test_user",
            private_key=keypair.private_key,
            preshared_key=keypair.preshared_key,
            profile_id=6,
            paid_for=date.today() + timedelta(days=30),
            tag="api_token_test",
            description="Тестовый пользователь через API токен"
        )
        print(f"Создан пользователь: {user.id} ({user.sub_id})")
        print(f"Assigned IP: {user.assigned_ip}")
        
        # 3. Получение конфига
        print("\nПолучение конфига...")
        config = await client.users.get_config(user.id)
        print(f"Конфиг получен, размер: {len(config.config)} символов")
        
        # 4. Продление подписки
        print("\nПродление подписки...")
        new_date = date.today() + timedelta(days=60)
        user = await client.users.renew_subscription(user.id, new_date)
        print(f"Подписка продлена до: {user.paid_for}")
        
        # 5. Список пользователей
        print("\nСписок пользователей...")
        result = await client.users.list(page=1, per_page=5)
        print(f"Всего пользователей: {result.total}")
        for u in result.items[:3]:
            print(f"  - {u.id}: {u.sub_id} ({u.status})")
        
        # 6. Отключение пользователя
        print(f"\nОтключение пользователя {user.id}...")
        user = await client.users.disable(user.id)
        print(f"Статус: {user.status}")
        
        # 7. Удаление пользователя
        print(f"\nУдаление пользователя {user.id}...")
        result = await client.users.delete(user.id)
        print(f"Результат: {result}")
        
        print("\n✅ Все операции выполнены успешно!")


if __name__ == "__main__":
    asyncio.run(main())
