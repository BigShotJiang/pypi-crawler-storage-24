"""Пример: управление подписками."""

import asyncio
from datetime import date, timedelta
from amnezio import AmnezioClient


async def check_and_disable_expired_users():
    """Проверка и отключение пользователей с истекшей подпиской."""
    async with AmnezioClient(
        base_url="https://panel.example.com",
        username="admin",
        password="secret"
    ) as client:
        
        today = date.today()
        disabled_count = 0
        
        # Получаем всех пользователей постранично
        page = 1
        per_page = 100
        
        while True:
            result = await client.users.list(page=page, per_page=per_page)
            
            if not result.items:
                break
            
            for user in result.items:
                # Пропускаем уже отключенных
                if user.status == "disabled":
                    continue
                
                # Проверяем дату подписки
                if user.paid_for and user.paid_for < today:
                    print(f"Отключаем пользователя {user.sub_id} (истекла {user.paid_for})")
                    await client.users.disable(user.id)
                    disabled_count += 1
            
            # Следующая страница
            if page >= result.total_pages:
                break
            page += 1
        
        print(f"\nВсего отключено пользователей: {disabled_count}")


async def renew_user_subscription(user_id: int, days: int):
    """Продление подписки пользователя."""
    async with AmnezioClient(
        base_url="https://panel.example.com",
        username="admin",
        password="secret"
    ) as client:
        
        # Получаем текущего пользователя
        user = await client.users.get(user_id)
        
        # Вычисляем новую дату
        # Если подписка еще не истекла, продлеваем от текущей даты
        # Если истекла, продлеваем от сегодняшнего дня
        if user.paid_for and user.paid_for >= date.today():
            new_date = user.paid_for + timedelta(days=days)
        else:
            new_date = date.today() + timedelta(days=days)
        
        # Продлеваем подписку и включаем пользователя
        user = await client.users.renew_subscription(user_id, new_date)
        
        print(f"Подписка продлена до {user.paid_for}")
        print(f"Статус: {user.status}")
        
        return user


async def main():
    # Пример 1: Отключение истекших подписок
    print("=== Проверка истекших подписок ===")
    await check_and_disable_expired_users()
    
    # Пример 2: Продление подписки
    print("\n=== Продление подписки ===")
    user_id = 1
    await renew_user_subscription(user_id, days=30)


if __name__ == "__main__":
    asyncio.run(main())
