"""Пример: создание пользователя через Telegram ID."""

import asyncio
from datetime import date, timedelta
from amnezio import AmnezioClient


async def create_telegram_user(telegram_id: int, profile_id: int, days: int = 30):
    """
    Создание пользователя по Telegram ID.
    
    Args:
        telegram_id: ID пользователя в Telegram
        profile_id: ID профиля
        days: Количество дней подписки
    
    Returns:
        Данные созданного пользователя
    """
    async with AmnezioClient(
        base_url="https://panel.example.com",
        username="admin",
        password="secret"
    ) as client:
        
        # Генерация ключей
        keypair = await client.users.generate_keypair()
        
        # Создание пользователя
        user = await client.users.create(
            sub_id=f"tg_{telegram_id}",
            private_key=keypair.private_key,
            preshared_key=keypair.preshared_key,
            telegram_id=telegram_id,
            profile_id=profile_id,
            paid_for=date.today() + timedelta(days=days),
            tag="telegram",
            description=f"User from Telegram: {telegram_id}"
        )
        
        # Получение конфига
        config = await client.users.get_config(user.id)
        
        return {
            "user_id": user.id,
            "sub_id": user.sub_id,
            "assigned_ip": user.assigned_ip,
            "paid_for": user.paid_for,
            "config": config.config,
        }


async def main():
    telegram_id = 123456789
    profile_id = 1
    
    result = await create_telegram_user(telegram_id, profile_id, days=30)
    
    print(f"Создан пользователь: {result['sub_id']}")
    print(f"User ID: {result['user_id']}")
    print(f"IP адрес: {result['assigned_ip']}")
    print(f"Подписка до: {result['paid_for']}")
    print(f"\nКонфиг:\n{result['config']}")


if __name__ == "__main__":
    asyncio.run(main())
