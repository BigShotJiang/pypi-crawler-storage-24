"""Примеры использования Amnezio SDK."""

import asyncio
from datetime import date, timedelta
from amnezio import AmnezioClient


async def main():
    # Создание клиента
    async with AmnezioClient(
        base_url="https://panel.example.com",
        username="admin",
        password="secret"
    ) as client:
        
        # 1. Генерация ключей для нового пользователя
        print("Генерация ключей...")
        keypair = await client.users.generate_keypair()
        print(f"Private key: {keypair.private_key}")
        print(f"Public key: {keypair.public_key}")
        print(f"Preshared key: {keypair.preshared_key}")
        
        # 2. Создание пользователя
        print("\nСоздание пользователя...")
        user = await client.users.create(
            sub_id="user123",
            private_key=keypair.private_key,
            preshared_key=keypair.preshared_key,
            profile_id=1,
            paid_for=date.today() + timedelta(days=30),
            tag="telegram",
            description="Тестовый пользователь"
        )
        print(f"Создан пользователь: {user.id} ({user.sub_id})")
        print(f"Assigned IP: {user.assigned_ip}")
        
        # 3. Получение пользователя
        print("\nПолучение пользователя...")
        user = await client.users.get(user.id)
        print(f"Статус: {user.status}")
        print(f"Подписка до: {user.paid_for}")
        
        # 4. Получение конфига
        print("\nПолучение конфига...")
        config = await client.users.get_config(user.id)
        print(config.config)
        
        # 5. Получение QR-кода
        print("\nПолучение QR-кода...")
        qrcode = await client.users.get_qrcode(user.id)
        with open(f"user_{user.id}_qrcode.png", "wb") as f:
            f.write(qrcode)
        print(f"QR-код сохранен в user_{user.id}_qrcode.png")
        
        # 6. Список пользователей
        print("\nСписок пользователей...")
        result = await client.users.list(page=1, per_page=10)
        print(f"Всего пользователей: {result.total}")
        for u in result.items:
            print(f"  - {u.id}: {u.sub_id} ({u.status})")
        
        # 7. Продление подписки
        print("\nПродление подписки...")
        new_date = date.today() + timedelta(days=60)
        user = await client.users.renew_subscription(user.id, new_date)
        print(f"Подписка продлена до: {user.paid_for}")
        
        # 8. Отключение пользователя
        print("\nОтключение пользователя...")
        user = await client.users.disable(user.id)
        print(f"Статус: {user.status}")
        
        # 9. Включение пользователя
        print("\nВключение пользователя...")
        user = await client.users.enable(user.id)
        print(f"Статус: {user.status}")
        
        # 10. Работа с профилями
        print("\nСписок профилей...")
        profiles = await client.profiles.list()
        for p in profiles:
            print(f"  - {p.id}: {p.name} (порт {p.listen_port})")
        
        # 11. Работа с нодами
        print("\nСписок нод...")
        nodes = await client.nodes.list()
        for n in nodes:
            print(f"  - {n.id}: {n.name} ({n.host}:{n.node_port}) - {n.status}")
            print(f"    Онлайн: {n.peers_online}")
        
        # 12. Синхронизация ноды
        if nodes:
            print(f"\nСинхронизация ноды {nodes[0].id}...")
            result = await client.nodes.sync(nodes[0].id)
            print(f"Config hash: {result.get('config_hash')}")
            print(f"Node version: {result.get('node_version')}")
        
        # 13. Push конфига на ноду
        if nodes:
            print(f"\nPush конфига на ноду {nodes[0].id}...")
            result = await client.nodes.push_config(nodes[0].id)
            print(f"Статус: {result.get('status')}")
        
        # 14. Удаление пользователя
        print(f"\nУдаление пользователя {user.id}...")
        result = await client.users.delete(user.id)
        print(f"Результат: {result}")


if __name__ == "__main__":
    asyncio.run(main())
