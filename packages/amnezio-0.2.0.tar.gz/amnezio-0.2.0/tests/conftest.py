"""Базовые конфигурационные файлы для тестов."""

import pytest
from unittest.mock import AsyncMock, MagicMock
import httpx


@pytest.fixture
def mock_httpx_client():
    """Mock для httpx.AsyncClient."""
    client = AsyncMock(spec=httpx.AsyncClient)
    return client


@pytest.fixture
def mock_response():
    """Создает mock для httpx.Response."""
    def _create_response(status_code=200, json_data=None):
        response = MagicMock(spec=httpx.Response)
        response.status_code = status_code
        response.json.return_value = json_data or {}
        response.text = str(json_data) if json_data else ""
        response.content = b""
        return response
    return _create_response
