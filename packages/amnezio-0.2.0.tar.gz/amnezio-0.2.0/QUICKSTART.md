# Amnezio SDK - Быстрый старт

## Установка

```bash
cd amnezio
pip install -e .
```

## 5-минутный старт

### 1. Создание клиента

```python
from amnezio import AmnezioClient

client = AmnezioClient(
    base_url="https://panel.example.com",
    username="admin",
    password="secret"
)
```

### 2. Создание пользователя

```python
# Генерация ключей
keypair = await client.users.generate_keypair()

# Создание пользователя
user = await client.users.create(
    sub_id="user123",
    private_key=keypair.private_key,
    preshared_key=keypair.preshared_key,
    profile_id=1,
    paid_for=date(2027, 12, 31)
)

print(f"Создан пользователь: {user.id}")
print(f"IP адрес: {user.assigned_ip}")
```

### 3. Получение конфига

```python
# Текстовый конфиг
config = await client.users.get_config(user.id)
print(config.config)

# QR-код
qrcode = await client.users.get_qrcode(user.id)
with open("qrcode.png", "wb") as f:
    f.write(qrcode)
```

### 4. Управление подпиской

```python
# Продление подписки
user = await client.users.renew_subscription(
    user.id, 
    paid_for=date(2028, 12, 31)
)

# Отключение
user = await client.users.disable(user.id)

# Включение
user = await client.users.enable(user.id)
```

## Полный пример

```python
import asyncio
from datetime import date, timedelta
from amnezio import AmnezioClient

async def main():
    async with AmnezioClient(
        base_url="https://panel.example.com",
        username="admin",
        password="secret"
    ) as client:
        
        # 1. Генерируем ключи
        keypair = await client.users.generate_keypair()
        
        # 2. Создаем пользователя
        user = await client.users.create(
            sub_id="user123",
            private_key=keypair.private_key,
            preshared_key=keypair.preshared_key,
            profile_id=1,
            paid_for=date.today() + timedelta(days=30)
        )
        
        # 3. Получаем конфиг
        config = await client.users.get_config(user.id)
        print(config.config)
        
        # 4. Получаем QR-код
        qrcode = await client.users.get_qrcode(user.id)
        with open(f"user_{user.id}.png", "wb") as f:
            f.write(qrcode)

if __name__ == "__main__":
    asyncio.run(main())
```

## Telegram бот (aiogram 3.x)

```python
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from amnezio import AmnezioClient

bot = Bot(token="YOUR_TOKEN")
dp = Dispatcher()

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    async with AmnezioClient(
        base_url="https://panel.example.com",
        username="admin",
        password="secret"
    ) as client:
        # Генерируем ключи
        keypair = await client.users.generate_keypair()
        
        # Создаем пользователя
        user = await client.users.create(
            sub_id=f"tg_{message.from_user.id}",
            telegram_id=message.from_user.id,
            private_key=keypair.private_key,
            preshared_key=keypair.preshared_key,
            profile_id=1,
            paid_for=date.today() + timedelta(days=30)
        )
        
        # Получаем конфиг
        config = await client.users.get_config(user.id)
        
        # Отправляем файл
        config_file = types.BufferedInputFile(
            config.config.encode(),
            filename="amneziawg.conf"
        )
        await message.answer_document(config_file)
        
        # Отправляем QR-код
        qrcode = await client.users.get_qrcode(user.id)
        qr_file = types.BufferedInputFile(qrcode, filename="qrcode.png")
        await message.answer_photo(qr_file)

if __name__ == "__main__":
    asyncio.run(dp.start_polling(bot))
```

## Обработка ошибок

```python
from amnezio.exceptions import NotFoundError, APIError

try:
    user = await client.users.get(999)
except NotFoundError:
    print("Пользователь не найден")
except APIError as e:
    print(f"Ошибка API: {e.status_code} - {e.message}")
```

## Тестирование

```bash
# CLI утилита
./test_sdk.py --url https://panel.example.com --username admin --password secret

# Запуск тестов
pytest

# С покрытием
pytest --cov=amnezio
```

## Документация

- `README.md` - Основная документация
- `INSTALL.md` - Детальная установка и API
- `STRUCTURE.md` - Архитектура проекта
- `examples/` - Примеры кода
- `CHANGELOG.md` - История изменений

## Поддержка

- GitHub Issues: https://github.com/amnezio/amnezio/issues
- Документация: https://github.com/amnezio/amnezio#readme
