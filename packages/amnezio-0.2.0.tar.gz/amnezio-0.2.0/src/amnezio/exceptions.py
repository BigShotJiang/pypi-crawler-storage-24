"""Исключения SDK."""


class AmnezioError(Exception):
    """Базовое исключение SDK."""
    pass


class AuthenticationError(AmnezioError):
    """Ошибка аутентификации."""
    pass


class NotFoundError(AmnezioError):
    """Ресурс не найден."""
    pass


class APIError(AmnezioError):
    """Ошибка API."""
    
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"API Error {status_code}: {message}")
