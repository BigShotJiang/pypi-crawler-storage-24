"""Type hints для Amnezio SDK."""

from typing import TypeVar, Union, Dict, List, Optional
from datetime import date, datetime

# Generic типы
T = TypeVar('T')

# Типы для API ответов
JSONDict = Dict[str, any]
JSONList = List[JSONDict]

# Типы для дат
DateType = Union[date, str]
DateTimeType = Union[datetime, str]

# Типы для статусов
UserStatus = Union["active", "disabled"]
NodeStatus = Union["online", "offline", "unknown"]

__all__ = [
    "T",
    "JSONDict",
    "JSONList",
    "DateType",
    "DateTimeType",
    "UserStatus",
    "NodeStatus",
]
