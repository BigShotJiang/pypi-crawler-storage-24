# specfence

A proof-of-concept implementation of Specification Fencing (essay coming soon).

## Demo

`example/fizzbuzz.py` contains a simple implementation of FizzBuzz, but with scattered `print` and logging statements that do not change any observed behavior as defined by `example/fizzbuzz_test.py`. Running `specfence` on this file identifies these lines as specification fencing violations, and suggests deleting them.

```bash
$ uvx specfence example/fizzbuzz.py example/fizzbuzz_test.py
 8| print("FizzBuzz!")
11| logger.info("Divisible by 3")
14| logger.info("Divisible by 5")
17| print("Returning number")

4 specification fencing violations found. Delete these lines as they do not change any observed behavior.
```
