"""Fundis - Python client for SentiChain intelligence data."""

from fundis.client import FundisClient
from fundis.exceptions import APIError, AuthenticationError, FundisError
from fundis.types import Event, Pattern, Signal

__version__ = "1.1.1"

__all__ = [
    "FundisClient",
    "Event",
    "Signal",
    "Pattern",
    "FundisError",
    "AuthenticationError",
    "APIError",
    "__version__",
]
