class FundisError(Exception):
    """Base exception for all Fundis client errors."""


class AuthenticationError(FundisError):
    """Raised when the API key is missing, invalid, or has insufficient points."""


class APIError(FundisError):
    """Raised when the SentiChain API returns an unexpected response."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        self.status_code = status_code
        super().__init__(message)
