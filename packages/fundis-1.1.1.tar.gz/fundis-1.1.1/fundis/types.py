from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Event:
    """A single classified sentiment event from the Fundis pipeline."""

    timestamp: str
    type: str
    sentiment: str
    summary: str
    is_pattern: bool = False
    pattern_keywords: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class Pattern:
    """A group of converging events sharing common keywords."""

    keywords: list[str]
    event_indices: list[int]
    description: str = ""


@dataclass(frozen=True)
class Signal:
    """Directional signal from the Fundis intelligence pipeline."""

    direction: str
    confidence: float
    rationale: str
    categories: dict[str, str | None] = field(default_factory=dict)
    patterns: list[Pattern] = field(default_factory=list)
    bullish_count: int = 0
    bearish_count: int = 0
    total_count: int = 0
