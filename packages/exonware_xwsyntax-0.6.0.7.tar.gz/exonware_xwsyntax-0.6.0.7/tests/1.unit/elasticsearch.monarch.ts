// elasticsearch.monarch.ts
// Auto-generated Monaco language definition
export const elasticsearchLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".elasticsearch",
  "operators": [
    "\n\n// Aggregation\naggregation_query: ",
    "\n\n// Bool query\nbool_query: ",
    "\n\n// Exists query\nexists_query: ",
    "\n\n// Nested query\nnested_query: ",
    "\n\n// Range query\nrange_query: ",
    "\n\n// Terminals\nIDENTIFIER: /[a-zA-Z_][a-zA-Z0-9_]*/\nSTRING: /",
    "\n\n// Wildcard query\nwildcard_query: ",
    "\n\nNULL: ",
    "\n\nagg_definition: STRING ",
    "\n\nagg_param: STRING ",
    "\n\nagg_params: ",
    "\n\nagg_type: ",
    "\n\nbool_clauses: bool_clause (",
    "\n\nfield_match: STRING ",
    "\n\nfield_value: STRING ",
    "\n\nfuzzy_options: fuzzy_option (",
    "\n\nmatch_options: match_option (",
    "\n\nmatch_query: ",
    "\n\nmulti_match_params: ",
    "\n\nquery_string_options: query_string_option (",
    "\n\nrange_condition: range_op ",
    "\n           | query\n\n// Multi-match query\nmulti_match_query: ",
    "\n        | ",
    " (",
    " (STRING | NUMBER)\n            | ",
    " (STRING | match_params)\n\nmatch_params: ",
    " NUMBER\n\n// Prefix query\nprefix_query: ",
    " NUMBER\n\nquery_array: ",
    " NUMBER\n            | ",
    " STRING\n\n// Fuzzy query\nfuzzy_query: ",
    " STRING\n\n// Term queries\nterm_query: ",
    " STRING\n                   | ",
    " STRING ",
    " STRING (",
    " STRING [",
    " STRING)* ",
    " [",
    " agg_definition (",
    " agg_definition)* ",
    " agg_param (",
    " agg_param)* ",
    " agg_params ",
    " agg_type ",
    " bool_clause)*\n\nbool_clause: ",
    " bool_clauses ",
    " field_match ",
    " field_value ",
    " fuzzy_option)*\n\nfuzzy_option: ",
    " fuzzy_options] ",
    " match_option)*\n\nmatch_option: ",
    " match_options]\n\n// Query string\nquery_string_query: ",
    " match_options] ",
    " multi_match_params ",
    " query ",
    " query (",
    " query)* ",
    " query_array\n           | ",
    " query_string_option)*\n\nquery_string_option: ",
    " query_string_options] ",
    " range_condition (",
    " range_condition)* ",
    " value\n\n// Values\nvalue: STRING | NUMBER | BOOLEAN_LITERAL | NULL\n\nBOOLEAN_LITERAL: ",
    " value\n\nrange_op: ",
    " value\n\nterms_query: ",
    " value (",
    " value)* ",
    " | ",
    ")\n                   | ",
    ")\n            | ",
    "AND\\",
    "OR\\",
    "\\",
    "]*",
    "aggs\\",
    "analyzer\\",
    "and\\",
    "avg\\",
    "bool\\",
    "cardinality\\",
    "date_histogram\\",
    "default_field\\",
    "default_operator\\",
    "exists\\",
    "field\\",
    "fields\\",
    "filter\\",
    "fuzziness\\",
    "fuzzy\\",
    "gt\\",
    "gte\\",
    "histogram\\",
    "lt\\",
    "lte\\",
    "match\\",
    "max\\",
    "min\\",
    "minimum_should_match\\",
    "multi_match\\",
    "must\\",
    "must_not\\",
    "nested\\",
    "operator\\",
    "or\\",
    "path\\",
    "prefix\\",
    "prefix_length\\",
    "query\\",
    "query_string\\",
    "range\\",
    "should\\",
    "stats\\",
    "sum\\",
    "term\\",
    "terms\\",
    "value\\",
    "wildcard\\",
    "{"
  ],
  "symbols": "\\ field_match\\ |\\ value\\\n\\\nrange_op:\\ |\\ agg_param\\)\\*\\ |\\ \\(STRING\\ \\|\\ NUMBER\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\ agg_definition\\)\\*\\ |\\]\\*|cardinality\\\\|field\\\\|\\\n\\\n//\\ Bool\\ query\\\nbool_query:\\ |AND\\\\|\\\n\\\n//\\ Aggregation\\\naggregation_query:\\ |\\\n\\\n//\\ Nested\\ query\\\nnested_query:\\ |\\ value\\)\\*\\ |nested\\\\|min\\\\|and\\\\|max\\\\|path\\\\|\\ value\\ \\(|\\ query_string_option\\)\\*\\\n\\\nquery_string_option:\\ |\\\n\\\n//\\ Exists\\ query\\\nexists_query:\\ |aggs\\\\|wildcard\\\\|stats\\\\|must\\\\|\\ STRING\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\{|match\\\\|\\ STRING\\\n\\\n//\\ Fuzzy\\ query\\\nfuzzy_query:\\ |\\ query\\ \\(|\\\n\\\nfield_match:\\ STRING\\ |lt\\\\|\\ NUMBER\\\n\\\nquery_array:\\ |\\ NUMBER\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |query_string\\\\|\\ \\|\\ |\\ NUMBER\\\n\\\n//\\ Prefix\\ query\\\nprefix_query:\\ |sum\\\\|\\ STRING\\\n\\\n//\\ Term\\ queries\\\nterm_query:\\ |\\ agg_type\\ |default_operator\\\\|\\ multi_match_params\\ |\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |query\\\\|\\ match_options\\]\\\n\\\n//\\ Query\\ string\\\nquery_string_query:\\ |\\ value\\\n\\\nterms_query:\\ |histogram\\\\|\\\n\\\nquery_string_options:\\ query_string_option\\ \\(|\\ fuzzy_options\\]\\ |range\\\\|\\\n\\\nagg_params:\\ |must_not\\\\|value\\\\|\\\n\\\nmatch_options:\\ match_option\\ \\(|bool\\\\|\\\n\\\nagg_param:\\ STRING\\ |\\ STRING\\ \\[|prefix_length\\\\|date_histogram\\\\|\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\ query_string_options\\]\\ |fuzzy\\\\|\\ STRING\\ |gte\\\\|default_field\\\\|or\\\\|\\ match_options\\]\\ |term\\\\|\\ range_condition\\)\\*\\ |\\\n\\\nfuzzy_options:\\ fuzzy_option\\ \\(|\\\n\\\nmatch_query:\\ |exists\\\\|\\\n\\\n//\\ Terminals\\\nIDENTIFIER:\\ /\\[a\\-zA\\-Z_\\]\\[a\\-zA\\-Z0\\-9_\\]\\*/\\\nSTRING:\\ /|\\ bool_clauses\\ |\\ bool_clause\\)\\*\\\n\\\nbool_clause:\\ |\\\n\\\nmulti_match_params:\\ |\\ \\(|\\ fuzzy_option\\)\\*\\\n\\\nfuzzy_option:\\ |\\ agg_param\\ \\(|\\ query_array\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |multi_match\\\\|\\\n\\\n//\\ Range\\ query\\\nrange_query:\\ |lte\\\\|\\ query\\)\\*\\ |gt\\\\|\\ range_condition\\ \\(|\\ value\\\n\\\n//\\ Values\\\nvalue:\\ STRING\\ \\|\\ NUMBER\\ \\|\\ BOOLEAN_LITERAL\\ \\|\\ NULL\\\n\\\nBOOLEAN_LITERAL:\\ |fuzziness\\\\|filter\\\\|analyzer\\\\|terms\\\\|operator\\\\|\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ query\\\n\\\n//\\ Multi\\-match\\ query\\\nmulti_match_query:\\ |\\ STRING\\ \\(|\\ query\\ |\\ \\[|\\ agg_definition\\ \\(|\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\ \\(STRING\\ \\|\\ match_params\\)\\\n\\\nmatch_params:\\ |\\ STRING\\)\\*\\ |OR\\\\|\\\n\\\nNULL:\\ |should\\\\|\\\\|\\ match_option\\)\\*\\\n\\\nmatch_option:\\ |\\ field_value\\ |prefix\\\\|\\\n\\\nrange_condition:\\ range_op\\ |avg\\\\|\\\n\\\nagg_type:\\ |\\\n\\\nagg_definition:\\ STRING\\ |fields\\\\|\\\n\\\nfield_value:\\ STRING\\ |\\ agg_params\\ |minimum_should_match\\\\|\\\n\\\nbool_clauses:\\ bool_clause\\ \\(|\\\n\\\n//\\ Wildcard\\ query\\\nwildcard_query:\\ ",
  "brackets": [
    {
      "open": "{",
      "close": "}",
      "token": "delimiter.curly"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/\\ value\\\n\\\n//\\ Values\\\nvalue:\\ STRING\\ \\|\\ NUMBER\\ \\|\\ BOOLEAN_LITERAL\\ \\|\\ NULL\\\n\\\nBOOLEAN_LITERAL:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Terminals\\\nIDENTIFIER:\\ /\\[a\\-zA\\-Z_\\]\\[a\\-zA\\-Z0\\-9_\\]\\*/\\\nSTRING:\\ //",
        "operator"
      ],
      [
        "/\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ query\\\n\\\n//\\ Multi\\-match\\ query\\\nmulti_match_query:\\ /",
        "operator"
      ],
      [
        "/\\ match_options\\]\\\n\\\n//\\ Query\\ string\\\nquery_string_query:\\ /",
        "operator"
      ],
      [
        "/\\ query_string_option\\)\\*\\\n\\\nquery_string_option:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nquery_string_options:\\ query_string_option\\ \\(/",
        "operator"
      ],
      [
        "/\\ \\(STRING\\ \\|\\ match_params\\)\\\n\\\nmatch_params:\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\\n//\\ Prefix\\ query\\\nprefix_query:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\\n//\\ Fuzzy\\ query\\\nfuzzy_query:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\\n//\\ Term\\ queries\\\nterm_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Aggregation\\\naggregation_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Wildcard\\ query\\\nwildcard_query:\\ /",
        "operator"
      ],
      [
        "/\\ \\(STRING\\ \\|\\ NUMBER\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Nested\\ query\\\nnested_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Exists\\ query\\\nexists_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nmatch_options:\\ match_option\\ \\(/",
        "operator"
      ],
      [
        "/\\\n\\\nfuzzy_options:\\ fuzzy_option\\ \\(/",
        "operator"
      ],
      [
        "/\\ fuzzy_option\\)\\*\\\n\\\nfuzzy_option:\\ /",
        "operator"
      ],
      [
        "/\\ match_option\\)\\*\\\n\\\nmatch_option:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Range\\ query\\\nrange_query:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ bool_clause\\)\\*\\\n\\\nbool_clause:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nbool_clauses:\\ bool_clause\\ \\(/",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Bool\\ query\\\nbool_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nrange_condition:\\ range_op\\ /",
        "operator"
      ],
      [
        "/\\ query_array\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_definition:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ query_string_options\\]\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfield_match:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\\nquery_array:\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nmulti_match_params:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfield_value:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ value\\\n\\\nterms_query:\\ /",
        "operator"
      ],
      [
        "/minimum_should_match\\\\/",
        "operator"
      ],
      [
        "/\\ multi_match_params\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_param:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ range_condition\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ value\\\n\\\nrange_op:\\ /",
        "operator"
      ],
      [
        "/\\ agg_definition\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ range_condition\\ \\(/",
        "operator"
      ],
      [
        "/default_operator\\\\/",
        "operator"
      ],
      [
        "/\\ agg_definition\\ \\(/",
        "operator"
      ],
      [
        "/\\ fuzzy_options\\]\\ /",
        "operator"
      ],
      [
        "/\\ match_options\\]\\ /",
        "operator"
      ],
      [
        "/\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/date_histogram\\\\/",
        "operator"
      ],
      [
        "/\\\n\\\nmatch_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_params:\\ /",
        "operator"
      ],
      [
        "/prefix_length\\\\/",
        "operator"
      ],
      [
        "/default_field\\\\/",
        "operator"
      ],
      [
        "/\\ bool_clauses\\ /",
        "operator"
      ],
      [
        "/\\ field_match\\ /",
        "operator"
      ],
      [
        "/\\ agg_param\\)\\*\\ /",
        "operator"
      ],
      [
        "/query_string\\\\/",
        "operator"
      ],
      [
        "/\\ field_value\\ /",
        "operator"
      ],
      [
        "/cardinality\\\\/",
        "operator"
      ],
      [
        "/\\ agg_param\\ \\(/",
        "operator"
      ],
      [
        "/multi_match\\\\/",
        "operator"
      ],
      [
        "/\\\n\\\nagg_type:\\ /",
        "operator"
      ],
      [
        "/\\ agg_params\\ /",
        "operator"
      ],
      [
        "/\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ agg_type\\ /",
        "operator"
      ],
      [
        "/histogram\\\\/",
        "operator"
      ],
      [
        "/fuzziness\\\\/",
        "operator"
      ],
      [
        "/\\ STRING\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ value\\)\\*\\ /",
        "operator"
      ],
      [
        "/wildcard\\\\/",
        "operator"
      ],
      [
        "/must_not\\\\/",
        "operator"
      ],
      [
        "/\\ STRING\\ \\[/",
        "operator"
      ],
      [
        "/\\ query\\)\\*\\ /",
        "operator"
      ],
      [
        "/analyzer\\\\/",
        "operator"
      ],
      [
        "/operator\\\\/",
        "operator"
      ],
      [
        "/\\ STRING\\ \\(/",
        "operator"
      ],
      [
        "/\\ value\\ \\(/",
        "operator"
      ],
      [
        "/\\ query\\ \\(/",
        "operator"
      ],
      [
        "/\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nNULL:\\ /",
        "operator"
      ],
      [
        "/nested\\\\/",
        "operator"
      ],
      [
        "/exists\\\\/",
        "operator"
      ],
      [
        "/filter\\\\/",
        "operator"
      ],
      [
        "/\\ query\\ /",
        "operator"
      ],
      [
        "/should\\\\/",
        "operator"
      ],
      [
        "/prefix\\\\/",
        "operator"
      ],
      [
        "/fields\\\\/",
        "operator"
      ],
      [
        "/field\\\\/",
        "operator"
      ],
      [
        "/stats\\\\/",
        "operator"
      ],
      [
        "/match\\\\/",
        "operator"
      ],
      [
        "/query\\\\/",
        "operator"
      ],
      [
        "/range\\\\/",
        "operator"
      ],
      [
        "/value\\\\/",
        "operator"
      ],
      [
        "/fuzzy\\\\/",
        "operator"
      ],
      [
        "/terms\\\\/",
        "operator"
      ],
      [
        "/path\\\\/",
        "operator"
      ],
      [
        "/aggs\\\\/",
        "operator"
      ],
      [
        "/must\\\\/",
        "operator"
      ],
      [
        "/bool\\\\/",
        "operator"
      ],
      [
        "/term\\\\/",
        "operator"
      ],
      [
        "/AND\\\\/",
        "operator"
      ],
      [
        "/min\\\\/",
        "operator"
      ],
      [
        "/and\\\\/",
        "operator"
      ],
      [
        "/max\\\\/",
        "operator"
      ],
      [
        "/sum\\\\/",
        "operator"
      ],
      [
        "/gte\\\\/",
        "operator"
      ],
      [
        "/lte\\\\/",
        "operator"
      ],
      [
        "/avg\\\\/",
        "operator"
      ],
      [
        "/lt\\\\/",
        "operator"
      ],
      [
        "/\\ \\|\\ /",
        "operator"
      ],
      [
        "/or\\\\/",
        "operator"
      ],
      [
        "/gt\\\\/",
        "operator"
      ],
      [
        "/OR\\\\/",
        "operator"
      ],
      [
        "/\\]\\*/",
        "operator"
      ],
      [
        "/\\ \\(/",
        "operator"
      ],
      [
        "/\\ \\[/",
        "operator"
      ],
      [
        "/\\{/",
        "operator"
      ],
      [
        "/\\\\/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const elasticsearchLanguageConfig = {
  "brackets": [
    [
      "{",
      "}"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "{",
      "close": "}"
    }
  ],
  "surroundingPairs": [
    {
      "open": "{",
      "close": "}"
    }
  ]
};
// Register with Monaco Editor
export function registerElasticsearchLanguage(monaco: any) {
  monaco.languages.register({ id: 'elasticsearch' });
  monaco.languages.setMonarchTokensProvider('elasticsearch', elasticsearchLanguage);
  monaco.languages.setLanguageConfiguration('elasticsearch', elasticsearchLanguageConfig);
}
