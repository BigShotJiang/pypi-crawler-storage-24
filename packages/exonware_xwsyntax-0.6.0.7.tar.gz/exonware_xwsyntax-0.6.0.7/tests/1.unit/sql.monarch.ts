// sql.monarch.ts
// Auto-generated Monaco language definition
export const sqlLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".sql",
  "ignoreCase": true,
  "keywords": [
    "ALL",
    "BLOB",
    "BOOL",
    "BOOLEAN",
    "CHAR",
    "CROSS",
    "DATE",
    "DATETIME",
    "DECIMAL",
    "DISTINCT",
    "DOUBLE",
    "FLOAT",
    "FULL",
    "INNER",
    "INT",
    "INTEGER",
    "LEFT",
    "NUMERIC",
    "RIGHT",
    "TEXT",
    "TIME",
    "TIMESTAMP",
    "TOP",
    "VARCHAR"
  ],
  "operators": [
    "!=",
    "%",
    "(",
    ")",
    "*",
    "+",
    ",",
    "-",
    ".",
    "/",
    "/\n\n// Keywords (case-insensitive)\nSELECT: ",
    "<",
    "<=",
    "<>",
    "=",
    ">",
    ">=",
    "[^",
    "]+",
    "i\n\n// Terminals\nQUOTED_IDENTIFIER: /`[^`]+`/ | /\\[[^\\]]+\\]/ | /",
    "i\nADD: ",
    "i\nALTER: ",
    "i\nAND: ",
    "i\nAS: ",
    "i\nASC: ",
    "i\nBETWEEN: ",
    "i\nBOOLEAN: ",
    "i\nBY: ",
    "i\nCHECK: ",
    "i\nCOLUMN: ",
    "i\nCREATE: ",
    "i\nDATABASE: ",
    "i\nDELETE: ",
    "i\nDESC: ",
    "i\nDROP: ",
    "i\nFOREIGN_KEY: ",
    "i\nFROM: ",
    "i\nGROUP: ",
    "i\nHAVING: ",
    "i\nIN: ",
    "i\nINDEX: ",
    "i\nINSERT: ",
    "i\nINTO: ",
    "i\nIS: ",
    "i\nJOIN: ",
    "i\nLIKE: ",
    "i\nLIMIT: ",
    "i\nMODIFY: ",
    "i\nNOT: ",
    "i\nNOT_NULL: ",
    "i\nNULL: ",
    "i\nOFFSET: ",
    "i\nON: ",
    "i\nOR: ",
    "i\nORDER: ",
    "i\nPRIMARY_KEY: ",
    "i\nSET: ",
    "i\nTABLE: ",
    "i\nUNIQUE: ",
    "i\nUPDATE: ",
    "i\nVALUES: ",
    "i\nVIEW: ",
    "i\nWHERE: ",
    "i ",
    "i | "
  ],
  "symbols": "i\\\nNULL:\\ |\\)|\\[\\^|i\\\nDROP:\\ |i\\\nGROUP:\\ |i\\\nCREATE:\\ |>=|=|i\\\nON:\\ |i\\\nIN:\\ |i\\\nSET:\\ |i\\\nBETWEEN:\\ |i\\\nBY:\\ |i\\\nALTER:\\ |<=|i\\ |i\\\n\\\n//\\ Terminals\\\nQUOTED_IDENTIFIER:\\ /`\\[\\^`\\]\\+`/\\ \\|\\ /\\\\\\[\\[\\^\\\\\\]\\]\\+\\\\\\]/\\ \\|\\ /|>|i\\\nVALUES:\\ |i\\\nLIKE:\\ |i\\\nOFFSET:\\ |\\.|i\\\nVIEW:\\ |i\\\nHAVING:\\ |i\\ \\|\\ |i\\\nAND:\\ |i\\\nNOT_NULL:\\ |%|i\\\nOR:\\ |/\\\n\\\n//\\ Keywords\\ \\(case\\-insensitive\\)\\\nSELECT:\\ |i\\\nDATABASE:\\ |i\\\nUNIQUE:\\ |i\\\nCHECK:\\ |i\\\nLIMIT:\\ |i\\\nDESC:\\ |i\\\nJOIN:\\ |i\\\nMODIFY:\\ |i\\\nBOOLEAN:\\ |\\*|i\\\nFROM:\\ |\\-|<>|\\(|i\\\nUPDATE:\\ |i\\\nWHERE:\\ |i\\\nORDER:\\ |i\\\nFOREIGN_KEY:\\ |i\\\nINSERT:\\ |i\\\nTABLE:\\ |i\\\nAS:\\ |i\\\nCOLUMN:\\ |i\\\nADD:\\ |i\\\nASC:\\ |/|,|<|i\\\nINDEX:\\ |i\\\nDELETE:\\ |!=|i\\\nPRIMARY_KEY:\\ |\\+|\\]\\+|i\\\nNOT:\\ |i\\\nIS:\\ |i\\\nINTO:\\ ",
  "brackets": [
    {
      "open": "(",
      "close": ")",
      "token": "delimiter.parenthesis"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/i\\\n\\\n//\\ Terminals\\\nQUOTED_IDENTIFIER:\\ /`\\[\\^`\\]\\+`/\\ \\|\\ /\\\\\\[\\[\\^\\\\\\]\\]\\+\\\\\\]/\\ \\|\\ //",
        "operator"
      ],
      [
        "//\\\n\\\n//\\ Keywords\\ \\(case\\-insensitive\\)\\\nSELECT:\\ /",
        "operator"
      ],
      [
        "/i\\\nFOREIGN_KEY:\\ /",
        "operator"
      ],
      [
        "/i\\\nPRIMARY_KEY:\\ /",
        "operator"
      ],
      [
        "/i\\\nNOT_NULL:\\ /",
        "operator"
      ],
      [
        "/i\\\nDATABASE:\\ /",
        "operator"
      ],
      [
        "/i\\\nBETWEEN:\\ /",
        "operator"
      ],
      [
        "/i\\\nBOOLEAN:\\ /",
        "operator"
      ],
      [
        "/i\\\nCREATE:\\ /",
        "operator"
      ],
      [
        "/i\\\nVALUES:\\ /",
        "operator"
      ],
      [
        "/i\\\nOFFSET:\\ /",
        "operator"
      ],
      [
        "/i\\\nHAVING:\\ /",
        "operator"
      ],
      [
        "/i\\\nUNIQUE:\\ /",
        "operator"
      ],
      [
        "/i\\\nMODIFY:\\ /",
        "operator"
      ],
      [
        "/i\\\nUPDATE:\\ /",
        "operator"
      ],
      [
        "/i\\\nINSERT:\\ /",
        "operator"
      ],
      [
        "/i\\\nCOLUMN:\\ /",
        "operator"
      ],
      [
        "/i\\\nDELETE:\\ /",
        "operator"
      ],
      [
        "/i\\\nGROUP:\\ /",
        "operator"
      ],
      [
        "/i\\\nALTER:\\ /",
        "operator"
      ],
      [
        "/i\\\nCHECK:\\ /",
        "operator"
      ],
      [
        "/i\\\nLIMIT:\\ /",
        "operator"
      ],
      [
        "/i\\\nWHERE:\\ /",
        "operator"
      ],
      [
        "/i\\\nORDER:\\ /",
        "operator"
      ],
      [
        "/i\\\nTABLE:\\ /",
        "operator"
      ],
      [
        "/i\\\nINDEX:\\ /",
        "operator"
      ],
      [
        "/i\\\nNULL:\\ /",
        "operator"
      ],
      [
        "/i\\\nDROP:\\ /",
        "operator"
      ],
      [
        "/i\\\nLIKE:\\ /",
        "operator"
      ],
      [
        "/i\\\nVIEW:\\ /",
        "operator"
      ],
      [
        "/i\\\nDESC:\\ /",
        "operator"
      ],
      [
        "/i\\\nJOIN:\\ /",
        "operator"
      ],
      [
        "/i\\\nFROM:\\ /",
        "operator"
      ],
      [
        "/i\\\nINTO:\\ /",
        "operator"
      ],
      [
        "/i\\\nSET:\\ /",
        "operator"
      ],
      [
        "/i\\\nAND:\\ /",
        "operator"
      ],
      [
        "/i\\\nADD:\\ /",
        "operator"
      ],
      [
        "/i\\\nASC:\\ /",
        "operator"
      ],
      [
        "/i\\\nNOT:\\ /",
        "operator"
      ],
      [
        "/i\\\nON:\\ /",
        "operator"
      ],
      [
        "/i\\\nIN:\\ /",
        "operator"
      ],
      [
        "/i\\\nBY:\\ /",
        "operator"
      ],
      [
        "/i\\\nOR:\\ /",
        "operator"
      ],
      [
        "/i\\\nAS:\\ /",
        "operator"
      ],
      [
        "/i\\\nIS:\\ /",
        "operator"
      ],
      [
        "/i\\ \\|\\ /",
        "operator"
      ],
      [
        "/\\[\\^/",
        "operator"
      ],
      [
        "/>=/",
        "operator"
      ],
      [
        "/<=/",
        "operator"
      ],
      [
        "/i\\ /",
        "operator"
      ],
      [
        "/<>/",
        "operator"
      ],
      [
        "/!=/",
        "operator"
      ],
      [
        "/\\]\\+/",
        "operator"
      ],
      [
        "/\\)/",
        "operator"
      ],
      [
        "/=/",
        "operator"
      ],
      [
        "/>/",
        "operator"
      ],
      [
        "/\\./",
        "operator"
      ],
      [
        "/%/",
        "operator"
      ],
      [
        "/\\*/",
        "operator"
      ],
      [
        "/\\-/",
        "operator"
      ],
      [
        "/\\(/",
        "operator"
      ],
      [
        "///",
        "operator"
      ],
      [
        "/,/",
        "operator"
      ],
      [
        "/</",
        "operator"
      ],
      [
        "/\\+/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const sqlLanguageConfig = {
  "brackets": [
    [
      "(",
      ")"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "'",
      "close": "'"
    }
  ],
  "surroundingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "'",
      "close": "'"
    }
  ]
};
// Register with Monaco Editor
export function registerSqlLanguage(monaco: any) {
  monaco.languages.register({ id: 'sql' });
  monaco.languages.setMonarchTokensProvider('sql', sqlLanguage);
  monaco.languages.setLanguageConfiguration('sql', sqlLanguageConfig);
}
