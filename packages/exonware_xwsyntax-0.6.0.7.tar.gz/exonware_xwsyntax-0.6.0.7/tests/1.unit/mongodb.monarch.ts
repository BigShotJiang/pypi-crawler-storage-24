// mongodb.monarch.ts
// Auto-generated Monaco language definition
export const mongodbLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".mongodb",
  "keywords": [
    "Date",
    "ISODate",
    "ObjectId",
    "aggregate",
    "countDocuments",
    "db",
    "deleteMany",
    "deleteOne",
    "false",
    "find",
    "insertMany",
    "insertOne",
    "new",
    "null",
    "project",
    "replaceOne",
    "true",
    "updateMany",
    "updateOne"
  ],
  "operators": [
    "$addFields",
    "$addToSet",
    "$all",
    "$and",
    "$bucket",
    "$count",
    "$elemMatch",
    "$eq",
    "$exists",
    "$facet",
    "$graphLookup",
    "$group",
    "$gt",
    "$gte",
    "$in",
    "$inc",
    "$limit",
    "$lookup",
    "$lt",
    "$lte",
    "$match",
    "$mul",
    "$ne",
    "$nin",
    "$nor",
    "$not",
    "$or",
    "$pop",
    "$project",
    "$pull",
    "$push",
    "$regex",
    "$rename",
    "$replaceRoot",
    "$set",
    "$size",
    "$skip",
    "$sort",
    "$text",
    "$type",
    "$unset",
    "$unwind",
    "$where",
    "(",
    ")",
    ",",
    ".",
    "/ | /",
    "0",
    "1",
    ":",
    "[",
    "[^",
    "]",
    "]*",
    "{",
    "}"
  ],
  "symbols": "\\)|\\$gt|\\$nor|\\[\\^|\\[|\\$eq|\\$or|\\$ne|\\$elemMatch|\\$mul|\\]\\*|\\$and|\\}|\\$pop|\\$lookup|\\$addFields|/\\ \\|\\ /|\\$type|\\$replaceRoot|\\.|\\$match|\\$nin|\\$project|1|:|\\$where|\\$inc|\\$group|\\$unset|\\$addToSet|\\$lt|\\(|\\$unwind|\\$text|\\$not|\\$regex|\\$gte|\\$facet|\\$bucket|\\$exists|\\$lte|\\$graphLookup|\\$all|\\$sort|\\$push|\\$pull|\\$size|\\$skip|,|\\$rename|\\$limit|\\{|\\$count|0|\\$in|\\$set|\\]",
  "brackets": [
    {
      "open": "(",
      "close": ")",
      "token": "delimiter.parenthesis"
    },
    {
      "open": "[",
      "close": "]",
      "token": "delimiter.square"
    },
    {
      "open": "{",
      "close": "}",
      "token": "delimiter.curly"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/\\$replaceRoot/",
        "operator"
      ],
      [
        "/\\$graphLookup/",
        "operator"
      ],
      [
        "/\\$elemMatch/",
        "operator"
      ],
      [
        "/\\$addFields/",
        "operator"
      ],
      [
        "/\\$addToSet/",
        "operator"
      ],
      [
        "/\\$project/",
        "operator"
      ],
      [
        "/\\$lookup/",
        "operator"
      ],
      [
        "/\\$unwind/",
        "operator"
      ],
      [
        "/\\$bucket/",
        "operator"
      ],
      [
        "/\\$exists/",
        "operator"
      ],
      [
        "/\\$rename/",
        "operator"
      ],
      [
        "/\\$match/",
        "operator"
      ],
      [
        "/\\$where/",
        "operator"
      ],
      [
        "/\\$group/",
        "operator"
      ],
      [
        "/\\$unset/",
        "operator"
      ],
      [
        "/\\$regex/",
        "operator"
      ],
      [
        "/\\$facet/",
        "operator"
      ],
      [
        "/\\$limit/",
        "operator"
      ],
      [
        "/\\$count/",
        "operator"
      ],
      [
        "//\\ \\|\\ //",
        "operator"
      ],
      [
        "/\\$type/",
        "operator"
      ],
      [
        "/\\$text/",
        "operator"
      ],
      [
        "/\\$sort/",
        "operator"
      ],
      [
        "/\\$push/",
        "operator"
      ],
      [
        "/\\$pull/",
        "operator"
      ],
      [
        "/\\$size/",
        "operator"
      ],
      [
        "/\\$skip/",
        "operator"
      ],
      [
        "/\\$nor/",
        "operator"
      ],
      [
        "/\\$mul/",
        "operator"
      ],
      [
        "/\\$and/",
        "operator"
      ],
      [
        "/\\$pop/",
        "operator"
      ],
      [
        "/\\$nin/",
        "operator"
      ],
      [
        "/\\$inc/",
        "operator"
      ],
      [
        "/\\$not/",
        "operator"
      ],
      [
        "/\\$gte/",
        "operator"
      ],
      [
        "/\\$lte/",
        "operator"
      ],
      [
        "/\\$all/",
        "operator"
      ],
      [
        "/\\$set/",
        "operator"
      ],
      [
        "/\\$gt/",
        "operator"
      ],
      [
        "/\\$eq/",
        "operator"
      ],
      [
        "/\\$or/",
        "operator"
      ],
      [
        "/\\$ne/",
        "operator"
      ],
      [
        "/\\$lt/",
        "operator"
      ],
      [
        "/\\$in/",
        "operator"
      ],
      [
        "/\\[\\^/",
        "operator"
      ],
      [
        "/\\]\\*/",
        "operator"
      ],
      [
        "/\\)/",
        "operator"
      ],
      [
        "/\\[/",
        "operator"
      ],
      [
        "/\\}/",
        "operator"
      ],
      [
        "/\\./",
        "operator"
      ],
      [
        "/1/",
        "operator"
      ],
      [
        "/:/",
        "operator"
      ],
      [
        "/\\(/",
        "operator"
      ],
      [
        "/,/",
        "operator"
      ],
      [
        "/\\{/",
        "operator"
      ],
      [
        "/0/",
        "operator"
      ],
      [
        "/\\]/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const mongodbLanguageConfig = {
  "brackets": [
    [
      "(",
      ")"
    ],
    [
      "[",
      "]"
    ],
    [
      "{",
      "}"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "[",
      "close": "]"
    },
    {
      "open": "{",
      "close": "}"
    },
    {
      "open": "'",
      "close": "'"
    }
  ],
  "surroundingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "[",
      "close": "]"
    },
    {
      "open": "{",
      "close": "}"
    },
    {
      "open": "'",
      "close": "'"
    }
  ]
};
// Register with Monaco Editor
export function registerMongodbLanguage(monaco: any) {
  monaco.languages.register({ id: 'mongodb' });
  monaco.languages.setMonarchTokensProvider('mongodb', mongodbLanguage);
  monaco.languages.setLanguageConfiguration('mongodb', mongodbLanguageConfig);
}
