//! Polyglot SQL integration — cross-dialect transpilation, formatting, extraction, and comparison.
//!
//! This module wraps the `polyglot-sql` crate to provide:
//! - **Transpilation**: Convert SQL between 32+ dialects
//! - **Formatting**: Pretty-print SQL in any dialect
//! - **Extraction**: Extract tables, columns, and functions from SQL without a schema
//! - **Comparison**: Structural diff of two SQL queries
//! - **Pre-validation**: Dialect-aware syntax checking before DataFusion planning

pub mod comparator;
pub mod dialect_map;
pub mod extractor;
pub mod formatter;
pub mod transpiler;
pub mod types;

pub use comparator::compare_queries;
pub use dialect_map::to_polyglot_dialect;
pub use extractor::{extract_columns, extract_metadata, extract_output_columns, extract_tables};
pub use formatter::format_sql;
pub use transpiler::{transpile, transpile_batch};
pub use types::*;
