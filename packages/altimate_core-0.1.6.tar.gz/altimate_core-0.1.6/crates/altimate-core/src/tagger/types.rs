//! Core data types for tag analysis results.

use serde::Serialize;

/// A single report item within a tag result.
#[derive(Debug, Clone, Serialize)]
pub struct TagReport {
    pub query_span: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub functions: Option<Vec<String>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata: Option<serde_json::Value>,
}

/// The result of running a single tag check.
#[derive(Debug, Clone, Serialize)]
pub struct TagResult {
    pub tag_name: String,
    pub triggered: bool,
    pub reports: Vec<TagReport>,
}

impl TagResult {
    /// Convenience constructor for a not-triggered result.
    pub fn not_triggered(name: &str) -> Self {
        Self {
            tag_name: name.to_string(),
            triggered: false,
            reports: Vec::new(),
        }
    }
}

/// Configuration for tag analysis.
#[derive(Debug, Clone, Default)]
pub struct AnalysisConfig {
    /// Tags to skip (empty = run all).
    pub skip_tags: Vec<String>,
}
