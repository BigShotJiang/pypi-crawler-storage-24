#!moo verb @dig @tunnel --on $player --dspec any --ispec "through:any" --ispec "to:any"

# pylint: disable=return-outside-function,undefined-variable

"""
This is a player command used to create a room or exit, (that is, instances of the class `$room` or ``$exit``. The verb
parses the arguments to determine the type and number of objects that are to be created. It uses the `create()` primitive,
with `$room` as a parent to create a room. Note that you can only use the `@dig` command to dig an exit from within a
room.
"""

from moo.sdk import context, create, lookup

directions = ["north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest", "up", "down"]
direction = context.parser.get_dobj_str()

source = context.player.location
if source.match_exit(direction):
    print("[red]There is already an exit in that direction.[/red]")
    return

if context.parser.has_pobj("through"):
    door = context.parser.get_pobj("through")
    if not door.is_a(_.exit):
        print("[red]The specified object is not an exit.[/red]")
        return
    door.add_alias(direction)
else:
    door = create(f"{direction} from {source.name}", parents=[_.exit], location=None)
    door.add_alias(direction)

if verb_name == "@dig":
    action = "Dug"
    dest = create(context.parser.get_pobj_str("to"), parents=[_.room], location=None)
else:
    action = "Tunnelled"
    dest = context.parser.get_pobj("to", lookup=True)

door.set_property("source", source)
door.set_property("dest", dest)
source.add_exit(door)
dest.add_entrance(door)

print(f'[yellow]{action} an exit {direction} to "{dest.name}".[/yellow]')
