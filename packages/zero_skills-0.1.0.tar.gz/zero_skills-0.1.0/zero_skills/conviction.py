"""
Conviction-based position sizing.

Size scales with consensus score, regime alignment, and funding favorability.
"""


class ConvictionSizer:
    """Position size scales with conviction.

    Higher consensus + stronger regime alignment = bigger position.
    """

    def __init__(self, equity: float, min_pct: float = 0.08, max_pct: float = 0.25):
        self.equity = equity
        self.min_pct = min_pct
        self.max_pct = max_pct

    def compute(self, consensus: float, regime: str, hurst: float | None = None) -> float:
        """Compute recommended position size in dollars.

        Args:
            consensus: 0-1 consensus score from voting/intelligence.
            regime: trending, reverting, stable, chaotic.
            hurst: optional hurst exponent for regime strength.

        Returns:
            Dollar amount for position size.
        """
        # 1. Consensus conviction: 60% threshold → 100%
        consensus_factor = max(0.0, min(1.0, (consensus - 0.60) / 0.40))

        # 2. Regime factor: trending/reverting = higher conviction, chaotic = lower
        regime_factors = {
            "trending": 0.9,
            "reverting": 0.7,
            "stable": 0.5,
            "chaotic": 0.2,
        }
        regime_factor = regime_factors.get(regime, 0.5)

        # If hurst provided, refine regime factor by strength
        if hurst is not None:
            h_strength = abs(hurst - 0.5) * 2  # 0-1
            regime_factor = regime_factor * (0.5 + 0.5 * h_strength)

        # 3. Composite conviction
        conviction = consensus_factor * 0.60 + regime_factor * 0.40

        # 4. Map conviction to size percentage
        size_pct = self.min_pct + conviction * (self.max_pct - self.min_pct)

        # 5. Dollar size
        return round(self.equity * size_pct, 2)
