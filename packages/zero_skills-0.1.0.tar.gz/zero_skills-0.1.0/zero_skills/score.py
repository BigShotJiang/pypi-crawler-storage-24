"""
Score and rank tracking via Zero API.
"""

from zero_skills.network import ZeroNetwork


class ScoreTracker:
    def __init__(self, network: ZeroNetwork):
        self.network = network

    async def get_score(self) -> dict:
        """GET /api/score — fetch agent's current score."""
        async with self.network._client() as client:
            resp = await client.get("/score")
            resp.raise_for_status()
            return resp.json()

    async def get_rank(self) -> dict:
        """GET /api/agents — fetch agent rank on leaderboard."""
        async with self.network._client() as client:
            resp = await client.get("/agents")
            resp.raise_for_status()
            return resp.json()
