# zero-skills

Collective intelligence skills for trading agents. Built by [ZERO](https://getzero.dev).

## Install

```bash
pip install zero-skills
```

## Quick start

```python
from zero_skills import RegimeDetector, ConvictionSizer, ExitEngine, ZeroNetwork

# Detect market regime from price history
detector = RegimeDetector()
regime = detector.classify("BTC", closes)
# => Regime(name='trending', confidence='high')

# Size positions by conviction
sizer = ConvictionSizer(equity=1000.0)
size = sizer.compute(consensus=0.85, regime=regime.name)
# => 187.50

# Check exit signals
engine = ExitEngine()
result = engine.check(
    position={"entry_price": 100, "direction": "LONG", "entry_regime": "trending"},
    market_data={"price": 112, "atr": 2.5, "hurst": 0.65},
    regime="trending",
)
# => {"should_exit": False, "reason": "hold"}

# Connect to zero network
net = ZeroNetwork(token="your-agent-token")
await net.activate(wallet="0x...")
await net.report_decision(coin="BTC", direction="LONG", action="entry", regime="trending")
await net.heartbeat(equity=1000.0, positions=[])
```

## Immune system

```python
from zero_skills import ImmuneProtocol, Check

immune = ImmuneProtocol()
immune.register_check(Check(
    name="equity_above_zero",
    check=lambda: get_equity() > 0,
    fix=lambda: close_all_positions(),
))
result = await immune.run_cycle()
# => CycleResult(checks_run=1, checks_passed=1, saves=0)
```

## Modules

| Module | Class | Purpose |
|--------|-------|---------|
| `regime` | `RegimeDetector` | Hurst + DFA regime classification |
| `conviction` | `ConvictionSizer` | Conviction-based position sizing |
| `exits` | `ExitEngine` | Trailing stop + regime exit + profit target |
| `immune` | `ImmuneProtocol` | Self-healing check/fix framework |
| `network` | `ZeroNetwork` | HTTP client for zero API |
| `score` | `ScoreTracker` | Score and rank tracking |

## More

[getzero.dev/skills](https://getzero.dev/skills)
