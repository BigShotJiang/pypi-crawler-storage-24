"""Test suite for plumkdocs."""
