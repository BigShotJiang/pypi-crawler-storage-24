"""FastAPI extension integration tests."""
