"""
The SAPI (Semantic AI With Pretrained Integration) is defined as a core architectural component responsible for the deterministic orchestration of training,
fine-tuning, and inference processes across the entire Sapiens model family.

During inference, the system implements a context-driven semantic routing mechanism, in which each prompt is processed through structured representations to enable the real-time,
dynamic selection of the most appropriate pretrained models. Rather than relying on a monolithic architecture, SAPI adopts a multi-model paradigm,
enabling the coordinated composition of heterogeneous specialists. This approach leads to increased accuracy, stronger semantic alignment, and improved contextual consistency in generated outputs.

One of its key technical differentiators is the ability to operate with an effectively unbounded context window,
enabled by advanced context management and retrieval strategies that mitigate traditional sequential memory limitations.
This allows the system to process large-scale information streams while preserving global coherence and semantic stability,
even in long-horizon or highly complex interactions.

In the training domain, SAPI introduces an alternative paradigm based on direct computational methods, eliminating the dependency on backpropagation.
This design significantly reduces the computational complexity associated with parameter optimization, resulting in faster learning cycles and improved energy efficiency,
while maintaining strong generalization capabilities.

The underlying infrastructure consists of a modular ecosystem of submodels encapsulated within an object-oriented structure, represented by the Frankenstein class.
This ecosystem includes both transformer-based architectures and non-conventional approaches that partially or fully eliminate backpropagation.
Coordination across these components is handled by the Entity algorithm, which evaluates input context at fine granularity and determines,
at runtime, the optimal model—or ensemble of models—to be deployed.

The result is a distributed, adaptive, and highly scalable artificial intelligence framework in which multiple architectural paradigms interoperate seamlessly,
enabling simultaneous optimization of performance, computational cost, and semantic quality of outputs.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
class SAPI:
	def __init__(self, show_errors=True, display_error_point=False):
		try:
			self.__show_errors = bool(show_errors) if type(show_errors) in (bool, int, float) else True
			self.__display_error_point = bool(display_error_point) if type(display_error_point) in (bool, int, float) else False
			try:
				from warnings import simplefilter, filterwarnings
				from logging import getLogger, ERROR, disable, CRITICAL
				from os import environ
				from dotenv import load_dotenv
				simplefilter('ignore')
				filterwarnings('ignore')
				filterwarnings('ignore', category=UserWarning, module='torch.distributed')
				getLogger('torch.distributed.elastic.multiprocessing.redirects').setLevel(ERROR)
				environ['DISABLE_MODEL_SOURCE_CHECK'] = 'True'
				load_dotenv()
				disable(CRITICAL)
			except: pass
			from traceback import print_exc
			self.__print_exc = print_exc
			from sapiens_sapi import SapiensSAPI
			self.__sapiens_sapi = SapiensSAPI(show_errors=self.__show_errors, display_error_point=self.__display_error_point)
			self.__OUTPUT = {'answer': '', 'answer_for_files': '', 'files': [], 'sources': [], 'javascript_charts': [], 'artifacts': [], 'next_token': '', 'str_cost': '0.0000000000', 'tool_call': []}
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.__init__: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def generateFrankenstein(self, model_paths=[], configuration={}, output_path='', progress=True):
		try: return self.__sapiens_sapi.generateFrankenstein(model_paths=model_paths, configuration=configuration, output_path=output_path, progress=progress)
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.generateFrankenstein: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
	def training(self, dataset_path='', presets=False, supplements=False, progress=True):
		try: return self.__sapiens_sapi.training(dataset_path=dataset_path, presets=presets, supplements=supplements, progress=progress)
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.training: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
	def saveModel(self, model_path='', progress=True):
		try: return self.__sapiens_sapi.saveModel(model_path=model_path, progress=progress)
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.saveModel: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
	def loadModel(self, model_path='', progress=True):
		try: return self.__sapiens_sapi.loadModel(model_path=model_path, progress=progress)
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.loadModel: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
	def fineTuning(self, dataset_path='', progress=True):
		try: return self.__sapiens_sapi.fineTuning(dataset_path=dataset_path, progress=progress)
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.fineTuning: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
	def inference(self, messages=[], max_tokens=None, stream=True, task_names=[], language='', temperature=0.5, creativity=0.5, humor=0.5, formality=0.5, political_spectrum=0.5, reasoning=0.0, reflection=False, tools=[]):
		try: return self.__sapiens_sapi.inference(messages=messages, max_tokens=max_tokens, stream=stream, task_names=task_names, language=language, temperature=temperature, creativity=creativity, humor=humor, formality=formality, political_spectrum=political_spectrum, reasoning=reasoning, reflection=reflection, tools=tools)
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.inference: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return self.__OUTPUT
	def close(self):
		try: return self.__sapiens_sapi.close()
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SAPI.close: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
			return False
"""
The SAPI (Semantic AI With Pretrained Integration) is defined as a core architectural component responsible for the deterministic orchestration of training,
fine-tuning, and inference processes across the entire Sapiens model family.

During inference, the system implements a context-driven semantic routing mechanism, in which each prompt is processed through structured representations to enable the real-time,
dynamic selection of the most appropriate pretrained models. Rather than relying on a monolithic architecture, SAPI adopts a multi-model paradigm,
enabling the coordinated composition of heterogeneous specialists. This approach leads to increased accuracy, stronger semantic alignment, and improved contextual consistency in generated outputs.

One of its key technical differentiators is the ability to operate with an effectively unbounded context window,
enabled by advanced context management and retrieval strategies that mitigate traditional sequential memory limitations.
This allows the system to process large-scale information streams while preserving global coherence and semantic stability,
even in long-horizon or highly complex interactions.

In the training domain, SAPI introduces an alternative paradigm based on direct computational methods, eliminating the dependency on backpropagation.
This design significantly reduces the computational complexity associated with parameter optimization, resulting in faster learning cycles and improved energy efficiency,
while maintaining strong generalization capabilities.

The underlying infrastructure consists of a modular ecosystem of submodels encapsulated within an object-oriented structure, represented by the Frankenstein class.
This ecosystem includes both transformer-based architectures and non-conventional approaches that partially or fully eliminate backpropagation.
Coordination across these components is handled by the Entity algorithm, which evaluates input context at fine granularity and determines,
at runtime, the optimal model—or ensemble of models—to be deployed.

The result is a distributed, adaptive, and highly scalable artificial intelligence framework in which multiple architectural paradigms interoperate seamlessly,
enabling simultaneous optimization of performance, computational cost, and semantic quality of outputs.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
