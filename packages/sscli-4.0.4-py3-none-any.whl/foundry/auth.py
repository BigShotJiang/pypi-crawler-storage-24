import os
import json
import tempfile
import urllib.parse
import time
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from foundry.constants import console, API_BASE_URL

# Allowed hostnames for outbound authenticated requests (C-5)
_ALLOWED_HOSTS = {"seedsource.dev", "auth.seedsource.dev", "localhost"}

# Allowed hostnames for browser-opened verification URIs (H-3)
# Includes github.com because GitHub device flow sends verification_uri there.
# seedsource.dev covers /activate endpoint; auth.seedsource.dev covers the auth subdomain.
_ALLOWED_VERIFICATION_HOSTS = {"github.com", "seedsource.dev", "auth.seedsource.dev", "localhost"}


def _http_error_message(status_code: int) -> str:
    """Map HTTP status codes from the license server to actionable user messages."""
    if status_code == 401:
        return "Invalid or expired credentials. Run: sscli auth login"
    if status_code == 403:
        return "Access denied. Your license may not cover this feature. Check: sscli whoami"
    if status_code == 404:
        return "Account not found. Have you registered? Visit: account.seedsource.dev"
    if status_code == 422:
        return "Validation error from server. Try logging out and back in: sscli auth logout && sscli auth login"
    if status_code == 429:
        return "Too many requests. Please wait a moment and try again."
    if 500 <= status_code < 600:
        return "License server is temporarily unavailable. Check status at: seedsource.dev"
    return f"Authentication failed (code: {status_code}). Run sscli auth login to refresh."


def _validate_request_url(url: str) -> None:
    """Validate that a URL is safe to send Bearer tokens to.

    Enforces HTTPS (except localhost) and hostname allowlist.
    Raises ValueError if the URL does not meet security requirements.
    """
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.hostname or ""
    if hostname not in _ALLOWED_HOSTS:
        raise ValueError(f"Request URL hostname not in allowed list: {hostname!r}")
    if parsed.scheme == "http" and hostname != "localhost":
        raise ValueError(f"HTTP only allowed for localhost; got scheme {parsed.scheme!r} for {hostname!r}")
    if parsed.scheme not in ("https", "http"):
        raise ValueError(f"Insecure URL scheme: {parsed.scheme!r}")

# Configuration
# The base URL is managed in foundry/constants.py (configurable via environment variables)
LICENSE_SERVER = API_BASE_URL
CREDENTIALS_FILE = Path.home() / ".config" / "sscli" / "credentials.json"


def save_credentials(data: Dict[str, Any]) -> None:
    """Cache authentication data locally.
    
    Stores access token, tier, and org info for CLI operations.
    Token is stored securely with owner-only file permissions (0600).
    """
    # Create directory with restrictive permissions (owner only)
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    
    # Store all authentication data
    cached_data = {
        "access_token": data.get("access_token"),
        "tier": data.get("tier", "free"),
        "org_name": data.get("org_name"),
        "email": data.get("email"),
        "status": data.get("status", "active"),
        "authorized": True,  # If we're caching, user just authenticated successfully
        "issued_at": int(data.get("issued_at", int(time.time()))),
        "expires_in": data.get("expires_in"),
        "expires_at": data.get("expires_at"),
    }

    if not cached_data.get("expires_at") and cached_data.get("expires_in"):
        try:
            cached_data["expires_at"] = int(cached_data["issued_at"]) + int(cached_data["expires_in"])
        except Exception:
            pass
    
    # Write to a securely created temp file (0600 at creation) then atomically replace.
    fd, temp_path = tempfile.mkstemp(
        prefix=f"{CREDENTIALS_FILE.name}.",
        suffix=".tmp",
        dir=str(CREDENTIALS_FILE.parent),
        text=True,
    )
    temp_file = Path(temp_path)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(cached_data, f, indent=2)
        os.chmod(temp_file, 0o600)
        temp_file.replace(CREDENTIALS_FILE)
        CREDENTIALS_FILE.chmod(0o600)
    finally:
        try:
            if temp_file.exists():
                temp_file.unlink()
        except Exception:
            pass


def _free_unauthorized_info() -> Dict[str, Any]:
    return {"tier": "free", "authorized": False, "org_name": None, "status": "unauthorized"}


def _clear_cached_credentials() -> None:
    try:
        CREDENTIALS_FILE.unlink()
    except FileNotFoundError:
        pass
    except Exception:
        pass


def _start_local_oauth_callback_server() -> tuple[ThreadingHTTPServer, dict[str, str]]:
    """Start a localhost callback server to capture OAuth code/state."""
    captured: dict[str, str] = {}

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path != "/auth/callback":
                self.send_response(404)
                self.end_headers()
                return

            params = urllib.parse.parse_qs(parsed.query)
            code = (params.get("code") or [None])[0]
            state = (params.get("state") or [None])[0]
            error = (params.get("error") or [None])[0]

            if error:
                captured["error"] = error
            if code:
                captured["code"] = code
            if state:
                captured["state"] = state

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(
                b"<html><body><h1>You can close this tab.</h1>"
                b"<p>Authentication is complete in your terminal.</p></body></html>"
            )

        def log_message(self, format, *args):  # noqa: A003
            return

    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    server.timeout = 0.5
    return server, captured


def _exchange_oauth_code(code: str, state: str) -> Dict[str, Any]:
    exchange_url = f"{LICENSE_SERVER}/v1/auth/github/exchange"
    _validate_request_url(exchange_url)
    response = requests.post(
        exchange_url,
        data={"code": code, "state": state},
        timeout=10,
        verify=True,
        allow_redirects=False,
    )
    if response.status_code != 200:
        _raw = response.text or ""
        _safe = _raw.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")[:200]
        raise RuntimeError(_http_error_message(response.status_code) + (f" — {_safe}" if _safe else ""))
    return response.json()


def login_flow() -> bool:
    """Authenticate via GitHub OAuth web flow.
    
    Starts a temporary localhost callback server, opens the GitHub authorize URL
    in the browser, then exchanges the callback code for an access token.
    
    Returns:
        True if authentication succeeded, False otherwise.
    """
    import webbrowser
    
    console.print("\n[bold blue]Seed & Source Authentication[/bold blue]")
    console.print("Authenticating with GitHub...\n")
    
    try:
        server, captured = _start_local_oauth_callback_server()
        callback_uri = f"http://127.0.0.1:{server.server_address[1]}/auth/callback"
        authorize_url = f"{LICENSE_SERVER}/v1/auth/github/authorize?{urllib.parse.urlencode({'redirect_uri': callback_uri})}"
        _validate_request_url(authorize_url)  # C-5
        response = requests.get(
            authorize_url,
            timeout=10,
            verify=True,
            allow_redirects=False,
        )
        if response.status_code != 200:
            _raw = response.text or ""
            _safe = _raw.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")[:200]
            console.print(f"[red]{_http_error_message(response.status_code)}[/red]")
            if _safe:
                console.print(f"[red]{_safe}[/red]")
            return False
        
        github_url = response.json()["url"]
        github_url_parsed = urllib.parse.urlparse(github_url)
        github_state = urllib.parse.parse_qs(github_url_parsed.query).get("state", [None])[0]
        if not github_state:
            raise RuntimeError("Authorization URL missing state")

        console.print(f"[bold yellow]Opening browser to GitHub OAuth...[/bold yellow]")
        console.print(f"If browser doesn't open, visit: {github_url}")
        try:
            # H-3: validate URI before opening browser — uses _ALLOWED_VERIFICATION_HOSTS
            # (broader than _ALLOWED_HOSTS since GitHub device flow is the OAuth provider)
            _parsed_vuri = urllib.parse.urlparse(github_url)
            _vuri_host = _parsed_vuri.hostname or ""
            _vuri_scheme = _parsed_vuri.scheme
            _is_local_http = _vuri_scheme == "http" and _vuri_host == "localhost"
            _vuri_ok = (
                _vuri_host in _ALLOWED_VERIFICATION_HOSTS
                and (_vuri_scheme == "https" or _is_local_http)
            )
            if not _vuri_ok:
                raise ValueError(f"Unsafe verification URI: {github_url!r}")
            webbrowser.open(github_url)
        except ValueError as _ve:
            console.print(f"[red]Unsafe verification URI blocked:[/red] {_ve}")
        except Exception:
            pass  # Browser opening is best-effort
        
        console.print("Waiting for browser callback...")
        deadline = time.time() + 60
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            while time.time() < deadline:
                if captured.get("error"):
                    console.print(f"\n[red]GitHub authorization was denied: {captured['error']}[/red]")
                    return False
                if captured.get("code") and captured.get("state"):
                    if captured["state"] != github_state:
                        console.print("\n[red]OAuth state mismatch. Run 'sscli auth login' again.[/red]")
                        return False
                    auth_data = _exchange_oauth_code(captured["code"], captured["state"])
                    save_credentials({
                        "access_token": auth_data.get("access_token"),
                        "tier": auth_data.get("tier", "free"),
                        "org_name": auth_data.get("org_name"),
                        "email": auth_data.get("email"),
                        "issued_at": int(time.time()),
                        "expires_in": auth_data.get("expires_in"),
                        "expires_at": auth_data.get("expires_at"),
                        "status": "active",
                        "authorized": True
                    })
                    email = auth_data.get("email")
                    tier_str = auth_data.get("tier", "free").upper()
                    org_name = auth_data.get("org_name")
                    if email:
                        console.print(f"\n✓ Successfully authenticated as {email}")
                    else:
                        console.print("\n✓ Authentication completed successfully")
                    if org_name:
                        console.print(f"License Tier: {tier_str} (via {org_name})")
                    else:
                        console.print(f"License Tier: {tier_str}")
                    return True
                time.sleep(0.25)
            console.print("\n[yellow]⚠️  Authentication timed out after 1 minute. Run 'sscli auth login' to try again.[/yellow]")
            return False
        finally:
            server.shutdown()
            server.server_close()
        
    except requests.RequestException:
        console.print("[red]Couldn't reach the Seed & Source server. Check your internet connection and try again.[/red]")
        return False
    except Exception as e:
        console.print(f"[red]Unexpected error during authentication:[/] {e}")
        return False


def get_current_license_info(verify: bool = False) -> Dict[str, Any]:
    """Get current license/tier info from local cache or validate with server.

    If verify=True, validates stored token with License Server to ensure authenticity.
    If verification fails, returns cached tier (or free if no cache).
    
    Token is stored locally in credentials file with restricted permissions (0600).
    """
    default_info = _free_unauthorized_info()
    
    # Check if cached credentials exist — TOCTOU-safe (H-24)
    cached_info = None
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            cached_info = json.load(f)
        if not isinstance(cached_info, dict):
            cached_info = None
        else:
            # Ensure authorized flag is set for cached credentials
            if "authorized" not in cached_info:
                cached_info["authorized"] = cached_info.get("tier", "free") != "free"
    except (FileNotFoundError, json.JSONDecodeError):
        cached_info = None
    except Exception:
        cached_info = None
    
    # If not verifying, return cached info but never trust local tier (C-14)
    if not verify:
        if cached_info:
            try:
                expires_at = cached_info.get("expires_at")
                if expires_at and int(expires_at) <= int(time.time()):
                    return default_info
            except Exception:
                pass
            return {**cached_info, "tier": "free"}
        return default_info
    
    # Verification mode: get token from cache and validate with License Server
    if not cached_info or not cached_info.get("access_token"):
        # No token available: never return local/tampered tier data.
        return default_info
    
    token = cached_info["access_token"]
    
    try:
        _validate_url = f"{LICENSE_SERVER}/v1/auth/validate"
        _validate_request_url(_validate_url)  # C-5
        response = requests.get(
            _validate_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=2.0,
            verify=True,           # H-1
            allow_redirects=False, # H-2
        )
        if response.status_code == 200:
            server_data = response.json()
            # Ensure authorized flag is set
            server_data["authorized"] = True
            server_data["access_token"] = token  # Preserve token
            # Update cache with fresh server data
            save_credentials(server_data)
            return server_data
        elif response.status_code == 401:
            # Token is invalid/revoked; clear local credentials and downgrade immediately.
            _clear_cached_credentials()
            console.print(f"[yellow]{_http_error_message(401)}[/yellow]")
            return default_info
        else:
            # Non-200: cannot verify tier — never trust local JSON tier (C-14)
            console.print(f"[yellow]{_http_error_message(response.status_code)}[/yellow]")
            return default_info
    except Exception:
        # Server unreachable — never trust local JSON tier (C-14)
        return default_info


def logout() -> None:
    """Clear authentication credentials.

    Removes locally stored access token and cached credentials.
    """
    # TOCTOU-safe unlink (H-24)
    try:
        CREDENTIALS_FILE.unlink()
        console.print("[green]✓ Logged out successfully.[/green]")
    except FileNotFoundError:
        console.print("[yellow]No active session found.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error during logout:[/] {e}")


# Legacy function - no longer used (kept for compatibility)
def get_access_token() -> Optional[str]:
    """Retrieve token from credentials file.
    
    Legacy function kept for backward compatibility.
    Returns stored access token or None if not authenticated.
    """
    # TOCTOU-safe read (H-24)
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
        return data.get("access_token")
    except (FileNotFoundError, json.JSONDecodeError):
        return None
    except Exception:
        return None
