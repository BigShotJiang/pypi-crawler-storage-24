"""Credit-related response models."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ClaimDailyCreditsResponse:
    success: bool
    credits_claimed: float | None = None
    new_balance: float | None = None
    next_claim_available_at: str | None = None
    error: str | None = None
    current_balance: float | None = None
