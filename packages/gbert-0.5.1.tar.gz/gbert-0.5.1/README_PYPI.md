# gbert

## English

`gbert` is a research-oriented package for multilingual manifesto analysis. It provides sentence-level CMP classification, corpus profiling, group comparison, country-year panel construction, uncertainty analysis, and comparative geometric inspection through UMAP.

### Installation

```bash
pip install gbert
```

Optional plotting and dimensionality-reduction packages:

```bash
pip install umap-learn matplotlib seaborn
```

### Model Initialisation

```python
from gbert import GbertClassifier

model = GbertClassifier(
    model_repo_id="your-org/your-model-repo",
)
```

Important initialization arguments:

- `model_path`: local model weights
- `model_repo_id`: Hugging Face model repository
- `model_filename`: model file name, default `causal_nam_best.pt`
- `hf_token`: optional Hugging Face token
- `text_model_name_or_path`: default `bert-base-multilingual-cased`
- `device`: `cpu`, `cuda`, or automatic selection
- `batch_size`: default batch size for corpus inference
- `max_length`: tokenizer truncation length

### Built-in Demo Corpus

`gbert` includes an illustrative multilingual demo corpus for testing the full workflow.

- countries: Japan, United States, Germany
- years: every year from 1996 to 2018
- size: 207 texts
- languages: Japanese, English, German
- metadata: `party_family`

This corpus is designed for workflow validation and API testing. It is not presented as an archival source corpus.

```python
from gbert import load_demo_corpus_ja_us_de_1996_2018

demo = load_demo_corpus_ja_us_de_1996_2018()
texts = demo["text"].tolist()
countries = demo["country"].tolist()
years = demo["year"].tolist()
party_family = demo["party_family"].tolist()
```

### Core Prediction APIs

#### `predict(text, country, year, top_k=5)`

Use for one text at a time.

Returns a dictionary with:

- `text`
- `country`
- `year`
- `predictions`
- `macro_values`

Each prediction item contains:

- `rank`
- `label`
- `cmp_code`
- `cmp_title`
- `probability`

#### `predict_batch(texts, country, year, top_k=5, batch_size=None, return_df=False)`

Use for multiple texts.

- `country` and `year` can be scalars or sequences
- when `return_df=True`, the output is a simplified `DataFrame`
- when `return_df=False`, the output is a list of full prediction dictionaries

### Corpus Analysis APIs

#### `analyze_corpus(...)`

Primary text-level analysis interface.

Key arguments:

- `texts`
- `country`
- `year`
- `batch_size`
- `top_k`
- `include_probabilities`
- `metadata`

Returns a `DataFrame` with text-level outputs such as:

- `text`
- `country`
- `year`
- `top_cmp_code`
- `top_cmp_title`
- `top_probability`
- `entropy`
- `confidence_margin`
- `predictions`
- optional probability columns `p_<cmp>`
- optional metadata columns supplied by the user

#### `compute_topic_profile(...)`

Builds a corpus-level CMP profile by averaging posterior probabilities across texts.

Returns a ranked `DataFrame` with:

- `cmp_code`
- `cmp_title`
- `score`
- `rank`

#### `bootstrap_topic_profile(...)`

Constructs bootstrap-based interval estimates for the corpus profile.

Returns:

- `cmp_code`
- `cmp_title`
- `mean_score`
- `ci_lower`
- `ci_upper`

#### `compare_groups(..., group=...)`

Compares any user-defined grouping variable.

Returns a dictionary with:

- `group_summary`
- `pairwise_divergence`

`group_summary` contains:

- `group`
- `n_texts`
- `mean_entropy`
- `mean_confidence_margin`
- `top_cmp_code`
- `top_cmp_title`
- `top_cmp_score`

`pairwise_divergence` contains Jensen-Shannon divergence values between groups.

#### `compare_country_profiles(...)`

Convenience wrapper for country-level group comparison.

### Panel and Summary APIs

#### `panelize_country_year(...)`

Aggregates text-level predictions into a country-year panel.

Returns a `DataFrame` with:

- `country`
- `year`
- `n_texts`
- `mean_entropy`
- `mean_confidence_margin`
- `top_cmp_code`
- `top_cmp_title`
- `top_cmp_score`
- `score_<cmp>` for every CMP category

#### `export_methods_summary(...)`

Builds a compact summary object for reporting and manuscript drafting.

Returns a dictionary with:

- `sample`
- `prediction_quality`
- `coverage`
- `top_topics`
- `methods_text`

### UMAP and Plotting APIs

#### `project_umap(...)`

Produces a two-dimensional projection from model outputs.

Important arguments:

- `representation`: `logits` or `probabilities`
- `n_neighbors`
- `min_dist`
- `metric`
- `random_state`
- `metadata`

Returns a `DataFrame` with:

- `text`
- `country`
- `year`
- `country_year`
- `umap_x`
- `umap_y`
- `top_cmp_code`
- `top_cmp_title`
- optional metadata columns

#### `plot_umap(...)`

Seaborn-based UMAP plot for comparative inspection.

Useful arguments:

- `color_by`
- `style_by`
- `size_by`
- `annotate`
- `annotate_by`
- `add_centroids`
- `palette`

Returns:

- `fig`
- `ax`
- projected `DataFrame`

#### `plot_topic_profile(profile, ...)`

Bar plot of a ranked topic profile.

#### `plot_group_divergence(divergence, ...)`

Heatmap of pairwise Jensen-Shannon divergence.

#### `plot_topic_heatmap(panel, ...)`

Heatmap based on the country-year panel.

#### `plot_topic_ridgeplot(analysis, ...)`

Distributional ridgeplot over probability columns from `analyze_corpus(...)`.

#### `plot_temporal_trends(panel, ...)`

Line plot of topic trajectories across years from the panel output.

### CMP Lookup APIs

#### `get_cmp_info(code)`

Returns:

- `cmp_code`
- `title`

#### `list_cmp_codes()`

Returns the full CMP code list available in the model label space.

### Complete Workflow Example

```python
from gbert import GbertClassifier, load_demo_corpus_ja_us_de_1996_2018

model = GbertClassifier(model_repo_id="your-org/your-model-repo")
demo = load_demo_corpus_ja_us_de_1996_2018()

texts = demo["text"].tolist()
countries = demo["country"].tolist()
years = demo["year"].tolist()
party_family = demo["party_family"].tolist()

analysis = model.analyze_corpus(
    texts=texts,
    country=countries,
    year=years,
    include_probabilities=True,
    metadata={"party_family": party_family},
)

profile = model.compute_topic_profile(
    texts=texts,
    country=countries,
    year=years,
)

panel = model.panelize_country_year(
    texts=texts,
    country=countries,
    year=years,
)

comparison = model.compare_groups(
    texts=texts,
    country=countries,
    year=years,
    group=party_family,
)

summary = model.export_methods_summary(
    texts=texts,
    country=countries,
    year=years,
)

fig, ax, umap_frame = model.plot_umap(
    texts=texts,
    country=countries,
    year=years,
    metadata={"party_family": party_family},
    color_by="country",
    style_by="party_family",
)
```

The default text backbone is `bert-base-multilingual-cased`.

## 日本語

`gbert` は、多言語政治宣言テキスト分析のための研究志向 Python パッケージです。CMP 分類、コーパス分析、群間比較、国・年パネル化、不確実性評価、UMAP による可視化を一貫して扱えます。

### 主要機能

- `predict(...)`: 単文予測
- `predict_batch(...)`: 複数文予測
- `analyze_corpus(...)`: 文単位分析
- `compute_topic_profile(...)`: コーパス主題分布
- `bootstrap_topic_profile(...)`: ブートストラップ区間推定
- `compare_groups(...)`: 任意グループ比較
- `compare_country_profiles(...)`: 国別比較
- `panelize_country_year(...)`: 国・年パネル化
- `project_umap(...)` / `plot_umap(...)`: UMAP 可視化
- `plot_topic_profile(...)`
- `plot_group_divergence(...)`
- `plot_topic_heatmap(...)`
- `plot_topic_ridgeplot(...)`
- `plot_temporal_trends(...)`
- `export_methods_summary(...)`
- `get_cmp_info(...)`
- `list_cmp_codes(...)`

### デモコーパス

`load_demo_corpus_ja_us_de_1996_2018()` は、日本・米国・ドイツ、1996-2018、計 207 文の多言語テスト用データを返します。`party_family` も含まれます。

## 中文

`gbert` 是一个面向研究工作的多语言政治宣言分析包，支持句子级 CMP 分类、语料分析、群体比较、国家-年份面板化、不确定性分析以及 UMAP 可视化。

### 主要接口

- `predict(...)`
- `predict_batch(...)`
- `analyze_corpus(...)`
- `compute_topic_profile(...)`
- `bootstrap_topic_profile(...)`
- `compare_groups(...)`
- `compare_country_profiles(...)`
- `panelize_country_year(...)`
- `project_umap(...)`
- `plot_umap(...)`
- `plot_topic_profile(...)`
- `plot_group_divergence(...)`
- `plot_topic_heatmap(...)`
- `plot_topic_ridgeplot(...)`
- `plot_temporal_trends(...)`
- `export_methods_summary(...)`
- `get_cmp_info(...)`
- `list_cmp_codes(...)`

### Demo 语料

`load_demo_corpus_ja_us_de_1996_2018()` 会返回日本、美国、德国在 1996-2018 年间的 207 条多语言测试文本，并包含 `party_family` 字段，便于直接测试分组比较接口。
