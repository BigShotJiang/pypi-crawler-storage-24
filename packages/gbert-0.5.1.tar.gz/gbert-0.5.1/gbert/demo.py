from __future__ import annotations

from typing import Any

import pandas as pd


JP_TEMPLATES = [
    ("developmentalist", "政府は{year}年に産業競争力を高めるため、研究開発と先端製造業への投資を拡大する。"),
    ("welfare", "政府は{year}年に医療、介護、教育への公的支出を強化し、社会的包摂を進める。"),
    ("internationalist", "政府は{year}年に外交協調と地域の安定を重視し、平和的解決を優先する。"),
]

US_TEMPLATES = [
    ("developmentalist", "In {year}, the federal government should expand strategic industrial investment and modern infrastructure."),
    ("welfare", "In {year}, public healthcare, education, and social protection should receive greater support."),
    ("internationalist", "In {year}, the United States should strengthen alliances, diplomacy, and international cooperation."),
]

DE_TEMPLATES = [
    ("developmentalist", "Im Jahr {year} soll der Staat Innovation, Industrie und moderne Infrastruktur gezielt foerdern."),
    ("welfare", "Im Jahr {year} muessen Sozialstaat, Bildung und oeffentliche Gesundheitsversorgung ausgebaut werden."),
    ("internationalist", "Im Jahr {year} sollte Deutschland internationale Zusammenarbeit, Diplomatie und Frieden staerken."),
]


def load_demo_corpus_ja_us_de_1996_2018(return_df: bool = True) -> pd.DataFrame | dict[str, list[Any]]:
    rows: list[dict[str, Any]] = []

    for year in range(1996, 2019):
        for party_family, text in JP_TEMPLATES:
            rows.append({"text": text.format(year=year), "country": "Japan", "year": year, "party_family": party_family})
        for party_family, text in US_TEMPLATES:
            rows.append({"text": text.format(year=year), "country": "United States", "year": year, "party_family": party_family})
        for party_family, text in DE_TEMPLATES:
            rows.append({"text": text.format(year=year), "country": "Germany", "year": year, "party_family": party_family})

    frame = pd.DataFrame(rows)
    if return_df:
        return frame
    return {
        "texts": frame["text"].tolist(),
        "countries": frame["country"].tolist(),
        "years": frame["year"].tolist(),
        "party_family": frame["party_family"].tolist(),
    }
