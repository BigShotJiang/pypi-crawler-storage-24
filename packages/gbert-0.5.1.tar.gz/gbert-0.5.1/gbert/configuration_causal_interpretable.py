from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class CausalInterpretableConfig:
    text_model_name_or_path: str = "bert-base-multilingual-cased"
    text_config: dict[str, Any] | None = None
    num_labels: int = 56
    num_macro: int = 6
    num_countries: int = 50
    num_years: int = 100
    text_hidden_dim: int = 256
    macro_hidden_dim: int = 16
    country_emb_dim: int = 16
    year_emb_dim: int = 16
    ctx_dim: int = 128
    ctx_depth: int = 2
    ctx_heads: int = 4
    dropout: float = 0.1
    problem_type: str | None = None
