from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Any, Sequence
import warnings

import joblib
import numpy as np
import pandas as pd

from .modeling_causal_interpretable import CausalInterpretableForSequenceClassification


MODEL_COUNTRY_TO_WB = {
    "Bosnia-Herzegovina": "Bosnia and Herzegovina",
    "Czech Republic": "Czechia",
    "Russia": "Russian Federation",
    "Slovakia": "Slovak Republic",
    "South Korea": "Korea, Rep.",
    "Turkey": "Turkiye",
}

WB_COUNTRY_TO_MODEL = {value: key for key, value in MODEL_COUNTRY_TO_WB.items()}

PACKAGE_DIR = Path(__file__).resolve().parent

MACRO_SOURCES = {
    "battle_value": "add/battle/API_VC.BTL.DETH_DS2_en_csv_v2_9816.csv",
    "gdp_value": "add/gdp/API_NY.GDP.MKTP.KD.ZG_DS2_en_csv_v2_2509.csv",
    "trade_value": "add/trade/API_NE.TRD.GNFS.ZS_DS2_en_csv_v2_2650.csv",
    "debt_value": "add/debt/API_GC.DOD.TOTL.GD.ZS_DS2_en_csv_v2_2484.csv",
    "inflation_value": "add/inflation/API_FP.CPI.TOTL.ZG_DS2_en_csv_v2_2479.csv",
    "unemployment_value": "add/unemployment/API_SL.UEM.TOTL.ZS_DS2_en_csv_v2_2821.csv",
}

CMP_CODE_TO_TITLE = {
    101: "Foreign Special Relationships: Positive",
    102: "Foreign Special Relationships: Negative",
    103: "Anti-Imperialism",
    104: "Military: Positive",
    105: "Military: Negative",
    106: "Peace",
    107: "Internationalism: Positive",
    108: "European Community/Union: Positive",
    109: "Internationalism: Negative",
    110: "European Community/Union: Negative",
    201: "Freedom and Human Rights",
    202: "Democracy",
    203: "Constitutionalism: Positive",
    204: "Constitutionalism: Negative",
    301: "Federalism",
    302: "Centralisation",
    303: "Governmental and Administrative Efficiency",
    304: "Political Corruption",
    305: "Political Authority",
    401: "Free Market Economy",
    402: "Incentives",
    403: "Market Regulation",
    404: "Economic Planning",
    405: "Corporatism/Mixed Economy",
    406: "Protectionism: Positive",
    407: "Protectionism: Negative",
    408: "Economic Goals",
    409: "Keynesian Demand Management",
    410: "Economic Growth: Positive",
    411: "Technology and Infrastructure",
    412: "Controlled Economy",
    413: "Nationalisation",
    414: "Economic Orthodoxy",
    415: "Marxist Analysis: Positive",
    416: "Anti-Growth Economy: Positive",
    501: "Environmental Protection: Positive",
    502: "Culture: Positive",
    503: "Equality: Positive",
    504: "Welfare State Expansion",
    505: "Welfare State Limitation",
    506: "Education Expansion",
    507: "Education Limitation",
    601: "National Way of Life: Positive",
    602: "National Way of Life: Negative",
    603: "Traditional Morality: Positive",
    604: "Traditional Morality: Negative",
    605: "Law and Order: Positive",
    606: "Civic Mindedness: Positive",
    607: "Multiculturalism: Positive",
    608: "Multiculturalism: Negative",
    701: "Labour Groups: Positive",
    702: "Labour Groups: Negative",
    703: "Agriculture and Farmers: Positive",
    704: "Middle Class and Professional Groups",
    705: "Underprivileged Minority Groups",
    706: "Non-Economic Demographic Groups",
}


@dataclass(frozen=True)
class MacroLookupResult:
    country: str
    year: int
    raw_values: dict[str, float]
    standardized_values: list[float]
    raw_sources: dict[str, str]


def _normalize_state_dict_keys(state_dict: dict[str, Any]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in state_dict.items():
        new_key = key
        if new_key.startswith("module."):
            new_key = new_key[len("module."):]
        if new_key.startswith("bert."):
            new_key = "text_encoder." + new_key[len("bert."):]
        if new_key == "ctx_to_bert.weight":
            new_key = "ctx_to_text.weight"
        elif new_key == "ctx_to_bert.bias":
            new_key = "ctx_to_text.bias"
        normalized[new_key] = value
    return normalized


def _as_list(value: Any, size: int, *, name: str) -> list[Any]:
    if isinstance(value, (str, bytes)):
        return [value] * size
    if isinstance(value, Sequence):
        items = list(value)
        if len(items) != size:
            raise ValueError(f"{name} must have the same length as texts.")
        return items
    return [value] * size


def _safe_normalize(values: np.ndarray) -> np.ndarray:
    total = float(values.sum())
    if total <= 0:
        return np.full_like(values, 1.0 / len(values), dtype=float)
    return values / total


def _probability_entropy(probs: np.ndarray) -> float:
    clipped = np.clip(probs, 1e-12, 1.0)
    return float(-(clipped * np.log(clipped)).sum())


def _top_margin(probs: np.ndarray) -> float:
    ordered = np.sort(probs)[::-1]
    if len(ordered) < 2:
        return float(ordered[0])
    return float(ordered[0] - ordered[1])


def _jensen_shannon_divergence(p: np.ndarray, q: np.ndarray) -> float:
    p = _safe_normalize(np.asarray(p, dtype=float))
    q = _safe_normalize(np.asarray(q, dtype=float))
    m = 0.5 * (p + q)

    def _kl(a: np.ndarray, b: np.ndarray) -> float:
        mask = a > 0
        return float(np.sum(a[mask] * np.log(a[mask] / np.clip(b[mask], 1e-12, None))))

    return 0.5 * _kl(p, m) + 0.5 * _kl(q, m)


class GbertClassifier:
    def __init__(
        self,
        *,
        base_dir: str | Path | None = None,
        model_path: str | Path | None = None,
        model_repo_id: str | None = None,
        model_filename: str | None = None,
        hf_token: str | None = None,
        text_model_name_or_path: str | None = None,
        device: str | None = None,
        batch_size: int = 16,
        max_length: int = 128,
        torch_num_threads: int | None = None,
    ) -> None:
        self.base_dir = Path(base_dir or PACKAGE_DIR).resolve()
        self.meta_path = self.base_dir / "preprocess_meta.joblib"
        self.model_path = self._resolve_model_path(model_path)
        self.model_repo_id = (
            model_repo_id
            or os.environ.get("GBERT_MODEL_REPO_ID")
            or os.environ.get("MODEL_REPO_ID")
            or ""
        ).strip()
        self.model_filename = (
            model_filename
            or os.environ.get("GBERT_MODEL_FILENAME")
            or os.environ.get("MODEL_FILENAME")
            or "causal_nam_best.pt"
        ).strip()
        self.hf_token = (
            hf_token
            or os.environ.get("HF_TOKEN")
            or os.environ.get("HUGGING_FACE_HUB_TOKEN")
            or None
        )
        self.text_model_name_or_path = (
            text_model_name_or_path
            or os.environ.get("TEXT_MODEL_NAME_OR_PATH")
            or "bert-base-multilingual-cased"
        ).strip()
        self.device_name = device
        self.batch_size = max(1, int(batch_size))
        self.max_length = max(8, int(max_length))
        self.torch_num_threads = int(
            torch_num_threads
            or os.environ.get("TORCH_NUM_THREADS")
            or 1
        )

        self.meta = self._load_meta()
        self.country_classes = [str(v) for v in self.meta["country_le"].classes_]
        self.year_classes = sorted(int(v) for v in self.meta["year_le"].classes_)
        self.label_classes = [str(v) for v in self.meta["cat_le"].classes_]
        self.macro_cols = list(self.meta["macro_cols"])
        self.macro_means = {
            key: float(value) for key, value in self.meta["macro_means"].to_dict().items()
        }
        self.macro_stds = {
            key: float(value) if float(value) != 0 else 1.0
            for key, value in self.meta["macro_stds"].to_dict().items()
        }
        self.macro_frame = self._load_macro_frame()
        self.model_year_min = min(self.year_classes)
        self.model_year_max = max(self.year_classes)
        self.supported_years = self._build_supported_years()
        self.available_years = self._build_available_years()

        self._torch = None
        self._tokenizer = None
        self._model = None
        self._device = None

        self._load_runtime()

    def get_cmp_info(self, code: int | str) -> dict[str, Any]:
        cmp_code = int(code)
        return {
            "cmp_code": cmp_code,
            "title": CMP_CODE_TO_TITLE.get(cmp_code, "Unknown CMP code"),
        }

    def list_cmp_codes(self) -> list[dict[str, Any]]:
        return [self.get_cmp_info(code) for code in self.label_classes]

    def _resolve_model_path(self, model_path: str | Path | None) -> Path:
        configured = (
            str(model_path)
            if model_path is not None
            else (
                os.environ.get("GBERT_MODEL_PATH")
                or os.environ.get("MODEL_PATH")
                or ""
            )
        ).strip()
        if configured:
            path = Path(configured)
            if not path.is_absolute():
                path = self.base_dir / path
            return path.resolve()
        return (self.base_dir / "causal_nam_best.pt").resolve()

    def _load_meta(self) -> dict[str, Any]:
        warnings.filterwarnings(
            "ignore",
            message="Trying to unpickle estimator LabelEncoder",
        )
        return joblib.load(self.meta_path)

    def _load_world_bank_csv(self, macro_name: str, relative_path: str) -> pd.DataFrame:
        csv_path = self.base_dir / relative_path
        df = pd.read_csv(csv_path, skiprows=4)
        year_cols = [col for col in df.columns if str(col).isdigit()]
        df = df[["Country Name", *year_cols]].copy()
        df["Country Name"] = df["Country Name"].replace(WB_COUNTRY_TO_MODEL)

        long_df = df.melt(
            id_vars="Country Name",
            value_vars=year_cols,
            var_name="year",
            value_name=macro_name,
        )
        long_df = long_df.rename(columns={"Country Name": "country"})
        long_df["year"] = long_df["year"].astype(int)
        long_df[macro_name] = pd.to_numeric(long_df[macro_name], errors="coerce")
        long_df = long_df[long_df["country"].isin(self.country_classes)].copy()
        return long_df

    def _load_macro_frame(self) -> pd.DataFrame:
        merged: pd.DataFrame | None = None
        for macro_name, relative_path in MACRO_SOURCES.items():
            macro_df = self._load_world_bank_csv(macro_name, relative_path)
            if merged is None:
                merged = macro_df
            else:
                merged = merged.merge(macro_df, on=["country", "year"], how="outer")

        if merged is None:
            raise RuntimeError("No macro data loaded from add directory.")
        return merged.sort_values(["country", "year"]).reset_index(drop=True)

    def _build_supported_years(self) -> list[int]:
        macro_years = sorted(int(v) for v in self.macro_frame["year"].dropna().astype(int).unique())
        return [year for year in macro_years if year >= self.model_year_min]

    def _build_available_years(self) -> dict[str, list[int]]:
        valid_years = set(self.supported_years)
        by_country: dict[str, list[int]] = {}
        for country in self.country_classes:
            country_df = self.macro_frame[self.macro_frame["country"] == country]
            years = sorted(
                int(y) for y in country_df["year"].dropna().astype(int).unique() if int(y) in valid_years
            )
            by_country[country] = years
        return by_country

    def _load_runtime(self) -> None:
        os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

        import torch
        from huggingface_hub import hf_hub_download
        from transformers import AutoTokenizer

        torch.set_num_threads(self.torch_num_threads)
        if hasattr(torch, "set_num_interop_threads"):
            torch.set_num_interop_threads(1)

        model_path = self.model_path
        if not model_path.exists():
            if not self.model_repo_id:
                raise FileNotFoundError(
                    "Model weights were not found. Set `model_path` or `GBERT_MODEL_PATH`, "
                    "or provide `model_repo_id` / `GBERT_MODEL_REPO_ID` for Hugging Face Hub."
                )
            model_path = Path(
                hf_hub_download(
                    repo_id=self.model_repo_id,
                    filename=self.model_filename,
                    token=self.hf_token,
                )
            )

        device_name = self.device_name
        if not device_name or device_name == "auto":
            device_name = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device_name)

        model = CausalInterpretableForSequenceClassification.from_text_pretrained(
            self.text_model_name_or_path,
            num_labels=len(self.label_classes),
            num_macro=len(self.macro_cols),
            num_countries=len(self.country_classes),
            num_years=len(self.year_classes),
            text_pretrained_kwargs={"low_cpu_mem_usage": True},
        ).to(device)

        load_kwargs: dict[str, Any] = {"map_location": device}
        if "weights_only" in torch.load.__code__.co_varnames:
            load_kwargs["weights_only"] = True
        if "mmap" in torch.load.__code__.co_varnames:
            load_kwargs["mmap"] = True
        state_dict = torch.load(model_path, **load_kwargs)
        if isinstance(state_dict, dict) and "state_dict" in state_dict and isinstance(state_dict["state_dict"], dict):
            state_dict = state_dict["state_dict"]
        state_dict = _normalize_state_dict_keys(state_dict)
        model.load_state_dict(state_dict)
        model.eval()
        model.requires_grad_(False)

        self._torch = torch
        self._tokenizer = AutoTokenizer.from_pretrained(self.text_model_name_or_path)
        self._model = model
        self._device = device
        self.model_path = model_path.resolve()

    def _validate_country(self, country: str) -> None:
        if country not in self.country_classes:
            raise ValueError(f"Unsupported country: {country}")

    def _validate_year(self, year: int) -> None:
        if year not in self.supported_years:
            raise ValueError(f"Unsupported year: {year}")

    def _encode_year(self, year: int) -> int:
        encoded_year = min(int(year), self.model_year_max)
        return int(self.meta["year_le"].transform([encoded_year])[0])

    def get_macro_values(self, country: str, year: int) -> MacroLookupResult:
        self._validate_country(country)
        self._validate_year(year)

        row = self.macro_frame[
            (self.macro_frame["country"] == country) & (self.macro_frame["year"] == year)
        ]

        raw_values: dict[str, float] = {}
        raw_sources: dict[str, str] = {}
        if row.empty:
            for macro_name in self.macro_cols:
                raw_values[macro_name] = 0.0
                raw_sources[macro_name] = "missing-year-filled-zero"
        else:
            row_data = row.iloc[0]
            for macro_name in self.macro_cols:
                value = row_data.get(macro_name)
                if pd.isna(value):
                    raw_values[macro_name] = 0.0
                    raw_sources[macro_name] = "dataset-missing-filled-zero"
                else:
                    raw_values[macro_name] = float(value)
                    raw_sources[macro_name] = "dataset"

        standardized_values = [
            (raw_values[macro_name] - self.macro_means[macro_name]) / self.macro_stds[macro_name]
            for macro_name in self.macro_cols
        ]
        return MacroLookupResult(
            country=country,
            year=int(year),
            raw_values=raw_values,
            standardized_values=standardized_values,
            raw_sources=raw_sources,
        )

    def _prepare_rows(
        self,
        texts: Sequence[str],
        countries: Sequence[str],
        years: Sequence[int],
    ) -> list[dict[str, Any]]:
        prepared_rows: list[dict[str, Any]] = []
        for text, country, year in zip(texts, countries, years):
            normalized_text = (text or "").strip()
            if not normalized_text:
                raise ValueError("Text is required.")
            self._validate_country(country)
            self._validate_year(int(year))
            macro_lookup = self.get_macro_values(country, int(year))
            prepared_rows.append(
                {
                    "text": normalized_text,
                    "country": country,
                    "year": int(year),
                    "country_id": int(self.meta["country_le"].transform([country])[0]),
                    "year_id": self._encode_year(int(year)),
                    "macro_lookup": macro_lookup,
                }
            )
        return prepared_rows

    def _predict_batch_internal(
        self,
        texts: Sequence[str],
        countries: Sequence[str],
        years: Sequence[int],
        *,
        top_k: int,
        batch_size: int,
    ) -> list[dict[str, Any]]:
        torch = self._torch
        tokenizer = self._tokenizer
        model = self._model
        device = self._device

        prepared_rows = self._prepare_rows(texts, countries, years)

        outputs: list[dict[str, Any]] = []
        top_k = max(1, min(int(top_k), len(self.label_classes)))
        batch_size = max(1, int(batch_size))

        for start in range(0, len(prepared_rows), batch_size):
            chunk = prepared_rows[start:start + batch_size]
            _, probs = self._forward_prepared_batch(chunk)

            for item, item_probs in zip(chunk, probs):
                ranked_indices = item_probs.argsort()[::-1][:top_k]
                predictions = [
                    {
                        "rank": rank + 1,
                        "label": str(self.label_classes[idx]),
                        "cmp_code": int(self.label_classes[idx]),
                        "cmp_title": CMP_CODE_TO_TITLE.get(int(self.label_classes[idx]), "Unknown CMP code"),
                        "probability": float(item_probs[idx]),
                    }
                    for rank, idx in enumerate(ranked_indices)
                ]
                macro_payload = {
                    macro_name: {
                        "raw": item["macro_lookup"].raw_values[macro_name],
                        "standardized": item["macro_lookup"].standardized_values[i],
                        "source": item["macro_lookup"].raw_sources[macro_name],
                    }
                    for i, macro_name in enumerate(self.macro_cols)
                }
                outputs.append(
                    {
                        "text": item["text"],
                        "country": item["country"],
                        "year": item["year"],
                        "predictions": predictions,
                        "macro_values": macro_payload,
                    }
                )
        return outputs

    def list_countries(self) -> list[str]:
        return [country for country in self.country_classes if self.available_years.get(country)]

    def list_years(self, country: str) -> list[int]:
        self._validate_country(country)
        years = self.available_years.get(country, [])
        if not years:
            raise ValueError(f"{country} has no supported years in add data.")
        return years

    def runtime_info(self) -> dict[str, Any]:
        return {
            "model_path": str(self.model_path),
            "model_repo_id": self.model_repo_id or None,
            "model_filename": self.model_filename,
            "text_model_name_or_path": self.text_model_name_or_path,
            "device": str(self._device),
            "torch_num_threads": self.torch_num_threads,
            "batch_size": self.batch_size,
            "max_length": self.max_length,
        }

    def _forward_prepared_batch(
        self,
        chunk: Sequence[dict[str, Any]],
    ) -> tuple[np.ndarray, np.ndarray]:
        tokenizer = self._tokenizer
        model = self._model
        device = self._device
        torch = self._torch

        encoded = tokenizer(
            [item["text"] for item in chunk],
            truncation=True,
            max_length=self.max_length,
            padding=True,
            return_tensors="pt",
        )

        macro_tensor = torch.tensor(
            [item["macro_lookup"].standardized_values for item in chunk],
            dtype=torch.float32,
            device=device,
        )
        country_tensor = torch.tensor(
            [item["country_id"] for item in chunk],
            dtype=torch.long,
            device=device,
        )
        year_tensor = torch.tensor(
            [item["year_id"] for item in chunk],
            dtype=torch.long,
            device=device,
        )

        with torch.inference_mode():
            logits = model(
                input_ids=encoded["input_ids"].to(device),
                attention_mask=encoded["attention_mask"].to(device),
                macro=macro_tensor,
                country_id=country_tensor,
                year_id=year_tensor,
            ).logits
            probs = torch.softmax(logits, dim=-1)

        return (
            logits.detach().cpu().numpy(),
            probs.detach().cpu().numpy(),
        )

    def analyze_corpus(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        batch_size: int | None = None,
        top_k: int = 5,
        include_probabilities: bool = False,
        metadata: dict[str, Sequence[Any] | Any] | None = None,
    ) -> pd.DataFrame:
        if isinstance(texts, (str, bytes)):
            raise TypeError("texts must be a sequence of strings, not a single string.")

        texts = list(texts)
        if not texts:
            return pd.DataFrame()

        countries = [str(item) for item in _as_list(country, len(texts), name="country")]
        years = [int(item) for item in _as_list(year, len(texts), name="year")]
        prepared_rows = self._prepare_rows(texts, countries, years)

        rows: list[dict[str, Any]] = []
        batch_size = max(1, int(batch_size or self.batch_size))
        metadata = metadata or {}

        for start in range(0, len(prepared_rows), batch_size):
            chunk = prepared_rows[start:start + batch_size]
            logits, probs = self._forward_prepared_batch(chunk)
            for local_idx, (item, item_logits, item_probs) in enumerate(zip(chunk, logits, probs)):
                ranked_indices = item_probs.argsort()[::-1][: max(1, min(int(top_k), len(self.label_classes)))]
                top_idx = int(ranked_indices[0])
                cmp_code = int(self.label_classes[top_idx])
                row = {
                    "text": item["text"],
                    "country": item["country"],
                    "year": item["year"],
                    "top_cmp_code": cmp_code,
                    "top_cmp_title": CMP_CODE_TO_TITLE.get(cmp_code, "Unknown CMP code"),
                    "top_probability": float(item_probs[top_idx]),
                    "entropy": _probability_entropy(item_probs),
                    "confidence_margin": _top_margin(item_probs),
                }
                row["predictions"] = [
                    {
                        "rank": rank + 1,
                        "cmp_code": int(self.label_classes[idx]),
                        "cmp_title": CMP_CODE_TO_TITLE.get(int(self.label_classes[idx]), "Unknown CMP code"),
                        "probability": float(item_probs[idx]),
                        "logit": float(item_logits[idx]),
                    }
                    for rank, idx in enumerate(ranked_indices)
                ]
                if include_probabilities:
                    for idx, label in enumerate(self.label_classes):
                        row[f"p_{label}"] = float(item_probs[idx])
                global_idx = start + local_idx
                for key, value in metadata.items():
                    expanded = _as_list(value, len(texts), name=key)
                    row[key] = expanded[global_idx]
                rows.append(row)

        return pd.DataFrame(rows)

    def compute_topic_profile(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        batch_size: int | None = None,
        metadata: dict[str, Sequence[Any] | Any] | None = None,
        normalize: bool = True,
    ) -> pd.DataFrame:
        analysis = self.analyze_corpus(
            texts=texts,
            country=country,
            year=year,
            batch_size=batch_size,
            include_probabilities=True,
            metadata=metadata,
        )
        if analysis.empty:
            return pd.DataFrame()

        probability_cols = [f"p_{label}" for label in self.label_classes]
        profile = analysis[probability_cols].mean(axis=0).to_numpy(dtype=float)
        if normalize:
            profile = _safe_normalize(profile)

        rows = []
        for label, value in zip(self.label_classes, profile):
            cmp_code = int(label)
            rows.append(
                {
                    "cmp_code": cmp_code,
                    "cmp_title": CMP_CODE_TO_TITLE.get(cmp_code, "Unknown CMP code"),
                    "score": float(value),
                }
            )
        frame = pd.DataFrame(rows).sort_values("score", ascending=False).reset_index(drop=True)
        frame["rank"] = np.arange(1, len(frame) + 1)
        return frame

    def bootstrap_topic_profile(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        n_bootstrap: int = 250,
        ci: float = 0.95,
        random_state: int = 42,
        batch_size: int | None = None,
        metadata: dict[str, Sequence[Any] | Any] | None = None,
    ) -> pd.DataFrame:
        analysis = self.analyze_corpus(
            texts=texts,
            country=country,
            year=year,
            batch_size=batch_size,
            include_probabilities=True,
            metadata=metadata,
        )
        if analysis.empty:
            return pd.DataFrame()

        rng = np.random.default_rng(random_state)
        probability_cols = [f"p_{label}" for label in self.label_classes]
        matrix = analysis[probability_cols].to_numpy(dtype=float)
        samples = []
        for _ in range(int(n_bootstrap)):
            indices = rng.integers(0, len(matrix), size=len(matrix))
            profile = _safe_normalize(matrix[indices].mean(axis=0))
            samples.append(profile)
        bootstrap = np.vstack(samples)

        lower_q = (1.0 - ci) / 2.0
        upper_q = 1.0 - lower_q
        rows = []
        for idx, label in enumerate(self.label_classes):
            cmp_code = int(label)
            rows.append(
                {
                    "cmp_code": cmp_code,
                    "cmp_title": CMP_CODE_TO_TITLE.get(cmp_code, "Unknown CMP code"),
                    "mean_score": float(bootstrap[:, idx].mean()),
                    "ci_lower": float(np.quantile(bootstrap[:, idx], lower_q)),
                    "ci_upper": float(np.quantile(bootstrap[:, idx], upper_q)),
                }
            )
        return pd.DataFrame(rows).sort_values("mean_score", ascending=False).reset_index(drop=True)

    def compare_groups(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        group: Sequence[Any],
        batch_size: int | None = None,
    ) -> dict[str, pd.DataFrame]:
        analysis = self.analyze_corpus(
            texts=texts,
            country=country,
            year=year,
            batch_size=batch_size,
            include_probabilities=True,
            metadata={"group": group},
        )
        if analysis.empty:
            return {"group_summary": pd.DataFrame(), "pairwise_divergence": pd.DataFrame()}

        probability_cols = [f"p_{label}" for label in self.label_classes]
        summary_rows = []
        group_profiles: dict[Any, np.ndarray] = {}

        for group_name, group_df in analysis.groupby("group", dropna=False):
            profile = _safe_normalize(group_df[probability_cols].mean(axis=0).to_numpy(dtype=float))
            group_profiles[group_name] = profile
            top_idx = int(np.argmax(profile))
            cmp_code = int(self.label_classes[top_idx])
            summary_rows.append(
                {
                    "group": group_name,
                    "n_texts": int(len(group_df)),
                    "mean_entropy": float(group_df["entropy"].mean()),
                    "mean_confidence_margin": float(group_df["confidence_margin"].mean()),
                    "top_cmp_code": cmp_code,
                    "top_cmp_title": CMP_CODE_TO_TITLE.get(cmp_code, "Unknown CMP code"),
                    "top_cmp_score": float(profile[top_idx]),
                }
            )

        divergence_rows = []
        group_names = list(group_profiles.keys())
        for left in group_names:
            for right in group_names:
                divergence_rows.append(
                    {
                        "group_left": left,
                        "group_right": right,
                        "js_divergence": _jensen_shannon_divergence(group_profiles[left], group_profiles[right]),
                    }
                )

        return {
            "group_summary": pd.DataFrame(summary_rows).sort_values("group").reset_index(drop=True),
            "pairwise_divergence": pd.DataFrame(divergence_rows),
        }

    def compare_country_profiles(
        self,
        texts: Sequence[str],
        country: Sequence[str],
        year: int | Sequence[int],
        *,
        batch_size: int | None = None,
    ) -> dict[str, pd.DataFrame]:
        return self.compare_groups(
            texts=texts,
            country=country,
            year=year,
            group=country,
            batch_size=batch_size,
        )

    def panelize_country_year(
        self,
        texts: Sequence[str],
        country: Sequence[str],
        year: Sequence[int],
        *,
        batch_size: int | None = None,
        min_texts: int = 1,
    ) -> pd.DataFrame:
        analysis = self.analyze_corpus(
            texts=texts,
            country=country,
            year=year,
            batch_size=batch_size,
            include_probabilities=True,
        )
        if analysis.empty:
            return pd.DataFrame()

        probability_cols = [f"p_{label}" for label in self.label_classes]
        grouped = analysis.groupby(["country", "year"], dropna=False)
        rows: list[dict[str, Any]] = []
        for (country_name, year_value), group_df in grouped:
            if len(group_df) < min_texts:
                continue
            mean_profile = _safe_normalize(group_df[probability_cols].mean(axis=0).to_numpy(dtype=float))
            top_idx = int(np.argmax(mean_profile))
            top_cmp_code = int(self.label_classes[top_idx])
            row = {
                "country": country_name,
                "year": int(year_value),
                "n_texts": int(len(group_df)),
                "mean_entropy": float(group_df["entropy"].mean()),
                "mean_confidence_margin": float(group_df["confidence_margin"].mean()),
                "top_cmp_code": top_cmp_code,
                "top_cmp_title": CMP_CODE_TO_TITLE.get(top_cmp_code, "Unknown CMP code"),
                "top_cmp_score": float(mean_profile[top_idx]),
            }
            for idx, label in enumerate(self.label_classes):
                row[f"score_{label}"] = float(mean_profile[idx])
            rows.append(row)
        return pd.DataFrame(rows).sort_values(["country", "year"]).reset_index(drop=True)

    def export_methods_summary(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        batch_size: int | None = None,
        include_probabilities: bool = False,
    ) -> dict[str, Any]:
        analysis = self.analyze_corpus(
            texts=texts,
            country=country,
            year=year,
            batch_size=batch_size,
            include_probabilities=include_probabilities,
        )
        if analysis.empty:
            return {
                "sample": {},
                "prediction_quality": {},
                "coverage": {},
                "top_topics": [],
                "methods_text": "",
            }

        profile = self.compute_topic_profile(
            texts=texts,
            country=country,
            year=year,
            batch_size=batch_size,
        )
        top_topics = profile.head(10).to_dict(orient="records")
        summary = {
            "sample": {
                "n_texts": int(len(analysis)),
                "n_countries": int(analysis["country"].nunique()),
                "year_min": int(analysis["year"].min()),
                "year_max": int(analysis["year"].max()),
            },
            "prediction_quality": {
                "mean_entropy": float(analysis["entropy"].mean()),
                "median_entropy": float(analysis["entropy"].median()),
                "mean_confidence_margin": float(analysis["confidence_margin"].mean()),
                "median_confidence_margin": float(analysis["confidence_margin"].median()),
                "mean_top_probability": float(analysis["top_probability"].mean()),
            },
            "coverage": {
                "countries": sorted(str(v) for v in analysis["country"].unique()),
                "years": sorted(int(v) for v in analysis["year"].unique()),
            },
            "top_topics": top_topics,
        }
        summary["methods_text"] = (
            f"The analytical sample contains {summary['sample']['n_texts']} texts across "
            f"{summary['sample']['n_countries']} countries covering the period "
            f"{summary['sample']['year_min']}-{summary['sample']['year_max']}. "
            f"Sentence-level posterior distributions were generated with GBERT and aggregated "
            f"to corpus-level CMP profiles. The mean predictive entropy was "
            f"{summary['prediction_quality']['mean_entropy']:.4f}, and the mean top-class margin was "
            f"{summary['prediction_quality']['mean_confidence_margin']:.4f}."
        )
        return summary

    def plot_topic_heatmap(
        self,
        panel: pd.DataFrame,
        *,
        topics: Sequence[int | str] | None = None,
        index: str = "country",
        columns: str = "year",
        figsize: tuple[int, int] = (12, 7),
        title: str = "Topic Heatmap",
        cmap: str = "mako",
    ):
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
        except ImportError as exc:
            raise ImportError(
                "Plotting heatmaps requires `matplotlib` and `seaborn`."
            ) from exc

        if panel.empty:
            raise ValueError("panel must not be empty.")

        if topics is None:
            score_cols = [col for col in panel.columns if col.startswith("score_")]
            topic_col = max(score_cols, key=lambda col: float(panel[col].mean()))
            pivot = panel.pivot(index=index, columns=columns, values=topic_col)
            title = f"{title}: {topic_col.replace('score_', 'CMP ')}"
        else:
            cols = [f"score_{int(topic)}" for topic in topics]
            available = [col for col in cols if col in panel.columns]
            if not available:
                raise ValueError("No requested topics were found in panel.")
            melted = panel[[index, columns, *available]].melt(
                id_vars=[index, columns],
                var_name="topic",
                value_name="score",
            )
            melted["topic"] = melted["topic"].str.replace("score_", "CMP ", regex=False)
            pivot = melted.pivot_table(index="topic", columns=columns, values="score", aggfunc="mean")

        sns.set_theme(style="white", context="talk")
        fig, ax = plt.subplots(figsize=figsize)
        sns.heatmap(pivot, cmap=cmap, annot=False, linewidths=0.3, linecolor="white", ax=ax)
        ax.set_title(title, pad=14)
        fig.tight_layout()
        return fig, ax, pivot

    def plot_topic_ridgeplot(
        self,
        analysis: pd.DataFrame,
        *,
        topics: Sequence[int | str] | None = None,
        top_n: int = 6,
        figsize: tuple[int, int] = (10, 8),
        title: str = "Topic Distribution Ridgeplot",
    ):
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
        except ImportError as exc:
            raise ImportError(
                "Plotting ridgeplots requires `matplotlib` and `seaborn`."
            ) from exc

        if analysis.empty:
            raise ValueError("analysis must not be empty.")

        probability_cols = [col for col in analysis.columns if col.startswith("p_")]
        if topics is None:
            mean_scores = analysis[probability_cols].mean().sort_values(ascending=False).head(top_n)
            selected = [col.replace("p_", "") for col in mean_scores.index]
        else:
            selected = [str(int(topic)) for topic in topics]

        rows = []
        for topic in selected:
            col = f"p_{topic}"
            if col not in analysis.columns:
                continue
            rows.append(
                pd.DataFrame(
                    {
                        "probability": analysis[col].astype(float),
                        "topic": f"CMP {topic}: {CMP_CODE_TO_TITLE.get(int(topic), 'Unknown CMP code')}",
                    }
                )
            )
        if not rows:
            raise ValueError("No matching topic probability columns were found for ridgeplot.")
        ridge = pd.concat(rows, ignore_index=True)

        sns.set_theme(style="white", context="talk")
        g = sns.FacetGrid(ridge, row="topic", hue="topic", aspect=4, height=max(1.0, figsize[1] / max(len(rows), 1)))
        g.map(sns.kdeplot, "probability", fill=True, alpha=0.8, linewidth=1.2)
        g.map(sns.kdeplot, "probability", color="white", lw=1.0)
        g.fig.subplots_adjust(hspace=-0.45)
        g.set_titles(row_template="{row_name}")
        g.set(xlim=(0, 1), yticks=[], ylabel="")
        g.despine(bottom=False, left=True)
        g.fig.set_size_inches(*figsize)
        g.fig.suptitle(title, y=1.02)
        return g

    def plot_temporal_trends(
        self,
        panel: pd.DataFrame,
        *,
        topics: Sequence[int | str] | None = None,
        countries: Sequence[str] | None = None,
        top_n: int = 6,
        figsize: tuple[int, int] = (12, 7),
        title: str = "Temporal Topic Trends",
    ):
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
        except ImportError as exc:
            raise ImportError(
                "Plotting temporal trends requires `matplotlib` and `seaborn`."
            ) from exc

        if panel.empty:
            raise ValueError("panel must not be empty.")

        data = panel.copy()
        if countries is not None:
            data = data[data["country"].isin(list(countries))]
        if data.empty:
            raise ValueError("No rows left after filtering countries.")

        score_cols = [col for col in data.columns if col.startswith("score_")]
        if topics is None:
            selected_cols = data[score_cols].mean().sort_values(ascending=False).head(top_n).index.tolist()
        else:
            selected_cols = [f"score_{int(topic)}" for topic in topics if f"score_{int(topic)}" in data.columns]
        if not selected_cols:
            raise ValueError("No matching topic columns were found for temporal trends.")
        melted = data[["country", "year", *selected_cols]].melt(
            id_vars=["country", "year"],
            var_name="topic",
            value_name="score",
        )
        melted["topic"] = melted["topic"].str.replace("score_", "CMP ", regex=False)

        sns.set_theme(style="whitegrid", context="talk")
        fig, ax = plt.subplots(figsize=figsize)
        sns.lineplot(
            data=melted,
            x="year",
            y="score",
            hue="topic",
            style="country",
            markers=True,
            dashes=False,
            ax=ax,
        )
        ax.set_title(title, pad=14)
        ax.set_xlabel("Year")
        ax.set_ylabel("Mean Topic Score")
        ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False, fontsize=9)
        fig.tight_layout()
        return fig, ax, melted

    def predict(
        self,
        text: str,
        country: str,
        year: int,
        *,
        top_k: int = 5,
    ) -> dict[str, Any]:
        return self._predict_batch_internal(
            texts=[text],
            countries=[country],
            years=[int(year)],
            top_k=top_k,
            batch_size=1,
        )[0]

    def predict_batch(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        top_k: int = 5,
        batch_size: int | None = None,
        return_df: bool = False,
    ) -> list[dict[str, Any]] | pd.DataFrame:
        if isinstance(texts, (str, bytes)):
            raise TypeError("texts must be a sequence of strings, not a single string.")

        texts = list(texts)
        if not texts:
            return pd.DataFrame() if return_df else []

        countries = [str(item) for item in _as_list(country, len(texts), name="country")]
        years = [int(item) for item in _as_list(year, len(texts), name="year")]
        results = self._predict_batch_internal(
            texts=texts,
            countries=countries,
            years=years,
            top_k=top_k,
            batch_size=batch_size or self.batch_size,
        )
        if not return_df:
            return results

        flat_rows: list[dict[str, Any]] = []
        for result in results:
            best_prediction = result["predictions"][0]
            flat_rows.append(
                {
                    "text": result["text"],
                    "country": result["country"],
                    "year": result["year"],
                    "label": best_prediction["label"],
                    "probability": best_prediction["probability"],
                    "predictions": result["predictions"],
                }
            )
        return pd.DataFrame(flat_rows)

    def project_umap(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        representation: str = "logits",
        batch_size: int | None = None,
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        metric: str = "cosine",
        random_state: int = 42,
        metadata: dict[str, Sequence[Any] | Any] | None = None,
        return_df: bool = True,
    ) -> pd.DataFrame | dict[str, Any]:
        if isinstance(texts, (str, bytes)):
            raise TypeError("texts must be a sequence of strings, not a single string.")

        texts = list(texts)
        if not texts:
            return pd.DataFrame() if return_df else {"data": [], "embedding_shape": [0, 0], "representation": representation}
        countries = [str(item) for item in _as_list(country, len(texts), name="country")]
        years = [int(item) for item in _as_list(year, len(texts), name="year")]

        prepared_rows = self._prepare_rows(texts, countries, years)
        metadata = metadata or {}

        embeddings: list[np.ndarray] = []
        batch_size = max(1, int(batch_size or self.batch_size))
        for start in range(0, len(prepared_rows), batch_size):
            chunk = prepared_rows[start:start + batch_size]
            logits, probs = self._forward_prepared_batch(chunk)
            if representation == "logits":
                embeddings.append(logits)
            elif representation == "probabilities":
                embeddings.append(probs)
            else:
                raise ValueError("representation must be 'logits' or 'probabilities'.")

        matrix = np.concatenate(embeddings, axis=0)

        try:
            import umap
        except ImportError as exc:
            raise ImportError(
                "UMAP support requires `umap-learn`. Install it with `pip install umap-learn`."
            ) from exc

        reducer = umap.UMAP(
            n_components=2,
            n_neighbors=n_neighbors,
            min_dist=min_dist,
            metric=metric,
            random_state=random_state,
        )
        coords = reducer.fit_transform(matrix)

        rows: list[dict[str, Any]] = []
        for item, vec, xy in zip(prepared_rows, matrix, coords):
            top_idx = int(np.argmax(vec))
            cmp_code = int(self.label_classes[top_idx])
            row = {
                "text": item["text"],
                "country": item["country"],
                "year": item["year"],
                "umap_x": float(xy[0]),
                "umap_y": float(xy[1]),
                "top_cmp_code": cmp_code,
                "top_cmp_title": CMP_CODE_TO_TITLE.get(cmp_code, "Unknown CMP code"),
            }
            row["country_year"] = f"{item['country']} ({item['year']})"
            for key, value in metadata.items():
                expanded = _as_list(value, len(texts), name=key)
                row[key] = expanded[len(rows)]
            rows.append(row)

        frame = pd.DataFrame(rows)
        if return_df:
            return frame
        return {
            "data": frame.to_dict(orient="records"),
            "embedding_shape": list(matrix.shape),
            "representation": representation,
        }

    def plot_umap(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        representation: str = "logits",
        batch_size: int | None = None,
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        metric: str = "cosine",
        random_state: int = 42,
        metadata: dict[str, Sequence[Any] | Any] | None = None,
        color_by: str = "country",
        style_by: str = "top_cmp_title",
        size_by: str | None = None,
        annotate: bool = False,
        annotate_by: str = "top_cmp_code",
        add_centroids: bool = True,
        palette: str = "deep",
        figsize: tuple[int, int] = (11, 8),
    ):
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
        except ImportError as exc:
            raise ImportError(
                "Plotting UMAP requires `matplotlib` and `seaborn`. Install them with `pip install matplotlib seaborn`."
            ) from exc

        frame = self.project_umap(
            texts=texts,
            country=country,
            year=year,
            representation=representation,
            batch_size=batch_size,
            n_neighbors=n_neighbors,
            min_dist=min_dist,
            metric=metric,
            random_state=random_state,
            metadata=metadata,
            return_df=True,
        )

        sns.set_theme(style="whitegrid", context="talk")
        fig, ax = plt.subplots(figsize=figsize)
        sns.scatterplot(
            data=frame,
            x="umap_x",
            y="umap_y",
            hue=color_by,
            style=style_by,
            size=size_by,
            palette=palette,
            alpha=0.82,
            edgecolor="white",
            linewidth=0.4,
            ax=ax,
        )

        if add_centroids:
            centroids = frame.groupby(color_by, dropna=False)[["umap_x", "umap_y"]].mean().reset_index()
            sns.scatterplot(
                data=centroids,
                x="umap_x",
                y="umap_y",
                hue=color_by,
                palette=palette,
                s=260,
                marker="X",
                edgecolor="black",
                linewidth=0.8,
                legend=False,
                ax=ax,
            )

        if annotate:
            for _, row in frame.iterrows():
                ax.text(row["umap_x"], row["umap_y"], str(row.get(annotate_by, "")), fontsize=8, alpha=0.9)

        ax.set_title("GBERT UMAP Comparison", pad=14)
        ax.set_xlabel("UMAP-1")
        ax.set_ylabel("UMAP-2")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False, fontsize=9)
        fig.tight_layout()
        return fig, ax, frame

    def plot_topic_profile(
        self,
        profile: pd.DataFrame,
        *,
        top_n: int = 15,
        value_col: str = "score",
        title: str = "Topic Profile",
        figsize: tuple[int, int] = (10, 6),
    ):
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
        except ImportError as exc:
            raise ImportError(
                "Plotting topic profiles requires `matplotlib` and `seaborn`."
            ) from exc

        data = profile.sort_values(value_col, ascending=False).head(top_n).iloc[::-1]
        sns.set_theme(style="whitegrid", context="talk")
        fig, ax = plt.subplots(figsize=figsize)
        sns.barplot(data=data, x=value_col, y="cmp_title", palette="crest", ax=ax)
        ax.set_title(title, pad=14)
        ax.set_xlabel(value_col.replace("_", " ").title())
        ax.set_ylabel("")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        fig.tight_layout()
        return fig, ax

    def plot_group_divergence(
        self,
        divergence: pd.DataFrame,
        *,
        figsize: tuple[int, int] = (8, 6),
        title: str = "Pairwise Jensen-Shannon Divergence",
    ):
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
        except ImportError as exc:
            raise ImportError(
                "Plotting divergence requires `matplotlib` and `seaborn`."
            ) from exc

        matrix = divergence.pivot(index="group_left", columns="group_right", values="js_divergence")
        sns.set_theme(style="white", context="talk")
        fig, ax = plt.subplots(figsize=figsize)
        sns.heatmap(matrix, annot=True, fmt=".3f", cmap="mako", square=True, cbar=True, ax=ax)
        ax.set_title(title, pad=14)
        fig.tight_layout()
        return fig, ax, matrix


def load_default_model(**kwargs: Any) -> GbertClassifier:
    return GbertClassifier(**kwargs)


def predict(
    text: str,
    country: str,
    year: int,
    *,
    top_k: int = 5,
    model: GbertClassifier | None = None,
    **model_kwargs: Any,
) -> dict[str, Any]:
    classifier = model or GbertClassifier(**model_kwargs)
    return classifier.predict(text=text, country=country, year=year, top_k=top_k)


def predict_batch(
    texts: Sequence[str],
    country: str | Sequence[str],
    year: int | Sequence[int],
    *,
    top_k: int = 5,
    batch_size: int | None = None,
    return_df: bool = False,
    model: GbertClassifier | None = None,
    **model_kwargs: Any,
) -> list[dict[str, Any]] | pd.DataFrame:
    classifier = model or GbertClassifier(**model_kwargs)
    return classifier.predict_batch(
        texts=texts,
        country=country,
        year=year,
        top_k=top_k,
        batch_size=batch_size,
        return_df=return_df,
    )


def project_umap(
    texts: Sequence[str],
    country: str | Sequence[str],
    year: int | Sequence[int],
    *,
    model: GbertClassifier | None = None,
    model_kwargs: dict[str, Any] | None = None,
    **kwargs: Any,
):
    classifier = model or GbertClassifier(**(model_kwargs or {}))
    return classifier.project_umap(texts=texts, country=country, year=year, **kwargs)


def analyze_corpus(
    texts: Sequence[str],
    country: str | Sequence[str],
    year: int | Sequence[int],
    *,
    model: GbertClassifier | None = None,
    model_kwargs: dict[str, Any] | None = None,
    **kwargs: Any,
):
    classifier = model or GbertClassifier(**(model_kwargs or {}))
    return classifier.analyze_corpus(texts=texts, country=country, year=year, **kwargs)


def compute_topic_profile(
    texts: Sequence[str],
    country: str | Sequence[str],
    year: int | Sequence[int],
    *,
    model: GbertClassifier | None = None,
    model_kwargs: dict[str, Any] | None = None,
    **kwargs: Any,
):
    classifier = model or GbertClassifier(**(model_kwargs or {}))
    return classifier.compute_topic_profile(texts=texts, country=country, year=year, **kwargs)


def panelize_country_year(
    texts: Sequence[str],
    country: Sequence[str],
    year: Sequence[int],
    *,
    model: GbertClassifier | None = None,
    model_kwargs: dict[str, Any] | None = None,
    **kwargs: Any,
):
    classifier = model or GbertClassifier(**(model_kwargs or {}))
    return classifier.panelize_country_year(texts=texts, country=country, year=year, **kwargs)
