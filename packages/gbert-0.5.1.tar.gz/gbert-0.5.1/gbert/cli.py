from __future__ import annotations

import argparse
import json

from .service import GbertClassifier


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run GBERT text analysis.")
    parser.add_argument("--text", required=True, help="Input text to analyze.")
    parser.add_argument("--country", required=True, help="Country name.")
    parser.add_argument("--year", required=True, type=int, help="Year to use for macro lookup.")
    parser.add_argument("--top-k", default=5, type=int, help="How many labels to return.")
    parser.add_argument("--model-path", help="Optional local model weights path.")
    parser.add_argument("--model-repo-id", help="Optional Hugging Face model repo.")
    parser.add_argument("--model-filename", default="causal_nam_best.pt", help="Model file name.")
    parser.add_argument("--hf-token", help="Optional Hugging Face token.")
    parser.add_argument("--device", help="cpu, cuda, or auto.")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    classifier = GbertClassifier(
        model_path=args.model_path,
        model_repo_id=args.model_repo_id,
        model_filename=args.model_filename,
        hf_token=args.hf_token,
        device=args.device,
    )
    result = classifier.predict(
        text=args.text,
        country=args.country,
        year=args.year,
        top_k=args.top_k,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
