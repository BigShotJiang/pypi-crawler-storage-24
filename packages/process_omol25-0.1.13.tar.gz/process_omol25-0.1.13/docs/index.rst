.. process_omol25 documentation master file, created by
   sphinx-quickstart on Sat Mar 21 08:10:34 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

process_omol25 documentation
============================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api
