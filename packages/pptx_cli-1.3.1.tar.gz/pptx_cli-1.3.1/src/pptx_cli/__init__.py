"""pptx_cli package."""

__all__ = ["__version__"]

__version__ = "1.3.1"
