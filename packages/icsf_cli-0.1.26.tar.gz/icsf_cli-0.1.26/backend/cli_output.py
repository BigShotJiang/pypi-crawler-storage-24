"""
cli_output.py

Rich, user-friendly terminal output for the ICSF CLI.
Provides coloured banners, step headers, progress spinners, and summary tables
without requiring any third-party libraries beyond the standard library.
"""

from __future__ import annotations

import os
import sys
import time
import threading
from typing import Optional, List, Dict, Any

# ── ANSI colour helpers ─────────────────────────────────────────────────────

def _supports_color() -> bool:
    """Return True if the terminal supports ANSI colour codes."""
    # Respect NO_COLOR and TERM=dumb conventions
    if os.environ.get("NO_COLOR") or os.environ.get("TERM") == "dumb":
        return False
    # Windows: colour works in Windows Terminal / VS Code; check ANSICON or WT_SESSION
    if sys.platform == "win32":
        return (
            os.environ.get("ANSICON") is not None
            or os.environ.get("WT_SESSION") is not None
            or os.environ.get("COLORTERM") is not None
            or "VSCODE_PID" in os.environ
        )
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


_COLOR = _supports_color()

_RESET  = "\033[0m"  if _COLOR else ""
_BOLD   = "\033[1m"  if _COLOR else ""
_DIM    = "\033[2m"  if _COLOR else ""

# Foreground colours
_CYAN   = "\033[36m" if _COLOR else ""
_GREEN  = "\033[32m" if _COLOR else ""
_YELLOW = "\033[33m" if _COLOR else ""
_RED    = "\033[31m" if _COLOR else ""
_WHITE  = "\033[97m" if _COLOR else ""
_BLUE   = "\033[34m" if _COLOR else ""
_MAGENTA= "\033[35m" if _COLOR else ""

# Background colours (for the top banner)
_BG_BLUE   = "\033[44m" if _COLOR else ""
_BG_CYAN   = "\033[46m" if _COLOR else ""


def c(text: str, *codes: str) -> str:
    """Wrap text with ANSI codes."""
    if not _COLOR or not codes:
        return text
    return "".join(codes) + text + _RESET


# ── Layout constants ────────────────────────────────────────────────────────

WIDTH = 78  # terminal width to fill


def _line(char: str = "─", col: str = _DIM) -> str:
    return c(char * WIDTH, col)


def _center(text: str, width: int = WIDTH) -> str:
    """Center text (strip ANSI codes for width calc)."""
    import re
    ansi_escape = re.compile(r"\033\[[0-9;]*m")
    visible = ansi_escape.sub("", text)
    pad = max(0, width - len(visible))
    left = pad // 2
    right = pad - left
    return " " * left + text + " " * right


# ── Public API ──────────────────────────────────────────────────────────────

def print_banner() -> None:
    """Print the ICSF CLI welcome banner."""
    print()
    print(c("┌" + "─" * (WIDTH - 2) + "┐", _CYAN, _BOLD))
    print(c("│", _CYAN, _BOLD) + _center(c("  ICSF  —  Intelligent Code Security & Fixing Platform", _WHITE, _BOLD)) + c("│", _CYAN, _BOLD))
    print(c("│", _CYAN, _BOLD) + _center(c("  CLI  ·  Automated Vulnerability Remediation", _DIM)) + c("│", _CYAN, _BOLD))
    print(c("└" + "─" * (WIDTH - 2) + "┘", _CYAN, _BOLD))
    print()


def print_section(title: str, emoji: str = "") -> None:
    """Print a top-level section header."""
    label = f"  {emoji}  {title}  " if emoji else f"  {title}  "
    print()
    print(_line("═", _CYAN))
    print(c(f"{_BOLD}{label}", _CYAN, _BOLD))
    print(_line("═", _CYAN))


def print_step(title: str, emoji: str = "▶") -> None:
    """Print a sub-step header."""
    print()
    print(_line("─", _DIM))
    print(c(f"  {emoji}  {title}", _YELLOW, _BOLD))
    print(_line("─", _DIM))


def print_ok(msg: str) -> None:
    print(c(f"  ✔  {msg}", _GREEN, _BOLD))


def print_warn(msg: str) -> None:
    print(c(f"  ⚠  {msg}", _YELLOW))


def print_error(msg: str) -> None:
    print(c(f"  ✖  {msg}", _RED, _BOLD))


def print_info(msg: str, indent: int = 2) -> None:
    prefix = " " * indent
    print(f"{prefix}{c('·', _DIM)} {msg}")


def print_kv(key: str, value: str, width: int = 26) -> None:
    """Print a key: value pair with aligned columns."""
    padded = key.ljust(width)
    print(f"  {c(padded, _DIM)}  {c(str(value), _WHITE)}")


# ── Progress spinner ────────────────────────────────────────────────────────

class Spinner:
    """
    Simple terminal spinner for long-running tasks.

    Usage:
        with Spinner("Cloning repository..."):
            do_long_work()
    """
    _FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, message: str, interval: float = 0.1):
        self.message = message
        self.interval = interval
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def _spin(self) -> None:
        idx = 0
        while not self._stop_event.is_set():
            frame = self._FRAMES[idx % len(self._FRAMES)]
            # Only animate when stdout is a real terminal
            if hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
                sys.stdout.write(f"\r  {c(frame, _CYAN)}  {self.message} ")
                sys.stdout.flush()
            time.sleep(self.interval)
            idx += 1

    def start(self) -> "Spinner":
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def stop(self, ok: bool = True) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join()
        if hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
            sys.stdout.write("\r" + " " * (WIDTH) + "\r")
            sys.stdout.flush()
        icon = c("✔", _GREEN, _BOLD) if ok else c("✖", _RED, _BOLD)
        print(f"  {icon}  {self.message}")

    def __enter__(self) -> "Spinner":
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.stop(ok=(exc_type is None))


# ── Vulnerability table ─────────────────────────────────────────────────────

_SEV_COLORS = {
    "critical": _RED,
    "high": _RED,
    "medium": _YELLOW,
    "low": _GREEN,
    "info": _DIM,
}


def print_vuln_table(vulnerabilities: List[Dict[str, Any]], repo_name: str) -> None:
    """Print a compact table of vulnerabilities for a repository."""
    if not vulnerabilities:
        return
    print()
    header = f"  Vulnerabilities mapped for  {c(repo_name, _CYAN, _BOLD)}"
    print(header)
    print(_line("─", _DIM))
    col_sev   = 10
    col_file  = 42
    col_line  = 6

    hdr = (
        c("  Severity".ljust(col_sev + 2), _DIM)
        + c("File".ljust(col_file), _DIM)
        + c("Line".rjust(col_line), _DIM)
    )
    print(hdr)
    print(_line("─", _DIM))

    for v in vulnerabilities:
        sev_raw = (v.get("severity") or "unknown").lower()
        sev_col = _SEV_COLORS.get(sev_raw, _WHITE)
        sev_str = sev_raw.upper().ljust(col_sev)
        file_str = str(
            v.get("matched_file_path") or v.get("file_path") or "N/A"
        )
        # Trim long file paths from left
        if len(file_str) > col_file - 2:
            file_str = "…" + file_str[-(col_file - 3):]
        file_str = file_str.ljust(col_file)
        line_str = str(v.get("line_no") or "").rjust(col_line)
        row = (
            "  " + c(sev_str, sev_col, _BOLD)
            + c(file_str, _WHITE)
            + c(line_str, _DIM)
        )
        print(row)
    print(_line("─", _DIM))
    total = len(vulnerabilities)
    fixable = sum(1 for v in vulnerabilities if v.get("file_found") and v.get("matched_file_path"))
    print_info(f"Total: {total}  ·  Fixable: {fixable}  ·  Skipped: {total - fixable}")


# ── Fix progress ────────────────────────────────────────────────────────────

def print_fix_start(idx: int, total: int, vuln: Dict[str, Any]) -> None:
    vuln_type = vuln.get("vulnerability", "Unknown")
    file_path = vuln.get("matched_file_path") or vuln.get("file_path") or "N/A"
    short_file = os.path.basename(file_path) if file_path != "N/A" else "N/A"
    sev_raw = (vuln.get("severity") or "unknown").lower()
    sev_col = _SEV_COLORS.get(sev_raw, _WHITE)
    sev_label = c(sev_raw.upper(), sev_col, _BOLD)
    print()
    print(
        c(f"  [{idx}/{total}]", _DIM)
        + " " + c(vuln_type, _YELLOW, _BOLD)
        + "  " + sev_label
        + "  " + c(f"({short_file})", _DIM)
    )


def print_fix_result(success: bool, vuln_type: str, duration: float) -> None:
    dur = f"{duration:.1f}s"
    if success:
        print_ok(f"{vuln_type}  ·  fixed in {c(dur, _DIM)}")
    else:
        print_error(f"{vuln_type}  ·  failed after {c(dur, _DIM)}")


# ── Build verification ──────────────────────────────────────────────────────

def print_build_status(ok: bool, retries: int = 0, auto_fixed: bool = False) -> None:
    if ok:
        if auto_fixed:
            print_ok(f"Build passed  (auto-repaired in {retries} attempt{'s' if retries != 1 else ''})")
        else:
            print_ok("Build passed")
    else:
        print_error("Build FAILED after all auto-repair attempts")
        print_warn("  PR will still be created with best-effort fixes — review manually.")


# ── Summary table ───────────────────────────────────────────────────────────

def print_final_summary(
    summary: Dict[str, Any],
    auto_pr: bool,
    duration_secs: float,
) -> None:
    """Print the final end-of-run summary box."""
    results = summary.get("results", []) or []
    total_repos = summary.get("total_repos_with_vulns", 0)
    processed   = summary.get("total_repos_processed", 0)

    print()
    print(c("╔" + "═" * (WIDTH - 2) + "╗", _CYAN, _BOLD))
    print(c("║", _CYAN, _BOLD) + _center(c("  🎉  ICSF CLI  —  Run Complete", _WHITE, _BOLD)) + c("║", _CYAN, _BOLD))
    print(c("╠" + "═" * (WIDTH - 2) + "╣", _CYAN, _BOLD))

    def _row(label: str, value: str) -> None:
        label_col = c(f"  {label.ljust(30)}", _DIM)
        val_col   = c(value, _WHITE, _BOLD)
        padding   = " " * max(0, WIDTH - 2 - 32 - len(value))
        print(c("║", _CYAN, _BOLD) + label_col + val_col + padding + c("║", _CYAN, _BOLD))

    _row("Repos with vulnerabilities:", str(total_repos))
    _row("Repos processed:", str(processed))

    mins, secs = divmod(int(duration_secs), 60)
    dur_str = f"{mins}m {secs}s" if mins else f"{secs}s"
    _row("Total duration:", dur_str)

    print(c("╠" + "═" * (WIDTH - 2) + "╣", _CYAN, _BOLD))

    pr_lines: List[str] = []
    for repo_result in results:
        repo = repo_result.get("repo", {}) or {}
        full_name = repo.get("full_name") or repo.get("name") or "unknown"
        batch_results = repo_result.get("batch_results") or {}

        successful = batch_results.get("successful", 0)
        failed     = batch_results.get("failed", 0)
        skipped    = batch_results.get("skipped", 0)
        build_ok   = (batch_results.get("build_verification") or {}).get("build_ok")

        build_icon = (c("✔ build", _GREEN) if build_ok else c("✖ build", _RED)) if build_ok is not None else ""
        fix_str = c(f"✔ {successful}", _GREEN) + (f"  {c(f'✖ {failed}', _RED)}" if failed else "") + (f"  {c(f'⏭ {skipped}', _DIM)}" if skipped else "")

        batch_pr = batch_results.get("batch_pr_result") or {}
        if auto_pr and batch_pr.get("success"):
            pr_url = batch_pr.get("pr_url", "N/A")
            pr_num = batch_pr.get("pr_number", "N/A")
            pr_str = c(f"PR #{pr_num}", _GREEN, _BOLD) + c(f"  →  {pr_url}", _DIM)
            pr_lines.append(f"  {c(full_name, _WHITE, _BOLD)}  ·  Fixes: {fix_str}  ·  {build_icon}  ·  {pr_str}")
        else:
            pr_lines.append(f"  {c(full_name, _WHITE, _BOLD)}  ·  Fixes: {fix_str}  ·  {build_icon}")

    for line in pr_lines:
        import re
        ansi_escape = re.compile(r"\033\[[0-9;]*m")
        visible_len = len(ansi_escape.sub("", line))
        pad = max(0, WIDTH - 2 - visible_len)
        print(c("║", _CYAN, _BOLD) + line + " " * pad + c("║", _CYAN, _BOLD))

    print(c("╚" + "═" * (WIDTH - 2) + "╝", _CYAN, _BOLD))
    print()
