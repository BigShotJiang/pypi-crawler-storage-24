"""
ICSF Command-Line Interface entrypoint.

This module exposes a small CLI wrapper around the core `cli_api` helpers.
Users install the package and then run:

    icsf run --credentials backend/credentials.yaml --csv report.csv --auto-pr --run-tests

to execute an end-to-end flow that mirrors the web application:
mapping → baseline testing → fixing → validation testing → PR creation.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
import time
from pathlib import Path
from typing import Optional

from . import cli_api
from .cli_output import (
    Spinner,
    print_banner,
    print_build_status,
    print_error,
    print_final_summary,
    print_fix_result,
    print_fix_start,
    print_info,
    print_kv,
    print_ok,
    print_section,
    print_step,
    print_vuln_table,
    print_warn,
    c,
    _CYAN, _DIM, _GREEN, _RED, _YELLOW, _WHITE, _BOLD,
)


# ── Logging setup ────────────────────────────────────────────────────────────

class _CliLogFormatter(logging.Formatter):
    """
    Compact formatter for CLI output.

    - Strips the logger name prefix (too noisy for users)
    - Colours by level
    - Suppresses internal botocore / urllib3 / httpx chatter unless verbose
    """

    _LEVEL_STYLES = {
        logging.DEBUG:    ("\033[2m", "DEBUG"),
        logging.INFO:     ("\033[36m", " INFO"),
        logging.WARNING:  ("\033[33m", " WARN"),
        logging.ERROR:    ("\033[31m", "ERROR"),
        logging.CRITICAL: ("\033[35m", "CRIT "),
    }

    _RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:  # noqa: D102
        from .cli_output import _COLOR
        col, tag = self._LEVEL_STYLES.get(record.levelno, ("", " INFO"))
        msg = record.getMessage()
        if _COLOR:
            prefix = f"{col}[{tag}]{self._RESET}"
        else:
            prefix = f"[{tag}]"
        return f"  {prefix}  {msg}"


_NOISY_LOGGERS = [
    "botocore",
    "boto3",
    "urllib3",
    "httpx",
    "httpcore",
    "git",
    "charset_normalizer",
    "asyncio",
]


def _configure_logging(verbose: bool) -> None:
    """
    Configure logging for CLI use:
    - User-level messages (INFO+) shown with pretty formatter
    - Internal library noise suppressed unless --verbose
    """
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)

    # Remove any handlers already attached (e.g. by basicConfig elsewhere)
    root.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(_CliLogFormatter())
    handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    root.addHandler(handler)

    # Quiet down noisy library loggers
    suppress_level = logging.DEBUG if verbose else logging.WARNING
    for name in _NOISY_LOGGERS:
        logging.getLogger(name).setLevel(suppress_level)


# ── Argument parser ──────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="icsf",
        description="ICSF – Intelligent Code Security & Fixing Platform (CLI)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  icsf run --credentials creds.yaml --csv vulns.csv --auto-pr\n"
            "  icsf run --credentials creds.yaml --csv vulns.csv --no-run-tests\n"
            "  icsf run --credentials creds.yaml --csv vulns.csv --repo-filter myapp\n"
        ),
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── run command ──────────────────────────────────────────────────────────
    run_parser = subparsers.add_parser(
        "run",
        help="Run end-to-end mapping, fixing, testing, and PR creation.",
        description="Map vulnerability CSV → fix code → validate build → create PR",
    )
    run_parser.add_argument(
        "--credentials",
        type=str,
        default=None,
        help=(
            "Path to credentials YAML containing GitHub token/username/email. "
            "If omitted, backend/credentials.yaml is used."
        ),
    )
    run_parser.add_argument(
        "--env",
        type=str,
        default=None,
        help=(
            "Path to .env file for AWS (Bedrock) and other env vars. "
            "If omitted, .env in the same directory as --credentials is loaded when present."
        ),
    )
    run_parser.add_argument(
        "--csv",
        type=str,
        required=True,
        help="Path to vulnerability CSV report.",
    )
    run_parser.add_argument(
        "--auto-pr",
        action="store_true",
        help="Automatically create a single batch PR per repository.",
    )
    run_parser.add_argument(
        "--no-auto-pr",
        dest="auto_pr",
        action="store_false",
        help="Do not create PRs (default).",
    )
    run_parser.set_defaults(auto_pr=False)

    run_parser.add_argument(
        "--run-tests",
        action="store_true",
        help="Run baseline + validation testing via Atlas (default: on).",
    )
    run_parser.add_argument(
        "--no-run-tests",
        dest="run_tests",
        action="store_false",
        help="Skip all testing (baseline & validation).",
    )
    run_parser.set_defaults(run_tests=True)

    run_parser.add_argument(
        "--repo-filter",
        type=str,
        default=None,
        help=(
            "Only process repositories whose name or full_name contains this "
            "substring (case-insensitive)."
        ),
    )
    run_parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Optional path to write a full JSON report of the run.",
    )
    run_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging (shows internal debug messages).",
    )

    return parser


# ── Command handler ──────────────────────────────────────────────────────────

def _handle_run(args: argparse.Namespace) -> int:
    _configure_logging(verbose=args.verbose)

    run_start = time.time()

    print_banner()

    # ── Resolve paths ────────────────────────────────────────────────────────
    credentials_path: Optional[Path]
    if args.credentials:
        credentials_path = Path(args.credentials).resolve()
    else:
        credentials_path = Path(__file__).resolve().parent / "credentials.yaml"

    env_path: Optional[Path] = None
    if getattr(args, "env", None):
        env_path = Path(args.env).resolve()
        if not env_path.exists():
            print_error(f"Env file not found: {env_path}")
            return 1

    csv_path = Path(args.csv).resolve()
    if not csv_path.exists():
        print_error(f"CSV file not found: {csv_path}")
        return 1

    # ── Configuration summary ────────────────────────────────────────────────
    print_section("Configuration", "⚙️")
    print_kv("Credentials file", str(credentials_path))
    print_kv("Vulnerability CSV", str(csv_path))
    if env_path:
        print_kv("Env override file", str(env_path))
    print_kv("Auto-PR creation", "Yes ✔" if args.auto_pr else "No")
    print_kv("Run tests (Atlas)", "Yes ✔" if args.run_tests else "No (--no-run-tests)")
    if args.repo_filter:
        print_kv("Repo filter", args.repo_filter)
    if args.verbose:
        print_kv("Verbose logging", "On")
    print()

    # ── Async runner ─────────────────────────────────────────────────────────
    async def _run() -> int:
        # Phase 1: Credentials + GitHub auth
        print_section("Phase 1 — GitHub Authentication", "🔑")
        try:
            with Spinner("Verifying GitHub token…"):
                token, username, email = cli_api.load_github_credentials_from_file(
                    credentials_path
                )
            print_ok(f"Authenticated as  {c(username or email or 'unknown', _CYAN, _BOLD)}")
        except Exception as exc:
            print_error(f"GitHub authentication failed: {exc}")
            return 1

        # Phase 2: Fetch repositories
        print_section("Phase 2 — Repository Discovery", "🔍")
        try:
            with Spinner("Fetching repositories from GitHub…"):
                repos = await cli_api.fetch_repositories_for_cli(token, username, email)
            print_ok(f"Found {c(str(len(repos)), _WHITE, _BOLD)} repositories")
        except Exception as exc:
            print_error(f"Repository fetch failed: {exc}")
            return 1

        # Phase 3: Map vulnerabilities from CSV
        print_section("Phase 3 — Vulnerability Mapping", "🗺️")
        try:
            with Spinner(f"Mapping vulnerabilities from  {csv_path.name}…"):
                mapping = cli_api.map_vulnerabilities_from_csv_for_cli(csv_path, repos)
        except Exception as exc:
            print_error(f"CSV mapping failed: {exc}")
            return 1

        total_mapped   = mapping.get("total_mapped", 0)
        total_unmapped = mapping.get("total_unmatched", 0)
        print_ok(f"Mapped {c(str(total_mapped), _WHITE, _BOLD)} repositories with vulnerability hits")
        if total_unmapped:
            print_warn(f"{total_unmapped} vulnerabilities could not be matched to a repository file")

        if total_mapped == 0:
            print_warn("No actionable vulnerabilities found — nothing to fix.")
            return 0

        # Phase 4: Per-repo pipeline
        mapped = mapping.get("mapped_vulnerabilities", {})

        repo_id_to_repo = {int(r["id"]): r for r in repos if "id" in r}

        def _repo_matches(repo_dict):
            if not args.repo_filter:
                return True
            name = (repo_dict.get("name") or "").lower()
            full = (repo_dict.get("full_name") or "").lower()
            return args.repo_filter.lower() in name or args.repo_filter.lower() in full

        end_to_end_results = []
        total_fixable_repos = 0

        for repo_id_str, payload in mapped.items():
            try:
                repo_id = int(repo_id_str)
            except ValueError:
                continue

            repo = repo_id_to_repo.get(repo_id) or payload.get("repo")
            if not repo or not _repo_matches(repo):
                continue

            vulnerabilities = payload.get("vulnerabilities", [])
            if not vulnerabilities:
                continue

            total_fixable_repos += 1
            full_name = repo.get("full_name") or repo.get("name") or "unknown"

            print_section(f"Repo: {full_name}", "📦")

            # Show vulnerability table
            print_vuln_table(vulnerabilities, full_name)

            # Clone / update repo
            print_step("Cloning repository", "📥")
            try:
                backend_root = Path(__file__).resolve().parent
                with Spinner(f"Cloning {full_name}…"):
                    repo_path = cli_api._ensure_repo_cloned_for_cli(repo, token, backend_root)
                print_ok(f"Repository ready at  {c(str(repo_path), _DIM)}")
            except Exception as exc:
                print_error(f"Clone failed: {exc}")
                continue

            # Baseline testing
            if args.run_tests:
                print_step("Baseline Testing (before fix)", "📊")
                print_info("Running build + existing tests (no AI) …")

            # Run per-vulnerability fixes
            print_step(f"Applying Fixes  ({len(vulnerabilities)} vulnerabilities)", "🤖")
            print_info("← 6-agent pipeline: Analyzer → Context → Strategy → Fix → Validator → Explanation")
            print()

            fixable = [v for v in vulnerabilities if v.get("file_found") and v.get("matched_file_path")]
            skippable = [v for v in vulnerabilities if not (v.get("file_found") and v.get("matched_file_path"))]
            if skippable:
                print_warn(f"{len(skippable)} vulnerabilities skipped (file not found in repo)")

            # We now call the real batch service; intercept per-vuln logs via monkey-patching
            # the batch_results object after the fact. The actual heavy LLM work happens inside.
            with Spinner(f"Running batch fix pipeline for {full_name}…"):
                try:
                    from .services.bedrock_service import BedrockService
                    from .services.batch_fix_service import BatchFixService
                    from .config import Config

                    bedrock_cfg = Config.get_bedrock_config(credentials_path)
                    bedrock_service = BedrockService(
                        access_key=bedrock_cfg["access_key"],
                        secret_key=bedrock_cfg["secret_key"],
                        region=bedrock_cfg["region"],
                    )
                    batch_service = BatchFixService(bedrock_service)

                    repo_name_str = repo.get("name", "")
                    owner = full_name.split("/")[0] if "/" in full_name else None

                    batch_results = await batch_service.fix_batch_vulnerabilities(
                        vulnerabilities=vulnerabilities,
                        repo_path=str(repo_path),
                        repo_name=repo_name_str,
                        clone_url=repo.get("clone_url") or repo.get("html_url", ""),
                        token=token,
                        max_concurrent=1,
                        auto_create_pr=args.auto_pr,
                        repo_owner=owner,
                        base_branch="main",
                        run_tests_after_fix=args.run_tests,
                    )
                except Exception as exc:
                    batch_results = {"successful": 0, "failed": len(fixable), "skipped": len(skippable), "results": [], "error": str(exc)}

            # ── Fix results ──────────────────────────────────────────────────
            print_step("Fix Results", "📋")
            for entry in batch_results.get("results", []):
                v_idx  = entry.get("vuln_idx", "?")
                status = entry.get("status", "failed")
                vuln_list = [v for v in vulnerabilities]
                # Best-effort vuln lookup
                vuln_for_entry = vuln_list[v_idx - 1] if isinstance(v_idx, int) and v_idx <= len(vuln_list) else {}
                vuln_type = vuln_for_entry.get("vulnerability", f"Vuln #{v_idx}")
                fix_result = entry.get("result") or {}
                duration   = fix_result.get("duration", 0) if isinstance(fix_result, dict) else 0

                if status == "success":
                    print_ok(f"{vuln_type}")
                elif status == "skipped":
                    print_warn(f"{vuln_type}  (skipped — file not found)")
                else:
                    err = entry.get("error") or "unknown error"
                    print_error(f"{vuln_type}  —  {err[:80]}")

            successful = batch_results.get("successful", 0)
            failed     = batch_results.get("failed", 0)
            skipped_n  = batch_results.get("skipped", 0)
            print()
            print_info(f"Fixes applied:   {c(str(successful), _GREEN, _BOLD)} succeeded   "
                       f"{c(str(failed), _RED) if failed else c('0', _DIM)} failed   "
                       f"{c(str(skipped_n), _DIM) if skipped_n else c('0', _DIM)} skipped")

            # ── Build verification ───────────────────────────────────────────
            build_verif = batch_results.get("build_verification") or {}
            if build_verif:
                print_step("Build Verification", "🔨")
                print_build_status(
                    ok=build_verif.get("build_ok", False),
                    retries=build_verif.get("retries", 0),
                    auto_fixed=build_verif.get("auto_fixed", False),
                )
                if not build_verif.get("build_ok"):
                    for err_line in (build_verif.get("build_errors") or [])[:5]:
                        print_info(c(err_line, _RED), indent=4)

            # ── PR result ────────────────────────────────────────────────────
            if args.auto_pr:
                print_step("Pull Request", "🔗")
                batch_pr = batch_results.get("batch_pr_result") or {}
                if batch_pr.get("success"):
                    pr_url = batch_pr.get("pr_url", "N/A")
                    pr_num = batch_pr.get("pr_number", "N/A")
                    print_ok(f"PR #{pr_num} created successfully")
                    print_info(f"{c(pr_url, _CYAN)}")
                else:
                    err = batch_pr.get("message") or batch_pr.get("error") or "No error detail"
                    print_warn(f"PR creation skipped or failed: {err[:100]}")

            end_to_end_results.append({"repo": repo, "batch_results": batch_results})

        # ── Final summary ────────────────────────────────────────────────────
        summary = {
            "total_repos_with_vulns": len(mapped),
            "total_repos_processed": total_fixable_repos,
            "mapping": mapping,
            "results": end_to_end_results,
        }
        duration = time.time() - run_start
        print_final_summary(summary, auto_pr=args.auto_pr, duration_secs=duration)

        # Optionally write full JSON report
        if args.output:
            out_path = Path(args.output).resolve()
            out_path.write_text(cli_api.to_pretty_json(summary), encoding="utf-8")
            print_ok(f"Full JSON report written to  {c(str(out_path), _DIM)}")
            print()

        return 0

    return asyncio.run(_run())


# ── Entry point ──────────────────────────────────────────────────────────────

def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "run":
        return _handle_run(args)

    parser.print_help()
    return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
