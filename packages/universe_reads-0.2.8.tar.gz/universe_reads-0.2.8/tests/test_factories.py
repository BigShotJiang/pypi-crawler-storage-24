from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class DummySession:
    """A minimal stand-in for a uopy Session."""

    created_with: dict[str, Any]

    def close(self) -> None:  # pragma: no cover
        return


def make_noarg_session() -> DummySession:
    """Factory that accepts no kwargs.

    Used to validate that `call_factory()` safely ignores optional pooling kwargs.
    """

    return DummySession(created_with={"kind": "noarg"})


def make_kw_session(
    *,
    pooling_on: bool | None = None,
    min_pool_size: int | None = None,
    max_pool_size: int | None = None,
) -> DummySession:
    """Factory that accepts pooling kwargs.

    Used to validate that `call_factory()` forwards supported kwargs.
    """

    return DummySession(
        created_with={
            "kind": "kw",
            "pooling_on": pooling_on,
            "min_pool_size": min_pool_size,
            "max_pool_size": max_pool_size,
        }
    )
