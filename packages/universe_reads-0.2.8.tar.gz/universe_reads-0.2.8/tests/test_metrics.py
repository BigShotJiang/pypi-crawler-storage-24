"""Tests for enhanced metrics: format_summary and throughput helpers."""
from __future__ import annotations

from dataclasses import dataclass

from universe_reads.metrics import format_summary, maybe_report, start_throughput


# ---------------------------------------------------------------------------
# Fake WorkerResult for testing (avoids importing the real one)
# ---------------------------------------------------------------------------

@dataclass
class FakeResult:
    worker_id: int
    records: int
    errors: int
    elapsed_seconds: float


# ---------------------------------------------------------------------------
# format_summary
# ---------------------------------------------------------------------------

def test_format_summary_single_worker():
    results = [FakeResult(worker_id=0, records=100, errors=0, elapsed_seconds=1.0)]
    text = format_summary(results, wall_seconds=1.0)

    assert "Worker Stats" in text
    assert "w-0" in text
    assert "100" in text
    assert "TOTAL" in text
    # Single worker → no "Avg worker rate" line.
    assert "Avg" not in text


def test_format_summary_multi_workers():
    results = [
        FakeResult(worker_id=0, records=200, errors=1, elapsed_seconds=2.0),
        FakeResult(worker_id=1, records=180, errors=0, elapsed_seconds=2.1),
        FakeResult(worker_id=2, records=220, errors=2, elapsed_seconds=1.9),
    ]
    text = format_summary(results, wall_seconds=2.5)

    assert "Worker Stats" in text
    assert "w-0" in text
    assert "w-1" in text
    assert "w-2" in text
    assert "TOTAL" in text
    assert "Peak" in text
    assert "Avg" in text

    # Total records = 600, total errors = 3.
    assert "600" in text
    assert "3" in text


def test_format_summary_zero_elapsed():
    """Should not crash on zero elapsed time."""
    results = [FakeResult(worker_id=0, records=0, errors=0, elapsed_seconds=0.0)]
    text = format_summary(results, wall_seconds=0.0)
    assert "TOTAL" in text


def test_format_summary_empty_results():
    """Edge case: no workers at all."""
    text = format_summary([], wall_seconds=1.0)
    assert "TOTAL" in text
    assert "0" in text


# ---------------------------------------------------------------------------
# maybe_report
# ---------------------------------------------------------------------------

def test_maybe_report_returns_none_when_too_soon():
    t = start_throughput()
    t.total = 100
    # Immediately after start, no time has passed → None.
    result = maybe_report(t, label="test", every_seconds=5.0)
    assert result is None


def test_maybe_report_returns_string_after_interval():
    t = start_throughput()
    t.total = 500
    # Simulate time passing by back-dating last_report_at.
    t.last_report_at -= 10.0
    result = maybe_report(t, label="test", every_seconds=5.0)
    assert result is not None
    assert "test" in result
    assert "500" in result
    assert "rec/s" in result


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    test_format_summary_single_worker()
    print("PASS: format_summary single worker")

    test_format_summary_multi_workers()
    print("PASS: format_summary multi workers")

    test_format_summary_zero_elapsed()
    print("PASS: format_summary zero elapsed")

    test_format_summary_empty_results()
    print("PASS: format_summary empty results")

    test_maybe_report_returns_none_when_too_soon()
    print("PASS: maybe_report returns None immediately")

    test_maybe_report_returns_string_after_interval()
    print("PASS: maybe_report returns string after interval")

    print("\nAll metrics tests passed.")


if __name__ == "__main__":
    main()
