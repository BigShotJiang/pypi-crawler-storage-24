"""Backward-compatible CLI entrypoint.

Prefer importing from `universe_reads.cli`.
"""

from __future__ import annotations

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
