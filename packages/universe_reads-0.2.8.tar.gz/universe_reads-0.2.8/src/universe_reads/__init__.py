"""Parallel UniVerse bulk reader.

Public API:
- `universe_reads.run(...)` (see `universe_reads.api`)
- `universe_reads.inspect(...)` (see `universe_reads.inspect_file`)
"""

from .api import run
from .inspect_file import inspect
from .parallel_read import RunOptions, WorkerResult

__all__ = ["__version__", "run", "inspect", "RunOptions", "WorkerResult"]

__version__ = "0.2.8"
