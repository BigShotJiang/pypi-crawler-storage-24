# HostWeaver 开发指南

本文档面向开发者，提供项目架构、自定义部署器和 License 生成机制的详细说明。

## 📐 项目架构

### 目录结构

```txt
hostweaver/
├── src/hostweaver/
│   ├── core/              # 核心引擎
│   │   ├── ssh_client.py       # SSH 连接池
│   │   ├── sftp_client.py      # SFTP 文件传输
│   │   ├── systemd.py          # Systemd 管理
│   │   └── base_deployer.py    # 抽象基类
│   ├── business/          # 业务集成
│   │   ├── fingerprint.py       # 机器指纹
│   │   ├── license_gen.py       # License 生成
│   │   └── generic_deployer.py  # 通用部署器
│   ├── workflow/          # 部署工作流
│   │   └── single_deploy.py     # 单机部署
│   ├── concurrent/        # 多机并发
│   │   ├── pool.py             # 并发池
│   │   └── reporter.py         # 报告生成
│   └── cli/               # 命令行工具
│       └── main.py             # CLI 入口
├── tests/               # 测试
├── examples/            # 示例代码
└── docs/                # 文档
    └── DEVELOPMENT.md   # 开发指南（本文件）
```

### 核心组件

| 组件 | 说明 |
|------|------|
| `SSHClientPool` | SSH 连接池，支持密码/私钥认证、连接复用 |
| `SFTPClient` | SFTP 文件传输，支持目录递归上传/下载 |
| `SystemdManager` | Systemd 服务管理，支持配置生成和生命周期控制 |
| `BaseDeployer` | 部署器抽象基类，定义标准接口 |
| `GenericDeployer` | 通用部署器实现，支持大多数应用场景 |
| `FingerprintExtractor` | 机器指纹提取器，读取 `/etc/machine-id` |
| `LicenseGenerator` | License 密钥生成器，支持 HMAC-SHA256 |
| `SingleDeployWorkflow` | 单机部署工作流封装 |
| `DeployPool` | 多机并发部署池 |
| `DeploymentReporter` | 部署报告生成器 |

## 🔧 自定义 Deployer

继承 [`BaseDeployer`](../src/hostweaver/core/base_deployer.py:1) 来实现自定义部署逻辑：

```python
from hostweaver.core.base_deployer import BaseDeployer

class MyCustomDeployer(BaseDeployer):
    def pre_deploy(self) -> bool:
        # 部署前准备：停止旧服务、备份配置等
        self.exec_command("sudo systemctl stop myapp || true")
        return True

    def run(self) -> bool:
        # 执行部署：上传文件、安装依赖等
        self.upload_file("./dist/app.tar.gz", "/opt/myapp/app.tar.gz")
        self.exec_command("tar -xzf /opt/myapp/app.tar.gz -C /opt/myapp")
        return True

    def post_deploy(self) -> bool:
        # 部署后处理：启动服务、验证状态等
        from hostweaver.core.systemd import SystemdManager
        systemd = SystemdManager(self.ssh_pool)
        systemd.start("myapp")
        return systemd.is_active("myapp")

# 使用
deployer = MyCustomDeployer(
    host="192.168.1.100",
    username="root",
    pkey_path="~/.ssh/id_rsa",
)
result = deployer.deploy()
print(f"部署结果：{result}")
```

## 🔑 License 生成机制

HostWeaver Deployer 支持基于机器指纹的 License 生成：

### 基础使用

```python
from hostweaver.business.license_gen import LicenseGenerator

# 创建生成器
generator = LicenseGenerator(secret_key=b"your-secret-key")

# 生成 License
machine_id = "abc123..."  # 从 /etc/machine-id 获取
license_key = generator.generate(machine_id)
print(f"License Key: {license_key}")
```

### 自定义 License Provider

```python
from hostweaver.business.license_gen import LicenseProvider

class MyLicenseProvider(LicenseProvider):
    env_name = "MY_APP_LICENSE"
    
    def __init__(self, secret_key: str):
        self.secret_key = secret_key
    
    def generate(self, machine_id: str) -> str:
        import hashlib
        # 自定义生成逻辑
        return f"APP-{hashlib.sha256((machine_id + self.secret_key).encode()).hexdigest()[:16]}"

# 使用自定义 Provider
from hostweaver.business.generic_deployer import GenericDeployer

deployer = GenericDeployer(
    host="192.168.1.100",
    source_path="./dist/app",
    license_provider=MyLicenseProvider("my-secret"),
)
```

## 🧪 开发环境设置

### 安装开发依赖

```bash
# 克隆仓库
git clone https://github.com/suroy/hostweaver.git
cd hostweaver

# 使用 uv 安装
uv pip install -e ".[dev]"
```

### 运行测试

```bash
# 运行所有测试
pytest

# 运行测试并生成覆盖率报告
pytest --cov=src/hostweaver --cov-report=html

# 运行特定测试
pytest tests/test_ssh_client.py

# 查看覆盖率报告
open htmlcov/index.html
```

### 代码质量检查

```bash
# 代码格式化
black src/ tests/

# 代码检查
ruff check src/ tests/

# 类型检查
pyright
```

## 📝 示例代码

更多示例代码请参考 [`examples/`](../examples/) 目录：

- [`examples/custom_deployer.py`](../examples/custom_deployer.py:1) - 自定义部署器示例
- [`examples/directory_deployment.py`](../examples/directory_deployment.py:1) - 目录部署示例
- [`examples/quick_start.py`](../examples/quick_start.py:1) - 快速开始示例

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📚 相关文档

- [README.md](../README.md) - 用户使用指南
- [CHANGELOG.md](../CHANGELOG.md) - 版本更新日志
- [RELEASE.md](../RELEASE.md) - 发布指南
