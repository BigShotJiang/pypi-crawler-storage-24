"""
自定义 Deployer 示例

演示如何继承 BaseDeployer 来实现自定义部署逻辑。
"""

import logging

from hostweaver.core.base_deployer import BaseDeployer

logger = logging.getLogger(__name__)


class CustomAppDeployer(BaseDeployer):
    """
    自定义应用部署器示例

    此示例演示如何：
    1. 继承 BaseDeployer
    2. 实现 pre_deploy(), run(), post_deploy() 方法
    3. 添加自定义逻辑
    """

    def __init__(
        self,
        host: str,
        app_name: str,
        app_package: str,
        install_dir: str = "/opt/custom-app",
        env_vars: dict[str, str] | None = None,
        **ssh_kwargs,
    ):
        """
        初始化自定义部署器

        Args:
            host: 远程主机地址
            app_name: 应用名称
            app_package: 应用包路径（本地）
            install_dir: 远程安装目录
            env_vars: 环境变量
            **ssh_kwargs: SSH 连接参数
        """
        super().__init__(host=host, **ssh_kwargs)

        self.app_name = app_name
        self.app_package = app_package
        self.install_dir = install_dir
        self.env_vars = env_vars or {}

    def pre_deploy(self) -> bool:
        """
        部署前准备

        1. 检查远程服务器环境
        2. 停止旧版本服务
        3. 备份配置文件

        Returns:
            准备是否成功
        """
        logger.info(f"[{self.host}] 开始部署前准备")

        try:
            # 1. 检查 Python 环境
            logger.info("检查 Python 环境")
            output, error, exit_code = self.exec_command("python3 --version")
            if exit_code != 0:
                logger.error("Python3 未安装")
                return False
            logger.info(f"Python 版本：{output.strip()}")

            # 2. 停止旧服务
            logger.info(f"停止旧服务：{self.app_name}")
            self.exec_command(f"sudo systemctl stop {self.app_name} || true")

            # 3. 备份配置（如果存在）
            config_path = f"{self.install_dir}/config.ini"
            output, _, exit_code = self.exec_command(
                f"[ -f {config_path} ] && cp {config_path} {config_path}.bak || true"
            )

            # 4. 确保安装目录存在
            logger.info(f"创建安装目录：{self.install_dir}")
            self.exec_command(f"sudo mkdir -p {self.install_dir}")
            self.exec_command(f"sudo chown $USER:$USER {self.install_dir}")

            return True

        except Exception as e:
            logger.error(f"部署前准备失败：{e}")
            return False

    def run(self) -> bool:
        """
        执行部署

        1. 上传应用包
        2. 安装依赖
        3. 生成配置文件

        Returns:
            部署是否成功
        """
        logger.info(f"[{self.host}] 开始执行部署")

        try:
            # 1. 上传应用包
            remote_package = f"{self.install_dir}/app.tar.gz"
            logger.info(f"上传应用包：{self.app_package} -> {remote_package}")

            if not self.upload_file(self.app_package, remote_package, executable=False):
                logger.error("应用包上传失败")
                return False

            # 2. 解压应用包
            logger.info("解压应用包")
            self.exec_command(f"tar -xzf {remote_package} -C {self.install_dir}")

            # 3. 安装依赖
            logger.info("安装 Python 依赖")
            requirements_path = f"{self.install_dir}/requirements.txt"
            self.exec_command(f"pip3 install -r {requirements_path} --user || true")

            # 4. 生成配置文件
            logger.info("生成配置文件")
            config_content = self._generate_config()
            config_remote = f"{self.install_dir}/config.ini"

            # 写入配置文件
            config_escaped = config_content.replace("'", "'\"'\"'")
            self.exec_command(f"echo '{config_escaped}' > {config_remote}")

            # 5. 赋予执行权限
            self.exec_command(f"chmod +x {self.install_dir}/main.py")

            return True

        except Exception as e:
            logger.error(f"部署执行失败：{e}")
            return False

    def post_deploy(self) -> bool:
        """
        部署后处理

        1. 生成 systemd 服务文件
        2. 重载并启动服务
        3. 验证服务状态

        Returns:
            处理是否成功
        """
        logger.info(f"[{self.host}] 开始部署后处理")

        try:
            from hostweaver.core.systemd import SystemdManager

            assert self.ssh_pool
            systemd = SystemdManager(self.ssh_pool)

            # 1. 生成服务配置
            logger.info("生成 Systemd 服务配置")
            service_content = systemd.generate_service_file(
                name=self.app_name,
                exec_path=f"python3 {self.install_dir}/main.py",
                working_directory=self.install_dir,
                env_vars=self.env_vars,
                description=f"Custom Application - {self.app_name}",
            )

            # 2. 写入服务文件
            if not systemd.write_service_file(self.app_name, service_content):
                logger.error("写入服务文件失败")
                return False

            # 3. 重载 systemd
            logger.info("重载 systemd 配置")
            if not systemd.daemon_reload():
                logger.error("systemd 重载失败")
                return False

            # 4. 启用并启动服务
            logger.info("启用并启动服务")
            systemd.enable(self.app_name)
            if not systemd.start(self.app_name):
                logger.error("服务启动失败")
                return False

            # 5. 验证服务状态
            import time

            time.sleep(2)

            is_active = systemd.is_active(self.app_name)
            if not is_active:
                logger.warning("服务未处于 active 状态")
            else:
                logger.info("服务启动成功")

            # 6. 获取日志
            logs = systemd.get_logs(self.app_name, lines=10)
            logger.info(f"服务日志:\n{logs}")

            return True

        except Exception as e:
            logger.error(f"部署后处理失败：{e}")
            return False

    def _generate_config(self) -> str:
        """
        生成配置文件内容

        Returns:
            配置文件内容
        """
        lines = ["[app]"]
        lines.append(f"name = {self.app_name}")
        lines.append(f"install_dir = {self.install_dir}")

        lines.append("\n[environment]")
        for key, value in self.env_vars.items():
            lines.append(f"{key} = {value}")

        return "\n".join(lines)


# 使用示例
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    # 创建部署器
    deployer = CustomAppDeployer(
        host="192.168.1.100",
        username="root",
        pkey_path="~/.ssh/id_rsa",
        app_name="myapp",
        app_package="./dist/myapp.tar.gz",
        install_dir="/opt/myapp",
        env_vars={"APP_ENV": "production", "APP_PORT": "8000"},
    )

    # 执行部署
    result = deployer.deploy()

    # 输出结果
    if result.success:
        print("部署成功!")
    else:
        print(f"部署失败：{result.message}")
