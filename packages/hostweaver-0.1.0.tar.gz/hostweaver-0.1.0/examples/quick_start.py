#!/usr/bin/env python3
"""
快速启动示例 - 验证 HostWeaver Deployer 核心功能

此脚本演示如何使用 HostWeaver Deployer 的核心组件。
注意：这是一个演示脚本，不会实际连接远程服务器。
"""

import sys
from pathlib import Path
from unittest.mock import MagicMock

# 添加 src 到路径
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def test_core_imports():
    """测试核心模块导入"""
    print("=" * 60)
    print("1. 测试核心模块导入")
    print("=" * 60)

    print("✓ SSHClientPool 导入成功")
    print("✓ SFTPClient 导入成功")
    print("✓ SystemdManager 导入成功")
    print("✓ BaseDeployer 导入成功")
    print()


def test_business_imports():
    """测试业务模块导入"""
    print("=" * 60)
    print("2. 测试业务模块导入")
    print("=" * 60)

    print("✓ FingerprintExtractor 导入成功")
    print("✓ LicenseGenerator 导入成功")
    print("✓ GenericDeployer 导入成功")
    print()


def test_workflow_imports():
    """测试工作流模块导入"""
    print("=" * 60)
    print("3. 测试工作流模块导入")
    print("=" * 60)

    print("✓ SingleDeployWorkflow 导入成功")
    print("✓ DeploymentResult 导入成功")
    print()


def test_concurrent_imports():
    """测试并发模块导入"""
    print("=" * 60)
    print("4. 测试并发模块导入")
    print("=" * 60)

    print("✓ DeployPool 导入成功")
    print("✓ HostConfig 导入成功")
    print("✓ DeployTask 导入成功")
    print("✓ DeploymentReporter 导入成功")
    print()


def test_license_generator():
    """测试 License 生成器功能"""
    print("=" * 60)
    print("5. 测试 License 生成器功能")
    print("=" * 60)

    from hostweaver.business.license_gen import LicenseGenerator

    # 创建生成器
    generator = LicenseGenerator(secret_key=b"my-secret-key-123")

    # 生成 License
    machine_id = "abc123def456"
    license_key = generator.generate(machine_id)

    print(f"  机器指纹：{machine_id}")
    print(f"  生成的 License: {license_key}")

    # 验证 License
    is_valid = generator.verify(machine_id, license_key)
    print(f"  验证结果：{'✓ 有效' if is_valid else '✗ 无效'}")

    if not is_valid:
        print("  ❌ License 验证失败!")
        return False

    print("✓ License 生成器功能正常")
    print()
    return True


def test_fingerprint_extractor():
    """测试指纹提取器（Mock 测试）"""
    print("=" * 60)
    print("6. 测试指纹提取器功能 (Mock)")
    print("=" * 60)

    from unittest.mock import MagicMock

    from hostweaver.business.fingerprint import FingerprintExtractor

    # 创建 Mock SSH 连接
    mock_ssh = MagicMock()
    mock_ssh.is_connected.return_value = True
    mock_ssh.exec_command.return_value = ("test-machine-id-123", "", 0)

    extractor = FingerprintExtractor(mock_ssh)

    # 获取机器指纹
    fingerprint = extractor.get_machine_id()

    print(f"  模拟机器指纹：{fingerprint}")

    if not fingerprint:
        print("  ❌ 指纹提取失败!")
        return False

    print("✓ 指纹提取器功能正常")
    print()
    return True


def test_host_config():
    """测试主机配置"""
    print("=" * 60)
    print("7. 测试主机配置")
    print("=" * 60)

    from hostweaver.concurrent.pool import HostConfig

    config = HostConfig(
        host="192.168.1.100",
        port=22,
        username="root",
        password="secret",
        env_vars={"APP_ENV": "production", "DEBUG": "false"},
    )

    print(f"  主机：{config.host}:{config.port}")
    print(f"  用户：{config.username}")
    print(f"  环境变量：{config.env_vars}")

    print("✓ 主机配置功能正常")
    print()
    return True


def test_deploy_pool():
    """测试部署池"""
    print("=" * 60)
    print("8. 测试部署池")
    print("=" * 60)

    from hostweaver.concurrent.pool import DeployPool, HostConfig

    pool = DeployPool(max_workers=3)

    # 添加主机
    hosts = ["192.168.1.100", "192.168.1.101", "192.168.1.102"]
    for host in hosts:
        config = HostConfig(host=host, username="root")
        pool.add_task(config, MagicMock, source_path="./test")

    print(f"  已添加 {len(pool.tasks)} 个部署任务")
    print(f"  最大并发数：{pool.max_workers}")

    # 获取汇总
    pool.get_summary()
    print("  部署池就绪，可执行部署")

    print("✓ 部署池功能正常")
    print()
    return True


def test_deployment_result():
    """测试部署结果"""
    print("=" * 60)
    print("9. 测试部署结果")
    print("=" * 60)

    from datetime import datetime, timedelta

    from hostweaver.workflow.single_deploy import DeploymentResult

    end_time = datetime.now()
    start_time = end_time - timedelta(seconds=15.5)

    result = DeploymentResult(
        success=True,
        host="192.168.1.100",
        message="部署成功",
        machine_id="abc123def456",
        license_key="LIC-abc123-xyz789",
        service_status="active (running)",
        start_time=start_time,
        end_time=end_time,
    )

    print(f"  主机：{result.host}")
    print(f"  状态：{'成功' if result.success else '失败'}")
    print(f"  机器指纹：{result.machine_id}")
    print(f"  License: {result.license_key}")
    print(f"  服务状态：{result.service_status}")
    print(f"  耗时：{result.duration:.2f}秒")

    print("✓ 部署结果功能正常")
    print()
    return True


def main():
    """主函数"""
    print()
    print("╔" + "=" * 58 + "╗")
    print("║" + " " * 10 + "HostWeaver Deployer 功能验证" + " " * 19 + "║")
    print("╚" + "=" * 58 + "╝")
    print()

    all_passed = True

    try:
        test_core_imports()
        test_business_imports()
        test_workflow_imports()
        test_concurrent_imports()
        all_passed &= test_license_generator()
        all_passed &= test_fingerprint_extractor()
        all_passed &= test_host_config()
        all_passed &= test_deploy_pool()
        all_passed &= test_deployment_result()

    except Exception as e:
        print(f"\n❌ 测试过程中出现异常：{e}")
        import traceback

        traceback.print_exc()
        all_passed = False

    print("=" * 60)
    if all_passed:
        print("✅ 所有功能验证通过！HostWeaver Deployer 可以正常运行。")
    else:
        print("❌ 部分功能验证失败，请检查错误信息。")
    print("=" * 60)
    print()

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
