"""
目录部署示例

演示如何使用 GenericDeployer 来部署整个项目目录（而非单个二进制文件）。

适用场景:
- 部署 Python 项目源代码
- 部署需要多个文件协作的应用
- 部署包含静态资源、模板等的 Web 应用
"""

import logging

from hostweaver.business.generic_deployer import GenericDeployer
from hostweaver.workflow.single_deploy import SingleDeployWorkflow

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def deploy_directory_example():
    """
    部署整个项目目录示例

    此示例展示:
    1. 部署整个项目目录到远程服务器
    2. 指定入口文件 (main.py)
    3. 注入环境变量
    4. 自动生成 License Key
    """
    # 创建 GenericDeployer 实例
    deployer = GenericDeployer(
        host="192.168.1.100",
        port=22,
        username="root",
        pkey_path="~/.ssh/id_rsa",  # 或使用 password="your_password"
        source_path="./my_project",  # 项目目录路径
        entrypoint="main.py",  # 入口文件（相对于项目目录）
        install_dir="/opt/app",
        service_name="myapp",
        env_vars={
            "APP_ENV": "production",
            "APP_PORT": "8000",
            "LOG_LEVEL": "info",
        },
        secret_key="your-secret-key-here",  # 用于生成 License
        license_method="hmac",  # 或 "rsa"
        timeout=60,
    )

    # 创建部署工作流
    workflow = SingleDeployWorkflow(
        deployer=deployer,
        show_logs=True,  # 显示服务日志
        log_lines=20,  # 显示前 20 行日志
    )

    # 执行部署
    result = workflow.execute()

    # 检查结果
    if result.success:
        logger.info("✅ 部署成功!")
        logger.info(f"主机：{result.host}")
        logger.info(f"机器指纹：{result.machine_id}")
        if result.service_status:
            logger.info(f"服务状态:\n{result.service_status}")
    else:
        logger.error(f"❌ 部署失败：{result.message}")

    return result


def deploy_binary_example():
    """
    部署单个二进制文件示例

    此示例展示:
    1. 部署单个二进制文件（如 PyInstaller 打包的可执行文件）
    2. 自动赋予执行权限
    """
    # 创建 GenericDeployer 实例
    deployer = GenericDeployer(
        host="192.168.1.100",
        port=22,
        username="root",
        pkey_path="~/.ssh/id_rsa",
        source_path="./dist/app",  # 二进制文件路径
        # entrypoint 参数在部署单个文件时会被忽略
        install_dir="/opt/app",
        service_name="myapp",
        env_vars={
            "APP_ENV": "production",
        },
        secret_key="your-secret-key-here",
        license_method="hmac",
        timeout=60,
    )

    # 创建部署工作流
    workflow = SingleDeployWorkflow(deployer=deployer, show_logs=True)

    # 执行部署
    result = workflow.execute()

    return result


def deploy_with_custom_ignore():
    """
    带忽略模式的目录部署示例

    演示如何自定义忽略模式，排除不需要的文件。
    """

    # 默认忽略模式
    default_ignore_patterns = [
        "*.pyc",
        "*.pyo",
        "__pycache__",
        "*.so",
        ".git",
        ".gitignore",
        "*.md",
        "tests",
        ".pytest_cache",
        ".mypy_cache",
        "htmlcov",
        ".coverage",
        "venv",
        ".venv",
        "env",
        ".env",
        "node_modules",
        "dist",
        "build",
        "*.egg-info",
    ]

    # 自定义忽略模式 - 排除更多文件
    custom_ignore_patterns = default_ignore_patterns + [
        "*.log",
        "*.tmp",
        "docs",
        "scripts",
        ".idea",
        ".vscode",
    ]

    # 创建部署器
    deployer = GenericDeployer(
        host="192.168.1.100",
        username="root",
        pkey_path="~/.ssh/id_rsa",
        source_path="./my_project",
        entrypoint="main.py",
        install_dir="/opt/app",
        service_name="myapp",
        env_vars={"APP_ENV": "production"},
        ignore_patterns=custom_ignore_patterns,  # 使用自定义忽略模式
    )

    workflow = SingleDeployWorkflow(deployer=deployer)
    result = workflow.execute()

    return result


if __name__ == "__main__":
    import sys

    # 从命令行参数选择示例
    example_type = sys.argv[1] if len(sys.argv) > 1 else "directory"

    if example_type == "directory":
        print("运行目录部署示例...")
        deploy_directory_example()
    elif example_type == "binary":
        print("运行二进制部署示例...")
        deploy_binary_example()
    elif example_type == "ignore":
        print("运行带忽略模式的目录部署示例...")
        deploy_with_custom_ignore()
    else:
        print(f"未知示例类型：{example_type}")
        print("可用类型：directory, binary, ignore")
        sys.exit(1)
