# HostWeaver Deployer 发布指南

本文档提供完整的发布流程指导。

## 📋 发布前检查清单

### 1. 代码质量检查

```bash
# 运行所有测试
pytest

# 代码格式化检查
black --check src/ tests/ examples/
ruff check src/ tests/ examples/

# 类型检查
pyright
```

### 2. 更新版本号

编辑以下文件，更新版本号：

**`pyproject.toml`**:
```toml
[project]
version = "0.2.0"  # 更新版本号
```

**`src/hostweaver/__init__.py`**:
```python
__version__ = "0.2.0"  # 更新版本号
```

### 3. 更新 CHANGELOG.md

记录本版本的变更内容（参见下方 CHANGELOG 模板）。

### 4. 确保 README.md 是最新的

检查 README.md 中的：
- 版本号引用
- API 示例代码
- 功能描述

---

## 🚀 发布流程

### 步骤 1: 安装构建工具

```bash
uv pip install build twine
```

### 步骤 2: 清理旧构建

```bash
rm -rf dist/ build/ *.egg-info
```

### 步骤 3: 构建分发包

```bash
# 构建 wheel 和 source distribution
python -m build
```

这会在 `dist/` 目录生成：
- `dist/hostweaver_deployer-<version>-py3-none-any.whl`
- `dist/hostweaver_deployer-<version>.tar.gz`

### 步骤 4: 本地测试安装

```bash
# 测试 wheel 安装
pip install dist/hostweaver_deployer-*.whl

# 验证 CLI 可用
hostweaver --version

# 卸载测试版本
pip uninstall hostweaver
```

### 步骤 5: 上传到 PyPI

#### 测试 PyPI（推荐先测试）

```bash
# 上传到 TestPyPI
twine upload --repository testpypi dist/*

# 测试安装
pip install --index-url https://test.pypi.org/simple/ hostweaver
```

#### 正式 PyPI

```bash
# 上传到 PyPI
twine upload dist/*
```

**注意**: 需要先在 [pypi.org](https://pypi.org/) 注册账号并配置 API token：

```bash
# 配置 ~/.pypirc
[pypi]
username = __token__
password = pypi-xxx...
```

### 步骤 6: 创建 Git 标签

```bash
# 创建版本标签
git tag -a v0.1.0 -m "Release version 0.1.0"

# 推送标签
git push origin v0.1.0
```

### 步骤 7: 创建 GitHub Release

1. 访问 https://github.com/suroy/hostweaver/releases
2. 点击 "Create a new release"
3. 选择刚创建的标签
4. 填写发布说明（可从 CHANGELOG.md 复制）
5. 上传 `dist/` 中的分发包（可选）

---

## 📝 CHANGELOG.md 模板

创建 `CHANGELOG.md` 文件：

```markdown
# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added
- 新增功能描述

### Changed
- 变更描述

### Fixed
- 修复描述

## [0.1.0] - 2026-03-15

### Added
- 初始版本发布
- SSH/SFTP 连接池管理
- Systemd 服务生命周期管理
- 机器指纹提取和 License 生成
- 单机部署工作流
- 多机并发部署支持
- 命令行工具 (CLI)
- 完整的测试套件

### Changed
- 无

### Fixed
- 无

### Removed
- 无
```

---

## 🔧 常见问题

### Q: 上传时提示 "403 Forbidden"

**A**: 检查是否配置了正确的 PyPI API token：

```bash
# 使用 keyring 存储 token
keyring set https://upload.pypi.org/legacy/ your-username
```

### Q: 版本号冲突

**A**: PyPI 不允许上传相同版本号的包。如果上传失败，需要：
1. 更新 `pyproject.toml` 和 `__init__.py` 中的版本号
2. 清理 `dist/` 目录
3. 重新构建

### Q: 依赖项缺失

**A**: 确保 `pyproject.toml` 中的 `dependencies` 列表完整：

```toml
dependencies = [
    "paramiko>=3.4.0",
    "typer>=0.9.0",
    "rich>=13.7.0",
]
```

---

## 📊 发布后验证

### 1. 验证 PyPI 页面

访问 https://pypi.org/project/hostweaver/ 确认：
- 版本号正确
- 描述渲染正常
- 侧边栏显示正确的分类和依赖

### 2. 测试全新安装

```bash
# 在新环境中测试
python -m venv test-env
source test-env/bin/activate
pip install hostweaver
hostweaver --version
```

### 3. 验证文档链接

检查 README.md 中的链接是否有效：
- GitHub 仓库链接
- 文档链接
- Issue 追踪链接

---

## 🎯 下一步

发布后可以考虑：
1. 在社交媒体/技术社区分享
2. 提交到 Python 周报
3. 编写使用教程博客
4. 收集用户反馈

---

**最后更新**: 2026-03-15
