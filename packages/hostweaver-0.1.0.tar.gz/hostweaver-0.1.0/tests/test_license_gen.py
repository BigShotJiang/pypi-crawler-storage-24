"""
License 生成器测试
"""

from hostweaver.business.license_gen import LicenseGenerator


class TestLicenseGenerator:
    """LicenseGenerator 测试类"""

    def test_init_with_secret_key(self):
        """测试使用自定义密钥初始化"""
        gen = LicenseGenerator(secret_key=b"my-secret-key")
        assert gen.secret_key == b"my-secret-key"

    def test_init_without_secret_key(self):
        """测试不提供密钥时使用默认密钥"""
        gen = LicenseGenerator()
        assert gen.secret_key == b"syscrafts-default-2026"

    def test_generate_basic(self):
        """测试基本 License 生成"""
        gen = LicenseGenerator(secret_key=b"test-key")
        license_key = gen.generate("8f3a2b1c-e5f7d9a4")

        # 验证格式：LIC-{8 位}-{8 位}
        parts = license_key.split("-")
        assert len(parts) == 3
        assert parts[0] == "LIC"
        assert len(parts[1]) == 8
        assert len(parts[2]) == 8

    def test_generate_with_custom_prefix(self):
        """测试自定义前缀"""
        gen = LicenseGenerator(secret_key=b"test-key", license_prefix="APP")
        license_key = gen.generate("8f3a2b1c-e5f7d9a4")

        parts = license_key.split("-")
        assert parts[0] == "APP"

    def test_generate_deterministic(self):
        """测试相同输入生成相同输出"""
        gen = LicenseGenerator(secret_key=b"test-key")
        key1 = gen.generate("8f3a2b1c-e5f7d9a4")
        key2 = gen.generate("8f3a2b1c-e5f7d9a4")
        assert key1 == key2

    def test_generate_different_secrets(self):
        """测试不同密钥生成不同 License"""
        gen1 = LicenseGenerator(secret_key=b"key1")
        gen2 = LicenseGenerator(secret_key=b"key2")

        key1 = gen1.generate("8f3a2b1c-e5f7d9a4")
        key2 = gen2.generate("8f3a2b1c-e5f7d9a4")
        assert key1 != key2

    def test_generate_different_machine_ids(self):
        """测试不同 machine_id 生成不同 License"""
        gen = LicenseGenerator(secret_key=b"test-key")

        key1 = gen.generate("8f3a2b1c-e5f7d9a4")
        key2 = gen.generate("1a2b3c4d-5e6f7g8h")
        assert key1 != key2

    def test_verify_valid_license(self):
        """测试验证有效 License"""
        gen = LicenseGenerator(secret_key=b"test-key")
        machine_id = "8f3a2b1c-e5f7d9a4"
        license_key = gen.generate(machine_id)

        assert gen.verify(machine_id, license_key) is True

    def test_verify_invalid_license(self):
        """测试验证无效 License"""
        gen = LicenseGenerator(secret_key=b"test-key")

        # 使用错误的 machine_id
        assert gen.verify("wrong-id", "LIC-8f3a2b1c-a7b3c9d2") is False

    def test_verify_wrong_format(self):
        """测试验证格式错误的 License"""
        gen = LicenseGenerator(secret_key=b"test-key")

        assert gen.verify("8f3a2b1c-e5f7d9a4", "invalid-format") is False

    def test_verify_wrong_prefix(self):
        """测试验证前缀不匹配的 License"""
        gen = LicenseGenerator(secret_key=b"test-key")
        machine_id = "8f3a2b1c-e5f7d9a4"

        # 使用不同的前缀验证（应该失败，因为 License 是使用默认前缀生成的）
        assert gen.verify(machine_id, "APP-8f3a2b1c-a7b3c9d2") is False

    def test_verify_with_different_secret(self):
        """测试使用不同密钥验证失败"""
        gen1 = LicenseGenerator(secret_key=b"key1")
        gen2 = LicenseGenerator(secret_key=b"key2")

        machine_id = "8f3a2b1c-e5f7d9a4"
        license_key = gen1.generate(machine_id)

        # 使用不同的密钥验证
        assert gen2.verify(machine_id, license_key) is False

    def test_short_machine_id(self):
        """测试短 machine_id"""
        gen = LicenseGenerator(secret_key=b"test-key")
        license_key = gen.generate("short")

        parts = license_key.split("-")
        assert parts[1] == "short"  # 短 ID 保持原样

    def test_empty_machine_id(self):
        """测试空 machine_id"""
        gen = LicenseGenerator(secret_key=b"test-key")
        license_key = gen.generate("")

        parts = license_key.split("-")
        assert parts[1] == ""
