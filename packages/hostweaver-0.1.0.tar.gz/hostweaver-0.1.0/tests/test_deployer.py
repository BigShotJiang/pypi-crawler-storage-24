"""
部署器测试
"""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from hostweaver.business.generic_deployer import DEFAULT_IGNORE_PATTERNS, GenericDeployer


class TestGenericDeployer:
    """GenericDeployer 测试类"""

    def test_init_basic(self):
        """测试基本初始化"""
        with patch.object(Path, "exists", return_value=True):
            deployer = GenericDeployer(
                host="192.168.1.100",
                source_path="./test_source",
                username="root",
                password="testpass",
            )

        assert deployer.host == "192.168.1.100"
        assert deployer.source_path == "./test_source"
        assert deployer.install_dir == "/opt/app"
        assert deployer.service_name == "myapp"

    def test_init_with_custom_params(self):
        """测试自定义参数初始化"""
        with patch.object(Path, "exists", return_value=True):
            deployer = GenericDeployer(
                host="192.168.1.100",
                source_path="./test_source",
                install_dir="/opt/myapp",
                service_name="myapp",
                env_vars={"APP_ENV": "production"},
                secret_key="my-secret",
                entrypoint="app.py",
            )

        assert deployer.install_dir == "/opt/myapp"
        assert deployer.service_name == "myapp"
        assert deployer.env_vars == {"APP_ENV": "production"}
        assert deployer.secret_key == "my-secret"
        assert deployer.entrypoint == "app.py"

    def test_init_source_not_exists(self):
        """测试源路径不存在"""
        with patch.object(Path, "exists", return_value=False):
            with pytest.raises(FileNotFoundError):
                GenericDeployer(
                    host="192.168.1.100",
                    source_path="./nonexistent",
                    username="root",
                )

    def test_init_with_ignore_patterns(self):
        """测试自定义忽略模式"""
        custom_patterns = ["*.log", "*.tmp"]
        with patch.object(Path, "exists", return_value=True):
            deployer = GenericDeployer(
                host="192.168.1.100",
                source_path="./test_source",
                username="root",
                ignore_patterns=custom_patterns,
            )

        assert deployer.ignore_patterns == custom_patterns

    def test_init_default_ignore_patterns(self):
        """测试默认忽略模式"""
        with patch.object(Path, "exists", return_value=True):
            deployer = GenericDeployer(
                host="192.168.1.100",
                source_path="./test_source",
                username="root",
            )

        assert deployer.ignore_patterns == DEFAULT_IGNORE_PATTERNS

    @patch.object(GenericDeployer, "_validate_source")
    def test_pre_deploy_get_fingerprint(self, mock_validate):
        """测试 pre_deploy 获取机器指纹"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test",
            username="root",
            password="test",
        )

        # Mock SSH connection
        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True

        # Mock systemd manager
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.stop.return_value = True

        # Mock fingerprint extractor
        with patch(
            "syscrafts.business.generic_deployer.FingerprintExtractor"
        ) as mock_extractor_class:
            mock_extractor = MagicMock()
            mock_extractor.get_fingerprint.return_value = "test-machine-id"
            mock_extractor_class.return_value = mock_extractor

            result = deployer.pre_deploy()

            assert result is True
            assert deployer.machine_id == "test-machine-id"

    @patch.object(GenericDeployer, "_validate_source")
    def test_pre_deploy_generates_license(self, mock_validate):
        """测试 pre_deploy 生成 License"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test",
            username="root",
            password="test",
            secret_key="my-secret",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.stop.return_value = True

        with patch(
            "syscrafts.business.generic_deployer.FingerprintExtractor"
        ) as mock_extractor_class:
            mock_extractor = MagicMock()
            mock_extractor.get_fingerprint.return_value = "test-machine-id"
            mock_extractor_class.return_value = mock_extractor

            result = deployer.pre_deploy()

            assert result is True
            assert deployer.license_key is not None
            assert "APP_LICENSE_KEY" in deployer.env_vars

    @patch.object(GenericDeployer, "_validate_source")
    def test_run_file_upload(self, mock_validate):
        """测试 run 方法上传文件"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test_app",
            username="root",
            password="test",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.generate_service_file.return_value = "[Unit]\n..."
        deployer.systemd_manager.write_service_file.return_value = True
        deployer.systemd_manager.daemon_reload.return_value = True

        with patch.object(Path, "is_file", return_value=True):
            with patch.object(
                deployer, "upload_file", return_value=True
            ) as mock_upload:
                result = deployer.run()

                assert result is True
                mock_upload.assert_called_once()

    @patch.object(GenericDeployer, "_validate_source")
    def test_run_directory_upload(self, mock_validate):
        """测试 run 方法上传目录"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test_project",
            username="root",
            password="test",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.generate_service_file.return_value = "[Unit]\n..."
        deployer.systemd_manager.write_service_file.return_value = True
        deployer.systemd_manager.daemon_reload.return_value = True

        with patch.object(Path, "is_file", return_value=False):
            with patch.object(
                deployer, "upload_directory", return_value=True
            ) as mock_upload:
                result = deployer.run()

                assert result is True
                mock_upload.assert_called_once()

    @patch.object(GenericDeployer, "_validate_source")
    def test_post_deploy_start_service(self, mock_validate):
        """测试 post_deploy 启动服务"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test",
            username="root",
            password="test",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.start.return_value = True
        deployer.systemd_manager.is_active.return_value = True
        deployer.systemd_manager.get_logs.return_value = "Log output"

        with patch.object(deployer, "get_service_status", return_value="active"):
            with patch.object(deployer, "get_service_logs", return_value="logs"):
                result = deployer.post_deploy()

                assert result is True
                deployer.systemd_manager.start.assert_called_once()

    @patch.object(GenericDeployer, "_validate_source")
    def test_get_logs(self, mock_validate):
        """测试获取日志"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test",
            username="root",
            password="test",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.get_logs.return_value = "Log line 1\nLog line 2"

        logs = deployer.get_logs(lines=50)

        assert "Log line 1" in logs
        deployer.systemd_manager.get_logs.assert_called_once_with("myapp", 50)

    @patch.object(GenericDeployer, "_validate_source")
    def test_restart(self, mock_validate):
        """测试重启服务"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test",
            username="root",
            password="test",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.restart.return_value = True

        result = deployer.restart()

        assert result is True
        deployer.systemd_manager.restart.assert_called_once()

    @patch.object(GenericDeployer, "_validate_source")
    def test_stop(self, mock_validate):
        """测试停止服务"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test",
            username="root",
            password="test",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.stop.return_value = True

        result = deployer.stop()

        assert result is True

    @patch.object(GenericDeployer, "_validate_source")
    def test_status(self, mock_validate):
        """测试获取状态"""
        mock_validate.return_value = True

        deployer = GenericDeployer(
            host="192.168.1.100",
            source_path="./test",
            username="root",
            password="test",
        )

        deployer.ssh_pool = MagicMock()
        deployer.ssh_pool.is_connected.return_value = True
        deployer.systemd_manager = MagicMock()
        deployer.systemd_manager.status.return_value = "● myapp - Active"

        status = deployer.status()

        assert "myapp" in status
