"""
部署工作流测试
"""

from unittest.mock import MagicMock

from hostweaver.workflow.single_deploy import DeploymentResult, SingleDeployWorkflow


class TestDeploymentResult:
    """DeploymentResult 测试类"""

    def test_init_success(self):
        """测试成功结果初始化"""
        result = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )

        assert result.host == "192.168.1.100"
        assert result.success is True
        assert result.message == "部署成功"
        assert result.machine_id is None
        assert result.logs is None

    def test_init_failure(self):
        """测试失败结果初始化"""
        result = DeploymentResult(
            host="192.168.1.100",
            success=False,
            message="连接失败",
        )

        assert result.success is False
        assert result.message == "连接失败"

    def test_init_with_details(self):
        """测试带详细信息的初始化"""
        result = DeploymentResult(
            host="192.168.1.100",
            success=True,
            details={"service_active": True, "version": "1.0.0"},
        )
        assert result.details
        assert result.details["service_active"] is True
        assert result.details["version"] == "1.0.0"

    def test_str_success(self):
        """测试成功状态的字符串表示"""
        result = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )

        assert "[SUCCESS]" in str(result)
        assert "192.168.1.100" in str(result)

    def test_str_failed(self):
        """测试失败状态的字符串表示"""
        result = DeploymentResult(
            host="192.168.1.100",
            success=False,
            message="部署失败",
        )

        assert "[FAILED]" in str(result)


class TestSingleDeployWorkflow:
    """SingleDeployWorkflow 测试类"""

    def test_init_basic(self):
        """测试基本初始化"""
        mock_deployer = MagicMock()

        workflow = SingleDeployWorkflow(deployer=mock_deployer)

        assert workflow.deployer == mock_deployer
        assert workflow.show_logs is True
        assert workflow.log_lines == 20

    def test_init_with_options(self):
        """测试带选项的初始化"""
        mock_deployer = MagicMock()

        workflow = SingleDeployWorkflow(
            deployer=mock_deployer,
            show_logs=False,
            log_lines=50,
        )

        assert workflow.show_logs is False
        assert workflow.log_lines == 50

    def test_execute_success(self):
        """测试执行成功"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.service_name = "test-service"

        # Mock deploy() 返回成功结果（包含服务状态和日志）
        mock_result = MagicMock()
        mock_result.success = True
        mock_result.message = "部署成功"
        mock_result.details = {
            "service_active": True,
            "service_status": "active (running)",
            "service_logs": "Log output",
        }
        mock_deployer.deploy.return_value = mock_result

        mock_deployer.machine_id = "test-machine-id"
        mock_deployer.license_key = "test-license"

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute()

        assert result.success is True
        assert result.host == "192.168.1.100"
        assert result.machine_id == "test-machine-id"
        assert result.license_key == "test-license"
        assert result.service_status == "active (running)"
        assert result.logs == "Log output"

    def test_execute_failure(self):
        """测试执行失败"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"

        # Mock deploy() 返回失败结果
        mock_result = MagicMock()
        mock_result.success = False
        mock_result.message = "连接失败"
        mock_result.details = {}
        mock_deployer.deploy.return_value = mock_result

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute()

        assert result.success is False
        assert result.message == "连接失败"

    def test_execute_with_exception(self):
        """测试执行异常"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.deploy.side_effect = Exception("Unexpected error")

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute()

        assert result.success is False
        assert "部署异常" in result.message

    def test_execute_status_error_handled(self):
        """测试服务状态获取错误被处理"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.service_name = "test-service"

        # Mock deploy() 返回成功结果，但 details 中没有服务状态/日志（模拟获取失败）
        mock_result = MagicMock()
        mock_result.success = True
        mock_result.message = "部署成功"
        mock_result.details = {"status_error": "Status error"}
        mock_deployer.deploy.return_value = mock_result

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute()

        assert result.success is True
        assert result.details
        assert "status_error" in result.details

    def test_execute_with_progress_success(self):
        """测试带进度回调的执行成功"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.service_name = "test-service"
        mock_deployer.connect.return_value = True
        mock_deployer.pre_deploy.return_value = True
        mock_deployer.run.return_value = True
        mock_deployer.post_deploy.return_value = True
        mock_deployer.get_service_status.return_value = "active"
        mock_deployer.get_service_logs.return_value = "logs"
        mock_deployer.machine_id = "test-id"

        progress_callback = MagicMock()

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute_with_progress(progress_callback=progress_callback)

        assert result.success is True
        # 验证进度回调被调用
        assert (
            progress_callback.call_count >= 5
        )  # CONNECT, PREPARE, DEPLOY, POST, DISCONNECT

    def test_execute_with_progress_connect_failure(self):
        """测试带进度回调的连接失败"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.connect.return_value = False

        progress_callback = MagicMock()

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute_with_progress(progress_callback=progress_callback)

        assert result.success is False
        assert "SSH 连接失败" in result.message

    def test_execute_with_progress_prepare_failure(self):
        """测试带进度回调的准备失败"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.connect.return_value = True
        mock_deployer.pre_deploy.return_value = False

        progress_callback = MagicMock()

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute_with_progress(progress_callback=progress_callback)

        assert result.success is False
        assert "部署前准备失败" in result.message
        mock_deployer.disconnect.assert_called_once()

    def test_execute_with_progress_deploy_failure(self):
        """测试带进度回调的部署失败"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.connect.return_value = True
        mock_deployer.pre_deploy.return_value = True
        mock_deployer.run.return_value = False

        progress_callback = MagicMock()

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute_with_progress(progress_callback=progress_callback)

        assert result.success is False
        assert "部署执行失败" in result.message
        mock_deployer.disconnect.assert_called_once()

    def test_execute_with_progress_post_deploy_failure(self):
        """测试带进度回调的部署后处理失败"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.connect.return_value = True
        mock_deployer.pre_deploy.return_value = True
        mock_deployer.run.return_value = True
        mock_deployer.post_deploy.return_value = False

        progress_callback = MagicMock()

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute_with_progress(progress_callback=progress_callback)

        assert result.success is False
        assert "部署后处理失败" in result.message
        mock_deployer.disconnect.assert_called_once()

    def test_execute_with_progress_exception(self):
        """测试带进度回调的异常处理"""
        mock_deployer = MagicMock()
        mock_deployer.host = "192.168.1.100"
        mock_deployer.connect.side_effect = Exception("Connection error")

        progress_callback = MagicMock()

        workflow = SingleDeployWorkflow(deployer=mock_deployer)
        result = workflow.execute_with_progress(progress_callback=progress_callback)

        assert result.success is False
        mock_deployer.disconnect.assert_called_once()
