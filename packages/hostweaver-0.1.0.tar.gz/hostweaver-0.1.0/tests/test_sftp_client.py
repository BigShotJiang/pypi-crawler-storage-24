"""
SFTP 客户端测试
"""

from pathlib import Path
from unittest.mock import MagicMock, mock_open, patch

import pytest

from hostweaver.core.sftp_client import SFTPClient


class TestSFTPClient:
    """SFTPClient 测试类"""

    def test_init(self):
        """测试初始化"""
        mock_ssh = MagicMock()
        client = SFTPClient(mock_ssh)

        assert client.ssh_pool == mock_ssh
        assert client._sftp is None

    def test_get_sftp_not_connected(self):
        """测试未连接时获取 SFTP 失败"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = False

        client = SFTPClient(mock_ssh)

        with pytest.raises(Exception):
            client._get_sftp()

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_get_sftp_success(self, mock_sftp_class):
        """测试成功获取 SFTP"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        result = client._get_sftp()

        assert result == mock_sftp

    def test_close(self):
        """测试关闭 SFTP"""
        mock_ssh = MagicMock()
        mock_sftp = MagicMock()

        client = SFTPClient(mock_ssh)
        client._sftp = mock_sftp
        client.close()

        mock_sftp.close.assert_called_once()
        assert client._sftp is None

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_mkdir_p_success(self, mock_sftp_class):
        """测试创建目录成功"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        # 目录不存在，需要创建 - 多次调用返回 FileNotFoundError
        # mkdir_p 会先检查完整路径，然后递归检查每个部分
        # 对于 "/remote/test/dir"，它会检查：/remote, /remote/test, /remote/test/dir
        # 然后最后一次检查确认创建成功
        mock_sftp.stat.side_effect = [
            FileNotFoundError(),  # 检查 /remote - 不存在
            FileNotFoundError(),  # 检查 /remote/test - 不存在
            FileNotFoundError(),  # 检查 /remote/test/dir - 不存在
            None,  # 检查 /remote - 创建后存在
            None,  # 检查 /remote/test - 创建后存在
            None,  # 检查 /remote/test/dir - 创建后存在
        ]
        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        client.mkdir_p("/remote/test/dir")

        # 验证 mkdir 被调用（多次，因为是递归创建）
        assert mock_sftp.mkdir.call_count >= 1

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_mkdir_p_already_exists(self, mock_sftp_class):
        """测试目录已存在"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        # 目录已存在
        mock_sftp.stat.return_value = True
        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        client.mkdir_p("/remote/test/dir")

        mock_sftp.mkdir.assert_not_called()

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_upload_success(self, mock_sftp_class):
        """测试上传文件成功"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)

        with patch.object(Path, "exists", return_value=True):
            with patch.object(Path, "is_file", return_value=True):
                with patch.object(Path, "parent") as mock_parent:
                    mock_parent.as_posix.return_value = "/remote"
                    result = client.upload("/local/test.txt", "/remote/test.txt")

        assert result is True
        mock_sftp.put.assert_called_once()

    def test_upload_file_not_exists(self):
        """测试上传文件不存在"""
        mock_ssh = MagicMock()

        client = SFTPClient(mock_ssh)

        with patch.object(Path, "exists", return_value=False):
            result = client.upload("/nonexistent.txt", "/remote/test.txt")

        assert result is False

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_upload_with_executable(self, mock_sftp_class):
        """测试上传文件并设置执行权限"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)

        with patch.object(Path, "exists", return_value=True):
            with patch.object(Path, "is_file", return_value=True):
                with patch.object(Path, "parent") as mock_parent:
                    mock_parent.as_posix.return_value = "/remote"
                    result = client.upload("/local/app", "/remote/app", executable=True)

        assert result is True
        mock_sftp.chmod.assert_called()

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_download_success(self, mock_sftp_class):
        """测试下载文件成功"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)

        with patch("builtins.open", mock_open()):
            with patch.object(Path, "expanduser", return_value=Path("/local/test.txt")):
                with patch.object(Path, "parent") as mock_parent:
                    mock_parent.mkdir = MagicMock()
                    result = client.download("/remote/test.txt", "/local/test.txt")

        assert result is True
        mock_sftp.get.assert_called_once()

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_download_file_not_exists(self, mock_sftp_class):
        """测试下载文件不存在"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_sftp.stat.side_effect = FileNotFoundError()
        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        result = client.download("/remote/nonexistent.txt", "/local/test.txt")

        assert result is False

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_chmod_success(self, mock_sftp_class):
        """测试修改权限成功"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        result = client.chmod("/remote/file.txt", 0o755)

        assert result is True
        mock_sftp.chmod.assert_called_once_with("/remote/file.txt", 0o755)

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_exists_true(self, mock_sftp_class):
        """测试文件存在"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        result = client.exists("/remote/file.txt")

        assert result is True

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_exists_false(self, mock_sftp_class):
        """测试文件不存在"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_sftp.stat.side_effect = FileNotFoundError()
        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        result = client.exists("/remote/nonexistent.txt")

        assert result is False

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_remove_success(self, mock_sftp_class):
        """测试删除文件成功"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        result = client.remove("/remote/file.txt")

        assert result is True
        mock_sftp.remove.assert_called_once_with("/remote/file.txt")

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_list_dir_success(self, mock_sftp_class):
        """测试列出目录成功"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_sftp.listdir.return_value = ["file1.txt", "file2.py", "subdir"]
        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        client = SFTPClient(mock_ssh)
        result = client.list_dir("/remote/dir")

        assert result == ["file1.txt", "file2.py", "subdir"]

    @patch("syscrafts.core.sftp_client.paramiko.SFTPClient")
    def test_context_manager(self, mock_sftp_class):
        """测试上下文管理器"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_client = MagicMock()
        mock_sftp = MagicMock()

        mock_ssh.get_client.return_value = mock_client
        mock_client.open_sftp.return_value = mock_sftp

        with SFTPClient(mock_ssh) as client:
            # 调用 _get_sftp 来触发 SFTP 会话创建
            sftp = client._get_sftp()
            assert sftp is not None
            assert client._sftp is not None

        # 验证 close 被调用
        mock_sftp.close.assert_called()
