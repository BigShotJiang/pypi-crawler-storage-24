"""
并发池测试
"""

from unittest.mock import MagicMock, patch

import pytest

from hostweaver.concurrent.pool import DeployPool, DeployTask, HostConfig
from hostweaver.concurrent.reporter import DeploymentReporter
from hostweaver.workflow.single_deploy import DeploymentResult


class TestHostConfig:
    """HostConfig 测试类"""

    def test_init_basic(self):
        """测试基本初始化"""
        config = HostConfig(host="192.168.1.100", username="root")

        assert config.host == "192.168.1.100"
        assert config.username == "root"
        assert config.port == 22
        assert config.password is None
        assert config.pkey_path is None
        assert config.env_vars is None

    def test_init_with_all_params(self):
        """测试带所有参数初始化"""
        config = HostConfig(
            host="192.168.1.100",
            port=2222,
            username="admin",
            password="secret",
            pkey_path="~/.ssh/id_rsa",
            env_vars={"APP_ENV": "production"},
            extra={"region": "cn-east"},
        )

        assert config.port == 2222
        assert config.password == "secret"
        assert config.pkey_path == "~/.ssh/id_rsa"
        assert config.env_vars == {"APP_ENV": "production"}
        assert config.extra == {"region": "cn-east"}

    def test_str(self):
        """测试字符串表示"""
        config = HostConfig(host="192.168.1.100", username="root")

        assert "192.168.1.100" in str(config)


class TestDeployTask:
    """DeployTask 测试类"""

    def test_init(self):
        """测试初始化"""
        config = HostConfig(host="192.168.1.100", username="root")
        deployer_class = MagicMock

        task = DeployTask(
            config=config,
            deployer_class=deployer_class,
            deployer_kwargs={"source_path": "./test"},
        )

        assert task.config == config
        assert task.deployer_class == deployer_class
        assert task.deployer_kwargs == {"source_path": "./test"}
        assert task.future is None


class TestDeployPool:
    """DeployPool 测试类"""

    def test_init_default(self):
        """测试默认初始化"""
        pool = DeployPool()

        assert pool.max_workers == 5
        assert pool.log_prefix is True
        assert pool.tasks == []
        assert pool.results == []

    def test_init_custom_workers(self):
        """测试自定义工作线程数"""
        pool = DeployPool(max_workers=10, log_prefix=False)

        assert pool.max_workers == 10
        assert pool.log_prefix is False

    def test_add_task(self):
        """测试添加任务"""
        pool = DeployPool()
        config = HostConfig(host="192.168.1.100", username="root")

        pool.add_task(
            config=config,
            deployer_class=MagicMock,
            source_path="./test",
        )

        assert len(pool.tasks) == 1
        assert pool.tasks[0].config == config
        assert pool.tasks[0].deployer_kwargs == {"source_path": "./test"}

    def test_add_multiple_tasks(self):
        """测试添加多个任务"""
        pool = DeployPool()

        for i in range(5):
            config = HostConfig(host=f"192.168.1.{i}", username="root")
            pool.add_task(
                config=config,
                deployer_class=MagicMock,
                source_path="./test",
            )

        assert len(pool.tasks) == 5

    def test_add_task_chain(self):
        """测试链式调用"""
        pool = DeployPool()

        result = pool.add_task(
            config=HostConfig(host="192.168.1.100", username="root"),
            deployer_class=MagicMock,
            source_path="./test",
        )

        assert result is pool

    def test_add_hosts(self):
        """测试批量添加主机"""
        pool = DeployPool()

        pool.add_hosts(
            hosts=["192.168.1.1", "192.168.1.2", "192.168.1.3"],
            deployer_class=MagicMock,
            common_kwargs={"source_path": "./test"},
        )

        assert len(pool.tasks) == 3
        assert pool.tasks[0].config.host == "192.168.1.1"
        assert pool.tasks[1].config.host == "192.168.1.2"
        assert pool.tasks[2].config.host == "192.168.1.3"

    def test_add_hosts_with_configs(self):
        """测试带配置批量添加主机"""
        pool = DeployPool()

        configs = [
            HostConfig(host="192.168.1.1", username="admin"),
            HostConfig(host="192.168.1.2", username="root", port=2222),
        ]

        pool.add_hosts(
            hosts=[],
            deployer_class=MagicMock,
            common_kwargs={"source_path": "./test"},
            host_configs=configs,
        )

        assert len(pool.tasks) == 2
        assert pool.tasks[0].config.username == "admin"
        assert pool.tasks[1].config.port == 2222

    @patch("syscrafts.concurrent.pool.as_completed")
    @patch("syscrafts.concurrent.pool.ThreadPoolExecutor")
    @patch("syscrafts.workflow.single_deploy.SingleDeployWorkflow")
    def test_execute(self, mock_workflow_class, mock_executor_class, mock_as_completed):
        """测试执行任务"""
        mock_executor = MagicMock()
        mock_executor_class.return_value.__enter__ = MagicMock(
            return_value=mock_executor
        )
        mock_executor_class.return_value.__exit__ = MagicMock(return_value=None)

        mock_future = MagicMock()
        mock_future.result.return_value = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )
        mock_executor.submit.return_value = mock_future
        mock_as_completed.return_value = [mock_future]

        mock_workflow = MagicMock()
        mock_workflow.execute.return_value = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )
        mock_workflow_class.return_value = mock_workflow

        pool = DeployPool(max_workers=5)
        config = HostConfig(host="192.168.1.100", username="root")
        pool.add_task(
            config=config,
            deployer_class=MagicMock,
            source_path="./test",
        )

        results = pool.execute()

        assert len(results) == 1
        assert results[0].success is True

    @patch("syscrafts.concurrent.pool.as_completed")
    @patch("syscrafts.concurrent.pool.ThreadPoolExecutor")
    @patch("syscrafts.workflow.single_deploy.SingleDeployWorkflow")
    def test_execute_with_failures(
        self, mock_workflow_class, mock_executor_class, mock_as_completed
    ):
        """测试执行任务（部分失败）"""
        mock_executor = MagicMock()
        mock_executor_class.return_value.__enter__ = MagicMock(
            return_value=mock_executor
        )
        mock_executor_class.return_value.__exit__ = MagicMock(return_value=None)

        # 创建成功和失败的 future
        mock_future_success = MagicMock()
        mock_future_success.result.return_value = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )

        mock_future_failure = MagicMock()
        mock_future_failure.result.return_value = DeploymentResult(
            host="192.168.1.101",
            success=False,
            message="连接失败",
        )

        mock_executor.submit.side_effect = [mock_future_success, mock_future_failure]
        mock_as_completed.return_value = [mock_future_success, mock_future_failure]

        mock_workflow_success = MagicMock()
        mock_workflow_success.execute.return_value = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )

        mock_workflow_failure = MagicMock()
        mock_workflow_failure.execute.return_value = DeploymentResult(
            host="192.168.1.101",
            success=False,
            message="连接失败",
        )

        mock_workflow_class.side_effect = [mock_workflow_success, mock_workflow_failure]

        pool = DeployPool(max_workers=5)

        for i in range(2):
            config = HostConfig(host=f"192.168.1.{100+i}", username="root")
            pool.add_task(
                config=config,
                deployer_class=MagicMock,
                source_path="./test",
            )

        results = pool.execute()

        assert len(results) == 2
        success_count = sum(1 for r in results if r.success)
        assert success_count == 1

    @patch("syscrafts.concurrent.pool.ThreadPoolExecutor")
    @patch("syscrafts.workflow.single_deploy.SingleDeployWorkflow")
    def test_execute_empty_tasks(self, mock_workflow_class, mock_executor_class):
        """测试空任务执行"""
        pool = DeployPool()

        results = pool.execute()

        assert results == []

    @patch("syscrafts.concurrent.pool.as_completed")
    @patch("syscrafts.concurrent.pool.ThreadPoolExecutor")
    @patch("syscrafts.workflow.single_deploy.SingleDeployWorkflow")
    def test_execute_with_callback(
        self, mock_workflow_class, mock_executor_class, mock_as_completed
    ):
        """测试带进度回调执行"""
        mock_executor = MagicMock()
        mock_executor_class.return_value.__enter__ = MagicMock(
            return_value=mock_executor
        )
        mock_executor_class.return_value.__exit__ = MagicMock(return_value=None)

        mock_future = MagicMock()
        mock_future.result.return_value = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )
        mock_executor.submit.return_value = mock_future
        mock_as_completed.return_value = [mock_future]

        mock_workflow = MagicMock()
        mock_workflow.execute.return_value = DeploymentResult(
            host="192.168.1.100",
            success=True,
            message="部署成功",
        )
        mock_workflow_class.return_value = mock_workflow

        pool = DeployPool(max_workers=5)
        config = HostConfig(host="192.168.1.100", username="root")
        pool.add_task(
            config=config,
            deployer_class=MagicMock,
            source_path="./test",
        )

        callback = MagicMock()
        pool.execute(progress_callback=callback)

        assert callback.called

    def test_get_summary(self):
        """测试获取汇总"""
        pool = DeployPool()
        pool.results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
            DeploymentResult(host="192.168.1.102", success=True, message="成功"),
        ]

        summary = pool.get_summary()

        assert summary["total"] == 3
        assert summary["success"] == 2
        assert summary["failed"] == 1
        assert summary["success_rate"] == pytest.approx(2 / 3)
        assert "192.168.1.100" in summary["success_hosts"]
        assert "192.168.1.101" in summary["failed_hosts"]

    def test_get_summary_empty(self):
        """测试空结果汇总"""
        pool = DeployPool()
        summary = pool.get_summary()

        assert summary["total"] == 0
        assert summary["success"] == 0
        assert summary["failed"] == 0
        assert summary["success_rate"] == 0.0

    @patch("syscrafts.concurrent.pool.logger")
    def test_print_summary(self, mock_logger):
        """测试打印汇总"""
        pool = DeployPool()
        pool.results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
        ]

        pool.print_summary()

        assert mock_logger.info.called


class TestDeploymentReporter:
    """DeploymentReporter 测试类"""

    def test_init(self):
        """测试初始化"""
        results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
        ]

        reporter = DeploymentReporter(results)

        assert len(reporter.results) == 2

    def test_get_summary(self):
        """测试获取汇总"""
        results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
            DeploymentResult(host="192.168.1.102", success=True, message="成功"),
        ]

        reporter = DeploymentReporter(results)
        summary = reporter.get_summary()

        assert summary["total"] == 3
        assert summary["success_count"] == 2
        assert summary["failed_count"] == 1
        assert summary["success_rate"] == pytest.approx(2 / 3)
        assert "192.168.1.100" in summary["success_hosts"]
        assert "192.168.1.101" in summary["failed_hosts"]

    def test_get_summary_empty(self):
        """测试空结果汇总"""
        reporter = DeploymentReporter([])
        summary = reporter.get_summary()

        assert summary["total"] == 0
        assert summary["success_count"] == 0
        assert summary["failed_count"] == 0
        assert summary["success_rate"] == 0.0

    def test_get_summary_with_duration(self):
        """测试带耗时的汇总"""
        from datetime import datetime, timedelta

        end_time = datetime.now()
        start_time = end_time - timedelta(seconds=10)

        results = [
            DeploymentResult(
                host="192.168.1.100",
                success=True,
                message="成功",
                start_time=start_time,
                end_time=end_time,
            ),
        ]

        reporter = DeploymentReporter(results)
        summary = reporter.get_summary()

        assert summary["avg_duration"] is not None
        assert summary["avg_duration"] >= 10

    def test_get_success_results(self):
        """测试获取成功结果"""
        results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
        ]

        reporter = DeploymentReporter(results)
        success_results = [r for r in reporter.results if r.success]

        assert len(success_results) == 1
        assert success_results[0].host == "192.168.1.100"

    def test_get_failed_results(self):
        """测试获取失败结果"""
        results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
        ]

        reporter = DeploymentReporter(results)
        failed_results = [r for r in reporter.results if not r.success]

        assert len(failed_results) == 1
        assert failed_results[0].host == "192.168.1.101"

    @patch("syscrafts.concurrent.reporter.console")
    def test_print_report(self, mock_console):
        """测试打印报告"""
        results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
        ]

        reporter = DeploymentReporter(results)
        reporter.print_report(verbose=True)

        assert mock_console.print.called

    def test_generate_text_report(self):
        """测试生成文本报告"""
        results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
        ]

        reporter = DeploymentReporter(results)
        report = reporter.generate_text_report(verbose=True)

        assert "部署汇总报告" in report
        assert "192.168.1.100" in report
        assert "192.168.1.101" in report
        assert "详细信息" in report

    def test_generate_text_report_verbose(self):
        """测试生成详细文本报告"""
        results = [
            DeploymentResult(
                host="192.168.1.100",
                success=True,
                message="成功",
                machine_id="abc123",
            ),
        ]

        reporter = DeploymentReporter(results)
        report = reporter.generate_text_report(verbose=True)

        assert "abc123" in report

    def test_generate_json_report(self):
        """测试生成 JSON 报告"""
        results = [
            DeploymentResult(host="192.168.1.100", success=True, message="成功"),
            DeploymentResult(host="192.168.1.101", success=False, message="失败"),
        ]

        reporter = DeploymentReporter(results)
        report = reporter.generate_json_report()

        assert "summary" in report
        assert "success_hosts" in report
        assert "failed_hosts" in report
        assert "results" in report
        assert len(report["results"]) == 2

    def test_deployment_result_duration(self):
        """测试部署结果耗时计算"""
        from datetime import datetime, timedelta

        end_time = datetime.now()
        start_time = end_time - timedelta(seconds=15.5)

        result = DeploymentResult(
            host="192.168.1.100",
            success=True,
            start_time=start_time,
            end_time=end_time,
        )

        assert result.duration is not None
        assert result.duration >= 15.0

    def test_deployment_result_no_duration(self):
        """测试无耗时信息"""
        result = DeploymentResult(host="192.168.1.100", success=True)

        assert result.duration is None

    def test_deployment_result_post_init(self):
        """测试 post_init 初始化 details"""
        result = DeploymentResult(host="192.168.1.100", success=True)

        assert result.details == {}

    def test_deployment_result_with_details(self):
        """测试带 details 初始化"""
        result = DeploymentResult(
            host="192.168.1.100",
            success=True,
            details={"key": "value"},
        )

        assert result.details == {"key": "value"}
