"""
SSH 客户端测试
"""

from unittest.mock import MagicMock, patch

import paramiko
import pytest

from hostweaver.core.ssh_client import SSHClientPool


class TestSSHClientPool:
    """SSHClientPool 测试类"""

    def test_init_with_password(self):
        """测试使用密码初始化"""
        pool = SSHClientPool(
            host="192.168.1.100",
            port=22,
            username="root",
            password="testpass",
        )

        assert pool.host == "192.168.1.100"
        assert pool.port == 22
        assert pool.username == "root"
        assert pool.password == "testpass"
        assert pool.pkey_path is None

    def test_init_with_pkey(self):
        """测试使用私钥初始化"""
        pool = SSHClientPool(
            host="192.168.1.100",
            port=22,
            username="root",
            pkey_path="~/.ssh/id_rsa",
        )

        assert pool.pkey_path == "~/.ssh/id_rsa"
        assert pool.password is None

    def test_init_requires_auth(self):
        """测试必须提供密码或私钥"""
        with pytest.raises(ValueError, match="必须提供至少一种认证方式"):
            SSHClientPool(
                host="192.168.1.100",
                username="root",
            )

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_connect_with_password(self, mock_ssh_class):
        """测试使用密码连接"""
        mock_client = MagicMock()
        mock_ssh_class.return_value = mock_client

        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )

        result = pool.connect()

        # connect() 返回 self，支持链式调用
        assert result is pool
        assert pool._connected is True
        mock_client.set_missing_host_key_policy.assert_called_once()
        mock_client.connect.assert_called_once()

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_connect_with_pkey(self, mock_ssh_class):
        """测试使用私钥连接"""
        mock_client = MagicMock()
        mock_ssh_class.return_value = mock_client
        mock_pkey = MagicMock(spec=paramiko.PKey)

        # Mock pkey loading
        with patch.object(SSHClientPool, "_load_pkey", return_value=mock_pkey):
            pool = SSHClientPool(
                host="192.168.1.100",
                username="root",
                pkey_path="~/.ssh/id_rsa",
            )

            result = pool.connect()

            # connect() 返回 self，支持链式调用
            assert result is pool
            assert pool._connected is True
            mock_client.connect.assert_called_once()

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_connect_failure(self, mock_ssh_class):
        """测试连接失败"""
        mock_client = MagicMock()
        mock_client.connect.side_effect = paramiko.SSHException("Connection refused")
        mock_ssh_class.return_value = mock_client

        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )

        with pytest.raises(paramiko.SSHException):
            pool.connect()

    def test_is_connected(self):
        """测试连接状态检查"""
        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )

        # 初始状态未连接
        assert pool.is_connected() is False

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_is_connected_after_connect(self, mock_ssh_class):
        """测试连接后状态"""
        mock_client = MagicMock()
        mock_ssh_class.return_value = mock_client

        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )
        pool.connect()

        assert pool.is_connected() is True

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_exec_command(self, mock_ssh_class):
        """测试执行命令"""
        mock_client = MagicMock()
        mock_stdin = MagicMock()
        mock_stdout = MagicMock()
        mock_stderr = MagicMock()

        mock_client.exec_command.return_value = (mock_stdin, mock_stdout, mock_stderr)
        mock_stdout.read.return_value = b"output\n"
        mock_stderr.read.return_value = b"error\n"
        mock_stdout.channel.recv_exit_status.return_value = 0

        mock_ssh_class.return_value = mock_client

        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )
        pool.connect()

        output, error, exit_code = pool.exec_command("ls -la")

        assert output == "output\n"
        assert error == "error\n"
        assert exit_code == 0

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_exec_command_not_connected(self, mock_ssh_class):
        """测试未连接时执行命令"""
        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )

        with pytest.raises(paramiko.SSHException, match="SSH 未连接"):
            pool.exec_command("ls -la")

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_disconnect(self, mock_ssh_class):
        """测试断开连接"""
        mock_client = MagicMock()
        mock_ssh_class.return_value = mock_client

        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )
        pool.connect()
        pool.disconnect()

        mock_client.close.assert_called_once()
        assert pool._client is None

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_context_manager(self, mock_ssh_class):
        """测试上下文管理器"""
        mock_client = MagicMock()
        mock_ssh_class.return_value = mock_client

        with SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        ) as pool:
            assert pool.is_connected() is True

        mock_client.close.assert_called_once()

    @patch("syscrafts.core.ssh_client.SSHClient")
    def test_reconnect(self, mock_ssh_class):
        """测试重新连接"""
        mock_client = MagicMock()
        mock_ssh_class.return_value = mock_client

        pool = SSHClientPool(
            host="192.168.1.100",
            username="root",
            password="testpass",
        )

        # 首次连接
        pool.connect()
        assert pool.is_connected() is True

        # 断开
        pool.disconnect()
        assert pool.is_connected() is False

        # 重新连接
        pool.connect()
        assert pool.is_connected() is True
