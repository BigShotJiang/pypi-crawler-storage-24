"""
机器指纹提取器测试
"""

from unittest.mock import MagicMock

from hostweaver.business.fingerprint import FingerprintExtractor


class TestFingerprintExtractor:
    """FingerprintExtractor 测试类"""

    def test_init(self):
        """测试初始化"""
        mock_ssh = MagicMock()
        extractor = FingerprintExtractor(mock_ssh)

        assert extractor.ssh_pool == mock_ssh

    def test_get_machine_id_success(self):
        """测试成功获取 machine-id"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("8f3a2b1c-e5f7d9a4\n", "", 0)

        extractor = FingerprintExtractor(mock_ssh)
        fingerprint = extractor.get_machine_id()

        assert fingerprint == "8f3a2b1c-e5f7d9a4"

    def test_get_machine_id_empty(self):
        """测试 machine-id 为空"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        extractor = FingerprintExtractor(mock_ssh)
        fingerprint = extractor.get_machine_id()

        assert fingerprint is None

    def test_get_machine_id_not_connected(self):
        """测试 SSH 未连接时获取 machine-id"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = False

        extractor = FingerprintExtractor(mock_ssh)
        fingerprint = extractor.get_machine_id()

        assert fingerprint is None

    def test_get_board_serial_success(self):
        """测试成功获取主板序列号"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("SN123456789\n", "", 0)

        extractor = FingerprintExtractor(mock_ssh)
        serial = extractor.get_board_serial()

        assert serial == "SN123456789"

    def test_get_board_serial_not_specified(self):
        """测试主板序列号为 'Not Specified'"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("Not Specified\n", "", 0)

        extractor = FingerprintExtractor(mock_ssh)
        serial = extractor.get_board_serial()

        assert serial is None

    def test_get_board_serial_not_connected(self):
        """测试 SSH 未连接时获取主板序列号"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = False

        extractor = FingerprintExtractor(mock_ssh)
        serial = extractor.get_board_serial()

        assert serial is None

    def test_get_hostname_success(self):
        """测试成功获取主机名"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("myserver\n", "", 0)

        extractor = FingerprintExtractor(mock_ssh)
        hostname = extractor.get_hostname()

        assert hostname == "myserver"

    def test_get_hostname_empty(self):
        """测试主机名为空"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        extractor = FingerprintExtractor(mock_ssh)
        hostname = extractor.get_hostname()

        assert hostname is None

    def test_get_fingerprint_with_machine_id(self):
        """测试获取指纹（machine-id 可用）"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        # 第一次调用返回 machine-id
        mock_ssh.exec_command.side_effect = [
            ("8f3a2b1c-e5f7d9a4\n", "", 0),  # get_machine_id
        ]

        extractor = FingerprintExtractor(mock_ssh)
        fingerprint = extractor.get_fingerprint()

        assert fingerprint == "mid:8f3a2b1c-e5f7d9a4"

    def test_get_fingerprint_with_board_serial(self):
        """测试获取指纹（主板序列号备用）"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        # machine-id 失败，返回主板序列号
        mock_ssh.exec_command.side_effect = [
            ("", "", 0),  # get_machine_id
            ("SN123456789\n", "", 0),  # get_board_serial
        ]

        extractor = FingerprintExtractor(mock_ssh)
        fingerprint = extractor.get_fingerprint()

        assert fingerprint == "bsn:SN123456789"

    def test_get_fingerprint_with_hostname(self):
        """测试获取指纹（主机名备用）"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        # machine-id 和主板序列号都失败，返回主机名
        mock_ssh.exec_command.side_effect = [
            ("", "", 0),  # get_machine_id
            ("", "", 0),  # get_board_serial
            ("myserver\n", "", 0),  # get_hostname
            ("x86_64\n", "", 0),  # uname -m
        ]

        extractor = FingerprintExtractor(mock_ssh)
        fingerprint = extractor.get_fingerprint()

        assert fingerprint is not None
        assert fingerprint.startswith("host:myserver:")

    def test_get_fingerprint_all_failures(self):
        """测试所有方式都失败"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        # 所有调用都返回空
        mock_ssh.exec_command.side_effect = [
            ("", "", 0),  # get_machine_id
            ("", "", 0),  # get_board_serial
            ("", "", 0),  # get_hostname
        ]

        extractor = FingerprintExtractor(mock_ssh)
        fingerprint = extractor.get_fingerprint()

        assert fingerprint is None

    def test_get_system_info(self):
        """测试获取系统信息"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.side_effect = [
            ("NAME=Ubuntu\nVERSION=20.04\nID=ubuntu\n", "", 0),  # os-release
            ("5.4.0-generic\n", "", 0),  # uname -r
            ("x86_64\n", "", 0),  # uname -m
            ("8\n", "", 0),  # nproc
        ]

        extractor = FingerprintExtractor(mock_ssh)
        info = extractor.get_system_info()

        assert "os_release" in info
        assert "kernel" in info
        assert "architecture" in info
        assert "cpu_cores" in info
