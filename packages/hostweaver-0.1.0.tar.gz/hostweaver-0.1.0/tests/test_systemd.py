"""
Systemd 管理器测试
"""

from unittest.mock import MagicMock

import pytest

from hostweaver.core.systemd import SystemdManager


class TestSystemdManager:
    """SystemdManager 测试类"""

    def test_init(self):
        """测试初始化"""
        mock_ssh = MagicMock()
        manager = SystemdManager(mock_ssh)

        assert manager.ssh_pool == mock_ssh

    def test_exec_command(self):
        """测试执行命令"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("output\n", "", 0)

        manager = SystemdManager(mock_ssh)
        output, error, exit_code = manager._exec_command("systemctl status test")

        assert output == "output\n"
        assert error == ""
        assert exit_code == 0
        mock_ssh.exec_command.assert_called_once_with("systemctl status test", 60)

    def test_exec_command_not_connected(self):
        """测试未连接时执行命令"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = False

        manager = SystemdManager(mock_ssh)

        with pytest.raises(ConnectionError):
            manager._exec_command("systemctl status test")

    def test_generate_service_file(self):
        """测试生成服务文件"""
        mock_ssh = MagicMock()
        manager = SystemdManager(mock_ssh)

        content = manager.generate_service_file(
            name="test-service",
            exec_path="/opt/app/main.py",
            working_directory="/opt/app",
            env_vars={"APP_ENV": "production", "APP_PORT": "8000"},
            description="Test Service",
        )

        assert "[Unit]" in content
        assert "Description=Test Service" in content
        assert "[Service]" in content
        assert "ExecStart=/opt/app/main.py" in content
        assert "WorkingDirectory=/opt/app" in content
        assert 'Environment="APP_ENV=production"' in content
        assert 'Environment="APP_PORT=8000"' in content
        assert "[Install]" in content
        assert "WantedBy=multi-user.target" in content

    def test_generate_service_file_minimal(self):
        """测试生成最小服务文件"""
        mock_ssh = MagicMock()
        manager = SystemdManager(mock_ssh)

        content = manager.generate_service_file(
            name="test-service",
            exec_path="/opt/app/main.py",
        )

        assert "[Unit]" in content
        assert "Description=test-service Service" in content
        assert "ExecStart=/opt/app/main.py" in content

    def test_write_service_file(self):
        """测试写入服务文件"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.write_service_file("test-service", "[Unit]\n...")

        assert result is True

    def test_write_service_file_failure(self):
        """测试写入服务文件失败"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "Permission denied", 1)

        manager = SystemdManager(mock_ssh)
        result = manager.write_service_file("test-service", "[Unit]\n...")

        assert result is False

    def test_daemon_reload(self):
        """测试重载 systemd 配置"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.daemon_reload()

        assert result is True
        mock_ssh.exec_command.assert_called_with("sudo systemctl daemon-reload", 60)

    def test_start(self):
        """测试启动服务"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.start("test-service")

        assert result is True
        mock_ssh.exec_command.assert_called_with(
            "sudo systemctl start test-service", 60
        )

    def test_stop(self):
        """测试停止服务"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.stop("test-service")

        assert result is True
        mock_ssh.exec_command.assert_called_with("sudo systemctl stop test-service", 60)

    def test_restart(self):
        """测试重启服务"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.restart("test-service")

        assert result is True
        mock_ssh.exec_command.assert_called_with(
            "sudo systemctl restart test-service", 60
        )

    def test_reload(self):
        """测试重载服务配置"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.reload("test-service")

        assert result is True
        mock_ssh.exec_command.assert_called_with(
            "sudo systemctl reload test-service", 60
        )

    def test_enable(self):
        """测试启用服务"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.enable("test-service")

        assert result is True
        mock_ssh.exec_command.assert_called_with(
            "sudo systemctl enable test-service", 60
        )

    def test_disable(self):
        """测试禁用服务"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.disable("test-service")

        assert result is True
        mock_ssh.exec_command.assert_called_with(
            "sudo systemctl disable test-service", 60
        )

    def test_status(self):
        """测试获取服务状态"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = (
            "● test-service - Test\n   Active: active (running)",
            "",
            0,
        )

        manager = SystemdManager(mock_ssh)
        status = manager.status("test-service")

        assert "test-service" in status
        assert "active" in status

    def test_is_active_true(self):
        """测试服务处于 active 状态"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("active", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.is_active("test-service")

        assert result is True

    def test_is_active_false(self):
        """测试服务处于 inactive 状态"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("Active: inactive (dead)", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.is_active("test-service")

        assert result is False

    def test_is_enabled_true(self):
        """测试服务已启用"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("enabled", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.is_enabled("test-service")

        assert result is True

    def test_is_enabled_false(self):
        """测试服务未启用"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("disabled", "", 0)

        manager = SystemdManager(mock_ssh)
        result = manager.is_enabled("test-service")

        assert result is False

    def test_get_logs(self):
        """测试获取服务日志"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("Log line 1\nLog line 2\n", "", 0)

        manager = SystemdManager(mock_ssh)
        logs = manager.get_logs("test-service", lines=50)

        assert "Log line 1" in logs
        assert "Log line 2" in logs
        mock_ssh.exec_command.assert_called_with(
            "journalctl -u test-service -n 50 --no-pager", 60
        )

    def test_get_logs_default_lines(self):
        """测试获取默认行数日志"""
        mock_ssh = MagicMock()
        mock_ssh.is_connected.return_value = True
        mock_ssh.exec_command.return_value = ("Log\n", "", 0)

        manager = SystemdManager(mock_ssh)
        logs = manager.get_logs("test-service")

        assert "Log" in logs
        mock_ssh.exec_command.assert_called_with(
            "journalctl -u test-service -n 20 --no-pager", 60
        )
