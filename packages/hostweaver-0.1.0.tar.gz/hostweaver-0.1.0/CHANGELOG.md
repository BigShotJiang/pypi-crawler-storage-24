# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-15

这是 HostWeaver 的第一个公开发布版本，包含完整的远程部署与状态管理功能。

**主要特性：**

- 🔐 基于 SSH/SFTP 的安全文件传输
- ⚙️ Systemd 服务自动配置和管理
- 🔑 基于机器指纹的 License 生成
- 🚀 一键部署工作流
- 🖥️ 多机并发部署支持
- 🎨 优雅的命令行界面

**适用场景：**

- Python 应用远程部署
- 二进制文件分发和部署
- 多服务器批量部署
- 需要授权管理的商业应用部署
