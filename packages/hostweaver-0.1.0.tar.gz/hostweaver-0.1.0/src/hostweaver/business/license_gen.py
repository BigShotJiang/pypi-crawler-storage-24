"""
License Key 生成器

基于机器指纹生成授权密钥。
支持多种算法和自定义生成方法。
"""

import hashlib
import hmac
import logging
from abc import ABC, abstractmethod
from collections.abc import Callable

logger = logging.getLogger(__name__)


class LicenseProvider(ABC):
    """
    License 提供者抽象基类

    继承此类可实现自定义 License 生成逻辑。

    类属性:
        env_name: License 环境变量名（默认 "APP_LICENSE_KEY"）
    """

    env_name: str = "APP_LICENSE_KEY"

    @abstractmethod
    def generate(self, machine_id: str) -> str | None:
        """
        生成 License Key

        Args:
            machine_id: 机器指纹

        Returns:
            License Key 字符串，None 表示不生成
        """
        pass


class LicenseGenerator(LicenseProvider):
    """
    License Key 生成器

    基于 machine_id 和 secret_key 生成授权密钥。
    支持多种算法：
    - hmac: HMAC-SHA256 签名（默认）
    - simple: 简单哈希拼接
    - custom: 自定义生成函数

    格式示例：LIC-8f3a2b1c-a7b3c9d2
    """

    def __init__(
        self,
        secret_key: bytes | None = None,
        method: str = "hmac",
        custom_generator: Callable[[str, bytes], str] | None = None,
        license_prefix: str = "LIC",
        env_name: str = "APP_LICENSE_KEY",
    ):
        """
        初始化 License 生成器

        Args:
            secret_key: 加盐密钥（可选，用于增加哈希复杂度）
            method: 生成方法，支持 'hmac', 'simple', 'custom'
            custom_generator: 自定义生成函数，签名：(machine_id: str, secret_key: bytes) -> str
            license_prefix: License 前缀标识
            env_name: 环境变量名
        """
        self.secret_key = secret_key or b"syscrafts-default-2026"
        self.method = method
        self.custom_generator = custom_generator
        self.license_prefix = license_prefix
        self.env_name = env_name

    def generate(self, machine_id: str) -> str:
        """
        生成 License Key

        Args:
            machine_id: 机器标识（通常是 /etc/machine-id 的内容）

        Returns:
            格式化的 License Key 字符串
        """
        if self.method == "custom" and self.custom_generator:
            return self.custom_generator(machine_id, self.secret_key)
        elif self.method == "simple":
            return self._generate_simple(machine_id)
        else:  # hmac
            return self._generate_hmac(machine_id)

    def _generate_hmac(self, machine_id: str) -> str:
        """使用 HMAC-SHA256 生成 License Key"""
        mid_prefix = machine_id[:8] if len(machine_id) >= 8 else machine_id
        h = hmac.new(self.secret_key, machine_id.encode("utf-8"), hashlib.sha256)
        hash_suffix = h.hexdigest()[:8]
        return f"{self.license_prefix}-{mid_prefix}-{hash_suffix}"

    def _generate_simple(self, machine_id: str) -> str:
        """使用简单哈希拼接生成 License Key"""
        mid_prefix = machine_id[:8] if len(machine_id) >= 8 else machine_id
        hash_input = self.secret_key + machine_id.encode("utf-8")
        hash_suffix = hashlib.sha256(hash_input).hexdigest()[:8]
        return f"{self.license_prefix}-{mid_prefix}-{hash_suffix}"

    def verify(self, machine_id: str, license_key: str) -> bool:
        """
        验证 License Key

        Args:
            machine_id: 机器标识
            license_key: 待验证的 License Key

        Returns:
            验证是否成功
        """
        if self.method == "custom":
            logger.warning("自定义方法不支持自动验证")
            return True
        return license_key == self.generate(machine_id)
