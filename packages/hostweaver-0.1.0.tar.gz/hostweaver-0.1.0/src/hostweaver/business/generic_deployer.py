"""
通用应用部署器

继承 BaseDeployer，实现通用的应用部署逻辑。
支持部署单个文件或整个项目目录。
支持简单的 License 生成功能，可自定义生成方法。
"""

import logging
from pathlib import Path

from hostweaver.business.fingerprint import FingerprintExtractor
from hostweaver.business.license_gen import LicenseGenerator, LicenseProvider
from hostweaver.core.base_deployer import BaseDeployer

logger = logging.getLogger(__name__)

# 默认忽略模式
DEFAULT_IGNORE_PATTERNS = [
    "*.pyc",
    "*.pyo",
    "__pycache__",
    "*.so",
    ".git",
    ".gitignore",
    "*.md",
    "tests",
    ".pytest_cache",
    ".mypy_cache",
    "htmlcov",
    ".coverage",
    "venv",
    ".venv",
    "env",
    ".env",
    "node_modules",
    "dist",
    "build",
    "*.egg-info",
]


class GenericDeployer(BaseDeployer):
    """
    通用应用部署器

    继承 BaseDeployer，实现具体的部署逻辑：
    1. 获取机器指纹
    2. 生成 License Key（如果提供了 license_provider 或 secret_key）
    3. 上传项目文件或目录
    4. 配置 Systemd 服务
    5. 启动并验证服务

    这是一个通用的部署器实现，可用于部署任何类型的应用程序。
    """

    def __init__(
        self,
        host: str,
        source_path: str,
        install_dir: str = "/opt/app",
        service_name: str = "myapp",
        env_vars: dict[str, str] | None = None,
        entrypoint: str = "main.py",
        ignore_patterns: list[str] | None = None,
        secret_key: str | None = None,
        license_provider: LicenseProvider | None = None,
        env_auto_append: bool = True,
        **ssh_kwargs,
    ):
        """
        初始化通用部署器

        Args:
            host: 远程主机地址
            source_path: 本地源路径（可以是单个文件或整个目录）
            install_dir: 远程安装目录
            service_name: Systemd 服务名称
            env_vars: 环境变量字典
            entrypoint: 应用入口文件名（相对于 install_dir）
            ignore_patterns: 上传目录时的忽略模式列表（默认使用 DEFAULT_IGNORE_PATTERNS）
            secret_key: License 生成密钥（可选，使用默认 HMAC-SHA256 算法）
            license_provider: License 提供者（可选，继承自 LicenseProvider）
            env_auto_append: 是否自动添加 License、APP_ENV 等环境变量
            **ssh_kwargs: SSH 连接参数（username, password, pkey_path 等）

        示例:
            # 使用默认 License 生成
            deployer = GenericDeployer(
                host="192.168.1.100",
                source_path="./dist/app",
                secret_key="your-secret",
            )

            # 使用自定义 License Provider（带初始化参数）
            class MyLicenseProvider(LicenseProvider):
                env_name = "MY_APP_LICENSE"

                def __init__(self, secret_key: str):
                    self.secret_key = secret_key

                def generate(self, machine_id: str) -> str:
                    import hashlib
                    return f"APP-{hashlib.sha256((machine_id + self.secret_key).encode()).hexdigest()[:16]}"

            deployer = GenericDeployer(
                host="192.168.1.100",
                source_path="./dist/app",
                license_provider=MyLicenseProvider("my-secret"),
            )

        """
        super().__init__(host=host, **ssh_kwargs)

        self.source_path = source_path
        self.install_dir = install_dir
        self.service_name = service_name
        self.env_vars = env_vars or {}
        self.entrypoint = entrypoint
        self.ignore_patterns = ignore_patterns or DEFAULT_IGNORE_PATTERNS
        self.secret_key = secret_key
        self.license_provider = license_provider
        self.env_auto_append = env_auto_append

        # 部署过程中获取的数据
        self.machine_id: str | None = None
        self.license_key: str | None = None

        # 验证源路径
        self._validate_source()

    def _validate_source(self):
        """验证源路径是否存在"""
        source = Path(self.source_path).expanduser()
        if not source.exists():
            raise FileNotFoundError(f"源路径不存在：{source}")
        logger.debug(
            f"源路径验证通过：{source} ({'目录' if source.is_dir() else '文件'})"
        )

    def pre_deploy(self) -> bool:
        """
        部署前准备

        1. 获取机器指纹
        2. 停止旧服务
        3. 生成 License Key

        Returns:
            准备是否成功
        """
        try:
            # 1. 获取机器指纹
            logger.info(f"正在获取机器指纹：{self.host}")
            assert self.ssh_pool
            fingerprint_extractor = FingerprintExtractor(self.ssh_pool)
            self.machine_id = fingerprint_extractor.get_fingerprint()

            if not self.machine_id:
                logger.error("无法获取机器指纹")
                self._result.message = "无法获取机器指纹"
                return False

            logger.info(f"获取到机器指纹：{self.machine_id[:16]}...")

            # 2. 停止旧服务
            logger.info(f"正在停止旧服务：{self.service_name}")
            assert self.systemd_manager
            self.systemd_manager.stop(self.service_name)

            # 3. 生成 License Key
            if self.license_provider:
                # 使用自定义 License Provider
                logger.info("使用自定义 License Provider 生成 License Key")
                self.license_key = self.license_provider.generate(self.machine_id)
                if self.license_key and self.env_auto_append:
                    self.env_vars[self.license_provider.env_name] = self.license_key
                    logger.debug(
                        f"License Key 生成成功并注入环境变量 {self.license_provider.env_name}"
                    )
            elif self.secret_key:
                # 使用默认生成方法
                logger.info("正在生成 License Key")
                license_gen = LicenseGenerator(
                    secret_key=self.secret_key.encode("utf-8")
                )
                self.license_key = license_gen.generate(self.machine_id)
                if self.license_key and self.env_auto_append:
                    self.env_vars["APP_LICENSE_KEY"] = self.license_key
                    logger.debug("License Key 生成成功并注入环境变量 APP_LICENSE_KEY")
            else:
                logger.warning(
                    "未提供 secret_key 或 license_provider，跳过 License Key 生成"
                )

            # 4. 确保安装目录存在
            logger.info(f"确保安装目录存在：{self.install_dir}")
            mkdir_cmd = f"sudo mkdir -p {self.install_dir}"
            self.exec_command(mkdir_cmd)

            return True

        except Exception as e:
            logger.error(f"部署前准备失败：{e}")
            self._result.message = f"部署前准备失败：{e}"
            return False

    def run(self) -> bool:
        """
        执行部署

        1. 上传项目文件或目录
        2. 生成并写入 .service 文件
        3. 重载 systemd

        Returns:
            部署是否成功
        """
        try:
            source = Path(self.source_path).expanduser()

            # 1. 上传项目文件或目录
            if source.is_file():
                # 单个文件（如二进制文件）
                remote_entrypoint = f"{self.install_dir}/{source.name}"
                logger.info(f"准备上传文件：{source}")

                if not self.upload_file(
                    str(source), remote_entrypoint, executable=True
                ):
                    logger.error("文件上传失败")
                    self._result.message = "文件上传失败"
                    return False

                exec_path = remote_entrypoint
            else:
                # 目录 - 上传整个目录
                logger.info(f"上传目录：{source} -> {self.install_dir}")
                logger.debug(f"忽略模式：{self.ignore_patterns}")

                if not self.upload_directory(
                    str(source), self.install_dir, ignore_patterns=self.ignore_patterns
                ):
                    logger.error("目录上传失败")
                    self._result.message = "目录上传失败"
                    return False

                # 设置入口点
                exec_path = f"{self.install_dir}/{self.entrypoint}"

            # 2. 准备环境变量
            service_env_vars = self.env_vars.copy()
            # 只在未显式设置时添加默认值
            if self.env_auto_append:
                service_env_vars.setdefault("APP_ENV", "production")

            # 3. 生成 .service 文件
            assert self.systemd_manager
            logger.info(f"生成 Systemd 服务配置：{self.service_name}")
            service_content = self.systemd_manager.generate_service_file(
                name=self.service_name,
                exec_path=exec_path,
                working_directory=self.install_dir,
                env_vars=service_env_vars,
                description=f"Application Service - {self.service_name}",
            )

            # 4. 写入 .service 文件
            if not self.systemd_manager.write_service_file(
                self.service_name, service_content
            ):
                logger.error("写入服务文件失败")
                self._result.message = "写入服务文件失败"
                return False

            # 5. 重载 systemd
            logger.info("重载 systemd 配置")
            if not self.systemd_manager.daemon_reload():
                logger.error("systemd 重载失败")
                self._result.message = "systemd 重载失败"
                return False

            # 保存部署详情
            self._result.details.update(
                {
                    "source_path": str(source),
                    "source_type": "file" if source.is_file() else "directory",
                    "exec_path": exec_path,
                    "install_dir": self.install_dir,
                    "machine_id": self.machine_id[:16] if self.machine_id else None,
                }
            )

            return True

        except Exception as e:
            logger.error(f"部署执行失败：{e}")
            self._result.message = f"部署执行失败：{e}"
            return False

    def post_deploy(self) -> bool:
        """
        部署后处理

        1. 启动服务
        2. 验证服务状态
        3. 输出日志

        Returns:
            处理是否成功
        """
        try:
            # 1. 启动服务
            logger.info(f"启动服务：{self.service_name}")
            assert self.systemd_manager
            if not self.systemd_manager.start(self.service_name):
                logger.error("服务启动失败")
                self._result.message = "服务启动失败"
                return False

            # 2. 等待服务启动
            import time

            time.sleep(2)

            # 3. 验证服务状态
            logger.info("验证服务状态")
            is_active = self.systemd_manager.is_active(self.service_name)
            if not is_active:
                logger.warning("服务未处于 active 状态")
                self._result.details["service_active"] = False
            else:
                self._result.details["service_active"] = True

            # 4. 获取服务状态
            status = self.get_service_status(self.service_name)
            self._result.details["service_status"] = status
            logger.info(f"部署完成，服务状态：{status[:100]}...")

            # 5. 获取日志
            logs = self.get_service_logs(self.service_name, lines=20)
            self._result.details["service_logs"] = logs
            logger.info(f"日志信息：{logs[:200]}...")

            return True

        except Exception as e:
            logger.error(f"部署后处理失败：{e}")
            self._result.message = f"部署后处理失败：{e}"
            return False

    def get_logs(self, lines: int = 50) -> str:
        """
        获取服务日志

        Args:
            lines: 日志行数

        Returns:
            日志内容
        """
        return self.get_service_logs(self.service_name, lines)

    def restart(self) -> bool:
        """
        重启服务（便捷方法）

        Returns:
            操作是否成功
        """
        assert self.systemd_manager
        return self.systemd_manager.restart(self.service_name)

    def stop(self) -> bool:
        """
        停止服务（便捷方法）

        Returns:
            操作是否成功
        """
        assert self.systemd_manager
        return self.systemd_manager.stop(self.service_name)

    def status(self) -> str:
        """
        获取服务状态（便捷方法）

        Returns:
            状态输出
        """
        return self.get_service_status(self.service_name)
