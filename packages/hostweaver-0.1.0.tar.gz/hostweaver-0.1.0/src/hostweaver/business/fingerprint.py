"""
机器指纹提取模块

用于读取远程服务器的唯一标识信息。
"""

import logging

from hostweaver.core.ssh_client import SSHClientPool

logger = logging.getLogger(__name__)


class FingerprintExtractor:
    """
    机器指纹提取器

    功能:
    - 读取 /etc/machine-id
    - 读取主板序列号 (dmidecode)
    - 生成唯一机器标识
    """

    def __init__(self, ssh_pool: SSHClientPool):
        """
        初始化指纹提取器

        Args:
            ssh_pool: SSH 连接池实例
        """
        self.ssh_pool = ssh_pool

    def _exec_command(self, command: str) -> tuple:
        """执行远程命令"""
        if not self.ssh_pool.is_connected():
            raise ConnectionError("SSH 未连接")
        return self.ssh_pool.exec_command(command)

    def get_machine_id(self) -> str | None:
        """
        获取 /etc/machine-id

        Returns:
            machine-id 字符串，如果获取失败则返回 None
        """
        try:
            # 尝试读取 /etc/machine-id
            command = "cat /etc/machine-id 2>/dev/null || cat /var/lib/dbus/machine-id 2>/dev/null || echo ''"
            output, error, exit_code = self._exec_command(command)

            machine_id = output.strip()
            if machine_id:
                logger.debug(f"获取到 machine-id: {machine_id[:8]}...")
                return machine_id
            else:
                logger.warning("无法获取 machine-id")
                return None

        except Exception as e:
            logger.error(f"获取 machine-id 失败：{e}")
            return None

    def get_board_serial(self) -> str | None:
        """
        获取主板序列号（需要 sudo 权限）

        Returns:
            主板序列号，如果获取失败则返回 None
        """
        try:
            # 使用 dmidecode 获取主板序列号
            command = "sudo dmidecode -s baseboard-serial-number 2>/dev/null || echo ''"
            output, error, exit_code = self._exec_command(command)

            serial = output.strip()
            if serial and serial != "Not Specified":
                logger.debug(f"获取到主板序列号：{serial[:8]}...")
                return serial
            else:
                logger.debug("无法获取主板序列号")
                return None

        except Exception as e:
            logger.error(f"获取主板序列号失败：{e}")
            return None

    def get_hostname(self) -> str | None:
        """
        获取主机名

        Returns:
            主机名，如果获取失败则返回 None
        """
        try:
            command = "hostname 2>/dev/null || echo ''"
            output, error, exit_code = self._exec_command(command)

            hostname = output.strip()
            if hostname:
                logger.debug(f"获取到主机名：{hostname}")
                return hostname
            else:
                return None

        except Exception as e:
            logger.error(f"获取主机名失败：{e}")
            return None

    def get_fingerprint(self) -> str | None:
        """
        获取综合机器指纹

        优先级:
        1. /etc/machine-id
        2. 主板序列号
        3. 主机名 + 其他标识

        Returns:
            机器指纹字符串，如果所有方式都失败则返回 None
        """
        # 尝试获取 machine-id
        machine_id = self.get_machine_id()
        if machine_id:
            return f"mid:{machine_id}"

        # 尝试获取主板序列号
        board_serial = self.get_board_serial()
        if board_serial:
            return f"bsn:{board_serial}"

        # 尝试获取主机名作为备选
        hostname = self.get_hostname()
        if hostname:
            # 结合主机名和其他信息
            command = "uname -m 2>/dev/null || echo ''"
            output, _, _ = self._exec_command(command)
            arch = output.strip()
            return f"host:{hostname}:{arch}"

        logger.error("无法获取任何机器标识信息")
        return None

    def get_system_info(self) -> dict:
        """
        获取系统信息

        Returns:
            包含系统信息的字典
        """
        info = {}

        # 获取操作系统信息
        try:
            command = "cat /etc/os-release 2>/dev/null | grep -E '^(NAME|VERSION|ID)=' || echo ''"
            output, _, _ = self._exec_command(command)
            info["os_release"] = output.strip()
        except Exception:
            pass

        # 获取内核版本
        try:
            command = "uname -r"
            output, _, _ = self._exec_command(command)
            info["kernel"] = output.strip()
        except Exception:
            pass

        # 获取架构
        try:
            command = "uname -m"
            output, _, _ = self._exec_command(command)
            info["architecture"] = output.strip()
        except Exception:
            pass

        # 获取 CPU 核心数
        try:
            command = "nproc"
            output, _, _ = self._exec_command(command)
            info["cpu_cores"] = output.strip()
        except Exception:
            pass

        return info
