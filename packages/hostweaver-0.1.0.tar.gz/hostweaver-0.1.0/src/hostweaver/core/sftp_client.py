"""
SFTP 文件传输模块

提供可靠的文件上传/下载功能，支持自动赋予执行权限。
"""

import logging
from pathlib import Path

import paramiko  # noqa: F401 - 用于测试 mock
from paramiko import SFTPClient as ParamikoSFTPClient
from paramiko import SSHException

from hostweaver.core.ssh_client import SSHClientPool

logger = logging.getLogger(__name__)


class SFTPClient:
    """
    SFTP 文件传输客户端

    功能:
    - 文件上传（自动 chmod +x）
    - 文件下载
    - 目录创建
    - 文件权限管理
    - 目录上传
    """

    def __init__(self, ssh_pool: SSHClientPool):
        """
        初始化 SFTP 客户端

        Args:
            ssh_pool: SSH 连接池实例
        """
        self.ssh_pool = ssh_pool
        self._sftp: ParamikoSFTPClient | None = None

    def _get_sftp(self) -> ParamikoSFTPClient:
        """获取 SFTP 客户端实例"""
        if not self.ssh_pool.is_connected():
            raise SSHException("SSH 未连接，请先调用 ssh_pool.connect()")

        if self._sftp is None:
            self._sftp = self.ssh_pool.get_client().open_sftp()
            logger.debug("SFTP 会话已建立")

        return self._sftp

    def close(self):
        """关闭 SFTP 连接"""
        if self._sftp:
            try:
                self._sftp.close()
            except Exception as e:
                logger.warning(f"关闭 SFTP 连接时出错：{e}")
            finally:
                self._sftp = None
                logger.debug("SFTP 连接已关闭")

    def mkdir_p(self, remote_path: str, mode: int = 0o755):
        """
        递归创建远程目录

        Args:
            remote_path: 远程目录路径
            mode: 目录权限模式
        """
        sftp = self._get_sftp()
        remote_path = remote_path.rstrip("/")

        # 检查目录是否已存在
        try:
            sftp.stat(remote_path)
            logger.debug(f"远程目录已存在：{remote_path}")
            return
        except FileNotFoundError:
            pass

        # 递归创建目录
        parts = remote_path.split("/")
        current_path = ""

        for part in parts:
            if not part:
                continue

            if current_path:
                current_path += "/" + part
            else:
                current_path = "/" + part if remote_path.startswith("/") else part

            try:
                sftp.stat(current_path)
            except FileNotFoundError:
                logger.debug(f"创建远程目录：{current_path}")
                sftp.mkdir(current_path, mode)

        logger.info(f"远程目录创建成功：{remote_path}")

    def upload(
        self,
        local_path: str | Path,
        remote_path: str,
        executable: bool = True,
        mode: int | None = None,
    ) -> bool:
        """
        上传文件

        Args:
            local_path: 本地文件路径
            remote_path: 远程文件路径
            executable: 是否自动设置执行权限 (chmod +x)
            mode: 自定义权限模式，如果为 None 则使用默认值

        Returns:
            上传是否成功
        """
        local_path = Path(local_path).expanduser()
        if not local_path.exists():
            logger.error(f"本地文件不存在：{local_path}")
            return False

        if not local_path.is_file():
            logger.error(f"本地路径不是文件：{local_path}")
            return False

        sftp = self._get_sftp()

        # 确保远程目录存在
        remote_dir = Path(remote_path).parent.as_posix()
        if remote_dir:
            self.mkdir_p(remote_dir)

        try:
            logger.info(f"上传文件：{local_path} -> {remote_path}")
            sftp.put(str(local_path), remote_path)

            # 设置权限
            if mode is not None:
                sftp.chmod(remote_path, mode)
                logger.debug(f"设置文件权限：{oct(mode)}")
            elif executable:
                # 默认设置执行权限
                sftp.chmod(remote_path, 0o755)
                logger.debug("设置文件执行权限：chmod +x")

            logger.info(f"文件上传成功：{remote_path}")
            return True

        except Exception as e:
            logger.error(f"文件上传失败：{e}")
            return False

    def download(self, remote_path: str, local_path: str | Path) -> bool:
        """
        下载文件

        Args:
            remote_path: 远程文件路径
            local_path: 本地文件路径

        Returns:
            下载是否成功
        """
        sftp = self._get_sftp()
        local_path = Path(local_path).expanduser()

        # 检查远程文件是否存在
        try:
            sftp.stat(remote_path)
        except FileNotFoundError:
            logger.error(f"远程文件不存在：{remote_path}")
            return False

        # 确保本地目录存在
        local_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            logger.info(f"下载文件：{remote_path} -> {local_path}")
            sftp.get(remote_path, str(local_path))
            logger.info(f"文件下载成功：{local_path}")
            return True

        except Exception as e:
            logger.error(f"文件下载失败：{e}")
            return False

    def chmod(self, remote_path: str, mode: int) -> bool:
        """
        修改远程文件权限

        Args:
            remote_path: 远程文件路径
            mode: 权限模式（如 0o755）

        Returns:
            操作是否成功
        """
        sftp = self._get_sftp()

        try:
            logger.debug(f"修改文件权限：{remote_path} -> {oct(mode)}")
            sftp.chmod(remote_path, mode)
            logger.info(f"文件权限修改成功：{remote_path}")
            return True
        except Exception as e:
            logger.error(f"修改文件权限失败：{e}")
            return False

    def exists(self, remote_path: str) -> bool:
        """
        检查远程文件/目录是否存在

        Args:
            remote_path: 远程路径

        Returns:
            是否存在
        """
        sftp = self._get_sftp()
        try:
            sftp.stat(remote_path)
            return True
        except FileNotFoundError:
            return False

    def remove(self, remote_path: str) -> bool:
        """
        删除远程文件

        Args:
            remote_path: 远程文件路径

        Returns:
            删除是否成功
        """
        sftp = self._get_sftp()

        try:
            logger.debug(f"删除远程文件：{remote_path}")
            sftp.remove(remote_path)
            logger.info(f"文件删除成功：{remote_path}")
            return True
        except Exception as e:
            logger.error(f"文件删除失败：{e}")
            return False

    def list_dir(self, remote_path: str) -> list:
        """
        列出远程目录内容

        Args:
            remote_path: 远程目录路径

        Returns:
            文件名列表
        """
        sftp = self._get_sftp()

        try:
            entries = sftp.listdir(remote_path)
            logger.debug(f"目录内容：{entries}")
            return entries
        except Exception as e:
            logger.error(f"列出目录失败：{e}")
            return []

    def upload_directory(
        self,
        local_dir: str | Path,
        remote_dir: str,
        ignore_patterns: list[str] | None = None,
    ) -> bool:
        """
        上传整个目录

        Args:
            local_dir: 本地目录路径
            remote_dir: 远程目录路径
            ignore_patterns: 忽略的文件模式列表（如 ['*.pyc', '__pycache__', '.git']）

        Returns:
            上传是否成功
        """
        import fnmatch

        local_dir = Path(local_dir).expanduser()
        if not local_dir.exists():
            logger.error(f"本地目录不存在：{local_dir}")
            return False

        if not local_dir.is_dir():
            logger.error(f"本地路径不是目录：{local_dir}")
            return False

        # 默认忽略模式
        if ignore_patterns is None:
            ignore_patterns = [
                "*.pyc",
                "*.pyo",
                "__pycache__",
                ".git",
                ".gitignore",
                "*.egg-info",
                ".venv",
                "venv",
                ".env",
                "*.so",
                "*.dylib",
            ]

        def should_ignore(path: Path) -> bool:
            """检查路径是否应该被忽略"""
            for pattern in ignore_patterns:
                if fnmatch.fnmatch(path.name, pattern):
                    return True
            # 检查路径中的任何部分是否应该被忽略
            for part in path.parts:
                if fnmatch.fnmatch(str(part), pattern):  # type: ignore
                    return True
            return False

        sftp = self._get_sftp()

        # 确保远程目录存在
        self.mkdir_p(remote_dir)

        files_uploaded = 0
        files_skipped = 0

        try:
            # 遍历本地目录
            for local_path in local_dir.rglob("*"):
                if local_path.is_file():
                    # 检查是否应该忽略
                    if should_ignore(local_path):
                        logger.debug(f"忽略文件：{local_path}")
                        files_skipped += 1
                        continue

                    # 计算相对路径
                    rel_path = local_path.relative_to(local_dir)
                    remote_path = f"{remote_dir}/{rel_path.as_posix()}"

                    # 确保远程目录存在
                    remote_parent = Path(remote_path).parent.as_posix()
                    if remote_parent and remote_parent != ".":
                        self.mkdir_p(remote_parent)

                    # 上传文件
                    try:
                        logger.debug(f"上传文件：{local_path} -> {remote_path}")
                        sftp.put(str(local_path), remote_path)

                        # 设置执行权限（如果是可执行文件或脚本）
                        if local_path.suffix in [".sh", ".py", ".pl", ".rb"]:
                            sftp.chmod(remote_path, 0o755)
                        else:
                            sftp.chmod(remote_path, 0o644)

                        files_uploaded += 1
                    except Exception as e:
                        logger.error(f"上传文件失败 {local_path}: {e}")
                        return False

            logger.info(
                f"目录上传完成：{files_uploaded} 个文件，{files_skipped} 个文件已忽略"
            )
            return True

        except Exception as e:
            logger.error(f"目录上传失败：{e}")
            return False

    def __enter__(self) -> "SFTPClient":
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False
