"""
部署器抽象基类

定义标准部署流程的生命周期：pre_deploy() -> run() -> post_deploy()
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from hostweaver.core.sftp_client import SFTPClient
from hostweaver.core.ssh_client import SSHClientPool
from hostweaver.core.systemd import SystemdManager

logger = logging.getLogger(__name__)


@dataclass
class DeploymentResult:
    """部署结果数据类"""

    success: bool = False
    host: str = ""
    message: str = ""
    start_time: datetime | None = None
    end_time: datetime | None = None
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def duration(self) -> float | None:
        """获取部署耗时（秒）"""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return None

    def __str__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        duration_str = f" ({self.duration:.2f}s)" if self.duration else ""
        return f"[{status}] {self.host}: {self.message}{duration_str}"


class BaseDeployer(ABC):
    """
    部署器抽象基类

    定义标准部署流程的生命周期：
    1. pre_deploy()  - 部署前准备
    2. run()         - 执行部署
    3. post_deploy() - 部署后处理

    使用模板方法模式，deploy() 方法定义了整个流程的骨架。
    """

    def __init__(
        self,
        host: str,
        port: int = 22,
        username: str | None = None,
        password: str | None = None,
        pkey_path: str | None = None,
        timeout: int = 30,
        allow_agent: bool = False,
        look_for_keys: bool = False,
    ):
        """
        初始化部署器

        Args:
            host: 远程主机地址
            port: SSH 端口，默认 22
            username: SSH 用户名
            password: SSH 密码
            pkey_path: SSH 私钥文件路径
            timeout: 连接超时时间（秒）
            allow_agent: 是否使用 SSH agent
            look_for_keys: 是否自动查找本地密钥
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.pkey_path = pkey_path
        self.timeout = timeout
        self.allow_agent = allow_agent
        self.look_for_keys = look_for_keys

        # 组件实例
        self.ssh_pool: SSHClientPool | None = None
        self.sftp_client: SFTPClient | None = None
        self.systemd_manager: SystemdManager | None = None

        # 部署结果
        self._result = DeploymentResult(host=host)

    def _init_components(self):
        """初始化 SSH、SFTP、Systemd 组件"""
        self.ssh_pool = SSHClientPool(
            host=self.host,
            port=self.port,
            username=self.username,
            password=self.password,
            pkey_path=self.pkey_path,
            timeout=self.timeout,
            allow_agent=self.allow_agent,
            look_for_keys=self.look_for_keys,
        )
        self.sftp_client = SFTPClient(self.ssh_pool)
        self.systemd_manager = SystemdManager(self.ssh_pool)

    def connect(self) -> bool:
        """
        建立 SSH 连接并初始化组件

        Returns:
            连接是否成功
        """
        try:
            logger.info(f"正在连接到 {self.host}:{self.port}")
            self._init_components()
            assert self.ssh_pool
            self.ssh_pool.connect()
            logger.info(f"SSH 连接成功：{self.host}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"SSH 连接失败：{e}")
            self._result.message = f"连接失败：{e}"
            return False

    def disconnect(self):
        """断开 SSH 连接"""
        try:
            if self.sftp_client:
                self.sftp_client.close()
            if self.ssh_pool:
                self.ssh_pool.disconnect()
            logger.debug(f"SSH 连接已断开：{self.host}")
        except Exception as e:
            logger.warning(f"断开连接时出错：{e}")

    @abstractmethod
    def pre_deploy(self) -> bool:
        """
        部署前准备

        子类必须实现此方法，通常用于：
        - 停止旧服务
        - 环境探测
        - 备份配置
        - 获取机器指纹等

        Returns:
            准备是否成功
        """
        pass

    @abstractmethod
    def run(self) -> bool:
        """
        执行部署

        子类必须实现此方法，通常用于：
        - 文件上传
        - 配置渲染
        - 服务配置等

        Returns:
            部署是否成功
        """
        pass

    @abstractmethod
    def post_deploy(self) -> bool:
        """
        部署后处理

        子类必须实现此方法，通常用于：
        - 启动服务
        - 验证服务状态
        - 输出日志
        - 清理临时文件等

        Returns:
            处理是否成功
        """
        pass

    def deploy(self) -> DeploymentResult:
        """
        完整部署流程（模板方法）

        执行顺序：connect -> pre_deploy -> run -> post_deploy -> disconnect

        Returns:
            DeploymentResult 部署结果
        """
        self._result.start_time = datetime.now()
        self._result.success = False

        try:
            # 1. 建立连接
            if not self.connect():
                self._result.message = "SSH 连接失败"
                return self._result

            # 2. 部署前准备
            logger.info(f"[部署前准备]：{self.host}")
            if not self.pre_deploy():
                self._result.message = "部署前准备失败"
                return self._result

            # 3. 执行部署
            logger.info(f"[执行部署]：{self.host}")
            if not self.run():
                self._result.message = "部署执行失败"
                return self._result

            # 4. 部署后处理
            logger.info(f"[部署后处理]：{self.host}")
            if not self.post_deploy():
                self._result.message = "部署后处理失败"
                return self._result

            # 部署成功
            self._result.success = True
            self._result.message = "部署成功"
            logger.info(f"部署成功：{self.host}")

        except Exception as e:
            logger.error(f"部署过程中发生异常：{e}")
            self._result.message = f"部署异常：{e}"
            self._result.success = False

        finally:
            # 5. 断开连接
            self.disconnect()
            self._result.end_time = datetime.now()

        return self._result

    def exec_command(self, command: str, timeout: int = 60) -> tuple:
        """
        执行远程命令（便捷方法）

        Args:
            command: 要执行的命令
            timeout: 超时时间（秒）

        Returns:
            (stdout, stderr, exit_code)
        """
        if not self.ssh_pool or not self.ssh_pool.is_connected():
            raise ConnectionError("SSH 未连接")
        return self.ssh_pool.exec_command(command, timeout)

    def upload_file(
        self, local_path: str, remote_path: str, executable: bool = True
    ) -> bool:
        """
        上传文件（便捷方法）

        Args:
            local_path: 本地文件路径
            remote_path: 远程文件路径
            executable: 是否设置执行权限

        Returns:
            上传是否成功
        """
        if not self.sftp_client:
            raise ConnectionError("SFTP 未初始化")
        return self.sftp_client.upload(local_path, remote_path, executable)

    def upload_directory(
        self,
        local_dir: str,
        remote_dir: str,
        ignore_patterns: list[str] | None = None,
    ) -> bool:
        """
        上传整个目录（便捷方法）

        Args:
            local_dir: 本地目录路径
            remote_dir: 远程目录路径
            ignore_patterns: 忽略的文件模式列表

        Returns:
            上传是否成功
        """
        if not self.sftp_client:
            raise ConnectionError("SFTP 未初始化")
        return self.sftp_client.upload_directory(local_dir, remote_dir, ignore_patterns)

    def get_service_status(self, service_name: str) -> str:
        """
        获取服务状态（便捷方法）

        Args:
            service_name: 服务名称

        Returns:
            服务状态输出
        """
        if not self.systemd_manager:
            raise ConnectionError("Systemd 管理器未初始化")
        return self.systemd_manager.status(service_name)

    def get_service_logs(self, service_name: str, lines: int = 20) -> str:
        """
        获取服务日志（便捷方法）

        Args:
            service_name: 服务名称
            lines: 日志行数

        Returns:
            日志内容
        """
        if not self.systemd_manager:
            raise ConnectionError("Systemd 管理器未初始化")
        return self.systemd_manager.get_logs(service_name, lines)
