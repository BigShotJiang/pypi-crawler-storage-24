"""
Systemd 服务管理模块

提供 Systemd 服务生命周期管理和配置文件生成。
"""

import logging
from pathlib import Path

from hostweaver.core.ssh_client import SSHClientPool

logger = logging.getLogger(__name__)


class SystemdManager:
    """
    Systemd 服务生命周期管理

    功能:
    - 动态生成 .service 文件
    - 服务启动/停止/重启/重载/状态查询
    - 环境变量注入
    - 日志收集
    """

    SERVICE_TEMPLATE = """[Unit]
Description={description}
After=network.target

[Service]
Type=simple
WorkingDirectory={working_directory}
ExecStart={exec_start}
{environment}
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""

    def __init__(self, ssh_pool: SSHClientPool):
        """
        初始化 Systemd 管理器

        Args:
            ssh_pool: SSH 连接池实例
        """
        self.ssh_pool = ssh_pool
        self.service_dir = "/etc/systemd/system"

    def _exec_command(self, command: str, timeout: int = 60) -> tuple:
        """执行远程命令"""
        if not self.ssh_pool.is_connected():
            raise ConnectionError("SSH 未连接")
        return self.ssh_pool.exec_command(command, timeout)

    def generate_service_file(
        self,
        name: str,
        exec_path: str,
        working_directory: str | None = None,
        env_vars: dict[str, str] | None = None,
        description: str | None = None,
    ) -> str:
        """
        生成 .service 文件内容

        Args:
            name: 服务名称
            exec_path: 可执行文件路径
            working_directory: 工作目录
            env_vars: 环境变量字典
            description: 服务描述

        Returns:
            .service 文件内容
        """
        # 默认工作目录为可执行文件所在目录
        if not working_directory:
            working_directory = str(Path(exec_path).parent)

        # 默认描述
        if not description:
            description = f"{name} Service"

        # 生成环境变量配置
        environment_lines = []
        if env_vars:
            for key, value in env_vars.items():
                # 转义双引号
                escaped_value = str(value).replace('"', '\\"')
                environment_lines.append(f'Environment="{key}={escaped_value}"')

        environment_str = "\n".join(environment_lines) if environment_lines else ""

        # 渲染模板
        content = self.SERVICE_TEMPLATE.format(
            description=description,
            working_directory=working_directory,
            exec_start=exec_path,
            environment=environment_str,
        )

        logger.debug(f"生成服务配置文件：{name}.service")
        return content

    def write_service_file(self, name: str, content: str) -> bool:
        """
        写入 .service 文件到 /etc/systemd/system/

        Args:
            name: 服务名称
            content: 文件内容

        Returns:
            写入是否成功
        """
        service_path = f"{self.service_dir}/{name}.service"

        try:
            # 使用 tee 命令写入文件（需要 sudo）
            command = f"echo '{content}' | sudo tee {service_path} > /dev/null"
            output, error, exit_code = self._exec_command(command)

            if exit_code != 0:
                logger.error(f"写入服务文件失败：{error}")
                return False

            logger.info(f"服务文件写入成功：{service_path}")
            return True

        except Exception as e:
            logger.error(f"写入服务文件异常：{e}")
            return False

    def daemon_reload(self) -> bool:
        """
        重载 systemd 配置

        Returns:
            操作是否成功
        """
        try:
            command = "sudo systemctl daemon-reload"
            output, error, exit_code = self._exec_command(command)

            if exit_code != 0:
                logger.error(f"daemon-reload 失败：{error}")
                return False

            logger.info("systemd 配置重载成功")
            return True

        except Exception as e:
            logger.error(f"daemon-reload 异常：{e}")
            return False

    def start(self, name: str) -> bool:
        """
        启动服务

        Args:
            name: 服务名称

        Returns:
            操作是否成功
        """
        try:
            command = f"sudo systemctl start {name}"
            output, error, exit_code = self._exec_command(command)

            if exit_code != 0:
                logger.error(f"启动服务失败 [{name}]: {error}")
                return False

            logger.info(f"服务启动成功：{name}")
            return True

        except Exception as e:
            logger.error(f"启动服务异常 [{name}]: {e}")
            return False

    def stop(self, name: str) -> bool:
        """
        停止服务

        Args:
            name: 服务名称

        Returns:
            操作是否成功
        """
        try:
            command = f"sudo systemctl stop {name}"
            output, error, exit_code = self._exec_command(command)

            # 即使服务未运行，stop 也会返回 0
            if exit_code != 0:
                logger.warning(f"停止服务返回非零退出码 [{name}]: {error}")

            logger.info(f"服务停止：{name}")
            return True

        except Exception as e:
            logger.error(f"停止服务异常 [{name}]: {e}")
            return False

    def restart(self, name: str) -> bool:
        """
        重启服务

        Args:
            name: 服务名称

        Returns:
            操作是否成功
        """
        try:
            command = f"sudo systemctl restart {name}"
            output, error, exit_code = self._exec_command(command)

            if exit_code != 0:
                logger.error(f"重启服务失败 [{name}]: {error}")
                return False

            logger.info(f"服务重启成功：{name}")
            return True

        except Exception as e:
            logger.error(f"重启服务异常 [{name}]: {e}")
            return False

    def reload(self, name: str) -> bool:
        """
        重载服务配置（不重启）

        Args:
            name: 服务名称

        Returns:
            操作是否成功
        """
        try:
            command = f"sudo systemctl reload {name}"
            output, error, exit_code = self._exec_command(command)

            if exit_code != 0:
                logger.error(f"重载服务失败 [{name}]: {error}")
                return False

            logger.info(f"服务重载成功：{name}")
            return True

        except Exception as e:
            logger.error(f"重载服务异常 [{name}]: {e}")
            return False

    def status(self, name: str) -> str:
        """
        获取服务状态

        Args:
            name: 服务名称

        Returns:
            服务状态输出
        """
        try:
            command = f"systemctl status {name} --no-pager"
            output, error, exit_code = self._exec_command(command)

            # systemctl status 返回 3 表示服务未运行，4 表示服务不存在
            # 这些情况下仍然返回输出
            status_output = output if output else error
            return status_output.strip()

        except Exception as e:
            logger.error(f"获取服务状态异常 [{name}]: {e}")
            return f"Error: {e}"

    def is_active(self, name: str) -> bool:
        """
        检查服务是否正在运行

        Args:
            name: 服务名称

        Returns:
            服务是否活跃
        """
        try:
            command = f"systemctl is-active {name}"
            output, error, exit_code = self._exec_command(command)

            status = output.strip() if output else error.strip()
            return status == "active"

        except Exception as e:
            logger.error(f"检查服务状态异常 [{name}]: {e}")
            return False

    def is_enabled(self, name: str) -> bool:
        """
        检查服务是否已启用（开机自启）

        Args:
            name: 服务名称

        Returns:
            服务是否已启用
        """
        try:
            command = f"systemctl is-enabled {name}"
            output, error, exit_code = self._exec_command(command)

            status = output.strip() if output else error.strip()
            return status == "enabled"

        except Exception as e:
            logger.error(f"检查服务启用状态异常 [{name}]: {e}")
            return False

    def enable(self, name: str) -> bool:
        """
        启用服务（开机自启）

        Args:
            name: 服务名称

        Returns:
            操作是否成功
        """
        try:
            command = f"sudo systemctl enable {name}"
            output, error, exit_code = self._exec_command(command)

            if exit_code != 0:
                logger.error(f"启用服务失败 [{name}]: {error}")
                return False

            logger.info(f"服务已启用：{name}")
            return True

        except Exception as e:
            logger.error(f"启用服务异常 [{name}]: {e}")
            return False

    def disable(self, name: str) -> bool:
        """
        禁用服务（开机自启）

        Args:
            name: 服务名称

        Returns:
            操作是否成功
        """
        try:
            command = f"sudo systemctl disable {name}"
            output, error, exit_code = self._exec_command(command)

            if exit_code != 0:
                logger.warning(f"禁用服务返回非零退出码 [{name}]: {error}")

            logger.info(f"服务已禁用：{name}")
            return True

        except Exception as e:
            logger.error(f"禁用服务异常 [{name}]: {e}")
            return False

    def get_logs(self, name: str, lines: int = 20) -> str:
        """
        获取服务日志（通过 journalctl）

        Args:
            name: 服务名称
            lines: 日志行数

        Returns:
            日志内容
        """
        try:
            command = f"journalctl -u {name} -n {lines} --no-pager"
            output, error, exit_code = self._exec_command(command)

            # journalctl 即使没有日志也会返回 0
            logs = output if output else error
            return logs.strip()

        except Exception as e:
            logger.error(f"获取日志异常 [{name}]: {e}")
            return f"Error: {e}"

    def follow_logs(self, name: str, lines: int = 10) -> str:
        """
        获取实时日志（带 tail 模式）

        Args:
            name: 服务名称
            lines: 初始显示的行数

        Returns:
            日志内容（注意：此方法不会持续跟踪，只返回当前输出）
        """
        try:
            command = f"journalctl -u {name} -n {lines} -f --no-pager"
            output, error, exit_code = self._exec_command(command, timeout=5)

            logs = output if output else error
            return logs.strip()

        except Exception as e:
            logger.error(f"获取实时日志异常 [{name}]: {e}")
            return f"Error: {e}"
