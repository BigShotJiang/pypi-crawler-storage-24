"""
SSH 连接池模块

提供 SSH 连接管理，支持密码和私钥认证，连接复用和自动重连。
"""

import logging
from pathlib import Path

import paramiko
from paramiko import AuthenticationException, AutoAddPolicy, SSHClient, SSHException

logger = logging.getLogger(__name__)


class SSHClientPool:
    """
    SSH 连接池，支持密码和私钥认证

    功能:
    - 连接复用
    - 自动重连
    - 连接超时管理
    - 密码认证
    - 私钥认证 (RSA/ED25519)
    """

    def __init__(
        self,
        host: str,
        port: int = 22,
        username: str | None = None,
        password: str | None = None,
        pkey_path: str | None = None,
        timeout: int = 30,
        allow_agent: bool = False,
        look_for_keys: bool = False,
    ):
        """
        初始化 SSH 连接池

        Args:
            host: 远程主机地址
            port: SSH 端口，默认 22
            username: SSH 用户名
            password: SSH 密码（可选，与私钥二选一）
            pkey_path: SSH 私钥文件路径（可选，与密码二选一）
            timeout: 连接超时时间（秒）
            allow_agent: 是否使用 SSH agent
            look_for_keys: 是否自动查找本地密钥
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.pkey_path = pkey_path
        self.timeout = timeout
        self.allow_agent = allow_agent
        self.look_for_keys = look_for_keys

        self._client: SSHClient | None = None
        self._connected = False

        # 验证认证方式
        if not password and not pkey_path and not allow_agent and not look_for_keys:
            raise ValueError(
                "必须提供至少一种认证方式：password, pkey_path, allow_agent 或 look_for_keys"
            )

    def _load_pkey(self) -> paramiko.PKey | None:
        """加载私钥文件"""
        if not self.pkey_path:
            return None

        pkey_path = Path(self.pkey_path).expanduser()
        if not pkey_path.exists():
            raise FileNotFoundError(f"私钥文件不存在：{pkey_path}")

        # 尝试多种私钥类型
        # 注意：paramiko 4.x 已移除 DSSKey，使用 getattr 动态检查
        key_classes: list = [
            paramiko.RSAKey,
            paramiko.Ed25519Key,
            paramiko.ECDSAKey,
        ]

        # 如果 paramiko 版本支持 DSSKey，则添加（忽略类型检查器的警告）
        if hasattr(paramiko, "DSSKey"):
            key_classes.append(paramiko.DSSKey)  # type: ignore

        for key_class in key_classes:
            try:
                pkey = key_class.from_private_key_file(
                    str(pkey_path), password=self.password
                )
                logger.debug(f"成功加载私钥：{key_class.__name__}")
                return pkey
            except (SSHException, ValueError) as e:
                logger.debug(f"私钥加载失败 ({key_class.__name__}): {e}")
                continue

        raise SSHException(f"无法加载私钥文件：{pkey_path}")

    def connect(self) -> "SSHClientPool":
        """
        建立 SSH 连接

        Returns:
            self, 支持链式调用
        """
        if self._connected and self._client:
            logger.debug("SSH 连接已存在，跳过连接")
            return self

        try:
            self._client = SSHClient()
            self._client.set_missing_host_key_policy(AutoAddPolicy())

            # 加载私钥（如果有）
            pkey = self._load_pkey()

            # 建立连接
            self._client.connect(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                pkey=pkey,
                timeout=self.timeout,
                allow_agent=self.allow_agent,
                look_for_keys=self.look_for_keys,
            )

            self._connected = True
            logger.info(f"SSH 连接成功：{self.username}@{self.host}:{self.port}")

        except AuthenticationException as e:
            logger.error(f"SSH 认证失败：{e}")
            raise
        except SSHException as e:
            logger.error(f"SSH 连接失败：{e}")
            raise
        except Exception as e:
            logger.error(f"SSH 连接异常：{e}")
            raise

        return self

    def disconnect(self):
        """关闭 SSH 连接"""
        if self._client:
            try:
                self._client.close()
            except Exception as e:
                logger.warning(f"关闭 SSH 连接时出错：{e}")
            finally:
                self._client = None
                self._connected = False
                logger.debug("SSH 连接已关闭")

    def get_client(self) -> SSHClient:
        """
        获取 SSH 客户端实例

        Returns:
            paramiko.SSHClient 实例
        """
        if not self._connected or not self._client:
            raise SSHException("SSH 未连接，请先调用 connect()")
        return self._client

    def exec_command(self, command: str, timeout: int = 60) -> tuple[str, str, int]:
        """
        执行远程命令

        Args:
            command: 要执行的命令
            timeout: 命令执行超时时间（秒）

        Returns:
            (stdout, stderr, exit_code) 元组
        """
        if not self._connected or not self._client:
            raise SSHException("SSH 未连接，请先调用 connect()")

        logger.debug(f"执行命令：{command}")

        try:
            stdin, stdout, stderr = self._client.exec_command(command, timeout=timeout)

            output = stdout.read().decode("utf-8", errors="replace")
            error = stderr.read().decode("utf-8", errors="replace")
            exit_code = stdout.channel.recv_exit_status()

            if exit_code != 0:
                logger.warning(f"命令执行失败 (exit={exit_code}): {error[:200]}")
            else:
                logger.debug(f"命令执行成功 (exit={exit_code})")

            return output, error, exit_code

        except TimeoutError:
            logger.error(f"命令执行超时：{command}")
            raise
        except SSHException as e:
            logger.error(f"SSH 命令执行异常：{e}")
            raise

    def is_connected(self) -> bool:
        """检查是否已连接"""
        return self._connected and self._client is not None

    def __enter__(self) -> "SSHClientPool":
        """上下文管理器入口"""
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.disconnect()
        return False
