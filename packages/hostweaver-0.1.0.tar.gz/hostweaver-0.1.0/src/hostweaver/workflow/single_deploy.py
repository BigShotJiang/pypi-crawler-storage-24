"""
单机部署工作流

实现完整的单机部署流程：连接→清理→探测→计算→分发→渲染→重启
"""

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from hostweaver.core.base_deployer import BaseDeployer

logger = logging.getLogger(__name__)


@dataclass
class DeploymentResult:
    """部署结果数据类"""

    success: bool = False
    host: str = ""
    message: str = ""
    machine_id: str | None = None
    license_key: str | None = None
    service_status: str | None = None
    logs: str | None = None
    details: dict[str, Any] | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None

    def __post_init__(self):
        if self.details is None:
            self.details = {}

    @property
    def duration(self) -> float | None:
        """获取部署耗时（秒）"""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return None

    def __str__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        return f"[{status}] {self.host}: {self.message}"


class SingleDeployWorkflow:
    """
    单机部署工作流

    执行时序:
    1. 连接与清理
    2. 环境探测 (machine_id)
    3. 本地计算 (License Key)
    4. 文件分发 (SFTP)
    5. 配置渲染 (Systemd)
    6. 服务重启
    7. 日志验证
    """

    def __init__(
        self,
        deployer: BaseDeployer,
        show_logs: bool = True,
        log_lines: int = 20,
    ):
        """
        初始化部署工作流

        Args:
            deployer: Deployer 实例
            show_logs: 是否显示日志
            log_lines: 日志行数
        """
        self.deployer = deployer
        self.show_logs = show_logs
        self.log_lines = log_lines

    def execute(self) -> DeploymentResult:
        """
        执行完整部署流程

        Returns:
            DeploymentResult 部署结果
        """
        logger.info(f"开始执行部署工作流：{self.deployer.host}")

        result = DeploymentResult(host=self.deployer.host)

        try:
            # 执行部署（调用 BaseDeployer.deploy()）
            core_result = self.deployer.deploy()

            # 转换结果
            result.success = core_result.success
            result.message = core_result.message
            result.details = core_result.details

            # 提取额外信息
            if hasattr(self.deployer, "machine_id"):
                result.machine_id = getattr(self.deployer, "machine_id", None)
            if hasattr(self.deployer, "license_key"):
                result.license_key = getattr(self.deployer, "license_key", None)

            # 从 deployer._result.details 中获取服务状态和日志
            if core_result.success and core_result.details:
                result.service_status = core_result.details.get("service_status")
                result.logs = core_result.details.get("service_logs")

        except Exception as e:
            logger.error(f"部署工作流执行失败：{e}")
            result.success = False
            result.message = f"部署异常：{e}"

        return result

    def execute_with_progress(self, progress_callback=None) -> DeploymentResult:
        """
        带进度回调的部署执行

        Args:
            progress_callback: 进度回调函数，签名：callback(step: str, message: str)

        Returns:
            DeploymentResult 部署结果
        """

        def default_callback(step: str, message: str):
            logger.info(f"[{step}] {message}")

        callback = progress_callback or default_callback

        try:
            # 1. 连接
            callback("CONNECT", f"正在连接到 {self.deployer.host}")
            if not self.deployer.connect():
                return DeploymentResult(
                    host=self.deployer.host,
                    success=False,
                    message="SSH 连接失败",
                )
            callback("CONNECT", "连接成功")

            # 2. 部署前准备
            callback("PREPARE", "执行部署前准备")
            if not self.deployer.pre_deploy():
                self.deployer.disconnect()
                return DeploymentResult(
                    host=self.deployer.host,
                    success=False,
                    message="部署前准备失败",
                )
            callback("PREPARE", "准备完成")

            # 3. 执行部署
            callback("DEPLOY", "执行部署")
            if not self.deployer.run():
                self.deployer.disconnect()
                return DeploymentResult(
                    host=self.deployer.host,
                    success=False,
                    message="部署执行失败",
                )
            callback("DEPLOY", "部署完成")

            # 4. 部署后处理
            callback("POST", "执行部署后处理")
            if not self.deployer.post_deploy():
                self.deployer.disconnect()
                return DeploymentResult(
                    host=self.deployer.host,
                    success=False,
                    message="部署后处理失败",
                )
            callback("POST", "后处理完成")

            # 5. 断开连接
            callback("DISCONNECT", "断开连接")
            self.deployer.disconnect()
            callback("DISCONNECT", "连接已断开")

            # 构建成功结果
            result = DeploymentResult(
                host=self.deployer.host,
                success=True,
                message="部署成功",
                machine_id=getattr(self.deployer, "machine_id", None),
                license_key=getattr(self.deployer, "license_key", None),
            )

            # 从 deployer._result.details 中获取服务状态和日志
            # （这些已经在 post_deploy() 中获取并保存）
            if hasattr(self.deployer, "_result") and self.deployer._result.details:
                result.service_status = self.deployer._result.details.get(
                    "service_status"
                )
                result.logs = self.deployer._result.details.get("service_logs")

            return result

        except Exception as e:
            logger.error(f"部署工作流执行失败：{e}")
            self.deployer.disconnect()
            return DeploymentResult(
                host=self.deployer.host,
                success=False,
                message=f"部署异常：{e}",
            )
