"""
部署报告生成器

生成详细的部署汇总报告。
"""

import logging
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from hostweaver.workflow.single_deploy import DeploymentResult

logger = logging.getLogger(__name__)
console = Console()


class DeploymentReporter:
    """
    部署报告生成器

    功能:
    - 汇总部署结果
    - 生成成功/失败统计
    - 输出详细报告
    """

    def __init__(self, results: list[DeploymentResult]):
        """
        初始化报告生成器

        Args:
            results: 部署结果列表
        """
        self.results = results

    def get_summary(self) -> dict[str, Any]:
        """
        获取汇总统计

        Returns:
            汇总字典
        """
        total = len(self.results)
        success_results = [r for r in self.results if r.success]
        failed_results = [r for r in self.results if not r.success]

        success_count = len(success_results)
        failed_count = len(failed_results)

        # 计算平均耗时
        durations = [r.duration for r in self.results if r.duration is not None]
        avg_duration = sum(durations) / len(durations) if durations else None

        return {
            "total": total,
            "success_count": success_count,
            "failed_count": failed_count,
            "success_rate": success_count / total if total > 0 else 0,
            "success_hosts": [r.host for r in success_results],
            "failed_hosts": [r.host for r in failed_results],
            "avg_duration": avg_duration,
            "results": self.results,
        }

    def generate_text_report(self, verbose: bool = False) -> str:
        """
        生成文本报告

        Args:
            verbose: 是否包含详细信息

        Returns:
            文本报告
        """
        summary = self.get_summary()
        lines = []

        lines.append("=" * 60)
        lines.append("部署汇总报告")
        lines.append("=" * 60)
        lines.append(f"总主机数：{summary['total']}")
        lines.append(f"成功：{summary['success_count']}")
        lines.append(f"失败：{summary['failed_count']}")
        lines.append(f"成功率：{summary['success_rate']:.1%}")

        if summary["avg_duration"]:
            lines.append(f"平均耗时：{summary['avg_duration']:.2f}秒")

        lines.append("")

        # 成功主机列表
        if summary["success_hosts"]:
            lines.append("✅ 成功主机:")
            for host in summary["success_hosts"]:
                lines.append(f"   - {host}")
            lines.append("")

        # 失败主机列表
        if summary["failed_hosts"]:
            lines.append("❌ 失败主机:")
            for host in summary["failed_hosts"]:
                lines.append(f"   - {host}")
            lines.append("")

        # 详细信息
        if verbose:
            lines.append("=" * 60)
            lines.append("详细信息")
            lines.append("=" * 60)

            for result in self.results:
                status = "✅" if result.success else "❌"
                lines.append(f"\n{status} {result.host}")
                lines.append(f"   状态：{'成功' if result.success else '失败'}")
                lines.append(f"   消息：{result.message}")

                if result.machine_id:
                    lines.append(f"   机器指纹：{result.machine_id[:16]}...")

                if result.duration:
                    lines.append(f"   耗时：{result.duration:.2f}秒")

                if result.service_status and verbose:
                    status_lines = result.service_status.split("\n")[:3]
                    lines.append(
                        f"   服务状态：{status_lines[0] if status_lines else 'N/A'}"
                    )

        lines.append("")
        lines.append("=" * 60)

        return "\n".join(lines)

    def print_report(self, verbose: bool = False):
        """
        打印报告到终端

        Args:
            verbose: 是否包含详细信息
        """
        summary = self.get_summary()

        # 标题
        title = Text("部署汇总报告", style="bold blue")
        console.print(Panel(title, border_style="blue"))

        # 统计表格
        stats_table = Table(show_header=False, box=None)
        stats_table.add_column("属性", style="cyan")
        stats_table.add_column("值", style="green")

        stats_table.add_row("总主机数", str(summary["total"]))
        stats_table.add_row("成功", f"[green]{summary['success_count']}[/green]")
        stats_table.add_row("失败", f"[red]{summary['failed_count']}[/red]")
        stats_table.add_row("成功率", f"{summary['success_rate']:.1%}")

        if summary["avg_duration"]:
            stats_table.add_row("平均耗时", f"{summary['avg_duration']:.2f}秒")

        console.print(stats_table)
        console.print()

        # 成功主机
        if summary["success_hosts"]:
            success_text = Text()
            success_text.append("✅ 成功主机：", style="bold green")
            success_text.append(", ".join(summary["success_hosts"]), style="green")
            console.print(success_text)

        # 失败主机
        if summary["failed_hosts"]:
            failed_text = Text()
            failed_text.append("❌ 失败主机：", style="bold red")
            failed_text.append(", ".join(summary["failed_hosts"]), style="red")
            console.print(failed_text)

        console.print()

        # 详细信息
        if verbose:
            console.print(Panel("详细信息", border_style="cyan"))

            for result in self.results:
                status_icon = "✅" if result.success else "❌"
                status_color = "green" if result.success else "red"

                host_text = Text()
                host_text.append(f"{status_icon} ", style=status_color)
                host_text.append(result.host, style="bold")

                console.print()
                console.print(host_text)

                details_table = Table(show_header=False, box=None)
                details_table.add_column("属性", style="cyan")
                details_table.add_column("值", style=status_color)

                details_table.add_row("状态", "成功" if result.success else "失败")
                details_table.add_row("消息", result.message)

                if result.machine_id:
                    details_table.add_row("机器指纹", result.machine_id[:16] + "...")

                if result.duration:
                    details_table.add_row("耗时", f"{result.duration:.2f}秒")

                console.print(details_table)

    def generate_json_report(self) -> dict[str, Any]:
        """
        生成 JSON 格式报告

        Returns:
            JSON 兼容的字典
        """
        summary = self.get_summary()

        return {
            "summary": {
                "total": summary["total"],
                "success_count": summary["success_count"],
                "failed_count": summary["failed_count"],
                "success_rate": summary["success_rate"],
                "avg_duration": summary["avg_duration"],
            },
            "success_hosts": summary["success_hosts"],
            "failed_hosts": summary["failed_hosts"],
            "results": [
                {
                    "host": r.host,
                    "success": r.success,
                    "message": r.message,
                    "machine_id": r.machine_id,
                    "duration": r.duration,
                    "details": r.details,
                }
                for r in self.results
            ],
        }
