"""
部署并发池

使用 ThreadPoolExecutor 实现多机并发部署。
"""

import logging
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any

from hostweaver.core.base_deployer import BaseDeployer
from hostweaver.workflow.single_deploy import DeploymentResult

logger = logging.getLogger(__name__)


@dataclass
class HostConfig:
    """主机配置数据类"""

    host: str
    port: int = 22
    username: str | None = None
    password: str | None = None
    pkey_path: str | None = None
    env_vars: dict[str, str] | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class DeployTask:
    """部署任务数据类"""

    config: HostConfig
    deployer_class: type
    deployer_kwargs: dict[str, Any]
    future: Future | None = None


class DeployPool:
    """
    部署并发池

    功能:
    - 多线程并发部署
    - 失败隔离
    - 进度跟踪
    - 日志前缀区分
    """

    def __init__(
        self,
        max_workers: int = 5,
        log_prefix: bool = True,
    ):
        """
        初始化并发池

        Args:
            max_workers: 最大并发数
            log_prefix: 是否在日志中添加 IP 前缀
        """
        self.max_workers = max_workers
        self.log_prefix = log_prefix
        self.results: list[DeploymentResult] = []
        self.tasks: list[DeployTask] = []

    def add_task(
        self,
        config: HostConfig,
        deployer_class: type,
        **deployer_kwargs,
    ) -> "DeployPool":
        """
        添加部署任务

        Args:
            config: 主机配置
            deployer_class: Deployer 类
            **deployer_kwargs: Deployer 初始化参数

        Returns:
            self, 支持链式调用
        """
        task = DeployTask(
            config=config,
            deployer_class=deployer_class,
            deployer_kwargs=deployer_kwargs,
        )
        self.tasks.append(task)
        logger.debug(f"添加部署任务：{config.host}")
        return self

    def add_hosts(
        self,
        hosts: list[str],
        deployer_class: type,
        common_kwargs: dict[str, Any] | None = None,
        host_configs: list[HostConfig] | None = None,
    ) -> "DeployPool":
        """
        批量添加主机

        Args:
            hosts: 主机列表
            deployer_class: Deployer 类
            common_kwargs: 通用参数
            host_configs: 主机配置列表（可选，用于覆盖默认配置）

        Returns:
            self, 支持链式调用
        """
        common_kwargs = common_kwargs or {}

        # 如果有 host_configs，使用配置
        if host_configs:
            for config in host_configs:
                self.add_task(config, deployer_class, **common_kwargs)
        else:
            # 否则使用默认配置
            for host in hosts:
                config = HostConfig(host=host)
                self.add_task(config, deployer_class, **common_kwargs)

        return self

    def _create_deployer(self, task: DeployTask) -> BaseDeployer:
        """创建 Deployer 实例"""
        config = task.config
        kwargs = task.deployer_kwargs.copy()

        # 合并 SSH 参数
        kwargs["host"] = config.host
        kwargs["port"] = config.port
        kwargs["username"] = config.username
        kwargs["password"] = config.password
        kwargs["pkey_path"] = config.pkey_path

        # 合并环境变量
        if config.env_vars:
            existing_env = kwargs.get("env_vars", {})
            existing_env.update(config.env_vars)
            kwargs["env_vars"] = existing_env

        return task.deployer_class(**kwargs)

    def _execute_task(self, task: DeployTask) -> DeploymentResult:
        """
        执行单个部署任务

        Args:
            task: 部署任务

        Returns:
            DeploymentResult 部署结果
        """
        host = task.config.host

        # 创建带 IP 前缀的日志处理器
        if self.log_prefix:
            host_logger = logging.getLogger(f"deploy.{host}")
            host_logger.info(f"[{host}] 开始部署")
        else:
            host_logger = logger
            logger.info(f"开始部署：{host}")

        try:
            # 创建 Deployer
            deployer = self._create_deployer(task)

            # 执行部署
            from hostweaver.workflow.single_deploy import SingleDeployWorkflow

            workflow = SingleDeployWorkflow(deployer=deployer, show_logs=False)
            result = workflow.execute()

            if self.log_prefix:
                if result.success:
                    host_logger.info(f"[{host}] 部署成功")
                else:
                    host_logger.error(f"[{host}] 部署失败：{result.message}")
            else:
                if result.success:
                    host_logger.info(f"部署成功：{host}")
                else:
                    host_logger.error(f"部署失败：{host} - {result.message}")

            return result

        except Exception as e:
            logger.error(f"部署异常 [{host}]: {e}")
            return DeploymentResult(
                host=host,
                success=False,
                message=f"部署异常：{e}",
            )

    def execute(
        self,
        progress_callback: Callable[[int, int, DeploymentResult], None] | None = None,
    ) -> list[DeploymentResult]:
        """
        执行所有部署任务

        Args:
            progress_callback: 进度回调函数，签名：callback(completed, total, result)

        Returns:
            所有部署结果列表
        """
        if not self.tasks:
            logger.warning("没有部署任务")
            return []

        total = len(self.tasks)
        completed = 0
        results = []

        logger.info(f"开始并发部署，共 {total} 台主机，最大并发数：{self.max_workers}")

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # 提交所有任务
            future_to_task = {
                executor.submit(self._execute_task, task): task for task in self.tasks
            }

            # 收集结果
            for future in as_completed(future_to_task):
                task = future_to_task[future]
                completed += 1

                try:
                    result = future.result()
                except Exception as e:
                    logger.error(f"任务执行异常 [{task.config.host}]: {e}")
                    result = DeploymentResult(
                        host=task.config.host,
                        success=False,
                        message=f"任务执行异常：{e}",
                    )

                results.append(result)

                # 调用进度回调
                if progress_callback:
                    progress_callback(completed, total, result)

                # 输出进度
                logger.info(f"部署进度：{completed}/{total}")

        self.results = results
        return results

    def get_summary(self) -> dict[str, Any]:
        """
        获取部署汇总

        Returns:
            汇总字典
        """
        total = len(self.results)
        success_count = sum(1 for r in self.results if r.success)
        failed_count = total - success_count

        success_hosts = [r.host for r in self.results if r.success]
        failed_hosts = [r.host for r in self.results if not r.success]

        return {
            "total": total,
            "success": success_count,
            "failed": failed_count,
            "success_rate": success_count / total if total > 0 else 0,
            "success_hosts": success_hosts,
            "failed_hosts": failed_hosts,
            "results": self.results,
        }

    def print_summary(self):
        """打印部署汇总到日志"""
        summary = self.get_summary()

        logger.info("=" * 50)
        logger.info("部署汇总报告")
        logger.info("=" * 50)
        logger.info(f"总主机数：{summary['total']}")
        logger.info(f"成功：{summary['success']}")
        logger.info(f"失败：{summary['failed']}")
        logger.info(f"成功率：{summary['success_rate']:.1%}")

        if summary["success_hosts"]:
            logger.info(f"成功主机：{', '.join(summary['success_hosts'])}")

        if summary["failed_hosts"]:
            logger.warning(f"失败主机：{', '.join(summary['failed_hosts'])}")

        logger.info("=" * 50)
