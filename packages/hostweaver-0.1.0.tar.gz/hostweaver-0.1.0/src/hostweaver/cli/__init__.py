"""
HostWeaver CLI - 命令行工具模块

提供优雅的终端命令行接口。
"""

from hostweaver.cli.main import app

__all__ = ["app"]
