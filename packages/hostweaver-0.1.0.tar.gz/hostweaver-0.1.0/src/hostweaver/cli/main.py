"""
HostWeaver CLI - 命令行工具

提供优雅的终端命令行接口，支持进度条和高亮日志输出。
"""

import logging
from pathlib import Path

import typer
from rich.console import Console
from rich.logging import RichHandler
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table

from hostweaver.business.generic_deployer import GenericDeployer
from hostweaver.workflow.single_deploy import SingleDeployWorkflow

# 初始化 Rich Console
console = Console()

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    handlers=[RichHandler(console=console, rich_tracebacks=True)],
)
logger = logging.getLogger(__name__)

# 创建 Typer 应用
app = typer.Typer(
    name="syscrafts",
    help="HostWeaver Deployer - 远程部署与状态管理工具",
    add_completion=True,
)


def version_callback(value: bool):
    """版本回调"""
    if value:
        from hostweaver import __version__

        console.print(f"[bold blue]HostWeaver Deployer[/bold blue] v{__version__}")
        raise typer.Exit()


# 全局选项
@app.callback()
def main_callback(
    version: bool | None = typer.Option(
        None, "--version", "-v", callback=version_callback, help="显示版本"
    ),
    verbose: bool = typer.Option(False, "--verbose", help="详细输出"),
):
    """HostWeaver Deployer 命令行工具"""
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)


@app.command("deploy")
def deploy_command(
    host: str = typer.Option(..., "--host", "-h", help="目标主机 IP"),
    port: int = typer.Option(22, "--port", "-p", help="SSH 端口"),
    username: str = typer.Option(..., "--username", "-u", help="SSH 用户名"),
    password: str | None = typer.Option(
        None, "--password", "-P", help="SSH 密码（或使用 --key-file）"
    ),
    key_file: str | None = typer.Option(
        None, "--key-file", "-k", help="SSH 私钥文件路径"
    ),
    source: str = typer.Option(
        ..., "--source", "-S", help="源文件路径（二进制文件或项目目录）"
    ),
    entrypoint: str = typer.Option(
        "main.py", "--entrypoint", "-E", help="应用入口文件（目录部署时使用）"
    ),
    install_dir: str = typer.Option(
        "/opt/app", "--install-dir", "-i", help="远程安装目录"
    ),
    service_name: str = typer.Option(
        "myapp", "--service", "-s", help="Systemd 服务名称"
    ),
    env_vars: list[str] | None = typer.Option(
        None, "--env", "-e", help="环境变量 (KEY=VALUE)，可多次指定"
    ),
    secret_key: str | None = typer.Option(
        None, "--secret-key", help="License 生成密钥"
    ),
    no_logs: bool = typer.Option(False, "--no-logs", help="不显示服务日志"),
):
    """
    部署应用到远程服务器

    支持部署单个二进制文件或整个项目目录。

    示例:
        # 部署单个二进制文件
        syscrafts deploy -h 192.168.1.100 -u root -k ~/.ssh/id_rsa -S ./app

        # 部署整个项目目录
        syscrafts deploy -h 192.168.1.100 -u root -k ~/.ssh/id_rsa -S ./project -E main.py

        # 带环境变量部署
        syscrafts deploy -h 192.168.1.100 -u root -P password -S ./app --env APP_ENV=production
    """
    console.print("[bold blue]🚀 开始部署[/bold blue]")
    console.print(f"  目标主机：[cyan]{host}[/cyan]")
    console.print(f"  源路径：[cyan]{source}[/cyan]")
    console.print(f"  安装目录：[cyan]{install_dir}[/cyan]")
    console.print(f"  服务名称：[cyan]{service_name}[/cyan]")

    # 验证源路径
    source_path = Path(source)
    if not source_path.exists():
        console.print(f"[bold red]❌ 错误：源路径不存在：{source}[/bold red]")
        raise typer.Exit(1)

    # 判断部署类型
    deploy_type = "文件" if source_path.is_file() else "目录"
    console.print(f"  部署类型：[cyan]{deploy_type}[/cyan]")
    if source_path.is_dir():
        console.print(f"  入口文件：[cyan]{entrypoint}[/cyan]")

    # 解析环境变量
    env_dict = {}
    if env_vars:
        for env in env_vars:
            if "=" not in env:
                console.print(
                    f"[bold red]❌ 错误：无效的环境变量格式：{env}[/bold red]"
                )
                raise typer.Exit(1)
            key, value = env.split("=", 1)
            env_dict[key] = value

    # 创建部署器
    deployer = GenericDeployer(
        host=host,
        port=port,
        username=username,
        password=password,
        pkey_path=key_file,
        source_path=source,
        entrypoint=entrypoint,
        install_dir=install_dir,
        service_name=service_name,
        env_vars=env_dict,
        secret_key=secret_key,
        timeout=60,
    )

    # 执行部署
    workflow = SingleDeployWorkflow(
        deployer=deployer,
        show_logs=not no_logs,
        log_lines=20,
    )

    # 使用进度条执行
    with Progress(
        TextColumn("[bold blue]{task.description}"),
        SpinnerColumn(),
        BarColumn(),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        # 定义步骤
        steps = [
            ("connect", "建立 SSH 连接"),
            ("prepare", "部署前准备"),
            ("deploy", "执行部署"),
            ("post", "部署后处理"),
            ("disconnect", "断开连接"),
        ]

        # 创建任务
        task = progress.add_task("初始化...", total=len(steps))

        def progress_callback(step: str, message: str):
            step_map = {
                "CONNECT": 0,
                "PREPARE": 1,
                "DEPLOY": 2,
                "POST": 3,
                "DISCONNECT": 4,
            }
            idx = step_map.get(step, 0)
            progress.update(task, completed=idx, description=f"[bold blue]{message}")

        # 执行
        result = workflow.execute_with_progress(progress_callback=progress_callback)

    # 输出结果
    console.print()
    if result.success:
        console.print("[bold green]✅ 部署成功![/bold green]")
        console.print(f"  主机：[cyan]{result.host}[/cyan]")
        if result.machine_id:
            console.print(f"  机器指纹：[cyan]{result.machine_id[:16]}...[/cyan]")
        if result.service_status:
            # 显示服务状态摘要
            status_lines = result.service_status.split("\n")
            for line in status_lines[:5]:
                console.print(f"  {line}")
    else:
        console.print("[bold red]❌ 部署失败![/bold red]")
        console.print(f"  原因：{result.message}")
        raise typer.Exit(1)

    # 输出日志
    if not no_logs and result.logs:
        console.print()
        console.print("[bold blue]📋 服务日志 (前 20 行)[/bold blue]")
        console.print(f"[dim]{result.logs}[/dim]")


@app.command("status")
def status_command(
    host: str = typer.Option(..., "--host", "-h", help="目标主机 IP"),
    port: int = typer.Option(22, "--port", "-p", help="SSH 端口"),
    username: str = typer.Option(..., "--username", "-u", help="SSH 用户名"),
    password: str | None = typer.Option(None, "--password", "-P", help="SSH 密码"),
    key_file: str | None = typer.Option(None, "--key-file", "-k", help="SSH 私钥文件"),
    service_name: str = typer.Option("myapp", "--service", "-s", help="服务名称"),
):
    """
    查询远程服务状态

    示例:
        syscrafts status -h 192.168.1.100 -u root -s myapp
    """
    from hostweaver.core.ssh_client import SSHClientPool
    from hostweaver.core.systemd import SystemdManager

    console.print(f"[bold blue]🔍 查询服务状态：{service_name} @ {host}[/bold blue]")

    try:
        # 建立连接
        with SSHClientPool(
            host=host,
            port=port,
            username=username,
            password=password,
            pkey_path=key_file,
        ) as ssh:
            systemd = SystemdManager(ssh)
            status = systemd.status(service_name)
            is_active = systemd.is_active(service_name)
            is_enabled = systemd.is_enabled(service_name)

        # 输出结果
        console.print()
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("属性", style="cyan")
        table.add_column("值", style="green")

        table.add_row("服务名称", service_name)
        table.add_row("主机", host)
        table.add_row(
            "运行状态", "[green]active[/green]" if is_active else "[red]inactive[/red]"
        )
        table.add_row(
            "开机自启",
            "[green]enabled[/green]" if is_enabled else "[yellow]disabled[/yellow]",
        )

        console.print(table)

        console.print()
        console.print("[bold]详细状态:[/bold]")
        console.print(f"[dim]{status}[/dim]")

    except Exception as e:
        console.print(f"[bold red]❌ 错误：{e}[/bold red]")
        raise typer.Exit(1)


@app.command("logs")
def logs_command(
    host: str = typer.Option(..., "--host", "-h", help="目标主机 IP"),
    port: int = typer.Option(22, "--port", "-p", help="SSH 端口"),
    username: str = typer.Option(..., "--username", "-u", help="SSH 用户名"),
    password: str | None = typer.Option(None, "--password", "-P", help="SSH 密码"),
    key_file: str | None = typer.Option(None, "--key-file", "-k", help="SSH 私钥文件"),
    service_name: str = typer.Option("myapp", "--service", "-s", help="服务名称"),
    lines: int = typer.Option(50, "--lines", "-n", help="日志行数"),
    follow: bool = typer.Option(False, "--follow", "-f", help="持续跟踪日志"),
):
    """
    查看远程服务日志

    示例:
        syscrafts logs -h 192.168.1.100 -u root -s myapp -n 100
    """
    from hostweaver.core.ssh_client import SSHClientPool
    from hostweaver.core.systemd import SystemdManager

    console.print(
        f"[bold blue]📋 查看日志：{service_name} @ {host} (最近 {lines} 行)[/bold blue]"
    )

    try:
        # 建立连接
        with SSHClientPool(
            host=host,
            port=port,
            username=username,
            password=password,
            pkey_path=key_file,
        ) as ssh:
            systemd = SystemdManager(ssh)
            logs = systemd.get_logs(service_name, lines)

        console.print()
        console.print(f"[dim]{logs}[/dim]")

    except Exception as e:
        console.print(f"[bold red]❌ 错误：{e}[/bold red]")
        raise typer.Exit(1)


@app.command("restart")
def restart_command(
    host: str = typer.Option(..., "--host", "-h", help="目标主机 IP"),
    port: int = typer.Option(22, "--port", "-p", help="SSH 端口"),
    username: str = typer.Option(..., "--username", "-u", help="SSH 用户名"),
    password: str | None = typer.Option(None, "--password", "-P", help="SSH 密码"),
    key_file: str | None = typer.Option(None, "--key-file", "-k", help="SSH 私钥文件"),
    service_name: str = typer.Option("myapp", "--service", "-s", help="服务名称"),
):
    """
    重启远程服务

    示例:
        syscrafts restart -h 192.168.1.100 -u root -s myapp
    """
    from hostweaver.core.ssh_client import SSHClientPool
    from hostweaver.core.systemd import SystemdManager

    console.print(f"[bold blue]🔄 重启服务：{service_name} @ {host}[/bold blue]")

    try:
        # 建立连接
        with SSHClientPool(
            host=host,
            port=port,
            username=username,
            password=password,
            pkey_path=key_file,
        ) as ssh:
            systemd = SystemdManager(ssh)

            console.print("  正在停止服务...")
            systemd.stop(service_name)

            console.print("  正在启动服务...")
            systemd.start(service_name)

            # 验证状态
            is_active = systemd.is_active(service_name)

        if is_active:
            console.print("[bold green]✅ 服务重启成功![/bold green]")
        else:
            console.print(
                "[bold yellow]⚠️  服务可能未正常启动，请检查日志[/bold yellow]"
            )

    except Exception as e:
        console.print(f"[bold red]❌ 错误：{e}[/bold red]")
        raise typer.Exit(1)


def main():
    """CLI 入口点"""
    app()


if __name__ == "__main__":
    main()
