"""S-MMU context retrieval helper for agent loop injection.

Queries the multi-view S-MMU graph (temporal, semantic, causal, entity edges)
to retrieve relevant memory chunks and formats them as an injectable context
string for LLM prompts.

This is a best-effort module: all failures are caught and logged, returning
an empty string so the agent loop is never disrupted.

Usage::

    from sage.memory.smmu_context import retrieve_smmu_context

    context = retrieve_smmu_context(working_memory)
    if context:
        messages.insert(2, Message(role=Role.SYSTEM, content=context))
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sage.memory.working import WorkingMemory

logger = logging.getLogger(__name__)

# Default weights: (temporal, semantic, causal, entity)
# Boost semantic + causal to favour meaning-related and cause-effect links.
_DEFAULT_WEIGHTS: tuple[float, float, float, float] = (1.0, 2.0, 1.5, 1.0)


def _filter_by_score(
    hits: list[tuple[str, float]], min_score: float = 0.5
) -> list[tuple[str, float]]:
    """Remove chunks below minimum relevance score."""
    return [(cid, s) for cid, s in hits if s >= min_score]


def retrieve_smmu_context(
    working_memory: WorkingMemory,
    max_hops: int = 2,
    top_k: int = 3,
    min_score: float = 0.5,
    weights: tuple[float, float, float, float] | None = None,
) -> str:
    """Retrieve relevant S-MMU chunks and format as a context string.

    Args:
        working_memory: The agent's working memory (wraps Rust S-MMU).
        max_hops: Maximum graph traversal depth for relevance scoring.
        top_k: Number of top-scoring chunks to include (default 3, was 5).
        min_score: Minimum relevance score threshold (default 0.5).
        weights: Optional (temporal, semantic, causal, entity) weight tuple.
                 Defaults to (1.0, 2.0, 1.5, 1.0) — boosting semantic + causal.

    Returns:
        A formatted string ready for injection as a SYSTEM message,
        or "" if the S-MMU has no chunks or retrieval fails.
    """
    try:
        chunk_count = working_memory.smmu_chunk_count()
        if chunk_count == 0:
            return ""

        # Use the most recently registered chunk as the query anchor (ULID)
        active_chunk_id = getattr(working_memory, "last_chunk_id", lambda: None)()
        if not active_chunk_id:
            return ""
        w = weights or _DEFAULT_WEIGHTS

        hits = working_memory.retrieve_relevant_chunks(
            active_chunk_id, max_hops, w
        )

        if not hits:
            return ""

        # Filter by minimum score and take top_k
        hits = _filter_by_score(hits, min_score)
        top_hits = hits[:top_k]
        if not top_hits:
            return ""

        # Format as injectable context with chunk summaries when available
        lines = ["[S-MMU Graph Memory] Relevant context from compacted memory:"]
        for chunk_id, score in top_hits:
            summary = ""
            try:
                summary = working_memory.get_chunk_summary(chunk_id)
            except (AttributeError, Exception):
                pass
            if summary:
                lines.append(f"- [{score:.2f}] {summary}")
            else:
                lines.append(f"- Chunk {chunk_id} (relevance: {score:.2f})")

        return "\n".join(lines)

    except Exception:
        logger.warning(
            "S-MMU context retrieval failed (best-effort, continuing without)",
            exc_info=True,
        )
        return ""
