import math
x = float(args.get("x", 0))
result = math.factorial(int(x))
print(json.dumps({"output": str(result)}))