name = args.get("name", "world")
print(json.dumps({"output": f"Hello, {name}!"}))