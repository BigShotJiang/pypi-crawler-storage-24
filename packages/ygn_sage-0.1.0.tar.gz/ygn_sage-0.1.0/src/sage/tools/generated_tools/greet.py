name = args.get("name", "world")
print(json.dumps({"output": f"hello {name}"}))