import json
result = args.get("a", 0) + args.get("b", 0)
print(json.dumps({"output": str(result)}))