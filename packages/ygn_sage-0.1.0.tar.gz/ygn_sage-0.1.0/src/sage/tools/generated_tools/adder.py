result = args["a"] + args["b"]
print(json.dumps({"output": str(result)}))