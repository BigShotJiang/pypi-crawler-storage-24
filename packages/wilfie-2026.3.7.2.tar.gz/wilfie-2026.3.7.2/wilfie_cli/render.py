"""CLI output rendering helpers."""

from __future__ import annotations

import json
from typing import Any


def _format_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True)
    return str(value)


def _render_table(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "(no rows)"
    columns: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in columns:
                columns.append(key)
    widths = {
        key: max(len(key), *(len(_format_cell(row.get(key))) for row in rows))
        for key in columns
    }
    header = " | ".join(key.ljust(widths[key]) for key in columns)
    divider = "-+-".join("-" * widths[key] for key in columns)
    body = [
        " | ".join(_format_cell(row.get(key)).ljust(widths[key]) for key in columns)
        for row in rows
    ]
    return "\n".join([header, divider, *body])


def _rows_from_standardized_table(table: Any) -> list[dict[str, Any]] | None:
    if not isinstance(table, dict):
        return None
    df = table.get("df")
    if not isinstance(df, dict):
        return None
    columns = df.get("columns")
    data = df.get("data")
    if not isinstance(columns, list) or not isinstance(data, list):
        return None
    rows: list[dict[str, Any]] = []
    for row in data:
        if not isinstance(row, list):
            return None
        rows.append(
            {
                str(column): row[index] if index < len(row) else None
                for index, column in enumerate(columns)
            }
        )
    return rows


def _sections_from_trace_payload(payload: Any) -> list[dict[str, Any]] | None:
    if not isinstance(payload, dict) or not isinstance(payload.get("target"), dict):
        return None
    section_map = [
        ("related_activity", "Related activity"),
        ("entity_resolution", "Entity resolution"),
        ("integration_object", "Integration object"),
        ("object_timeline", "Object timeline"),
        ("received_from_shopify", "Received from Shopify"),
        ("sent_to_shopify", "Sent to Shopify"),
        ("sent_to_wms", "Sent to WMS"),
        ("internal_processing", "Internal processing"),
    ]
    if not any(key in payload for key, _ in section_map):
        return None
    sections: list[dict[str, Any]] = [
        {"title": "Trace target", "payload": payload["target"]},
    ]
    for key, title in section_map:
        body = payload.get(key)
        if body is None:
            continue
        sections.append({"title": title, "payload": body})
    return sections


def _emit_table_mode_payload(payload: Any) -> None:
    if isinstance(payload, dict):
        sections = payload.get("sections")
        if not isinstance(sections, list):
            sections = _sections_from_trace_payload(payload)
        if isinstance(sections, list):
            rendered_any = False
            for section in sections:
                if not isinstance(section, dict):
                    continue
                title = _format_cell(section.get("title") or "Section")
                body = section.get("payload")
                if rendered_any:
                    print("")
                print(title)
                print("-" * len(title))
                _emit_table_mode_payload(body)
                rendered_any = True
            if not rendered_any:
                print("(no sections)")
            return

        table_rows = _rows_from_standardized_table(payload.get("table"))
        if table_rows is not None:
            print(_render_table(table_rows))
            metadata = {
                key: value
                for key, value in payload.items()
                if key != "table" and not isinstance(value, (dict, list))
            }
            if metadata:
                print("")
                for key, value in metadata.items():
                    print(f"{key}: {_format_cell(value)}")
            return

        if isinstance(payload.get("items"), list):
            print(_render_table(payload.get("items") or []))
            metadata = {
                key: value
                for key, value in payload.items()
                if key != "items"
            }
            if metadata:
                print("")
                for key, value in metadata.items():
                    print(f"{key}: {_format_cell(value)}")
            return

    if isinstance(payload, list):
        if payload and all(isinstance(item, dict) for item in payload):
            print(_render_table(payload))
        else:
            for item in payload:
                print(_format_cell(item))
        return

    if isinstance(payload, dict):
        for key, value in payload.items():
            print(f"{key}: {_format_cell(value)}")
        return

    print(_format_cell(payload))


def emit_payload(payload: Any, *, output_mode: str) -> None:
    if output_mode == "json":
        print(json.dumps(payload, indent=2, sort_keys=True, default=str))
        return

    _emit_table_mode_payload(payload)
