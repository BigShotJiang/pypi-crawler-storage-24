# pyprocessors_chunk_sentences

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_chunk_sentences)](https://github.com/oterrier/pyprocessors_chunk_sentences/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_chunk_sentences/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_chunk_sentences/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_chunk_sentences)](https://codecov.io/gh/oterrier/pyprocessors_chunk_sentences)
[![docs](https://img.shields.io/readthedocs/pyprocessors_chunk_sentences)](https://pyprocessors_chunk_sentences.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_chunk_sentences)](https://pypi.org/project/pyprocessors_chunk_sentences/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_chunk_sentences)](https://pypi.org/project/pyprocessors_chunk_sentences/)

Create segments from annotations

## Installation

You can simply `pip install pyprocessors_chunk_sentences`.

## Developing

### Pre-requisites

You will need to install [uv](https://docs.astral.sh/uv/getting-started/installation/) for dependency management and building:

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_chunk_sentences
```

Install the project with test dependencies:

```
uv sync --extra test
```

### Running the test suite

You can run the full test suite with:

```
uv run pytest
```

### Linting and formatting

This project uses [ruff](https://docs.astral.sh/ruff/) for linting and formatting:

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

You can build the HTML documentation with:

```
uv sync --extra docs
uv run sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.
