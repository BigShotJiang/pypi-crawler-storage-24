"""jBOM - KiCad Bill of Materials and Placement File Generator."""

__version__ = "6.44.2"
