
# -*- coding: utf-8 -*-
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
sys.path.append(curPath)
""" 
    @Description
    @Author：yanlei.wang
    @file： t_1.py
    @date：2026/3/13 09:38
"""

import requests
from src.utils.common_tools import to_camel_case
from datetime import datetime, timedelta
import pandas as pd


class KjjAPI:
    def __init__(self):
        self.base_url = "https://kjjapi.kanjiujing.cn/com-api"

    def get_holding_changes(self, uri, **kwargs):
        """
        """
        url = self.base_url + uri
        params = kwargs if kwargs else {}
        # 注意：request 参数是服务端注入的，客户端无需传递
        headers = {"Content-Type": "application/x-www-form-urlencoded",
                   "Token": "abc......"}
        # 过滤 None 值
        payload = {to_camel_case(k): v for k, v in params.items() if v is not None}

        response = requests.post(url, data=payload, headers=headers)
        response.raise_for_status()
        data_lst = response.json().get("data", [])
        if isinstance(data_lst, list):
            return pd.DataFrame(data_lst)
        return pd.DataFrame()


# 使用示例
if __name__ == "__main__":
    api = KjjAPI()
    # 查询最近30天的增持记录
    data = api.get_holding_changes(
        uri="/api/tool/manager/holding/change/list",
        page_index=0,
        page_size=50,
        change_type=1,  # 假设1为增持，请根据实际枚举值调整
        start_date=(datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"),
        end_date=datetime.now().strftime("%Y-%m-%d"),
        platform="lhh5"
    )

    print(data)

