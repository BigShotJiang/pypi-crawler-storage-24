# -*- coding: utf-8 -*-
import sys
import os

import requests

curPath = os.path.abspath(os.path.dirname(__file__))
sys.path.append(curPath)
""" 
    @Description
    @Author：yanlei.wang
    @file： core.py
    @date：2026/3/10 11:57
"""
from datetime import datetime, timedelta
from kjj.utils.common_tools import to_camel_case
from kjj.common.conf import base_url


class KjjApi:
    def __init__(self, token):
        self.token = token
        self.base_url = base_url

    def query_kjj_data(self, **kwargs):
        """
        ?interfaceId=15&requestType=GET&pageIndex=0&pageSize=10&changeType=1&startDate=2026-02-11&endDate=2026-03-13
        """
        params = kwargs if kwargs else {}
        # 注意：request 参数是服务端注入的，客户端无需传递
        headers = {"Content-Type": "application/x-www-form-urlencoded",
                   "Token": f"Bearer {self.token}"}
        # 过滤 None 值
        payload = {to_camel_case(k): v for k, v in params.items() if v is not None}
        payload.update({"requestType": "GET"})
        response = requests.get(self.base_url, params=payload, headers=headers)
        response.raise_for_status()
        data_lst = response.json().get("data", [])
        if data_lst:
            return data_lst
        return response.json().get("msg", "接口请求异常！！")


if __name__ == '__main__':
    api = KjjApi('bear ')
    # 查询最近30天的增持记录
    data = api.query_kjj_data(
        interfaceId=115,
        page_index=0,
        page_size=50,
        change_type=1,  # 假设1为增持，请根据实际枚举值调整
        start_date=(datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"),
        end_date=datetime.now().strftime("%Y-%m-%d"),
    )

    print(data)

