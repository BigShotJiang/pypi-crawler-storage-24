# My Package

equal-data
===============


* easy to use as most of the data returned are pandas DataFrame objects
* can be easily saved as csv, excel or json files
* can be inserted into MySQL or Mongodb

Target Users
--------------

* financial market analyst of China
* learners of financial data analysis with pandas/NumPy
* people who are interested in China financial data

Installation
--------------

    pip install equal-data

Upgrade
---------------

    pip install equal-data --upgrade

Quick Start
--------------

::

    import kjj as KjjApi
    api = KjjApi("your token")
    




