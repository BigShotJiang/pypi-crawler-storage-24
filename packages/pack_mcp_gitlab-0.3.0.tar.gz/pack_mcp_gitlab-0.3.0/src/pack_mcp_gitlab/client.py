import gitlab

from pack_mcp_gitlab.errors import handle_gitlab_error


class GitLabClient:
    def __init__(self, gitlab_url: str, gitlab_token: str):
        if not gitlab_url or not gitlab_url.strip():
            raise ValueError("GITLAB_URL é obrigatório. Configure a variável de ambiente.")
        if not gitlab_token or not gitlab_token.strip():
            raise ValueError("GITLAB_TOKEN é obrigatório. Configure a variável de ambiente.")

        self.gl = gitlab.Gitlab(gitlab_url, private_token=gitlab_token)

    @handle_gitlab_error
    def list_merge_requests(self, project_path: str, state: str = "opened") -> list[dict]:
        """Retorna lista de MRs do projeto filtrados por estado."""
        project = self.gl.projects.get(project_path)
        mrs = project.mergerequests.list(state=state, per_page=100, iterator=True)
        return [
            {
                "iid": mr.iid,
                "title": mr.title,
                "author": mr.author["username"],
                "source_branch": mr.source_branch,
                "target_branch": mr.target_branch,
                "state": mr.state,
                "web_url": mr.web_url,
                "created_at": mr.created_at,
                "updated_at": mr.updated_at,
            }
            for mr in mrs
        ]

    @handle_gitlab_error
    def get_merge_request(self, project_path: str, mr_iid: int) -> dict:
        """Retorna detalhes completos de um MR."""
        project = self.gl.projects.get(project_path)
        mr = project.mergerequests.get(mr_iid)
        return {
            "iid": mr.iid,
            "title": mr.title,
            "description": mr.description,
            "state": mr.state,
            "author": {
                "name": mr.author["name"],
                "username": mr.author["username"],
            },
            "source_branch": mr.source_branch,
            "target_branch": mr.target_branch,
            "web_url": mr.web_url,
            "created_at": mr.created_at,
            "updated_at": mr.updated_at,
        }

    @handle_gitlab_error
    def get_merge_request_changes(self, project_path: str, mr_iid: int) -> list[dict]:
        """Retorna diffs/alterações de um MR."""
        project = self.gl.projects.get(project_path)
        mr = project.mergerequests.get(mr_iid)
        changes = mr.changes()["changes"]
        return [
            {
                "new_path": change["new_path"],
                "old_path": change["old_path"],
                "new_file": change["new_file"],
                "renamed_file": change["renamed_file"],
                "deleted_file": change["deleted_file"],
                "diff": change["diff"],
            }
            for change in changes
        ]

    @handle_gitlab_error
    def get_file_content(self, project_path: str, file_path: str, ref: str = "HEAD") -> dict:
        """Retorna conteúdo de arquivo decodificado em UTF-8."""
        project = self.gl.projects.get(project_path)
        f = project.files.get(file_path=file_path, ref=ref)
        return {
            "file_path": file_path,
            "ref": ref,
            "content": f.decode().decode("utf-8"),
        }

    @handle_gitlab_error
    def create_merge_request_note(self, project_path: str, mr_iid: int, body: str) -> dict:
        """Cria comentário no MR. Retorna id e confirmação."""
        if not body or not body.strip():
            raise ValueError("O conteúdo do comentário (body) é obrigatório.")
        project = self.gl.projects.get(project_path)
        mr = project.mergerequests.get(mr_iid)
        note = mr.notes.create({"body": body})
        return {"id": note.id, "success": True}

    @handle_gitlab_error
    def list_merge_request_notes(self, project_path: str, mr_iid: int) -> list[dict]:
        """Retorna lista de comentários do MR."""
        project = self.gl.projects.get(project_path)
        mr = project.mergerequests.get(mr_iid)
        notes = mr.notes.list(per_page=100, iterator=True)
        return [
            {
                "id": note.id,
                "body": note.body,
                "author": {
                    "name": note.author["name"],
                    "username": note.author["username"],
                },
                "created_at": note.created_at,
                "system": note.system,
            }
            for note in notes
        ]

    @handle_gitlab_error
    def get_project(self, project_path: str) -> dict:
        """Retorna informações do projeto."""
        project = self.gl.projects.get(project_path)
        return {
            "id": project.id,
            "name": project.name,
            "path_with_namespace": project.path_with_namespace,
            "description": project.description,
            "default_branch": project.default_branch,
            "web_url": project.web_url,
            "visibility": project.visibility,
        }

    @handle_gitlab_error
    def search_projects(self, search: str) -> list[dict]:
        """Busca projetos por nome."""
        projects = self.gl.projects.list(search=search, per_page=100)
        return [
            {
                "id": project.id,
                "name": project.name,
                "path_with_namespace": project.path_with_namespace,
                "description": project.description,
                "web_url": project.web_url,
            }
            for project in projects
        ]

    @handle_gitlab_error
    def create_merge_request(
        self,
        project_path: str,
        source_branch: str,
        target_branch: str,
        title: str,
        description: str = "",
        remove_source_branch: bool = False,
        squash: bool = False,
        labels: str = "",
        assignee_ids: list[int] | None = None,
        reviewer_ids: list[int] | None = None,
    ) -> dict:
        """Cria um novo Merge Request no projeto."""
        project = self.gl.projects.get(project_path)

        # Validação: verificar se há diferenças entre as branches
        comparison = project.repository_compare(target_branch, source_branch)
        if not comparison.get("commits") and not comparison.get("diffs"):
            raise ValueError(
                f"Não há diferenças entre '{source_branch}' e '{target_branch}'. "
                "Faça commits na source_branch antes de criar o Merge Request."
            )

        data: dict = {
            "source_branch": source_branch,
            "target_branch": target_branch,
            "title": title,
            "description": description,
            "remove_source_branch": remove_source_branch,
            "squash": squash,
        }
        if labels:
            data["labels"] = labels
        if assignee_ids:
            data["assignee_ids"] = assignee_ids
        if reviewer_ids:
            data["reviewer_ids"] = reviewer_ids

        mr = project.mergerequests.create(data)
        return {
            "iid": mr.iid,
            "title": mr.title,
            "state": mr.state,
            "web_url": mr.web_url,
            "source_branch": mr.source_branch,
            "target_branch": mr.target_branch,
            "created_at": mr.created_at,
        }





