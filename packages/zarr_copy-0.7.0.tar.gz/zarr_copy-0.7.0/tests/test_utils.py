"""Tests for zarr_copy.utils."""

from zarr_copy.utils import iter_slices, tuple_max


class TestTupleMax:
    def test_basic(self):
        assert tuple_max((1, 8, 4), (2, 4, 8)) == (2, 8, 8)

    def test_single_tuple(self):
        assert tuple_max((3, 1, 4)) == (3, 1, 4)

    def test_three_tuples(self):
        assert tuple_max((1, 2), (3, 1), (2, 4)) == (3, 4)

    def test_equal_tuples(self):
        assert tuple_max((5, 5), (5, 5)) == (5, 5)


class TestIterSlices:
    def test_single_dim_exact_fit(self):
        # 6 elements, chunk size 2 -> 3 slices
        bounds = (slice(0, 6),)
        result = list(iter_slices(bounds, (2,)))
        assert result == [(slice(0, 2),), (slice(2, 4),), (slice(4, 6),)]

    def test_single_dim_uneven(self):
        # 5 elements, chunk size 3 -> 2 slices, last one clipped
        bounds = (slice(0, 5),)
        result = list(iter_slices(bounds, (3,)))
        assert result == [(slice(0, 3),), (slice(3, 5),)]

    def test_two_dims(self):
        bounds = (slice(0, 4), slice(0, 4))
        result = list(iter_slices(bounds, (2, 2)))
        assert len(result) == 4
        assert (slice(0, 2), slice(0, 2)) in result
        assert (slice(2, 4), slice(2, 4)) in result

    def test_non_zero_start(self):
        bounds = (slice(2, 8),)
        result = list(iter_slices(bounds, (3,)))
        assert result == [(slice(2, 5),), (slice(5, 8),)]

    def test_covers_full_range(self):
        # Every element should be covered exactly once
        bounds = (slice(0, 10), slice(0, 7))
        chunk = (3, 3)
        covered = set()
        for sl in iter_slices(bounds, chunk):
            for i in range(sl[0].start, sl[0].stop):
                for j in range(sl[1].start, sl[1].stop):
                    assert (i, j) not in covered, f"({i},{j}) covered twice"
                    covered.add((i, j))
        assert covered == {(i, j) for i in range(10) for j in range(7)}
