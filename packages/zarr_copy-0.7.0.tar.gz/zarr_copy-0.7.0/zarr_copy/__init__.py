"""zarr-copy: copy a zarr dataset while optionally rechunking variables."""

from .copy import copy_group, copy_variable, copy_variable_transformed
from .transform import TransformSpec, apply_transform, load_transform_spec, resolve_sources
from .utils import gen_array, iter_slices, tuple_max

__all__ = [
    "copy_group",
    "copy_variable",
    "copy_variable_transformed",
    "TransformSpec",
    "apply_transform",
    "load_transform_spec",
    "resolve_sources",
    "gen_array",
    "iter_slices",
    "tuple_max",
]
