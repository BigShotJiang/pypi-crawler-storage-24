import numpy as np
from scipy.special import expit
from scipy.linalg import svd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils.validation import check_array, check_is_fitted

class LogisticPCA(BaseEstimator, TransformerMixin):
    """
    Estimates a low-rank structural representation of binary matrices.
    Utilizes a Majorization-Minimization (MM) algorithm to bound the 
    Hessian of the Bernoulli log-likelihood, ensuring monotonic convergence.
    Appropriate for dimensionality reduction of sparse administrative records.
    """
    def __init__(self, n_components=2, max_iter=100, tol=1e-5, verbose=False):
        self.n_components = n_components
        self.max_iter = max_iter
        self.tol = tol
        self.verbose = verbose
        
        # Initialize internal state parameters
        self.mu_ = None
        self.components_ = None
        self.U_ = None
        self.loss_history_ = []

    def fit(self, X, y=None):
        """
        Fits the latent parameter space to the observed binary matrix.
        """
        # Enforce scikit-learn standard array validation
        X = check_array(X, dtype='numeric', accept_sparse=False)
        n_samples, n_features = X.shape
        
        # Econometric safeguard: Verify the Bernoulli support constraint
        if not np.array_equal(X, X.astype(bool)):
            raise ValueError("Structural violation: X must contain only binary values (0 or 1).")
        
        # Initialize the baseline intercept to capture main effects
        self.mu_ = np.zeros(n_features)
        Theta = np.zeros((n_samples, n_features))
        self.loss_history_ = []

        for i in range(self.max_iter):
            # Transform the linear predictor to the probability scale
            P = expit(Theta)
            
            # Formulate the quadratic surrogate working matrix (Z)
            # The theoretical upper bound for the Bernoulli variance is exactly 0.25
            Z = Theta + 4.0 * (X - P)
            
            # Isolate the main effects
            self.mu_ = np.mean(Z, axis=0)
            Z_centered = Z - self.mu_
            
            # Extract structural dimensions via Singular Value Decomposition
            U_full, S_full, Vt_full = svd(Z_centered, full_matrices=False)
            
            # Truncate to the specified latent rank (k)
            U_k = U_full[:, :self.n_components]
            S_k = S_full[:self.n_components]
            Vt_k = Vt_full[:self.n_components, :]
            
            # Reconstruct the bounded linear predictor
            Theta = self.mu_ + np.dot(U_k, np.dot(np.diag(S_k), Vt_k))
            
            # Calculate the Bernoulli deviance to track optimization trajectory
            loss = -2.0 * np.sum(X * Theta - np.log(1.0 + np.exp(Theta)))
            self.loss_history_.append(loss)
            
            if self.verbose:
                print(f"Iteration {i}: Deviance = {loss:.4f}")
                
            # Convergence check to halt redundant estimation
            if i > 0 and abs(self.loss_history_[-2] - loss) < self.tol:
                break
                
        # Store the final identified structural parameters
        self.components_ = Vt_k
        self.U_ = np.dot(U_k, np.diag(S_k))
        
        # Required scikit-learn protocol to mark the estimator as fitted
        self.is_fitted_ = True
        
        return self

    def transform(self, X):
        """
        Projects out-of-sample observations into the identified latent space.
        Maintains fixed structural components (V) while optimizing U.
        """
        # Verify the model has been estimated prior to transformation
        check_is_fitted(self, 'is_fitted_')
        
        X = check_array(X, dtype='numeric', accept_sparse=False)
        n_samples = X.shape[0]
        
        if not np.array_equal(X, X.astype(bool)):
            raise ValueError("Structural violation: X must contain only binary values (0 or 1).")
        
        # Initialize the unobserved heterogeneity matrix
        U_new = np.zeros((n_samples, self.n_components))
        V = self.components_.T 
        
        for _ in range(self.max_iter):
            Theta = self.mu_ + np.dot(U_new, V.T)
            P = expit(Theta)
            
            # Calculate the surrogate matrix for the validation cohort
            Z = Theta + 4.0 * (X - P)
            
            # Project onto the orthogonal component space
            U_new = np.dot(Z - self.mu_, V)
            
        return U_new

class CVLogisticPCA(BaseEstimator):
    """
    Wrapper for cross-validated structural rank selection.
    Included to maintain namespace integrity for external imports.
    """
    def __init__(self, cv=5):
        self.cv = cv
    
    def fit(self, X, y=None):
        pass