def create_dataset_from_stream(
    self,
    request: Optional[FileLike] = None,
    name: Optional[str] = None,
    source: Optional[
        DataSourceItem
    ] = None,  # optional because we still have to support the old way # TODO: Remove once deprecated
    *,
    timeout: Optional[int] = DEFAULT_TIMEOUT,
) -> Dataset:
    """Create a dataset by streaming chunks of the dataset.

    DEPRECATED: Please use create_dataset instead.
    """

    warnings.warn(
        DeprecationWarning(
            "create_dataset_from_stream is deprecated. Use create_dataset instead."
        )
    )

    _source: Optional[Union[str, FileLike]] = request or source # type: ignore[assignment]
    return self.create_dataset(source=_source, name=name, timeout=timeout)


def create_dataset(
    self,
    request: Optional[FileLike] = None,  # TODO: Remove once deprecated
    name: Optional[str] = None,
    source: Optional[
        DataSourceItems
    ] = None,  # optional because we still have to support the old way
    *,
    timeout: Optional[int] = DEFAULT_TIMEOUT,
) -> Dataset:
    """Create a dataset from file upload."""

    if request:
        warnings.warn(DeprecationWarning("request is deprecated. Use file instead."))

    if request is not None and source is not None:
        raise ValueError("You cannot pass both request and source.")

    if request is None and source is None:
        raise ValueError("You need to pass in a source.")

    _source = request or source

    if _source is None:
        raise ValueError("You need to pass in a source.")

    ds, inferred_type = ArrowDatasetBuilder().to_dataset(_source)

    filetype: Optional[FileType] = FileType[inferred_type] if inferred_type else None

    kwargs = {
        "method": "post",
        "url": "/datasets/stream",
        "timeout": timeout,
        "dataset": ds,
        "params": dict(name=name, filetype=filetype),
    }

    result = self.client.request(**kwargs) # type: ignore[arg-type]

    return Dataset(**result)


def download_dataset_as_stream(
    self,
    id: str,
    destination: Optional[Union[str, FileLike]] = None,
    *,
    filetype: Optional[FileType] = None,
    timeout: Optional[int] = DEFAULT_TIMEOUT,
) -> Any:
    """Download a dataset by streaming chunks of it.

    DEPRECATED: Please use download_dataset instead.
    """
    warnings.warn(
        DeprecationWarning(
            "download_dataset_as_stream is deprecated. Use download_dataset instead."
        )
    )

    # Ignoring return type because download_dataset's logic makes sure
    # that the return type will be BytesIO
    # No point in going through the hassle of using typing.overload for something
    # that will be removed soon
    return self.download_dataset(
        id,
        destination=destination,
        timeout=timeout,
        filetype=filetype,
        from_download_as_stream=True,
    )


def download_dataset(
    self,
    id: str,
    destination: Optional[Union[str, FileLike]] = None,
    filetype: Optional[FileType] = None,
    *,
    timeout: Optional[int] = DEFAULT_TIMEOUT,
    from_download_as_stream: bool = False,  # TODO: Remove once deprecated
) -> Any:
    """Download a dataset."""
    # Download dataset metadata
    dataset_info = self.client.datasets.get_dataset(id, timeout=timeout)

    if destination is None:
        warnings.warn(
            DeprecationWarning(
                "Please specify the destination argument. The return type will change in the future."
            )
        )

        if not from_download_as_stream:
            # Download as CSV was the old return value when using download_dataset
            filetype = filetype or FileType.csv
        else:
            # Download as the filetype of the dataset on the server was the old
            # return value when using download_dataset_as_stream
            filetype = filetype or dataset_info.filetype
    else:
        if not (isinstance(destination, str) or is_file_like(destination)):
            raise TypeError(
                f"Expected destination to be a string or a buffer, got {type(destination)} instead"
            )

    return self.client.request(
        method="get",
        url=f"/datasets/{id}/download/stream",
        params={"filetype": filetype},
        should_stream=True,
        want_content=destination is None and not from_download_as_stream,
        timeout=timeout,
        destination=destination,
    )
