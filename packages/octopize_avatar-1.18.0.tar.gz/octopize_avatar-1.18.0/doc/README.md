# Documentation

## Objective

The objective of this file is to describe how the build process of the documentation.

## Tools

We use `sphinx` to build our documentation, along with a few extensions.

- `sphinx.ext.autodoc`

  TODO: Explain to which files this applies to.

- `sphinx.ext.napoleon`

  TODO: Explain to which files this applies to.

- [`sphinx_multiversion`](https://holzhaus.github.io/sphinx-multiversion/master/quickstart.html)

  This is used to create multiple versions of the documentation.

- `sphinx.ext.autosummary`

  TODO: Explain to which files this applies to.

- `sphinxcontrib.autodoc_pydantic`

  This is used to generate documentation from `pydantic` models which come with useful information such as constrained values and a docstring per variable.

## Editing documentation

The following `.rst` files are **auto-generated** from their Markdown sources via `just format-doc`:

| Generated file              | Source file                |
| --------------------------- | -------------------------- |
| `doc/source/tutorial.rst`   | `doc/source/tutorial.md`   |
| `doc/source/user_guide.rst` | `doc/source/user_guide.md` |
| `doc/source/changelog.rst`  | `CHANGELOG.md`             |

**Always edit the `.md` source**, then run:

```bash
just format-doc
```

to regenerate the `.rst`. Commit both the `.md` and the regenerated `.rst` together.

Editing the `.rst` directly will cause your changes to be **silently overwritten** the next time `just format-doc` or `just doc-build` is run.

## Build process

Use `just doc-build` to build the documentation. Be on the lookout for errors during the build process, as `sphinx-multiversion` will not stop the build process on errors.

## Gotchas

`sphinx-multiversion` uses git to checkout the different branches and tags of the documentation. That means that any changes that you want to see being built MUST be committed. Any change that is not committed will not be taken into account.
