from lxml import etree
from typing import Optional, Any, Union, List
from ..xml_utils import xpath, inches_to_emu, emu_to_inches, qname
from .format import FillFormat
from ..text import Text

class BaseShape:
    """
    Base class for all shape types on a slide.
    
    Provides properties to manipulate the position (x, y) and size (width, height)
    of the shape using either English Metric Units (EMUs) or inches.
    """
    
    def __init__(self, xml_element: Optional[etree._Element] = None) -> None:
        """
        Initializes a new shape instance wrapping an XML element.
        
        Args:
            xml_element (Optional[etree._Element]): The raw lxml element representing the shape.
        """
        if xml_element is None:
            raise ValueError("BaseShape requires an xml_element. Use a specific subclass to construct from scratch.")
        self._element = xml_element
        self.slide: Optional[Any] = None

    @property
    def element(self) -> etree._Element:
        """
        Returns the underlying lxml element for advanced editing and extraction.
        
        Returns:
            etree._Element: The raw lxml XML element.
        """
        return self._element

    @property
    def shape_name(self) -> str:
        """
        Gets or sets the shape's internal reference name.
        
        Returns:
            str: The internal name (e.g., 'TextBox 1'), or an empty string if not found.
        """
        nvPr = xpath(self._element, ".//p:cNvPr")
        if nvPr:
            return str(nvPr[0].get("name", ""))
        return ""

    @shape_name.setter
    def shape_name(self, value: str) -> None:
        nvPr = xpath(self._element, ".//p:cNvPr")
        if nvPr:
            nvPr[0].set("name", value)

    def _get_xfrm_node(self) -> Optional[etree._Element]:
        """Internal helper to locate the <a:xfrm> transform node."""
        xfrms = xpath(self._element, ".//a:xfrm")
        if xfrms:
            return xfrms[0]
        return None

    def _get_off_node(self) -> Optional[etree._Element]:
        """Internal helper to locate the <a:off> offset node."""
        xfrm = self._get_xfrm_node()
        if xfrm is not None:
            offs = xpath(xfrm, "a:off")
            if offs:
                return offs[0]
        return None

    def _get_ext_node(self) -> Optional[etree._Element]:
        """Internal helper to locate the <a:ext> extent (size) node."""
        xfrm = self._get_xfrm_node()
        if xfrm is not None:
            exts = xpath(xfrm, "a:ext")
            if exts:
                return exts[0]
        return None

    @property
    def x(self) -> int:
        """
        Gets or sets the X (horizontal) coordinate of the shape in EMUs.
        
        Returns:
            int: The X coordinate in EMUs.
        """
        node = self._get_off_node()
        return int(node.get("x", 0)) if node is not None else 0

    @x.setter
    def x(self, value: int) -> None:
        node = self._get_off_node()
        if node is not None:
            node.set("x", str(int(value)))

    @property
    def y(self) -> int:
        """
        Gets or sets the Y (vertical) coordinate of the shape in EMUs.
        
        Returns:
            int: The Y coordinate in EMUs.
        """
        node = self._get_off_node()
        return int(node.get("y", 0)) if node is not None else 0

    @y.setter
    def y(self, value: int) -> None:
        node = self._get_off_node()
        if node is not None:
            node.set("y", str(int(value)))

    @property
    def cx(self) -> int:
        """
        Gets or sets the width (cx) of the shape in EMUs.
        
        Returns:
            int: The width in EMUs.
        """
        node = self._get_ext_node()
        return int(node.get("cx", 0)) if node is not None else 0

    @cx.setter
    def cx(self, value: int) -> None:
        node = self._get_ext_node()
        if node is not None:
            node.set("cx", str(int(value)))

    @property
    def cy(self) -> int:
        """
        Gets or sets the height (cy) of the shape in EMUs.
        
        Returns:
            int: The height in EMUs.
        """
        node = self._get_ext_node()
        return int(node.get("cy", 0)) if node is not None else 0

    @cy.setter
    def cy(self, value: int) -> None:
        node = self._get_ext_node()
        if node is not None:
            node.set("cy", str(int(value)))

    @property
    def x_inches(self) -> float:
        """X coordinate represented in inches."""
        return emu_to_inches(self.x)

    @x_inches.setter
    def x_inches(self, value: float) -> None:
        self.x = inches_to_emu(value)

    @property
    def y_inches(self) -> float:
        """Y coordinate represented in inches."""
        return emu_to_inches(self.y)

    @y_inches.setter
    def y_inches(self, value: float) -> None:
        self.y = inches_to_emu(value)

    @property
    def width_inches(self) -> float:
        """Width represented in inches."""
        return emu_to_inches(self.cx)

    @width_inches.setter
    def width_inches(self, value: float) -> None:
        self.cx = inches_to_emu(value)

    @property
    def height_inches(self) -> float:
        """Height represented in inches."""
        return emu_to_inches(self.cy)

    @height_inches.setter
    def height_inches(self, value: float) -> None:
        self.cy = inches_to_emu(value)

    @property
    def fill(self) -> FillFormat:
        """
        Gets the FillFormat object for this shape, allowing background color styling.
        
        Returns:
            FillFormat: The format object for customizing the shape's fill.
        """
        return FillFormat(self)

    def has_text(self, text_pattern: str) -> bool:
        """
        Checks if the shape contains the specified text pattern anywhere in its XML structure.
        
        Args:
            text_pattern (str): The string pattern to search for (e.g. '{{name}}').
            
        Returns:
            bool: True if the pattern is found within any <a:t> nodes, False otherwise.
        """
        t_nodes = xpath(self._element, ".//a:t")
        for node in t_nodes:
            if node.text and text_pattern in node.text:
                return True
        return False

    @property
    def is_textual(self) -> bool:
        """
        Returns True if the shape is capable of bearing text (has a txBody or is a Table/Chart).
        """
        if xpath(self._element, ".//p:txBody") or xpath(self._element, ".//a:txBody"):
            return True
        # Charts and Tables are considered textual because they contain text elements
        if xpath(self._element, ".//c:chart") or xpath(self._element, ".//a:tbl"):
            return True
        return False

    @property
    def text(self) -> str:
        """
        Gets or sets the text content of the shape.
        
        Returns:
            str: joined text from all <a:t> nodes.
        """
        t_nodes = xpath(self._element, ".//a:t/text()")
        return "".join(t_nodes)

    @text.setter
    def text(self, value: Union[str, Text]) -> None:
        """
        Sets the text content. Handles rich Text objects if the shape has a txBody.
        """
        if self.slide:
            # Delegate to slide's helper which is already robust
            self.slide._set_shape_text(self._element, value)
        else:
            # Fallback if no slide reference
            if isinstance(value, Text):
                txBody = xpath(self._element, ".//p:txBody") or xpath(self._element, ".//a:txBody")
                if txBody:
                    paragraphs = xpath(txBody[0], "a:p")
                    for p in paragraphs:
                        txBody[0].remove(p)
                    txBody[0].append(value.to_xml_element())
            else:
                t_nodes = xpath(self._element, ".//a:t")
                if t_nodes:
                    t_nodes[0].text = str(value)
                    for node in t_nodes[1:]:
                        p = node.getparent()
                        if p is not None:
                            p.remove(node)

    def replace_text(self, old: str, new: str) -> int:
        """
        Replaces all occurrences of 'old' with 'new' in all text nodes.
        
        Returns:
            int: Number of replacements made.
        """
        count = 0
        t_nodes = xpath(self._element, ".//a:t")
        for node in t_nodes:
            if node.text and old in node.text:
                node.text = node.text.replace(old, new)
                count += 1
        return count

    def replace_with_picture(self, image_path: str) -> None:
        """
        Replaces this shape with a picture, preserving its position and size.
        """
        if self.slide:
            from .picture import Picture
            x, y, cx, cy = self.x, self.y, self.cx, self.cy
            self.slide.delete_shape(self)
            new_pic = Picture(image_path, x, y, cx, cy)
            self.slide.insert_shape(new_pic)
        else:
            raise ValueError("Shape must be attached to a slide to be replaced with a picture.")
