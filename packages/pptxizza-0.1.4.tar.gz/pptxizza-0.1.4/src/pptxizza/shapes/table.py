from lxml import etree
from typing import List, Optional, Any, Union, Dict
from ..xml_utils import xpath, NAMESPACES, qname
from .graphic_frame import GraphicFrame
from ..util import Length

class _Cell:
    """Represents a single cell in a table."""
    def __init__(self, element: etree._Element, slide: Any) -> None:
        self._element = element
        self.slide = slide

    @property
    def text(self) -> str:
        """Gets the plain text content of the cell."""
        t_nodes = xpath(self._element, ".//a:t")
        return "".join([t.text for t in t_nodes if t.text])

    @text.setter
    def text(self, value: str) -> None:
        """Sets the plain text content of the cell, replacing existing content."""
        txBody = xpath(self._element, "a:txBody")
        if not txBody:
            txBody_elem = etree.SubElement(self._element, qname("a", "txBody"))
            etree.SubElement(txBody_elem, qname("a", "bodyPr"))
            etree.SubElement(txBody_elem, qname("a", "lstStyle"))
        else:
            txBody_elem = txBody[0]
        
        # Remove all existing paragraphs
        for p in xpath(txBody_elem, "a:p"):
            txBody_elem.remove(p)
            
        # Create a new paragraph with the text
        p_elem = etree.SubElement(txBody_elem, qname("a", "p"))
        r_elem = etree.SubElement(p_elem, qname("a", "r"))
        t_elem = etree.SubElement(r_elem, qname("a", "t"))
        t_elem.text = str(value)

class _Row:
    """Represents a row in a table."""
    def __init__(self, element: etree._Element, slide: Any) -> None:
        self._element = element
        self.slide = slide

    @property
    def cells(self) -> List[_Cell]:
        """Returns a list of cells in this row."""
        return [_Cell(tc, self.slide) for tc in xpath(self._element, "a:tc")]

class _Column:
    """Represents a column in a table (mostly for width and removal)."""
    def __init__(self, table: 'Table', index: int) -> None:
        self._table = table
        self._index = index

    @property
    def width(self) -> int:
        """Gets the column width in EMUs."""
        tblGrid = xpath(self._table._tbl, "a:tblGrid")[0]
        cols = xpath(tblGrid, "a:gridCol")
        return int(cols[self._index].get("w", 0))

    @width.setter
    def width(self, value: int) -> None:
        """Sets the column width in EMUs."""
        tblGrid = xpath(self._table._tbl, "a:tblGrid")[0]
        cols = xpath(tblGrid, "a:gridCol")
        cols[self._index].set("w", str(int(value)))

class Table(GraphicFrame):
    """
    Represents a Table shape.
    Provides methods to manipulate rows, columns, and cell data.
    """
    def __init__(self, xml_element: Optional[etree._Element] = None, rows: int = 0, cols: int = 0, x: Union[int, Length] = 0, y: Union[int, Length] = 0, cx: Union[int, Length] = 0, cy: Union[int, Length] = 0) -> None:
        """
        Initializes a Table shape.
        
        Args:
            xml_element (Optional[etree._Element]): Existing XML node to wrap. If None, it creates a new one.
            rows (int): Number of rows for a new table.
            cols (int): Number of columns for a new table.
            x (int): Optional initial X coordinate in EMUs.
            y (int): Optional initial Y coordinate in EMUs.
            cx (int): Optional initial width in EMUs.
            cy (int): Optional initial height in EMUs.
        """
        if xml_element is None:
            table_xml = f'''
            <p:graphicFrame xmlns:a="{NAMESPACES["a"]}" xmlns:p="{NAMESPACES["p"]}">
                <p:nvGraphicFramePr>
                    <p:cNvPr id="0" name="Table"/>
                    <p:cNvGraphicFramePr/>
                    <p:nvPr/>
                </p:nvGraphicFramePr>
                <p:xfrm>
                    <a:off x="{int(x)}" y="{int(y)}"/>
                    <a:ext cx="{int(cx)}" cy="{int(cy)}"/>
                </p:xfrm>
                <a:graphic>
                    <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table">
                        <a:tbl>
                            <a:tblPr/>
                            <a:tblGrid/>
                        </a:tbl>
                    </a:graphicData>
                </a:graphic>
            </p:graphicFrame>
            '''
            xml_element = etree.fromstring(table_xml.encode('utf-8'))
        
        super().__init__(xml_element)
        tbl_nodes = xpath(self._element, ".//a:tbl")
        if not tbl_nodes:
            raise ValueError("GraphicFrame does not contain a table element.")
        self._tbl = tbl_nodes[0]

        if rows > 0 or cols > 0:
            # Initialize with requested dimensions
            for _ in range(cols):
                self.add_column(width_emu=int(cx // cols) if cols > 0 else 2000000)
            for _ in range(rows):
                self.add_row(height_emu=int(cy // rows) if rows > 1 else 370840)

    @property
    def rows(self) -> List[_Row]:
        """Returns a list of rows in the table."""
        return [_Row(tr, self.slide) for tr in xpath(self._tbl, "a:tr")]

    @property
    def columns(self) -> List[_Column]:
        """Returns a list of columns in the table."""
        tblGrid = xpath(self._tbl, "a:tblGrid")[0]
        cols = xpath(tblGrid, "a:gridCol")
        return [_Column(self, i) for i in range(len(cols))]

    @property
    def row_count(self) -> int:
        """Returns the number of rows in the table."""
        return len(xpath(self._tbl, "a:tr"))

    @property
    def column_count(self) -> int:
        """Returns the number of columns in the table."""
        tblGrid = xpath(self._tbl, "a:tblGrid")[0]
        return len(xpath(tblGrid, "a:gridCol"))

    def ensure_size(self, rows: int, cols: int) -> None:
        """
        Ensures the table has at least the specified number of rows and columns.
        """
        current_rows = self.row_count
        current_cols = self.column_count
        
        if cols > current_cols:
            for _ in range(cols - current_cols):
                self.add_column()
        
        if rows > current_rows:
            for _ in range(rows - current_rows):
                self.add_row()

    def set_data(self, data: Union[List[List[Any]], List[Dict[str, Any]]]) -> None:
        """
        Populates the table with data.
        If a list of lists is provided, it fills cells by index.
        If a list of dicts is provided, it assumes the first row contains headers.
        """
        if not data:
            return
            
        if isinstance(data[0], list):
            self.ensure_size(len(data), len(data[0]))
            for r_idx, row_data in enumerate(data):
                for c_idx, value in enumerate(row_data):
                    self.cell(r_idx, c_idx).text = str(value)
        elif isinstance(data[0], dict):
            # Header-based filling
            headers = list(data[0].keys())
            self.ensure_size(len(data) + 1, len(headers))
            self.set_column_names(headers)
            for r_idx, row_dict in enumerate(data):
                for c_idx, header in enumerate(headers):
                    self.cell(r_idx + 1, c_idx).text = str(row_dict.get(header, ""))

    def to_matrix(self) -> List[List[str]]:
        """Returns the table data as a 2D list of strings."""
        return [[cell.text for cell in row.cells] for row in self.rows]

    def cell(self, row_idx: int, col_idx: int) -> _Cell:
        """
        Returns a specific cell by index.
        
        Args:
            row_idx (int): 0-indexed row position.
            col_idx (int): 0-indexed column position.
        """
        rows = self.rows
        if row_idx < 0 or row_idx >= len(rows):
            raise IndexError(f"Row index {row_idx} out of range (max {len(rows)-1})")
        cells = rows[row_idx].cells
        if col_idx < 0 or col_idx >= len(cells):
            raise IndexError(f"Column index {col_idx} out of range (max {len(cells)-1})")
        return cells[col_idx]

    @property
    def style_id(self) -> str:
        """Gets the Table Style GUID."""
        style_id_nodes = xpath(self._tbl, "a:tblPr/a:tblStyleId")
        if style_id_nodes:
            return style_id_nodes[0].text or ""
        return ""

    @style_id.setter
    def style_id(self, value: str) -> None:
        """Sets the Table Style GUID."""
        tblPr = xpath(self._tbl, "a:tblPr")
        if not tblPr:
            tblPr_elem = etree.Element(qname("a", "tblPr"))
            self._tbl.insert(0, tblPr_elem)
        else:
            tblPr_elem = tblPr[0]
        
        style_id_nodes = xpath(tblPr_elem, "a:tblStyleId")
        if not style_id_nodes:
            style_id_elem = etree.SubElement(tblPr_elem, qname("a", "tblStyleId"))
        else:
            style_id_elem = style_id_nodes[0]
        style_id_elem.text = value

    def apply_preset(self, preset_name: str) -> None:
        """
        Applies a table style preset.
        
        Common Presets:
        - 'Medium Style 2 - Accent 1'
        - 'Light Style 1'
        - 'Dark Style 1'
        """
        presets = {
            "Medium Style 2 - Accent 1": "{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}",
            "Medium Style 2 - Accent 2": "{ED083AE6-46FA-4A59-8FB0-9997E7E50039}",
            "Light Style 1": "{21E4AEA4-8DFA-4A11-82A9-7001FD6F4C40}",
            "Dark Style 1": "{E202B19D-56CF-4690-BD35-B5CC5043B0ED}",
        }
        if preset_name in presets:
            self.style_id = presets[preset_name]
        else:
            # If not in presets, assume it's already a GUID or valid ID
            self.style_id = preset_name

    def add_row(self, height_emu: int = 370840) -> _Row:
        """Appends a new row to the table."""
        tblGrid = xpath(self._tbl, "a:tblGrid")[0]
        num_cols = len(xpath(tblGrid, "a:gridCol"))
        
        tr = etree.SubElement(self._tbl, qname("a", "tr"), h=str(height_emu))
        for _ in range(num_cols):
            tc = etree.SubElement(tr, qname("a", "tc"))
            txBody = etree.SubElement(tc, qname("a", "txBody"))
            etree.SubElement(txBody, qname("a", "bodyPr"))
            etree.SubElement(txBody, qname("a", "lstStyle"))
            etree.SubElement(txBody, qname("a", "p"))
            etree.SubElement(tc, qname("a", "tcPr"))
        return _Row(tr, self.slide)

    def remove_row(self, row_idx: int) -> None:
        """Removes the row at the specified index."""
        rows = xpath(self._tbl, "a:tr")
        if 0 <= row_idx < len(rows):
            self._tbl.remove(rows[row_idx])
        else:
            raise IndexError(f"Row index {row_idx} out of range.")

    def add_column(self, width_emu: int = 2000000) -> None:
        """Appends a new column to the table."""
        tblGrid = xpath(self._tbl, "a:tblGrid")[0]
        etree.SubElement(tblGrid, qname("a", "gridCol"), w=str(width_emu))
        
        for tr in xpath(self._tbl, "a:tr"):
            tc = etree.SubElement(tr, qname("a", "tc"))
            txBody = etree.SubElement(tc, qname("a", "txBody"))
            etree.SubElement(txBody, qname("a", "bodyPr"))
            etree.SubElement(txBody, qname("a", "lstStyle"))
            etree.SubElement(txBody, qname("a", "p"))
            etree.SubElement(tc, qname("a", "tcPr"))

    def remove_column(self, col_idx: int) -> None:
        """Removes the column at the specified index."""
        tblGrid = xpath(self._tbl, "a:tblGrid")[0]
        gridCols = xpath(tblGrid, "a:gridCol")
        if 0 <= col_idx < len(gridCols):
            tblGrid.remove(gridCols[col_idx])
        else:
            raise IndexError(f"Column index {col_idx} out of range.")
            
        for tr in xpath(self._tbl, "a:tr"):
            tcs = xpath(tr, "a:tc")
            if 0 <= col_idx < len(tcs):
                tr.remove(tcs[col_idx])

    def set_column_names(self, names: List[str]) -> None:
        """Sets the text of the first row (header row)."""
        if not self.rows:
            self.add_row()
        header_row = self.rows[0]
        for i, name in enumerate(names):
            if i < len(header_row.cells):
                header_row.cells[i].text = name
