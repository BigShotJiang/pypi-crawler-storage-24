from typing import List, Dict, Union, Any, Optional
from ..xml_utils import xpath
from .graphic_frame import GraphicFrame

class Chart(GraphicFrame):
    """
    Base wrapper for GraphicFrames proven to contain internal chart relations.
    """
    
    @property
    def has_title(self) -> bool:
        """Checks if the chart has a title."""
        if self.slide is None:
            return False
        from ..charts import has_chart_title
        return has_chart_title(self.slide, self.shape_name)

    @property
    def title_text(self) -> Optional[str]:
        """Gets or sets the chart title text."""
        if self.slide is None:
            return None
        from ..charts import get_chart_title
        return get_chart_title(self.slide, self.shape_name)

    @title_text.setter
    def title_text(self, value: str) -> None:
        self.set_title(value)

    def set_title(self, text: str) -> None:
        """Sets the chart title text."""
        if self.slide is None:
            raise ValueError("Chart must have a reference to a Slide to modify title.")
        from ..charts import set_chart_title
        set_chart_title(self.slide, self.shape_name, text)

    def replace_title_text(self, old: str, new: str) -> None:
        """Replaces substrings within the chart title."""
        current = self.title_text
        if current and old in current:
            self.title_text = current.replace(old, new)

    def replace_data(self, data: Dict[Union[int, str], List[Any]], categories: List[str]) -> None:
        """
        Modifies native chart cache bounds without replacing templates.
        
        Args:
            data (Dict[Union[int, str], List[Any]]): A dictionary mapping Series index integers or strings to numeric lists.
            categories (List[str]): Array mapping category labels.
            
        Raises:
            ValueError: If the current chart has no linkage back to a valid Slide object (needs the relation graph).
        """
        if self.slide is None:
            raise ValueError("Chart must have a reference to a Slide to modify nested data.")
            
        from ..charts import replace_chart_data
        
        # We can directly exploit the shape_name attribute to delegate downwards
        replace_chart_data(self.slide, self.shape_name, data, categories)
