from lxml import etree
from typing import Optional, Union
from ..util import Length
from ..xml_utils import NAMESPACES, parse_xml
from .base_shape import BaseShape

class Picture(BaseShape):
    """
    Represents an image element (<p:pic>) inserted on the slide.
    """
    def __init__(self, image_path: Optional[str] = None, x: Union[int, Length] = 0, y: Union[int, Length] = 0, cx: Union[int, Length] = 0, cy: Union[int, Length] = 0, xml_element: Optional[etree._Element] = None) -> None:
        """
        Initializes a Picture that can be added to a Presentation slide.
        
        Args:
            image_path (Optional[str]): Source file path for the image (used when adding from scratch).
            x (int): Optional initial X coordinate in EMUs.
            y (int): Optional initial Y coordinate in EMUs.
            cx (int): Optional initial width in EMUs.
            cy (int): Optional initial height in EMUs.
            xml_element (Optional[etree._Element]): Existing XML node to wrap. If None, it creates a new one.
        """
        self.pending_image_path = image_path
        if xml_element is None:
            pic_xml = f'''
            <p:pic xmlns:a="{NAMESPACES["a"]}" xmlns:p="{NAMESPACES["p"]}" xmlns:r="{NAMESPACES["r"]}">
                <p:nvPicPr>
                    <p:cNvPr id="0" name="Picture"/>
                    <p:cNvPicPr>
                        <a:picLocks noChangeAspect="1"/>
                    </p:cNvPicPr>
                    <p:nvPr/>
                </p:nvPicPr>
                <p:blipFill>
                    <a:blip r:embed=""/>
                    <a:stretch>
                        <a:fillRect/>
                    </a:stretch>
                </p:blipFill>
                <p:spPr>
                    <a:xfrm>
                        <a:off x="{int(x)}" y="{int(y)}"/>
                        <a:ext cx="{int(cx)}" cy="{int(cy)}"/>
                    </a:xfrm>
                    <a:prstGeom prst="rect">
                        <a:avLst/>
                    </a:prstGeom>
                </p:spPr>
            </p:pic>
            '''
            xml_element = parse_xml(pic_xml.encode('utf-8'))
        super().__init__(xml_element)

    @staticmethod
    def from_file(image_path: str, x: Union[int, Length] = 0, y: Union[int, Length] = 0, cx: Union[int, Length] = 0, cy: Union[int, Length] = 0) -> 'Picture':
        """
        Creates a new Picture instance from a file path.
        
        Args:
            image_path (str): Path to the image file.
            x (int): Optional initial X coordinate in EMUs.
            y (int): Optional initial Y coordinate in EMUs.
            cx (int): Optional initial width in EMUs.
            cy (int): Optional initial height in EMUs.
            
        Returns:
            Picture: A new Picture instance.
        """
        return Picture(image_path, x, y, cx, cy)
