import os
import sys

# Ensure pptxizza from src is used
sys.path.insert(0, os.path.abspath("src"))

from pptxizza.presentation import Presentation
from pptxizza.shapes import TextBox, Table, Chart, Picture
from pptxizza.text import Text, Run
from pptxizza.util import Inches

def test_ergonomics():
    output_path = os.path.abspath("tests/output/test_ergonomics.pptx")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # 1. Slide Management
    print("Testing Slide Management...")
    pres = Presentation(create_blank_slide=True)
    assert len(pres.slides) == 1
    
    pres.add_blank_slide()
    assert len(pres.slides) == 2
    
    slide3 = pres.ensure_slide(2)
    assert len(pres.slides) == 3
    
    # 2. Picture Insertion
    print("Testing Picture Insertion...")
    image_path = os.path.abspath("tests/fixtures/test_image.png")
    pic = slide3.add_picture(image_path, x=Inches(1), y=Inches(1), cx=Inches(2), cy=Inches(2))
    assert isinstance(pic, Picture)
    
    # 3. Generic Text Access
    print("Testing Generic Text Access...")
    tb = slide3.insert_shape(TextBox("Hello World", x=Inches(4), y=Inches(1)))
    assert tb.is_textual
    assert tb.text == "Hello World"
    
    # Rich text setter
    rich_text = Text()
    rich_text.add_run("Rich ", bold=True)
    rich_text.add_run("Text", italic=True)
    tb.text = rich_text
    assert "Rich Text" in tb.text
    
    # replace_text
    tb.replace_text("Rich", "Awesome")
    assert "Awesome Text" in tb.text
    
    # find_text
    results = pres.find_text("Awesome")
    assert len(results) > 0
    assert results[0].element == tb.element
    
    # 4. Table Ergonomics
    print("Testing Table Ergonomics...")
    slide4 = pres.add_blank_slide()
    table = slide4.insert_shape(Table(rows=2, cols=2, x=Inches(1), y=Inches(1), cx=Inches(4), cy=Inches(2)))
    assert table.row_count == 2
    assert table.column_count == 2
    
    table.ensure_size(3, 3)
    assert table.row_count == 3
    assert table.column_count == 3
    
    data = [
        ["Header 1", "Header 2", "Header 3"],
        ["A1", "B1", "C1"],
        ["A2", "B2", "C2"]
    ]
    table.set_data(data)
    matrix = table.to_matrix()
    assert matrix[1][1] == "B1"
    
    # Dict data
    dict_data = [
        {"Name": "Alice", "Age": 30},
        {"Name": "Bob", "Age": 25}
    ]
    slide5 = pres.add_blank_slide()
    table2 = slide5.insert_shape(Table(x=Inches(1), y=Inches(1)))
    table2.set_data(dict_data)
    assert table2.cell(1, 0).text == "Alice"
    assert table2.cell(0, 1).text == "Age"
    
    # 5. replace_with_picture
    print("Testing replace_with_picture...")
    rect = slide5.insert_shape(TextBox("Replace me", x=Inches(5), y=Inches(5)))
    rect.replace_with_picture(image_path)
    # Check if a picture appeared at that location
    found_pics = slide5.find_shapes(shape_type=Picture)
    assert len(found_pics) > 0
    
    # Note: Chart titles are harder to test without a template that has a chart,
    # but the logic is there and uses same xpath patterns as other working things.
    
    pres.save(output_path)
    print(f"Verification successful! Saved to {output_path}")

if __name__ == "__main__":
    test_ergonomics()
