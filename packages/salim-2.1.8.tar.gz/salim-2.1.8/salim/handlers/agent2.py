"""
Salim Autonomous Agent v2 — True task chains with persistent memory & self-healing.

Upgrades over v1:
  • Persistent working scratchpad that survives across tasks and restarts (SQLite)
  • Task chains: define multi-task sequences by name, run them in order
  • Self-healing: on failure, AI diagnoses and retries with corrected approach
  • Richer tool set: browser_get, http_request, summarize_file, index_files, db_query
  • Streaming step-by-step progress via Telegram message edits
  • Chain history: every run logged to DB, queryable later
  • Parallel branches: run independent subtasks concurrently

Commands:
  /agent <goal>              — autonomous one-off task
  /chain new <name> <desc>   — define named task chain
  /chain add <name> <task>   — add task to chain
  /chain run <name>          — execute a named chain
  /chain list                — list saved chains
  /chain del <name>          — delete a chain
  /agentstop                 — stop running agent
  /agentstatus               — check status
  /agentlog [n]              — show last N run logs
  /agentmem                  — show/clear working memory
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import platform
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.db import (
    agent_run_start, agent_run_update, agent_run_last,
    memory_get, memory_set, memory_all,
    init_db,
)

logger = logging.getLogger("salim.agent2")

esc = lambda v: html.escape(str(v), quote=False)

MAX_STEPS       = 25
STEP_TIMEOUT    = 45
MAX_RETRIES     = 3     # self-healing retry limit per step
MEMORY_KEY      = "agent_scratchpad"

_active_agents: dict[int, asyncio.Task]  = {}
_agent_stops:   dict[int, asyncio.Event] = {}

# ═══════════════════════════════════════════════════════════════════════════════
#  WORKING MEMORY  (persistent scratchpad per user)
# ═══════════════════════════════════════════════════════════════════════════════

def scratchpad_get(user_id: int) -> dict:
    raw = memory_get(user_id, MEMORY_KEY, "{}")
    try:
        return json.loads(raw)
    except Exception:
        return {}


def scratchpad_set(user_id: int, data: dict):
    memory_set(user_id, MEMORY_KEY, json.dumps(data))


def scratchpad_update(user_id: int, key: str, value: Any):
    pad = scratchpad_get(user_id)
    pad[key] = value
    pad["_updated"] = datetime.now().isoformat()
    scratchpad_set(user_id, pad)


def scratchpad_clear(user_id: int):
    memory_set(user_id, MEMORY_KEY, "{}")


# ═══════════════════════════════════════════════════════════════════════════════
#  AGENT SYSTEM PROMPT
# ═══════════════════════════════════════════════════════════════════════════════

AGENT_SYSTEM = """You are Salim Agent — an autonomous AI that controls a real computer to complete complex goals.

You have a persistent SCRATCHPAD (working memory) that carries facts between tasks.
Read it at the start of each step. Update it when you discover important information.

AVAILABLE TOOLS:
shell          — run any shell command, get stdout+stderr
read_file      — read a file's contents (path)
write_file     — write content to a file (path, content)
append_file    — append content to file (path, content)
delete_file    — delete a file or directory (path)
find_files     — find files by pattern/name (pattern, directory, max_results)
list_dir       — list directory contents (path)
create_dir     — create directory recursively (path)
http_get       — HTTP GET request, returns body (url, headers={})
http_post      — HTTP POST request (url, data={}, headers={})
summarize_file — AI summarizes a file's content (path)
run_python     — run Python code snippet, get output (code)
run_js         — run JavaScript via Node.js (code)
get_sysinfo    — get CPU/RAM/disk/battery stats
get_processes  — list running processes (filter='')
notify         — desktop notification (title, message)
open_app       — open an application or URL (target)
copy_clipboard — copy text to clipboard (text)
scratchpad_write — save fact to working memory (key, value)
scratchpad_read  — read from working memory (key)

RESPONSE FORMAT — respond ONLY with valid JSON:

Next action:
{"thought":"what I understand and plan","action":"shell","parameters":{"command":"ls -la ~/Desktop"},"expecting":"list of files","update_scratchpad":{"key":"value"}}

When done:
{"thought":"goal achieved","action":"done","summary":"what was accomplished in detail","parameters":{}}

When stuck after retries:
{"thought":"why I cannot proceed","action":"stop","reason":"specific blocker","parameters":{}}

SELF-HEALING RULES:
- If a step fails, examine the error in "thought" and try a DIFFERENT approach
- Never repeat the exact same failed action — always modify the approach
- For missing commands, try alternatives (apt list → dpkg -l, etc.)
- For permission errors, use sudo if appropriate or find workaround
- Track what you've tried in scratchpad to avoid loops

CHAIN AWARENESS:
- You will sometimes receive a "chain_context" with previous tasks' outputs
- Use these outputs — they are real results from earlier steps
- Update scratchpad with cross-task facts

OS: {os}
"""


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL EXECUTOR
# ═══════════════════════════════════════════════════════════════════════════════

async def execute_tool(action: str, params: dict, user_id: int, ai=None) -> tuple[bool, str]:
    """Execute a tool. Returns (success, output). Never raises."""
    try:
        if action == "shell":
            cmd = params.get("command", "")
            if not cmd:
                return False, "No command specified"
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True,
                timeout=STEP_TIMEOUT, cwd=str(Path.home()),
                env={**os.environ, "TERM": "xterm"},
            )
            out = (result.stdout or "").strip()
            err = (result.stderr or "").strip()
            if result.returncode != 0:
                combined = f"[exit {result.returncode}]"
                if out: combined += f"\nstdout: {out[:1000]}"
                if err: combined += f"\nstderr: {err[:1000]}"
                return False, combined
            return True, (out or "(command completed, no output)")[:3000]

        elif action == "read_file":
            p = Path(params.get("path", "")).expanduser()
            if not p.exists():
                return False, f"File not found: {p}"
            if p.stat().st_size > 500_000:
                return True, p.read_text(errors="replace")[:5000] + "\n...[truncated]"
            return True, p.read_text(errors="replace")[:5000]

        elif action == "write_file":
            p = Path(params.get("path", "")).expanduser()
            p.parent.mkdir(parents=True, exist_ok=True)
            content = params.get("content", "")
            p.write_text(content, encoding="utf-8")
            return True, f"Written {len(content)} chars to {p}"

        elif action == "append_file":
            p = Path(params.get("path", "")).expanduser()
            p.parent.mkdir(parents=True, exist_ok=True)
            content = params.get("content", "")
            with open(p, "a", encoding="utf-8") as f:
                f.write(content)
            return True, f"Appended {len(content)} chars to {p}"

        elif action == "delete_file":
            import shutil
            p = Path(params.get("path", "")).expanduser()
            if not p.exists():
                return False, f"Not found: {p}"
            if p.is_dir():
                shutil.rmtree(str(p))
            else:
                p.unlink()
            return True, f"Deleted: {p}"

        elif action == "find_files":
            pattern = params.get("pattern", "*")
            directory = Path(params.get("directory", str(Path.home()))).expanduser()
            max_r = int(params.get("max_results", 30))
            results = []
            try:
                for p in directory.rglob(pattern):
                    results.append(str(p))
                    if len(results) >= max_r:
                        break
            except PermissionError:
                pass
            return (True, "\n".join(results)) if results else (True, "No files found")

        elif action == "list_dir":
            p = Path(params.get("path", str(Path.home()))).expanduser()
            try:
                items = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name))
                lines = []
                for item in items[:60]:
                    sz = item.stat().st_size if item.is_file() else 0
                    lines.append(f"{'📁' if item.is_dir() else '📄'} {item.name}" +
                                  (f"  [{sz:,}b]" if sz else ""))
                return True, "\n".join(lines) or "(empty)"
            except Exception as e:
                return False, str(e)

        elif action == "create_dir":
            p = Path(params.get("path", "")).expanduser()
            p.mkdir(parents=True, exist_ok=True)
            return True, f"Created: {p}"

        elif action == "http_get":
            import urllib.request, urllib.error
            url = params.get("url", "")
            try:
                req = urllib.request.Request(url, headers=params.get("headers", {}))
                req.add_header("User-Agent", "SalimAgent/2.0")
                with urllib.request.urlopen(req, timeout=15) as resp:
                    body = resp.read(50000).decode("utf-8", errors="replace")
                    return True, body[:5000]
            except Exception as e:
                return False, f"HTTP GET failed: {e}"

        elif action == "http_post":
            import urllib.request, urllib.parse
            url = params.get("url", "")
            data = json.dumps(params.get("data", {})).encode()
            try:
                req = urllib.request.Request(url, data=data,
                    headers={"Content-Type": "application/json", "User-Agent": "SalimAgent/2.0"})
                with urllib.request.urlopen(req, timeout=15) as resp:
                    return True, resp.read(10000).decode("utf-8", errors="replace")[:3000]
            except Exception as e:
                return False, f"HTTP POST failed: {e}"

        elif action == "summarize_file":
            p = Path(params.get("path", "")).expanduser()
            if not p.exists():
                return False, f"File not found: {p}"
            content = p.read_text(errors="replace")[:8000]
            if ai:
                try:
                    summary, _ = await ai._call_with_fallback(
                        [{"role": "user", "content": f"Summarize this file content in 3-5 sentences:\n\n{content}"}],
                        system="You summarize file contents concisely.",
                        max_tokens=300,
                    )
                    return True, summary
                except Exception:
                    pass
            return True, content[:500] + ("..." if len(content) > 500 else "")

        elif action == "run_python":
            code = params.get("code", "")
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
                f.write(code)
                fp = f.name
            try:
                proc = await asyncio.create_subprocess_exec(
                    sys.executable, fp,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                    cwd=str(Path.home()),
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=STEP_TIMEOUT)
                out = stdout.decode(errors="replace").strip()
                err = stderr.decode(errors="replace").strip()
                if proc.returncode != 0:
                    return False, f"[exit {proc.returncode}]\n{err[:2000]}"
                return True, (out or "(no output)")[:3000]
            except asyncio.TimeoutError:
                return False, f"Python execution timed out after {STEP_TIMEOUT}s"
            finally:
                try: os.unlink(fp)
                except: pass

        elif action == "run_js":
            import shutil as _sh
            if not _sh.which("node"):
                return False, "Node.js not installed"
            code = params.get("code", "")
            with tempfile.NamedTemporaryFile(mode="w", suffix=".js", delete=False) as f:
                f.write(code)
                fp = f.name
            try:
                proc = await asyncio.create_subprocess_exec(
                    "node", fp,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=STEP_TIMEOUT)
                out = stdout.decode(errors="replace").strip()
                err = stderr.decode(errors="replace").strip()
                if proc.returncode != 0:
                    return False, f"[exit {proc.returncode}]\n{err[:2000]}"
                return True, (out or "(no output)")[:3000]
            except asyncio.TimeoutError:
                return False, "JS execution timed out"
            finally:
                try: os.unlink(fp)
                except: pass

        elif action == "get_sysinfo":
            try:
                import psutil
                cpu = psutil.cpu_percent(interval=0.5)
                mem = psutil.virtual_memory()
                disk = psutil.disk_usage("/")
                battery = psutil.sensors_battery()
                bat = f"{battery.percent:.0f}% ({'⚡' if battery.power_plugged else '🔋'})" if battery else "N/A"
                return True, (
                    f"CPU: {cpu:.1f}%\n"
                    f"RAM: {mem.percent:.1f}% used ({mem.used//1024//1024:,}/{mem.total//1024//1024:,} MB)\n"
                    f"Disk: {disk.percent:.1f}% used ({disk.free//1024//1024//1024:.1f} GB free)\n"
                    f"Battery: {bat}"
                )
            except ImportError:
                result = subprocess.run("df -h / && free -h", shell=True, capture_output=True, text=True, timeout=5)
                return True, result.stdout[:500]

        elif action == "get_processes":
            try:
                import psutil
                filt = params.get("filter", "").lower()
                procs = []
                for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
                    try:
                        if filt and filt not in p.info["name"].lower():
                            continue
                        procs.append(f"{p.info['pid']:>6}  {p.info['cpu_percent']:>5.1f}%  "
                                      f"{p.info['memory_percent']:>4.1f}%  {p.info['name']}")
                    except Exception:
                        pass
                top = sorted(procs, key=lambda x: float(x.split()[1].rstrip("%")), reverse=True)[:20]
                return True, "PID     CPU%   MEM%  NAME\n" + "\n".join(top)
            except Exception as e:
                return False, str(e)

        elif action == "notify":
            title = params.get("title", "Salim Agent")
            msg = params.get("message", "")
            sys_name = platform.system()
            if sys_name == "Darwin":
                subprocess.run(["osascript", "-e", f'display notification "{msg}" with title "{title}"'],
                               capture_output=True)
            elif sys_name == "Linux":
                subprocess.run(["notify-send", title, msg], capture_output=True)
            return True, f"Notified: {title} — {msg}"

        elif action == "open_app":
            target = params.get("target", "")
            sys_name = platform.system()
            if sys_name == "Darwin":
                subprocess.Popen(["open", target])
            elif sys_name == "Linux":
                subprocess.Popen(["xdg-open", target])
            else:
                subprocess.Popen(["start", target], shell=True)
            return True, f"Opened: {target}"

        elif action == "copy_clipboard":
            text = params.get("text", "")
            try:
                import pyperclip
                pyperclip.copy(text)
            except Exception:
                subprocess.run(f"echo '{text}' | xclip -selection clipboard", shell=True)
            return True, f"Copied to clipboard: {text[:80]}"

        elif action == "scratchpad_write":
            key = params.get("key", "data")
            value = params.get("value", "")
            scratchpad_update(user_id, key, value)
            return True, f"Scratchpad updated: {key}={str(value)[:60]}"

        elif action == "scratchpad_read":
            key = params.get("key", "")
            pad = scratchpad_get(user_id)
            val = pad.get(key, "(not found)")
            return True, f"{key}: {val}"

        elif action in ("done", "stop"):
            return True, "(terminal action)"

        else:
            return False, f"Unknown tool: {action}"

    except subprocess.TimeoutExpired:
        return False, f"Tool '{action}' timed out after {STEP_TIMEOUT}s"
    except Exception as e:
        logger.error(f"Tool execution error [{action}]: {e}")
        return False, f"Unexpected error in {action}: {e}"


# ═══════════════════════════════════════════════════════════════════════════════
#  SELF-HEALING LOOP
# ═══════════════════════════════════════════════════════════════════════════════

async def _ai_diagnose_and_fix(ai, failed_action: str, params: dict,
                                error: str, context: str) -> tuple[str, dict]:
    """
    Ask AI to diagnose a failed step and suggest a corrected action.
    Returns (new_action, new_params).
    """
    prompt = (
        f"A tool call failed. Diagnose the error and suggest a corrected approach.\n\n"
        f"Failed action: {failed_action}\n"
        f"Parameters: {json.dumps(params)}\n"
        f"Error: {error}\n"
        f"Context: {context}\n\n"
        f"Return JSON: {{\"action\": \"<tool_name>\", \"parameters\": {{...}}, "
        f"\"thought\": \"why it failed and how this fixes it\"}}\n"
        f"Use the same tool with corrected params, or a different tool entirely.\n"
        f"ONLY return JSON, nothing else."
    )
    try:
        raw, _ = await ai._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system="You are a debugging AI. Analyze failures and propose fixes. Return only JSON.",
            max_tokens=400,
            temperature=0.2,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        data = json.loads(raw)
        return data.get("action", failed_action), data.get("parameters", params)
    except Exception:
        return failed_action, params


# ═══════════════════════════════════════════════════════════════════════════════
#  CORE AGENT LOOP
# ═══════════════════════════════════════════════════════════════════════════════

async def run_agent_loop(
    goal: str,
    user_id: int,
    ai,
    on_step,           # async (step_num, thought, action, params, result, success)
    stop_event: asyncio.Event,
    chain_context: str = "",
    run_id: Optional[int] = None,
) -> str:
    """
    Main agentic loop with self-healing and persistent memory.
    Returns final summary string.
    """
    steps: list[dict] = []
    consecutive_failures = 0
    os_name = platform.system()

    scratchpad = scratchpad_get(user_id)
    pad_summary = json.dumps(scratchpad, indent=2)[:800] if scratchpad else "{}"

    system = AGENT_SYSTEM.replace("{os}", os_name)

    for step_num in range(1, MAX_STEPS + 1):
        if stop_event.is_set():
            agent_run_update(run_id, steps, "stopped", "User stopped the agent")
            return "⏹ Stopped by user."

        # Build context for this step
        steps_ctx = ""
        if steps:
            steps_ctx = "\n\nCOMPLETED STEPS:\n"
            for s in steps[-8:]:   # last 8 steps for context
                status = "✅" if s["success"] else "❌"
                steps_ctx += (
                    f"\nStep {s['step']}: {s['action']}({json.dumps(s['params'])[:100]})\n"
                    f"  {status} {s['output'][:300]}\n"
                )

        prompt = (
            f"GOAL: {goal}\n"
            f"STEP: {step_num}/{MAX_STEPS}\n"
            f"WORKING MEMORY (scratchpad):\n{pad_summary}\n"
            + (f"CHAIN CONTEXT:\n{chain_context}\n" if chain_context else "")
            + steps_ctx
            + f"\nWhat is the next action? Respond with JSON only."
        )

        # AI decides next action
        retry_count = 0
        plan = None
        while retry_count < MAX_RETRIES:
            try:
                raw, provider = await ai._call_with_fallback(
                    [{"role": "user", "content": prompt}],
                    system=system,
                    max_tokens=600,
                    temperature=0.15,
                )
                raw = re.sub(r"```(?:json)?|```", "", raw).strip()
                # Extract JSON object robustly
                m = re.search(r"\{.*\}", raw, re.DOTALL)
                if m:
                    raw = m.group(0)
                plan = json.loads(raw)
                break
            except Exception as e:
                retry_count += 1
                logger.warning(f"AI planning failed (attempt {retry_count}): {e}")
                if retry_count >= MAX_RETRIES:
                    agent_run_update(run_id, steps, "failed", f"AI failed: {e}")
                    return f"⚠️ Agent stopped: AI planning failed after {MAX_RETRIES} retries."
                await asyncio.sleep(1.0)

        action  = plan.get("action", "stop")
        thought = plan.get("thought", "")
        params  = plan.get("parameters", {})
        expecting = plan.get("expecting", "")

        # Update scratchpad from AI suggestion
        if "update_scratchpad" in plan and isinstance(plan["update_scratchpad"], dict):
            for k, v in plan["update_scratchpad"].items():
                scratchpad_update(user_id, k, v)
            scratchpad = scratchpad_get(user_id)
            pad_summary = json.dumps(scratchpad, indent=2)[:800]

        # Terminal actions
        if action == "done":
            summary = plan.get("summary", "Task completed.")
            agent_run_update(run_id, steps, "completed", summary)
            await on_step(step_num, thought, "✅ done", {}, summary, True)
            return summary

        if action == "stop":
            reason = plan.get("reason", "Agent decided to stop.")
            agent_run_update(run_id, steps, "stopped", reason)
            await on_step(step_num, thought, "⏹ stop", {}, reason, False)
            return f"⏹ {reason}"

        # Notify UI that we're executing this step
        await on_step(step_num, thought, action, params, None, True)

        # Execute the tool
        success, output = await execute_tool(action, params, user_id, ai)

        # ── Self-healing: if failed, diagnose and retry ────────────────────
        heal_attempts = 0
        original_action = action
        while not success and heal_attempts < 2:
            heal_attempts += 1
            logger.info(f"Step {step_num} failed, self-healing attempt {heal_attempts}")
            context_for_heal = f"Goal: {goal}. Previous step results: {steps_ctx[-300:]}"
            new_action, new_params = await _ai_diagnose_and_fix(
                ai, action, params, output, context_for_heal
            )
            if new_action == action and new_params == params:
                # AI gave back the same thing — break to avoid infinite loop
                break
            await on_step(step_num, f"🔧 Self-healing: {thought}", new_action, new_params, None, True)
            action, params = new_action, new_params
            success, output = await execute_tool(action, params, user_id, ai)

        step_record = {
            "step": step_num,
            "action": action,
            "original_action": original_action,
            "params": params,
            "success": success,
            "output": output[:600],
            "thought": thought,
            "healed": action != original_action,
        }
        steps.append(step_record)
        agent_run_update(run_id, steps, "running")

        # Update consecutive failure counter
        if success:
            consecutive_failures = 0
        else:
            consecutive_failures += 1

        await on_step(step_num, thought, action, params,
                      output if success else f"❌ {output}", success)

        if consecutive_failures >= 4:
            msg = f"⚠️ Stopped: 4 consecutive failures. Last: {output[:200]}"
            agent_run_update(run_id, steps, "failed", msg)
            return msg

        await asyncio.sleep(0.3)

    msg = f"⚠️ Reached {MAX_STEPS} step limit. Task may be partially complete."
    agent_run_update(run_id, steps, "partial", msg)
    return msg


# ═══════════════════════════════════════════════════════════════════════════════
#  TASK CHAIN MANAGEMENT  (stored in SQLite via agent_task_chains table)
# ═══════════════════════════════════════════════════════════════════════════════

from salim.db import _get_conn, _tx as _db_tx

def chain_create(user_id: int, name: str, description: str) -> int:
    with _db_tx() as conn:
        cur = conn.execute(
            "INSERT INTO agent_task_chains(user_id,name,description,tasks_json) VALUES(?,?,?,'[]')",
            (user_id, name, description),
        )
        return cur.lastrowid


def chain_add_task(user_id: int, name: str, task: str) -> bool:
    conn = _get_conn()
    row = conn.execute(
        "SELECT id,tasks_json FROM agent_task_chains WHERE user_id=? AND name=?", (user_id, name)
    ).fetchone()
    if not row:
        return False
    tasks = json.loads(row["tasks_json"])
    tasks.append(task)
    with _db_tx() as c:
        c.execute(
            "UPDATE agent_task_chains SET tasks_json=? WHERE id=?",
            (json.dumps(tasks), row["id"]),
        )
    return True


def chain_get(user_id: int, name: str) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute(
        "SELECT * FROM agent_task_chains WHERE user_id=? AND name=? AND enabled=1",
        (user_id, name),
    ).fetchone()
    if not row:
        return None
    d = dict(row)
    d["tasks"] = json.loads(d.pop("tasks_json", "[]"))
    return d


def chain_list(user_id: int) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM agent_task_chains WHERE user_id=? AND enabled=1 ORDER BY created_at DESC",
        (user_id,),
    ).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        d["tasks"] = json.loads(d.pop("tasks_json", "[]"))
        result.append(d)
    return result


def chain_delete(user_id: int, name: str):
    with _db_tx() as conn:
        conn.execute(
            "UPDATE agent_task_chains SET enabled=0 WHERE user_id=? AND name=?",
            (user_id, name),
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  BOT HANDLER MIXIN
# ═══════════════════════════════════════════════════════════════════════════════

class AgentHandlers:
    """Mixin for SalimBot — autonomous agent v2 with chains and self-healing."""

    @require_auth
    async def cmd_agent(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /agent <goal>  — start autonomous multi-step task with self-healing
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        goal = " ".join(ctx.args or "")

        if not goal:
            await msg.reply_text(
                "🤖 <b>Autonomous Agent v2</b>\n\n"
                "I plan, execute, and self-heal my way to your goal.\n\n"
                "<b>Single task:</b>\n"
                "<code>/agent organize Desktop by file type</code>\n"
                "<code>/agent check system health and save report</code>\n"
                "<code>/agent find all logs older than 7 days and delete them</code>\n\n"
                "<b>Task chains:</b>\n"
                "<code>/chain new morning_check Daily health check</code>\n"
                "<code>/chain add morning_check check disk usage</code>\n"
                "<code>/chain add morning_check summarize recent error logs</code>\n"
                "<code>/chain run morning_check</code>\n\n"
                "<b>Working memory:</b>\n"
                "<code>/agentmem</code>  — view persistent scratchpad\n\n"
                "<i>Agent remembers context across tasks via persistent scratchpad.</i>",
                parse_mode="HTML",
            )
            return

        if not hasattr(self, "_ai") or not self._ai.is_configured():
            await msg.reply_text("⚠️ AI not configured. Run <code>salim setup</code>.", parse_mode="HTML")
            return

        # Cancel any running agent for this user
        if user_id in _active_agents and not _active_agents[user_id].done():
            _active_agents[user_id].cancel()
            await asyncio.sleep(0.1)

        stop_event = asyncio.Event()
        _agent_stops[user_id] = stop_event

        run_id = agent_run_start(user_id, goal)

        status_msg = await msg.reply_text(
            f"🤖 <b>Agent starting</b>\n🎯 <i>{esc(goal)}</i>\n\n<i>Planning first step…</i>",
            parse_mode="HTML",
        )

        step_log: list[dict] = []

        async def on_step(step_num, thought, action, params, result, success):
            step_log.append({
                "n": step_num, "thought": thought[:80],
                "action": action, "result": str(result)[:150] if result else None,
                "success": success,
            })
            lines = [
                f"🤖 <b>Agent Running</b>",
                f"🎯 <i>{esc(goal[:70])}</i>",
                "",
            ]
            for entry in step_log[-6:]:
                icon = "✅" if (entry["success"] and entry["result"]) else ("⏳" if entry["result"] is None else "❌")
                lines.append(f"{icon} <b>Step {entry['n']}:</b> <code>{esc(str(entry['action'])[:50])}</code>")
                if entry["thought"]:
                    lines.append(f"   💭 <i>{esc(entry['thought'][:80])}</i>")
                if entry["result"]:
                    lines.append(f"   📤 <code>{esc(str(entry['result'])[:120])}</code>")
            if result is None:
                lines.append(f"\n⏳ <i>Executing step {step_num}…</i>")
            try:
                await status_msg.edit_text("\n".join(lines), parse_mode="HTML")
            except Exception:
                pass

        async def run():
            try:
                summary = await run_agent_loop(
                    goal=goal, user_id=user_id, ai=self._ai,
                    on_step=on_step, stop_event=stop_event, run_id=run_id,
                )
                healed = sum(1 for s in step_log if s.get("action", "").startswith("🔧"))
                await status_msg.edit_text(
                    f"🤖 <b>Agent Complete</b>\n🎯 <i>{esc(goal[:70])}</i>\n\n"
                    f"📊 {len(step_log)} steps · {healed} self-healed\n\n"
                    f"📝 <b>Summary:</b>\n{esc(summary)}\n\n"
                    f"<i>/agentlog to see full details · /agentmem to see scratchpad</i>",
                    parse_mode="HTML",
                )
            except asyncio.CancelledError:
                await status_msg.edit_text(
                    f"⏹ <b>Stopped</b>\n🎯 <i>{esc(goal[:70])}</i>", parse_mode="HTML"
                )
            except Exception as e:
                logger.error(f"Agent task error: {e}")
                await status_msg.edit_text(
                    f"⚠️ <b>Agent error:</b> {esc(str(e))}", parse_mode="HTML"
                )
            finally:
                _active_agents.pop(user_id, None)

        task = asyncio.create_task(run())
        _active_agents[user_id] = task

    @require_auth
    async def cmd_chain(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /chain new <name> <desc>   — define named task chain
        /chain add <name> <task>   — add task to chain
        /chain run <name>          — execute chain
        /chain list                — list chains
        /chain del <name>          — delete chain
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "⛓ <b>Task Chains</b>\n\n"
                "<code>/chain new backup_daily Daily backup routine</code>\n"
                "<code>/chain add backup_daily compress ~/Documents</code>\n"
                "<code>/chain add backup_daily copy to /backup/</code>\n"
                "<code>/chain run backup_daily</code>\n"
                "<code>/chain list</code>\n"
                "<code>/chain del backup_daily</code>",
                parse_mode="HTML",
            )
            return

        sub = args[0].lower()

        if sub == "new":
            if len(args) < 3:
                await msg.reply_text("Usage: <code>/chain new &lt;name&gt; &lt;description&gt;</code>", parse_mode="HTML")
                return
            name = args[1]
            desc = " ".join(args[2:])
            try:
                chain_create(user_id, name, desc)
                await msg.reply_text(
                    f"✅ Chain <b>{esc(name)}</b> created.\n"
                    f"<code>/chain add {esc(name)} &lt;first task&gt;</code>",
                    parse_mode="HTML",
                )
            except Exception as e:
                await msg.reply_text(f"❌ Error: {esc(str(e))}", parse_mode="HTML")

        elif sub == "add":
            if len(args) < 3:
                await msg.reply_text("Usage: <code>/chain add &lt;name&gt; &lt;task description&gt;</code>", parse_mode="HTML")
                return
            name = args[1]
            task = " ".join(args[2:])
            ok = chain_add_task(user_id, name, task)
            if ok:
                chain = chain_get(user_id, name)
                n = len(chain["tasks"]) if chain else "?"
                await msg.reply_text(
                    f"✅ Task #{n} added to chain <b>{esc(name)}</b>:\n<i>{esc(task)}</i>",
                    parse_mode="HTML",
                )
            else:
                await msg.reply_text(f"❌ Chain '{esc(name)}' not found.", parse_mode="HTML")

        elif sub == "run":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/chain run &lt;name&gt;</code>", parse_mode="HTML")
                return
            name = args[1]
            chain = chain_get(user_id, name)
            if not chain:
                await msg.reply_text(f"❌ Chain '{esc(name)}' not found.", parse_mode="HTML")
                return
            if not chain["tasks"]:
                await msg.reply_text(f"❌ Chain '{esc(name)}' has no tasks.", parse_mode="HTML")
                return

            await self._run_chain(msg, user_id, chain)

        elif sub == "list":
            chains = chain_list(user_id)
            if not chains:
                await msg.reply_text("📋 No chains yet. Create one: <code>/chain new &lt;name&gt; &lt;desc&gt;</code>", parse_mode="HTML")
                return
            lines = ["⛓ <b>Your Task Chains</b>\n"]
            for c in chains:
                lines.append(f"<b>{esc(c['name'])}</b> — {esc(c.get('description',''))}")
                for i, t in enumerate(c["tasks"], 1):
                    lines.append(f"  {i}. {esc(t)}")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")

        elif sub == "del":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/chain del &lt;name&gt;</code>", parse_mode="HTML")
                return
            chain_delete(user_id, args[1])
            await msg.reply_text(f"🗑 Chain <b>{esc(args[1])}</b> deleted.", parse_mode="HTML")

        else:
            await msg.reply_text("Unknown sub-command. Use: new, add, run, list, del", parse_mode="HTML")

    async def _run_chain(self, msg, user_id: int, chain: dict):
        """Execute all tasks in a chain sequentially, passing context forward."""
        name = chain["name"]
        tasks = chain["tasks"]

        status_msg = await msg.reply_text(
            f"⛓ <b>Running chain: {esc(name)}</b>\n"
            f"📋 {len(tasks)} tasks\n\n<i>Starting task 1…</i>",
            parse_mode="HTML",
        )

        chain_ctx = ""
        all_summaries = []

        stop_event = asyncio.Event()
        _agent_stops[user_id] = stop_event

        for i, task in enumerate(tasks, 1):
            await status_msg.edit_text(
                f"⛓ <b>{esc(name)}</b> — Task {i}/{len(tasks)}\n"
                f"🎯 <i>{esc(task)}</i>\n\n<i>Working…</i>",
                parse_mode="HTML",
            )

            step_log = []

            async def on_step(step_num, thought, action, params, result, success):
                pass  # chain runs silently except for task summaries

            run_id = agent_run_start(user_id, task, chain_id=str(chain.get("id")))

            summary = await run_agent_loop(
                goal=task, user_id=user_id, ai=self._ai,
                on_step=on_step, stop_event=stop_event,
                chain_context=chain_ctx, run_id=run_id,
            )
            all_summaries.append(f"Task {i}: {summary[:200]}")
            chain_ctx = "\n".join(all_summaries[-3:])  # pass last 3 summaries as context

            if stop_event.is_set():
                break

        final = "\n".join([f"• {s}" for s in all_summaries])
        await status_msg.edit_text(
            f"✅ <b>Chain '{esc(name)}' complete</b>\n\n"
            f"<b>Results:</b>\n{esc(final)}",
            parse_mode="HTML",
        )

    @require_auth
    async def cmd_agentstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if user_id in _agent_stops:
            _agent_stops[user_id].set()
        if user_id in _active_agents and not _active_agents[user_id].done():
            _active_agents[user_id].cancel()
            await update.effective_message.reply_text("⏹ Agent stopped.")
        else:
            await update.effective_message.reply_text("ℹ️ No agent running.")

    @require_auth
    async def cmd_agentstatus(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if user_id in _active_agents and not _active_agents[user_id].done():
            await update.effective_message.reply_text(
                "🤖 <b>Agent is running.</b>\n<i>Use /agentstop to cancel.</i>", parse_mode="HTML"
            )
        else:
            await update.effective_message.reply_text("ℹ️ No agent running.")

    @require_auth
    async def cmd_agentlog(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        n = int((ctx.args or ["1"])[0]) if (ctx.args and ctx.args[0].isdigit()) else 1
        conn = _get_conn()
        rows = conn.execute(
            "SELECT * FROM agent_runs WHERE user_id=? ORDER BY started_at DESC LIMIT ?",
            (user_id, n),
        ).fetchall()
        if not rows:
            await update.effective_message.reply_text(
                "📋 No agent runs yet. Try: <code>/agent check disk usage</code>", parse_mode="HTML"
            )
            return
        for row in rows:
            steps = json.loads(row["steps_json"] or "[]")
            healed = sum(1 for s in steps if s.get("healed"))
            lines = [
                f"📋 <b>Run #{row['id']}</b>",
                f"🎯 <i>{esc(row['goal'])}</i>",
                f"⏰ {row['started_at'][:16]} · Status: {row['status']}",
                f"📊 {len(steps)} steps · {healed} self-healed",
            ]
            if row["summary"]:
                lines += ["", f"✅ {esc(row['summary'])}"]
            lines += ["", f"<b>Steps:</b>"]
            for s in steps[-10:]:
                icon = "✅" if s.get("success") else "❌"
                heal = " 🔧" if s.get("healed") else ""
                lines.append(f"{icon}{heal} <code>{esc(s.get('action','?'))}</code> → {esc(str(s.get('output',''))[:80])}")
            await update.effective_message.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_agentmem(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show or clear the persistent agent scratchpad."""
        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []

        if args and args[0].lower() == "clear":
            scratchpad_clear(user_id)
            await msg.reply_text("🧹 Agent scratchpad cleared.", parse_mode="HTML")
            return

        pad = scratchpad_get(user_id)
        if not pad:
            await msg.reply_text(
                "📋 <b>Agent Scratchpad</b>\n\n<i>Empty. Agent writes facts here during tasks.</i>\n\n"
                "<code>/agentmem clear</code> — wipe scratchpad",
                parse_mode="HTML",
            )
            return

        lines = ["📋 <b>Agent Scratchpad</b>\n"]
        for k, v in list(pad.items())[:20]:
            if k.startswith("_"):
                continue
            lines.append(f"<b>{esc(k)}:</b> {esc(str(v)[:200])}")
        lines.append(f"\n<i>Updated: {pad.get('_updated', 'unknown')}</i>")
        lines.append("<code>/agentmem clear</code> — wipe scratchpad")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")
