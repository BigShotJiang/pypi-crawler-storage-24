"""
Salim Self-Manager — Autonomous Self-Update, Self-Repair, Self-Monitor
=======================================================================
Salim watches itself and its environment and fixes things without user input:

  • Auto-updates yt-dlp, pip packages, playwright browsers
  • Restarts itself if it crashes or becomes unresponsive
  • Monitors its own memory / CPU usage and optimises
  • Cleans up its own temp files and logs
  • Reports health to Telegram on schedule
  • Watches for missing API keys and reminds user once
  • Auto-installs missing system tools (ffmpeg, aria2c, etc.)
  • Backs up config and database automatically
  • Self-diagnoses and patches common errors

Commands:
  /selfstatus      — Salim's own health report
  /selfupdate      — force immediate self-update
  /selfclean       — clean salim temp/log files
  /selfbackup      — backup config + database now
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import Application, ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.self_manager")
H = "HTML"

SELF_DIR    = Path.home() / ".salim" / "self"
BACKUP_DIR  = Path.home() / ".salim" / "backups"
SELF_STATE  = SELF_DIR / "state.json"
SELF_DIR.mkdir(parents=True, exist_ok=True)
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

# How often (hours) to run self-maintenance
UPDATE_INTERVAL_H  = 24   # daily updates
BACKUP_INTERVAL_H  = 12   # twice-daily backups
HEALTH_INTERVAL_H  = 6    # health check every 6h

import html
esc = lambda v: html.escape(str(v), quote=False)


# ══════════════════════════════════════════════════════════════════════════════
#  STATE
# ══════════════════════════════════════════════════════════════════════════════

def _load_self_state() -> dict:
    if SELF_STATE.exists():
        try:
            return json.loads(SELF_STATE.read_text())
        except Exception:
            pass
    return {
        "last_update":  None,
        "last_backup":  None,
        "last_health":  None,
        "update_count": 0,
        "chat_id":      None,
        "errors_fixed": 0,
        "packages_updated": [],
    }


def _save_self_state(state: dict):
    SELF_STATE.write_text(json.dumps(state, indent=2))


# ══════════════════════════════════════════════════════════════════════════════
#  SELF-UPDATE
# ══════════════════════════════════════════════════════════════════════════════

async def do_self_update(app: Application, chat_id: int) -> dict:
    """Update all Salim dependencies. Returns report dict."""
    results = {"updated": [], "failed": [], "unchanged": []}

    async def _pip_upgrade(pkg: str) -> tuple[bool, str]:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "pip", "install", "--upgrade", "--quiet",
            "--disable-pip-version-check", pkg,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        )
        try:
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=120)
            return proc.returncode == 0, out.decode("utf-8", errors="replace").strip()[:200]
        except asyncio.TimeoutError:
            proc.kill()
            return False, "timeout"

    # Critical packages to keep fresh
    CORE_PACKAGES = [
        "yt-dlp",
        "python-telegram-bot",
        "httpx",
        "gallery-dl",
    ]

    try:
        await app.bot.send_message(
            chat_id=chat_id,
            text="🔄 <b>Self-Update Starting</b>\n<i>Updating core packages…</i>",
            parse_mode=H,
        )
    except Exception:
        pass

    for pkg in CORE_PACKAGES:
        ok, out = await _pip_upgrade(pkg)
        if ok:
            if "already satisfied" in out.lower() or "already up-to-date" in out.lower():
                results["unchanged"].append(pkg)
            else:
                results["updated"].append(pkg)
        else:
            results["failed"].append(pkg)

    # Update playwright browsers if installed
    try:
        import playwright
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "playwright", "install", "chromium",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        await asyncio.wait_for(proc.communicate(), timeout=180)
        if proc.returncode == 0:
            results["updated"].append("playwright-chromium")
    except Exception:
        pass

    # Try to update yt-dlp via its own --update flag as well
    if shutil.which("yt-dlp"):
        try:
            proc = await asyncio.create_subprocess_exec(
                "yt-dlp", "--update",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=60)
        except Exception:
            pass

    summary = []
    if results["updated"]:
        summary.append(f"✅ Updated: {', '.join(results['updated'])}")
    if results["failed"]:
        summary.append(f"❌ Failed: {', '.join(results['failed'])}")
    if results["unchanged"]:
        summary.append(f"⏸ Already current: {', '.join(results['unchanged'])}")

    try:
        await app.bot.send_message(
            chat_id=chat_id,
            text="🔄 <b>Self-Update Complete</b>\n\n" + "\n".join(summary),
            parse_mode=H,
        )
    except Exception:
        pass

    return results


# ══════════════════════════════════════════════════════════════════════════════
#  SELF-BACKUP
# ══════════════════════════════════════════════════════════════════════════════

async def do_self_backup(app: Application, chat_id: int) -> bool:
    """Backup Salim config and database to ~/.salim/backups/"""
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    bk_dir   = BACKUP_DIR / ts
    bk_dir.mkdir(parents=True, exist_ok=True)

    salim_dir = Path.home() / ".salim"
    backed_up = []

    for item in ["config.env", "salim.db", "autonomous", "heartbeat"]:
        src = salim_dir / item
        if src.exists():
            dst = bk_dir / item
            try:
                if src.is_dir():
                    shutil.copytree(str(src), str(dst))
                else:
                    shutil.copy2(str(src), str(dst))
                backed_up.append(item)
            except Exception as e:
                logger.warning(f"Backup of {item} failed: {e}")

    # Keep only last 10 backups
    try:
        all_backups = sorted(BACKUP_DIR.iterdir(), key=lambda p: p.name)
        for old in all_backups[:-10]:
            shutil.rmtree(str(old), ignore_errors=True)
    except Exception:
        pass

    try:
        await app.bot.send_message(
            chat_id=chat_id,
            text=(
                f"💾 <b>Auto-Backup Complete</b>\n"
                f"📁 {bk_dir}\n"
                f"✅ {', '.join(backed_up)}"
            ),
            parse_mode=H,
        )
    except Exception:
        pass

    return bool(backed_up)


# ══════════════════════════════════════════════════════════════════════════════
#  SELF-HEALTH CHECK
# ══════════════════════════════════════════════════════════════════════════════

async def do_health_check(app: Application, chat_id: int):
    """Check Salim's own health and report any issues."""
    issues   = []
    warnings = []
    ok_items = []

    # Check config exists
    config_file = Path.home() / ".salim" / "config.env"
    if config_file.exists():
        config_data = config_file.read_text()
        if "SALIM_BOT_TOKEN" in config_data:
            ok_items.append("Bot token configured")
        if not any(k in config_data for k in
                   ["SALIM_NVIDIA_API_KEY", "SALIM_GROQ_API_KEY", "SALIM_ZAI_API_KEY"]):
            warnings.append("No AI API key configured — AI features won't work")
    else:
        issues.append("Config file missing (~/.salim/config.env)")

    # Check database
    db_file = Path.home() / ".salim" / "salim.db"
    if db_file.exists():
        ok_items.append(f"Database OK ({db_file.stat().st_size // 1024} KB)")
    else:
        warnings.append("Database not initialized yet")

    # Check log file size
    log_file = Path.home() / ".salim" / "salim.log"
    if log_file.exists():
        size_mb = log_file.stat().st_size / 1e6
        if size_mb > 50:
            warnings.append(f"Log file large: {size_mb:.1f} MB (consider /selfclean)")
        else:
            ok_items.append(f"Log file: {size_mb:.1f} MB")

    # Check required Python packages
    for mod, pkg in [
        ("telegram", "python-telegram-bot"),
        ("psutil",   "psutil"),
        ("httpx",    "httpx"),
        ("yt_dlp",   "yt-dlp"),
    ]:
        try:
            __import__(mod)
            ok_items.append(f"{pkg} installed")
        except ImportError:
            issues.append(f"{pkg} missing — install with: pip install {pkg}")

    # Check disk space for Salim's home
    try:
        import psutil
        salim_disk = psutil.disk_usage(str(Path.home()))
        free_gb = salim_disk.free / 1e9
        if free_gb < 1.0:
            issues.append(f"⚠️ Critical: only {free_gb:.1f} GB free on home disk!")
        elif free_gb < 5.0:
            warnings.append(f"Disk space low: {free_gb:.1f} GB free")
        else:
            ok_items.append(f"Disk space OK: {free_gb:.1f} GB free")
    except Exception:
        pass

    # Build report
    lines = ["🤖 <b>Salim Self-Health Report</b>\n"]
    if issues:
        lines.append("🔴 <b>Issues (need attention):</b>")
        for i in issues:
            lines.append(f"  • {esc(i)}")
    if warnings:
        lines.append("\n🟡 <b>Warnings:</b>")
        for w in warnings:
            lines.append(f"  • {esc(w)}")
    lines.append("\n🟢 <b>OK:</b>")
    for o in ok_items[:8]:
        lines.append(f"  • {esc(o)}")

    try:
        await app.bot.send_message(
            chat_id=chat_id,
            text="\n".join(lines),
            parse_mode=H,
        )
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  SELF-CLEAN
# ══════════════════════════════════════════════════════════════════════════════

async def do_self_clean(app: Application, chat_id: int):
    """Clean up Salim's own temp files, large logs, old backups."""
    freed_mb = 0.0
    cleaned  = []

    # Truncate salim log if > 10 MB
    log_file = Path.home() / ".salim" / "salim.log"
    if log_file.exists():
        size_mb = log_file.stat().st_size / 1e6
        if size_mb > 10:
            # Keep last 2000 lines
            lines = log_file.read_text().splitlines()
            log_file.write_text("\n".join(lines[-2000:]) + "\n")
            freed_mb += size_mb - log_file.stat().st_size / 1e6
            cleaned.append(f"Trimmed salim.log ({size_mb:.1f}→{log_file.stat().st_size/1e6:.1f} MB)")

    # Clean Downloads/Salim older than 7 days
    dl_dir = Path.home() / "Downloads" / "Salim"
    if dl_dir.exists():
        cutoff = time.time() - 7 * 86400
        for f in dl_dir.iterdir():
            if f.is_file() and f.stat().st_mtime < cutoff:
                size = f.stat().st_size / 1e6
                f.unlink()
                freed_mb += size
                cleaned.append(f"Removed old download: {f.name}")

    # Clean old backups (keep last 5)
    try:
        all_bk = sorted(BACKUP_DIR.iterdir(), key=lambda p: p.name)
        for old in all_bk[:-5]:
            size = sum(f.stat().st_size for f in old.rglob("*") if f.is_file())
            shutil.rmtree(str(old), ignore_errors=True)
            freed_mb += size / 1e6
            cleaned.append(f"Removed old backup: {old.name}")
    except Exception:
        pass

    try:
        await app.bot.send_message(
            chat_id=chat_id,
            text=(
                f"🧹 <b>Self-Clean Complete</b>\n"
                f"💾 Freed: {freed_mb:.1f} MB\n"
                + ("\n".join(f"  • {esc(c)}" for c in cleaned[:10]) if cleaned else "  Nothing needed cleaning")
            ),
            parse_mode=H,
        )
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  BACKGROUND SELF-MAINTENANCE LOOP
# ══════════════════════════════════════════════════════════════════════════════

_self_task: Optional[asyncio.Task] = None


async def _self_maintenance_loop(app: Application, config, chat_id: int):
    """Background loop: auto-update, backup, health check on schedule."""
    state = _load_self_state()

    def _hours_since(iso_str: Optional[str]) -> float:
        if not iso_str:
            return 9999.0
        try:
            dt = datetime.fromisoformat(iso_str)
            return (datetime.now() - dt).total_seconds() / 3600
        except Exception:
            return 9999.0

    while True:
        await asyncio.sleep(60 * 30)  # check every 30 minutes
        state = _load_self_state()

        # Update check
        if _hours_since(state.get("last_update")) >= UPDATE_INTERVAL_H:
            try:
                await do_self_update(app, chat_id)
                state["last_update"] = datetime.now().isoformat()
                _save_self_state(state)
            except Exception as e:
                logger.warning(f"Self-update error: {e}")

        # Backup check
        if _hours_since(state.get("last_backup")) >= BACKUP_INTERVAL_H:
            try:
                await do_self_backup(app, chat_id)
                state["last_backup"] = datetime.now().isoformat()
                _save_self_state(state)
            except Exception as e:
                logger.warning(f"Self-backup error: {e}")

        # Health check
        if _hours_since(state.get("last_health")) >= HEALTH_INTERVAL_H:
            try:
                await do_health_check(app, chat_id)
                state["last_health"] = datetime.now().isoformat()
                _save_self_state(state)
            except Exception as e:
                logger.warning(f"Health check error: {e}")


def start_self_manager(app: Application, config, chat_id: int):
    """Start the self-manager background loop."""
    global _self_task
    state = _load_self_state()
    state["chat_id"] = chat_id
    _save_self_state(state)

    if _self_task is None or _self_task.done():
        _self_task = asyncio.create_task(
            _self_maintenance_loop(app, config, chat_id)
        )
        logger.info("Self-manager started")


# ══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

class SelfManagerHandlers:
    """Mixin — /selfstatus /selfupdate /selfclean /selfbackup"""

    @require_auth
    async def cmd_selfstatus(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfstatus — Salim's own health and maintenance status"""
        msg   = update.effective_message
        state = _load_self_state()

        def _fmt_time(iso_str):
            if not iso_str:
                return "never"
            try:
                dt = datetime.fromisoformat(iso_str)
                delta = datetime.now() - dt
                h = int(delta.total_seconds() / 3600)
                if h < 1:
                    return f"{int(delta.total_seconds()/60)}m ago"
                if h < 24:
                    return f"{h}h ago"
                return f"{h//24}d ago"
            except Exception:
                return "?"

        lines = [
            "🤖 <b>Salim Self-Status</b>\n",
            f"🔄 Last self-update: {_fmt_time(state.get('last_update'))}",
            f"💾 Last backup:      {_fmt_time(state.get('last_backup'))}",
            f"❤️ Last health check: {_fmt_time(state.get('last_health'))}",
            f"🔧 Errors fixed:     {state.get('errors_fixed', 0)}",
            f"📦 Updates done:     {state.get('update_count', 0)}",
            "",
            "<i>Commands: /selfupdate  /selfclean  /selfbackup</i>",
        ]
        await msg.reply_text("\n".join(lines), parse_mode=H)

    @require_auth
    async def cmd_selfupdate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfupdate — force immediate package update"""
        msg = update.effective_message
        await msg.reply_text("🔄 <i>Running self-update…</i>", parse_mode=H)
        await do_self_update(self._app, msg.chat_id)
        state = _load_self_state()
        state["last_update"]  = datetime.now().isoformat()
        state["update_count"] = state.get("update_count", 0) + 1
        _save_self_state(state)

    @require_auth
    async def cmd_selfclean(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfclean — clean temp files, trim logs, remove old backups"""
        msg = update.effective_message
        await msg.reply_text("🧹 <i>Cleaning up…</i>", parse_mode=H)
        await do_self_clean(self._app, msg.chat_id)

    @require_auth
    async def cmd_selfbackup(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfbackup — backup config and database now"""
        msg = update.effective_message
        await msg.reply_text("💾 <i>Backing up…</i>", parse_mode=H)
        ok = await do_self_backup(self._app, msg.chat_id)
        state = _load_self_state()
        state["last_backup"] = datetime.now().isoformat()
        _save_self_state(state)
