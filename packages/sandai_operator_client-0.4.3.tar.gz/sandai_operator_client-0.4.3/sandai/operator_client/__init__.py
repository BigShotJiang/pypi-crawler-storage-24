"""Public package exports for the Sandai operator client."""

from . import client as _client_module
from . import exceptions as _exceptions_module
from .client import *
from .exceptions import *
from .config import (
    VALID_PRIORITIES,
    CeleryConfig,
    ClientConfig,
    env_bool,
    get_celery_config,
    get_default_celery_config,
    resolve_client_config,
)
from .types import (
    BatchTaskResult,
    ErrorInfoDict,
    HealthCheckResult,
    InputArtifactDict,
    OperatorDescription,
    OperatorTaskResult,
    SubmittedTask,
    TaskMetaDict,
    TaskPayloadDict,
)

__all__ = list(dict.fromkeys(
    list(getattr(_client_module, "__all__", []))
    + list(getattr(_exceptions_module, "__all__", []))
    + [
        "VALID_PRIORITIES",
        "CeleryConfig",
        "ClientConfig",
        "env_bool",
        "get_celery_config",
        "get_default_celery_config",
        "resolve_client_config",
        "BatchTaskResult",
        "ErrorInfoDict",
        "HealthCheckResult",
        "InputArtifactDict",
        "OperatorDescription",
        "OperatorTaskResult",
        "SubmittedTask",
        "TaskMetaDict",
        "TaskPayloadDict",
    ]
))
