"""
Data Interface Module

Handles data access, database operations, and data management.
"""

__version__ = "1.0.12"
__author__ = "GUIBRUSHR Team"
__description__ = "Data Interface Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import data interface components when accessed (prevents circular imports).
    """
    if name in {'DataInterface', 'DBSQLite3'}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'DataInterface',
    'DBSQLite3'
]