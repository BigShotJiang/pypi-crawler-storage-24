"""
Input Panels Module

Contains all input panel components for data entry and configuration.
"""

__version__ = "1.0.12"
__author__ = "GUIBRUSHR Team"
__description__ = "Input Panels Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import input panel components when accessed (prevents circular imports).
    """
    if name == 'InputPanel':
        module = importlib.import_module(".InputPanel", package=__name__)
        sys.modules[f"{__name__}.InputPanel"] = module
        return getattr(module, "InputPanel")
    elif name in {"Frame_Cross_Correlation", "TabPanels"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'InputPanel',
    'Frame_Cross_Correlation',
    'TabPanels'
]