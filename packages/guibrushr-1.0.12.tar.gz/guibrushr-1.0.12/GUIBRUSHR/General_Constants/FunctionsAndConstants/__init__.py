"""
Functions and Constants Module

Contains utility functions and constant definitions used throughout the application.
"""

__version__ = "1.0.12"
__author__ = "GUIBRUSHR Team"
__description__ = "Functions and Constants Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import submodules when accessed (prevents circular imports).
    """
    if name == "general_functions":
        module = importlib.import_module(".general_functions", package=__name__)
        sys.modules[f"{__name__}.general_functions"] = module
        return module
    elif name == "Constant_Variables":
        module = importlib.import_module(".Constant_Variables", package=__name__)
        sys.modules[f"{__name__}.Constant_Variables"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'general_functions',
    'Constant_Variables'
]