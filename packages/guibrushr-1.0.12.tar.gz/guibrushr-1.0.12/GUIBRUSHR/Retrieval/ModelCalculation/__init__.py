"""
Model Calculation Module

Contains model calculation and computation components.
"""

__version__ = "1.0.12"
__author__ = "GUIBRUSHR Team"
__description__ = "Model Calculation Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import model calculation submodules when accessed (prevents circular imports).
    """
    if name == "Classes":
        module = importlib.import_module(".Classes", package=__name__)
        sys.modules[f"{__name__}.Classes"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "Classes"
]
