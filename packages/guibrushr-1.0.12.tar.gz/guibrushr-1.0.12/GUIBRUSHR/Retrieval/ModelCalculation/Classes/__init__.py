"""
Model Calculation Classes Module

Contains class definitions for model calculation and computation.
"""

__version__ = "1.0.12"
__author__ = "GUIBRUSHR Team"
__description__ = "Model Calculation Classes Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import model calculation classes when accessed (prevents circular imports).
    """
    # Currently no components defined, but structure is ready for future additions
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = []