# Documentation

Use this page as an entry point based on what you are trying to do.

## For CLI Users

- Install and first commands:
  [Project README](../README.md)
- iOS 17+ developer service access:
  [iOS 17+ tunnels](guides/ios17-tunnels.md)
- Common day-to-day commands:
  [CLI recipes](guides/cli-recipes.md)

## For Python API Users

- High-level protocol walkthrough:
  [Understanding iDevice protocol layers](../misc/understanding_idevice_protocol_layers.md)
- DTX client usage:
  [DTX README](../pymobiledevice3/dtx/README.md)
- DTX protocol internals:
  [DTX DEVELOPMENT](../pymobiledevice3/dtx/DEVELOPMENT.md)
- Writing custom CLI commands using service providers:
  [Writing commands with service_provider](guides/writing-commands-with-service-provider.md)

## Protocol Deep Dives

- RemoteXPC internals:
  [RemoteXPC](../misc/RemoteXPC.md)
- iDevice stack overview:
  [Understanding iDevice protocol layers](../misc/understanding_idevice_protocol_layers.md)

## Project and Contribution

- Contribution workflow:
  [CONTRIBUTING](../CONTRIBUTING.md)
- Community standards:
  [CODE_OF_CONDUCT](../CODE_OF_CONDUCT.md)
- Agent workflow guidance:
  [AGENTS](../AGENTS.md)
