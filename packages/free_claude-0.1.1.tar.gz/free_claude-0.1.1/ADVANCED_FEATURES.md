# Advanced Features Guide 🚀

This guide covers all advanced features in free-claude:
1. **Extended Thinking** — deep reasoning with configurable token budget
2. **Auto-planning** — automatic task decomposition into steps
3. **Session & Memory** — save/resume conversations and persistent memory
4. **Advanced Search & Indexing** — fast full-text search using ripgrep
5. **Agent Teammates** — multi-agent coordination for complex tasks
6. **Interactive UI Components** — beautiful terminal interfaces

---

## 1. 🧠 Extended Thinking

Extended Thinking lets Claude reason deeply before answering. Ideal for complex architecture decisions, debugging hard problems, or multi-step analysis.

### Enable via CLI
```bash
fclaude --think                    # default budget: 8,000 tokens
fclaude --think-budget 16000       # custom budget
fclaude --think -q "design a distributed cache"
```

### Enable in-chat
```
/think                  Toggle on (default 8,000 tokens)
/think 16000            Enable with custom budget
/think off              Disable
```

### Python API
```python
from free_claude import Agent

agent = Agent(model="opus4", thinking_budget=12000)
response = agent.run("Design a fault-tolerant microservices architecture")
```

### What you'll see
When thinking is active, Claude's internal reasoning is shown in a 🧠 panel before the final answer:
```
╭─ 🧠 Thinking ─────────────────────────────────────────────╮
│ I need to consider the trade-offs between consistency and  │
│ availability. For a distributed cache, I should think      │
│ about eviction policies, replication strategies...         │
╰────────────────────────────────────────────────────────────╯

Here's my recommended architecture...
```

### Tips
- Use thinking for **hard problems** (architecture, debugging, algorithm design)
- Larger budget = deeper reasoning, but slower response
- Thinking is disabled automatically when using tools (Anthropic restriction)
- Use `/think off` to switch back to fast mode for simple questions

---

## 2. 🗺️ Auto-Planning

Auto-planning asks Claude to break a complex goal into ordered, actionable steps before execution.

### Commands
```
/autoplan <goal>        Claude creates a step-by-step plan
/plan show              View current plan and progress
/plan next              Execute next step
/plan done              Mark current step as complete
/plan new <goal>        Start a manual plan
/plan reset             Clear the current plan
```

### Example workflow
```
> /autoplan refactor the authentication module to use JWT

📋 Task Plan
 1. Audit current auth code — Read existing session/token handling
 2. Design JWT schema — Define payload fields and expiry
 3. Implement JWT generation — Use PyJWT library
 4. Implement JWT validation middleware — Verify signature + expiry
 5. Update login endpoint — Return JWT instead of session cookie
 6. Update protected routes — Replace session checks with JWT checks
 7. Write tests — Cover happy path, expiry, invalid tokens

Plan created with 7 steps. Use /plan next to start.

> /plan next
→ Executing step 1: Audit current auth code...

> /plan done
✅ Step 1 complete. Use /plan next for step 2.
```

### When to use
- Refactoring large modules
- Multi-file feature implementation
- Complex debugging sessions
- Systematic code reviews

---

## 3. 💾 Session & Memory

### Sessions — Save and Resume Conversations

```
/save [name]            Save current conversation to disk
/resume [id]            Resume a previously saved session
/sessions               List recent sessions (newest first)
/export [md|json]       Export conversation to a file
/checkpoint             Quick-save the current state
/restore                Restore from last checkpoint
```

**Example:**
```
# Save before closing
> /save auth-refactor

# Next day, continue where you left off
> /sessions
  1. auth-refactor  (2026-03-26 09:00, 42 messages)
  2. api-design     (2026-03-25 14:30, 18 messages)

> /resume auth-refactor
✅ Resumed session "auth-refactor" (42 messages)
```

**Export:**
```
> /export md    → session_2026-03-26.md
> /export json  → session_2026-03-26.json
```

### Memory — Persistent Facts Across Sessions

```
/memory set <key> <value>    Store a persistent fact
/memory get <key>            Recall a specific fact
/memory forget <key>         Delete a memory entry
/memory search <query>       Full-text search across memories
/memory list                 List all stored memories
```

**Example:**
```
> /memory set project "Django REST API with PostgreSQL"
> /memory set style "always use type hints and PEP 8"
> /memory set team "Alice (backend), Bob (frontend)"

# Next session — Claude automatically recalls these
```

**Tips:**
- Store project context, coding preferences, team info
- Memories persist in `~/.free_claude/memory.json`
- Use `/memory search` to find relevant memories quickly

---

---

## 4. 🔍 Advanced Search & Indexing

### Overview
Fast full-text search across large codebases using ripgrep with intelligent caching.

### Commands

#### `/index` - Index your project
```bash
/index              # Index project files (Python, JS, TS, Markdown, etc.)
/index --force      # Force re-indexing (ignore cache)
```

**What it does:**
- Scans all code files in the project
- Creates an SQLite index in `.free-claude/index/`
- Caches file hashes to skip unchanged files
- Extracts language metadata for each file

**Performance:**
- Initial indexing: depends on project size
- Incremental updates: ~100ms for changed files
- Search queries: <100ms typically

#### `/search` - Search your project
```bash
/search "function_name"                    # Search for text
/search "class.*Handler" --glob "*.py"     # Regex + file pattern
/find "TODO"                               # Alias for /search
```

**Output:**
```
Found 5 matches
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ File                          ┃ Line ┃ Match                      ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ src/agent.py                  │  42 │ def handle_search(query):  │
│ src/search.py                 │ 128 │ class ProjectIndexer:      │
│ tests/test_search.py          │  15 │ def test_search_basic():   │
└───────────────────────────────┴────┴────────────────────────────┘

Showing 5 results
```

### Use Cases

**Finding where a function is used:**
```bash
/search "def my_function"
/search "my_function(" --glob "*.py"
```

**Locating error messages:**
```bash
/search "Connection timeout"
/search "ERROR:" --glob "*.log"
```

**Finding TODOs and FIXMEs:**
```bash
/search "TODO|FIXME"
/search "HACK:" --glob "*.py"
```

**Searching across specific file types:**
```bash
/search "class.*Service" --glob "*.ts"
/search "import.*utils" --glob "*.py"
```

---

## 5. 👥 Agent Teammates

### Overview
Create a team of AI agents with specialized roles that can work together on complex tasks.

### Available Roles

| Role | Specialization | Tools | Best For |
|------|---|---|---|
| **code_reviewer** | Code quality, style, bugs | bash, find, grep | Reviewing PRs, finding issues |
| **test_writer** | Test coverage, edge cases | bash, create_file, find | Writing tests, QA |
| **docs_writer** | Documentation, clarity | create_file, read_file | Writing docs, examples |
| **debugger** | Root cause analysis | bash, read_file, grep | Finding & fixing bugs |
| **refactorer** | Code improvement | bash, read_file, find | Improving code structure |
| **architect** | System design | read_file, bash | High-level decisions |
| **security_auditor** | Security vulnerabilities | read_file, grep, bash | Security reviews |

### Commands

#### `/teammate` - Manage your team
```bash
/teammate                          # Show team status
/teammate add code_reviewer        # Add a teammate with a role
/teammate list                     # List all teammates
/teammate delegate <role> <task>   # Assign task to a role
```

#### `/tasks` - View task queue
```bash
/tasks                            # Show all pending tasks
```

### Workflow Example

**1. Create a team:**
```bash
/teammate add code_reviewer
/teammate add test_writer
/teammate add debugger

# View team
/teammate
```

Output:
```
╭─ Team Status ────────────────────────────────────────────────────────╮
│ Name              Role                 Status      Tasks              │
├──────────────────────────────��────────────────────────────────────────┤
│ code_reviewer_1   code_reviewer        idle        0                  │
│ test_writer_1     test_writer          idle        0                  │
│ debugger_1        debugger             idle        0                  │
╰───────────────────────────────────────────────────────────────────────╯
```

**2. Delegate work:**
```bash
/teammate delegate code_reviewer Review the authentication module for bugs
/teammate delegate test_writer Write unit tests for the payment processor
/teammate delegate debugger Debug the memory leak in the data loader
```

**3. Monitor progress:**
```bash
/tasks
```

Output:
```
╭─ Task Monitor ──────────────────────────────────────────────────────╮
│ Task                  Assigned To   Status       Priority            │
├─────────────────────────────────────────────────────────────────────┤
│ Review the authentic  code_reviewer assigned     ★★★                │
│ Write unit tests for  test_writer   in_progress  ★★                 │
│ Debug the memory      debugger      pending      ★★★★★              │
╰─────────────────────────────────────────────────────────────────────╯
```

### System Prompts

Each teammate has a specialized system prompt optimized for their role:

- **Code Reviewer**: Focuses on correctness, style, performance, best practices
- **Test Writer**: Emphasizes coverage, edge cases, maintainability
- **Docs Writer**: Prioritizes clarity, examples, accessibility
- **Debugger**: Systematic analysis, root causes, prevention
- **Refactorer**: Safe improvements, readability, technical debt
- **Architect**: Long-term thinking, scalability, design patterns
- **Security Auditor**: Thorough, cautious, compliance-focused

### Inter-Agent Communication

Teammates can communicate via message bus:
- Each task creates a conversation context for the assigned teammate
- Teammates receive notifications of task assignments
- Results are captured and stored for later reference

### Advanced: Custom Workflows

Coming soon! Planned features:
- Task dependencies (task B waits for task A)
- Feedback loops (code reviewer → developer → test writer)
- Parallel task execution
- Agent-to-agent collaboration messages

---

## 6. 🎨 Interactive UI Components

### Overview
Rich, interactive terminal components for viewing search results, team status, and code.

### Components

#### File Selector
```python
from src.free_claude.ui_components import show_file_selector

files = ["file1.py", "file2.py", "file3.js"]
selected = show_file_selector(console, files)
```

#### Search Results Display
```python
from src.free_claude.ui_components import show_search_results

results = [
    {"file_path": "app.py", "line_num": 42, "matched_text": "def handler():"},
]
show_search_results(console, results)
```

#### Team Status Display
```python
from src.free_claude.ui_components import show_team_status

team_status = agent._team.get_team_status()
show_team_status(console, team_status)
```

#### Task Monitor
```python
from src.free_claude.ui_components import show_task_monitor

tasks = [{"title": "Review code", "status": "in_progress", "priority": 3}]
show_task_monitor(console, tasks)
```

#### Code Viewer
```python
from src.free_claude.ui_components import show_code

code = """
def hello():
    print("Hello, World!")
"""
show_code(console, code, language="python", title="Example")
```

### Features

✅ **Beautiful tables** with rounded borders and colored columns
✅ **Real-time updates** with progress bars
✅ **Syntax highlighting** for code
✅ **Responsive layout** - adapts to terminal size
✅ **Interactive elements** - search, select, filter
✅ **Accessibility** - clear labels and descriptions

---

## Complete Workflow Example

Imagine you want to refactor a large Python project:

```bash
# 1. Index the project for fast search
/index

# 2. Create your team
/teammate add code_reviewer
/teammate add test_writer
/teammate add refactorer
/teammate add security_auditor

# 3. Search for all functions that need refactoring
/search "def.*\(.*,.*,.*,.*\):"  # Functions with 4+ parameters

# 4. Delegate refactoring work
/teammate delegate refactorer Simplify the authentication module
/teammate delegate code_reviewer Review the refactored auth module
/teammate delegate test_writer Write comprehensive tests for auth
/teammate delegate security_auditor Audit the new auth implementation

# 5. Monitor progress
/tasks

# 6. Review specific files
/search "class AuthHandler" --glob "*.py"

# 7. Export results when done
# (Feature coming soon)
```

---

## Architecture

### Search System
```
ProjectIndexer
├── ripgrep (fast search binary)
├── SQLite (index cache)
├── File watcher (for updates)
└── Context extractor (surrounding lines)
```

### Team System
```
AgentTeam
├── Leader (main orchestrator)
├── Teammates (specialized agents)
├── MessageBus (inter-agent communication)
├── TaskCoordinator (task distribution)
└── TaskQueue (pending work)
```

### UI System
```
InteractiveComponent (base class)
├── FileSelector
├── BranchSelector
├── SearchResults
├── TaskMonitor
├── TeammateStatus
├── CodeViewer
└── ProgressMonitor
```

---

## Performance Tips

### Search
- Use `/index` before intensive searching
- Use `--glob` to limit file patterns
- Regex patterns are faster than keywords for complex matches

### Teammates
- Add teammates only for roles you need
- Delegate larger tasks for better context usage
- Monitor `/tasks` to avoid bottlenecks

### UI
- Components automatically limit display to 50-100 items
- Use Rich's built-in truncation for large outputs
- Progress bars update efficiently

---

## Troubleshooting

### "ripgrep not found"
```bash
# Install ripgrep
brew install ripgrep      # macOS
apt install ripgrep       # Ubuntu/Debian
choco install ripgrep     # Windows
```

### Search returns no results
- Try `/index --force` to refresh the index
- Check query syntax matches ripgrep format
- Verify files are not gitignored

### Teammate not working
- Ensure teammate was added with `/teammate add <role>`
- Check `/tasks` to see if task was assigned
- Try `/teammate list` to verify team exists

---

## Future Enhancements

🔄 **Coming Soon:**
- Web-based dashboard for team monitoring
- Export results to files (JSON, CSV, Markdown)
- Custom team workflows and pipelines
- Integration with Git for PR analysis
- Caching of teammate conversations
- Multi-language search support
- Custom teammate roles

---

## Examples

### Example 1: Bug Triage
```bash
/index
/search "ERROR:|Exception" --glob "*.log"
/teammate add debugger
/teammate delegate debugger Investigate the 5 most recent errors
```

### Example 2: Code Review
```bash
/search "TODO|FIXME|HACK"
/teammate add code_reviewer
/teammate delegate code_reviewer Review marked technical debt
/teammate add refactorer
/teammate delegate refactorer Suggest improvements for flagged items
```

### Example 3: Testing
```bash
/search "def test_" --glob "*/test_*.py"
/teammate add test_writer
/teammate delegate test_writer Improve test coverage to 90%
```

---

## Tips & Tricks

💡 **Regex Search**
```bash
/search "def\s+\w+\s*\([^)]*\):"  # Find all function definitions
/search "class\s+\w+" --glob "*.py"  # Find all classes
```

💡 **Fast Navigation**
After searching, share results with teammates:
```
/search "payment_processor"
/teammate delegate debugger Review all uses of payment_processor
```

💡 **Team Coordination**
Build a review pipeline:
```bash
/teammate add debugger
/teammate add test_writer
/teammate add code_reviewer
/tasks  # Monitor all three working in parallel
```

---

**Happy building! 🎉**
