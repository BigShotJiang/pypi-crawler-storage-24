"""Core agent loop for free-claude — streaming, tools, MCP, and rich UI."""
import contextlib
import io
import json
import os
import sys
import threading
from typing import Optional
import urllib.error
import urllib.request

from .auth import get_token, refresh_token
from .config import API_BASE, DEFAULT_SYSTEM_PROMPT, MODELS
from .app_config import config as app_config
from .logger import log
from .mcp import StdioMCPClient, create_mcp_client, discover_hfi_plugins
from .tools import BUILTIN_TOOLS, execute_tool
from . import rich_ui as ui
from .search import ProjectIndexer
from .teammates import AgentTeam, TeammateRole
from .ui_components import show_search_results, show_team_status, show_task_monitor
from .core import ContextManager, StreamingClient, ToolExecutor
from .core.streaming import DEFAULT_THINKING_BUDGET
from .intelligence import TaskPlanner, MemoryStore, ContextSummarizer
from .session import SessionHistory, CheckpointManager, SessionExporter


class Agent:
    """Free Claude agent with tool use, MCP support, and rich UI."""

    def __init__(self, model: str = "default", system: str = None,
                 mcp_servers: dict = None, mcp_clients: list = None,
                 auto_plugins: bool = True,
                 thinking_budget: int = 0):
        app_config.load()
        self.token = refresh_token() or get_token()
        # CLI model arg overrides config file
        resolved_model = model if model != "default" else app_config.model
        self.model = MODELS.get(resolved_model, MODELS["default"])
        self.system = system or app_config.system_prompt or DEFAULT_SYSTEM_PROMPT
        log.info("Agent init: model=%s", self.model)
        self.mcp_clients: list = []
        self.tools: list = list(BUILTIN_TOOLS)
        self.thinking_budget: int = thinking_budget  # 0 = disabled

        # Core subsystems
        self._ctx = ContextManager()
        self._rate_limits: dict = {}

        # Phase 2 — Intelligence & Session
        self._memory = MemoryStore()
        self._planner = TaskPlanner()
        self._summarizer = ContextSummarizer()
        self._history = SessionHistory()
        self._checkpoint = CheckpointManager()
        self._exporter = SessionExporter()
        self._current_session_id: Optional[str] = None

        # Auto-load claude-hfi plugins silently
        if auto_plugins:
            self._auto_load_plugins()

        # Pre-created MCP clients (e.g. from --plugin CLI flag)
        if mcp_clients:
            for client in mcp_clients:
                if client.start():
                    self.mcp_clients.append(client)
                    self.tools.extend(client.get_tool_definitions())

        # stdio MCP servers from {name: [cmd, args...]} dict
        if mcp_servers:
            for name, cmd in mcp_servers.items():
                client = StdioMCPClient(name, cmd)
                if client.start():
                    self.mcp_clients.append(client)
                    self.tools.extend(client.get_tool_definitions())

    # ── Compatibility shims for old code that reads self.messages ──────

    @property
    def messages(self) -> list:
        return self._ctx.messages

    @messages.setter
    def messages(self, val: list):
        self._ctx.messages = val

    # ── Plugin loading ─────────────────────────────────────────────────

    def _auto_load_plugins(self):
        """Auto-discover and load claude-hfi plugins silently."""
        import shutil
        plugins = discover_hfi_plugins()
        if not plugins:
            return

        loaded = []
        for name, config in plugins.items():
            transport = config.get("type", "stdio")
            headers = config.get("headers", {})
            if any("${" in v for v in headers.values()):
                continue
            if transport == "stdio" and not shutil.which(config.get("command", "")):
                continue
            try:
                client = create_mcp_client(name, config)
                success = [False]

                def try_start(c=client, s=success):
                    buf = io.StringIO()
                    try:
                        with contextlib.redirect_stdout(buf):
                            s[0] = c.start(verbose=False)
                    except Exception:
                        s[0] = False

                t = threading.Thread(target=try_start, daemon=True)
                t.start()
                t.join(timeout=8)

                if success[0]:
                    self.mcp_clients.append(client)
                    new_tools = client.get_tool_definitions()
                    self.tools.extend(new_tools)
                    loaded.append(f"{name}({len(new_tools)})")
            except Exception:
                pass

        if loaded:
            ui.print_mcp_loaded(loaded)

    # ── Internal helpers ───────────────────────────────────────────────

    def _streamer(self) -> StreamingClient:
        """Return a fresh StreamingClient with current token/model/tools."""
        return StreamingClient(API_BASE, self.token, self.model,
                               self.system, self.tools,
                               thinking_budget=self.thinking_budget)

    def _maybe_summarize(self):
        """Auto-compress context if it's getting too large."""
        if self._summarizer.should_summarize(self._ctx.messages):
            from . import rich_ui as _ui
            _ui.print_info("📝 Context large — summarizing older messages...")
            self._ctx.messages = self._summarizer.maybe_compress(
                self._ctx.messages, API_BASE, self.token
            )

    def _executor(self) -> ToolExecutor:
        """Return a ToolExecutor bound to current mcp_clients."""
        return ToolExecutor(self.mcp_clients, execute_tool)

    # ── Public API ─────────────────────────────────────────────────────

    def run(self, user_input: str, max_iters: int = None, stream: bool = False) -> str:
        """Run the agent loop for a single user turn."""
        if max_iters is None:
            max_iters = app_config.max_tool_iterations
        self._ctx.add_user(user_input)
        header_printed = False
        streamer = self._streamer()
        executor = self._executor()

        # Auto-compress context if too large before each turn
        self._maybe_summarize()

        for i in range(max_iters):
            try:
                if stream:
                    if not header_printed:
                        ui.print_assistant_header()
                        header_printed = True
                    response, rl = streamer.stream(self._ctx.get(), ui.console)
                else:
                    response, rl = streamer.call(self._ctx.get())
            except urllib.error.HTTPError as e:
                if e.code == 401:
                    self.token = refresh_token() or get_token()
                    streamer = self._streamer()
                    response, rl = streamer.call(self._ctx.get())
                else:
                    err = e.read().decode()
                    self._ctx.pop_last()
                    return f"❌ API Error {e.code}: {err[:200]}"
            except KeyboardInterrupt:
                self._ctx.pop_last()
                raise

            self._rate_limits = rl
            self._ctx.track_usage(response.get("usage", {}))

            stop_reason = response.get("stop_reason")
            content = response.get("content", [])
            self._ctx.add_assistant(content)

            # Render text for non-streaming responses
            if stream and response.get("full_text"):
                ui.render_markdown(response["full_text"])

            # Show thinking blocks if extended thinking enabled
            thinking_blocks = response.get("thinking_blocks", [])
            if thinking_blocks and self.thinking_budget > 0:
                ui.print_thinking_blocks(thinking_blocks)

            if stop_reason == "end_turn":
                return " ".join(
                    b.get("text", "") for b in content if b.get("type") == "text"
                ).strip()

            elif stop_reason == "tool_use":
                if i > 0:
                    ui.print_step(i + 1, max_iters)

                tool_results = []
                for block in content:
                    if block.get("type") != "tool_use":
                        continue
                    tool_out = executor.run(block)
                    ui.print_tool_call(tool_out["name"], tool_out["detail"])
                    if tool_out["dropped"]:
                        ui.print_warning(f"Tool result truncated ({tool_out['dropped']:,} chars dropped)")
                    ui.print_tool_result(tool_out["result"])
                    tool_results.append(tool_out["payload"])

                self._ctx.add_user(tool_results)
                if stream:
                    ui.console.print()
                continue

            else:
                text = " ".join(
                    b.get("text", "") for b in content if b.get("type") == "text"
                ).strip()
                return text or f"(stop: {stop_reason})"

        # Max iterations — force a final text-only summary
        return self._force_summary(streamer, stream)

    def _force_summary(self, streamer: StreamingClient, stream: bool) -> str:
        """Called when max_iters is hit — get a final answer without tools."""
        ui.print_summarizing()
        summary_msgs = self._ctx.get() + [{
            "role": "user",
            "content": (
                "You have used all available steps. "
                "Now write your complete final answer. "
                "Do NOT call any more tools - text only."
            ),
        }]
        try:
            if stream:
                ui.print_assistant_header()
                response, _ = streamer.stream(summary_msgs, ui.console,
                                              include_tools=False)
                if response.get("full_text"):
                    ui.render_markdown(response["full_text"])
                return response.get("full_text", "")
            else:
                response, _ = streamer.call(summary_msgs)
                return " ".join(
                    b.get("text", "") for b in response.get("content", [])
                    if b.get("type") == "text"
                ).strip()
        except Exception:
            return "❌ Max iterations reached"

    # ── Interactive chat ───────────────────────────────────────────────

    def chat(self):
        n_builtin = sum(1 for t in self.tools if not t["name"].startswith("mcp_"))
        n_mcp = len(self.tools) - n_builtin
        plugin_names = [c.name for c in self.mcp_clients] or None
        ui.print_banner(self.model, n_builtin, n_mcp, plugin_names=plugin_names)

        while True:
            try:
                cwd = os.path.basename(os.getcwd())
                user_input = ui.print_user_prompt(cwd)
            except (KeyboardInterrupt, EOFError):
                ui.print_goodbye()
                self.cleanup()
                break

            if not user_input.strip():
                continue

            # "!" → run as shell command directly
            if user_input.strip().startswith("!"):
                shell_cmd = user_input.strip()[1:].strip()
                if shell_cmd:
                    try:
                        result = os.popen(shell_cmd).read()
                        if result:
                            ui.console.print(result, end="")
                    except Exception as e:
                        ui.print_error(str(e))
                continue

            if user_input.strip().startswith("/"):
                self._handle_cmd(user_input.strip())
                continue

            try:
                self.run(user_input, stream=True)
            except KeyboardInterrupt:
                ui.print_interrupted()
                self._ctx.pop_last()

    # ── Command handler ────────────────────────────────────────────────

    def _handle_cmd(self, cmd_line: str):
        parts = cmd_line.split()
        cmd = parts[0].lower()

        if cmd in ("/quit", "/exit"):
            ui.print_goodbye()
            self.cleanup()
            sys.exit(0)

        elif cmd in ("/clear", "/c"):
            self._ctx.clear()
            ui.print_success("Conversation cleared")

        elif cmd in ("/usage", "/u"):
            self._show_usage()

        elif cmd in ("/model", "/m"):
            if len(parts) > 1:
                key = parts[1]
                if key in MODELS:
                    self.model = MODELS[key]
                    ui.print_success(f"Model: {self.model}")
                else:
                    ui.console.print(f"Available: {', '.join(MODELS.keys())}")
            else:
                ui.print_models_table(MODELS, self.model)

        elif cmd in ("/tools", "/t"):
            ui.print_tools_table(self.tools)

        elif cmd == "/plugins":
            ui.print_plugins_table(discover_hfi_plugins())

        elif cmd == "/plugin":
            self._load_plugin(parts)

        elif cmd == "/mcp":
            self._add_mcp(parts)

        elif cmd in ("/search", "/find"):
            self._cmd_search(cmd_line, parts)

        elif cmd == "/index":
            self._cmd_index(cmd_line)

        elif cmd == "/teammate":
            self._cmd_teammate(cmd_line, parts)

        elif cmd == "/tasks":
            self._cmd_tasks()

        elif cmd == "/cd":
            if len(parts) > 1:
                try:
                    os.chdir(os.path.expanduser(parts[1]))
                    ui.print_success(f"Directory: {os.getcwd()}")
                except Exception as e:
                    ui.print_error(str(e))

        elif cmd == "/system":
            self.system = cmd_line[8:].strip() or DEFAULT_SYSTEM_PROMPT
            ui.print_success("System prompt updated")

        elif cmd == "/config":
            self._show_config()

        elif cmd in ("/save", "/s"):
            self._cmd_save(parts)

        elif cmd in ("/resume", "/r"):
            self._cmd_resume(parts)

        elif cmd == "/sessions":
            self._cmd_sessions()

        elif cmd in ("/memory", "/mem"):
            self._cmd_memory(cmd_line, parts)

        elif cmd == "/plan":
            self._cmd_plan(cmd_line, parts)

        elif cmd in ("/think", "/thinking"):
            self._cmd_think(parts)

        elif cmd in ("/autoplan", "/ap"):
            self._cmd_autoplan(cmd_line)

        elif cmd in ("/help", "/?"):
            self._show_help()

        else:
            ui.print_warning(f"Unknown command '{cmd}'. Type /help.")

    # ── Command implementations ────────────────────────────────────────

    def _show_usage(self):
        from rich.table import Table
        from rich import box
        summary = self._ctx.usage_summary()
        rl = self._rate_limits

        table = Table(box=box.ROUNDED, show_header=True,
                      header_style="bold cyan", border_style="dim cyan",
                      padding=(0, 2), show_edge=True)
        table.add_column("Metric", style="yellow", min_width=26, no_wrap=True)
        table.add_column("Value", style="white", justify="right")

        table.add_row("[bold]Session[/bold]", "")
        table.add_row("  Requests",      str(summary["requests"]))
        table.add_row("  Input tokens",  f"{summary['input_tokens']:,}")
        table.add_row("  Output tokens", f"{summary['output_tokens']:,}")
        table.add_row("  Total tokens",  f"[bold]{summary['total_tokens']:,}[/bold]")

        if rl:
            table.add_row("", "")
            table.add_row("[bold]Rate Limits[/bold]", "")
            table.add_row("  Input tokens  (remaining/limit)",
                          f"{rl.get('anthropic-ratelimit-input-tokens-remaining','?')} / "
                          f"{rl.get('anthropic-ratelimit-input-tokens-limit','?')}")
            table.add_row("  Output tokens (remaining/limit)",
                          f"{rl.get('anthropic-ratelimit-output-tokens-remaining','?')} / "
                          f"{rl.get('anthropic-ratelimit-output-tokens-limit','?')}")
            table.add_row("  Requests      (remaining/limit)",
                          f"{rl.get('anthropic-ratelimit-requests-remaining','?')} / "
                          f"{rl.get('anthropic-ratelimit-requests-limit','?')}")
            table.add_row("  Resets at", rl.get("anthropic-ratelimit-tokens-reset", "?"))
        else:
            table.add_row("", "")
            table.add_row("[dim]Rate limits[/dim]", "[dim](make a request first)[/dim]")

        table.add_row("", "")
        table.add_row("Cost", "[bold green]$0.00 — FREE! 🎉[/bold green]")
        ui.console.print()
        ui.console.print(table)
        ui.console.print()

    def _show_config(self):
        from rich.table import Table
        from rich import box
        from .app_config import _CONFIG_FILE
        table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
                      border_style="dim cyan", padding=(0, 2), show_edge=True)
        table.add_column("Key", style="yellow", min_width=22, no_wrap=True)
        table.add_column("Value", style="white")
        table.add_column("Source", style="dim", justify="center")

        file_exists = _CONFIG_FILE.exists()
        source = str(_CONFIG_FILE) if file_exists else "[dim]defaults[/dim]"

        for k, v in app_config._data.items():
            table.add_row(k, str(v), "file" if file_exists else "default")

        ui.console.print()
        ui.console.print(f"[dim]Config file: {_CONFIG_FILE}[/dim]")
        ui.console.print(table)
        ui.console.print(f"[dim]Edit {_CONFIG_FILE} and restart to apply changes.[/dim]")
        ui.console.print()

    def _show_help(self):
        from rich.table import Table
        from rich import box
        table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
                      border_style="dim cyan", padding=(0, 2), show_edge=True)
        table.add_column("Command", style="yellow", min_width=22, no_wrap=True)
        table.add_column("Description", style="white")
        cmds = [
            ("/model [key]",      "Switch model  (opus, sonnet, haiku, opus4, sonnet4)"),
            ("/clear",            "Clear conversation history"),
            ("/usage",            "Show token usage and rate limits"),
            ("/tools",            "List all available tools"),
            ("/plugins",          "List claude-hfi marketplace plugins"),
            ("/plugin <name>",    "Enable a claude-hfi plugin"),
            ("/mcp <name> <cmd>", "Add custom MCP server via stdio"),
            ("/search <query>",   "🔍 Search project with ripgrep"),
            ("/index",            "📑 Index project for fast search"),
            ("/teammate",         "👥 Manage agent teammates & swarms"),
            ("/tasks",            "📋 Show pending team tasks"),
            ("/cd <path>",        "Change working directory"),
            ("/system [text]",    "Update system prompt"),
            ("/config",           "⚙️  Show current configuration"),
            ("/save [md|json|session]", "💾 Save conversation"),
            ("/resume [id]",      "📂 Resume saved session or checkpoint"),
            ("/sessions",         "📋 List saved sessions"),
            ("/memory",           "🧠 Long-term memory (set/get/forget/search)"),
            ("/plan",             "📐 Task planning (new/next/done/show)"),
            ("/think [budget|off]", "🧠 Toggle extended thinking (e.g. /think 10000)"),
            ("/autoplan <goal>",  "🗺️  Auto-decompose task into steps with Claude"),
            ("!<shell cmd>",      "Run shell command directly"),
            ("/help",             "Show this help"),
            ("/quit",             "Exit"),
        ]
        for cmd_str, desc in cmds:
            table.add_row(cmd_str, desc)
        ui.console.print()
        ui.console.print(table)
        ui.console.print()

    def _load_plugin(self, parts: list):
        if len(parts) < 2:
            ui.print_info("Usage: /plugin <name>")
            return
        plugin_name = parts[1]
        available = discover_hfi_plugins()
        if plugin_name not in available:
            ui.print_error(f"Plugin '{plugin_name}' not found. Use /plugins to list.")
            return
        try:
            client = create_mcp_client(plugin_name, available[plugin_name])
            if client.start():
                self.mcp_clients.append(client)
                new_tools = client.get_tool_definitions()
                self.tools.extend(new_tools)
                ui.print_success(f"Plugin [{plugin_name}]: {len(new_tools)} tools added")
        except Exception as e:
            ui.print_error(f"Plugin error: {e}")

    def _add_mcp(self, parts: list):
        if len(parts) >= 3:
            name, mcp_cmd = parts[1], parts[2:]
            client = StdioMCPClient(name, mcp_cmd)
            if client.start():
                self.mcp_clients.append(client)
                new_tools = client.get_tool_definitions()
                self.tools.extend(new_tools)
                ui.print_success(f"MCP [{name}]: {len(new_tools)} tools added")
        else:
            ui.print_info("Usage: /mcp <name> <command> [args...]")
            for c in self.mcp_clients:
                ui.print_info(f"Active: {c.name} ({len(c.tools)} tools)")

    def _cmd_search(self, cmd_line: str, parts: list):
        if len(parts) < 2:
            ui.print_info("Usage: /search <query> [--glob pattern]")
            return
        query = " ".join(parts[1:]).split("--glob")[0].strip()
        file_pattern = None
        if "--glob" in cmd_line:
            file_pattern = cmd_line.split("--glob")[1].strip().split()[0]
        indexer = ProjectIndexer(os.getcwd())
        results = indexer.search(query, file_pattern)
        if results:
            ui.console.print(f"[cyan]Found {len(results)} matches[/cyan]")
            show_search_results(ui.console, [
                {"file_path": r.file_path, "line_num": r.line_num,
                 "matched_text": r.matched_text}
                for r in results
            ])
        else:
            ui.print_info("No matches found")

    def _cmd_index(self, cmd_line: str):
        force = "--force" in cmd_line
        indexer = ProjectIndexer(os.getcwd())
        ui.console.print("[cyan]Indexing project...[/cyan]")
        stats = indexer.index_project(force=force)
        ui.console.print(f"[green]✓ Indexed {stats['files_indexed']} files[/green]")
        if stats["errors"]:
            ui.print_warning(f"{len(stats['errors'])} errors during indexing")

    def _cmd_teammate(self, cmd_line: str, parts: list):
        if not hasattr(self, "_team"):
            self._team = AgentTeam()
        if len(parts) < 2:
            show_team_status(ui.console, self._team.get_team_status())
            return
        subcmd = parts[1]
        if subcmd == "add":
            if len(parts) < 3:
                ui.print_info("Usage: /teammate add <role>")
                ui.print_info(f"Roles: {', '.join(r.value for r in TeammateRole)}")
                return
            try:
                role = TeammateRole(parts[2])
                name = f"{parts[2]}_1"
                self._team.add_teammate(name, role)
                ui.print_success(f"Added teammate: {name} ({role.value})")
            except ValueError:
                ui.print_error(f"Unknown role: {parts[2]}")
        elif subcmd == "list":
            show_team_status(ui.console, self._team.get_team_status())
        elif subcmd == "delegate":
            if len(parts) < 4:
                ui.print_info("Usage: /teammate delegate <role> <task>")
                return
            try:
                role = TeammateRole(parts[2])
                task = self._team.delegate_task(
                    title=" ".join(parts[3:])[:50],
                    description=" ".join(parts[3:]),
                    role=role,
                )
                ui.print_success(f"Delegated to {parts[2]}: {task.id}")
            except ValueError:
                ui.print_error(f"Unknown role: {parts[2]}")

    # ── Phase 2 command implementations ───────────────────────────────

    def _cmd_save(self, parts: list):
        """Save conversation to file or named session."""
        if not self._ctx.messages:
            ui.print_info("Nothing to save yet")
            return
        # /save             → export to markdown on Desktop
        # /save session     → save as named session
        # /save json        → export as JSON
        fmt = parts[1].lower() if len(parts) > 1 else "md"
        if fmt == "session":
            session = self._history.save(
                self._ctx.messages, self.model,
                session_id=self._current_session_id,
            )
            self._current_session_id = session.id
            ui.print_success(f"Session saved: {session.id}  ({session.message_count} messages)")
        elif fmt == "json":
            path = self._exporter.to_json(self._ctx.messages, model=self.model)
            ui.print_success(f"Exported JSON: {path}")
        else:
            path = self._exporter.to_markdown(self._ctx.messages, model=self.model)
            ui.print_success(f"Exported Markdown: {path}")
        # Always keep a quick checkpoint too
        self._checkpoint.save(self._ctx.messages, self.model, self.system)

    def _cmd_resume(self, parts: list):
        """Resume a saved session by ID."""
        if len(parts) < 2:
            # No ID — resume from checkpoint
            data = self._checkpoint.load()
            if not data:
                ui.print_info("No checkpoint found. Use /save first or provide a session ID.")
                return
            self._ctx.messages = data["messages"]
            self.model = data.get("model", self.model)
            ui.print_success(
                f"Resumed checkpoint: {data['message_count']} messages  "
                f"(saved {data['saved_at'][:16]})"
            )
        else:
            session = self._history.load(parts[1])
            if not session:
                ui.print_error(f"Session '{parts[1]}' not found. Use /sessions to list.")
                return
            self._ctx.messages = session.messages
            self._current_session_id = session.id
            self.model = session.model
            ui.print_success(
                f"Resumed session: {session.id}  "
                f"'{session.preview}'  ({session.message_count} messages)"
            )

    def _cmd_sessions(self):
        """List saved sessions."""
        sessions = self._history.list()
        if not sessions:
            ui.print_info("No saved sessions. Use /save session to save one.")
            return
        from rich.table import Table
        from rich import box
        table = Table(box=box.ROUNDED, header_style="bold cyan",
                      border_style="dim cyan", padding=(0, 2), show_edge=True)
        table.add_column("ID", style="yellow", min_width=18, no_wrap=True)
        table.add_column("Preview", style="white", width=40)
        table.add_column("Msgs", style="cyan", justify="right")
        table.add_column("Saved", style="dim")
        for s in sessions:
            table.add_row(s.id, s.preview, str(s.message_count), s.updated_at[:16])
        ui.console.print()
        ui.console.print(table)
        ui.console.print(f"\n[dim]Resume with: /resume <id>[/dim]\n")

    def _cmd_memory(self, cmd_line: str, parts: list):
        """Manage long-term memory."""
        if len(parts) < 2:
            # Show all memories
            entries = self._memory.all()
            if not entries:
                ui.print_info("No memories yet. Use /memory set <key> <value>")
                return
            from rich.table import Table
            from rich import box
            table = Table(box=box.ROUNDED, header_style="bold cyan",
                          border_style="dim cyan", padding=(0, 2), show_edge=True)
            table.add_column("Key", style="yellow", min_width=16)
            table.add_column("Value", style="white")
            table.add_column("Category", style="dim", justify="center")
            for e in entries:
                table.add_row(e.key, e.value[:60], e.category)
            ui.console.print()
            ui.console.print(table)
            ui.console.print()
            return

        subcmd = parts[1]
        if subcmd == "set" and len(parts) >= 4:
            key, value = parts[2], " ".join(parts[3:])
            self._memory.remember(key, value)
            ui.print_success(f"Remembered: {key} = {value}")
        elif subcmd == "get" and len(parts) >= 3:
            val = self._memory.recall(parts[2])
            if val:
                ui.console.print(f"  [yellow]{parts[2]}[/yellow]: {val}")
            else:
                ui.print_info(f"No memory for '{parts[2]}'")
        elif subcmd == "forget" and len(parts) >= 3:
            if self._memory.forget(parts[2]):
                ui.print_success(f"Forgotten: {parts[2]}")
            else:
                ui.print_info(f"Key '{parts[2]}' not found")
        elif subcmd == "clear":
            self._memory.clear()
            ui.print_success("All memories cleared")
        elif subcmd == "search" and len(parts) >= 3:
            results = self._memory.search(" ".join(parts[2:]))
            for e in results:
                ui.console.print(f"  [yellow]{e.key}[/yellow]: {e.value}")
        else:
            ui.print_info("Usage: /memory [set <key> <val> | get <key> | forget <key> | search <q> | clear]")

    def _cmd_plan(self, cmd_line: str, parts: list):
        """Task planning commands."""
        if len(parts) < 2 or parts[1] == "show":
            if self._planner.current_plan:
                ui.console.print(self._planner.current_plan.summary())
            else:
                ui.print_info("No active plan. Use /plan new <goal>")
            return

        subcmd = parts[1]
        if subcmd == "new" and len(parts) >= 3:
            goal = " ".join(parts[2:])
            plan = self._planner.new_plan(goal)
            ui.print_success(f"New plan: {goal}")
        elif subcmd == "next":
            step = self._planner.advance()
            if step:
                ui.console.print(f"[cyan]▶ Step {step.index + 1}:[/cyan] {step.title}")
                ui.console.print(f"  {step.description}")
            else:
                ui.print_info("Plan complete or no active plan")
        elif subcmd == "done":
            self._planner.complete_step()
            if self._planner.current_plan:
                ui.console.print(self._planner.current_plan.summary())
        elif subcmd == "reset":
            self._planner.reset()
            ui.print_success("Plan reset")
        else:
            ui.print_info("Usage: /plan [new <goal> | next | done | show | reset]")

    def _cmd_think(self, parts: list):
        """Toggle or set extended thinking budget."""
        if len(parts) >= 2:
            arg = parts[1].lower()
            if arg in ("off", "0", "disable"):
                self.thinking_budget = 0
                ui.print_success("Extended thinking disabled")
                return
            try:
                budget = int(arg)
                if budget < 1000:
                    ui.print_warning("Budget must be >= 1000 tokens. Setting to 1000.")
                    budget = 1000
                self.thinking_budget = budget
                ui.print_thinking_status(budget)
                return
            except ValueError:
                pass
        # Toggle: if off → enable with default, if on → show status
        if self.thinking_budget == 0:
            self.thinking_budget = DEFAULT_THINKING_BUDGET
            ui.print_thinking_status(self.thinking_budget)
            ui.print_info("Extended thinking ON. Use /think off to disable.")
        else:
            ui.print_thinking_status(self.thinking_budget)
            ui.print_info(f"Use '/think off' to disable or '/think <n>' to change budget.")

    def _cmd_autoplan(self, cmd_line: str):
        """Ask Claude to decompose a goal into a plan and display it."""
        goal = cmd_line.split(None, 1)[1].strip() if len(cmd_line.split(None, 1)) > 1 else ""
        if not goal:
            ui.print_info("Usage: /autoplan <goal description>")
            return

        ui.print_info(f"🗺️  Planning: {goal}")
        plan_prompt = (
            f"Break down this goal into 5-10 clear, ordered steps that I can execute one by one.\n"
            f"Format each step as: N. Title — Brief description of what to do.\n\n"
            f"Goal: {goal}"
        )
        # Use a lightweight streamer (no tools, no thinking for planning itself)
        from .core.streaming import StreamingClient as SC
        from .config import API_BASE
        streamer = SC(API_BASE, self.token, self.model, "", [])
        try:
            response, _ = streamer.call([{"role": "user", "content": plan_prompt}],
                                        max_tokens=1024)
            plan_text = " ".join(
                b.get("text", "") for b in response.get("content", [])
                if b.get("type") == "text"
            ).strip()
            if plan_text:
                plan = self._planner.parse_from_text(goal, plan_text)
                ui.print_plan(plan.summary())
                ui.print_success(f"Plan created with {len(plan.steps)} steps. Use /plan next to start.")
            else:
                ui.print_error("Could not generate plan")
        except Exception as e:
            ui.print_error(f"Planning failed: {e}")

    def _cmd_tasks(self):
        if not hasattr(self, "_team"):
            ui.print_info("No team. Use /teammate add <role> first")
            return
        pending = self._team.coordinator.get_pending_tasks()
        if pending:
            show_task_monitor(ui.console, [
                {"title": t.title, "assigned_to": t.assigned_to or "unassigned",
                 "status": t.status, "priority": t.priority}
                for t in pending
            ])
        else:
            ui.print_info("No pending tasks")

    def cleanup(self):
        for client in self.mcp_clients:
            client.stop()
