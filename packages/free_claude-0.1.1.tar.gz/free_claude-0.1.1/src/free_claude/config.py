"""Configuration constants for free-claude."""
import os

TOKEN_FILE = os.path.expanduser("~/.free_claude/token.json")
CONFIG_FILE = os.path.expanduser("~/.free_claude/config.json")

# API base URL — override via env var for custom deployments
API_BASE = os.environ.get(
    "FREE_CLAUDE_API_BASE",
    "https://api.interface.feedback/api_proxy",
)

# OAuth configuration — all values can be overridden via environment variables.
# Copy .env.example to .env and fill in your own values if self-hosting.
_OAUTH_DOMAIN = os.environ.get("FREE_CLAUDE_OAUTH_DOMAIN", "")
_OAUTH_CLIENT_ID = os.environ.get("FREE_CLAUDE_OAUTH_CLIENT_ID", "")
_OAUTH_AUDIENCE = os.environ.get("FREE_CLAUDE_OAUTH_AUDIENCE", "")

OAUTH_CONFIG = {
    "domain":       _OAUTH_DOMAIN,
    "clientId":     _OAUTH_CLIENT_ID,
    "audience":     _OAUTH_AUDIENCE,
    "authorizeUrl": f"https://{_OAUTH_DOMAIN}/authorize",
    "tokenUrl":     f"https://{_OAUTH_DOMAIN}/oauth/token",
    "redirectUri":  os.environ.get("FREE_CLAUDE_REDIRECT_URI", "http://localhost:3000/code"),
    "scope":        os.environ.get("FREE_CLAUDE_OAUTH_SCOPE", "openid profile email offline_access"),
}

MODELS = {
    "opus":    "claude-opus-4-5-20251101",
    "sonnet":  "claude-sonnet-4-5-20250929",
    "haiku":   "claude-haiku-4-5-20251001",
    "opus4":   "claude-opus-4-6",
    "sonnet4": "claude-sonnet-4-6",
    "default": "claude-opus-4-6",
}

DEFAULT_SYSTEM_PROMPT = """You are a powerful AI coding assistant and personal agent running locally.

You have access to tools: bash, read_file, write_file, list_dir, web_fetch, python_eval, and MCP tools.

**CRITICAL RULES:**
1. For simple questions (greetings, explanations, opinions) → answer DIRECTLY without tools
2. For tasks requiring file/system info → use tools EFFICIENTLY (max 5-8 calls), then write your COMPLETE answer
3. NEVER call tools just to "explore" - only call if you genuinely need the information
4. After gathering enough context, STOP tools and write a full, conclusive response
5. Do NOT leave the user without a final answer - always conclude with clear text
6. Keep bash commands safe; ask before destructive operations
"""
