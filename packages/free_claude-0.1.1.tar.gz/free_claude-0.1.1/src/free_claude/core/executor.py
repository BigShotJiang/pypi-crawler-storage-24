"""Tool execution engine — dispatches built-in and MCP tool calls."""
from typing import List, Dict, Any, Callable, Tuple

_MAX_TOOL_RESULT_CHARS = 20_000


class ToolExecutor:
    """
    Executes tool calls — both built-in and MCP plugin tools.
    Truncates oversized results to prevent context overflow.
    """

    def __init__(self, mcp_clients: List, execute_builtin: Callable):
        self.mcp_clients = mcp_clients
        self._execute_builtin = execute_builtin

    def run(self, block: Dict) -> Dict:
        """
        Execute a tool_use block from the API response.

        Returns a dict with:
          - name:    tool name
          - detail:  short description for display
          - result:  truncated result string
          - payload: ready-to-send tool_result dict for the API
          - dropped: chars dropped by truncation (0 if none)
        """
        name: str = block["name"]
        inputs: Dict[str, Any] = block["input"]
        tool_id: str = block["id"]

        detail = (
            inputs.get("command")
            or inputs.get("path")
            or inputs.get("url")
            or str(inputs.get("code", ""))[:60]
            or ""
        )

        try:
            result = self._dispatch(name, inputs)
        except KeyboardInterrupt:
            result = "[INTERRUPTED] Tool was stopped by user"

        result_str, dropped = self._truncate(str(result))

        return {
            "name": name,
            "detail": str(detail),
            "result": result_str,
            "dropped": dropped,
            "payload": {
                "type": "tool_result",
                "tool_use_id": tool_id,
                "content": result_str,
            },
        }

    def _dispatch(self, name: str, inputs: Dict) -> Any:
        """Route tool call to built-in handler or MCP client."""
        if name.startswith("mcp_"):
            parts = name[4:].split("_", 1)
            client_name = parts[0]
            tool_name = parts[1] if len(parts) > 1 else ""
            for client in self.mcp_clients:
                if client.name == client_name:
                    return client.call_tool(tool_name, inputs)
            return f"[ERROR] MCP client '{client_name}' not found"
        return self._execute_builtin(name, inputs)

    def _truncate(self, result_str: str) -> Tuple[str, int]:
        """Truncate if over limit. Returns (result, dropped_chars)."""
        if len(result_str) <= _MAX_TOOL_RESULT_CHARS:
            return result_str, 0
        kept = result_str[:_MAX_TOOL_RESULT_CHARS]
        dropped = len(result_str) - _MAX_TOOL_RESULT_CHARS
        notice = f"\n\n[... {dropped:,} characters truncated to avoid context overflow ...]"
        return kept + notice, dropped


__all__ = ["ToolExecutor"]
