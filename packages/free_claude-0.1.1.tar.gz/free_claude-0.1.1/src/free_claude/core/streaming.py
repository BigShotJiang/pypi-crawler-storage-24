"""Streaming API logic — builds requests and parses SSE stream."""
import json
import urllib.request
from typing import Dict, List, Optional, Tuple

from rich.live import Live
from rich.spinner import Spinner

# Extended Thinking beta header (Anthropic API requirement)
_THINKING_BETA = "interleaved-thinking-2025-05-14"
# Default thinking budget in tokens (~medium depth)
DEFAULT_THINKING_BUDGET = 8000


class StreamingClient:
    """Handles both blocking and streaming Anthropic API calls.

    Extended Thinking:
        Set thinking_budget > 0 to enable Claude's extended thinking mode.
        This sends the 'thinking' parameter and required beta header.
        Thinking blocks are captured and returned in response['thinking_blocks'].
    """

    def __init__(self, api_base: str, token: str, model: str,
                 system: str, tools: list,
                 thinking_budget: int = 0):
        self.api_base = api_base
        self.token = token
        self.model = model
        self.system = system
        self.tools = tools
        self.thinking_budget = thinking_budget  # 0 = disabled

    def _build_request(self, messages: list, stream: bool,
                       max_tokens: int, include_tools: bool):
        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": self.system,
            "messages": messages,
            "stream": stream,
        }
        if include_tools and self.tools:
            payload["tools"] = self.tools

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01",
        }

        # Extended Thinking: add thinking param + beta header
        if self.thinking_budget > 0:
            payload["thinking"] = {
                "type": "enabled",
                "budget_tokens": self.thinking_budget,
            }
            # Extended thinking requires higher max_tokens than budget
            payload["max_tokens"] = max(max_tokens, self.thinking_budget + 1000)
            # Disable tools when thinking (Anthropic restriction on some models)
            payload.pop("tools", None)
            headers["anthropic-beta"] = _THINKING_BETA

        return urllib.request.Request(
            f"{self.api_base}/v1/messages",
            data=json.dumps(payload).encode(),
            headers=headers,
            method="POST",
        )

    def call(self, messages: list, max_tokens: int = 8096) -> Tuple[dict, dict]:
        """Blocking API call. Returns (response_dict, rate_limits)."""
        req = self._build_request(messages, stream=False,
                                   max_tokens=max_tokens, include_tools=True)
        with urllib.request.urlopen(req, timeout=120) as resp:
            rate_limits = _extract_rate_limits(resp.headers)
            result = json.loads(resp.read())
        # Extract thinking blocks for caller
        result["thinking_blocks"] = _extract_thinking(result.get("content", []))
        return result, rate_limits

    def stream(self, messages: list, console,
               max_tokens: int = 8096,
               include_tools: bool = True) -> Tuple[dict, dict]:
        """
        Streaming API call. Shows spinner while receiving.
        Returns (response_dict, rate_limits).
        response_dict has extra keys:
          'full_text'      — concatenated text output
          'thinking_blocks' — list of thinking block texts (if thinking enabled)
        """
        req = self._build_request(messages, stream=True,
                                   max_tokens=max_tokens,
                                   include_tools=include_tools)
        full_text = ""
        thinking_texts: List[str] = []
        current_thinking = ""
        in_thinking_block = False
        tool_uses = []
        current_tool = None
        stop_reason = None
        usage = {}
        rate_limits = {}

        import time
        from rich.text import Text as RichText

        _t0 = time.monotonic()
        thinking_enabled = self.thinking_budget > 0

        def _make_status():
            elapsed = int(time.monotonic() - _t0)
            if thinking_enabled and in_thinking_block:
                t = RichText()
                t.append("🧠 ", style="bold magenta")
                t.append("thinking deeply", style="magenta")
                t.append(f" [{elapsed}s]", style="dim yellow")
                return t
            if elapsed < 5:
                return Spinner("dots", style="dim cyan")
            t = RichText()
            t.append("⠋ ", style="dim cyan")
            t.append("thinking ", style="dim")
            t.append(f"[{elapsed}s]", style="dim yellow")
            return t

        with Live(_make_status(), console=console, refresh_per_second=4,
                  transient=True) as live:
            with urllib.request.urlopen(req, timeout=180) as resp:
                rate_limits = _extract_rate_limits(resp.headers)
                for raw_line in resp:
                    live.update(_make_status())
                    line = raw_line.decode("utf-8").rstrip()
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    etype = event.get("type", "")

                    if etype == "content_block_start":
                        block = event.get("content_block", {})
                        btype = block.get("type", "")
                        if btype == "thinking":
                            in_thinking_block = True
                            current_thinking = ""
                        elif btype == "tool_use":
                            in_thinking_block = False
                            current_tool = {
                                "id": block["id"],
                                "name": block["name"],
                                "input_str": "",
                            }
                        else:
                            in_thinking_block = False

                    elif etype == "content_block_delta":
                        delta = event.get("delta", {})
                        dtype = delta.get("type", "")
                        if dtype == "thinking_delta":
                            current_thinking += delta.get("thinking", "")
                        elif dtype == "text_delta":
                            full_text += delta.get("text", "")
                        elif dtype == "input_json_delta" and current_tool is not None:
                            current_tool["input_str"] += delta.get("partial_json", "")

                    elif etype == "content_block_stop":
                        if in_thinking_block and current_thinking:
                            thinking_texts.append(current_thinking)
                            current_thinking = ""
                            in_thinking_block = False
                        if current_tool is not None:
                            tool_uses.append(current_tool)
                            current_tool = None

                    elif etype == "message_delta":
                        delta = event.get("delta", {})
                        stop_reason = delta.get("stop_reason", stop_reason)
                        usage = event.get("usage", usage)

                    elif etype == "message_stop":
                        break

        content = []
        if full_text:
            content.append({"type": "text", "text": full_text})
        for tu in tool_uses:
            try:
                parsed = json.loads(tu["input_str"]) if tu["input_str"] else {}
            except json.JSONDecodeError:
                parsed = {}
            content.append({
                "type": "tool_use",
                "id": tu["id"],
                "name": tu["name"],
                "input": parsed,
            })

        response = {
            "content": content,
            "stop_reason": stop_reason or ("tool_use" if tool_uses else "end_turn"),
            "usage": usage,
            "full_text": full_text,
            "thinking_blocks": thinking_texts,
        }
        return response, rate_limits


def _extract_thinking(content: list) -> List[str]:
    """Extract thinking block texts from a non-streaming response."""
    return [
        b.get("thinking", "")
        for b in content
        if b.get("type") == "thinking" and b.get("thinking")
    ]


def _extract_rate_limits(headers) -> dict:
    return {k: headers[k] for k in headers if "ratelimit" in k.lower()}


__all__ = ["StreamingClient", "DEFAULT_THINKING_BUDGET"]
