"""
Structured logging for free-claude.

Usage:
    from .logger import log
    log.debug("Loading plugin %s", name)
    log.info("Token refreshed")
    log.warning("Context trimmed to %d messages", n)
    log.error("API error: %s", err)

Log level is controlled by AppConfig.log_level or FREE_CLAUDE_LOG_LEVEL env var.
Logs go to stderr so they don't pollute the terminal UI.
"""
import logging
import os
import sys
from pathlib import Path

_LOG_DIR = Path.home() / ".config" / "free-claude" / "logs"
_LOG_FILE = _LOG_DIR / "free-claude.log"

_FMT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATE_FMT = "%H:%M:%S"


def _resolve_level() -> int:
    """Determine log level from env var or config file."""
    raw = os.environ.get("FREE_CLAUDE_LOG_LEVEL", "").upper()
    if raw:
        return getattr(logging, raw, logging.WARNING)
    try:
        from .app_config import config
        return getattr(logging, config.log_level.upper(), logging.WARNING)
    except Exception:
        return logging.WARNING


def _setup_logger() -> logging.Logger:
    logger = logging.getLogger("free-claude")
    if logger.handlers:
        return logger  # Already configured

    level = _resolve_level()
    logger.setLevel(level)

    # Console handler (stderr only — don't mix with Rich output)
    if level <= logging.DEBUG:
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(level)
        console_handler.setFormatter(logging.Formatter(_FMT, _DATE_FMT))
        logger.addHandler(console_handler)

    # File handler (always, for debugging)
    try:
        _LOG_DIR.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(_LOG_FILE, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)  # capture everything to file
        file_handler.setFormatter(logging.Formatter(_FMT, _DATE_FMT))
        logger.addHandler(file_handler)
    except Exception:
        pass  # Silently skip if we can't write to log file

    logger.propagate = False
    return logger


# Module-level logger instance
log = _setup_logger()


def get_logger(name: str) -> logging.Logger:
    """Get a child logger for a specific module."""
    return logging.getLogger(f"free-claude.{name}")


__all__ = ["log", "get_logger"]
