"""Task decomposition — breaks complex requests into ordered steps."""
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime
from enum import Enum


class StepStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    SKIPPED = "skipped"
    FAILED = "failed"


@dataclass
class Step:
    """A single step in a plan."""
    index: int
    title: str
    description: str
    tool_hint: Optional[str] = None      # suggested tool (e.g. "bash", "read_file")
    depends_on: List[int] = field(default_factory=list)  # step indices
    status: StepStatus = StepStatus.PENDING
    result: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    def start(self):
        self.status = StepStatus.IN_PROGRESS
        self.started_at = datetime.now()

    def complete(self, result: str = ""):
        self.status = StepStatus.DONE
        self.result = result
        self.completed_at = datetime.now()

    def fail(self, reason: str = ""):
        self.status = StepStatus.FAILED
        self.result = reason
        self.completed_at = datetime.now()

    @property
    def is_ready(self) -> bool:
        """True if all dependencies are done."""
        return self.status == StepStatus.PENDING


@dataclass
class Plan:
    """An ordered list of steps to accomplish a goal."""
    goal: str
    steps: List[Step] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)

    def add_step(self, title: str, description: str,
                 tool_hint: str = None, depends_on: List[int] = None) -> Step:
        step = Step(
            index=len(self.steps),
            title=title,
            description=description,
            tool_hint=tool_hint,
            depends_on=depends_on or [],
        )
        self.steps.append(step)
        return step

    @property
    def pending_steps(self) -> List[Step]:
        return [s for s in self.steps if s.status == StepStatus.PENDING]

    @property
    def done_steps(self) -> List[Step]:
        return [s for s in self.steps if s.status == StepStatus.DONE]

    @property
    def is_complete(self) -> bool:
        return all(s.status in (StepStatus.DONE, StepStatus.SKIPPED)
                   for s in self.steps)

    @property
    def progress(self) -> float:
        if not self.steps:
            return 1.0
        done = sum(1 for s in self.steps
                   if s.status in (StepStatus.DONE, StepStatus.SKIPPED))
        return done / len(self.steps)

    def summary(self) -> str:
        lines = [f"📋 Plan: {self.goal}", f"Progress: {self.progress:.0%}"]
        for step in self.steps:
            icon = {"pending": "⏳", "in_progress": "🔄",
                    "done": "✅", "skipped": "⏭️", "failed": "❌"}.get(step.status, "❓")
            lines.append(f"  {icon} Step {step.index + 1}: {step.title}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "goal": self.goal,
            "created_at": self.created_at.isoformat(),
            "steps": [
                {
                    "index": s.index,
                    "title": s.title,
                    "description": s.description,
                    "tool_hint": s.tool_hint,
                    "status": s.status,
                    "result": s.result,
                }
                for s in self.steps
            ],
        }


class TaskPlanner:
    """
    Decomposes a complex goal into ordered steps.
    Can be driven by Claude's output or built manually.
    """

    def __init__(self):
        self.current_plan: Optional[Plan] = None
        self.plan_history: List[Plan] = []

    def new_plan(self, goal: str) -> Plan:
        """Create a new plan and set it as current."""
        if self.current_plan:
            self.plan_history.append(self.current_plan)
        self.current_plan = Plan(goal=goal)
        return self.current_plan

    def parse_from_text(self, goal: str, text: str) -> Plan:
        """
        Parse a plan from Claude's numbered list output.

        Recognises patterns like:
          1. Step title — description
          2. Another step
          - Bullet point step
        """
        plan = self.new_plan(goal)
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            # Match "1. Title" or "- Title" or "* Title"
            for prefix in ["- ", "* ", "• "]:
                if line.startswith(prefix):
                    title = line[len(prefix):].strip()
                    plan.add_step(title, title)
                    break
            else:
                # Try numbered list: "1. Title" or "1) Title"
                for sep in [". ", ") "]:
                    if len(line) > 2 and line[0].isdigit() and sep in line:
                        _, _, rest = line.partition(sep)
                        title = rest.strip()
                        # Split on " — " or " - " for title/description
                        if " — " in title:
                            t, _, d = title.partition(" — ")
                        elif " - " in title:
                            t, _, d = title.partition(" - ")
                        else:
                            t, d = title, title
                        plan.add_step(t.strip(), d.strip())
                        break
        return plan

    def advance(self) -> Optional[Step]:
        """Return the next pending step, or None if plan is complete."""
        if not self.current_plan:
            return None
        for step in self.current_plan.steps:
            if step.status == StepStatus.PENDING:
                step.start()
                return step
        return None

    def complete_step(self, result: str = ""):
        """Mark the current in-progress step as done."""
        if not self.current_plan:
            return
        for step in self.current_plan.steps:
            if step.status == StepStatus.IN_PROGRESS:
                step.complete(result)
                return

    def reset(self):
        """Clear current plan."""
        if self.current_plan:
            self.plan_history.append(self.current_plan)
        self.current_plan = None


__all__ = ["TaskPlanner", "Plan", "Step", "StepStatus"]
