"""Long-term memory — stores facts, preferences, and context across sessions."""
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

_log = logging.getLogger(__name__)


@dataclass
class MemoryEntry:
    """A single remembered fact."""
    key: str                          # short unique key (e.g. "user_name")
    value: str                        # the remembered content
    category: str = "general"        # general | preference | fact | project
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    hits: int = 0                     # how many times retrieved

    def touch(self):
        self.hits += 1
        self.updated_at = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "key": self.key,
            "value": self.value,
            "category": self.category,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "hits": self.hits,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "MemoryEntry":
        return cls(**d)


class MemoryStore:
    """
    Persistent key-value memory store backed by JSON.

    Stored at: ~/.config/free-claude/memory.json

    Usage:
        mem = MemoryStore()
        mem.remember("user_lang", "Vietnamese", category="preference")
        mem.recall("user_lang")           # → "Vietnamese"
        mem.search("lang")               # → list of matching entries
        mem.forget("user_lang")
    """

    _STORE_PATH = Path.home() / ".config" / "free-claude" / "memory.json"

    def __init__(self, store_path: Path = None):
        self._path = Path(store_path) if store_path else self._STORE_PATH
        self._data: Dict[str, MemoryEntry] = {}
        self._load()

    # ── Core operations ────────────────────────────────────────────────

    def remember(self, key: str, value: str, category: str = "general") -> MemoryEntry:
        """Store or update a memory entry."""
        if key in self._data:
            entry = self._data[key]
            entry.value = value
            entry.category = category
            entry.updated_at = datetime.now().isoformat()
        else:
            entry = MemoryEntry(key=key, value=value, category=category)
            self._data[key] = entry
        self._save()
        return entry

    def recall(self, key: str) -> Optional[str]:
        """Retrieve a memory by exact key. Returns None if not found."""
        entry = self._data.get(key)
        if entry:
            entry.touch()
            self._save()
            return entry.value
        return None

    def forget(self, key: str) -> bool:
        """Delete a memory entry. Returns True if it existed."""
        if key in self._data:
            del self._data[key]
            self._save()
            return True
        return False

    def search(self, query: str, category: str = None) -> List[MemoryEntry]:
        """Full-text search across keys and values."""
        q = query.lower()
        results = []
        for entry in self._data.values():
            if category and entry.category != category:
                continue
            if q in entry.key.lower() or q in entry.value.lower():
                results.append(entry)
        return sorted(results, key=lambda e: e.hits, reverse=True)

    def all(self, category: str = None) -> List[MemoryEntry]:
        """Return all entries, optionally filtered by category."""
        entries = list(self._data.values())
        if category:
            entries = [e for e in entries if e.category == category]
        return sorted(entries, key=lambda e: e.updated_at, reverse=True)

    def clear(self, category: str = None):
        """Clear all memories, or just a category."""
        if category:
            self._data = {k: v for k, v in self._data.items()
                          if v.category != category}
        else:
            self._data.clear()
        self._save()

    def context_snippet(self, max_entries: int = 10) -> str:
        """
        Return a compact text snippet suitable for injecting into system prompt.
        Lists the most recently updated / most accessed memories.
        """
        entries = sorted(self._data.values(),
                         key=lambda e: (e.hits, e.updated_at), reverse=True)
        entries = entries[:max_entries]
        if not entries:
            return ""
        lines = ["[Memory]"]
        for e in entries:
            lines.append(f"  {e.key}: {e.value}")
        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self._data)

    # ── Persistence ────────────────────────────────────────────────────

    def _load(self):
        try:
            if self._path.exists():
                raw = json.loads(self._path.read_text(encoding="utf-8"))
                self._data = {k: MemoryEntry.from_dict(v) for k, v in raw.items()}
        except json.JSONDecodeError as e:
            _log.warning("memory.json is corrupted, starting fresh: %s", e)
            self._data = {}
        except Exception as e:
            _log.error("Failed to load memory from %s: %s", self._path, e)
            self._data = {}

    def _save(self):
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            payload = {k: v.to_dict() for k, v in self._data.items()}
            self._path.write_text(json.dumps(payload, indent=2, ensure_ascii=False),
                                   encoding="utf-8")
        except PermissionError as e:
            _log.error("Permission denied writing memory to %s: %s", self._path, e)
        except Exception as e:
            _log.error("Failed to save memory to %s: %s", self._path, e)


__all__ = ["MemoryStore", "MemoryEntry"]
