"""Rich UI components for free-claude - beautiful terminal output like aider."""
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.rule import Rule
from rich.theme import Theme
from rich import box
from rich.padding import Padding

# Custom theme
THEME = Theme({
    "user.label":      "bold bright_green",
    "user.cwd":        "green",
    "assistant.label": "bold bright_blue",
    "tool.name":       "bold yellow",
    "tool.detail":     "white",
    "tool.result":     "dim white",
    "tool.sep":        "dim",
    "step.label":      "dim cyan",
    "model.name":      "bold magenta",
    "success":         "bold green",
    "error":           "bold red",
    "warning":         "yellow",
    "info":            "dim cyan",
    "mcp.label":       "bold blue",
    "header":          "bold cyan",
})

console = Console(theme=THEME, highlight=False)


def print_banner(model: str, n_builtin: int, n_mcp: int, plugin_names: list = None):
    """Print startup banner."""
    content = Text()
    content.append("  Model  ", style="dim")
    content.append(model, style="model.name")
    content.append("\n  Tools  ", style="dim")
    content.append(f"{n_builtin}", style="success")
    content.append(" built-in", style="dim")
    content.append(" · ", style="dim")
    content.append(f"{n_mcp}", style="mcp.label")
    content.append(" MCP", style="dim")
    if plugin_names:
        content.append("\n  Plugins ", style="dim")
        content.append(", ".join(plugin_names), style="mcp.label")
    content.append("\n  Cmds   ", style="dim")
    content.append("/model /clear /tools /plugins /plugin /mcp /help", style="info")

    console.print()
    console.print(Panel(
        content,
        title="[bold cyan]free-claude[/bold cyan]",
        subtitle="[dim]Claude with Tools + MCP[/dim]",
        border_style="cyan",
        padding=(0, 1),
    ))
    console.print()


def print_user_prompt(cwd: str) -> str:
    """Print user prompt and return input."""
    console.print()
    console.print(Text.assemble(
        ("╭─ ", "dim cyan"),
        ("You", "user.label"),
        (f"  {cwd}", "user.cwd"),
    ))
    console.print(Text("╰─> ", "dim cyan"), end="")
    try:
        return input()
    except EOFError:
        return "/quit"


def print_assistant_header():
    """Print assistant response header."""
    console.print()
    console.print(Text.assemble(
        ("╭─ ", "dim blue"),
        ("Claude", "assistant.label"),
    ))


def print_tool_call(name: str, detail: str):
    """Print a tool call."""
    # Clean up name
    display_name = name
    if name.startswith("mcp_"):
        parts = name[4:].split("_", 1)
        display_name = f"{parts[0]}/{parts[1]}" if len(parts) > 1 else parts[0]

    console.print()
    console.print(Text.assemble(
        ("  ⚙ ", "dim"),
        (display_name, "tool.name"),
        ("  ", ""),
        (str(detail)[:100], "tool.detail"),
    ))


def print_tool_result(result: str):
    """Print tool result - show meaningful preview."""
    result = result.strip()
    if not result or result == "(no output)":
        console.print(Text("    ↳ (no output)", style="dim"))
        return

    lines = result.split("\n")
    # Show up to 4 lines
    preview_lines = [l for l in lines if l.strip()][:4]
    remaining = len([l for l in lines if l.strip()]) - len(preview_lines)

    for i, line in enumerate(preview_lines):
        prefix = "    ↳ " if i == 0 else "      "
        # Truncate long lines
        display = line[:120] + ("…" if len(line) > 120 else "")
        console.print(Text(prefix + display, style="tool.result"))

    if remaining > 0:
        console.print(Text(f"      … {remaining} more lines", style="dim"))


def print_step(step: int, max_steps: int):
    """Print step counter as a subtle separator."""
    console.print()
    console.print(Rule(
        title=f"[step.label]step {step}/{max_steps}[/step.label]",
        style="dim",
        align="left",
    ))


def print_summarizing():
    """Print summarizing indicator."""
    console.print()
    console.print(Rule(
        title="[step.label]synthesizing answer…[/step.label]",
        style="dim",
        align="left",
    ))


def print_error(msg: str):
    console.print(Text(f"  ✗ {msg}", style="error"))


def print_warning(msg: str):
    console.print(Text(f"  ⚠ {msg}", style="warning"))


def print_success(msg: str):
    console.print(Text(f"  ✓ {msg}", style="success"))


def print_info(msg: str):
    console.print(Text(f"  {msg}", style="info"))


def print_mcp_loaded(names: list):
    """Silently absorbed into banner — no separate output."""
    pass  # Plugin names shown in banner via n_mcp count


def print_mcp_status(name: str, transport: str, n_tools: int, success: bool, error: str = ""):
    if success:
        console.print(Text.assemble(
            ("  ✓ ", "success"), (f"{name}", "bold"),
            (f" [{transport}]", "dim"), (f" {n_tools} tools", "success"),
        ))
    else:
        console.print(Text.assemble(
            ("  ✗ ", "error"), (f"{name}", "bold"), (f" {error}", "dim"),
        ))


def print_interrupted():
    console.print()
    console.print(Text("  ⚠ Interrupted — type /quit to exit", style="warning"))


def print_goodbye():
    console.print()
    console.print(Text("  Goodbye! 👋", style="bold cyan"))


def print_tools_table(tools: list):
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
                  border_style="dim cyan", padding=(0, 2), show_edge=True)
    table.add_column("Tool", min_width=26, style="yellow", no_wrap=True)
    table.add_column("Type", min_width=9, style="dim", justify="center")
    table.add_column("Description", style="white")

    for t in tools:
        name = t["name"]
        desc = t.get("description", "")[:72]
        if name.startswith("mcp_"):
            parts = name[4:].split("_", 1)
            display = f"{parts[0]}/{parts[1]}" if len(parts) > 1 else parts[0]
            kind = "MCP"
            style = "bright_blue"
        else:
            display = name
            kind = "built-in"
            style = "yellow"
        table.add_row(Text(display, style=style), kind, desc)

    console.print()
    console.print(f"  [bold cyan]{len(tools)} tools available[/bold cyan]")
    console.print(table)
    console.print()


def print_models_table(models: dict, current: str):
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
                  border_style="dim cyan", padding=(0, 2), show_edge=True)
    table.add_column("Key", style="yellow", min_width=10, no_wrap=True)
    table.add_column("Model ID", style="white")
    table.add_column("Status", style="dim green", justify="center")
    for k, v in models.items():
        marker = "[bold green]✓ active[/bold green]" if v == current else ""
        table.add_row(k, v, marker)
    console.print()
    console.print(table)
    console.print()


def print_plugins_table(plugins: dict):
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
                  border_style="dim cyan", padding=(0, 2), show_edge=True)
    table.add_column("Plugin", style="yellow", min_width=14, no_wrap=True)
    table.add_column("Transport", style="cyan", min_width=8, justify="center")
    table.add_column("Details", style="white")
    table.add_column("Auth", style="dim", justify="center")

    for name, cfg in plugins.items():
        transport = cfg.get("type", "stdio")
        needs_auth = any("${" in v for v in cfg.get("headers", {}).values())
        if transport == "stdio":
            cmd = cfg.get("command", "")
            args = " ".join(cfg.get("args", []))
            detail = f"{cmd} {args}"[:56]
        else:
            detail = cfg.get("url", "")[:56]
        auth = "[yellow]🔑 required[/yellow]" if needs_auth else "[green]✓ free[/green]"
        table.add_row(name, transport, detail, auth)

    console.print()
    console.print(f"  [bold cyan]{len(plugins)} plugins available[/bold cyan]  [dim]use: /plugin <name>[/dim]")
    console.print(table)
    console.print()


def render_markdown(text: str):
    """Render text as Rich Markdown with a clean left indent."""
    if text:
        console.print(Padding(Markdown(text, code_theme="monokai"), pad=(0, 0, 0, 2)))


def print_thinking_blocks(blocks: list, show: bool = True):
    """Render extended thinking blocks in a collapsible panel."""
    if not blocks or not show:
        return
    for i, thinking in enumerate(blocks, 1):
        if not thinking.strip():
            continue
        # Truncate very long thinking for display
        display = thinking.strip()
        truncated = False
        if len(display) > 2000:
            display = display[:2000]
            truncated = True

        label = f"🧠 Thinking" if len(blocks) == 1 else f"🧠 Thinking [{i}/{len(blocks)}]"
        content = Text(display, style="dim white")
        if truncated:
            content.append(f"\n  … ({len(thinking) - 2000:,} more chars)", style="dim")

        console.print()
        console.print(Panel(
            content,
            title=f"[bold magenta]{label}[/bold magenta]",
            border_style="dim magenta",
            padding=(0, 1),
            expand=False,
        ))


def print_thinking_status(budget: int):
    """Show that extended thinking is active."""
    console.print(Text.assemble(
        ("  🧠 ", "bold magenta"),
        ("Extended Thinking enabled", "magenta"),
        (f"  budget: {budget:,} tokens", "dim"),
    ))


def print_plan(plan_summary: str):
    """Render a task plan summary."""
    console.print()
    console.print(Panel(
        Text(plan_summary, style="white"),
        title="[bold cyan]📋 Task Plan[/bold cyan]",
        border_style="cyan",
        padding=(0, 1),
    ))
