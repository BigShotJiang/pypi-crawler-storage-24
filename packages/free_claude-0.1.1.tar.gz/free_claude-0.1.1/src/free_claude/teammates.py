"""Agent teammates and swarms — each teammate makes real API calls."""
import json
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from queue import Queue
from typing import Optional, List, Dict, Callable, Any
import threading


class TeammateRole(str, Enum):
    CODE_REVIEWER    = "code_reviewer"
    TEST_WRITER      = "test_writer"
    DOCS_WRITER      = "docs_writer"
    DEBUGGER         = "debugger"
    REFACTORER       = "refactorer"
    ARCHITECT        = "architect"
    SECURITY_AUDITOR = "security_auditor"


class TeammateStatus(str, Enum):
    IDLE     = "idle"
    THINKING = "thinking"
    WORKING  = "working"
    BLOCKED  = "blocked"
    DONE     = "done"


# ── Role system prompts ────────────────────────────────────────────────────

_SYSTEM_PROMPTS: Dict[TeammateRole, str] = {
    TeammateRole.CODE_REVIEWER: (
        "You are an expert code reviewer. Review code for correctness, style, "
        "performance, and best practices. Be concise, constructive, and specific. "
        "Respond in plain text with clear sections: Issues, Suggestions, Summary."
    ),
    TeammateRole.TEST_WRITER: (
        "You are a testing specialist. Write comprehensive, maintainable tests. "
        "Cover edge cases, happy paths, and error conditions. "
        "Output working pytest/unittest code with clear docstrings."
    ),
    TeammateRole.DOCS_WRITER: (
        "You are a documentation expert. Write clear, concise documentation. "
        "Include usage examples. Target developers of all levels. "
        "Output clean Markdown."
    ),
    TeammateRole.DEBUGGER: (
        "You are a debugging expert. Identify root causes systematically. "
        "Analyse error messages, trace execution, suggest minimal fixes. "
        "Be precise and methodical."
    ),
    TeammateRole.REFACTORER: (
        "You are a refactoring expert. Suggest safe, incremental improvements. "
        "Improve readability, reduce complexity, eliminate duplication. "
        "Always preserve existing behaviour."
    ),
    TeammateRole.ARCHITECT: (
        "You are a software architect. Think long-term: scalability, maintainability, "
        "design patterns, component boundaries. Provide high-level guidance with "
        "concrete recommendations."
    ),
    TeammateRole.SECURITY_AUDITOR: (
        "You are a security expert. Identify vulnerabilities: injection attacks, "
        "auth issues, data leaks, insecure defaults. Be thorough and err on the "
        "side of caution. Prioritise findings by severity."
    ),
}


# ── Message bus ────────────────────────────────────────────────────────────

@dataclass
class Message:
    sender: str
    receiver: str
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    task_id: Optional[str] = None
    attachments: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "sender": self.sender,
            "receiver": self.receiver,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "task_id": self.task_id,
        }


class MessageBus:
    def __init__(self):
        self._subs: Dict[str, List[Callable]] = {}
        self.history: List[Message] = []
        self._lock = threading.Lock()

    def subscribe(self, channel: str, cb: Callable):
        with self._lock:
            self._subs.setdefault(channel, []).append(cb)

    def publish(self, msg: Message):
        with self._lock:
            self.history.append(msg)
            callbacks = (self._subs.get(msg.receiver, []) +
                         self._subs.get("*", []))
        for cb in callbacks:
            try:
                cb(msg)
            except Exception:
                pass


# ── Task ──────────────────────────────────────────────────────────────────

@dataclass
class Task:
    id: str
    title: str
    description: str
    assigned_to: Optional[str] = None
    priority: int = 1
    status: str = "pending"
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    result: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)


# ── Teammate — makes real API calls ───────────────────────────────────────

class Teammate:
    """
    An AI specialist that makes real Anthropic API calls
    with a role-specific system prompt and its own conversation history.
    """

    def __init__(self, name: str, role: TeammateRole,
                 message_bus: MessageBus,
                 api_base: str = "https://api.interface.feedback/api_proxy",
                 token: str = "",
                 model: str = "claude-sonnet-4-6"):
        self.name = name
        self.role = role
        self.message_bus = message_bus
        self.api_base = api_base
        self.token = token
        self.model = model
        self.status = TeammateStatus.IDLE
        self.conversation: List[Dict] = []
        self.assigned_tasks: List[Task] = []
        self.current_task: Optional[Task] = None

    def get_system_prompt(self) -> str:
        return _SYSTEM_PROMPTS.get(self.role, "You are a helpful AI assistant.")

    def run_task(self, task: Task) -> str:
        """
        Execute a task by calling the Anthropic API with role-specific context.
        Returns the assistant's response text.
        """
        self.status = TeammateStatus.WORKING
        self.current_task = task
        task.status = "in_progress"

        self.conversation.append({
            "role": "user",
            "content": (
                f"Task: {task.title}\n\n"
                f"{task.description}"
            ),
        })

        try:
            result = self._call_api()
        except Exception as e:
            result = f"[ERROR] {str(e)}"
            task.status = "failed"
        else:
            task.status = "done"
            task.result = result
            task.completed_at = datetime.now()

        self.conversation.append({"role": "assistant", "content": result})
        self.status = TeammateStatus.DONE

        self.message_bus.publish(Message(
            sender=self.name,
            receiver="leader",
            content=f"Task '{task.title}' complete",
            task_id=task.id,
        ))
        return result

    def ask(self, question: str) -> str:
        """Ask the teammate a question (without a formal task)."""
        self.status = TeammateStatus.THINKING
        self.conversation.append({"role": "user", "content": question})
        try:
            result = self._call_api()
        except Exception as e:
            result = f"[ERROR] {str(e)}"
        self.conversation.append({"role": "assistant", "content": result})
        self.status = TeammateStatus.IDLE
        return result

    def _call_api(self) -> str:
        """Make a blocking API call and return the text response."""
        payload = {
            "model": self.model,
            "max_tokens": 4096,
            "system": self.get_system_prompt(),
            "messages": self.conversation[-20:],  # keep last 20 for context
        }
        req = urllib.request.Request(
            f"{self.api_base}/v1/messages",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())

        for block in data.get("content", []):
            if block.get("type") == "text":
                return block["text"]
        return ""

    def get_status(self) -> Dict:
        return {
            "role": self.role.value,
            "status": self.status.value,
            "tasks_assigned": len(self.assigned_tasks),
            "current_task": self.current_task.title if self.current_task else None,
            "conversation_turns": len(self.conversation) // 2,
        }


# ── Coordinator ───────────────────────────────────────────────────────────

class TaskCoordinator:
    def __init__(self, message_bus: MessageBus):
        self.message_bus = message_bus
        self.tasks: Dict[str, Task] = {}
        self._by_role: Dict[TeammateRole, List[Teammate]] = {}
        self._lock = threading.Lock()

    def register(self, teammate: Teammate):
        with self._lock:
            self._by_role.setdefault(teammate.role, []).append(teammate)

    def create_task(self, title: str, description: str,
                    priority: int = 1, context: Dict = None) -> Task:
        task = Task(
            id=f"task_{datetime.now().strftime('%H%M%S_%f')}",
            title=title,
            description=description,
            priority=priority,
            context=context or {},
        )
        with self._lock:
            self.tasks[task.id] = task
        return task

    def assign_to_role(self, task: Task, role: TeammateRole) -> Optional[Teammate]:
        """Find best idle teammate for role and assign."""
        with self._lock:
            candidates = self._by_role.get(role, [])
        for tm in candidates:
            if tm.status == TeammateStatus.IDLE:
                task.assigned_to = tm.name
                task.status = "assigned"
                tm.assigned_tasks.append(task)
                return tm
        if candidates:
            task.assigned_to = candidates[0].name
            task.status = "assigned"
            candidates[0].assigned_tasks.append(task)
            return candidates[0]
        return None

    def get_pending_tasks(self) -> List[Task]:
        with self._lock:
            tasks = [t for t in self.tasks.values() if t.status == "pending"]
        return sorted(tasks, key=lambda t: t.priority, reverse=True)

    def get_all_tasks(self) -> List[Task]:
        with self._lock:
            return list(self.tasks.values())


# ── AgentTeam ─────────────────────────────────────────────────────────────

class AgentTeam:
    """Orchestrates a team of AI specialists."""

    def __init__(self, api_base: str = "https://api.interface.feedback/api_proxy",
                 token: str = "", model: str = "claude-sonnet-4-6"):
        self.api_base = api_base
        self.token = token
        self.model = model
        self.message_bus = MessageBus()
        self.coordinator = TaskCoordinator(self.message_bus)
        self.teammates: Dict[str, Teammate] = {}

    def add_teammate(self, name: str, role: TeammateRole) -> Teammate:
        tm = Teammate(name, role, self.message_bus,
                      self.api_base, self.token, self.model)
        self.teammates[name] = tm
        self.coordinator.register(tm)
        return tm

    def remove_teammate(self, name: str) -> bool:
        if name in self.teammates:
            del self.teammates[name]
            return True
        return False

    def delegate_task(self, title: str, description: str,
                      role: TeammateRole, priority: int = 1,
                      run_async: bool = False) -> Task:
        """
        Create and assign a task. If run_async=True, runs in a background thread.
        """
        task = self.coordinator.create_task(title, description, priority)
        teammate = self.coordinator.assign_to_role(task, role)
        if not teammate:
            return task  # No teammate available, task stays pending

        if run_async:
            t = threading.Thread(
                target=teammate.run_task,
                args=(task,),
                daemon=True,
            )
            t.start()
        else:
            teammate.run_task(task)

        return task

    def ask_teammate(self, role: TeammateRole, question: str) -> Optional[str]:
        """Ask a question to the first available teammate with a role."""
        candidates = self.coordinator._by_role.get(role, [])
        if not candidates:
            return None
        return candidates[0].ask(question)

    def get_team_status(self) -> Dict:
        return {
            name: tm.get_status()
            for name, tm in self.teammates.items()
        }

    def get_message_history(self) -> List[Dict]:
        return [m.to_dict() for m in self.message_bus.history]

    def broadcast(self, content: str):
        self.message_bus.publish(Message(
            sender="leader",
            receiver="broadcast",
            content=content,
        ))


__all__ = [
    "Teammate", "AgentTeam", "TaskCoordinator", "MessageBus",
    "Task", "Message", "TeammateRole", "TeammateStatus",
]
