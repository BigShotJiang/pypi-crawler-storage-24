"""MCP (Model Context Protocol) client for free-claude.
Supports stdio, SSE, and HTTP transport types.
Also supports auto-discovery from claude-hfi plugin marketplace.
"""
import json
import os
import subprocess
import threading
import urllib.request
import urllib.error
from typing import Optional


# claude-hfi plugin marketplace location
HFI_PLUGINS_DIR = os.path.expanduser(
    "~/.claude-hfi/plugins/marketplaces/claude-plugins-official/external_plugins"
)


def discover_hfi_plugins() -> dict:
    """
    Discover available MCP plugins from claude-hfi marketplace.
    Returns dict: {name: {type, url/command, args, headers, ...}}
    """
    plugins = {}
    if not os.path.isdir(HFI_PLUGINS_DIR):
        return plugins

    for entry in os.scandir(HFI_PLUGINS_DIR):
        if not entry.is_dir():
            continue
        mcp_file = os.path.join(entry.path, ".mcp.json")
        if not os.path.exists(mcp_file):
            continue
        try:
            with open(mcp_file) as f:
                data = json.load(f)
            # Normalize: some files have top-level name, some have mcpServers wrapper
            if "mcpServers" in data:
                data = data["mcpServers"]
            for name, config in data.items():
                plugins[name] = config
        except Exception:
            pass

    return plugins


def list_hfi_plugins() -> None:
    """Print available claude-hfi plugins."""
    plugins = discover_hfi_plugins()
    if not plugins:
        print("  No claude-hfi plugins found")
        return
    print(f"  📦 {len(plugins)} plugins from claude-hfi marketplace:")
    for name, cfg in plugins.items():
        transport = cfg.get("type", "stdio")
        if transport == "stdio":
            cmd = cfg.get("command", "") + " " + " ".join(cfg.get("args", []))
            print(f"    • {name:<20} [stdio] {cmd[:50]}")
        else:
            url = cfg.get("url", "")
            needs_auth = "headers" in cfg or "oauth" in cfg
            auth_note = " 🔑 (needs auth)" if needs_auth else ""
            print(f"    • {name:<20} [{transport}] {url[:50]}{auth_note}")


def create_mcp_client(name: str, config: dict, env: dict = None) -> "MCPClient":
    """Factory: create correct MCPClient based on transport type."""
    transport = config.get("type", "stdio")
    if transport == "stdio":
        cmd = [config["command"]] + config.get("args", [])
        return StdioMCPClient(name, cmd, env=env)
    elif transport in ("http", "sse"):
        url = config["url"]
        headers = config.get("headers", {})
        # Resolve env vars in headers (e.g. ${GITHUB_PERSONAL_ACCESS_TOKEN})
        resolved_headers = {}
        for k, v in headers.items():
            if "${" in v:
                var_name = v.strip("${}")
                resolved = os.environ.get(var_name, "")
                if not resolved and env:
                    resolved = env.get(var_name, "")
                resolved_headers[k] = resolved
            else:
                resolved_headers[k] = v
        return HttpMCPClient(name, url, headers=resolved_headers, transport=transport)
    else:
        raise ValueError(f"Unknown MCP transport: {transport}")


class MCPClient:
    """Base MCP client."""
    def __init__(self, name: str):
        self.name = name
        self.tools: list = []

    def start(self) -> bool:
        raise NotImplementedError

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        raise NotImplementedError

    def stop(self):
        pass

    def get_tool_definitions(self) -> list:
        result = []
        for t in self.tools:
            result.append({
                "name": f"mcp_{self.name}_{t['name']}",
                "description": f"[MCP:{self.name}] {t.get('description', '')}",
                "input_schema": t.get("inputSchema", {"type": "object", "properties": {}}),
            })
        return result


class StdioMCPClient(MCPClient):
    """MCP client via stdio transport (JSON-RPC 2.0)."""

    def __init__(self, name: str, command: list, env: dict = None):
        super().__init__(name)
        self.command = command
        self.env = env
        self.process = None
        self._msg_id = 0
        self._lock = threading.Lock()

    def _next_id(self) -> int:
        with self._lock:
            self._msg_id += 1
            return self._msg_id

    def start(self, verbose: bool = True) -> bool:
        try:
            proc_env = os.environ.copy()
            if self.env:
                proc_env.update(self.env)
            self.process = subprocess.Popen(
                self.command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                env=proc_env,
            )
            self._send({
                "jsonrpc": "2.0", "id": self._next_id(), "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "clientInfo": {"name": "free-claude", "version": "0.1.0"},
                    "capabilities": {},
                },
            })
            self._recv(timeout=10)
            self._send({"jsonrpc": "2.0", "id": self._next_id(), "method": "tools/list", "params": {}})
            resp = self._recv(timeout=15)
            if resp and "result" in resp:
                self.tools = resp["result"].get("tools", [])
            if verbose:
                print(f"  ✅ MCP [{self.name}] stdio: {len(self.tools)} tools")
            return True
        except Exception as e:
            if verbose:
                print(f"  ❌ MCP [{self.name}] failed: {e}")
            return False

    def _send(self, msg: dict):
        self.process.stdin.write(json.dumps(msg) + "\n")
        self.process.stdin.flush()

    # Timeout for waiting on a single tool call response
    _TOOL_TIMEOUT_SECS = 30
    # Max chars to return from a single MCP tool result (~4k tokens)
    _MAX_RESULT_CHARS = 15_000

    def _recv(self, timeout: float = 30.0):
        """Read one JSON-RPC response line with a timeout."""
        result_holder = [None]
        error_holder = [None]

        def _read():
            try:
                line = self.process.stdout.readline()
                result_holder[0] = json.loads(line) if line else None
            except Exception as e:
                error_holder[0] = e

        t = threading.Thread(target=_read, daemon=True)
        t.start()
        t.join(timeout=timeout)

        if t.is_alive():
            # Timed out — process is hung reading a huge response
            return {"error": f"[MCP TIMEOUT] Tool took >{timeout}s — result too large?"}
        if error_holder[0]:
            return None
        return result_holder[0]

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        try:
            self._send({
                "jsonrpc": "2.0", "id": self._next_id(),
                "method": "tools/call",
                "params": {"name": tool_name, "arguments": arguments},
            })
            resp = self._recv(timeout=self._TOOL_TIMEOUT_SECS)
            if resp and "result" in resp:
                content = resp["result"].get("content", [])
                text = "\n".join(
                    c.get("text", "") for c in content if c.get("type") == "text"
                )
                # Truncate oversized results before sending to API
                if len(text) > self._MAX_RESULT_CHARS:
                    dropped = len(text) - self._MAX_RESULT_CHARS
                    text = (
                        text[:self._MAX_RESULT_CHARS]
                        + f"\n\n[... {dropped:,} characters truncated ...]"
                    )
                return text
            if resp and "error" in resp:
                return f"[MCP ERROR] {resp['error']}"
        except Exception as e:
            return f"[MCP ERROR] {e}"
        return "(no result)"

    def stop(self):
        if self.process:
            try:
                self.process.terminate()
            except Exception:
                pass


class HttpMCPClient(MCPClient):
    """MCP client via HTTP or SSE transport."""

    def __init__(self, name: str, url: str, headers: dict = None, transport: str = "http"):
        super().__init__(name)
        self.base_url = url.rstrip("/")
        self.headers = headers or {}
        self.transport = transport
        self._session_id: Optional[str] = None
        self._msg_id = 0
        self._lock = threading.Lock()

    def _next_id(self) -> int:
        with self._lock:
            self._msg_id += 1
            return self._msg_id

    def _post(self, data: dict) -> dict:
        body = json.dumps(data).encode()
        req_headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        req_headers.update(self.headers)
        if self._session_id:
            req_headers["Mcp-Session-Id"] = self._session_id

        req = urllib.request.Request(
            self.base_url,
            data=body,
            headers=req_headers,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            # Capture session ID if provided
            sid = resp.headers.get("Mcp-Session-Id")
            if sid:
                self._session_id = sid
            content_type = resp.headers.get("Content-Type", "")
            raw = resp.read().decode("utf-8", errors="replace")

        # Handle SSE response
        if "text/event-stream" in content_type:
            return self._parse_sse_response(raw)
        else:
            return json.loads(raw)

    def _parse_sse_response(self, raw: str) -> dict:
        """Extract JSON from SSE data lines."""
        for line in raw.splitlines():
            if line.startswith("data: "):
                try:
                    return json.loads(line[6:])
                except json.JSONDecodeError:
                    pass
        return {}

    def start(self, verbose: bool = True) -> bool:
        try:
            resp = self._post({
                "jsonrpc": "2.0", "id": self._next_id(), "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "clientInfo": {"name": "free-claude", "version": "0.1.0"},
                    "capabilities": {},
                },
            })
            # List tools
            resp2 = self._post({
                "jsonrpc": "2.0", "id": self._next_id(), "method": "tools/list", "params": {}
            })
            if resp2 and "result" in resp2:
                self.tools = resp2["result"].get("tools", [])
            if verbose:
                print(f"  ✅ MCP [{self.name}] {self.transport}: {len(self.tools)} tools")
            return True
        except urllib.error.HTTPError as e:
            if verbose:
                if e.code in (401, 403):
                    print(f"  ❌ MCP [{self.name}] auth required - check your API token/key")
                else:
                    print(f"  ❌ MCP [{self.name}] HTTP {e.code}: {e.reason}")
            return False
        except Exception as e:
            if verbose:
                print(f"  ❌ MCP [{self.name}] failed: {e}")
            return False

    # Max chars for HTTP MCP results (same as stdio)
    _MAX_RESULT_CHARS = 15_000

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        try:
            resp = self._post({
                "jsonrpc": "2.0", "id": self._next_id(),
                "method": "tools/call",
                "params": {"name": tool_name, "arguments": arguments},
            })
            if resp and "result" in resp:
                content = resp["result"].get("content", [])
                text = "\n".join(c.get("text", "") for c in content if c.get("type") == "text")
                if len(text) > self._MAX_RESULT_CHARS:
                    dropped = len(text) - self._MAX_RESULT_CHARS
                    text = (
                        text[:self._MAX_RESULT_CHARS]
                        + f"\n\n[... {dropped:,} characters truncated ...]"
                    )
                return text
            if resp and "error" in resp:
                return f"[MCP ERROR] {resp['error']}"
        except Exception as e:
            return f"[MCP ERROR] {e}"
        return "(no result)"
