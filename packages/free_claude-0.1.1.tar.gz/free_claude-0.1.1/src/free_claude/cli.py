"""CLI entry point for free-claude."""
import argparse
import os
import sys

from . import __version__
from .config import MODELS
from .mcp import discover_hfi_plugins, list_hfi_plugins, create_mcp_client


def main():
    parser = argparse.ArgumentParser(
        prog="fclaude",
        description="free-claude: Free Claude AI agent with tools and MCP support",
    )
    parser.add_argument("--version", action="version", version=f"free-claude {__version__}")
    parser.add_argument("-m", "--model", default="default", choices=list(MODELS.keys()),
                        help="Model to use (default: opus4 = claude-opus-4-6)")
    parser.add_argument("-q", "--query", help="Single query (non-interactive mode)")
    parser.add_argument("-s", "--system", help="System prompt")
    parser.add_argument("--mcp", nargs="+", action="append", metavar="ARG",
                        help="Add MCP server: --mcp name command [args...]")
    parser.add_argument("--plugin", action="append", metavar="NAME",
                        help="Enable claude-hfi plugin by name (e.g. --plugin context7 --plugin playwright)")
    parser.add_argument("--plugins", action="store_true",
                        help="List available claude-hfi plugins and exit")
    parser.add_argument("--cwd", help="Set working directory")
    parser.add_argument("--no-tools", action="store_true", help="Disable built-in tools")
    parser.add_argument("--no-auto-plugins", action="store_true",
                        help="Disable auto-loading of claude-hfi plugins")
    parser.add_argument("--think", action="store_true",
                        help="Enable extended thinking (default budget: 8000 tokens)")
    parser.add_argument("--think-budget", type=int, default=0, metavar="N",
                        help="Extended thinking token budget (enables thinking if > 0)")

    args = parser.parse_args()

    if args.cwd:
        os.chdir(args.cwd)

    # List plugins and exit
    if args.plugins:
        print("\n🔌 Available claude-hfi plugins:")
        list_hfi_plugins()
        print("\nUsage: fclaude --plugin <name>")
        return

    # Parse manual MCP servers
    mcp_servers = {}
    if args.mcp:
        for mcp_args in args.mcp:
            if len(mcp_args) >= 2:
                mcp_servers[mcp_args[0]] = mcp_args[1:]

    # Load claude-hfi plugins
    hfi_plugin_clients = []
    if args.plugin:
        available = discover_hfi_plugins()
        print("🔌 Loading plugins...")
        for plugin_name in args.plugin:
            if plugin_name not in available:
                print(f"  ❌ Plugin '{plugin_name}' not found. Run: fclaude --plugins")
                continue
            config = available[plugin_name]
            try:
                client = create_mcp_client(plugin_name, config)
                hfi_plugin_clients.append(client)
            except Exception as e:
                print(f"  ❌ Plugin '{plugin_name}' error: {e}")

    try:
        from .agent import Agent
        from .core.streaming import DEFAULT_THINKING_BUDGET

        # Resolve thinking budget
        thinking_budget = 0
        if args.think_budget > 0:
            thinking_budget = args.think_budget
        elif args.think:
            thinking_budget = DEFAULT_THINKING_BUDGET

        agent = Agent(
            model=args.model,
            system=args.system,
            mcp_servers=mcp_servers or None,
            mcp_clients=hfi_plugin_clients or None,
            auto_plugins=not args.no_auto_plugins,
            thinking_budget=thinking_budget,
        )

        if args.query:
            # Single query: stream trực tiếp ra stdout
            agent.run(args.query, stream=True)
        else:
            agent.chat()

    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


def login_cmd():
    """fclaude-login command."""
    from .auth import is_logged_in, login, refresh_token

    print("🔐 free-claude Login")
    print("=" * 40)

    if is_logged_in():
        print("✅ Already logged in. Attempting to refresh token...")
        try:
            token = refresh_token()
            if token:
                print(f"✅ Token refreshed successfully!")
                print(f"   Token: {token[:30]}...")
                return
        except Exception as e:
            print(f"⚠️  Refresh failed: {e}")
        print("Starting fresh login...")

    try:
        token = login(open_browser=True)
        print(f"\n🎉 Login successful!")
        print(f"   Token: {token[:30]}...")
        print(f"\n💡 Now run: fclaude")
    except KeyboardInterrupt:
        print("\n❌ Login cancelled")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Login failed: {e}")
        sys.exit(1)


def set_token_cmd():
    """fclaude-set-token command - manually set access token."""
    import argparse
    from .auth import save_token
    
    parser = argparse.ArgumentParser(
        prog="fclaude-set-token",
        description="Manually set free-claude access token"
    )
    parser.add_argument("token", nargs="?", help="Access token (or will prompt)")
    args = parser.parse_args()
    
    print("🔐 free-claude Token Setup")
    print("=" * 40)
    
    token = args.token
    if not token:
        print("\nEnter your access token:")
        print("(Paste and press Enter - input will be hidden)\n")
        import getpass
        token = getpass.getpass("Token: ").strip()
    
    if not token:
        print("❌ No token provided")
        sys.exit(1)
    
    try:
        save_token(token)
        print(f"\n✅ Token saved successfully!")
        print(f"   Token: {token[:30]}...")
        print(f"   Location: ~/.free_claude/token.json")
        print(f"\n💡 Now run: fclaude")
    except Exception as e:
        print(f"\n❌ Failed to save token: {e}")
        sys.exit(1)
