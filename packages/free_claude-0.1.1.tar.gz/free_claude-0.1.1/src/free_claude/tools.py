"""Built-in tools for free-claude agent."""
import os
import re
import subprocess
import urllib.request
from pathlib import Path

BUILTIN_TOOLS = [
    {
        "name": "bash",
        "description": "Execute a bash shell command. Use for running scripts, system commands, git, etc.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The bash command to execute"},
                "timeout": {"type": "integer", "description": "Timeout in seconds (default: 30)"},
            },
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read the contents of a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
                "start_line": {"type": "integer", "description": "Start line (1-indexed)"},
                "end_line": {"type": "integer", "description": "End line (1-indexed)"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Write or create a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to write"},
                "content": {"type": "string", "description": "Content to write"},
                "append": {"type": "boolean", "description": "Append instead of overwrite"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "list_dir",
        "description": "List directory contents with file sizes.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path (default: .)"},
                "recursive": {"type": "boolean", "description": "List recursively"},
            },
            "required": [],
        },
    },
    {
        "name": "web_fetch",
        "description": "Fetch content from a URL (HTML, JSON, text).",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch"},
                "max_chars": {"type": "integer", "description": "Max chars to return (default: 5000)"},
            },
            "required": ["url"],
        },
    },
    {
        "name": "python_eval",
        "description": "Execute Python code and return output. Good for calculations and data processing.",
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"},
            },
            "required": ["code"],
        },
    },
]


def run_bash(command: str, timeout: int = 30) -> str:
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=timeout, cwd=os.getcwd(),
        )
        out = result.stdout or ""
        if result.stderr:
            out += f"\n[stderr]: {result.stderr}"
        if result.returncode != 0:
            out += f"\n[exit code: {result.returncode}]"
        return out.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return f"[ERROR] Command timed out after {timeout}s"
    except Exception as e:
        return f"[ERROR] {e}"


def run_read_file(path: str, start_line: int = None, end_line: int = None) -> str:
    try:
        path = os.path.expanduser(path)
        with open(path, errors="replace") as f:
            lines = f.readlines()
        if start_line or end_line:
            s = (start_line - 1) if start_line else 0
            e = end_line if end_line else len(lines)
            lines = lines[s:e]
        content = "".join(lines)
        if len(content) > 20000:
            content = content[:20000] + f"\n...[truncated, {len(lines)} lines total]"
        return content
    except FileNotFoundError:
        return f"[ERROR] File not found: {path}"
    except Exception as e:
        return f"[ERROR] {e}"


def run_write_file(path: str, content: str, append: bool = False) -> str:
    try:
        path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        mode = "a" if append else "w"
        with open(path, mode) as f:
            f.write(content)
        action = "Appended to" if append else "Written"
        return f"✅ {action} {path} ({len(content)} chars)"
    except Exception as e:
        return f"[ERROR] {e}"


def run_list_dir(path: str = ".", recursive: bool = False) -> str:
    try:
        path = os.path.expanduser(path)
        if recursive:
            result = subprocess.run(
                ["find", path, "-not", "-path", "*/.*"],
                capture_output=True, text=True, timeout=10,
            )
            return result.stdout[:5000] or "(empty)"
        entries = []
        for item in sorted(Path(path).iterdir()):
            try:
                stat = item.stat()
                kind = "📁" if item.is_dir() else "📄"
                entries.append(f"{kind} {item.name:<40} {stat.st_size:>10} bytes")
            except Exception:
                entries.append(f"  {item.name}")
        return "\n".join(entries) if entries else "(empty directory)"
    except Exception as e:
        return f"[ERROR] {e}"


def run_web_fetch(url: str, max_chars: int = 5000) -> str:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            content_type = resp.headers.get("Content-Type", "")
            raw = resp.read().decode("utf-8", errors="replace")
        if "html" in content_type:
            raw = re.sub(r"<script[^>]*>.*?</script>", "", raw, flags=re.DOTALL)
            raw = re.sub(r"<style[^>]*>.*?</style>", "", raw, flags=re.DOTALL)
            raw = re.sub(r"<[^>]+>", " ", raw)
            raw = re.sub(r"\s+", " ", raw).strip()
        return raw[:max_chars] + ("..." if len(raw) > max_chars else "")
    except Exception as e:
        return f"[ERROR] {e}"


def run_python_eval(code: str) -> str:
    """Execute Python code safely in a subprocess sandbox."""
    import sys
    import tempfile
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as f:
            # Wrap code: try to print last expression if no explicit print
            wrapped = (
                "import sys, io\n"
                "_buf = io.StringIO()\n"
                "_old_stdout = sys.stdout\n"
                "sys.stdout = _buf\n"
                "try:\n"
                + "\n".join(f"    {line}" for line in code.splitlines())
                + "\nexcept Exception as _e:\n"
                "    sys.stdout = _old_stdout\n"
                "    print(f'[ERROR] {_e}')\n"
                "else:\n"
                "    sys.stdout = _old_stdout\n"
                "    _out = _buf.getvalue()\n"
                "    print(_out, end='')\n"
            )
            f.write(wrapped)
            tmp_path = f.name

        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=15,
            cwd=os.getcwd(),
        )
        output = result.stdout or ""
        if result.stderr:
            output += f"\n[stderr]: {result.stderr}"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "[ERROR] Python code timed out after 15s"
    except Exception as e:
        return f"[ERROR] {e}"
    finally:
        try:
            import os as _os
            _os.unlink(tmp_path)
        except Exception:
            pass


def execute_tool(name: str, inputs: dict) -> str:
    dispatch = {
        "bash": lambda i: run_bash(i["command"], i.get("timeout", 30)),
        "read_file": lambda i: run_read_file(i["path"], i.get("start_line"), i.get("end_line")),
        "write_file": lambda i: run_write_file(i["path"], i["content"], i.get("append", False)),
        "list_dir": lambda i: run_list_dir(i.get("path", "."), i.get("recursive", False)),
        "web_fetch": lambda i: run_web_fetch(i["url"], i.get("max_chars", 5000)),
        "python_eval": lambda i: run_python_eval(i["code"]),
    }
    fn = dispatch.get(name)
    if fn:
        return fn(inputs)
    return f"[ERROR] Unknown tool: {name}"
