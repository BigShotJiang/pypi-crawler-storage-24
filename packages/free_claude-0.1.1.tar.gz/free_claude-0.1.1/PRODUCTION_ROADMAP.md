# 🚀 Production Roadmap — free-claude

> Kế hoạch nâng cấp từ v0.3 (stable) lên v1.0 (production-ready)

---

## 📊 Trạng thái hiện tại (v0.3)

| Hạng mục | Điểm | Ghi chú |
|---|---|---|
| Kiến trúc | 8/10 | Modular, clean, dễ extend |
| Tính năng | 8/10 | Thinking, planning, memory, sessions |
| Độ ổn định | 7/10 | 112 tests pass, còn 1 checkpoint |
| Security | 7/10 | Env vars OK, chưa mã hóa memory |
| Performance | 6/10 | Chưa có log rotation, context trim thô |
| UX | 7/10 | Rich UI đẹp, một số edge case chưa xử lý |

---

## 🗺️ Phases Overview

```
v0.3 (NOW) ──► v0.4 (Security & Stability) ──► v0.5 (Performance) ──► v1.0 (Production)
    2 tuần              2 tuần                       1 tháng
```

---

## 📋 Phase 3 — Security & Stability (v0.4)

> **Mục tiêu:** Production-safe, không mất data, không crash âm thầm

### 3.1 🔐 Security

#### Memory Encryption
```python
# Hiện tại: plain text
~/.free_claude/memory.json  ← ai đọc được

# Mục tiêu: mã hóa AES-256 với key từ OS keyring
from cryptography.fernet import Fernet
# hoặc dùng native: keyring, SecretService (Linux), Keychain (macOS)
```

**Tasks:**
- [ ] Detect OS keyring support (keyring lib)
- [ ] Generate + store encryption key trong OS keyring
- [ ] Encrypt/decrypt `memory.json` và `token.json` transparently
- [ ] Migration path: auto-encrypt existing plain files on first run

#### Token Security
- [ ] Xóa token khỏi RAM sau khi dùng xong mỗi request
- [ ] Token expiry check trước mỗi request (không chờ 401)
- [ ] Warn nếu `token.json` permission không phải `0600`

---

### 3.2 🔄 Log Rotation

```python
# Hiện tại: file tăng vô hạn
~/.config/free-claude/logs/free_claude.log  ← có thể GB

# Mục tiêu: RotatingFileHandler
logging.handlers.RotatingFileHandler(
    maxBytes=5 * 1024 * 1024,   # 5MB per file
    backupCount=3,               # giữ 3 files cũ
)
```

**Tasks:**
- [ ] Thay `FileHandler` → `RotatingFileHandler` trong `logger.py`
- [ ] Thêm log cleanup command: `fclaude --clear-logs`
- [ ] Log timestamp format chuẩn ISO-8601

---

### 3.3 💾 Multi-Checkpoint

```python
# Hiện tại: 1 checkpoint duy nhất (bị ghi đè)
~/.free_claude/checkpoint.json

# Mục tiêu: N checkpoints với timestamp
~/.free_claude/checkpoints/
    2026-03-26T09-00-00.json
    2026-03-26T09-30-00.json   ← giữ 10 gần nhất
    2026-03-26T10-00-00.json   ← latest

/checkpoint        → save với timestamp
/restore           → list + chọn checkpoint để restore
/restore 3         → restore checkpoint thứ 3
```

**Tasks:**
- [ ] Đổi `checkpoint.py` lưu vào `checkpoints/` directory
- [ ] Auto-rotate: giữ tối đa 10 checkpoints
- [ ] `/restore` hiển thị list với timestamp và message count
- [ ] `/restore <n>` restore checkpoint cụ thể

---

### 3.4 🛡️ Input Validation

- [ ] Validate `--think-budget` range (1000 – 100000)
- [ ] Validate model name trước khi gọi API (tránh 400 error mù)
- [ ] Sanitize file paths trong tools (prevent path traversal)
- [ ] `bash` tool: warn trước destructive commands (`rm -rf`, `dd`, `mkfs`)

---

## 📋 Phase 4 — Performance & UX (v0.5)

> **Mục tiêu:** Nhanh hơn, mượt hơn, thân thiện hơn

### 4.1 ⚡ Performance

#### Parallel Tool Execution
```python
# Hiện tại: tools chạy tuần tự
tool1 → tool2 → tool3  (chậm nếu tool là web_fetch hoặc bash lâu)

# Mục tiêu: chạy song song khi không phụ thuộc nhau
asyncio.gather(tool1(), tool2(), tool3())
```

**Tasks:**
- [ ] Detect independent tool calls trong một response
- [ ] `asyncio` wrapper cho `bash`, `web_fetch`
- [ ] Progress bar khi chạy parallel tools

#### Smarter Context Trimming
- [ ] Estimate tokens chính xác hơn (dùng `tiktoken` hoặc Anthropic tokenizer)
- [ ] Preserve tool results gần nhất (thường quan trọng hơn messages cũ)
- [ ] Summarize theo topic cluster thay vì drop messages

#### Response Caching
- [ ] Cache kết quả `web_fetch` (TTL 5 phút)
- [ ] Cache `list_dir` results (TTL 30s)
- [ ] Skip re-index nếu file chưa thay đổi (đã có hash check)

---

### 4.2 🎨 UX Improvements

#### `/config` command
```
/config                    → xem config hiện tại
/config model sonnet4      → đổi default model
/config theme light        → đổi theme
/config show_tokens true   → hiện token usage
```

**Tasks:**
- [ ] Wire `app_config.py` vào `/config` command trong agent
- [ ] `/config save` persist thay đổi vào file
- [ ] `/config reset` về defaults

#### Better Error Messages
```python
# Hiện tại:
❌ API Error: 400

# Mục tiêu:
❌ Model 'claude-xyz' not found. Available: opus4, sonnet4, haiku
   Run: fclaude -m sonnet4
```

**Tasks:**
- [ ] Parse API error body và hiển thị hint
- [ ] Rate limit → hiển thị retry-after countdown
- [ ] Network error → suggest check connection / proxy

#### `/history` command
```
/history          → xem 20 messages gần nhất dạng compact
/history 5        → xem 5 messages
/history search   → tìm trong history hiện tại
```

#### Auto-save
- [ ] Auto-checkpoint mỗi 10 messages
- [ ] Auto-save session khi exit (`/quit` hoặc Ctrl+C)
- [ ] Prompt "Resume last session?" khi start mới

---

### 4.3 🔍 Search Improvements

- [ ] BM25 relevance ranking (thay vì chỉ match)
- [ ] Snippet preview với context surrounding match
- [ ] `/search` kết quả click-to-open trong editor (nếu `$EDITOR` set)
- [ ] Search history: lặp lại query cũ với ↑↓

---

## 📋 Phase 5 — Production Release (v1.0)

> **Mục tiêu:** Stable, documented, publishable

### 5.1 📦 PyPI Release

```toml
# pyproject.toml cần update:
[project]
version = "1.0.0"
requires-python = ">=3.9"
dependencies = ["rich>=13.0.0"]

[project.optional-dependencies]
security = ["cryptography>=41.0", "keyring>=24.0"]
fast = ["tiktoken>=0.5"]
```

**Tasks:**
- [ ] Bump version → `1.0.0`
- [ ] Finalize `pyproject.toml` (author, keywords, classifiers)
- [ ] Build và test: `python -m build && pip install dist/*.whl`
- [ ] Publish: `twine upload dist/*`
- [ ] GitHub Release với changelog

### 5.2 🧪 Test Coverage

**Mục tiêu: 90%+ coverage**

| Module | Hiện tại | Mục tiêu |
|---|---|---|
| `auth.py` | ~70% | 90% |
| `agent.py` | ~50% | 80% |
| `tools.py` | ~85% | 95% |
| `search.py` | ~60% | 85% |
| `teammates.py` | ~40% | 80% |
| `intelligence/` | ~75% | 90% |
| `session/` | ~80% | 95% |

**Tasks:**
- [ ] Integration tests: agent loop end-to-end với mock API
- [ ] Test extended thinking flow
- [ ] Test `/autoplan` decomposition
- [ ] Test session save → resume cycle
- [ ] Test memory encryption/decryption

### 5.3 📖 Documentation

- [ ] `docs/` directory với MkDocs hoặc Sphinx
- [ ] API reference (`Agent`, `StreamingClient`, `MemoryStore`...)
- [ ] Plugin development guide
- [ ] Video demo (GIF screencast)
- [ ] `CONTRIBUTING.md`

### 5.4 🔧 CI/CD

```yaml
# .github/workflows/test.yml — đã có
# Cần thêm:
# .github/workflows/publish.yml — auto-publish khi tag v*.*.* 
```

**Tasks:**
- [ ] Fix `.github/workflows/publish.yml` (đã có skeleton)
- [ ] Add `codecov` integration
- [ ] Add `ruff` linter check trong CI
- [ ] Add `mypy` type check trong CI

---

## 🎯 Priority Matrix

```
                    IMPACT
              Low         High
           ┌──────────┬──────────┐
      Easy │ /history │ Log rot. │
           │ /config  │ Multi-ck │
           ├──────────┼──────────┤
      Hard │ Parallel │ Encrypt  │
           │ tools    │ memory   │
           │ BM25     │ PyPI     │
           └──────────┴──────────┘
```

**Làm trước:** Log rotation → Multi-checkpoint → `/config` command → Memory encryption → PyPI

---

## 📅 Timeline

| Milestone | ETA | Deliverable |
|---|---|---|
| **v0.4** | +2 tuần | Log rotation, multi-checkpoint, token security, input validation |
| **v0.5** | +2 tuần | `/config`, `/history`, auto-save, better errors |
| **v0.9** | +3 tuần | 90% test coverage, CI/CD, docs |
| **v1.0** | +1 tháng | PyPI publish, GitHub release, video demo |

---

## 🔥 Quick Wins (có thể làm ngay, < 1 giờ mỗi task)

1. **Log rotation** — 10 dòng trong `logger.py`
2. **`/config` command** — `app_config` đã có, chỉ cần wire vào agent commands
3. **Auto-checkpoint mỗi 10 messages** — 5 dòng trong agent loop
4. **Validate `--think-budget`** — 3 dòng trong `cli.py`
5. **`fclaude --version`** — 1 dòng trong `cli.py`

---

## 💡 Ideas cho v2.0 (Ecosystem)

- 🌐 **Web dashboard** — xem team status, sessions trong browser (Textual/Flet)
- 🔗 **Git integration** — auto-review PRs, generate commit messages
- 🤖 **GitHub Actions plugin** — chạy agent trong CI/CD
- 🛒 **Plugin marketplace** — community plugins cho MCP
- 👥 **Multi-user sessions** — share session với teammates
- 📱 **REST API mode** — `fclaude serve` → HTTP API để integrate
- 🧩 **VS Code extension** — dùng trực tiếp trong editor

---

*Last updated: 2026-03-26 | Current version: v0.3*
