# 🏗️ free-claude — Architecture Roadmap

---

## 📦 Current State (v0.3 — NOW)

```
free-claude/
├── src/free_claude/
│   ├── __init__.py           Entry point + public API
│   ├── cli.py                Argparse CLI (--think, --think-budget, --mcp, ...)
│   ├── config.py             Models, constants (all via env vars)
│   ├── app_config.py         User config (~/.config/free-claude/config.toml)
│   ├── auth.py               OAuth PKCE token management + refresh
│   ├── agent.py              Core agent loop ← heart of the system
│   ├── tools.py              Built-in tools (bash, file, web, python sandbox)
│   ├── mcp.py                MCP client (stdio + HTTP/SSE transport)
│   ├── rich_ui.py            Terminal UI (thinking panels, markdown, tables)
│   ├── search.py             Ripgrep + SQLite indexing + Python fallback
│   ├── teammates.py          Multi-agent coordination (7 roles)
│   ├── ui_components.py      Interactive Rich components (file/branch selector)
│   ├── logger.py             Structured logging to ~/.config/free-claude/logs/
│   │
│   ├── core/                 Low-level agent infrastructure
│   │   ├── context.py        Message history, token-aware trimming
│   │   ├── streaming.py      SSE streaming + Extended Thinking support
│   │   └── executor.py       Tool execution engine
│   │
│   ├── intelligence/         Higher-order reasoning
│   │   ├── memory.py         Long-term memory (persistent JSON)
│   │   ├── planner.py        Task decomposition (/plan, /autoplan)
│   │   └── summarizer.py     Auto-compress long contexts via API
│   │
│   └── session/              Conversation persistence
│       ├── history.py        Save/load/list sessions
│       ├── checkpoint.py     Quick save/restore
│       └── export.py         Export to Markdown/JSON
│
├── tests/
│   ├── test_auth.py          Auth + token tests
│   ├── test_core.py          Core/streaming/context tests
│   ├── test_tools.py         Built-in tools tests
│   └── test_phase2.py        Intelligence + session tests (80+ cases)
│
├── .env.example              OAuth config template
├── pyproject.toml            Package metadata
├── README.md                 User guide
├── ADVANCED_FEATURES.md      Detailed feature guides
├── ARCHITECTURE_ROADMAP.md   This file
└── CHANGELOG.md              Version history
```

### ✅ Điểm mạnh hiện tại (v0.3)
- ✅ Streaming API + Rich Markdown render
- ✅ **Extended Thinking** — `--think` / `/think` với thinking budget
- ✅ **Auto-planning** — `/autoplan` + `/plan` workflow
- ✅ MCP plugin system (stdio + HTTP/SSE)
- ✅ Built-in tools (bash, file, web, **python sandbox subprocess**)
- ✅ Search & indexing với ripgrep + **Python fallback**
- ✅ Teammate roles (code_reviewer, debugger...) → **gọi HFI API thật**
- ✅ Session save/resume/export + checkpoint
- ✅ Long-term memory qua sessions
- ✅ Auto context summarization khi context dài
- ✅ OAuth credentials qua env vars (không hardcode)
- ✅ **112 tests passing**

### 🟡 Còn cần cải thiện
- 🟡 `agent.py` vẫn còn lớn — có thể tách commands ra `commands/`
- 🟡 Log rotation chưa có (file tăng vô hạn)
- 🟡 Memory chưa mã hóa
- 🟡 Chỉ lưu 1 checkpoint (chưa có lịch sử)

---

## 🚀 Phase 1 — Refactor & Stability (v1.0)

> **Mục tiêu:** Clean architecture, production-ready

```
src/free_claude/
├── core/
│   ├── __init__.py
│   ├── agent.py          # Loop chính (chat, run) — đã tách nhỏ
│   ├── streaming.py      # Stream API logic riêng
│   ├── context.py        # Message history + trimming
│   └── executor.py       # Tool execution engine
│
├── tools/
│   ├── __init__.py
│   ├── bash.py           # Shell execution
│   ├── files.py          # File operations
│   ├── web.py            # Web fetch
│   └── registry.py       # Tool registry pattern
│
├── plugins/
│   ├── __init__.py
│   ├── mcp.py            # MCP protocol (stdio/http)
│   ├── loader.py         # Plugin discovery & load
│   └── marketplace.py    # HFI plugin marketplace
│
├── ui/
│   ├── __init__.py
│   ├── rich_ui.py        # Rich terminal components
│   ├── components.py     # Interactive UI
│   └── themes.py         # Color themes (light/dark)
│
├── search/
│   ├── __init__.py
│   ├── indexer.py        # SQLite indexer
│   ├── ripgrep.py        # Ripgrep wrapper
│   └── cache.py          # File hash cache
│
├── auth.py               # Token management
├── config.py             # Config + constants
└── cli.py                # Entry point
```

### Phase 1 Tasks
- [x] Tách `agent.py` → `core/` modules (context, streaming, executor)
- [x] Config file (`~/.config/free-claude/config.toml`) + `/config` command
- [x] Proper logging system (`logger.py` → `~/.config/free-claude/logs/`)
- [x] Full pytest coverage — **112/112 tests passed** ✅

---

## 🧠 Phase 2 — Intelligence (v1.5)

> **Mục tiêu:** Agent thật sự thông minh hơn

```
src/free_claude/
├── intelligence/
│   ├── __init__.py
│   ├── planner.py        # Task decomposition
│   ├── memory.py         # Long-term memory (vector store)
│   ├── summarizer.py     # Auto-summarize long contexts
│   └── router.py         # Smart tool/teammate routing
│
├── teammates/
│   ├── __init__.py
│   ├── base.py           # Teammate base class
│   ├── roles.py          # 7 roles + system prompts
│   ├── coordinator.py    # Task coordination
│   ├── message_bus.py    # Inter-agent comms
│   └── executor.py       # Actually call API per teammate ← MISSING NOW
│
├── session/
│   ├── __init__.py
│   ├── history.py        # Conversation persistence
│   ├── checkpoint.py     # Save/resume sessions
│   └── export.py         # Export to markdown/JSON
```

### Phase 2 Features
- [x] **Teammates gọi API thật** — HFI proxy endpoint, `claude-sonnet-4-6`
- [x] **Long-term memory** — `intelligence/memory.py` + `/memory` command
- [x] **Task planner** — `intelligence/planner.py` + `/plan` + `/autoplan` command
- [x] **Smart context summarization** — `intelligence/summarizer.py` gọi API thật
- [x] **Session persistence** — `session/history.py` + `checkpoint.py`
- [x] **`/save`, `/resume`, `/sessions`, `/export`** commands
- [x] **Extended Thinking** — `core/streaming.py` + `--think` CLI flag
- [x] **Auto-planning** — `/autoplan` decompose goal → steps via API
- [x] **Token-accurate context trimming** — `estimated_tokens()` với 3.5 chars/token
- [x] **Silent failure → proper logging** — memory, history, checkpoint

---

## 🌐 Phase 3 — Ecosystem (v2.0)

> **Mục tiêu:** Platform mở rộng được

```
src/free_claude/
├── server/
│   ├── api.py            # REST API server (FastAPI)
│   ├── websocket.py      # Real-time streaming
│   └── auth_server.py    # OAuth server
│
├── dashboard/
│   ├── web_ui.py         # Web dashboard (Textual/Flet)
│   ├── team_monitor.py   # Real-time team status
│   └── analytics.py      # Usage analytics
│
├── integrations/
│   ├── git.py            # Git operations
│   ├── github.py         # GitHub PR/Issues
│   ├── jira.py           # Jira integration
│   └── slack.py          # Slack notifications
│
└── marketplace/
    ├── registry.py       # Plugin registry
    ├── installer.py      # One-click install
    └── sdk.py            # Plugin development SDK
```

### Phase 3 Features
- [ ] **Web dashboard** — monitor teammates trong browser
- [ ] **REST API** — dùng free-claude như một service
- [ ] **Git integration** — analyze PRs, auto-review
- [ ] **GitHub Actions** — CI/CD integration
- [ ] **Plugin marketplace** — community plugins
- [ ] **Multi-user** — team sharing sessions

---

## 📊 Architecture Diagram

```
┌─────────────────────────────────────────────────────────┐
│                    USER INTERFACE                        │
│  ┌──────────────┐  ┌─────────────┐  ┌───────────────┐  │
│  │   CLI (!)    │  │  /commands  │  │  Web UI (v2)  │  │
│  └──────┬───────┘  └──────┬──────┘  └───────┬───────┘  │
└─────────┼─────────────────┼──────────────────┼──────────┘
          │                 │                  │
          └─────────────────▼──────────────────┘
                      ┌─────────────┐
                      │  AGENT CORE │
                      │  agent.py   │
                      └──────┬──────┘
          ┌───────────────────┼─────────────────┐
          ▼                   ▼                 ▼
  ┌───────────────┐  ┌────────────────┐  ┌──────────────┐
  │  TOOL ENGINE  │  │   MCP PLUGINS  │  │  TEAMMATES   │
  │  bash/file/  │  │ context7/      │  │ code_review  │
  │  web/search  │  │ serena/        │  │ test_writer  │
  └───────┬───────┘  │ playwright/.. │  │ debugger/..  │
          │          └────────┬───────┘  └──────┬───────┘
          │                   │                 │
          └───────────────────▼─────────────────┘
                      ┌─────────────┐
                      │  ANTHROPIC  │
                      │     API     │
                      └─────────────┘
                             │
          ┌──────────────────┼───────────────────┐
          ▼                  ▼                   ▼
  ┌──────────────┐  ┌─────────────────┐  ┌─────────────┐
  │    MEMORY    │  │     SEARCH      │  │   SESSION   │
  │  (v1.5)      │  │ ripgrep+SQLite  │  │  (v1.5)     │
  └──────────────┘  └─────────────────┘  └─────────────┘
```

---

## 🎯 Priority Roadmap

| Milestone | Features | ETA |
|-----------|----------|-----|
| **v1.0** | Refactor agent.py, tool registry, config file, 80% tests | 1 week |
| **v1.5** | Teammates API thật, session persistence, long-term memory | 2 weeks |
| **v2.0** | Web dashboard, Git integration, plugin marketplace | 1 month |

---

## 🔥 Quick Wins (có thể làm ngay)

1. **Config file** `~/.config/free-claude/config.toml` — save model preference
2. **`/history`** command — xem conversation log đẹp
3. **`/save`** command — export conversation ra markdown
4. **Teammate API thật** — implement `Teammate.run(task)` gọi Anthropic
5. **Themes** — `/theme dark|light|minimal`

---

## 📝 Change Log

| Version | Date | Changes |
|---------|------|---------|
| v0.1 | 2026-03 | Initial release — basic agent + MCP |
| v0.2 | 2026-03 | Session, memory, planner, teammates, search, Rich UI |
| v0.3 | 2026-03-26 | Extended Thinking, auto-planning, bug fixes, security cleanup |
| v1.0 | TBD | **Phase 3** — log rotation, memory encryption, web dashboard |
