"""Tests for Phase 2 modules: intelligence/ and session/."""
import json
import tempfile
from pathlib import Path
import pytest


# ── TaskPlanner ────────────────────────────────────────────────────────────

class TestTaskPlanner:
    def setup_method(self):
        from free_claude.intelligence.planner import TaskPlanner
        self.planner = TaskPlanner()

    def test_new_plan(self):
        plan = self.planner.new_plan("Fix auth bug")
        assert plan.goal == "Fix auth bug"
        assert len(plan.steps) == 0
        assert self.planner.current_plan is plan

    def test_add_steps(self):
        plan = self.planner.new_plan("Refactor code")
        plan.add_step("Read code", "Read the source")
        plan.add_step("Identify issues", "Find problems")
        assert len(plan.steps) == 2
        assert plan.steps[0].index == 0
        assert plan.steps[1].index == 1

    def test_advance_and_complete(self):
        plan = self.planner.new_plan("Goal")
        plan.add_step("Step 1", "Do step 1")
        plan.add_step("Step 2", "Do step 2")

        step = self.planner.advance()
        assert step.title == "Step 1"
        assert step.status.value == "in_progress"

        self.planner.complete_step("Done!")
        assert plan.steps[0].status.value == "done"
        assert plan.steps[0].result == "Done!"

    def test_progress_calculation(self):
        plan = self.planner.new_plan("Goal")
        plan.add_step("A", "a")
        plan.add_step("B", "b")
        plan.add_step("C", "c")
        assert plan.progress == 0.0

        self.planner.advance()
        self.planner.complete_step()
        assert abs(plan.progress - 1/3) < 0.01

    def test_plan_is_complete(self):
        plan = self.planner.new_plan("Goal")
        plan.add_step("Only step", "desc")
        self.planner.advance()
        self.planner.complete_step()
        assert plan.is_complete

    def test_parse_from_numbered_list(self):
        text = """
1. Read the code — Look at the source files
2. Identify issues — Find bugs and problems
3. Fix issues — Apply the fixes
"""
        plan = self.planner.parse_from_text("Fix bugs", text)
        assert len(plan.steps) == 3
        assert plan.steps[0].title == "Read the code"
        assert plan.steps[1].title == "Identify issues"

    def test_parse_from_bullets(self):
        text = """
- Install dependencies
- Run tests
- Deploy
"""
        plan = self.planner.parse_from_text("Deploy", text)
        assert len(plan.steps) == 3

    def test_reset_archives_plan(self):
        plan = self.planner.new_plan("Old goal")
        self.planner.reset()
        assert self.planner.current_plan is None
        assert len(self.planner.plan_history) == 1

    def test_plan_summary(self):
        plan = self.planner.new_plan("Test goal")
        plan.add_step("Step A", "desc")
        summary = plan.summary()
        assert "Test goal" in summary
        assert "Step A" in summary

    def test_plan_to_dict(self):
        plan = self.planner.new_plan("My goal")
        plan.add_step("S1", "d1")
        d = plan.to_dict()
        assert d["goal"] == "My goal"
        assert len(d["steps"]) == 1

    def test_advance_returns_none_when_done(self):
        plan = self.planner.new_plan("Goal")
        assert self.planner.advance() is None

    def test_step_fail(self):
        plan = self.planner.new_plan("Goal")
        plan.add_step("Step", "desc")
        step = self.planner.advance()
        step.fail("Something went wrong")
        assert step.status.value == "failed"
        assert step.result == "Something went wrong"


# ── MemoryStore ────────────────────────────────────────────────────────────

class TestMemoryStore:
    def setup_method(self):
        from free_claude.intelligence.memory import MemoryStore
        self.tmp = Path(tempfile.mktemp(suffix=".json"))
        self.mem = MemoryStore(store_path=self.tmp)

    def teardown_method(self):
        if self.tmp.exists():
            self.tmp.unlink()

    def test_remember_and_recall(self):
        self.mem.remember("name", "Alice")
        assert self.mem.recall("name") == "Alice"

    def test_recall_missing_key(self):
        assert self.mem.recall("nonexistent") is None

    def test_forget(self):
        self.mem.remember("key", "value")
        assert self.mem.forget("key") is True
        assert self.mem.recall("key") is None

    def test_forget_missing_key(self):
        assert self.mem.forget("nonexistent") is False

    def test_update_existing(self):
        self.mem.remember("key", "old")
        self.mem.remember("key", "new")
        assert self.mem.recall("key") == "new"
        assert len(self.mem) == 1

    def test_search_by_key(self):
        self.mem.remember("user_language", "Vietnamese")
        self.mem.remember("user_name", "Bao")
        self.mem.remember("project", "free-claude")
        results = self.mem.search("user")
        assert len(results) == 2

    def test_search_by_value(self):
        self.mem.remember("pref", "dark mode enabled")
        results = self.mem.search("dark")
        assert len(results) == 1

    def test_filter_by_category(self):
        self.mem.remember("lang", "vi", category="preference")
        self.mem.remember("proj", "fclaude", category="project")
        prefs = self.mem.all(category="preference")
        assert len(prefs) == 1
        assert prefs[0].key == "lang"

    def test_context_snippet(self):
        self.mem.remember("user_name", "Bao")
        self.mem.remember("lang", "Vietnamese")
        snippet = self.mem.context_snippet()
        assert "[Memory]" in snippet
        assert "user_name" in snippet
        assert "lang" in snippet

    def test_context_snippet_empty(self):
        assert self.mem.context_snippet() == ""

    def test_persistence(self):
        from free_claude.intelligence.memory import MemoryStore
        self.mem.remember("persistent_key", "persistent_value")
        # Load from same file
        mem2 = MemoryStore(store_path=self.tmp)
        assert mem2.recall("persistent_key") == "persistent_value"

    def test_clear_all(self):
        self.mem.remember("a", "1")
        self.mem.remember("b", "2")
        self.mem.clear()
        assert len(self.mem) == 0

    def test_clear_by_category(self):
        self.mem.remember("a", "1", category="pref")
        self.mem.remember("b", "2", category="fact")
        self.mem.clear(category="pref")
        assert len(self.mem) == 1

    def test_hits_tracking(self):
        self.mem.remember("key", "value")
        self.mem.recall("key")
        self.mem.recall("key")
        entry = self.mem._data["key"]
        assert entry.hits == 2


# ── ContextSummarizer ──────────────────────────────────────────────────────

class TestContextSummarizer:
    def setup_method(self):
        from free_claude.intelligence.summarizer import ContextSummarizer
        self.s = ContextSummarizer(threshold_chars=500, keep_recent=2)

    def test_should_not_summarize_short(self):
        msgs = [{"role": "user", "content": "hi"}]
        assert not self.s.should_summarize(msgs)

    def test_should_summarize_long(self):
        msgs = [{"role": "user", "content": "x" * 200}] * 5
        assert self.s.should_summarize(msgs)

    def test_total_chars(self):
        msgs = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "world"},
        ]
        assert self.s.total_chars(msgs) == 10

    def test_compress_keeps_recent(self):
        msgs = [{"role": "user", "content": f"msg {i}"} for i in range(10)]
        compressed = self.s.compress(msgs, "Summary of old messages")
        # Should have summary + ack + last 2 messages
        assert len(compressed) == 4
        assert "Summary" in compressed[0]["content"]
        assert compressed[2]["content"] == "msg 8"
        assert compressed[3]["content"] == "msg 9"

    def test_build_summary_prompt(self):
        msgs = [
            {"role": "user", "content": "What is Python?"},
            {"role": "assistant", "content": "Python is a programming language."},
        ]
        prompt = self.s.build_summary_prompt(msgs)
        assert len(prompt) == 1
        assert "transcript" in prompt[0]["content"].lower()

    def test_estimate_savings(self):
        msgs = [{"role": "user", "content": "x" * 1000}] * 10
        savings = self.s.estimate_token_savings(msgs, "Short summary")
        assert savings > 0


# ── CheckpointManager ─────────────────────────────────────────────────────

class TestCheckpointManager:
    def setup_method(self):
        from free_claude.session.checkpoint import CheckpointManager
        self.path = Path(tempfile.mktemp(suffix=".json"))
        self.cp = CheckpointManager(path=self.path)

    def teardown_method(self):
        if self.path.exists():
            self.path.unlink()

    def test_save_and_load(self):
        msgs = [{"role": "user", "content": "Hello"}]
        assert self.cp.save(msgs, "claude-opus-4-6")
        data = self.cp.load()
        assert data is not None
        assert data["message_count"] == 1
        assert data["model"] == "claude-opus-4-6"
        assert data["messages"][0]["content"] == "Hello"

    def test_load_none_when_missing(self):
        assert self.cp.load() is None

    def test_exists(self):
        assert not self.cp.exists()
        self.cp.save([], "model")
        assert self.cp.exists()

    def test_clear(self):
        self.cp.save([], "model")
        assert self.cp.clear()
        assert not self.cp.exists()

    def test_clear_nonexistent(self):
        assert not self.cp.clear()

    def test_info(self):
        msgs = [{"role": "user", "content": "x"}] * 5
        self.cp.save(msgs, "claude-opus-4-6")
        info = self.cp.info()
        assert info["model"] == "claude-opus-4-6"
        assert info["message_count"] == 5
        assert "saved_at" in info


# ── SessionHistory ─────────────────────────────────────────────────────────

class TestSessionHistory:
    def setup_method(self):
        from free_claude.session.history import SessionHistory
        self.dir = Path(tempfile.mkdtemp())
        self.hist = SessionHistory(sessions_dir=self.dir)

    def test_save_and_load(self):
        msgs = [{"role": "user", "content": "Hello!"}]
        session = self.hist.save(msgs, "claude-opus-4-6")
        assert session.message_count == 1
        assert session.preview == "Hello!"

        loaded = self.hist.load(session.id)
        assert loaded.id == session.id
        assert loaded.message_count == 1

    def test_auto_title(self):
        msgs = [{"role": "user", "content": "Explain recursion in Python"}]
        session = self.hist.save(msgs, "model")
        assert "Explain recursion" in session.title

    def test_list_sessions(self):
        msgs = [{"role": "user", "content": "q1"}]
        self.hist.save(msgs, "model", session_id="session_001")
        self.hist.save(msgs, "model", session_id="session_002")
        sessions = self.hist.list()
        assert len(sessions) == 2

    def test_list_empty(self):
        assert self.hist.list() == []

    def test_delete(self):
        msgs = [{"role": "user", "content": "test"}]
        session = self.hist.save(msgs, "model")
        assert self.hist.delete(session.id)
        assert self.hist.load(session.id) is None

    def test_delete_nonexistent(self):
        assert not self.hist.delete("nonexistent_id")

    def test_update(self):
        msgs = [{"role": "user", "content": "original"}]
        session = self.hist.save(msgs, "model")
        new_msgs = msgs + [{"role": "assistant", "content": "reply"}]
        assert self.hist.update(session.id, new_msgs)
        loaded = self.hist.load(session.id)
        assert loaded.message_count == 2

    def test_load_nonexistent(self):
        assert self.hist.load("nonexistent") is None


# ── SessionExporter ────────────────────────────────────────────────────────

class TestSessionExporter:
    def setup_method(self):
        from free_claude.session.export import SessionExporter
        self.exporter = SessionExporter()
        self.tmp_dir = Path(tempfile.mkdtemp())
        self.msgs = [
            {"role": "user", "content": "What is Python?"},
            {"role": "assistant", "content": "Python is a programming language."},
            {"role": "user", "content": "Tell me more."},
            {"role": "assistant", "content": "It was created by Guido van Rossum."},
        ]

    def test_to_markdown(self):
        path = self.exporter.to_markdown(
            self.msgs,
            output_path=self.tmp_dir / "test.md",
            model="claude-opus-4-6"
        )
        assert path.exists()
        content = path.read_text()
        assert "# Conversation Export" in content
        assert "What is Python?" in content
        assert "Python is a programming language." in content

    def test_to_json(self):
        path = self.exporter.to_json(
            self.msgs,
            output_path=self.tmp_dir / "test.json",
            model="claude-opus-4-6"
        )
        assert path.exists()
        data = json.loads(path.read_text())
        assert data["message_count"] == 4
        assert data["model"] == "claude-opus-4-6"
        assert len(data["messages"]) == 4

    def test_to_text(self):
        text = self.exporter.to_text(self.msgs)
        assert "[USER]" in text
        assert "[ASSISTANT]" in text
        assert "What is Python?" in text

    def test_to_markdown_with_tool_use(self):
        msgs = [
            {"role": "user", "content": "Run ls"},
            {"role": "assistant", "content": [
                {"type": "text", "text": "Running ls..."},
                {"type": "tool_use", "name": "bash", "input": {"command": "ls"}},
            ]},
        ]
        path = self.exporter.to_markdown(
            msgs, output_path=self.tmp_dir / "tool.md"
        )
        content = path.read_text()
        assert "Running ls..." in content
        assert "bash" in content


# ── AgentTeam (Teammates with real API structure) ──────────────────────────

class TestAgentTeam:
    def setup_method(self):
        from free_claude.teammates import AgentTeam, TeammateRole, TeammateStatus
        self.AgentTeam = AgentTeam
        self.TeammateRole = TeammateRole
        self.TeammateStatus = TeammateStatus

    def test_add_teammate(self):
        team = self.AgentTeam()
        tm = team.add_teammate("reviewer_1", self.TeammateRole.CODE_REVIEWER)
        assert tm.name == "reviewer_1"
        assert tm.role == self.TeammateRole.CODE_REVIEWER
        assert tm.status == self.TeammateStatus.IDLE

    def test_get_team_status(self):
        team = self.AgentTeam()
        team.add_teammate("reviewer_1", self.TeammateRole.CODE_REVIEWER)
        team.add_teammate("tester_1", self.TeammateRole.TEST_WRITER)
        status = team.get_team_status()
        assert "reviewer_1" in status
        assert "tester_1" in status
        assert status["reviewer_1"]["role"] == "code_reviewer"

    def test_remove_teammate(self):
        team = self.AgentTeam()
        team.add_teammate("tm", self.TeammateRole.DEBUGGER)
        assert team.remove_teammate("tm")
        assert "tm" not in team.teammates

    def test_system_prompt_per_role(self):
        team = self.AgentTeam()
        for role in self.TeammateRole:
            tm = team.add_teammate(f"{role.value}_test", role)
            prompt = tm.get_system_prompt()
            assert len(prompt) > 20  # Non-trivial prompt

    def test_delegate_task_no_teammate(self):
        team = self.AgentTeam()
        # No teammate for this role — task stays pending
        task = team.delegate_task(
            "Review code",
            "Check auth.py",
            self.TeammateRole.CODE_REVIEWER,
        )
        assert task.status in ("pending", "assigned")

    def test_message_bus(self):
        team = self.AgentTeam()
        received = []
        team.message_bus.subscribe("*", lambda m: received.append(m))
        team.broadcast("Hello team!")
        assert len(received) == 1
        assert received[0].content == "Hello team!"

    def test_coordinator_create_task(self):
        team = self.AgentTeam()
        task = team.coordinator.create_task("Fix bug", "Detailed desc", priority=5)
        assert task.title == "Fix bug"
        assert task.priority == 5
        assert task.status == "pending"

    def test_get_message_history(self):
        team = self.AgentTeam()
        team.broadcast("Test message")
        hist = team.get_message_history()
        assert len(hist) == 1
        assert hist[0]["content"] == "Test message"
