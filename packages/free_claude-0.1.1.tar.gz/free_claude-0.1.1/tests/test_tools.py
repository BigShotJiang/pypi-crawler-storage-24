"""Tests for free_claude.tools module."""
import os
import pytest
from free_claude.tools import (
    run_bash,
    run_read_file,
    run_write_file,
    run_list_dir,
    run_python_eval,
    execute_tool,
    BUILTIN_TOOLS,
)


def test_builtin_tools_count():
    assert len(BUILTIN_TOOLS) == 6


def test_builtin_tools_have_required_fields():
    for tool in BUILTIN_TOOLS:
        assert "name" in tool
        assert "description" in tool
        assert "input_schema" in tool


def test_run_bash_success():
    result = run_bash("echo hello")
    assert "hello" in result


def test_run_bash_stderr():
    result = run_bash("echo err >&2")
    assert "err" in result


def test_run_bash_exit_code():
    result = run_bash("exit 1")
    assert "exit code: 1" in result


def test_run_bash_timeout():
    result = run_bash("sleep 10", timeout=1)
    assert "timed out" in result.lower() or "ERROR" in result


def test_run_read_file(tmp_path):
    f = tmp_path / "test.txt"
    f.write_text("hello\nworld\n")
    result = run_read_file(str(f))
    assert "hello" in result
    assert "world" in result


def test_run_read_file_lines(tmp_path):
    f = tmp_path / "test.txt"
    f.write_text("line1\nline2\nline3\n")
    result = run_read_file(str(f), start_line=2, end_line=3)
    assert "line2" in result
    assert "line1" not in result


def test_run_read_file_not_found():
    result = run_read_file("/nonexistent/file.txt")
    assert "ERROR" in result or "not found" in result.lower()


def test_run_write_file(tmp_path):
    f = tmp_path / "out.txt"
    result = run_write_file(str(f), "hello world")
    assert "✅" in result
    assert f.read_text() == "hello world"


def test_run_write_file_append(tmp_path):
    f = tmp_path / "out.txt"
    run_write_file(str(f), "line1\n")
    run_write_file(str(f), "line2\n", append=True)
    content = f.read_text()
    assert "line1" in content
    assert "line2" in content


def test_run_list_dir(tmp_path):
    (tmp_path / "file1.txt").write_text("a")
    (tmp_path / "file2.py").write_text("b")
    result = run_list_dir(str(tmp_path))
    assert "file1.txt" in result
    assert "file2.py" in result


def test_run_python_eval_print():
    result = run_python_eval("print('hello from eval')")
    assert "hello from eval" in result


def test_run_python_eval_math():
    result = run_python_eval("x = 6 * 7\nprint(x)")
    assert "42" in result


def test_run_python_eval_error():
    result = run_python_eval("raise ValueError('test error')")
    assert "ERROR" in result


def test_execute_tool_bash():
    result = execute_tool("bash", {"command": "echo dispatch_test"})
    assert "dispatch_test" in result


def test_execute_tool_python():
    result = execute_tool("python_eval", {"code": "print(1+1)"})
    assert "2" in result


def test_execute_tool_unknown():
    result = execute_tool("nonexistent_tool", {})
    assert "ERROR" in result or "Unknown" in result
