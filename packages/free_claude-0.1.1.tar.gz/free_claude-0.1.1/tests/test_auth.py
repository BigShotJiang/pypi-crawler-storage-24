"""Tests for free_claude.auth module."""
import json
import os
import pytest
import free_claude.config as config_module
from free_claude.auth import is_logged_in, ensure_config_dir


def test_token_file_path():
    assert config_module.TOKEN_FILE.endswith("token.json")
    assert ".free_claude" in config_module.TOKEN_FILE


def test_is_logged_in_false(tmp_path, monkeypatch):
    fake_token = str(tmp_path / "nonexistent_token.json")
    monkeypatch.setattr(config_module, "TOKEN_FILE", fake_token)
    # Also patch auth module's reference
    import free_claude.auth as auth_module
    monkeypatch.setattr(auth_module, "TOKEN_FILE", fake_token)
    assert is_logged_in() is False


def test_is_logged_in_true(tmp_path, monkeypatch):
    fake_token = tmp_path / "token.json"
    fake_token.write_text(json.dumps({"accessToken": "test_token", "refreshToken": None}))
    import free_claude.auth as auth_module
    monkeypatch.setattr(auth_module, "TOKEN_FILE", str(fake_token))
    assert is_logged_in() is True


def test_ensure_config_dir(tmp_path, monkeypatch):
    fake_token = str(tmp_path / "subdir" / "token.json")
    import free_claude.auth as auth_module
    monkeypatch.setattr(auth_module, "TOKEN_FILE", fake_token)
    ensure_config_dir()
    assert os.path.isdir(str(tmp_path / "subdir"))


def test_get_token_exits_when_not_logged_in(tmp_path, monkeypatch):
    fake_token = str(tmp_path / "no_token.json")
    import free_claude.auth as auth_module
    monkeypatch.setattr(auth_module, "TOKEN_FILE", fake_token)
    with pytest.raises(SystemExit):
        auth_module.get_token()


def test_get_token_returns_value(tmp_path, monkeypatch):
    fake_token = tmp_path / "token.json"
    fake_token.write_text(json.dumps({"accessToken": "my_access_token"}))
    import free_claude.auth as auth_module
    monkeypatch.setattr(auth_module, "TOKEN_FILE", str(fake_token))
    token = auth_module.get_token()
    assert token == "my_access_token"
