"""Tests for core/ modules: ContextManager, ToolExecutor, AppConfig, Logger."""
import pytest
from pathlib import Path


# ── ContextManager ─────────────────────────────────────────────────────────

class TestContextManager:
    def setup_method(self):
        from free_claude.core.context import ContextManager
        self.ctx = ContextManager()

    def test_add_and_get_messages(self):
        self.ctx.add_user("hello")
        self.ctx.add_assistant("hi")
        msgs = self.ctx.get()
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"
        assert msgs[1]["role"] == "assistant"

    def test_clear(self):
        self.ctx.add_user("hello")
        self.ctx.clear()
        assert self.ctx.get() == []

    def test_pop_last(self):
        self.ctx.add_user("hello")
        self.ctx.add_assistant("hi")
        self.ctx.pop_last()
        assert len(self.ctx.get()) == 1
        assert self.ctx.get()[0]["role"] == "user"

    def test_pop_last_empty(self):
        # Should not raise on empty
        self.ctx.pop_last()
        assert self.ctx.get() == []

    def test_track_usage(self):
        self.ctx.track_usage({"input_tokens": 100, "output_tokens": 50})
        self.ctx.track_usage({"input_tokens": 200, "output_tokens": 75})
        s = self.ctx.usage_summary()
        assert s["requests"] == 2
        assert s["input_tokens"] == 300
        assert s["output_tokens"] == 125
        assert s["total_tokens"] == 425

    def test_total_tokens_property(self):
        self.ctx.track_usage({"input_tokens": 10, "output_tokens": 5})
        assert self.ctx.total_tokens == 15

    def test_needs_trim_false_by_default(self):
        self.ctx.add_user("short message")
        assert not self.ctx.needs_trim()

    def test_needs_trim_true_when_large(self):
        from free_claude.core.context import _MAX_CONTEXT_CHARS
        # Add message that exceeds budget
        self.ctx.add_user("x" * (_MAX_CONTEXT_CHARS + 1000))
        assert self.ctx.needs_trim()

    def test_context_trimming(self):
        from free_claude.core.context import _MAX_CONTEXT_CHARS
        big = "x" * 100_000
        # Add many big messages to force trimming
        for i in range(10):
            self.ctx.add_user(big)
            self.ctx.add_assistant(big)

        total_before = sum(len(str(m.get("content", ""))) for m in self.ctx.messages)
        trimmed = self.ctx.get()
        total_after = sum(len(str(m.get("content", ""))) for m in trimmed)

        assert total_after <= _MAX_CONTEXT_CHARS
        assert len(trimmed) < len(self.ctx.messages)

    def test_trimming_keeps_at_least_two(self):
        self.ctx.add_user("short")
        self.ctx.add_assistant("reply")
        trimmed = self.ctx.get()
        assert len(trimmed) >= 1


# ── ToolExecutor ───────────────────────────────────────────────────────────

class TestToolExecutor:
    def setup_method(self):
        from free_claude.core.executor import ToolExecutor

        def fake_builtin(name, inputs):
            return f"result_of_{name}"

        self.executor = ToolExecutor([], fake_builtin)

    def _make_block(self, name, inputs=None, tool_id="test-id"):
        return {"name": name, "input": inputs or {}, "id": tool_id}

    def test_builtin_dispatch(self):
        out = self.executor.run(self._make_block("bash", {"command": "ls"}))
        assert out["result"] == "result_of_bash"
        assert out["dropped"] == 0
        assert out["name"] == "bash"
        assert out["detail"] == "ls"

    def test_payload_structure(self):
        out = self.executor.run(self._make_block("bash", {}, "my-id"))
        payload = out["payload"]
        assert payload["type"] == "tool_result"
        assert payload["tool_use_id"] == "my-id"
        assert isinstance(payload["content"], str)

    def test_mcp_not_found(self):
        out = self.executor.run(self._make_block("mcp_myserver_my_tool"))
        assert "ERROR" in out["result"]
        assert "myserver" in out["result"]

    def test_mcp_dispatch(self):
        class FakeClient:
            name = "myserver"
            def call_tool(self, tool_name, inputs):
                return f"mcp:{tool_name}"

        from free_claude.core.executor import ToolExecutor
        ex = ToolExecutor([FakeClient()], lambda n, i: "fallback")
        out = ex.run(self._make_block("mcp_myserver_do_something"))
        assert out["result"] == "mcp:do_something"

    def test_truncation(self):
        from free_claude.core.executor import _MAX_TOOL_RESULT_CHARS

        def big_result(name, inputs):
            return "A" * (_MAX_TOOL_RESULT_CHARS + 5000)

        from free_claude.core.executor import ToolExecutor
        ex = ToolExecutor([], big_result)
        out = ex.run(self._make_block("bash"))
        assert out["dropped"] == 5000
        assert "truncated" in out["result"]
        assert len(out["result"]) <= _MAX_TOOL_RESULT_CHARS + 200  # notice overhead

    def test_no_truncation_within_limit(self):
        from free_claude.core.executor import _MAX_TOOL_RESULT_CHARS

        def small_result(name, inputs):
            return "B" * (_MAX_TOOL_RESULT_CHARS - 1)

        from free_claude.core.executor import ToolExecutor
        ex = ToolExecutor([], small_result)
        out = ex.run(self._make_block("bash"))
        assert out["dropped"] == 0

    def test_keyboard_interrupt_handled(self):
        def interrupt(name, inputs):
            raise KeyboardInterrupt

        from free_claude.core.executor import ToolExecutor
        ex = ToolExecutor([], interrupt)
        out = ex.run(self._make_block("bash"))
        assert "INTERRUPTED" in out["result"]

    def test_detail_from_url(self):
        out = self.executor.run(self._make_block("web_fetch", {"url": "https://example.com"}))
        assert out["detail"] == "https://example.com"

    def test_detail_from_path(self):
        out = self.executor.run(self._make_block("read_file", {"path": "/tmp/foo.txt"}))
        assert out["detail"] == "/tmp/foo.txt"


# ── AppConfig ──────────────────────────────────────────────────────────────

class TestAppConfig:
    def setup_method(self):
        # Reset singleton state
        from free_claude.app_config import AppConfig
        AppConfig._instance = None
        from free_claude import app_config as mod
        mod.config._loaded = False
        mod.config._data = {}

    def test_defaults_before_load(self):
        from free_claude.app_config import AppConfig, DEFAULTS
        cfg = AppConfig()
        # get() triggers load()
        assert cfg.get("theme") in ("dark", "light", "minimal")

    def test_default_values(self):
        from free_claude.app_config import AppConfig, DEFAULTS
        AppConfig._instance = None
        cfg = AppConfig()
        cfg._data = {}
        cfg._loaded = True
        for k, v in DEFAULTS.items():
            assert cfg.get(k) == v

    def test_set_and_get(self):
        from free_claude.app_config import AppConfig
        AppConfig._instance = None
        cfg = AppConfig()
        cfg._data = {}
        cfg._loaded = True
        cfg.set("model", "opus4")
        assert cfg.get("model") == "opus4"

    def test_toml_parsing(self):
        from free_claude.app_config import _parse_toml
        text = """
# comment
model = "opus4"
max_tool_iterations = 20
auto_load_plugins = false
log_level = "DEBUG"
"""
        result = _parse_toml(text)
        assert result["model"] == "opus4"
        assert result["max_tool_iterations"] == 20
        assert result["auto_load_plugins"] is False
        assert result["log_level"] == "DEBUG"

    def test_toml_booleans(self):
        from free_claude.app_config import _parse_toml
        result = _parse_toml("flag1 = true\nflag2 = false")
        assert result["flag1"] is True
        assert result["flag2"] is False

    def test_toml_ignores_comments_and_blanks(self):
        from free_claude.app_config import _parse_toml
        result = _parse_toml("# This is a comment\n\nmodel = \"haiku\"")
        assert result == {"model": "haiku"}

    def test_properties(self):
        from free_claude.app_config import AppConfig
        AppConfig._instance = None
        cfg = AppConfig()
        cfg._data = {
            "model": "opus4",
            "theme": "light",
            "max_tool_iterations": 10,
            "log_level": "DEBUG",
            "auto_load_plugins": False,
            "show_token_usage": True,
            "system_prompt": "Custom prompt",
        }
        cfg._loaded = True
        assert cfg.model == "opus4"
        assert cfg.theme == "light"
        assert cfg.max_tool_iterations == 10
        assert cfg.log_level == "DEBUG"
        assert cfg.auto_load_plugins is False
        assert cfg.show_token_usage is True
        assert cfg.system_prompt == "Custom prompt"


# ── Logger ─────────────────────────────────────────────────────────────────

class TestLogger:
    def test_log_instance_exists(self):
        from free_claude.logger import log
        import logging
        assert isinstance(log, logging.Logger)
        assert log.name == "free-claude"

    def test_get_logger(self):
        from free_claude.logger import get_logger
        import logging
        child = get_logger("test")
        assert isinstance(child, logging.Logger)
        assert "free-claude.test" in child.name

    def test_log_methods_work(self):
        from free_claude.logger import log
        # Should not raise
        log.debug("debug message")
        log.info("info message")
        log.warning("warning message")
        log.error("error message")

    def test_log_file_location(self):
        from free_claude.logger import _LOG_FILE
        # Log file path should be in user's home
        assert str(Path.home()) in str(_LOG_FILE)
