# Changelog

All notable changes to this project will be documented in this file.

## [0.1.1] - 2026-03-26

### Added
- **fclaude-set-token command** - Manual token setup for users who cannot use browser-based login
- **FREE_CLAUDE_TOKEN environment variable** - Support for token via environment variable (takes precedence over file)
- **Cross-platform token setup** - Instructions for Mac, Linux, and Windows

### Fixed
- **401 error on client machines** - Fixed refresh_token() to gracefully handle missing OAuth config
- **Token refresh without OAuth** - Now falls back to existing token when OAuth config is unavailable

### Changed
- Error message now suggests both `fclaude-login` and `fclaude-set-token`
- README updated with 3 methods for token setup

## [0.1.0] - 2025-03-25

### Initial Release
- Free Claude AI agent with HFI API support
- Built-in tools (bash, file operations, web fetch, python eval)
- MCP (Model Context Protocol) support
- Extended thinking mode
- Session management
- Multi-agent teams
- Long-term memory

