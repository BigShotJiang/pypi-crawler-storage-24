"""Data models for nimbus-core SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class FindingInput:
    """A security finding to get remediation for."""

    title: str
    description: str
    severity: str = "HIGH"
    source: str = "direct_check"
    service: str = "general"
    resource_arn: Optional[str] = None
    resource_id: Optional[str] = None
    region: Optional[str] = None
    recommendation: Optional[str] = None
    details: Optional[dict[str, Any]] = None


@dataclass
class RemediationResult:
    """Result from a remediation request."""

    remediation: str
    normalized_finding: dict[str, Any]


@dataclass
class InitResult:
    """Result from infrastructure provisioning."""

    account_id: str
    region: str
    kb_id: str
    docs_bucket: str = ""
    vector_bucket: str = ""
    ds_id: str = ""
