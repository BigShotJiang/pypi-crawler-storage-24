# nimbus-core

Nimbus AWS Security SDK — Bedrock RAG remediation and infrastructure provisioning.

## Install

```bash
pip install nimbus-core
```

## Prerequisites

- AWS credentials configured (`aws configure` or env vars)
- Bedrock model access enabled:
  - `amazon.titan-embed-text-v2:0`
  - `anthropic.claude-haiku-4-5-20251001-v1:0`

## Quick Start

### With an existing Knowledge Base

```python
from nimbus_core import NimbusClient

client = NimbusClient(region="us-east-1", kb_id="YOUR_KB_ID")
result = client.suggest_fix("S3 bucket is publicly accessible")
print(result.remediation)
```

### Provision a new Knowledge Base first

```python
from nimbus_core import NimbusClient

client = NimbusClient(region="us-east-1")
client.init()  # creates S3 bucket, vectors, Bedrock KB, uploads docs

result = client.suggest_fix("EC2 instance has no IMDSv2 enforced")
print(result.remediation)
```

### Structured finding input

```python
from nimbus_core import NimbusClient, FindingInput

client = NimbusClient(region="us-east-1", kb_id="YOUR_KB_ID")

finding = FindingInput(
    title="Public S3 Bucket",
    description="S3 bucket my-bucket has public read access enabled",
    severity="HIGH",
    service="s3",
    resource_arn="arn:aws:s3:::my-bucket",
)
result = client.suggest_fix_for_finding(finding)
print(result.remediation)
```
