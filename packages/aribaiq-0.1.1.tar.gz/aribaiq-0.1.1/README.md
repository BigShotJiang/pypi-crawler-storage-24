# aribaiq

**aribaiq** is an open-source Python library for **AI-powered procurement, sourcing, and supplier intelligence analytics**.

It is designed to help teams turn raw sourcing or ERP-exported data into practical insights through:

- supplier intelligence scoring
- spend visibility and optimization signals
- ESG-aware evaluation
- responsible AI checks
- AI-ready prompt generation for copilots and LLM workflows

The package is lightweight, vendor-neutral, and suitable for analytics teams, engineers, procurement strategists, and open-source developers building modern source-to-pay intelligence solutions.

---

## Why aribaiq?

Procurement teams often have large datasets but limited decision visibility.

Common challenges include:

- inconsistent supplier performance evaluation
- difficulty identifying concentration risk
- scattered ESG and compliance indicators
- limited explainability in AI-assisted sourcing decisions
- manual effort in turning analytics into executive summaries

**aribaiq** helps solve these problems with transparent analytics, governance-aware checks, and AI-ready outputs.

---

## Core Features

### Supplier intelligence scoring
Ranks suppliers using business-relevant signals such as:
- on-time rate
- defect rate
- ESG score
- spend concentration

### Spend analytics
Highlights:
- category concentration
- supplier spread
- consolidation opportunities
- single-supplier exposure

### ESG scoring
Provides weighted ESG evaluation support for suppliers.

### Responsible AI checks
Includes:
- missingness checks
- invalid value detection
- representation imbalance warnings

### GenAI-ready prompts
Builds provider-agnostic prompts for:
- internal copilots
- chat assistants
- LLM-based reporting pipelines

### CLI included
Run analytics directly on CSV, JSON, or JSONL files.

---

## Installation

```bash
pip install aribaiq
```

## Author
Jagadeesh Vasanthada

## LICENSE

MIT License

Copyright (c) 2026

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


