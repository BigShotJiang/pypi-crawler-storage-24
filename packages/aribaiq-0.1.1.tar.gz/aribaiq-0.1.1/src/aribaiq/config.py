from pydantic import BaseModel, Field


class AribaIQConfig(BaseModel):
    default_currency: str = Field(default="USD")
    governance_enabled: bool = Field(default=True)
    concentration_threshold: float = Field(default=0.40)
