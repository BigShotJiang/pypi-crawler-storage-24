import pandas as pd


def spend_summary(df: pd.DataFrame) -> pd.DataFrame:
    required = {"supplier_id", "annual_spend"}
    if not required.issubset(df.columns):
        return pd.DataFrame(columns=["supplier_id", "annual_spend"])

    grouped = (
        df.groupby("supplier_id", dropna=False)
        .agg(annual_spend=("annual_spend", "sum"))
        .reset_index()
        .sort_values("annual_spend", ascending=False)
    )
    return grouped
