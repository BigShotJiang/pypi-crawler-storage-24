import pandas as pd


def supplier_concentration(df: pd.DataFrame) -> pd.DataFrame:
    if "category" not in df.columns or "annual_spend" not in df.columns:
        return pd.DataFrame(
            columns=["category", "supplier_count", "total_spend", "signal"]
        )

    grouped = (
        df.groupby("category", dropna=False)
        .agg(
            supplier_count=("supplier_id", "nunique"),
            total_spend=("annual_spend", "sum"),
        )
        .reset_index()
    )

    def classify(row: pd.Series) -> str:
        if row["supplier_count"] == 1 and row["total_spend"] > 250000:
            return "Single-supplier exposure"
        if row["supplier_count"] >= 5 and row["total_spend"] > 100000:
            return "Consolidation opportunity"
        return "Monitor"

    grouped["signal"] = grouped.apply(classify, axis=1)
    return grouped.sort_values("total_spend", ascending=False).reset_index(drop=True)
