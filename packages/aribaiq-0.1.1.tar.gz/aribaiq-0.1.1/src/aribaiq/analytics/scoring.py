import numpy as np
import pandas as pd


def score_suppliers(features: pd.DataFrame) -> pd.DataFrame:
    score = (
        0.30 * (1.0 - features["late_risk"].clip(0, 1))
        + 0.25 * (1.0 - features["quality_risk"].clip(0, 1))
        + 0.20 * (1.0 - features["esg_risk"].clip(0, 1))
        + 0.15 * (1.0 - features["spend_share"].clip(0, 1))
        + 0.10 * np.minimum(features["category_count"] / 5.0, 1.0)
    )

    out = pd.DataFrame(
        {
            "supplier_id": features.index.astype(str),
            "aiq_score": (score * 100.0).round(2),
            "late_risk": features["late_risk"].round(4),
            "quality_risk": features["quality_risk"].round(4),
            "esg_risk": features["esg_risk"].round(4),
            "spend_share": features["spend_share"].round(4),
        }
    )

    return out.sort_values("aiq_score", ascending=False).reset_index(drop=True)
