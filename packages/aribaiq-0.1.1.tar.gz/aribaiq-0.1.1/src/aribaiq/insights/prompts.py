from typing import Any, Dict


def build_genai_prompt(results: Dict[str, Any]) -> str:
    return (
        "You are an AI procurement and sourcing advisor.\n\n"
        f"ANALYTICS_RESULTS:\n{results}\n\n"
        "Generate:\n"
        "1) Top supplier risks\n"
        "2) Top sourcing opportunities\n"
        "3) Spend optimization recommendations\n"
        "4) ESG and governance observations\n"
        "Use concise executive language."
    )
