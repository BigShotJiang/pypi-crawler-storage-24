from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class InsightCard:
    title: str
    summary: str
    data: Dict[str, Any]


def render_cards(cards: List[InsightCard]) -> str:
    lines = []
    for idx, card in enumerate(cards, 1):
        lines.append(f"{idx}. {card.title}\n   {card.summary}")
    return "\n".join(lines)
