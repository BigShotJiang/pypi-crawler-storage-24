class AribaIQError(Exception):
    """Base exception for aribaiq."""


class DataValidationError(AribaIQError):
    """Raised when input data is invalid."""


class AnalyticsError(AribaIQError):
    """Raised when analytics computation fails."""
