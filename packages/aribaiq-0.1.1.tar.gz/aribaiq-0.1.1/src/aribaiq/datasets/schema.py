from typing import Optional
from pydantic import BaseModel


class SupplierRecord(BaseModel):
    supplier_id: str
    country: Optional[str] = None
    category: Optional[str] = None
    annual_spend: Optional[float] = None
    esg_score: Optional[float] = None
    on_time_rate: Optional[float] = None
    defect_rate: Optional[float] = None
