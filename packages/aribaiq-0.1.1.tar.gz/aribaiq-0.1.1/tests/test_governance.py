import pandas as pd
from aribaiq.governance.responsible_ai import (
    data_quality_report,
    representation_proxy_check,
)


def test_governance_checks():
    df = pd.DataFrame(
        {
            "supplier_id": ["A", "B", "C", "D"],
            "country": ["US", "US", "US", "US"],
            "esg_score": [95, None, 120, 88],
        }
    )

    dq = data_quality_report(df)
    rep = representation_proxy_check(df)

    assert len(dq) >= 1
    assert len(rep) >= 1
