import pandas as pd
from aribaiq.analytics.features import build_supplier_features
from aribaiq.analytics.scoring import score_suppliers


def test_score_suppliers():
    df = pd.DataFrame(
        {
            "supplier_id": ["A", "B"],
            "annual_spend": [100000, 200000],
            "esg_score": [90, 50],
            "on_time_rate": [0.95, 0.75],
            "defect_rate": [0.01, 0.05],
            "category": ["IT", "Hardware"],
        }
    )

    features = build_supplier_features(df)
    ranked = score_suppliers(features)

    assert len(ranked) == 2
    assert "aiq_score" in ranked.columns
