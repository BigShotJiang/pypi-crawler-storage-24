"""
Spec loader and chain scanner.

Reads YAML migration specs and provides detection/verification logic
that all MCP tools share.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from functools import cmp_to_key, lru_cache
from pathlib import Path
from typing import Any

import yaml


# ── Paths ────────────────────────────────────────────────────────────────────

MCP_DIR = Path(__file__).parent
SPEC_DIR = MCP_DIR / "migration_spec" / "v50-to-v54"
DOCS_DIR = MCP_DIR / "docs"
UPGRADING_FILE = DOCS_DIR / "UPGRADING.md"
CHANGELOG_FILE = DOCS_DIR / "CHANGELOG.md"
RELEASE_NOTES_FILE = DOCS_DIR / "RELEASE_NOTES.md"


# ── Spec loading ──────────────────────────────────────────────────────────────


@dataclass
class Spec:
    """A parsed migration spec."""

    id: str
    title: str
    version: str
    description: str
    raw: dict[str, Any]

    # Detection
    detection_imports: list[str] = field(default_factory=list)
    detection_patterns: list[str] = field(default_factory=list)
    detection_files: list[str] = field(default_factory=list)
    detection_go_mod: list[str] = field(default_factory=list)
    detection_min_sdk_version: str = ""
    detection_max_sdk_version_exclusive: str = ""

    # Changes
    changes: dict[str, Any] = field(default_factory=dict)

    # Manual steps
    manual_steps: list[dict[str, str]] = field(default_factory=list)

    # Verification
    verification: dict[str, Any] = field(default_factory=dict)

    @property
    def has_fatal_warnings(self) -> bool:
        warnings = _mapping(self.changes.get("imports")).get("warnings", [])
        return any(w.get("fatal", False) for w in warnings)

    @property
    def fatal_message(self) -> str:
        warnings = _mapping(self.changes.get("imports")).get("warnings", [])
        for warning in warnings:
            if warning.get("fatal", False):
                return warning.get("message", "")
        return ""


def _mapping(value: Any) -> dict[str, Any]:
    """Normalize optional YAML mapping sections to empty dicts."""
    if isinstance(value, dict):
        return value
    return {}


def _normalize_manual_steps(raw_steps: Any) -> list[dict[str, str]]:
    """Accept both string and object manual-step forms."""
    normalized: list[dict[str, str]] = []
    for index, step in enumerate(raw_steps or [], start=1):
        if isinstance(step, str):
            description = step.strip()
            if description:
                normalized.append(
                    {
                        "id": f"manual-step-{index}",
                        "description": description,
                    }
                )
            continue

        if not isinstance(step, dict):
            continue

        description = str(step.get("description", "")).strip()
        if not description:
            continue

        normalized.append(
            {
                "id": str(step.get("id") or f"manual-step-{index}"),
                "description": description,
            }
        )

    return normalized


@lru_cache(maxsize=None)
def _load_specs_cached(directory: str) -> tuple[Spec, ...]:
    specs = []
    for spec_file in sorted(Path(directory).glob("*.yaml")):
        with spec_file.open() as handle:
            raw = _mapping(yaml.safe_load(handle))

        detection = _mapping(raw.get("detection"))
        sdk_version = _mapping(detection.get("sdk_version"))
        specs.append(
            Spec(
                id=raw["id"],
                title=raw["title"],
                version=raw.get("version", ""),
                description=raw.get("description", ""),
                raw=raw,
                detection_imports=detection.get("imports", []),
                detection_patterns=detection.get("patterns", []),
                detection_files=detection.get("files", []),
                detection_go_mod=detection.get("go_mod", []),
                detection_min_sdk_version=str(sdk_version.get("min_inclusive", "")),
                detection_max_sdk_version_exclusive=str(sdk_version.get("max_exclusive", "")),
                changes=_mapping(raw.get("changes")),
                manual_steps=_normalize_manual_steps(raw.get("manual_steps", [])),
                verification=_mapping(raw.get("verification")),
            )
        )
    return tuple(specs)


def load_specs(spec_dir: Path | None = None) -> list[Spec]:
    """Load all YAML specs from the spec directory."""
    directory = str((spec_dir or SPEC_DIR).resolve())
    return list(_load_specs_cached(directory))


# ── Spec ordering ─────────────────────────────────────────────────────────────

SPEC_ORDER = [
    "group-enterprise-migration",     # fatal check first
    "core-sdk-migration",             # broad dependency/import rewrites first
    "store-v2-migration",
    "bank-endblock-order",
    "crisis-removal",
    "circuit-contrib-migration",
    "nft-contrib-migration",
    "gov-keeper-migration",
    "gov-hooks-proposer-arg",
    "validator-power-rename",
    "epochs-keeper-pointer",
    "epochs-app-module-pointer",
    "ante-handler-simplification",
    "app-structure-cleanup",
    "sr25519-removal-warning",        # advisory-only warnings
    "otel-migration-warning",
    "block-gas-meter-warning",
]


def order_specs(specs: list[Spec]) -> list[Spec]:
    """Sort specs into the correct application order."""
    order_map = {spec_id: index for index, spec_id in enumerate(SPEC_ORDER)}
    return sorted(specs, key=lambda spec: order_map.get(spec.id, 999))


# ── File discovery ────────────────────────────────────────────────────────────


def _iter_files(
    directory: str,
    *,
    suffixes: tuple[str, ...] | None = None,
    include_names: set[str] | None = None,
) -> list[str]:
    """List files under a directory tree with optional filtering."""
    results: list[str] = []
    include_names = include_names or set()
    for root, _, files in os.walk(directory):
        for name in files:
            if suffixes is not None and not name.endswith(suffixes) and name not in include_names:
                continue
            if suffixes is None and include_names and name not in include_names:
                continue
            results.append(os.path.join(root, name))
    return sorted(results)


def list_go_files(directory: str) -> list[str]:
    """List Go source files under a directory."""
    return _iter_files(directory, suffixes=(".go",))


def list_go_mod_files(directory: str) -> list[str]:
    """List go.mod files under a directory."""
    return _iter_files(directory, include_names={"go.mod"})


def _read_file(path: str) -> str:
    return Path(path).read_text(errors="replace")


def _search_files(
    paths: list[str],
    pattern: str,
    *,
    literal: bool = False,
    max_results: int = 50,
) -> list[str]:
    """Search a list of files for a pattern."""
    if not pattern:
        return []

    regex = re.compile(re.escape(pattern) if literal else pattern, re.MULTILINE)
    matches: list[str] = []

    for path in paths:
        try:
            content = _read_file(path)
        except OSError:
            continue

        if regex.search(content):
            matches.append(path)
            if len(matches) >= max_results:
                break

    return matches


def _find_named_files(directory: str, names: list[str], max_results: int = 50) -> list[str]:
    """Find files by exact filename match."""
    targets = set(names)
    matches: list[str] = []
    for path in _iter_files(directory):
        if os.path.basename(path) in targets:
            matches.append(path)
            if len(matches) >= max_results:
                break
    return matches


@dataclass
class SDKVersionResult:
    """Result of SDK version detection."""

    version: str
    detection_note: str = ""


def _detect_sdk_version(chain_dir: str) -> SDKVersionResult:
    """Parse go.mod to find the SDK version.

    Returns a structured result with the version string and an optional
    diagnostic note explaining *why* detection failed or was ambiguous.
    """
    go_mod_files = list_go_mod_files(chain_dir)
    if not go_mod_files:
        return SDKVersionResult("unknown", "no go.mod files found in the directory tree")

    # Check root go.mod first, then sub-modules
    root_go_mod = os.path.join(chain_dir, "go.mod")
    ordered = sorted(go_mod_files, key=lambda p: (p != root_go_mod, p))

    for go_mod_path in ordered:
        content = _read_file(go_mod_path)

        # Detect if this IS the SDK itself
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("module ") and "github.com/cosmos/cosmos-sdk" in stripped:
                return SDKVersionResult(
                    "unknown",
                    f"module path is github.com/cosmos/cosmos-sdk in {os.path.relpath(go_mod_path, chain_dir)}; "
                    "this appears to be the SDK itself rather than a dependent chain",
                )

        for line in content.splitlines():
            stripped = line.strip()
            if "github.com/cosmos/cosmos-sdk" not in stripped or stripped.startswith("//"):
                continue
            for part in stripped.split():
                if part.startswith("v0."):
                    return SDKVersionResult(part)

    return SDKVersionResult(
        "unknown",
        "github.com/cosmos/cosmos-sdk dependency not found in any go.mod file",
    )


def _parse_semver(version: str) -> tuple[tuple[int, int, int], list[str | int] | None] | None:
    cleaned = version.strip()
    if not cleaned or cleaned == "unknown":
        return None

    cleaned = cleaned.split("+", 1)[0]
    match = re.match(
        r"^v?(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)(?:-(?P<prerelease>[0-9A-Za-z.-]+))?$",
        cleaned,
    )
    if not match:
        return None

    prerelease = match.group("prerelease")
    prerelease_parts: list[str | int] | None = None
    if prerelease:
        prerelease_parts = [
            int(part) if part.isdigit() else part
            for part in prerelease.split(".")
        ]

    return (
        (
            int(match.group("major")),
            int(match.group("minor")),
            int(match.group("patch")),
        ),
        prerelease_parts,
    )


def _compare_semver(left: str, right: str) -> int:
    parsed_left = _parse_semver(left)
    parsed_right = _parse_semver(right)

    if parsed_left is None and parsed_right is None:
        return 0
    if parsed_left is None:
        return -1
    if parsed_right is None:
        return 1

    left_main, left_prerelease = parsed_left
    right_main, right_prerelease = parsed_right

    if left_main != right_main:
        return -1 if left_main < right_main else 1

    if left_prerelease is None and right_prerelease is None:
        return 0
    if left_prerelease is None:
        return 1
    if right_prerelease is None:
        return -1

    for left_part, right_part in zip(left_prerelease, right_prerelease):
        if left_part == right_part:
            continue

        left_numeric = isinstance(left_part, int)
        right_numeric = isinstance(right_part, int)
        if left_numeric and right_numeric:
            return -1 if left_part < right_part else 1
        if left_numeric != right_numeric:
            return -1 if left_numeric else 1
        return -1 if str(left_part) < str(right_part) else 1

    if len(left_prerelease) == len(right_prerelease):
        return 0
    return -1 if len(left_prerelease) < len(right_prerelease) else 1


def semver_sort_desc(versions: list[str]) -> list[str]:
    return sorted(versions, key=cmp_to_key(_compare_semver), reverse=True)


def sdk_version_matches(spec: Spec, sdk_version: str) -> bool:
    if sdk_version == "unknown":
        return True

    if (
        spec.detection_min_sdk_version
        and _compare_semver(sdk_version, spec.detection_min_sdk_version) < 0
    ):
        return False

    if (
        spec.detection_max_sdk_version_exclusive
        and _compare_semver(sdk_version, spec.detection_max_sdk_version_exclusive) >= 0
    ):
        return False

    return True


# ── Chain scanning ────────────────────────────────────────────────────────────


@dataclass
class ScanResult:
    """Result of scanning a chain directory."""

    chain_dir: str
    sdk_version: str
    applicable_specs: list[str]
    warnings: list[dict[str, str]]
    fatal_blocks: list[dict[str, str]]
    detection_details: dict[str, dict[str, list[str]]]
    detection_note: str = ""
    fatal_spec_ids: list[str] = field(default_factory=list)
    application_order: list[str] = field(default_factory=list)


def scan_chain(chain_dir: str, specs: list[Spec] | None = None) -> ScanResult:
    """
    Scan a chain directory and determine which specs apply.

    Returns a structured result with SDK version, applicable specs,
    warnings, and fatal blocks.  Fatal-blocked specs appear in both
    ``applicable_specs`` (for backward compat) and ``fatal_spec_ids``.
    The ``application_order`` field contains non-fatal applicable specs
    in the correct sequence.
    """
    specs = specs or load_specs()

    version_result = _detect_sdk_version(chain_dir)
    sdk_version = version_result.version
    applicable: list[str] = []
    warnings: list[dict[str, str]] = []
    fatal_blocks: list[dict[str, str]] = []
    fatal_spec_ids: list[str] = []
    details: dict[str, dict[str, list[str]]] = {}

    go_files = list_go_files(chain_dir)
    go_mod_files = list_go_mod_files(chain_dir)
    warning_keys: set[tuple[str, str]] = set()

    for spec in order_specs(specs):
        if not sdk_version_matches(spec, sdk_version):
            continue

        matched_imports = _search_files(
            go_files,
            "|".join(re.escape(imp) for imp in spec.detection_imports),
            max_results=50,
        ) if spec.detection_imports else []

        matched_patterns = _search_files(
            go_files,
            "|".join(re.escape(pattern) for pattern in spec.detection_patterns),
            max_results=50,
        ) if spec.detection_patterns else []

        matched_files = _find_named_files(chain_dir, spec.detection_files) if spec.detection_files else []

        matched_go_mod = []
        if spec.detection_go_mod:
            matched_go_mod = _search_files(
                go_mod_files,
                "|".join(re.escape(entry) for entry in spec.detection_go_mod),
                max_results=50,
            )

        if matched_imports or matched_patterns or matched_files or matched_go_mod:
            applicable.append(spec.id)
            details[spec.id] = {
                "matched_imports": [os.path.relpath(path, chain_dir) for path in matched_imports],
                "matched_patterns": [os.path.relpath(path, chain_dir) for path in matched_patterns],
                "matched_files": [os.path.relpath(path, chain_dir) for path in matched_files],
                "matched_go_mod": [os.path.relpath(path, chain_dir) for path in matched_go_mod],
            }

            if spec.has_fatal_warnings:
                fatal_blocks.append(
                    {"spec_id": spec.id, "message": spec.fatal_message}
                )
                fatal_spec_ids.append(spec.id)

            for warning in _mapping(spec.changes.get("imports")).get("warnings", []):
                if not warning.get("fatal", False):
                    key = (spec.id, warning.get("message", ""))
                    if key in warning_keys:
                        continue
                    warning_keys.add(key)
                    warnings.append({"spec_id": spec.id, "message": key[1]})

    application_order = [sid for sid in applicable if sid not in fatal_spec_ids]

    return ScanResult(
        chain_dir=chain_dir,
        sdk_version=sdk_version,
        applicable_specs=applicable,
        warnings=warnings,
        fatal_blocks=fatal_blocks,
        detection_details=details,
        detection_note=version_result.detection_note,
        fatal_spec_ids=fatal_spec_ids,
        application_order=application_order,
    )


# ── Verification ──────────────────────────────────────────────────────────────


@dataclass
class VerifyResult:
    """Result of verifying a spec against a directory."""

    spec_id: str
    passed: bool
    failures: list[str]


def verify_spec(spec: Spec, chain_dir: str) -> VerifyResult:
    """Run verification checks for a single spec."""
    failures: list[str] = []
    verification = spec.verification
    go_files = list_go_files(chain_dir)

    for import_path in verification.get("must_not_import", []):
        files = _search_files(go_files, f'"{import_path}"', literal=True)
        if files:
            short = [os.path.relpath(path, chain_dir) for path in files[:3]]
            failures.append(
                f"must_not_import '{import_path}' found in: {', '.join(short)}"
            )

    failures.extend(
        _check_content_rules(
            verification.get("must_not_contain", []),
            chain_dir=chain_dir,
            go_files=go_files,
            should_exist=False,
        )
    )
    failures.extend(
        _check_content_rules(
            verification.get("must_contain", []),
            chain_dir=chain_dir,
            go_files=go_files,
            should_exist=True,
        )
    )

    return VerifyResult(
        spec_id=spec.id,
        passed=not failures,
        failures=failures,
    )


def _check_content_rules(
    entries: list[Any],
    *,
    chain_dir: str,
    go_files: list[str],
    should_exist: bool,
) -> list[str]:
    failures: list[str] = []

    for entry in entries:
        pattern, file_match, exclude_file_match = _parse_content_rule(entry)
        if not pattern:
            continue

        files = _matching_content_files(go_files, chain_dir, pattern, file_match, exclude_file_match)
        if should_exist:
            if not files:
                failures.append(f"must_contain '{pattern}' not found anywhere")
            continue

        if files:
            short = [os.path.relpath(path, chain_dir) for path in files[:3]]
            failures.append(
                f"must_not_contain '{pattern}' found in: {', '.join(short)}"
            )

    return failures


def _parse_content_rule(entry: Any) -> tuple[str, str, str]:
    """Return (pattern, file_match, exclude_file_match)."""
    if isinstance(entry, str):
        return entry, "", ""
    if isinstance(entry, dict):
        return (
            entry.get("pattern", ""),
            entry.get("file_match", ""),
            entry.get("exclude_file_match", ""),
        )
    return "", "", ""


def _matching_content_files(
    go_files: list[str],
    chain_dir: str,
    pattern: str,
    file_match: str,
    exclude_file_match: str = "",
) -> list[str]:
    files = _search_files(go_files, pattern, literal=True)
    if file_match:
        files = [
            path for path in files
            if os.path.relpath(path, chain_dir).endswith(file_match)
        ]
    if exclude_file_match:
        files = [
            path for path in files
            if not os.path.relpath(path, chain_dir).endswith(exclude_file_match)
        ]
    return files
