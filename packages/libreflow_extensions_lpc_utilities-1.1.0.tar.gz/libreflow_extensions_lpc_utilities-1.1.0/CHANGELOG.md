# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)[^1].

<!---
Types of changes

- Added for new features.
- Changed for changes in existing functionality.
- Deprecated for soon-to-be removed features.
- Removed for now removed features.
- Fixed for any bug fixes.
- Security in case of vulnerabilities.

-->

## [Unreleased]

## [1.1.0] - 2026-03-23

### Added

* An action to render a sequence from a Blender file using the Storyliner add-on
  * Individual shots are stored in a `TrackedFolder`
  * Then, a full-length movie can be generated from those individual shots
    * This specific step has an associated action that is available on a `TrackedFolder`

### Changed

* Expand the asset family map by default.

## [1.0.0] - 2026-02-21

### Added

* initial release: handle asset families for create kitsu assets actions
  * assets map for an asset type is hidden for now