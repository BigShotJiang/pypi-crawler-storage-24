# VaultAgent core module
