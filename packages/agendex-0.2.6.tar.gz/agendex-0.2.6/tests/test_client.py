"""Tests for AgendexClient."""
import json
import pytest
from unittest.mock import Mock, patch, MagicMock
import os
import requests

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agendex import AgendexClient
from agendex.errors import AgendexError, DeniedError, PendingApprovalError, ConfigurationError


class TestAgendexClient:
    """Test AgendexClient functionality."""
    
    def test_init_from_params(self):
        """Test initialization with explicit parameters."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='shadow'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )
        
        assert client.base_url == "http://test:8000"
        assert client.agent_id == "test_agent"
        assert client.mode == "shadow"

    def test_headers_include_tenant_id_when_set(self):
        """Tenant header should be sent when tenant_id is configured."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='shadow'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
                tenant_id="tenant-a",
            )

        headers = client._headers()
        assert headers["X-Agendex-Tenant-Id"] == "tenant-a"
    
    def test_init_missing_agent_id_raises(self):
        """Test that missing agent_id raises ConfigurationError."""
        with pytest.raises(ConfigurationError) as exc_info:
            AgendexClient(
                base_url="http://test:8000",
                agent_id=None,
                token="test_token",
            )
        assert "agent_id is required" in str(exc_info.value)
    
    def test_init_missing_token_raises(self):
        """Test that missing token raises ConfigurationError."""
        # Ensure no environment token is accidentally picked up.
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ConfigurationError) as exc_info:
                AgendexClient(
                    base_url="http://test:8000",
                    agent_id="test_agent",
                    token=None,
                )
        assert "token is required" in str(exc_info.value)

    def test_init_relative_base_url_raises(self):
        """Relative URLs like /api are browser-only and invalid for the SDK."""
        with pytest.raises(ConfigurationError) as exc_info:
            AgendexClient(
                base_url="/api",
                agent_id="test_agent",
                token="test_token",
            )
        assert "absolute URL" in str(exc_info.value)

    def test_init_absolute_api_prefix_url_is_allowed(self):
        """Absolute URLs may still include an /api prefix when routed through a proxy."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='shadow'):
            client = AgendexClient(
                base_url="https://dashboard.example.com/api",
                agent_id="test_agent",
                token="test_token",
            )

        assert client.base_url == "https://dashboard.example.com/api"
    
    def test_invoke_shadow_mode(self):
        """Test invoke in shadow mode returns a non-blocking future envelope."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='shadow'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        mock_eval = Mock(ok=True)
        mock_eval.status_code = 200
        mock_eval.json = Mock(return_value={
            "decision": {"outcome": "would_allow", "reason": "Matched rule"},
            "request_id": "req-shadow",
            "latency_ms": 14.0,
        })

        with patch("agendex.client.requests.post", return_value=mock_eval) as mock_post:
            result = client.invoke(
                action="tool.test",
                params={"key": "value"},
                task="test_task",
                context={"user_id": "user-123", "chat_id": "chat-xyz", "reasoning": "Need tool access"},
                trace_id="trace-1",
                span_id="span-1",
                parent_span_id="span-0",
                actor="assistant:ops",
            )

            assert result["_agendex"] == "shadow"
            assert result["decision"] == "pending"
            assert result["execute"] is True
            bg_result = result["_shadow_future"].result(timeout=5)
            assert bg_result["decision"] == "would_allow"
            assert bg_result["server_latency_ms"] == 14.0

        payload = mock_post.call_args.kwargs["json"]
        decision_context = payload["context"]["decision_context"]
        supporting_context = payload["context"]["supporting_context"]
        assert decision_context["decision_type"] == "tool_call"
        assert decision_context["user_id"] == "user-123"
        assert decision_context["session_id"] == "chat-xyz"
        assert decision_context["tool_action_intent"] == "tool.test"
        assert decision_context["trace_id"] == "trace-1"
        assert supporting_context["tool_args"] == {"key": "value"}
        assert supporting_context["tool_call_payload"]["action"] == "tool.test"

    def test_invoke_shadow_mode_emits_latency_events(self):
        """Shadow mode should emit the normalized decision payload from the background call."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='shadow'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        events = []
        mock_eval = Mock(ok=True)
        mock_eval.status_code = 200
        mock_eval.json = Mock(return_value={
            "decision": {"outcome": "would_allow", "reason": "Matched rule"},
            "request_id": "req-shadow",
            "latency_ms": 11.5,
        })

        with patch("agendex.client.requests.post", return_value=mock_eval):
            result = client.invoke(
                action="tool.test",
                params={"key": "value"},
                task="test_task",
                context={"user_id": "user-123", "chat_id": "chat-xyz"},
                on_event=events.append,
            )
            result["_shadow_future"].result(timeout=5)

        decision_event = next(evt for evt in events if evt.get("type") == "decision")
        assert decision_event["latency_ms"] == 11.5
        assert decision_event["decision_context"]["decision_type"] == "tool_call"
        assert decision_event["decision_context"]["user_id"] == "user-123"
        assert decision_event["supporting_context"]["tool_name"] == "tool.test"
        assert decision_event["context_coverage"]["has_tool_action_intent"] is True
        assert not any(evt.get("type") == "invoke_result" for evt in events)

    def test_invoke_shadow_mode_evaluate_failure_returns_shadow_envelope(self):
        """Shadow mode should not block execution when evaluate fails."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='shadow'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        with patch("agendex.client.requests.post", side_effect=requests.exceptions.Timeout("timed out")):
            result = client.invoke(
                action="tool.test",
                params={"key": "value"},
                task="test_task",
            )

            assert result["_agendex"] == "shadow"
            assert result["decision"] == "pending"
            assert result["execute"] is True
            bg_result = result["_shadow_future"].result(timeout=5)
            assert bg_result["decision"] == "unknown"
            assert bg_result["transport_status"]["transport_ok"] is False
    
    def test_invoke_enforce_mode_allow(self):
        """Test invoke in enforce mode with allow decision."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='enforce'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )
        
        # Mock the session for evaluate and invoke
        mock_response = Mock()
        mock_response.ok = True
        mock_response.status_code = 200
        mock_response.json = Mock(return_value={
            "decision": {"outcome": "allow", "reason": "Matched rule"},
            "token": "scoped-token-123",
            "request_id": "req-123",
        })
        mock_response.raise_for_status = Mock()
        
        mock_invoke_response = Mock()
        mock_invoke_response.ok = True
        mock_invoke_response.status_code = 200
        mock_invoke_response.json = Mock(return_value={
            "success": True,
            "result": {"data": "test_result"},
        })
        mock_invoke_response.raise_for_status = Mock()
        
        client._session = Mock()
        client._session.post = Mock(side_effect=[mock_response, mock_invoke_response])
        
        result = client.invoke(
            action="tool.test",
            params={"key": "value"},
            task="test_task",
        )
        
        assert result == {"data": "test_result"}

    def test_invoke_enforce_mode_emits_invoke_latency(self):
        """Enforce mode should emit invoke latency in invoke_result callback events."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='enforce'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        events = []
        mock_eval = Mock()
        mock_eval.ok = True
        mock_eval.status_code = 200
        mock_eval.json = Mock(return_value={
            "decision": {"outcome": "allow", "reason": "Matched rule"},
            "token": "scoped-token-123",
            "request_id": "req-123",
            "latency_ms": 9.2,
        })
        mock_eval.raise_for_status = Mock()

        mock_invoke_response = Mock()
        mock_invoke_response.ok = True
        mock_invoke_response.status_code = 200
        mock_invoke_response.json = Mock(return_value={
            "success": True,
            "result": {"data": "test_result"},
        })
        mock_invoke_response.raise_for_status = Mock()

        client._session = Mock()
        client._session.post = Mock(side_effect=[mock_eval, mock_invoke_response])

        client.invoke(
            action="tool.test",
            params={"key": "value"},
            task="test_task",
            on_event=events.append,
        )

        decision_event = next(evt for evt in events if evt.get("type") == "decision")
        assert decision_event["latency_ms"] == 9.2
        invoke_event = next(evt for evt in events if evt.get("type") == "invoke_result")
        assert isinstance(invoke_event.get("latency_ms"), float)

    def test_invoke_enforce_includes_trace_context(self):
        """Trace context should be merged into evaluate payload context."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='enforce'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        mock_eval = Mock()
        mock_eval.ok = True
        mock_eval.status_code = 200
        mock_eval.json = Mock(return_value={
            "decision": {"outcome": "allow", "reason": "ok"},
            "token": "scoped-token-123",
            "request_id": "req-123",
        })
        mock_eval.raise_for_status = Mock()

        mock_invoke = Mock()
        mock_invoke.ok = True
        mock_invoke.status_code = 200
        mock_invoke.json = Mock(return_value={"success": True, "result": {"ok": True}})
        mock_invoke.raise_for_status = Mock()

        client._session = Mock()
        client._session.post = Mock(side_effect=[mock_eval, mock_invoke])

        client.invoke(
            action="tool.test",
            params={"key": "value"},
            task="test_task",
            context={"reasoning": "need info"},
            trace_id="trace-1",
            span_id="span-1",
            parent_span_id="span-0",
            actor="assistant-analyst",
        )

        evaluate_call = client._session.post.call_args_list[0]
        payload = evaluate_call.kwargs["json"]
        assert payload["context"]["trace_id"] == "trace-1"
        assert payload["context"]["span_id"] == "span-1"
        assert payload["context"]["parent_span_id"] == "span-0"
        assert payload["context"]["actor"] == "assistant-analyst"
        assert payload["context"]["reasoning"] == "need info"
        assert payload["context"]["decision_context"]["trace_id"] == "trace-1"
        assert payload["context"]["decision_context"]["actor"] == "assistant-analyst"
        assert payload["context"]["decision_context"]["tool_action_intent"] == "tool.test"
        assert payload["context"]["supporting_context"]["tool_name"] == "tool.test"
    
    def test_invoke_enforce_mode_deny(self):
        """Test invoke in enforce mode with deny decision."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='enforce'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )
        
        mock_response = Mock()
        mock_response.ok = True
        mock_response.status_code = 200
        mock_response.json = Mock(return_value={
            "decision": {
                "outcome": "deny",
                "reason": "Action not allowed",
                "matched_rule": "deny_all",
            },
            "request_id": "req-123",
        })
        mock_response.raise_for_status = Mock()
        
        client._session = Mock()
        client._session.post = Mock(return_value=mock_response)
        
        with pytest.raises(DeniedError) as exc_info:
            client.invoke(
                action="tool.dangerous",
                params={},
                task="test_task",
            )
        
        assert exc_info.value.action == "tool.dangerous"
        assert "not allowed" in exc_info.value.reason
    
    def test_invoke_enforce_mode_pending_approval(self):
        """Test invoke in enforce mode with pending approval."""
        with patch.object(AgendexClient, '_fetch_mode', return_value='enforce'):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )
        
        mock_response = Mock()
        mock_response.ok = True
        mock_response.status_code = 200
        mock_response.json = Mock(return_value={
            "decision": {
                "outcome": "pending_approval",
                "reason": "Requires approval",
            },
            "approval_id": "apr-0001",
            "request_id": "req-123",
        })
        mock_response.raise_for_status = Mock()
        
        client._session = Mock()
        client._session.post = Mock(return_value=mock_response)
        
        with pytest.raises(PendingApprovalError) as exc_info:
            client.invoke(
                action="tool.payment",
                params={"amount": 5000},
                task="test_task",
            )
        
        assert exc_info.value.approval_id == "apr-0001"

    def test_ingest_events_success(self):
        """Event ingestion posts to /events/ingest and returns server payload."""
        with patch.object(AgendexClient, "_fetch_mode", return_value="shadow"):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        mock_response = Mock()
        mock_response.raise_for_status = Mock()
        mock_response.json = Mock(return_value={"ingested": 2})

        client._session = Mock()
        client._session.post = Mock(return_value=mock_response)

        events = [{"event_type": "a"}, {"event_type": "b"}]
        result = client.ingest_events(events)

        assert result == {"ingested": 2}
        call = client._session.post.call_args
        assert call.kwargs["json"] == {"events": events}
        assert call.kwargs["headers"]["Authorization"] == "Bearer test_token"

    def test_ingest_events_empty_batch(self):
        """Empty or invalid event batches should no-op without network calls."""
        with patch.object(AgendexClient, "_fetch_mode", return_value="shadow"):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        client._session = Mock()
        result = client.ingest_events([])
        assert result == {"ingested": 0}
        client._session.post.assert_not_called()

    def test_ingest_events_request_error(self):
        """Transport errors during ingestion are surfaced as AgendexError."""
        with patch.object(AgendexClient, "_fetch_mode", return_value="shadow"):
            client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        client._session = Mock()
        client._session.post.side_effect = requests.exceptions.RequestException("boom")

        with pytest.raises(AgendexError):
            client.ingest_events([{"event_type": "tool_call"}])

    def test_shadow_and_enforce_emit_same_decision_payload_shape(self):
        shadow_events = []
        with patch.object(AgendexClient, "_fetch_mode", return_value="shadow"):
            shadow_client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        shadow_response = Mock(ok=True)
        shadow_response.status_code = 200
        shadow_response.json = Mock(return_value={
            "decision": {"outcome": "would_allow", "reason": "Matched rule"},
            "request_id": "req-shadow",
            "latency_ms": 8.5,
        })

        with patch("agendex.client.requests.post", return_value=shadow_response):
            shadow_result = shadow_client.invoke(
                action="tool.send_payment",
                params={"amount": 1500, "email": "finance@example.com"},
                task="payments",
                context={"user_id": "user-123", "chat_id": "chat-xyz", "reasoning": "Need to pay invoice"},
                on_event=shadow_events.append,
            )
            shadow_result["_shadow_future"].result(timeout=5)

        enforce_events = []
        with patch.object(AgendexClient, "_fetch_mode", return_value="enforce"):
            enforce_client = AgendexClient(
                base_url="http://test:8000",
                agent_id="test_agent",
                token="test_token",
            )

        mock_eval = Mock()
        mock_eval.ok = True
        mock_eval.status_code = 200
        mock_eval.json = Mock(return_value={
            "decision": {"outcome": "allow", "reason": "Matched rule"},
            "token": "scoped-token-123",
            "request_id": "req-123",
            "latency_ms": 9.2,
        })
        mock_eval.raise_for_status = Mock()

        mock_invoke_response = Mock()
        mock_invoke_response.ok = True
        mock_invoke_response.status_code = 200
        mock_invoke_response.json = Mock(return_value={"success": True, "result": {"ok": True}})
        mock_invoke_response.raise_for_status = Mock()

        enforce_client._session = Mock()
        enforce_client._session.post = Mock(side_effect=[mock_eval, mock_invoke_response])

        enforce_client.invoke(
            action="tool.send_payment",
            params={"amount": 1500, "email": "finance@example.com"},
            task="payments",
            context={"user_id": "user-123", "chat_id": "chat-xyz", "reasoning": "Need to pay invoice"},
            on_event=enforce_events.append,
        )

        shadow_decision = next(evt for evt in shadow_events if evt.get("type") == "decision")
        enforce_decision = next(evt for evt in enforce_events if evt.get("type") == "decision")
        assert set(shadow_decision["decision_context"].keys()) == set(enforce_decision["decision_context"].keys())
        assert set(shadow_decision["supporting_context"].keys()) == set(enforce_decision["supporting_context"].keys())
        assert shadow_decision["decision_context"]["resource_targets"] == enforce_decision["decision_context"]["resource_targets"]
        assert any(target["type"] == "payment" for target in shadow_decision["decision_context"]["resource_targets"])
        assert any(target["type"] == "email" for target in shadow_decision["decision_context"]["resource_targets"])


class TestActivityExtraction:
    """Test automatic resource extraction."""
    
    def test_extract_http_resource(self):
        """Test HTTP resource extraction from params."""
        from agendex.activity import extract_resources
        
        resources = extract_resources("http.request", {
            "url": "https://api.example.com/v1/users",
            "method": "POST",
        })
        
        assert len(resources) == 1
        assert resources[0]["type"] == "http"
        assert resources[0]["domain"] == "api.example.com"
        assert resources[0]["method"] == "POST"
    
    def test_extract_s3_resource(self):
        """Test S3 resource extraction from params."""
        from agendex.activity import extract_resources
        
        resources = extract_resources("s3.read", {
            "bucket": "my-bucket",
            "key": "reports/monthly/2025-01.csv",
        })
        
        assert len(resources) == 1
        assert resources[0]["type"] == "s3"
        assert resources[0]["bucket"] == "my-bucket"
        assert resources[0]["key_prefix"] == "reports/monthly/"
    
    def test_extract_payment_resource(self):
        """Test payment resource extraction from tool kwargs."""
        from agendex.activity import extract_resources
        
        resources = extract_resources("tool.payment", {
            "kwargs": {"amount": 1500, "currency": "EUR"},
        })
        
        assert any(r["type"] == "payment" for r in resources)
        payment = next(r for r in resources if r["type"] == "payment")
        assert payment["amount"] == 1500
        assert payment["currency"] == "EUR"
