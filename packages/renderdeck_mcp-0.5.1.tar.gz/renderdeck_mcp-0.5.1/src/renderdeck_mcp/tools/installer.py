"""Install subcommand: configures API key and Claude Desktop integration.

Prompts for a Gemini API key (via macOS dialog or terminal fallback),
validates it, stores it encrypted, and writes the Claude Desktop MCP config.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

CLAUDE_DESKTOP_CONFIG = (
    Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
)

MCP_SERVER_ENTRY = {
    "command": "uvx",
    "args": ["renderdeck-mcp", "serve"],
}


def _prompt_api_key_osascript() -> str | None:
    """Prompt for API key via macOS dialog. Returns None if cancelled or unavailable."""
    script = (
        'display dialog "Enter your Google Gemini API key:" '
        'default answer "" with title "RenderDeck Setup" '
        "with hidden answer"
    )
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode != 0:
            return None
        # Output format: "button returned:OK, text returned:THE_KEY"
        for part in result.stdout.strip().split(", "):
            if part.startswith("text returned:"):
                return part[len("text returned:") :]
        return None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def _prompt_api_key_terminal() -> str | None:
    """Fallback: prompt for API key via terminal input."""
    try:
        import getpass

        key = getpass.getpass("Enter your Google Gemini API key: ")
        return key if key.strip() else None
    except (EOFError, KeyboardInterrupt):
        return None


def _prompt_api_key() -> str | None:
    """Get API key from user, trying macOS dialog first."""
    key = _prompt_api_key_osascript()
    if key:
        return key.strip()
    return _prompt_api_key_terminal()


def _write_claude_desktop_config() -> None:
    """Merge renderdeck MCP server into Claude Desktop config."""
    config: dict = {}
    if CLAUDE_DESKTOP_CONFIG.is_file():
        try:
            config = json.loads(CLAUDE_DESKTOP_CONFIG.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    servers = config.setdefault("mcpServers", {})
    servers["renderdeck"] = MCP_SERVER_ENTRY

    CLAUDE_DESKTOP_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    CLAUDE_DESKTOP_CONFIG.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")


def run_install() -> None:
    """Run the interactive install flow."""
    print()
    print("  Setting up RenderDeck MCP for Claude Desktop...")
    print()

    # Step 1: Prompt for API key
    print("  Step 1/3: Gemini API key")
    api_key = _prompt_api_key()
    if not api_key:
        print("\n  No API key provided. Installation cancelled.", file=sys.stderr)
        sys.exit(1)

    # Step 2: Validate the key
    print("  Step 2/3: Validating API key...")
    from renderdeck_mcp.tools.setup import _validate_api_key

    if not _validate_api_key(api_key):
        print(
            "\n  Invalid API key — Gemini API rejected it. Please check and try again.",
            file=sys.stderr,
        )
        sys.exit(1)
    print("  ✓ API key is valid")

    # Step 3: Store key
    from renderdeck_mcp.config import store_api_key

    store_api_key(api_key)
    print("  ✓ API key stored securely in ~/.renderdeck/config.json")

    # Step 4: Configure Claude Desktop
    print("  Step 3/3: Configuring Claude Desktop...")
    _write_claude_desktop_config()
    print(f"  ✓ Claude Desktop config updated: {CLAUDE_DESKTOP_CONFIG}")

    print()
    print("  ════════════════════════════════════════════════════")
    print("  ✓ Installation complete!")
    print()
    print("  Restart Claude Desktop to start using RenderDeck.")
    print("  ════════════════════════════════════════════════════")
    print()
