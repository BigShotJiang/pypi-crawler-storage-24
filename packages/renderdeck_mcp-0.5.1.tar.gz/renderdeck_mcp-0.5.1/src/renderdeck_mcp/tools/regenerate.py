"""MCP tool: regenerate_slide.

Regenerates specific slides by forcing image generation (bypassing cache)
for the given slide numbers, then reassembling the .pptx.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

ProgressCallback = Callable[[float, float, str], Awaitable[None]]

logger = logging.getLogger(__name__)


async def run_regenerate_slide(
    project_name: str,
    slide_numbers: list[int],
    slide_prompt_content: str,
    output_path: str | None = None,
    progress_cb: ProgressCallback | None = None,
) -> dict[str, Any]:
    """Regenerate specific slides and reassemble the .pptx.

    Forces Gemini API calls for the specified slide numbers (bypasses cache),
    keeps all other slides cached, updates the cache manifest, and rebuilds
    the .pptx.

    Args:
        project_name: Cache project name.
        slide_numbers: 1-based slide numbers to regenerate.
        slide_prompt_content: Full prompt file content (needed for prompts).
        output_path: Optional output path for the .pptx.

    Returns:
        Result dict with status, output_path, regenerated/cached counts.
    """
    from renderdeck_mcp.assembly.pptx_builder import DeckData, SlideData, build_pptx
    from renderdeck_mcp.generation.cache import (
        CacheManifest,
        content_hash_for_slide,
        options_hash,
        save_cache_manifest,
    )
    from renderdeck_mcp.generation.gemini import (
        AspectRatio,
        GeminiConfig,
        SlideImageRequest,
        generate_images_concurrent,
    )
    from renderdeck_mcp.parser import ParsedDeck, parse_prompt_file

    # Step 1 — Parse
    deck: ParsedDeck = parse_prompt_file(slide_prompt_content)
    if not deck.slides:
        return {"status": "error", "message": "Prompt file contains no slides."}

    # Step 2 — Validate slide numbers
    valid_numbers = set(range(1, len(deck.slides) + 1))
    force_set = set(slide_numbers)
    invalid = force_set - valid_numbers
    if invalid:
        logger.warning("Slide numbers not in deck (ignored): %s", sorted(invalid))

    to_regenerate = force_set & valid_numbers
    if not to_regenerate:
        return {
            "status": "error",
            "message": (
                f"No valid slide numbers to regenerate. Deck has slides 1-{len(deck.slides)}."
            ),
        }

    # Step 3 — Resolve API key
    from renderdeck_mcp.config import get_api_key

    api_key = get_api_key()
    if not api_key:
        return {
            "status": "error",
            "message": (
                "Gemini API key not configured. "
                "Use setup_gemini_key tool or set GOOGLE_GEMINI_API_KEY."
            ),
        }

    # Step 4 — Setup
    model = "gemini-3-pro-image-preview"
    cache_base = Path.home() / ".renderdeck" / "cache"
    cache_dir = cache_base / project_name
    current_opts_hash = options_hash(aspect_ratio="WIDE", model=model)

    # Step 5 — Load cached images for non-regenerated slides
    cached_images: dict[int, bytes | None] = {}
    for idx, slide in enumerate(deck.slides):
        slide_num = idx + 1
        if slide_num not in to_regenerate:
            img_path = cache_dir / f"slide_{slide_num:02d}.png"
            if img_path.is_file():
                try:
                    cached_images[slide_num] = img_path.read_bytes()
                except OSError:
                    cached_images[slide_num] = None

    # Step 6 — Generate images for specified slides
    config = GeminiConfig(api_key=api_key, model=model)
    requests: list[SlideImageRequest] = []
    for slide_num in sorted(to_regenerate):
        slide = deck.slides[slide_num - 1]
        if not slide.has_prompt:
            logger.warning("Slide %d has no image prompt, skipping", slide_num)
            continue
        requests.append(
            SlideImageRequest(
                slide_index=slide_num - 1,
                prompt=slide.image_prompt,
                aspect_ratio=AspectRatio.WIDE,
                general_context=deck.general,
                visual_rules=deck.global_rules,
            )
        )

    generated_images: dict[int, bytes | None] = {}
    if requests:
        logger.info("Regenerating %d slide(s) via Gemini...", len(requests))
        results = await generate_images_concurrent(requests, config, progress_cb=progress_cb)
        cache_dir.mkdir(parents=True, exist_ok=True)
        for result in results:
            slide_num = result.slide_index + 1
            generated_images[slide_num] = result.image_bytes
            if result.image_bytes is not None:
                img_path = cache_dir / f"slide_{slide_num:02d}.png"
                try:
                    img_path.write_bytes(result.image_bytes)
                except OSError:
                    pass

    # Step 7 — Assemble .pptx
    slide_data_list: list[SlideData] = []
    for idx, slide in enumerate(deck.slides):
        slide_num = idx + 1
        image_bytes: bytes | None = None
        if slide_num in generated_images:
            image_bytes = generated_images[slide_num]
        elif slide_num in cached_images:
            image_bytes = cached_images[slide_num]

        slide_data_list.append(
            SlideData(
                slide_number=slide_num,
                title=slide.title,
                speaker_notes=slide.speaker_notes,
                image_bytes=image_bytes,
            )
        )

    deck_data = DeckData(title=deck.title, slides=slide_data_list)
    resolved_output = output_path or str(
        Path.home() / "Documents" / "RenderDeck" / f"{project_name}_regen.pptx"
    )
    written_path = build_pptx(deck_data, resolved_output)

    # Step 8 — Update cache manifest
    content_hashes: dict[int, str] = {}
    for idx, slide in enumerate(deck.slides):
        content_hashes[idx + 1] = content_hash_for_slide(
            general=deck.general,
            global_rules=deck.global_rules,
            image_prompt=slide.image_prompt,
        )

    new_manifest = CacheManifest(
        version=1,
        options_hash=current_opts_hash,
        slides=content_hashes,
    )
    save_cache_manifest(project_name, new_manifest)

    return {
        "status": "ok",
        "output_path": str(written_path),
        "slide_count": len(deck.slides),
        "slides_regenerated": len(generated_images),
        "slides_cached": len(cached_images),
        "invalid_slide_numbers": sorted(invalid) if invalid else [],
    }
