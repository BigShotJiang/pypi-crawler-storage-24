"""List available TTS voices for video narration."""

from __future__ import annotations

import tempfile
import webbrowser
from pathlib import Path

_LOCALE_LABELS: dict[str, str] = {
    "en-AU": "Australia",
    "en-CA": "Canada",
    "en-GB": "United Kingdom",
    "en-HK": "Hong Kong",
    "en-IE": "Ireland",
    "en-IN": "India",
    "en-KE": "Kenya",
    "en-NG": "Nigeria",
    "en-NZ": "New Zealand",
    "en-PH": "Philippines",
    "en-SG": "Singapore",
    "en-TZ": "Tanzania",
    "en-US": "United States",
    "en-ZA": "South Africa",
}


def _build_html(voices: list[dict[str, str]]) -> str:
    """Build a self-contained HTML page with inline audio players and filters."""
    rows: list[str] = []
    locales_seen: set[str] = set()

    for v in voices:
        sample = v.get("sample_url", "")
        if not sample:
            continue

        locales_seen.add(v["locale"])
        player = f'<audio controls preload="none" src="{sample}"></audio>'
        gender_cls = "gender-f" if v["gender"] == "Female" else "gender-m"
        locale = v["locale"]
        country_code = locale.split("-")[1]
        row = (
            f'<tr data-locale="{locale}" data-gender="{v["gender"]}">'
            f'<td class="alias">{v["alias"]}</td>'
            f'<td class="full-name">{v["full_name"]}</td>'
            f'<td class="locale">{country_code}</td>'
            f'<td class="{gender_cls}">{v["gender"]}</td>'
            f"<td>{player}</td></tr>"
        )
        rows.append(row)

    body = "\n".join(rows)
    locale_options = "\n".join(
        f'<option value="{loc}">{loc.split("-")[1]} — {_LOCALE_LABELS.get(loc, loc)}</option>'
        for loc in sorted(locales_seen)
    )

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>RenderDeck \u2014 Voice Samples</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
background:#f8f9fa;color:#1a1a2e;padding:2rem;line-height:1.6}}
h1{{margin-bottom:.5rem;font-size:1.8rem}}
.subtitle{{color:#666;margin-bottom:2rem}}
.usage{{background:#e8f4fd;border-left:4px solid #2196F3;
padding:1rem 1.2rem;margin-bottom:2rem;border-radius:0 6px 6px 0}}
.usage code{{background:#d4e9f7;padding:2px 6px;border-radius:3px;font-size:.9em}}
.filters{{display:flex;gap:1.5rem;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap}}
.filters label{{font-weight:600;margin-right:.3rem}}
.filters select{{padding:6px 10px;border:1px solid #ccc;border-radius:4px;font-size:.95em}}
.filters .gender-group{{display:flex;gap:1rem;align-items:center}}
.filters .gender-group label{{font-weight:normal;cursor:pointer}}
.filters .gender-group input{{margin-right:4px;cursor:pointer}}
.count{{color:#666;font-size:.9em;margin-bottom:1rem}}
table{{width:100%;border-collapse:collapse;background:#fff;
border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
th{{background:#1a1a2e;color:#fff;text-align:left;padding:12px 16px;font-weight:600}}
td{{padding:10px 16px;border-bottom:1px solid #eee}}
tr:last-child td{{border-bottom:none}}
tr:hover{{background:#f0f4ff}}
.alias{{font-family:monospace;font-weight:600;font-size:1.05em}}
.full-name{{font-family:monospace;color:#555;font-size:.9em}}
.locale{{font-weight:600;color:#388E3C}}
.gender-f{{color:#7B1FA2}}.gender-m{{color:#1565C0}}
audio{{height:32px;vertical-align:middle}}
footer{{margin-top:2rem;color:#888;font-size:.85em}}
</style></head><body>
<h1>RenderDeck Voice Samples</h1>
<p class="subtitle">Click play to preview each voice \u2014
use the alias in <code>generate_video(voice="...")</code></p>
<div class="usage"><strong>Usage:</strong> Pass the alias as the <code>voice</code> parameter.<br>
Example: <code>generate_video(project_name="my_deck", ..., voice="roger")</code></div>
<div class="filters">
<div><label for="locale-filter">Country:</label>
<select id="locale-filter"><option value="">All Countries</option>
{locale_options}
</select></div>
<div class="gender-group"><label><input type="checkbox"
class="gender-cb" value="Female" checked> Female</label>
<label><input type="checkbox" class="gender-cb" value="Male" checked> Male</label></div>
</div>
<p class="count" id="voice-count"></p>
<table>
<thead><tr><th>Alias</th><th>Full Name</th><th>Country</th>
<th>Gender</th><th>Play Sample</th></tr></thead>
<tbody id="voice-body">{body}</tbody>
</table>
<footer>Samples from <a href="https://github.com/yaph/tts-samples">
tts-samples</a>. Only voices with available samples are shown.</footer>
<script>
(function(){{
  const sel=document.getElementById('locale-filter');
  const cbs=document.querySelectorAll('.gender-cb');
  const tbody=document.getElementById('voice-body');
  const countEl=document.getElementById('voice-count');
  function applyFilters(){{
    const loc=sel.value;
    const genders=new Set();
    cbs.forEach(cb=>{{if(cb.checked)genders.add(cb.value)}});
    let shown=0;
    tbody.querySelectorAll('tr').forEach(tr=>{{
      const matchLoc=!loc||tr.dataset.locale===loc;
      const matchGen=genders.has(tr.dataset.gender);
      tr.style.display=(matchLoc&&matchGen)?'':'none';
      if(matchLoc&&matchGen)shown++;
    }});
    countEl.textContent='Showing '+shown+' voice'+(shown!==1?'s':'');
  }}
  sel.addEventListener('change',applyFilters);
  cbs.forEach(cb=>cb.addEventListener('change',applyFilters));
  applyFilters();
}})();
</script>
</body></html>"""


def run_list_voices() -> dict[str, object]:
    """Return all supported TTS voices with aliases and metadata.

    Also opens a local HTML page with inline audio players in the
    user's default browser so they can audition voices immediately.
    """
    from renderdeck_mcp.voices import DEFAULT_VOICES

    voices: list[dict[str, str]] = []
    full_voices: list[dict[str, str]] = []
    for alias, info in sorted(DEFAULT_VOICES.items()):
        voices.append(
            {
                "alias": alias,
                "full_name": info["full_name"],
                "locale": info["locale"],
                "gender": info["gender"],
            }
        )
        full_voices.append({"alias": alias, **info})

    html = _build_html(full_voices)
    tmp = Path(tempfile.gettempdir()) / "renderdeck_voice_samples.html"
    tmp.write_text(html, encoding="utf-8")
    webbrowser.open(tmp.as_uri())

    return {
        "voices": voices,
        "default_voice": "aria (en-US-AriaNeural)",
        "total_count": len(voices),
        "samples_page": str(tmp),
        "samples_hint": (
            "A voice samples page with play buttons has been opened in the browser. "
            "Click play next to any voice to hear it."
        ),
        "usage_hint": (
            "Use the alias (e.g. 'roger') or full name (e.g. 'en-US-RogerNeural') "
            "as the voice parameter in generate_video."
        ),
    }
