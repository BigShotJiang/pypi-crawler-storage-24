"""Gemini image generation client.

Wraps the google-genai SDK to generate slide images from text prompts.
Supports configurable concurrency, exponential backoff retry,
time-budgeted generation, and text-only fallback on failure.

Implemented by task 2.2 gemini-client.
"""

from __future__ import annotations

import asyncio
import base64
import binascii
import http.client
import io
import logging
import time
import urllib.error
import urllib.request
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import Any
from urllib.parse import urlparse

from google import genai
from google.genai import types

from renderdeck_mcp.generation.types import ReferenceImageDict, ResolvedReferenceImage

ProgressCallback = Callable[[float, float, str], Awaitable[None]]

logger = logging.getLogger(__name__)

# Capture the real asyncio.sleep at module load time so that test mocks on
# asyncio.sleep do not prevent the event-loop yields inside
# generate_images_concurrent.
_real_sleep = asyncio.sleep

# Maximum wall-clock seconds for the entire image generation phase.
# Claude Desktop enforces a ~240s MCP tool timeout; we leave headroom for
# parsing, cache checks, and .pptx assembly.
_GENERATION_BUDGET_SECONDS: float = 180.0


class AspectRatio(StrEnum):
    """Aspect ratio for generated images."""

    WIDE = "16:9"
    STANDARD = "4:3"


@dataclass(frozen=True)
class GeminiConfig:
    """Runtime configuration for the Gemini image generation client."""

    api_key: str
    model: str = "gemini-3-pro-image-preview"
    max_retries: int = 3
    max_concurrent_images: int = 5
    retry_delays: tuple[float, ...] = (1.0, 2.0, 4.0)
    generation_budget: float = _GENERATION_BUDGET_SECONDS


@dataclass(frozen=True)
class SlideImageRequest:
    """Input descriptor for a single slide image generation request."""

    slide_index: int
    prompt: str
    aspect_ratio: AspectRatio = AspectRatio.WIDE
    general_context: str = ""
    visual_rules: str = ""
    reference_images: tuple[ReferenceImageDict, ...] = ()  # immutable for frozen


@dataclass
class ImageResult:
    """Output of a single image generation attempt."""

    slide_index: int
    image_bytes: bytes | None
    fallback: bool
    error: str | None = None


# ---------------------------------------------------------------------------
# Internal constants
# ---------------------------------------------------------------------------

_STYLE_PREAMBLE = (
    "STYLE DIRECTIVE: You are a world-class presentation designer. "
    "Create visually striking, dynamic slides with bold compositions, "
    "rich depth and dimension, and confident use of color. "
    "Embrace contrast, visual hierarchy, and engaging layouts. "
    "Make every slide feel polished and energetic — "
    "not clip-art, not stock-photo generic, not flat or lifeless."
)

_POLICY_KEYWORDS = ("blocked", "policy", "PROHIBITED_CONTENT")
_RETRYABLE_CODES = ("429", "500", "502", "503")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_prompt(request: SlideImageRequest) -> str:
    """Assemble full prompt from general context, visual rules, slide prompt."""
    parts: list[str] = [_STYLE_PREAMBLE]
    if request.general_context:
        parts.append(f"GENERAL CONTEXT:\n{request.general_context}")
    if request.visual_rules:
        parts.append(f"GLOBAL VISUAL RULES:\n{request.visual_rules}")
    parts.append(f"SLIDE IMAGE PROMPT:\n{request.prompt}")
    return "\n\n".join(parts)


def _is_content_policy_block(exc: Exception) -> bool:
    """Return True if the exception is a content policy violation."""
    msg = str(exc).lower()
    return any(kw.lower() in msg for kw in _POLICY_KEYWORDS)


def _is_retryable(exc: Exception) -> bool:
    """Return True if the exception indicates a transient failure."""
    if _is_content_policy_block(exc):
        return False
    msg = str(exc)
    return any(code in msg for code in _RETRYABLE_CODES)


def _extract_bytes_from_part(part: Any) -> bytes | None:
    """Extract image bytes from a single response part using three strategies."""
    # Strategy 1 & 2: inline_data.data — bytes or base64 string
    try:
        data = part.inline_data.data
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return base64.b64decode(data)
    except (AttributeError, ValueError):
        pass

    # Strategy 3: as_image() -> PIL Image -> BytesIO
    try:
        pil_image = part.as_image()
        buf = io.BytesIO()
        pil_image.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        pass

    return None


def _extract_image_bytes(response: Any) -> bytes | None:
    """Parse Gemini response to extract raw PNG bytes.

    Checks response.parts first, then response.candidates[0].content.parts.
    Handles both bytes and base64-encoded inline_data, and as_image() fallback.
    Returns None if no image part is found.
    """
    parts: list[Any] = []
    try:
        if response.parts:
            parts = list(response.parts)
    except Exception:
        pass

    if not parts:
        try:
            parts = list(response.candidates[0].content.parts)
        except Exception:
            pass

    for part in parts:
        result = _extract_bytes_from_part(part)
        if result is not None:
            return result

    return None


# Maximum number of reference images allowed per slide.
MAX_REFERENCE_IMAGES = 14

# Maximum size for a fetched reference image (20 MB).
_MAX_REFERENCE_IMAGE_BYTES = 20 * 1024 * 1024


async def _fetch_url_as_base64(url: str) -> str | None:
    """Fetch an image URL and return its base64 encoding.

    Uses urllib.request (stdlib) wrapped in asyncio.to_thread.
    Returns None on any network error, timeout, or non-200 status.
    Logs a warning on failure. URL is trimmed to scheme+host in log messages.

    Args:
        url: HTTP or HTTPS URL to fetch.

    Returns:
        Base64-encoded bytes as a str, or None on failure.
    """
    parsed = urlparse(url)
    safe_url = f"{parsed.scheme}://{parsed.netloc}"

    if parsed.scheme not in ("http", "https"):
        logger.warning("[reference-fetch] %s — unsupported scheme", safe_url)
        return None

    def _do_fetch() -> bytes | None:
        try:
            with urllib.request.urlopen(url, timeout=10) as response:
                if response.status != 200:
                    logger.warning(
                        "[reference-fetch] %s — HTTP %d",
                        safe_url,
                        response.status,
                    )
                    return None
                data = response.read(_MAX_REFERENCE_IMAGE_BYTES + 1)
                if len(data) > _MAX_REFERENCE_IMAGE_BYTES:
                    logger.warning(
                        "[reference-fetch] %s — image too large (>%d bytes)",
                        safe_url,
                        _MAX_REFERENCE_IMAGE_BYTES,
                    )
                    return None
                return data
        except (urllib.error.URLError, http.client.HTTPException, OSError, TimeoutError) as exc:
            logger.warning(
                "[reference-fetch] %s — %s",
                safe_url,
                type(exc).__name__,
            )
            return None
        except Exception as exc:
            logger.warning(
                "[reference-fetch] %s — %s",
                safe_url,
                type(exc).__name__,
            )
            return None

    data = await asyncio.to_thread(_do_fetch)
    if data is None:
        return None
    return base64.b64encode(data).decode("ascii")


async def _resolve_reference_image(
    ref: ReferenceImageDict,
) -> ResolvedReferenceImage | None:
    """Resolve a ReferenceImageDict into a confirmed ResolvedReferenceImage.

    Steps:
    1. If ref has 'url', fetch it and encode to base64.
    2. If ref has 'base64', validate it is decodable.
    3. Determine media_type (default: "image/png").
    4. Return None on any failure (logged as warning).

    Args:
        ref: Caller-supplied reference image descriptor.

    Returns:
        ResolvedReferenceImage, or None if the image cannot be resolved.
    """
    base64_data: str | None = None

    if "url" in ref:
        base64_data = await _fetch_url_as_base64(ref["url"])
        if base64_data is None:
            return None
    elif "base64" in ref:
        raw_b64 = ref["base64"]
        if not raw_b64:
            logger.warning("[reference-decode] empty base64 data — skipping")
            return None
        try:
            base64.b64decode(raw_b64, validate=True)
        except binascii.Error as exc:
            logger.warning("[reference-decode] invalid base64 data — %s", type(exc).__name__)
            return None
        base64_data = raw_b64
    else:
        logger.warning("[reference-skip] no url or base64 field in entry")
        return None

    media_type = ref.get("media_type", "image/png")
    role = ref.get("role", "")
    placement = ref.get("placement", "")

    return ResolvedReferenceImage(
        base64_data=base64_data,
        media_type=media_type,
        role=role,
        placement=placement,
    )


def _build_contents(
    request: SlideImageRequest,
    resolved: list[ResolvedReferenceImage],
) -> str | list[Any]:
    """Build the Gemini API `contents` argument.

    Returns a plain str when resolved is empty (text-only path, backward compatible).
    Returns a list of content parts when resolved is non-empty (multimodal path).

    The text prompt is always the last part so Gemini treats the images as context.

    Args:
        request: Slide request with prompt assembled by _build_prompt.
        resolved: Resolved reference images (may be empty).

    Returns:
        str (text-only) or list[dict] (multimodal).
    """
    if not resolved:
        return _build_prompt(request)

    # Build the role annotation string
    annotation_lines = [f"- {r.role}: {r.placement}" for r in resolved if r.role]
    full_text = _build_prompt(request)
    if annotation_lines:
        annotation = "REFERENCE IMAGES:\n" + "\n".join(annotation_lines)
        full_text = f"{full_text}\n\n{annotation}"

    contents: list[Any] = []
    for r in resolved:
        contents.append(
            types.Part(
                inline_data=types.Blob(
                    mime_type=r.media_type,
                    data=base64.b64decode(r.base64_data),
                )
            )
        )
    contents.append(types.Part(text=full_text))
    return contents


# ---------------------------------------------------------------------------
# Public async functions
# ---------------------------------------------------------------------------


async def generate_image(
    client: genai.Client,
    request: SlideImageRequest,
    config: GeminiConfig,
) -> bytes | None:
    """Generate a single PNG image for one slide.

    Attempts up to config.max_retries calls with exponential backoff on
    HTTP 429 (quota) and 503 (service unavailable). Returns PNG bytes on
    success, or None if all attempts fail or the content is policy-blocked.

    Args:
        client: Authenticated google-genai Client instance.
        request: Slide descriptor including prompt and aspect ratio.
        config: Runtime tuning parameters (retries, delays).

    Returns:
        PNG bytes, or None on failure (caller treats as text-only slide).

    Raises:
        ValueError: If more than MAX_REFERENCE_IMAGES reference images are provided.
    """
    if len(request.reference_images) > MAX_REFERENCE_IMAGES:
        raise ValueError(
            f"Too many reference images: {len(request.reference_images)} > {MAX_REFERENCE_IMAGES}"
        )

    # Resolve all reference images before the retry loop
    resolved: list[ResolvedReferenceImage] = []
    for ref in request.reference_images:
        r = await _resolve_reference_image(ref)
        if r is not None:
            resolved.append(r)

    if request.reference_images:
        n_total = len(request.reference_images)
        n_resolved = len(resolved)
        n_skipped = n_total - n_resolved
        logger.info(
            "slide %d: %d/%d references resolved (%d skipped)",
            request.slide_index,
            n_resolved,
            n_total,
            n_skipped,
        )

    contents = _build_contents(request, resolved)

    for attempt, delay in enumerate(config.retry_delays[: config.max_retries]):
        try:
            response = await asyncio.to_thread(
                client.models.generate_content,
                model=config.model,
                contents=contents,
                config=types.GenerateContentConfig(
                    response_modalities=["IMAGE"],
                    image_config=types.ImageConfig(
                        aspect_ratio=request.aspect_ratio.value,
                    ),
                ),
            )
            image_bytes = _extract_image_bytes(response)
            if image_bytes is not None:
                return image_bytes
            # Empty response — treat as transient, retry
        except Exception as exc:
            if _is_content_policy_block(exc):
                logger.warning("Content policy block on slide %d", request.slide_index)
                return None
            if not _is_retryable(exc):
                logger.warning(
                    "Non-retryable error on slide %d: %s",
                    request.slide_index,
                    type(exc).__name__,
                )
                return None
            if attempt < config.max_retries - 1:
                logger.info(
                    "Retrying slide %d after %.0fs (attempt %d)",
                    request.slide_index,
                    delay,
                    attempt + 1,
                )
                await asyncio.sleep(delay)

    return None


async def generate_images_concurrent(
    requests: list[SlideImageRequest],
    config: GeminiConfig,
    progress_cb: ProgressCallback | None = None,
) -> list[ImageResult]:
    """Generate images for all slides with bounded concurrency and a time budget.

    Uses an asyncio.Semaphore(config.max_concurrent_images) to cap
    simultaneous Gemini API calls. A wall-clock budget (config.generation_budget,
    default 180s) ensures the function returns before the MCP client timeout.
    Tasks still running when the budget expires are cancelled and treated as
    text-only fallback slides.

    Args:
        requests: One SlideImageRequest per slide.
        config: Includes api_key, model, concurrency, retry, and budget settings.
        progress_cb: Optional async callback(current, total, message) for
            reporting per-image progress to the MCP client.

    Returns:
        List of ImageResult, one per input request, in the same order.
        Slides that fail or are cancelled produce ImageResult(fallback=True).

    Raises:
        Nothing. Per-slide failures are isolated; one failure never
        prevents other slides from being attempted.
    """
    client = genai.Client(api_key=config.api_key)
    semaphore = asyncio.Semaphore(config.max_concurrent_images)
    total = float(len(requests) + 1)  # +1 for assembly step in caller
    completed = 0
    deadline = time.monotonic() + config.generation_budget

    async def _bounded(request: SlideImageRequest) -> ImageResult:
        nonlocal completed
        async with semaphore:
            try:
                image_bytes = await generate_image(client, request, config)
            except ValueError as exc:
                logger.warning(
                    "Slide %d skipped: %s",
                    request.slide_index,
                    exc,
                )
                completed += 1
                return ImageResult(
                    slide_index=request.slide_index,
                    image_bytes=None,
                    fallback=True,
                    error=str(exc),
                )
            completed += 1
            if progress_cb is not None:
                slide_num = request.slide_index + 1
                await progress_cb(
                    float(completed),
                    total,
                    f"Image {completed}/{len(requests)} done (slide {slide_num})",
                )
            return ImageResult(
                slide_index=request.slide_index,
                image_bytes=image_bytes,
                fallback=image_bytes is None,
            )

    # Create tasks one at a time, yielding between each so that tasks start
    # (and submit to the thread pool) in input order. Use the real asyncio.sleep
    # so that test mocks on asyncio.sleep do not suppress the event-loop yield.
    tasks: list[asyncio.Task[ImageResult]] = []
    for req in requests:
        tasks.append(asyncio.create_task(_bounded(req)))
        await _real_sleep(0)

    if not tasks:
        return []

    # Wait with a time budget — collect whatever finishes in time.
    remaining = max(0.0, deadline - time.monotonic())
    done, pending = await asyncio.wait(tasks, timeout=remaining)

    # Cancel stragglers and build results indexed by slide_index.
    if pending:
        timed_out_indices = []
        for t in pending:
            t.cancel()
            timed_out_indices.append(t)
        # Let cancellations propagate.
        await asyncio.gather(*pending, return_exceptions=True)
        logger.warning(
            "Time budget exhausted: %d/%d images completed, %d cancelled",
            len(done),
            len(requests),
            len(pending),
        )
        if progress_cb is not None:
            await progress_cb(
                float(completed),
                total,
                f"Time budget — {len(done)}/{len(requests)} images, partial deck",
            )

    # Collect completed results and fill in fallbacks for cancelled tasks.
    results_by_index: dict[int, ImageResult] = {}
    for t in done:
        exc = t.exception()
        if exc is None:
            result = t.result()
            results_by_index[result.slide_index] = result
        # Exceptions should not happen (generate_image catches all), but guard.

    ordered: list[ImageResult] = []
    for req in requests:
        if req.slide_index in results_by_index:
            ordered.append(results_by_index[req.slide_index])
        else:
            ordered.append(
                ImageResult(
                    slide_index=req.slide_index,
                    image_bytes=None,
                    fallback=True,
                    error="cancelled (time budget exceeded)",
                )
            )

    return ordered
