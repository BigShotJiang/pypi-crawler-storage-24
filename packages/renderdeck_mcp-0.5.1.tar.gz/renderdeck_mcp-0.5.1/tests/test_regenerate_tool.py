"""Tests for the regenerate_slide MCP tool."""

from __future__ import annotations

import asyncio
import io
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from PIL import Image

from renderdeck_mcp.tools.regenerate import run_regenerate_slide


def _make_png() -> bytes:
    """Create a minimal valid PNG image."""
    buf = io.BytesIO()
    Image.new("RGB", (100, 100), "blue").save(buf, format="PNG")
    return buf.getvalue()


SAMPLE_PROMPT = """\
# Test Deck

## General

Test context.

## Global Rules

FORMAT: 16:9

---

## Slide 01 — First

A wide-format opening slide with blue gradient.

---

## Slide 02 — Second

Content slide with data cards.

---

## Slide 03 — Third

Closing statement slide.

## Speaker Notes

### Slide 01 — First

**Say:** Hello.
**Time:** 10 seconds

### Slide 02 — Second

**Say:** Data time.
**Time:** 1 minute

### Slide 03 — Third

**Say:** Goodbye.
**Time:** 10 seconds
"""


def _run(coro):
    """Helper to run async in tests."""
    return asyncio.run(coro)


class TestRegenerateSlide:
    """Tests for run_regenerate_slide."""

    def test_no_slides_returns_error(self) -> None:
        result = _run(run_regenerate_slide("proj", [1], "# Empty\n"))
        assert result["status"] == "error"
        assert "no slides" in result["message"].lower()

    def test_invalid_slide_numbers_returns_error(self) -> None:
        result = _run(run_regenerate_slide("proj", [99], SAMPLE_PROMPT))
        assert result["status"] == "error"
        assert "No valid slide numbers" in result["message"]

    def test_no_api_key_returns_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("GOOGLE_GEMINI_API_KEY", raising=False)
        monkeypatch.setattr("renderdeck_mcp.config.get_api_key", lambda: None)
        result = _run(run_regenerate_slide("proj", [1], SAMPLE_PROMPT))
        assert result["status"] == "error"
        assert "API key" in result["message"]

    def test_successful_regeneration(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: pytest.TempPathFactory
    ) -> None:
        monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")

        # Mock generate_images_concurrent
        from renderdeck_mcp.generation.gemini import ImageResult

        mock_results = [
            ImageResult(fallback=False, slide_index=0, image_bytes=_make_png()),
        ]
        mock_gen = AsyncMock(return_value=mock_results)

        output = str(tmp_path / "output.pptx") if hasattr(tmp_path, "__truediv__") else None

        with patch(
            "renderdeck_mcp.generation.gemini.generate_images_concurrent",
            mock_gen,
        ):
            result = _run(run_regenerate_slide("test-proj", [1], SAMPLE_PROMPT, output))

        assert result["status"] == "ok"
        assert result["slides_regenerated"] == 1
        assert result["slide_count"] == 3

    def test_mixed_valid_invalid_slides(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")

        from renderdeck_mcp.generation.gemini import ImageResult

        mock_results = [
            ImageResult(fallback=False, slide_index=1, image_bytes=_make_png()),
        ]
        mock_gen = AsyncMock(return_value=mock_results)

        with patch(
            "renderdeck_mcp.generation.gemini.generate_images_concurrent",
            mock_gen,
        ):
            result = _run(
                run_regenerate_slide("proj", [2, 99], SAMPLE_PROMPT, str(tmp_path / "out.pptx"))
            )

        assert result["status"] == "ok"
        assert result["invalid_slide_numbers"] == [99]
        assert result["slides_regenerated"] == 1

    def test_non_specified_slides_not_regenerated(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")

        from renderdeck_mcp.generation.gemini import ImageResult

        mock_results = [
            ImageResult(fallback=False, slide_index=0, image_bytes=_make_png()),
        ]
        mock_gen = AsyncMock(return_value=mock_results)

        with patch(
            "renderdeck_mcp.generation.gemini.generate_images_concurrent",
            mock_gen,
        ):
            result = _run(run_regenerate_slide("proj", [1], SAMPLE_PROMPT))

        # Only slide 1 should be regenerated
        assert result["slides_regenerated"] == 1
        # Gemini was called with exactly 1 request
        mock_gen.assert_called_once()
        requests = mock_gen.call_args[0][0]
        assert len(requests) == 1
        assert requests[0].slide_index == 0  # slide 1 is index 0
