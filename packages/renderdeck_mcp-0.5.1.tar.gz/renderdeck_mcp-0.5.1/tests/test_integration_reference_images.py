"""Integration tests for the reference-image-input feature (EXE-1091).

These tests verify the interactions BETWEEN components — what unit tests do NOT cover:

- Parser → generate_deck pipeline: parsed reference_images flow through to
  SlideImageRequest construction in run_generate_deck.
- generate_slide MCP tool: end-to-end from MCP tool parameter to Gemini API call.
- generate_deck with references: full pipeline parse → cache check → generate →
  assemble with reference images.
- Cache invalidation: reference image changes trigger cache miss in the full pipeline.
- Error propagation: URL fetch failures in the full generate_deck pipeline produce
  the correct fallback behaviour.

Mock strategy:
- Gemini API (generate_image / generate_images_concurrent): always mocked.
- HTTP URL fetches (urllib.request.urlopen): mocked where needed.
- Filesystem cache: redirected to tmp_path so tests are isolated.
- Parser and content-hashing run REAL (unmodified) code.

Design: docs/sdd/epic-mcp-server-generation-assembly/reference-image-input/design.md
"""

from __future__ import annotations

import base64
import io
import logging
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from PIL import Image

# ---------------------------------------------------------------------------
# Constants shared across all tests
# ---------------------------------------------------------------------------

MINIMAL_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 20


def _make_real_png() -> bytes:
    """Return a minimal but structurally valid PNG for cache hit validation."""
    buf = io.BytesIO()
    Image.new("RGB", (4, 4), "blue").save(buf, format="PNG")
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Patch targets (module-level for clarity)
# ---------------------------------------------------------------------------

_GEN_CONCURRENT = "renderdeck_mcp.tools.generate_deck.generate_images_concurrent"
_GEN_IMAGE = "renderdeck_mcp.tools.generate_slide.generate_image"
_LOAD_CACHE = "renderdeck_mcp.tools.generate_deck.load_cache_manifest"
_SAVE_CACHE = "renderdeck_mcp.tools.generate_deck.save_cache_manifest"
_BUILD_PPTX = "renderdeck_mcp.tools.generate_deck.build_pptx"
_READ_CACHED = "renderdeck_mcp.tools.generate_deck._read_cached_image"

# ---------------------------------------------------------------------------
# Prompt file fixtures — real prompt file strings used by multiple tests
# ---------------------------------------------------------------------------

_DECK_WITH_REFERENCES = """\
# Tech Startup Deck

## General
We build AI productivity tools.

## Global Rules
Bold, modern color palette.

---

## Slide 01 — Product Overview

Show the product dashboard.

REFERENCES:
- url: https://example.com/screenshot.png
  role: product screenshot
  placement: center

---

## Slide 02 — Team

Show the team headshots.

REFERENCES:
- url: https://example.com/logo.png
  role: brand logo
  placement: top-right corner

- base64: aGVsbG8=
  media_type: image/jpeg
  role: team photo
  placement: center
"""

_DECK_WITHOUT_REFERENCES = """\
# Plain Deck

## General
Standard deck.

---

## Slide 01 — Intro

A plain intro slide.

---

## Slide 02 — Conclusion

A plain conclusion slide.
"""

_DECK_MIXED_REFERENCES = """\
# Mixed Deck

## General
Mixed context.

---

## Slide 01 — With Ref

Slide with a reference.

REFERENCES:
- url: https://example.com/img.png
  role: hero

---

## Slide 02 — Without Ref

Slide without a reference.
"""


# ---------------------------------------------------------------------------
# Helper — ImageResult factory
# ---------------------------------------------------------------------------


def _make_image_results_from_requests(
    requests: list[Any],
    fallback_indices: set[int] | None = None,
) -> list[Any]:
    """Build ImageResult objects matching the given request list."""
    from renderdeck_mcp.generation.gemini import ImageResult

    fallback_indices = fallback_indices or set()
    return [
        ImageResult(
            slide_index=req.slide_index,
            image_bytes=None if i in fallback_indices else _make_real_png(),
            fallback=i in fallback_indices,
        )
        for i, req in enumerate(requests)
    ]


# ===========================================================================
# Integration Area 1: Parser → generate_deck pipeline
#
# Verifies that reference_images parsed from the prompt file are threaded
# through to the SlideImageRequest objects passed to generate_images_concurrent.
# The parser and hash-computation run real code; only the Gemini API is mocked.
# ===========================================================================


@pytest.mark.asyncio
async def test_int_parser_references_reach_slide_image_requests(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-PD01: Parsed reference_images flow through to SlideImageRequest.reference_images.

    The parser extracts the REFERENCES: block from each slide body. After parsing,
    run_generate_deck builds SlideImageRequest objects. This test confirms that the
    reference_images tuple on each request matches the parsed references from the
    prompt file.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    captured_requests: list[Any] = []

    async def _capture_and_return(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        captured_requests.extend(requests)
        return _make_image_results_from_requests(requests)

    with (
        patch(_GEN_CONCURRENT, side_effect=_capture_and_return),
        patch(_LOAD_CACHE, return_value=None),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            slide_prompt_content=_DECK_WITH_REFERENCES,
            output_path=str(fake_output),
        )

    assert result["status"] == "ok", f"Unexpected error: {result}"
    assert result["slide_count"] == 2
    assert len(captured_requests) == 2

    # Slide 01 — one URL reference
    req_slide1 = next(r for r in captured_requests if r.slide_index == 0)
    assert len(req_slide1.reference_images) == 1
    assert req_slide1.reference_images[0]["url"] == "https://example.com/screenshot.png"
    assert req_slide1.reference_images[0]["role"] == "product screenshot"
    assert req_slide1.reference_images[0]["placement"] == "center"

    # Slide 02 — two references: one URL and one base64
    req_slide2 = next(r for r in captured_requests if r.slide_index == 1)
    assert len(req_slide2.reference_images) == 2
    url_refs = [r for r in req_slide2.reference_images if "url" in r]
    b64_refs = [r for r in req_slide2.reference_images if "base64" in r]
    assert len(url_refs) == 1
    assert len(b64_refs) == 1
    assert url_refs[0]["url"] == "https://example.com/logo.png"
    assert b64_refs[0]["media_type"] == "image/jpeg"


@pytest.mark.asyncio
async def test_int_parser_no_references_yields_empty_tuples(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-PD02: Slides without REFERENCES: blocks produce reference_images=() on requests.

    Backward-compatibility check: existing prompt files without REFERENCES: blocks
    must not gain any references through the pipeline.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    captured_requests: list[Any] = []

    async def _capture_and_return(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        captured_requests.extend(requests)
        return _make_image_results_from_requests(requests)

    with (
        patch(_GEN_CONCURRENT, side_effect=_capture_and_return),
        patch(_LOAD_CACHE, return_value=None),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            slide_prompt_content=_DECK_WITHOUT_REFERENCES,
            output_path=str(fake_output),
        )

    assert result["status"] == "ok"
    for req in captured_requests:
        assert req.reference_images == (), (
            f"Slide {req.slide_index} should have empty references, got {req.reference_images!r}"
        )


@pytest.mark.asyncio
async def test_int_parser_mixed_references_only_on_correct_slides(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-PD03: Only the slide with REFERENCES: gets references; the other stays empty.

    Verifies that reference_images from one slide do not leak into other slides.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    captured_requests: list[Any] = []

    async def _capture_and_return(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        captured_requests.extend(requests)
        return _make_image_results_from_requests(requests)

    with (
        patch(_GEN_CONCURRENT, side_effect=_capture_and_return),
        patch(_LOAD_CACHE, return_value=None),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            slide_prompt_content=_DECK_MIXED_REFERENCES,
            output_path=str(fake_output),
        )

    assert result["status"] == "ok"
    assert len(captured_requests) == 2

    req_with_ref = next(r for r in captured_requests if r.slide_index == 0)
    req_without_ref = next(r for r in captured_requests if r.slide_index == 1)

    assert len(req_with_ref.reference_images) == 1
    assert req_with_ref.reference_images[0]["url"] == "https://example.com/img.png"

    assert req_without_ref.reference_images == ()


@pytest.mark.asyncio
async def test_int_parser_reference_images_stripped_from_image_prompt(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-PD04: The REFERENCES: block is stripped from image_prompt before generation.

    The SlideImageRequest.prompt must not contain the REFERENCES: keyword or any URL.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    captured_requests: list[Any] = []

    async def _capture_and_return(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        captured_requests.extend(requests)
        return _make_image_results_from_requests(requests)

    with (
        patch(_GEN_CONCURRENT, side_effect=_capture_and_return),
        patch(_LOAD_CACHE, return_value=None),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=None),
    ):
        await run_generate_deck(
            slide_prompt_content=_DECK_WITH_REFERENCES,
            output_path=str(fake_output),
        )

    for req in captured_requests:
        assert "REFERENCES:" not in req.prompt, (
            f"Slide {req.slide_index} prompt contains REFERENCES: keyword"
        )
        assert "https://example.com/screenshot.png" not in req.prompt


# ===========================================================================
# Integration Area 2: generate_slide MCP tool end-to-end
#
# Verifies that the server.generate_slide MCP tool accepts reference_images
# and threads it all the way through to run_generate_slide → SlideImageRequest.
# ===========================================================================


@pytest.mark.asyncio
async def test_int_mcp_generate_slide_tool_accepts_reference_images(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-MCP01: server.generate_slide MCP tool accepts reference_images parameter.

    The MCP tool layer (server.py) must forward reference_images to run_generate_slide.
    This tests the boundary between the MCP tool definition and the implementation.
    """
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    png_b64 = base64.b64encode(MINIMAL_PNG).decode("ascii")
    captured_requests: list[Any] = []

    async def _capture_generate(client: Any, request: Any, config: Any) -> bytes:
        captured_requests.append(request)
        return _make_real_png()

    with (
        patch(_GEN_IMAGE, side_effect=_capture_generate),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        from renderdeck_mcp import server

        result = await server.generate_slide(
            project_name="test-proj",
            slide_number=1,
            image_prompt="A product slide",
            reference_images=[{"base64": png_b64, "role": "logo", "placement": "top-right"}],
        )

    assert result["status"] == "ok", f"Unexpected error: {result}"
    assert len(captured_requests) == 1

    request = captured_requests[0]
    assert isinstance(request.reference_images, tuple)
    assert len(request.reference_images) == 1
    assert request.reference_images[0]["base64"] == png_b64
    assert request.reference_images[0]["role"] == "logo"


@pytest.mark.asyncio
async def test_int_mcp_generate_slide_tool_reference_images_none_default(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-MCP02: server.generate_slide with no reference_images produces empty tuple.

    When the MCP caller does not supply reference_images, the SlideImageRequest
    must have reference_images=() (backward compatible).
    """
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    captured_requests: list[Any] = []

    async def _capture_generate(client: Any, request: Any, config: Any) -> bytes:
        captured_requests.append(request)
        return _make_real_png()

    with (
        patch(_GEN_IMAGE, side_effect=_capture_generate),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        from renderdeck_mcp import server

        result = await server.generate_slide(
            project_name="test-proj",
            slide_number=1,
            image_prompt="A plain slide",
        )

    assert result["status"] == "ok"
    assert len(captured_requests) == 1
    assert captured_requests[0].reference_images == ()


@pytest.mark.asyncio
async def test_int_mcp_generate_slide_tool_reference_images_multiple(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-MCP03: Multiple reference images are all forwarded through the MCP tool layer."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    png_b64 = base64.b64encode(MINIMAL_PNG).decode("ascii")
    refs = [
        {"base64": png_b64, "role": "logo"},
        {"url": "https://example.com/background.png", "role": "background"},
        {"base64": png_b64, "media_type": "image/jpeg", "role": "hero"},
    ]

    captured_requests: list[Any] = []

    async def _capture_generate(client: Any, request: Any, config: Any) -> bytes:
        captured_requests.append(request)
        return _make_real_png()

    with (
        patch(_GEN_IMAGE, side_effect=_capture_generate),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        from renderdeck_mcp import server

        result = await server.generate_slide(
            project_name="test-proj",
            slide_number=2,
            image_prompt="A multi-ref slide",
            reference_images=refs,
        )

    assert result["status"] == "ok"
    assert len(captured_requests[0].reference_images) == 3


# ===========================================================================
# Integration Area 3: generate_deck with references — full pipeline
#
# Tests the full parse → cache check → generate → assemble flow when
# reference images are present in the prompt file.
# ===========================================================================


@pytest.mark.asyncio
async def test_int_generate_deck_with_references_succeeds(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-DECK01: Full generate_deck pipeline with REFERENCES: blocks succeeds.

    Verifies that a prompt file containing REFERENCES: blocks on every slide
    produces a successful result dict with the correct slide counts.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    async def _succeed(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        return _make_image_results_from_requests(requests)

    with (
        patch(_GEN_CONCURRENT, side_effect=_succeed),
        patch(_LOAD_CACHE, return_value=None),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            slide_prompt_content=_DECK_WITH_REFERENCES,
            output_path=str(fake_output),
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 2
    assert result["slides_generated"] == 2
    assert result["slides_cached"] == 0


@pytest.mark.asyncio
async def test_int_generate_deck_reference_images_included_in_content_hash(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-DECK02: Content hash differs for slides with vs. without references.

    run_generate_deck calls content_hash_for_slide. When reference_images are
    parsed from a slide, the computed hash must differ from the same slide with
    no references (same image_prompt text).
    """
    from renderdeck_mcp.generation.cache import content_hash_for_slide
    from renderdeck_mcp.parser.prompt_file import parse_prompt_file

    # Parse both prompt files to extract slide data
    deck_with = parse_prompt_file(_DECK_MIXED_REFERENCES)
    deck_without = parse_prompt_file(_DECK_WITHOUT_REFERENCES)

    slide_with_ref = deck_with.slides[0]  # has a REFERENCES: block
    slide_without_ref = deck_without.slides[0]  # no REFERENCES: block

    # Compute hashes as run_generate_deck would
    hash_with_ref = content_hash_for_slide(
        general=deck_with.general,
        global_rules=deck_with.global_rules,
        image_prompt=slide_with_ref.image_prompt,
        reference_images=slide_with_ref.reference_images,
    )
    hash_without_ref = content_hash_for_slide(
        general=deck_without.general,
        global_rules=deck_without.global_rules,
        image_prompt=slide_without_ref.image_prompt,
        reference_images=slide_without_ref.reference_images,
    )

    # The hashes must be different (both text and references differ)
    assert hash_with_ref != hash_without_ref


@pytest.mark.asyncio
async def test_int_generate_deck_slides_with_only_references_no_prompt_skipped(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-DECK03: A slide with REFERENCES: but no image prompt text is skipped for generation.

    has_prompt=False means generate_deck should not add this slide to the
    generation queue even if it has reference images.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    prompt_no_text = """\
# Ref-Only Deck

---

## Slide 01 — No Text

REFERENCES:
- url: https://example.com/img.png
  role: background
"""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    async def _succeed(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        return _make_image_results_from_requests(requests)

    gen_mock = AsyncMock(side_effect=_succeed)

    with (
        patch(_GEN_CONCURRENT, gen_mock),
        patch(_LOAD_CACHE, return_value=None),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            slide_prompt_content=prompt_no_text,
            output_path=str(fake_output),
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 1
    # Slide has no image prompt — Gemini should not be called
    gen_mock.assert_not_called()


# ===========================================================================
# Integration Area 4: Cache invalidation with reference images
#
# Verifies that changing reference_images causes a cache miss in the full
# generate_deck and generate_slide pipelines.
# ===========================================================================


@pytest.mark.asyncio
async def test_int_cache_miss_when_references_added_to_generate_deck(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-CACHE01: Adding REFERENCES: to a prompt causes a cache miss in generate_deck.

    First run: no references → slides cached. Second run: same prompt with added
    REFERENCES: blocks → content hashes differ → Gemini called again.
    """
    from renderdeck_mcp.generation.cache import (
        CacheManifest,
        content_hash_for_slide,
        options_hash,
    )
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    # Compute what the hashes would be for the plain (no-refs) deck
    from renderdeck_mcp.parser.prompt_file import parse_prompt_file

    deck_plain = parse_prompt_file(_DECK_WITHOUT_REFERENCES)
    model = "gemini-3-pro-image-preview"
    opts = options_hash(aspect_ratio="WIDE", model=model)

    plain_hashes = {
        idx + 1: content_hash_for_slide(
            general=deck_plain.general,
            global_rules=deck_plain.global_rules,
            image_prompt=slide.image_prompt,
            reference_images=[],  # no references
        )
        for idx, slide in enumerate(deck_plain.slides)
    }

    # Simulate a cached manifest from the plain (no-refs) deck
    cached_manifest = CacheManifest(
        version=1,
        options_hash=opts,
        slides=plain_hashes,
    )

    # Now run generate_deck with the MIXED deck (which has references on slide 1)
    gen_call_count: dict[str, int] = {"n": 0}

    async def _counting_generate(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        gen_call_count["n"] += len(requests)
        return _make_image_results_from_requests(requests)

    with (
        patch(_GEN_CONCURRENT, side_effect=_counting_generate),
        patch(_LOAD_CACHE, return_value=cached_manifest),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=_make_real_png()),
    ):
        result = await run_generate_deck(
            slide_prompt_content=_DECK_MIXED_REFERENCES,
            output_path=str(fake_output),
        )

    assert result["status"] == "ok"
    # Slide 01 now has a reference → hash changed → cache miss → regeneration
    # Slide 02 still has no references but different prompt text so also a miss
    # At minimum slide 01 must be regenerated
    assert gen_call_count["n"] >= 1


@pytest.mark.asyncio
async def test_int_cache_hit_when_references_unchanged_in_generate_slide(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-CACHE02: Same reference_images on second call hits the generate_slide cache.

    First generate_slide call writes the cached image. Second call with identical
    parameters (including same reference_images) should return cached=True and
    not call generate_image again.
    """
    from renderdeck_mcp.tools.generate_slide import run_generate_slide

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    png_b64 = base64.b64encode(MINIMAL_PNG).decode("ascii")
    refs = [{"base64": png_b64, "role": "logo", "placement": "top-right"}]
    call_count: dict[str, int] = {"n": 0}

    async def _counting_generate(client: Any, request: Any, config: Any) -> bytes:
        call_count["n"] += 1
        return _make_real_png()

    with (
        patch(_GEN_IMAGE, side_effect=_counting_generate),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        result1 = await run_generate_slide(
            project_name="cache-test",
            slide_number=1,
            image_prompt="Product overview",
            reference_images=refs,
        )
        result2 = await run_generate_slide(
            project_name="cache-test",
            slide_number=1,
            image_prompt="Product overview",
            reference_images=refs,
        )

    assert result1["status"] == "ok"
    assert result1["cached"] is False
    assert result2["status"] == "ok"
    assert result2["cached"] is True
    assert call_count["n"] == 1  # generate_image called only once


@pytest.mark.asyncio
async def test_int_cache_miss_when_reference_url_changes_in_generate_slide(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-CACHE03: Changing a reference URL causes a cache miss in generate_slide.

    A second call to generate_slide with a different URL in reference_images
    must compute a new content hash and re-generate the image.
    """
    from renderdeck_mcp.tools.generate_slide import run_generate_slide

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    call_count: dict[str, int] = {"n": 0}

    async def _counting_generate(client: Any, request: Any, config: Any) -> bytes:
        call_count["n"] += 1
        return _make_real_png()

    with (
        patch(_GEN_IMAGE, side_effect=_counting_generate),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        # First call with URL version 1
        result1 = await run_generate_slide(
            project_name="url-change-test",
            slide_number=1,
            image_prompt="A slide",
            reference_images=[{"url": "https://example.com/v1.png", "role": "logo"}],
        )
        # Second call with a different URL — hash must differ → cache miss
        result2 = await run_generate_slide(
            project_name="url-change-test",
            slide_number=1,
            image_prompt="A slide",
            reference_images=[{"url": "https://example.com/v2.png", "role": "logo"}],
        )

    assert result1["status"] == "ok"
    assert result1["cached"] is False
    assert result2["status"] == "ok"
    assert result2["cached"] is False
    assert call_count["n"] == 2  # both were cache misses


# ===========================================================================
# Integration Area 5: Error propagation
#
# Verifies that URL fetch failures in the full generate_deck pipeline result
# in correct fallback behaviour rather than pipeline abortion.
# ===========================================================================


@pytest.mark.asyncio
async def test_int_url_fetch_failure_does_not_abort_generate_deck(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-ERR01: URL fetch failure inside generate_deck pipeline does not abort generation.

    When generate_images_concurrent encounters URL-based references that cannot
    be fetched, the slide falls back to text-only generation. The overall
    generate_deck result is still status="ok".
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "test-key")
    fake_output = tmp_path / "out.pptx"

    # generate_images_concurrent is mocked to simulate what would happen if
    # URL fetches fail: images are still generated (text-only fallback inside
    # generate_image), so the results still contain valid image bytes.
    async def _succeed_despite_bad_refs(requests: list[Any], config: Any, **kw: Any) -> list[Any]:
        # Simulate the real behaviour: URL fetch fails → text-only generation succeeds
        return _make_image_results_from_requests(requests)

    with (
        patch(_GEN_CONCURRENT, side_effect=_succeed_despite_bad_refs),
        patch(_LOAD_CACHE, return_value=None),
        patch(_SAVE_CACHE),
        patch(_BUILD_PPTX, return_value=fake_output),
        patch(_READ_CACHED, return_value=None),
    ):
        result = await run_generate_deck(
            slide_prompt_content=_DECK_WITH_REFERENCES,
            output_path=str(fake_output),
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 2
    assert result["slides_generated"] == 2


@pytest.mark.asyncio
async def test_int_url_fetch_failure_logs_warning_in_generate_slide(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """INT-ERR02: A failing URL fetch in generate_slide logs a warning and returns ok.

    When generate_image encounters a URL reference that fails to fetch, it should:
    - Log a WARNING
    - Fall back to text-only generation (or skip the reference)
    - Return status="ok" (not "error")
    """
    import urllib.error

    from renderdeck_mcp.generation.gemini import (
        GeminiConfig,
        SlideImageRequest,
        generate_image,
    )

    # Real config with zero delays
    config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=1,
        max_concurrent_images=1,
        retry_delays=(0.0,),
    )

    # Build a SlideImageRequest with a URL reference
    try:
        from renderdeck_mcp.generation.types import ReferenceImageDict
    except ImportError:
        pytest.skip("generation.types not yet implemented")

    ref: ReferenceImageDict = {"url": "https://broken.example.com/img.png", "role": "hero"}
    request = SlideImageRequest(
        slide_index=0,
        prompt="A product slide",
        reference_images=(ref,),
    )

    # Mock: Gemini returns a valid image; URL fetch fails
    part = MagicMock()
    part.inline_data.data = MINIMAL_PNG
    response = MagicMock()
    response.parts = [part]
    mock_client = MagicMock()
    mock_client.models.generate_content.return_value = response

    with (
        patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.URLError("connection refused"),
        ),
        patch("asyncio.sleep", new_callable=AsyncMock),
        caplog.at_level(logging.WARNING, logger="renderdeck_mcp.generation.gemini"),
    ):
        result = await generate_image(mock_client, request, config)

    # Generation should still succeed (text-only fallback)
    assert result is not None
    assert result == MINIMAL_PNG

    # A warning must have been logged about the fetch failure
    warning_msgs = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warning_msgs) >= 1, "Expected at least one warning about the URL fetch failure"


@pytest.mark.asyncio
async def test_int_all_references_fail_generate_image_falls_back_to_text_only(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-ERR03: When all references fail, generate_image uses text-only contents.

    This crosses the _resolve_reference_image → _build_contents boundary.
    All references return None from _resolve_reference_image, so _build_contents
    must return a plain str, and the Gemini call proceeds as text-only.
    """
    from renderdeck_mcp.generation.gemini import GeminiConfig, SlideImageRequest, generate_image

    try:
        from renderdeck_mcp.generation.types import ReferenceImageDict
    except ImportError:
        pytest.skip("generation.types not yet implemented")

    config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=1,
        max_concurrent_images=1,
        retry_delays=(0.0,),
    )

    refs: tuple[ReferenceImageDict, ...] = (
        {"url": "https://bad1.example.com/img.png"},
        {"url": "https://bad2.example.com/img.png"},
        {"base64": "!!!not-valid-base64!!!"},
    )
    request = SlideImageRequest(
        slide_index=0,
        prompt="A slide with all-failing references",
        reference_images=refs,
    )

    part = MagicMock()
    part.inline_data.data = MINIMAL_PNG
    response = MagicMock()
    response.parts = [part]
    mock_client = MagicMock()
    mock_client.models.generate_content.return_value = response

    captured_contents: list[Any] = []

    def _capture_and_return(*args: Any, **kwargs: Any) -> MagicMock:
        captured_contents.append(kwargs.get("contents"))
        return response

    mock_client.models.generate_content.side_effect = _capture_and_return

    with (
        patch(
            "renderdeck_mcp.generation.gemini._fetch_url_as_base64",
            new_callable=AsyncMock,
            return_value=None,
        ),
        patch("asyncio.sleep", new_callable=AsyncMock),
    ):
        result = await generate_image(mock_client, request, config)

    # Must still produce an image (text-only path)
    assert result == MINIMAL_PNG

    # The contents argument to generate_content must be a str (text-only fallback)
    assert len(captured_contents) >= 1
    assert isinstance(captured_contents[0], str), (
        f"Expected text-only str fallback, got {type(captured_contents[0]).__name__}"
    )


# ===========================================================================
# Integration Area 6: generate_slide + generate_image boundary
#
# Tests the boundary between run_generate_slide (tool) and generate_image
# (Gemini client): verifies that the SlideImageRequest produced by the tool
# contains the right reference_images and that the image result is cached.
# ===========================================================================


@pytest.mark.asyncio
async def test_int_generate_slide_with_references_caches_result(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-GS01: run_generate_slide with references writes image to cache directory.

    After a successful run, the cache directory must contain slide_01.png and
    the manifest must record the content hash that includes the reference images.
    """
    from renderdeck_mcp.generation.cache import content_hash_for_slide, load_cache_manifest
    from renderdeck_mcp.tools.generate_slide import run_generate_slide

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    png_b64 = base64.b64encode(MINIMAL_PNG).decode("ascii")
    refs = [{"base64": png_b64, "role": "logo"}]
    real_png = _make_real_png()

    with (
        patch(_GEN_IMAGE, new_callable=AsyncMock, return_value=real_png),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        result = await run_generate_slide(
            project_name="slide-cache-test",
            slide_number=1,
            image_prompt="A slide",
            reference_images=refs,
        )

    assert result["status"] == "ok"
    assert result["cached"] is False

    # Image file must exist in cache
    cached_img = tmp_path / "cache" / "slide-cache-test" / "slide_01.png"
    assert cached_img.is_file()
    assert cached_img.read_bytes() == real_png

    # Manifest must record the hash with references included
    manifest = load_cache_manifest("slide-cache-test")
    assert manifest is not None
    assert 1 in manifest.slides

    expected_hash = content_hash_for_slide(
        general="",
        global_rules="",
        image_prompt="A slide",
        reference_images=refs,
    )
    assert manifest.slides[1] == expected_hash


@pytest.mark.asyncio
async def test_int_generate_slide_reference_images_appear_in_slide_image_request(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """INT-GS02: run_generate_slide passes reference_images as tuple to SlideImageRequest.

    This test crosses the tool → SlideImageRequest boundary: checks that the
    list passed to run_generate_slide is converted to a tuple on the request.
    """
    from renderdeck_mcp.tools.generate_slide import run_generate_slide

    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    png_b64 = base64.b64encode(MINIMAL_PNG).decode("ascii")
    refs_list = [
        {"base64": png_b64, "role": "logo"},
        {"url": "https://example.com/bg.png", "role": "background"},
    ]

    captured: list[Any] = []

    async def _capture(client: Any, request: Any, config: Any) -> bytes:
        captured.append(request)
        return _make_real_png()

    with (
        patch(_GEN_IMAGE, side_effect=_capture),
        patch("google.genai.Client", return_value=MagicMock()),
    ):
        result = await run_generate_slide(
            project_name="tuple-test",
            slide_number=3,
            image_prompt="Slide three",
            reference_images=refs_list,
        )

    assert result["status"] == "ok"
    assert len(captured) == 1

    request = captured[0]
    # Must be a tuple (frozen, hashable)
    assert isinstance(request.reference_images, tuple)
    # Must contain both entries
    assert len(request.reference_images) == 2
    # Slide index must match slide_number - 1
    assert request.slide_index == 2
