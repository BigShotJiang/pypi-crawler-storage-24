# SPDX-License-Identifier: Apache-2.0
"""Policy rules for seccomp user notification filesystem virtualization.

Defines path-based rules that the notification supervisor uses to
decide whether to allow, deny, or virtualize filesystem access.
"""

from __future__ import annotations

import errno
import fnmatch
import re
import socket
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional, Sequence, Set


class NotifAction(Enum):
    """Action for a seccomp notification path match."""

    ALLOW = "allow"          # Let the syscall proceed (CONTINUE)
    DENY = "deny"            # Return an error to the caller
    VIRTUALIZE = "virtualize"  # Inject a memfd with fake content


@dataclass(frozen=True)
class PathRule:
    """A rule matching filesystem paths to notification actions.

    Patterns use fnmatch-style globs: ``*`` matches within a component,
    ``**`` is not supported (use multiple rules or prefix matching).

    Rules are evaluated in order; first match wins.
    """

    pattern: str
    """Path pattern (fnmatch glob or exact prefix ending with '/')."""

    action: NotifAction = NotifAction.ALLOW
    """What to do when the pattern matches."""

    errno_code: int = errno.EACCES
    """Error code for DENY actions."""

    virtual_content: bytes = b""
    """Content to serve for VIRTUALIZE actions."""


_PROC_PID_RE = re.compile(r"^/proc/(\d+)(/|$)")


@dataclass(frozen=True)
class NotifPolicy:
    """Policy for the seccomp notification supervisor.

    Rules are evaluated in order — first match wins.
    If no rule matches, the default is ALLOW (syscall proceeds).

    When ``isolate_pids`` is True and a ``sandbox_pids`` callback is
    provided, accesses to ``/proc/<pid>/...`` where ``<pid>`` is not in
    the sandbox are denied with ESRCH (No such process).  Accesses to
    the sandbox's own processes pass through to the normal rule chain.
    """

    rules: tuple[PathRule, ...] = ()

    isolate_pids: bool = False
    """If True, deny /proc/<pid>/ access for PIDs outside the sandbox."""

    foreign_pid_error: int = errno.ESRCH
    """Errno returned for foreign-pid access (default: ESRCH)."""

    allowed_ips: frozenset[str] = field(default_factory=frozenset)
    """If non-empty, only connect/sendto to these IPs is allowed.
    All other destinations get ECONNREFUSED.  Populated by resolve_hosts()."""

    max_memory_bytes: int = 0
    """If > 0, total mmap/brk bytes across the sandbox are capped.
    Allocations exceeding this return ENOMEM."""

    max_processes: int = 0
    """If > 0, clone/fork is denied when process count reaches this limit."""

    port_remap: bool = False
    """If True, bind/connect ports are remapped and inbound traffic is proxied."""

    cow_enabled: bool = False
    """If True, filesystem COW syscalls (unlinkat, mkdirat, etc.) are intercepted."""

    random_seed: int | None = None
    """If set, getrandom() returns deterministic PRNG output."""

    time_start: float | None = None
    """If set, clock_gettime/gettimeofday are shifted to start from this epoch."""

    def decide(
        self,
        path: str,
        sandbox_pids: Optional[Set[int]] = None,
    ) -> tuple[NotifAction, int, bytes]:
        """Evaluate rules against a path and return the action.

        Args:
            path: Resolved absolute path from the intercepted syscall.
            sandbox_pids: Set of PIDs belonging to this sandbox (from
                the sandbox).  Only used when ``isolate_pids`` is True.

        Returns:
            (action, errno_code, virtual_content) tuple.
        """
        if self.isolate_pids and sandbox_pids is not None:
            m = _PROC_PID_RE.match(path)
            if m:
                target_pid = int(m.group(1))
                if target_pid not in sandbox_pids:
                    return NotifAction.DENY, self.foreign_pid_error, b""

        for rule in self.rules:
            if self._matches(rule.pattern, path):
                return rule.action, rule.errno_code, rule.virtual_content
        return NotifAction.ALLOW, 0, b""

    @staticmethod
    def _matches(pattern: str, path: str) -> bool:
        """Check if a path matches a rule pattern.

        Supports:
        - Exact match: ``/proc/kcore``
        - Prefix match (pattern ends with /): ``/sys/firmware/``
        - fnmatch glob: ``/proc/*/status``
        """
        if pattern.endswith("/"):
            return path == pattern.rstrip("/") or path.startswith(pattern)
        return fnmatch.fnmatch(path, pattern)


def resolve_hosts(domains: Sequence[str]) -> tuple[bytes, frozenset[str]]:
    """Resolve domain names and generate /etc/hosts content.

    Resolves each domain via getaddrinfo (both IPv4 and IPv6) and
    produces a hosts file containing only those mappings plus localhost.
    Domains that fail to resolve are silently skipped.

    Must be called before fork (parent has unrestricted network).

    Returns:
        (hosts_content, allowed_ips) — the virtual /etc/hosts bytes
        and the set of resolved IP addresses (including loopback).
    """
    lines = [
        "# Generated by sandlock",
        "127.0.0.1\tlocalhost",
        "::1\tlocalhost",
    ]
    ips: set[str] = {"127.0.0.1", "::1"}
    for domain in domains:
        seen: set[str] = set()
        try:
            results = socket.getaddrinfo(
                domain, None, type=socket.SOCK_STREAM,
            )
        except socket.gaierror:
            continue
        for family, _, _, _, sockaddr in results:
            ip = sockaddr[0]
            if ip not in seen:
                seen.add(ip)
                ips.add(ip)
                lines.append(f"{ip}\t{domain}")
    return "\n".join(lines).encode() + b"\n", frozenset(ips)


_NSSWITCH_HOSTS_CONTENT = b"hosts: files\n"


def hosts_rules(hosts_content: bytes) -> tuple[PathRule, ...]:
    """Build NotifPolicy rules that virtualize /etc/hosts and /etc/nsswitch.conf."""
    return (
        PathRule(
            "/etc/hosts", NotifAction.VIRTUALIZE,
            virtual_content=hosts_content,
        ),
        PathRule(
            "/etc/nsswitch.conf", NotifAction.VIRTUALIZE,
            virtual_content=_NSSWITCH_HOSTS_CONTENT,
        ),
    )


def default_proc_rules() -> tuple[PathRule, ...]:
    """Safe default rules: deny sensitive kernel interfaces, allow the rest."""
    return (
        # Deny kernel memory and sensitive interfaces
        PathRule("/proc/kcore", NotifAction.DENY, errno.EACCES),
        PathRule("/proc/kallsyms", NotifAction.DENY, errno.EACCES),
        PathRule("/proc/config.gz", NotifAction.DENY, errno.EACCES),
        PathRule("/proc/keys", NotifAction.DENY, errno.EACCES),
        PathRule("/proc/key-users", NotifAction.DENY, errno.EACCES),
        PathRule("/proc/sched_debug", NotifAction.DENY, errno.EACCES),
        PathRule("/proc/timer_list", NotifAction.DENY, errno.EACCES),
        PathRule("/proc/modules", NotifAction.DENY, errno.EACCES),
        # Deny sensitive sysfs paths
        PathRule("/sys/kernel/", NotifAction.DENY, errno.EACCES),
        PathRule("/sys/firmware/", NotifAction.DENY, errno.EACCES),
        PathRule("/sys/fs/cgroup/", NotifAction.DENY, errno.EACCES),
        # Virtualize mount info (hide host mounts)
        # Multiple patterns: /proc/mounts (symlink), /proc/self/mounts,
        # /proc/<pid>/mounts (resolved symlink)
        PathRule("/proc/mounts", NotifAction.VIRTUALIZE, virtual_content=b""),
        PathRule("/proc/mountinfo", NotifAction.VIRTUALIZE, virtual_content=b""),
        PathRule("/proc/*/mounts", NotifAction.VIRTUALIZE, virtual_content=b""),
        PathRule("/proc/*/mountinfo", NotifAction.VIRTUALIZE, virtual_content=b""),
        # Allow everything else
        PathRule("*", NotifAction.ALLOW),
    )
