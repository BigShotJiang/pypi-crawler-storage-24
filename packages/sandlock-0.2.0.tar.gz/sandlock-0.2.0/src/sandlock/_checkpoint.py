# SPDX-License-Identifier: Apache-2.0
"""Checkpoint and restore for sandboxed processes.

Two layers of state capture:

1. **OS-level** (automatic, transparent): Sandlock uses ptrace +
   /proc to dump registers, memory, and file descriptors from the
   frozen child.  The child does not need to cooperate.

2. **App-level** (optional, cooperative): If the child registered
   a save_fn, Sandlock triggers it via a 1-byte write on the control
   socket.  The child runs save_fn and sends raw bytes back.
   This covers state that ptrace can't see (open sockets, epoll, etc.).

Combined with BranchFS (O(1) filesystem snapshot) and SIGSTOP,
this provides full checkpoint/restore without CRIU or root.

Control socket protocol (for app-level state only):

    Parent → Child:  1 byte (0x01 = checkpoint trigger)
    Child → Parent:  4-byte big-endian length + raw state bytes
"""

from __future__ import annotations

import json
import os
import shutil
import struct
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

if TYPE_CHECKING:
    from ._ptrace import ProcessState

_DEFAULT_STORE = Path.home() / ".sandlock" / "checkpoints"

# Trigger byte
TRIGGER_CHECKPOINT = b"\x01"

# Response status
_STATUS_OK = 0
_STATUS_ERR = 1


@dataclass
class Checkpoint:
    """Complete checkpoint: OS state + filesystem + optional app state.

    All data is raw bytes — no Python-specific serialization imposed
    on the application.
    """

    # OS-level (captured automatically via ptrace)
    process_state: ProcessState | None = None
    """Registers, memory, fds — captured transparently."""

    # Filesystem (captured via BranchFS)
    branch_id: str | None = None
    """BranchFS branch UUID (O(1) COW snapshot)."""

    workdir: str | None = None
    """BranchFS mount point."""

    # App-level (optional, from save_fn)
    app_state: bytes | None = None
    """Raw bytes from save_fn. None if no save_fn registered."""

    # Metadata
    policy_data: bytes = b""
    """Serialized Policy (for re-applying confinement on restore)."""

    sandbox_id: str | None = None

    # --- Named checkpoint persistence ---

    def save(self, name: str, *, store: Path | str | None = None) -> Path:
        """Persist this checkpoint to disk under the given name.

        Storage layout::

            <store>/<name>/
            ├── meta.json          # branch_id, workdir, sandbox_id
            ├── policy.dat         # serialized Policy bytes
            ├── app_state.bin      # raw app state (optional)
            └── process/           # OS-level state (optional)
                ├── info.json      # pid, cwd, exe
                ├── fds.json       # file descriptor table
                ├── memory_map.json# region metadata
                ├── threads/
                │   └── <tid>.bin  # raw register bytes
                └── memory/
                    └── <index>.bin# raw memory contents

        Args:
            name: Checkpoint name (used as directory name).
            store: Storage root. Defaults to ``~/.sandlock/checkpoints/``.

        Returns:
            Path to the checkpoint directory.
        """
        root = Path(store) if store is not None else _DEFAULT_STORE
        cp_dir = root / name

        # Atomic-ish: write to temp, rename
        tmp_dir = cp_dir.with_suffix(".tmp")
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)
        tmp_dir.mkdir(parents=True)

        try:
            # meta.json
            meta = {
                "branch_id": self.branch_id,
                "workdir": self.workdir,
                "sandbox_id": self.sandbox_id,
            }
            (tmp_dir / "meta.json").write_text(json.dumps(meta))

            # policy.dat
            (tmp_dir / "policy.dat").write_bytes(self.policy_data)

            # app_state.bin
            if self.app_state is not None:
                (tmp_dir / "app_state.bin").write_bytes(self.app_state)

            # process state
            if self.process_state is not None:
                self._save_process_state(tmp_dir / "process")

            # Rename into place
            if cp_dir.exists():
                shutil.rmtree(cp_dir)
            tmp_dir.rename(cp_dir)

        except BaseException:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir)
            raise

        return cp_dir

    def _save_process_state(self, proc_dir: Path) -> None:
        """Write ProcessState to a directory of files."""
        ps = self.process_state
        proc_dir.mkdir()

        # info.json
        info = {"pid": ps.pid, "cwd": ps.cwd, "exe": ps.exe}
        (proc_dir / "info.json").write_text(json.dumps(info))

        # fds.json
        fds = [
            {
                "fd": fd.fd,
                "path": fd.path,
                "flags": fd.flags,
                "offset": fd.offset,
                "restorable": fd.restorable,
            }
            for fd in ps.fds
        ]
        (proc_dir / "fds.json").write_text(json.dumps(fds))

        # threads/<tid>.bin — raw register bytes
        threads_dir = proc_dir / "threads"
        threads_dir.mkdir()
        thread_meta = []
        for ts in ps.threads:
            (threads_dir / f"{ts.tid}.bin").write_bytes(ts.registers.data)
            thread_meta.append({
                "tid": ts.tid,
                "arch": ts.registers.arch,
            })
        (proc_dir / "threads.json").write_text(json.dumps(thread_meta))

        # memory/<index>.bin — raw memory contents
        mem_dir = proc_dir / "memory"
        mem_dir.mkdir()
        mem_map = []
        for i, region in enumerate(ps.memory):
            (mem_dir / f"{i}.bin").write_bytes(region.contents)
            mem_map.append({
                "start": region.start,
                "end": region.end,
                "perms": region.perms,
                "offset": region.offset,
                "path": region.path,
            })
        (proc_dir / "memory_map.json").write_text(json.dumps(mem_map))

    @classmethod
    def load(cls, name: str, *, store: Path | str | None = None) -> "Checkpoint":
        """Load a named checkpoint from disk.

        Args:
            name: Checkpoint name.
            store: Storage root. Defaults to ``~/.sandlock/checkpoints/``.

        Returns:
            Checkpoint with all state restored.

        Raises:
            FileNotFoundError: If the checkpoint does not exist.
        """
        root = Path(store) if store is not None else _DEFAULT_STORE
        cp_dir = root / name
        if not cp_dir.is_dir():
            raise FileNotFoundError(f"Checkpoint not found: {cp_dir}")

        # meta.json
        meta = json.loads((cp_dir / "meta.json").read_text())

        # policy.dat
        policy_data = (cp_dir / "policy.dat").read_bytes()

        # app_state.bin
        app_path = cp_dir / "app_state.bin"
        app_state = app_path.read_bytes() if app_path.exists() else None

        # process state
        proc_dir = cp_dir / "process"
        process_state = cls._load_process_state(proc_dir) if proc_dir.is_dir() else None

        return cls(
            process_state=process_state,
            branch_id=meta.get("branch_id"),
            workdir=meta.get("workdir"),
            app_state=app_state,
            policy_data=policy_data,
            sandbox_id=meta.get("sandbox_id"),
        )

    @staticmethod
    def _load_process_state(proc_dir: Path) -> "ProcessState":
        """Read ProcessState from a directory of files."""
        from ._ptrace import (
            ProcessState, ThreadState, RegisterState,
            MemoryRegion, FileDescriptor,
        )

        info = json.loads((proc_dir / "info.json").read_text())

        # Threads
        thread_meta = json.loads((proc_dir / "threads.json").read_text())
        threads = []
        for tm in thread_meta:
            reg_data = (proc_dir / "threads" / f"{tm['tid']}.bin").read_bytes()
            threads.append(ThreadState(
                tid=tm["tid"],
                registers=RegisterState(arch=tm["arch"], data=reg_data),
            ))

        # Memory
        mem_map = json.loads((proc_dir / "memory_map.json").read_text())
        memory = []
        for i, mm in enumerate(mem_map):
            contents = (proc_dir / "memory" / f"{i}.bin").read_bytes()
            memory.append(MemoryRegion(
                start=mm["start"],
                end=mm["end"],
                perms=mm["perms"],
                offset=mm["offset"],
                path=mm["path"],
                contents=contents,
            ))

        # File descriptors
        fds_data = json.loads((proc_dir / "fds.json").read_text())
        fds = [
            FileDescriptor(
                fd=fd["fd"],
                path=fd["path"],
                flags=fd["flags"],
                offset=fd["offset"],
                restorable=fd["restorable"],
            )
            for fd in fds_data
        ]

        return ProcessState(
            pid=info["pid"],
            threads=threads,
            memory=memory,
            fds=fds,
            cwd=info.get("cwd", ""),
            exe=info.get("exe", ""),
        )

    @classmethod
    def list(cls, *, store: Path | str | None = None) -> list[str]:
        """List all named checkpoints.

        Args:
            store: Storage root. Defaults to ``~/.sandlock/checkpoints/``.

        Returns:
            Sorted list of checkpoint names.
        """
        root = Path(store) if store is not None else _DEFAULT_STORE
        if not root.is_dir():
            return []
        return sorted(
            d.name for d in root.iterdir()
            if d.is_dir() and (d / "meta.json").exists()
        )

    @classmethod
    def delete(cls, name: str, *, store: Path | str | None = None) -> None:
        """Delete a named checkpoint.

        Args:
            name: Checkpoint name.
            store: Storage root. Defaults to ``~/.sandlock/checkpoints/``.

        Raises:
            FileNotFoundError: If the checkpoint does not exist.
        """
        root = Path(store) if store is not None else _DEFAULT_STORE
        cp_dir = root / name
        if not cp_dir.is_dir():
            raise FileNotFoundError(f"Checkpoint not found: {cp_dir}")
        shutil.rmtree(cp_dir)


# --- Control socket protocol (for app-level state) ---

def _send_bytes(fd: int, data: bytes) -> None:
    """Send length-prefixed bytes."""
    header = struct.pack(">I", len(data))
    payload = header + data
    view = memoryview(payload)
    while len(view) > 0:
        written = os.write(fd, view)
        view = view[written:]


def _recv_bytes(fd: int) -> bytes:
    """Receive length-prefixed bytes."""
    header = b""
    while len(header) < 4:
        chunk = os.read(fd, 4 - len(header))
        if not chunk:
            raise EOFError("Control socket closed")
        header += chunk
    length = struct.unpack(">I", header)[0]
    if length == 0:
        return b""
    data = b""
    while len(data) < length:
        chunk = os.read(fd, min(length - len(data), 65536))
        if not chunk:
            raise EOFError("Control socket closed mid-read")
        data += chunk
    return data


# --- Child side ---

class _CheckpointListener:
    """Listens for checkpoint triggers in the child process.

    save_fn is registered at construction in the child's address space.
    The parent triggers it by writing a single byte to the control socket.
    """

    def __init__(self, control_fd: int, save_fn: Callable[[], bytes]):
        self._fd = control_fd
        self._save_fn = save_fn

    def start(self) -> None:
        t = threading.Thread(target=self._run, name="sandlock-ckpt", daemon=True)
        t.start()

    def _run(self) -> None:
        try:
            while True:
                trigger = os.read(self._fd, 1)
                if not trigger:
                    break
                if trigger == TRIGGER_CHECKPOINT:
                    self._do_checkpoint()
        except OSError:
            pass
        finally:
            try:
                os.close(self._fd)
            except OSError:
                pass

    def _do_checkpoint(self) -> None:
        try:
            state = self._save_fn()
            _send_bytes(self._fd, bytes([_STATUS_OK]) + state)
        except Exception as e:
            msg = f"{type(e).__name__}: {e}".encode("utf-8", errors="replace")
            _send_bytes(self._fd, bytes([_STATUS_ERR]) + msg)


def start_child_listener(
    control_fd: int,
    save_fn: Callable[[], bytes],
) -> None:
    """Start the checkpoint listener in the child process."""
    _CheckpointListener(control_fd, save_fn).start()


# --- Clone-ready loop (runs on main thread after init_fn returns) ---

TRIGGER_FORK = b"\x03"


import ctypes as _ctypes
import ctypes.util as _ctypes_util
import platform as _platform

_libc = _ctypes.CDLL(_ctypes_util.find_library("c"), use_errno=True)
_libc.syscall.restype = _ctypes.c_long
_NR_FORK = 57 if _platform.machine() == "x86_64" else None


def _raw_fork() -> int:
    """Raw fork(2) syscall, bypassing glibc clone() wrapper.

    Python's ``os.fork()`` uses ``clone``, which seccomp intercepts
    via USER_NOTIF for process counting.  The ``fork`` syscall (NR 57)
    is NOT intercepted, so it goes straight through BPF.
    """
    if _NR_FORK is None:
        return os.fork()
    pid = _libc.syscall(_ctypes.c_long(_NR_FORK))
    if pid < 0:
        err = _ctypes.get_errno()
        raise OSError(err, os.strerror(err))
    return pid


TRIGGER_FORK_BATCH = b"\x04"


def clone_ready_loop(control_fd: int, work_fn: "Callable") -> None:
    """Main-thread loop: wait for fork commands, fork and run work_fn.

    After init_fn returns, the main thread enters this loop.  It blocks
    on ``os.read()`` (GIL released), so no CPU is wasted.  When the
    parent sends TRIGGER_FORK, the main thread calls raw ``fork(2)``
    (not ``os.fork()``), bypassing the seccomp USER_NOTIF round-trip.

    Also supports TRIGGER_FORK_BATCH: fork N clones in a tight loop
    with a single round-trip, returning all PIDs at once.

    Args:
        control_fd: Child's end of the control socket.
        work_fn: Function to run in each clone.
    """
    import sys

    while True:
        try:
            trigger = os.read(control_fd, 1)
        except OSError:
            break
        if not trigger:
            break

        if trigger == TRIGGER_FORK:
            try:
                env_json = _recv_bytes(control_fd)
            except (EOFError, OSError):
                break

            env = json.loads(env_json) if env_json else {}

            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass

            try:
                pid = _raw_fork()
            except OSError:
                os.write(control_fd, struct.pack(">I", 0))
                continue

            if pid == 0:
                # === Clone child ===
                try:
                    os.close(control_fd)
                    os.setpgid(0, 0)
                    os.environ.update(env)
                    work_fn()
                except SystemExit as e:
                    os._exit(e.code if isinstance(e.code, int) else 1)
                except BaseException:
                    os._exit(1)
                os._exit(0)
            else:
                # === Template: send clone PID back ===
                os.write(control_fd, struct.pack(">I", pid))

        elif trigger == TRIGGER_FORK_BATCH:
            # Batch fork: receive all envs, fork in tight loop,
            # send all PIDs back in one write.
            try:
                batch_json = _recv_bytes(control_fd)
            except (EOFError, OSError):
                break

            env_list = json.loads(batch_json) if batch_json else []
            n = len(env_list)

            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass

            pids = []
            for env in env_list:
                try:
                    pid = _raw_fork()
                except OSError:
                    pids.append(0)
                    continue

                if pid == 0:
                    try:
                        os.close(control_fd)
                        os.setpgid(0, 0)
                        os.environ.update(env)
                        work_fn()
                    except SystemExit as e:
                        os._exit(e.code if isinstance(e.code, int) else 1)
                    except BaseException:
                        os._exit(1)
                    os._exit(0)
                else:
                    pids.append(pid)

            # Send all PIDs in one write
            os.write(control_fd, struct.pack(f">{n}I", *pids))


def request_fork(
    control_fd: int,
    env: dict[str, str] | None = None,
) -> int:
    """Send a fork command to the template's clone-ready loop.

    Args:
        control_fd: Parent's end of the control socket.
        env: Environment variable overrides for the clone.

    Returns:
        PID of the clone child.

    Raises:
        RuntimeError: If fork failed in the child.
    """
    env_json = json.dumps(env or {}).encode()
    os.write(control_fd, TRIGGER_FORK)
    _send_bytes(control_fd, env_json)

    raw = os.read(control_fd, 4)
    if len(raw) < 4:
        raise RuntimeError("Fork: no response from child")
    pid = struct.unpack(">I", raw)[0]
    if pid == 0:
        raise RuntimeError("Fork: fork() failed in child")
    return pid


def request_fork_batch(
    control_fd: int,
    envs: list[dict[str, str]],
) -> list[int]:
    """Send a batch fork command. Returns list of clone PIDs."""
    batch_json = json.dumps(envs).encode()
    os.write(control_fd, TRIGGER_FORK_BATCH)
    _send_bytes(control_fd, batch_json)

    n = len(envs)
    raw = b""
    while len(raw) < n * 4:
        chunk = os.read(control_fd, n * 4 - len(raw))
        if not chunk:
            raise RuntimeError("Fork batch: connection closed")
        raw += chunk
    pids = list(struct.unpack(f">{n}I", raw))
    return pids


# --- Parent side ---

def request_app_state(control_fd: int) -> bytes:
    """Trigger save_fn in the child and receive app state bytes.

    Args:
        control_fd: Parent's end of the control socket.

    Returns:
        Raw bytes from the child's save_fn.

    Raises:
        RuntimeError: If save_fn failed in the child.
    """
    os.write(control_fd, TRIGGER_CHECKPOINT)
    response = _recv_bytes(control_fd)
    if len(response) == 0:
        raise RuntimeError("Empty checkpoint response")
    status = response[0]
    payload = response[1:]
    if status == _STATUS_OK:
        return payload
    elif status == _STATUS_ERR:
        raise RuntimeError(
            f"save_fn failed in child: {payload.decode('utf-8', errors='replace')}"
        )
    else:
        raise RuntimeError(f"Unknown response status: {status}")
