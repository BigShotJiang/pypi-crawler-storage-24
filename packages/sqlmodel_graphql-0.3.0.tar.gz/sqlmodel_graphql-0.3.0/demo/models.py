"""SQLModel entity definitions for the demo application."""

from typing import Optional

from sqlmodel import Field, Relationship, SQLModel, select

from sqlmodel_graphql import QueryMeta, mutation, query


class BaseEntity(SQLModel):
    """Base class for all demo entities."""

    pass


class User(BaseEntity, table=True):
    """User entity."""

    id: int | None = Field(default=None, primary_key=True)
    name: str
    email: str

    # Relationship: User has many posts
    posts: list["Post"] = Relationship(back_populates="author")

    # Relationship: User has many comments
    comments: list["Comment"] = Relationship(back_populates="author")

    @query(name="users", description="Get all users with optional limit")
    async def get_all(
        cls, limit: int = 10, query_meta: QueryMeta | None = None
    ) -> list["User"]:
        """Get all users with optional limit."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).limit(limit)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return list(result.all())

    @query(name="user", description="Get a user by ID")
    async def get_by_id(cls, id: int, query_meta: QueryMeta | None = None) -> Optional["User"]:
        """Get a user by ID."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).where(cls.id == id)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return result.first()

    @mutation(name="create_user", description="Create a new user")
    async def create(cls, name: str, email: str, query_meta: QueryMeta) -> "User":
        """Create a new user (idempotent)."""
        from demo.database import async_session

        async with async_session() as session:
            # Idempotency check: return existing user if email already exists
            existing = await session.exec(select(cls).where(cls.email == email))
            if existing.first():
                stmt = select(cls).where(cls.id == existing.first().id)
                stmt = stmt.options(*query_meta.to_options(cls))
                result = await session.exec(stmt)
                return result.first()

            user = cls(name=name, email=email)
            session.add(user)
            await session.commit()
            await session.refresh(user)

            # Re-query with query_meta to load relationships
            stmt = select(cls).where(cls.id == user.id)
            stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return result.first()


class Post(BaseEntity, table=True):
    """Post entity."""

    id: int | None = Field(default=None, primary_key=True)
    title: str
    content: str
    author_id: int = Field(foreign_key="user.id")

    # Relationship: Post belongs to User
    author: Optional["User"] = Relationship(back_populates="posts")

    # Relationship: Post has many comments
    comments: list["Comment"] = Relationship(back_populates="post")

    @query(name="posts", description="Get all posts with optional limit")
    async def get_all(
        cls, limit: int = 10, query_meta: QueryMeta | None = None
    ) -> list["Post"]:
        """Get all posts with optional limit."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).limit(limit)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return list(result.all())

    @query(name="post", description="Get a post by ID")
    async def get_by_id(cls, id: int, query_meta: QueryMeta | None = None) -> Optional["Post"]:
        """Get a post by ID."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).where(cls.id == id)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return result.first()

    @query(name="posts_by_author", description="Get posts by author ID")
    async def get_by_author(
        cls, author_id: int, limit: int = 10, query_meta: QueryMeta | None = None
    ) -> list["Post"]:
        """Get posts by author ID."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).where(cls.author_id == author_id).limit(limit)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return list(result.all())

    @mutation(name="create_post")
    async def create(
        cls, title: str, content: str, author_id: int, query_meta: QueryMeta
    ) -> "Post":
        """Create a new post (idempotent)."""
        from demo.database import async_session

        async with async_session() as session:
            # Idempotency check: return existing post if same title + author
            existing = await session.exec(
                select(cls).where(cls.title == title, cls.author_id == author_id)
            )
            if existing.first():
                stmt = select(cls).where(cls.id == existing.first().id)
                stmt = stmt.options(*query_meta.to_options(cls))
                result = await session.exec(stmt)
                return result.first()

            post = cls(title=title, content=content, author_id=author_id)
            session.add(post)
            await session.commit()
            await session.refresh(post)

            # Re-query with query_meta to load relationships
            stmt = select(cls).where(cls.id == post.id)
            stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return result.first()


class Comment(BaseEntity, table=True):
    """Comment entity."""

    id: int | None = Field(default=None, primary_key=True)
    content: str
    post_id: int = Field(foreign_key="post.id")
    author_id: int = Field(foreign_key="user.id")

    # Relationship: Comment belongs to Post
    post: Optional["Post"] = Relationship(back_populates="comments")

    # Relationship: Comment belongs to User
    author: Optional["User"] = Relationship(back_populates="comments")

    @query(name="comments", description="Get all comments with optional limit")
    async def get_all(
        cls, limit: int = 10, query_meta: QueryMeta | None = None
    ) -> list["Comment"]:
        """Get all comments with optional limit."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).limit(limit)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return list(result.all())

    @query(name="comment", description="Get a comment by ID")
    async def get_by_id(cls, id: int, query_meta: QueryMeta | None = None) -> Optional["Comment"]:
        """Get a comment by ID."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).where(cls.id == id)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return result.first()

    @query(name="comments_by_post", description="Get comments by post ID")
    async def get_by_post(
        cls, post_id: int, limit: int = 10, query_meta: QueryMeta | None = None
    ) -> list["Comment"]:
        """Get comments by post ID."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).where(cls.post_id == post_id).limit(limit)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return list(result.all())

    @query(name="comments_by_author", description="Get comments by author ID")
    async def get_by_author(
        cls, author_id: int, limit: int = 10, query_meta: QueryMeta | None = None
    ) -> list["Comment"]:
        """Get comments by author ID."""
        from demo.database import async_session

        async with async_session() as session:
            stmt = select(cls).where(cls.author_id == author_id).limit(limit)
            if query_meta:
                stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return list(result.all())

    @mutation(name="create_comment", description="Create a new comment")
    async def create(
        cls, content: str, post_id: int, author_id: int, query_meta: QueryMeta
    ) -> "Comment":
        """Create a new comment (idempotent)."""
        from demo.database import async_session

        async with async_session() as session:
            # Idempotency check: return existing comment if same content + post + author
            existing = await session.exec(
                select(cls).where(
                    cls.content == content,
                    cls.post_id == post_id,
                    cls.author_id == author_id,
                )
            )
            if existing.first():
                stmt = select(cls).where(cls.id == existing.first().id)
                stmt = stmt.options(*query_meta.to_options(cls))
                result = await session.exec(stmt)
                return result.first()

            comment = cls(content=content, post_id=post_id, author_id=author_id)
            session.add(comment)
            await session.commit()
            await session.refresh(comment)

            # Re-query with query_meta to load relationships
            stmt = select(cls).where(cls.id == comment.id)
            stmt = stmt.options(*query_meta.to_options(cls))
            result = await session.exec(stmt)
            return result.first()
