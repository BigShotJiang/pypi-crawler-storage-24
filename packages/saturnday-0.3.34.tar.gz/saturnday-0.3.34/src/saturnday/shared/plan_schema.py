"""Single source of truth for plan JSON schema.

Used by both the planner prompt and the plan validator.
"""

from __future__ import annotations

from typing import Any

PLAN_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["version", "project_id", "tickets"],
    "properties": {
        "version": {"type": "integer", "const": 1},
        "project_id": {"type": "string", "minLength": 1},
        "notes": {"type": "string"},
        "mode": {"type": "string", "enum": ["generation", "remediation"]},
        "definition_of_done": {
            "type": "array",
            "items": {
                "type": "string",
                "enum": ["tickets_applied", "all_tickets_passed"],
            },
        },
        "stop_conditions": {
            "type": "array",
            "items": {"type": "string"},
        },
        "max_project_tickets": {
            "type": "integer",
            "minimum": 1,
        },
        "default_timeout_seconds": {
            "type": "integer",
            "minimum": 1,
        },
        "default_retry_limit": {
            "type": "integer",
            "minimum": 0,
        },
        "phases": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["phase_id", "ticket_ids"],
                "properties": {
                    "phase_id": {"type": "string"},
                    "name": {"type": "string"},
                    "ticket_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
            },
        },
        "tickets": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "required": ["ticket_id", "goal"],
                "properties": {
                    "ticket_id": {"type": "string", "minLength": 1},
                    "goal": {"type": "string", "minLength": 1},
                    "verify_cmd": {"type": "string"},
                    "acceptance_criteria": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "dependencies": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "out_of_scope": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "evidence_required": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "failure_mode": {"type": "string"},
                    "if_blocked": {"type": "string"},
                    "scope": {
                        "type": "object",
                        "properties": {
                            "allowed_globs": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "forbidden_globs": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "budgets": {
                                "type": "object",
                                "properties": {
                                    "max_files_changed": {"type": "integer", "minimum": 1},
                                    "max_total_diff_lines": {"type": "integer", "minimum": 1},
                                    "max_per_file_diff_lines": {"type": "integer", "minimum": 1},
                                },
                            },
                        },
                    },
                },
            },
        },
    },
}


def schema_for_prompt() -> str:
    """Return a human-readable schema description for inclusion in planner prompts.

    This is NOT the JSON schema — it's a natural-language description
    optimized for LLM consumption.
    """
    return """\
You must output a valid JSON plan with this structure:

{
  "version": 1,
  "project_id": "<short-kebab-case-id>",
  "notes": "<context for the coder — repo layout, conventions, constraints>",
  "mode": "generation" | "remediation",
  "definition_of_done": ["all_tickets_passed"],
  "stop_conditions": [],
  "max_project_tickets": null,
  "phases": [
    {"phase_id": "phase-1", "name": "Build", "ticket_ids": ["T001", "T002"]}
  ],
  "tickets": [
    {
      "ticket_id": "T001",
      "goal": "Clear, specific instruction for what to create or change.",
      "verify_cmd": "pytest tests/test_foo.py -q",
      "acceptance_criteria": ["function parse_event exists in src/parser.py", "class Event exists in src/models.py", "file src/models.py exists", "test test_parse_event exists in tests/test_parser.py"],
      "out_of_scope": ["Do not modify existing tests", "Do not change the API surface"],
      "evidence_required": ["New test file passes", "Function exists in module"],
      "failure_mode": "coder_error",
      "if_blocked": "Check dependency T001 output, verify function signature",
      "dependencies": [],
      "scope": {
        "allowed_globs": ["src/**", "tests/**"],
        "forbidden_globs": ["*.lock"],
        "budgets": {
          "max_files_changed": 2,
          "max_total_diff_lines": 80,
          "max_per_file_diff_lines": 60
        }
      }
    }
  ]
}

Rules:
- Each ticket must change at most 2 files and 80 lines total.
- Each ticket must have at most 3 dependencies.
- ticket_id must be unique across the plan.
- dependencies must reference ticket_ids defined in the plan.
- Goal must be specific and actionable — not vague directions.
- verify_cmd should be a concrete command that validates the ticket.
- Phases group tickets for progress tracking (optional).
- definition_of_done: "all_tickets_passed" requires all tickets to PASS.
- stop_conditions: normalized markers that abort the run if matched.
- out_of_scope: explicitly state what the ticket must NOT do.
- evidence_required: what artifacts must exist after the ticket completes.
- failure_mode: expected failure type (coder_error, spec_ambiguity, dependency_missing, governance_block).
- if_blocked: what the operator should do if the ticket fails all retries.
- The ticket rubric aligns with the engineering standards corpus: tickets should be written so code produced to satisfy them naturally meets the engineering constitution, testing rules, and senior judgment rules.
"""
