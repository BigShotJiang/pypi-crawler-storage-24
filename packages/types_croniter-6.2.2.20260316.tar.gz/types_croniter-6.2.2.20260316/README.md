## Typing stubs for croniter

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`croniter`](https://github.com/pallets-eco/croniter) package. It can be used by type checkers
to check code that uses `croniter`. This version of
`types-croniter` aims to provide accurate annotations for
`croniter==6.2.2`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/croniter`](https://github.com/python/typeshed/tree/main/stubs/croniter)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`61524fab4e1804462cc31d2e6b43ff7279188f85`](https://github.com/python/typeshed/commit/61524fab4e1804462cc31d2e6b43ff7279188f85).