#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Written by Lucas Sinclair.
GNUv3 Licensed.
Contact at www.sinclair.bio
"""

# Use the optmagic library to make a command line tool automatically #
from optmagic import OptMagic

# The main object of our package #
from crest4 import Classify

# The main function to run when we are called #
def main():
    magic = OptMagic(Classify)
    return magic()

# Execute when run, not when imported #
if __name__ == "__main__": main()