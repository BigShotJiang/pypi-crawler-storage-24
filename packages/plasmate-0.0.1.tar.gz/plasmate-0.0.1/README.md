# Plasmate

The agent-native headless browser engine.

- **AWP** (Agent Web Protocol) replaces CDP
- **SOM** (Semantic Object Model) replaces DOM dumps
- **Wasm Skills** for community-extensible site automation

Built in Rust. Open source (Apache 2.0).

https://plasmate.app
