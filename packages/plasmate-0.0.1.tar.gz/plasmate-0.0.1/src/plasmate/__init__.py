"""Plasmate - The agent-native headless browser engine."""
__version__ = "0.0.1"
