"""测试下载器核心功能"""
from unittest.mock import MagicMock, patch, PropertyMock

from bw_retry_downloader import Downloader, Task, RetryPolicy, DownloadReport


def _mock_response(status_code=200, text="ok", content=b"ok", headers=None):
    """构造 mock 响应对象"""
    resp = MagicMock()
    resp.status_code = status_code
    resp.text = text
    resp.content = content
    resp.headers = headers or {}
    return resp


class TestDownloader:
    """Downloader 核心功能测试"""

    def test_basic_download(self):
        """基本下载：全部成功"""
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_response(200)

        dl = Downloader(workers=2, session=mock_session)
        dl.add_tasks([
            Task(url="https://example.com/1"),
            Task(url="https://example.com/2"),
            Task(url="https://example.com/3"),
        ])
        report = dl.run()

        assert report.total == 3
        assert report.success_count == 3
        assert report.failed_count == 0

    def test_non_2xx_without_retry(self):
        """非重试状态码（如 404）标记为失败但不重试"""
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_response(404, text="Not Found")

        policy = RetryPolicy(fast_retries=1, slow_retries=1)
        dl = Downloader(workers=1, session=mock_session, retry_policy=policy)
        dl.add_task(Task(url="https://example.com/missing"))
        report = dl.run()

        assert report.failed_count == 1
        assert report.failed[0].status_code == 404
        assert report.failed[0].error == "HTTP 404"
        # 404 不在重试列表，只尝试 1 次
        assert report.failed[0].attempts == 1

    def test_retry_on_500(self):
        """500 触发重试"""
        mock_session = MagicMock()
        # 前 2 次返回 500，第 3 次成功
        mock_session.request.side_effect = [
            _mock_response(500),
            _mock_response(500),
            _mock_response(200),
        ]

        # 关闭 jitter 让测试更快
        policy = RetryPolicy(fast_retries=2, slow_retries=1, fast_delay=0.01, jitter=False)
        dl = Downloader(workers=1, session=mock_session, retry_policy=policy)
        dl.add_task(Task(url="https://example.com/flaky"))
        report = dl.run()

        assert report.success_count == 1
        assert report.success[0].attempts == 3

    def test_retry_on_exception(self):
        """网络异常触发重试"""
        import requests

        mock_session = MagicMock()
        mock_session.request.side_effect = [
            requests.ConnectionError("connection refused"),
            _mock_response(200),
        ]

        policy = RetryPolicy(fast_retries=2, slow_retries=0, fast_delay=0.01, jitter=False)
        dl = Downloader(workers=1, session=mock_session, retry_policy=policy)
        dl.add_task(Task(url="https://example.com/unstable"))
        report = dl.run()

        assert report.success_count == 1
        assert report.success[0].attempts == 2

    def test_all_retries_exhausted(self):
        """所有重试耗尽后标记失败"""
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_response(503)

        policy = RetryPolicy(
            fast_retries=1, slow_retries=1,
            fast_delay=0.01, slow_delay_base=0.01, jitter=False,
        )
        dl = Downloader(workers=1, session=mock_session, retry_policy=policy)
        dl.add_task(Task(url="https://example.com/down"))
        report = dl.run()

        assert report.failed_count == 1
        assert report.failed[0].attempts == 3  # 1 + 1 + 1
        assert "503" in report.failed[0].error

    def test_meta_preserved_in_result(self):
        """meta 数据在结果中完整保留"""
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_response(200)

        dl = Downloader(workers=1, session=mock_session)
        dl.add_task(Task(
            url="https://example.com",
            meta={"product_id": 42, "source": "test"},
        ))
        report = dl.run()

        assert report.success[0].task.meta == {"product_id": 42, "source": "test"}

    def test_progress_callback(self):
        """进度回调被正确调用"""
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_response(200)

        progress_calls = []

        def on_progress(done, total, result):
            progress_calls.append((done, total, result.success))

        dl = Downloader(workers=1, session=mock_session)
        dl.add_tasks([Task(url=f"https://example.com/{i}") for i in range(3)])
        dl.run(on_progress=on_progress)

        assert len(progress_calls) == 3
        # 所有回调的 total 都是 3
        assert all(total == 3 for _, total, _ in progress_calls)
        # 所有都成功
        assert all(success for _, _, success in progress_calls)

    def test_before_request_hook(self):
        """请求前钩子可以修改任务"""
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_response(200)

        def add_header(task):
            from dataclasses import replace
            return replace(task, headers={"X-Custom": "test"})

        dl = Downloader(workers=1, session=mock_session, before_request=add_header)
        dl.add_task(Task(url="https://example.com"))
        dl.run()

        call_kwargs = mock_session.request.call_args
        assert call_kwargs.kwargs.get("headers") == {"X-Custom": "test"} or \
               call_kwargs[1].get("headers") == {"X-Custom": "test"}

    def test_after_response_hook(self):
        """响应后钩子可以修改结果"""
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_response(200, text="验证码")

        def check_captcha(result):
            if "验证码" in (result.text or ""):
                result.success = False
                result.error = "触发验证码"
            return result

        dl = Downloader(workers=1, session=mock_session, after_response=check_captcha)
        dl.add_task(Task(url="https://example.com"))
        report = dl.run()

        assert report.failed_count == 1
        assert report.failed[0].error == "触发验证码"

    def test_context_manager(self):
        """上下文管理器正确释放资源"""
        with Downloader(workers=1) as dl:
            assert dl._session is None  # 惰性创建
            _ = dl.session  # 触发创建
            assert dl._session is not None

        # 退出后 session 被关闭
        assert dl._session is None

    def test_empty_run(self):
        """无任务时 run() 返回空报告"""
        dl = Downloader(workers=1)
        report = dl.run()
        assert report.total == 0
        assert report.success_count == 0
        assert report.failed_count == 0

    def test_concurrent_execution(self):
        """多线程并发执行"""
        import threading
        import time

        mock_session = MagicMock()
        thread_ids = set()

        def slow_request(*args, **kwargs):
            thread_ids.add(threading.current_thread().ident)
            # 加一点延迟，确保多个线程有机会同时执行
            time.sleep(0.05)
            return _mock_response(200)

        mock_session.request = slow_request

        dl = Downloader(workers=3, session=mock_session)
        dl.add_tasks([Task(url=f"https://example.com/{i}") for i in range(10)])
        report = dl.run()

        assert report.success_count == 10
        # 应该用了多个线程（至少 2 个）
        assert len(thread_ids) >= 2


class TestDownloadReport:
    """DownloadReport 测试"""

    def test_failed_tasks(self):
        """failed_tasks() 返回可重新提交的任务列表"""
        t1 = Task(url="https://example.com/1")
        t2 = Task(url="https://example.com/2")
        from bw_retry_downloader import Result
        results = [
            Result(task=t1, success=True, status_code=200),
            Result(task=t2, success=False, error="timeout"),
        ]
        report = DownloadReport(results)

        failed = report.failed_tasks()
        assert len(failed) == 1
        assert failed[0].url == "https://example.com/2"

    def test_failed_urls(self):
        """failed_urls() 返回失败 URL 列表"""
        from bw_retry_downloader import Result
        t1 = Task(url="https://a.com")
        t2 = Task(url="https://b.com")
        results = [
            Result(task=t1, success=False, error="err"),
            Result(task=t2, success=False, error="err"),
        ]
        report = DownloadReport(results)
        assert set(report.failed_urls()) == {"https://a.com", "https://b.com"}

    def test_summary_format(self):
        """summary() 格式正确"""
        from bw_retry_downloader import Result
        t = Task(url="https://example.com", meta={"id": 1})
        results = [
            Result(task=t, success=False, error="HTTP 503", attempts=6),
        ]
        report = DownloadReport(results)
        s = report.summary()
        assert "总计=1" in s
        assert "成功=0" in s
        assert "失败=1" in s
        assert "HTTP 503" in s
        assert "6次" in s
