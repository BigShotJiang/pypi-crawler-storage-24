"""测试数据模型"""
import pytest

from bw_retry_downloader import Task, Result
from bw_retry_downloader.exceptions import TaskValidationError


class TestTask:
    """Task 数据模型测试"""

    def test_basic_creation(self):
        """基础创建，默认值正确"""
        t = Task(url="https://example.com")
        assert t.url == "https://example.com"
        assert t.method == "GET"
        assert t.timeout == 10.0
        assert t.task_id  # 自动生成，非空

    def test_same_input_same_id(self):
        """相同请求参数应该生成相同的 task_id（幂等性）"""
        t1 = Task(url="https://example.com", params={"a": 1, "b": 2})
        t2 = Task(url="https://example.com", params={"a": 1, "b": 2})
        assert t1.task_id == t2.task_id

    def test_params_order_irrelevant(self):
        """参数顺序不影响 task_id"""
        t1 = Task(url="https://example.com", params={"a": 1, "b": 2})
        t2 = Task(url="https://example.com", params={"b": 2, "a": 1})
        assert t1.task_id == t2.task_id

    def test_different_url_different_id(self):
        """不同 URL 生成不同的 task_id"""
        t1 = Task(url="https://example.com/1")
        t2 = Task(url="https://example.com/2")
        assert t1.task_id != t2.task_id

    def test_different_method_different_id(self):
        """不同 HTTP 方法生成不同的 task_id"""
        t1 = Task(url="https://example.com", method="GET")
        t2 = Task(url="https://example.com", method="POST")
        assert t1.task_id != t2.task_id

    def test_custom_task_id(self):
        """支持自定义 task_id"""
        t = Task(url="https://example.com", task_id="my-id")
        assert t.task_id == "my-id"

    def test_data_json_mutual_exclusion(self):
        """data 和 json 不能同时设置"""
        with pytest.raises(TaskValidationError, match="互斥"):
            Task(url="https://example.com", data="abc", json={"key": "val"})

    def test_data_alone_ok(self):
        """单独设置 data 正常"""
        t = Task(url="https://example.com", data="abc")
        assert t.data == "abc"

    def test_json_alone_ok(self):
        """单独设置 json 正常"""
        t = Task(url="https://example.com", json={"key": "val"})
        assert t.json == {"key": "val"}

    def test_to_dict_from_dict_roundtrip(self):
        """序列化/反序列化往返一致"""
        t = Task(
            url="https://example.com",
            method="POST",
            headers={"User-Agent": "test"},
            params={"q": "hello"},
            json={"key": "val"},
            timeout=5.0,
            meta={"product_id": 123, "source": "test"},
        )
        d = t.to_dict()
        t2 = Task.from_dict(d)
        assert t.url == t2.url
        assert t.method == t2.method
        assert t.headers == t2.headers
        assert t.params == t2.params
        assert t.json == t2.json
        assert t.timeout == t2.timeout
        assert t.meta == t2.meta
        assert t.task_id == t2.task_id

    def test_to_dict_omits_none(self):
        """序列化时跳过 None 字段"""
        t = Task(url="https://example.com")
        d = t.to_dict()
        assert "headers" not in d
        assert "params" not in d
        assert "meta" not in d

    def test_meta_passthrough(self):
        """meta 字段透传业务数据"""
        meta = {"db_id": 42, "source": "api", "extra": [1, 2, 3]}
        t = Task(url="https://example.com", meta=meta)
        assert t.meta == meta


class TestResult:
    """Result 数据模型测试"""

    def test_success_result(self):
        """成功结果"""
        t = Task(url="https://example.com")
        r = Result(task=t, success=True, status_code=200, text="ok")
        assert r.success
        assert r.status_code == 200
        assert r.error is None

    def test_failed_result(self):
        """失败结果包含错误信息"""
        t = Task(url="https://example.com")
        r = Result(
            task=t, success=False,
            error="ConnectionError: timeout",
            attempts=3, elapsed=5.2,
        )
        assert not r.success
        assert r.attempts == 3
        assert r.error == "ConnectionError: timeout"

    def test_result_preserves_task_meta(self):
        """结果中保留 Task 的 meta 数据"""
        t = Task(url="https://example.com", meta={"id": 99})
        r = Result(task=t, success=False, error="timeout")
        assert r.task.meta == {"id": 99}
