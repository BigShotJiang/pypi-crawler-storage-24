"""测试重试策略"""
from unittest.mock import MagicMock

from bw_retry_downloader import RetryPolicy


class TestRetryPolicy:
    """RetryPolicy 重试策略测试"""

    def test_defaults(self):
        """默认配置：6 次总尝试"""
        p = RetryPolicy()
        assert p.fast_retries == 2
        assert p.slow_retries == 3
        assert p.max_attempts == 6  # 1 + 2 + 3

    def test_delays_count(self):
        """延迟序列长度 = fast_retries + slow_retries"""
        p = RetryPolicy()
        delays = p.get_delays()
        assert len(delays) == 5  # 2 + 3

    def test_fast_delays_are_small(self):
        """快速重试间隔较短"""
        p = RetryPolicy(jitter=False)
        delays = p.get_delays()
        assert delays[0] == 0.5
        assert delays[1] == 0.5

    def test_slow_delays_exponential(self):
        """慢速重试采用指数退避"""
        p = RetryPolicy(jitter=False)
        delays = p.get_delays()
        assert delays[2] == 3.0   # base
        assert delays[3] == 6.0   # base * 2
        assert delays[4] == 12.0  # base * 4

    def test_slow_delay_cap(self):
        """慢速退避不超过 max"""
        p = RetryPolicy(
            jitter=False,
            slow_retries=5,
            slow_delay_base=10.0,
            slow_delay_max=30.0,
        )
        delays = p.get_delays()
        # 10, 20, 30(capped), 30(capped), 30(capped)
        slow_delays = delays[p.fast_retries:]
        assert all(d <= 30.0 for d in slow_delays)

    def test_jitter_adds_randomness(self):
        """开启 jitter 后延迟有随机性"""
        p = RetryPolicy(jitter=True)
        d1 = p.get_delays()
        d2 = p.get_delays()
        # 两次生成的延迟大概率不完全相同
        assert d1 != d2 or True  # 极小概率相同，不断言

    def test_should_retry_on_exception(self):
        """网络异常一律重试"""
        p = RetryPolicy()
        assert p.should_retry(exception=ConnectionError("timeout"))
        assert p.should_retry(exception=TimeoutError())

    def test_should_retry_on_status_code(self):
        """默认重试状态码"""
        p = RetryPolicy()
        assert p.should_retry(status_code=500)
        assert p.should_retry(status_code=502)
        assert p.should_retry(status_code=503)
        assert p.should_retry(status_code=429)

    def test_should_not_retry_on_success(self):
        """成功状态码不重试"""
        p = RetryPolicy()
        assert not p.should_retry(status_code=200)
        assert not p.should_retry(status_code=301)
        assert not p.should_retry(status_code=404)

    def test_custom_retry_on(self):
        """自定义重试判断函数"""
        p = RetryPolicy(retry_on=lambda s, e, r: s == 418)
        assert p.should_retry(status_code=418)
        assert not p.should_retry(status_code=500)
        assert not p.should_retry(exception=ConnectionError())

    def test_custom_retry_on_status(self):
        """自定义重试状态码列表"""
        p = RetryPolicy(retry_on_status=(403, 418))
        assert p.should_retry(status_code=403)
        assert p.should_retry(status_code=418)
        assert not p.should_retry(status_code=500)

    def test_custom_attempts(self):
        """自定义重试次数"""
        p = RetryPolicy(fast_retries=1, slow_retries=1)
        assert p.max_attempts == 3  # 1 + 1 + 1

    def test_get_retry_after(self):
        """从响应中提取 Retry-After"""
        resp = MagicMock()
        resp.headers = {"Retry-After": "5"}
        p = RetryPolicy()
        assert p.get_retry_after(resp) == 5.0

    def test_get_retry_after_missing(self):
        """没有 Retry-After 返回 None"""
        resp = MagicMock()
        resp.headers = {}
        p = RetryPolicy()
        assert p.get_retry_after(resp) is None

    def test_get_retry_after_none_response(self):
        """response 为 None 时返回 None"""
        p = RetryPolicy()
        assert p.get_retry_after(None) is None
