"""自定义异常"""


class DownloaderError(Exception):
    """下载器基础异常"""
    pass


class TaskValidationError(DownloaderError):
    """任务参数校验异常"""
    pass
