"""三层重试补偿策略

第一层（快速重试）：处理瞬时网络抖动，间隔短
第二层（慢速重试）：指数退避，处理服务端临时过载
第三层：放弃，返回失败结果给业务方
"""
import random
import logging
from typing import Optional, Tuple, List, Callable

logger = logging.getLogger("bw_retry_downloader")


class RetryPolicy:
    """三层重试策略

    默认配置：总共最多 6 次尝试（1 首次 + 2 快速 + 3 慢速），
    延迟序列约为 [0.5s, 0.7s, 3s, 6s, 12s]（含 jitter）。

    Args:
        fast_retries: 快速重试次数，处理瞬时抖动
        fast_delay: 快速重试间隔（秒）
        slow_retries: 慢速重试次数，处理服务端过载
        slow_delay_base: 慢速退避起始间隔（秒）
        slow_delay_max: 慢速退避最大间隔（秒）
        jitter: 是否添加随机抖动，避免 thundering herd
        retry_on_status: 需要重试的 HTTP 状态码
        retry_on: 自定义重试判断函数 (status_code, exception, response) -> bool
    """

    def __init__(
        self,
        fast_retries: int = 2,
        fast_delay: float = 0.5,
        slow_retries: int = 3,
        slow_delay_base: float = 3.0,
        slow_delay_max: float = 30.0,
        jitter: bool = True,
        retry_on_status: Tuple[int, ...] = (429, 500, 502, 503, 504),
        retry_on: Optional[Callable] = None,
    ):
        self.fast_retries = fast_retries
        self.fast_delay = fast_delay
        self.slow_retries = slow_retries
        self.slow_delay_base = slow_delay_base
        self.slow_delay_max = slow_delay_max
        self.jitter = jitter
        self.retry_on_status = retry_on_status
        self.retry_on = retry_on

    @property
    def max_attempts(self) -> int:
        """总尝试次数 = 1（首次） + 快速重试 + 慢速重试"""
        return 1 + self.fast_retries + self.slow_retries

    def get_delays(self) -> List[float]:
        """生成所有重试间隔序列，长度 = fast_retries + slow_retries"""
        delays = []
        # 第一层：快速重试，固定小间隔
        for _ in range(self.fast_retries):
            d = self.fast_delay
            if self.jitter:
                d += random.uniform(0, 0.5)
            delays.append(d)
        # 第二层：慢速重试，指数退避
        for i in range(self.slow_retries):
            d = min(self.slow_delay_base * (2 ** i), self.slow_delay_max)
            if self.jitter:
                d += random.uniform(0, d * 0.3)
            delays.append(d)
        return delays

    def should_retry(
        self,
        status_code: Optional[int] = None,
        exception: Optional[Exception] = None,
        response: Optional[object] = None,
    ) -> bool:
        """判断是否应该重试"""
        # 用户自定义判断优先
        if self.retry_on is not None:
            return self.retry_on(status_code, exception, response)
        # 网络异常一律重试
        if exception is not None:
            return True
        # 状态码判断
        if status_code and status_code in self.retry_on_status:
            return True
        return False

    def get_retry_after(self, response) -> Optional[float]:
        """从 429 响应中提取 Retry-After 头"""
        if response is None:
            return None
        retry_after = getattr(response, "headers", {}).get("Retry-After")
        if retry_after is None:
            return None
        try:
            return float(retry_after)
        except (ValueError, TypeError):
            return None
