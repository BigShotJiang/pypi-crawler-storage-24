"""任务队列抽象

V0.1 仅提供 MemoryQueue，BaseQueue 为 V2 的 FileQueue/RedisQueue 预留扩展点。
"""
import queue
import logging
from abc import ABC, abstractmethod
from typing import Optional, List

from .models import Task

logger = logging.getLogger("bw_retry_downloader")


class BaseQueue(ABC):
    """队列抽象基类

    自定义队列只需继承此类并实现 put/get/size/empty 四个方法。
    """

    @abstractmethod
    def put(self, task: Task) -> None:
        ...

    @abstractmethod
    def get(self) -> Optional[Task]:
        ...

    @abstractmethod
    def size(self) -> int:
        ...

    @abstractmethod
    def empty(self) -> bool:
        ...

    def put_many(self, tasks: List[Task]) -> None:
        """批量添加任务"""
        for t in tasks:
            self.put(t)


class MemoryQueue(BaseQueue):
    """基于 queue.Queue 的内存队列（默认）

    线程安全，适用于单次运行的采集任务。
    """

    def __init__(self):
        self._q: queue.Queue = queue.Queue()

    def put(self, task: Task) -> None:
        self._q.put(task)

    def get(self) -> Optional[Task]:
        try:
            return self._q.get_nowait()
        except queue.Empty:
            return None

    def size(self) -> int:
        return self._q.qsize()

    def empty(self) -> bool:
        return self._q.empty()
