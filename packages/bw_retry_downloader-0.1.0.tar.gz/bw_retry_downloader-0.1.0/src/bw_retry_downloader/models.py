"""任务和结果的数据模型"""
import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from .exceptions import TaskValidationError


@dataclass
class Task:
    """下载任务

    字段名与 requests 库保持一致，降低学习成本。
    task_id 基于请求内容自动生成，相同请求产生相同 ID，支持幂等去重。
    meta 字段用于挂载业务数据（如数据库 ID），结果返回时原样带回。
    """

    url: str
    method: str = "GET"
    headers: Optional[Dict[str, str]] = None
    params: Optional[Dict[str, Any]] = None
    data: Optional[Any] = None
    json: Optional[Any] = None
    timeout: float = 10.0
    proxies: Optional[Dict[str, str]] = None
    meta: Optional[Dict[str, Any]] = None
    task_id: str = ""

    def __post_init__(self):
        # data 和 json 互斥校验
        if self.data is not None and self.json is not None:
            raise TaskValidationError("data 和 json 不能同时设置，它们是互斥参数")
        # 自动生成确定性 task_id
        if not self.task_id:
            self.task_id = self._generate_id()

    def _generate_id(self) -> str:
        """基于请求内容生成确定性 ID，相同请求产生相同 ID"""
        key = f"{self.method.upper()}:{self.url}"
        if self.params:
            key += f"|params:{json.dumps(self.params, sort_keys=True, ensure_ascii=False)}"
        if self.data is not None:
            if isinstance(self.data, bytes):
                key += f"|data:{hashlib.md5(self.data).hexdigest()}"
            else:
                key += f"|data:{self.data}"
        if self.json is not None:
            key += f"|json:{json.dumps(self.json, sort_keys=True, ensure_ascii=False)}"
        return hashlib.md5(key.encode()).hexdigest()[:12]

    def to_dict(self) -> dict:
        """序列化为字典，用于队列持久化"""
        d: Dict[str, Any] = {
            "url": self.url,
            "method": self.method,
            "timeout": self.timeout,
            "task_id": self.task_id,
        }
        if self.headers is not None:
            d["headers"] = self.headers
        if self.params is not None:
            d["params"] = self.params
        if self.data is not None:
            d["data"] = self.data
        if self.json is not None:
            d["json"] = self.json
        if self.proxies is not None:
            d["proxies"] = self.proxies
        if self.meta is not None:
            d["meta"] = self.meta
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Task":
        """从字典反序列化"""
        return cls(**d)


@dataclass
class Result:
    """下载结果

    无论成功还是失败，都会返回 Result 对象。
    业务方通过 success 字段判断采集是否成功，
    通过 task.meta 获取原始业务数据做失败上报。
    """

    task: Task
    success: bool
    status_code: Optional[int] = None
    content: Optional[bytes] = None
    text: Optional[str] = None
    error: Optional[str] = None
    attempts: int = 0
    elapsed: float = 0.0
    started_at: float = 0.0
    finished_at: float = 0.0
