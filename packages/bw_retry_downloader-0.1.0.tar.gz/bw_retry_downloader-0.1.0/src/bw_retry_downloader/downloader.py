"""核心下载器：线程池 + 分层重试 + 结果收集"""
import time
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Callable

import requests

from .models import Task, Result
from .retry import RetryPolicy
from .queue import BaseQueue, MemoryQueue

logger = logging.getLogger("bw_retry_downloader")


class Downloader:
    """轻量级重试下载器

    用法::

        with Downloader(workers=5) as dl:
            dl.add_tasks([Task(url="https://example.com/1"), ...])
            report = dl.run()
            print(report.summary())

    Args:
        workers: 线程池大小
        retry_policy: 重试策略，默认三层补偿
        queue: 任务队列，默认内存队列
        session: requests.Session，默认自动创建
        before_request: 请求前钩子，如动态设置代理/Cookie
        after_response: 响应后钩子，如校验内容是否有效
    """

    def __init__(
        self,
        workers: int = 5,
        retry_policy: Optional[RetryPolicy] = None,
        queue: Optional[BaseQueue] = None,
        session: Optional[requests.Session] = None,
        before_request: Optional[Callable[[Task], Task]] = None,
        after_response: Optional[Callable[[Result], Result]] = None,
    ):
        self.workers = workers
        self.retry_policy = retry_policy or RetryPolicy()
        self.queue = queue or MemoryQueue()
        self._session = session
        self._own_session = session is None
        self.before_request = before_request
        self.after_response = after_response
        self._shutdown_event = threading.Event()

    @property
    def session(self) -> requests.Session:
        if self._session is None:
            self._session = requests.Session()
        return self._session

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        """释放资源"""
        if self._own_session and self._session is not None:
            self._session.close()
            self._session = None

    def shutdown(self):
        """发送关闭信号，正在执行的任务会尽快完成"""
        self._shutdown_event.set()

    def add_task(self, task: Task) -> None:
        """添加单个任务"""
        self.queue.put(task)

    def add_tasks(self, tasks: List[Task]) -> None:
        """批量添加任务"""
        self.queue.put_many(tasks)

    def _execute_one(self, task: Task) -> Result:
        """执行单个任务，含分层重试逻辑"""
        start_time = time.time()
        delays = self.retry_policy.get_delays()
        last_error = None
        last_status = None
        attempt = 0

        for attempt in range(self.retry_policy.max_attempts):
            # 检查关闭信号
            if self._shutdown_event.is_set():
                return Result(
                    task=task,
                    success=False,
                    error="下载器被中断",
                    attempts=attempt,
                    elapsed=time.time() - start_time,
                    started_at=start_time,
                    finished_at=time.time(),
                )

            try:
                # 请求前钩子
                t = task
                if self.before_request:
                    t = self.before_request(task)

                resp = self.session.request(
                    method=t.method,
                    url=t.url,
                    headers=t.headers,
                    params=t.params,
                    data=t.data,
                    json=t.json,
                    timeout=t.timeout,
                    proxies=t.proxies,
                )
                last_status = resp.status_code

                # 判断是否需要重试
                if not self.retry_policy.should_retry(
                    status_code=resp.status_code,
                    response=resp,
                ):
                    # 不需要重试 = 得到了确定性响应
                    is_success = 200 <= resp.status_code < 300
                    result = Result(
                        task=task,
                        success=is_success,
                        status_code=resp.status_code,
                        content=resp.content,
                        text=resp.text,
                        error=None if is_success else f"HTTP {resp.status_code}",
                        attempts=attempt + 1,
                        elapsed=time.time() - start_time,
                        started_at=start_time,
                        finished_at=time.time(),
                    )
                    if self.after_response:
                        result = self.after_response(result)
                    return result

                # 需要重试
                last_error = f"HTTP {resp.status_code}"
                layer = "快速" if attempt < self.retry_policy.fast_retries else "慢速"
                logger.warning(
                    "[%s重试] task_id=%s url=%s 第%d次 状态码=%d",
                    layer, task.task_id, task.url, attempt + 1, resp.status_code,
                )

                # 429 特殊处理：优先使用 Retry-After 头
                if resp.status_code == 429 and attempt < len(delays):
                    retry_after = self.retry_policy.get_retry_after(resp)
                    if retry_after is not None:
                        delays[attempt] = retry_after
                        logger.info("[429] 使用 Retry-After=%.1fs", retry_after)

            except requests.RequestException as e:
                last_error = f"{type(e).__name__}: {e}"
                layer = "快速" if attempt < self.retry_policy.fast_retries else "慢速"
                logger.warning(
                    "[%s重试] task_id=%s url=%s 第%d次 异常=%s",
                    layer, task.task_id, task.url, attempt + 1, last_error,
                )

            # 等待后重试（最后一次不等待）
            if attempt < len(delays):
                # 用 Event.wait 代替 time.sleep，支持中断
                if self._shutdown_event.wait(delays[attempt]):
                    break

        # 所有重试耗尽 —— 第三层：放弃并记录
        logger.error(
            "[放弃] task_id=%s url=%s 共尝试%d次 最后错误=%s",
            task.task_id, task.url, attempt + 1, last_error,
        )
        return Result(
            task=task,
            success=False,
            status_code=last_status,
            error=last_error,
            attempts=attempt + 1,
            elapsed=time.time() - start_time,
            started_at=start_time,
            finished_at=time.time(),
        )

    def run(
        self,
        on_progress: Optional[Callable[[int, int, Result], None]] = None,
    ) -> "DownloadReport":
        """运行所有任务，返回下载报告

        Args:
            on_progress: 进度回调 (已完成数, 总数, 当前结果)
        """
        self._shutdown_event.clear()

        # 取出所有任务
        tasks: List[Task] = []
        while not self.queue.empty():
            task = self.queue.get()
            if task:
                tasks.append(task)

        total = len(tasks)
        if total == 0:
            return DownloadReport([])

        logger.info("开始下载: 共%d个任务, %d个线程", total, self.workers)

        results: List[Result] = []
        pool = ThreadPoolExecutor(max_workers=self.workers)

        try:
            future_map = {pool.submit(self._execute_one, t): t for t in tasks}

            for future in as_completed(future_map):
                try:
                    result = future.result()
                except Exception as e:
                    # _execute_one 内部已捕获所有异常，这里是兜底
                    task = future_map[future]
                    result = Result(
                        task=task,
                        success=False,
                        error=f"未预期异常: {e}",
                        started_at=time.time(),
                        finished_at=time.time(),
                    )
                results.append(result)
                if on_progress:
                    on_progress(len(results), total, result)

        except KeyboardInterrupt:
            logger.warning("收到中断信号，正在停止...")
            self._shutdown_event.set()
        finally:
            pool.shutdown(wait=True, cancel_futures=True)

        report = DownloadReport(results)
        logger.info(report.summary())
        return report


class DownloadReport:
    """下载报告：汇总成功/失败，提供失败上报

    核心用法::

        report = dl.run()
        # 查看失败
        for r in report.failed:
            print(f"失败: {r.task.url}, 原因: {r.error}, meta: {r.task.meta}")
        # 重跑失败任务
        dl.add_tasks(report.failed_tasks())
        report2 = dl.run()
    """

    def __init__(self, results: List[Result]):
        self.results = results
        self.success = [r for r in results if r.success]
        self.failed = [r for r in results if not r.success]

    @property
    def success_count(self) -> int:
        return len(self.success)

    @property
    def failed_count(self) -> int:
        return len(self.failed)

    @property
    def total(self) -> int:
        return len(self.results)

    def failed_tasks(self) -> List[Task]:
        """返回所有失败的 Task，可直接重新提交给 Downloader"""
        return [r.task for r in self.failed]

    def failed_urls(self) -> List[str]:
        """返回所有失败的 URL"""
        return [r.task.url for r in self.failed]

    def summary(self) -> str:
        """生成摘要字符串"""
        lines = [
            f"下载完成: 总计={self.total} 成功={self.success_count} 失败={self.failed_count}"
        ]
        if self.failed:
            lines.append("失败详情:")
            for r in self.failed:
                meta_info = f" meta={r.task.meta}" if r.task.meta else ""
                lines.append(
                    f"  - {r.task.url} | 原因: {r.error} | "
                    f"尝试: {r.attempts}次{meta_info}"
                )
        return "\n".join(lines)
