"""bw-retry-downloader: 轻量级重试下载器，专为爬虫工程师设计"""

from .models import Task, Result
from .retry import RetryPolicy
from .queue import BaseQueue, MemoryQueue
from .downloader import Downloader, DownloadReport
from .exceptions import DownloaderError, TaskValidationError

__version__ = "0.1.0"

__all__ = [
    "Task",
    "Result",
    "RetryPolicy",
    "BaseQueue",
    "MemoryQueue",
    "Downloader",
    "DownloadReport",
    "DownloaderError",
    "TaskValidationError",
]
