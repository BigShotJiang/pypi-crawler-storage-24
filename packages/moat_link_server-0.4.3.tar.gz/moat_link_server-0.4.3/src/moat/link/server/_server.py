"""
The main MoaT-Link Server
"""

from __future__ import annotations

import anyio
import anyio.abc
import logging
import os
import random
import signal
import sys
import time
from anyio.abc import SocketAttribute
from contextlib import asynccontextmanager, nullcontext
from datetime import UTC, datetime
from functools import partial
from platform import uname

from asyncactor import (
    Actor,
    GoodNodeEvent,
    PingEvent,
    RecoverEvent,
    TagEvent,
)
from asyncactor.backend import get_transport

from moat.util import (
    MsgReader,
    MsgWriter,
    NotGiven,
    attrdict,
    gen_ident,
    id2str,
    to_attrdict,
)
from moat.lib.broadcast import Broadcaster, BroadcastReader
from moat.lib.codec.cbor import CBOR_TAG_CBOR_LEADER, Tag
from moat.lib.codec.moat_cbor import (
    CBOR_TAG_MOAT_CHANGE,
    CBOR_TAG_MOAT_FILE_END,
    CBOR_TAG_MOAT_FILE_ID,
)
from moat.lib.micro import AC_use
from moat.lib.mqtt import QoS
from moat.lib.path import (
    P,
    Path,
    PathLongener,
    PathShortener,
    Root,
)
from moat.lib.rpc import MsgHandler, MsgSender, rpc_on_aiostream
from moat.link.auth import AnonAuth, TokenAuth
from moat.link.backend import Backend, get_backend
from moat.link.client import BasicLink, LinkCommon
from moat.link.common import _Sub_i as _CommonSubI
from moat.link.exceptions import ClientError, OutOfDateError
from moat.link.hello import Hello
from moat.link.meta import MsgMeta
from moat.link.node import Node
from moat.util.exc import ExpKeyError, exc_iter

from collections import defaultdict
from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from pathlib import Path as FSPath

    from moat.lib.path import PathElem
    from moat.lib.rpc import Msg
    from moat.link.backend import Message

    from collections.abc import Awaitable, Callable

    PathType = anyio.Path | FSPath | str

NotGivenType = type(NotGiven)


class BadFile(ValueError):
    pass


class _NotGiven:
    pass


@asynccontextmanager
async def EventSetter(evt):
    try:
        yield
    finally:
        evt.set()


Stream = anyio.abc.ByteStream

ClosedResourceError = anyio.ClosedResourceError

_client_nr = 0


def max_n(a, b):
    if a is None:
        return b
    elif b is None:
        return a
    elif a < b:
        return b
    else:
        return a


def cmp_n(a, b):
    if a is None:
        a = -1
    if b is None:
        b = -1
    return b - a


def tag_check(tags: Sequence[Tag]) -> bool:
    """
    Check that these tags describe a complete dump
    """
    if len(tags) < 2:
        return False
    t = tags[0]
    if t.tag != CBOR_TAG_MOAT_FILE_ID:
        return False
    t = t.value[1]
    if t.get("mode", "") not in {"full", "init"}:
        return False

    t = tags[-1]
    if t.tag != CBOR_TAG_MOAT_FILE_END:
        return False

    return True


def _get_my_ip(ip6: bool = False):
    """
    Find my IP address
    :return:
    """
    import socket  # noqa: PLC0415

    s = socket.socket(socket.AF_INET6 if ip6 else socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("2606:4700:4700::1111" if ip6 else "1.1.1.1", 53))
    ip = s.getsockname()[0]
    s.close()
    return ip


class HelloProc:
    """
    A hacked-up command processor for receiving the first client message.
    """

    def __init__(self, client):
        self.client = client

    async def received(self, msg):
        qlen = msg.get("qlen", 0)
        self.client.qlen = min(qlen, self.client.server.cfg.server.buffer)
        del self.client.in_stream[0]

    async def aclose(self):
        self.client.in_stream.pop(0, None)


class _Sub_d(MsgHandler):
    "Data access namespace."

    def __init__(self, parent: ServerClient):
        super().__init__(parent.server.cfg)
        self.parent = parent

    doc_get = dict(_d="get subnode data", _r=["Any:Data", "MsgMeta"], _0="Path")
    doc_collect = dict(_d="collate subnode data", _r="Any:Data", _0="Path:root", _1="Path")
    doc_list = dict(_d="get subnode child names", _r=["Any:Data", "MsgMeta"], _o="str")
    doc_walk = dict(
        _d="get subtree",
        _0="Path",
        _1="float:mintime",
        _2="int:mindepth",
        _3="int:maxdepth",
        _r=dict(_0="int:depth", _1="Path:sub", _2="Any:data", _99="MsgMeta"),
        _o="str",
    )
    doc_search = dict(_d="search subnode data", _r=["Any:Data", "MsgMeta"], _0="Path")
    doc_set = dict(
        _d="set value",
        _0="Path",
        _1="Any",
        _99="MsgMeta:optional",
        t="Time of last change",
    )
    doc_delete = dict(
        _d="delete value",
        _0="Path",
        _99="MsgMeta:optional",
        t="float:Time of+ last change",
        rec="bool:recursive",
    )
    doc_deltree = dict(_d="drop a subtree", _0="Path", _r="int:#nodes", _o="node data")

    async def stream_get(self, msg: Msg) -> None:
        await self.parent.d_get_stream_(msg)

    async def stream_collect(self, msg: Msg) -> None:
        await self.parent.d_collect_stream_(msg)

    async def stream_list(self, msg: Msg) -> None:
        await self.parent.d_list_stream_(msg)

    async def stream_walk(self, msg: Msg) -> None:
        await self.parent.d_walk_stream_(msg)

    async def stream_deltree(self, msg: Msg) -> None:
        await self.parent.d_deltree_stream_(msg)

    async def cmd_search(self, path: Path) -> Any:
        return await self.parent.d_search_(path)

    async def cmd_set(
        self,
        path: Path,
        value: Any,
        meta: MsgMeta | None = None,
        t: float | bool | None = None,
    ) -> Any:
        return await self.parent.d_set_(path, value, meta=meta, t=t)

    async def cmd_delete(
        self, path: Path, meta: MsgMeta | None = None, t: float | None = None, rec: bool = False
    ) -> Any:
        return await self.parent.d_delete_(path, meta=meta, t=t, rec=rec)


class _Sub_e(MsgHandler):
    "Error handling namespace."

    def __init__(self, parent: ServerClient):
        super().__init__(parent.server.cfg)
        self.parent = parent

    doc_exc = dict(_d="Report an exception", _0="path:Path", _1="exc:Error", _k="any")
    doc_info = dict(_d="Report a non-exceptional anomaly", _0="path:Path", _k="any")
    doc_ack = dict(_d="Acknowledge an error", _0="path:Path", _k="any", ack="None|bool|float:")
    doc_ok = dict(_d="State is OK", _0="path:Path", _k="any")
    doc_mon = dict(_d="Monitoring wrapper", _0="path:Path", _i="log data", _k="any")

    def stream_exc(self, msg: Msg) -> Awaitable[Any]:
        return self.parent.e_exc_stream_(msg)

    def stream_info(self, msg: Msg) -> Awaitable[Any]:
        return self.parent.e_info_stream_(msg)

    def stream_ack(self, msg: Msg) -> Awaitable[Any]:
        return self.parent.e_ack_stream_(msg)

    def stream_ok(self, msg: Msg) -> Awaitable[Any]:
        return self.parent.e_ok_stream_(msg)

    async def stream_mon(self, msg: Msg) -> None:
        await self.parent.e_mon_stream_(msg)


class _Sub_i(_CommonSubI):
    "Server informational namespace."

    def __init__(self, parent: ServerClient):
        super().__init__(parent)
        self.parent = parent

    doc_state = dict(_d="state", _r="MsgMeta:optional")
    doc_error = dict(_d="last disconnect error", _r="Any:error")
    doc_stamp = dict(_d="stamp", _r="int:timestamp sequence#")
    doc_sync = dict(_d="sync", _0="int:timestamp sequence#")
    doc_checkid = dict(_d="probe client ID", _0="str:id of the client", t="retry delay")

    async def cmd_state(self) -> Any:
        return await self.parent.i_state_()

    def cmd_error(self, last_name: str | None = None) -> Any:
        return self.parent.i_error_(last_name=last_name)

    def cmd_stamp(self) -> int:
        return self.parent.i_stamp_()

    def cmd_sync(self, stamp: Any) -> Awaitable[None]:
        return self.parent.i_sync_(stamp)

    async def cmd_checkid(self, id: str, t: float = 0.1) -> bool:
        return await self.parent.i_checkid_(id=id, t=t)


class _Sub_s(MsgHandler):
    "Save/load namespace."

    def __init__(self, parent: ServerClient):
        super().__init__(parent.server.cfg)
        self.parent = parent

    doc_log = dict(_d="save updates", _0="str:filename", state="bool:include current state")
    doc_save = dict(_d="save current state", _0="str:filename", prefix="path:subtree")
    doc_load = dict(_d="load state", _0="str:filename", prefix="path:subtree")

    async def cmd_log(self, path: str, *, state: bool = False) -> bool:
        return await self.parent.s_log_(path, state=state)

    async def cmd_save(self, path: str, prefix: Path = Path()) -> bool:
        return await self.parent.s_save_(path, prefix=prefix)

    async def cmd_load(self, path: str, *, prefix: Path = Path()) -> Any:
        return await self.parent.s_load_(path, prefix=prefix)


class ServerClient(LinkCommon):
    """Represent one (possibly-non-server) client."""

    _hello: Hello | None = None
    _auth_data: Any = None
    is_server: bool = False
    protocol_version: int = -1
    prefix: str
    name: str
    server: Server

    def __init__(self, server: Server, prefix: str, stream: Stream):
        self.server = server
        self.cfg = server.cfg
        self.prefix = prefix
        self.stream = stream

        # there sustained rate might be > 10 connections per second.
        # >100 requires rate limiting.
        global _client_nr
        t = int(time.time() * 100 - 175000000000)
        if t < 0:  # testing. Revert.
            t += 175000000000
        if _client_nr == 0 or _client_nr < t:
            _client_nr = t
        else:
            _client_nr += 1
            if _client_nr > t + 1000:
                raise RuntimeError("The connection rate is too high!")
        self.client_nr = id2str(_client_nr)
        self.name = f"{self.prefix}_{self.client_nr}"

        self.logger = logging.getLogger(f"moat.link.server.{prefix}.{self.client_nr}")

    @property
    def sender(self) -> MsgSender:
        return self._sender

    async def aclose(self):
        """
        Shut this client down
        """
        self.tg.cancel_scope.cancel()

    async def run(self):
        """Main loop for this client connection."""

        self.logger.debug("START %s C_%s", self.name, self.client_nr)
        self._hello = Hello(
            them=self.name,
            me=self.server.name,
            me_server=True,
            auth_in=[TokenAuth(*self.server.tokens), AnonAuth()],
            rpc_auth_modes=("token", "anon"),
            rpc_auth_data={"token": self.server.tokens},
            rpc_auth_server=True,
        )
        async with (
            self,
            anyio.create_task_group() as self.tg,
            rpc_on_aiostream(self, self.stream) as cmd,
        ):
            self._sender = MsgSender(cmd)

            # basic setup
            them = None
            try:
                if await self._hello.run(MsgSender(cmd)) is False or not (
                    auth := self._hello.auth_data
                ):
                    self.logger.debug("NO C_%s", self.client_nr)
                    return
                them = self._hello.them
                self.is_server = self._hello.they_server
                if True:  # self.is_server:
                    if them is None:
                        raise RuntimeError("No remote name after handshake")
                    try:
                        self.server.rename_client(self, them)
                    except ValueError:
                        self.logger.warning("Rename to %s failed", them)

                self.protocol_version = self._hello.protocol_version
            finally:
                del self._hello

            self._auth_data = auth

            # periodic ping
            while True:
                # XXX only when otherwise idle
                await anyio.sleep(self.server.cfg.server.probe.repeat)
                with anyio.fail_after(self.server.cfg.server.probe.timeout):
                    await self._sender.cmd(P("i.乒"))

    async def setup(self):
        "Attach delegated sub-command handlers."
        self._sub_i = _Sub_i(self)
        await super().setup()
        self._sub_dh = _Sub_d(self)
        self._sub_eh = _Sub_e(self)
        self._sub_sh = _Sub_s(self)
        await AC_use(self, self.delegate(P("d"), self._sub_dh))
        await AC_use(self, self.delegate(P("e"), self._sub_eh))
        await AC_use(self, self.delegate(P("s"), self._sub_sh))

    async def wait_ready(self, wait: bool = True):
        "Standard; waits for auth to complete"
        if self._hello is None:
            return False
        if not wait:
            await self._hello.wait_done()
        return None

    @property
    def auth_data(self):
        """
        Retrieve auth data.

        These might be stored in the Hello processor while startup is incomplete.
        """
        if self._hello is not None:
            return self._hello.auth_data
        return self._auth_data

    async def handle(self, msg, rcmd):
        """
        Message handlers that intercepts (a) authorization, (b) a "d_"
        path-based "simple data" command
        """
        if self._hello is not None and self._hello.auth_data is None:
            if self._hello.is_auth_cmd(rcmd):
                return await self._hello.handle(msg, rcmd)
            if not self._hello.auth_accepting:
                await msg.ml_send_error(ValueError("No Hello/Auth"))
                return

        if rcmd[-1] == "d_":
            # Simple Data. If both a path vector and a `p` argument is
            # given, concatenate them.
            if "p" not in msg.kw:
                msg._kw = dict(msg.kw)  # noqa: SLF001
                msg._kw["p"] = Path.build(rcmd[-2::-1])  # noqa: SLF001
            elif len(rcmd) > 1:
                msg._kw = dict(msg.kw)  # noqa: SLF001
                msg._kw["p"] = Path.build(rcmd[-2::-1]) + msg["p"]  # noqa: SLF001
            return await msg.call_simple(self.d_simple_)

        return await super().handle(msg, rcmd)

    async def d_get_stream_(self, msg):
        """Get the data of a sub-node.

        Arguments:
        * path

        Result:
        * data
        * metadata dump
        """
        path = Path.build(msg[0])
        if len(path) and path[0] == "run":
            data = self.server.rdata
        else:
            data = self.server.data
        d = data[path]
        if d.meta is None:
            await msg.result(d.data)
        else:
            await msg.result(d.data, *d.meta.dump())

    async def d_collect_stream_(self, msg):
        """Collate the dicts on the path from some root to a sub-node.

        This is used to e.g. collect path-specific config data for a subsystem.

        Arguments:
        * root path
        * path

        Result:
        * data (as dict)
        """
        root = Path.build(msg[0])
        path = msg[1]
        d = self.server.data[root].collect(path)
        await msg.result(**d)

    doc_d = dict(_d="Data access commands")
    doc_e = dict(_d="Error handling commands")
    doc_i = dict(_d="Informational commands")
    doc_s = dict(_d="Data load/save commands")

    doc_cl = dict(_d="Access to named clients")

    def sub_cl(self, msg: Msg, rcmd: list[PathElem]) -> Awaitable:
        "Local subcommand redirect for 'cl'"
        return self.server.sub_cl(msg, rcmd)

    doc_srv = dict(_d="Access to named servers")

    def sub_srv(self, msg: Msg, rcmd: list[PathElem]) -> Awaitable:
        "Local subcommand redirect for 'srv'"
        return self.server.sub_srv(msg, rcmd)

    def stream_cl(self, msg: Msg) -> Awaitable:
        "Send the list of currently-known clients"
        return self.server.stream_cl(msg)

    async def d_list_stream_(self, msg):
        """Get the child names of a sub-node.
        Arguments:
        * path

        Stream:
        * strings
        """

        async with msg.stream_out():
            for k in list(self.server.data[msg[0]].keys()):
                await msg.send(k)

    async def d_walk_stream_(self, msg):
        """
        Get a whole subtree.
        Arguments:
        * pathname
        * min timestamp
        * min depth
        * max depth
        """

        ps = PathShortener()

        async def _writer(p, n):
            try:
                nd = n.data
            except ValueError:
                return
            d, sp = ps.short(p)
            await msg.send(d, sp, nd, *n.meta.dump())

        try:
            d = self.server.data.get(Path.build(msg[0]), create=False)
        except KeyError:
            async with msg.stream_out():
                return

        ts = msg.get(1, 0, nulled=True)
        xmin = msg.get(2, 0, nulled=True)
        xmax = msg.get(3, 9999999, nulled=True)
        async with msg.stream_out():
            await d.walk(_writer, timestamp=ts, min_depth=xmin, max_depth=xmax)

    def d_simple_(self, value: Any = _NotGiven, *, p: Path, **_kw) -> Awaitable:
        """
        Handler for direct storage
        """
        p = Path.build(p)
        if value is _NotGiven:
            return self.d_get_(p)
        elif value is NotGiven:
            return self.d_delete_(p)
        else:
            return self.d_set_(p, value)

    async def d_get_(self, path: Path):
        """Get the data of a sub-node.

        Arguments:
        * path

        Result:
        * data
        """
        if len(path) and path[0] == "run":
            data = self.server.rdata
        else:
            data = self.server.data
        d = data[path]
        return d.data

    async def d_search_(self, path: Path):
        """Search for wildcard-matching sub-node data.

        Arguments:
        * path

        Result:
        * data
        """
        if len(path) and path[0] == "run":
            data = self.server.rdata
        else:
            data = self.server.data
        d = data.search(path)
        return d.data

    async def d_set_(
        self,
        path,
        value,
        meta: MsgMeta | None = None,
        t: float | bool | None = None,
    ):
        """Set a node's value.

        Arguments:
        * pathname
        * value
        * optional: new metadata
        * optional: t: timestamp of last change, or a flag.
          If False, must not exist; if True, must exist.

        You should not call this unless absolutely necessary.
        Instead, send to the MQTT topic directly.

        Using this method does *not* protect against conflicts.
        """
        if meta is None:
            meta = MsgMeta(origin=self.name)
        meta.source = "Client"
        path = Path.build(path)

        try:
            node = self.server.data.get(path)
        except ValueError:
            if t:
                raise ExpKeyError(path) from None
        else:
            if t is (node.data_ is NotGiven):
                raise ExpKeyError(path) from None
            elif t not in (None, True, False) and (
                node.meta is None or abs(node.meta.timestamp - t) > 0.001
            ):
                raise OutOfDateError(node.meta)

        return self.server.maybe_update(path, value, meta, force=True)

    async def d_delete_(self, path, meta=None, t: float | None = None, rec: bool = False):
        """Delete a node's value.

        Arguments:
        * pathname
        * optional: new metadata
        * optional: t: timestamp of last change

        You should only call this if you don't know whether the data exists.
        If you do, send an empty value to the MQTT topic directly.
        """
        if meta is None:
            meta = MsgMeta(origin=self.name)
        meta.source = "Client"
        path = Path.build(path)

        try:
            node = self.server.data[path]
            dv = node.data
            dm = node.meta
        except (KeyError, ValueError):
            node = None
        else:
            if rec:

                async def rec_del(n, p):
                    await anyio.sleep(0.01)
                    for pp, nn in n.items():
                        await rec_del(nn, p / pp)
                    self.server.maybe_update(p, NotGiven, meta)

                await rec_del(node, path)
            else:
                if t is not None and (node.meta is None or abs(node.meta.timestamp - t) > 0.001):
                    raise OutOfDateError(node.meta)
                self.server.maybe_update(path, NotGiven, meta)

        if node is None:
            return None
        else:
            if dm is None:
                return dv
            return dv, *dm.dump()

    def e_exc_stream_(self, msg: Msg) -> Awaitable:
        """Report not-an-error"""
        kw = dict(msg.kw)
        if len(msg.args) > 2:
            kw["args"] = msg.args[2:]
        return self.server.set_error(msg[0], msg[1], kw, MsgMeta(origin=self.name))

    def e_info_stream_(self, msg: Msg) -> Awaitable:
        """Report not-an-error"""
        kw = dict(msg.kw)
        if len(msg.args) > 2:
            kw["args"] = msg.args[2:]
        return self.server.set_error(msg[0], msg[1], kw, MsgMeta(origin=self.name))

    def e_ack_stream_(self, msg: Msg) -> Awaitable:
        """Acknowledge an error"""
        kw = dict(msg.kw)
        if len(msg.args) > 2:
            kw["args"] = msg.args[2:]
        kw["ack"] = True
        return self.server.set_error(msg[0], NotGiven, kw, MsgMeta(origin=self.name))

    def e_ok_stream_(self, msg: Msg) -> Awaitable:
        """Report not-an-error"""
        kw = dict(msg.kw)
        if len(msg.args) > 1:
            kw["args"] = msg.args[1:]
        return self.server.set_error(msg[0], None, kw, MsgMeta(origin=self.name))

    async def e_mon_stream_(self, msg: Msg):
        path = msg[0]
        kw = dict(msg.kw)
        kw["start"] = time.time()
        kw["log"] = log = []
        try:
            async with msg.stream_in() as mon:
                async for mon_msg in mon:
                    a = mon_msg.to_list(dict_only=True)
                    if not a and log and not log[-1]:
                        continue
                    log.append(a)
                    if len(log) > 10:
                        log[4:-5] = [...]
                    # await self.backend.send(P(":R.run.error") + path, kw)
        except Exception as exc:
            err = exc
        except BaseException:
            err = "BaseExc"
            raise
        else:
            err = None
        finally:
            if err is not None:
                kw["exc"] = err
            with anyio.move_on_after(2, shield=True):
                await self.server.set_error(path, err, kw, MsgMeta(origin=self.name))

    async def i_state_(self):
        """Return some info about this node's internal state"""
        return self.server.get_state()

    def i_error_(self, last_name: str | None = None) -> Any:
        """Return some info about the reason my link got disconnected"""
        return self.server.get_cached_error(last_name or self.name)

    def i_stamp_(self) -> int:
        """Return a new timestamp value"""
        return self.server.new_stamp()

    def i_sync_(self, stamp) -> Awaitable[None]:
        """wait until the server received this stamp#"""
        return self.server.wait_stamp(stamp)

    async def i_checkid_(self, id: str, t: float = 0.1) -> bool:
        """wait until the server received this stamp#"""
        await anyio.sleep(0.1)
        if id in self.server.known_ids:
            return True
        if not t:
            return False
        await anyio.sleep(t)
        return id in self.server.known_ids

    async def d_deltree_stream_(self, msg):
        """Delete a node's value.
        Sub-nodes are cleared (after their parent).
        """
        root = msg[0]
        if not root:
            raise ClientError("You can't delete the root node")
        ps = PathShortener(root)
        data = self.server.data[root]
        res = 0

        async with msg.stream_w() if msg.can_stream else nullcontext() as ws:

            async def _del(path: Path, entry: Node):
                if entry.data is NotGiven:
                    return

                meta = MsgMeta(origin=self.name)
                meta.source = "Client"

                data = entry.data
                if self.server.maybe_update(path, NotGiven, meta) and ws is not None:
                    await ws.send(*ps.short(path), data, *meta.dump())

                nonlocal res
                res += 1

            await data.walk(_del)
            await msg.result(res)

    async def s_log_(self, path: str, *, state: bool = False) -> bool:
        await self.server.run_saver(path, save_state=state)
        return True

    async def s_save_(self, path: str, prefix=Path()) -> bool:
        await self.server.save(path, prefix=prefix)

        return True

    async def s_load_(self, path, *, prefix=Path()) -> tuple[int, int, list[Tag], str]:
        return await self.server.load_file(fn=path, prefix=prefix)


class Server(MsgHandler):
    """
    This is the main MoaT-Link server. It manages connections to the MQTT server,
    the clients, and (optionally) logs all changes to a file.

    Args:
      name (str): the name of this MoaT-Link server instance.
        It **must** be unique.
      cfg: configuration.
        See ``_cfg.yaml`` for default values.
        The relevant part is the ``link.server`` sub-dict (mostly).
      init (Any):
        The initial content of the root entry. **Do not use this**, except
          when setting up an entirely new MoaT-Link cluster.

    """

    # pylint: disable=no-member # mis-categorizing cfg as tuple
    data: Node
    rdata: Node
    name: str
    backend: Backend

    cfg: attrdict

    service_monitor: Broadcaster[Message]
    write_monitor: Broadcaster[Tag | tuple[Path, Any, MsgMeta]]

    known_ids: set[str]
    logger: logging.Logger

    last_auth: str | None = None
    cur_auth: str

    _syncing: dict[str, anyio.abc.CancelScope]
    _writing: set[str]
    _writing_done: anyio.Event
    _stopped: anyio.Event

    # Client ID > disconnect error
    _error_cache: dict[str, Exception | str]

    _stamp_in: int = 0
    _stamp_out: int = 0
    _stamp_in_evt: anyio.Event

    _ping_history: Sequence[str] = ()

    _server_link: dict[str, tuple[anyio.CancelScope, BasicLink | None]]
    _server_link_add: anyio.Event

    _f_load: anyio.Path | None = None
    _f_save: anyio.Path | None = None

    _downed: dict[str, float]

    def __init__(
        self,
        cfg: dict,
        name: str,
        init: Any = NotGiven,
        load: anyio.Path | FSPath | str | None = None,
        save: anyio.Path | FSPath | str | None = None,
    ):
        self.data = Node()
        self.rdata = Node()
        self.name = name
        self.cfg = to_attrdict(cfg)

        self._init = init

        self.known_ids = set()

        self.logger = logging.getLogger("moat.link.server." + name)
        self._writing = set()
        self._writing_done = anyio.Event()
        self._error_cache = {}
        self._stamp_in_evt = anyio.Event()
        self._syncing = {}
        self._server_link = {}
        self._server_link_add = anyio.Event()
        self._downed = {}

        # connected clients
        self._clients: dict[str, ServerClient] = dict()

        if load is not None:
            self._f_load = anyio.Path(load)
        if save is not None:
            self._f_save = anyio.Path(save)

    @property
    def clients(self) -> dict[str, ServerClient]:
        return self._clients

    def server_link(self, name):
        return self._server_link[name]

    def rename_client(self, client: ServerClient, name: str):
        """
        Change a client name (result of protocol startup)
        """
        if client.name == name:
            return
        if name in self._clients:
            raise ValueError(f"Name exists: {name!r}")
        del self._clients[client.name]
        client.name = name
        self._clients[name] = client

    def refresh_auth(self):
        """
        Generate a new access token (but remember the previous one)
        """
        try:
            self.last_auth = self.cur_auth
        except AttributeError:
            self.last_auth = None
        self.cur_auth = gen_ident(20)

    @property
    def tokens(self):
        res = [self.cur_auth]
        if self.last_auth is not None:
            res.append(self.last_auth)
        return res

    def maybe_update(
        self,
        path: Path,
        data: Any,
        meta: MsgMeta,
        local: bool = False,
        force: bool = False,
    ):
        """
        A data item arrives.

        Update our store if it's newer.
        """
        if len(path) and path[0] == "run":
            return False
        if res := self.data.set(path, data, meta, force=force):
            if not local:
                self.write_monitor((path, data, meta))
        return res

    async def _mon_run(self, topic: Path, msg: Message) -> bool:
        """
        Messages to run.* are skipped by the main monitor backend.
        """
        if msg.retain:
            # We remember retained messages but we don't store them.
            self.rdata.set(topic, msg.data, msg.meta)
        return False

    async def _backend_monitor(
        self,
        task_status: anyio.abc.TaskStatus = anyio.TASK_STATUS_IGNORED,
    ):
        """
        The task that listens to the backend's message stream and updates
        the data store.

        If there is a method named ``_mon_{topic[0]}`` it is called with
        the topic and message.

        Further processing will be inhibited if the result is `False`.
        """
        t_start = anyio.current_time() if self.data else None

        async with self.backend.monitor(
            P(":R"),
            raw=False,
            qos=QoS.AT_LEAST_ONCE,
            no_local=True,
            subtree=True,
        ) as stream:
            task_status.started()
            async for msg in stream:
                self.logger.debug("Recv: %r", msg)
                msg.meta.source = "Mon"
                topic = msg.topic
                path = Path.build(topic)

                if len(path) > 0 and (hdl := getattr(self, f"_mon_{path[0]}", None)) is not None:
                    if (await hdl(path, msg)) is False:
                        continue

                if t_start is not None and not topic:
                    if anyio.current_time() - t_start > 10:
                        t_start = None
                    elif self.data and msg.data != self.data.data:
                        raise RuntimeError(f"Existing data? {msg} {self.data}")

                self.maybe_update(path, msg.data, msg.meta)

    async def _backend_sender(self, task_status: anyio.abc.TaskStatus = anyio.TASK_STATUS_IGNORED):
        rdr = self.write_monitor.reader(999)
        task_status.started()
        async for msg in rdr:
            if isinstance(msg, Tag):
                continue
            p, d, m = msg
            if not m.source:
                m.source = "?"
            elif m.source == "Mon" or m.source[0] == "_":
                continue
            await self.backend.send(
                topic=P(":R") + p, data=d, meta=m, retain=(len(p) == 0 or p[0] != "run")
            )

    async def _pinger(
        self,
        ready: anyio.Event,
        *,
        task_status: anyio.abc.TaskStatus = anyio.TASK_STATUS_IGNORED,
    ):
        """
        This task
        * sends PING messages
        * handles incoming pings
        * triggers split recovery

        The initial ping is delayed randomly.

        Args:
          delay: an event to set after the initial ping message has been
            sent.
        """
        T = get_transport("moat_link")
        async with Actor(
            T(self.backend, P(":R.run.service.main.ping")),
            name=self.name,
            cfg=self.cfg.server.ping,
            send_raw=True,
        ) as actor:
            self._actor = actor
            task_status.started()

            async for msg in actor:
                self.logger.debug("ACT IN %s", repr(msg))

                if isinstance(msg, RecoverEvent):
                    self._tg.start_soon(
                        self.recover_split,
                        msg.prio,
                        msg.replace,
                        msg.local_nodes,
                        msg.remote_nodes,
                    )

                elif isinstance(msg, GoodNodeEvent):
                    # self._tg.start_soon(self.fetch_data, msg.nodes)
                    await actor.set_value(True)
                    ready.set()

                elif isinstance(msg, TagEvent):
                    # We're "it"
                    await self.set_main_link()
                    await actor.set_value(True)
                    ready.set()

                elif isinstance(msg, PingEvent):
                    # record history, for recovery
                    if msg.msg.node == self.name:
                        continue
                    await actor.set_value(True)
                    ready.set()
                    self._ping_history = msg.msg.history

    async def set_main_link(self):
        await self.backend.send(
            P(":R.run.service.main.conn"),
            {"node": uname().node, "link": self.link_data, "auth": {"token": self.cur_auth}},
            meta=MsgMeta(origin=self.name),
            retain=True,
        )

    def new_stamp(self):
        """
        Return the next stamp value.

        Usage: a client calls this via `i_stamp`, sends the value to the
        server's ``stamp`` MQTT channel, then calls `wait_stamp` to ensure
        that the stamp value arrived there.

        This ensures (absent packet loss, interrupted connections, and
        similar nonsense) that updates have arrived at the server.
        """
        self._stamp_out += 1
        return self._stamp_out

    async def wait_stamp(self, stamp):
        """
        Wait until the server has seen this stamp value (or better) on its
        ``stamp`` channel.
        """
        while self._stamp_in < stamp:
            await self._stamp_in_evt.wait()

    async def fetch_data(self, nodes):
        """
        We are newly started and don't have any data.

        Try to get the initial data from some other node.
        """
        nodes  # noqa:B018  # pyright:ignore

    async def recover_split(self, prio, replace, local_history, sources):
        """
        Recover from a network split.

        TODO
        """
        # TODO
        # The idea is:
        #  connect to a source
        #  get all its data changed since timestamp-that-source-was-last-seen
        #  re-broadcast all data changed since timestamp-that-source-was-last-seen

    async def set_error(
        self,
        path: Path,
        err: str | BaseException | None | NotGivenType,
        kw: dict[str, Any],
        meta: MsgMeta,
    ):
        """
        Update error data.

        Args:
            path: Path which the error applies to. Must not be empty and
                  not start with "error".
            err: Error message or exception. None: clear; NotGiven:
                 increase occurrence counter
        """
        if len(path) == 0 or path[0] == "error":
            raise ValueError(f"Messed-up error path: {path}")
        p = Path.build(("error",) + path)

        try:
            dt = self.data.get(p, create=False if err is None else None)
        except KeyError:
            return  # no error exists
        if (dd := dt.data_) is NotGiven:
            dd = {}
        elif not isinstance(dd, dict):
            dd = {"data": dd}
        dd.update(kw)

        if err is None:
            # Delete, i.e. write the old record to error storage.
            dd["ok"] = True
        elif err is not NotGiven:
            # count
            dd.pop("ok", None)
            if dt.meta:  # this is an update
                dd["n"] = dd.get("n", 1) + 1
                if "first" not in dd:
                    dd["first"] = dt.meta.timestamp

        await self.backend.send(P(":R.run.error") + path, dd, meta=meta, retain=False)
        if err is None:
            dd = NotGiven
        else:
            dd.pop("bt", None)

        # this shortcuts maybe_update
        # forcing is required because we just modified the dict in-place
        if dt.set(Path(), dd, meta, force=True):
            self.write_monitor((p, dd, meta))

    async def _save(
        self,
        writer: Callable[[Tag | list[Any]], Awaitable[None]],
        shorter: PathShortener,
        hdr: bool | Tag = True,
        ftr: bool | Tag = True,
        prefix=P(":"),
        **kw,
    ):
        """Save the current state.

        @hdr and @ftr are items to prepend/append to the data stream.

        If @timestamp is set, older items will be ignored.

        @writer is an async callback that writes each item.
        """

        async def saver(path, data) -> None:
            if data.data_ is NotGiven and data.meta is None:
                return
            d, p = shorter.short(path)
            await writer([d, p, data.data_, *data.meta.dump()])
            return

        if hdr:
            if hdr is True:
                kw["state"] = self.get_state()
                hdr = self.gen_hdr_start(**kw)
            await writer(hdr)

        # await writer({"info": msg})
        await self.data.get(prefix).walk(saver, timestamp=kw.get("timestamp", 0))

        if ftr:
            if ftr is True:
                ftr = self.gen_hdr_stop()
            await writer(ftr)

    def gen_hdr_start(self, name, mode="full", **kw):
        """Return the CBOR tag for a start-of-file record"""
        from moat.lib.codec.moat_cbor import gen_start  # noqa: PLC0415

        fn = anyio.Path(name).name
        mstr = f"MoaT-Link {mode} {fn!r}"
        mstr += " " * (25 - len(mstr))
        kw["mode"] = mode
        kw["name"] = name
        kw["time"] = datetime.now(UTC)

        return gen_start(mstr, **kw)

    def gen_hdr_stop(self, **kw):
        """Return the CBOR tag for an end-of-file record"""
        from moat.lib.codec.moat_cbor import gen_stop  # noqa: PLC0415

        kw["time"] = datetime.now(UTC)
        return gen_stop(**kw)

    def gen_hdr_change(self, **kw):
        """Return the CBOR tag that describes a change"""
        from moat.lib.codec.moat_cbor import gen_change  # noqa: PLC0415

        kw["time"] = datetime.now(UTC)
        return gen_change(**kw)

    def get_state(self):
        return dict()

    async def save(self, path: str | anyio.Path, task_status=anyio.TASK_STATUS_IGNORED, **kw):
        """Save the current state to ``path``."""
        shorter = PathShortener([])
        try:
            spath = str(path)
            if spath in self._writing:
                raise RuntimeError(f"Already writing: {spath!r}")
            self._writing.add(spath)
            async with MsgWriter(path=path, codec="std-cbor") as mw:
                task_status.started()
                await self._save(mw, shorter, name=str(path), mode="full", **kw)
        finally:
            self._writing.remove(spath)

    async def save_stream(
        self,
        path: str | anyio.Path | FSPath | None = None,
        save_state: bool = False,
        task_status=anyio.TASK_STATUS_IGNORED,
        **kw,
    ):
        """Save the current state to ``path``.
        Continue writing updates until cancelled.

        Args:
          path: The file to save to.
          save_state: Flag whether to write the current state.
            If ``False`` (the default), only write changes.

        This task flushes the current buffer to disk when five seconds
        pass without updates, or every 100 messages.
        """
        shorter = PathShortener([])

        with anyio.CancelScope() as scope:
            spath = str(path)
            try:
                if spath in self._writing:
                    raise RuntimeError(f"Already writing: {spath!r}")
                self._writing.add(spath)
                rdr = self.write_monitor.reader(999)
                async with (
                    anyio.create_task_group() as tg,
                    MsgWriter(path=path, codec="std-cbor") as mw,
                ):
                    try:
                        msg = self.gen_hdr_stop(
                            name=str(path),
                            mode="restart" if save_state else "next",
                        )
                        # This ensures that the Stop message isn't seen by
                        # the new writer
                        self.write_monitor(msg)
                        rdr = self.write_monitor.reader(999, send_last=False)
                        task_status.started(scope)

                        msg = self.gen_hdr_start(
                            name=str(path),
                            mode="full" if save_state else "incr",
                            state=None if save_state else False,
                            **kw,
                        )
                        try:
                            await mw(msg)
                        except Exception as exc:
                            self.logger.error("MSG WRITE FAIL %r", msg, exc_info=exc)
                            msg = self.gen_hdr_start(
                                name=str(path),
                                mode="full" if save_state else "incr",
                                state=None if save_state else False,
                            )
                            await mw(msg)

                        if save_state:
                            tg.start_soon(
                                partial(
                                    self._save,
                                    mw,
                                    shorter,
                                    hdr=False,
                                    ftr=self.gen_hdr_change(state=False),
                                ),
                            )

                        await self._save_stream(rdr, mw, shorter, msg)
                    except BaseException as exc:
                        #
                        with anyio.move_on_after(2, shield=True):
                            await mw(self.gen_hdr_stop(mode="error", error=repr(exc)))
                        raise

                    finally:
                        with anyio.move_on_after(2, shield=True):
                            await mw.flush(force=True)
            finally:
                self._writing.remove(spath)
                self._writing_done.set()

    @staticmethod
    async def _save_stream(rdr, mw, shorter, ign):
        # helper for .save_stream() to keep the indent levels down

        last_saved = time.monotonic()
        last_saved_count = 1
        TIMEOUT = 5
        MAXMSG = 100

        while True:
            msg = None
            if last_saved_count:
                with anyio.move_on_after(TIMEOUT):
                    msg = await anext(rdr)
            else:
                msg = await anext(rdr)
            if msg is None or msg is ign:
                pass
            elif isinstance(msg, (list, tuple)):
                path, data, meta = msg
                if len(path) and path[0] == "run":
                    continue
                d, p = shorter.short(path)
                await mw([d, p, data, *meta.dump()])
                last_saved_count += 1
            elif isinstance(msg, Tag) and msg.tag == CBOR_TAG_MOAT_FILE_END:
                await mw(msg)
                return
            else:
                await mw(msg)

            # Ensure that we save the system state often enough.
            t = time.monotonic()
            td = t - last_saved
            if td >= TIMEOUT or last_saved_count >= MAXMSG:
                await mw.flush(force=True)
                last_saved = time.monotonic()
                last_saved_count = 0

    async def _flush_deleted(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Background task to remove deleted nodes from the tree
        """
        task_status.started()
        await anyio.sleep(self.cfg.timeout.delete / 10)
        t = time.time()

        async def _walk(d: Node) -> bool:
            # return True if we need to keep this

            has_any = False
            await anyio.sleep(0.1)

            # Drop the Meta entry if the deletion was long enough ago
            if (
                d._data is NotGiven  # noqa:SLF001
                and d.meta is not None
                and t - d.meta.timestamp > self.cfg.timeout.delete
            ):
                del d.meta
            drop = set()
            for k, v in d.items():
                if await _walk(v):
                    has_any = True
                else:
                    drop.add(k)
            for k in drop:
                del d[k]
            if has_any or d._data is not NotGiven:  # noqa:SLF001
                return True
            return d.meta is not None

        while True:
            await _walk(self.data)

            await anyio.sleep(self.cfg.timeout.delete / 20)

    async def _save_task(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Background task to periodically restart the saver task
        """
        save = self.cfg.server.save
        dest = anyio.Path(save.dir)
        rewrite = 0
        kw = {}
        while True:
            now = datetime.now(UTC)
            fn = dest / now.strftime(save.name)
            await fn.parent.mkdir(exist_ok=True, parents=True)
            await self.run_saver(path=fn, save_state=rewrite == 0, **kw)

            task_status.started()
            task_status = anyio.TASK_STATUS_IGNORED

            await anyio.sleep(save.interval)
            rewrite = (rewrite or save.rewrite) - 1
            kw["prev"] = str(fn)

    async def run_saver(self, path: PathType | None, save_state: bool = True, **kw):
        """
        Start a task that continually saves to disk.

        At most one one saver runs at a time; if a new one is started,
        the old saver is cancelled as soon as the new saver's current state
        is on disk (if told to do so) and it is ready to start writing.

        Args:
          path (str): The file to save to. If ``None``, simply stop any
            already-running log.
          save_state (bool): Flag whether to write the current state.
            If `False` (the default), only write changes.

        """
        if path is not None:
            await self._tg.start(
                partial(
                    self.save_stream,
                    path=path,
                    save_state=save_state,
                    **kw,
                ),
            )
        else:
            self.write_monitor(self.gen_hdr_stop(reason="log_end"))

    async def _sigterm(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        with anyio.open_signal_receiver(signal.SIGTERM) as r:
            task_status.started()

            async for _s in r:
                self._stop_flag.set()
                break

    async def serve(
        self,
        *,
        task_status=anyio.TASK_STATUS_IGNORED,
    ) -> None:
        """
        The method that opens a backend connection and actually runs the server.

        This will terminate when `stop` is called (in another task).
        """
        will_data = attrdict(
            topic=P(":R.run.service.main.server") / self.name,
            data=NotGiven,
            qos=1,
            retain=True,
        )

        # root path
        csr = self.cfg.root
        csr = P(csr) if isinstance(csr, str) else Path.build(csr)
        Root.set(csr)

        self._stop_flag = anyio.Event()
        self._stopped = anyio.Event()

        async with (
            EventSetter(self._stopped),
            Broadcaster(send_last=True, length=1000) as self.write_monitor,
            get_backend(self.cfg, name=self.name, will=will_data) as self.backend,
            anyio.create_task_group() as _tg,
        ):
            self._tg = _tg

            await _tg.start(self._monitor_ids)
            await _tg.start(self._monitor_pings)

            # Semi-detached taskgroups for clients and listeners

            async def run_tg(task_status):
                async with anyio.create_task_group() as tg:
                    task_status.started(tg)
                    await anyio.sleep_forever()

            self.logger.info("Starting up.")
            client_tg = await _tg.start(run_tg)
            listen_tg = await _tg.start(run_tg)

            # basic infrastructure

            await _tg.start(self._auth_update)
            await _tg.start(self._sigterm)

            # background tasks

            await _tg.start(self._backend_monitor)
            await _tg.start(self._backend_sender)
            await _tg.start(self._read_main)
            await _tg.start(self._read_stamp)

            # create a client link to any other servers we see
            await _tg.start(self._watch_up)

            # retrieve data

            self.logger.info("Reading data.")
            await _tg.start(self._read_initial)

            # save data
            self.logger.info("Starting services.")

            sd = anyio.Path(self.cfg.server.save.dir)
            if await sd.is_dir():
                await _tg.start(self._save_task)

            if self._init is not NotGiven:
                self.maybe_update(Path(), self._init, MsgMeta(origin="INIT", source="INIT"))

            if self._f_save is not None:
                await _tg.start(self.save, self._f_save)
                self._f_save = None

            # let clients in
            # TODO config via database

            ports = []
            if "ports" in self.cfg.server:
                for name, conn in self.cfg.server.ports.items():
                    ports.append(
                        await listen_tg.start(
                            self._run_server, client_tg, f"{self.name}-{name}", conn
                        )
                    )
            if not ports:
                conn = attrdict(host="0.0.0.0", port=self.cfg.server.port)  # noqa:S104
                ports.append(await listen_tg.start(self._run_server, client_tg, self.name, conn))

            globals = {"0.0.0.0", "::"}  # noqa: A001,S104
            link = [
                {"host": _get_my_ip(hp[0] == "::") if hp[0] in globals else hp[0], "port": hp[1]}
                for hp in ports
                if isinstance(hp, tuple)
            ]

            if not link:
                self.logger.warning("No external port")
            self.link_data = link

            # announce us to clients
            self.logger.info("Announcing to clients.")

            await self.backend.send(
                P(":R.run.service.main.server") / self.name,
                {"node": uname().node, "link": self.link_data, "auth": {"token": self.cur_auth}},
                meta=MsgMeta(origin=self.name),
                retain=True,
                qos=1,
            )

            ping_ready = anyio.Event()
            await _tg.start(self._pinger, ping_ready)
            if self._init is not NotGiven:
                await self.set_main_link()
            elif self.cfg.server.timeout.up > 0:
                with anyio.move_on_after(self.cfg.server.timeout.up):
                    await ping_ready.wait()
            elif self.cfg.server.timeout.up < 0:
                with anyio.fail_after(-self.cfg.server.timeout.up):
                    await ping_ready.wait()

            # watch for Will messages from dying servers that are "it"
            await _tg.start(self._watch_down)

            del self._init  # after this point there's no more difference

            # done, ready for service

            task_status.started((self, ports))
            self.logger.info("Start done.")

            # maintainance

            await _tg.start(self._flush_deleted)

            # wait for some stop signal

            await self._stop_flag.wait()

            # announce that we're going down
            await self.backend.send(
                topic=P(":R.run.service.main.down"),
                data=self.name,
                retain=False,
            )
            # TODO if we were "it", wait for some other server's announcement

            # stop listeners

            listen_tg.cancel_scope.cancel()

            # stop active clients

            # TODO tell our clients to reconnect to somewhere else
            # TODO wait a few seconds OR until they're all gone
            client_tg.cancel_scope.cancel()

            # stop saving data

            await self._stop_writers()
            # TODO signal our saver to finish
            # TODO wait for our saver to finish

            # Stop the rest
            _tg.cancel_scope.cancel()
            self._stopped.set()

    async def wait_stopped(self):
        "wait until service ends"
        await self._stopped.wait()

    async def _stop_writers(self):
        """Tell our writers to stop"""
        self.write_monitor(self.gen_hdr_stop(reason="Shutdown"))
        while self._writing:
            try:
                with anyio.fail_after(0.5):
                    await self._writing_done.wait()
                    self._writing_done = anyio.Event()
            except TimeoutError:
                for fn in self._writing:
                    self.logger.error("Shutdown: still writing to %r", fn)
                return

    async def cancel(self):
        """Cancel the server task.

        Unlike `stop` this does not allow the server to shut down cleanly.
        """
        self._tg.cancel_scope.cancel()  # pyright:ignore  # ??

    async def stop(self):
        """
        Tell the server to shut down cleanly.

        Waits until the server is in fact down.
        """
        self._stop_flag.set()
        await self._stopped.wait()

    async def _auth_update(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Background task to refresh the auth data.
        """
        self.refresh_auth()
        task_status.started()
        while True:
            await anyio.sleep(900)
            self.refresh_auth()
            await self.backend.send(
                P(":R.run.service.main.server") / self.name,
                {"node": uname().node, "link": self.link_data, "auth": {"token": self.cur_auth}},
                meta=MsgMeta(origin=self.name),
                retain=True,
                qos=1,
            )

            await anyio.sleep(30)
            self.last_auth = None

    async def _run_server_link(
        self, name: str, data: dict[str, Any], *, task_status=anyio.TASK_STATUS_IGNORED
    ):
        """
        Run a single client link to another server.
        """
        # TODO: There should be only one TCP link between server A and B, not two
        # (plus another for syncing).

        backoff = 0

        with anyio.CancelScope() as sc:
            self._server_link[name] = (sc, None)
            task_status.started()

            while True:
                try:
                    async with BasicLink(self.cfg, name=self.name, data=data) as conn:
                        conn.add_sub("cl")
                        if self._server_link[name][0] is not sc:
                            return
                        self._server_link[name] = (sc, conn)
                        self._server_link_add.set()
                        self._server_link_add = anyio.Event()

                        await anyio.sleep(30)
                        backoff = 0
                        await anyio.sleep_forever()

                except* (EOFError, anyio.ClosedResourceError, anyio.EndOfStream):
                    self.logger.warning("Link to %s closed", name)

                except* OSError:
                    self.logger.warning("Link to %s died", name)

                except* Exception as exc:
                    self.logger.warning("Link to %s died", name, exc_info=exc)

                finally:
                    if name in self._server_link and self._server_link[name][0] is sc:
                        self._server_link[name] = (sc, None)
                    else:
                        return

                backoff = min(backoff * 1.2 + 0.1, 30)
                await anyio.sleep(backoff)

    async def _watch_up(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Monitor servers' service announcements and connects to them
        so that client links can be forwarded.
        """
        async with (
            anyio.create_task_group() as tg,
            self.backend.monitor(P(":R.run.service.main.server"), subtree=True) as mon,
        ):
            task_status.started()
            async for msg in mon:
                name = msg.topic[-1]

                sl = self._server_link.pop(name, None)
                if sl is not None:
                    sl[0].cancel()

                if msg.data is NotGiven:
                    tg.start_soon(self._down_one, name)
                    continue
                self._downed.pop(name, None)

                if name == self.name:
                    continue
                if name in self._server_link:
                    continue
                await tg.start(self._run_server_link, name, msg.data)

    async def _down_one(self, name: str):
        # protect against repeats
        t = anyio.current_time()
        if name in self._downed and t - self._downed[name] < self.cfg.server.ping.cycle:
            return
        self._downed[name] = t

        main = aiter(self.service_monitor.reader(5, send_last=True))
        try:
            with anyio.fail_after(0.1):
                service = await anext(main)
        except TimeoutError:
            return  # no service, nothing to do
        if service.meta.origin != name:
            return  # not current

        async with anyio.create_task_group() as tg:

            @tg.start_soon
            async def changed():
                async for msg in main:
                    if msg.meta.origin != name:
                        tg.cancel_scope.cancel()
                        return

            gap = self.cfg.server.ping.gap
            try:
                n = self._ping_history.index(self.name)
            except ValueError:
                await anyio.sleep(gap * (1.2 + random.random()))
            else:
                await anyio.sleep(gap * n / len(self._ping_history))
            await self.set_main_link()

    async def _watch_down(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Monitor "down" messages and broadcast our own info if it's the active node.
        """

        async with (
            self.backend.monitor(P(":R.run.service.main.down")) as mon,
            anyio.create_task_group() as tg,
        ):
            task_status.started()
            async for msg in mon:
                name = msg.data
                if name == self.name:
                    return
                tg.start_soon(self._down_one, msg.data)

    async def _read_main(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Task to read the main service monitoring channel
        """
        async with (
            Broadcaster(300, send_last=True) as self.service_monitor,
            self.backend.monitor(P(":R.run.service.main.conn")) as mon,
        ):
            task_status.started()
            async for msg in mon:
                self.service_monitor(msg)

    async def _read_stamp(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Task to read our stamping channel
        """
        async with self.backend.monitor(P(":R.run.service.main.stamp") / self.name) as mon:
            task_status.started()
            async for msg in mon:
                self._stamp_in = msg.data
                self._stamp_in_evt.set()
                self._stamp_in_evt = anyio.Event()

    async def _sync_from(self, name: str, data: dict) -> bool:
        """
        Sync from the server indicated by this message.

        Returns True if successful.
        """
        with anyio.CancelScope() as scope:
            if name in self._syncing:
                self.logger.warning("Already syncing to %s", name)
                return False
            self._syncing[name] = scope

            try:
                with anyio.fail_after(5):
                    while (
                        name not in self._server_link
                        or (conn := self._server_link[name][1]) is None
                    ):
                        await self._server_link_add.wait()

                await self._sync_one(conn)
            except OSError as exc:
                self.logger.warning("No sync %r: %r", data, exc)
                return False
            except Exception as exc:
                self.logger.warning(
                    "No sync %r: %r",
                    data,
                    exc,
                    exc_info=exc,
                )
                return False
            finally:
                del self._syncing[name]
        return True

    async def _sync_one(self, conn: MsgSender, prefix: Path = Path()):
        async with conn.cmd(P("d.walk"), prefix).stream_in() as feed:
            pl = PathLongener()
            upd = 0
            skp = 0
            async for msg in feed:
                d, p, data, *mt = msg
                path = pl.long(d, p)
                meta = MsgMeta.restore(mt)
                meta.source = "_Load"
                if self.maybe_update(prefix + path, data, meta):
                    upd += 1
                else:
                    skp += 1
                self.logger.debug("Sync Msg %r", msg)
        self.logger.info("Sync finished. %d new, %d existing", upd, skp)

    async def _load_initial(self, fn):
        upd, _skp, tags, mode = await self.load_file(fn=fn)
        if mode != "init" and not upd:
            raise RuntimeError("No data!")
        if not tag_check(tags):
            raise RuntimeError("No or incomplete tags!")
        return

    async def _read_initial(self, *, task_status=anyio.TASK_STATUS_IGNORED):
        """
        Read initial data from either file backup or a remote server.

        Runs in the background if we have initial data.
        """
        ready = anyio.Event()
        if self._init is not NotGiven:
            ready.set()
        if self._f_load is not None:
            await self._load_initial(self._f_load)
            task_status.started()
            return

        async with anyio.create_task_group() as tg:

            @tg.start_soon
            async def trigger():
                with anyio.fail_after(self.cfg.server.timeout.startup):
                    await ready.wait()
                task_status.started()

            tg.start_soon(self._get_remote_data, aiter(self.service_monitor), ready)
            tg.start_soon(self._read_saved_data, ready)

            # Allow for retrieving data from MQTT if no server is running.
            # This should not be done lightly.
            if self.cfg.server.timeout.mqtt:
                rdr = self.write_monitor.reader(10000)
                while True:
                    with anyio.move_on_after(self.cfg.server.timeout.mqtt):
                        await anext(rdr)
                        continue
                    break
                ready.set()

    async def _read_saved_data(self, ready: anyio.Event):
        save = self.cfg.server.save
        dest = anyio.Path(save.dir)
        if not await dest.is_dir():
            self.logger.info("No saved data in %r", str(dest))
            return

        done = set()
        fs: list[anyio.Path] = []
        async for fn in dest.rglob("*.moat"):
            fs.append(fn)
        fs.sort()
        fn = None

        while fs:
            if fn is None:
                fn = fs.pop()

            sfn = str(fn)
            if sfn in done or sfn in self._writing:
                fn = None
                continue
            done.add(sfn)

            try:
                upd, _skp, tags, mode = await self.load_file(fn=fn)
            except Exception as exc:
                self.logger.error("Failed to load %s", fn, exc_info=exc)
                await fn.rename(fn.with_suffix(".moat.bad"))
                continue

            if mode != "init" and (not upd or not tags):
                continue
            if not tag_check(tags):
                # extract the first tag's value
                tt = tags[0]
                while isinstance(tt, Tag):
                    tt = tt.value
                if isinstance(tt, Sequence):
                    tt = tt[1]
                fn = tt.get("prev", None)
                if fn is not None:
                    fn = anyio.Path(fn)
                continue
            ready.set()
            return

    async def load_file(
        self, fn: anyio.Path, prefix: Path = Path(), local: bool = False
    ) -> tuple[int, int, list[Tag], str]:
        """
        Load a file.

        The result is the number of updated/skipped entries,
        plus the tags from the file.
        """
        self.logger.info("Loading from %r", fn)
        mode = "?"
        async with MsgReader(fn, codec="std-cbor") as rdr:
            pl = PathLongener(prefix)
            upd, skp, tags = 0, 0, []
            ehdr = None
            async for msg in rdr:
                self.logger.debug("Load %r", msg)
                if isinstance(msg, Tag) and msg.tag == CBOR_TAG_CBOR_LEADER:
                    msg = msg.value  # noqa:PLW2901
                if isinstance(msg, Tag):
                    tags.append(msg)
                    if msg.tag == CBOR_TAG_MOAT_FILE_ID:
                        # concatenated files?
                        if ehdr is not None:
                            raise ValueError("START within file %r", str(fn))
                        mode = msg.value[1].get("mode", "?")
                        # TODO verify that these belong together

                    elif msg.tag == CBOR_TAG_MOAT_CHANGE:
                        # TODO verify?
                        continue

                    elif msg.tag == CBOR_TAG_MOAT_FILE_END:
                        if ehdr is None:
                            raise ValueError("END without start in %r", str(fn))
                        if ehdr.tag == CBOR_TAG_MOAT_FILE_END:
                            raise ValueError("Duplicate END in %r", str(fn))
                    else:
                        self.logger.warning("Unknown tag %r: %r", str(fn), msg)
                        continue
                    ehdr = msg
                    continue
                elif ehdr is None:
                    raise ValueError("Untagged file")
                elif ehdr.tag != CBOR_TAG_MOAT_FILE_ID:
                    raise ValueError("Data %r after tag: %r", msg, ehdr)

                # Any other problems just raise an exception
                d, p, data, *mt = msg
                path = pl.long(d, p)
                meta = MsgMeta.restore(mt)
                meta.source = "_file"
                if self.maybe_update(path, data, meta, local=local):
                    # Entries that have been deleted don't count as updates
                    if data is not NotGiven:
                        upd += 1
                else:
                    skp += 1

            self.logger.info("Loading from %r done: %d/%d", fn, upd, skp)
            return upd, skp, tags, mode

    async def _get_remote_data(self, main: BroadcastReader, ready: anyio.Event):
        seen = defaultdict(lambda: 0)
        async for msg in main:
            if msg.meta.origin == self.name:
                continue  # XXX stale
            if msg.data is NotGiven:
                continue  # deleted?
            if await self._sync_from(msg.meta.origin, msg.data):
                ready.set()
                return
            sn = seen[msg.meta.origin]
            if sn > 2:
                return
            seen[msg.meta.origin] = sn + 1

        pass

    def get_cached_error(self, name) -> Exception | str | None:
        return self._error_cache.pop(name, None)

    async def _run_server(self, tg, name, cfg, *, task_status=anyio.TASK_STATUS_IGNORED):
        """runs a listener on a single port"""
        if "host" in cfg:
            # TODO SSL and/or whatnot
            lcfg = attrdict()
            if "host" in cfg:
                lcfg.local_host = cfg.host
            if "port" in cfg:
                lcfg.local_port = cfg.port
            try:
                listener = await anyio.create_tcp_listener(**lcfg)
            except Exception as exc:
                raise RuntimeError("Could not create socket", cfg) from exc

        elif "port" in cfg:
            # Unix socket
            port = cfg.port
            if port.startswith("RUN/"):
                port = os.environ["XDG_RUNTIME_DIR"] + port[3:]
            try:
                listener = await anyio.create_unix_listener(port)
            except Exception as exc:
                raise RuntimeError("Could not create socket", port, cfg) from exc

        else:
            self.logger.error("No host/port in server cfg %s: %r", name, cfg)
            task_status.started(None)
            return

        async with listener:
            task_status.started(listener.extra(SocketAttribute.local_address))
            await listener.serve(partial(self._client_task, name), task_group=tg)

    async def _client_task(self, name, stream):
        """
        Manager for a single client connection.

        The actual work happens in `ServerClient.run`. This wrapper
        mainly tries to record what went wrong on the server so the next
        client session can ask.

        @name is the key name of this server's config item.
        """
        c = None
        cnr = -1
        try:
            c = ServerClient(server=self, prefix=name, stream=stream)
            cnr = c.client_nr
            try:
                oc = self._clients.get(c.name, None)
                self._clients[c.name] = c
                if oc is not None:
                    await oc.aclose()
                    del oc
                await c.run()

            finally:
                if self._clients.get(c.name, None) is c:
                    del self._clients[c.name]

        except (ClosedResourceError, anyio.EndOfStream):
            self.logger.debug("Client C_%s closed", cnr)
        except BaseException as exc:
            CancelExc = anyio.get_cancelled_exc_class()
            self.logger.debug("End Client C_%s %r", cnr, exc)
            ex = [e for e in exc_iter(exc) if not isinstance(e, CancelExc)]
            if not ex:
                exc = None
            elif len(ex) == 1:
                exc = ex[0]

            if exc is not None and not isinstance(exc, CancelExc):
                if isinstance(exc, (ClosedResourceError, anyio.EndOfStream)):
                    self.logger.debug("Client C_%s closed", cnr)
                elif isinstance(exc, TimeoutError):
                    self.logger.warning("Client C_%s timed out", cnr)
                else:
                    self.logger.exception("Client connection C_%s killed", cnr, exc_info=exc)
            if exc is None:
                exc = "Cancelled"
            self._error_cache[name] = cast(Exception, exc)
            self.logger.debug("End Client C_%s %r", cnr, exc)
            if "pytest" in sys.modules:
                raise
        finally:
            with anyio.move_on_after(2, shield=True):
                await stream.aclose()

    # server-to-server crosslinks

    async def sub_cl(self, msg: Msg, rcmd: list[PathElem]) -> None:
        """
        Direct to one of our clients.
        """
        "Local subcommand redirect for 'cl'"
        name = rcmd.pop()
        if not isinstance(name, str):
            raise KeyError(name)
        try:
            cl = self._clients[name]
        except KeyError:
            for cl in self._clients.values():
                if f"{cl.prefix}_{cl.client_nr}" == name:
                    break
            else:
                raise
        return await cl.sender.handle(msg, rcmd)

    async def stream_cl(self, msg: Msg) -> None:
        """
        Send the list of currently-known clients.
        """
        if not msg.can_stream:
            return await msg.result(len(self._clients))

        cl = list(self._clients.keys())
        async with msg.stream_out(len(cl)) as ml:
            for cn in cl:
                await ml.send(cn)

    async def sub_srv(self, msg: Msg, rcmd: list[PathElem]) -> None:
        """
        Direct a message to another server.
        """
        name = rcmd.pop()
        if not isinstance(name, str):
            raise KeyError(name)
        if name == self.name:
            return await self.handle(msg, rcmd)

        try:
            _sc, conn = self._server_link[name]
        except KeyError:
            conn = None
        if conn is None:
            raise RuntimeError(f"Server link {name!r} down")

        return await conn.handle(msg, rcmd)

    async def stream_srv(self, msg: Msg) -> None:
        """
        Send the list of currently-known servers.
        """
        if not msg.can_stream:
            return await msg.result(len(self._server_link))

        cl = list(self._server_link.keys())
        async with msg.stream_out(len(cl)) as ml:
            for cn in cl:
                await ml.send(cn)

    async def _monitor_ids(self, *, task_status):
        async with self.backend.monitor(
            P(":R.run.id"),
            raw=False,
            qos=QoS.AT_LEAST_ONCE,
            no_local=False,
            subtree=True,
        ) as mon:
            task_status.started()

            async for msg in mon:
                name = msg.topic[-1]
                if msg.data is NotGiven:
                    self.known_ids.discard(name)
                else:
                    self.known_ids.add(name)

    async def _monitor_pings(self, *, task_status):
        async with self.backend.monitor(
            P(":R.run.ping.id"),
            raw=False,
            no_local=False,
            subtree=True,
        ) as mon:
            task_status.started()

            async for msg in mon:
                name = msg.topic[-1]
                if msg.data is NotGiven or not msg.data["up"]:
                    self.known_ids.discard(name)
