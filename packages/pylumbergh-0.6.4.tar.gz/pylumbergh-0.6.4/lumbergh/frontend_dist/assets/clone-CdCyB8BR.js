import{b as r}from"./graph-Ddh4WSJA.js";var e=4;function a(o){return r(o,e)}export{a as c};
