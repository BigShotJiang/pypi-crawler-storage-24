"""Shared fixtures for CLI tests."""

import pytest
from navari_cli.config import NavariConfig


@pytest.fixture()
def _tmp_config(tmp_path, monkeypatch):
    """Redirect NavariConfig to a temporary directory."""
    monkeypatch.setattr(NavariConfig, "CONFIG_DIR", tmp_path)
    monkeypatch.setattr(NavariConfig, "CREDENTIALS_FILE", tmp_path / "credentials.json")
    monkeypatch.setattr(NavariConfig, "CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(NavariConfig, "MSAL_CACHE_FILE", tmp_path / "msal_cache.json")
