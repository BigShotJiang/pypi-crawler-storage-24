"""Entry point for python -m navari_cli."""

from navari_cli.cli import app

if __name__ == "__main__":
    app()
