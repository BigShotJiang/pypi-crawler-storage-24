"""Navari CLI - Command-line interface for Navari AI Agent."""

# Use the OS certificate store (Windows cert store, macOS Keychain, etc.)
# so that corporate CAs trusted at the OS level work without --no-verify.
# Skip when imported as a side-effect during tests — truststore's SSLContext
# patching causes infinite recursion in botocore's create_urllib3_context().
import sys

if "pytest" not in sys.modules:
    import truststore

    truststore.inject_into_ssl()

try:
    from navari_cli._version import __version__
except ImportError:
    __version__ = "0.0.0-dev"
