"""Constants for Navari CLI."""

# OAuth redirect server
DEFAULT_REDIRECT_PORT = 4444
DEFAULT_REDIRECT_PATH = "/direct-callback"
DEFAULT_REDIRECT_URI = f"http://localhost:{DEFAULT_REDIRECT_PORT}{DEFAULT_REDIRECT_PATH}"

# File size limit
MAX_ATTACHMENT_FILE_SIZE = 500 * 1024 * 1024  # 500MB

# Output
DEFAULT_FORMAT = "plain"
