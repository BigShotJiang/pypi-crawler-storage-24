from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.latest_legal_agreements_response import LatestLegalAgreementsResponse
from ...types import Response


def _get_kwargs() -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/user/legal-agreements/latest",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> LatestLegalAgreementsResponse | None:
    if response.status_code == 200:
        response_200 = LatestLegalAgreementsResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[LatestLegalAgreementsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[LatestLegalAgreementsResponse]:
    """Get Latest Legal Agreements

     Get the latest legal agreement for each type.

    This endpoint is public and does not require authentication as users need
    access to legal documents before login.

    Returns:
        LatestLegalAgreementsResponse: Contains the latest legal agreement for each type

    Raises:
        HTTPException: If there's an error retrieving the agreements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LatestLegalAgreementsResponse]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> LatestLegalAgreementsResponse | None:
    """Get Latest Legal Agreements

     Get the latest legal agreement for each type.

    This endpoint is public and does not require authentication as users need
    access to legal documents before login.

    Returns:
        LatestLegalAgreementsResponse: Contains the latest legal agreement for each type

    Raises:
        HTTPException: If there's an error retrieving the agreements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LatestLegalAgreementsResponse
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[LatestLegalAgreementsResponse]:
    """Get Latest Legal Agreements

     Get the latest legal agreement for each type.

    This endpoint is public and does not require authentication as users need
    access to legal documents before login.

    Returns:
        LatestLegalAgreementsResponse: Contains the latest legal agreement for each type

    Raises:
        HTTPException: If there's an error retrieving the agreements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LatestLegalAgreementsResponse]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> LatestLegalAgreementsResponse | None:
    """Get Latest Legal Agreements

     Get the latest legal agreement for each type.

    This endpoint is public and does not require authentication as users need
    access to legal documents before login.

    Returns:
        LatestLegalAgreementsResponse: Contains the latest legal agreement for each type

    Raises:
        HTTPException: If there's an error retrieving the agreements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LatestLegalAgreementsResponse
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
