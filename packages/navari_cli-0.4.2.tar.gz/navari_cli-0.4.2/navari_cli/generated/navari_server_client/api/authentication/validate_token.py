from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.validate_token_response import ValidateTokenResponse
from ...types import Response


def _get_kwargs() -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/auth/validate",
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ValidateTokenResponse | None:
    if response.status_code == 200:
        response_200 = ValidateTokenResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ValidateTokenResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[ValidateTokenResponse]:
    """Validate Token

     Validate JWT token for nginx auth_request.

    This endpoint is designed to be used by nginx's auth_request module.
    It validates the JWT token and returns appropriate HTTP status codes.
    Additionally validates that the token belongs to the workspace user.

    Args:
        request: The FastAPI request object
        current_user: The authenticated user (validates the token)

    Returns:
        Simple success response for valid tokens

    Raises:
        HTTPException: 401/403 for invalid tokens or user mismatch

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ValidateTokenResponse]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> ValidateTokenResponse | None:
    """Validate Token

     Validate JWT token for nginx auth_request.

    This endpoint is designed to be used by nginx's auth_request module.
    It validates the JWT token and returns appropriate HTTP status codes.
    Additionally validates that the token belongs to the workspace user.

    Args:
        request: The FastAPI request object
        current_user: The authenticated user (validates the token)

    Returns:
        Simple success response for valid tokens

    Raises:
        HTTPException: 401/403 for invalid tokens or user mismatch

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ValidateTokenResponse
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[ValidateTokenResponse]:
    """Validate Token

     Validate JWT token for nginx auth_request.

    This endpoint is designed to be used by nginx's auth_request module.
    It validates the JWT token and returns appropriate HTTP status codes.
    Additionally validates that the token belongs to the workspace user.

    Args:
        request: The FastAPI request object
        current_user: The authenticated user (validates the token)

    Returns:
        Simple success response for valid tokens

    Raises:
        HTTPException: 401/403 for invalid tokens or user mismatch

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ValidateTokenResponse]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> ValidateTokenResponse | None:
    """Validate Token

     Validate JWT token for nginx auth_request.

    This endpoint is designed to be used by nginx's auth_request module.
    It validates the JWT token and returns appropriate HTTP status codes.
    Additionally validates that the token belongs to the workspace user.

    Args:
        request: The FastAPI request object
        current_user: The authenticated user (validates the token)

    Returns:
        Simple success response for valid tokens

    Raises:
        HTTPException: 401/403 for invalid tokens or user mismatch

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ValidateTokenResponse
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
