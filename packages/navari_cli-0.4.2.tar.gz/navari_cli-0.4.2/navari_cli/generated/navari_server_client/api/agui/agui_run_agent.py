from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    conversation_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/conversations/{conversation_id}/agui".format(
            conversation_id=quote(str(conversation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | HTTPValidationError]:
    """Agui Run Agent

     AG-UI protocol endpoint with comprehensive features.

    Features:
    - Conversation-level concurrency control
    - Message history persistence (auto-loaded by agent_manager, saved in on_complete)
    - Usage tracking after run completes
    - Privacy mode detection
    - A2A task cancellation via connection monitoring
    - Error handling with user-friendly messages

    Follows standard AG-UI protocol:
    - POST with RunAgentInput in body
    - Returns SSE stream of AG-UI events
    - Handles DeferredToolRequests (approval flow) automatically
    - Supports file uploads via forwardedProps.file_ids (handled by NavariAGUIAdapter)

    Args:
        conversation_id: The conversation ID
        request: FastAPI Request object
        user: Authenticated user from dependency

    Returns:
        StreamingResponse with SSE events

    Args:
        conversation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | HTTPValidationError | None:
    """Agui Run Agent

     AG-UI protocol endpoint with comprehensive features.

    Features:
    - Conversation-level concurrency control
    - Message history persistence (auto-loaded by agent_manager, saved in on_complete)
    - Usage tracking after run completes
    - Privacy mode detection
    - A2A task cancellation via connection monitoring
    - Error handling with user-friendly messages

    Follows standard AG-UI protocol:
    - POST with RunAgentInput in body
    - Returns SSE stream of AG-UI events
    - Handles DeferredToolRequests (approval flow) automatically
    - Supports file uploads via forwardedProps.file_ids (handled by NavariAGUIAdapter)

    Args:
        conversation_id: The conversation ID
        request: FastAPI Request object
        user: Authenticated user from dependency

    Returns:
        StreamingResponse with SSE events

    Args:
        conversation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        conversation_id=conversation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | HTTPValidationError]:
    """Agui Run Agent

     AG-UI protocol endpoint with comprehensive features.

    Features:
    - Conversation-level concurrency control
    - Message history persistence (auto-loaded by agent_manager, saved in on_complete)
    - Usage tracking after run completes
    - Privacy mode detection
    - A2A task cancellation via connection monitoring
    - Error handling with user-friendly messages

    Follows standard AG-UI protocol:
    - POST with RunAgentInput in body
    - Returns SSE stream of AG-UI events
    - Handles DeferredToolRequests (approval flow) automatically
    - Supports file uploads via forwardedProps.file_ids (handled by NavariAGUIAdapter)

    Args:
        conversation_id: The conversation ID
        request: FastAPI Request object
        user: Authenticated user from dependency

    Returns:
        StreamingResponse with SSE events

    Args:
        conversation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | HTTPValidationError | None:
    """Agui Run Agent

     AG-UI protocol endpoint with comprehensive features.

    Features:
    - Conversation-level concurrency control
    - Message history persistence (auto-loaded by agent_manager, saved in on_complete)
    - Usage tracking after run completes
    - Privacy mode detection
    - A2A task cancellation via connection monitoring
    - Error handling with user-friendly messages

    Follows standard AG-UI protocol:
    - POST with RunAgentInput in body
    - Returns SSE stream of AG-UI events
    - Handles DeferredToolRequests (approval flow) automatically
    - Supports file uploads via forwardedProps.file_ids (handled by NavariAGUIAdapter)

    Args:
        conversation_id: The conversation ID
        request: FastAPI Request object
        user: Authenticated user from dependency

    Returns:
        StreamingResponse with SSE events

    Args:
        conversation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            conversation_id=conversation_id,
            client=client,
        )
    ).parsed
