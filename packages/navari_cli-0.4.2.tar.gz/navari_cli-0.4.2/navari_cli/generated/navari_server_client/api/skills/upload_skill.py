from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_upload_skill_api_skills_upload_post import BodyUploadSkillApiSkillsUploadPost
from ...models.http_validation_error import HTTPValidationError
from ...models.skill_upload_response import SkillUploadResponse
from ...types import Response


def _get_kwargs(
    *,
    body: BodyUploadSkillApiSkillsUploadPost,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/skills/upload",
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SkillUploadResponse | None:
    if response.status_code == 200:
        response_200 = SkillUploadResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SkillUploadResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: BodyUploadSkillApiSkillsUploadPost,
) -> Response[HTTPValidationError | SkillUploadResponse]:
    """Upload Skill

     Upload a skill as a ZIP file.

    The ZIP must contain a SKILL.md file at the root or in a single subdirectory.
    The SKILL.md must have 'name' and 'description' fields in its frontmatter.

    Skills with the same name will be overwritten.

    Args:
        body (BodyUploadSkillApiSkillsUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SkillUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: BodyUploadSkillApiSkillsUploadPost,
) -> HTTPValidationError | SkillUploadResponse | None:
    """Upload Skill

     Upload a skill as a ZIP file.

    The ZIP must contain a SKILL.md file at the root or in a single subdirectory.
    The SKILL.md must have 'name' and 'description' fields in its frontmatter.

    Skills with the same name will be overwritten.

    Args:
        body (BodyUploadSkillApiSkillsUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SkillUploadResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: BodyUploadSkillApiSkillsUploadPost,
) -> Response[HTTPValidationError | SkillUploadResponse]:
    """Upload Skill

     Upload a skill as a ZIP file.

    The ZIP must contain a SKILL.md file at the root or in a single subdirectory.
    The SKILL.md must have 'name' and 'description' fields in its frontmatter.

    Skills with the same name will be overwritten.

    Args:
        body (BodyUploadSkillApiSkillsUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SkillUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: BodyUploadSkillApiSkillsUploadPost,
) -> HTTPValidationError | SkillUploadResponse | None:
    """Upload Skill

     Upload a skill as a ZIP file.

    The ZIP must contain a SKILL.md file at the root or in a single subdirectory.
    The SKILL.md must have 'name' and 'description' fields in its frontmatter.

    Skills with the same name will be overwritten.

    Args:
        body (BodyUploadSkillApiSkillsUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SkillUploadResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
