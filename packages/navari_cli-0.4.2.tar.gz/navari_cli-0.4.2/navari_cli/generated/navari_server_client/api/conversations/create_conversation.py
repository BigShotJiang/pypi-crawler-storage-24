from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.conversation_create import ConversationCreate
from ...models.conversation_detail_response import ConversationDetailResponse
from ...models.error_response import ErrorResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: ConversationCreate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/conversations/",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConversationDetailResponse | ErrorResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ConversationDetailResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConversationDetailResponse | ErrorResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ConversationCreate,
) -> Response[ConversationDetailResponse | ErrorResponse | HTTPValidationError]:
    """Create Conversation

     Create a new conversation with available feature flags.

    Args:
        data: The data for the new conversation
        current_user: The authenticated user
        creds: Authorization credentials

    Returns:
        The created conversation with available MCP tool features

    Args:
        body (ConversationCreate): Request model for creating a new conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationDetailResponse | ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ConversationCreate,
) -> ConversationDetailResponse | ErrorResponse | HTTPValidationError | None:
    """Create Conversation

     Create a new conversation with available feature flags.

    Args:
        data: The data for the new conversation
        current_user: The authenticated user
        creds: Authorization credentials

    Returns:
        The created conversation with available MCP tool features

    Args:
        body (ConversationCreate): Request model for creating a new conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationDetailResponse | ErrorResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ConversationCreate,
) -> Response[ConversationDetailResponse | ErrorResponse | HTTPValidationError]:
    """Create Conversation

     Create a new conversation with available feature flags.

    Args:
        data: The data for the new conversation
        current_user: The authenticated user
        creds: Authorization credentials

    Returns:
        The created conversation with available MCP tool features

    Args:
        body (ConversationCreate): Request model for creating a new conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationDetailResponse | ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ConversationCreate,
) -> ConversationDetailResponse | ErrorResponse | HTTPValidationError | None:
    """Create Conversation

     Create a new conversation with available feature flags.

    Args:
        data: The data for the new conversation
        current_user: The authenticated user
        creds: Authorization credentials

    Returns:
        The created conversation with available MCP tool features

    Args:
        body (ConversationCreate): Request model for creating a new conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationDetailResponse | ErrorResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
