from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.conversation_response import ConversationResponse
from ...models.conversation_update import ConversationUpdate
from ...models.error_response import ErrorResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    conversation_id: str,
    *,
    body: ConversationUpdate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/conversations/{conversation_id}".format(
            conversation_id=quote(str(conversation_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConversationResponse | ErrorResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ConversationResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConversationResponse | ErrorResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    body: ConversationUpdate,
) -> Response[ConversationResponse | ErrorResponse | HTTPValidationError]:
    """Update Conversation

     Update a conversation.

    Args:
        conversation_id: The ID of the conversation to update
        data: The update data for the conversation
        current_user: The authenticated user

    Returns:
        The updated conversation

    Args:
        conversation_id (str): The ID of the conversation to update
        body (ConversationUpdate): Request model for updating a conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationResponse | ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    body: ConversationUpdate,
) -> ConversationResponse | ErrorResponse | HTTPValidationError | None:
    """Update Conversation

     Update a conversation.

    Args:
        conversation_id: The ID of the conversation to update
        data: The update data for the conversation
        current_user: The authenticated user

    Returns:
        The updated conversation

    Args:
        conversation_id (str): The ID of the conversation to update
        body (ConversationUpdate): Request model for updating a conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationResponse | ErrorResponse | HTTPValidationError
    """

    return sync_detailed(
        conversation_id=conversation_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    body: ConversationUpdate,
) -> Response[ConversationResponse | ErrorResponse | HTTPValidationError]:
    """Update Conversation

     Update a conversation.

    Args:
        conversation_id: The ID of the conversation to update
        data: The update data for the conversation
        current_user: The authenticated user

    Returns:
        The updated conversation

    Args:
        conversation_id (str): The ID of the conversation to update
        body (ConversationUpdate): Request model for updating a conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationResponse | ErrorResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conversation_id: str,
    *,
    client: AuthenticatedClient,
    body: ConversationUpdate,
) -> ConversationResponse | ErrorResponse | HTTPValidationError | None:
    """Update Conversation

     Update a conversation.

    Args:
        conversation_id: The ID of the conversation to update
        data: The update data for the conversation
        current_user: The authenticated user

    Returns:
        The updated conversation

    Args:
        conversation_id (str): The ID of the conversation to update
        body (ConversationUpdate): Request model for updating a conversation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationResponse | ErrorResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            conversation_id=conversation_id,
            client=client,
            body=body,
        )
    ).parsed
