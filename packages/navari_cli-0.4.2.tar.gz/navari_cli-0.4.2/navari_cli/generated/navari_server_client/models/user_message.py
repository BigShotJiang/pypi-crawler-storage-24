from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.binary_input_content import BinaryInputContent
    from ..models.text_input_content import TextInputContent


T = TypeVar("T", bound="UserMessage")


@_attrs_define
class UserMessage:
    """A user message supporting text or multimodal content.

    Attributes:
        id (str):
        content (list[BinaryInputContent | TextInputContent] | str):
        role (Literal['user'] | Unset):  Default: 'user'.
        name (None | str | Unset):
    """

    id: str
    content: list[BinaryInputContent | TextInputContent] | str
    role: Literal["user"] | Unset = "user"
    name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.text_input_content import TextInputContent

        id = self.id

        content: list[dict[str, Any]] | str
        if isinstance(self.content, list):
            content = []
            for content_type_1_item_data in self.content:
                content_type_1_item: dict[str, Any]
                if isinstance(content_type_1_item_data, TextInputContent):
                    content_type_1_item = content_type_1_item_data.to_dict()
                else:
                    content_type_1_item = content_type_1_item_data.to_dict()

                content.append(content_type_1_item)

        else:
            content = self.content

        role = self.role

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "content": content,
            }
        )
        if role is not UNSET:
            field_dict["role"] = role
        if name is not UNSET:
            field_dict["name"] = name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.binary_input_content import BinaryInputContent
        from ..models.text_input_content import TextInputContent

        d = dict(src_dict)
        id = d.pop("id")

        def _parse_content(data: object) -> list[BinaryInputContent | TextInputContent] | str:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                content_type_1 = []
                _content_type_1 = data
                for content_type_1_item_data in _content_type_1:

                    def _parse_content_type_1_item(data: object) -> BinaryInputContent | TextInputContent:
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            content_type_1_item_type_0 = TextInputContent.from_dict(data)

                            return content_type_1_item_type_0
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        if not isinstance(data, dict):
                            raise TypeError()
                        content_type_1_item_type_1 = BinaryInputContent.from_dict(data)

                        return content_type_1_item_type_1

                    content_type_1_item = _parse_content_type_1_item(content_type_1_item_data)

                    content_type_1.append(content_type_1_item)

                return content_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[BinaryInputContent | TextInputContent] | str, data)

        content = _parse_content(d.pop("content"))

        role = cast(Literal["user"] | Unset, d.pop("role", UNSET))
        if role != "user" and not isinstance(role, Unset):
            raise ValueError(f"role must match const 'user', got '{role}'")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        user_message = cls(
            id=id,
            content=content,
            role=role,
            name=name,
        )

        user_message.additional_properties = d
        return user_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
