from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RunFinishedEvent")


@_attrs_define
class RunFinishedEvent:
    """Event indicating that a run has finished.

    Attributes:
        thread_id (str):
        run_id (str):
        type_ (Literal['RUN_FINISHED'] | Unset):  Default: 'RUN_FINISHED'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
        result (Any | None | Unset):
    """

    thread_id: str
    run_id: str
    type_: Literal["RUN_FINISHED"] | Unset = "RUN_FINISHED"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    result: Any | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        thread_id = self.thread_id

        run_id = self.run_id

        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        result: Any | None | Unset
        if isinstance(self.result, Unset):
            result = UNSET
        else:
            result = self.result

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "threadId": thread_id,
                "runId": run_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event
        if result is not UNSET:
            field_dict["result"] = result

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        thread_id = d.pop("threadId")

        run_id = d.pop("runId")

        type_ = cast(Literal["RUN_FINISHED"] | Unset, d.pop("type", UNSET))
        if type_ != "RUN_FINISHED" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'RUN_FINISHED', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        def _parse_result(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        result = _parse_result(d.pop("result", UNSET))

        run_finished_event = cls(
            thread_id=thread_id,
            run_id=run_id,
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
            result=result,
        )

        run_finished_event.additional_properties = d
        return run_finished_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
