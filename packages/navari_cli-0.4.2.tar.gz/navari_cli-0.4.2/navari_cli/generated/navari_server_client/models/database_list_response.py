from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.database_info import DatabaseInfo


T = TypeVar("T", bound="DatabaseListResponse")


@_attrs_define
class DatabaseListResponse:
    """Response containing list of available databases from mcp-sql.

    Attributes:
        databases (list[DatabaseInfo]):
    """

    databases: list[DatabaseInfo]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        databases = []
        for databases_item_data in self.databases:
            databases_item = databases_item_data.to_dict()
            databases.append(databases_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "databases": databases,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.database_info import DatabaseInfo

        d = dict(src_dict)
        databases = []
        _databases = d.pop("databases")
        for databases_item_data in _databases:
            databases_item = DatabaseInfo.from_dict(databases_item_data)

            databases.append(databases_item)

        database_list_response = cls(
            databases=databases,
        )

        database_list_response.additional_properties = d
        return database_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
