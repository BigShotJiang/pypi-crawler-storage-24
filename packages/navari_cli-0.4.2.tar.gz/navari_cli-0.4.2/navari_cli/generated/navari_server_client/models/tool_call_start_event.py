from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ToolCallStartEvent")


@_attrs_define
class ToolCallStartEvent:
    """Event indicating the start of a tool call.

    Attributes:
        tool_call_id (str):
        tool_call_name (str):
        type_ (Literal['TOOL_CALL_START'] | Unset):  Default: 'TOOL_CALL_START'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
        parent_message_id (None | str | Unset):
    """

    tool_call_id: str
    tool_call_name: str
    type_: Literal["TOOL_CALL_START"] | Unset = "TOOL_CALL_START"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    parent_message_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tool_call_id = self.tool_call_id

        tool_call_name = self.tool_call_name

        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        parent_message_id: None | str | Unset
        if isinstance(self.parent_message_id, Unset):
            parent_message_id = UNSET
        else:
            parent_message_id = self.parent_message_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "toolCallId": tool_call_id,
                "toolCallName": tool_call_name,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event
        if parent_message_id is not UNSET:
            field_dict["parentMessageId"] = parent_message_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tool_call_id = d.pop("toolCallId")

        tool_call_name = d.pop("toolCallName")

        type_ = cast(Literal["TOOL_CALL_START"] | Unset, d.pop("type", UNSET))
        if type_ != "TOOL_CALL_START" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'TOOL_CALL_START', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        def _parse_parent_message_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_message_id = _parse_parent_message_id(d.pop("parentMessageId", UNSET))

        tool_call_start_event = cls(
            tool_call_id=tool_call_id,
            tool_call_name=tool_call_name,
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
            parent_message_id=parent_message_id,
        )

        tool_call_start_event.additional_properties = d
        return tool_call_start_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
