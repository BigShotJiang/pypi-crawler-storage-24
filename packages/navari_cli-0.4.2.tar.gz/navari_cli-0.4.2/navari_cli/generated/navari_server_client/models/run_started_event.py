from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.run_agent_input import RunAgentInput


T = TypeVar("T", bound="RunStartedEvent")


@_attrs_define
class RunStartedEvent:
    """Event indicating that a run has started.

    Attributes:
        thread_id (str):
        run_id (str):
        type_ (Literal['RUN_STARTED'] | Unset):  Default: 'RUN_STARTED'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
        parent_run_id (None | str | Unset):
        input_ (None | RunAgentInput | Unset):
    """

    thread_id: str
    run_id: str
    type_: Literal["RUN_STARTED"] | Unset = "RUN_STARTED"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    parent_run_id: None | str | Unset = UNSET
    input_: None | RunAgentInput | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.run_agent_input import RunAgentInput

        thread_id = self.thread_id

        run_id = self.run_id

        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        parent_run_id: None | str | Unset
        if isinstance(self.parent_run_id, Unset):
            parent_run_id = UNSET
        else:
            parent_run_id = self.parent_run_id

        input_: dict[str, Any] | None | Unset
        if isinstance(self.input_, Unset):
            input_ = UNSET
        elif isinstance(self.input_, RunAgentInput):
            input_ = self.input_.to_dict()
        else:
            input_ = self.input_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "threadId": thread_id,
                "runId": run_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event
        if parent_run_id is not UNSET:
            field_dict["parentRunId"] = parent_run_id
        if input_ is not UNSET:
            field_dict["input"] = input_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.run_agent_input import RunAgentInput

        d = dict(src_dict)
        thread_id = d.pop("threadId")

        run_id = d.pop("runId")

        type_ = cast(Literal["RUN_STARTED"] | Unset, d.pop("type", UNSET))
        if type_ != "RUN_STARTED" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'RUN_STARTED', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        def _parse_parent_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_run_id = _parse_parent_run_id(d.pop("parentRunId", UNSET))

        def _parse_input_(data: object) -> None | RunAgentInput | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                input_type_0 = RunAgentInput.from_dict(data)

                return input_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RunAgentInput | Unset, data)

        input_ = _parse_input_(d.pop("input", UNSET))

        run_started_event = cls(
            thread_id=thread_id,
            run_id=run_id,
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
            parent_run_id=parent_run_id,
            input_=input_,
        )

        run_started_event.additional_properties = d
        return run_started_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
