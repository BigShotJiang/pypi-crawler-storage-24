from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.legal_agreement_type import LegalAgreementType

T = TypeVar("T", bound="LegalAgreementResponse")


@_attrs_define
class LegalAgreementResponse:
    """Response model for legal agreement data.

    Attributes:
        id (UUID):
        type_ (LegalAgreementType): Types of legal agreements.
        content (str):
        version (str):
        created_at (datetime.datetime):
    """

    id: UUID
    type_: LegalAgreementType
    content: str
    version: str
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        type_ = self.type_.value

        content = self.content

        version = self.version

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "type": type_,
                "content": content,
                "version": version,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        type_ = LegalAgreementType(d.pop("type"))

        content = d.pop("content")

        version = d.pop("version")

        created_at = isoparse(d.pop("created_at"))

        legal_agreement_response = cls(
            id=id,
            type_=type_,
            content=content,
            version=version,
            created_at=created_at,
        )

        legal_agreement_response.additional_properties = d
        return legal_agreement_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
