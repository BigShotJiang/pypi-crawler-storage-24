from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.conversation_create_metadata_type_0 import ConversationCreateMetadataType0


T = TypeVar("T", bound="ConversationCreate")


@_attrs_define
class ConversationCreate:
    """Request model for creating a new conversation.

    Attributes:
        user_id (str): User ID to associate with the conversation
        title (str | Unset): Title of the conversation Default: 'New Conversation'.
        metadata (ConversationCreateMetadataType0 | None | Unset): Optional metadata for the conversation
    """

    user_id: str
    title: str | Unset = "New Conversation"
    metadata: ConversationCreateMetadataType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.conversation_create_metadata_type_0 import ConversationCreateMetadataType0

        user_id = self.user_id

        title = self.title

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, ConversationCreateMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_id": user_id,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.conversation_create_metadata_type_0 import ConversationCreateMetadataType0

        d = dict(src_dict)
        user_id = d.pop("user_id")

        title = d.pop("title", UNSET)

        def _parse_metadata(data: object) -> ConversationCreateMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = ConversationCreateMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConversationCreateMetadataType0 | None | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        conversation_create = cls(
            user_id=user_id,
            title=title,
            metadata=metadata,
        )

        conversation_create.additional_properties = d
        return conversation_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
