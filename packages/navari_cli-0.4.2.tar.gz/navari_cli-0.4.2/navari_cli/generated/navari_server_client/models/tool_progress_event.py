from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ToolProgressEvent")


@_attrs_define
class ToolProgressEvent:
    """Pydantic AI tool_progress event model.

    Attributes:
        tool_name (str): Name of the tool being executed
        message (str): Progress message
        event_kind (Literal['tool_progress'] | Unset): Event kind Default: 'tool_progress'.
        notification_type (None | str | Unset): Type of notification (status, thinking, code, observation, solution)
        content (None | str | Unset): Additional content (e.g., code, observation text, solution)
        content_format (None | str | Unset): Format of content: 'markdown' or 'text' (default: text)
        timestamp (str | Unset): ISO timestamp
        run_id (None | str | Unset): Run ID if available
    """

    tool_name: str
    message: str
    event_kind: Literal["tool_progress"] | Unset = "tool_progress"
    notification_type: None | str | Unset = UNSET
    content: None | str | Unset = UNSET
    content_format: None | str | Unset = UNSET
    timestamp: str | Unset = UNSET
    run_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tool_name = self.tool_name

        message = self.message

        event_kind = self.event_kind

        notification_type: None | str | Unset
        if isinstance(self.notification_type, Unset):
            notification_type = UNSET
        else:
            notification_type = self.notification_type

        content: None | str | Unset
        if isinstance(self.content, Unset):
            content = UNSET
        else:
            content = self.content

        content_format: None | str | Unset
        if isinstance(self.content_format, Unset):
            content_format = UNSET
        else:
            content_format = self.content_format

        timestamp = self.timestamp

        run_id: None | str | Unset
        if isinstance(self.run_id, Unset):
            run_id = UNSET
        else:
            run_id = self.run_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "tool_name": tool_name,
                "message": message,
            }
        )
        if event_kind is not UNSET:
            field_dict["event_kind"] = event_kind
        if notification_type is not UNSET:
            field_dict["notification_type"] = notification_type
        if content is not UNSET:
            field_dict["content"] = content
        if content_format is not UNSET:
            field_dict["content_format"] = content_format
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if run_id is not UNSET:
            field_dict["run_id"] = run_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tool_name = d.pop("tool_name")

        message = d.pop("message")

        event_kind = cast(Literal["tool_progress"] | Unset, d.pop("event_kind", UNSET))
        if event_kind != "tool_progress" and not isinstance(event_kind, Unset):
            raise ValueError(f"event_kind must match const 'tool_progress', got '{event_kind}'")

        def _parse_notification_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        notification_type = _parse_notification_type(d.pop("notification_type", UNSET))

        def _parse_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content = _parse_content(d.pop("content", UNSET))

        def _parse_content_format(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content_format = _parse_content_format(d.pop("content_format", UNSET))

        timestamp = d.pop("timestamp", UNSET)

        def _parse_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        run_id = _parse_run_id(d.pop("run_id", UNSET))

        tool_progress_event = cls(
            tool_name=tool_name,
            message=message,
            event_kind=event_kind,
            notification_type=notification_type,
            content=content,
            content_format=content_format,
            timestamp=timestamp,
            run_id=run_id,
        )

        tool_progress_event.additional_properties = d
        return tool_progress_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
