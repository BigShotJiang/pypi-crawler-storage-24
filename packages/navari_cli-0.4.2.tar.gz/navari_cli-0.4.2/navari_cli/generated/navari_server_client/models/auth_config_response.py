from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AuthConfigResponse")


@_attrs_define
class AuthConfigResponse:
    """Response model for public auth configuration.

    Returned by the unauthenticated /api/auth/config endpoint
    so CLI and external clients can discover OAuth settings.

        Attributes:
            tenant_id (str):
            client_id (str):
            scopes (list[str]):
            authority (str):
    """

    tenant_id: str
    client_id: str
    scopes: list[str]
    authority: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        client_id = self.client_id

        scopes = self.scopes

        authority = self.authority

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "tenant_id": tenant_id,
                "client_id": client_id,
                "scopes": scopes,
                "authority": authority,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        client_id = d.pop("client_id")

        scopes = cast(list[str], d.pop("scopes"))

        authority = d.pop("authority")

        auth_config_response = cls(
            tenant_id=tenant_id,
            client_id=client_id,
            scopes=scopes,
            authority=authority,
        )

        auth_config_response.additional_properties = d
        return auth_config_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
