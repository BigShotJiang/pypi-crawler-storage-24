from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.function_call import FunctionCall


T = TypeVar("T", bound="ToolCall")


@_attrs_define
class ToolCall:
    """A tool call, modelled after OpenAI tool calls.

    Attributes:
        id (str):
        function (FunctionCall): Name and arguments of a function call.
        type_ (Literal['function'] | Unset):  Default: 'function'.
    """

    id: str
    function: FunctionCall
    type_: Literal["function"] | Unset = "function"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        function = self.function.to_dict()

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "function": function,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.function_call import FunctionCall

        d = dict(src_dict)
        id = d.pop("id")

        function = FunctionCall.from_dict(d.pop("function"))

        type_ = cast(Literal["function"] | Unset, d.pop("type", UNSET))
        if type_ != "function" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'function', got '{type_}'")

        tool_call = cls(
            id=id,
            function=function,
            type_=type_,
        )

        tool_call.additional_properties = d
        return tool_call

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
