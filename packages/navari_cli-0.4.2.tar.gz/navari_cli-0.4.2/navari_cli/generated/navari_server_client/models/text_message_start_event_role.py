from enum import Enum


class TextMessageStartEventRole(str, Enum):
    ASSISTANT = "assistant"
    DEVELOPER = "developer"
    SYSTEM = "system"
    USER = "user"

    def __str__(self) -> str:
        return str(self.value)
