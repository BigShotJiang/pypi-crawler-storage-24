from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.conversation_mode import ConversationMode
from ..types import UNSET, Unset

T = TypeVar("T", bound="UserPreferencesResponse")


@_attrs_define
class UserPreferencesResponse:
    """Response model for user preferences.

    Attributes:
        user_id (str): User ID
        created_at (datetime.datetime): Creation timestamp
        updated_at (datetime.datetime): Last update timestamp
        default_conversation_mode (ConversationMode | None | Unset): Default conversation mode for new conversations
    """

    user_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    default_conversation_mode: ConversationMode | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        default_conversation_mode: None | str | Unset
        if isinstance(self.default_conversation_mode, Unset):
            default_conversation_mode = UNSET
        elif isinstance(self.default_conversation_mode, ConversationMode):
            default_conversation_mode = self.default_conversation_mode.value
        else:
            default_conversation_mode = self.default_conversation_mode

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_id": user_id,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if default_conversation_mode is not UNSET:
            field_dict["default_conversation_mode"] = default_conversation_mode

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("user_id")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_default_conversation_mode(data: object) -> ConversationMode | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                default_conversation_mode_type_0 = ConversationMode(data)

                return default_conversation_mode_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConversationMode | None | Unset, data)

        default_conversation_mode = _parse_default_conversation_mode(d.pop("default_conversation_mode", UNSET))

        user_preferences_response = cls(
            user_id=user_id,
            created_at=created_at,
            updated_at=updated_at,
            default_conversation_mode=default_conversation_mode,
        )

        user_preferences_response.additional_properties = d
        return user_preferences_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
