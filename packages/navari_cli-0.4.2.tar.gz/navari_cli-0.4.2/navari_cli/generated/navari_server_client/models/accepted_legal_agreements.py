from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.accepted_legal_agreement_info import AcceptedLegalAgreementInfo


T = TypeVar("T", bound="AcceptedLegalAgreements")


@_attrs_define
class AcceptedLegalAgreements:
    """Accepted legal agreements grouped by type.

    Attributes:
        terms_and_conditions (AcceptedLegalAgreementInfo | None | Unset):
        privacy_policy (AcceptedLegalAgreementInfo | None | Unset):
    """

    terms_and_conditions: AcceptedLegalAgreementInfo | None | Unset = UNSET
    privacy_policy: AcceptedLegalAgreementInfo | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.accepted_legal_agreement_info import AcceptedLegalAgreementInfo

        terms_and_conditions: dict[str, Any] | None | Unset
        if isinstance(self.terms_and_conditions, Unset):
            terms_and_conditions = UNSET
        elif isinstance(self.terms_and_conditions, AcceptedLegalAgreementInfo):
            terms_and_conditions = self.terms_and_conditions.to_dict()
        else:
            terms_and_conditions = self.terms_and_conditions

        privacy_policy: dict[str, Any] | None | Unset
        if isinstance(self.privacy_policy, Unset):
            privacy_policy = UNSET
        elif isinstance(self.privacy_policy, AcceptedLegalAgreementInfo):
            privacy_policy = self.privacy_policy.to_dict()
        else:
            privacy_policy = self.privacy_policy

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if terms_and_conditions is not UNSET:
            field_dict["terms_and_conditions"] = terms_and_conditions
        if privacy_policy is not UNSET:
            field_dict["privacy_policy"] = privacy_policy

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.accepted_legal_agreement_info import AcceptedLegalAgreementInfo

        d = dict(src_dict)

        def _parse_terms_and_conditions(data: object) -> AcceptedLegalAgreementInfo | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                terms_and_conditions_type_0 = AcceptedLegalAgreementInfo.from_dict(data)

                return terms_and_conditions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AcceptedLegalAgreementInfo | None | Unset, data)

        terms_and_conditions = _parse_terms_and_conditions(d.pop("terms_and_conditions", UNSET))

        def _parse_privacy_policy(data: object) -> AcceptedLegalAgreementInfo | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                privacy_policy_type_0 = AcceptedLegalAgreementInfo.from_dict(data)

                return privacy_policy_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AcceptedLegalAgreementInfo | None | Unset, data)

        privacy_policy = _parse_privacy_policy(d.pop("privacy_policy", UNSET))

        accepted_legal_agreements = cls(
            terms_and_conditions=terms_and_conditions,
            privacy_policy=privacy_policy,
        )

        accepted_legal_agreements.additional_properties = d
        return accepted_legal_agreements

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
