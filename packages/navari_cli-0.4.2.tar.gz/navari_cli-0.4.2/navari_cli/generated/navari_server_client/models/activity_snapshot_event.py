from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ActivitySnapshotEvent")


@_attrs_define
class ActivitySnapshotEvent:
    """Event containing a snapshot of an activity message.

    Attributes:
        message_id (str):
        activity_type (str):
        content (Any):
        type_ (Literal['ACTIVITY_SNAPSHOT'] | Unset):  Default: 'ACTIVITY_SNAPSHOT'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
        replace (bool | Unset):  Default: True.
    """

    message_id: str
    activity_type: str
    content: Any
    type_: Literal["ACTIVITY_SNAPSHOT"] | Unset = "ACTIVITY_SNAPSHOT"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    replace: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        message_id = self.message_id

        activity_type = self.activity_type

        content = self.content

        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        replace = self.replace

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "messageId": message_id,
                "activityType": activity_type,
                "content": content,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event
        if replace is not UNSET:
            field_dict["replace"] = replace

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        message_id = d.pop("messageId")

        activity_type = d.pop("activityType")

        content = d.pop("content")

        type_ = cast(Literal["ACTIVITY_SNAPSHOT"] | Unset, d.pop("type", UNSET))
        if type_ != "ACTIVITY_SNAPSHOT" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'ACTIVITY_SNAPSHOT', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        replace = d.pop("replace", UNSET)

        activity_snapshot_event = cls(
            message_id=message_id,
            activity_type=activity_type,
            content=content,
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
            replace=replace,
        )

        activity_snapshot_event.additional_properties = d
        return activity_snapshot_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
