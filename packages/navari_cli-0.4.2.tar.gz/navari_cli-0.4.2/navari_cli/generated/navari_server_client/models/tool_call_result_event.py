from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ToolCallResultEvent")


@_attrs_define
class ToolCallResultEvent:
    """Event containing the result of a tool call.

    Attributes:
        message_id (str):
        tool_call_id (str):
        content (str):
        type_ (Literal['TOOL_CALL_RESULT'] | Unset):  Default: 'TOOL_CALL_RESULT'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
        role (Literal['tool'] | None | Unset):
    """

    message_id: str
    tool_call_id: str
    content: str
    type_: Literal["TOOL_CALL_RESULT"] | Unset = "TOOL_CALL_RESULT"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    role: Literal["tool"] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        message_id = self.message_id

        tool_call_id = self.tool_call_id

        content = self.content

        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        role: Literal["tool"] | None | Unset
        if isinstance(self.role, Unset):
            role = UNSET
        else:
            role = self.role

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "messageId": message_id,
                "toolCallId": tool_call_id,
                "content": content,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event
        if role is not UNSET:
            field_dict["role"] = role

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        message_id = d.pop("messageId")

        tool_call_id = d.pop("toolCallId")

        content = d.pop("content")

        type_ = cast(Literal["TOOL_CALL_RESULT"] | Unset, d.pop("type", UNSET))
        if type_ != "TOOL_CALL_RESULT" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'TOOL_CALL_RESULT', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        def _parse_role(data: object) -> Literal["tool"] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            role_type_0 = cast(Literal["tool"], data)
            if role_type_0 != "tool":
                raise ValueError(f"role_type_0 must match const 'tool', got '{role_type_0}'")
            return role_type_0
            return cast(Literal["tool"] | None | Unset, data)

        role = _parse_role(d.pop("role", UNSET))

        tool_call_result_event = cls(
            message_id=message_id,
            tool_call_id=tool_call_id,
            content=content,
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
            role=role,
        )

        tool_call_result_event.additional_properties = d
        return tool_call_result_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
