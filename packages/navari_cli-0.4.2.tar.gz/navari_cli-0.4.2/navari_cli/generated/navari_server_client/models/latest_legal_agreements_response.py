from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.latest_legal_agreements_response_agreements import LatestLegalAgreementsResponseAgreements


T = TypeVar("T", bound="LatestLegalAgreementsResponse")


@_attrs_define
class LatestLegalAgreementsResponse:
    """Response model for latest legal agreements by type.

    Attributes:
        agreements (LatestLegalAgreementsResponseAgreements):
    """

    agreements: LatestLegalAgreementsResponseAgreements
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agreements = self.agreements.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agreements": agreements,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.latest_legal_agreements_response_agreements import LatestLegalAgreementsResponseAgreements

        d = dict(src_dict)
        agreements = LatestLegalAgreementsResponseAgreements.from_dict(d.pop("agreements"))

        latest_legal_agreements_response = cls(
            agreements=agreements,
        )

        latest_legal_agreements_response.additional_properties = d
        return latest_legal_agreements_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
