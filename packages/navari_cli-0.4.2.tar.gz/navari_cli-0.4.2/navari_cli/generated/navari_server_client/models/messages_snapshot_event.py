from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.activity_message import ActivityMessage
    from ..models.assistant_message import AssistantMessage
    from ..models.developer_message import DeveloperMessage
    from ..models.system_message import SystemMessage
    from ..models.tool_message import ToolMessage
    from ..models.user_message import UserMessage


T = TypeVar("T", bound="MessagesSnapshotEvent")


@_attrs_define
class MessagesSnapshotEvent:
    """Event containing a snapshot of the messages.

    Attributes:
        messages (list[ActivityMessage | AssistantMessage | DeveloperMessage | SystemMessage | ToolMessage |
            UserMessage]):
        type_ (Literal['MESSAGES_SNAPSHOT'] | Unset):  Default: 'MESSAGES_SNAPSHOT'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
    """

    messages: list[ActivityMessage | AssistantMessage | DeveloperMessage | SystemMessage | ToolMessage | UserMessage]
    type_: Literal["MESSAGES_SNAPSHOT"] | Unset = "MESSAGES_SNAPSHOT"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.assistant_message import AssistantMessage
        from ..models.developer_message import DeveloperMessage
        from ..models.system_message import SystemMessage
        from ..models.tool_message import ToolMessage
        from ..models.user_message import UserMessage

        messages = []
        for messages_item_data in self.messages:
            messages_item: dict[str, Any]
            if isinstance(messages_item_data, DeveloperMessage):
                messages_item = messages_item_data.to_dict()
            elif isinstance(messages_item_data, SystemMessage):
                messages_item = messages_item_data.to_dict()
            elif isinstance(messages_item_data, AssistantMessage):
                messages_item = messages_item_data.to_dict()
            elif isinstance(messages_item_data, UserMessage):
                messages_item = messages_item_data.to_dict()
            elif isinstance(messages_item_data, ToolMessage):
                messages_item = messages_item_data.to_dict()
            else:
                messages_item = messages_item_data.to_dict()

            messages.append(messages_item)

        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "messages": messages,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.activity_message import ActivityMessage
        from ..models.assistant_message import AssistantMessage
        from ..models.developer_message import DeveloperMessage
        from ..models.system_message import SystemMessage
        from ..models.tool_message import ToolMessage
        from ..models.user_message import UserMessage

        d = dict(src_dict)
        messages = []
        _messages = d.pop("messages")
        for messages_item_data in _messages:

            def _parse_messages_item(
                data: object,
            ) -> ActivityMessage | AssistantMessage | DeveloperMessage | SystemMessage | ToolMessage | UserMessage:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    messages_item_type_0 = DeveloperMessage.from_dict(data)

                    return messages_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    messages_item_type_1 = SystemMessage.from_dict(data)

                    return messages_item_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    messages_item_type_2 = AssistantMessage.from_dict(data)

                    return messages_item_type_2
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    messages_item_type_3 = UserMessage.from_dict(data)

                    return messages_item_type_3
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    messages_item_type_4 = ToolMessage.from_dict(data)

                    return messages_item_type_4
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                messages_item_type_5 = ActivityMessage.from_dict(data)

                return messages_item_type_5

            messages_item = _parse_messages_item(messages_item_data)

            messages.append(messages_item)

        type_ = cast(Literal["MESSAGES_SNAPSHOT"] | Unset, d.pop("type", UNSET))
        if type_ != "MESSAGES_SNAPSHOT" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'MESSAGES_SNAPSHOT', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        messages_snapshot_event = cls(
            messages=messages,
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
        )

        messages_snapshot_event.additional_properties = d
        return messages_snapshot_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
