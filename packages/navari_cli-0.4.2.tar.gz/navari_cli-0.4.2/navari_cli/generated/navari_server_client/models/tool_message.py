from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ToolMessage")


@_attrs_define
class ToolMessage:
    """A tool result message.

    Attributes:
        id (str):
        content (str):
        tool_call_id (str):
        role (Literal['tool'] | Unset):  Default: 'tool'.
        error (None | str | Unset):
    """

    id: str
    content: str
    tool_call_id: str
    role: Literal["tool"] | Unset = "tool"
    error: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        content = self.content

        tool_call_id = self.tool_call_id

        role = self.role

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "content": content,
                "toolCallId": tool_call_id,
            }
        )
        if role is not UNSET:
            field_dict["role"] = role
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        content = d.pop("content")

        tool_call_id = d.pop("toolCallId")

        role = cast(Literal["tool"] | Unset, d.pop("role", UNSET))
        if role != "tool" and not isinstance(role, Unset):
            raise ValueError(f"role must match const 'tool', got '{role}'")

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        tool_message = cls(
            id=id,
            content=content,
            tool_call_id=tool_call_id,
            role=role,
            error=error,
        )

        tool_message.additional_properties = d
        return tool_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
