from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.text_message_chunk_event_role_type_0 import TextMessageChunkEventRoleType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="TextMessageChunkEvent")


@_attrs_define
class TextMessageChunkEvent:
    """Event containing a chunk of text message content.

    Attributes:
        type_ (Literal['TEXT_MESSAGE_CHUNK'] | Unset):  Default: 'TEXT_MESSAGE_CHUNK'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
        message_id (None | str | Unset):
        role (None | TextMessageChunkEventRoleType0 | Unset):
        delta (None | str | Unset):
    """

    type_: Literal["TEXT_MESSAGE_CHUNK"] | Unset = "TEXT_MESSAGE_CHUNK"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    message_id: None | str | Unset = UNSET
    role: None | TextMessageChunkEventRoleType0 | Unset = UNSET
    delta: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        message_id: None | str | Unset
        if isinstance(self.message_id, Unset):
            message_id = UNSET
        else:
            message_id = self.message_id

        role: None | str | Unset
        if isinstance(self.role, Unset):
            role = UNSET
        elif isinstance(self.role, TextMessageChunkEventRoleType0):
            role = self.role.value
        else:
            role = self.role

        delta: None | str | Unset
        if isinstance(self.delta, Unset):
            delta = UNSET
        else:
            delta = self.delta

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event
        if message_id is not UNSET:
            field_dict["messageId"] = message_id
        if role is not UNSET:
            field_dict["role"] = role
        if delta is not UNSET:
            field_dict["delta"] = delta

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = cast(Literal["TEXT_MESSAGE_CHUNK"] | Unset, d.pop("type", UNSET))
        if type_ != "TEXT_MESSAGE_CHUNK" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'TEXT_MESSAGE_CHUNK', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        def _parse_message_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message_id = _parse_message_id(d.pop("messageId", UNSET))

        def _parse_role(data: object) -> None | TextMessageChunkEventRoleType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                role_type_0 = TextMessageChunkEventRoleType0(data)

                return role_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextMessageChunkEventRoleType0 | Unset, data)

        role = _parse_role(d.pop("role", UNSET))

        def _parse_delta(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        delta = _parse_delta(d.pop("delta", UNSET))

        text_message_chunk_event = cls(
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
            message_id=message_id,
            role=role,
            delta=delta,
        )

        text_message_chunk_event.additional_properties = d
        return text_message_chunk_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
