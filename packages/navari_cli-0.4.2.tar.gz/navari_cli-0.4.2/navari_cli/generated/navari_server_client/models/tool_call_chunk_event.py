from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ToolCallChunkEvent")


@_attrs_define
class ToolCallChunkEvent:
    """Event containing a chunk of tool call content.

    Attributes:
        type_ (Literal['TOOL_CALL_CHUNK'] | Unset):  Default: 'TOOL_CALL_CHUNK'.
        timestamp (int | None | Unset):
        raw_event (Any | None | Unset):
        tool_call_id (None | str | Unset):
        tool_call_name (None | str | Unset):
        parent_message_id (None | str | Unset):
        delta (None | str | Unset):
    """

    type_: Literal["TOOL_CALL_CHUNK"] | Unset = "TOOL_CALL_CHUNK"
    timestamp: int | None | Unset = UNSET
    raw_event: Any | None | Unset = UNSET
    tool_call_id: None | str | Unset = UNSET
    tool_call_name: None | str | Unset = UNSET
    parent_message_id: None | str | Unset = UNSET
    delta: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        timestamp: int | None | Unset
        if isinstance(self.timestamp, Unset):
            timestamp = UNSET
        else:
            timestamp = self.timestamp

        raw_event: Any | None | Unset
        if isinstance(self.raw_event, Unset):
            raw_event = UNSET
        else:
            raw_event = self.raw_event

        tool_call_id: None | str | Unset
        if isinstance(self.tool_call_id, Unset):
            tool_call_id = UNSET
        else:
            tool_call_id = self.tool_call_id

        tool_call_name: None | str | Unset
        if isinstance(self.tool_call_name, Unset):
            tool_call_name = UNSET
        else:
            tool_call_name = self.tool_call_name

        parent_message_id: None | str | Unset
        if isinstance(self.parent_message_id, Unset):
            parent_message_id = UNSET
        else:
            parent_message_id = self.parent_message_id

        delta: None | str | Unset
        if isinstance(self.delta, Unset):
            delta = UNSET
        else:
            delta = self.delta

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if raw_event is not UNSET:
            field_dict["rawEvent"] = raw_event
        if tool_call_id is not UNSET:
            field_dict["toolCallId"] = tool_call_id
        if tool_call_name is not UNSET:
            field_dict["toolCallName"] = tool_call_name
        if parent_message_id is not UNSET:
            field_dict["parentMessageId"] = parent_message_id
        if delta is not UNSET:
            field_dict["delta"] = delta

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = cast(Literal["TOOL_CALL_CHUNK"] | Unset, d.pop("type", UNSET))
        if type_ != "TOOL_CALL_CHUNK" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'TOOL_CALL_CHUNK', got '{type_}'")

        def _parse_timestamp(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timestamp = _parse_timestamp(d.pop("timestamp", UNSET))

        def _parse_raw_event(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        raw_event = _parse_raw_event(d.pop("rawEvent", UNSET))

        def _parse_tool_call_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tool_call_id = _parse_tool_call_id(d.pop("toolCallId", UNSET))

        def _parse_tool_call_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tool_call_name = _parse_tool_call_name(d.pop("toolCallName", UNSET))

        def _parse_parent_message_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_message_id = _parse_parent_message_id(d.pop("parentMessageId", UNSET))

        def _parse_delta(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        delta = _parse_delta(d.pop("delta", UNSET))

        tool_call_chunk_event = cls(
            type_=type_,
            timestamp=timestamp,
            raw_event=raw_event,
            tool_call_id=tool_call_id,
            tool_call_name=tool_call_name,
            parent_message_id=parent_message_id,
            delta=delta,
        )

        tool_call_chunk_event.additional_properties = d
        return tool_call_chunk_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
