"""Repository-specific observability matchers."""
