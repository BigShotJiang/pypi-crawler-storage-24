"""Reusable matcher helpers."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import re
from dataclasses import dataclass
from functools import partial

from jps_observability_utils.models import AuditFinding
from jps_observability_utils.utils.file_utils import ScannedFile
from jps_observability_utils.utils.text_utils import compact_snippet


@dataclass(frozen=True, slots=True)
class Rule:
    """A static evidence rule."""

    technology: str
    category: str
    title: str
    evidence_type: str
    pattern: str
    interpretation: str
    recommended_action: str
    confidence: str
    file_names: tuple[str, ...] = ()
    path_suffixes: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CompiledRule:
    """Rule paired with a compiled regex."""

    rule: Rule
    pattern: re.Pattern[str]


def rule_applies(rule: Rule, scanned_file: ScannedFile) -> bool:
    """Return True when a rule should be evaluated against a file."""
    if rule.file_names and scanned_file.absolute_path.name.lower() not in rule.file_names:
        return False
    if rule.path_suffixes:
        suffix = scanned_file.absolute_path.suffix.lower()
        file_name = scanned_file.absolute_path.name.lower()
        if suffix not in rule.path_suffixes and file_name not in rule.path_suffixes:
            return False
    return True


def finding_from_match(rule: Rule, scanned_file: ScannedFile, match: re.Match[str]) -> AuditFinding:
    """Build a finding object from a regex match."""
    matched_text = compact_snippet(match.group(0))
    line_number = scanned_file.content.count("\n", 0, match.start()) + 1
    return AuditFinding(
        title=rule.title,
        technology=rule.technology,
        category=rule.category,
        confidence=rule.confidence,
        evidence_type=rule.evidence_type,
        file_path=scanned_file.relative_path,
        line_number=line_number,
        match_text=matched_text,
        interpretation=rule.interpretation,
        recommended_action=rule.recommended_action,
    )


def _compile_rules(rules: list[Rule]) -> list[CompiledRule]:
    """Compile all rule regexes once per scan."""
    return [CompiledRule(rule=rule, pattern=re.compile(rule.pattern, re.MULTILINE)) for rule in rules]


def _match_file(scanned_file: ScannedFile, compiled_rules: list[CompiledRule]) -> list[AuditFinding]:
    """Evaluate all rules for a single file."""
    findings: list[AuditFinding] = []
    seen_keys: set[tuple[str, str, int | None, str]] = set()
    for compiled_rule in compiled_rules:
        rule = compiled_rule.rule
        if not rule_applies(rule, scanned_file):
            continue
        match = compiled_rule.pattern.search(scanned_file.content)
        if not match:
            continue
        finding = finding_from_match(rule, scanned_file, match)
        key = (finding.title, finding.file_path, finding.line_number, finding.match_text)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        findings.append(finding)
    return findings


def apply_rules(
    scanned_files: list[ScannedFile],
    rules: list[Rule],
    max_workers: int | None = None,
) -> list[AuditFinding]:
    """Evaluate regex rules across scanned files."""
    compiled_rules = _compile_rules(rules)
    match_file = partial(_match_file, compiled_rules=compiled_rules)
    if max_workers == 1:
        matched_batches = [match_file(scanned_file) for scanned_file in scanned_files]
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            matched_batches = list(executor.map(match_file, scanned_files))

    findings: list[AuditFinding] = []
    for batch in matched_batches:
        findings.extend(batch)
    return findings
