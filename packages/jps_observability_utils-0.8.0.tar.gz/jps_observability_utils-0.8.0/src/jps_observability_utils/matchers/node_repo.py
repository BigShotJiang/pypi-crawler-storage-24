"""Detection rules for Node.js repositories."""

from __future__ import annotations

from jps_observability_utils.matchers.common import Rule, apply_rules
from jps_observability_utils.models import AuditFinding
from jps_observability_utils.utils.file_utils import ScannedFile

NODE_RULES = [
    Rule(
        technology="OpenTelemetry",
        category="Telemetry Instrumentation",
        title="OpenTelemetry package or import detected",
        evidence_type="dependency/import",
        pattern=r"@opentelemetry/[a-z0-9\-_/]+|from\s+['\"]@opentelemetry/|require\(['\"]@opentelemetry/",
        interpretation="The repository contains static evidence consistent with Node.js OpenTelemetry package usage.",
        recommended_action="Confirm whether SDK startup occurs in the production entrypoint and whether exporters are configured per environment.",
        confidence="Medium",
        path_suffixes=(".json", ".js", ".ts", ".tsx", ".jsx", ".yml", ".yaml"),
    ),
    Rule(
        technology="OpenTelemetry",
        category="Telemetry Instrumentation",
        title="Node OpenTelemetry bootstrap pattern detected",
        evidence_type="initialization",
        pattern=r"NodeSDK|getNodeAutoInstrumentations|--require\s+.*tracing|--import\s+.*tracing",
        interpretation="The repository contains stronger evidence of Node.js OpenTelemetry bootstrap or auto-instrumentation setup.",
        recommended_action="Review startup flags and initialization ordering to verify instrumentation occurs before application modules load.",
        confidence="High",
        path_suffixes=(".js", ".ts", ".json", ".sh", ".env", ".yaml", ".yml"),
    ),
    Rule(
        technology="Prometheus",
        category="Monitoring and Metrics",
        title="Prometheus metrics evidence detected",
        evidence_type="metrics instrumentation",
        pattern=r"prom-client|collectDefaultMetrics|['\"]/metrics['\"]",
        interpretation="The repository contains evidence consistent with Prometheus metrics instrumentation or endpoint exposure.",
        recommended_action="Verify how metrics are exposed and whether scrape jobs are configured in deployment environments.",
        confidence="Medium",
        path_suffixes=(".js", ".ts", ".json", ".yaml", ".yml"),
    ),
    Rule(
        technology="Datadog",
        category="Observability Platforms",
        title="Datadog integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"\bdd-trace\b|\bDATADOG\b|\bDD_(SERVICE|ENV|VERSION|AGENT_HOST|TRACE_[A-Z0-9_]+|LOGS_[A-Z0-9_]+|PROFILING_[A-Z0-9_]+|RUNTIME_METRICS_[A-Z0-9_]+)\b",
        interpretation="The repository contains evidence consistent with Datadog tracing or related telemetry configuration.",
        recommended_action="Check preload behavior, environment variables, and service metadata to confirm intended Datadog coverage.",
        confidence="Medium",
        path_suffixes=(".js", ".ts", ".json", ".yaml", ".yml", ".env", ".sh"),
    ),
    Rule(
        technology="New Relic",
        category="Observability Platforms",
        title="New Relic integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"newrelic|NEW_RELIC",
        interpretation="The repository contains evidence consistent with New Relic instrumentation or configuration.",
        recommended_action="Confirm agent bootstrap timing and environment configuration for the target runtime.",
        confidence="Medium",
        path_suffixes=(".js", ".ts", ".json", ".yaml", ".yml", ".env", ".sh"),
    ),
    Rule(
        technology="Sentry",
        category="Observability Platforms",
        title="Sentry integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"@sentry/node|Sentry\.init|SENTRY_DSN",
        interpretation="The repository contains evidence consistent with Sentry error or performance monitoring integration.",
        recommended_action="Verify DSN configuration, release tagging, and whether tracing or profiling is intentionally enabled.",
        confidence="Medium",
        path_suffixes=(".js", ".ts", ".json", ".yaml", ".yml", ".env"),
    ),
    Rule(
        technology="Elastic APM",
        category="Observability Platforms",
        title="Elastic APM integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"elastic-apm-node|ELASTIC_APM",
        interpretation="The repository contains evidence consistent with Elastic APM instrumentation or configuration.",
        recommended_action="Confirm startup order and environment-specific Elastic APM settings before treating the integration as active.",
        confidence="Medium",
        path_suffixes=(".js", ".ts", ".json", ".yaml", ".yml", ".env"),
    ),
    Rule(
        technology="OTLP / Collector",
        category="Pipeline and Export Configuration",
        title="OTLP or collector configuration evidence detected",
        evidence_type="export configuration",
        pattern=r"\bOTEL_[A-Z0-9_]+\b|\botlp\b|\botelcol\b|^\s*(receivers|exporters):",
        interpretation="The repository contains environment variables or config content consistent with OTLP or collector-based export.",
        recommended_action="Inspect deployment manifests and bootstrap files to identify actual telemetry destinations.",
        confidence="High",
        path_suffixes=(".js", ".ts", ".json", ".yaml", ".yml", ".env", ".sh"),
    ),
    Rule(
        technology="Structured Logging",
        category="Logging",
        title="Structured logging evidence detected",
        evidence_type="logging configuration",
        pattern=r"\bpino\b|\bwinston\b|\btraceId\b|\brequestId\b|\bcorrelationId\b|logger\.(info|warn|error|debug)\s*\(\s*\{",
        interpretation="The repository contains evidence consistent with structured logging or correlation identifiers relevant to observability.",
        recommended_action="Review log schema, request correlation propagation, and downstream ingestion assumptions.",
        confidence="Low",
        path_suffixes=(".js", ".ts", ".json", ".yaml", ".yml"),
    ),
]


def find_node_evidence(
    scanned_files: list[ScannedFile],
    max_workers: int | None = None,
) -> list[AuditFinding]:
    """Return Node.js-specific observability findings."""
    return apply_rules(scanned_files, NODE_RULES, max_workers=max_workers)
