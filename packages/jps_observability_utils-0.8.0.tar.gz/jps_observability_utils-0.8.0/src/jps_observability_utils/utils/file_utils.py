"""Filesystem helpers used by repository scanners."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from fnmatch import fnmatch
from functools import partial
from pathlib import Path

from jps_observability_utils.constants import DEFAULT_IGNORE_DIRS, DEFAULT_TEXT_EXTENSIONS


@dataclass(slots=True)
class ScannedFile:
    """A safely loaded repository file."""

    relative_path: str
    absolute_path: Path
    content: str


@dataclass(slots=True)
class FileLoadResult:
    """Outcome of attempting to load a repository file."""

    scanned_file: ScannedFile | None = None
    unreadable_path: str | None = None


def should_ignore(relative_path: str, ignore_patterns: list[str]) -> bool:
    """Return True when a path matches any ignore pattern."""
    if not ignore_patterns:
        return False
    return any(fnmatch(relative_path, pattern) or fnmatch(Path(relative_path).name, pattern) for pattern in ignore_patterns)


def is_probably_text_file(path: Path) -> bool:
    """Use filename heuristics to decide whether a file should be read as text."""
    if path.suffix.lower() in DEFAULT_TEXT_EXTENSIONS:
        return True
    return path.name.lower() in {
        "dockerfile",
        "makefile",
        "jenkinsfile",
        ".env",
        "procfile",
    }


def _read_text_file(repo_path: Path, path: Path) -> FileLoadResult:
    """Read a single repository file safely."""
    relative_path = path.relative_to(repo_path).as_posix()
    try:
        content = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return FileLoadResult(unreadable_path=relative_path)

    return FileLoadResult(
        scanned_file=ScannedFile(relative_path=relative_path, absolute_path=path, content=content)
    )


def walk_repository(
    repo_path: Path,
    ignore_patterns: list[str] | None = None,
    max_workers: int | None = None,
) -> tuple[list[ScannedFile], list[str], list[str]]:
    """Recursively collect readable text files from a repository."""
    patterns = ignore_patterns or []
    ignored_paths: list[str] = []
    candidate_paths: list[Path] = []

    for path in sorted(repo_path.rglob("*")):
        if path.is_dir():
            continue

        relative_path = path.relative_to(repo_path).as_posix()
        parts = set(path.relative_to(repo_path).parts)
        if DEFAULT_IGNORE_DIRS.intersection(parts):
            ignored_paths.append(relative_path)
            continue
        if should_ignore(relative_path, patterns):
            ignored_paths.append(relative_path)
            continue
        if not is_probably_text_file(path):
            continue

        candidate_paths.append(path)

    read_file = partial(_read_text_file, repo_path)
    if max_workers == 1:
        load_results = [read_file(path) for path in candidate_paths]
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            load_results = list(executor.map(read_file, candidate_paths))

    scanned_files = [result.scanned_file for result in load_results if result.scanned_file is not None]
    unreadable_files = [result.unreadable_path for result in load_results if result.unreadable_path is not None]

    return scanned_files, sorted(set(ignored_paths)), sorted(set(unreadable_files))
