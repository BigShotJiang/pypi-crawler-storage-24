"""Deterministic finding ordering and identifier assignment."""

from __future__ import annotations

from jps_observability_utils.constants import CATEGORY_ORDER, LANGUAGE_PREFIX
from jps_observability_utils.models import AuditFinding


def sort_findings(findings: list[AuditFinding]) -> list[AuditFinding]:
    """Return findings in deterministic order."""
    category_index = {category: idx for idx, category in enumerate(CATEGORY_ORDER)}
    return sorted(
        findings,
        key=lambda finding: (
            category_index.get(finding.category, len(CATEGORY_ORDER)),
            finding.technology.lower(),
            finding.file_path,
            finding.line_number if finding.line_number is not None else 0,
            finding.title.lower(),
            finding.match_text.lower(),
        ),
    )


def assign_finding_ids(findings: list[AuditFinding], language_target: str) -> list[AuditFinding]:
    """Assign stable sequential finding IDs using a language-specific prefix."""
    prefix = LANGUAGE_PREFIX[language_target]
    sorted_findings = sort_findings(findings)
    for index, finding in enumerate(sorted_findings, start=1):
        finding.finding_id = f"{prefix}-{index:03d}"
    return sorted_findings
