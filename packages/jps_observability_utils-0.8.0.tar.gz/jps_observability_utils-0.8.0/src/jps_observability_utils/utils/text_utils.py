"""Text parsing helpers."""

from __future__ import annotations

import re


def find_line_number(content: str, match_text: str) -> int | None:
    """Locate the line number for a matched snippet."""
    if not match_text:
        return None
    index = content.find(match_text)
    if index < 0:
        return None
    return content.count("\n", 0, index) + 1


def first_regex_match(pattern: str, content: str) -> tuple[str, int | None]:
    """Return the first regex match and its line number."""
    compiled = re.compile(pattern, re.MULTILINE)
    match = compiled.search(content)
    if not match:
        return "", None
    text = match.group(0).strip()
    line = content.count("\n", 0, match.start()) + 1
    return text, line


def compact_snippet(text: str, limit: int = 160) -> str:
    """Normalize whitespace and limit snippet length."""
    snippet = " ".join(text.strip().split())
    if len(snippet) <= limit:
        return snippet
    return f"{snippet[: limit - 3]}..."
