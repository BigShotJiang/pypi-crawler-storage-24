"""Render audit reports to Markdown and JSON."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

from jps_observability_utils.constants import CATEGORY_ORDER, METHODOLOGY_PATTERNS
from jps_observability_utils.models import AuditReport


def build_report_paths(
    output_dir: Path,
    language_target: str,
    repository_name: str,
    timestamp: str,
) -> dict[str, Path]:
    """Build deterministic output paths for report artifacts."""
    base_name = f"observability_audit_{language_target}_{repository_name}_{timestamp}"
    return {
        "markdown": output_dir / f"{base_name}.md",
        "json": output_dir / f"{base_name}.json",
        "trace_matrix": output_dir / f"{base_name}_trace_matrix.csv",
    }


def _build_findings_summary_rows(report: AuditReport) -> list[str]:
    rows = ["| Category | Findings |", "| --- | ---: |"]
    counts: dict[str, int] = defaultdict(int)
    for finding in report.findings:
        counts[finding.category] += 1
    for category in CATEGORY_ORDER:
        rows.append(f"| {category} | {counts.get(category, 0)} |")
    return rows


def render_markdown(report: AuditReport, ignore_patterns: list[str]) -> str:
    """Return the report rendered as Markdown."""
    lines: list[str] = []
    lines.append("# Observability Audit Report")
    lines.append("")
    lines.append("## 1. Executive Summary")
    lines.append("")
    lines.append(f"- Repository path: `{report.repository_path}`")
    lines.append(f"- Repository name: `{report.repository_name}`")
    lines.append(f"- Audit language target: `{report.language_target}`")
    lines.append(f"- Scan timestamp: `{report.scan_timestamp}`")
    lines.append(f"- Total findings count: `{len(report.findings)}`")
    lines.append(
        f"- Findings by confidence level: `{report.summary['findings_by_confidence'] or {'High': 0, 'Medium': 0, 'Low': 0}}`"
    )
    lines.append(
        f"- Major technologies detected: `{', '.join(report.summary['major_technologies_detected']) or 'None detected'}`"
    )
    lines.append("- Notable caveats: static, heuristic evidence only; no runtime certainty is claimed.")
    lines.append("")
    lines.append("## 2. Scope")
    lines.append("")
    lines.append(f"- Audited repository path: `{report.repository_path}`")
    lines.append(f"- Scan type: `static {report.language_target} repository audit`")
    lines.append(f"- Relevant exclusions or ignore patterns: `{ignore_patterns or ['built-in defaults only']}`")
    lines.append(f"- Scanned file count: `{report.files_scanned}`")
    lines.append("")
    lines.append("## 3. Methodology")
    lines.append("")
    lines.append("- Evidence categories evaluated:")
    for pattern in METHODOLOGY_PATTERNS:
        lines.append(f"  - {pattern}")
    lines.append("- Confidence model explanation: High indicates strong configuration or initialization evidence, Medium indicates meaningful partial evidence, and Low indicates weaker supporting indicators.")
    lines.append("- Limitations of static analysis:")
    for limitation in report.limitations:
        lines.append(f"  - {limitation}")
    lines.append("")
    lines.append("## 4. Findings Summary")
    lines.append("")
    lines.extend(_build_findings_summary_rows(report))
    lines.append("")
    lines.append("## 5. Detailed Findings")
    lines.append("")

    if not report.findings:
        lines.append("No detectable evidence of the targeted observability-related technologies was found in the scanned repository contents.")
        lines.append("")
    else:
        grouped = defaultdict(list)
        for finding in report.findings:
            grouped[finding.category].append(finding)

        category_number = 1
        for category in CATEGORY_ORDER:
            findings = grouped.get(category, [])
            if not findings:
                continue
            lines.append(f"### 5.{category_number} {category}")
            lines.append("")
            for finding_number, finding in enumerate(findings, start=1):
                heading = f"#### 5.{category_number}.{finding_number} {finding.finding_id}: {finding.title}"
                lines.append(heading)
                lines.append("")
                lines.append(f"- Finding ID: `{finding.finding_id}`")
                lines.append(f"- Title: `{finding.title}`")
                lines.append(f"- Category: `{finding.category}`")
                lines.append(f"- Confidence: `{finding.confidence}`")
                lines.append(f"- Evidence type: `{finding.evidence_type}`")
                lines.append(f"- Evidence summary: `{finding.match_text or finding.title}`")
                lines.append(f"- File path: `{finding.file_path}`")
                lines.append(f"- Line number: `{finding.line_number if finding.line_number is not None else 'N/A'}`")
                lines.append(f"- Interpretation: {finding.interpretation}")
                lines.append(f"- Recommended follow-up or remediation action: {finding.recommended_action}")
                lines.append("")
            category_number += 1

    lines.append("## 6. Gaps and Follow-Up Recommendations")
    lines.append("")
    if report.findings:
        lines.append("- Review detected technologies against runtime bootstrap paths and deployment configuration.")
        lines.append("- Validate whether exporters, collectors, and metrics endpoints are active in non-local environments.")
        lines.append("- Track each finding in downstream remediation or verification work as needed.")
    else:
        lines.append("- No detectable evidence was found; confirm whether observability is managed outside the repository or absent.")
        lines.append("- Consider validating deployment manifests, platform configuration, or runtime-managed agents separately.")
    lines.append("")
    lines.append("## 7. Traceability Matrix")
    lines.append("")
    lines.append("| Finding ID | Report section reference | Category | Evidence summary | File location | Recommended action | Jira reference |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- |")
    for row in report.trace_matrix:
        lines.append(
            f"| {row.finding_id} | {row.section_reference} | {row.category} | {row.evidence_summary} | {row.file_path}:{row.line_number or 'N/A'} | {row.recommended_action} |  |"
        )
    if not report.trace_matrix:
        lines.append("| None | N/A | N/A | No findings generated | N/A | N/A |  |")
    lines.append("")
    lines.append("## 8. Appendix")
    lines.append("")
    lines.append(f"- Files scanned: `{report.scanned_files}`")
    lines.append(f"- Ignored paths: `{report.ignored_paths}`")
    lines.append(f"- Patterns evaluated: `{METHODOLOGY_PATTERNS}`")
    lines.append(f"- Raw evidence index: `{[finding.match_text for finding in report.findings]}`")
    lines.append("")
    return "\n".join(lines)


def write_markdown(report: AuditReport, output_path: Path, ignore_patterns: list[str]) -> Path:
    """Write a Markdown report to disk."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(render_markdown(report, ignore_patterns), encoding="utf-8")
    return output_path


def write_json(report: AuditReport, output_path: Path) -> Path:
    """Write a JSON report to disk."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    return output_path
