"""Core data models for audit generation."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class AuditFinding:
    """Evidence-based finding generated during a repository audit."""

    finding_id: str = ""
    title: str = ""
    technology: str = ""
    category: str = ""
    confidence: str = ""
    evidence_type: str = ""
    file_path: str = ""
    line_number: int | None = None
    match_text: str = ""
    interpretation: str = ""
    recommended_action: str = ""
    section_reference: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation."""
        return asdict(self)


@dataclass(slots=True)
class ScanStats:
    """Summary statistics about the repository scan."""

    files_scanned: int = 0
    ignored_paths: list[str] = field(default_factory=list)
    unreadable_files: list[str] = field(default_factory=list)
    findings_by_confidence: dict[str, int] = field(default_factory=dict)
    findings_by_category: dict[str, int] = field(default_factory=dict)
    technologies_detected: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation."""
        return asdict(self)


@dataclass(slots=True)
class TraceMatrixRow:
    """Tabular representation of a finding for CSV export."""

    finding_id: str
    section_reference: str
    title: str
    category: str
    technology: str
    confidence: str
    evidence_type: str
    evidence_summary: str
    file_path: str
    line_number: int | None
    recommended_action: str
    jira_ticket: str = ""
    status: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation."""
        return asdict(self)


@dataclass(slots=True)
class AuditReport:
    """Complete audit output model."""

    report_type: str
    language_target: str
    repository_name: str
    repository_path: str
    scan_timestamp: str
    tool_version: str
    files_scanned: int
    ignored_paths: list[str]
    findings: list[AuditFinding]
    summary: dict[str, Any]
    limitations: list[str]
    report_files: dict[str, str]
    trace_matrix: list[TraceMatrixRow] = field(default_factory=list)
    unreadable_files: list[str] = field(default_factory=list)
    scanned_files: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation."""
        return {
            "report_type": self.report_type,
            "language_target": self.language_target,
            "repository_name": self.repository_name,
            "repository_path": self.repository_path,
            "scan_timestamp": self.scan_timestamp,
            "tool_version": self.tool_version,
            "files_scanned": self.files_scanned,
            "ignored_paths": self.ignored_paths,
            "findings": [finding.to_dict() for finding in self.findings],
            "summary": self.summary,
            "limitations": self.limitations,
            "report_files": self.report_files,
            "trace_matrix": [row.to_dict() for row in self.trace_matrix],
            "unreadable_files": self.unreadable_files,
            "scanned_files": self.scanned_files,
        }
