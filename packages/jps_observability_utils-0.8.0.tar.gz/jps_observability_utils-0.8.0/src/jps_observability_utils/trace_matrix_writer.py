"""CSV trace matrix export."""

from __future__ import annotations

import csv
from pathlib import Path

from jps_observability_utils.models import AuditReport


def write_trace_matrix(report: AuditReport, output_path: Path) -> Path:
    """Write trace matrix rows to CSV."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "finding_id",
                "section_reference",
                "title",
                "category",
                "technology",
                "confidence",
                "evidence_type",
                "evidence_summary",
                "file_path",
                "line_number",
                "recommended_action",
                "jira_ticket",
                "status",
            ],
        )
        writer.writeheader()
        for row in report.trace_matrix:
            writer.writerow(row.to_dict())
    return output_path
