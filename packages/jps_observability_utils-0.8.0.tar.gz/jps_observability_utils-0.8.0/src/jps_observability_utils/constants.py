"""Project constants for observability audits."""

from __future__ import annotations

DEFAULT_IGNORE_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "node_modules",
    "dist",
    "build",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "__pycache__",
    ".next",
    ".turbo",
    ".yarn",
    ".pnpm-store",
    "coverage",
}

DEFAULT_TEXT_EXTENSIONS = {
    ".cfg",
    ".conf",
    ".env",
    ".ini",
    ".js",
    ".json",
    ".jsx",
    ".lock",
    ".log",
    ".md",
    ".mjs",
    ".py",
    ".sh",
    ".tf",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".yaml",
    ".yml",
}

DEPENDENCY_FILE_NAMES = {
    "pyproject.toml",
    "requirements.txt",
    "poetry.lock",
    "setup.py",
    "setup.cfg",
    "pipfile",
    "pipfile.lock",
    "environment.yml",
    "package.json",
    "package-lock.json",
    "npm-shrinkwrap.json",
    "yarn.lock",
    "pnpm-lock.yaml",
}

CATEGORY_ORDER = [
    "Telemetry Instrumentation",
    "Monitoring and Metrics",
    "Logging",
    "Observability Platforms",
    "Pipeline and Export Configuration",
    "Alerting and Monitoring Configuration",
]

LANGUAGE_PREFIX = {
    "python": "OBS-PY",
    "node": "OBS-NODE",
}

METHODOLOGY_PATTERNS = [
    "dependency manifests",
    "source imports and initialization code",
    "environment variables",
    "deployment and pipeline configuration",
    "collector and exporter signatures",
    "metrics endpoint patterns",
]

LIMITATIONS = [
    "This audit is static and evidence-based; it does not prove runtime behavior.",
    "Absence of evidence in the repository is not proof that observability is absent in deployed environments.",
    "Confidence levels reflect the strength of static indicators, not production validation.",
]
