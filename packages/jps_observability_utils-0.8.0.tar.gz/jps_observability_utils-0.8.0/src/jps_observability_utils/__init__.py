"""jps_observability_utils package."""

__version__ = "0.8.0"
