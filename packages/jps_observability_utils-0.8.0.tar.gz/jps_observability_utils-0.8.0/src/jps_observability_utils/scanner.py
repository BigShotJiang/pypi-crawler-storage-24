"""Repository scanning orchestration."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from jps_observability_utils import __version__
from jps_observability_utils.constants import CATEGORY_ORDER, LIMITATIONS
from jps_observability_utils.matchers.node_repo import find_node_evidence
from jps_observability_utils.matchers.python_repo import find_python_evidence
from jps_observability_utils.models import AuditReport, ScanStats, TraceMatrixRow
from jps_observability_utils.utils.file_utils import walk_repository
from jps_observability_utils.utils.id_utils import assign_finding_ids


@dataclass(slots=True)
class ScanResult:
    """Full in-memory result of a repository audit before writing files."""

    report: AuditReport
    stats: ScanStats


def _assign_section_references(report: AuditReport) -> None:
    grouped = {}
    for finding in report.findings:
        grouped.setdefault(finding.category, []).append(finding)

    category_number = 1
    for category in CATEGORY_ORDER:
        findings = grouped.get(category, [])
        if not findings:
            continue
        for finding_number, finding in enumerate(findings, start=1):
            finding.section_reference = f"5.{category_number}.{finding_number}"
        category_number += 1


def _build_trace_matrix_rows(report: AuditReport) -> list[TraceMatrixRow]:
    return [
        TraceMatrixRow(
            finding_id=finding.finding_id,
            section_reference=finding.section_reference,
            title=finding.title,
            category=finding.category,
            technology=finding.technology,
            confidence=finding.confidence,
            evidence_type=finding.evidence_type,
            evidence_summary=finding.match_text or finding.title,
            file_path=finding.file_path,
            line_number=finding.line_number,
            recommended_action=finding.recommended_action,
        )
        for finding in report.findings
    ]


def _summary_from_findings(findings, repo_path: Path, language_target: str, stats: ScanStats) -> dict[str, object]:
    return {
        "repository_path": str(repo_path.resolve()),
        "repository_name": repo_path.name,
        "audit_language_target": language_target,
        "total_findings": len(findings),
        "findings_by_confidence": stats.findings_by_confidence,
        "findings_by_category": stats.findings_by_category,
        "major_technologies_detected": stats.technologies_detected,
        "notable_caveats": LIMITATIONS,
    }


def audit_repository(
    repo_path: Path,
    language_target: str,
    ignore_patterns: list[str] | None = None,
    max_workers: int | None = None,
) -> ScanResult:
    """Scan a repository and build a report model."""
    scanned_files, ignored_paths, unreadable_files = walk_repository(
        repo_path,
        ignore_patterns,
        max_workers=max_workers,
    )
    if language_target == "python":
        findings = find_python_evidence(scanned_files, max_workers=max_workers)
    elif language_target == "node":
        findings = find_node_evidence(scanned_files, max_workers=max_workers)
    else:
        raise ValueError(f"Unsupported language target: {language_target}")

    ordered_findings = assign_finding_ids(findings, language_target)

    tech_counter = Counter(finding.technology for finding in ordered_findings)
    confidence_counter = Counter(finding.confidence for finding in ordered_findings)
    category_counter = Counter(finding.category for finding in ordered_findings)
    stats = ScanStats(
        files_scanned=len(scanned_files),
        ignored_paths=ignored_paths,
        unreadable_files=unreadable_files,
        findings_by_confidence=dict(sorted(confidence_counter.items())),
        findings_by_category=dict(sorted(category_counter.items())),
        technologies_detected=sorted(tech_counter.keys()),
    )

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    report = AuditReport(
        report_type="observability_audit",
        language_target=language_target,
        repository_name=repo_path.name,
        repository_path=str(repo_path.resolve()),
        scan_timestamp=timestamp,
        tool_version=__version__,
        files_scanned=stats.files_scanned,
        ignored_paths=stats.ignored_paths,
        findings=ordered_findings,
        summary=_summary_from_findings(ordered_findings, repo_path, language_target, stats),
        limitations=LIMITATIONS,
        report_files={},
        unreadable_files=unreadable_files,
        scanned_files=[file.relative_path for file in scanned_files],
    )
    _assign_section_references(report)
    report.trace_matrix = _build_trace_matrix_rows(report)
    return ScanResult(report=report, stats=stats)
