import json
from pathlib import Path

from typer.testing import CliRunner

from jps_observability_utils.cli import app


runner = CliRunner()
FIXTURES = Path(__file__).parent / "fixtures"


def test_audit_python_cli_writes_expected_files(tmp_path: Path) -> None:
    result = runner.invoke(
        app,
        [
            "audit-python",
            str(FIXTURES / "python_repo_otel"),
            "--output-dir",
            str(tmp_path),
            "--format",
            "both",
            "--trace-matrix",
        ],
    )

    assert result.exit_code == 0, result.stdout
    report_files = list(tmp_path.iterdir())
    assert any(path.suffix == ".md" for path in report_files)
    assert any(path.suffix == ".json" for path in report_files)
    assert any(path.name.endswith("_trace_matrix.csv") for path in report_files)


def test_audit_node_cli_json_contains_structured_findings(tmp_path: Path) -> None:
    result = runner.invoke(
        app,
        [
            "audit-node",
            str(FIXTURES / "node_repo_otel"),
            "--output-dir",
            str(tmp_path),
            "--format",
            "json",
            "--no-trace-matrix",
        ],
    )

    assert result.exit_code == 0, result.stdout
    json_path = next(tmp_path.glob("*.json"))
    payload = json.loads(json_path.read_text(encoding="utf-8"))
    assert payload["language_target"] == "node"
    assert payload["findings"]
    assert payload["findings"][0]["finding_id"].startswith("OBS-NODE-")
