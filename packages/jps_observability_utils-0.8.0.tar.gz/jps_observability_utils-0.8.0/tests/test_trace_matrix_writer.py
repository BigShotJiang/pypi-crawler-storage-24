import csv
from pathlib import Path

from jps_observability_utils.scanner import audit_repository
from jps_observability_utils.trace_matrix_writer import write_trace_matrix


FIXTURES = Path(__file__).parent / "fixtures"


def test_trace_matrix_rows_align_with_findings(tmp_path: Path) -> None:
    result = audit_repository(FIXTURES / "python_repo_otel", "python")
    output_path = tmp_path / "trace_matrix.csv"

    write_trace_matrix(result.report, output_path)

    with output_path.open(encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))

    assert len(rows) == len(result.report.findings)
    assert rows[0]["finding_id"] == result.report.findings[0].finding_id
    assert rows[0]["section_reference"]
