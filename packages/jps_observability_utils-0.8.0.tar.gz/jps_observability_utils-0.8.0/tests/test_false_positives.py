from pathlib import Path

from jps_observability_utils.scanner import audit_repository


FIXTURES = Path(__file__).parent / "fixtures"


def test_node_audit_does_not_treat_bare_4318_in_mock_json_as_otlp_evidence() -> None:
    result = audit_repository(FIXTURES / "node_repo_mock_data_only", "node")

    technologies = {finding.technology for finding in result.report.findings}
    assert "OTLP / Collector" not in technologies
    assert result.report.findings == []


def test_node_audit_does_not_treat_add_list_item_as_datadog_evidence() -> None:
    result = audit_repository(FIXTURES / "node_repo_false_datadog", "node")

    technologies = {finding.technology for finding in result.report.findings}
    assert "Datadog" not in technologies
    assert result.report.findings == []


def test_node_audit_does_not_treat_console_error_json_stringify_as_structured_logging() -> None:
    result = audit_repository(FIXTURES / "node_repo_false_logging", "node")

    technologies = {finding.technology for finding in result.report.findings}
    assert "Structured Logging" not in technologies
    assert result.report.findings == []
