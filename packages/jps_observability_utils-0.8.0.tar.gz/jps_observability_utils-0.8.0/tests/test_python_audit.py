from pathlib import Path

from jps_observability_utils.scanner import audit_repository


FIXTURES = Path(__file__).parent / "fixtures"


def test_python_audit_detects_expected_technologies() -> None:
    result = audit_repository(FIXTURES / "python_repo_otel", "python")

    technologies = {finding.technology for finding in result.report.findings}
    assert "OpenTelemetry" in technologies
    assert "Prometheus" in technologies
    assert "OTLP / Collector" in technologies
    assert "Structured Logging" in technologies


def test_python_audit_assigns_deterministic_ids() -> None:
    first = audit_repository(FIXTURES / "python_repo_otel", "python")
    second = audit_repository(FIXTURES / "python_repo_otel", "python")

    assert [finding.finding_id for finding in first.report.findings] == [
        finding.finding_id for finding in second.report.findings
    ]


def test_python_audit_handles_clean_repo() -> None:
    result = audit_repository(FIXTURES / "python_repo_clean", "python")
    assert result.report.findings == []


def test_python_vendor_detection_finds_platform_integrations() -> None:
    result = audit_repository(FIXTURES / "python_repo_vendor", "python")
    technologies = {finding.technology for finding in result.report.findings}
    assert "Datadog" in technologies
    assert "Sentry" in technologies


def test_python_audit_parallel_scan_matches_single_worker_results() -> None:
    sequential = audit_repository(FIXTURES / "python_repo_otel", "python", max_workers=1)
    parallel = audit_repository(FIXTURES / "python_repo_otel", "python", max_workers=4)

    assert [finding.to_dict() for finding in sequential.report.findings] == [
        finding.to_dict() for finding in parallel.report.findings
    ]
