from pathlib import Path

from jps_observability_utils.report_writer import render_markdown
from jps_observability_utils.scanner import audit_repository


FIXTURES = Path(__file__).parent / "fixtures"


def test_markdown_report_contains_numbered_sections_and_finding_ids() -> None:
    result = audit_repository(FIXTURES / "python_repo_otel", "python")
    markdown = render_markdown(result.report, [])

    assert "## 1. Executive Summary" in markdown
    assert "## 5. Detailed Findings" in markdown
    assert "#### 5.1.1 OBS-PY-001" in markdown
    assert "## 7. Traceability Matrix" in markdown


def test_markdown_report_contains_no_findings_message() -> None:
    result = audit_repository(FIXTURES / "node_repo_clean", "node")
    markdown = render_markdown(result.report, [])

    assert "No detectable evidence of the targeted observability-related technologies was found" in markdown
