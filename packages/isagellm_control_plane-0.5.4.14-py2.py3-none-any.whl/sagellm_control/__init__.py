"""sageLLM Control Plane - Intelligent request routing and scheduling.

The Control Plane sits between users and LLM execution instances, providing:
- Intelligent request routing and load balancing
- Advanced scheduling policies (priority, SLO-aware, cost-optimized)
- Engine lifecycle management (spawn, stop, health check)
- Performance monitoring and adaptive optimization

Quick Start:
    from sagellm_control import ControlPlaneManager
"""

from __future__ import annotations

from sagellm_control._version import __version__
from sagellm_control.admission import AdmissionDecision, AdmissionGuard
from sagellm_control.engine_client import (
    ClientConfig,
    EngineClient,
    EngineClientError,
    EngineRequestError,
    EngineTimeoutError,
    EngineUnavailableError,
    RequestContext,
    RetryPolicy,
)
from sagellm_control.failover import EngineFailoverManager, FailoverEvent
from sagellm_control.ir import (
    ComputationNode,
    DefaultIRExecutor,
    DependencyEdge,
    ExecutionCommand,
    IRBuilder,
    IRExecutor,
    IRNode,
    IROptimizer,
    NodeType,
    ParallelismConfig,
    ParallelismStrategy,
    ResourceAllocation,
    SchedulerIR,
    TaskNode,
)
from sagellm_control.lifecycle import EngineLifecycleManager
from sagellm_control.local_engine_client import LocalEngineClient
from sagellm_control.manager import ControlPlaneManager
from sagellm_control.observability import (
    PROMETHEUS_AVAILABLE,
    ControlPlaneMetricsCollector,
    ControlPlanePrometheusExporter,
    SchedulingMetrics,
    SchedulingSpan,
    TraceContext,
    get_current_trace_context,
)
from sagellm_control.pd_router import PDEngineEntry, PDRouter
from sagellm_control.policies import (
    AdaptivePolicy,
    FIFOPolicy,
    HeterogeneousSchedulingPolicy,
    KVAwareIRPolicy,
    KVAwareSchedulingPolicy,
    LifetimeAwarePolicy,
    LoadBalancingPolicy,
    PrefixGroupingPolicy,
    PriorityPolicy,
    SchedulingPolicy,
    SLOAwarePolicy,
    SpeculativeSchedulingPolicy,
)
from sagellm_control.predictor import (
    HistoricalPredictor,
    HybridHeuristicPredictor,
    LengthBasedPredictor,
    LifetimePredictor,
)
from sagellm_control.protocols import EmbeddingEngine
from sagellm_control.router import LoadBalancer, RequestRouter
from sagellm_control.scaling import ScalingManager, ScalingRecommendation
from sagellm_control.types import (
    EngineInfo,
    EngineState,
    ExecutionInstanceType,
    PlacementDecision,
    RequestMetadata,
    RequestPriority,
    RequestStatus,
    RequestType,
    SchedulingDecision,
)

__all__ = [
    "__version__",
    # Admission Control
    "AdmissionGuard",
    "AdmissionDecision",
    # Types
    "EngineInfo",
    "EngineState",
    "RequestMetadata",
    "RequestPriority",
    "RequestStatus",
    "RequestType",
    "SchedulingDecision",
    "PlacementDecision",
    "ExecutionInstanceType",  # MVP: PD 分离支持
    # IR
    "SchedulerIR",
    "IRNode",
    "TaskNode",
    "ComputationNode",
    "DependencyEdge",
    "ResourceAllocation",
    "ParallelismConfig",
    "ParallelismStrategy",
    "NodeType",
    "IRBuilder",
    "IROptimizer",
    "IRExecutor",
    "DefaultIRExecutor",
    "ExecutionCommand",
    # Manager
    "ControlPlaneManager",
    # Router
    "LoadBalancer",
    "RequestRouter",
    # Lifecycle
    "EngineLifecycleManager",
    # Scaling (MVP)
    "ScalingManager",
    # Protocols
    "EmbeddingEngine",
    # Policies
    "SchedulingPolicy",
    "FIFOPolicy",
    "PriorityPolicy",
    "SLOAwarePolicy",
    "AdaptivePolicy",
    "LoadBalancingPolicy",
    "KVAwareSchedulingPolicy",
    "KVAwareIRPolicy",
    "LifetimeAwarePolicy",
    "PrefixGroupingPolicy",
    "HeterogeneousSchedulingPolicy",
    "SpeculativeSchedulingPolicy",
    # Failover
    "EngineFailoverManager",
    "FailoverEvent",
    # Scaling
    "ScalingRecommendation",
    # Predictors
    "LifetimePredictor",
    "LengthBasedPredictor",
    "HistoricalPredictor",
    "HybridHeuristicPredictor",
    # Engine Client
    "EngineClient",
    "LocalEngineClient",
    "ClientConfig",
    "RequestContext",
    "RetryPolicy",
    "EngineClientError",
    "EngineTimeoutError",
    "EngineUnavailableError",
    "EngineRequestError",
    # Observability
    "SchedulingMetrics",
    "ControlPlaneMetricsCollector",
    "TraceContext",
    "SchedulingSpan",
    "get_current_trace_context",
    "ControlPlanePrometheusExporter",
    "PROMETHEUS_AVAILABLE",
    # PD Separation Router
    "PDRouter",
    "PDEngineEntry",
]
