"""Scheduling Policies for the Control Plane.

Available policies:
- FIFO: First-in-first-out (default)
- Priority: Priority-based scheduling
- SLOAware: SLA/deadline-aware scheduling
- Adaptive: Dynamic policy selection
- LoadBalancing: Multi-strategy load balancing (round_robin, least_connections, etc.)
- KVAware: KV cache budget-aware scheduling
- LifetimeAware: Lifetime predictor-aware scheduling
- PrefixGrouping: Prefix-based request grouping for KV cache reuse
- Speculative: Draft+verify speculative decoding optimised routing
"""

from __future__ import annotations

from sagellm_control.policies.adaptive import AdaptivePolicy
from sagellm_control.policies.base import SchedulingPolicy
from sagellm_control.policies.fifo import FIFOPolicy
from sagellm_control.policies.heterogeneous import HeterogeneousSchedulingPolicy
from sagellm_control.policies.kv_aware import KVAwareIRPolicy, KVAwareSchedulingPolicy
from sagellm_control.policies.lifetime_aware import LifetimeAwarePolicy
from sagellm_control.policies.load_balancing import LoadBalancingPolicy
from sagellm_control.policies.prefix_grouping import PrefixGroupingPolicy
from sagellm_control.policies.priority import PriorityPolicy
from sagellm_control.policies.slo_aware import SLOAwarePolicy
from sagellm_control.policies.speculative import SpeculativeSchedulingPolicy

__all__ = [
    "SchedulingPolicy",
    "FIFOPolicy",
    "PriorityPolicy",
    "SLOAwarePolicy",
    "AdaptivePolicy",
    "LoadBalancingPolicy",
    "KVAwareSchedulingPolicy",
    "KVAwareIRPolicy",
    "LifetimeAwarePolicy",
    "PrefixGroupingPolicy",
    "HeterogeneousSchedulingPolicy",
    "SpeculativeSchedulingPolicy",
]
