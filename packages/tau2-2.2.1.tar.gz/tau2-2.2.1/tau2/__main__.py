#!/usr/bin/env python3
from tau2.main import main

if __name__ == '__main__':
    main()
