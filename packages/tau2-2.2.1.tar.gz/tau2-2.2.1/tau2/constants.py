import numpy as np
from scipy import constants

# Fundamental constants in SI units
C_CM_S = constants.c * 100  # Speed of light in cm/s (exact)
H_J_S = constants.h         # Planck constant in J*s
K_J_K = constants.k         # Boltzmann constant in J/K

# Derived constants in spectroscopic units
KB_INV_CM = K_J_K / (H_J_S * C_CM_S) # Boltzmann constant in cm^-1/K
HBAR_CM = 1 / (2 * np.pi * C_CM_S) # h-bar in cm^-1 * s
TWO_PI_OVER_HBAR = 2 * np.pi / HBAR_CM # Prefactor 2*pi/hbar in (cm * s)^-1
PI_OVER_HBAR = np.pi / HBAR_CM # Prefactor pi/hbar in (cm * s)^-1
MU_B_CM_T = constants.physical_constants['Bohr magneton'][0] / (H_J_S * C_CM_S) # Bohr Magneton in cm^-1 / T

# Free electron g-factor
# Scipy returns the physics convention (negative for electron); we take abs to match chemistry convention.
G_E = abs(constants.physical_constants['electron g factor'][0])