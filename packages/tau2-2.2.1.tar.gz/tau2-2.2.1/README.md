# tau2

`tau2` is a python package for simulating magnetic relaxation.

# Installation via `pip`

Install `tau2` using `pip` (if using a shared machine, add the `--user` argument after `install`)

```
pip install tau2
```

# Updating

Update the code using `pip` (if using a shared machine, add the `--user` argument after `install`)

```
pip install tau2 --upgrade
```

# Installation with `pip` editable install

**Only do this if you are developing (i.e. changing) the code.**

Clone a copy of this repository, preferably while within a directory called git

```
mkdir -p git; cd git
git clone https://gitlab.com/chilton-group/tau2
```

Navigate to the package directory

```
cd tau2/packages
```

and install the package in editable mode (if using a shared machine, add the `--user` argument after `install`)

```
pip install -e .
```

When you're done developing (i.e. your changes have been merged to the master), 
or if you just want to use the current release version of the package, uninstall using `pip`

```
pip uninstall tau2
```

and follow the Installation via `pip` instructions above.

# Usage

The `tau2` command line interface can be invoked with 

```
tau2 -h
```

which prints a list of available subprograms.

Additional options for the `raman` and `orbach` programs can be viewed with `--advanced_help`.

# Documentation

The [documentation](https://chilton-group.gitlab.io/tau2/) for this package is hosted by gitlab, and is automatically generated whenever new code is committed to the `main` branch. The automatic generation of this documentation relies on a common layout for comments and docstrings within the code, see [contributing](https://gitlab.com/chilton-group/group-wiki/-/wikis/Contributing:-General) for more information.

# Development

Before making changes to this repository, please follow the steps outlined in the [Chilton group wiki](https://gitlab.com/chilton-group/group-wiki/-/wikis/Contributing:-General).

# Bugs

If you believe you have a bug, *please check that you are using the most up to date version of the code*. 

If that does not fix the problem, please create an issue on GitLab detailing the following:
 - The commands you entered
 - The error message

Remember to simplify the problem as much as possible in order to provide a minimum working example, e.g. an example for a small molecule rather than one with 100000 atoms.

Then, look at the code, try and figure out what you think is wrong if possible, and include this in your issue.
