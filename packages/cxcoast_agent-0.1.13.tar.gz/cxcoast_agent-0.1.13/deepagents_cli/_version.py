"""Version information and lightweight constants for CXCoast Agent."""

__version__ = "0.1.13"

DOCS_URL = "https://docs.cxcoast.com/cli"
"""URL for CXCoast Agent CLI documentation."""

PYPI_URL = "https://pypi.org/pypi/cxcoast-agent/json"
"""PyPI JSON API endpoint for version checks."""

CHANGELOG_URL = (
    "https://github.com/admin-cxcoast/cxcoast-agent/blob/customization/libs/cli/CHANGELOG.md"
)
"""URL for the full changelog."""

USER_AGENT = f"cxcoast-agent/{__version__} update-check"
"""User-Agent header sent with PyPI requests."""
