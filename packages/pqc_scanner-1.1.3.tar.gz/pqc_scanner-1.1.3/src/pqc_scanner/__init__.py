"""
pqc-scanner — Automated timing side-channel scanner for NIST PQC standards.

Detects constant-time violations in ML-KEM (FIPS 203) and ML-DSA (FIPS 204)
using TVLA statistical methodology (ISO 17825).

Usage:
    pqc-scanner liboqs --traces 100000
    pqc-scanner scan --algorithm both --traces 10000
    pqc-scanner compare --traces 10000
"""

__version__ = "1.0.0"
__author__ = "Collective Qubits"
__license__ = "MIT"
