"""
Alti-2 communication protocol definitions.

Packet format (unencrypted):
  BYTE 0:       Packet length (excludes byte 0 and checksum byte)
  BYTES 1..N:   Command payload
  BYTE N+1:     Checksum = sum(BYTES 1..N) mod 256

The first command (Get Type 0) and the last (End ASCII) are sent as ASCII
hex strings. All other commands are padded to 32 bytes and XTEA-encrypted.
"""

import struct
from datetime import datetime

# ---------------------------------------------------------------------------
# Product ID mapping
# ---------------------------------------------------------------------------
PRODUCT_NAMES = {
    7:  "Atlas",
    8:  "MA12",
    9:  "MA12 mBar",
    12: "Atlas2",
    13: "Atlas2 Student",
    14: "Atlas2 Juno",
    15: "MA15A",
}

# ---------------------------------------------------------------------------
# Command codes
# ---------------------------------------------------------------------------
CMD_GET_TYPE_ZERO = 0x80   # Get Type 0 record (initial handshake)
CMD_READ_MEMORY   = 0xA0   # Read memory (160 decimal)
CMD_READ_DATETIME = 0xA2   # Read device date/time
CMD_END_COMM      = 0xAF   # End communication (175 decimal)
CMD_WRITE_MEMORY  = 0xB0   # Write memory block (176 decimal) — UNTESTED
CMD_END_ASCII     = 0x03   # Final ASCII end command

# ---------------------------------------------------------------------------
# Acknowledgement codes (single raw bytes)
# ---------------------------------------------------------------------------
ACK_ABORTED       = 0x30   # 48  - Communication aborted
ACK_OK            = 0x31   # 49  - Command recognized successfully
ACK_BAD_LENGTH    = 0x32   # 50  - Packet length incorrect
ACK_BAD_CHECKSUM  = 0x33   # 51  - Packet checksum incorrect
ACK_REPEAT        = 0x34   # 52  - Please repeat packet
ACK_READY         = 0x35   # 53  - Ready to send/receive
ACK_UNKNOWN_CMD   = 0x36   # 54  - Command not recognized
ACK_BAD_SYNTAX    = 0x37   # 55  - Incorrect command syntax
ACK_EEPROM_ERROR  = 0x38   # 56  - Error writing to EEPROM/FRAM
ACK_FLASH_ERROR   = 0x39   # 57  - Flash erase error
ACK_OUT_OF_BOUNDS = 0x3A   # 58  - Memory address out of bounds
ACK_FLASH_WRITE   = 0x3B   # 59  - Flash write error
ACK_NO_BOOTLOADER = 0x3C   # 60  - No bootloader present

ACK_NAMES = {
    ACK_ABORTED:       "ABORTED",
    ACK_OK:            "OK",
    ACK_BAD_LENGTH:    "BAD_LENGTH",
    ACK_BAD_CHECKSUM:  "BAD_CHECKSUM",
    ACK_REPEAT:        "REPEAT",
    ACK_READY:         "READY",
    ACK_UNKNOWN_CMD:   "UNKNOWN_CMD",
    ACK_BAD_SYNTAX:    "BAD_SYNTAX",
    ACK_EEPROM_ERROR:  "EEPROM_ERROR",
    ACK_FLASH_ERROR:   "FLASH_ERROR",
    ACK_OUT_OF_BOUNDS: "OUT_OF_BOUNDS",
    ACK_FLASH_WRITE:   "FLASH_WRITE_ERROR",
    ACK_NO_BOOTLOADER: "NO_BOOTLOADER",
}

# ---------------------------------------------------------------------------
# FRAM data structure addresses and sizes
# ---------------------------------------------------------------------------
FRAM_JUMPS_SUMMARY_ADDR   = 0x000A  # 10
FRAM_JUMPS_SUMMARY_SIZE   = 30
FRAM_SETTINGS_ADDR        = 0x002C  # 44
FRAM_SETTINGS_SIZE        = 13
FRAM_SPEED_GROUPS_ADDR    = 0x003A  # 58
FRAM_SPEED_GROUPS_SIZE    = 26
FRAM_DZ_NAMES_ADDR        = 0x0054  # 84
FRAM_AIRCRAFT_NAMES_ADDR  = 0x0196  # 406
FRAM_ALARM_NAMES_ADDR     = 0x02D8  # 728
FRAM_ALARM_TONE_DIR_ADDR  = 0x041A  # 1050
FRAM_ALARM_TONE_DIR_SIZE  = 18
FRAM_ALARM_TONE_DATA_ADDR = 0x042C  # 1068
FRAM_ALARM_TONE_DATA_SIZE = 160
FRAM_ALARM_SETTINGS_ADDR  = 0x04CC  # 1228
FRAM_ALARM_SETTINGS_SIZE  = 84

# FRAM name table layout
FRAM_NAME_ENTRY_SIZE     = 10      # bytes per name entry
FRAM_NAME_COUNT          = 32      # entries per name table
FRAM_NAME_HEADER_SIZE    = 2       # bytes before first entry (checksum + count)
FRAM_NAME_TABLE_SIZE     = FRAM_NAME_HEADER_SIZE + FRAM_NAME_COUNT * FRAM_NAME_ENTRY_SIZE

# Max data bytes in a single B0 write packet
# Packet = [length][B0][addr4][data...][checksum], padded to 32 bytes
# Max: 32 - 1(len) - 1(cmd) - 4(addr) - 1(chk) = 25
WRITE_MAX_PAYLOAD = 25

DEFAULT_AIRCRAFT_NAMES = [
    "Cessna", "Piper", "Beech", "King Air", "Twin Otter", "Skyvan",
    "Caravan", "Porter", "Antonov", "Helicopter", "Balloon", "Glider",
    "Ultralight", "Wingsuit", "BASE", "Other",
    "Custom1", "Custom2", "Custom3", "Custom4", "Custom5", "Custom6",
    "Custom7", "Custom8", "Custom9", "Custom10", "Custom11", "Custom12",
    "Custom13", "Custom14", "Custom15", "Custom16",
]

DEFAULT_DZ_NAMES = [
    "Home", "Away", "Local", "Training", "Boogie", "Competition",
    "Demo", "Fun Jump", "Accuracy", "Formation", "Freefly", "Wingsuit",
    "Canopy", "Tandem", "Student", "Instructor",
    "Custom1", "Custom2", "Custom3", "Custom4", "Custom5", "Custom6",
    "Custom7", "Custom8", "Custom9", "Custom10", "Custom11", "Custom12",
    "Custom13", "Custom14", "Custom15", "Custom16",
]

DEFAULT_ALARM_NAMES = [
    "FF1", "FF2", "FF3", "FF4", "CP1", "CP2", "CP3", "CP4",
    "Custom1", "Custom2", "Custom3", "Custom4", "Custom5", "Custom6",
    "Custom7", "Custom8", "Custom9", "Custom10", "Custom11", "Custom12",
    "Custom13", "Custom14", "Custom15", "Custom16", "Custom17", "Custom18",
    "Custom19", "Custom20", "Custom21", "Custom22", "Custom23", "Custom24",
]

# ---------------------------------------------------------------------------
# Packet building
# ---------------------------------------------------------------------------

def _checksum(payload: bytes) -> int:
    """Compute checksum: sum of payload bytes mod 256."""
    return sum(payload) & 0xFF


def build_packet(command_code: int, params: bytes = b'') -> bytes:
    """Build a raw command packet: [length][command][params][checksum].

    Args:
        command_code: The command byte (e.g. CMD_READ_MEMORY).
        params:       Additional parameter bytes.

    Returns:
        Complete packet bytes (not yet padded/encrypted).
    """
    payload = bytes([command_code]) + params
    length = len(payload)
    chk = _checksum(payload)
    return bytes([length]) + payload + bytes([chk])


def build_ascii_command(command_code: int) -> bytes:
    """Build a command as ASCII hex string (for first/last commands).

    The packet [length, command, checksum] is converted to uppercase
    hex ASCII characters without spaces: e.g. "018080" for cmd 0x80.

    Args:
        command_code: The command byte.

    Returns:
        ASCII bytes of the hex string representation.
    """
    payload = bytes([command_code])
    length = len(payload)
    chk = _checksum(payload)
    packet = bytes([length]) + payload + bytes([chk])
    return ''.join(f'{b:02X}' for b in packet).encode('ascii')


def build_read_command(address: int, length: int) -> bytes:
    """Build a read memory command packet.

    Format: [07][A0][addr_lo][addr_mid][addr_hi][addr_highest][len_lo][len_hi][checksum]

    Args:
        address: 32-bit memory address (little-endian DWORD).
        length:  Number of bytes to read (16-bit, little-endian WORD, max 65535).

    Returns:
        Complete packet bytes (9 bytes, not yet padded/encrypted).
    """
    if length < 1 or length > 0xFFFF:
        raise ValueError(f"Read length must be 1..65535, got {length}")
    addr_bytes = struct.pack('<I', address)
    len_bytes = struct.pack('<H', length)
    return build_packet(CMD_READ_MEMORY, addr_bytes + len_bytes)


def build_write_command(address: int, data: bytes) -> bytes:
    """Build a write memory command packet.

    Format: [length][B0][addr_lo..hi][data...][checksum]

    The data must fit in a single 32-byte encrypted packet (max 25 bytes).
    For larger writes, callers should split into multiple commands.

    .. warning::
        The B0 write command format is inferred from the protocol
        documentation and by symmetry with the A0 read command.
        The official tool never implements B0.  The packet format and
        ACK response sequence have NOT been verified against a real
        device.  Use at your own risk.

    Args:
        address: 32-bit memory address (little-endian DWORD).
        data:    Bytes to write (1..25 bytes).

    Returns:
        Complete packet bytes (to be padded and encrypted).
    """
    if len(data) < 1 or len(data) > WRITE_MAX_PAYLOAD:
        raise ValueError(
            f"Write data must be 1..{WRITE_MAX_PAYLOAD} bytes, got {len(data)}")
    addr_bytes = struct.pack('<I', address)
    return build_packet(CMD_WRITE_MEMORY, addr_bytes + data)


def build_datetime_command() -> bytes:
    """Build the read date/time command packet.

    Returns:
        Packet bytes: [01][A2][A2] (3 bytes, to be padded and encrypted).
    """
    return build_packet(CMD_READ_DATETIME)


def build_end_command() -> bytes:
    """Build the encrypted end communication command.

    Returns:
        Packet bytes: [01][AF][AF] (3 bytes, to be padded and encrypted).
    """
    return build_packet(CMD_END_COMM)


def build_end_ascii() -> bytes:
    """Build the final ASCII end command.

    Returns:
        ASCII bytes "010303".
    """
    return build_ascii_command(CMD_END_ASCII)


def pad_to_32(data: bytes) -> bytes:
    """Pad data with zero bytes to exactly 32 bytes.

    Args:
        data: Input bytes (must be <= 32 bytes).

    Returns:
        32 bytes (original data + zero padding).
    """
    if len(data) > 32:
        raise ValueError(f"Data too long to pad: {len(data)} bytes")
    return data + b'\x00' * (32 - len(data))


# ---------------------------------------------------------------------------
# Type 0 record parsing
# ---------------------------------------------------------------------------

def parse_type_zero(frame: bytes) -> dict:
    """Parse the 32-byte Type 0 record returned during initial handshake.

    Type 0 record structure:
      Byte 0:      Record length (always 0x1E = 30)
      Byte 1:      Record type (always 0x00)
      Byte 2:      Communication type
      Byte 3:      Firmware revision major (high nibble = major, low nibble = minor)
      Byte 4:      Firmware revision minor (sub-version)
      Bytes 5-13:  Serial number (9 ASCII chars, space-padded)
      Byte 14:     Hardware ID (add 0x40 for letter: 1='A', 2='B', 3='C')
      Byte 15:     Product ID
      Byte 16:     FRAM configuration
      Bytes 17-20: Detail log start address (uint32 LE)
      Bytes 21-22: Total jumps (uint16 LE)
      Bytes 23-26: Total jump seconds (uint32 LE)
      Bytes 27-30: Summary log start address (uint32 LE)
      Byte 31:     Checksum

    Args:
        frame: Raw 32 bytes from device.

    Returns:
        Dictionary with parsed fields and 'raw' original bytes.
    """
    if len(frame) != 32:
        raise ValueError(f"Type 0 record must be 32 bytes, got {len(frame)}")

    info = {}
    info['length']        = frame[0]
    info['type']          = frame[1]
    info['comm_type']     = frame[2]
    info['rev_major']     = frame[3]
    info['rev_minor']     = frame[4]
    info['serial_number'] = bytes(frame[5:14]).decode('ascii', errors='replace').strip('\x00').strip()
    info['hardware_id']   = chr(frame[14] + 0x40) if frame[14] < 26 else f'0x{frame[14]:02X}'
    info['product_id']    = frame[15]
    info['product_name']  = PRODUCT_NAMES.get(frame[15], f"Unknown({frame[15]})")
    info['fram_config']   = frame[16]
    info['detail_log_start'] = struct.unpack_from('<I', frame, 17)[0]
    info['total_jumps']      = struct.unpack_from('<H', frame, 21)[0]
    info['total_jump_seconds'] = struct.unpack_from('<I', frame, 23)[0]
    info['summary_start']    = struct.unpack_from('<I', frame, 27)[0]
    info['sw_version']    = f"{frame[3] >> 4}.{frame[3] & 0x0F}.{frame[4]}"
    info['checksum']      = frame[31]
    info['raw']           = bytes(frame)
    return info


# ---------------------------------------------------------------------------
# Date/time response parsing (A2 command response)
# ---------------------------------------------------------------------------

def parse_datetime_response(data: bytes) -> datetime | None:
    """Parse the decrypted A2 date/time response.

    Format (8 bytes):
      Bytes 0-1: Year (uint16 LE)
      Byte 2:    Month (1-12)
      Byte 3:    Day (1-31)
      Byte 4:    Checksum byte
      Byte 5:    Hour (0-23)
      Byte 6:    Minute (0-59)
      Byte 7:    Second (0-59)

    Returns:
        datetime object, or None if data is invalid.
    """
    if len(data) < 8:
        return None

    year = struct.unpack_from('<H', data, 0)[0]
    month = data[2]
    day = data[3]
    hour = data[5]
    minute = data[6]
    second = data[7]

    if not (1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31
            and hour <= 23 and minute <= 59 and second <= 59):
        return None

    try:
        return datetime(year, month, day, hour, minute, second)
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# FRAM name parsing
# ---------------------------------------------------------------------------

def parse_fram_name(data: bytes) -> str | None:
    """Parse a 10-byte FRAM name entry.

    The second byte's high bit is a flag and must be masked off.
    Names are NUL-terminated ASCII strings.

    Args:
        data: 10 bytes of FRAM name data.

    Returns:
        Decoded name string, or None if empty.
    """
    if len(data) < 10:
        return None

    name_bytes = bytearray(data[:10])
    if len(name_bytes) > 1 and name_bytes[1] != 0:
        name_bytes[1] = name_bytes[1] & 0x7F

    nul_pos = bytes(name_bytes).find(b'\x00')
    if nul_pos == 0:
        return None
    length = nul_pos if nul_pos > 0 else 10

    name = bytes(name_bytes[:length]).decode('ascii', errors='replace').strip()
    return name if name else None


def fram_name_address(base_addr: int, index: int) -> int:
    """Compute the FRAM address for a name entry.

    Address = base + 2 (header) + index * 10.
    """
    return base_addr + FRAM_NAME_HEADER_SIZE + index * FRAM_NAME_ENTRY_SIZE


def get_alarm_name(index: int, is_cp: bool,
                   custom_names: dict[int, str] | None = None) -> str:
    """Resolve an alarm index to a display name.

    Special values:
      - CP alarm: 50-63 (except 62) = "Deactivated", 62 = "Default"
      - FF alarm: 128 = "Deactivated", 127 = "Default"
      - 0-31: look up in custom_names, fallback to DEFAULT_ALARM_NAMES
    """
    if custom_names is None:
        custom_names = {}

    if is_cp:
        if 50 <= index <= 63 and index != 62:
            return "Deactivated"
        if index == 62:
            return "Default"
        if 0 <= index <= 31:
            if index in custom_names:
                return custom_names[index]
            if index < len(DEFAULT_ALARM_NAMES):
                return DEFAULT_ALARM_NAMES[index]
            return f"Custom{index}"
        return f"CP_{index}"

    if index == 128:
        return "Deactivated"
    if index == 127:
        return "Default"
    if 0 <= index <= 31:
        if index in custom_names:
            return custom_names[index]
        if index < len(DEFAULT_ALARM_NAMES):
            return DEFAULT_ALARM_NAMES[index]
        return f"Custom{index}"
    return f"FF_{index}"


def encode_fram_name(name: str) -> bytes:
    """Encode a name string into a 10-byte FRAM name entry.

    Names are NUL-terminated ASCII, max 10 characters.
    Byte 1 has its high bit set as a "used" flag.

    The encoding logic is the inverse of the read-side parsing verified
    in the official tool's ``ReadNameFromFram``.  The flag semantics are
    confirmed by the protocol spec, but actual write-back has not been
    tested on a device.

    Args:
        name: Name string (max 10 ASCII characters, will be truncated).

    Returns:
        10 bytes of FRAM name data.
    """
    encoded = name[:10].encode('ascii', errors='replace')
    buf = bytearray(FRAM_NAME_ENTRY_SIZE)
    buf[:len(encoded)] = encoded
    if len(encoded) > 1:
        buf[1] = buf[1] | 0x80
    return bytes(buf)


# ---------------------------------------------------------------------------
# Device settings parsing/encoding
# ---------------------------------------------------------------------------

def parse_settings(data: bytes) -> dict:
    """Parse the 13-byte device settings record (FRAM address 0x002C).

    .. warning::
        The settings layout comes from the Neptune N3/N3A protocol spec.
        It has not been verified on Atlas 2 hardware.  The official tool
        never reads or writes device settings.

    Returns:
        Dictionary with setting names as keys.
    """
    if len(data) < FRAM_SETTINGS_SIZE:
        raise ValueError(
            f"Settings record needs {FRAM_SETTINGS_SIZE} bytes, got {len(data)}")
    return {
        'altitude_unit':    'meters' if data[0] else 'feet',
        'speed_unit':       'kmh' if data[1] else 'mph',
        'temperature_unit': 'celsius' if data[2] else 'fahrenheit',
        'display_flip':     bool(data[3]),
        'logbook_enabled':  bool(data[4]),
        'time_format':      '24h' if data[5] else '12h',
        'date_format':      'international' if data[6] else 'us',
        'canopy_display':   bool(data[7]),
        'climb_display':    'altitude' if data[8] else 'time',
        'display_contrast': data[10],
        'canopy_alarms':    'loud' if data[12] else 'normal',
    }


_SETTINGS_ENCODE_MAP = {
    'altitude_unit':    (0,  {'feet': 0, 'meters': 1}),
    'speed_unit':       (1,  {'mph': 0, 'kmh': 1}),
    'temperature_unit': (2,  {'fahrenheit': 0, 'celsius': 1}),
    'display_flip':     (3,  {False: 0, True: 1}),
    'logbook_enabled':  (4,  {False: 0, True: 1}),
    'time_format':      (5,  {'12h': 0, '24h': 1}),
    'date_format':      (6,  {'us': 0, 'international': 1}),
    'canopy_display':   (7,  {False: 0, True: 1}),
    'climb_display':    (8,  {'time': 0, 'altitude': 1}),
    'display_contrast': (10, None),
    'canopy_alarms':    (12, {'normal': 0, 'loud': 1}),
}


def encode_settings(settings: dict, base: bytes | None = None) -> bytes:
    """Encode a settings dictionary to a 13-byte FRAM record.

    Only keys present in ``settings`` are updated; absent keys retain the
    value from ``base`` (or zero if no base is provided).

    Args:
        settings: Dict of setting name → value (see parse_settings keys).
        base:     Existing 13-byte settings to use as defaults, typically
                  read from the device first with a read-modify-write pattern.

    Returns:
        13 bytes ready to write to FRAM_SETTINGS_ADDR.
    """
    buf = bytearray(base[:FRAM_SETTINGS_SIZE]) if base else bytearray(FRAM_SETTINGS_SIZE)
    for key, value in settings.items():
        if key not in _SETTINGS_ENCODE_MAP:
            raise ValueError(f"Unknown setting: {key}")
        offset, mapping = _SETTINGS_ENCODE_MAP[key]
        if mapping is None:
            buf[offset] = int(value) & 0xFF
        else:
            if value not in mapping:
                raise ValueError(
                    f"Invalid value for {key}: {value!r} "
                    f"(expected one of {list(mapping.keys())})")
            buf[offset] = mapping[value]
    return bytes(buf)


# ---------------------------------------------------------------------------
# Logbook record parsing (22 bytes per record)
# ---------------------------------------------------------------------------

def _extract_bits(data: bytes, bit_offset: int, bit_count: int) -> int:
    """Extract a bit-field value from a byte array (LSB-first within each byte)."""
    result = 0
    for i in range(bit_count):
        bit_pos = bit_offset + i
        byte_idx = bit_pos // 8
        bit_idx = bit_pos % 8
        if byte_idx < len(data) and (data[byte_idx] & (1 << bit_idx)):
            result |= (1 << i)
    return result


def _parse_word(data: bytes, offset: int) -> int:
    """Parse a 16-bit little-endian word at byte offset."""
    return data[offset] | (data[offset + 1] << 8)


LOGBOOK_RECORD_SIZE = 22  # bytes per jump record


def _month_counter_to_date(month_counter: int, day: int,
                           hours: int, minutes: int) -> datetime | None:
    """Convert month counter to a year/month and build a datetime.

    The month counter is a running count of months since an epoch:
      year = 2000 + mc // 12 + 15  (or +14 when mc % 12 == 0)
      month = mc % 12              (or 12 when mc % 12 == 0)

    NOTE: The firmware stores this as a full 8-bit value (0-255).
    The original format spec only allocated 7 bits (max 127 = July 2025),
    with bit 7 reserved as a "deleted" flag.  This caused a Y2K-style
    overflow bug starting August 2025 (mc=128, bit 7 set).
    We use all 8 bits to correctly handle dates beyond July 2025.
    """
    if month_counter <= 0 or day == 0:
        return None

    if month_counter % 12 != 0:
        year = month_counter // 12 + 15 + 2000
        month = month_counter % 12
    else:
        year = month_counter // 12 + 14 + 2000
        month = 12

    try:
        return datetime(year, month, day, hours, minutes, 0)
    except ValueError:
        return None


def parse_logbook_record(data: bytes) -> dict:
    """Parse a single 22-byte logbook (jump) record.

    Field layout (11 uint16 LE words):

      word0  (bytes 0-1):   Jump number (16 bits)
      word1  (bytes 2-3):   bits 0-7: month counter (8 bits, see overflow note),
                            bits 8-15: FF alarm index
      word2  (bytes 4-5):   bits 0-9: freefall time (seconds)
      word3  (bytes 6-7):   bits 0-5: minutes, bits 6-10: hours,
                            bit 15: aircraft index high bit
      word4  (bytes 8-9):   }  packed as uint32 with word5:
      word5  (bytes 10-11): }  bits 0-6/7-13/14-20/21-27: speeds (m/s)
                            bits 28-31 (word5 12-15): aircraft index low 4 bits
      word6  (bytes 12-13): bits 0-9: exit altitude, bits 10-14: day
      word7  (bytes 14-15): bits 0-9: deploy altitude, bits 10-14: DZ index
      word8  (bytes 16-17): bits 0-11: canopy time, bits 12-13: CP alarm high,
                            bits 14-15: LT index high
      word9  (bytes 18-19): bits 0-9: DZ altitude, bits 10-15: LT index low
      word10 (bytes 20-21): bits 0-3: SW revision, bits 4-7: CP alarm low,
                            byte 21: max speed

    Args:
        data: At least 22 bytes of logbook data.

    Returns:
        Dictionary with all parsed fields.
    """
    if len(data) < LOGBOOK_RECORD_SIZE:
        raise ValueError(f"Logbook record needs {LOGBOOK_RECORD_SIZE} bytes, got {len(data)}")

    w = _parse_word
    rec = {}

    # word0: jump number
    rec['jump_number'] = w(data, 0)

    # Read sw_major early (from word3) to decide word1 parsing strategy
    w3 = w(data, 6)
    rec['sw_major'] = (w3 >> 11) & 0x0F

    # word1: month counter + FF alarm index
    # Firmware < 1.0 has a bug: it writes month_counter as a full 8-bit
    # value, overflowing into the bit 7 "deleted" flag when mc >= 128
    # (August 2025).  For these records, we use all 8 bits as month_counter
    # and ignore the deleted flag.  Firmware >= 1.0 fixed this.
    w1 = w(data, 2)
    if rec['sw_major'] < 1:
        month_counter     = w1 & 0xFF
        rec['deleted']    = False
    else:
        month_counter     = w1 & 0x7F
        rec['deleted']    = bool(w1 & 0x80)
    ff_alarm_idx          = (w1 >> 8) & 0xFF
    rec['ff_alarms_off']  = bool(ff_alarm_idx & 0x80)
    rec['ff_alarm_index'] = ff_alarm_idx & 0x7F

    # word2: freefall time
    w2 = w(data, 4)
    rec['freefall_time'] = w2 & 0x3FF

    # word3: minutes, hours, aircraft high bit (sw_major already read above)
    rec['minutes']  = w3 & 0x3F
    rec['hours']    = (w3 >> 6) & 0x1F
    aircraft_hi     = (w3 >> 15) & 1

    # word4+word5: speeds and aircraft low bits
    w4 = w(data, 8)
    w5 = w(data, 10)
    speed_packed = ((w5 & 0xFFF) << 16) | w4
    rec['speed_3kft']  = speed_packed & 0x7F          # m/s
    rec['speed_6kft']  = (speed_packed >> 7) & 0x7F   # m/s
    rec['speed_9kft']  = (speed_packed >> 14) & 0x7F  # m/s
    rec['speed_12kft'] = (speed_packed >> 21) & 0x7F  # m/s
    aircraft_lo = (w5 >> 12) & 0x0F
    rec['aircraft_index'] = aircraft_hi * 16 + aircraft_lo

    # word6: exit altitude, day
    w6 = w(data, 12)
    exit_raw = w6 & 0x3FF
    rec['exit_alt_raw'] = exit_raw
    rec['exit_alt_m']   = exit_raw * 16
    rec['exit_alt_ft']  = int(exit_raw * 16 * 3.28084)
    rec['day'] = (w6 >> 10) & 0x1F

    # word7: deploy altitude, DZ name index
    w7 = w(data, 14)
    deploy_raw = w7 & 0x3FF
    rec['deploy_alt_raw'] = deploy_raw
    rec['deploy_alt_m']   = deploy_raw * 16
    rec['deploy_alt_ft']  = int(deploy_raw * 16 * 3.28084)
    rec['dz_name_index']  = (w7 >> 10) & 0x1F

    # word8: canopy time, CP alarm high, LT index high
    w8 = w(data, 16)
    rec['canopy_time'] = w8 & 0xFFF
    cp_alarm_hi = (w8 >> 12) & 0x03
    lt_hi       = (w8 >> 14) & 0x03

    # word9: DZ altitude, LT index low
    w9 = w(data, 18)
    dz_alt_raw = w9 & 0x3FF
    rec['dz_alt_raw'] = dz_alt_raw
    rec['dz_alt_m']   = dz_alt_raw * 4 - 640
    rec['dz_alt_ft']  = int(rec['dz_alt_m'] * 3.28084)
    lt_lo = (w9 >> 10) & 0x3F
    rec['lt_index'] = lt_hi * 64 + lt_lo

    # word10: SW revision, CP alarm low, max speed
    rec['sw_revision'] = data[20] & 0x0F
    rec['sw_minor']    = (w2 >> 10) & 0x3F
    cp_alarm_lo = (data[20] >> 4) & 0x0F
    rec['canopy_alarm_index'] = cp_alarm_hi * 16 + cp_alarm_lo
    rec['canopy_alarm_off']   = bool(cp_alarm_hi)
    rec['max_speed'] = data[21]

    rec['sw_version'] = f"{rec['sw_major']}.{rec['sw_minor']}.{rec['sw_revision']}"

    # Date reconstruction from month counter
    rec['month_counter'] = month_counter
    rec['date'] = _month_counter_to_date(
        month_counter, rec['day'], rec['hours'], rec['minutes'])

    # For old firmware, also detect empty/zeroed records
    if not rec['deleted'] and rec['jump_number'] == 0:
        rec['deleted'] = True

    # Average speed (vertical m/s, computed from altitude drop / freefall time)
    if rec['freefall_time'] > 0:
        alt_drop = rec['exit_alt_m'] - rec['deploy_alt_m']
        rec['avg_speed_ms'] = (alt_drop + rec['freefall_time'] // 2) // rec['freefall_time']
    else:
        rec['avg_speed_ms'] = 0

    return rec


def format_logbook_record(rec: dict,
                          aircraft_names: list[str] | None = None,
                          dz_names: list[str] | None = None,
                          alarm_names: dict[int, str] | None = None) -> str:
    """Format a parsed logbook record as a human-readable string.

    If name tables are provided, indices are resolved to names.
    """
    if aircraft_names is None:
        aircraft_names = DEFAULT_AIRCRAFT_NAMES
    if dz_names is None:
        dz_names = DEFAULT_DZ_NAMES

    ac_idx = rec['aircraft_index']
    ac_name = aircraft_names[ac_idx] if ac_idx < len(aircraft_names) else f"Index {ac_idx}"
    dz_idx = rec['dz_name_index']
    dz_name = dz_names[dz_idx] if dz_idx < len(dz_names) else f"Index {dz_idx}"

    ff_name = get_alarm_name(rec['ff_alarm_index'], is_cp=False, custom_names=alarm_names)
    if rec['ff_alarms_off']:
        ff_name = "Deactivated"
    cp_name = get_alarm_name(rec['canopy_alarm_index'], is_cp=True, custom_names=alarm_names)
    if rec['canopy_alarm_off']:
        cp_name = "Deactivated"

    lines = []
    lines.append(f"  Jump #{rec['jump_number']}" +
                 (" [DELETED]" if rec['deleted'] else ""))

    if rec.get('date'):
        lines.append(f"  Date:        {rec['date']:%Y-%m-%d %H:%M}")
    else:
        lines.append(f"  Time:        {rec['hours']:02d}:{rec['minutes']:02d}, Day {rec['day']}")

    ff_min, ff_sec = divmod(rec['freefall_time'], 60)
    cp_min, cp_sec = divmod(rec['canopy_time'], 60)
    lines.append(f"  Freefall:    {rec['freefall_time']}s ({ff_min}m {ff_sec:02d}s)")
    lines.append(f"  Canopy:      {rec['canopy_time']}s ({cp_min}m {cp_sec:02d}s)")
    lines.append(f"  Exit Alt:    {rec['exit_alt_ft']} ft ({rec['exit_alt_m']} m)")
    lines.append(f"  Deploy Alt:  {rec['deploy_alt_ft']} ft ({rec['deploy_alt_m']} m)")
    lines.append(f"  DZ Alt:      {rec['dz_alt_ft']} ft ({rec['dz_alt_m']} m)")

    speed_parts = []
    for label, key in [("3K", 'speed_3kft'), ("6K", 'speed_6kft'),
                        ("9K", 'speed_9kft'), ("12K", 'speed_12kft')]:
        v = rec[key]
        if v:
            mph = round(v * 2.237)
            kmh = round(v * 3.6)
            speed_parts.append(f"{label}={mph}mph/{kmh}kmh")
    if speed_parts:
        lines.append(f"  Speeds:      {', '.join(speed_parts)}")

    max_mph = round(rec['max_speed'] * 2.237)
    lines.append(f"  Max Speed:   {rec['max_speed']} m/s ({max_mph} mph)")

    lines.append(f"  Aircraft:    {ac_name} (#{ac_idx})")
    lines.append(f"  Drop Zone:   {dz_name} (#{dz_idx})")
    lines.append(f"  FF Alarm:    {ff_name}")
    lines.append(f"  CP Alarm:    {cp_name}")
    lines.append(f"  FW Version:  {rec['sw_version']}")
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------

CSV_HEADER = (
    "Jump Number,Date,Time,"
    "Exit Alt (m),Exit Alt (ft),Deploy Alt (m),Deploy Alt (ft),"
    "DZ Alt (m),DZ Alt (ft),"
    "Freefall Time,Canopy Time,"
    "Speed 3K (mph),Speed 6K (mph),Speed 9K (mph),Speed 12K (mph),Average Speed (mph),"
    "Speed 3K (kmh),Speed 6K (kmh),Speed 9K (kmh),Speed 12K (kmh),Average Speed (kmh),"
    "Max Speed (m/s),Max Speed (mph),"
    "Aircraft,Drop Zone,FF Alarm,CP Alarm,Deleted"
)


def logbook_record_to_csv_row(rec: dict,
                               aircraft_names: list[str] | None = None,
                               dz_names: list[str] | None = None,
                               alarm_names: dict[int, str] | None = None) -> str:
    """Convert a parsed logbook record to a CSV row string."""
    if aircraft_names is None:
        aircraft_names = DEFAULT_AIRCRAFT_NAMES
    if dz_names is None:
        dz_names = DEFAULT_DZ_NAMES

    ac_idx = rec['aircraft_index']
    ac_name = aircraft_names[ac_idx] if ac_idx < len(aircraft_names) else f"Index {ac_idx}"
    dz_idx = rec['dz_name_index']
    dz_name = dz_names[dz_idx] if dz_idx < len(dz_names) else f"Index {dz_idx}"

    ff_name = get_alarm_name(rec['ff_alarm_index'], is_cp=False, custom_names=alarm_names)
    if rec['ff_alarms_off']:
        ff_name = "Deactivated"
    cp_name = get_alarm_name(rec['canopy_alarm_index'], is_cp=True, custom_names=alarm_names)
    if rec['canopy_alarm_off']:
        cp_name = "Deactivated"

    dt = rec.get('date')
    date_str = f"{dt:%Y-%m-%d}" if dt else ""
    time_str = f"{dt:%H:%M:%S}" if dt else f"{rec['hours']:02d}:{rec['minutes']:02d}:00"

    s3  = round(rec['speed_3kft'] * 2.237)
    s6  = round(rec['speed_6kft'] * 2.237)
    s9  = round(rec['speed_9kft'] * 2.237)
    s12 = round(rec['speed_12kft'] * 2.237)
    avg_mph = round(rec.get('avg_speed_ms', 0) * 2.237)

    s3k  = round(rec['speed_3kft'] * 3.6)
    s6k  = round(rec['speed_6kft'] * 3.6)
    s9k  = round(rec['speed_9kft'] * 3.6)
    s12k = round(rec['speed_12kft'] * 3.6)
    avg_kmh = round(rec.get('avg_speed_ms', 0) * 3.6)

    max_mph = round(rec['max_speed'] * 2.237)

    return (
        f"{rec['jump_number']},{date_str},{time_str},"
        f"{rec['exit_alt_m']},{rec['exit_alt_ft']},{rec['deploy_alt_m']},{rec['deploy_alt_ft']},"
        f"{rec['dz_alt_m']},{rec['dz_alt_ft']},"
        f"{rec['freefall_time']},{rec['canopy_time']},"
        f"{s3},{s6},{s9},{s12},{avg_mph},"
        f"{s3k},{s6k},{s9k},{s12k},{avg_kmh},"
        f"{rec['max_speed']},{max_mph},"
        f"\"{ac_name}\",\"{dz_name}\",\"{ff_name}\",\"{cp_name}\","
        f"{'Yes' if rec['deleted'] else 'No'}"
    )
