"""
Serial communication with Alti-2 altimeter devices.

Communication flow:
  1. Open serial port (57600 baud, 8N1, RTS/CTS flow control)
  2. DTR toggle to wake the device, then wait
  3. Send ASCII command "018080" to request Type 0 record
  4. Receive Type 0 as space-separated ASCII hex (32 groups)
  5. Generate XTEA session key from Type 0 + product ID
  6. Send/receive XTEA-encrypted 32-byte packets for memory R/W
  7. End communication with ASCII \\x01EXIT command

The device has an idle timeout (~10-15s) after which it exits
communication mode.  A background keepalive thread sends periodic
pings to prevent this.  If communication is lost anyway, public
methods auto-reconnect as a fallback.
"""

import time
import struct
import logging
import threading

import serial

from .crypto import xtea_encrypt, xtea_decrypt, build_session_key
from .protocol import (
    build_ascii_command, build_read_command, build_write_command,
    build_datetime_command,
    pad_to_32, parse_type_zero, parse_datetime_response,
    parse_fram_name, fram_name_address, encode_fram_name,
    parse_settings, encode_settings,
    CMD_GET_TYPE_ZERO,
    ACK_OK, ACK_READY, ACK_REPEAT, ACK_EEPROM_ERROR, ACK_OUT_OF_BOUNDS,
    ACK_NAMES,
    FRAM_AIRCRAFT_NAMES_ADDR, FRAM_DZ_NAMES_ADDR, FRAM_ALARM_NAMES_ADDR,
    FRAM_NAME_ENTRY_SIZE, FRAM_NAME_COUNT, FRAM_NAME_HEADER_SIZE,
    FRAM_SETTINGS_ADDR, FRAM_SETTINGS_SIZE,
    WRITE_MAX_PAYLOAD,
    DEFAULT_AIRCRAFT_NAMES, DEFAULT_DZ_NAMES, DEFAULT_ALARM_NAMES,
)

logger = logging.getLogger(__name__)


FTDI_VID = 0x0403
FTDI_PID_FT232R = 0x6001


def _prefer_cu(device: str) -> str:
    """On macOS, prefer /dev/cu.* over /dev/tty.* for outgoing connections."""
    if device.startswith("/dev/tty."):
        import os
        cu = device.replace("/dev/tty.", "/dev/cu.", 1)
        if os.path.exists(cu):
            return cu
    return device


def auto_detect_port() -> str | None:
    """Auto-detect the serial port for an Alti-2 device.

    Detection strategy (in order):
      1. Look for a USB-serial device with FTDI VID:PID 0403:6001
         (the chip used in all known Alti-2 USB cables).
      2. Fall back to common USB-serial path-name patterns if
         pyserial's list_ports is unavailable.

    Works on macOS, Linux, and Windows.

    Returns:
        Port path string, or None if no suitable port was found.
    """
    try:
        import serial.tools.list_ports
        for p in serial.tools.list_ports.comports():
            if p.vid == FTDI_VID and p.pid == FTDI_PID_FT232R:
                return _prefer_cu(p.device)
    except ImportError:
        pass

    import sys, glob as _glob
    if sys.platform == "darwin":
        patterns = ["/dev/cu.usbserial-*", "/dev/cu.usbmodem*"]
    elif sys.platform == "linux":
        patterns = ["/dev/ttyUSB*", "/dev/ttyACM*"]
    else:
        return None

    for pattern in patterns:
        matches = _glob.glob(pattern)
        if matches:
            return matches[0]

    return None


class AltitoolError(Exception):
    """Base exception for pyaltitool communication errors."""
    pass


class AltitoolAckError(AltitoolError):
    """Device returned an unexpected acknowledgement."""
    def __init__(self, expected: int, received: int):
        self.expected = expected
        self.received = received
        exp_name = ACK_NAMES.get(expected, f"0x{expected:02X}")
        rcv_name = ACK_NAMES.get(received, f"0x{received:02X}")
        super().__init__(f"Expected ACK {exp_name}, got {rcv_name}")


class AltitoolDevice:
    """Communicate with an Alti-2 altimeter device via serial port.

    A background daemon thread sends keepalive pings every few seconds
    to prevent the device's idle timeout.  If communication is lost
    despite this, commands auto-reconnect transparently (DTR wake +
    handshake, ~4-5 seconds).

    Usage:
        port = auto_detect_port()          # or pass explicitly
        with AltitoolDevice(port) as dev:
            info = dev.connect()
            data = dev.read_memory(0x0000, 64)
    """

    BAUDRATE = 57600
    TIMEOUT = 10.0
    PACKET_SIZE = 32
    _KEEPALIVE_INTERVAL = 5.0

    def __init__(self, port: str):
        self.port_path = port
        self._serial: serial.Serial = None
        self._session_key: bytes = None
        self._type_zero: dict = None
        self._connected = False
        self._lock = threading.Lock()
        self._last_activity = 0.0
        self._keepalive_stop = threading.Event()
        self._keepalive_thread: threading.Thread = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.disconnect()

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def type_zero(self) -> dict:
        return self._type_zero

    @property
    def session_key(self) -> bytes:
        return self._session_key

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> dict:
        """Open port, wake device, perform handshake, start keepalive.

        Returns:
            Parsed Type 0 record dictionary.
        """
        with self._lock:
            self._open_port()
            self._wake_device()
            self._handshake()
            self._last_activity = time.time()
        self._start_keepalive()
        return self._type_zero

    def reconnect(self) -> dict:
        """Re-establish communication with full DTR wake.

        Keeps the serial port open but re-runs the DTR wake and
        handshake.  Must be called with self._lock held.
        """
        logger.info("Reconnecting...")
        self._connected = False

        if not self._serial or not self._serial.is_open:
            self._open_port()

        self._flush_remaining()
        self._wake_device()
        self._handshake()
        self._last_activity = time.time()
        return self._type_zero

    def force_reconnect(self):
        """Force a reconnection (acquire lock internally).

        Useful between successive large reads — the device's serial
        state becomes unreliable after multi-packet exchanges.
        """
        with self._lock:
            self.reconnect()

    def disconnect(self):
        """Stop keepalive, end communication, close serial port."""
        self._stop_keepalive()

        with self._lock:
            if self._connected:
                try:
                    self._end_communication()
                except Exception as e:
                    logger.warning(f"Error during end-communication: {e}")
                self._connected = False

            if self._serial and self._serial.is_open:
                try:
                    self._serial.close()
                    logger.info("Serial port closed.")
                except Exception as e:
                    logger.warning(f"Error closing port: {e}")
                self._serial = None

    # ------------------------------------------------------------------
    # Keepalive
    # ------------------------------------------------------------------

    def _start_keepalive(self):
        self._stop_keepalive()
        self._keepalive_stop.clear()
        t = threading.Thread(target=self._keepalive_loop, daemon=True)
        t.start()
        self._keepalive_thread = t
        logger.debug("Keepalive thread started")

    def _stop_keepalive(self):
        self._keepalive_stop.set()
        t = self._keepalive_thread
        if t is not None:
            t.join(timeout=3)
            self._keepalive_thread = None
        logger.debug("Keepalive thread stopped")

    def _keepalive_loop(self):
        while not self._keepalive_stop.wait(timeout=1.0):
            if not self._connected:
                continue
            elapsed = time.time() - self._last_activity
            if elapsed < self._KEEPALIVE_INTERVAL:
                continue
            if not self._lock.acquire(timeout=0.1):
                continue
            try:
                if not self._connected:
                    continue
                logger.debug(f"Keepalive ping (idle {elapsed:.1f}s)...")
                self._keepalive_ping()
                self._last_activity = time.time()
                logger.debug("Keepalive OK")
            except Exception as e:
                logger.info(f"Keepalive failed ({e}), device timed out")
                self._connected = False
            finally:
                self._lock.release()

    def _keepalive_ping(self):
        """Send A2 (read datetime) as a lightweight keepalive probe."""
        packet = build_datetime_command()
        self._send_encrypted(packet)
        ack1 = self._read_ack()
        if ack1 != ACK_OK:
            raise AltitoolError(f"Keepalive: unexpected ACK 0x{ack1:02X}")
        ack2 = self._read_ack()
        if ack2 != ACK_READY:
            raise AltitoolError(f"Keepalive: no READY")
        self._recv_encrypted()
        self._send_ack(ACK_OK)

    # ------------------------------------------------------------------
    # Command wrapper with reconnect fallback
    # ------------------------------------------------------------------

    _RECOVERABLE_ERRORS = ("CTS timeout", "Timeout", "Short read")

    def _with_reconnect(self, fn):
        """Acquire lock, execute fn(); reconnect once on failure."""
        with self._lock:
            if not self._connected:
                logger.info("Not connected, reconnecting before command...")
                self.reconnect()
            try:
                result = fn()
                self._last_activity = time.time()
                return result
            except AltitoolError as e:
                msg = str(e)
                if any(kw in msg for kw in self._RECOVERABLE_ERRORS):
                    logger.info(f"Communication lost ({e}), reconnecting...")
                    self.reconnect()
                    result = fn()
                    self._last_activity = time.time()
                    return result
                raise

    # ------------------------------------------------------------------
    # Memory read (A0 command)
    # ------------------------------------------------------------------

    def read_memory(self, address: int, length: int) -> bytes:
        """Read a block of memory from the device.

        Args:
            address: 32-bit memory start address.
            length:  Number of bytes to read (1..65535).

        Returns:
            The requested memory bytes.
        """
        if length < 1 or length > 0xFFFF:
            raise ValueError(f"Read length must be 1..65535, got {length}")
        return self._with_reconnect(lambda: self._read_memory_impl(address, length))

    def _read_memory_impl(self, address: int, length: int) -> bytes:
        logger.info(f"Reading {length} bytes from 0x{address:08X}...")
        self._flush_remaining()
        packet = build_read_command(address, length)

        MAX_RETRIES = 5
        for attempt in range(MAX_RETRIES):
            if attempt > 0:
                logger.info(f"  Retrying read command (attempt {attempt+1}/{MAX_RETRIES})...")
                time.sleep(0.3)

            self._send_encrypted(packet)

            ack1 = self._read_ack()
            if ack1 == ACK_OK:
                break
            elif ack1 == ACK_REPEAT:
                logger.debug(f"Got REPEAT on attempt {attempt+1}, resending...")
                continue
            else:
                raise AltitoolAckError(ACK_OK, ack1)
        else:
            raise AltitoolError(f"Read command not accepted after {MAX_RETRIES} attempts")

        ack2 = self._read_ack()
        if ack2 != ACK_READY:
            raise AltitoolAckError(ACK_READY, ack2)

        total_bytes = length + 4
        num_packets = (total_bytes + self.PACKET_SIZE - 1) // self.PACKET_SIZE

        all_data = bytearray()
        for i in range(num_packets):
            decrypted = self._recv_encrypted()
            all_data.extend(decrypted)
            self._send_ack(ACK_OK)
            logger.debug(f"Packet {i+1}/{num_packets} OK")

        echo_addr = struct.unpack_from('<I', all_data, 0)[0]
        if echo_addr != address:
            logger.warning(
                f"Address echo mismatch: expected 0x{address:08X}, "
                f"got 0x{echo_addr:08X}")

        time.sleep(0.1)
        result = bytes(all_data[4:4 + length])
        logger.info(f"Read complete: {len(result)} bytes")
        return result

    # ------------------------------------------------------------------
    # Read date/time (A2 command)
    # ------------------------------------------------------------------

    def read_datetime(self):
        """Read the current date and time from the device.

        Returns:
            datetime object with the device's current date/time.
        """
        return self._with_reconnect(self._read_datetime_impl)

    def _read_datetime_impl(self):
        logger.info("Reading device date/time (A2 command)...")
        packet = build_datetime_command()
        self._send_encrypted(packet)

        ack1 = self._read_ack()
        if ack1 == ACK_OK:
            pass
        elif ack1 == ACK_REPEAT:
            self._send_encrypted(packet)
            ack1 = self._read_ack()
            if ack1 != ACK_OK:
                raise AltitoolAckError(ACK_OK, ack1)
        else:
            raise AltitoolAckError(ACK_OK, ack1)

        ack2 = self._read_ack()
        if ack2 != ACK_READY:
            raise AltitoolAckError(ACK_READY, ack2)

        decrypted = self._recv_encrypted()
        self._send_ack(ACK_OK)

        dt = parse_datetime_response(decrypted)
        if dt is None:
            raise AltitoolError(
                f"Failed to parse date/time from response: {decrypted.hex(' ')}")

        logger.info(f"Device date/time: {dt}")
        return dt

    # ------------------------------------------------------------------
    # Read FRAM names
    # ------------------------------------------------------------------

    def read_fram_name(self, base_addr: int, index: int) -> str | None:
        """Read a single name entry from the device's FRAM."""
        addr = fram_name_address(base_addr, index)
        data = self.read_memory(addr, FRAM_NAME_ENTRY_SIZE)
        return parse_fram_name(data)

    def read_names(self, base_addr: int, defaults: list[str],
                   indices: list[int] | None = None) -> dict[int, str]:
        """Read name entries from FRAM, falling back to defaults.

        Reads the entire 320-byte name table in one bulk operation
        instead of 32 individual reads.
        """
        if indices is None:
            indices = list(range(FRAM_NAME_COUNT))

        start_addr = base_addr + FRAM_NAME_HEADER_SIZE
        total_len = FRAM_NAME_COUNT * FRAM_NAME_ENTRY_SIZE
        try:
            data = self.read_memory(start_addr, total_len)
        except AltitoolError as e:
            logger.warning(f"Bulk name read failed ({e}), using defaults")
            return {i: defaults[i] if i < len(defaults) else f"Index {i}"
                    for i in indices if 0 <= i < FRAM_NAME_COUNT}

        result = {}
        for idx in indices:
            if idx < 0 or idx >= FRAM_NAME_COUNT:
                continue
            offset = idx * FRAM_NAME_ENTRY_SIZE
            chunk = data[offset:offset + FRAM_NAME_ENTRY_SIZE]
            if len(chunk) < FRAM_NAME_ENTRY_SIZE:
                result[idx] = defaults[idx] if idx < len(defaults) else f"Index {idx}"
                continue
            name = parse_fram_name(chunk)
            if name:
                result[idx] = name
            else:
                result[idx] = defaults[idx] if idx < len(defaults) else f"Index {idx}"
        return result

    def read_aircraft_names(self, indices: list[int] | None = None) -> dict[int, str]:
        """Read aircraft names from FRAM."""
        return self.read_names(FRAM_AIRCRAFT_NAMES_ADDR, DEFAULT_AIRCRAFT_NAMES, indices)

    def read_dz_names(self, indices: list[int] | None = None) -> dict[int, str]:
        """Read drop zone names from FRAM."""
        return self.read_names(FRAM_DZ_NAMES_ADDR, DEFAULT_DZ_NAMES, indices)

    def read_alarm_names(self, indices: list[int] | None = None) -> dict[int, str]:
        """Read alarm names from FRAM."""
        return self.read_names(FRAM_ALARM_NAMES_ADDR, DEFAULT_ALARM_NAMES, indices)

    # ------------------------------------------------------------------
    # Memory write (B0 command)
    #
    # WARNING: All write operations below are UNTESTED on real hardware.
    # The B0 command format and ACK sequence are inferred from the
    # protocol documentation and by analogy with the A0 read command.
    # The official tool never sends B0 commands.
    # ------------------------------------------------------------------

    def write_memory(self, address: int, data: bytes) -> None:
        """Write a block of data to the device's FRAM.

        Automatically splits writes exceeding 25 bytes into multiple
        B0 commands at sequential addresses.

        .. warning::
            UNTESTED — the B0 write protocol has not been verified on
            real hardware.  Back up device data before use.

        Args:
            address: 32-bit FRAM start address.
            data:    Bytes to write.
        """
        if not data:
            raise ValueError("Cannot write empty data")
        self._with_reconnect(lambda: self._write_memory_impl(address, data))

    def _write_memory_impl(self, address: int, data: bytes) -> None:
        self._flush_remaining()
        offset = 0
        while offset < len(data):
            chunk = data[offset:offset + WRITE_MAX_PAYLOAD]
            cur_addr = address + offset
            logger.info(
                f"Writing {len(chunk)} bytes to 0x{cur_addr:08X}...")

            packet = build_write_command(cur_addr, chunk)

            MAX_RETRIES = 5
            for attempt in range(MAX_RETRIES):
                if attempt > 0:
                    logger.info(
                        f"  Retrying write (attempt {attempt + 1}/{MAX_RETRIES})...")
                    time.sleep(0.3)

                self._send_encrypted(packet)
                ack = self._read_ack()

                if ack == ACK_OK:
                    break
                elif ack == ACK_REPEAT:
                    logger.debug(f"Got REPEAT on attempt {attempt + 1}")
                    continue
                elif ack == ACK_EEPROM_ERROR:
                    raise AltitoolError(
                        f"EEPROM/FRAM write error at 0x{cur_addr:08X}")
                elif ack == ACK_OUT_OF_BOUNDS:
                    raise AltitoolError(
                        f"Address out of bounds: 0x{cur_addr:08X}")
                else:
                    raise AltitoolAckError(ACK_OK, ack)
            else:
                raise AltitoolError(
                    f"Write not accepted after {MAX_RETRIES} attempts "
                    f"at 0x{cur_addr:08X}")

            time.sleep(0.05)
            offset += len(chunk)

        logger.info(f"Write complete: {len(data)} bytes to 0x{address:08X}")

    # ------------------------------------------------------------------
    # Write FRAM names
    # ------------------------------------------------------------------

    def write_fram_name(self, base_addr: int, index: int,
                        name: str) -> None:
        """Write a single name entry to the device's FRAM.

        Args:
            base_addr: Base address of the name table.
            index:     Entry index (0..31).
            name:      Name string (max 10 ASCII characters).
        """
        if index < 0 or index >= FRAM_NAME_COUNT:
            raise ValueError(f"Name index must be 0..{FRAM_NAME_COUNT - 1}")
        addr = fram_name_address(base_addr, index)
        data = encode_fram_name(name)
        self.write_memory(addr, data)

    def write_aircraft_name(self, index: int, name: str) -> None:
        """Write an aircraft name to the device."""
        self.write_fram_name(FRAM_AIRCRAFT_NAMES_ADDR, index, name)

    def write_dz_name(self, index: int, name: str) -> None:
        """Write a drop zone name to the device."""
        self.write_fram_name(FRAM_DZ_NAMES_ADDR, index, name)

    def write_alarm_name(self, index: int, name: str) -> None:
        """Write an alarm name to the device."""
        self.write_fram_name(FRAM_ALARM_NAMES_ADDR, index, name)

    # ------------------------------------------------------------------
    # Device settings
    # ------------------------------------------------------------------

    def read_settings(self) -> dict:
        """Read device settings from FRAM.

        Returns:
            Dictionary with parsed settings (see protocol.parse_settings).
        """
        return self._with_reconnect(self._read_settings_impl)

    def _read_settings_impl(self) -> dict:
        data = self._read_memory_impl(FRAM_SETTINGS_ADDR, FRAM_SETTINGS_SIZE)
        return parse_settings(data)

    def read_settings_raw(self) -> bytes:
        """Read raw device settings bytes from FRAM."""
        return self._with_reconnect(
            lambda: self._read_memory_impl(FRAM_SETTINGS_ADDR, FRAM_SETTINGS_SIZE))

    def write_settings(self, settings: dict,
                       base: bytes | None = None) -> None:
        """Write device settings to FRAM using read-modify-write.

        If ``base`` is not provided, current settings are read first so
        that unspecified fields are preserved.

        .. warning::
            UNTESTED — settings layout is from the N3/N3A protocol spec
            and may differ on Atlas 2.  The official tool never reads or
            writes settings.

        Args:
            settings: Dict of setting name → value to change.
            base:     Optional existing raw settings bytes (13 bytes).
                      If None, reads current settings from device first.
        """
        def _impl():
            nonlocal base
            if base is None:
                base = self._read_memory_impl(
                    FRAM_SETTINGS_ADDR, FRAM_SETTINGS_SIZE)
            encoded = encode_settings(settings, base)
            self._write_memory_impl(FRAM_SETTINGS_ADDR, encoded)

        self._with_reconnect(_impl)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _open_port(self):
        if self._serial and self._serial.is_open:
            return
        logger.info(f"Opening {self.port_path} at {self.BAUDRATE} baud...")
        self._serial = serial.Serial(
            port=self.port_path,
            baudrate=self.BAUDRATE,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=self.TIMEOUT,
            rtscts=True,
        )
        self._serial.dtr = True
        self._serial.rts = True
        logger.info("Serial port opened.")

    def _wake_device(self):
        logger.info("Waking device (DTR toggle)...")
        self._serial.dtr = False
        time.sleep(2.0)
        self._serial.dtr = True
        time.sleep(2.0)
        logger.info("DTR wake sequence completed")

    def _handshake(self):
        cmd = build_ascii_command(CMD_GET_TYPE_ZERO)

        for attempt in range(3):
            self._serial.reset_input_buffer()
            logger.info(f"Sending Get Type 0 command: {cmd!r} (attempt {attempt+1}/3)")
            self._serial.write(cmd)
            self._serial.flush()

            type_zero_raw = self._read_type_zero_response(timeout=6.0)
            if type_zero_raw is not None:
                break

            if attempt < 2:
                logger.info(f"No Type 0 response, retrying ({attempt+1}/3)...")
        else:
            raise AltitoolError("No Type 0 response after 3 attempts")

        self._type_zero = parse_type_zero(type_zero_raw)

        pid = self._type_zero['product_id']
        self._session_key = build_session_key(type_zero_raw, pid)
        self._connected = True

        time.sleep(0.1)

        logger.info(
            f"Handshake OK: {self._type_zero['product_name']} "
            f"S/N={self._type_zero['serial_number']} "
            f"FW={self._type_zero['sw_version']}")
        logger.debug(f"Session key: {self._session_key.hex(' ')}")

    def _read_type_zero_response(self, timeout: float = 6.0) -> bytes | None:
        buf = b''
        deadline = time.time() + timeout

        while time.time() < deadline:
            waiting = self._serial.in_waiting
            if waiting > 0:
                chunk = self._serial.read(waiting)
                buf += chunk
                logger.debug(f"Type0 rx: +{len(chunk)} bytes (total {len(buf)})")

                text = buf.decode('ascii', errors='replace')
                text = text.replace('\r', '').replace('\n', '').strip()
                groups = text.split()

                if len(groups) >= 32:
                    try:
                        raw = bytes(int(g, 16) for g in groups[:32])
                        logger.debug(f"Type 0 raw: {raw.hex(' ')}")
                        time.sleep(0.1)
                        self._serial.reset_input_buffer()
                        return raw
                    except ValueError as e:
                        logger.debug(f"Hex parse error: {e}, waiting for more data...")
            else:
                time.sleep(0.05)

        if buf:
            logger.warning(f"Type 0 partial response ({len(buf)} bytes): {buf!r}")
        return None

    def _send_encrypted(self, packet: bytes):
        padded = pad_to_32(packet)
        encrypted = xtea_encrypt(padded, self._session_key)
        self._send_bytes_with_flow_control(encrypted)
        logger.debug(f"TX encrypted [{len(encrypted)}]: {encrypted.hex(' ')}")

    def _send_bytes_with_flow_control(self, data: bytes):
        for i, byte_val in enumerate(data):
            deadline = time.time() + 2.0
            while not self._serial.cts:
                if time.time() > deadline:
                    raise AltitoolError("CTS timeout - device not ready to receive")
                time.sleep(0.002)
            self._serial.write(bytes([byte_val]))
            if i % 8 == 0:
                time.sleep(0.001)
        self._serial.flush()
        time.sleep(0.005)

    def _recv_encrypted(self) -> bytes:
        buf = bytearray()
        deadline = time.time() + self.TIMEOUT

        while len(buf) < self.PACKET_SIZE and time.time() < deadline:
            need = self.PACKET_SIZE - len(buf)
            chunk = self._serial.read(need)
            if not chunk:
                raise AltitoolError(
                    f"Timeout: got {len(buf)}/{self.PACKET_SIZE} encrypted bytes")
            if not buf:
                chunk = chunk.lstrip(b'\x00\r\n')
                if not chunk:
                    continue
            buf.extend(chunk)

        if len(buf) < self.PACKET_SIZE:
            raise AltitoolError(
                f"Short read: got {len(buf)}/{self.PACKET_SIZE} encrypted bytes "
                f"(data: {bytes(buf).hex(' ')})")

        raw = bytes(buf[:self.PACKET_SIZE])
        decrypted = xtea_decrypt(raw, self._session_key)
        logger.debug(f"RX encrypted [{len(raw)}]: {raw.hex(' ')}")
        logger.debug(f"   decrypted: {decrypted.hex(' ')}")
        return decrypted

    def _read_ack(self) -> int:
        deadline = time.time() + self.TIMEOUT
        while time.time() < deadline:
            data = self._serial.read(1)
            if len(data) != 1:
                raise AltitoolError("Timeout waiting for ACK byte")
            b = data[0]
            if b in (0x00, 0x0D, 0x0A):
                logger.debug(f"Skipping leading byte 0x{b:02X}")
                continue
            name = ACK_NAMES.get(b, f"0x{b:02X}")
            logger.debug(f"RX ACK: {b} ({name})")
            return b
        raise AltitoolError("Timeout waiting for ACK byte (only got padding)")

    def _send_ack(self, ack_code: int = ACK_OK):
        self._serial.write(bytes([ack_code]))
        logger.debug(f"TX ACK: {ack_code}")

    def _end_communication(self):
        logger.info("Ending communication...")
        exit_cmd = b'\x01EXIT'
        try:
            self._send_bytes_with_flow_control(exit_cmd)
        except AltitoolError:
            pass

        try:
            time.sleep(0.5)
            waiting = self._serial.in_waiting
            if waiting > 0:
                resp = self._serial.read(waiting)
                logger.debug(f"Exit response: {resp.hex(' ')}")
                self._send_ack(ACK_OK)
        except Exception as e:
            logger.debug(f"Exit response read failed (non-critical): {e}")

        time.sleep(0.5)
        self._flush_remaining()
        logger.info("End-communication sequence sent.")

    def _flush_remaining(self):
        try:
            while self._serial and self._serial.is_open and self._serial.in_waiting > 0:
                self._serial.read(self._serial.in_waiting)
                time.sleep(0.05)
        except Exception:
            pass
