"""pyaltitool — Unofficial Python library for communicating with Alti-2 skydiving altimeters.

Not affiliated with, endorsed by, or associated with Alti-2 Technologies.
https://github.com/5BytesHook/pyaltitool
"""

__version__ = "0.1.0"

from .device import AltitoolDevice, AltitoolError, AltitoolAckError, auto_detect_port
from .protocol import (
    PRODUCT_NAMES,
    LOGBOOK_RECORD_SIZE,
    parse_logbook_record,
    format_logbook_record,
    logbook_record_to_csv_row,
    CSV_HEADER,
    parse_type_zero,
    parse_datetime_response,
    parse_settings,
    encode_settings,
    parse_fram_name,
    encode_fram_name,
)

__all__ = [
    "AltitoolDevice",
    "AltitoolError",
    "AltitoolAckError",
    "auto_detect_port",
    "PRODUCT_NAMES",
    "LOGBOOK_RECORD_SIZE",
    "parse_logbook_record",
    "format_logbook_record",
    "logbook_record_to_csv_row",
    "CSV_HEADER",
    "parse_type_zero",
    "parse_datetime_response",
    "parse_settings",
    "encode_settings",
    "parse_fram_name",
    "encode_fram_name",
]
