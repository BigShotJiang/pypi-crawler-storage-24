"""
XTEA encryption/decryption and session key generation for pyaltitool.

The Alti-2 protocol uses XTEA (eXtended Tiny Encryption Algorithm) with:
  - 16 rounds per block
  - 4 blocks of 8 bytes = 32 bytes per encrypt/decrypt operation
  - 16-byte key derived from the Type 0 record and product ID

Key generation uses product-specific seed bytes combined with bytes
from the Type 0 record returned by the device during initial handshake.
"""

import struct


# -- XTEA Constants --
_DELTA = 0x9E3779B9
_MASK = 0xFFFFFFFF
_ROUNDS = 16
_BLOCK_SIZE = 8   # bytes per XTEA block
_NUM_BLOCKS = 4   # blocks per 32-byte packet
_PACKET_SIZE = _BLOCK_SIZE * _NUM_BLOCKS  # 32 bytes


def xtea_encrypt(data: bytes, key: bytes) -> bytes:
    """Encrypt 32 bytes using XTEA with 16-byte key (16 rounds, 4 blocks).

    Args:
        data: 32 bytes of plaintext.
        key:  16 bytes encryption key.

    Returns:
        32 bytes of ciphertext.
    """
    if len(data) != _PACKET_SIZE:
        raise ValueError(f"Data must be {_PACKET_SIZE} bytes, got {len(data)}")
    if len(key) != 16:
        raise ValueError(f"Key must be 16 bytes, got {len(key)}")

    kw = struct.unpack('<4I', key)
    result = bytearray(_PACKET_SIZE)

    for blk in range(_NUM_BLOCKS):
        v0, v1 = struct.unpack_from('<2I', data, blk * _BLOCK_SIZE)
        s = 0
        for _ in range(_ROUNDS):
            # v0 += (((v1<<4) ^ (v1>>5)) + v1) ^ (sum + key[sum & 3])
            t = (((v1 << 4) & _MASK) ^ (v1 >> 5))
            t = (t + v1) & _MASK
            v0 = (v0 + (t ^ ((s + kw[s & 3]) & _MASK))) & _MASK
            s = (s + _DELTA) & _MASK
            # v1 += (((v0<<4) ^ (v0>>5)) + v0) ^ (sum + key[(sum>>11) & 3])
            t = (((v0 << 4) & _MASK) ^ (v0 >> 5))
            t = (t + v0) & _MASK
            v1 = (v1 + (t ^ ((s + kw[(s >> 11) & 3]) & _MASK))) & _MASK
        struct.pack_into('<2I', result, blk * _BLOCK_SIZE, v0, v1)

    return bytes(result)


def xtea_decrypt(data: bytes, key: bytes) -> bytes:
    """Decrypt 32 bytes using XTEA with 16-byte key (16 rounds, 4 blocks).

    Args:
        data: 32 bytes of ciphertext.
        key:  16 bytes encryption key.

    Returns:
        32 bytes of plaintext.
    """
    if len(data) != _PACKET_SIZE:
        raise ValueError(f"Data must be {_PACKET_SIZE} bytes, got {len(data)}")
    if len(key) != 16:
        raise ValueError(f"Key must be 16 bytes, got {len(key)}")

    kw = struct.unpack('<4I', key)
    result = bytearray(_PACKET_SIZE)

    for blk in range(_NUM_BLOCKS):
        v0, v1 = struct.unpack_from('<2I', data, blk * _BLOCK_SIZE)
        s = (_DELTA * _ROUNDS) & _MASK  # 0xE3779B90 for 16 rounds
        for _ in range(_ROUNDS):
            # v1 -= (((v0<<4) ^ (v0>>5)) + v0) ^ (sum + key[(sum>>11) & 3])
            t = (((v0 << 4) & _MASK) ^ (v0 >> 5))
            t = (t + v0) & _MASK
            v1 = (v1 - (t ^ ((s + kw[(s >> 11) & 3]) & _MASK))) & _MASK
            s = (s - _DELTA) & _MASK
            # v0 -= (((v1<<4) ^ (v1>>5)) + v1) ^ (sum + key[sum & 3])
            t = (((v1 << 4) & _MASK) ^ (v1 >> 5))
            t = (t + v1) & _MASK
            v0 = (v0 - (t ^ ((s + kw[s & 3]) & _MASK))) & _MASK
        struct.pack_into('<2I', result, blk * _BLOCK_SIZE, v0, v1)

    return bytes(result)


# -- Product-specific key seeds --
_KEY_ATLAS = bytes([170, 105, 68])
_KEY_MA12 = bytes([56, 153, 207])
_KEY_JUNO = bytes([141, 175, 17])

_PRODUCT_KEY_MAP = {
    7:  _KEY_ATLAS,   # Atlas
    8:  _KEY_MA12,    # MA12
    9:  _KEY_MA12,    # MA12 mBar
    12: _KEY_ATLAS,   # Atlas2
    14: _KEY_JUNO,    # Atlas2 Juno
    15: _KEY_MA12,    # MA15A
}


def build_session_key(type_zero_raw: bytes, product_id: int) -> bytes:
    """Generate the 16-byte session key from Type 0 record and product ID.

    The key is assembled from 3 product-specific seed bytes interleaved
    with 13 bytes picked from specific positions in the Type 0 record.

    Args:
        type_zero_raw: The raw 32-byte Type 0 record from the device.
        product_id:    Product ID byte (type_zero_raw[15]).

    Returns:
        16-byte session key for XTEA encryption/decryption.
    """
    if len(type_zero_raw) < 27:
        raise ValueError(f"Type 0 record too short: {len(type_zero_raw)} bytes")

    seed = _PRODUCT_KEY_MAP.get(product_id, _KEY_MA12)
    r = type_zero_raw  # shorthand

    key = bytearray(16)
    key[0]  = seed[0]
    key[1]  = r[23]
    key[2]  = r[6]
    key[3]  = r[13]
    key[4]  = r[24]
    key[5]  = r[22]
    key[6]  = r[12]
    key[7]  = seed[1]
    key[8]  = r[7]
    key[9]  = r[8]
    key[10] = r[10]
    key[11] = seed[2]
    key[12] = r[9]
    key[13] = r[11]
    key[14] = r[26]
    key[15] = r[25]
    return bytes(key)


def self_test() -> bool:
    """Verify encrypt/decrypt roundtrip works correctly."""
    import os
    key = os.urandom(16)
    plaintext = os.urandom(32)
    ciphertext = xtea_encrypt(plaintext, key)
    decrypted = xtea_decrypt(ciphertext, key)
    assert decrypted == plaintext, "XTEA self-test FAILED: roundtrip mismatch"
    assert ciphertext != plaintext, "XTEA self-test FAILED: ciphertext equals plaintext"
    return True


if __name__ == '__main__':
    self_test()
    print("XTEA self-test passed.")
