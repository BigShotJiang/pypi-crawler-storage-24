"""VoxSession — the composition-based public API for Voxgraph SDK.

VoxSession **wraps** (not extends) a LiveKit AgentSession. This composition
pattern is more resilient to LiveKit API changes than inheritance.

Lean SDK: Only captures data the session report can't provide:
- Token counts (metrics_collected events)
- Context-tagged developer logs
- Prompt version + tags
- Cost tracking

Transcripts, latency, tool calls, events -> handled by ctx.make_session_report()

Usage:
    from voxgraph import VoxSession
    from livekit.agents import AgentSession

    session = AgentSession(stt=..., llm=..., tts=...)
    vox = VoxSession(
        session,
        api_key="vxg_abc123",
        agent_id="550e8400-e29b-41d4-a716-446655440000",
    )
    await vox.start(agent=MyAgent(), room=ctx.room)
"""

from __future__ import annotations

import dataclasses
import logging
import uuid
from typing import TYPE_CHECKING, Any

from voxgraph._compat import check_livekit_version, livekit_has_model_usage_collector
from voxgraph.config import VoxConfig, load_config
from voxgraph.context import TurnContext, _current_turn
from voxgraph.interceptor import attach_listeners, detach_listeners
from voxgraph.logger import install_vox_log_handler, uninstall_vox_log_handler
from voxgraph.audio_recorder import AudioRecorder
from voxgraph.models import SessionMeta
from voxgraph.telemetry import TelemetryCollector, TelemetrySender

if TYPE_CHECKING:
    from livekit.agents import AgentSession, JobContext
    from livekit.agents.voice.events import AgentEvent

__all__ = ["VoxSession"]

logger = logging.getLogger("voxgraph.session")


class VoxSession:
    """Observability wrapper for a LiveKit AgentSession.

    Composition pattern: takes an existing AgentSession and adds Voxgraph
    instrumentation without modifying the session's behavior.

    The SDK automatically detects the LiveKit JobContext and registers shutdown
    hooks, so the session report is always captured regardless of how the call ends.

    Args:
        session: The LiveKit AgentSession to observe.
        api_key: Voxgraph API key. Can also be set via the VOXGRAPH_API_KEY
            environment variable.
        agent_id: UUID of the voice AI agent (from the Voxgraph dashboard).
            Required for prompt fetch and usage attribution. Can also be set
            via VOXGRAPH_AGENT_ID.
        environment: Prompt branch to fetch (default: ``"main"``). Use
            ``"dev"`` or ``"staging"`` to test non-production prompts. Can
            also be set via VOXGRAPH_ENVIRONMENT.
        tags: Optional key-value metadata attached to the session report
            (e.g. ``{"customer_tier": "enterprise", "region": "us-east"}``)
        enable_recording: When ``True``, captures session audio (user mic +
            agent TTS) and uploads it to Voxgraph. The ``recording_url`` is
            included in the session report automatically. Defaults to
            ``False``.
    """

    def __init__(
        self,
        session: AgentSession,
        *,
        api_key: str | None = None,
        agent_id: str | None = None,
        environment: str | None = None,
        tags: dict[str, str] | None = None,
        enable_recording: bool = False,
    ) -> None:
        check_livekit_version()

        self._session = session
        self._session_id = f"vox_{uuid.uuid4().hex[:12]}"
        self._conversation_id = str(uuid.uuid4())
        self._ctx: JobContext | None = None
        self._is_started = False
        self._is_shutdown = False
        self._close_listener: Any = None
        self._enable_recording = enable_recording
        self._recorder: AudioRecorder | None = AudioRecorder() if enable_recording else None
        self._prompt_version: str = ""  # Auto-captured from API during prompt fetch
        self._turn_token: Any = None  # ContextVar token for resetting turn context

        # Load configuration (endpoint is always hardcoded to api.voxgraph.io)
        self._config = load_config(
            api_key=api_key,
            agent_id=agent_id,
            environment=environment,
            tags=tags,
        )

        # Initialize telemetry pipeline
        self._collector = TelemetryCollector(max_buffer_size=self._config.max_buffer_size)
        self._sender = TelemetrySender(self._config, self._collector)
        self._sender.set_session_id(self._session_id)
        self._sender.set_conversation_id(self._conversation_id)

        logger.info(
            "VoxSession created (id=%s, debug=%s)",
            self._session_id, self._config.debug,
        )


    @property
    def session(self) -> AgentSession:
        """Access the underlying LiveKit AgentSession."""
        return self._session

    @property
    def session_id(self) -> str:
        """The unique Voxgraph session identifier."""
        return self._session_id

    @property
    def conversation_id(self) -> str:
        """The UUID used to identify this conversation in the Voxgraph backend."""
        return self._conversation_id

    async def start(
        self,
        *,
        agent: Any,
        room: Any,
        room_options: Any | None = None,
        **kwargs: Any,
    ) -> None:
        """Start observability for this session.

        Starts the LiveKit session and attaches metrics + log instrumentation.

        Automatically captures the session report at call end via two layers:
          1. AgentSession 'close' event — fires for ALL termination reasons
             (disconnect, shutdown, error, task_complete).
          2. ctx.add_shutdown_callback — secondary safety net registered via
             get_job_context(), in case the session close event doesn't fire.

        Args:
            agent: The Agent instance to observe.
            room: The LiveKit Room instance.
            room_options: Optional RoomOptions for the session.
        """
        if self._is_started:
            logger.warning("VoxSession.start() called multiple times, ignoring.")
            return

        # 1a. Start the background telemetry sender (initializes the HTTP client
        #     needed by the recorder for S3 presigned URLs)
        await self._sender.start()

        # 1b. Attach audio recorder hook BEFORE session.start() so it intercepts
        #     session.output.audio the instant RoomIO sets it — before the agent
        #     activity (and first greeting) begins.
        if self._recorder is not None:
            try:
                self._recorder.attach(
                    session=self._session,
                    conversation_id=self._conversation_id,
                    http_client=self._sender._client,
                    endpoint=self._config.endpoint,
                )
            except Exception:
                logger.exception("AudioRecorder failed to attach — recording disabled for this session")
                self._recorder = None

        # 1c. Start the LiveKit session (RoomIO wires audio inside here, which
        #     triggers our hook above to wrap it with RecorderIO immediately)
        # 1d. Attempt to fetch and inject the deployed prompt from Voxgraph.
        #     This runs BEFORE session.start() so instructions are set before the
        #     first user turn. On any failure (network, 404, timeout) the method
        #     does nothing — the agent keeps whatever instructions the customer set.
        await self._fetch_and_inject_prompt(agent)

        start_kwargs: dict[str, Any] = {"agent": agent, "room": room}
        if room_options is not None:
            start_kwargs["room_options"] = room_options
        start_kwargs.update(kwargs)
        await self._session.start(**start_kwargs)

        # 2. Attach interceptor (no-op; kept for interface stability)
        attach_listeners(self._session)

        # 3. Layer 1 (Primary): Register a shutdown callback via JobContext.
        #    LiveKit awaits every shutdown callback to completion before exiting
        #    the job — this guarantees shutdown() runs fully regardless of what
        #    the customer agent code does or how quickly it exits.
        #    Also stores ctx for make_session_report() in shutdown().
        _has_job_context = False
        try:
            from livekit.agents import get_job_context
            ctx = get_job_context()
            self._ctx = ctx
            ctx.add_shutdown_callback(self.shutdown)
            _has_job_context = True
            logger.debug("Auto-registered shutdown callback via get_job_context()")
        except (RuntimeError, ImportError):
            # Not inside a LiveKit job (e.g. unit tests, local dev) — fine.
            logger.debug("No job context found; shutdown callback not auto-registered")

        # 4. Layer 2 (Fallback): Hook the session 'close' event with ensure_future.
        #    Only used when there is NO job context (e.g. tests, local dev).
        #    When a job context IS present, the shutdown callback above is the
        #    authoritative trigger — using ensure_future here would race against
        #    it and could be cancelled by the event loop before drain() completes.
        if not _has_job_context:
            def _on_close(_event: Any) -> None:
                import asyncio
                asyncio.create_task(self.shutdown(), name="voxgraph-shutdown")

            self._session.on("close", _on_close)
            self._close_listener = _on_close
            logger.debug("Registered close-event fallback (no job context)")

        # 5. Install structured log handler
        install_vox_log_handler(self._collector.record_log)

        # 6. Hook conversation_item_added to auto-set vox_turn_context per user turn.
        #    The VoxLogHandler already reads get_current_turn() on every emit, so once
        #    this ContextVar is set, all logs during the turn are automatically tagged
        #    with turn_id — no changes needed in user code.
        #    We only set context for user messages (role == "user") because that is the
        #    meaningful unit of work the logs should be attributed to. The context is
        #    left set until the next user turn begins (it's not cleared at turn end
        #    because agent reply logs during generation should share the same turn_id).
        self._session.on("conversation_item_added", self._on_conversation_item_added)

        self._is_started = True
        logger.info(
            "VoxSession started (id=%s, environment=%s, prompt_version=%s, recording=%s)",
            self._session_id, self._config.environment, self._prompt_version or "(none)", self._enable_recording,
        )

    async def shutdown(self) -> None:
        """Gracefully shut down the Voxgraph instrumentation.

        Safe to call multiple times — only executes once (guarded by _is_shutdown).

        Steps:
        1. Detach metrics listener
        2. Remove log handler
        3. Capture session report from LiveKit JobContext
        4. Send SDK-exclusive session metadata
        5. Drain all buffered telemetry
        """
        if self._is_shutdown:
            return
        self._is_shutdown = True

        logger.info("VoxSession shutting down (id=%s)", self._session_id)

        # 1. Detach listeners
        try:
            detach_listeners(self._session)
        except Exception:
            logger.exception("Error detaching listeners during shutdown")

        # 2. Remove log handler
        try:
            uninstall_vox_log_handler()
        except Exception:
            logger.exception("Error removing log handler during shutdown")

        # 3. Capture the full session report from LiveKit.
        #    Use stored ctx from start(), or fall back to get_job_context() one last time.
        ctx = self._ctx
        if ctx is None:
            try:
                from livekit.agents import get_job_context
                ctx = get_job_context()
            except (RuntimeError, ImportError):
                pass

        try:
            if ctx is not None:
                try:
                    report = ctx.make_session_report()

                    # Extract usage from the raw report events BEFORE to_dict() strips
                    # metrics_collected events. We use LiveKit's own UsageCollector to
                    # aggregate LLM tokens, STT audio duration, and TTS characters.
                    usage = self._extract_usage(report.events)

                    # Extract ended_reason from the raw close event BEFORE to_dict().
                    # The 'close' event carries a 'reason' field; to_dict() includes it
                    # in the events list but the backend expects it as a top-level field.
                    ended_reason = self._extract_ended_reason(report.events)

                    # duration is a raw attribute on SessionReport but is NOT included
                    # in to_dict() output — must be read directly from the raw object.
                    duration_seconds: int | None = None
                    if getattr(report, "duration", None) is not None:
                        duration_seconds = int(report.duration)

                    report_dict = report.to_dict()
                    report_dict["usage"] = usage
                    report_dict["ended_reason"] = ended_reason
                    report_dict["duration_seconds"] = duration_seconds

                    # Override the partial options from to_dict() with the full set read
                    # directly from the AgentSession. to_dict() silently drops 6 fields:
                    # false_interruption_timeout, resume_false_interruption,
                    # use_tts_aligned_transcript, tts_text_transforms, ivr_detection,
                    # aec_warmup_duration.
                    report_dict["options"] = self._capture_full_options(self._session)

                    # Capture userdata and current_speech — not available in the report at all.
                    report_dict["session_data"] = self._capture_session_data(self._session)

                    # Auto-detect call classification from room participants.
                    # SIP participant → channel=phone; sip.ruleID non-empty → inbound.
                    call_type, call_channel = self._detect_call_classification(ctx)
                    report_dict["call_type"] = call_type
                    report_dict["call_channel"] = call_channel

                    # Stamp SDK-owned fields onto the report — the backend's
                    # IngestReportRequest accepts both environment and prompt_version.
                    report_dict["environment"] = self._config.environment
                    report_dict["prompt_version"] = self._prompt_version or None

                    # Build a per-agent tool snapshot map from the raw session report.
                    # Each AgentConfigUpdate that carries _tools (full FunctionTool objects)
                    # is captured before to_dict() discards the in-memory _tools attribute.
                    # This handles: single agent, multi-agent handoffs, update_tools() mid-call.
                    report_dict["tools"] = self._extract_agent_tool_map(report)

                    # ── CRITICAL: queue the report before any await ──────────────
                    # record_session_report() must be called here, before
                    # await self._recorder.stop() below. If the asyncio task is
                    # cancelled at that await (because the job is shutting down),
                    # CancelledError bypasses except-Exception guards. By storing
                    # the report dict in the collector NOW, drain() can always send
                    # it — even if we never return from the recorder await.
                    # report_dict is a plain dict; any mutations made after this
                    # call (recording_url, etc.) are visible to drain() because
                    # Python dicts are passed by reference.
                    self._collector.record_session_report(report_dict)
                    logger.info("Session report captured (job_id=%s)", report_dict.get("job_id", "?"))

                    # Stop audio recorder and enrich the already-queued report.
                    # This await is where CancelledError can strike — that is now
                    # safe because the report is already in the collector.
                    if self._recorder is not None:
                        try:
                            recording_url, recording_started_at = await self._recorder.stop()
                            if recording_url:
                                report_dict["recording_url"] = recording_url
                            if recording_started_at is not None:
                                report_dict["recording_started_at"] = recording_started_at
                        except Exception:
                            logger.exception("AudioRecorder failed to stop — recording_url will be missing")

                except Exception:
                    logger.exception("Error capturing session report during shutdown")
            else:
                logger.warning(
                    "No JobContext available — session report skipped. "
                    "If running in a LiveKit job, this is unexpected."
                )

            # 4. Send SDK-exclusive session metadata
            try:
                meta = SessionMeta(
                    session_id=self._session_id,
                    prompt_version=self._prompt_version,
                    environment=self._config.environment,
                    tags=self._config.tags,
                )
                self._collector.record_session_meta(meta)
            except Exception:
                logger.exception("Error recording session meta during shutdown")

        except BaseException as exc:
            # CancelledError (BaseException in Python 3.8+) and other fatal errors.
            # Log it so the developer can see what interrupted shutdown, then re-raise
            # so asyncio can propagate the cancellation correctly.
            logger.warning(
                "VoxSession shutdown interrupted (%s: %s). "
                "Drain will still run via finally to send the queued session report.",
                type(exc).__name__, exc,
            )
            raise
        finally:
            # 5. Drain telemetry buffer — ALWAYS runs, even if cancelled above.
            # asyncio.shield() creates an independent Task for drain() so it runs
            # to completion even when the outer shutdown() Task is being cancelled.
            import asyncio as _asyncio
            try:
                await _asyncio.shield(self._sender.drain())
            except _asyncio.CancelledError:
                # The outer task was cancelled while we were waiting for the shield.
                # drain() continues running in the background as a detached task and
                # will complete on its own — the session report will still be sent.
                logger.debug("Shutdown task cancelled during drain; drain continues in background.")
            except Exception:
                logger.exception("Error draining telemetry during shutdown")

        logger.info(
            "VoxSession shutdown complete (id=%s, dropped=%d)",
            self._session_id, self._collector.dropped_count,
        )

    def _on_conversation_item_added(self, event: Any) -> None:
        """Auto-set the vox_turn_context ContextVar when a user conversation item is added.

        Fires on every ``conversation_item_added`` event from the LiveKit AgentSession.
        Only user-role messages update the context — assistant messages and tool calls
        are attributed to the same turn that triggered them.

        The ContextVar is set imperatively (not via the context manager) because this
        is an event handler, not a coroutine. The token is stored so we can reset it
        cleanly on the next turn, preventing stale context from leaking across turns.

        Args:
            event: The ``ConversationItemAddedEvent`` from LiveKit.
        """
        try:
            item = event.item
            role = getattr(item, "role", None)

            # Only advance the turn for user messages — each user utterance
            # defines a new observable "turn" that logs should be attributed to.
            if str(role) != "user":
                return

            # item.id is the LiveKit chat item UUID — use it as the turn_id.
            # Fall back to a fresh UUID if the field is missing (future-proofs
            # against LiveKit API changes).
            item_id: str = getattr(item, "id", None) or uuid.uuid4().hex

            # Reset the previous turn token if one exists, then set the new context.
            if self._turn_token is not None:
                try:
                    _current_turn.reset(self._turn_token)
                except Exception:
                    pass  # Token already invalid — safe to ignore

            job_id: str = getattr(self._ctx, "job", None)
            if job_id is not None:
                job_id = getattr(job_id, "id", str(job_id))
            else:
                job_id = ""

            ctx = TurnContext(
                turn_id=item_id,
                session_id=self._session_id,
                job_id=job_id,
            )
            self._turn_token = _current_turn.set(ctx)

            logger.debug(
                "Turn context updated (turn_id=%s, session_id=%s)",
                item_id, self._session_id,
            )
        except Exception:
            # Never let this crash the session
            logger.debug("Failed to update turn context on conversation_item_added", exc_info=True)

    @staticmethod
    def _extract_ended_reason(events: list[Any]) -> str | None:
        """Extract the session end reason from the raw close event.

        The LiveKit 'close' event has a 'reason' field (e.g. 'participant_disconnected',
        'job_shutdown', 'error', 'task_completed', 'user_initiated'). It IS included
        in to_dict() events list, but the backend expects it as a top-level field.

        Args:
            events: The raw list of AgentEvent objects from SessionReport.events.

        Returns:
            The reason string, or None if no close event was found.
        """
        try:
            for event in events:
                if getattr(event, "type", None) == "close":
                    return getattr(event, "reason", None)
        except Exception:
            logger.debug("Could not extract ended_reason from events")
        return None

    @staticmethod
    def _detect_call_classification(ctx: Any) -> tuple[str | None, str | None]:
        """Auto-detect call_type and call_channel from room participants.

        Inspects remote participants in the LiveKit room at shutdown time:
        - If a SIP participant is found (kind == PARTICIPANT_KIND_SIP):
            - call_channel = 'phone'
            - call_type = 'inbound' if sip.ruleID is set, else 'outbound'
        - If no SIP participant is found:
            - call_channel = 'web'
            - call_type = None (web sessions don't have meaningful direction)

        Args:
            ctx: The LiveKit JobContext instance.

        Returns:
            Tuple of (call_type, call_channel), both may be None on error.
        """
        try:
            from livekit import rtc
            for participant in ctx.room.remote_participants.values():
                if participant.kind == rtc.ParticipantKind.PARTICIPANT_KIND_SIP:
                    rule_id = (participant.attributes or {}).get("sip.ruleID", "")
                    call_type = "inbound" if rule_id else "outbound"
                    return call_type, "phone"
            # No SIP participant found — this is a standard web session
            return None, "web"
        except Exception:
            logger.debug("Could not detect call classification from participants")
            return None, None

    @staticmethod
    def _capture_full_options(session: Any) -> dict:
        """Read all AgentSessionOptions fields directly from the AgentSession.

        `to_dict()` only serialises a subset; reading `session.options` gives the
        complete dataclass including the 6 hidden fields.

        Args:
            session: The LiveKit AgentSession instance.

        Returns:
            A dict of all option fields, safe for JSON serialisation.
        """
        try:
            opts = session.options  # AgentSessionOptions dataclass
            raw = dataclasses.asdict(opts)
            # tts_text_transforms is a Sequence[str] | None — ensure list[str]
            if raw.get("tts_text_transforms") is not None:
                raw["tts_text_transforms"] = [str(t) for t in raw["tts_text_transforms"]]
            return raw
        except Exception:
            logger.warning("Could not capture full AgentSessionOptions; falling back to empty dict")
            return {}

    @staticmethod
    def _extract_agent_tool_map(report: Any) -> list[dict] | None:
        """Build a per-agent tool snapshot list from the raw SessionReport.

        Scans the chat history in the pre-serialisation ``report`` object for
        ``AgentConfigUpdate`` items that still carry ``_tools`` (a list of
        ``FunctionTool``/``RawFunctionTool`` objects set in-memory by LiveKit).
        This attribute is silently discarded by ``to_dict()``; we must read it
        here, before serialisation.

        Each ``AgentConfigUpdate`` represents one of:
        - **Initial agent start** — the first snapshot for an agent_id.
        - **Agent handoff** — a new agent_id appears for the first time.
        - **Dynamic tool update** — same agent_id, new tool set mid-call.

        Output format (one entry per config change, in chronological order)::

            [
              {"agent_id": "triage_agent",  "sequence": 0, "tools": [{...}, ...]},
              {"agent_id": "booking_agent", "sequence": 1, "tools": [{...}]},
              {"agent_id": "triage_agent",  "sequence": 2, "tools": [{...}, ..., ...]},
            ]

        Args:
            report: The raw ``SessionReport`` object from
                ``ctx.make_session_report()``, before calling ``.to_dict()``.

        Returns:
            Ordered list of per-agent tool snapshots, or ``None`` if nothing
            could be extracted (e.g., no tools registered, extraction error).
        """
        try:
            from livekit.agents import llm

            # The report's chat history is accessible via report.chat_ctx.items
            # (the raw ChatContext object behind the serialised chat_history).
            # Fall back to report.items if the structure differs across versions.
            chat_ctx = getattr(report, "chat_history", None)
            if chat_ctx is not None:
                raw_items = getattr(chat_ctx, "items", [])
            else:
                raw_items = getattr(report, "items", [])

            if not raw_items:
                return None

            snapshots: list[dict] = []
            sequence = 0

            for item in raw_items:
                # Only care about AgentConfigUpdate items
                if not isinstance(item, llm.AgentConfigUpdate):
                    continue

                # _tools holds the *full* FunctionTool/RawFunctionTool objects.
                # It is only present when tools were set for this config update.
                # Pure instruction-only updates have _tools == None / not set.
                raw_tools: list[Any] | None = getattr(item, "_tools", None)
                if not raw_tools:
                    continue

                agent_id: str = getattr(item, "agent_id", None) or "unknown"

                tool_defs: list[dict] = []
                for tool in raw_tools:
                    try:
                        if isinstance(tool, llm.FunctionTool):
                            schema = llm.utils.build_legacy_openai_schema(
                                tool, internally_tagged=True
                            )
                            tool_defs.append({
                                "name": tool.info.name,
                                "description": tool.info.description,
                                "parameters": schema.get("parameters"),
                            })
                        elif isinstance(tool, llm.RawFunctionTool):
                            raw = tool.info.raw_schema
                            tool_defs.append({
                                "name": tool.info.name,
                                "description": raw.get("description"),
                                "parameters": raw.get("parameters"),
                            })
                    except Exception:
                        logger.debug("Could not serialize tool %r in agent %s", tool, agent_id)

                if not tool_defs:
                    continue  # all tools in this snapshot failed to serialize

                snapshots.append({
                    "agent_id": agent_id,
                    "sequence": sequence,
                    "tools": tool_defs,
                })
                sequence += 1

            return snapshots or None

        except Exception:
            logger.debug("Could not build agent tool map from session report")
            return None

    @staticmethod
    def _capture_session_data(session: Any) -> dict:
        """Capture AgentSession-level data not present in the session report.

        Captures:
        - ``userdata``: Arbitrary value set by the agent on session.userdata.
          Must be JSON-safe; non-serialisable values are coerced to ``str()``.

        Args:
            session: The LiveKit AgentSession instance.

        Returns:
            A dict with a ``userdata`` key.
        """
        result: dict = {"userdata": None}

        # --- userdata ---
        try:
            if not hasattr(session, "_userdata"):
                logger.warning(
                    "session._userdata not found — LiveKit API may have changed. "
                    "userdata will be null in the session report."
                )
            else:
                userdata = session._userdata  # read private attr to avoid ValueError guard
                if userdata is not None:
                    import json
                    try:
                        # Validate JSON-serialisability; if it passes, store as-is.
                        json.dumps(userdata)
                        result["userdata"] = userdata
                    except (TypeError, ValueError):
                        # Fall back to string representation for non-JSON-safe objects.
                        result["userdata"] = str(userdata)
        except Exception:
            logger.debug("Could not capture session.userdata")

        return result

    @staticmethod
    def _extract_usage(events: list[AgentEvent]) -> dict:
        """Aggregate usage data from raw SessionReport events.

        Dispatches to the appropriate collector implementation based on the
        installed livekit-agents version:

        - livekit-agents >= 1.5.0 → :meth:`_extract_usage_v15` (``ModelUsageCollector``)
        - livekit-agents <  1.5.0 → :meth:`_extract_usage_legacy` (``UsageCollector``)

        Must be called BEFORE ``report.to_dict()`` because ``to_dict()``
        explicitly filters out ``metrics_collected`` events.

        Args:
            events: The raw list of AgentEvent objects from ``SessionReport.events``.

        Returns:
            A dict matching the backend UsagePayload schema.
        """
        if livekit_has_model_usage_collector():
            return VoxSession._extract_usage_v15(events)
        return VoxSession._extract_usage_legacy(events)

    @staticmethod
    def _extract_usage_legacy(events: list[AgentEvent]) -> dict:
        """Aggregate usage via the legacy ``UsageCollector`` (livekit-agents 1.0–1.4.x).

        Uses the (now-deprecated) ``UsageCollector`` class and reads
        ``metrics_collected`` events from the raw SessionReport event list.

        Args:
            events: Raw AgentEvent list from ``SessionReport.events``.

        Returns:
            A dict matching the backend UsagePayload schema.
        """
        try:
            from livekit.agents.metrics import UsageCollector  # deprecated in 1.5.0
            from livekit.agents.metrics.base import (
                LLMMetrics, STTMetrics, TTSMetrics,
            )
        except ImportError:
            logger.warning("livekit.agents.metrics not available; usage will not be populated")
            return {}

        collector = UsageCollector()
        llm_models: dict[tuple, dict] = {}
        stt_models: dict[tuple, dict] = {}
        tts_models: dict[tuple, dict] = {}

        for event in events:
            if event.type != "metrics_collected":
                continue
            metrics = event.metrics
            collector.collect(metrics)

            # Capture provider/model pairs — deduplicate by (provider, model) key
            meta = getattr(metrics, "metadata", None)
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                entry = {"provider": meta.model_provider, "model": meta.model_name}
                if isinstance(metrics, LLMMetrics):
                    llm_models[key] = entry
                elif isinstance(metrics, STTMetrics):
                    stt_models[key] = entry
                elif isinstance(metrics, TTSMetrics):
                    tts_models[key] = entry

        summary = collector.get_summary()
        return {
            "llm_prompt_tokens": summary.llm_prompt_tokens,
            "llm_completion_tokens": summary.llm_completion_tokens,
            "stt_audio_duration_seconds": summary.stt_audio_duration,
            "tts_characters_count": summary.tts_characters_count,
            "llm_models": list(llm_models.values()) or None,
            "stt_models": list(stt_models.values()) or None,
            "tts_models": list(tts_models.values()) or None,
        }

    @staticmethod
    def _extract_usage_v15(events: list[AgentEvent]) -> dict:
        """Aggregate usage via ``ModelUsageCollector`` (livekit-agents >= 1.5.0).

        Uses the new ``ModelUsageCollector`` that provides structured per-model
        and per-provider breakdowns via typed usage classes (``LLMModelUsage``,
        ``STTModelUsage``, ``TTSModelUsage``).

        Args:
            events: Raw AgentEvent list from ``SessionReport.events``.

        Returns:
            A dict matching the backend UsagePayload schema, identical in shape
            to the legacy path so no backend migration is required.
        """
        try:
            from livekit.agents.metrics import ModelUsageCollector
            from livekit.agents.metrics.base import (
                LLMModelUsage, STTModelUsage, TTSModelUsage,
            )
        except ImportError:
            logger.warning(
                "livekit.agents.metrics.ModelUsageCollector not available; "
                "falling back to legacy UsageCollector."
            )
            return VoxSession._extract_usage_legacy(events)

        collector = ModelUsageCollector()
        llm_models: dict[tuple, dict] = {}
        stt_models: dict[tuple, dict] = {}
        tts_models: dict[tuple, dict] = {}

        for event in events:
            # ModelUsageCollector still reads from metrics_collected events —
            # the event itself is not deprecated, only the *listener* API is.
            if event.type != "metrics_collected":
                continue
            metrics = event.metrics
            collector.collect(metrics)

        # Build per-model entries from the typed usage objects.
        for model_usage in collector.get_usage().model_usage:
            key = (
                getattr(model_usage, "provider", None) or "",
                getattr(model_usage, "model", None) or "",
            )
            entry = {
                "provider": getattr(model_usage, "provider", None),
                "model": getattr(model_usage, "model", None),
            }
            if isinstance(model_usage, LLMModelUsage):
                llm_models[key] = entry
            elif isinstance(model_usage, STTModelUsage):
                stt_models[key] = entry
            elif isinstance(model_usage, TTSModelUsage):
                tts_models[key] = entry

        # Aggregate totals across all models for the top-level scalar fields.
        usage = collector.get_usage()
        llm_prompt_tokens = sum(
            getattr(u, "prompt_tokens", 0)
            for u in usage.model_usage
            if isinstance(u, LLMModelUsage)
        )
        llm_completion_tokens = sum(
            getattr(u, "completion_tokens", 0)
            for u in usage.model_usage
            if isinstance(u, LLMModelUsage)
        )
        stt_audio_duration = sum(
            getattr(u, "audio_duration", 0.0)
            for u in usage.model_usage
            if isinstance(u, STTModelUsage)
        )
        tts_characters_count = sum(
            getattr(u, "characters_count", 0)
            for u in usage.model_usage
            if isinstance(u, TTSModelUsage)
        )

        return {
            "llm_prompt_tokens": llm_prompt_tokens,
            "llm_completion_tokens": llm_completion_tokens,
            "stt_audio_duration_seconds": stt_audio_duration,
            "tts_characters_count": tts_characters_count,
            "llm_models": list(llm_models.values()) or None,
            "stt_models": list(stt_models.values()) or None,
            "tts_models": list(tts_models.values()) or None,
        }


    async def _fetch_and_inject_prompt(self, agent: Any) -> None:
        """Fetch the HEAD system prompt for the configured branch and inject it into the agent.

        Called inside start() before self._session.start() so the instructions
        are set before any user turn begins.

        Failure policy: on ANY error (network, timeout, 404, missing agent_id)
        this method does nothing and logs a warning. The agent keeps whatever
        instructions the customer set in their own code. This guarantees that
        the Voxgraph prompt feature is purely additive — it never breaks a
        live call.
        """
        if not self._config.agent_id:
            logger.debug("VoxSession: no agent_id set, skipping prompt fetch")
            return

        if not self._sender._client:
            logger.debug("VoxSession: HTTP client not ready, skipping prompt fetch")
            return

        try:
            resp = await self._sender._client.get(
                "/api/v1/prompts/head",
                params={
                    "agent_id": self._config.agent_id,
                    "environment": self._config.environment,
                    "name": "system_prompt",
                },
                timeout=3.0,
            )

            if resp.status_code == 200:
                data = resp.json()
                content = data.get("content", "")
                if content:
                    # Auto-capture version_number from the API response
                    version_number = data.get("version_number")
                    self._prompt_version = str(version_number) if version_number is not None else ""
                    await agent.update_instructions(content)
                    logger.info(
                        "VoxSession: prompt injected from Voxgraph (env=%s, version=%s)",
                        self._config.environment, self._prompt_version or "(unknown)",
                    )
                else:
                    logger.debug("VoxSession: deployed prompt has empty content, skipping injection")

            elif resp.status_code == 404:
                logger.debug(
                    "VoxSession: no prompt deployed for env=%s (404), using agent's own instructions",
                    self._config.environment,
                )
            else:
                logger.warning(
                    "VoxSession: prompt fetch returned unexpected status %d, using agent's own instructions",
                    resp.status_code,
                )

        except Exception:
            logger.warning(
                "VoxSession: prompt fetch failed, using agent's own instructions (env=%s)",
                self._config.environment,
            )

    def __repr__(self) -> str:
        status = "started" if self._is_started else "created"
        if self._is_shutdown:
            status = "shutdown"
        return f"<VoxSession id={self._session_id} status={status}>"

