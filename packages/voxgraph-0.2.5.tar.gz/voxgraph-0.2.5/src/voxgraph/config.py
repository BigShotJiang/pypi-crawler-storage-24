"""Voxgraph SDK configuration.

The backend endpoint defaults to the Voxgraph production API. For local
development, set the ``VOXGRAPH_DEV_ENDPOINT`` env var in the consuming
project's environment (e.g. ``http://localhost:8000``).

Only api_key is required. agent_id and environment are optional.
"""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass, field

__all__ = ["VoxConfig", "load_config"]

# Default production endpoint.
ENDPOINT = "https://api.voxgraph.io"


@dataclass(frozen=True, slots=True)
class VoxConfig:
    """Immutable SDK configuration.

    The endpoint defaults to the Voxgraph production API but can be
    overridden via the ``VOXGRAPH_DEV_ENDPOINT`` env var for local
    development.
    """

    api_key: str = ""
    agent_id: str = ""
    environment: str = "main"  # Prompt branch: "main", "dev", "staging", etc.
    endpoint: str = ENDPOINT   # Internal — always ENDPOINT, never user-supplied
    batch_size: int = 50
    flush_interval_s: float = 1.0
    max_buffer_size: int = 1000
    max_retries: int = 3
    request_timeout_s: float = 10.0
    debug: bool = False         # Internal — set via VOXGRAPH_DEBUG env var only
    tags: dict[str, str] = field(default_factory=dict)


def load_config(
    *,
    api_key: str | None = None,
    agent_id: str | None = None,
    environment: str | None = None,
    tags: dict[str, str] | None = None,
) -> VoxConfig:
    """Create a VoxConfig from explicit arguments, falling back to env vars.

    Users provide: api_key, agent_id, environment.

    Supported env vars (fallback when the kwarg is not supplied):
        VOXGRAPH_API_KEY          — API key for the Voxgraph backend (required)
        VOXGRAPH_AGENT_ID         — UUID of the voice AI agent (optional)
        VOXGRAPH_ENVIRONMENT      — Prompt branch, default "main" (optional)
        VOXGRAPH_DEBUG            — SDK debug logging; "1"/"true"/"yes" (optional)
        VOXGRAPH_DEV_ENDPOINT     — Override backend URL for local dev (optional)
    """
    debug = os.environ.get("VOXGRAPH_DEBUG", "").lower() in ("1", "true", "yes")
    resolved_key = api_key or os.environ.get("VOXGRAPH_API_KEY", "")
    if not resolved_key:
        warnings.warn(
            "Voxgraph SDK: no API key provided. Set api_key= or VOXGRAPH_API_KEY. "
            "All telemetry will be silently discarded until a valid key is supplied.",
            UserWarning,
            stacklevel=3,
        )
    return VoxConfig(
        api_key=resolved_key,
        agent_id=agent_id or os.environ.get("VOXGRAPH_AGENT_ID", ""),
        environment=environment or os.environ.get("VOXGRAPH_ENVIRONMENT", "main"),
        endpoint=os.environ.get("VOXGRAPH_DEV_ENDPOINT", ENDPOINT),
        debug=debug,
        tags=tags or {},
    )
