"""Tests for VoxSession._extract_agent_tool_map()."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from voxgraph.session import VoxSession


# ---------------------------------------------------------------------------
# Minimal stubs for LiveKit objects
# ---------------------------------------------------------------------------


def _make_function_tool(name: str, description: str, parameters: dict) -> MagicMock:
    """Return a minimal FunctionTool stand-in."""
    from livekit.agents import llm

    tool = MagicMock(spec=llm.FunctionTool)
    tool.info = MagicMock()
    tool.info.name = name
    tool.info.description = description
    # build_legacy_openai_schema uses the actual tool; patch it locally in tests.
    return tool


def _make_config_update(agent_id: str, tool_objects: list | None) -> MagicMock:
    """Return a minimal AgentConfigUpdate stand-in."""
    from livekit.agents import llm

    item = MagicMock(spec=llm.AgentConfigUpdate)
    item.agent_id = agent_id
    item._tools = tool_objects
    return item


def _make_report(items: list) -> MagicMock:
    """Return a minimal SessionReport stand-in with chat_history.items."""
    chat_history = MagicMock()
    chat_history.items = items
    report = MagicMock()
    report.chat_history = chat_history
    return report


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestExtractAgentToolMap:
    """Unit tests for VoxSession._extract_agent_tool_map()."""

    def _call(self, report: Any) -> list[dict] | None:
        return VoxSession._extract_agent_tool_map(report)

    def test_returns_none_for_empty_chat_ctx(self):
        report = _make_report([])
        assert self._call(report) is None

    def test_returns_none_when_no_config_updates(self):
        """Non-AgentConfigUpdate items in the chat context are ignored."""
        from livekit.agents import llm

        regular_msg = MagicMock(spec=llm.ChatMessage)
        report = _make_report([regular_msg])
        assert self._call(report) is None

    def test_returns_none_when_config_update_has_no_tools(self):
        """AgentConfigUpdate that is a pure instruction update (no _tools) is skipped."""
        item = _make_config_update("my_agent", None)
        report = _make_report([item])
        assert self._call(report) is None

    def test_single_agent_single_snapshot(self, monkeypatch):
        """Single agent, one config update → one snapshot with sequence=0."""
        from livekit.agents import llm

        fake_schema = {"parameters": {"type": "object", "properties": {}}}
        monkeypatch.setattr(llm.utils, "build_legacy_openai_schema", lambda t, **kw: fake_schema)

        tool = MagicMock(spec=llm.FunctionTool)
        tool.info.name = "get_weather"
        tool.info.description = "Get the current weather"

        item = _make_config_update("weather_agent", [tool])
        report = _make_report([item])

        result = self._call(report)
        assert result is not None
        assert len(result) == 1
        snap = result[0]
        assert snap["agent_id"] == "weather_agent"
        assert snap["sequence"] == 0
        assert len(snap["tools"]) == 1
        assert snap["tools"][0]["name"] == "get_weather"
        assert snap["tools"][0]["description"] == "Get the current weather"

    def test_multi_agent_handoff(self, monkeypatch):
        """Two agents → two snapshots with distinct agent_ids, sequences 0 and 1."""
        from livekit.agents import llm

        monkeypatch.setattr(
            llm.utils, "build_legacy_openai_schema",
            lambda t, **kw: {"parameters": {"type": "object"}}
        )

        tool_a = MagicMock(spec=llm.FunctionTool)
        tool_a.info.name = "transfer"
        tool_a.info.description = "Transfer to another agent"

        tool_b = MagicMock(spec=llm.FunctionTool)
        tool_b.info.name = "book_appointment"
        tool_b.info.description = "Book an appointment"

        items = [
            _make_config_update("triage_agent", [tool_a]),
            _make_config_update("booking_agent", [tool_b]),
        ]
        report = _make_report(items)

        result = self._call(report)
        assert result is not None
        assert len(result) == 2
        assert result[0]["agent_id"] == "triage_agent"
        assert result[0]["sequence"] == 0
        assert result[1]["agent_id"] == "booking_agent"
        assert result[1]["sequence"] == 1

    def test_dynamic_tool_update_same_agent(self, monkeypatch):
        """Two AgentConfigUpdates with the same agent_id → two snapshots (initial + update)."""
        from livekit.agents import llm

        monkeypatch.setattr(
            llm.utils, "build_legacy_openai_schema",
            lambda t, **kw: {"parameters": {}}
        )

        tool_v1 = MagicMock(spec=llm.FunctionTool)
        tool_v1.info.name = "search"
        tool_v1.info.description = "Search the database"

        tool_v2a = MagicMock(spec=llm.FunctionTool)
        tool_v2a.info.name = "search"
        tool_v2a.info.description = "Search the database"

        tool_v2b = MagicMock(spec=llm.FunctionTool)
        tool_v2b.info.name = "escalate"
        tool_v2b.info.description = "Escalate to supervisor"

        items = [
            _make_config_update("support_agent", [tool_v1]),          # initial
            _make_config_update("support_agent", [tool_v2a, tool_v2b]),  # after update_tools()
        ]
        report = _make_report(items)

        result = self._call(report)
        assert result is not None
        assert len(result) == 2
        assert result[0]["agent_id"] == "support_agent"
        assert result[0]["sequence"] == 0
        assert len(result[0]["tools"]) == 1

        assert result[1]["agent_id"] == "support_agent"
        assert result[1]["sequence"] == 1
        assert len(result[1]["tools"]) == 2

    def test_raw_function_tool_serialization(self):
        """RawFunctionTool items are serialized via raw_schema."""
        from livekit.agents import llm

        raw_tool = MagicMock(spec=llm.RawFunctionTool)
        raw_tool.info.name = "raw_op"
        raw_tool.info.raw_schema = {
            "name": "raw_op",
            "description": "A raw tool",
            "parameters": {"type": "object"},
        }

        item = _make_config_update("raw_agent", [raw_tool])
        report = _make_report([item])

        result = self._call(report)
        assert result is not None
        assert len(result) == 1
        tool_def = result[0]["tools"][0]
        assert tool_def["name"] == "raw_op"
        assert tool_def["description"] == "A raw tool"
        assert tool_def["parameters"] == {"type": "object"}

    def test_falls_back_to_report_items_when_no_chat_ctx(self):
        """If report.chat_ctx is missing, fall back to reading report.items directly."""
        from livekit.agents import llm

        raw_tool = MagicMock(spec=llm.RawFunctionTool)
        raw_tool.info.name = "fallback_tool"
        raw_tool.info.raw_schema = {"name": "fallback_tool", "description": None, "parameters": {}}

        item = _make_config_update("fb_agent", [raw_tool])

        # Report has no chat_ctx, but has .items directly
        report = MagicMock(spec=[])  # no spec attributes
        report.chat_ctx = None       # explicitly None
        report.items = [item]

        result = self._call(report)
        assert result is not None
        assert result[0]["tools"][0]["name"] == "fallback_tool"

    def test_graceful_degradation_on_bad_report(self):
        """Returns None instead of raising when the report has unexpected structure."""
        result = self._call(None)
        assert result is None


# ---------------------------------------------------------------------------
# Tests for _extract_usage() version branching
# ---------------------------------------------------------------------------

def _make_metrics_event(
    event_type: str,
    *,
    llm_prompt: int = 0,
    llm_completion: int = 0,
    stt_duration: float = 0.0,
    tts_chars: int = 0,
    provider: str = "openai",
    model: str = "gpt-4o",
) -> MagicMock:
    """Return a mock AgentEvent carrying metrics."""
    from unittest.mock import MagicMock
    event = MagicMock()
    event.type = event_type
    metrics = MagicMock()
    # Legacy metadata shape
    meta = MagicMock()
    meta.model_provider = provider
    meta.model_name = model
    metrics.metadata = meta
    # Numeric fields used by both paths
    metrics.prompt_tokens = llm_prompt
    metrics.completion_tokens = llm_completion
    metrics.audio_duration = stt_duration
    metrics.characters_count = tts_chars
    event.metrics = metrics
    return event


class TestExtractUsage:
    """Unit tests for VoxSession._extract_usage() version-gate dispatch."""

    def test_legacy_path_returns_correct_shape(self, monkeypatch):
        """Legacy path (pre-1.5.0): UsageCollector returns the expected dict shape."""
        # Force legacy branch
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: False,
        )

        # Build a minimal mock UsageCollector that returns a fixed summary
        from unittest.mock import MagicMock, patch

        summary = MagicMock()
        summary.llm_prompt_tokens = 100
        summary.llm_completion_tokens = 50
        summary.stt_audio_duration = 12.5
        summary.tts_characters_count = 300

        mock_collector_instance = MagicMock()
        mock_collector_instance.get_summary.return_value = summary

        from livekit.agents.metrics.base import LLMMetrics

        event = MagicMock()
        event.type = "metrics_collected"
        event.metrics = MagicMock(spec=LLMMetrics)
        event.metrics.metadata = MagicMock()
        event.metrics.metadata.model_provider = "openai"
        event.metrics.metadata.model_name = "gpt-4o"

        with patch(
            "voxgraph.session.VoxSession._extract_usage_legacy.__func__"
            if False else "livekit.agents.metrics.UsageCollector",
            return_value=mock_collector_instance,
        ):
            result = VoxSession._extract_usage_legacy([event])

        assert "llm_prompt_tokens" in result
        assert "llm_completion_tokens" in result
        assert "stt_audio_duration_seconds" in result
        assert "tts_characters_count" in result
        assert "llm_models" in result
        assert "stt_models" in result
        assert "tts_models" in result

    def test_dispatcher_selects_legacy_when_version_below_15(self, monkeypatch):
        """_extract_usage() calls _extract_usage_legacy when gate returns False."""
        called = []

        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: False,
        )
        monkeypatch.setattr(
            VoxSession,
            "_extract_usage_legacy",
            staticmethod(lambda events: called.append("legacy") or {}),
        )

        VoxSession._extract_usage([])
        assert called == ["legacy"]

    def test_dispatcher_selects_v15_when_version_at_or_above_15(self, monkeypatch):
        """_extract_usage() calls _extract_usage_v15 when gate returns True."""
        called = []

        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: True,
        )
        monkeypatch.setattr(
            VoxSession,
            "_extract_usage_v15",
            staticmethod(lambda events: called.append("v15") or {}),
        )

        VoxSession._extract_usage([])
        assert called == ["v15"]

    def test_empty_events_returns_valid_shape_legacy(self, monkeypatch):
        """Legacy path: empty event list produces a zero-filled dict without raising."""
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: False,
        )
        result = VoxSession._extract_usage([])
        # Should return either {} (ImportError) or a dict with expected keys
        if result:
            assert "llm_prompt_tokens" in result

    def test_empty_events_returns_valid_shape_v15(self, monkeypatch):
        """v1.5 path: empty event list produces a zero-filled dict without raising."""
        monkeypatch.setattr(
            "voxgraph.session.livekit_has_model_usage_collector",
            lambda: True,
        )
        result = VoxSession._extract_usage([])
        if result:
            assert "llm_prompt_tokens" in result


# ---------------------------------------------------------------------------
# Tests for _compat.py helpers
# ---------------------------------------------------------------------------


class TestCompatHelpers:
    """Unit tests for livekit_version() and livekit_has_model_usage_collector()."""

    def test_livekit_version_returns_tuple(self):
        from voxgraph._compat import livekit_version
        ver = livekit_version()
        assert isinstance(ver, tuple)
        assert all(isinstance(x, int) for x in ver)

    def test_livekit_version_is_cached(self):
        """Calling livekit_version() twice returns the same object."""
        from voxgraph._compat import livekit_version
        assert livekit_version() is livekit_version()

    def test_has_model_usage_collector_returns_bool(self):
        from voxgraph._compat import livekit_has_model_usage_collector
        result = livekit_has_model_usage_collector()
        assert isinstance(result, bool)

    def test_has_model_usage_collector_true_for_v15(self, monkeypatch):
        import voxgraph._compat as compat
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_CACHE", (1, 5, 0))
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_RESOLVED", True)
        assert compat.livekit_has_model_usage_collector() is True

    def test_has_model_usage_collector_false_for_v14(self, monkeypatch):
        import voxgraph._compat as compat
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_CACHE", (1, 4, 6))
        monkeypatch.setattr(compat, "_LIVEKIT_VERSION_RESOLVED", True)
        assert compat.livekit_has_model_usage_collector() is False

