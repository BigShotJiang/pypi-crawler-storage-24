# image-core (Python)

Infra-agnostic image processing core for exercise solutions.

## Prerequisites

- Python 3.11+
- pip (or uv/pip-tools)

## Features

- Validate image payloads
- Resize by longest edge
- Convert output format
- Return required metadata
- Bytes and stream entry points

## Install

Published package:

```bash
pip install intro-to-cc-image-core
```

Local package test (without publishing):

```bash
pip install .
```

## API Surface

This package intentionally exposes a small student-facing API:

| Function | Input style | Typical use case |
| --- | --- | --- |
| `process_image_bytes` | `bytes` | Use when you already have complete bytes in memory |
| `process_image_stream` | `BinaryIO` stream | Use when image data comes from stream-based IO |

Persistence and storage integration stay in your app code.

## Bytes Usage

```python
from image_core.models import ProcessingConfig
from image_core.processing import process_image_bytes

result = process_image_bytes(
    source_bytes=input_bytes,
    config=ProcessingConfig(
        max_long_edge_px=1280,
        output_format="JPEG",
        output_quality=85,
    ),
    image_id="img-1",
)

print(result.metadata, result.content_type)
```

## Build and Publish Checklist

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```

## Stream Usage

```python
from image_core.models import ProcessingConfig
from image_core.processing import process_image_stream

with open("./input.png", "rb") as source_stream:
    result = process_image_stream(
        source_stream=source_stream,
        config=ProcessingConfig(
            max_long_edge_px=1280,
            output_format="JPEG",
            output_quality=85,
        ),
        image_id="img-2",
        asset_path="processed/img-2.jpg",
    )

print(result.metadata, result.content_type)
```
