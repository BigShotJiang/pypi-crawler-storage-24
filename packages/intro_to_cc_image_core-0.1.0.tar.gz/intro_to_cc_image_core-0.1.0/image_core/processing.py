import io
import uuid
from typing import BinaryIO

from PIL import Image, ImageOps, UnidentifiedImageError

from .errors import InvalidImageError
from .models import ImageMetadata, ProcessingConfig, ProcessingResult


def _content_type_for_format(output_format: str) -> str:
    normalized = output_format.upper()
    if normalized == "JPEG" or normalized == "JPG":
        return "image/jpeg"
    if normalized == "PNG":
        return "image/png"
    if normalized == "WEBP":
        return "image/webp"
    raise ValueError(f"Unsupported output format: {output_format}")


def _resize_dimensions(width: int, height: int, max_long_edge_px: int) -> tuple[int, int]:
    longest = max(width, height)
    if longest <= max_long_edge_px:
        return width, height

    scale = max_long_edge_px / float(longest)
    return max(1, int(width * scale)), max(1, int(height * scale))


def process_image_bytes(
    source_bytes: bytes,
    config: ProcessingConfig,
    image_id: str | None = None,
    asset_path: str | None = None,
    asset_url: str | None = None,
) -> ProcessingResult:
    try:
        with Image.open(io.BytesIO(source_bytes)) as image:
            normalized = ImageOps.exif_transpose(image)
            original_width, original_height = normalized.size
            processed_width, processed_height = _resize_dimensions(
                original_width, original_height, config.max_long_edge_px
            )

            transformed = normalized.resize((processed_width, processed_height), Image.Resampling.LANCZOS)
            output = io.BytesIO()
            transformed.save(output, format=config.output_format, quality=config.output_quality)
            processed_bytes = output.getvalue()

    except (UnidentifiedImageError, OSError) as exc:
        raise InvalidImageError("Input payload is not a valid image") from exc

    out_id = image_id or str(uuid.uuid4())
    metadata = ImageMetadata(
        id=out_id,
        original_width_px=original_width,
        original_height_px=original_height,
        processed_width_px=processed_width,
        processed_height_px=processed_height,
        asset_path=asset_path,
        asset_url=asset_url,
    )

    return ProcessingResult(
        processed_bytes=processed_bytes,
        metadata=metadata,
        content_type=_content_type_for_format(config.output_format),
    )


def process_image_stream(
    source_stream: BinaryIO,
    config: ProcessingConfig,
    image_id: str | None = None,
    asset_path: str | None = None,
    asset_url: str | None = None,
) -> ProcessingResult:
    source_bytes = source_stream.read()
    return process_image_bytes(
        source_bytes=source_bytes,
        config=config,
        image_id=image_id,
        asset_path=asset_path,
        asset_url=asset_url,
    )
