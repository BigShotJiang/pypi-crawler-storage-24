class ImageCoreError(Exception):
    """Base error for the image core module."""


class InvalidImageError(ImageCoreError):
    """Raised when input bytes are not a valid image."""
