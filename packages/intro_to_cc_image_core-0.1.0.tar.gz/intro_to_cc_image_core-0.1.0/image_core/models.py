from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ProcessingConfig:
    max_long_edge_px: int = 1280
    output_format: str = "JPEG"
    output_quality: int = 85


@dataclass(frozen=True)
class ImageMetadata:
    id: str
    original_width_px: int
    original_height_px: int
    processed_width_px: int
    processed_height_px: int
    asset_path: Optional[str] = None
    asset_url: Optional[str] = None


@dataclass(frozen=True)
class ProcessingResult:
    processed_bytes: bytes
    metadata: ImageMetadata
    content_type: str
