from io import BytesIO

import pytest
from PIL import Image

from image_core.errors import InvalidImageError
from image_core.models import ProcessingConfig
from image_core.processing import process_image_bytes, process_image_stream


def _make_image(width: int, height: int, fmt: str = "PNG") -> bytes:
    image = Image.new("RGB", (width, height), color=(220, 120, 50))
    output = BytesIO()
    image.save(output, format=fmt)
    return output.getvalue()


def test_process_image_happy_path() -> None:
    source = _make_image(2400, 1200)
    result = process_image_bytes(
        source,
        ProcessingConfig(max_long_edge_px=1280, output_format="JPEG", output_quality=85),
        image_id="img-1",
        asset_path="processed/img-1.jpg",
    )

    assert result.metadata.id == "img-1"
    assert result.metadata.original_width_px == 2400
    assert result.metadata.original_height_px == 1200
    assert result.metadata.processed_width_px == 1280
    assert result.metadata.processed_height_px == 640
    assert result.metadata.asset_path == "processed/img-1.jpg"
    assert result.content_type == "image/jpeg"
    assert len(result.processed_bytes) > 0


def test_process_image_invalid_image() -> None:
    with pytest.raises(InvalidImageError):
        process_image_bytes(
            b"this-is-not-an-image",
            ProcessingConfig(max_long_edge_px=1280, output_format="JPEG", output_quality=85),
        )


def test_process_image_stream_happy_path() -> None:
    source = _make_image(900, 600)
    result = process_image_stream(
        BytesIO(source),
        ProcessingConfig(max_long_edge_px=800, output_format="JPEG", output_quality=85),
        image_id="img-stream",
    )

    assert result.metadata.id == "img-stream"
    assert result.metadata.original_width_px == 900
    assert result.metadata.original_height_px == 600
    assert result.metadata.processed_width_px == 800
    assert result.metadata.processed_height_px == 533
