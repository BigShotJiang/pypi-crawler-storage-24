"""Fachada pública do módulo de normalização.

Permite instanciar o pipeline com providers customizados,
sem depender de variáveis de ambiente ou do monólito app/.
"""

from address_normalizer.modules.abbreviation.base import AbbreviationProvider
from address_normalizer.pipeline.orchestrator import Pipeline
from address_normalizer.pipeline.steps.uppercase import UppercaseStep
from address_normalizer.pipeline.steps.abbreviation import AbbreviationStep
from address_normalizer.pipeline.steps.encoding import EncodingStep
from address_normalizer.pipeline.steps.preprocessing import PreprocessingStep
from address_normalizer.schemas.endereco import NormalizationResult


class NormalizerFacade:
    """Fachada pública do módulo de normalização.

    Permite instanciar o pipeline com providers customizados,
    sem depender de variáveis de ambiente ou do monólito app/.
    """

    def __init__(
        self,
        abbreviation_provider: AbbreviationProvider,
        *,
        separar_numero_logradouro: bool = False,
        normalizar_cep: bool = False,
    ):
        self._abbreviation_provider = abbreviation_provider
        self._pipeline = Pipeline(
            steps=[
                UppercaseStep(),           # 1. Uppercase primeiro (para identificar tokens)
                EncodingStep(),            # 2. Correção de encoding (antes de abreviações)
                AbbreviationStep(provider=abbreviation_provider),  # 3. Expansão de abreviações
                PreprocessingStep(separar_numero_logradouro=separar_numero_logradouro, normalizar_cep=normalizar_cep),       # 4. Limpeza e normalização
            ]
        )

    async def normalize(self, endereco: dict) -> NormalizationResult:
        """Normaliza um endereço e retorna resultado completo."""
        return await self._pipeline.normalize(endereco)

    async def normalize_batch(
        self, enderecos: list[dict]
    ) -> list[NormalizationResult]:
        """Normaliza uma lista de endereços."""
        results = []
        for endereco in enderecos:
            result = await self._pipeline.normalize(endereco)
            results.append(result)
        return results

    @property
    def provider_name(self) -> str:
        """Nome do provider de abreviações ativo."""
        return self._abbreviation_provider.provider_name
