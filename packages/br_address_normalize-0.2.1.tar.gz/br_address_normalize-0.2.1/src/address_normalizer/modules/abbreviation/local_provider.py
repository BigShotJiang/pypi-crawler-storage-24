from pathlib import Path

from address_normalizer.modules.abbreviation.base import AbbreviationProvider
from address_normalizer.modules.abbreviation.deterministic import DeterministicLayer
from address_normalizer.data import load_unified_abbreviations, build_field_indices, load_null_markers


class LocalAbbreviationProvider(AbbreviationProvider):
    """Provider de expansão de abreviações usando dicionário JSON local.

    Carrega o arquivo abbreviations_unified.json e usa o DeterministicLayer
    para expansão com contexto posicional e regras de campo.
    Indicado para desenvolvimento local e quando a API externa não está
    disponível.
    """

    def __init__(self, dict_path: Path | None = None):
        """Inicializa o provider com o dicionário de abreviações.

        Args:
            dict_path: Caminho para o arquivo JSON de abreviações.
                Se None, usa o caminho padrão em abbreviations_unified.json.
        """
        # Load unified abbreviations and build indices
        unified = load_unified_abbreviations(dict_path)
        field_indices, positional_indices = build_field_indices(unified)
        null_markers = load_null_markers()
        
        # Initialize DeterministicLayer for proper context-aware expansion
        self._l1 = DeterministicLayer(
            field_indices=field_indices,
            positional_indices=positional_indices,
            null_markers=null_markers,
            general_dict=None,
            preserve_unknown_codes=True,
        )

    async def expand(self, text: str, field_name: str, context: dict | None = None) -> tuple[str, list[dict]]:
        """Expande abreviações token a token usando o DeterministicLayer.

        Aplica regras posicionais e de contexto de campo para expansão correta.

        Args:
            text: Texto com possíveis abreviações.
            field_name: Nome do campo sendo processado.
            context: Contexto do endereço (não utilizado no provider local).

        Returns:
            Tupla (texto_expandido, lista_transformações).
        """
        if not text or not text.strip():
            return text, []

        tokens = text.split()
        transformacoes = []
        new_tokens = []

        for i, token in enumerate(tokens):
            upper_token = token.upper().rstrip(".,;:")
            next_token = tokens[i + 1].upper() if i + 1 < len(tokens) else None
            
            # Use DeterministicLayer for context-aware expansion
            decision = self._l1.expand_token(upper_token, next_token, field_name, i)
            
            if decision.action == "remove":
                transformacoes.append({
                    "campo": field_name,
                    "tipo": "remocao",
                    "de": token,
                    "para": "",
                    "regra_aplicada": decision.rule_applied or "REMOVE",
                })
                # Skip this token (don't add to new_tokens)
            elif decision.action == "expand" and decision.expanded:
                transformacoes.append({
                    "campo": field_name,
                    "tipo": "abreviacao",
                    "de": token,
                    "para": decision.expanded,
                    "regra_aplicada": decision.rule_applied or "LOCAL_DICT",
                })
                new_tokens.append(decision.expanded)
            else:
                # Preserve token as-is
                new_tokens.append(token)

        return " ".join(new_tokens) if new_tokens else "", transformacoes

    async def health_check(self) -> bool:
        """Sempre retorna True pois o dicionário é local."""
        return True

    @property
    def provider_name(self) -> str:
        return "local"
