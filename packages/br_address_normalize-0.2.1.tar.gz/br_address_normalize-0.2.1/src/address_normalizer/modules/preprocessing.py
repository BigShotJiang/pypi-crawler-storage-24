import re
from dataclasses import dataclass, field


TIPOS_LOGRADOURO = {
    "RUA", "AVENIDA", "TRAVESSA", "RODOVIA", "ALAMEDA", "RAMAL",
    "ESTRADA", "PASSAGEM", "COMUNIDADE", "BECO", "VIELA", "LARGO",
    "PRACA", "PRAÇA", "QUADRA", "CONJUNTO", "VILA", "PARQUE",
    "JARDIM", "CHÁCARA", "FAZENDA", "CONDOMÍNIO", "RESIDENCIAL",
    "BALNEÁRIO", "DISTRITO", "SETOR", "CÓRREGO", "IGARAPÉ",
}

# CEPs inválidos (sequências repetidas e padrões óbvios)
CEPS_INVALIDOS = frozenset({
    "00000000", "11111111", "22222222", "33333333", "44444444",
    "55555555", "66666666", "77777777", "88888888", "99999999",
    "12345678", "87654321",
})


@dataclass
class PreprocessResult:
    """Resultado do pré-processamento de um campo."""

    valor: str
    transformacoes: list[dict] = field(default_factory=list)
    cep_invalido: bool = False


class Preprocessor:
    """Módulo de limpeza bruta de endereços.

    Executa transformações baseadas em regex para resolver problemas
    comuns na digitação de endereços brasileiros: prefixos duplicados,
    códigos no logradouro, CEP malformado, número colado no nome, e
    inconsistência de caixa.
    """

    def __init__(self, *, separar_numero_logradouro: bool = False, normalizar_cep: bool = False):
        self._separar_numero_logradouro_enabled = separar_numero_logradouro
        self._normalizar_cep_enabled = normalizar_cep

    def process(self, endereco: dict) -> dict[str, PreprocessResult]:
        """Executa todas as etapas de pré-processamento no endereço.

        Args:
            endereco: Dicionário com campos do endereço bruto.

        Returns:
            Dicionário campo→PreprocessResult com valores limpos e
            transformações registradas.
        """
        results = {}
        for campo in ("logradouro", "numero", "complemento", "bairro", "municipio", "uf", "cep"):
            valor = str(endereco.get(campo, "") or "").strip()
            results[campo] = PreprocessResult(valor=valor)

        self._remover_valores_placeholder(results)
        self._remover_prefixo_duplicado(results)
        self._remover_codigo_logradouro(results)
        if self._separar_numero_logradouro_enabled:
            self._separar_numero_logradouro(results)
        if self._normalizar_cep_enabled:
            self._normalizar_cep(results)
        self._normalizar_uf(results)

        return results

    def _normalizar_caixa(self, results: dict[str, PreprocessResult]) -> None:
        """Padroniza todos os campos para UPPERCASE."""
        for campo, res in results.items():
            if campo == "cep":
                continue
            upper = res.valor.upper()
            if upper != res.valor and res.valor:
                res.transformacoes.append({
                    "campo": campo, "tipo": "limpeza",
                    "de": res.valor, "para": upper,
                })
                res.valor = upper

    def _remover_valores_placeholder(self, results: dict[str, PreprocessResult]) -> None:
        """Remove conteúdos que são apenas o título do campo ou prefixos redundantes."""
        placeholders_por_campo = {
            "logradouro": {"LOGRADOURO", "ENDERECO", "ENDEREÇO"},
            "numero": {"NUMERO", "NÚMERO", "S/N", "SN"},
            "complemento": {"COMPLEMENTO"},
            "bairro": {"BAIRRO"},
            "municipio": {"MUNICIPIO", "MUNICÍPIO", "CIDADE"},
            "uf": {"UF", "ESTADO"},
            "cep": {"CEP"}
        }

        placeholders_comuns = {
            "INDEFINIDO", "EM VALIDACAO", "EM VALIDAÇÃO",
            "EM BRANCO", "EM VILIDACAO", "EM VILIDAÇÃO",
            "EM NINF", "EM CONSULTA"
        }

        for campo, res in results.items():
            if not res or not res.valor:
                continue

            valor_original = res.valor
            placeholders = placeholders_por_campo.get(campo, set())

            # 1. Match exato (para todos)
            if res.valor in placeholders or res.valor in placeholders_comuns:
                res.transformacoes.append({
                    "campo": campo, "tipo": "limpeza",
                    "de": res.valor, "para": "",
                })
                res.valor = ""
                continue

            # 2. Remoção de prefixos redundantes (EXCETO bairro e municipio)
            # Para logradouro, removemos apenas se seguido de um tipo conhecido
            if campo == "logradouro":
                for p in placeholders:
                    for tipo in TIPOS_LOGRADOURO:
                        pattern = re.compile(rf"^{p}\s+({tipo})\b", re.IGNORECASE)
                        match = pattern.match(res.valor)
                        if match:
                            novo = pattern.sub(match.group(1), res.valor)
                            res.transformacoes.append({
                                "campo": campo, "tipo": "limpeza",
                                "de": res.valor, "para": novo,
                            })
                            res.valor = novo
                            break
                    else: continue
                    break
            
            # Para outros campos técnicos (numero, complemento), removemos o prefixo se seguido de algo
            elif campo in ("numero", "complemento"):
                for p in placeholders:
                    pattern = re.compile(rf"^{p}\s+", re.IGNORECASE)
                    if pattern.match(res.valor):
                        novo = pattern.sub("", res.valor).strip()
                        if novo:
                            res.transformacoes.append({
                                "campo": campo, "tipo": "limpeza",
                                "de": res.valor, "para": novo,
                            })
                            res.valor = novo
                            break

    def _remover_prefixo_duplicado(self, results: dict[str, PreprocessResult]) -> None:
        """Remove tipos de logradouro duplicados como 'RUA RUA TIA BELA'."""
        res = results.get("logradouro")
        if not res or not res.valor:
            return

        for tipo in TIPOS_LOGRADOURO:
            pattern = re.compile(rf"^({tipo})\s+\1\b", re.IGNORECASE)
            match = pattern.match(res.valor)
            if match:
                novo = pattern.sub(match.group(1), res.valor)
                res.transformacoes.append({
                    "campo": "logradouro", "tipo": "limpeza",
                    "de": res.valor, "para": novo,
                })
                res.valor = novo
                break

    def _remover_codigo_logradouro(self, results: dict[str, PreprocessResult]) -> None:
        """Remove códigos numéricos no início do logradouro (exceto contadores pequenos).

        Preserva contadores de 1 a 4 (ex: '1 TRAVESSA'). Remove valores > 4.
        """
        res = results.get("logradouro")
        if not res or not res.valor:
            return

        pattern = re.compile(r"^(\d+)\s+")
        match = pattern.match(res.valor)
        if match:
            numero_str = match.group(1)
            if len(numero_str) > 1 or int(numero_str) > 4:
                novo = pattern.sub("", res.valor)
                res.transformacoes.append({
                    "campo": "logradouro", "tipo": "limpeza",
                    "de": res.valor, "para": novo,
                })
                res.valor = novo

    def _separar_numero_logradouro(self, results: dict[str, PreprocessResult]) -> None:
        """Trata números colados no final do logradouro.

        Se o campo numero estiver vazio, separa o número.
        Se já estiver preenchido, considera vazamento no logradouro e apenas remove.
        """
        res_log = results.get("logradouro")
        res_num = results.get("numero")
        if not res_log or not res_log.valor:
            return

        numero_preenchido = res_num and res_num.valor and res_num.valor.strip() not in ("", "0")

        pattern = re.compile(r"^(.+?)\s+(\d{1,6})$")
        match = pattern.match(res_log.valor)
        if match:
            nome = match.group(1)
            numero = match.group(2)
            if not nome[-1].isdigit():
                res_log.transformacoes.append({
                    "campo": "logradouro", "tipo": "limpeza",
                    "de": res_log.valor, "para": nome,
                })
                res_log.valor = nome
                if not numero_preenchido:
                    res_num.transformacoes.append({
                        "campo": "numero", "tipo": "limpeza",
                        "de": res_num.valor, "para": numero,
                    })
                    res_num.valor = numero

    def _normalizar_cep(self, results: dict[str, PreprocessResult]) -> None:
        """Normaliza CEP com regras de padding e detecção de lixo.

        Regras:
        1. Remove tudo que não for dígito.
        2. Padding/ajuste:
           - len == 8: CEP íntegro.
           - len == 7: Adiciona 0 à esquerda (perda de formatação Excel).
           - len == 9 e começa com 0: Remove primeiro zero (exportação errônea).
           - Caso contrário: mantém e sinaliza como incorreto.
        3. Filtro de lixo: sequências repetidas, 12345678, 99999999.
        """
        res = results.get("cep")
        if not res or not res.valor:
            return

        original = res.valor
        digits = re.sub(r"\D", "", original)

        if not digits:
            res.cep_invalido = True
            return

        normalizado = digits
        cep_invalido = False

        if len(digits) == 8:
            normalizado = digits
        elif len(digits) == 7:
            normalizado = "0" + digits
            res.transformacoes.append({
                "campo": "cep", "tipo": "limpeza",
                "de": original, "para": normalizado,
                "regra_aplicada": "CEP_PADDING_7_DIGITOS",
            })
        elif len(digits) == 9 and digits.startswith("0"):
            normalizado = digits[1:]
            res.transformacoes.append({
                "campo": "cep", "tipo": "limpeza",
                "de": original, "para": normalizado,
                "regra_aplicada": "CEP_REMOVE_ZERO_EXTRA",
            })
        else:
            cep_invalido = True
            if digits != original:
                res.transformacoes.append({
                    "campo": "cep", "tipo": "limpeza",
                    "de": original, "para": digits,
                    "regra_aplicada": "CEP_LIMPEZA_CARACTERES",
                })
            normalizado = digits

        # Filtro de lixo
        if not cep_invalido and normalizado in CEPS_INVALIDOS:
            cep_invalido = True
            res.transformacoes.append({
                "campo": "cep", "tipo": "limpeza",
                "de": normalizado, "para": normalizado,
                "regra_aplicada": "CEP_PADRAO_INVALIDO",
            })

        res.valor = normalizado
        res.cep_invalido = cep_invalido

        # Registrar transformação de limpeza básica (remoção de caracteres)
        if not cep_invalido and normalizado != original and len(digits) == 8:
            # Só registra se não foi registrado por outra regra acima
            if not any(t.get("regra_aplicada", "").startswith("CEP_") for t in res.transformacoes):
                res.transformacoes.append({
                    "campo": "cep", "tipo": "limpeza",
                    "de": original, "para": normalizado,
                })

    def _normalizar_uf(self, results: dict[str, PreprocessResult]) -> None:
        """Garante UF em 2 caracteres uppercase."""
        res = results.get("uf")
        if not res or not res.valor:
            return

        normalizado = res.valor.strip().upper()[:2]
        if normalizado != res.valor:
            res.transformacoes.append({
                "campo": "uf", "tipo": "limpeza",
                "de": res.valor, "para": normalizado,
            })
            res.valor = normalizado
