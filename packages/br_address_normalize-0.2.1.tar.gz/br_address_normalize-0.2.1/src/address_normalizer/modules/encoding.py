"""Correção de logradouros com encoding corrompido (ISO-8859-1 → ASCII).

Vogais acentuadas foram removidas durante conversão de encoding, deixando
fragmentos como "JOO" (João), "ANT NIO" (Antônio), "CORA OES" (Corações).

Este módulo aplica regras de substituição ordenadas por especificidade
(mais longas/contextuais primeiro) para restaurar os nomes corretos.
"""

import re
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# A) Dicionário de regras: lista ordenada de (pattern_regex, replacement)
#
# ORDEM IMPORTA: regras mais específicas (com contexto/lookbehind) vêm antes
# das genéricas para evitar substituições parciais.
# ---------------------------------------------------------------------------

REGRAS_ENCODING: list[tuple[str, str]] = [
    # ===== GRUPO 1: Formas compostas com espaço (prefixo + sufixo) =====
    # IMPORTANTE: Nunca adicionar acentos. Substituir por versão sem acentos.

    # --- NIO (masculino) - nomes com terminação -ônio, -ênio, -ínio ---
    (r"\bANT\s+NIO\b", "ANTONIO"),
    (r"\bEUG\s+NIO\b", "EUGENIO"),
    (r"\bVIR\s+NIO\b", "VIRGINIO"),
    (r"\bHER\s+NIO\b", "HERMINIO"),
    (r"\bDOM\s+NIO\b", "DOMINIO"),
    (r"\bPATR\s+NIO\b", "PATRIMONIO"),
    (r"\bTEST\s+NIO\b", "TESTEMONIO"),
    (r"\bPATRIM\s+NIO\b", "PATRIMONIO"),
    (r"\bDEM\s+NIO\b", "DEMONIO"),
    (r"\bCOND\s+NIO\b", "CONDOMINIO"),
    (r"\bON\s+NIO\b", "ONENIO"),
    (r"\bPEL\s+NIO\b", "PELONIO"),
    (r"\bARS\s+NIO\b", "ARSENIO"),
    (r"\bSEL\s+NIO\b", "SELENIO"),
    (r"\bIR\s+NIO\b", "IRENIO"),
    (r"\bCEN\s+NIO\b", "CENENIO"),
    (r"\bLIC\s+NIO\b", "LICINIO"),
    (r"\bFUL\s+NIO\b", "FULGENCIO"),
    (r"\bMIN\s+NIO\b", "MINENIO"),
    (r"\bFLAM\s+NIO\b", "FLAMINIO"),
    (r"\bSAT\s+NIO\b", "SATURNINIO"),
    (r"\bLAV\s+NIO\b", "LAVINIO"),
    (r"\bJUV\s+NIO\b", "JUVENCIO"),  # variação rara

    # --- NIA (feminino) - nomes com terminação -ônia, -ênia, -ânia ---
    (r"\bANT\s+NIA\b", "ANTONIA"),
    (r"\bEFIG\s+NIA\b", "EFIGENIA"),
    (r"\bIFIG\s+NIA\b", "IFIGENIA"),
    (r"\bEUG\s+NIA\b", "EUGENIA"),
    (r"\bVIRG\s+NIA\b", "VIRGINIA"),
    (r"\bALEX\s+NIA\b", "ALEXANIA"),
    (r"\bGOI\s+NIA\b", "GOIANIA"),
    (r"\bBRIT\s+NIA\b", "BRITANNIA"),
    (r"\bCAMP\s+NIA\b", "CAMPANIA"),
    (r"\bLUS\s+NIA\b", "LUSANIA"),
    (r"\bURB\s+NIA\b", "URBANIA"),
    (r"\bSID\s+NIA\b", "SIDONIA"),
    (r"\bMAC\s+NIA\b", "MACEDONIA"),
    (r"\bPATR\s+NIA\b", "PATRIMANIA"),
    (r"\bHER\s+NIA\b", "HERMINIA"),
    (r"\bLAV\s+NIA\b", "LAVINIA"),
    (r"\bSARD\s+NIA\b", "SARDANIA"),

    # --- CIO - nomes com terminação -ácio, -ício, -úcio ---
    (r"\bIN\s+CIO\b", "INACIO"),
    (r"\bIGN\s+CIO\b", "IGNACIO"),
    (r"\bMAUR\s+CIO\b", "MAURICIO"),
    (r"\bPATR\s+CIO\b", "PATRICIO"),
    (r"\bFABR\s+CIO\b", "FABRICIO"),
    (r"\bVIN\s+CIO\b", "VINICIUS"),  # variação corrompida "VIN CIO"
    (r"\bBONIF\s+CIO\b", "BONIFACIO"),
    (r"\bHOR\s+CIO\b", "HORACIO"),
    (r"\bEUST\s+CIO\b", "EUSTAQUIO"),  # variação
    (r"\bLUCR\s+CIO\b", "LUCRECIO"),
    (r"\bTEREN\s+CIO\b", "TERENCIO"),
    (r"\bLAUR\s+CIO\b", "LAURENCIO"),
    (r"\bEV\s+CIO\b", "EVANCIO"),
    (r"\bCON\s+CIO\b", "CONSORCIO"),
    (r"\bCOM\s+CIO\b", "COMERCIO"),
    (r"\bNEG\s+CIO\b", "NEGOCIO"),
    (r"\bINN\s+CIO\b", "INOCENCIO"),
    (r"\bINOC\s+CIO\b", "INOCENCIO"),
    (r"\bDEM\s+CIO\b", "DEMOCIO"),

    # --- LIO - nomes com terminação -úlio, -ílio, -élio ---
    (r"\bGET\s+LIO\b", "GETULIO"),
    (r"\bJ\s+LIO\b", "JULIO"),
    (r"\bJU\s+LIO\b", "JULIO"),
    (r"\bEM\s+LIO\b", "EMILIO"),
    (r"\bAUR\s+LIO\b", "AURELIO"),
    (r"\bPERC\s+LIO\b", "PERCILIO"),
    (r"\bAT\s+LIO\b", "ATILIO"),
    (r"\bCEC\s+LIO\b", "CECILIO"),
    (r"\bVIRG\s+LIO\b", "VIRGILIO"),
    (r"\bBAS\s+LIO\b", "BASILIO"),
    (r"\bOV\s+LIO\b", "OVIDIO"),  # variação rara
    (r"\bOT\s+LIO\b", "OTILIO"),
    (r"\bCORN\s+LIO\b", "CORNELIO"),
    (r"\bROS\s+LIO\b", "ROSELIO"),
    (r"\bEV\s+LIO\b", "EVELIO"),
    (r"\bTUL\s+LIO\b", "TULIO"),
    (r"\bOF\s+LIO\b", "OFELIO"),
    (r"\bDE\s+LIO\b", "DELIO"),

    # --- OES - terminações -ões ---
    (r"\bCORA\s+OES\b", "CORACOES"),
    (r"\bNA\s+OES\b", "NACOES"),
    (r"\bLE\s+OES\b", "LEOES"),
    (r"\bFALC\s+OES\b", "FALCOES"),
    (r"\bTUBAR\s+OES\b", "TUBAROES"),
    (r"\bCAM\s+OES\b", "CAMOES"),
    (r"\bSERT\s+OES\b", "SERTOES"),
    (r"\bGIR\s+OES\b", "GIRONES"),
    (r"\bPAV\s+OES\b", "PAVOES"),
    (r"\bFALCOES\b", "FALCOES"),  # sem espaço, acento faltante
    (r"\bDRAG\s+OES\b", "DRAGOES"),
    (r"\bAVI\s+OES\b", "AVIOES"),

    # --- JOO - João ---
    (r"\bJOO\b", "JOO"),

    # --- JOS - José (acento removido) ---
    (r"\bJOS\b(?=\s+[A-Z])", "JOS"),  # "JOS" seguido de outro nome

    # --- IMO - Irmão ---
    (r"\bIMO\b(?=\s+[A-Z])", "IMO"),  # "IMO" seguido de nome próprio

    # --- IRMAO - Irmão (sem acento) ---
    (r"\bIRMAO\b", "IRMAO"),

    # --- OTAO - Otão ---
    (r"\bOTAO\b", "OTAO"),

    # ===== GRUPO 2: Terminações comuns sem espaço (acento faltante) =====

    (r"\bPRACA\b", "PRACA"),
    (r"\bSAO\b", "SAO"),
    (r"\bJOAO\b", "JOAO"),
    (r"\bSEBASTIAO\b", "SEBASTIAO"),
    (r"\bCONSTITUICAO\b", "CONSTITUICAO"),
    (r"\bCONCEICAO\b", "CONCEICAO"),
    (r"\bREDENCAO\b", "REDENCAO"),
    (r"\bASSUNCAO\b", "ASSUNCAO"),
    (r"\bEMILIO\b", "EMILIO"),
    (r"\bGETULIO\b", "GETULIO"),
    (r"\bANTONIO\b", "ANTONIO"),
    (r"\bJOSE\b", "JOSE"),

    # ===== GRUPO 3: Terminações genéricas (ÚLTIMO RECURSO) =====
    # Aplicadas apenas quando nenhuma regra contextual acima casou.
    # Estas são mais arriscadas e devem vir por último.
]

# Fragmentos que são altamente ambíguos e requerem revisão humana.
# Se encontrados isolados, a função sinaliza requer_revisao=True.
FRAGMENTOS_AMBIGUOS: list[str] = [
    r"\bRIA\b",       # pode ser -ária, -ória, Maria, etc.
    r"\bLIA\b",       # pode ser -ília, -ália, -élia, Amália, etc.
    r"\bNIO\b",       # sem prefixo, não se sabe qual nome
    r"\bNIA\b",       # sem prefixo, não se sabe qual nome
    r"\bCIO\b",       # sem prefixo, não se sabe qual nome
    r"\bLIO\b",       # sem prefixo, não se sabe qual nome
    r"\bOES\b",       # sem prefixo, não se sabe qual terminação -ões
]

# Pré-compilar as regras para performance
_REGRAS_COMPILADAS: list[tuple[re.Pattern, str]] = [
    (re.compile(pattern), replacement)
    for pattern, replacement in REGRAS_ENCODING
]

_AMBIGUOS_COMPILADOS: list[re.Pattern] = [
    re.compile(pattern) for pattern in FRAGMENTOS_AMBIGUOS
]


# ---------------------------------------------------------------------------
# B) Função principal
# ---------------------------------------------------------------------------

@dataclass
class EncodingFixResult:
    """Resultado da correção de encoding de um logradouro."""
    original: str
    corrigido: str
    alteracoes: list[str] = field(default_factory=list)
    requer_revisao: bool = False
    fragmentos_ambiguos: list[str] = field(default_factory=list)


def corrigir_logradouro(texto: str) -> EncodingFixResult:
    """Aplica regras de correção de encoding corrompido a um logradouro.

    Args:
        texto: Logradouro em UPPER CASE, possivelmente corrompido.

    Returns:
        EncodingFixResult com o texto corrigido, lista de alterações
        aplicadas e flag de revisão para fragmentos ambíguos.
    """
    resultado = EncodingFixResult(original=texto, corrigido=texto)

    # Aplicar regras na ordem definida (mais específicas primeiro)
    current = texto
    for pattern, replacement in _REGRAS_COMPILADAS:
        new_text = pattern.sub(replacement, current)
        if new_text != current:
            resultado.alteracoes.append(f"{pattern.pattern} → {replacement}")
            current = new_text

    resultado.corrigido = current

    # Verificar se restam fragmentos ambíguos não resolvidos
    for pattern in _AMBIGUOS_COMPILADOS:
        match = pattern.search(resultado.corrigido)
        if match:
            fragmento = match.group()
            resultado.requer_revisao = True
            resultado.fragmentos_ambiguos.append(fragmento)

    return resultado


def corrigir_logradouro_dict(texto: str) -> dict:
    """Versão dict-friendly de corrigir_logradouro para serialização."""
    r = corrigir_logradouro(texto)
    return {
        "original": r.original,
        "corrigido": r.corrigido,
        "alteracoes": r.alteracoes,
        "requer_revisao": r.requer_revisao,
        "fragmentos_ambiguos": r.fragmentos_ambiguos,
    }


# ---------------------------------------------------------------------------
# Integração com o Preprocessor do pipeline
# ---------------------------------------------------------------------------

def aplicar_correcao_encoding(valor: str) -> tuple[str, list[dict]]:
    """Aplica correção de encoding e retorna no formato do pipeline.

    Args:
        valor: Texto do campo (logradouro, bairro, etc).

    Returns:
        Tupla (valor_corrigido, lista_de_transformacoes).
    """
    result = corrigir_logradouro(valor)
    transformacoes = []
    if result.corrigido != result.original:
        transformacoes.append({
            "campo": "logradouro",
            "tipo": "encoding_fix",
            "de": result.original,
            "para": result.corrigido,
        })
    return result.corrigido, transformacoes


# ---------------------------------------------------------------------------
# D) Nota sobre integração PostgreSQL
# ---------------------------------------------------------------------------

POSTGRESQL_NOTES = """
-- =========================================================================
-- INTEGRAÇÃO POSTGRESQL: Correção de encoding com regexp_replace em cadeia
-- =========================================================================
--
-- No PostgreSQL, use \\y no lugar de \\b para word boundaries.
-- Exemplo de função PL/pgSQL que aplica as regras em cadeia:

CREATE OR REPLACE FUNCTION corrigir_encoding_logradouro(texto TEXT)
RETURNS TABLE(corrigido TEXT, requer_revisao BOOLEAN) AS $$
DECLARE
    resultado TEXT := texto;
    tem_ambiguidade BOOLEAN := FALSE;
BEGIN
    -- Grupo 1: Formas compostas com contexto (mais específicas primeiro)
    resultado := regexp_replace(resultado, '\\yANT\\s+NIO\\y', 'ANTONIO', 'g');
    resultado := regexp_replace(resultado, '\\yEUG\\s+NIO\\y', 'EUGENIO', 'g');
    resultado := regexp_replace(resultado, '\\yVIR\\s+NIO\\y', 'VIRGINIO', 'g');
    resultado := regexp_replace(resultado, '\\yHER\\s+NIO\\y', 'HERMINIO', 'g');

    resultado := regexp_replace(resultado, '\\yANT\\s+NIA\\y', 'ANTONIA', 'g');
    resultado := regexp_replace(resultado, '\\yEFIG\\s+NIA\\y', 'EFIGENIA', 'g');
    resultado := regexp_replace(resultado, '\\yVIRG\\s+NIA\\y', 'VIRGINIA', 'g');
    resultado := regexp_replace(resultado, '\\yGOI\\s+NIA\\y', 'GOIANIA', 'g');

    resultado := regexp_replace(resultado, '\\yIN\\s+CIO\\y', 'INACIO', 'g');
    resultado := regexp_replace(resultado, '\\yMAUR\\s+CIO\\y', 'MAURICIO', 'g');
    resultado := regexp_replace(resultado, '\\yFABR\\s+CIO\\y', 'FABRICIO', 'g');
    resultado := regexp_replace(resultado, '\\yBONIF\\s+CIO\\y', 'BONIFACIO', 'g');
    resultado := regexp_replace(resultado, '\\yHOR\\s+CIO\\y', 'HORACIO', 'g');
    resultado := regexp_replace(resultado, '\\yCOM\\s+CIO\\y', 'COMERCIO', 'g');

    resultado := regexp_replace(resultado, '\\yGET\\s+LIO\\y', 'GETULIO', 'g');
    resultado := regexp_replace(resultado, '\\yEM\\s+LIO\\y', 'EMILIO', 'g');
    resultado := regexp_replace(resultado, '\\yAUR\\s+LIO\\y', 'AURELIO', 'g');
    resultado := regexp_replace(resultado, '\\yJ\\s+LIO\\y', 'JULIO', 'g');
    resultado := regexp_replace(resultado, '\\yBAS\\s+LIO\\y', 'BASILIO', 'g');
    resultado := regexp_replace(resultado, '\\yCORN\\s+LIO\\y', 'CORNELIO', 'g');

    resultado := regexp_replace(resultado, '\\yCORA\\s+OES\\y', 'CORACOES', 'g');
    resultado := regexp_replace(resultado, '\\yNA\\s+OES\\y', 'NACOES', 'g');
    resultado := regexp_replace(resultado, '\\yLE\\s+OES\\y', 'LEOES', 'g');
    resultado := regexp_replace(resultado, '\\yCAM\\s+OES\\y', 'CAMOES', 'g');

    resultado := regexp_replace(resultado, '\\yJOO\\y', 'JOO', 'g');
    resultado := regexp_replace(resultado, '\\yIRMAO\\y', 'IRMAO', 'g');
    resultado := regexp_replace(resultado, '\\yOTAO\\y', 'OTAO', 'g');
    resultado := regexp_replace(resultado, '\\yPRACA\\y', 'PRACA', 'g');
    resultado := regexp_replace(resultado, '\\ySAO\\y', 'SAO', 'g');
    resultado := regexp_replace(resultado, '\\yJOAO\\y', 'JOAO', 'g');
    resultado := regexp_replace(resultado, '\\yANTONIO\\y', 'ANTONIO', 'g');
    resultado := regexp_replace(resultado, '\\yJOSE\\y', 'JOSE', 'g');
    resultado := regexp_replace(resultado, '\\yGETULIO\\y', 'GETULIO', 'g');
    resultado := regexp_replace(resultado, '\\yEMILIO\\y', 'EMILIO', 'g');

    -- Verificar fragmentos ambíguos remanescentes
    IF resultado ~ '\\yRIA\\y' OR resultado ~ '\\yLIA\\y'
       OR resultado ~ '\\yNIO\\y' OR resultado ~ '\\yNIA\\y'
       OR resultado ~ '\\yCIO\\y' OR resultado ~ '\\yLIO\\y'
       OR resultado ~ '\\yOES\\y' THEN
        tem_ambiguidade := TRUE;
    END IF;

    RETURN QUERY SELECT resultado, tem_ambiguidade;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Uso:
-- SELECT * FROM corrigir_encoding_logradouro('RUA ANT NIO ALVARENGA DE RESENDE');
-- → ('RUA ANTÔNIO ALVARENGA DE RESENDE', FALSE)
--
-- UPDATE enderecos SET
--   logradouro = (corrigir_encoding_logradouro(logradouro)).corrigido,
--   requer_revisao = (corrigir_encoding_logradouro(logradouro)).requer_revisao
-- WHERE logradouro ~ '\\y(JOO|NIO|NIA|CIO|LIO|OES|IMO|OTAO|IRMAO)\\y'
--    OR logradouro ~ '\\w+\\s+(NIO|NIA|CIO|LIO|OES)\\y';
"""
