"""Interactive mode command handlers."""
