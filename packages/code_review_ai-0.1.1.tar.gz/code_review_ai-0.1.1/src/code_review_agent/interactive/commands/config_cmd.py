"""Config commands: show, get, set, save, reset, validate."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import SecretStr
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from code_review_agent.theme import theme

if TYPE_CHECKING:
    from code_review_agent.interactive.session import SessionState

console = Console()

# Config keys grouped by category for display.
_CONFIG_CATEGORIES: dict[str, list[str]] = {
    "LLM": [
        "llm_provider",
        "llm_model",
        "llm_base_url",
        "llm_temperature",
        "llm_top_p",
        "llm_max_tokens",
        "llm_api_key",
        "request_timeout_seconds",
        "test_connection_on_start",
    ],
    "Token Budget": [
        "token_tier",
        "max_prompt_tokens",
        "max_tokens_per_review",
        "llm_input_price_per_m",
        "llm_output_price_per_m",
        "rate_limit_rpm",
    ],
    "Review": [
        "dedup_strategy",
        "max_review_seconds",
        "max_concurrent_agents",
        "default_agents",
    ],
    "Iterative Review": [
        "max_deepening_rounds",
        "is_validation_enabled",
        "max_validation_rounds",
    ],
    "GitHub": [
        "github_token",
        "max_pr_files",
        "github_rate_limit_warn_threshold",
        "pr_stale_days",
    ],
    "Custom Agents": [
        "custom_agents_dir",
    ],
    "History & Usage": [
        "history_db_path",
        "auto_save_history",
        "usage_window",
    ],
    "Interactive": [
        "interactive_history_file",
        "interactive_prompt",
        "interactive_vi_mode",
        "interactive_autocomplete_cache_ttl",
        "watch_debounce_seconds",
    ],
    "Logging": [
        "log_level",
    ],
}


def _mask_secret(value: object) -> str:
    """Mask secret values for display."""
    if isinstance(value, SecretStr):
        raw = value.get_secret_value()
        if len(raw) <= 8:
            return "****"
        return f"{raw[:4]}****{raw[-4:]}"
    return str(value) if value is not None else "[dim]not set[/dim]"


def _get_config_value(session: SessionState, key: str) -> object:
    """Get a config value, checking session overrides first."""
    # Virtual llm_api_key: map to {provider}_api_key
    if key == "llm_api_key":
        settings = session.effective_settings
        provider = settings.llm_provider
        real_key = f"{provider}_api_key"
        if real_key in session.config_overrides:
            return session.config_overrides[real_key]
        return getattr(session.settings, real_key, None)

    if key in session.config_overrides:
        return session.config_overrides[key]
    return getattr(session.settings, key, None)


def cmd_config(args: list[str], session: SessionState) -> None:
    """Show all config or a specific category."""
    if args and args[0] == "show":
        args = args[1:]
    if args and args[0] == "edit":
        from code_review_agent.interactive.commands.config_edit import cmd_config_edit

        return cmd_config_edit(args[1:], session)
    if args and args[0] == "get":
        return cmd_config_get(args[1:], session)
    if args and args[0] == "set":
        return cmd_config_set(args[1:], session)
    if args and args[0] == "save":
        return cmd_config_save(args[1:], session)
    if args and args[0] == "reset":
        return cmd_config_reset(args[1:], session)
    if args and args[0] == "validate":
        return cmd_config_validate(args[1:], session)
    if args and args[0] == "diff":
        return cmd_config_diff(args[1:], session)

    # Show specific category
    if args:
        category = args[0].upper()
        for cat_name, keys in _CONFIG_CATEGORIES.items():
            if cat_name.upper().startswith(category):
                _print_category(cat_name, keys, session)
                return
        console.print(f"[red]Unknown category: {args[0]}[/red]")
        console.print(f"Available: {', '.join(_CONFIG_CATEGORIES)}")
        return

    # Show all categories
    for cat_name, keys in _CONFIG_CATEGORIES.items():
        _print_category(cat_name, keys, session)


def _print_category(name: str, keys: list[str], session: SessionState) -> None:
    """Print a config category as a Rich table."""
    table = Table(show_header=False, show_edge=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold", width=35)
    table.add_column("Value")

    for key in keys:
        value = _get_config_value(session, key)
        display = _mask_secret(value)
        is_overridden = key in session.config_overrides
        if is_overridden:
            display = f"{display} [{theme.warning}](session override)[/{theme.warning}]"
        table.add_row(key, display)

    console.print(Panel(table, title=name, border_style="blue"))


def cmd_config_get(args: list[str], session: SessionState) -> None:
    """Show a single config value."""
    if not args:
        console.print("[red]Usage: config get <key>[/red]")
        return
    key = args[0]
    value = _get_config_value(session, key)
    if value is None and not hasattr(session.settings, key):
        console.print(f"[red]Unknown config key: {key}[/red]")
        return
    console.print(f"  {key} = {_mask_secret(value)}")


def cmd_config_set(args: list[str], session: SessionState) -> None:
    """Set a config value and persist to database immediately."""
    if len(args) < 2:
        console.print("[red]Usage: config set <key> <value>[/red]")
        return
    key = args[0]
    value = " ".join(args[1:])

    if not hasattr(session.settings, key):
        console.print(f"[red]Unknown config key: {key}[/red]")
        return

    session.config_overrides[key] = value
    session.invalidate_settings_cache()

    # Auto-save to DB immediately
    saved = save_config_to_db(session)
    persist_label = "(saved)" if saved else "(session only)"
    console.print(f"  [green]{key}[/green] = {value} [dim]{persist_label}[/dim]")

    # Show cost warning for cost-related keys
    _COST_KEYS = {"max_deepening_rounds", "is_validation_enabled", "max_validation_rounds"}
    if key in _COST_KEYS:
        multiplier, reasons = session.estimate_cost_multiplier()
        if multiplier > 1.0:
            console.print(
                f"\n  [{theme.warning}]! Cost impact:"
                f" ~{multiplier:.1f}x per review[/{theme.warning}]"
            )
            for reason in reasons:
                console.print(f"    [dim]{reason}[/dim]")

    # Run connection test for LLM-related config changes
    _LLM_SET = {
        "llm_provider",
        "llm_model",
        "llm_base_url",
        "nvidia_api_key",
        "openrouter_api_key",
    }
    if key in _LLM_SET and session.effective_settings.test_connection_on_start:
        from code_review_agent.interactive.repl import run_connection_test

        # Build previous config snapshot for revert
        prev: dict[str, str] = {}
        for k in ("llm_provider", "llm_model", "llm_base_url"):
            old_val = getattr(session.settings, k, None)
            if old_val is not None:
                prev[k] = str(old_val)
        run_connection_test(session, previous_llm_config=prev)


def cmd_config_save(args: list[str], session: SessionState) -> None:
    """Persist session config overrides to the database."""
    if not session.config_overrides:
        console.print("[dim]No session overrides to save.[/dim]")
        return

    saved = save_config_to_db(session)
    if saved:
        console.print(f"  [green]{saved} setting(s) saved to database[/green]")
        for key, value in session.config_overrides.items():
            console.print(f"    {key} = {value}")
        console.print("[dim]  Settings persist across restarts.[/dim]")
    else:
        console.print(f"[{theme.error}]Failed to save config[/{theme.error}]")


def save_config_to_db(session: SessionState) -> int:
    """Write config overrides to the database.

    Skips health marks and API keys (those are managed separately).
    Returns the number of settings saved.
    """
    from code_review_agent.storage import ReviewStorage

    try:
        settings = session.effective_settings
        storage = ReviewStorage(settings.history_db_path)
        count = 0
        for key, value in session.config_overrides.items():
            if key.startswith("health:") or key.endswith("_api_key"):
                continue
            storage.save_config(key, str(value))
            count += 1
        return count
    except Exception:
        return 0


def cmd_config_reset(args: list[str], session: SessionState) -> None:
    """Reload config from .env, discard all overrides (session + database)."""
    count = len(session.config_overrides)
    session.config_overrides.clear()
    session.invalidate_settings_cache()

    # Also clear persisted overrides from database
    try:
        from code_review_agent.storage import ReviewStorage

        storage = ReviewStorage(session.effective_settings.history_db_path)
        storage.clear_all_config()
    except Exception:  # noqa: S110
        pass

    console.print(f"  [green]Reset {count} override(s). Config reloaded from .env.[/green]")


def cmd_config_validate(args: list[str], session: SessionState) -> None:
    """Validate current config."""
    try:
        from code_review_agent.config import Settings

        Settings()
        console.print("[green]Config is valid.[/green]")
    except Exception as exc:
        console.print(f"[red]Config validation error: {exc}[/red]")


def cmd_config_diff(args: list[str], session: SessionState) -> None:
    """Show differences between session and .env config."""
    if not session.config_overrides:
        console.print("[dim]No session overrides. Config matches .env.[/dim]")
        return
    for key, value in session.config_overrides.items():
        original = getattr(session.settings, key, None)
        display_new = "****" if key.endswith("_api_key") or key == "llm_api_key" else value
        console.print(f"  {key}: {_mask_secret(original)} -> {display_new}")
