"""
DataDocked MCP Server
Maritime data API integration for AI assistants
"""

__version__ = "1.0.0"
