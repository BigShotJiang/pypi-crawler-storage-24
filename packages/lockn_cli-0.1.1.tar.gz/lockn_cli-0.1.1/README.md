# lockn-cli

**LockN CLI — AI orchestration toolkit for local model management and hardware profiling.**

## Install

```bash
pip install lockn-cli
```

## Usage

```bash
# Detect your hardware
lockn init

# See which AI models fit your machine
lockn models recommend

# List all available models
lockn models list

# Check status
lockn status
```

## About

LockN CLI is part of the [LockN](https://lockn.ai) platform — AI-powered workflow orchestration, agent management, and intelligent automation.

## License

[FSL-1.1-ALv2](./LICENSE.md) — Functional Source License, converting to Apache 2.0 after two years.

Copyright 2026 OneSun Labs LLC.
