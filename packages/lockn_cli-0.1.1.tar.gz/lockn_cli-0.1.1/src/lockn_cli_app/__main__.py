"""Allow running as python -m lockn_cli_app."""
from lockn_cli_app.cli import cli

cli()
