"""LockN CLI — Local AI model management and hardware profiling."""
from __future__ import annotations

import sys

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from lockn_cli_app import __version__
from lockn_cli_app.config import NodeProfile, ensure_dirs, get_installed_models
from lockn_cli_app.hardware import detect_hardware
from lockn_cli_app.registry import get_catalog, get_model, recommend_models

console = Console()


@click.group()
@click.version_option(__version__, prog_name="lockn")
def cli():
    """🔒 LockN CLI — AI orchestration toolkit."""
    pass


@cli.command()
def init():
    """Detect hardware and create a local profile."""
    ensure_dirs()

    with console.status("[bold blue]Detecting hardware..."):
        profile = detect_hardware()
        profile.save()

    console.print(Panel.fit(
        f"[bold green]✅ Initialized![/]\n\n"
        f"  Chip:     {profile.chip or 'Unknown'}\n"
        f"  Memory:   {profile.total_memory_gb} GB\n"
        f"  Free:     {profile.available_memory_gb} GB available\n"
        f"  Disk:     {profile.disk_free_gb} GB free\n"
        f"  GPU:      {profile.gpu_cores} cores\n"
        f"  Platform: {profile.platform}\n"
        f"  OS:       {profile.os_version}\n"
        f"  Node ID:  {profile.node_id}",
        title="LockN Profile",
    ))

    recommended = recommend_models(profile.total_memory_gb)
    if recommended:
        console.print(f"\n[bold]Your machine ({profile.total_memory_gb}GB) can run these models:[/]\n")
        _print_model_table(recommended)
    else:
        console.print("\n[yellow]No compatible models found for your hardware.[/]")


@cli.group()
def models():
    """Manage local AI models."""
    pass


@models.command("recommend")
def models_recommend():
    """Show models that fit your hardware."""
    profile = NodeProfile.load()
    if profile is None:
        console.print("[red]Run `lockn init` first to detect hardware.[/]")
        sys.exit(1)

    recommended = recommend_models(profile.total_memory_gb)
    if not recommended:
        console.print("[yellow]No models fit your hardware.[/]")
        return

    console.print(f"\n[bold]Recommended models for {profile.total_memory_gb}GB memory:[/]\n")
    _print_model_table(recommended)


@models.command("list")
def models_list():
    """Show all available models."""
    catalog = get_catalog()
    if not catalog:
        console.print("[yellow]No models in catalog.[/]")
        return

    _print_model_table(catalog)


@models.command("installed")
def models_installed():
    """Show installed models."""
    installed = get_installed_models()
    if not installed:
        console.print("[yellow]No models installed. Run `lockn models install <model-id>`[/]")
        return

    table = Table(title="Installed Models")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Size", justify="right")
    table.add_column("Tier", style="magenta")

    for mid, info in installed.items():
        table.add_row(mid, info["name"], f"{info['size_gb']}GB", info["tier"])

    console.print(table)


@cli.command()
def status():
    """Show current LockN status."""
    profile = NodeProfile.load()
    installed = get_installed_models()
    model_list = ", ".join(installed.keys()) if installed else "none"

    if not profile:
        console.print(Panel.fit(
            "[yellow]Not initialized[/]\n\n"
            "  Run [bold]lockn init[/] to get started.",
            title="🔒 LockN Status",
        ))
        return

    console.print(Panel.fit(
        f"  Node ID:  {profile.node_id}\n"
        f"  Platform: {profile.platform}\n"
        f"  Memory:   {profile.total_memory_gb} GB\n"
        f"  GPU:      {profile.gpu_cores} cores\n"
        f"  Models:   {model_list}",
        title="🔒 LockN Status",
    ))


def _print_model_table(models_list):
    table = Table()
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Active Params")
    table.add_column("Size", justify="right")
    table.add_column("Min RAM", justify="right")
    table.add_column("Tier", style="magenta")
    table.add_column("Capabilities")

    for m in models_list:
        table.add_row(
            m.id,
            m.name,
            m.active_params,
            f"{m.size_gb}GB",
            f"{m.min_memory_gb}GB",
            m.tier,
            ", ".join(m.capabilities),
        )

    console.print(table)
