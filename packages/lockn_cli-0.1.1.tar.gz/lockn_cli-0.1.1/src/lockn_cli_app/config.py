"""Node profile and configuration management."""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

LOCKN_POOL_DIR = Path.home() / ".lockn-node"
NODE_PROFILE_PATH = LOCKN_POOL_DIR / "node-profile.json"
MODELS_DIR = LOCKN_POOL_DIR / "models"
INSTALLED_MODELS_PATH = LOCKN_POOL_DIR / "installed-models.json"


@dataclass
class NodeProfile:
    chip: str = ""
    total_memory_gb: float = 0.0
    available_memory_gb: float = 0.0
    disk_free_gb: float = 0.0
    gpu_cores: int = 0
    os_version: str = ""
    platform: str = ""  # "macos-arm64", "macos-x86", "linux-x86", etc.
    node_id: str = ""
    capabilities: list[str] = field(default_factory=list)

    def save(self) -> None:
        NODE_PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
        NODE_PROFILE_PATH.write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def load(cls) -> Optional["NodeProfile"]:
        if not NODE_PROFILE_PATH.exists():
            return None
        data = json.loads(NODE_PROFILE_PATH.read_text())
        return cls(**data)


def ensure_dirs() -> None:
    """Create the lockn-node directory structure."""
    for d in [LOCKN_POOL_DIR, MODELS_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def get_installed_models() -> dict:
    """Load installed models registry."""
    if not INSTALLED_MODELS_PATH.exists():
        return {}
    return json.loads(INSTALLED_MODELS_PATH.read_text())


def save_installed_models(models: dict) -> None:
    """Save installed models registry."""
    INSTALLED_MODELS_PATH.write_text(json.dumps(models, indent=2))
