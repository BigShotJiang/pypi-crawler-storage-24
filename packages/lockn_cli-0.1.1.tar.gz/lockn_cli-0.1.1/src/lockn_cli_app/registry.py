"""Curated MLX model catalog."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ModelEntry:
    id: str
    name: str
    mlx_repo: str
    active_params: str
    size_gb: float
    min_memory_gb: float
    context_length: int
    capabilities: list[str] = field(default_factory=list)
    tier: str = "Pro"

    def fits(self, total_memory_gb: float) -> bool:
        return self.min_memory_gb <= total_memory_gb


MODEL_CATALOG: list[ModelEntry] = [
    ModelEntry(
        id="phi-4-mini-4bit",
        name="Phi-4 Mini (4-bit)",
        mlx_repo="mlx-community/Phi-4-mini-instruct-4bit",
        active_params="3.8B",
        size_gb=2.5,
        min_memory_gb=8,
        context_length=16384,
        capabilities=["chat", "code"],
        tier="Nano",
    ),
    ModelEntry(
        id="qwen3-8b-4bit",
        name="Qwen3 8B (4-bit)",
        mlx_repo="mlx-community/Qwen3-8B-4bit",
        active_params="8B",
        size_gb=5.0,
        min_memory_gb=12,
        context_length=32768,
        capabilities=["chat", "reasoning"],
        tier="Lite",
    ),
    ModelEntry(
        id="deepseek-r1-qwen3-8b-4bit",
        name="DeepSeek R1 0528 Qwen3-8B (4-bit)",
        mlx_repo="mlx-community/DeepSeek-R1-0528-Qwen3-8B-4bit",
        active_params="8B",
        size_gb=5.0,
        min_memory_gb=12,
        context_length=32768,
        capabilities=["chat", "reasoning", "math"],
        tier="Lite",
    ),
    ModelEntry(
        id="mistral-small-3.1-4bit",
        name="Mistral Small 3.1 24B (4-bit)",
        mlx_repo="mlx-community/Mistral-Small-3.1-24B-Instruct-2503-4bit",
        active_params="24B",
        size_gb=13.0,
        min_memory_gb=20,
        context_length=32768,
        capabilities=["chat", "code", "vision"],
        tier="Pro",
    ),
    ModelEntry(
        id="gemma-3-27b-4bit",
        name="Gemma 3 27B (4-bit)",
        mlx_repo="mlx-community/gemma-3-27b-it-4bit",
        active_params="27B",
        size_gb=15.0,
        min_memory_gb=24,
        context_length=8192,
        capabilities=["chat", "vision"],
        tier="Pro",
    ),
    ModelEntry(
        id="qwen3.5-27b-4bit",
        name="Qwen3.5 27B (4-bit)",
        mlx_repo="mlx-community/Qwen3.5-27B-4bit",
        active_params="27B",
        size_gb=15.0,
        min_memory_gb=24,
        context_length=32768,
        capabilities=["chat", "reasoning", "code", "vision"],
        tier="Pro",
    ),
    ModelEntry(
        id="qwen3-30b-a3b-4bit",
        name="Qwen3 30B-A3B MoE (4-bit)",
        mlx_repo="mlx-community/Qwen3-30B-A3B-4bit",
        active_params="3B",
        size_gb=17.0,
        min_memory_gb=24,
        context_length=32768,
        capabilities=["chat", "reasoning"],
        tier="Flash",
    ),
    ModelEntry(
        id="llama-4-scout-4bit",
        name="Llama 4 Scout 17B-16E (4-bit)",
        mlx_repo="mlx-community/Llama-4-Scout-17B-16E-Instruct-4bit",
        active_params="~17B active",
        size_gb=30.0,
        min_memory_gb=48,
        context_length=131072,
        capabilities=["chat", "vision", "multilingual"],
        tier="Pro",
    ),
    ModelEntry(
        id="qwen3.5-122b-a10b-4bit",
        name="Qwen3.5 122B-A10B MoE (4-bit)",
        mlx_repo="mlx-community/Qwen3.5-397B-A17B-4bit",  # Closest available
        active_params="10B",
        size_gb=65.0,
        min_memory_gb=80,
        context_length=32768,
        capabilities=["chat", "reasoning", "code"],
        tier="Ultra",
    ),
]


def get_catalog() -> list[ModelEntry]:
    return MODEL_CATALOG


def get_model(model_id: str) -> Optional[ModelEntry]:
    for m in MODEL_CATALOG:
        if m.id == model_id:
            return m
    return None


def recommend_models(total_memory_gb: float) -> list[ModelEntry]:
    """Return models that fit in the given memory, sorted by size descending."""
    fits = [m for m in MODEL_CATALOG if m.fits(total_memory_gb)]
    return sorted(fits, key=lambda m: m.size_gb, reverse=True)
