"""Hardware detection for macOS Apple Silicon (extensible to other platforms)."""
from __future__ import annotations

import json
import platform
import shutil
import subprocess
import uuid
from pathlib import Path

from lockn_cli_app.config import NodeProfile


def _run(cmd: list[str]) -> str:
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ""


def _detect_chip() -> str:
    return _run(["sysctl", "-n", "machdep.cpu.brand_string"])


def _detect_total_memory_gb() -> float:
    raw = _run(["sysctl", "-n", "hw.memsize"])
    if raw:
        return int(raw) / (1024 ** 3)
    return 0.0


def _detect_available_memory_gb() -> float:
    """Parse vm_stat for a rough available memory estimate."""
    raw = _run(["vm_stat"])
    if not raw:
        return 0.0
    page_size = 16384  # Apple Silicon default
    free_pages = 0
    for line in raw.splitlines():
        if "page size of" in line:
            try:
                page_size = int(line.split("page size of")[1].strip().rstrip("."))
            except ValueError:
                pass
        for key in ("Pages free", "Pages inactive", "Pages purgeable"):
            if line.startswith(key):
                try:
                    free_pages += int(line.split(":")[1].strip().rstrip("."))
                except ValueError:
                    pass
    return (free_pages * page_size) / (1024 ** 3)


def _detect_disk_free_gb() -> float:
    usage = shutil.disk_usage(Path.home())
    return usage.free / (1024 ** 3)


def _detect_gpu_cores() -> int:
    raw = _run(["system_profiler", "SPDisplaysDataType", "-json"])
    if not raw:
        return 0
    try:
        data = json.loads(raw)
        displays = data.get("SPDisplaysDataType", [])
        for d in displays:
            cores_str = d.get("sppci_cores", "")
            if cores_str:
                return int(cores_str)
    except (json.JSONDecodeError, ValueError):
        pass
    return 0


def _detect_platform() -> str:
    machine = platform.machine().lower()
    system = platform.system().lower()
    if system == "darwin":
        return f"macos-{'arm64' if machine == 'arm64' else 'x86'}"
    return f"{system}-{machine}"


def detect_hardware() -> NodeProfile:
    """Detect hardware and return a NodeProfile."""
    sys = platform.system()
    is_mac = sys == "Darwin"
    is_arm = platform.machine() == "arm64"

    profile = NodeProfile(
        platform=_detect_platform(),
        os_version=platform.mac_ver()[0] if is_mac else platform.release(),
        node_id=str(uuid.uuid4())[:8],
    )

    if is_mac:
        profile.chip = _detect_chip()
        profile.total_memory_gb = round(_detect_total_memory_gb(), 1)
        profile.available_memory_gb = round(_detect_available_memory_gb(), 1)
        profile.disk_free_gb = round(_detect_disk_free_gb(), 1)
        profile.gpu_cores = _detect_gpu_cores()

    if is_mac and is_arm:
        profile.capabilities = ["mlx", "metal", "unified-memory"]
    elif is_mac:
        profile.capabilities = ["metal"]
    else:
        profile.capabilities = []

    return profile
