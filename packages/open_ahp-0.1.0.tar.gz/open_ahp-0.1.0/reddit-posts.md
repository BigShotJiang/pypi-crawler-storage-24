# Reddit Posts — Agent History Protocol Launch

---

## r/opensource

**Title:** I built an open standard for tamper-evident AI agent observability — Agent History Protocol

**Body:**

Hey r/opensource,

I've been working on Agent History Protocol (AHP) — an open standard for recording what AI agents actually do, in a tamper-evident way.

**The problem:** AI agents are increasingly autonomous — making API calls, using tools via MCP, communicating with other agents via A2A, getting LLM responses. But there's no common observability protocol across frameworks. Every platform logs differently, most don't log at all, and nothing is tamper-proof.

As agents move into critical areas (healthcare, finance, infrastructure) and start interacting across organizational boundaries, this becomes a real reliability and security gap.

**What AHP does:** It hash-chains every agent action into an append-only, cryptographically linked record. If any record is modified, deleted, inserted, or reordered — the hash chain breaks and verification catches it instantly.

Three conformance levels:
- Level 1: Hash-chained recording
- Level 2: Ed25519 cryptographic signing
- Level 3: Independent witness servers (tamper-proof even if the agent deletes its own chain)

Python and TypeScript SDKs with auto-instrumentation — drop-in, no code changes needed.

Would love feedback on the spec and implementation. The full specification, SDKs, and a multi-agent demo with real LLM calls are all in the repo.

GitHub: https://github.com/iamanandsingh/agent-history-protocol

License: Apache 2.0

---

## r/coolgithubprojects

**Title:** Agent History Protocol — tamper-evident flight recorder for AI agents (Python & TypeScript)

**Body:**

AHP is an open standard that hash-chains every AI agent action (HTTP calls, MCP tool use, A2A messages, LLM inferences, authorization decisions) into tamper-evident, append-only records.

If any record is modified, deleted, or reordered — verification fails instantly. Like a flight recorder for AI agents.

- Framework-agnostic — Python and TypeScript SDKs
- Auto-instrumentation (drop-in, no code changes)
- CLI for verification, gap detection, filtering, export
- 3 conformance levels: recording → signing → independent witnesses
- Apache 2.0 licensed

https://github.com/iamanandsingh/agent-history-protocol

---

## r/sideproject

**Title:** Built an open standard for AI agent observability — looking for feedback

**Body:**

Hey everyone,

I've been working on this for a while and finally got it to a point where I'd love outside feedback.

**What it is:** Agent History Protocol (AHP) — an open standard for tamper-evident recording of every action an AI agent takes.

**Why I built it:** AI agents are everywhere now, making real decisions — but there's no common way to know what they actually did. Every framework logs differently, hallucination is still unsolved, and nothing is tamper-proof. As agents move into sensitive areas and start interacting across organizations, this felt like a missing piece of infrastructure.

**How it works:** Every HTTP call, MCP tool use, A2A message, LLM inference, and authorization decision gets a hash-chained, append-only record. Modify anything and the chain breaks. Three levels — basic recording, cryptographic signing, and independent witnesses.

**Tech stack:** Python and TypeScript SDKs, auto-instrumentation, CLI tools. Apache 2.0 licensed.

The repo has the full specification, both SDKs, and a multi-agent demo running on real Gemini Flash API calls.

GitHub: https://github.com/iamanandsingh/agent-history-protocol

Would love to hear what you think — especially if you're building agents in production and dealing with observability gaps.

---

## r/Python (if karma allows)

**Title:** [Show Python] Agent History Protocol — tamper-evident recording for AI agent actions

**Body:**

I built a Python SDK for Agent History Protocol (AHP) — an open standard for hash-chained, tamper-evident recording of AI agent actions.

Quick start:

```bash
pip install ahp-sdk
```

```python
from ahp.core.chain import ChainWriter
from ahp.core.records import BootPayload

writer = ChainWriter("agent.ahp")
writer.write_boot(BootPayload(agent_name="my-agent", sdk_name="ahp-py", sdk_version="0.1.0"))

# Auto-instrumentation intercepts HTTP/requests/httpx calls automatically
# Every action gets a hash-chained, append-only record
```

TypeScript: `npm install open-ahp`

Verify the chain:

```bash
ahp verify --chain agent.ahp
ahp log --chain agent.ahp
```

The SDK auto-instruments urllib, requests, and httpx — drop it into any existing agent system and it records every HTTP call, MCP tool use, A2A message, and LLM inference with no code changes.

Three conformance levels: basic hash-chaining → Ed25519 signing → independent witness servers.

TypeScript SDK also available with fetch interceptor.

GitHub: https://github.com/iamanandsingh/agent-history-protocol

Apache 2.0 licensed. Feedback welcome.

---

## General Tips

- **Don't post in all subreddits on the same day** — Reddit flags this as spam
- **Space them out:** Post in r/coolgithubprojects today, r/opensource tomorrow, r/sideproject day after
- **Engage with every comment** — Reddit rewards active makers
- **Build karma first** by commenting genuinely on other posts in these communities
- **Never say "please upvote"** — instant credibility killer on Reddit
