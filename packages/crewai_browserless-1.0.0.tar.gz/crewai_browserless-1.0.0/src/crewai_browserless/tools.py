import os
from typing import Optional

import requests
from crewai.tools import BaseTool, EnvVar
from pydantic import BaseModel, Field


class BrowserlessSmartScrapeInput(BaseModel):
    """Input schema for BrowserlessSmartScrapeTool."""

    url: str = Field(..., description="The URL to scrape (http or https only).")
    formats: list[str] = Field(
        default=["markdown"],
        description=(
            "Output formats to return. "
            "Options: 'markdown', 'html', 'screenshot', 'pdf', 'links'. "
            "Defaults to ['markdown']."
        ),
    )
    timeout: Optional[int] = Field(
        default=None,
        description="Request timeout in milliseconds. Uses server default if not set.",
    )


class BrowserlessSmartScrapeTool(BaseTool):
    name: str = "Browserless Smart Scrape"
    description: str = (
        "Scrapes a web page using the Browserless /smart-scrape API. "
        "Automatically handles anti-bot detection, captchas, and proxying. "
        "Returns content in the requested formats (markdown, html, screenshot, pdf, links). "
        "Best used when you need clean, readable content from a web page."
    )
    args_schema: type[BaseModel] = BrowserlessSmartScrapeInput
    env_vars: list[EnvVar] = [
        EnvVar(
            name="BROWSERLESS_API_URL",
            description="Base URL of the Browserless instance. Defaults to https://production-sfo.browserless.io.",
            required=False,
        ),
        EnvVar(
            name="BROWSERLESS_API_TOKEN",
            description="API token for authenticating with Browserless.",
            required=True,
        ),
    ]

    def _run(self, url: str, formats: list[str] | None = None, timeout: int | None = None) -> str:
        api_url = os.environ.get("BROWSERLESS_API_URL", "https://production-sfo.browserless.io").rstrip("/")
        token = os.environ["BROWSERLESS_API_TOKEN"]

        endpoint = f"{api_url}/smart-scrape"
        params: dict[str, str] = {"token": token}
        if timeout is not None:
            params["timeout"] = str(timeout)

        body: dict = {"url": url}
        if formats is not None:
            body["formats"] = formats

        response = requests.post(endpoint, json=body, params=params, timeout=120)
        response.raise_for_status()

        data = response.json()

        if not data.get("ok"):
            message = data.get("message", "Unknown error")
            strategy = data.get("strategy", "unknown")
            return f"Scrape failed (strategy: {strategy}): {message}"

        parts: list[str] = []

        if data.get("markdown"):
            parts.append(data["markdown"])
        elif data.get("content"):
            content = data["content"]
            parts.append(content if isinstance(content, str) else str(content))

        if data.get("links"):
            parts.append("\n## Links\n" + "\n".join(f"- {link}" for link in data["links"]))

        if data.get("screenshot"):
            parts.append(f"\n[Screenshot available as base64 PNG, {len(data['screenshot'])} chars]")

        if data.get("pdf"):
            parts.append(f"\n[PDF available as base64, {len(data['pdf'])} chars]")

        return "\n\n".join(parts) if parts else "No content returned."
