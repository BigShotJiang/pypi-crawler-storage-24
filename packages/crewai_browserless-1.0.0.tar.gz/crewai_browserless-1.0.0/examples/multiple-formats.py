from crewai_browserless import BrowserlessSmartScrapeTool

tool = BrowserlessSmartScrapeTool()

# HTML
print(tool.run(url="https://example.com", formats=["html"]))

# Markdown (default)
print(tool.run(url="https://example.com", formats=["markdown"]))

# Links only
print(tool.run(url="https://example.com", formats=["links"]))

# Multiple formats at once
print(tool.run(url="https://example.com", formats=["markdown", "links"]))

# With a custom timeout (in milliseconds)
print(tool.run(url="https://example.com", formats=["markdown"], timeout=60000))