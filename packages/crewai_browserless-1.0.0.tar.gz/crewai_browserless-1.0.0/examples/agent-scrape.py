from crewai import Agent, Crew, Task
from crewai_browserless import BrowserlessSmartScrapeTool

agent = Agent(
    role="Web Researcher",
    goal="Scrape web pages and summarize their content.",
    backstory="An expert at extracting useful information from websites.",
    tools=[BrowserlessSmartScrapeTool()],
)

task = Task(
    description="Scrape https://www.browserless.io/blog/java-memory-leak and summarize what the page is about.",
    expected_output="A short summary of the page content.",
    agent=agent,
)

crew = Crew(agents=[agent], tasks=[task])
result = crew.kickoff()

print(result)