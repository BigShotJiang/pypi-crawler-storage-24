from crewai_browserless import BrowserlessSmartScrapeTool

tool = BrowserlessSmartScrapeTool()

# Call the tool directly
result = tool.run(url="https://en.wikipedia.org/wiki/Headless_browser", formats=["markdown"])

print(result)