# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateArtifactoryResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'status': 'str',
        'trace_id': 'str',
        'result': 'object'
    }

    attribute_map = {
        'status': 'status',
        'trace_id': 'trace_id',
        'result': 'result'
    }

    def __init__(self, status=None, trace_id=None, result=None):
        r"""UpdateArtifactoryResponse

        The model defined in huaweicloud sdk

        :param status: 结果状态
        :type status: str
        :param trace_id: 请求id
        :type trace_id: str
        :param result: 请求返回结果，接口不同，返回不同
        :type result: object
        """
        
        super().__init__()

        self._status = None
        self._trace_id = None
        self._result = None
        self.discriminator = None

        if status is not None:
            self.status = status
        if trace_id is not None:
            self.trace_id = trace_id
        if result is not None:
            self.result = result

    @property
    def status(self):
        r"""Gets the status of this UpdateArtifactoryResponse.

        结果状态

        :return: The status of this UpdateArtifactoryResponse.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this UpdateArtifactoryResponse.

        结果状态

        :param status: The status of this UpdateArtifactoryResponse.
        :type status: str
        """
        self._status = status

    @property
    def trace_id(self):
        r"""Gets the trace_id of this UpdateArtifactoryResponse.

        请求id

        :return: The trace_id of this UpdateArtifactoryResponse.
        :rtype: str
        """
        return self._trace_id

    @trace_id.setter
    def trace_id(self, trace_id):
        r"""Sets the trace_id of this UpdateArtifactoryResponse.

        请求id

        :param trace_id: The trace_id of this UpdateArtifactoryResponse.
        :type trace_id: str
        """
        self._trace_id = trace_id

    @property
    def result(self):
        r"""Gets the result of this UpdateArtifactoryResponse.

        请求返回结果，接口不同，返回不同

        :return: The result of this UpdateArtifactoryResponse.
        :rtype: object
        """
        return self._result

    @result.setter
    def result(self, result):
        r"""Sets the result of this UpdateArtifactoryResponse.

        请求返回结果，接口不同，返回不同

        :param result: The result of this UpdateArtifactoryResponse.
        :type result: object
        """
        self._result = result

    def to_dict(self):
        import warnings
        warnings.warn("UpdateArtifactoryResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateArtifactoryResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
