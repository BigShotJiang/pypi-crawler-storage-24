"""
Tests for sinc_prompt core functions.

Run with: python -m pytest tests/ -v
Or:       python -m unittest tests.test_core -v
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

# Ensure the package is importable from the repo root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sinc_prompt import (
    validate,
    parse,
    format_prompt,
    compute_snr,
    nyquist_completeness,
    scatter,
    to_json,
    SincFragment,
    SincPrompt,
    SINC_BANDS,
    BAND_IMPORTANCE,
)


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

VALID_SINC_JSON = {
    "formula": "x(t) = Sigma x(nT) * sinc((t - nT) / T)",
    "T": "specification-axis",
    "fragments": [
        {"n": 0, "t": "PERSONA", "x": "You are a senior Python developer."},
        {"n": 1, "t": "CONTEXT", "x": "The user has a Django REST API project."},
        {"n": 2, "t": "DATA", "x": "The error traceback shows a 500 on /api/users/."},
        {"n": 3, "t": "CONSTRAINTS", "x": "Do not modify the database schema. Use only stdlib. Keep backward compatibility. Must pass all existing tests. Do not add new dependencies. Follow PEP 8."},
        {"n": 4, "t": "FORMAT", "x": "Return the fix as a unified diff. Include a one-sentence root cause. Show the test command and output."},
        {"n": 5, "t": "TASK", "x": "Fix the 500 error on the users endpoint."},
    ],
}

MINIMAL_SINC_JSON = {
    "formula": "x(t) = Sigma x(nT) * sinc((t - nT) / T)",
    "T": "spec",
    "fragments": [
        {"n": 5, "t": "TASK", "x": "Hello world."},
    ],
}


class TestValidate(unittest.TestCase):
    """Tests for validate()."""

    def test_valid_full_prompt(self):
        is_valid, errors = validate(VALID_SINC_JSON)
        self.assertTrue(is_valid)
        self.assertEqual(errors, [])

    def test_valid_minimal_prompt(self):
        is_valid, errors = validate(MINIMAL_SINC_JSON)
        self.assertTrue(is_valid)
        self.assertEqual(errors, [])

    def test_valid_json_string(self):
        json_str = json.dumps(VALID_SINC_JSON)
        is_valid, errors = validate(json_str)
        self.assertTrue(is_valid)
        self.assertEqual(errors, [])

    def test_valid_file_path(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".sinc.json", delete=False
        ) as f:
            json.dump(VALID_SINC_JSON, f)
            f.flush()
            path = f.name
        try:
            is_valid, errors = validate(Path(path))
            self.assertTrue(is_valid)
            self.assertEqual(errors, [])
        finally:
            os.unlink(path)

    def test_missing_formula(self):
        bad = {k: v for k, v in VALID_SINC_JSON.items() if k != "formula"}
        is_valid, errors = validate(bad)
        self.assertFalse(is_valid)
        self.assertTrue(any("formula" in e for e in errors))

    def test_missing_fragments(self):
        bad = {"formula": "x", "T": "t"}
        is_valid, errors = validate(bad)
        self.assertFalse(is_valid)
        self.assertTrue(any("fragments" in e for e in errors))

    def test_empty_content(self):
        bad = dict(VALID_SINC_JSON)
        bad["fragments"] = [{"n": 0, "t": "PERSONA", "x": "   "}]
        is_valid, errors = validate(bad)
        self.assertFalse(is_valid)
        self.assertTrue(any("non-empty" in e for e in errors))

    def test_invalid_band_name(self):
        bad = dict(VALID_SINC_JSON)
        bad["fragments"] = [{"n": 0, "t": "INVALID_BAND", "x": "content"}]
        is_valid, errors = validate(bad)
        self.assertFalse(is_valid)
        self.assertTrue(any("INVALID_BAND" in e for e in errors))

    def test_wrong_n_for_band(self):
        bad = dict(VALID_SINC_JSON)
        bad["fragments"] = [{"n": 3, "t": "PERSONA", "x": "content"}]
        is_valid, errors = validate(bad)
        self.assertFalse(is_valid)
        self.assertTrue(any("should have n=0" in e for e in errors))

    def test_duplicate_band_index(self):
        bad = dict(VALID_SINC_JSON)
        bad["fragments"] = [
            {"n": 0, "t": "PERSONA", "x": "first"},
            {"n": 0, "t": "PERSONA", "x": "second"},
        ]
        is_valid, errors = validate(bad)
        self.assertFalse(is_valid)
        self.assertTrue(any("duplicate" in e.lower() for e in errors))

    def test_extra_top_level_keys(self):
        bad = dict(VALID_SINC_JSON, extra_key="bad")
        is_valid, errors = validate(bad)
        self.assertFalse(is_valid)
        self.assertTrue(any("extra_key" in e for e in errors))

    def test_invalid_json_string(self):
        is_valid, errors = validate("{broken json")
        self.assertFalse(is_valid)
        self.assertTrue(any("parse" in e.lower() for e in errors))

    def test_nonexistent_file(self):
        is_valid, errors = validate(Path("/nonexistent/file.sinc.json"))
        self.assertFalse(is_valid)
        self.assertTrue(any("not found" in e.lower() for e in errors))


class TestParse(unittest.TestCase):
    """Tests for parse()."""

    def test_parse_valid(self):
        prompt = parse(VALID_SINC_JSON)
        self.assertIsInstance(prompt, SincPrompt)
        self.assertEqual(len(prompt.fragments), 6)
        self.assertEqual(prompt.fragments[0].t, "PERSONA")
        self.assertEqual(prompt.fragments[5].t, "TASK")

    def test_parse_sorts_by_index(self):
        shuffled = dict(VALID_SINC_JSON)
        shuffled["fragments"] = list(reversed(VALID_SINC_JSON["fragments"]))
        prompt = parse(shuffled)
        indices = [f.n for f in prompt.fragments]
        self.assertEqual(indices, sorted(indices))

    def test_parse_json_string(self):
        prompt = parse(json.dumps(VALID_SINC_JSON))
        self.assertIsInstance(prompt, SincPrompt)
        self.assertEqual(len(prompt.fragments), 6)

    def test_parse_invalid_raises(self):
        with self.assertRaises(ValueError):
            parse({"formula": "x", "T": "t"})

    def test_get_band(self):
        prompt = parse(VALID_SINC_JSON)
        constraints = prompt.get_band("CONSTRAINTS")
        self.assertIsNotNone(constraints)
        self.assertEqual(constraints.n, 3)

    def test_get_band_missing(self):
        prompt = parse(MINIMAL_SINC_JSON)
        persona = prompt.get_band("PERSONA")
        self.assertIsNone(persona)

    def test_is_complete(self):
        full = parse(VALID_SINC_JSON)
        self.assertTrue(full.is_complete())

        partial = parse(MINIMAL_SINC_JSON)
        self.assertFalse(partial.is_complete())


class TestFormatPrompt(unittest.TestCase):
    """Tests for format_prompt()."""

    def test_format_contains_all_bands(self):
        output = format_prompt(VALID_SINC_JSON)
        for band in SINC_BANDS:
            self.assertIn(f"[{band}]", output)

    def test_format_order(self):
        output = format_prompt(VALID_SINC_JSON)
        positions = {band: output.index(f"[{band}]") for band in SINC_BANDS}
        # Bands should appear in order 0-5
        for i in range(len(SINC_BANDS) - 1):
            self.assertLess(
                positions[SINC_BANDS[i]],
                positions[SINC_BANDS[i + 1]],
            )

    def test_format_includes_content(self):
        output = format_prompt(VALID_SINC_JSON)
        self.assertIn("senior Python developer", output)
        self.assertIn("Fix the 500 error", output)


class TestComputeSNR(unittest.TestCase):
    """Tests for compute_snr()."""

    def test_snr_positive(self):
        snr = compute_snr(VALID_SINC_JSON)
        self.assertGreater(snr, 0.0)

    def test_snr_is_float(self):
        snr = compute_snr(VALID_SINC_JSON)
        self.assertIsInstance(snr, float)


class TestNyquistCompleteness(unittest.TestCase):
    """Tests for nyquist_completeness()."""

    def test_full_prompt_completeness(self):
        score = nyquist_completeness(VALID_SINC_JSON)
        self.assertAlmostEqual(score, 1.0, places=2)

    def test_minimal_prompt_completeness(self):
        score = nyquist_completeness(MINIMAL_SINC_JSON)
        # Only TASK band present = 2.8% / 88.9% = ~0.0315
        self.assertGreater(score, 0.0)
        self.assertLess(score, 0.1)

    def test_completeness_range(self):
        score = nyquist_completeness(VALID_SINC_JSON)
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 1.0)


class TestScatter(unittest.TestCase):
    """Tests for scatter()."""

    def test_scatter_returns_sinc_prompt(self):
        result = scatter("Write a Python function that sorts a list using quicksort")
        self.assertIsInstance(result, SincPrompt)

    def test_scatter_has_6_bands(self):
        result = scatter("You are an expert Python developer. Write a function that sorts a list. Use only stdlib. Return as a code block.")
        self.assertEqual(len(result.fragments), 6)

    def test_scatter_all_bands_named(self):
        result = scatter("Create a REST API endpoint")
        band_names = {f.t for f in result.fragments}
        self.assertEqual(band_names, set(SINC_BANDS))

    def test_scatter_empty_raises(self):
        with self.assertRaises(ValueError):
            scatter("")

    def test_scatter_persona_extraction(self):
        result = scatter("You are a senior data scientist. Analyze this dataset and find correlations.")
        persona = result.get_band("PERSONA")
        self.assertIn("data scientist", persona.x.lower())

    def test_scatter_task_extraction(self):
        result = scatter("Please write a sorting algorithm in Python.")
        task = result.get_band("TASK")
        self.assertTrue(len(task.x) > 0)

    def test_scatter_constraint_extraction(self):
        result = scatter("Build a web scraper. You must not use Selenium. Always respect robots.txt. Never store credentials in plaintext.")
        constraints = result.get_band("CONSTRAINTS")
        self.assertIn("must", constraints.x.lower())


class TestToJson(unittest.TestCase):
    """Tests for to_json()."""

    def test_roundtrip(self):
        prompt = parse(VALID_SINC_JSON)
        exported = to_json(prompt)
        self.assertIn("formula", exported)
        self.assertIn("T", exported)
        self.assertIn("fragments", exported)
        self.assertEqual(len(exported["fragments"]), 6)

    def test_json_serializable(self):
        prompt = parse(VALID_SINC_JSON)
        exported = to_json(prompt)
        # Should be JSON-serializable without error
        json_str = json.dumps(exported)
        self.assertIsInstance(json_str, str)

    def test_roundtrip_validates(self):
        prompt = parse(VALID_SINC_JSON)
        exported = to_json(prompt)
        is_valid, errors = validate(exported)
        self.assertTrue(is_valid)
        self.assertEqual(errors, [])


class TestSincFragment(unittest.TestCase):
    """Tests for SincFragment dataclass."""

    def test_valid_fragment(self):
        frag = SincFragment(n=0, t="PERSONA", x="A helpful assistant.")
        self.assertEqual(frag.n, 0)
        self.assertEqual(frag.t, "PERSONA")

    def test_invalid_index(self):
        with self.assertRaises(ValueError):
            SincFragment(n=7, t="PERSONA", x="content")

    def test_invalid_negative_index(self):
        with self.assertRaises(ValueError):
            SincFragment(n=-1, t="PERSONA", x="content")

    def test_empty_band_name(self):
        with self.assertRaises(ValueError):
            SincFragment(n=0, t="", x="content")


class TestWeights(unittest.TestCase):
    """Tests for weights module."""

    def test_six_bands(self):
        self.assertEqual(len(SINC_BANDS), 6)

    def test_six_weights(self):
        self.assertEqual(len(BAND_IMPORTANCE), 6)

    def test_all_bands_have_weights(self):
        for band in SINC_BANDS:
            self.assertIn(band, BAND_IMPORTANCE)

    def test_weights_positive(self):
        for band, weight in BAND_IMPORTANCE.items():
            self.assertGreater(weight, 0.0, f"{band} weight must be positive")

    def test_constraints_is_heaviest(self):
        max_band = max(BAND_IMPORTANCE, key=BAND_IMPORTANCE.get)
        self.assertEqual(max_band, "CONSTRAINTS")


if __name__ == "__main__":
    unittest.main()
