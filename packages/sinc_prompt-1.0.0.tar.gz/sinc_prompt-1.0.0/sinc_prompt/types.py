"""
sinc-prompt data types.

Dataclass representations of the sinc-prompt format structures.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class SincFragment:
    """A single sinc-prompt fragment (one of the 6 Nyquist bands).

    Attributes:
        n: Band index (0-5).
        t: Band name (PERSONA, CONTEXT, DATA, CONSTRAINTS, FORMAT, TASK).
        x: Band content (the signal sample at this frequency).
    """
    n: int
    t: str
    x: str

    def __post_init__(self):
        if not isinstance(self.n, int) or not (0 <= self.n <= 5):
            raise ValueError(f"Fragment index n must be 0-5, got {self.n}")
        if not isinstance(self.t, str) or not self.t.strip():
            raise ValueError("Fragment band name t must be a non-empty string")
        if not isinstance(self.x, str):
            raise ValueError("Fragment content x must be a string")


@dataclass
class SincPrompt:
    """A complete sinc-prompt with all 6 bands.

    Attributes:
        formula: The sinc reconstruction formula.
        T: The specification axis label.
        fragments: List of 6 SincFragment objects (one per band).
    """
    formula: str
    T: str
    fragments: List[SincFragment]

    # Default formula for convenience
    DEFAULT_FORMULA = "x(t) = Sigma x(nT) * sinc((t - nT) / T)"

    def __post_init__(self):
        if not isinstance(self.fragments, list):
            raise ValueError("fragments must be a list")

    def get_band(self, band_name: str) -> Optional[SincFragment]:
        """Get a fragment by band name.

        Args:
            band_name: One of PERSONA, CONTEXT, DATA, CONSTRAINTS, FORMAT, TASK.

        Returns:
            The matching SincFragment or None.
        """
        band_upper = band_name.upper()
        for frag in self.fragments:
            if frag.t.upper() == band_upper:
                return frag
        return None

    def band_names(self) -> List[str]:
        """Return list of band names present in this prompt."""
        return [f.t for f in self.fragments]

    def is_complete(self) -> bool:
        """Check if all 6 bands are present with non-empty content."""
        from .weights import SINC_BANDS
        present = {f.t.upper() for f in self.fragments if f.x.strip()}
        return all(b in present for b in SINC_BANDS)

    def to_dict(self) -> dict:
        """Convert to a plain dict (sinc JSON format)."""
        return {
            "formula": self.formula,
            "T": self.T,
            "fragments": [
                {"n": f.n, "t": f.t, "x": f.x}
                for f in self.fragments
            ],
        }
