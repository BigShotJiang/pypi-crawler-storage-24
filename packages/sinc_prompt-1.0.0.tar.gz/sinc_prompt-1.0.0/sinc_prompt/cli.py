"""
sinc-prompt CLI entry point.

Usage:
    sinc-prompt validate <file.sinc.json>
    sinc-prompt format <file.sinc.json>
    sinc-prompt completeness <file.sinc.json>
    sinc-prompt scatter "raw prompt text"
"""

import argparse
import json
import sys
from pathlib import Path

from .core import validate, format_prompt, nyquist_completeness, scatter, compute_snr, to_json


def main(argv=None):
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="sinc-prompt",
        description="Validator and converter for the sinc-prompt structured LLM prompt format.",
        epilog="Documentation: https://tokencalc.pro/integrations",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="sinc-prompt 1.0.0",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # validate
    p_validate = subparsers.add_parser(
        "validate",
        help="Validate a sinc-prompt JSON file",
    )
    p_validate.add_argument(
        "file",
        type=str,
        help="Path to a .sinc.json file",
    )

    # format
    p_format = subparsers.add_parser(
        "format",
        help="Format a sinc-prompt file into a readable prompt string",
    )
    p_format.add_argument(
        "file",
        type=str,
        help="Path to a .sinc.json file",
    )

    # completeness
    p_completeness = subparsers.add_parser(
        "completeness",
        help="Show Nyquist completeness score for a sinc-prompt file",
    )
    p_completeness.add_argument(
        "file",
        type=str,
        help="Path to a .sinc.json file",
    )

    # scatter
    p_scatter = subparsers.add_parser(
        "scatter",
        help="Decompose a raw prompt into 6 sinc bands (heuristic, no LLM)",
    )
    p_scatter.add_argument(
        "prompt",
        type=str,
        help="Raw prompt text to scatter into 6 bands",
    )
    p_scatter.add_argument(
        "--json",
        action="store_true",
        dest="output_json",
        help="Output as sinc JSON instead of formatted text",
    )

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "validate":
        _cmd_validate(args)
    elif args.command == "format":
        _cmd_format(args)
    elif args.command == "completeness":
        _cmd_completeness(args)
    elif args.command == "scatter":
        _cmd_scatter(args)


def _cmd_validate(args):
    """Handle the validate command."""
    path = Path(args.file)
    if not path.exists():
        print(f"Error: file not found: {path}", file=sys.stderr)
        sys.exit(1)

    is_valid, errors = validate(path)

    if is_valid:
        print(f"VALID: {path}")
        # Also show completeness and SNR as bonus info
        try:
            completeness = nyquist_completeness(path)
            snr = compute_snr(path)
            print(f"  Nyquist completeness: {completeness:.1%}")
            print(f"  SNR: {snr:.4f}")
        except Exception:
            pass
        sys.exit(0)
    else:
        print(f"INVALID: {path}", file=sys.stderr)
        for err in errors:
            print(f"  - {err}", file=sys.stderr)
        sys.exit(1)


def _cmd_format(args):
    """Handle the format command."""
    path = Path(args.file)
    if not path.exists():
        print(f"Error: file not found: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        output = format_prompt(path)
        print(output)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def _cmd_completeness(args):
    """Handle the completeness command."""
    path = Path(args.file)
    if not path.exists():
        print(f"Error: file not found: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        score = nyquist_completeness(path)
        snr = compute_snr(path)
        print(f"File: {path}")
        print(f"Nyquist completeness: {score:.1%}")
        print(f"SNR: {snr:.4f}")

        # Show per-band breakdown
        from .core import parse
        from .weights import BAND_IMPORTANCE, SINC_BANDS
        prompt = parse(path)
        present = {f.t.upper() for f in prompt.fragments if f.x.strip()}
        print()
        print(f"{'Band':<14} {'Weight':>8} {'Present':>8}")
        print("-" * 32)
        for band in SINC_BANDS:
            weight = BAND_IMPORTANCE[band]
            status = "YES" if band in present else "MISSING"
            print(f"{band:<14} {weight:>7.1%} {status:>8}")
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def _cmd_scatter(args):
    """Handle the scatter command."""
    try:
        result = scatter(args.prompt)
        if args.output_json:
            print(json.dumps(to_json(result), indent=2, ensure_ascii=False))
        else:
            print(format_prompt(result))
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
