"""
sinc-prompt core functions.

Validate, parse, format, analyze, and scatter sinc-prompt documents.
Zero dependencies -- uses only Python stdlib.
"""

import json
import math
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

from .schema import SINC_PROMPT_SCHEMA, BAND_NAME_TO_INDEX
from .types import SincFragment, SincPrompt
from .weights import BAND_IMPORTANCE, SINC_BANDS, BAND_INDEX


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------

def validate(sinc_json: Union[dict, str, Path]) -> Tuple[bool, List[str]]:
    """Validate a sinc-prompt document against the schema.

    Performs structural validation without requiring jsonschema as a
    dependency.  Checks types, required fields, enums, and cross-
    references (n <-> t consistency).

    Args:
        sinc_json: A dict, a JSON string, or a Path to a .sinc.json file.

    Returns:
        A tuple of (is_valid, errors) where errors is a list of human-
        readable error strings.  Empty list means valid.
    """
    errors: List[str] = []
    data = _load_input(sinc_json, errors)
    if data is None:
        return (False, errors)

    # Top-level type
    if not isinstance(data, dict):
        errors.append("Root must be a JSON object (dict).")
        return (False, errors)

    # Required keys
    for key in ("formula", "T", "fragments"):
        if key not in data:
            errors.append(f"Missing required key: '{key}'.")

    # No extra keys
    allowed_top = {"formula", "T", "fragments"}
    extra = set(data.keys()) - allowed_top
    if extra:
        errors.append(f"Unexpected top-level keys: {sorted(extra)}.")

    if errors:
        return (False, errors)

    # formula
    if not isinstance(data["formula"], str) or not data["formula"].strip():
        errors.append("'formula' must be a non-empty string.")

    # T
    if not isinstance(data["T"], str) or not data["T"].strip():
        errors.append("'T' must be a non-empty string.")

    # fragments
    frags = data["fragments"]
    if not isinstance(frags, list):
        errors.append("'fragments' must be an array.")
        return (False, errors)

    if len(frags) < 1:
        errors.append("'fragments' must contain at least 1 item.")
    if len(frags) > 6:
        errors.append(f"'fragments' has {len(frags)} items; maximum is 6.")

    seen_n: Dict[int, str] = {}
    seen_t: Dict[str, int] = {}
    valid_bands = set(BAND_NAME_TO_INDEX.keys())

    for i, frag in enumerate(frags):
        prefix = f"fragments[{i}]"
        if not isinstance(frag, dict):
            errors.append(f"{prefix}: must be an object.")
            continue

        # Required fragment keys
        for key in ("n", "t", "x"):
            if key not in frag:
                errors.append(f"{prefix}: missing required key '{key}'.")

        # Extra keys
        frag_extra = set(frag.keys()) - {"n", "t", "x"}
        if frag_extra:
            errors.append(f"{prefix}: unexpected keys {sorted(frag_extra)}.")

        # n
        n_val = frag.get("n")
        if not isinstance(n_val, int) or isinstance(n_val, bool):
            errors.append(f"{prefix}.n: must be an integer.")
        elif n_val < 0 or n_val > 5:
            errors.append(f"{prefix}.n: must be 0-5, got {n_val}.")
        else:
            if n_val in seen_n:
                errors.append(f"{prefix}.n: duplicate index {n_val} (also at band '{seen_n[n_val]}').")
            seen_n[n_val] = frag.get("t", "?")

        # t
        t_val = frag.get("t")
        if not isinstance(t_val, str):
            errors.append(f"{prefix}.t: must be a string.")
        elif t_val not in valid_bands:
            errors.append(f"{prefix}.t: must be one of {sorted(valid_bands)}, got '{t_val}'.")
        else:
            if t_val in seen_t:
                errors.append(f"{prefix}.t: duplicate band name '{t_val}'.")
            seen_t[t_val] = frag.get("n", -1)

        # x
        x_val = frag.get("x")
        if not isinstance(x_val, str):
            errors.append(f"{prefix}.x: must be a string.")
        elif not x_val.strip():
            errors.append(f"{prefix}.x: must be non-empty.")

        # Cross-check: n matches expected index for t
        if isinstance(n_val, int) and isinstance(t_val, str) and t_val in BAND_NAME_TO_INDEX:
            expected_n = BAND_NAME_TO_INDEX[t_val]
            if n_val != expected_n:
                errors.append(
                    f"{prefix}: band '{t_val}' should have n={expected_n}, got n={n_val}."
                )

    return (len(errors) == 0, errors)


# ---------------------------------------------------------------------------
# parse
# ---------------------------------------------------------------------------

def parse(input_data: Union[dict, str, Path]) -> SincPrompt:
    """Parse a sinc-prompt from dict, JSON string, or file path.

    Args:
        input_data: The sinc-prompt source.

    Returns:
        A SincPrompt dataclass instance.

    Raises:
        ValueError: If input is invalid or fails validation.
    """
    errors: List[str] = []
    data = _load_input(input_data, errors)
    if data is None:
        raise ValueError(f"Cannot parse sinc-prompt: {'; '.join(errors)}")

    is_valid, val_errors = validate(data)
    if not is_valid:
        raise ValueError(f"Invalid sinc-prompt: {'; '.join(val_errors)}")

    fragments = [
        SincFragment(n=f["n"], t=f["t"], x=f["x"])
        for f in data["fragments"]
    ]
    # Sort by band index
    fragments.sort(key=lambda f: f.n)

    return SincPrompt(
        formula=data["formula"],
        T=data["T"],
        fragments=fragments,
    )


# ---------------------------------------------------------------------------
# format_prompt
# ---------------------------------------------------------------------------

def format_prompt(sinc: Union[SincPrompt, dict, str, Path]) -> str:
    """Format a sinc-prompt into a readable prompt string.

    Output format:
        [PERSONA]
        <content>

        [CONTEXT]
        <content>
        ...

    Args:
        sinc: A SincPrompt, dict, JSON string, or file Path.

    Returns:
        Formatted prompt string.
    """
    prompt = _ensure_sinc_prompt(sinc)
    parts = []
    for frag in sorted(prompt.fragments, key=lambda f: f.n):
        parts.append(f"[{frag.t}]\n{frag.x}")
    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# compute_snr
# ---------------------------------------------------------------------------

def compute_snr(sinc: Union[SincPrompt, dict, str, Path]) -> float:
    """Compute the signal-to-noise ratio of a sinc-prompt.

    SNR measures how well the prompt's band distribution matches the
    ideal importance weights.  A perfect prompt has SNR approaching
    infinity; a raw unstructured prompt has SNR near 0.

    The signal power is the weighted content present in each band.
    The noise power is the deviation from ideal distribution.

    Args:
        sinc: A SincPrompt, dict, JSON string, or file Path.

    Returns:
        SNR as a float (higher is better).  Returns 0.0 for empty prompts.
    """
    prompt = _ensure_sinc_prompt(sinc)

    # Compute content lengths per band
    band_lengths: Dict[str, int] = {}
    total_length = 0
    for frag in prompt.fragments:
        length = len(frag.x.strip())
        band_lengths[frag.t.upper()] = length
        total_length += length

    if total_length == 0:
        return 0.0

    # Compute actual distribution
    actual_dist: Dict[str, float] = {}
    for band in SINC_BANDS:
        actual_dist[band] = band_lengths.get(band, 0) / total_length

    # Signal: sum of weighted contributions (how much useful structure exists)
    signal_power = 0.0
    for band in SINC_BANDS:
        weight = BAND_IMPORTANCE[band]
        content_ratio = actual_dist[band]
        # Signal contribution: weight * content presence (geometric mean approach)
        if content_ratio > 0:
            signal_power += weight * min(content_ratio / weight, 1.0) if weight > 0 else 0

    # Noise: deviation from ideal distribution
    noise_power = 0.0
    for band in SINC_BANDS:
        weight = BAND_IMPORTANCE[band]
        deviation = abs(actual_dist[band] - weight)
        noise_power += weight * deviation

    if noise_power < 1e-10:
        return 100.0  # Effectively perfect

    snr = signal_power / noise_power
    return round(snr, 4)


# ---------------------------------------------------------------------------
# nyquist_completeness
# ---------------------------------------------------------------------------

def nyquist_completeness(sinc: Union[SincPrompt, dict, str, Path]) -> float:
    """Compute Nyquist-weighted completeness score (0.0 to 1.0).

    Each band contributes its importance weight to the score if present
    and non-empty.  A prompt with all 6 bands filled scores 1.0
    (normalized by the sum of weights).

    Args:
        sinc: A SincPrompt, dict, JSON string, or file Path.

    Returns:
        Completeness score between 0.0 and 1.0.
    """
    prompt = _ensure_sinc_prompt(sinc)

    present_bands = set()
    for frag in prompt.fragments:
        if frag.x.strip():
            present_bands.add(frag.t.upper())

    weight_sum = sum(BAND_IMPORTANCE.values())
    if weight_sum == 0:
        return 0.0

    achieved = 0.0
    for band in SINC_BANDS:
        if band in present_bands:
            achieved += BAND_IMPORTANCE[band]

    return round(achieved / weight_sum, 4)


# ---------------------------------------------------------------------------
# scatter
# ---------------------------------------------------------------------------

def scatter(raw_prompt: str) -> SincPrompt:
    """Decompose a raw prompt into 6 sinc bands using heuristics.

    This is a zero-LLM heuristic decomposition.  It analyzes the raw
    text for patterns that indicate persona, context, data, constraints,
    format preferences, and the core task.

    Args:
        raw_prompt: A raw, unstructured prompt string.

    Returns:
        A SincPrompt with heuristically-assigned bands.
    """
    text = raw_prompt.strip()
    if not text:
        raise ValueError("Cannot scatter an empty prompt.")

    persona = _extract_persona(text)
    context = _extract_context(text)
    data = _extract_data(text)
    constraints = _extract_constraints(text)
    fmt = _extract_format(text)
    task = _extract_task(text)

    # Fallback: if task is empty, use the full prompt
    if not task:
        task = text

    fragments = [
        SincFragment(n=0, t="PERSONA", x=persona or "General-purpose assistant."),
        SincFragment(n=1, t="CONTEXT", x=context or "No specific context provided."),
        SincFragment(n=2, t="DATA", x=data or "No specific data inputs identified."),
        SincFragment(n=3, t="CONSTRAINTS", x=constraints or "No explicit constraints stated."),
        SincFragment(n=4, t="FORMAT", x=fmt or "Default format."),
        SincFragment(n=5, t="TASK", x=task),
    ]

    return SincPrompt(
        formula=SincPrompt.DEFAULT_FORMULA,
        T="specification-axis",
        fragments=fragments,
    )


# ---------------------------------------------------------------------------
# to_json
# ---------------------------------------------------------------------------

def to_json(sinc: Union[SincPrompt, dict, str, Path]) -> dict:
    """Export a sinc-prompt to a plain dict (sinc JSON format).

    Args:
        sinc: A SincPrompt, dict, JSON string, or file Path.

    Returns:
        A dict in sinc-prompt JSON format.
    """
    prompt = _ensure_sinc_prompt(sinc)
    return prompt.to_dict()


# ===========================================================================
# Internal helpers
# ===========================================================================

def _load_input(
    input_data: Union[dict, str, Path],
    errors: List[str],
) -> Optional[dict]:
    """Load sinc-prompt data from various input types."""
    if isinstance(input_data, dict):
        return input_data

    if isinstance(input_data, Path) or (
        isinstance(input_data, str) and (
            input_data.endswith(".json") and not input_data.strip().startswith("{")
        )
    ):
        path = Path(input_data) if not isinstance(input_data, Path) else input_data
        if not path.exists():
            errors.append(f"File not found: {path}")
            return None
        try:
            text = path.read_text(encoding="utf-8")
            return json.loads(text)
        except json.JSONDecodeError as e:
            errors.append(f"JSON parse error in {path}: {e}")
            return None
        except OSError as e:
            errors.append(f"File read error: {e}")
            return None

    if isinstance(input_data, str):
        try:
            return json.loads(input_data)
        except json.JSONDecodeError as e:
            errors.append(f"JSON parse error: {e}")
            return None

    errors.append(f"Unsupported input type: {type(input_data).__name__}")
    return None


def _ensure_sinc_prompt(sinc: Union[SincPrompt, dict, str, Path]) -> SincPrompt:
    """Convert input to a SincPrompt, parsing if needed."""
    if isinstance(sinc, SincPrompt):
        return sinc
    return parse(sinc)


# ---------------------------------------------------------------------------
# Scatter heuristic helpers
# ---------------------------------------------------------------------------

_PERSONA_PATTERNS = [
    re.compile(r"(?:you are|act as|behave like|pretend to be|role:\s*)\s*(.+?)(?:\.|$)", re.IGNORECASE),
    re.compile(r"(?:as an?|as the)\s+(\w[\w\s]{2,30}?)(?:,|\.|$)", re.IGNORECASE),
]

_CONSTRAINT_KEYWORDS = [
    "must", "must not", "do not", "don't", "never", "always", "avoid",
    "ensure", "required", "forbidden", "prohibited", "mandatory", "limit",
    "maximum", "minimum", "only", "no more than", "at least", "exactly",
    "strictly", "under no circumstances",
]

_FORMAT_KEYWORDS = [
    "json", "markdown", "table", "list", "bullet", "csv", "xml", "yaml",
    "numbered", "heading", "code block", "paragraph", "format:",
    "output format", "respond in", "respond with", "return as",
    "structure:", "template:",
]


def _extract_persona(text: str) -> str:
    """Extract persona/role hints from raw text."""
    for pattern in _PERSONA_PATTERNS:
        match = pattern.search(text)
        if match:
            return match.group(1).strip()
    return ""


def _extract_context(text: str) -> str:
    """Extract contextual information from raw text."""
    context_parts = []
    # Look for context-setting sentences (background, situation, etc.)
    context_patterns = [
        re.compile(r"(?:context|background|situation|given that|assuming)\s*:?\s*(.+?)(?:\.\s|$)", re.IGNORECASE),
        re.compile(r"(?:I am|I'm|we are|we're|I have|I've)\s+(.+?)(?:\.\s|$)", re.IGNORECASE),
    ]
    for pattern in context_patterns:
        for match in pattern.finditer(text):
            context_parts.append(match.group(1).strip())
    return " ".join(context_parts) if context_parts else ""


def _extract_data(text: str) -> str:
    """Extract specific data inputs from raw text."""
    data_parts = []
    data_patterns = [
        re.compile(r"(?:data|input|given|here is|here are|the following)\s*:?\s*(.+?)(?:\.\s|$)", re.IGNORECASE),
        re.compile(r'(?:```|"""|\'\'\')\s*([\s\S]+?)\s*(?:```|"""|\'\'\')', re.MULTILINE),
    ]
    for pattern in data_patterns:
        for match in pattern.finditer(text):
            data_parts.append(match.group(1).strip())
    return " ".join(data_parts) if data_parts else ""


def _extract_constraints(text: str) -> str:
    """Extract constraints and rules from raw text."""
    sentences = re.split(r'(?<=[.!?])\s+', text)
    constraint_sentences = []
    for sentence in sentences:
        lower = sentence.lower()
        if any(kw in lower for kw in _CONSTRAINT_KEYWORDS):
            constraint_sentences.append(sentence.strip())
    return " ".join(constraint_sentences) if constraint_sentences else ""


def _extract_format(text: str) -> str:
    """Extract format preferences from raw text."""
    format_parts = []
    lower = text.lower()
    for kw in _FORMAT_KEYWORDS:
        if kw in lower:
            # Find the sentence containing this keyword
            for sentence in re.split(r'(?<=[.!?])\s+', text):
                if kw in sentence.lower():
                    format_parts.append(sentence.strip())
                    break
    # Deduplicate
    seen = set()
    unique = []
    for part in format_parts:
        if part not in seen:
            seen.add(part)
            unique.append(part)
    return " ".join(unique) if unique else ""


def _extract_task(text: str) -> str:
    """Extract the core task/objective from raw text."""
    task_patterns = [
        re.compile(r"(?:please|can you|could you|I need you to|I want you to)\s+(.+?)(?:\.\s|$)", re.IGNORECASE),
        re.compile(r"(?:task|objective|goal|do)\s*:?\s*(.+?)(?:\.\s|$)", re.IGNORECASE),
    ]
    for pattern in task_patterns:
        match = pattern.search(text)
        if match:
            return match.group(1).strip()

    # Fallback: first imperative sentence or the whole text
    sentences = re.split(r'(?<=[.!?])\s+', text)
    for sentence in sentences:
        stripped = sentence.strip()
        # Simple heuristic: starts with a verb-like word
        if stripped and stripped[0].isupper() and len(stripped) > 10:
            first_word = stripped.split()[0].lower()
            imperative_starters = [
                "write", "create", "build", "make", "generate", "find",
                "list", "explain", "describe", "analyze", "design",
                "implement", "develop", "fix", "update", "convert",
                "translate", "summarize", "compare", "review", "help",
            ]
            if first_word in imperative_starters:
                return stripped
    return ""
