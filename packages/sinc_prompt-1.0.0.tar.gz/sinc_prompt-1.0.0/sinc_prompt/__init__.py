"""
sinc-prompt: Validator and converter for the sinc-prompt structured LLM prompt format.

Formula: x(t) = Sigma x(nT) * sinc((t - nT) / T)
6 bands: PERSONA (7.0%), CONTEXT (6.3%), DATA (3.8%), CONSTRAINTS (42.7%), FORMAT (26.3%), TASK (2.8%)

Zero dependencies. Uses only Python stdlib.

Usage:
    >>> import sinc_prompt
    >>> is_valid, errors = sinc_prompt.validate({"formula": "...", "T": "...", "fragments": [...]})
    >>> prompt = sinc_prompt.parse("path/to/prompt.sinc.json")
    >>> text = sinc_prompt.format_prompt(prompt)
    >>> score = sinc_prompt.nyquist_completeness(prompt)
    >>> scattered = sinc_prompt.scatter("Write a Python function that sorts a list")
"""

__version__ = "1.0.0"
__author__ = "Mario Alexandre"

from .core import (
    validate,
    parse,
    format_prompt,
    compute_snr,
    nyquist_completeness,
    scatter,
    to_json,
)
from .types import SincFragment, SincPrompt
from .weights import BAND_IMPORTANCE, SINC_BANDS, BAND_INDEX
from .schema import SINC_PROMPT_SCHEMA

__all__ = [
    # Core functions
    "validate",
    "parse",
    "format_prompt",
    "compute_snr",
    "nyquist_completeness",
    "scatter",
    "to_json",
    # Types
    "SincFragment",
    "SincPrompt",
    # Constants
    "BAND_IMPORTANCE",
    "SINC_BANDS",
    "BAND_INDEX",
    "SINC_PROMPT_SCHEMA",
    # Metadata
    "__version__",
]
