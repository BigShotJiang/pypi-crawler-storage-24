"""
sinc-prompt JSON Schema (draft-07).

Defines the canonical schema for sinc-prompt-v1 documents.
Used by validate() for structural validation.
"""

SINC_PROMPT_SCHEMA = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "$id": "https://tokencalc.pro/spec/sinc-prompt-v1.schema.json",
    "title": "sinc-prompt-v1",
    "description": (
        "A structured LLM prompt format based on Nyquist sampling theory. "
        "6 bands (PERSONA, CONTEXT, DATA, CONSTRAINTS, FORMAT, TASK) "
        "provide the minimum sampling rate to reconstruct intent without aliasing."
    ),
    "type": "object",
    "required": ["formula", "T", "fragments"],
    "properties": {
        "formula": {
            "type": "string",
            "description": "The sinc reconstruction formula.",
            "minLength": 1,
        },
        "T": {
            "type": "string",
            "description": "The specification axis (sampling period label).",
            "minLength": 1,
        },
        "fragments": {
            "type": "array",
            "description": "The 6 sinc-prompt band fragments.",
            "minItems": 1,
            "maxItems": 6,
            "items": {
                "type": "object",
                "required": ["n", "t", "x"],
                "properties": {
                    "n": {
                        "type": "integer",
                        "minimum": 0,
                        "maximum": 5,
                        "description": "Band index (0=PERSONA, 1=CONTEXT, 2=DATA, 3=CONSTRAINTS, 4=FORMAT, 5=TASK).",
                    },
                    "t": {
                        "type": "string",
                        "enum": ["PERSONA", "CONTEXT", "DATA", "CONSTRAINTS", "FORMAT", "TASK"],
                        "description": "Band name.",
                    },
                    "x": {
                        "type": "string",
                        "minLength": 1,
                        "description": "Band content (the signal sample).",
                    },
                },
                "additionalProperties": False,
            },
        },
    },
    "additionalProperties": False,
}

# Band name to index mapping (for validation cross-checks)
BAND_NAME_TO_INDEX = {
    "PERSONA": 0,
    "CONTEXT": 1,
    "DATA": 2,
    "CONSTRAINTS": 3,
    "FORMAT": 4,
    "TASK": 5,
}
