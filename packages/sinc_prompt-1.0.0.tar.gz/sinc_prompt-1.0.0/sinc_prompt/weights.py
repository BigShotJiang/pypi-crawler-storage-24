"""
sinc-prompt band importance weights.

Derived from empirical quality analysis of structured LLM prompts.
The weights represent each band's contribution to output quality,
normalized to sum to 1.0 (with rounding tolerance).

Formula: x(t) = Sigma x(nT) * sinc((t - nT) / T)
"""

# Ordered list of the 6 sinc bands (Nyquist-minimum sampling)
SINC_BANDS = [
    "PERSONA",
    "CONTEXT",
    "DATA",
    "CONSTRAINTS",
    "FORMAT",
    "TASK",
]

# Band importance weights (fraction of total quality contribution)
# Source: empirical analysis -- CONSTRAINTS dominates at 42.7%
BAND_IMPORTANCE = {
    "PERSONA":     0.070,   #  7.0%
    "CONTEXT":     0.063,   #  6.3%
    "DATA":        0.038,   #  3.8%
    "CONSTRAINTS": 0.427,   # 42.7%
    "FORMAT":      0.263,   # 26.3%
    "TASK":        0.028,   #  2.8%
}

# Band index mapping (n-value in sinc fragments)
BAND_INDEX = {name: i for i, name in enumerate(SINC_BANDS)}

# Verification: weights sum to ~1.0 (within floating-point tolerance)
_WEIGHT_SUM = sum(BAND_IMPORTANCE.values())
assert abs(_WEIGHT_SUM - 0.889) < 0.01, (
    f"Band weights sum to {_WEIGHT_SUM}, expected ~0.889 "
    "(remaining 11.1% is inter-band coupling, not assignable to a single band)"
)
