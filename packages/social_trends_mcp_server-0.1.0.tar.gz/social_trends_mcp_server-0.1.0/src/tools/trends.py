"""
MCP-Tools fuer Social-Media-Trends.

6 Tools:
- get_trending_hackernews: Top HN Stories
- get_subreddit_hot: Heisse Posts eines Subreddits
- search_reddit: Reddit-Suche
- get_trending_topics: Aggregierte Trends (HN + Reddit)
- get_tech_pulse: Quick Tech-Pulse (HN + r/technology + r/programming)
- search_mentions: Pruefen ob ein Thema auf HN/Reddit diskutiert wird
"""

import asyncio
from typing import Any

from src.clients.social import social_client


async def get_trending_hackernews(limit: int = 20) -> dict[str, Any]:
    """
    Top-Stories von HackerNews abrufen.

    Zeigt die aktuell heissesten Stories mit Titel, Score,
    Kommentaranzahl und URL.

    Args:
        limit: Anzahl der Stories (Standard: 20, Maximum: 50)
    """
    limit = min(max(1, limit), 50)

    try:
        stories = await social_client.get_hn_top_stories(limit)
        return {
            "source": "HackerNews",
            "count": len(stories),
            "stories": stories,
        }
    except Exception as e:
        return {"error": f"HackerNews-Abruf fehlgeschlagen: {str(e)}"}


async def get_subreddit_hot(subreddit: str, limit: int = 15) -> dict[str, Any]:
    """
    Heisseste Posts eines Subreddits abrufen.

    Zeigt die aktuell angesagtesten Posts mit Score,
    Kommentaren und Links.

    Args:
        subreddit: Name des Subreddits (z.B. "technology", "programming")
        limit: Anzahl der Posts (Standard: 15, Maximum: 50)
    """
    limit = min(max(1, limit), 50)
    # Subreddit-Name bereinigen
    subreddit = subreddit.strip().strip("/").removeprefix("r/")

    try:
        posts = await social_client.get_subreddit_hot(subreddit, limit)
        return {
            "source": "Reddit",
            "subreddit": subreddit,
            "count": len(posts),
            "posts": posts,
        }
    except Exception as e:
        return {"error": f"Reddit-Abruf fehlgeschlagen: {str(e)}"}


async def search_reddit(
    query: str, sort: str = "hot", limit: int = 15
) -> dict[str, Any]:
    """
    Reddit nach einem Begriff durchsuchen.

    Durchsucht alle oeffentlichen Subreddits nach dem Suchbegriff.

    Args:
        query: Suchbegriff (z.B. "MCP server", "AI agents")
        sort: Sortierung — "hot", "new", "relevance", "top" (Standard: "hot")
        limit: Anzahl der Ergebnisse (Standard: 15, Maximum: 50)
    """
    limit = min(max(1, limit), 50)
    allowed_sorts = ("hot", "new", "relevance", "top")
    if sort not in allowed_sorts:
        sort = "hot"

    try:
        results = await social_client.search_reddit(query, sort, limit)
        return {
            "source": "Reddit",
            "query": query,
            "sort": sort,
            "count": len(results),
            "results": results,
        }
    except Exception as e:
        return {"error": f"Reddit-Suche fehlgeschlagen: {str(e)}"}


async def get_trending_topics(source: str = "all") -> dict[str, Any]:
    """
    Aggregierte Trending-Topics von HackerNews und Reddit.

    Kombiniert die heissesten Themen aus beiden Plattformen
    fuer einen Ueberblick, was gerade im Internet diskutiert wird.

    Args:
        source: Quelle — "all" (beide), "hackernews", "reddit" (Standard: "all")
    """
    results: dict[str, Any] = {"source": source}

    try:
        tasks = []

        if source in ("all", "hackernews"):
            tasks.append(("hackernews", social_client.get_hn_top_stories(15)))

        if source in ("all", "reddit"):
            tasks.append(("reddit", social_client.get_subreddit_hot("popular", 15)))

        gathered = await asyncio.gather(
            *[t[1] for t in tasks], return_exceptions=True
        )

        for i, (name, _) in enumerate(tasks):
            data = gathered[i]
            if isinstance(data, Exception):
                results[name] = {"error": str(data)}
            else:
                results[name] = {
                    "count": len(data),
                    "items": data,
                }

        return results

    except Exception as e:
        return {"error": f"Trending-Abruf fehlgeschlagen: {str(e)}"}


async def get_tech_pulse() -> dict[str, Any]:
    """
    Quick Tech-Pulse: Top 5 aus HackerNews, r/technology und r/programming.

    Perfekt fuer einen schnellen Ueberblick, was gerade in der
    Tech-Welt passiert. Kombiniert drei wichtige Tech-Quellen.
    """
    try:
        hn_task = social_client.get_hn_top_stories(5)
        tech_task = social_client.get_subreddit_hot("technology", 5)
        prog_task = social_client.get_subreddit_hot("programming", 5)

        results = await asyncio.gather(
            hn_task, tech_task, prog_task, return_exceptions=True
        )

        pulse: dict[str, Any] = {}

        labels = ["hackernews", "r/technology", "r/programming"]
        for i, label in enumerate(labels):
            data = results[i]
            if isinstance(data, Exception):
                pulse[label] = {"error": str(data)}
            else:
                # Kompakte Darstellung: nur Titel + Score
                pulse[label] = [
                    {
                        "title": item.get("title", ""),
                        "score": item.get("score", 0),
                        "url": item.get("url") or item.get("hn_url") or item.get("permalink", ""),
                    }
                    for item in data
                ]

        return {
            "description": "Tech-Pulse: Top 5 aus HN, r/technology, r/programming",
            "pulse": pulse,
        }

    except Exception as e:
        return {"error": f"Tech-Pulse fehlgeschlagen: {str(e)}"}


async def search_mentions(topic: str) -> dict[str, Any]:
    """
    Pruefen ob ein Thema auf HackerNews und Reddit diskutiert wird.

    Durchsucht beide Plattformen nach Erwaenungen eines Themas.
    Nuetzlich um zu sehen, ob ein Produkt, eine Technologie oder
    ein Ereignis Aufmerksamkeit bekommt.

    Args:
        topic: Thema/Begriff zum Suchen (z.B. "Claude", "Rust", "MCP protocol")
    """
    try:
        hn_task = social_client.search_hn(topic, 10)
        reddit_task = social_client.search_reddit(topic, "hot", 10)

        results = await asyncio.gather(
            hn_task, reddit_task, return_exceptions=True
        )

        mentions: dict[str, Any] = {"topic": topic}

        # HackerNews-Ergebnisse
        hn_data = results[0]
        if isinstance(hn_data, Exception):
            mentions["hackernews"] = {"error": str(hn_data)}
        else:
            mentions["hackernews"] = {
                "count": len(hn_data),
                "results": hn_data,
            }

        # Reddit-Ergebnisse
        reddit_data = results[1]
        if isinstance(reddit_data, Exception):
            mentions["reddit"] = {"error": str(reddit_data)}
        else:
            mentions["reddit"] = {
                "count": len(reddit_data),
                "results": reddit_data,
            }

        # Zusammenfassung
        hn_count = len(hn_data) if not isinstance(hn_data, Exception) else 0
        reddit_count = len(reddit_data) if not isinstance(reddit_data, Exception) else 0
        mentions["total_mentions"] = hn_count + reddit_count
        mentions["is_trending"] = (hn_count + reddit_count) >= 5

        return mentions

    except Exception as e:
        return {"error": f"Mention-Suche fehlgeschlagen: {str(e)}"}
