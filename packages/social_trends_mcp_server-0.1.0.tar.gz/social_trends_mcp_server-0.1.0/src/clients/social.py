"""
Async HTTP-Client fuer Reddit und HackerNews APIs.

Reddit: Oeffentliche JSON-API (kein Auth noetig)
HackerNews: Firebase REST API (kein Auth noetig)
"""

import asyncio
from typing import Any

import httpx

from src.config import (
    HN_BASE_URL,
    HTTP_TIMEOUT,
    REDDIT_BASE_URL,
    USER_AGENT,
)


class SocialClient:
    """Async Client fuer Reddit und HackerNews."""

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Lazy-Init des HTTP-Clients."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=HTTP_TIMEOUT,
                headers={"User-Agent": USER_AGENT},
                follow_redirects=True,
            )
        return self._client

    async def close(self) -> None:
        """Client sauber schliessen."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    # ── Reddit ──────────────────────────────────────────────

    async def get_subreddit_hot(
        self, subreddit: str, limit: int = 15
    ) -> list[dict[str, Any]]:
        """Holt die heissesten Posts eines Subreddits."""
        client = await self._get_client()
        url = f"{REDDIT_BASE_URL}/r/{subreddit}/hot.json"
        params = {"limit": limit, "raw_json": 1}

        resp = await client.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()

        posts = []
        for child in data.get("data", {}).get("children", []):
            post = child.get("data", {})
            posts.append({
                "title": post.get("title", ""),
                "score": post.get("score", 0),
                "num_comments": post.get("num_comments", 0),
                "url": post.get("url", ""),
                "permalink": f"https://reddit.com{post.get('permalink', '')}",
                "author": post.get("author", ""),
                "subreddit": post.get("subreddit", subreddit),
                "created_utc": post.get("created_utc", 0),
                "selftext": (post.get("selftext", "") or "")[:200],
            })

        return posts

    async def search_reddit(
        self, query: str, sort: str = "hot", limit: int = 15
    ) -> list[dict[str, Any]]:
        """Sucht auf Reddit nach einem Begriff."""
        client = await self._get_client()
        url = f"{REDDIT_BASE_URL}/search.json"
        params = {"q": query, "sort": sort, "limit": limit, "raw_json": 1}

        resp = await client.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()

        results = []
        for child in data.get("data", {}).get("children", []):
            post = child.get("data", {})
            results.append({
                "title": post.get("title", ""),
                "score": post.get("score", 0),
                "num_comments": post.get("num_comments", 0),
                "url": post.get("url", ""),
                "permalink": f"https://reddit.com{post.get('permalink', '')}",
                "author": post.get("author", ""),
                "subreddit": post.get("subreddit", ""),
                "created_utc": post.get("created_utc", 0),
                "selftext": (post.get("selftext", "") or "")[:200],
            })

        return results

    # ── HackerNews ──────────────────────────────────────────

    async def get_hn_top_story_ids(self, limit: int = 20) -> list[int]:
        """Holt die IDs der Top-Stories von HackerNews."""
        client = await self._get_client()
        url = f"{HN_BASE_URL}/topstories.json"

        resp = await client.get(url)
        resp.raise_for_status()
        story_ids: list[int] = resp.json()

        return story_ids[:limit]

    async def get_hn_item(self, item_id: int) -> dict[str, Any]:
        """Holt ein einzelnes HN-Item (Story, Comment, etc.)."""
        client = await self._get_client()
        url = f"{HN_BASE_URL}/item/{item_id}.json"

        resp = await client.get(url)
        resp.raise_for_status()
        return resp.json() or {}

    async def get_hn_top_stories(self, limit: int = 20) -> list[dict[str, Any]]:
        """Holt die Top-Stories mit Details (parallelisiert)."""
        story_ids = await self.get_hn_top_story_ids(limit)

        # Alle Story-Details parallel abrufen
        tasks = [self.get_hn_item(sid) for sid in story_ids]
        items = await asyncio.gather(*tasks, return_exceptions=True)

        stories = []
        for item in items:
            if isinstance(item, Exception) or not isinstance(item, dict):
                continue
            stories.append({
                "title": item.get("title", ""),
                "score": item.get("score", 0),
                "num_comments": item.get("descendants", 0),
                "url": item.get("url", ""),
                "hn_url": f"https://news.ycombinator.com/item?id={item.get('id', '')}",
                "author": item.get("by", ""),
                "time": item.get("time", 0),
                "type": item.get("type", "story"),
            })

        return stories

    async def search_hn(self, query: str, limit: int = 15) -> list[dict[str, Any]]:
        """Sucht auf HackerNews via Algolia API."""
        client = await self._get_client()
        url = "https://hn.algolia.com/api/v1/search"
        params = {"query": query, "hitsPerPage": limit, "tags": "story"}

        resp = await client.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()

        results = []
        for hit in data.get("hits", []):
            results.append({
                "title": hit.get("title", ""),
                "score": hit.get("points", 0),
                "num_comments": hit.get("num_comments", 0),
                "url": hit.get("url", ""),
                "hn_url": f"https://news.ycombinator.com/item?id={hit.get('objectID', '')}",
                "author": hit.get("author", ""),
                "created_at": hit.get("created_at", ""),
            })

        return results


# Globale Client-Instanz
social_client = SocialClient()
