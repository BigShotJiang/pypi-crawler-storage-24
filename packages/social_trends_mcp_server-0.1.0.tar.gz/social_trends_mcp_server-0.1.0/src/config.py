"""
Konfiguration fuer den Social Trends MCP Server.
"""

# User-Agent fuer Reddit API (Pflicht, sonst 429)
USER_AGENT = "SocialTrendsMCP/0.1.0"

# API-Basis-URLs
REDDIT_BASE_URL = "https://www.reddit.com"
HN_BASE_URL = "https://hacker-news.firebaseio.com/v0"

# Standard-Limits
DEFAULT_HN_LIMIT = 20
DEFAULT_REDDIT_LIMIT = 15

# Timeout fuer HTTP-Requests in Sekunden
HTTP_TIMEOUT = 15.0
