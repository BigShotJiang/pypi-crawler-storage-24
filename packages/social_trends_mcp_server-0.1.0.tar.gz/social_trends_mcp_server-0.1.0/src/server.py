"""
Social Trends MCP Server.

Gibt AI-Agents Zugriff auf Trending-Topics von Reddit und HackerNews.
Laeuft standardmaessig ueber stdio-Transport.
"""

from mcp.server.fastmcp import FastMCP

from src.tools.trends import (
    get_subreddit_hot,
    get_tech_pulse,
    get_trending_hackernews,
    get_trending_topics,
    search_mentions,
    search_reddit,
)

# Server erstellen
mcp = FastMCP(
    "Social Trends MCP Server",
    instructions=(
        "Aggregiert Trending-Topics von Reddit und HackerNews. "
        "Bietet 6 Tools: Trending HN-Stories, Subreddit-Hot-Posts, "
        "Reddit-Suche, aggregierte Trends, Tech-Pulse und Mention-Suche."
    ),
)

# Tools registrieren
mcp.tool()(get_trending_hackernews)
mcp.tool()(get_subreddit_hot)
mcp.tool()(search_reddit)
mcp.tool()(get_trending_topics)
mcp.tool()(get_tech_pulse)
mcp.tool()(search_mentions)


def main() -> None:
    """Server starten (stdio-Transport)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
