# Social Trends MCP Server
