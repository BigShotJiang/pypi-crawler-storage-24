# Social Trends MCP Server

MCP server that gives AI agents access to trending topics from **Reddit** and **HackerNews** — both using free, public APIs with no authentication required.

## Tools (6)

| Tool | Description |
|------|-------------|
| `get_trending_hackernews` | Top HN stories with title, score, comments, URL |
| `get_subreddit_hot` | Hot posts from any subreddit |
| `search_reddit` | Search across all of Reddit |
| `get_trending_topics` | Aggregated trends from HN + Reddit front page |
| `get_tech_pulse` | Quick pulse: top 5 from HN + r/technology + r/programming |
| `search_mentions` | Check if a topic is being discussed on HN or Reddit |

## Installation

```bash
pip install social-trends-mcp-server
```

## Usage with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "social-trends": {
      "command": "social-trends-server"
    }
  }
}
```

## Usage with Claude Code

```bash
claude mcp add social-trends -- social-trends-server
```

## Examples

**"What's trending on HackerNews right now?"**
→ Uses `get_trending_hackernews`

**"Give me a tech pulse"**
→ Uses `get_tech_pulse` — top 5 from HN, r/technology, r/programming

**"Is anyone talking about Rust on social media?"**
→ Uses `search_mentions("Rust")` — searches HN + Reddit

**"What's hot on r/machinelearning?"**
→ Uses `get_subreddit_hot("machinelearning")`

## Data Sources

- **Reddit** — Public JSON API (no auth required)
- **HackerNews** — Firebase REST API (no auth required)
- **HN Search** — Algolia API (no auth required)

## No API Keys Needed

This server uses only public, free APIs. No configuration or API keys required.

## License

MIT
