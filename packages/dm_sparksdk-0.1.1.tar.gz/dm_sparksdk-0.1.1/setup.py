from setuptools import setup, find_packages

with open('DESCRIPTION.md', 'r', encoding='utf-8') as f:
    description = f.read()

setup(
    name='dm-sparkSDK',
    version='0.1.1',
    author='DeepModel',
    packages=find_packages(),
    install_requires=[
        'httpx>=0.24.0',
    ],
    python_requires='>=3.8',
    long_description=description,
    long_description_content_type='text/markdown',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)