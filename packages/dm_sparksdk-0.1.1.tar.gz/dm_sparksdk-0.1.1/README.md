# Spark SDK

A Python SDK for interacting with the DeepModel Spark API.

---

## Installation

### Install from PyPI
```bash
pip install dm-sparkSDK
```

### Install from Source
```bash
# 1. Clone the repository
git clone https://github.com/your-org/dm-sparkSDK.git
cd dm-sparkSDK

# 2. Install dependencies
pip install setuptools wheel twine httpx

# 3. Build the package
python setup.py sdist bdist_wheel

# 4. Install the built package
pip install dist\dm-sparkSDK-0.1.0-py3-none-any.whl

# Upload to PyPI
twine upload dist/*
```

---

## Quick Start

```python
import asyncio
import dm-sparkSDK

async def main():
    # Initialize the client
    client = dm-sparkSDK.Client(
        api_key="your_api_key",
        api_url="https://your-api-url.com"
    )

    # Get all unified tools and agents
    result = await client.get_unified_tools()
    print(result)

    # Invoke an MCP tool
    invoke_result = await client.invoke_tool(
        connection_id="uuid-here",
        target_type=dm-sparkSDK.MCP,
        tool_or_agent_name="create_issue",
        arguments={"title": "Bug report", "body": "Something went wrong"},
        query="create a github issue"
    )
    print(invoke_result)

asyncio.run(main())
```

---

## Usage

### Initialize the Client

```python
import dm-sparkSDK

client = dm-sparkSDK.Client(
    api_key="your_api_key",
    api_url="https://your-api-url.com"
)
```

| Parameter | Type   | Required | Description                        |
|-----------|--------|----------|------------------------------------|
| `api_key` | `str`  | ✅ Yes   | Your API key for authentication    |
| `api_url` | `str`  | ✅ Yes   | The base URL of the Spark API      |

---

### `get_unified_tools()`

Retrieves all MCP tools and worker agents accessible to the user, including their connection status and payload schemas.

```python
result = await client.get_unified_tools()
```

#### Response Structure

```json
{
    "success": true,
    "tools": {
        "mcp_tools": {
            "github": [
                {
                    "tool_name": "create_issue",
                    "is_configured": true,
                    "connection_id": "uuid-here",
                    "description": "Creates a GitHub issue",
                    "payload_schema": {},
                    "icon_url": "https://..."
                }
            ]
        },
        "worker_agents": [
            {
                "tool_name": "My Agent",
                "is_configured": true,
                "connection_id": "uuid-here",
                "description": "A custom worker agent",
                "payload_schema": {},
                "agent_avatar_url": "https://..."
            }
        ]
    },
    "status_code": 200,
    "detail": null
}
```

| Field         | Type           | Description                                  |
|---------------|----------------|----------------------------------------------|
| `success`     | `bool`         | Whether the request was successful           |
| `tools`       | `dict`         | All MCP tools and worker agents              |
| `status_code` | `int`          | HTTP status code of the response             |
| `detail`      | `str` / `null` | Error detail message if request failed       |

---

### `invoke_tool()`

Directly invoke an MCP tool or worker agent with provided arguments. No LLM inference is performed — arguments are used as-is.

```python
result = await client.invoke_tool(
    connection_id="uuid-here",
    target_type=dm-sparkSDK.MCP,         # or dm-sparkSDK.AGENT
    tool_or_agent_name="create_issue",
    arguments={"title": "Bug report", "body": "Something went wrong"},
    query="create a github issue"      # optional
)
```

#### Parameters

| Parameter            | Type            | Required | Description                                          |
|----------------------|-----------------|----------|------------------------------------------------------|
| `connection_id`      | `str` / `UUID`  | ✅ Yes   | The connection ID of the tool or agent               |
| `target_type`        | `str`           | ✅ Yes   | `dm-sparkSDK.MCP` (`"mcp"`) or `dm-sparkSDK.AGENT` (`"agent"`) |
| `tool_or_agent_name` | `str`           | ✅ Yes   | The name of the tool or agent to invoke              |
| `arguments`          | `dict`          | ✅ Yes   | Arguments to pass to the tool or agent               |
| `query`              | `str`           | ❌ No    | Optional user query context for agent invocation     |

#### Response Structure

```json
{
    "success": true,
    "tool_or_agent_name": "create_issue",
    "connection_id": "uuid-here",
    "result": {},
    "status_code": 200,
    "detail": null
}
```

| Field                | Type           | Description                                       |
|----------------------|----------------|---------------------------------------------------|
| `success`            | `bool`         | Whether the invocation was successful             |
| `tool_or_agent_name` | `str`          | The name of the tool or agent invoked             |
| `connection_id`      | `str`          | The connection ID used                            |
| `result`             | `any`          | The result returned by the tool or agent          |
| `status_code`        | `int`          | HTTP status code of the response                  |
| `detail`             | `str` / `null` | Error detail message if invocation failed         |

#### Target Type Constants

```python
dm-sparkSDK.MCP    # "mcp"   — for MCP tools
dm-sparkSDK.AGENT  # "agent" — for worker agents
```

---

### Error Handling

All errors are returned as part of the response dictionary rather than raising exceptions:

```python
result = await client.get_unified_tools()

if not result.get("success"):
    print(f"Error {result.get('status_code')}: {result.get('detail')}")
else:
    print(result.get("tools"))
```

| Error Type       | `status_code` | `detail` Example                                     |
|------------------|---------------|------------------------------------------------------|
| HTTP Error       | e.g. `401`    | `"No detail provided"`                               |
| Request Error    | `400`         | `"Request error: Connection refused"`                |
| Unexpected Error | `500`         | `"An unexpected error occurred: ..."`                |

---

## Project Structure

```
dm-sparkSDK/
├── dm-sparkSDK/
│   ├── __init__.py       # Exposes Client
│   └── client.py         # SparkClient class with all methods
├── setup.py              # Package configuration
└── README.md
```

---

## Requirements

- Python `>= 3.8`
- `httpx >= 0.24.0`

---

## Publishing to PyPI

```bash
# Install twine
pip install twine

# Build the package
python setup.py sdist bdist_wheel

# Upload to PyPI
twine upload dist/*
```

---

## License

This project is licensed under the MIT License.
