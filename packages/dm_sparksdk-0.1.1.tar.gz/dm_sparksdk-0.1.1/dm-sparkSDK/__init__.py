from .client import SparkClient

Client = SparkClient

# Target type constants for invoke_tool
MCP = "mcp"
AGENT = "agent"

__all__ = ["Client", "SparkClient", "MCP", "AGENT"]