import httpx
from typing import Any, Dict, Optional, Union
from uuid import UUID


class SparkClient:
    """
    Spark SDK Client.
    
    Usage:
        import spark_sdk
        client = spark_sdk.Client(api_key="your_api_key", api_url="https://your-api-url.com")
        result = await client.get_tools()
    """
    def __init__(self, api_key: str, api_url: str):
        """
        Initialize the Spark SDK Client.

        Args:
            api_key (str): Your API key for authentication.
            api_url (str): The base URL of the Spark API.
        """
        if not api_key:
            raise ValueError("API key is required.")
        if not api_url:
            raise ValueError("API URL is required.")
        
        self.api_key = api_key
        self.api_url = api_url.rstrip('/')
        self.headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json"
        }


    async def get_unified_tools(self):
        """
        Get all tools available in the Spark.
        Returns all available tools along with connected and not connected tools.

        Returns:
            dict: A dictionary containing all available tools along with connected and not connected tools.
        """
        endpoint = f"{self.api_url}/utils/unified-tools-and-agents"

        async with httpx.AsyncClient(timeout=None) as client:
            try:
                response = await client.get(endpoint, headers=self.headers)
                response.raise_for_status()
                return {
                    "success": True,
                    "tools": response.json(),
                    "status_code": response.status_code,
                    "detail": None
                }
            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "tools": None,
                    "status_code": e.response.status_code,
                    "detail": e.response.json().get("detail", "No detail provided")
                }
            except httpx.RequestError as e:
                return {
                    "success": False,
                    "tools": None,
                    "status_code": 400,
                    "detail": f"An error occurred while making the request: {str(e)}"
                }
            except Exception as e:
                return {
                    "success": False,
                    "tools": None,
                    "status_code": 500,
                    "detail": f"An unexpected error occurred: {str(e)}"
                }
            
    
    async def invoke_tool(self, connection_id: Union[str, UUID], target_type: str, tool_or_agent_name: str, arguments: Dict[str, Any], query: Optional[str] = "") -> dict:
        """
        Directly invoke an MCP tool or worker agent with provided arguments.
        No LLM inference is performed — arguments are used as-is.
        Required parameters are validated before execution.

        Args:
            connection_id (str): The connection ID of the tool or agent.
            target_type (str): The type of target to invoke. Either "mcp" or "agent".
            tool_or_agent_name (str): The name of the tool or agent to invoke.
            arguments (Dict[str, Any]): The arguments to pass to the tool or agent.
            query (Optional[str]): Optional user query context for agent invocation.

        Returns:
            dict: A dictionary containing:
                - success (bool): Whether the invocation was successful
                - tool_or_agent_name (str): The name of the tool or agent invoked
                - connection_id (str): The connection ID of the tool or agent invoked
                - result (Any): The result of the invocation
                - status_code (int): The HTTP status code of the response
                - detail (Optional[str]): Additional error details if any

        Example:
            result = await client.invoke_tool(
                connection_id="uuid-here",
                target_type="mcp",
                tool_or_agent_name="create_issue",
                arguments={"title": "Bug report", "body": "Something went wrong"},
                query="create a github issue"
            )
        """
        if target_type not in ("mcp", "agent"):
            return {
                "success": False,
                "tool_or_agent_name": tool_or_agent_name,
                "connection_id": connection_id,
                "result": None,
                "status_code": 400,
                "detail": "Invalid target_type. Must be 'mcp' or 'agent'."
            }

        endpoint = f"{self.api_url}/utils/tools/invoke"
        params = {"query": query} if query else {}
        payload = {
            "connection_id": connection_id,
            "target_type": target_type.lower(),
            "tool_or_agent_name": tool_or_agent_name,
            "arguments": arguments
        }

        async with httpx.AsyncClient(timeout=None) as client:
            try:
                response = await client.post(
                    endpoint,
                    headers=self.headers,
                    json=payload,
                    params=params
                )
                response.raise_for_status()
                return response.json()

            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "tool_or_agent_name": tool_or_agent_name,
                    "connection_id": connection_id,
                    "result": None,
                    "status_code": e.response.status_code,
                    "detail": e.response.json().get("detail", "No detail provided")
                }
            except httpx.RequestError as e:
                return {
                    "success": False,
                    "tool_or_agent_name": tool_or_agent_name,
                    "connection_id": connection_id,
                    "result": None,
                    "status_code": 400,
                    "detail": f"Request error: {str(e)}"
                }
            except Exception as e:
                return {
                    "success": False,
                    "tool_or_agent_name": tool_or_agent_name,
                    "connection_id": connection_id,
                    "result": None,
                    "status_code": 500,
                    "detail": f"Unexpected error: {str(e)}"
                }