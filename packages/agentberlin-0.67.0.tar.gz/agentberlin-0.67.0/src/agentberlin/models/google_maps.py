"""Pydantic models for Google Maps API responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class GoogleMapsSearchMetadata(BaseModel):
    """Metadata about the Google Maps search."""

    id: Optional[str] = None
    status: Optional[str] = None
    total_time_taken: Optional[float] = None


class GoogleMapsPlace(BaseModel):
    """Single place result from Google Maps search."""

    title: str
    place_id: Optional[str] = None
    data_id: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    rating: Optional[float] = None
    reviews: Optional[int] = None
    type: Optional[str] = None
    thumbnail: Optional[str] = None
    gps_coordinates: Optional[dict] = None
    hours: Optional[str] = None
    price_level: Optional[str] = None


class GoogleMapsSearchResponse(BaseModel):
    """Response for Google Maps search."""

    query: str
    results: List[GoogleMapsPlace] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleMapsSearchMetadata] = None


class GoogleMapsReview(BaseModel):
    """Single review from Google Maps."""

    rating: Optional[float] = None
    text: Optional[str] = None
    author: Optional[str] = None
    date: Optional[str] = None
    likes: Optional[int] = None
    response: Optional[str] = None


class GoogleMapsReviewsResponse(BaseModel):
    """Response for Google Maps reviews."""

    place_id: Optional[str] = None
    data_id: Optional[str] = None
    title: Optional[str] = None
    address: Optional[str] = None
    rating: Optional[float] = None
    total_reviews: Optional[int] = None
    reviews: List[GoogleMapsReview] = Field(default_factory=list)
    search_metadata: Optional[GoogleMapsSearchMetadata] = None
