"""Pydantic models for Google Trends API responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class GoogleTrendsMetadata(BaseModel):
    """Metadata about the Google Trends search."""

    id: Optional[str] = None
    status: Optional[str] = None
    total_time_taken: Optional[float] = None


class GoogleTrendsTimelinePoint(BaseModel):
    """Single point in interest over time timeline."""

    date: str
    value: int
    formatted_value: Optional[str] = None


class GoogleTrendsInterestOverTimeResponse(BaseModel):
    """Response for Google Trends interest over time."""

    query: str
    geo: Optional[str] = None
    timeframe: Optional[str] = None
    timeline: List[GoogleTrendsTimelinePoint] = Field(default_factory=list)
    average_interest: Optional[float] = None
    search_metadata: Optional[GoogleTrendsMetadata] = None


class GoogleTrendsRelatedQuery(BaseModel):
    """Single related query result."""

    query: str
    value: Optional[int] = None
    link: Optional[str] = None
    extracted_value: Optional[int] = None


class GoogleTrendsRelatedQueriesResponse(BaseModel):
    """Response for Google Trends related queries."""

    query: str
    geo: Optional[str] = None
    top: List[GoogleTrendsRelatedQuery] = Field(default_factory=list)
    rising: List[GoogleTrendsRelatedQuery] = Field(default_factory=list)
    search_metadata: Optional[GoogleTrendsMetadata] = None
