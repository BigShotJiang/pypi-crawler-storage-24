"""Pydantic models for Backlink Marketplace responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class BacklinkMarketplaceMarketplace(BaseModel):
    """Marketplace entry for a domain."""

    name: str
    price: float
    currency: str
    url: Optional[str] = None


class BacklinkMarketplaceDomain(BaseModel):
    """A domain from the backlink marketplace."""

    domain: str
    dr: int = Field(description="Domain Rating (Ahrefs)")
    da: int = Field(description="Domain Authority (Moz)")
    traffic: int = Field(description="Monthly organic traffic")
    rd: int = Field(description="Referring domains")
    categories: List[str] = Field(default_factory=list)
    language: str = ""
    country: str = ""
    link_type: str = Field(default="", description="dofollow/nofollow")
    marketplaces: List[BacklinkMarketplaceMarketplace] = Field(default_factory=list)
    min_price: float = 0
    max_price: float = 0
    spam_score: int = 0
    trust_flow: int = Field(default=0, description="Trust flow (Majestic)")
    citation_flow: int = Field(default=0, description="Citation flow (Majestic)")


class BacklinkMarketplaceListDomainsResponse(BaseModel):
    """Response for listing backlink marketplace domains."""

    domains: List[BacklinkMarketplaceDomain] = Field(default_factory=list)
    total: int
    limit: int
    offset: int
    has_more: bool
