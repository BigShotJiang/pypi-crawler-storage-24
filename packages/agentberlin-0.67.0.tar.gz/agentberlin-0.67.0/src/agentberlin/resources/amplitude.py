"""Amplitude resource for Agent Berlin SDK."""

from typing import Any, Dict, List, Optional

from .._http import HTTPClient
from ..models.amplitude import (
    AmplitudeCohort,
    AmplitudeEvent,
    AmplitudeResponse,
    CohortsListResponse,
    EventsListResponse,
    FunnelResponse,
    FunnelStep,
    RetentionDay,
    RetentionResponse,
    SessionsData,
    UsersData,
)
from ..utils import get_project_domain


class AmplitudeResource:
    """Resource for Amplitude product analytics.

    Provides access to Amplitude analytics data through the Agent Berlin API.
    The project context is determined by the sandbox's PROJECT_DOMAIN environment
    variable, so methods don't require explicit project parameters.

    Example:
        # Get core analytics
        analytics = client.amplitude.get()
        print(f"Active users: {analytics.users.active}")
        print(f"New users: {analytics.users.new}")
        print(f"Avg session length: {analytics.sessions.average_length}s")

        # List all events
        events = client.amplitude.list_events()
        for event in events.events:
            print(f"{event.name}: {event.totals} weekly")

        # Analyze a funnel
        funnel = client.amplitude.get_funnel(
            events=["Sign Up", "Complete Profile", "Make Purchase"]
        )
        print(f"Overall conversion: {funnel.overall_conversion}%")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def get(
        self,
        *,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> AmplitudeResponse:
        """Get core analytics data (sessions and users).

        Args:
            start_date: Start date in YYYYMMDD format. Defaults to 30 days ago.
            end_date: End date in YYYYMMDD format. Defaults to today.

        Returns:
            AmplitudeResponse with sessions and users data.

        Raises:
            AgentBerlinNotFoundError: If Amplitude integration not found.
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        payload: Dict[str, Any] = {
            "project_domain": project_domain,
        }

        if start_date is not None:
            payload["start_date"] = start_date
        if end_date is not None:
            payload["end_date"] = end_date

        data = self._http.post("/amplitude/get", json=payload)

        sessions = SessionsData(
            total=data["sessions"]["total"],
            average_length=data["sessions"]["average_length"],
            per_user=data["sessions"]["per_user"],
        )
        users = UsersData(
            active=data["users"]["active"],
            new=data["users"]["new"],
        )

        return AmplitudeResponse(sessions=sessions, users=users)

    def list_events(self) -> EventsListResponse:
        """List all trackable events.

        Returns:
            EventsListResponse with list of all events and their weekly totals.

        Raises:
            AgentBerlinNotFoundError: If Amplitude integration not found.
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        payload: Dict[str, Any] = {
            "project_domain": project_domain,
        }

        data = self._http.post("/amplitude/events", json=payload)

        events = [
            AmplitudeEvent(name=e["name"], totals=e["totals"])
            for e in data.get("events", [])
        ]

        return EventsListResponse(events=events)

    def list_cohorts(self) -> CohortsListResponse:
        """List all behavioral cohorts.

        Returns:
            CohortsListResponse with list of all cohorts and their sizes.

        Raises:
            AgentBerlinNotFoundError: If Amplitude integration not found.
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        payload: Dict[str, Any] = {
            "project_domain": project_domain,
        }

        data = self._http.post("/amplitude/cohorts", json=payload)

        cohorts = [
            AmplitudeCohort(
                id=c["id"],
                name=c["name"],
                size=c["size"],
                description=c.get("description"),
            )
            for c in data.get("cohorts", [])
        ]

        return CohortsListResponse(cohorts=cohorts)

    def get_funnel(
        self,
        events: List[str],
        *,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> FunnelResponse:
        """Analyze funnel conversion for a sequence of events.

        Args:
            events: List of event names in funnel order (min 2 events).
            start_date: Start date in YYYYMMDD format. Defaults to 30 days ago.
            end_date: End date in YYYYMMDD format. Defaults to today.

        Returns:
            FunnelResponse with conversion rates for each step.

        Raises:
            AgentBerlinNotFoundError: If Amplitude integration not found.
            AgentBerlinAPIError: If the API returns an error.
        """
        if len(events) < 2:
            raise ValueError("At least 2 events are required for funnel analysis")

        project_domain = get_project_domain()
        payload: Dict[str, Any] = {
            "project_domain": project_domain,
            "events": events,
        }

        if start_date is not None:
            payload["start_date"] = start_date
        if end_date is not None:
            payload["end_date"] = end_date

        data = self._http.post("/amplitude/funnel", json=payload)

        steps = [
            FunnelStep(
                event=s["event"],
                users_entered=s["users_entered"],
                users_completed=s["users_completed"],
                conversion_rate=s["conversion_rate"],
                drop_off_rate=s["drop_off_rate"],
            )
            for s in data.get("steps", [])
        ]

        return FunnelResponse(
            steps=steps,
            overall_conversion=data.get("overall_conversion", 0.0),
        )

    def get_retention(
        self,
        *,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> RetentionResponse:
        """Get retention analysis.

        Args:
            start_date: Start date in YYYYMMDD format. Defaults to 30 days ago.
            end_date: End date in YYYYMMDD format. Defaults to today.

        Returns:
            RetentionResponse with retention rates for days 0, 1, 7, 14, 30.

        Raises:
            AgentBerlinNotFoundError: If Amplitude integration not found.
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        payload: Dict[str, Any] = {
            "project_domain": project_domain,
        }

        if start_date is not None:
            payload["start_date"] = start_date
        if end_date is not None:
            payload["end_date"] = end_date

        data = self._http.post("/amplitude/retention", json=payload)

        retention = [
            RetentionDay(
                day=r["day"],
                retained=r["retained"],
                retention_rate=r["retention_rate"],
            )
            for r in data.get("retention", [])
        ]

        return RetentionResponse(
            cohort_size=data.get("cohort_size", 0),
            retention=retention,
        )
