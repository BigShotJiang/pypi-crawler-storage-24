"""Bing Search resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.bing_search import (
    BingSearchCopilotResponse,
    BingSearchImagesResponse,
    BingSearchNewsResponse,
    BingSearchShoppingResponse,
    BingSearchVideosResponse,
    BingSearchWebResponse,
)


class BingSearchResource:
    """Resource for Bing Search operations.

    Search the web using Microsoft Bing - includes web results, news, images,
    videos, shopping, and Copilot.

    Example:
        # Web search
        results = client.bing_search.web(
            query="best seo tools",
            max_results=10,
        )

        # News search
        results = client.bing_search.news(
            query="AI technology",
            country="us",
        )

        # Copilot AI search
        results = client.bing_search.copilot(
            query="What is SEO?",
        )

        for result in results.results:
            print(f"{result.title}: {result.url}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def web(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> BingSearchWebResponse:
        """Search the web using Bing.

        Returns titles, URLs, and snippets of top-ranking pages.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            BingSearchWebResponse with search results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/bing-search/web", json=payload)
        return BingSearchWebResponse.model_validate(data)

    def news(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> BingSearchNewsResponse:
        """Search Bing News.

        Returns news articles matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            BingSearchNewsResponse with news results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/bing-search/news", json=payload)
        return BingSearchNewsResponse.model_validate(data)

    def images(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> BingSearchImagesResponse:
        """Search Bing Images.

        Returns image results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            BingSearchImagesResponse with image results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/bing-search/images", json=payload)
        return BingSearchImagesResponse.model_validate(data)

    def videos(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> BingSearchVideosResponse:
        """Search Bing Videos.

        Returns video results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            BingSearchVideosResponse with video results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/bing-search/videos", json=payload)
        return BingSearchVideosResponse.model_validate(data)

    def shopping(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> BingSearchShoppingResponse:
        """Search Bing Shopping.

        Returns shopping/product results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            BingSearchShoppingResponse with shopping results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/bing-search/shopping", json=payload)
        return BingSearchShoppingResponse.model_validate(data)

    def copilot(
        self,
        query: str,
    ) -> BingSearchCopilotResponse:
        """Use Bing Copilot for AI-powered answers.

        Returns an AI-generated answer with source citations.

        Args:
            query: The search query to execute.

        Returns:
            BingSearchCopilotResponse with AI-generated answer and sources.
        """
        payload: dict[str, object] = {"query": query}

        data = self._http.post("/bing-search/copilot", json=payload)
        return BingSearchCopilotResponse.model_validate(data)
