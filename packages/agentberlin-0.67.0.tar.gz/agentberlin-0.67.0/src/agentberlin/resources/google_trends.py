"""Google Trends resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.google_trends import (
    GoogleTrendsInterestOverTimeResponse,
    GoogleTrendsRelatedQueriesResponse,
)


class GoogleTrendsResource:
    """Resource for Google Trends operations.

    Explore search interest over time and discover related queries.

    Example:
        # Get interest over time
        interest = client.google_trends.interest_over_time(
            query="artificial intelligence",
            geo="US",
            timeframe="today 12-m",
        )

        # Get related queries
        related = client.google_trends.related_queries(
            query="machine learning",
        )

        for point in interest.timeline:
            print(f"{point.date}: {point.value}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def interest_over_time(
        self,
        query: str,
        *,
        geo: Optional[str] = None,
        timeframe: Optional[str] = None,
    ) -> GoogleTrendsInterestOverTimeResponse:
        """Get search interest over time for a query.

        Returns a timeline of relative search interest (0-100).

        Args:
            query: The search term to analyze.
            geo: Geographic region code (e.g., 'US', 'GB', 'DE').
                Empty string for worldwide.
            timeframe: Time range for the data. Examples:
                - 'now 1-H': Past hour
                - 'now 4-H': Past 4 hours
                - 'now 1-d': Past day
                - 'now 7-d': Past 7 days
                - 'today 1-m': Past month
                - 'today 3-m': Past 3 months
                - 'today 12-m': Past year
                - 'today 5-y': Past 5 years
                - 'all': Since 2004
                - '2020-01-01 2020-12-31': Custom date range

        Returns:
            GoogleTrendsInterestOverTimeResponse with timeline data.
        """
        payload: dict[str, object] = {"query": query}
        if geo is not None:
            payload["geo"] = geo
        if timeframe is not None:
            payload["timeframe"] = timeframe

        data = self._http.post("/google-trends/interest-over-time", json=payload)
        return GoogleTrendsInterestOverTimeResponse.model_validate(data)

    def related_queries(
        self,
        query: str,
        *,
        geo: Optional[str] = None,
    ) -> GoogleTrendsRelatedQueriesResponse:
        """Get related queries for a search term.

        Returns both "top" related queries (by total volume) and
        "rising" queries (fastest growing).

        Args:
            query: The search term to analyze.
            geo: Geographic region code (e.g., 'US', 'GB', 'DE').
                Empty string for worldwide.

        Returns:
            GoogleTrendsRelatedQueriesResponse with top and rising queries.
        """
        payload: dict[str, object] = {"query": query}
        if geo is not None:
            payload["geo"] = geo

        data = self._http.post("/google-trends/related-queries", json=payload)
        return GoogleTrendsRelatedQueriesResponse.model_validate(data)
