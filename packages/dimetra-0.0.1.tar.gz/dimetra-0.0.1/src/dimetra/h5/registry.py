from __future__ import annotations
from h5kit.codec.codec_registry import CodecRegistry

codec_registry = CodecRegistry()