from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class LengthSeqCodecLayout:
    values_mm: str = "values_mm"
    unit: str = "unit"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(self.values_mm,),
            groups=(),
            attrs=(self.unit,))

LENGTH_SEQ_CODEC_LAYOUT = LengthSeqCodecLayout()