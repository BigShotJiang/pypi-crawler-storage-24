from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class LengthCodecLayout:
    value_mm: str = "value_mm"
    unit: str = "unit"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(datasets=(),groups=(),attrs=(self.value_mm, self.unit))


LENGTH_CODEC_LAYOUT = LengthCodecLayout()