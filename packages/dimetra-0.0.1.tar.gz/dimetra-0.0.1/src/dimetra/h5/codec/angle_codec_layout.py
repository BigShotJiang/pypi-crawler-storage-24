from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class AngleCodecLayout:
    value_rad: str = "value_rad"
    unit: str = "unit"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(datasets=(),groups=(),attrs=(self.value_rad, self.unit))

ANGLE_CODEC_LAYOUT = AngleCodecLayout()