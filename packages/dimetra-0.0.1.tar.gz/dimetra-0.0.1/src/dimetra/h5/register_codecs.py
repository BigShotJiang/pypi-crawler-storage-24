from __future__ import annotations

from allytools.h5.registry import codec_registry
from allytools.h5.codec.length_codec import LengthCodec
from allytools.h5.codec.length_seq_codec import LengthSeqCodec
from allytools.units.length import Length
from allytools.units.length_seq import LengthSeq


def register_allytools_codecs() -> None:
    codec_registry.register(LengthCodec, py_type=Length)
    codec_registry.register(LengthSeqCodec, py_type=LengthSeq)