from dataclasses import dataclass
from dimetra.geo.area import Area

@dataclass(frozen=True, slots=True)
class AreaVector3D:
    x: Area
    y: Area
    z: Area

    def norm(self) -> Area:
        import math
        return Area(
            math.hypot(
                self.x.value_mm2,
                self.y.value_mm2,
                self.z.value_mm2,
            )
        )

    def __str__(self) -> str:
        return f"AreaVector3D({self.x}, {self.y}, {self.z})"
