from __future__ import annotations
from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from typing import overload
from dimetra.geo.length import Length
from dimetra.geo.length_unit import LengthUnit
from dimetra.geo.length_array import LengthArray


@dataclass(frozen=True)
class LengthSeq(Sequence[Length]):
    _data: LengthArray

    def __post_init__(self) -> None:
        if self._data is None:
            raise ValueError("LengthSeq._data cannot be None")

        if not isinstance(self._data, LengthArray):
            raise TypeError(f"LengthSeq expects LengthArray, got {type(self._data).__name__}")

    def __len__(self) -> int:
        return len(self._data)

    @overload
    def __getitem__(self, index: int) -> Length: ...
    @overload
    def __getitem__(self, index: slice) -> LengthSeq: ...

    def __getitem__(self, index: int | slice) -> Length | LengthSeq:
        out = self._data[index]
        if isinstance(out, LengthArray):
            return LengthSeq(out)
        return out

    def __iter__(self) -> Iterator[Length]:
        for i in range(len(self._data)):
            yield self._data[i]

    @property
    def unit(self) -> LengthUnit:
        return self._data.unit

    @property
    def values_mm(self):
        return self._data.values_mm