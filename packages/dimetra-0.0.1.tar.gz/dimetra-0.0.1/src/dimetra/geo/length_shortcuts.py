from dimetra.geo.length import Length
from dimetra.geo.length_unit import LengthUnit

def mm(x: float) -> Length:
    return Length(x)

def um(x: float) -> Length:
    return Length(x, LengthUnit.UM)

def nm(x: float) -> Length:
    return Length(x, LengthUnit.NM)