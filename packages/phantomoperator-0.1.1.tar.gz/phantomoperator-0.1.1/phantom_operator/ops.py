import numpy as np
from phantom_operator.array import AbsentArray


def _ensure_array(x):
    if isinstance(x, AbsentArray):
        return x
    if isinstance(x, (int, float)):
        return AbsentArray(np.array([x]), np.array([0], dtype=np.int8))
    if isinstance(x, list):
        return AbsentArray(x)
    raise TypeError(f"Cannot convert {type(x).__name__} to AbsentArray")


def _broadcast(a, b):
    a = _ensure_array(a)
    b = _ensure_array(b)
    if a.shape != b.shape:
        try:
            v = np.broadcast_shapes(a.shape, b.shape)
            av = np.broadcast_to(a._values, v).copy()
            as_ = np.broadcast_to(a._states, v).copy()
            bv = np.broadcast_to(b._values, v).copy()
            bs = np.broadcast_to(b._states, v).copy()
            a = AbsentArray(av, as_)
            b = AbsentArray(bv, bs)
        except ValueError:
            raise ValueError(f"Cannot broadcast shapes {a.shape} and {b.shape}")
    return a, b


def add(x, y):
    x, y = _broadcast(x, y)
    same = x._states == y._states
    result_values = np.where(same, x._values + y._values, np.nan)
    result_states = np.where(same, x._states, -1)
    if np.any(~same):
        from absence_calculator import add as pt_add, AbsentNumber
        for idx in zip(*np.where(~same)):
            xn = AbsentNumber(x._values[idx], int(x._states[idx])) if x._values[idx] != 0 else AbsentNumber(1, 1)
            yn = AbsentNumber(y._values[idx], int(y._states[idx])) if y._values[idx] != 0 else AbsentNumber(1, 1)
            r = pt_add(xn, yn)
            result_values[idx] = r.left.value if hasattr(r, 'left') else (r.value if hasattr(r, 'value') else 0)
            result_states[idx] = 0
    result_states = np.where(result_states == -1, 0, result_states)
    return AbsentArray(result_values, result_states.astype(np.int8))


def subtract(x, y):
    x, y = _broadcast(x, y)
    same = x._states == y._states
    equal_vals = x._values == y._values
    void_mask = same & equal_vals
    normal_mask = same & ~equal_vals
    result_values = np.zeros_like(x._values)
    result_states = np.zeros_like(x._states)
    result_values[normal_mask] = x._values[normal_mask] - y._values[normal_mask]
    result_states[normal_mask] = x._states[normal_mask]
    result_values[void_mask] = 0
    result_states[void_mask] = 0
    if np.any(~same):
        for idx in zip(*np.where(~same)):
            result_values[idx] = x._values[idx]
            result_states[idx] = x._states[idx]
    return AbsentArray(result_values, result_states.astype(np.int8))


def multiply(x, y):
    x, y = _broadcast(x, y)
    result_values = x._values * y._values
    result_states = ((x._states.astype(np.int16) + y._states.astype(np.int16)) % 2).astype(np.int8)
    return AbsentArray(result_values, result_states)


def divide(x, y):
    x, y = _broadcast(x, y)
    with np.errstate(divide='ignore', invalid='ignore'):
        result_values = np.where(y._values != 0, x._values / y._values, 0)
    result_values = np.round(result_values, 10)
    int_mask = result_values == np.floor(result_values)
    result_values = np.where(int_mask, np.floor(result_values), result_values)
    result_states = ((x._states.astype(np.int16) + y._states.astype(np.int16)) % 2).astype(np.int8)
    return AbsentArray(result_values, result_states)


def erase(x, y):
    x, y = _broadcast(x, y)
    same = x._states == y._states
    remainder_vals = np.where(same, np.maximum(x._values - y._values, 0), x._values)
    remainder_states = x._states.copy()
    erased_vals = np.where(same, np.minimum(x._values, y._values), np.zeros_like(x._values))
    erased_states = np.where(same, (y._states.astype(np.int16) + 1) % 2, y._states).astype(np.int8)
    excess_vals = np.where(same, np.maximum(y._values - x._values, 0), np.zeros_like(y._values))
    excess_states = erased_states.copy()
    no_remainder = same & (x._values <= y._values)
    remainder_states = np.where(no_remainder, -1, remainder_states).astype(np.int8)
    remainder_vals = np.where(no_remainder, 0, remainder_vals)
    no_excess = same & (y._values <= x._values)
    excess_states = np.where(no_excess, -1, excess_states).astype(np.int8)
    excess_vals = np.where(no_excess, 0, excess_vals)
    return {
        'remainder': AbsentArray(remainder_vals, remainder_states),
        'erased': AbsentArray(erased_vals, erased_states),
        'excess': AbsentArray(excess_vals, excess_states),
    }


def toggle(arr):
    arr = _ensure_array(arr)
    new_states = ((arr._states.astype(np.int16) + 1) % 2).astype(np.int8)
    return AbsentArray(arr._values.copy(), new_states)


def where(arr, condition_fn=None):
    arr = _ensure_array(arr)
    if condition_fn is None:
        return np.where(arr._states == 0)
    mask = condition_fn(arr._values, arr._states)
    return np.where(mask)


def count_present(arr):
    arr = _ensure_array(arr)
    return int(np.sum(arr._states == 0))


def present_mask(arr):
    arr = _ensure_array(arr)
    return arr._states == 0


def absent_mask(arr):
    arr = _ensure_array(arr)
    return arr._states == 1
