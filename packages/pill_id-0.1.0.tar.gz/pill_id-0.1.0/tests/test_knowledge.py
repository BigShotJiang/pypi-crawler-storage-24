"""Tests for knowledge base modules."""

from pill_id.knowledge.colors_shapes import (
    STANDARD_COLORS,
    STANDARD_SHAPES,
    normalize_color,
    normalize_shape,
)
from pill_id.knowledge.imprint_codes import (
    MANUFACTURER_PATTERNS,
    identify_manufacturer,
)
from pill_id.knowledge.pill_database import PILL_DATABASE, get_database_stats


class TestColorsShapes:
    def test_standard_colors_not_empty(self):
        assert len(STANDARD_COLORS) >= 10

    def test_standard_shapes_not_empty(self):
        assert len(STANDARD_SHAPES) >= 10

    def test_normalize_color_exact(self):
        assert normalize_color("white") == "white"
        assert normalize_color("blue") == "blue"

    def test_normalize_color_alias(self):
        assert normalize_color("off-white") == "white"
        assert normalize_color("ivory") == "white"
        assert normalize_color("navy") == "blue"
        assert normalize_color("lavender") == "purple"
        assert normalize_color("grey") == "gray"

    def test_normalize_color_case_insensitive(self):
        assert normalize_color("WHITE") == "white"
        assert normalize_color("Light Blue") == "blue"

    def test_normalize_color_unknown(self):
        assert normalize_color("neon green") == "neon green"

    def test_normalize_shape_exact(self):
        assert normalize_shape("round") == "round"
        assert normalize_shape("capsule") == "capsule"

    def test_normalize_shape_alias(self):
        assert normalize_shape("circular") == "round"
        assert normalize_shape("elliptical") == "oval"
        assert normalize_shape("elongated") == "oblong"
        assert normalize_shape("rectangular") == "rectangle"

    def test_normalize_shape_case_insensitive(self):
        assert normalize_shape("OVAL") == "oval"


class TestImprintCodes:
    def test_patterns_not_empty(self):
        assert len(MANUFACTURER_PATTERNS) >= 40

    def test_identify_mylan(self):
        results = identify_manufacturer("M 357")
        manufacturers = [r[0] for r in results]
        assert "Mylan (Viatris)" in manufacturers

    def test_identify_amneal(self):
        results = identify_manufacturer("IP 102")
        manufacturers = [r[0] for r in results]
        assert "Amneal Pharmaceuticals" in manufacturers

    def test_identify_teva(self):
        results = identify_manufacturer("TV 7489")
        manufacturers = [r[0] for r in results]
        assert "Teva Pharmaceutical" in manufacturers

    def test_identify_teva_93(self):
        results = identify_manufacturer("93 48")
        manufacturers = [r[0] for r in results]
        assert "Teva Pharmaceutical" in manufacturers

    def test_identify_tylenol(self):
        results = identify_manufacturer("TYLENOL 500")
        manufacturers = [r[0] for r in results]
        assert "Johnson & Johnson" in manufacturers

    def test_identify_pfizer(self):
        results = identify_manufacturer("PFIZER")
        manufacturers = [r[0] for r in results]
        assert "Pfizer" in manufacturers

    def test_identify_lupin(self):
        results = identify_manufacturer("LU E71")
        manufacturers = [r[0] for r in results]
        assert "Lupin Pharmaceuticals" in manufacturers

    def test_identify_empty(self):
        assert identify_manufacturer("") == []

    def test_identify_unknown(self):
        assert identify_manufacturer("ZZZZZ 999") == []

    def test_case_insensitive(self):
        results = identify_manufacturer("tylenol 500")
        assert len(results) > 0


class TestPillDatabase:
    def test_database_has_200_plus_entries(self):
        assert len(PILL_DATABASE) >= 200

    def test_all_entries_have_required_fields(self):
        for entry in PILL_DATABASE:
            assert entry.name
            assert entry.generic_name
            assert entry.strength
            assert entry.manufacturer
            assert entry.imprint
            assert entry.color
            assert entry.shape

    def test_has_prescription_drugs(self):
        rx = [e for e in PILL_DATABASE if e.ndc is not None]
        assert len(rx) >= 50

    def test_has_otc_medications(self):
        otc_names = {"Advil", "Tylenol", "Aleve", "Claritin", "Zyrtec"}
        db_names = {e.name for e in PILL_DATABASE}
        assert otc_names.issubset(db_names)

    def test_has_supplements(self):
        supps = [e for e in PILL_DATABASE if "Vitamin" in e.name or "Omega" in e.name]
        assert len(supps) >= 10

    def test_database_stats(self):
        stats = get_database_stats()
        assert stats["total_entries"] >= 200
        assert stats["unique_manufacturers"] >= 10
        assert stats["unique_colors"] >= 5
        assert stats["unique_shapes"] >= 3
