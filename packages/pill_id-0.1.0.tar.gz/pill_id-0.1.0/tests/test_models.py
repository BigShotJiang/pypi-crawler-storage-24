"""Tests for data models."""

from pill_id.models import ExtractedFeatures, PillDatabaseEntry, PillMatch, PillResult


class TestExtractedFeatures:
    def test_minimal(self):
        f = ExtractedFeatures(color="white", shape="round")
        assert f.color == "white"
        assert f.shape == "round"
        assert f.imprint_front is None
        assert f.imprint_back is None

    def test_full(self):
        f = ExtractedFeatures(
            color="blue",
            shape="oval",
            imprint_front="M 357",
            imprint_back="5",
            scoring="single",
            coating="film-coated",
            size_estimate="medium",
            additional_notes="speckled",
        )
        assert f.imprint_front == "M 357"
        assert f.additional_notes == "speckled"

    def test_serialization(self):
        f = ExtractedFeatures(color="pink", shape="capsule")
        data = f.model_dump()
        assert data["color"] == "pink"
        assert data["shape"] == "capsule"
        reconstructed = ExtractedFeatures(**data)
        assert reconstructed == f


class TestPillMatch:
    def test_create(self):
        m = PillMatch(
            name="Tylenol",
            generic_name="Acetaminophen",
            strength="500mg",
            manufacturer="J&J",
            ndc="12345",
            imprint="TYLENOL 500",
            color="white",
            shape="capsule",
            confidence=0.95,
            match_details={"imprint": {"type": "exact"}},
        )
        assert m.confidence == 0.95
        assert m.match_details["imprint"]["type"] == "exact"

    def test_confidence_bounds(self):
        import pytest

        with pytest.raises(Exception):
            PillMatch(
                name="X", generic_name="X", strength="1mg",
                manufacturer="X", imprint="X", color="x",
                shape="x", confidence=1.5, match_details={},
            )

    def test_ndc_optional(self):
        m = PillMatch(
            name="X", generic_name="X", strength="1mg",
            manufacturer="X", imprint="X", color="x",
            shape="x", confidence=0.5, match_details={},
        )
        assert m.ndc is None


class TestPillResult:
    def test_default_disclaimer(self):
        r = PillResult(
            extracted_features=ExtractedFeatures(color="white", shape="round"),
        )
        assert "informational purposes" in r.disclaimer
        assert r.matches == []
        assert r.warnings == []

    def test_json_serialization(self):
        r = PillResult(
            extracted_features=ExtractedFeatures(color="blue", shape="oval"),
            matches=[],
            warnings=["test warning"],
            processing_time_ms=123.45,
        )
        json_str = r.model_dump_json()
        assert "test warning" in json_str
        assert "123.45" in json_str


class TestPillDatabaseEntry:
    def test_defaults(self):
        e = PillDatabaseEntry(
            name="Test",
            generic_name="Testerol",
            strength="10mg",
            manufacturer="TestCo",
            imprint="T 10",
            color="white",
            shape="round",
        )
        assert e.scoring == "none"
        assert e.coating == "uncoated"
        assert e.ndc is None
