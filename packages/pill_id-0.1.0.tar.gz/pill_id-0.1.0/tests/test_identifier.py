"""Tests for the main PillIdentifier class."""

from __future__ import annotations

import pytest

from pill_id.identifier import PillIdentifier
from pill_id.models import ExtractedFeatures
from tests.conftest import MockVisionProvider, make_test_image


class TestPillIdentifier:
    def test_identify_from_bytes(self, mock_provider, test_image_bytes):
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            vision_provider=mock_provider,
        )
        result = identifier.identify(test_image_bytes)

        assert result.extracted_features.color == "white"
        assert result.extracted_features.imprint_front == "TYLENOL 500"
        assert len(result.matches) > 0
        assert result.disclaimer
        assert result.processing_time_ms > 0
        assert mock_provider.call_count == 1

    def test_identify_from_features(self, tylenol_features):
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            vision_provider=MockVisionProvider(),
        )
        result = identifier.identify_from_features(tylenol_features)

        assert result.extracted_features == tylenol_features
        assert len(result.matches) > 0
        # Should find Tylenol
        names = [m.name for m in result.matches]
        assert any("Tylenol" in n for n in names)

    def test_identify_gabapentin(self, gabapentin_features):
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            vision_provider=MockVisionProvider(gabapentin_features),
        )
        result = identifier.identify_from_features(gabapentin_features)

        top = result.matches[0]
        assert "Gabapentin" in top.name or "Gabapentin" in top.generic_name
        assert top.confidence > 0.5

    def test_identify_unknown_pill(self, unknown_features):
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            vision_provider=MockVisionProvider(unknown_features),
        )
        result = identifier.identify_from_features(unknown_features)

        # Should have few or no matches above threshold
        assert all(m.confidence < 0.7 for m in result.matches)

    def test_identify_batch(self, mock_provider, test_image_bytes):
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            vision_provider=mock_provider,
        )
        results = identifier.identify_batch([test_image_bytes, test_image_bytes])

        assert len(results) == 2
        assert mock_provider.call_count == 2

    def test_missing_api_key_raises(self):
        with pytest.raises(ValueError, match="API key is required"):
            PillIdentifier(provider="openai", api_key=None)

    def test_unknown_provider_raises(self):
        with pytest.raises(ValueError, match="Unknown provider"):
            PillIdentifier(provider="google", api_key="test")

    def test_custom_database(self, small_database):
        features = ExtractedFeatures(
            color="white",
            shape="round",
            imprint_front="TP 100",
        )
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            vision_provider=MockVisionProvider(features),
            custom_database=small_database,
        )
        result = identifier.identify_from_features(features)

        assert len(result.matches) > 0
        assert result.matches[0].name == "Test Drug A"

    def test_top_k_limits_results(self, tylenol_features):
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            top_k=2,
            vision_provider=MockVisionProvider(tylenol_features),
        )
        result = identifier.identify_from_features(tylenol_features)
        assert len(result.matches) <= 2

    def test_disclaimer_always_present(self, tylenol_features):
        identifier = PillIdentifier(
            provider="openai",
            api_key="test",
            vision_provider=MockVisionProvider(tylenol_features),
        )
        result = identifier.identify_from_features(tylenol_features)
        assert "pharmacist" in result.disclaimer.lower()
