"""Tests for safety warnings and disclaimers."""

from pill_id.models import PillMatch
from pill_id.safety.warnings import DISCLAIMER, generate_warnings


def _make_match(
    name: str = "Test",
    generic: str = "Testamine",
    confidence: float = 0.9,
    imprint_type: str = "exact",
) -> PillMatch:
    return PillMatch(
        name=name,
        generic_name=generic,
        strength="10mg",
        manufacturer="TestCo",
        imprint="T10",
        color="white",
        shape="round",
        confidence=confidence,
        match_details={"imprint": {"type": imprint_type}},
    )


class TestDisclaimer:
    def test_disclaimer_content(self):
        assert "informational" in DISCLAIMER
        assert "pharmacist" in DISCLAIMER


class TestGenerateWarnings:
    def test_no_matches(self):
        warnings = generate_warnings([])
        assert len(warnings) == 1
        assert "No matches found" in warnings[0]

    def test_high_confidence_no_warning(self):
        matches = [_make_match(confidence=0.95)]
        warnings = generate_warnings(matches)
        assert not any("Low confidence" in w for w in warnings)

    def test_low_confidence_warning(self):
        matches = [_make_match(confidence=0.4)]
        warnings = generate_warnings(matches)
        assert any("Low confidence" in w for w in warnings)

    def test_multiple_high_confidence_warning(self):
        matches = [
            _make_match(name="Drug A", confidence=0.9),
            _make_match(name="Drug B", confidence=0.85),
        ]
        warnings = generate_warnings(matches)
        assert any("Multiple high-confidence" in w for w in warnings)

    def test_no_multiple_warning_when_one_high(self):
        matches = [
            _make_match(name="Drug A", confidence=0.9),
            _make_match(name="Drug B", confidence=0.5),
        ]
        warnings = generate_warnings(matches)
        assert not any("Multiple high-confidence" in w for w in warnings)

    def test_controlled_substance_warning(self):
        matches = [_make_match(generic="Alprazolam", confidence=0.9)]
        warnings = generate_warnings(matches)
        assert any("controlled substance" in w for w in warnings)

    def test_controlled_substance_hydrocodone(self):
        matches = [
            _make_match(generic="Hydrocodone/Acetaminophen", confidence=0.9)
        ]
        warnings = generate_warnings(matches)
        assert any("controlled substance" in w for w in warnings)

    def test_no_controlled_warning_for_regular_drug(self):
        matches = [_make_match(generic="Acetaminophen", confidence=0.9)]
        warnings = generate_warnings(matches)
        assert not any("controlled substance" in w for w in warnings)

    def test_no_imprint_warning(self):
        matches = [_make_match(imprint_type="none", confidence=0.5)]
        warnings = generate_warnings(matches)
        assert any("No imprint match" in w for w in warnings)

    def test_combined_warnings(self):
        matches = [_make_match(
            generic="Oxycodone",
            confidence=0.5,
            imprint_type="none",
        )]
        warnings = generate_warnings(matches)
        # Should have low confidence + controlled + no imprint
        assert len(warnings) >= 2
