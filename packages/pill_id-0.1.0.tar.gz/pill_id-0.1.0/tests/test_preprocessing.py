"""Tests for image preprocessing utilities."""

from __future__ import annotations

import io

import pytest
from PIL import Image

from pill_id.config import PillIDConfig
from pill_id.preprocessing.image_utils import (
    ImageValidationError,
    image_to_base64,
    prepare_image,
    resize_if_needed,
    validate_image,
)
from pill_id.preprocessing.prompt_builder import build_extraction_prompt
from tests.conftest import make_test_image


class TestValidateImage:
    def test_valid_jpeg(self, test_image_bytes):
        img = validate_image(test_image_bytes)
        assert img.size == (200, 200)

    def test_valid_png(self, test_image_png_bytes):
        img = validate_image(test_image_png_bytes)
        assert img.size == (200, 200)

    def test_too_large(self):
        config = PillIDConfig(
            provider="openai",
            api_key="test",
            max_image_size=100,  # 100 bytes
        )
        data = make_test_image()
        with pytest.raises(ImageValidationError, match="exceeds"):
            validate_image(data, config)

    def test_invalid_data(self):
        with pytest.raises(ImageValidationError, match="Cannot open"):
            validate_image(b"not an image")

    def test_empty_data(self):
        with pytest.raises(ImageValidationError):
            validate_image(b"")


class TestResizeIfNeeded:
    def test_no_resize_needed(self):
        img = Image.new("RGB", (100, 100))
        result = resize_if_needed(img, max_dimension=200)
        assert result.size == (100, 100)

    def test_resize_wide(self):
        img = Image.new("RGB", (4000, 2000))
        result = resize_if_needed(img, max_dimension=2048)
        assert result.size[0] == 2048
        assert result.size[1] == 1024

    def test_resize_tall(self):
        img = Image.new("RGB", (1000, 4000))
        result = resize_if_needed(img, max_dimension=2048)
        assert result.size[1] == 2048
        assert result.size[0] == 512


class TestImageToBase64:
    def test_jpeg(self):
        img = Image.new("RGB", (50, 50), "red")
        b64, mime = image_to_base64(img, "JPEG")
        assert len(b64) > 0
        assert mime == "image/jpeg"

    def test_png(self):
        img = Image.new("RGB", (50, 50), "blue")
        b64, mime = image_to_base64(img, "PNG")
        assert mime == "image/png"

    def test_rgba_to_jpeg(self):
        img = Image.new("RGBA", (50, 50), (255, 0, 0, 128))
        b64, mime = image_to_base64(img, "JPEG")
        assert mime == "image/jpeg"


class TestPrepareImage:
    def test_from_bytes(self, test_image_bytes):
        config = PillIDConfig(provider="openai", api_key="test")
        b64, mime = prepare_image(test_image_bytes, config)
        assert len(b64) > 0
        assert mime.startswith("image/")

    def test_from_file(self, tmp_path, test_image_bytes):
        path = tmp_path / "test.jpg"
        path.write_bytes(test_image_bytes)

        config = PillIDConfig(provider="openai", api_key="test")
        b64, mime = prepare_image(str(path), config)
        assert len(b64) > 0

    def test_file_not_found(self):
        config = PillIDConfig(provider="openai", api_key="test")
        with pytest.raises(FileNotFoundError):
            prepare_image("/nonexistent/path.jpg", config)

    def test_unsupported_type(self):
        config = PillIDConfig(provider="openai", api_key="test")
        with pytest.raises(ImageValidationError, match="Unsupported source type"):
            prepare_image(12345, config)  # type: ignore


class TestPromptBuilder:
    def test_includes_vocabulary(self):
        prompt = build_extraction_prompt(include_vocabulary=True)
        assert "white" in prompt
        assert "round" in prompt

    def test_excludes_vocabulary(self):
        prompt = build_extraction_prompt(include_vocabulary=False)
        assert "standardized color" not in prompt.lower()

    def test_requires_json(self):
        prompt = build_extraction_prompt()
        assert "JSON" in prompt
