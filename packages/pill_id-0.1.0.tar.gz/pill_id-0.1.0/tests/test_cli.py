"""Tests for the CLI interface."""

from __future__ import annotations

from unittest.mock import patch, MagicMock

from click.testing import CliRunner

from pill_id.cli import main


class TestCLI:
    def test_version(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_database_stats(self):
        runner = CliRunner()
        result = runner.invoke(main, ["database"])
        assert result.exit_code == 0
        assert "Total entries" in result.output
        assert "Prescription" in result.output

    def test_search_command(self):
        runner = CliRunner()
        result = runner.invoke(main, ["search", "--imprint", "M 357"])
        assert result.exit_code == 0
        # Should find hydrocodone
        assert "match" in result.output.lower()

    def test_search_no_results(self):
        runner = CliRunner()
        result = runner.invoke(main, ["search", "--imprint", "ZZZZZ999"])
        assert result.exit_code == 0
        assert "No matches" in result.output

    def test_search_with_color(self):
        runner = CliRunner()
        result = runner.invoke(
            main, ["search", "--imprint", "M 357", "--color", "white"]
        )
        assert result.exit_code == 0

    def test_search_json_output(self):
        runner = CliRunner()
        result = runner.invoke(
            main, ["search", "--imprint", "TYLENOL", "--json-output"]
        )
        assert result.exit_code == 0
        assert "[" in result.output  # JSON array

    def test_identify_missing_api_key(self):
        runner = CliRunner()
        result = runner.invoke(main, ["identify", "test.jpg"])
        assert result.exit_code == 1
        assert "Error" in result.output

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "identify" in result.output
        assert "search" in result.output
        assert "database" in result.output

    def test_identify_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["identify", "--help"])
        assert result.exit_code == 0
        assert "--provider" in result.output
        assert "--top" in result.output
