"""Shared fixtures for pill-id tests."""

from __future__ import annotations

import io
from unittest.mock import MagicMock

import pytest
from PIL import Image

from pill_id.models import ExtractedFeatures, PillDatabaseEntry
from pill_id.providers.base import BaseVisionProvider


def make_test_image(
    width: int = 200,
    height: int = 200,
    color: str = "white",
    fmt: str = "JPEG",
) -> bytes:
    """Create a simple test image as bytes."""
    img = Image.new("RGB", (width, height), color)
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return buf.getvalue()


class MockVisionProvider(BaseVisionProvider):
    """A mock vision provider that returns pre-defined features."""

    def __init__(self, features: ExtractedFeatures | None = None) -> None:
        super().__init__(api_key="test-key", model="test-model")
        self.features = features or ExtractedFeatures(
            color="white",
            shape="capsule",
            imprint_front="TYLENOL 500",
            imprint_back=None,
            scoring="none",
            coating="film-coated",
        )
        self.call_count = 0

    def extract_features(self, image_b64: str, mime_type: str) -> ExtractedFeatures:
        self.call_count += 1
        return self.features


@pytest.fixture
def mock_provider():
    """Return a MockVisionProvider with default features (Tylenol-like)."""
    return MockVisionProvider()


@pytest.fixture
def test_image_bytes():
    """Return simple JPEG test image bytes."""
    return make_test_image()


@pytest.fixture
def test_image_png_bytes():
    """Return simple PNG test image bytes."""
    return make_test_image(fmt="PNG")


@pytest.fixture
def tylenol_features():
    """Return features matching Tylenol Extra Strength 500mg."""
    return ExtractedFeatures(
        color="white",
        shape="capsule",
        imprint_front="TYLENOL 500",
        imprint_back=None,
        scoring="none",
        coating="film-coated",
    )


@pytest.fixture
def gabapentin_features():
    """Return features matching Gabapentin 300mg (IP 102)."""
    return ExtractedFeatures(
        color="yellow",
        shape="capsule",
        imprint_front="IP 102",
        imprint_back=None,
        scoring="none",
        coating="uncoated",
    )


@pytest.fixture
def unknown_features():
    """Return features for an unknown pill not in the database."""
    return ExtractedFeatures(
        color="purple",
        shape="hexagon",
        imprint_front="ZZZZZ 999",
        imprint_back="XYZ",
        scoring="cross",
        coating="sugar-coated",
    )


@pytest.fixture
def small_database():
    """Return a small test database with a few entries."""
    return [
        PillDatabaseEntry(
            name="Test Drug A",
            generic_name="Testamine",
            strength="100mg",
            manufacturer="Test Pharma",
            ndc="12345-6789",
            imprint="TP 100",
            color="white",
            shape="round",
            scoring="single",
            coating="film-coated",
        ),
        PillDatabaseEntry(
            name="Test Drug B",
            generic_name="Betastatin",
            strength="50mg",
            manufacturer="Mylan (Viatris)",
            ndc="98765-4321",
            imprint="M B50",
            color="blue",
            shape="oval",
            scoring="none",
            coating="uncoated",
        ),
        PillDatabaseEntry(
            name="Test Drug C",
            generic_name="Gammapril",
            strength="20mg",
            manufacturer="Teva Pharmaceutical",
            ndc="11111-2222",
            imprint="TV 2020",
            color="pink",
            shape="capsule",
            scoring="none",
            coating="film-coated",
        ),
    ]
