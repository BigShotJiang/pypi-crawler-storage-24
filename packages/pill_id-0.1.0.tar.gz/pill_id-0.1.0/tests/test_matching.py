"""Tests for feature matching and confidence scoring."""

from pill_id.matching.feature_matcher import FeatureMatcher
from pill_id.matching.scorer import compute_confidence
from pill_id.models import ExtractedFeatures, PillDatabaseEntry


class TestScorer:
    def test_exact_match(self):
        features = ExtractedFeatures(
            color="white",
            shape="capsule",
            imprint_front="TYLENOL 500",
            scoring="none",
            coating="film-coated",
        )
        entry = PillDatabaseEntry(
            name="Tylenol",
            generic_name="Acetaminophen",
            strength="500mg",
            manufacturer="J&J",
            imprint="TYLENOL 500",
            color="white",
            shape="capsule",
            scoring="none",
            coating="film-coated",
        )
        score, details = compute_confidence(features, entry)
        assert score >= 0.8
        assert details["imprint"]["type"] == "exact"
        assert details["color"]["matched"] is True
        assert details["shape"]["matched"] is True

    def test_partial_imprint_match(self):
        features = ExtractedFeatures(
            color="white",
            shape="capsule",
            imprint_front="TYLENOL",
        )
        entry = PillDatabaseEntry(
            name="Tylenol",
            generic_name="Acetaminophen",
            strength="500mg",
            manufacturer="J&J",
            imprint="TYLENOL 500",
            color="white",
            shape="capsule",
        )
        score, details = compute_confidence(features, entry)
        assert details["imprint"]["type"] == "partial"
        assert score > 0.3

    def test_no_match(self):
        features = ExtractedFeatures(
            color="purple",
            shape="hexagon",
            imprint_front="ZZZZZ",
        )
        entry = PillDatabaseEntry(
            name="Tylenol",
            generic_name="Acetaminophen",
            strength="500mg",
            manufacturer="J&J",
            imprint="TYLENOL 500",
            color="white",
            shape="capsule",
        )
        score, details = compute_confidence(features, entry)
        assert score < 0.3
        assert details["color"]["matched"] is False
        assert details["shape"]["matched"] is False

    def test_color_only_match(self):
        features = ExtractedFeatures(color="white", shape="round")
        entry = PillDatabaseEntry(
            name="Test",
            generic_name="Test",
            strength="10mg",
            manufacturer="Test",
            imprint="X",
            color="white",
            shape="oval",
        )
        score, details = compute_confidence(features, entry)
        assert details["color"]["matched"] is True
        assert details["shape"]["matched"] is False

    def test_shape_only_match(self):
        features = ExtractedFeatures(color="red", shape="round")
        entry = PillDatabaseEntry(
            name="Test",
            generic_name="Test",
            strength="10mg",
            manufacturer="Test",
            imprint="X",
            color="white",
            shape="round",
        )
        score, details = compute_confidence(features, entry)
        assert details["color"]["matched"] is False
        assert details["shape"]["matched"] is True

    def test_score_clamped_to_one(self):
        """Even with all matches, score should not exceed 1.0."""
        features = ExtractedFeatures(
            color="white",
            shape="capsule",
            imprint_front="TYLENOL 500",
            scoring="none",
            coating="film-coated",
        )
        entry = PillDatabaseEntry(
            name="Tylenol",
            generic_name="Acetaminophen",
            strength="500mg",
            manufacturer="J&J",
            imprint="TYLENOL 500",
            color="white",
            shape="capsule",
            scoring="none",
            coating="film-coated",
        )
        score, _ = compute_confidence(features, entry)
        assert score <= 1.0

    def test_color_alias_normalization(self):
        features = ExtractedFeatures(color="off-white", shape="round")
        entry = PillDatabaseEntry(
            name="Test",
            generic_name="Test",
            strength="10mg",
            manufacturer="Test",
            imprint="X",
            color="white",
            shape="round",
        )
        score, details = compute_confidence(features, entry)
        assert details["color"]["matched"] is True

    def test_imprint_front_and_back(self):
        features = ExtractedFeatures(
            color="white",
            shape="round",
            imprint_front="M",
            imprint_back="357",
        )
        entry = PillDatabaseEntry(
            name="Hydrocodone",
            generic_name="Hydrocodone",
            strength="5/325mg",
            manufacturer="Mallinckrodt",
            imprint="M 357",
            color="white",
            shape="capsule",
        )
        score, details = compute_confidence(features, entry)
        assert details["imprint"]["type"] in ("exact", "partial")
        assert details["imprint"]["score"] > 0


class TestFeatureMatcher:
    def test_match_tylenol(self, tylenol_features):
        matcher = FeatureMatcher()
        matches = matcher.match(tylenol_features)
        assert len(matches) > 0
        assert any("Tylenol" in m.name for m in matches)

    def test_match_gabapentin(self, gabapentin_features):
        matcher = FeatureMatcher()
        matches = matcher.match(gabapentin_features)
        assert len(matches) > 0
        assert matches[0].generic_name == "Gabapentin"

    def test_match_unknown(self, unknown_features):
        matcher = FeatureMatcher(confidence_threshold=0.5)
        matches = matcher.match(unknown_features)
        # Should have no high-confidence matches
        assert all(m.confidence < 0.7 for m in matches)

    def test_top_k_respected(self, tylenol_features):
        matcher = FeatureMatcher(top_k=3)
        matches = matcher.match(tylenol_features)
        assert len(matches) <= 3

    def test_confidence_threshold(self, tylenol_features):
        matcher = FeatureMatcher(confidence_threshold=0.9)
        matches = matcher.match(tylenol_features)
        for m in matches:
            assert m.confidence >= 0.9

    def test_custom_database(self, small_database):
        features = ExtractedFeatures(
            color="blue",
            shape="oval",
            imprint_front="M B50",
        )
        matcher = FeatureMatcher(database=small_database)
        matches = matcher.match(features)
        assert len(matches) > 0
        assert matches[0].name == "Test Drug B"

    def test_search_by_imprint(self):
        matcher = FeatureMatcher(top_k=10)
        matches = matcher.search_by_imprint("M 357", color="white")
        assert len(matches) > 0

    def test_matches_sorted_by_confidence(self, tylenol_features):
        matcher = FeatureMatcher(top_k=10, confidence_threshold=0.1)
        matches = matcher.match(tylenol_features)
        for i in range(len(matches) - 1):
            assert matches[i].confidence >= matches[i + 1].confidence

    def test_manufacturer_code_bonus(self):
        """Manufacturer code in imprint should boost confidence."""
        features = ExtractedFeatures(
            color="white",
            shape="round",
            imprint_front="M 55",
        )
        matcher = FeatureMatcher(top_k=10, confidence_threshold=0.1)
        matches = matcher.match(features)
        # Should find Mylan entries with manufacturer bonus
        mylan_matches = [m for m in matches if "Mylan" in m.manufacturer]
        assert len(mylan_matches) > 0
