"""Command-line interface for pill-id."""

from __future__ import annotations

import json
import sys

import click

from pill_id import __version__


@click.group()
@click.version_option(version=__version__, prog_name="pill-id")
def main() -> None:
    """pill-id: Identify pills and medications from images using AI."""


@main.command()
@click.argument("image", type=str)
@click.option(
    "--provider",
    type=click.Choice(["openai", "anthropic"]),
    default="openai",
    help="Vision AI provider.",
)
@click.option("--api-key", type=str, default=None, help="API key (or set env var).")
@click.option("--top", type=int, default=5, help="Number of top matches to show.")
@click.option("--json-output", "output_json", is_flag=True, help="Output raw JSON.")
@click.option("--threshold", type=float, default=0.3, help="Minimum confidence threshold.")
def identify(
    image: str,
    provider: str,
    api_key: str | None,
    top: int,
    output_json: bool,
    threshold: float,
) -> None:
    """Identify a pill from an image file or URL."""
    from pill_id import PillIdentifier

    try:
        identifier = PillIdentifier(
            provider=provider,
            api_key=api_key,
            top_k=top,
            confidence_threshold=threshold,
        )
        result = identifier.identify(image)
    except Exception as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)

    if output_json:
        click.echo(result.model_dump_json(indent=2))
        return

    # Pretty print
    click.echo()
    click.echo("Extracted Features:")
    click.echo(f"  Color: {result.extracted_features.color}")
    click.echo(f"  Shape: {result.extracted_features.shape}")
    if result.extracted_features.imprint_front:
        click.echo(f"  Imprint (front): {result.extracted_features.imprint_front}")
    if result.extracted_features.imprint_back:
        click.echo(f"  Imprint (back): {result.extracted_features.imprint_back}")
    if result.extracted_features.scoring:
        click.echo(f"  Scoring: {result.extracted_features.scoring}")
    if result.extracted_features.coating:
        click.echo(f"  Coating: {result.extracted_features.coating}")
    click.echo()

    if result.warnings:
        click.echo("Warnings:")
        for w in result.warnings:
            click.echo(f"  * {w}")
        click.echo()

    if result.matches:
        click.echo(f"Top {len(result.matches)} Matches:")
        for i, m in enumerate(result.matches, 1):
            click.echo(f"  {i}. {m.name} ({m.generic_name}) {m.strength}")
            click.echo(f"     Manufacturer: {m.manufacturer}")
            click.echo(f"     Imprint: {m.imprint}")
            click.echo(f"     Confidence: {m.confidence:.0%}")
            click.echo()
    else:
        click.echo("No matches found.")
        click.echo()

    click.echo(f"Disclaimer: {result.disclaimer}")
    click.echo(f"Processing time: {result.processing_time_ms:.0f}ms")


@main.command()
@click.option("--imprint", type=str, required=True, help="Imprint text to search.")
@click.option("--color", type=str, default=None, help="Filter by color.")
@click.option("--shape", type=str, default=None, help="Filter by shape.")
@click.option("--top", type=int, default=10, help="Number of results.")
@click.option("--json-output", "output_json", is_flag=True, help="Output raw JSON.")
def search(
    imprint: str,
    color: str | None,
    shape: str | None,
    top: int,
    output_json: bool,
) -> None:
    """Search the pill database by imprint, color, or shape."""
    from pill_id.matching.feature_matcher import FeatureMatcher

    matcher = FeatureMatcher(top_k=top)
    results = matcher.search_by_imprint(imprint, color=color, shape=shape)

    if output_json:
        data = [r.model_dump() for r in results]
        click.echo(json.dumps(data, indent=2))
        return

    if not results:
        click.echo("No matches found.")
        return

    click.echo(f"Found {len(results)} match(es) for imprint '{imprint}':")
    click.echo()
    for i, m in enumerate(results, 1):
        click.echo(f"  {i}. {m.name} ({m.generic_name}) {m.strength}")
        click.echo(f"     Manufacturer: {m.manufacturer}")
        click.echo(f"     Imprint: {m.imprint} | Color: {m.color} | Shape: {m.shape}")
        click.echo(f"     Confidence: {m.confidence:.0%}")
        click.echo()


@main.command()
def database() -> None:
    """Show pill database statistics."""
    from pill_id.knowledge.pill_database import get_database_stats

    stats = get_database_stats()
    click.echo("Pill Database Statistics:")
    click.echo(f"  Total entries:        {stats['total_entries']}")
    click.echo(f"  Prescription drugs:   {stats['prescription_entries']}")
    click.echo(f"  OTC / Supplements:    {stats['otc_supplement_entries']}")
    click.echo(f"  Unique generics:      {stats['unique_generic_names']}")
    click.echo(f"  Unique manufacturers: {stats['unique_manufacturers']}")
    click.echo(f"  Colors:               {stats['unique_colors']}")
    click.echo(f"  Shapes:               {stats['unique_shapes']}")


if __name__ == "__main__":
    main()
