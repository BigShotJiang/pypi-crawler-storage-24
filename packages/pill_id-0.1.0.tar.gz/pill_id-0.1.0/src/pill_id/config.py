"""Configuration for pill-id."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class PillIDConfig:
    """Configuration for PillIdentifier."""

    provider: str = "openai"
    api_key: str | None = None
    model: str | None = None
    top_k: int = 5
    confidence_threshold: float = 0.3
    max_image_size: int = 4 * 1024 * 1024  # 4 MB
    max_image_dimension: int = 2048
    supported_formats: tuple[str, ...] = ("JPEG", "PNG", "WEBP", "GIF", "BMP")
    request_timeout: float = 30.0

    def __post_init__(self) -> None:
        if self.api_key is None:
            self.api_key = self._resolve_api_key()
        if self.model is None:
            self.model = self._default_model()
        if self.top_k < 1:
            raise ValueError("top_k must be >= 1")

    def _resolve_api_key(self) -> str | None:
        """Resolve API key from environment variables."""
        if self.provider == "openai":
            return os.environ.get("OPENAI_API_KEY")
        elif self.provider == "anthropic":
            return os.environ.get("ANTHROPIC_API_KEY")
        return None

    def _default_model(self) -> str:
        """Return the default model for the configured provider."""
        defaults = {
            "openai": "gpt-4o",
            "anthropic": "claude-sonnet-4-20250514",
        }
        return defaults.get(self.provider, "gpt-4o")


# Singleton default config
_default_config: PillIDConfig | None = None


def get_default_config() -> PillIDConfig:
    """Return the default configuration, creating it lazily."""
    global _default_config
    if _default_config is None:
        _default_config = PillIDConfig(
            provider=os.environ.get("PILL_ID_PROVIDER", "openai"),
            top_k=int(os.environ.get("PILL_ID_TOP_K", "5")),
        )
    return _default_config
