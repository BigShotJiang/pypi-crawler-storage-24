"""Base class for vision model providers."""

from __future__ import annotations

import abc

from pill_id.models import ExtractedFeatures


class BaseVisionProvider(abc.ABC):
    """Abstract base class for AI vision providers."""

    def __init__(self, api_key: str, model: str, timeout: float = 30.0) -> None:
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    @abc.abstractmethod
    def extract_features(self, image_b64: str, mime_type: str) -> ExtractedFeatures:
        """Extract visual features from a base64-encoded pill image.

        Args:
            image_b64: Base64-encoded image data.
            mime_type: MIME type of the image (e.g. 'image/jpeg').

        Returns:
            Extracted visual features.
        """
        ...

    def _build_system_prompt(self) -> str:
        """Return the system prompt for pill feature extraction."""
        return (
            "You are a pill identification assistant. Analyze the provided image of a "
            "pill or tablet and extract its visual features. Respond ONLY with a JSON "
            "object containing the following fields:\n"
            '- "color": primary color (e.g. "white", "blue", "pink", "yellow", "orange")\n'
            '- "shape": shape (e.g. "round", "oval", "capsule", "oblong", "rectangle", '
            '"diamond", "triangle", "pentagon", "hexagon")\n'
            '- "imprint_front": text/numbers on front side, or null\n'
            '- "imprint_back": text/numbers on back side, or null\n'
            '- "scoring": score line type ("none", "single", "cross"), or null\n'
            '- "coating": coating type ("film-coated", "sugar-coated", "uncoated"), or null\n'
            '- "size_estimate": estimated size ("small", "medium", "large"), or null\n'
            '- "additional_notes": any other notable characteristics, or null\n\n'
            "Return ONLY valid JSON, no markdown, no explanation."
        )

    def _build_user_prompt(self) -> str:
        """Return the user prompt for pill feature extraction."""
        return (
            "Identify the visual features of this pill/tablet. "
            "Look carefully at the color, shape, any text or numbers imprinted on it, "
            "score lines, coating, and size. Return the features as JSON."
        )
