"""Vision model providers for pill feature extraction."""

from pill_id.providers.base import BaseVisionProvider
from pill_id.providers.openai_provider import OpenAIVisionProvider

__all__ = ["BaseVisionProvider", "OpenAIVisionProvider"]

# Conditional import for anthropic
try:
    from pill_id.providers.anthropic_provider import AnthropicVisionProvider

    __all__.append("AnthropicVisionProvider")
except ImportError:
    pass
