"""OpenAI GPT-4 Vision provider for pill feature extraction."""

from __future__ import annotations

import json

from openai import OpenAI

from pill_id.models import ExtractedFeatures
from pill_id.providers.base import BaseVisionProvider


class OpenAIVisionProvider(BaseVisionProvider):
    """Extract pill features using OpenAI's GPT-4 Vision API."""

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o",
        timeout: float = 30.0,
    ) -> None:
        super().__init__(api_key=api_key, model=model, timeout=timeout)
        self.client = OpenAI(api_key=api_key, timeout=timeout)

    def extract_features(self, image_b64: str, mime_type: str) -> ExtractedFeatures:
        """Extract visual features from a base64-encoded pill image via OpenAI."""
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": self._build_system_prompt()},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": self._build_user_prompt()},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{mime_type};base64,{image_b64}",
                                "detail": "high",
                            },
                        },
                    ],
                },
            ],
            max_tokens=500,
            temperature=0.1,
        )

        raw = response.choices[0].message.content or "{}"
        # Strip markdown code fences if present
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
        if raw.endswith("```"):
            raw = raw.rsplit("```", 1)[0]
        raw = raw.strip()

        data = json.loads(raw)
        return ExtractedFeatures(**data)
