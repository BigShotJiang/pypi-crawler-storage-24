"""Anthropic Claude Vision provider for pill feature extraction."""

from __future__ import annotations

import json

try:
    from anthropic import Anthropic
except ImportError as exc:
    raise ImportError(
        "The anthropic package is required for the Anthropic provider. "
        "Install it with: pip install pill-id[anthropic]"
    ) from exc

from pill_id.models import ExtractedFeatures
from pill_id.providers.base import BaseVisionProvider


class AnthropicVisionProvider(BaseVisionProvider):
    """Extract pill features using Anthropic's Claude Vision API."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-20250514",
        timeout: float = 30.0,
    ) -> None:
        super().__init__(api_key=api_key, model=model, timeout=timeout)
        self.client = Anthropic(api_key=api_key, timeout=timeout)

    def extract_features(self, image_b64: str, mime_type: str) -> ExtractedFeatures:
        """Extract visual features from a base64-encoded pill image via Anthropic."""
        response = self.client.messages.create(
            model=self.model,
            max_tokens=500,
            system=self._build_system_prompt(),
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": mime_type,
                                "data": image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": self._build_user_prompt(),
                        },
                    ],
                }
            ],
        )

        raw = response.content[0].text
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
        if raw.endswith("```"):
            raw = raw.rsplit("```", 1)[0]
        raw = raw.strip()

        data = json.loads(raw)
        return ExtractedFeatures(**data)
