"""Image validation, resizing, and format conversion utilities."""

from __future__ import annotations

import base64
import io
from pathlib import Path

from PIL import Image

from pill_id.config import PillIDConfig, get_default_config


class ImageValidationError(Exception):
    """Raised when an image fails validation."""


def validate_image(
    data: bytes,
    config: PillIDConfig | None = None,
) -> Image.Image:
    """Validate image bytes and return a PIL Image.

    Args:
        data: Raw image bytes.
        config: Optional configuration (uses default if not provided).

    Returns:
        PIL Image object.

    Raises:
        ImageValidationError: If the image is invalid, too large, or unsupported.
    """
    cfg = config or get_default_config()

    if len(data) > cfg.max_image_size:
        max_mb = cfg.max_image_size / (1024 * 1024)
        raise ImageValidationError(
            f"Image size ({len(data) / (1024 * 1024):.1f} MB) exceeds "
            f"maximum allowed size ({max_mb:.0f} MB)."
        )

    try:
        img = Image.open(io.BytesIO(data))
        img.verify()
        # Re-open after verify (verify closes the file)
        img = Image.open(io.BytesIO(data))
    except Exception as exc:
        raise ImageValidationError(f"Cannot open image: {exc}") from exc

    fmt = img.format
    if fmt and fmt.upper() not in cfg.supported_formats:
        raise ImageValidationError(
            f"Unsupported image format '{fmt}'. "
            f"Supported: {', '.join(cfg.supported_formats)}"
        )

    return img


def resize_if_needed(
    img: Image.Image,
    max_dimension: int | None = None,
    config: PillIDConfig | None = None,
) -> Image.Image:
    """Resize an image if it exceeds the maximum dimension.

    Args:
        img: PIL Image to potentially resize.
        max_dimension: Override for maximum dimension.
        config: Optional configuration.

    Returns:
        Resized (or original) PIL Image.
    """
    cfg = config or get_default_config()
    max_dim = max_dimension or cfg.max_image_dimension

    w, h = img.size
    if max(w, h) <= max_dim:
        return img

    if w > h:
        new_w = max_dim
        new_h = int(h * (max_dim / w))
    else:
        new_h = max_dim
        new_w = int(w * (max_dim / h))

    return img.resize((new_w, new_h), Image.LANCZOS)


def image_to_base64(img: Image.Image, target_format: str = "JPEG") -> tuple[str, str]:
    """Convert a PIL Image to base64 string.

    Args:
        img: PIL Image.
        target_format: Target format for encoding.

    Returns:
        Tuple of (base64_string, mime_type).
    """
    buffer = io.BytesIO()

    # Convert RGBA to RGB for JPEG
    if target_format.upper() == "JPEG" and img.mode in ("RGBA", "P"):
        img = img.convert("RGB")

    img.save(buffer, format=target_format)
    b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")

    mime_map = {
        "JPEG": "image/jpeg",
        "PNG": "image/png",
        "WEBP": "image/webp",
        "GIF": "image/gif",
        "BMP": "image/bmp",
    }
    mime_type = mime_map.get(target_format.upper(), "image/jpeg")
    return b64, mime_type


def prepare_image(
    source: str | bytes | Path,
    config: PillIDConfig | None = None,
) -> tuple[str, str]:
    """Prepare an image for sending to a vision model.

    Accepts a file path, URL, or raw bytes. Returns base64 string and MIME type.

    Args:
        source: File path, URL string, or raw bytes.
        config: Optional configuration.

    Returns:
        Tuple of (base64_string, mime_type).

    Raises:
        ImageValidationError: If the image is invalid.
        FileNotFoundError: If a file path doesn't exist.
    """
    cfg = config or get_default_config()

    if isinstance(source, (str, Path)):
        source_str = str(source)

        # URL
        if source_str.startswith(("http://", "https://")):
            import httpx

            resp = httpx.get(source_str, timeout=cfg.request_timeout, follow_redirects=True)
            resp.raise_for_status()
            data = resp.content
        else:
            # File path
            path = Path(source_str)
            if not path.exists():
                raise FileNotFoundError(f"Image file not found: {path}")
            data = path.read_bytes()
    elif isinstance(source, bytes):
        data = source
    else:
        raise ImageValidationError(
            f"Unsupported source type: {type(source).__name__}. "
            "Expected str, Path, or bytes."
        )

    img = validate_image(data, cfg)
    img = resize_if_needed(img, config=cfg)

    # Determine output format
    fmt = img.format or "JPEG"
    if fmt.upper() not in ("JPEG", "PNG", "WEBP"):
        fmt = "JPEG"

    return image_to_base64(img, target_format=fmt.upper())
