"""Build structured prompts for vision model feature extraction."""

from __future__ import annotations

from pill_id.knowledge.colors_shapes import STANDARD_COLORS, STANDARD_SHAPES


def build_extraction_prompt(include_vocabulary: bool = True) -> str:
    """Build a detailed prompt for extracting pill features.

    Args:
        include_vocabulary: Whether to include the standardized vocabulary
            of colors and shapes as hints for the model.

    Returns:
        A prompt string for the vision model.
    """
    lines = [
        "Analyze this image of a pill, tablet, or capsule.",
        "Extract the following visual features and return them as a JSON object:",
        "",
        "Required fields:",
        '  "color" — the primary color of the pill',
        '  "shape" — the overall shape',
        "",
        "Optional fields (use null if not visible or not applicable):",
        '  "imprint_front" — any text, numbers, or logos on the front side',
        '  "imprint_back" — any text, numbers, or logos on the back side',
        '  "scoring" — score/break lines: "none", "single", or "cross"',
        '  "coating" — coating type: "film-coated", "sugar-coated", or "uncoated"',
        '  "size_estimate" — estimated size relative to typical pills: '
        '"small", "medium", or "large"',
        '  "additional_notes" — anything else notable (e.g., speckled, two-tone)',
        "",
    ]

    if include_vocabulary:
        lines.extend([
            "Use these standardized color names when possible:",
            f"  {', '.join(STANDARD_COLORS)}",
            "",
            "Use these standardized shape names when possible:",
            f"  {', '.join(STANDARD_SHAPES)}",
            "",
        ])

    lines.extend([
        "IMPORTANT: Return ONLY a valid JSON object. No markdown fences, ",
        "no explanation, no extra text.",
    ])

    return "\n".join(lines)
