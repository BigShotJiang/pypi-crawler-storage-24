"""Confidence scoring logic for pill matching."""

from __future__ import annotations

from pill_id.knowledge.colors_shapes import normalize_color, normalize_shape
from pill_id.models import ExtractedFeatures, PillDatabaseEntry


# Weight constants
WEIGHT_IMPRINT_EXACT = 0.50
WEIGHT_IMPRINT_PARTIAL = 0.25
WEIGHT_COLOR = 0.15
WEIGHT_SHAPE = 0.15
WEIGHT_MANUFACTURER_CODE = 0.10
WEIGHT_SCORING_COATING = 0.10


def _normalize_imprint(text: str | None) -> str:
    """Normalize imprint text for comparison."""
    if not text:
        return ""
    return text.upper().strip().replace(" ", "").replace("-", "")


def _imprint_score(
    extracted_front: str | None,
    extracted_back: str | None,
    db_imprint: str,
) -> tuple[float, str]:
    """Score imprint match between extracted features and a database entry.

    Returns:
        Tuple of (score, match_type) where match_type is one of:
        'exact', 'partial', 'none'.
    """
    norm_db = _normalize_imprint(db_imprint)
    if not norm_db:
        return 0.0, "none"

    # Combine front and back imprints
    parts = []
    if extracted_front:
        parts.append(extracted_front)
    if extracted_back:
        parts.append(extracted_back)

    if not parts:
        return 0.0, "none"

    combined = _normalize_imprint(" ".join(parts))

    # Exact match
    if combined == norm_db:
        return WEIGHT_IMPRINT_EXACT, "exact"

    # Check if one contains the other
    if norm_db in combined or combined in norm_db:
        return WEIGHT_IMPRINT_PARTIAL, "partial"

    # Check if any word from the extracted text matches any word in db imprint
    extracted_words = set(combined)
    db_words = set(norm_db)
    if extracted_words & db_words and len(combined) > 2:
        # Character overlap ratio
        overlap = len(extracted_words & db_words) / max(len(db_words), 1)
        if overlap > 0.5:
            return WEIGHT_IMPRINT_PARTIAL * 0.8, "partial"

    return 0.0, "none"


def _color_score(extracted: str, db_color: str) -> tuple[float, bool]:
    """Score color match. Returns (score, matched)."""
    norm_ext = normalize_color(extracted)
    norm_db = normalize_color(db_color)
    if norm_ext == norm_db:
        return WEIGHT_COLOR, True
    return 0.0, False


def _shape_score(extracted: str, db_shape: str) -> tuple[float, bool]:
    """Score shape match. Returns (score, matched)."""
    norm_ext = normalize_shape(extracted)
    norm_db = normalize_shape(db_shape)
    if norm_ext == norm_db:
        return WEIGHT_SHAPE, True
    return 0.0, False


def _scoring_coating_score(
    extracted_scoring: str | None,
    extracted_coating: str | None,
    db_scoring: str,
    db_coating: str,
) -> tuple[float, dict]:
    """Score match for scoring lines and coating type."""
    score = 0.0
    details: dict[str, bool] = {}

    if extracted_scoring and extracted_scoring.lower() == db_scoring.lower():
        score += WEIGHT_SCORING_COATING / 2
        details["scoring_match"] = True
    else:
        details["scoring_match"] = False

    if extracted_coating and extracted_coating.lower() == db_coating.lower():
        score += WEIGHT_SCORING_COATING / 2
        details["coating_match"] = True
    else:
        details["coating_match"] = False

    return score, details


def compute_confidence(
    features: ExtractedFeatures,
    entry: PillDatabaseEntry,
) -> tuple[float, dict]:
    """Compute a confidence score for how well extracted features match a DB entry.

    Args:
        features: Features extracted from the pill image.
        entry: A database entry to compare against.

    Returns:
        Tuple of (confidence_score, match_details).
        confidence_score is between 0.0 and 1.0.
        match_details describes which features matched or mismatched.
    """
    total = 0.0
    details: dict = {}

    # Imprint
    imp_score, imp_type = _imprint_score(
        features.imprint_front, features.imprint_back, entry.imprint
    )
    total += imp_score
    details["imprint"] = {"score": imp_score, "type": imp_type}

    # Color
    c_score, c_match = _color_score(features.color, entry.color)
    total += c_score
    details["color"] = {"score": c_score, "matched": c_match}

    # Shape
    s_score, s_match = _shape_score(features.shape, entry.shape)
    total += s_score
    details["shape"] = {"score": s_score, "matched": s_match}

    # Scoring + coating
    sc_score, sc_details = _scoring_coating_score(
        features.scoring, features.coating, entry.scoring, entry.coating
    )
    total += sc_score
    details["scoring_coating"] = {"score": sc_score, **sc_details}

    # Clamp to [0, 1]
    total = min(max(total, 0.0), 1.0)

    return total, details
