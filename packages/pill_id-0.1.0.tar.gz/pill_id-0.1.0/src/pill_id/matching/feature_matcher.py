"""Match extracted features against the pill database."""

from __future__ import annotations

from pill_id.knowledge.imprint_codes import identify_manufacturer
from pill_id.knowledge.pill_database import PILL_DATABASE
from pill_id.matching.scorer import compute_confidence
from pill_id.models import ExtractedFeatures, PillDatabaseEntry, PillMatch


class FeatureMatcher:
    """Match extracted pill features against the embedded database."""

    def __init__(
        self,
        database: list[PillDatabaseEntry] | None = None,
        top_k: int = 5,
        confidence_threshold: float = 0.3,
    ) -> None:
        self.database = database if database is not None else PILL_DATABASE
        self.top_k = top_k
        self.confidence_threshold = confidence_threshold

    def match(self, features: ExtractedFeatures) -> list[PillMatch]:
        """Find the best matching pills for the given extracted features.

        Args:
            features: Visual features extracted from a pill image.

        Returns:
            List of PillMatch objects sorted by confidence (descending),
            limited to top_k results above the confidence threshold.
        """
        scored: list[tuple[float, dict, PillDatabaseEntry]] = []

        for entry in self.database:
            confidence, details = compute_confidence(features, entry)

            # Bonus for manufacturer code match
            if features.imprint_front or features.imprint_back:
                imprint_text = " ".join(
                    filter(None, [features.imprint_front, features.imprint_back])
                )
                mfr_matches = identify_manufacturer(imprint_text)
                for mfr_name, _desc in mfr_matches:
                    if mfr_name.lower() in entry.manufacturer.lower():
                        confidence = min(confidence + 0.10, 1.0)
                        details["manufacturer_code"] = {
                            "matched": True,
                            "manufacturer": mfr_name,
                        }
                        break

            if confidence >= self.confidence_threshold:
                scored.append((confidence, details, entry))

        # Sort by confidence descending
        scored.sort(key=lambda x: x[0], reverse=True)

        results: list[PillMatch] = []
        for confidence, details, entry in scored[: self.top_k]:
            results.append(
                PillMatch(
                    name=entry.name,
                    generic_name=entry.generic_name,
                    strength=entry.strength,
                    manufacturer=entry.manufacturer,
                    ndc=entry.ndc,
                    imprint=entry.imprint,
                    color=entry.color,
                    shape=entry.shape,
                    confidence=round(confidence, 4),
                    match_details=details,
                )
            )

        return results

    def search_by_imprint(
        self,
        imprint: str,
        color: str | None = None,
        shape: str | None = None,
    ) -> list[PillMatch]:
        """Search the database by imprint text with optional color/shape filters.

        Args:
            imprint: Imprint text to search for.
            color: Optional color filter.
            shape: Optional shape filter.

        Returns:
            List of matching PillMatch objects.
        """
        features = ExtractedFeatures(
            color=color or "",
            shape=shape or "",
            imprint_front=imprint,
        )
        # Temporarily lower threshold for search
        old_threshold = self.confidence_threshold
        self.confidence_threshold = 0.1
        results = self.match(features)
        self.confidence_threshold = old_threshold
        return results
