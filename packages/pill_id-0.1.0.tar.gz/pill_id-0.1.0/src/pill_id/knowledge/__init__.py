"""Embedded knowledge bases for pill identification."""

from pill_id.knowledge.colors_shapes import STANDARD_COLORS, STANDARD_SHAPES
from pill_id.knowledge.imprint_codes import MANUFACTURER_PATTERNS
from pill_id.knowledge.pill_database import PILL_DATABASE

__all__ = [
    "PILL_DATABASE",
    "MANUFACTURER_PATTERNS",
    "STANDARD_COLORS",
    "STANDARD_SHAPES",
]
