"""Common manufacturer imprint code patterns for pill identification."""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class ManufacturerPattern:
    """A pattern linking imprint codes to manufacturers."""

    pattern: str  # regex pattern
    manufacturer: str
    description: str


# ~50 common manufacturer imprint patterns
MANUFACTURER_PATTERNS: list[ManufacturerPattern] = [
    # Major generic manufacturers
    ManufacturerPattern(r"^M\s?\d+", "Mylan (Viatris)", "M followed by numbers"),
    ManufacturerPattern(r"^MYL", "Mylan (Viatris)", "MYL prefix"),
    ManufacturerPattern(r"^IP\s?\d+", "Amneal Pharmaceuticals", "IP followed by numbers"),
    ManufacturerPattern(r"^AN\s?\d+", "Amneal Pharmaceuticals", "AN followed by numbers"),
    ManufacturerPattern(r"^IG\s?\d+", "InvaGen (Cipla)", "IG followed by numbers"),
    ManufacturerPattern(r"^G\s?\d+", "Glenmark Pharmaceuticals", "G followed by numbers"),
    ManufacturerPattern(r"^GG\s?\d+", "Geneva Generics (Sandoz)", "GG followed by numbers"),
    ManufacturerPattern(r"^E\s?\d+", "Endo/Par Pharmaceutical", "E followed by numbers"),
    ManufacturerPattern(r"^L\s?\d+", "Perrigo / L Perrigo", "L followed by numbers"),
    ManufacturerPattern(r"^LU\s?[A-Z]\d+", "Lupin Pharmaceuticals", "LU letter-numbers"),
    ManufacturerPattern(r"^SG\s?\d+", "ScieGen Pharmaceuticals", "SG followed by numbers"),
    ManufacturerPattern(r"^SL\s?\d+", "Solco Healthcare", "SL followed by numbers"),
    ManufacturerPattern(r"^TV\s?\d+", "Teva Pharmaceutical", "TV followed by numbers"),
    ManufacturerPattern(r"^TEVA", "Teva Pharmaceutical", "TEVA prefix"),
    ManufacturerPattern(r"^93\s?\d+", "Teva Pharmaceutical", "93 followed by numbers (legacy)"),
    ManufacturerPattern(r"^ZC\s?\d+", "Zydus (Cadila)", "ZC followed by numbers"),
    ManufacturerPattern(r"^Z\s?\d+", "Zydus (Cadila)", "Z followed by numbers"),
    ManufacturerPattern(r"^WPI\s?\d+", "Watson (Actavis/Teva)", "WPI followed by numbers"),
    ManufacturerPattern(r"^WAT\s?\d+", "Watson (Actavis/Teva)", "WAT followed by numbers"),
    ManufacturerPattern(r"^APO", "Apotex Corporation", "APO prefix"),
    ManufacturerPattern(r"^AUR", "Aurobindo Pharma", "AUR prefix"),
    ManufacturerPattern(r"^H\s?\d+", "Aurobindo Pharma", "H followed by numbers"),
    ManufacturerPattern(r"^RDY\s?\d+", "Dr. Reddy's Laboratories", "RDY followed by numbers"),
    ManufacturerPattern(r"^RP\s?\d+", "Rhodes Pharmaceuticals", "RP followed by numbers"),
    ManufacturerPattern(r"^R\s?\d+", "Actavis (generic)", "R followed by numbers"),
    ManufacturerPattern(r"^S\s?\d+", "Sun Pharmaceutical", "S followed by numbers"),
    ManufacturerPattern(r"^U\s?\d+", "Unichem Pharmaceuticals", "U followed by numbers"),
    ManufacturerPattern(r"^MP\s?\d+", "Sun Pharmaceutical (Mutual)", "MP followed by numbers"),
    ManufacturerPattern(r"^V\s?\d+", "Vintage (Qualitest)", "V followed by numbers"),
    ManufacturerPattern(r"^N\s?\d+", "Novopharm/Teva", "N followed by numbers"),
    ManufacturerPattern(r"^K\s?\d+", "KVK-Tech", "K followed by numbers"),
    ManufacturerPattern(r"^C\s?\d+", "Cipla / Aurobindo", "C followed by numbers"),
    ManufacturerPattern(r"^DAN\s?\d+", "Watson/Danbury", "DAN followed by numbers"),
    ManufacturerPattern(r"^PH\s?\d+", "Pharm Assoc (PAI)", "PH followed by numbers"),
    ManufacturerPattern(r"^CTI\s?\d+", "CTI BioPharma", "CTI followed by numbers"),
    # Brand names
    ManufacturerPattern(r"^TYLENOL", "Johnson & Johnson", "TYLENOL brand"),
    ManufacturerPattern(r"^ADVIL", "Pfizer (Haleon)", "ADVIL brand"),
    ManufacturerPattern(r"^MOTRIN", "Johnson & Johnson", "MOTRIN brand"),
    ManufacturerPattern(r"^ALEVE", "Bayer", "ALEVE brand"),
    ManufacturerPattern(r"^BAYER", "Bayer", "BAYER brand"),
    ManufacturerPattern(r"^LIPITOR", "Pfizer", "LIPITOR brand"),
    ManufacturerPattern(r"^VIAGRA", "Pfizer", "VIAGRA brand"),
    ManufacturerPattern(r"^PFE", "Pfizer", "Pfizer logo code"),
    ManufacturerPattern(r"^PFIZER", "Pfizer", "PFIZER text"),
    ManufacturerPattern(r"^XANAX", "Pfizer (Upjohn)", "XANAX brand"),
    ManufacturerPattern(r"^NORCO", "Allergan", "NORCO brand"),
    ManufacturerPattern(r"^OC\s?\d+", "Purdue Pharma", "OC followed by numbers"),
    ManufacturerPattern(r"^LILLY\s?\d+", "Eli Lilly", "LILLY followed by numbers"),
    ManufacturerPattern(r"^ABG\s?\d+", "Allergan", "ABG followed by numbers"),
    ManufacturerPattern(r"^NVR", "Novartis", "NVR prefix"),
]


def identify_manufacturer(imprint: str) -> list[tuple[str, str]]:
    """Identify possible manufacturers from an imprint string.

    Args:
        imprint: The imprint text from a pill.

    Returns:
        List of (manufacturer, description) tuples for matching patterns.
    """
    if not imprint:
        return []

    normalized = imprint.upper().strip()
    matches = []
    for pattern in MANUFACTURER_PATTERNS:
        if re.match(pattern.pattern, normalized):
            matches.append((pattern.manufacturer, pattern.description))
    return matches
