"""Standardized vocabulary for pill colors and shapes."""

from __future__ import annotations

# Canonical color names and common aliases that map to them.
COLOR_ALIASES: dict[str, str] = {
    "white": "white",
    "off-white": "white",
    "cream": "white",
    "ivory": "white",
    "blue": "blue",
    "light blue": "blue",
    "dark blue": "blue",
    "navy": "blue",
    "sky blue": "blue",
    "pink": "pink",
    "light pink": "pink",
    "rose": "pink",
    "red": "red",
    "dark red": "red",
    "maroon": "red",
    "yellow": "yellow",
    "light yellow": "yellow",
    "pale yellow": "yellow",
    "orange": "orange",
    "peach": "orange",
    "green": "green",
    "light green": "green",
    "dark green": "green",
    "olive": "green",
    "purple": "purple",
    "lavender": "purple",
    "violet": "purple",
    "brown": "brown",
    "tan": "brown",
    "beige": "brown",
    "gray": "gray",
    "grey": "gray",
    "black": "black",
    "clear": "clear",
    "transparent": "clear",
}

STANDARD_COLORS: list[str] = [
    "white",
    "blue",
    "pink",
    "red",
    "yellow",
    "orange",
    "green",
    "purple",
    "brown",
    "gray",
    "black",
    "clear",
]

# Canonical shape names and common aliases.
SHAPE_ALIASES: dict[str, str] = {
    "round": "round",
    "circular": "round",
    "circle": "round",
    "oval": "oval",
    "elliptical": "oval",
    "egg": "oval",
    "capsule": "capsule",
    "cap": "capsule",
    "oblong": "oblong",
    "elongated": "oblong",
    "rectangle": "rectangle",
    "rectangular": "rectangle",
    "square": "rectangle",
    "diamond": "diamond",
    "rhombus": "diamond",
    "triangle": "triangle",
    "triangular": "triangle",
    "pentagon": "pentagon",
    "hexagon": "hexagon",
    "octagon": "octagon",
    "heart": "heart",
    "kidney": "kidney",
    "barrel": "barrel",
}

STANDARD_SHAPES: list[str] = [
    "round",
    "oval",
    "capsule",
    "oblong",
    "rectangle",
    "diamond",
    "triangle",
    "pentagon",
    "hexagon",
    "octagon",
    "heart",
    "kidney",
    "barrel",
]


def normalize_color(color: str) -> str:
    """Normalize a color string to its canonical form."""
    return COLOR_ALIASES.get(color.lower().strip(), color.lower().strip())


def normalize_shape(shape: str) -> str:
    """Normalize a shape string to its canonical form."""
    return SHAPE_ALIASES.get(shape.lower().strip(), shape.lower().strip())
