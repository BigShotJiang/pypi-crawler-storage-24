"""Safety warnings and disclaimers for pill identification results."""

from __future__ import annotations

from pill_id.models import PillMatch

DISCLAIMER = (
    "This tool is for informational purposes only. "
    "Always verify medication identity with a pharmacist."
)

LOW_CONFIDENCE_THRESHOLD = 0.7
HIGH_CONFIDENCE_THRESHOLD = 0.85
MULTIPLE_HIGH_CONFIDENCE_THRESHOLD = 0.8


def generate_warnings(matches: list[PillMatch]) -> list[str]:
    """Generate safety warnings based on identification results.

    Args:
        matches: List of pill matches from the identification process.

    Returns:
        List of warning strings.
    """
    warnings: list[str] = []

    if not matches:
        warnings.append(
            "No matches found in the database. This pill could not be identified. "
            "Consult a pharmacist for assistance."
        )
        return warnings

    top = matches[0]

    # Low confidence warning
    if top.confidence < LOW_CONFIDENCE_THRESHOLD:
        warnings.append(
            "Low confidence match \u2014 do NOT rely on this identification. "
            "Please consult a pharmacist to verify this medication."
        )

    # Multiple high-confidence matches (ambiguous)
    high_conf = [m for m in matches if m.confidence >= MULTIPLE_HIGH_CONFIDENCE_THRESHOLD]
    if len(high_conf) > 1:
        names = ", ".join(m.name for m in high_conf[:3])
        warnings.append(
            f"Multiple high-confidence matches found ({names}). "
            "The pill may be difficult to distinguish visually. "
            "Verify with a pharmacist."
        )

    # Controlled substance warning
    controlled_generics = {
        "alprazolam", "diazepam", "lorazepam", "clonazepam",
        "oxycodone", "hydrocodone/acetaminophen", "tramadol",
        "mixed amphetamine salts", "methylphenidate", "zolpidem",
    }
    for m in matches[:3]:
        if m.generic_name.lower() in controlled_generics:
            warnings.append(
                "This may be a controlled substance. "
                "Possession without a valid prescription is illegal. "
                "Contact your pharmacist or healthcare provider."
            )
            break

    # No imprint detected
    if top.match_details.get("imprint", {}).get("type") == "none":
        warnings.append(
            "No imprint match was found. Identification based solely on "
            "color and shape is unreliable. Many different medications share "
            "similar physical characteristics."
        )

    return warnings
