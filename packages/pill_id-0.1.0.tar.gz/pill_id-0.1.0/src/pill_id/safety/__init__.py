"""Safety warnings and disclaimers."""

from pill_id.safety.warnings import generate_warnings, DISCLAIMER

__all__ = ["generate_warnings", "DISCLAIMER"]
