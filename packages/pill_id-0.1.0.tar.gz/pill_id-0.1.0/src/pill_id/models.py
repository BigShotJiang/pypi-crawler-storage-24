"""Data models for pill-id."""

from __future__ import annotations

from pydantic import BaseModel, Field


class ExtractedFeatures(BaseModel):
    """Visual features extracted from a pill image by a vision model."""

    color: str = Field(description="Primary color, e.g. 'white', 'blue', 'pink'")
    shape: str = Field(description="Shape, e.g. 'round', 'oval', 'capsule', 'rectangle'")
    imprint_front: str | None = Field(
        default=None, description="Text or numbers printed on the front"
    )
    imprint_back: str | None = Field(
        default=None, description="Text or numbers printed on the back"
    )
    scoring: str | None = Field(
        default=None, description="Score line type: 'none', 'single', 'cross'"
    )
    coating: str | None = Field(
        default=None,
        description="Coating type: 'film-coated', 'sugar-coated', 'uncoated'",
    )
    size_estimate: str | None = Field(
        default=None, description="Estimated size: 'small', 'medium', 'large'"
    )
    additional_notes: str | None = Field(
        default=None, description="Any other notable visual characteristics"
    )


class PillMatch(BaseModel):
    """A single match result from the pill database."""

    name: str = Field(description="Brand or common drug name")
    generic_name: str = Field(description="Generic/chemical name")
    strength: str = Field(description="Dosage strength, e.g. '500mg'")
    manufacturer: str = Field(description="Manufacturer name")
    ndc: str | None = Field(default=None, description="National Drug Code")
    imprint: str = Field(description="Known imprint text on the pill")
    color: str = Field(description="Known color")
    shape: str = Field(description="Known shape")
    confidence: float = Field(ge=0.0, le=1.0, description="Match confidence 0-1")
    match_details: dict = Field(
        default_factory=dict,
        description="Breakdown of which features matched or mismatched",
    )


class PillResult(BaseModel):
    """Complete identification result."""

    matches: list[PillMatch] = Field(
        default_factory=list, description="Top matches sorted by confidence"
    )
    extracted_features: ExtractedFeatures = Field(
        description="Features extracted from the image"
    )
    warnings: list[str] = Field(
        default_factory=list, description="Safety warnings"
    )
    disclaimer: str = Field(
        default=(
            "This tool is for informational purposes only. "
            "Always verify medication identity with a pharmacist."
        ),
        description="Legal disclaimer, always present",
    )
    processing_time_ms: float = Field(
        default=0.0, description="Total processing time in milliseconds"
    )


class PillDatabaseEntry(BaseModel):
    """A single entry in the embedded pill database."""

    name: str
    generic_name: str
    strength: str
    manufacturer: str
    ndc: str | None = None
    imprint: str
    color: str
    shape: str
    scoring: str = "none"
    coating: str = "uncoated"
