"""Main PillIdentifier class -- the primary public interface."""

from __future__ import annotations

import time
from pathlib import Path

from pill_id.config import PillIDConfig
from pill_id.matching.feature_matcher import FeatureMatcher
from pill_id.models import ExtractedFeatures, PillDatabaseEntry, PillResult
from pill_id.preprocessing.image_utils import prepare_image
from pill_id.providers.base import BaseVisionProvider
from pill_id.safety.warnings import DISCLAIMER, generate_warnings


class PillIdentifier:
    """Identify pills from images using AI vision models and database matching.

    Usage::

        identifier = PillIdentifier(provider="openai", api_key="sk-...")
        result = identifier.identify("pill_photo.jpg")
        print(result.matches[0].name)
    """

    def __init__(
        self,
        provider: str = "openai",
        api_key: str | None = None,
        model: str | None = None,
        top_k: int = 5,
        confidence_threshold: float = 0.3,
        custom_database: list[PillDatabaseEntry] | None = None,
        vision_provider: BaseVisionProvider | None = None,
    ) -> None:
        """Initialize the PillIdentifier.

        Args:
            provider: Vision provider name ('openai' or 'anthropic').
            api_key: API key for the vision provider.
            model: Model name override.
            top_k: Number of top matches to return.
            confidence_threshold: Minimum confidence to include a match.
            custom_database: Optional custom pill database to use instead of built-in.
            vision_provider: Optional pre-configured vision provider instance.
        """
        self.config = PillIDConfig(
            provider=provider,
            api_key=api_key,
            model=model,
            top_k=top_k,
            confidence_threshold=confidence_threshold,
        )

        self.matcher = FeatureMatcher(
            database=custom_database,
            top_k=top_k,
            confidence_threshold=confidence_threshold,
        )

        if vision_provider is not None:
            self._provider = vision_provider
        else:
            self._provider = self._create_provider()

    def _create_provider(self) -> BaseVisionProvider:
        """Create a vision provider based on configuration."""
        if not self.config.api_key:
            raise ValueError(
                f"API key is required for provider '{self.config.provider}'. "
                f"Set it via the api_key parameter or the appropriate "
                f"environment variable."
            )

        if self.config.provider == "openai":
            from pill_id.providers.openai_provider import OpenAIVisionProvider

            return OpenAIVisionProvider(
                api_key=self.config.api_key,
                model=self.config.model or "gpt-4o",
                timeout=self.config.request_timeout,
            )
        elif self.config.provider == "anthropic":
            from pill_id.providers.anthropic_provider import AnthropicVisionProvider

            return AnthropicVisionProvider(
                api_key=self.config.api_key,
                model=self.config.model or "claude-sonnet-4-20250514",
                timeout=self.config.request_timeout,
            )
        else:
            raise ValueError(
                f"Unknown provider '{self.config.provider}'. "
                f"Supported: 'openai', 'anthropic'."
            )

    def identify(self, source: str | bytes | Path) -> PillResult:
        """Identify a pill from an image.

        Args:
            source: Image file path, URL, or raw bytes.

        Returns:
            PillResult with matches, extracted features, and warnings.
        """
        start = time.monotonic()

        # Phase 1: Prepare image and extract features via vision AI
        image_b64, mime_type = prepare_image(source, self.config)
        features = self._provider.extract_features(image_b64, mime_type)

        # Phase 2: Match features against database
        matches = self.matcher.match(features)

        # Generate safety warnings
        warnings = generate_warnings(matches)

        elapsed_ms = (time.monotonic() - start) * 1000

        return PillResult(
            matches=matches,
            extracted_features=features,
            warnings=warnings,
            disclaimer=DISCLAIMER,
            processing_time_ms=round(elapsed_ms, 2),
        )

    def identify_batch(
        self, sources: list[str | bytes | Path]
    ) -> list[PillResult]:
        """Identify pills from multiple images.

        Args:
            sources: List of image file paths, URLs, or raw bytes.

        Returns:
            List of PillResult objects, one per input image.
        """
        return [self.identify(source) for source in sources]

    def identify_from_features(self, features: ExtractedFeatures) -> PillResult:
        """Identify a pill from pre-extracted features (no vision API call).

        Useful for testing or when features are already known.

        Args:
            features: Pre-extracted visual features.

        Returns:
            PillResult with matches and warnings.
        """
        start = time.monotonic()
        matches = self.matcher.match(features)
        warnings = generate_warnings(matches)
        elapsed_ms = (time.monotonic() - start) * 1000

        return PillResult(
            matches=matches,
            extracted_features=features,
            warnings=warnings,
            disclaimer=DISCLAIMER,
            processing_time_ms=round(elapsed_ms, 2),
        )
