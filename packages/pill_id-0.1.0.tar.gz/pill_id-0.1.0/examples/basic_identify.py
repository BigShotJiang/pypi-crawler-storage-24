"""Basic pill identification example."""

from pill_id import PillIdentifier

# Initialize with your API key
identifier = PillIdentifier(
    provider="openai",  # or "anthropic"
    api_key="sk-...",   # or set OPENAI_API_KEY env var
)

# Identify from a file
result = identifier.identify("pill_photo.jpg")

# Print results
print(f"Extracted Features:")
print(f"  Color: {result.extracted_features.color}")
print(f"  Shape: {result.extracted_features.shape}")
print(f"  Imprint: {result.extracted_features.imprint_front}")
print()

for i, match in enumerate(result.matches, 1):
    print(f"Match #{i}: {match.name} ({match.generic_name}) {match.strength}")
    print(f"  Manufacturer: {match.manufacturer}")
    print(f"  Imprint: {match.imprint}")
    print(f"  Confidence: {match.confidence:.0%}")
    print()

# Warnings
for warning in result.warnings:
    print(f"WARNING: {warning}")

print(f"\n{result.disclaimer}")
print(f"Processing time: {result.processing_time_ms:.0f}ms")
