"""Batch pill identification example."""

from pill_id import PillIdentifier

identifier = PillIdentifier(
    provider="openai",
    api_key="sk-...",
)

# Identify multiple pills at once
images = ["pill1.jpg", "pill2.jpg", "pill3.jpg"]
results = identifier.identify_batch(images)

for image, result in zip(images, results):
    print(f"\n--- {image} ---")
    if result.matches:
        top = result.matches[0]
        print(f"  Best match: {top.name} ({top.confidence:.0%})")
    else:
        print("  No matches found")
    for w in result.warnings:
        print(f"  WARNING: {w}")
