"""Example: Using a custom pill database."""

from pill_id import PillIdentifier
from pill_id.models import ExtractedFeatures, PillDatabaseEntry

# Define your own pill database (e.g., for a specific pharmacy or country)
custom_db = [
    PillDatabaseEntry(
        name="Custom Med A",
        generic_name="Customamine",
        strength="50mg",
        manufacturer="Custom Pharma",
        ndc="99999-0001",
        imprint="CP 50",
        color="blue",
        shape="round",
        scoring="single",
        coating="film-coated",
    ),
    PillDatabaseEntry(
        name="Custom Med B",
        generic_name="Betacustom",
        strength="100mg",
        manufacturer="Custom Pharma",
        ndc="99999-0002",
        imprint="CP 100",
        color="white",
        shape="oval",
        scoring="none",
        coating="uncoated",
    ),
]

# Use with the identifier
identifier = PillIdentifier(
    provider="openai",
    api_key="sk-...",
    custom_database=custom_db,
)

# Or use identify_from_features to skip the vision API call
features = ExtractedFeatures(
    color="blue",
    shape="round",
    imprint_front="CP 50",
    scoring="single",
    coating="film-coated",
)

result = identifier.identify_from_features(features)
print(f"Top match: {result.matches[0].name} ({result.matches[0].confidence:.0%})")
