#!/usr/bin/env python3
"""
快速检查服务器状态
"""
import requests

def check_server_status():
    """检查服务器各个端点状态"""
    
    server_url = "https://file-upload-server.ai4s.com.cn"
    
    print("🔍 服务器状态检查")
    print("=" * 50)
    
    endpoints = [
        ("/health", "健康检查"),
        ("/docs", "API文档"),
        ("/api/token/generate", "Token生成"),
    ]
    
    for endpoint, name in endpoints:
        try:
            print(f"\n📍 检查 {name}: {endpoint}")
            
            if endpoint == "/api/token/generate":
                # POST请求测试
                response = requests.post(
                    f"{server_url}{endpoint}",
                    json={
                        "user_id": "test123",
                        "user_name": "Test User",
                        "role": "user"
                    },
                    timeout=10
                )
            else:
                # GET请求测试
                response = requests.get(f"{server_url}{endpoint}", timeout=10)
            
            print(f"   状态码: {response.status_code}")
            
            if response.status_code == 200:
                print("   ✅ 正常")
            elif response.status_code == 503:
                print("   ❌ 服务不可用 (503)")
                print("   可能原因:")
                print("   - 服务启动失败")
                print("   - 数据库连接失败") 
                print("   - 代码错误")
            else:
                print(f"   ⚠️  异常状态: {response.status_code}")
                
            # 显示错误详情
            if response.status_code >= 400:
                try:
                    error_detail = response.json()
                    print(f"   错误详情: {error_detail}")
                except:
                    print(f"   错误文本: {response.text[:200]}")
                    
        except requests.exceptions.ConnectionError:
            print("   ❌ 连接失败 - 服务器可能未运行")
        except requests.exceptions.Timeout:
            print("   ❌ 请求超时")
        except Exception as e:
            print(f"   ❌ 检查失败: {e}")
    
    print("\n" + "=" * 50)
    print("💡 建议:")
    print("1. 如果全部503，检查服务器部署状态")
    print("2. 如果健康检查失败，检查服务是否启动")
    print("3. 如果Token接口503，检查数据库连接")

if __name__ == "__main__":
    check_server_status()
