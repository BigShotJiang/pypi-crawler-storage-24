# 更新日志

## [3.1.0] - 2026-03-24

### 💥 重大变更 (Breaking Changes)
- **存储后端切换**: 文件上传目标从 CPFS 切换到 OSS (inspire-alluxio-prod)
- **文件路径格式变更**: 文件路径从本地 CPFS 路径变为 `oss://inspire-alluxio-prod/{dataset_id}/{filename}`

### 🔧 变更
- OSS 模式不再需要服务器端 OSS→CPFS 传输，SDK 上传到 OSS 后直接完成
- 分片直传模式：服务端合并分片后自动上传到 OSS
- 移除 CPFS 相关路径配置和文件操作逻辑

### 🔄 兼容性
- ✅ SDK API 接口保持兼容，用户代码无需修改
- ✅ Token 认证机制保持兼容
- ❌ 文件存储路径格式发生变化（从本地路径变为 OSS 路径）

## [2.0.0] - 2025-09-16

### 💥 重大变更 (Breaking Changes)
- **API参数变更**: `dataset_name` → `dataset_id`
- **路径变更**: 文件存储路径现在使用 `dataset_id` 而不是 `dataset_name`

### 🔧 API变更
#### 之前 (v1.x)
```python
upload_file("file.txt", dataset_name="my_dataset")
```

#### 现在 (v2.0)
```python
upload_file("file.txt", dataset_id="dataset_123")
```

### ⚠️ 升级说明
- 所有调用 `upload_file()` 的代码需要将 `dataset_name` 参数改为 `dataset_id`
- 服务器端存储路径结构保持不变，只是参数名称变更
- Token认证系统保持兼容

### 🔄 兼容性
- ❌ **不兼容** v1.x API参数
- ✅ **兼容** Token认证机制
- ✅ **兼容** 文件上传协议

## [1.2.0] - 2025-09-16

### 🆕 新增功能
- **Token认证支持**: 新增基于Token的认证方式，支持永不过期的访问令牌
- **自动Token申请**: SDK可根据`user_id`和`user_name`自动申请Token
- **双重认证兼容**: 同时支持Token认证和旧版API Key认证，向后兼容

### 🔧 API变更
- `FileUploadSDK.__init__()`新增参数:
  - `access_token: Optional[str]` - 访问令牌
  - `user_name: Optional[str]` - 用户名（用于自动申请Token）
- `init_sdk()`新增参数:
  - `access_token: Optional[str]` - 访问令牌
  - `user_name: Optional[str]` - 用户名

### 📖 使用示例

#### Token认证方式（推荐）
```python
from file_upload_sdk import init_sdk, upload_file

# 方式1: 直接使用已有Token
init_sdk(
    base_url="https://your-server.com",
    access_token="hf_your_token_here"
)

# 方式2: 自动申请Token（推荐）
init_sdk(
    base_url="https://your-server.com",
    user_id=12345,
    user_name="Your Name"
)

# 上传文件
upload_file("large_file.zip", "my_dataset")
```

#### API Key认证方式（兼容旧版）
```python
# 继续支持旧版API Key方式
init_sdk(
    base_url="https://your-server.com",
    user_id=12345  # 自动申请API Key
)
```

### 🔄 兼容性
- ✅ 完全向后兼容，现有代码无需修改
- ✅ 优先使用Token认证，提升安全性
- ✅ 自动降级到API Key认证（如果未提供Token）

## [1.1.1] - 2025-09-15

### 🐛 修复
- 修复API Key格式问题，避免下划线冲突
- 修复日期序列化问题

### 🔧 改进
- 优化错误处理和提示信息
- 改进连接重试机制

## [1.1.0] - 2025-09-14

### 🆕 新增功能
- API Key认证支持
- 自动用户创建
- 每日上传限制

### 🔧 改进
- 更好的错误处理
- 改进的进度显示

## [1.0.0] - 2025-09-13

### 🎉 首次发布
- 大文件分块上传
- 断点续传支持
- MD5校验
- 进度回调
- 自动重试机制
