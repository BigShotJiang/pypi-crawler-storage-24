# 部署指南

## 🚀 生产环境部署

### 方式1: 使用docker-compose (推荐)

#### Staging环境
```bash
# 停止旧容器
docker-compose down

# 启动staging环境
docker-compose -f docker-compose.staging.yml up -d --build

# 初始化数据库（首次部署）
docker-compose -f docker-compose.staging.yml exec file-upload-server python init_db.py
```

#### Production环境
```bash
# 停止旧容器
docker-compose down

# 启动production环境
docker-compose -f docker-compose.prod.yml up -d --build

# 初始化数据库（首次部署）
docker-compose -f docker-compose.prod.yml exec file-upload-server python init_db.py
```

### 方式2: 直接使用docker run

#### Production环境
```bash
# 构建镜像
docker build -t file-upload-server:latest .

# 停止旧容器
docker stop file-upload-server || true
docker rm file-upload-server || true

# 启动新容器
docker run -d \
  --name file-upload-server \
  -p 8000:8000 \
  -e MYSQL_HOST=rm-0jl47t29i47644wic.mysql.rds.aliyuncs.com \
  -e MYSQL_PORT=3306 \
  -e MYSQL_USER=Sais_fileupload \
  -e MYSQL_PASSWORD=hK4hR7vJ2cC1 \
  -e MYSQL_DATABASE=file_upload_production \
  -v /cpfs-nfs/sais/data-plaza-svc/datasets:/cpfs-nfs/sais/data-plaza-svc/datasets \
  -v /cpfs-nfs/sais/data-plaza-svc/temp:/cpfs-nfs/sais/data-plaza-svc/temp \
  --restart unless-stopped \
  file-upload-server:latest

# 初始化数据库（首次部署）
docker exec -it file-upload-server python init_db.py
```

#### Staging环境
```bash
# 构建镜像
docker build -t file-upload-server:staging .

# 停止旧容器
docker stop file-upload-server-staging || true
docker rm file-upload-server-staging || true

# 启动新容器
docker run -d \
  --name file-upload-server-staging \
  -p 8001:8000 \
  -e MYSQL_HOST=rm-0jl16a029o4kz05z3.mysql.rds.aliyuncs.com \
  -e MYSQL_PORT=3306 \
  -e MYSQL_USER=Sais_fileupload \
  -e MYSQL_PASSWORD=lJ0gA4dH8nK2 \
  -e MYSQL_DATABASE=file_upload_staging \
  -v /cpfs-nfs/sais/data-plaza-svc/datasets:/cpfs-nfs/sais/data-plaza-svc/datasets \
  -v /cpfs-nfs/sais/data-plaza-svc/temp:/cpfs-nfs/sais/data-plaza-svc/temp \
  --restart unless-stopped \
  file-upload-server:staging

# 初始化数据库（首次部署）
docker exec -it file-upload-server-staging python init_db.py
```

## 🔍 验证部署

### 检查服务状态
```bash
# 查看容器日志
docker logs file-upload-server

# 检查健康状态
curl http://localhost:8000/health

# 测试Token生成
curl -X POST "http://localhost:8000/api/token/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "test123",
    "user_name": "Test User", 
    "role": "user"
  }'
```

## 📋 数据库配置说明

### MySQL连接信息

**Staging环境:**
- 主机: rm-0jl16a029o4kz05z3.mysql.rds.aliyuncs.com
- 端口: 3306
- 用户: Sais_fileupload
- 密码: lJ0gA4dH8nK2

**Production环境:**
- 主机: rm-0jl47t29i47644wic.mysql.rds.aliyuncs.com  
- 端口: 3306
- 用户: Sais_fileupload
- 密码: hK4hR7vJ2cC1

### 数据库表结构
系统会自动创建所需的表结构，包括:
- `tokens` - Token认证信息

## 🔧 故障排除

### 常见问题

1. **MySQL连接失败**
   - 检查网络连接
   - 确认数据库账号密码
   - 检查防火墙设置

2. **服务启动失败**
   - 查看容器日志: `docker logs file-upload-server`
   - 检查端口占用: `netstat -tlnp | grep 8000`

3. **Token生成失败**
   - 确认数据库连接正常
   - 运行数据库初始化: `python init_db.py`
