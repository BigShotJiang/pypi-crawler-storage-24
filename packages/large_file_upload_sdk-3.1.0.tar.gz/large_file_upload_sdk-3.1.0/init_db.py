#!/usr/bin/env python3
"""
数据库初始化脚本
"""
from database import init_database, DATABASE_URL, TokenRecord, FileUploadRecord
from sqlalchemy import text
import os


def create_database_if_not_exists():
    """创建数据库（如果不存在）"""
    from sqlalchemy import create_engine
    
    # 解析数据库URL以获取数据库名
    db_name = os.getenv("MYSQL_DATABASE", "file_upload_db")
    host = os.getenv("MYSQL_HOST", "localhost")
    port = os.getenv("MYSQL_PORT", "3306")
    user = os.getenv("MYSQL_USER", "root")
    password = os.getenv("MYSQL_PASSWORD", "")
    
    # 连接到MySQL服务器（不指定数据库）
    server_url = f"mysql+pymysql://{user}:{password}@{host}:{port}/"
    
    try:
        engine = create_engine(server_url)
        with engine.connect() as conn:
            # 创建数据库（如果不存在）
            conn.execute(text(f"CREATE DATABASE IF NOT EXISTS {db_name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"))
            print(f"✅ 数据库 {db_name} 准备完成")
            
    except Exception as e:
        print(f"❌ 创建数据库失败: {e}")
        raise


def show_table_info():
    """显示表结构信息"""
    print("\n📋 数据库表结构:")
    print("-" * 50)
    
    # Token表
    print(f"\n1. {TokenRecord.__tablename__} (Token管理表)")
    print("   字段:")
    for column in TokenRecord.__table__.columns:
        print(f"   - {column.name}: {column.type} {'(主键)' if column.primary_key else ''}")
    
    # 文件上传记录表
    print(f"\n2. {FileUploadRecord.__tablename__} (文件上传记录表)")
    print("   字段:")
    for column in FileUploadRecord.__table__.columns:
        print(f"   - {column.name}: {column.type} {'(主键)' if column.primary_key else ''}")


def main():
    """主函数"""
    print("🚀 初始化文件上传服务数据库")
    print("=" * 50)
    
    print(f"数据库连接: {DATABASE_URL}")
    
    try:
        # 1. 创建数据库
        create_database_if_not_exists()
        
        # 2. 初始化表结构
        init_database()
        
        # 3. 显示表信息
        show_table_info()
        
        print("\n🎉 数据库初始化完成！")
        print("\n✨ Token特性:")
        print("- 永不过期，一次生成永久有效")
        print("- 简化的权限管理")
        print("- 所有用户可访问所有数据集")
        print("\n📝 下一步:")
        print("1. 确保MySQL服务正在运行")
        print("2. 配置正确的数据库连接参数(.env文件)")
        print("3. 启动文件上传服务: python main.py")
        
    except Exception as e:
        print(f"\n❌ 初始化失败: {e}")
        exit(1)


if __name__ == "__main__":
    main()
