"""
OSS 上传配置
"""
import os


class OSSConfig:
    """阿里云 OSS 配置"""

    endpoint: str = os.getenv("OSS_ENDPOINT", "https://oss-cn-wulanchabu.aliyuncs.com")
    bucket_name: str = os.getenv("OSS_BUCKET", "inspire-alluxio-prod")
    access_key_id: str = os.getenv("OSS_ACCESS_KEY_ID", "")
    access_key_secret: str = os.getenv("OSS_ACCESS_KEY_SECRET", "")

    # OSS 路径前缀（为空，因为直接用 {dataset_id}/ 作为路径）
    upload_prefix: str = os.getenv("OSS_UPLOAD_PREFIX", "")


oss_config = OSSConfig()
