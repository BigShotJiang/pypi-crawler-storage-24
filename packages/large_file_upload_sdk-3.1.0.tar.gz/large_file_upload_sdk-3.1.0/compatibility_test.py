#!/usr/bin/env python3
"""
新旧版本兼容性测试
"""
import os
import tempfile
from file_upload_sdk import init_sdk, upload_file

def test_backward_compatibility():
    """测试向后兼容性"""
    
    print("🔄 新旧版本兼容性测试")
    print("=" * 50)
    
    server_url = "https://file-upload-server.ai4s.com.cn"
    
    # 测试1: 旧版API Key方式 (兼容性)
    print("\n1️⃣ 测试旧版API Key方式")
    try:
        init_sdk(
            base_url=server_url,
            user_id=888  # 只提供user_id，应该自动申请API Key
        )
        print("✅ 旧版API Key兼容性正常")
        
        # 创建小测试文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("API Key compatibility test\n")
            test_file = f.name
        
        result = upload_file(
            file_path=test_file,
            dataset_id="api_key_compat_test"
        )
        
        if result.get('success'):
            print("✅ API Key方式文件上传成功")
        else:
            print(f"❌ API Key方式上传失败: {result.get('error')}")
            
        os.unlink(test_file)
        
    except Exception as e:
        print(f"❌ 旧版API Key测试失败: {e}")
    
    # 测试2: 新版Token方式 (主要功能)
    print("\n2️⃣ 测试新版Token方式")
    try:
        init_sdk(
            base_url=server_url,
            user_id=777,
            user_name="Compatibility Test User"
        )
        print("✅ 新版Token方式正常")
        
        # 创建测试文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("Token compatibility test\n")
            test_file = f.name
        
        result = upload_file(
            file_path=test_file,
            dataset_id="token_compat_test"
        )
        
        if result.get('success'):
            print("✅ Token方式文件上传成功")
        else:
            print(f"❌ Token方式上传失败: {result.get('error')}")
            
        os.unlink(test_file)
        
    except Exception as e:
        print(f"❌ 新版Token测试失败: {e}")
    
    # 测试3: 直接Token方式
    print("\n3️⃣ 测试直接Token方式")
    if os.getenv("ACCESS_TOKEN"):
        try:
            init_sdk(
                base_url=server_url,
                access_token=os.getenv("ACCESS_TOKEN")
            )
            print("✅ 直接Token方式正常")
        except Exception as e:
            print(f"❌ 直接Token测试失败: {e}")
    else:
        print("ℹ️  跳过 (未设置ACCESS_TOKEN)")


def test_edge_cases():
    """测试边缘情况"""
    
    print("\n\n🧪 边缘情况测试")
    print("=" * 50)
    
    server_url = "https://file-upload-server.ai4s.com.cn"
    
    # 测试1: 空文件上传
    print("\n1️⃣ 测试空文件上传")
    try:
        init_sdk(
            base_url=server_url,
            user_id=666,
            user_name="Edge Case Test"
        )
        
        # 创建空文件
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as f:
            empty_file = f.name
        
        result = upload_file(
            file_path=empty_file,
            dataset_id="empty_file_test"
        )
        
        if result.get('success'):
            print("✅ 空文件上传成功")
        else:
            print(f"⚠️  空文件上传失败: {result.get('error')}")
            
        os.unlink(empty_file)
        
    except Exception as e:
        print(f"❌ 空文件测试失败: {e}")
    
    # 测试2: 长文件名
    print("\n2️⃣ 测试长文件名")
    try:
        long_name = "a" * 100 + ".txt"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("Long filename test\n")
            test_file = f.name
        
        result = upload_file(
            file_path=test_file,
            dataset_id="long_name_test",
            file_name=long_name
        )
        
        if result.get('success'):
            print("✅ 长文件名处理正常")
        else:
            print(f"⚠️  长文件名处理异常: {result.get('error')}")
            
        os.unlink(test_file)
        
    except Exception as e:
        print(f"❌ 长文件名测试失败: {e}")
    
    # 测试3: 特殊字符数据集名
    print("\n3️⃣ 测试特殊字符数据集名")
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("Special chars test\n")
            test_file = f.name
        
        result = upload_file(
            file_path=test_file,
            dataset_id="test-dataset_with.special@chars"
        )
        
        if result.get('success'):
            print("✅ 特殊字符数据集名处理正常")
        else:
            print(f"⚠️  特殊字符处理异常: {result.get('error')}")
            
        os.unlink(test_file)
        
    except Exception as e:
        print(f"❌ 特殊字符测试失败: {e}")


if __name__ == "__main__":
    print("🔄 Large File Upload SDK - 兼容性测试")
    print("📅 测试时间:", "2025-09-16")
    
    test_backward_compatibility()
    test_edge_cases()
    
    print("\n" + "=" * 50)
    print("🎯 兼容性测试完成！")
    print("\n📊 测试覆盖:")
    print("✅ 新旧版本兼容性")
    print("✅ 不同认证方式")  
    print("✅ 边缘情况处理")
    print("✅ 特殊场景测试")
