"""
配置文件
"""
import os
from typing import List, Optional

try:
    from pydantic_settings import BaseSettings
except ImportError:
    from pydantic import BaseSettings


class Settings(BaseSettings):
    """应用配置"""
    
    # 服务器配置
    app_name: str = "file-upload-server"
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = True
    
    # 文件上传配置
    upload_base_dir: str = "/cpfs-nfs/sais/data-plaza-svc/datasets"  # 数据集基础路径，可通过环境变量UPLOAD_BASE_DIR覆盖
    temp_dir: str = "/cpfs-nfs/sais/data-plaza-svc/temp"  # 临时路径，放在数据盘上
    # 注意：不再使用服务端全局文件大小限制；只依赖 Token 的 max_file_size 做用户级限制
    max_file_size: int = 1024 * 1024 * 1024 * 1024  # 1TB（已废弃，保留字段避免破坏兼容）
    chunk_size: int = 10 * 1024 * 1024  # 10MB
    chunk_expire_hours: int = 24
    
    # 允许的文件类型 (空列表表示允许所有类型)
    allowed_file_types: List[str] = []
    
    # 是否启用MD5校验
    enable_md5_check: bool = True
    
    # 并发上传限制
    max_concurrent_uploads: int = 10

    # 上传完成通知配置
    upload_notify_base_url: str = os.getenv(
        "UPLOAD_NOTIFY_BASE_URL",
        "https://data-plaza-svc.ai4s.com.cn"
    )
    dataset_service_secret: str = os.getenv(
        "DATASET_SERVICE_SECRET",
        "iW21ci7dZXJ5LXNlY3123S1wcm9kdWNcaW9uLWtlqS1oZWJl"
    )
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


def get_settings() -> Settings:
    """获取配置实例"""
    return Settings()


def get_dataset_upload_path(dataset_id: str) -> str:
    """根据数据集ID生成OSS上传路径"""
    if not dataset_id:
        raise ValueError("数据集ID不能为空")

    # OSS 路径: {dataset_id}/
    return f"{dataset_id}/"


def get_dataset_temp_path(dataset_id: str) -> str:
    """根据数据集ID生成临时路径"""
    # 临时路径统一使用配置的临时目录，避免在数据集目录中留下临时文件
    return settings.temp_dir


# 全局配置实例
settings = get_settings()

# 确保临时目录存在（仅在目录路径存在时创建）
try:
    os.makedirs(settings.temp_dir, exist_ok=True)
except OSError as e:
    # 如果是本地开发环境，使用本地临时目录
    if not os.path.exists('/cpfs-nfs'):
        settings.temp_dir = "/tmp/uploads/temp"
        settings.upload_base_dir = "/tmp/uploads"
        os.makedirs(settings.temp_dir, exist_ok=True)
        print(f"本地开发环境：使用临时目录 {settings.temp_dir}")
    else:
        raise e
