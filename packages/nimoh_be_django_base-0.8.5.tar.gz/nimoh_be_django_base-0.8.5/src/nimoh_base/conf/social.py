"""
nimoh_base.conf.social
=======================
Helpers for wiring ``social-auth-app-django`` into a consumer project.

Install the `[social]` extra::

    pip install "nimoh-be-django-base[social]"

Then in your project settings::

    from nimoh_base.conf.social import get_social_installed_apps, get_social_auth_pipeline

    NIMOH_BASE["SOCIAL_AUTH_ENABLED"] = True

    INSTALLED_APPS += get_social_installed_apps()

    AUTHENTICATION_BACKENDS = [
        "social_core.backends.google.GoogleOAuth2",
        "social_core.backends.github.GithubOAuth2",
        "django.contrib.auth.backends.ModelBackend",
    ]

    SOCIAL_AUTH_PIPELINE = get_social_auth_pipeline()

    # Provider credentials (keep in .env)
    SOCIAL_AUTH_GOOGLE_OAUTH2_KEY = env("SOCIAL_AUTH_GOOGLE_OAUTH2_KEY", default="")
    SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET = env("SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET", default="")
    SOCIAL_AUTH_GITHUB_KEY = env("SOCIAL_AUTH_GITHUB_KEY", default="")
    SOCIAL_AUTH_GITHUB_SECRET = env("SOCIAL_AUTH_GITHUB_SECRET", default="")

Then include the social URLs::

    from django.urls import include, path

    urlpatterns = [
        ...
        path("auth/social/", include("nimoh_base.auth.url_modules.social")),
    ]
"""

from __future__ import annotations

import logging as _logging

_logger = _logging.getLogger(__name__)


def get_social_installed_apps() -> list[str]:
    """Return the ``INSTALLED_APPS`` entries required by ``social-auth-app-django``.

    Merging these into your project settings is sufficient to activate the
    social auth database tables without touching ``INSTALLED_APPS`` manually::

        INSTALLED_APPS = get_base_apps() + get_social_installed_apps() + [...]
    """
    return [
        "social_django",
    ]


def get_social_auth_pipeline() -> tuple[str, ...]:
    """Return a sensible default social-auth pipeline.

    The pipeline marks accounts created via social login with
    ``is_social_account = True`` and stores the provider slug.

    Override specific steps by building your own tuple from these defaults::

        SOCIAL_AUTH_PIPELINE = get_social_auth_pipeline() + (
            "myapp.social.my_custom_step",
        )
    """
    return (
        "social_core.pipeline.social_auth.social_details",
        "social_core.pipeline.social_auth.social_uid",
        "social_core.pipeline.social_auth.auth_allowed",
        "social_core.pipeline.social_auth.social_user",
        "social_core.pipeline.user.get_username",
        # Attempt to link to an existing user by email before creating a new one.
        # Prevents AuthAlreadyAssociated / UniqueViolation when a user who registered
        # with email+password later signs in with a social provider (e.g. Google).
        "social_core.pipeline.social_auth.associate_by_email",
        "social_core.pipeline.user.create_user",
        "social_core.pipeline.social_auth.associate_user",
        "social_core.pipeline.social_auth.load_extra_data",
        # nimoh-base step: stamp is_social_account + social_provider on the user
        "nimoh_base.conf.social._pipeline_mark_social_account",
        "social_core.pipeline.user.user_details",
        "nimoh_base.conf.social.social_generate_exchange_token",
    )


def _pipeline_mark_social_account(backend, user, response, *args, **kwargs):
    """Social-auth pipeline step: set ``is_social_account`` and ``social_provider``.

    This step is inserted by :func:`get_social_auth_pipeline`.
    """
    if user is None:
        return

    changed = False
    if not user.is_social_account:
        user.is_social_account = True
        changed = True

    provider = getattr(backend, "name", "")
    if provider and user.social_provider != provider:
        user.social_provider = provider
        changed = True

    if changed:
        update_fields = ["is_social_account", "social_provider"]
        user.save(update_fields=update_fields)


def get_social_context_processors() -> list[str]:
    """Return the ``TEMPLATES`` context processors needed by ``social_django``.

    Add to your ``TEMPLATES[0]["OPTIONS"]["context_processors"]`` list::

        context_processors = (
            ...
            *get_social_context_processors(),
        )
    """
    return [
        "social_django.context_processors.backends",
        "social_django.context_processors.login_redirect",
    ]


# Session key used to pass the exchange token from the pipeline to the done view.
# Shared between social_generate_exchange_token() and social_login_done_view().
SOCIAL_EXCHANGE_TOKEN_SESSION_KEY = "_nimoh_social_exchange_token"


def social_generate_exchange_token(strategy, user, backend, *args, **kwargs):
    """
    PSA pipeline step: generate a one-time ExchangeToken and store it in the
    PSA session so that ``social_login_done_view`` can issue JWT cookies.

    Why store in the session instead of relying on ``request.user``?
    PSA's ``_do_login`` calls ``backend.strategy.authenticate()`` which
    re-runs Django's ``authenticate()`` chain. In the ``associate_by_email``
    flow the user was fetched directly from the DB and has no
    ``_auth_user_backend`` attribute, so ``auth.login()`` fails silently —
    ``request.user`` is never set on the done view. PSA's own session storage
    is guaranteed to persist across the /complete/ → /done/ redirect pair.
    """
    if not user or not user.pk:
        return

    from nimoh_base.auth.services import ExchangeTokenService

    try:
        token = ExchangeTokenService.generate_exchange_token(
            user=user,
            context={
                "source": "social_auth",
                "provider": getattr(backend, "name", "unknown"),
            },
        )
        strategy.session_set(SOCIAL_EXCHANGE_TOKEN_SESSION_KEY, str(token))
        _logger.info(
            "Social exchange token stored in session for user %s (%s)",
            user.email,
            getattr(backend, "name", "?"),
        )
    except Exception:
        _logger.exception("Failed to generate social exchange token for user %s", user.pk)
