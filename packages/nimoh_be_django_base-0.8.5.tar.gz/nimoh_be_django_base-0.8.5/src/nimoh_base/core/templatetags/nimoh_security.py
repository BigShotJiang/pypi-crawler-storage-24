"""
nimoh_security — Django template tags for security helpers.

Usage in templates::

    {% load nimoh_security %}

    <!-- Inline script allowed by CSP -->
    <script nonce="{% csp_nonce %}">
        console.log("Hello");
    </script>

    <!-- Inline style allowed by CSP -->
    <style nonce="{% csp_nonce %}">
        body { margin: 0; }
    </style>

    <!-- Store as a variable for multiple uses -->
    {% csp_nonce as nonce %}
    <script nonce="{{ nonce }}">...</script>
    <style nonce="{{ nonce }}">...</style>
"""

from django import template

register = template.Library()


@register.simple_tag(takes_context=True)
def csp_nonce(context):
    """
    Return the per-request CSP nonce set by ``SecurityHeadersMiddleware``.

    The nonce is a 128-bit URL-safe random value (``secrets.token_urlsafe(16)``)
    regenerated for every request and stored on ``request.csp_nonce``.  It is
    already embedded in the ``Content-Security-Policy`` response header's
    ``script-src`` and ``style-src`` directives, so any ``<script>`` or
    ``<style>`` element that carries a matching ``nonce`` attribute will be
    permitted by the browser's CSP enforcement.

    Example::

        {% load nimoh_security %}

        <script nonce="{% csp_nonce %}">
            // This inline script is explicitly allowed by CSP.
        </script>

    Returns an empty string when called outside a request context (e.g. in
    management-command email rendering) so templates never raise exceptions.
    """
    request = context.get("request")
    if request is None:
        return ""
    return getattr(request, "csp_nonce", "")
