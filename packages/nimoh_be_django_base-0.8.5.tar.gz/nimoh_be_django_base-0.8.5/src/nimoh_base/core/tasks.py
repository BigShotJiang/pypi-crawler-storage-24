"""Core tasks."""

from celery import shared_task
from celery.utils.log import get_task_logger
from django.conf import settings
from django.core.mail import send_mail

logger = get_task_logger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=300)
def send_email_task(
    self,
    subject,
    message,
    recipient_list,
    from_email=None,
    html_message=None,
    html_template=None,
    template_context=None,
    **kwargs,
):
    """
    Send email asynchronously, with optional HTML content.

    This task retries up to 3 times with 5-minute delays on failure.

    Args:
        subject:          Email subject line.
        message:          Plain-text body (always required; used as the
                          ``text/plain`` fallback when HTML is also provided).
        recipient_list:   List of recipient email addresses.
        from_email:       Sender address (defaults to ``DEFAULT_FROM_EMAIL``).
        html_message:     Optional pre-rendered HTML body.  When provided,
                          Django sends a multipart ``text/plain`` +
                          ``text/html`` message automatically.
        html_template:    Template path relative to ``TEMPLATES`` dirs, e.g.
                          ``'emails/auth/welcome.html'``.  When supplied the
                          template is rendered with ``template_context`` and
                          the result is used as ``html_message``.  Ignored
                          when ``html_message`` is already set.
        template_context: Dict passed to ``render_to_string()`` when
                          ``html_template`` is given.
        **kwargs:         Extra keyword arguments forwarded to
                          ``django.core.mail.send_mail()``.

    Returns:
        dict: Status and details of the email send operation.
    """
    try:
        from_email = from_email or settings.DEFAULT_FROM_EMAIL

        # Render HTML from template when no pre-rendered body was supplied.
        if html_message is None and html_template:
            from django.template.loader import render_to_string

            html_message = render_to_string(html_template, template_context or {})

        logger.info(
            f"Sending email to {len(recipient_list)} recipients: {subject}",
            extra={
                "recipients": recipient_list,
                "subject": subject,
                "has_html": html_message is not None,
            },
        )

        sent_count = send_mail(
            subject=subject,
            message=message,
            from_email=from_email,
            recipient_list=recipient_list,
            fail_silently=False,
            html_message=html_message,
            **kwargs,
        )

        logger.info(
            f"Email sent successfully to {sent_count} recipients", extra={"subject": subject, "sent_count": sent_count}
        )

        return {
            "status": "success",
            "sent_count": sent_count,
            "recipients": recipient_list,
            "subject": subject,
        }

    except Exception as exc:
        logger.error(
            f"Email send failed: {exc}", extra={"subject": subject, "recipients": recipient_list}, exc_info=True
        )

        # Retry with exponential backoff
        raise self.retry(exc=exc, countdown=300 * (self.request.retries + 1))


@shared_task(bind=True, max_retries=2)
def cleanup_task(self):
    """
    General cleanup task that can be scheduled.

    This task is routed to the 'maintenance' queue with low priority.
    Useful for periodic cleanup operations.

    Returns:
        dict: Cleanup status and details
    """
    try:
        logger.info("Starting cleanup task")

        # Add your cleanup logic here
        # Examples:
        # - Clean up temporary files
        # - Remove old cache entries
        # - Archive old data

        result = {
            "status": "success",
            "message": "Cleanup completed successfully",
        }

        logger.info("Cleanup task completed")
        return result

    except Exception as exc:
        logger.error(f"Cleanup task failed: {exc}", exc_info=True)
        raise self.retry(exc=exc, countdown=600)


@shared_task(bind=True, max_retries=3)
def monitoring_task(self, metric_name, metric_value):
    """
    Task for sending monitoring metrics.

    This task is routed to the 'monitoring' queue.
    Rate-limited to 20 per minute.

    Args:
        metric_name: Name of the metric
        metric_value: Value to record

    Returns:
        dict: Metric recording status
    """
    try:
        logger.info(
            f"Recording metric: {metric_name} = {metric_value}",
            extra={"metric_name": metric_name, "metric_value": metric_value},
        )

        # Add your monitoring logic here
        # Examples:
        # - Send to StatsD
        # - Send to Prometheus
        # - Send to CloudWatch

        return {
            "status": "success",
            "metric_name": metric_name,
            "metric_value": metric_value,
        }

    except Exception as exc:
        logger.error(f"Monitoring task failed: {exc}", extra={"metric_name": metric_name}, exc_info=True)
        raise self.retry(exc=exc, countdown=60)
