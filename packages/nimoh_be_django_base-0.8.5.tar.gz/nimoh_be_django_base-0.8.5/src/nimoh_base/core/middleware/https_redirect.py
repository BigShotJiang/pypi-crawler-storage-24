"""
HTTPS Redirect Middleware.

Redirects plain-HTTP requests to HTTPS in production (``DEBUG=False``).
Controlled by ``NIMOH_BASE["FORCE_HTTPS"]`` (default ``True``).
"""

from django.conf import settings
from django.http import HttpResponsePermanentRedirect


class HTTPSRedirectMiddleware:
    """
    Permanent (301) HTTP → HTTPS redirect middleware.

    Active only when BOTH conditions are met:

    - ``DEBUG = False``
    - ``NIMOH_BASE["FORCE_HTTPS"] = True`` (default)

    Position it as the **first** entry in ``MIDDLEWARE`` so the redirect occurs
    before any session, auth, or CSRF middleware processes the unsecured
    request.  Has no effect in local development (``DEBUG=True``) regardless of
    the ``FORCE_HTTPS`` value.

    Disable when HTTPS termination is handled upstream::

        NIMOH_BASE = {
            ...
            "FORCE_HTTPS": False,  # Nginx / load-balancer handles TLS
        }
    """

    def __init__(self, get_response):
        self.get_response = get_response
        # Evaluated once at startup — avoids per-request setting look-ups.
        from nimoh_base.conf import nimoh_setting

        self._active = not settings.DEBUG and nimoh_setting("FORCE_HTTPS", True)

    def __call__(self, request):
        if self._active and not request.is_secure():
            host = request.get_host()
            secure_url = f"https://{host}{request.get_full_path()}"
            return HttpResponsePermanentRedirect(secure_url)
        return self.get_response(request)
