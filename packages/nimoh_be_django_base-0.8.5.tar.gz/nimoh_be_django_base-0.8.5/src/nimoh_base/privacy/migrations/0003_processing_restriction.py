"""
Add processing_restricted and processing_restricted_at to PrivacyProfile.

Implements GDPR Article 18 — Right to Restriction of Processing.
"""

from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("nimoh_privacy", "0002_remove_recovery_info_visibility"),
    ]

    operations = [
        migrations.AddField(
            model_name="privacyprofile",
            name="processing_restricted",
            field=models.BooleanField(
                default=False,
                help_text="Data processing is currently restricted (GDPR Article 18)",
            ),
        ),
        migrations.AddField(
            model_name="privacyprofile",
            name="processing_restricted_at",
            field=models.DateTimeField(
                blank=True,
                null=True,
                help_text="When processing restriction was applied",
            ),
        ),
    ]
