"""
Remove domain-specific fields from PrivacyProfile.

Drops three fields that were specific to addiction-recovery domain apps and
have no place in a generic reusable base package:

  - research_participation_consent       (v0.7.5 — see P1-3)
  - research_participation_consent_at    (v0.7.5 — see P1-3)
  - anonymize_posts_on_deletion          (v0.7.5 — see P1-3)

Consumer projects that require these fields should add them in their own
PrivacyProfile extension or a separate model.
"""

from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("nimoh_privacy", "0003_processing_restriction"),
    ]

    operations = [
        migrations.RemoveField(
            model_name="privacyprofile",
            name="research_participation_consent",
        ),
        migrations.RemoveField(
            model_name="privacyprofile",
            name="research_participation_consent_at",
        ),
        migrations.RemoveField(
            model_name="privacyprofile",
            name="anonymize_posts_on_deletion",
        ),
    ]
