"""
Celery tasks for the monitoring app.

Background tasks for:
- Pruning old PerformanceMetric, HealthCheck, and EndpointMetrics rows
  to keep the monitoring tables from growing unbounded.
"""

import logging

from celery import shared_task
from django.db.utils import DatabaseError

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def cleanup_monitoring_metrics(self):
    """
    Delete monitoring rows older than ``NIMOH_BASE['MONITORING_RETENTION_DAYS']``.

    Runs weekly via Celery Beat (Sunday 03:00 UTC by default).  Prunes:

    - ``PerformanceMetric`` — keyed on ``timestamp``
    - ``HealthCheck``       — keyed on ``timestamp``
    - ``EndpointMetrics``   — keyed on ``created_at``

    The retention window is configured via ``NIMOH_BASE['MONITORING_RETENTION_DAYS']``
    (default: 30 days).

    Returns:
        dict: Counts of deleted rows per model.
    """
    try:
        from datetime import timedelta

        from django.utils import timezone

        from nimoh_base.conf import nimoh_setting
        from nimoh_base.monitoring.models import EndpointMetrics, HealthCheck, PerformanceMetric

        retention_days = nimoh_setting("MONITORING_RETENTION_DAYS", 30)
        cutoff = timezone.now() - timedelta(days=retention_days)

        deleted_metrics = PerformanceMetric.objects.filter(timestamp__lt=cutoff).delete()[0]
        deleted_health = HealthCheck.objects.filter(timestamp__lt=cutoff).delete()[0]
        deleted_endpoints = EndpointMetrics.objects.filter(created_at__lt=cutoff).delete()[0]

        result = {
            "status": "success",
            "retention_days": retention_days,
            "deleted_performance_metrics": deleted_metrics,
            "deleted_health_checks": deleted_health,
            "deleted_endpoint_metrics": deleted_endpoints,
            "total_deleted": deleted_metrics + deleted_health + deleted_endpoints,
        }

        logger.info(
            "Monitoring cleanup completed: %d rows deleted (retention=%d days)",
            result["total_deleted"],
            retention_days,
        )

        return result

    except DatabaseError as exc:
        logger.error("Monitoring cleanup failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)
