# Generated migration: email-change token + social-auth fields

import uuid

import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("nimoh_auth", "0002_totp"),
    ]

    operations = [
        # ── Social auth fields on the concrete User model ─────────────────────
        migrations.AddField(
            model_name="user",
            name="is_social_account",
            field=models.BooleanField(
                default=False,
                help_text=(
                    "True when the account was created via a social/OAuth2 provider. "
                    "Social accounts may not have a usable password."
                ),
            ),
        ),
        migrations.AddField(
            model_name="user",
            name="social_provider",
            field=models.CharField(
                max_length=50,
                blank=True,
                default="",
                help_text="The social provider slug (e.g. 'google-oauth2', 'github'). Empty for password accounts.",
            ),
        ),
        # ── EmailChangeToken ──────────────────────────────────────────────────
        migrations.CreateModel(
            name="EmailChangeToken",
            fields=[
                (
                    "id",
                    models.UUIDField(
                        primary_key=True,
                        default=uuid.uuid4,
                        editable=False,
                        serialize=False,
                    ),
                ),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="email_change_tokens",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "new_email",
                    models.EmailField(help_text="The address the user wants to move to (not yet applied)."),
                ),
                ("token", models.CharField(max_length=255, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("expires_at", models.DateTimeField()),
                ("used_at", models.DateTimeField(blank=True, null=True)),
                ("is_used", models.BooleanField(default=False)),
                ("ip_address", models.GenericIPAddressField(blank=True, null=True)),
            ],
            options={
                "db_table": "nimoh_auth_email_change_token",
            },
        ),
        migrations.AddIndex(
            model_name="emailchangetoken",
            index=models.Index(fields=["token"], name="nimoh_ect_token_idx"),
        ),
        migrations.AddIndex(
            model_name="emailchangetoken",
            index=models.Index(fields=["user"], name="nimoh_ect_user_idx"),
        ),
        migrations.AddIndex(
            model_name="emailchangetoken",
            index=models.Index(fields=["expires_at"], name="nimoh_ect_expires_idx"),
        ),
    ]
