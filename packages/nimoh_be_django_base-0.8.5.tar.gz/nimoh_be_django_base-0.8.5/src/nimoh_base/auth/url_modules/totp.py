"""
Two-Factor Authentication (TOTP) URL configuration.
"""

from django.urls import path

from ..view_modules.totp import (
    begin_setup_view,
    confirm_setup_view,
    disable_view,
    regenerate_backup_codes_view,
    verify_view,
)

app_name = "totp"

urlpatterns = [
    path("setup/", begin_setup_view, name="setup"),
    path("confirm/", confirm_setup_view, name="confirm"),
    path("verify/", verify_view, name="verify"),
    path("backup-codes/regenerate/", regenerate_backup_codes_view, name="backup-codes-regenerate"),
    path("disable/", disable_view, name="disable"),
]
