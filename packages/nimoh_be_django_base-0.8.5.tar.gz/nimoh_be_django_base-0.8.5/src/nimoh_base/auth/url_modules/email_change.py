"""URL patterns for the email-change flow (§3.3)."""

from django.urls import path

from nimoh_base.auth.view_modules.email_change import (
    email_change_confirm_view,
    email_change_request_view,
)

app_name = "email_change"

urlpatterns = [
    path("", email_change_request_view, name="request"),
    path("confirm/", email_change_confirm_view, name="confirm"),
]
