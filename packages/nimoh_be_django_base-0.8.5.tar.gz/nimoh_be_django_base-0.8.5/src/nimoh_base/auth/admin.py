"""
Django admin configuration for authentication models.
"""

from django.apps import apps as django_apps
from django.conf import settings
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils import timezone
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

from .models import (
    AuditLog,
    BackupCode,
    EmailChangeToken,
    EmailVerificationToken,
    PasswordResetToken,
    TokenBlacklist,
    TOTPDevice,
    UserSession,
)

User = get_user_model()


def _get_configured_profile_model():
    """Return the profile model configured in NIMOH_BASE['PROFILE_MODEL'], or None."""
    model_path = getattr(settings, "NIMOH_BASE", {}).get("PROFILE_MODEL")
    if not model_path:
        return None
    try:
        app_label, model_name = model_path.rsplit(".", 1)
        return django_apps.get_model(app_label, model_name)
    except (LookupError, ValueError):
        return None


class CustomUserAdmin(BaseUserAdmin):
    """
    Custom User admin with additional authentication fields.
    """

    list_display = (
        *BaseUserAdmin.list_display,
        "email_verified",
        "is_account_locked_status",
        "failed_login_attempts",
        "last_login_formatted",
    )

    list_filter = (*BaseUserAdmin.list_filter, "email_verified", "password_changed_at", "locked_until")

    readonly_fields = (*BaseUserAdmin.readonly_fields, "email_verified_at", "password_changed_at", "locked_until")

    fieldsets = (
        *BaseUserAdmin.fieldsets,
        (_("Email Verification"), {"fields": ("email_verified", "email_verified_at")}),
        (_("Account Security"), {"fields": ("failed_login_attempts", "locked_until", "password_changed_at")}),
    )

    def is_account_locked_status(self, obj):
        """Check if account is currently locked."""
        return obj.is_account_locked()

    is_account_locked_status.boolean = True
    is_account_locked_status.short_description = "Account Locked"

    def last_login_formatted(self, obj):
        """Format last login time."""
        if obj.last_login:
            return obj.last_login.strftime("%Y-%m-%d %H:%M:%S")
        return "Never"

    last_login_formatted.short_description = "Last Login"
    last_login_formatted.admin_order_field = "last_login"

    actions = ["unlock_accounts", "verify_emails"]

    def unlock_accounts(self, request, queryset):
        """Unlock selected user accounts."""
        count = 0
        for user in queryset:
            if user.is_account_locked():
                user.failed_login_attempts = 0
                user.locked_until = None
                user.save(update_fields=["failed_login_attempts", "locked_until"])
                count += 1

        self.message_user(request, f"Successfully unlocked {count} account(s).")

    unlock_accounts.short_description = "Unlock selected accounts"

    def verify_emails(self, request, queryset):
        """Verify email addresses for selected users."""
        count = queryset.filter(email_verified=False).update(email_verified=True, email_verified_at=timezone.now())

        self.message_user(request, f"Successfully verified {count} email address(es).")

    verify_emails.short_description = "Verify selected email addresses"


# ============================================================================
# ============================================================================
# Enhanced User Admin for Authentication & Authorization Section
# ============================================================================
#
# Note: UserProfileBasic admin is handled in the profiles app admin.py
# This provides User admin with profile integration for the auth section.
# ============================================================================

_UserProfileModel = _get_configured_profile_model()


if _UserProfileModel is not None:

    class UserProfileBasicInline(admin.StackedInline):
        """Inline admin interface for user basic profiles."""

        model = _UserProfileModel
        can_delete = False
        verbose_name_plural = "Basic Profile"

        readonly_fields = (
            "created_at",
            "updated_at",
        )

        fieldsets = (
            (_("Basic Profile Information"), {"fields": ("display_name", "bio", "timezone")}),
            (_("Privacy Settings"), {"fields": ("profile_visibility",)}),
            (
                _("Leadership Permissions"),
                {"fields": ("can_lead_group",), "description": _("Set leadership permissions for this user")},
            ),
            (_("Timestamps"), {"fields": ("created_at", "updated_at"), "classes": ("collapse",)}),
        )

    _profile_inlines: tuple = (UserProfileBasicInline,)

else:
    _profile_inlines = ()


class EnhancedUserAdmin(BaseUserAdmin):
    """Enhanced user admin with profile inline and comprehensive features."""

    inlines = _profile_inlines

    list_display = (
        "username",
        "email",
        "display_name_from_profile",
        "email_verified",
        "is_staff",
        "is_active",
        "profile_completion_status",
        "last_login_formatted",
    )

    list_filter = (*BaseUserAdmin.list_filter, "email_verified", "password_changed_at", "locked_until")

    search_fields = (*BaseUserAdmin.search_fields, "first_name", "last_name")

    readonly_fields = (
        *BaseUserAdmin.readonly_fields,
        "email_verified_at",
        "password_changed_at",
        "locked_until",
        "profile_info_summary",
    )

    fieldsets = (
        *BaseUserAdmin.fieldsets,
        (_("Email Verification"), {"fields": ("email_verified", "email_verified_at")}),
        (_("Account Security"), {"fields": ("failed_login_attempts", "locked_until", "password_changed_at")}),
        (
            _("Profile Summary"),
            {
                "fields": ("profile_info_summary",),
                "description": _("Basic profile information (edit in Profile section below)"),
            },
        ),
    )

    def display_name_from_profile(self, obj):
        """Display the user's full name, falling back to username."""
        return obj.get_full_name() or obj.username

    display_name_from_profile.short_description = _("Display Name")
    display_name_from_profile.admin_order_field = "username"

    def profile_completion_status(self, obj):
        """Show privacy consent status."""
        try:
            pp = obj.privacy_profile
            consents = [
                pp.privacy_policy_accepted,
                pp.terms_of_service_accepted,
                pp.data_processing_consent,
            ]
            completed = sum(consents)
            total = len(consents)
            percentage = (completed / total) * 100

            if percentage >= 80:
                icon, color = "✅", "green"
            elif percentage >= 50:
                icon, color = "⚠️", "orange"
            else:
                icon, color = "❌", "red"

            return format_html('<span style="color: {};">{} {}%</span>', color, icon, int(percentage))
        except AttributeError:
            return format_html('<span style="color: grey;">—</span>')

    profile_completion_status.short_description = _("Consent Status")

    def profile_info_summary(self, obj):
        """Display privacy profile summary."""
        try:
            pp = obj.privacy_profile
            yes, no = "Yes", "<em>No</em>"
            html = [
                f"<strong>Privacy Policy Accepted:</strong> {yes if pp.privacy_policy_accepted else no}",
                f"<strong>Terms Accepted:</strong> {yes if pp.terms_of_service_accepted else no}",
                f"<strong>Data Processing Consent:</strong> {yes if pp.data_processing_consent else no}",
                f"<strong>Profile Visibility:</strong> {pp.get_profile_visibility_display()}",
                f"<strong>Created:</strong> {pp.created_at.strftime('%Y-%m-%d %H:%M')}",
            ]
            return format_html("<br>".join(html))
        except AttributeError:
            return format_html("<em>No privacy profile yet — created automatically on first consent action.</em>")

    profile_info_summary.short_description = _("Privacy Profile")

    def is_account_locked_status(self, obj):
        """Check if account is currently locked."""
        return obj.is_account_locked()

    is_account_locked_status.boolean = True
    is_account_locked_status.short_description = "Account Locked"

    def last_login_formatted(self, obj):
        """Format last login time."""
        if obj.last_login:
            return obj.last_login.strftime("%Y-%m-%d %H:%M:%S")
        return "Never"

    last_login_formatted.short_description = "Last Login"
    last_login_formatted.admin_order_field = "last_login"

    actions = ["unlock_accounts", "verify_emails", "create_missing_profiles"]

    def unlock_accounts(self, request, queryset):
        """Unlock selected user accounts."""
        count = 0
        for user in queryset:
            if user.is_account_locked():
                user.failed_login_attempts = 0
                user.locked_until = None
                user.save(update_fields=["failed_login_attempts", "locked_until"])
                count += 1

        self.message_user(request, f"Successfully unlocked {count} account(s).")

    unlock_accounts.short_description = "Unlock selected accounts"

    def verify_emails(self, request, queryset):
        """Verify email addresses for selected users."""
        count = queryset.filter(email_verified=False).update(email_verified=True, email_verified_at=timezone.now())
        self.message_user(request, f"Successfully verified {count} email address(es).")

    verify_emails.short_description = "Verify email addresses"

    def create_missing_profiles(self, request, queryset):
        """Create basic profiles for users who don't have them."""
        ProfileModel = _get_configured_profile_model()
        if ProfileModel is None:
            self.message_user(request, "NIMOH_BASE['PROFILE_MODEL'] is not configured.", level="error")
            return

        count = 0
        for user in queryset:
            _profile, created = ProfileModel.objects.get_or_create(
                user=user,
                defaults={
                    "display_name": f"User {user.username}",
                    "timezone": "UTC",
                },
            )
            if created:
                count += 1

        self.message_user(request, f"Successfully created {count} basic profile(s).")

    create_missing_profiles.short_description = "Create missing basic profiles"

    def get_queryset(self, request):
        """Optimize queryset with select_related for profile data."""
        return super().get_queryset(request).select_related("privacy_profile")


# Register User admin in the standard Authentication and Authorization section
# This will make Users appear alongside Groups in the default auth section
admin.site.register(User, EnhancedUserAdmin)


@admin.register(UserSession)
class UserSessionAdmin(admin.ModelAdmin):
    """
    Admin interface for user sessions.
    """

    list_display = [
        "user_email",
        "device_name",
        "ip_address",
        "is_active",
        "is_verified",
        "created_at_formatted",
        "last_activity_formatted",
    ]

    list_filter = [
        "is_active",
        "is_verified",
        "created_at",
        "last_activity_at",
        "country",
    ]

    search_fields = [
        "user__email",
        "user__username",
        "ip_address",
        "user_agent",
        "device_fingerprint",
        "device_name",
    ]

    readonly_fields = [
        "user",
        "session_key",
        "refresh_token_jti",
        "device_fingerprint",
        "created_at",
        "last_activity_at",
        "last_rotation_at",
    ]

    date_hierarchy = "created_at"

    def user_email(self, obj):
        """Display user email."""
        return obj.user.email

    user_email.short_description = "User Email"
    user_email.admin_order_field = "user__email"

    def created_at_formatted(self, obj):
        """Format creation time."""
        return obj.created_at.strftime("%Y-%m-%d %H:%M:%S")

    created_at_formatted.short_description = "Created"
    created_at_formatted.admin_order_field = "created_at"

    def last_activity_formatted(self, obj):
        """Format last activity time."""
        if obj.last_activity_at:
            return obj.last_activity_at.strftime("%Y-%m-%d %H:%M:%S")
        return "Never"

    last_activity_formatted.short_description = "Last Activity"
    last_activity_formatted.admin_order_field = "last_activity_at"

    actions = ["terminate_sessions"]

    def terminate_sessions(self, request, queryset):
        """Terminate selected sessions."""
        count = queryset.filter(is_active=True).update(
            is_active=False, terminated_at=timezone.now(), termination_reason="admin_action"
        )

        self.message_user(request, f"Successfully terminated {count} session(s).")

    terminate_sessions.short_description = "Terminate selected sessions"


@admin.register(TokenBlacklist)
class TokenBlacklistAdmin(admin.ModelAdmin):
    """
    Admin interface for token blacklist.
    """

    list_display = [
        "user_email",
        "token_type",
        "reason",
        "blacklisted_at_formatted",
        "expires_at_formatted",
        "is_expired_status",
    ]

    list_filter = [
        "token_type",
        "reason",
        "blacklisted_at",
        "expires_at",
    ]

    search_fields = [
        "user__email",
        "user__username",
        "jti",
    ]

    readonly_fields = [
        "user",
        "jti",
        "token_type",
        "blacklisted_at",
        "expires_at",
    ]

    date_hierarchy = "blacklisted_at"

    def user_email(self, obj):
        """Display user email."""
        return obj.user.email

    user_email.short_description = "User Email"
    user_email.admin_order_field = "user__email"

    def blacklisted_at_formatted(self, obj):
        """Format blacklisted time."""
        return obj.blacklisted_at.strftime("%Y-%m-%d %H:%M:%S")

    blacklisted_at_formatted.short_description = "Blacklisted"
    blacklisted_at_formatted.admin_order_field = "blacklisted_at"

    def expires_at_formatted(self, obj):
        """Format expiration time."""
        if obj.expires_at:
            return obj.expires_at.strftime("%Y-%m-%d %H:%M:%S")
        return "Never"

    expires_at_formatted.short_description = "Expires"
    expires_at_formatted.admin_order_field = "expires_at"

    def is_expired_status(self, obj):
        """Check if token is expired."""
        return obj.is_expired()

    is_expired_status.boolean = True
    is_expired_status.short_description = "Expired"


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    """
    Admin interface for audit logs - read-only for security.
    """

    list_display = [
        "user_display",
        "event_type",
        "success",
        "risk_level",
        "ip_address",
        "timestamp_formatted",
    ]

    list_filter = [
        "event_type",
        "success",
        "risk_level",
        "timestamp",
    ]

    search_fields = [
        "user__email",
        "user__username",
        "event_type",
        "description",
        "ip_address",
    ]

    readonly_fields = [
        "user",
        "event_type",
        "description",
        "ip_address",
        "user_agent",
        "session_id",
        "timestamp",
        "success",
        "risk_level",
        "metadata",
    ]

    date_hierarchy = "timestamp"

    def user_display(self, obj):
        """Display user email or 'Anonymous' if no user."""
        if obj.user:
            return obj.user.email
        return format_html("<em>Anonymous</em>")

    user_display.short_description = "User"
    user_display.admin_order_field = "user__email"

    def timestamp_formatted(self, obj):
        """Format timestamp."""
        return obj.timestamp.strftime("%Y-%m-%d %H:%M:%S")

    timestamp_formatted.short_description = "Timestamp"
    timestamp_formatted.admin_order_field = "timestamp"

    def has_add_permission(self, request):
        """Audit logs should not be manually created."""
        return False

    def has_change_permission(self, request, obj=None):
        """Audit logs should not be modified."""
        return False

    def has_delete_permission(self, request, obj=None):
        """Audit logs should not be deleted."""
        return request.user.is_superuser  # Only superusers can delete for cleanup


@admin.register(EmailVerificationToken)
class EmailVerificationTokenAdmin(admin.ModelAdmin):
    """
    Admin interface for email verification tokens.
    """

    list_display = [
        "user_email",
        "email",
        "is_used",
        "is_expired_status",
        "created_at_formatted",
        "expires_at_formatted",
    ]

    list_filter = [
        "is_used",
        "created_at",
        "expires_at",
    ]

    search_fields = [
        "user__email",
        "email",
        "token",
    ]

    readonly_fields = [
        "user",
        "token",
        "email",
        "created_at",
        "expires_at",
        "used_at",
        "ip_address",
    ]

    date_hierarchy = "created_at"

    def user_email(self, obj):
        """Display user email."""
        return obj.user.email

    user_email.short_description = "User Email"
    user_email.admin_order_field = "user__email"

    def created_at_formatted(self, obj):
        """Format creation time."""
        return obj.created_at.strftime("%Y-%m-%d %H:%M:%S")

    created_at_formatted.short_description = "Created"
    created_at_formatted.admin_order_field = "created_at"

    def expires_at_formatted(self, obj):
        """Format expiration time."""
        return obj.expires_at.strftime("%Y-%m-%d %H:%M:%S")

    expires_at_formatted.short_description = "Expires"
    expires_at_formatted.admin_order_field = "expires_at"

    def is_expired_status(self, obj):
        """Check if token is expired."""
        return obj.is_expired()

    is_expired_status.boolean = True
    is_expired_status.short_description = "Expired"


@admin.register(PasswordResetToken)
class PasswordResetTokenAdmin(admin.ModelAdmin):
    """
    Admin interface for password reset tokens.
    """

    list_display = [
        "user_email",
        "is_used",
        "is_expired_status",
        "created_at_formatted",
        "expires_at_formatted",
    ]

    list_filter = [
        "is_used",
        "created_at",
        "expires_at",
    ]

    search_fields = [
        "user__email",
        "token",
    ]

    readonly_fields = [
        "user",
        "token",
        "created_at",
        "expires_at",
        "used_at",
        "ip_address",
        "user_agent",
    ]

    date_hierarchy = "created_at"

    def user_email(self, obj):
        """Display user email."""
        return obj.user.email

    user_email.short_description = "User Email"
    user_email.admin_order_field = "user__email"

    def created_at_formatted(self, obj):
        """Format creation time."""
        return obj.created_at.strftime("%Y-%m-%d %H:%M:%S")

    created_at_formatted.short_description = "Created"
    created_at_formatted.admin_order_field = "created_at"

    def expires_at_formatted(self, obj):
        """Format expiration time."""
        return obj.expires_at.strftime("%Y-%m-%d %H:%M:%S")

    expires_at_formatted.short_description = "Expires"
    expires_at_formatted.admin_order_field = "expires_at"

    def is_expired_status(self, obj):
        """Check if token is expired."""
        return obj.is_expired()

    is_expired_status.boolean = True
    is_expired_status.short_description = "Expired"


# ─────────────────────────────────────────────────────────────────────────────
# Two-Factor Authentication Admin
# ─────────────────────────────────────────────────────────────────────────────


@admin.register(TOTPDevice)
class TOTPDeviceAdmin(admin.ModelAdmin):
    """Admin for TOTP authenticator devices."""

    list_display = ("user", "name", "confirmed", "created_at")
    list_filter = ("confirmed",)
    search_fields = ("user__email", "user__username")
    readonly_fields = ("secret", "created_at")
    ordering = ("-created_at",)

    def has_add_permission(self, request):
        """Prevent manual TOTP device creation via admin — use the API flow."""
        return False


@admin.register(BackupCode)
class BackupCodeAdmin(admin.ModelAdmin):
    """Admin for TOTP backup codes (hashed — no plain-text access)."""

    list_display = ("user", "used", "created_at", "used_at")
    list_filter = ("used",)
    search_fields = ("user__email", "user__username")
    readonly_fields = ("user", "code_hash", "created_at", "used_at")
    ordering = ("-created_at",)

    def has_add_permission(self, request):
        """Backup codes are generated by the API only."""
        return False


@admin.register(EmailChangeToken)
class EmailChangeTokenAdmin(admin.ModelAdmin):
    """Admin for email-change confirmation tokens."""

    list_display = ("user", "new_email", "is_used", "created_at", "expires_at", "used_at")
    list_filter = ("is_used",)
    search_fields = ("user__email", "new_email")
    readonly_fields = ("user", "new_email", "token", "created_at", "expires_at", "used_at", "ip_address")
    ordering = ("-created_at",)

    def has_add_permission(self, request):
        """Email-change tokens are created by the API only."""
        return False
