"""Spot instance commands"""
