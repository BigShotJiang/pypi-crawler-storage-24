export const dynamic = "force-dynamic";

import { OptionsList } from "@/features/options/options-list";
import { getOptionsDashboards } from "@/lib/api/client";

export default async function OptionsPage() {
  const dashboards = await getOptionsDashboards();
  return <OptionsList dashboards={dashboards} />;
}
