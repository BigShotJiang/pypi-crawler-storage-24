"""Interactive prompts using questionary."""

import sys
from typing import Any, Optional

import click
import questionary


def _require_tty(flag_hint: str) -> None:
    if not sys.stdin.isatty():
        click.echo(
            f"Error: Interactive prompt requires a TTY. Pass {flag_hint} instead.",
            err=True,
        )
        sys.exit(1)


def select_scenario(scenarios: list[dict[str, Any]]) -> Optional[str]:
    _require_tty("--scenario-set-id")
    if not scenarios:
        return None

    choices = [
        questionary.Choice(
            title=f"{s.get('title', '')} ({s.get('id', '')})",
            value=s.get("id", ""),
        )
        for s in scenarios
    ]

    # Default to the first (most recently created) scenario set
    default = choices[0].value if choices else None

    answer = questionary.select(
        "Select a scenario set:",
        choices=choices,
        default=default,
    ).ask()

    return answer


def select_environment(
    environments: list[dict[str, Any]], default: Optional[str] = None
) -> Optional[str]:
    _require_tty("--env-id")
    if not environments:
        return None

    choices = [
        questionary.Choice(
            title=f"{e.get('name', '')} ({e.get('id', '')})",
            value=e.get("id", ""),
        )
        for e in environments
    ]

    return questionary.select(
        "Choose environment:",
        choices=choices,
        default=default,
    ).ask()


def confirm_action(message: str, default: bool = False, flag_hint: str = "--yes") -> bool:
    _require_tty(flag_hint)
    return questionary.confirm(message, default=default).ask()


def prompt_environment_name() -> Optional[str]:
    _require_tty("--name")
    answer = questionary.text(
        'Name your env (e.g. "agent-env"):',
        validate=lambda x: len(x) > 0 or "Name cannot be empty",
    ).ask()

    return answer


def select_from_list(
    prompt: str,
    items: list[dict[str, Any]],
    flag_hint: str = "--id",
    default: Optional[str] = None,
) -> Optional[str]:
    _require_tty(flag_hint)
    if not items:
        return None

    choices = [
        questionary.Choice(title=item.get("title", item.get("id", "")), value=item.get("id", ""))
        for item in items
    ]

    return questionary.select(prompt, choices=choices, default=default).ask()
