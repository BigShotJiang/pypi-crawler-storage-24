"""Markdown summary formatter for the `veris run` pipeline command."""

from __future__ import annotations


def _fmt_duration(seconds: int | None) -> str:
    if seconds is None:
        return "—"
    m, s = divmod(seconds, 60)
    return f"{m}m {s:02d}s"


def format_markdown_summary(
    run: dict,
    scenario_set: dict,
    simulations: list[dict],
    eval_run: dict,
) -> str:
    """Build a markdown report from run + evaluation data."""

    # Build lookup maps
    scenarios = scenario_set.get("scenarios") or []
    scenario_map: dict[str, str] = {s["id"]: s["title"] for s in scenarios}
    sim_scenario_map: dict[str, str] = {s["id"]: s["scenario_id"] for s in simulations}

    lines: list[str] = []
    lines.append("## Veris Simulation Report")
    lines.append("")

    # Metadata table
    lines.append("| Field | Value |")
    lines.append("|-------|-------|")
    lines.append(f"| Run | `{run['id']}` |")
    lines.append(f"| Status | {run['status']} |")
    set_title = scenario_set.get("title", "—")
    set_id = scenario_set.get("id", "—")
    lines.append(f"| Scenario Set | {set_title} (`{set_id}`) |")
    lines.append(f"| Scenarios | {len(scenarios)} |")
    lines.append(f"| Duration | {_fmt_duration(run.get('duration_seconds'))} |")
    lines.append("")

    # Grading results
    grading_results = eval_run.get("grading_results") or []
    if grading_results:
        lines.append("### Grading Results")
        lines.append("")
        lines.append("| Scenario | Simulation | Score | Status |")
        lines.append("|----------|------------|-------|--------|")
        for gr in grading_results:
            sim_id = gr["simulation_id"]
            scenario_id = sim_scenario_map.get(sim_id, "—")
            scenario_title = scenario_map.get(scenario_id, scenario_id)
            score = gr.get("score")
            score_str = f"{score:.2f}" if score is not None else "—"
            lines.append(f"| {scenario_title} | `{sim_id}` | {score_str} | {gr['status']} |")
        lines.append("")

    # Assertion results
    assertion_results = eval_run.get("assertion_results") or []
    if assertion_results:
        lines.append("### Assertion Results")
        lines.append("")
        lines.append("| Scenario | Verdict | Criteria |")
        lines.append("|----------|---------|----------|")
        for ar in assertion_results:
            sim_id = ar["simulation_id"]
            scenario_id = sim_scenario_map.get(sim_id, "—")
            scenario_title = scenario_map.get(scenario_id, scenario_id)
            verdict = ar.get("verdict") or "—"
            # Compute criteria summary
            criteria_results = (ar.get("result") or {}).get("criteria_results", [])
            if criteria_results:
                passed = sum(1 for c in criteria_results if c.get("result") == "PASS")
                criteria_str = f"{passed}/{len(criteria_results)}"
            else:
                criteria_str = "—"
            lines.append(f"| {scenario_title} | {verdict} | {criteria_str} |")
        lines.append("")

    return "\n".join(lines)
