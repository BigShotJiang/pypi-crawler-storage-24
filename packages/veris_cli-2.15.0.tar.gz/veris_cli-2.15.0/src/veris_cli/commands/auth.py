"""Login command."""

import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

import click

from veris_cli import output
from veris_cli.commands._helpers import get_profile
from veris_cli.config import Config


@click.command()
@click.argument("api_key", required=False, default=None)
@click.option(
    "--backend-url",
    default=None,
    help="Backend URL (default: https://sandbox.api.veris.ai)",
)
@click.option(
    "--org",
    default=None,
    help="Organization ID to scope this profile to (e.g. org_abc123)",
)
@click.option(
    "--console-url",
    default=None,
    help="Console URL (default: https://console.veris.ai)",
)
@click.pass_context
def login(
    ctx, api_key: str | None, backend_url: str | None, org: str | None, console_url: str | None
):
    """Authenticate with Veris via Google login or API key.

    Usage:
      veris login                     # Browser-based Google login
      veris login <api-key>           # Direct API key login (for CI/scripts)
      veris login --backend-url URL   # Specify backend URL
      veris login --org org_abc123    # Scope profile to an organization
    """
    profile = get_profile(ctx)
    config = Config(profile=profile)

    if backend_url or console_url:
        profile_data = config._load_profile()
        if backend_url:
            profile_data["backend_url"] = backend_url
        if console_url:
            profile_data["console_url"] = console_url
        config._save_profile(profile_data)

    # Direct API key login
    if api_key:
        effective_url = backend_url or config.get_backend_url()
        config.set_api_key(api_key, effective_url)
        if org:
            config.set_organization_id(org)
        output.print_success(f"API key saved to {config.config_file}")
        output.print_info(f"Backend URL: {effective_url}")
        if org:
            output.print_info(f"Organization: {org}")
        if config.profile != "default":
            output.print_info(f"Profile: {config.profile}")
        return

    # Browser-based Google OAuth login
    effective_url = backend_url or config.get_backend_url()
    result: dict[str, str] = {}
    server_ready = threading.Event()

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            query = parse_qs(urlparse(self.path).query)
            if "token" in query:
                result["token"] = query["token"][0]
                result["email"] = query.get("email", [""])[0]
                result["name"] = query.get("name", [""])[0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body style='font-family:system-ui;display:flex;"
                    b"justify-content:center;align-items:center;height:100vh;margin:0'>"
                    b"<div style='text-align:center'>"
                    b"<h2>Login successful!</h2>"
                    b"<p>You can close this tab and return to the CLI.</p>"
                    b"</div></body></html>"
                )
            else:
                error = query.get("error", ["Unknown error"])[0]
                result["error"] = error
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    f"<html><body><h2>Login failed: {error}</h2></body></html>".encode()
                )

        def log_message(self, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), CallbackHandler)
    port = server.server_address[1]

    def serve():
        server_ready.set()
        server.handle_request()

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    server_ready.wait()

    login_url = f"{effective_url}/v1/auth/login?cli_port={port}"
    output.print_info("Opening browser to log in with Google...")
    webbrowser.open(login_url)

    thread.join(timeout=120)
    server.server_close()

    if "error" in result:
        output.print_error(f"Login failed: {result['error']}")
        sys.exit(1)
    elif "token" not in result:
        output.print_error("Login timed out. Please try again.")
        sys.exit(1)

    config.set_api_key(result["token"], effective_url)
    if org:
        config.set_organization_id(org)

    email = result.get("email", "")
    if email:
        output.print_success(f"Logged in as {email}")
    else:
        output.print_success("Logged in successfully")
    output.print_info(f"API key saved to {config.config_file}")
    if org:
        output.print_info(f"Organization: {org}")
