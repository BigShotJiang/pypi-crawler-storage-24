"""Scenario management commands: create, status, list, get, delete."""

import sys
import time

import click

from veris_cli import output
from veris_cli.api import VerisAPI
from veris_cli.commands._helpers import get_profile, resolve_env_id


@click.group()
def scenarios():
    """Scenario management commands."""
    pass


@scenarios.command(name="create")
@click.option("--env-id", default=None, help="Environment ID")
@click.option("--num", default=None, type=int, help="Number of scenarios to generate")
@click.option("--image-tag", default=None, help="Image tag to use (default: latest)")
@click.pass_context
def scenarios_create(ctx, env_id: str, num: int | None, image_tag: str):
    """Generate scenario set via async job.

    Launches an async job that explores your agent code, generates test
    scenarios and a grader definition.
    """
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not env_id:
            env_id = resolve_env_id(profile, env_id)

        if num is None:
            if sys.stdin.isatty():
                import questionary

                answer = questionary.text(
                    "Number of scenarios to generate:",
                    default="5",
                    validate=lambda x: x.isdigit() and int(x) > 0,
                ).ask()
                num = int(answer) if answer else 5
            else:
                num = 5

        output.print_info(f"Generating {num} scenario(s) for environment {env_id}...")
        result = api.generate_scenario_set(
            environment_id=env_id,
            num_scenarios=num,
            image_tag=image_tag,
        )

        set_id = result.get("id", "")
        output.print_success(f"Scenario generation started: {set_id}")
        output.print_info(f"→ Next: veris scenarios status {set_id} --watch")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to generate scenarios: {e}")
        sys.exit(1)


@scenarios.command(name="status")
@click.argument("set_id")
@click.option("--watch", is_flag=True, help="Poll until generation completes")
@click.pass_context
def scenarios_status(ctx, set_id: str, watch: bool):
    """Check scenario set generation progress."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if watch:
            from rich.live import Live

            try:
                with Live(console=output.console, refresh_per_second=1) as live:
                    while True:
                        data = api.get_scenario_set(set_id)
                        status = data.get("status", "")
                        live.update(output.build_scenario_status_panel(data))

                        if status in ("ready", "completed", "failed"):
                            break

                        time.sleep(5)
            except KeyboardInterrupt:
                output.print_info("\nStopped watching.")
                return

            # Print final status summary (no scenarios table)
            output.print_scenario_set_summary(data)
            if status not in ("failed",):
                output.print_info(f"\n→ Next: veris simulations create --scenario-set-id {set_id}")
                output.print_info(f"        veris scenarios get {set_id}")
        else:
            data = api.get_scenario_set(set_id)
            output.print_scenario_set_summary(data)

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get scenario set status: {e}")
        sys.exit(1)


@scenarios.command(name="list")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def scenarios_list(ctx, env_id: str):
    """List scenario sets for an environment."""
    profile = get_profile(ctx)
    try:
        if not env_id:
            from veris_cli.config import ProjectConfig

            project_config = ProjectConfig(profile=profile)
            env_id = project_config.get_environment_id()

        api = VerisAPI(profile=profile)
        result = api.list_scenario_sets(environment_id=env_id)

        # Fetch graders to show alongside scenario sets
        graders = []
        if env_id:
            try:
                graders_result = api.list_graders(environment_id=env_id)
                graders = graders_result.get("graders", [])
            except Exception:
                pass

        output.print_scenario_sets_table(result, graders=graders)
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list scenarios: {e}")
        sys.exit(1)


@scenarios.command(name="get")
@click.argument("set_id")
@click.pass_context
def scenarios_get(ctx, set_id: str):
    """View a scenario set in the console."""
    from veris_cli.commands._helpers import get_console_url

    profile = get_profile(ctx)
    console_url = get_console_url(profile)
    url = f"{console_url}/scenarios/{set_id}"
    output.print_info(f"→ {url}")


@scenarios.command(name="delete")
@click.argument("set_id")
@click.pass_context
def scenarios_delete(ctx, set_id: str):
    """Delete a scenario set."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        api.delete_scenario_set(set_id)
        output.print_success(f"Scenario set {set_id} deleted")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to delete scenario set: {e}")
        sys.exit(1)
