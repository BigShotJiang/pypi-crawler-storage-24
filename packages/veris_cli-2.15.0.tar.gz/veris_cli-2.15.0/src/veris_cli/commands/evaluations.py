"""Evaluation commands: create, status, list (graders), get (grader)."""

import sys
import time

import click

from veris_cli import output, prompts
from veris_cli.api import VerisAPI
from veris_cli.commands._helpers import (
    get_console_url,
    get_profile,
    select_grader_interactive,
    try_get_project_env_id,
)


@click.group()
def evaluations():
    """Evaluation commands — trigger grading and manage graders."""
    pass


@evaluations.command(name="create")
@click.option("--sim-run-id", default=None, help="Simulation run ID to evaluate")
@click.option("--grader-id", default=None, help="Grader ID to use")
@click.pass_context
def evaluations_create(ctx, sim_run_id: str, grader_id: str):
    """Trigger grading + assertions on a simulation run."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not sim_run_id:
            # Scope to current project's environment if available
            project_env_id = try_get_project_env_id(profile)

            result = api.list_runs(status="completed", environment_id=project_env_id)
            runs = result.get("runs", [])
            if not runs:
                output.print_error("No completed simulation runs found")
                sys.exit(1)

            choices = []
            for r in runs:
                created = (r.get("created_at") or "")[:10]
                sims_done = r.get("completed_simulations", 0)
                sims_total = r.get("total_simulations", 0)
                scenario_set = r.get("scenario_set_id", "")[:20]
                title = (
                    f"{r.get('id', '')}  {scenario_set}  {sims_done}/{sims_total} sims  {created}"
                )
                choices.append({"id": r.get("id", ""), "title": title})

            sim_run_id = prompts.select_from_list(
                "Select a completed simulation run:", choices, flag_hint="--sim-run-id"
            )
            if not sim_run_id:
                output.print_error("No simulation run selected")
                sys.exit(1)

        if not grader_id:
            run_data = api.get_run(sim_run_id)
            env_id = run_data.get("environment_id")
            scenario_set_id = run_data.get("scenario_set_id")
            if not env_id:
                output.print_error("Could not determine environment from simulation run")
                sys.exit(1)

            grader_id = select_grader_interactive(api, env_id, scenario_set_id)

        output.print_info(f"Triggering evaluation on {sim_run_id} with grader {grader_id}...")
        result = api.trigger_evaluation(run_id=sim_run_id, grader_id=grader_id)

        eval_run_id = result.get("evaluation_run_id", "")
        console_url = get_console_url(profile)
        output.print_success(f"Evaluation started: {eval_run_id}")
        output.print_info(f"→ {console_url}/evaluations/{sim_run_id}/{eval_run_id}")
        output.print_info(f"→ Next: veris evaluations status {sim_run_id} {eval_run_id} --watch")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to create evaluation: {e}")
        sys.exit(1)


@evaluations.command(name="status")
@click.argument("sim_run_id")
@click.argument("eval_run_id")
@click.option("--watch", is_flag=True, help="Poll every 5 seconds until complete")
@click.pass_context
def evaluations_status(ctx, sim_run_id: str, eval_run_id: str, watch: bool):
    """Get evaluation run status and results."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if watch:
            from rich.live import Live

            try:
                with Live(console=output.console, refresh_per_second=1) as live:
                    while True:
                        data = api.get_evaluation_run(run_id=sim_run_id, eval_run_id=eval_run_id)
                        live.update(output.build_evaluation_status_panel(data))

                        status = data.get("status", "")
                        if status in ["completed", "failed"]:
                            break

                        time.sleep(5)
            except KeyboardInterrupt:
                output.print_info("\nStopped watching.")
                return

            # Print final state
            data = api.get_evaluation_run(run_id=sim_run_id, eval_run_id=eval_run_id)
            output.print_evaluation_run_details(data)
            output.print_info(f"\n→ {get_console_url(profile)}/simulations/{sim_run_id}")
            output.print_info(f"→ Next: veris reports create {sim_run_id}")
        else:
            data = api.get_evaluation_run(run_id=sim_run_id, eval_run_id=eval_run_id)
            output.print_evaluation_run_details(data)
            output.print_info(f"\n→ {get_console_url(profile)}/simulations/{sim_run_id}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get evaluation status: {e}")
        sys.exit(1)


@evaluations.command(name="list")
@click.argument("sim_run_id", required=False, default=None)
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def evaluations_list(ctx, sim_run_id: str | None, env_id: str | None):
    """List evaluation runs.

    With SIM_RUN_ID, lists evals for that run.
    Without arguments, lists evals across recent runs for the current environment.
    """
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if sim_run_id:
            # Fast path: single run
            result = api.list_evaluation_runs(run_id=sim_run_id)
            output.print_evaluation_runs_table(result.get("evaluation_runs", []))
        else:
            # Fan-out: fetch evals across recent runs for the environment
            if not env_id:
                env_id = try_get_project_env_id(profile)
            if not env_id:
                output.print_error("No environment configured. Pass SIM_RUN_ID or use --env-id.")
                sys.exit(1)

            from concurrent.futures import ThreadPoolExecutor, as_completed

            runs_result = api.list_runs(environment_id=env_id)
            runs = runs_result.get("runs", [])

            def fetch_evals(r):
                result = api.list_evaluation_runs(run_id=r["id"])
                evals = []
                for er in result.get("evaluation_runs", []):
                    er["_run_id"] = r["id"]
                    er["_scenario_set_id"] = r.get("scenario_set_id", "")
                    evals.append(er)
                return evals

            all_evals = []
            with ThreadPoolExecutor(max_workers=10) as pool:
                futures = {pool.submit(fetch_evals, r): r for r in runs}
                for future in as_completed(futures):
                    try:
                        all_evals.extend(future.result())
                    except Exception:
                        pass

            all_evals.sort(key=lambda e: e.get("created_at", ""), reverse=True)
            output.print_evaluation_runs_table(all_evals)
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list evaluations: {e}")
        sys.exit(1)


@evaluations.command(name="get")
@click.argument("sim_run_id")
@click.argument("eval_run_id")
@click.pass_context
def evaluations_get(ctx, sim_run_id: str, eval_run_id: str):
    """View evaluation run in the console."""
    profile = get_profile(ctx)
    console_url = get_console_url(profile)
    url = f"{console_url}/evaluations/{sim_run_id}/{eval_run_id}"
    output.print_info(f"→ {url}")
