"""Environment management commands: create, push, list, delete, set-var, get-vars, rm-var."""

import sys
import time
from pathlib import Path

import click
import httpx
import yaml

from veris_cli import output, prompts, templates
from veris_cli.api import VerisAPI
from veris_cli.commands._helpers import get_profile, resolve_env_id
from veris_cli.config import Config, ProjectConfig


def _env_push_remote(env_id: str, tag: str, profile: str | None = None):
    tarball_path = None
    try:
        from veris_cli.build_context import create_build_context

        output.print_info("Packaging build context...")
        tarball_path, size = create_build_context(Path.cwd())
        size_mb = size / 1024 / 1024
        output.print_success(f"Build context: {size_mb:.1f} MB")

        api = VerisAPI(profile=profile)
        build_result = api.create_build(environment_id=env_id, tag=tag)
        build_id = build_result["build_id"]
        upload_url = build_result["upload_url"]

        output.print_info("Uploading build context...")
        with open(tarball_path, "rb") as f:
            upload_resp = httpx.put(
                upload_url,
                content=f,
                headers={"Content-Type": "application/gzip"},
                timeout=300,
            )
        if upload_resp.status_code not in (200, 201):
            output.print_error(f"Upload failed: {upload_resp.status_code} {upload_resp.text}")
            sys.exit(1)
        output.print_success("Upload complete")

        output.print_info("Starting Cloud Build...")
        api.notify_build_uploaded(environment_id=env_id, build_id=build_id)

        from rich.console import Console
        from rich.live import Live
        from rich.spinner import Spinner

        console = Console()
        cursor = None
        logs_started = False
        build_status = "building"

        # Show spinner until first log lines arrive
        spinner = Live(
            Spinner("dots", text="Building image..."), console=console, refresh_per_second=4
        )
        spinner.start()

        poll_errors = 0
        try:
            while True:
                time.sleep(2)
                try:
                    result = api.get_build_logs(
                        environment_id=env_id, build_id=build_id, cursor=cursor
                    )
                    poll_errors = 0
                except Exception:
                    poll_errors += 1
                    if poll_errors >= 5:
                        raise
                    continue
                lines = result.get("lines") or []
                build_status = result.get("status", build_status)
                new_cursor = result.get("cursor")
                if new_cursor:
                    cursor = new_cursor

                if lines and not logs_started:
                    # First log lines arrived — stop spinner, print header
                    spinner.stop()
                    logs_started = True
                    console.rule("Build logs")

                for line in lines:
                    click.echo(line)

                if build_status in ("complete", "failed") and (not lines or not new_cursor):
                    break
        finally:
            if not logs_started:
                spinner.stop()

        if logs_started:
            console.rule()

        # Fetch final status for image URI / error detail
        status_result = api.get_build_status(environment_id=env_id, build_id=build_id)

        if build_status == "failed":
            error = status_result.get("error", "Unknown error")
            output.print_error(f"Build failed: {error}")
            sys.exit(1)

        image_uri = status_result.get("image_uri", "")
        output.print_success(f"Image pushed: {image_uri}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to push: {e}")
        sys.exit(1)
    finally:
        if tarball_path:
            tarball_path.unlink(missing_ok=True)


@click.group()
def env():
    """Environment management commands."""
    pass


@env.command(name="create")
@click.option("--name", default=None, help="Environment name (will prompt if not provided)")
@click.pass_context
def env_create(ctx, name: str):
    """Register a new environment on the backend.

    Creates the environment and saves env_id to .veris/config.yaml.
    Uploads .veris/veris.yaml to the backend config store.
    """
    profile = get_profile(ctx)
    veris_dir = Path.cwd() / ".veris"

    if not veris_dir.exists():
        output.print_error(".veris/ not found. Run 'veris init' first.")
        sys.exit(1)

    project_config = ProjectConfig(profile=profile)
    existing_env_id = project_config.get_environment_id()

    if existing_env_id:
        existing_name = project_config._load_profile().get("environment_name", "unknown")
        output.print_info(f"Environment already configured: {existing_env_id} ({existing_name})")
        return

    if not name:
        name = prompts.prompt_environment_name()
        if not name:
            output.print_error("Environment name is required")
            sys.exit(1)

    output.print_info(f"\nCreating environment '{name}'...")
    try:
        api = VerisAPI(profile=profile)
        result = api.create_environment(name=name)

        environment = result.get("environment", {})
        env_id = environment.get("id")

        if not env_id:
            output.print_error("Failed to get environment ID from response")
            sys.exit(1)

        project_config.set_environment_id(env_id, name)

        # Upload veris.yaml if it exists
        veris_yaml = veris_dir / "veris.yaml"
        if veris_yaml.exists():
            try:
                config = yaml.safe_load(veris_yaml.read_text())
                api.upload_environment_config(env_id, config)
                output.print_success("Config uploaded")
            except Exception as e:
                output.print_warning(f"Config upload failed (non-fatal): {e}")

        output.print_success(f"Environment created: {env_id}")
        output.print_info("Environment ID saved to .veris/config.yaml")
        output.print_info("\n→ Next: veris env push")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except httpx.ConnectError:
        output.print_error(
            f"Could not connect to backend at {Config(profile=profile).get_backend_url()}"
        )
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to create environment: {e}")
        sys.exit(1)


@env.command(name="push")
@click.option("--tag", default="latest", help="Image tag (default: latest)")
@click.pass_context
def env_push(ctx, tag: str):
    """Build and push environment image via Cloud Build."""
    profile = get_profile(ctx)
    veris_dir = Path.cwd() / ".veris"
    dockerfile = veris_dir / "Dockerfile.sandbox"
    veris_yaml = veris_dir / "veris.yaml"

    if not dockerfile.exists():
        output.print_error(".veris/Dockerfile.sandbox not found. Run 'veris init' first.")
        sys.exit(1)

    if not veris_yaml.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris init' first.")
        sys.exit(1)

    project_config = ProjectConfig(profile=profile)
    env_id = project_config.get_environment_id()

    if not env_id:
        output.print_error("No environment configured. Run 'veris env create' first.")
        sys.exit(1)

    # Upload veris.yaml config first
    try:
        api = VerisAPI(profile=profile)
        config = yaml.safe_load(veris_yaml.read_text())
        api.upload_environment_config(env_id, config)
        output.print_success("Config validated and uploaded")
    except yaml.YAMLError as e:
        output.print_error(f"Failed to parse veris.yaml: {e}")
        sys.exit(1)
    except Exception as e:
        detail = getattr(e, "detail", str(e))
        output.print_error(f"veris.yaml validation failed:\n{detail}")
        sys.exit(1)

    _env_push_remote(env_id, tag, profile)


@env.command(name="list")
@click.pass_context
def env_list(ctx):
    """List environments for current profile."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        result = api.list_environments()
        output.print_environments_table(result.get("environments", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list environments: {e}")
        sys.exit(1)


@env.command(name="delete")
@click.argument("env_id")
@click.pass_context
def env_delete(ctx, env_id: str):
    """Delete an environment."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        api.delete_environment(env_id)
        output.print_success(f"Environment {env_id} deleted")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to delete environment: {e}")
        sys.exit(1)


@env.group()
def vars():
    """Environment variable management."""
    pass


@vars.command(name="set")
@click.argument("key_values", nargs=-1, required=True)
@click.option("--secret", is_flag=True, help="Mark all values as secret (encrypted at rest)")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def vars_set(ctx, key_values: tuple[str, ...], secret: bool, env_id: str):
    """Set environment variables.

    Pass one or more KEY=VALUE pairs:

      veris env vars set OPENAI_API_KEY=sk-... --secret
      veris env vars set DB_HOST=localhost DB_PORT=5432
    """
    profile = get_profile(ctx)
    variables = []
    for item in key_values:
        if "=" not in item:
            output.print_error(f"Invalid format: '{item}'. Expected KEY=VALUE.")
            sys.exit(1)
        key, _, value = item.partition("=")
        key = key.strip()
        if not key:
            output.print_error(f"Empty key in: '{item}'")
            sys.exit(1)
        variables.append({"key": key, "value": value, "is_secret": secret})

    try:
        api = VerisAPI(profile=profile)
        env_id = resolve_env_id(profile, env_id)
        result = api.upsert_environment_variables(env_id, variables)
        count = len(result.get("variables", []))
        output.print_success(f"{count} variable(s) saved to environment {env_id}")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to set variables: {e}")
        sys.exit(1)


@vars.command(name="list")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def vars_list(ctx, env_id: str):
    """List environment variables."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        env_id = resolve_env_id(profile, env_id)
        result = api.list_environment_variables(env_id)
        output.print_environment_variables_table(result.get("variables", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list variables: {e}")
        sys.exit(1)


@vars.command(name="rm")
@click.argument("key")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def vars_rm(ctx, key: str, env_id: str):
    """Remove an environment variable by key.

    Example: veris env vars rm OPENAI_API_KEY
    """
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        env_id = resolve_env_id(profile, env_id)
        api.delete_environment_variable(env_id, key)
        output.print_success(f"Variable '{key}' removed from environment {env_id}")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to remove variable: {e}")
        sys.exit(1)
