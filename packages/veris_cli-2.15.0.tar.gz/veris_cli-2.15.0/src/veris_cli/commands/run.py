"""Top-level `veris run` pipeline command.

Chains: scenarios → simulations → evaluations → reports.
Interactive prompts in TTY mode, all-flags for CI.
Markdown summary to stdout, progress to stderr.
"""

import sys
import time

import click

from veris_cli import output, prompts
from veris_cli.api import VerisAPI
from veris_cli.commands._helpers import (
    get_console_url,
    get_profile,
    resolve_env_id,
    select_grader_interactive,
)


@click.command()
@click.option("--scenario-set-id", default=None, help="Scenario set ID (overrides prompt)")
@click.option("--env-id", default=None, help="Environment ID (overrides config)")
@click.option("--grader-id", default=None, help="Grader ID (overrides prompt)")
@click.option("--image-tag", default=None, help="Image tag to run (default: latest)")
@click.option("--simulation-timeout", default=None, type=int, help="Timeout per sim in seconds")
@click.option("--report", is_flag=True, help="Generate HTML report after evaluation")
@click.pass_context
def run(ctx, scenario_set_id, env_id, grader_id, image_tag, simulation_timeout, report):
    """Run the full pipeline: simulations → evaluations → report.

    In interactive mode (TTY), prompts for each step.
    In CI mode, pass all flags and get markdown summary to stdout.

    \b
    Examples:
      veris run                                    # interactive
      veris run --scenario-set-id X --grader-id Y  # CI
      veris run --report                           # include HTML report
    """
    from veris_cli.run_output import format_markdown_summary

    profile = get_profile(ctx)
    is_tty = sys.stdin.isatty()

    # Resolve env_id
    env_id = env_id or resolve_env_id(profile, None)

    try:
        api = VerisAPI(profile=profile)
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)

    # Resolve scenario_set_id
    if not scenario_set_id:
        if not is_tty:
            click.echo("Error: Pass --scenario-set-id for non-interactive mode.", err=True)
            sys.exit(1)

        click.echo("Fetching scenario sets...", err=True)
        sets = api.list_scenario_sets(environment_id=env_id)
        if not sets:
            output.print_error("No scenario sets found for this environment.")
            sys.exit(1)

        choices = [
            {
                "id": s["id"],
                "title": f"{s.get('title', '')} ({s['id']}) — {s.get('scenario_count', '?')} scenarios",
            }
            for s in sets
        ]
        scenario_set_id = prompts.select_from_list(
            "Select a scenario set:", choices, flag_hint="--scenario-set-id"
        )
        if not scenario_set_id:
            output.print_error("No scenario set selected")
            sys.exit(1)

    # Resolve grader — auto-select the one mapped to the scenario set
    if not grader_id:
        graders_resp = api.list_graders(env_id, scenario_set_id=scenario_set_id)
        graders = graders_resp.get("graders", [])
        # Find grader matching the scenario set
        matched = [g for g in graders if g.get("scenario_set_id") == scenario_set_id]
        if matched:
            grader_id = matched[0]["id"]
            click.echo(f"Auto-selected grader {grader_id} (mapped to {scenario_set_id})", err=True)
        elif is_tty:
            grader_id = select_grader_interactive(api, env_id, scenario_set_id)
        elif graders:
            grader_id = graders[0]["id"]
        else:
            click.echo("Error: No grader found for this environment/scenario set.", err=True)
            sys.exit(1)

    # Resolve report flag
    if is_tty and not report:
        from veris_cli.prompts import confirm_action

        report = confirm_action("Generate HTML report?", default=True, flag_hint="--report")

    # Build run config
    run_config = {}
    if image_tag:
        run_config["image_tag"] = image_tag
    if simulation_timeout:
        run_config["simulation_timeout"] = simulation_timeout

    # Step 1: Create simulation run
    click.echo(
        f"Creating simulation run (scenario_set={scenario_set_id})...",
        err=True,
    )
    try:
        run_data = api.create_run(
            scenario_set_id=scenario_set_id,
            environment_id=env_id,
            config=run_config if run_config else None,
        )
    except Exception as e:
        click.echo(f"Error: Failed to create simulation run: {e}", err=True)
        sys.exit(1)

    run_id = run_data["id"]
    console_url = get_console_url(profile)
    click.echo(f"Simulation run {run_id}: created", err=True)
    click.echo(f"→ {console_url}/simulations/{run_id}", err=True)

    # Step 2: Poll simulation run with status panel
    from rich.live import Live

    try:
        with Live(console=output.console, refresh_per_second=1) as live:
            while True:
                run_data = api.get_run(run_id)
                live.update(output.build_simulation_status_panel(run_data))

                status = run_data.get("status", "")
                if status in ("completed", "failed", "cancelled"):
                    break

                time.sleep(3)
    except KeyboardInterrupt:
        output.print_info("\nStopped.")
        sys.exit(1)

    run_failed = run_data["status"] == "failed"
    if run_failed:
        click.echo(
            f"Simulation run {run_id}: failed — {run_data.get('error_message', 'unknown error')}",
            err=True,
        )
        if run_data.get("completed_simulations", 0) == 0:
            sys.exit(1)
        click.echo("Some simulations completed — continuing to evaluation...", err=True)
    elif run_data["status"] == "cancelled":
        click.echo(f"Simulation run {run_id}: cancelled", err=True)
        sys.exit(1)

    # Step 3: Trigger evaluation
    click.echo(f"Using grader {grader_id}", err=True)
    click.echo("Triggering evaluation...", err=True)
    try:
        eval_resp = api.trigger_evaluation(run_id, grader_id)
    except Exception as e:
        click.echo(f"Error: Failed to trigger evaluation: {e}", err=True)
        sys.exit(1)

    eval_run_id = eval_resp["evaluation_run_id"]
    click.echo(f"Evaluation {eval_run_id}: started", err=True)
    click.echo(f"→ {console_url}/evaluations/{run_id}/{eval_run_id}", err=True)

    # Step 4: Poll evaluation with status panel
    try:
        with Live(console=output.console, refresh_per_second=1) as live:
            while True:
                eval_run = api.get_evaluation_run(run_id, eval_run_id)
                live.update(output.build_evaluation_status_panel(eval_run))

                status = eval_run.get("status", "")
                if status in ("completed", "failed"):
                    break

                time.sleep(5)
    except KeyboardInterrupt:
        output.print_info("\nStopped.")
        sys.exit(1)

    if eval_run["status"] == "failed":
        click.echo(f"Evaluation {eval_run_id}: failed", err=True)

    # Step 5: Fetch supplementary data and output markdown
    try:
        scenario_set = api.get_scenario_set(scenario_set_id)
        sims_resp = api.list_run_simulations(run_id)
    except Exception as e:
        click.echo(f"Error: Failed to fetch data: {e}", err=True)
        sys.exit(1)

    simulations = sims_resp.get("simulations", [])
    md = format_markdown_summary(run_data, scenario_set, simulations, eval_run)
    click.echo(md)

    # Step 6: Generate report if requested
    if report:
        click.echo("Generating report...", err=True)
        try:
            report_resp = api.generate_report(
                environment_id=env_id,
                evaluation_run_id=eval_run_id,
            )
            report_id = report_resp.get("report_id", "")
            click.echo(f"Report {report_id}: generating...", err=True)
            click.echo(f"→ {console_url}/reports/{report_id}", err=True)

            # Poll report with status panel
            try:
                with Live(console=output.console, refresh_per_second=1) as live:
                    while True:
                        report_data = api.get_report(report_id)
                        live.update(output.build_report_status_panel(report_data))

                        status = report_data.get("status", "")
                        if status == "completed":
                            break
                        elif status == "failed":
                            break
                        time.sleep(5)
            except KeyboardInterrupt:
                output.print_info("\nStopped.")
                sys.exit(1)

            if report_data.get("status") == "completed":
                click.echo(f"✓ Report ready: {report_id}", err=True)
                click.echo(f"  → veris reports get {report_id} -o results.html", err=True)
            else:
                click.echo(f"✗ Report generation failed: {report_id}", err=True)
        except Exception as e:
            click.echo(f"Error: Failed to generate report: {e}", err=True)

    # Exit non-zero if run or evaluation failed
    if run_failed or eval_run.get("status") == "failed":
        sys.exit(1)
