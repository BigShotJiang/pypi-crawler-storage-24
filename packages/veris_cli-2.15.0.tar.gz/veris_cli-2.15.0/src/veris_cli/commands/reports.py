"""Report commands: create, status, list, get."""

import sys
import time
from pathlib import Path

import click

from veris_cli import output
from veris_cli.api import VerisAPI
from veris_cli.commands._helpers import get_console_url, get_profile, resolve_env_id


@click.group()
def reports():
    """Report management commands."""
    pass


@reports.command(name="create")
@click.argument("sim_run_id", required=False, default=None)
@click.option(
    "--eval-run-id", default=None, help="Evaluation run ID (defaults to most recent completed)"
)
@click.pass_context
def reports_create(ctx, sim_run_id: str, eval_run_id: str):
    """Trigger report generation for a simulation run."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        # TODO: Backend needs run_id on Report model.
        # For now, fall back to env_id-based report creation.
        env_id = None
        if not sim_run_id:
            env_id = resolve_env_id(profile, None)
        else:
            # Get env_id from the run
            run_data = api.get_run(sim_run_id)
            env_id = run_data.get("environment_id")

        if not env_id:
            output.print_error("Could not determine environment for report")
            sys.exit(1)

        output.print_info(f"Generating report for environment {env_id}...")
        result = api.generate_report(
            environment_id=env_id,
            evaluation_run_id=eval_run_id,
        )

        report_id = result.get("report_id", "")
        console_url = get_console_url(profile)
        output.print_success(f"Report generation started: {report_id}")
        output.print_info(f"→ {console_url}/reports/{report_id}")
        output.print_info(f"→ Next: veris reports status {report_id} --watch")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to generate report: {e}")
        sys.exit(1)


@reports.command(name="status")
@click.argument("report_id")
@click.option("--watch", is_flag=True, help="Poll every 5 seconds until complete")
@click.pass_context
def reports_status(ctx, report_id: str, watch: bool):
    """Get report generation status."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if watch:
            from rich.live import Live

            try:
                with Live(console=output.console, refresh_per_second=1) as live:
                    while True:
                        report_data = api.get_report(report_id)
                        live.update(output.build_report_status_panel(report_data))

                        status = report_data.get("status", "")
                        if status in ["completed", "failed"]:
                            break

                        time.sleep(5)
            except KeyboardInterrupt:
                output.print_info("\nStopped watching.")
                return

            report_data = api.get_report(report_id)
            output.print_report_details(report_data)
            output.print_info(f"\n→ {get_console_url(profile)}/reports/{report_id}")
            if report_data.get("status") == "completed":
                output.print_info(f"→ Next: veris reports get {report_id} -o results.html")
        else:
            report_data = api.get_report(report_id)
            output.print_report_details(report_data)
            output.print_info(f"\n→ {get_console_url(profile)}/reports/{report_id}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get report status: {e}")
        sys.exit(1)


@reports.command(name="list")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def reports_list(ctx, env_id: str):
    """List reports for an environment."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        env_id = resolve_env_id(profile, env_id)
        result = api.list_reports(environment_id=env_id)
        output.print_reports_table(result.get("reports", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list reports: {e}")
        sys.exit(1)


@reports.command(name="get")
@click.argument("report_id")
@click.option(
    "-o", "--output-file", default=None, help="Output file path (default: report-<id>.html)"
)
@click.pass_context
def reports_get(ctx, report_id: str, output_file: str):
    """Download report as HTML file."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        report_data = api.get_report(report_id)

        status = report_data.get("status", "")
        if status != "completed":
            output.print_error(
                f"Report is not completed (status: {status}). Wait for completion first."
            )
            sys.exit(1)

        html_content = report_data.get("html_content")
        if not html_content:
            output.print_error("Report has no content.")
            sys.exit(1)

        if not output_file:
            output_file = f"report-{report_id}.html"

        Path(output_file).write_text(html_content)
        output.print_success(f"Report saved to {output_file}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to download report: {e}")
        sys.exit(1)
