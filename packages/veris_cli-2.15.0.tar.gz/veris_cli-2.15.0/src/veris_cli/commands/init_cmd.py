"""Init command — local scaffold only, no backend call."""

from pathlib import Path

import click

from veris_cli import output, templates


@click.command()
def init():
    """Scaffold .veris/ directory with template files.

    Creates Dockerfile.sandbox, veris.yaml, and .dockerignore templates.
    Does NOT create a backend environment — use 'veris env create' for that.
    """
    veris_dir = Path.cwd() / ".veris"
    veris_dir.mkdir(parents=True, exist_ok=True)

    created_files = []

    dockerfile_path = veris_dir / "Dockerfile.sandbox"
    if not dockerfile_path.exists():
        dockerfile_path.write_text(templates.get_dockerfile_sandbox())
        created_files.append("  - .veris/Dockerfile.sandbox - Docker image template")
    else:
        output.print_info("Skipping .veris/Dockerfile.sandbox (already exists)")

    veris_yaml_path = veris_dir / "veris.yaml"
    if not veris_yaml_path.exists():
        veris_yaml_path.write_text(templates.get_veris_yaml())
        created_files.append("  - .veris/veris.yaml - Simulation configuration")
    else:
        output.print_info("Skipping .veris/veris.yaml (already exists)")

    dockerignore_path = veris_dir / ".dockerignore"
    if not dockerignore_path.exists():
        dockerignore_path.write_text(templates.get_dockerignore())
        created_files.append(
            "  - .veris/.dockerignore - Build context exclusions for `veris env push`"
        )
    else:
        output.print_info("Skipping .veris/.dockerignore (already exists)")

    if created_files:
        output.print_success("Environment initiated.")
        output.print_info("Created files:")
        for file in created_files:
            output.print_info(file)

    output.print_info("\nNext steps:")
    output.print_info("  1. Edit .veris/Dockerfile.sandbox to match your agent")
    output.print_info("  2. Edit .veris/veris.yaml with your agent settings")
    output.print_info("  3. Run 'veris env create --name my-agent' to register on backend")
