"""Profile management commands: list, get, use, delete."""

import sys

import click

from veris_cli import output
from veris_cli.commands._helpers import get_profile
from veris_cli.config import Config


@click.group()
def profile():
    """Manage named profiles for different environments."""
    pass


@profile.command(name="list")
def profile_list():
    """List all profiles in global config."""
    config = Config()
    profiles = config.list_profiles()
    active = config.get_active_profile() or "default"

    if not profiles:
        output.print_info("No profiles configured. Run 'veris login' to create one.")
        return

    for name in profiles:
        marker = " (active)" if name == active else ""
        output.print_info(f"  {name}{marker}")


@profile.command(name="get")
@click.pass_context
def profile_get(ctx):
    """Show active profile's settings."""
    from veris_cli.config import ProjectConfig

    profile_name = get_profile(ctx)
    config = Config(profile=profile_name)
    project_config = ProjectConfig(profile=profile_name)

    output.print_info(f"Profile: {config.profile}")

    global_data = config._load_profile()
    if global_data:
        output.print_info("\nGlobal settings (~/.veris/config.yaml):")
        for k, v in global_data.items():
            display_v = v
            if k == "api_key" and v:
                display_v = v[:8] + "..." if len(v) > 8 else v
            output.print_info(f"  {k}: {display_v}")
    else:
        output.print_info("\nNo global settings for this profile.")

    project_data = project_config._load_profile()
    if project_data:
        output.print_info("\nProject settings (.veris/config.yaml):")
        for k, v in project_data.items():
            output.print_info(f"  {k}: {v}")


@profile.command(name="use")
@click.argument("name", required=False, default=None)
@click.option("--org", default=None, help="Organization ID to set for the profile")
@click.pass_context
def profile_use(ctx, name: str | None, org: str | None):
    """Set active profile and organization.

    Without arguments, interactively prompts for profile and org.
    """
    config = Config()
    profiles = config.list_profiles()

    if not name:
        if not profiles:
            output.print_error("No profiles configured. Run 'veris login' to create one.")
            sys.exit(1)

        from veris_cli import prompts

        choices = [{"id": p, "title": p} for p in profiles]
        name = prompts.select_from_list("Select a profile:", choices, flag_hint="NAME")
        if not name:
            output.print_error("No profile selected")
            sys.exit(1)

    if profiles and name not in profiles:
        output.print_error(f"Profile '{name}' does not exist.")
        output.print_info(f"Available profiles: {', '.join(profiles)}")
        sys.exit(1)

    config.set_active_profile(name)
    output.print_success(f"Active profile set to '{name}'")

    if org:
        config_with_profile = Config(profile=name)
        config_with_profile.set_organization_id(org)
        output.print_success(f"Organization set to '{org}'")


@profile.command(name="delete")
@click.argument("name")
def profile_delete(name: str):
    """Remove a profile from global config."""
    if name == "default":
        output.print_error("Cannot delete the default profile.")
        sys.exit(1)

    config = Config()
    if config.delete_profile(name):
        output.print_success(f"Profile '{name}' deleted")
    else:
        output.print_error(f"Profile '{name}' not found")
        sys.exit(1)
