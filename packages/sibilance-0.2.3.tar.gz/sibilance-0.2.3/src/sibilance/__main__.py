"""Entry point for `python -m sibilance` or the `sibilance` CLI command."""

import sys


def main() -> None:
    replay = "--replay-hatching" in sys.argv

    from sibilance.app import SibilanceApp

    app = SibilanceApp(replay_hatching=replay)
    app.run()


if __name__ == "__main__":
    main()
