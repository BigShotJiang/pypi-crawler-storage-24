import os.path

if config.system_source_config["db-driver"] == "postgres":
    directory = os.path.dirname(__file__)

    with open(os.path.join(directory, "table.sql")) as fobj:
        sql(fobj.read())
    with open(os.path.join(directory, "ddl.sql")) as fobj:
        sql(fobj.read())
