from typing import Optional, Tuple, Type

from pydantic import Field, create_model
from sqlmodel import SQLModel


def generate_crud_models(model: Type[SQLModel]) -> Tuple[Type[SQLModel], Type[SQLModel], Type[SQLModel]]:
    """Generates Pydantic models for Create, Update, and Patch operations.

    Args:
        model (Type[SQLModel]): The source SQLModel class.

    Returns:
        Tuple[Type[SQLModel], Type[SQLModel], Type[SQLModel]]: A tuple containing (CreateModel, UpdateModel, PatchModel).
    """
    model_fields = model.model_fields

    # Exclude fields named "id" and preserve field constraints
    create_fields = {
        name: (field.annotation, field)
        for name, field in model_fields.items()
        if name != "id"
    }

    CreateModel = create_model(f"{model.__name__}Create", __base__=SQLModel, **create_fields)

    # Update fields (PUT) - same as CreateModel but different name for clarity in docs
    update_fields = create_fields.copy()
    UpdateModel = create_model(f"{model.__name__}Update", __base__=SQLModel, **update_fields)

    # Patch fields (PATCH) - all non-"id" fields are optional
    patch_fields = {
        name: (Optional[field.annotation], Field(None))
        for name, field in model_fields.items()
        if name != "id"
    }
    PatchModel = create_model(f"{model.__name__}Patch", __base__=SQLModel, **patch_fields)

    return CreateModel, UpdateModel, PatchModel
