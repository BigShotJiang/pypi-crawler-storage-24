from typing import Any, List, Type

from fastapi import APIRouter, Body, HTTPException, Path, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import SQLModel, select
from strawberry.fastapi import GraphQLRouter

from autoendpoint.graphql_utils import generate_graphql_schema
from autoendpoint.models import generate_crud_models
from autoendpoint.utils import is_primary_key


class AutoEndpoint:
    """Automatic FastAPI endpoint generator for SQLModel models.

    This class takes a database session and a list of SQLModel models and automatically
    generates a set of CRUD (Create, Read, Update, Delete) endpoints for each model.
    The generated endpoints are registered to a FastAPI APIRouter.

    Attributes:
        _db_session (AsyncSession): The asynchronous database session.
        models (List[Type[SQLModel]]): A list of SQLModel classes to generate endpoints for.
        router (APIRouter): The FastAPI router containing the generated endpoints.
    """

    def __init__(self, db_session: AsyncSession, models: List[Type[SQLModel]], enable_graphql: bool = True):
        """Initializes the AutoEndpoint with a database session and models.

        Args:
            db_session (AsyncSession): The asynchronous SQLAlchemy/SQLModel session.
            models (List[Type[SQLModel]]): A list of SQLModel classes to be exposed via API.
            enable_graphql (bool): Whether to enable the GraphQL endpoint. Defaults to True.
        """
        self._db_session = db_session
        self.models = models
        self.enable_graphql = enable_graphql
        self.router = APIRouter()
        self._build_routes()

    def _build_routes(self):
        """Iterates through all models and registers their endpoints."""
        for model in self.models:
            self._register_model_endpoints(model=model)
        
        if self.enable_graphql:
            self._add_graphql_route()

    def _add_graphql_route(self):
        """Adds a dynamic GraphQL endpoint using Strawberry."""
        schema = generate_graphql_schema(models=self.models, db_session=self._db_session)
        graphql_app = GraphQLRouter(schema)
        self.router.include_router(graphql_app, prefix="/graphql", tags=["GraphQL"])

    def _register_model_endpoints(self, model: Type[SQLModel]):
        """Generates and registers CRUD endpoints for a specific SQLModel."""
        name = model.__name__.lower()
        model_fields = model.model_fields
        CreateModel, UpdateModel, PatchModel = generate_crud_models(model=model)
        pk_name = next((n for n, f in model_fields.items() if is_primary_key(field=f)), None)

        self._add_read_all_route(model=model, name=name)
        self._add_create_one_route(model=model, name=name, CreateModel=CreateModel)

        if pk_name:
            pk_type = model_fields[pk_name].annotation
            self._add_read_one_by_id_route(model=model, name=name, pk_name=pk_name, pk_type=pk_type)
            self._add_update_one_route(model=model, name=name, pk_name=pk_name, pk_type=pk_type, UpdateModel=UpdateModel)
            self._add_patch_one_route(model=model, name=name, pk_name=pk_name, pk_type=pk_type, PatchModel=PatchModel)
            self._add_delete_one_route(model=model, name=name, pk_name=pk_name, pk_type=pk_type)

        self._add_read_one_by_unique_field_route(model=model, name=name, model_fields=model_fields)
        self._add_read_by_field_route(model=model, name=name, model_fields=model_fields)

    def _add_read_all_route(self, model: Type[SQLModel], name: str):
        @self.router.get(f"/{name}",
                         response_model=List[model],
                         tags=[model.__name__],
                         description=f"Retrieve all {model.__name__} records",
                         summary=f"Retrieve all {model.__name__}")
        async def read_all():
            results = await self._db_session.execute(select(model))
            return results.scalars().all()

    def _add_create_one_route(self, model: Type[SQLModel], name: str, CreateModel: Type[SQLModel]):
        @self.router.post(f"/{name}",
                         response_model=model,
                         tags=[model.__name__],
                         description=f"Create a new {model.__name__} record",
                         summary=f"Create {model.__name__}")
        async def create_one(item: CreateModel = Body(..., description=f"The {model.__name__} data to create")):
            db_item = model(**item.model_dump())
            self._db_session.add(db_item)
            await self._db_session.commit()
            await self._db_session.refresh(db_item)
            return db_item

    def _add_read_one_by_id_route(self, model: Type[SQLModel], name: str, pk_name: str, pk_type: Type):
        @self.router.get(f"/{name}/{{{pk_name}}}",
                         response_model=model,
                         tags=[model.__name__],
                         description=f"Retrieve a {model.__name__} record by {pk_name}",
                         summary=f"Retrieve {model.__name__} by {pk_name}")
        async def read_one_by_id(pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to retrieve by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            records = results.scalars().all()
            if not records:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            if len(records) > 1:
                raise HTTPException(status_code=400, detail=f"Multiple {model.__name__} records found for {pk_name}={pk_value}")
            return records[0]

    def _add_update_one_route(self, model: Type[SQLModel], name: str, pk_name: str, pk_type: Type, UpdateModel: Type[SQLModel]):
        @self.router.put(f"/{name}/{{{pk_name}}}",
                         response_model=model,
                         tags=[model.__name__],
                         description=f"Update a {model.__name__} record by {pk_name}",
                         summary=f"Update {model.__name__} by {pk_name}")
        async def update_one(item: UpdateModel = Body(..., description=f"The {model.__name__} data to update"), 
                             pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to update by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            update_data = item.model_dump(exclude_unset=False)
            for key, value in update_data.items():
                setattr(db_item, key, value)
            
            self._db_session.add(db_item)
            await self._db_session.commit()
            await self._db_session.refresh(db_item)
            return db_item

    def _add_patch_one_route(self, model: Type[SQLModel], name: str, pk_name: str, pk_type: Type, PatchModel: Type[SQLModel]):
        @self.router.patch(f"/{name}/{{{pk_name}}}",
                           response_model=model,
                           tags=[model.__name__],
                           description=f"Partially update a {model.__name__} record by {pk_name}",
                           summary=f"Patch {model.__name__} by {pk_name}")
        async def patch_one(item: PatchModel = Body(..., description=f"The {model.__name__} data to patch"), 
                            pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to patch by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            update_data = item.model_dump(exclude_unset=True)
            for key, value in update_data.items():
                setattr(db_item, key, value)
            
            self._db_session.add(db_item)
            await self._db_session.commit()
            await self._db_session.refresh(db_item)
            return db_item

    def _add_delete_one_route(self, model: Type[SQLModel], name: str, pk_name: str, pk_type: Type):
        @self.router.delete(f"/{name}/{{{pk_name}}}",
                            tags=[model.__name__],
                            description=f"Delete a {model.__name__} record by {pk_name}",
                            summary=f"Delete {model.__name__} by {pk_name}")
        async def delete_one(pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to delete by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            await self._db_session.delete(db_item)
            await self._db_session.commit()
            return {"detail": f"{model.__name__} deleted"}

    def _add_read_one_by_unique_field_route(self, model: Type[SQLModel], name: str, model_fields: dict):
        @self.router.get(f"/{name}/unique/{{field_name}}",
                         response_model=model,
                         tags=[model.__name__],
                         description=f"Retrieve a {model.__name__} record by a unique field and value",
                         summary=f"Retrieve {model.__name__} by unique field")
        async def read_one_by_unique_field(
            field_name: str = Path(..., description="The name of the unique field to search by"), 
            value: Any = Query(..., description="The value of the unique field to search for")
        ):
            if field_name not in model_fields:
                raise HTTPException(status_code=400, detail=f"Field '{field_name}' not found in {model.__name__}")

            results = await self._db_session.execute(select(model).where(getattr(model, field_name) == value))
            records = results.scalars().all()

            if not records:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            if len(records) > 1:
                raise HTTPException(status_code=400, detail=f"Multiple {model.__name__} records found for {field_name}={value}")
            return records[0]

    def _add_read_by_field_route(self, model: Type[SQLModel], name: str, model_fields: dict):
        @self.router.get(f"/{name}/filter/{{field_name}}",
                         response_model=List[model],
                         tags=[model.__name__],
                         description=f"Retrieve {model.__name__} records by a field and value",
                         summary=f"Retrieve {model.__name__} by field")
        async def read_by_field(
            field_name: str = Path(..., description="The name of the field to filter by"), 
            value: Any = Query(..., description="The value of the field to filter for")
        ):
            if field_name not in model_fields:
                raise HTTPException(status_code=400, detail=f"Field '{field_name}' not found in {model.__name__}")

            results = await self._db_session.execute(select(model).where(getattr(model, field_name) == value))
            return results.scalars().all()


    def init_app(self, app):
        """Includes the generated router into a FastAPI application.

        Args:
            app: The FastAPI application instance.
        """
        app.include_router(self.router)
