from typing import List, Type

import strawberry
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import SQLModel, select


def generate_graphql_schema(models: List[Type[SQLModel]], db_session: AsyncSession) -> strawberry.Schema:
    """Dynamically generates a Strawberry GraphQL schema for the given SQLModels.

    Args:
        models: A list of SQLModel classes to include in the schema.
        db_session: The asynchronous database session to use for queries.

    Returns:
        A Strawberry Schema object.
    """
    
    query_fields = {}

    for model in models:
        # Create a Strawberry type from the SQLModel
        @strawberry.experimental.pydantic.type(model=model, all_fields=True)
        class ModelType:
            @strawberry.field
            def string_representation(self, root: model) -> str:
                return str(root)
        
        # Define a closure for the resolver
        def make_resolver(m=model):
            async def resolve(self) -> List[ModelType]:
                results = await db_session.execute(select(m))
                return results.scalars().all()
            return resolve
            
        # Add to query fields. Strawberry converts snake_case to camelCase by default.
        query_fields[f"list_{model.__name__.lower()}"] = strawberry.field(resolver=make_resolver(model))
        
    DynamicQuery = type("Query", (object,), query_fields)
    DynamicQuery = strawberry.type(DynamicQuery)
    
    return strawberry.Schema(query=DynamicQuery)
