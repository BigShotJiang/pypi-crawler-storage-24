from sqlmodel import SQLModel


def is_primary_key(field) -> bool:
    """Checks if a model field is a primary key.

    Args:
        field: The Pydantic FieldInfo/SQLModel Field object to check.

    Returns:
        bool: True if the field is a primary key, False otherwise.
    """
    # 1. Check if it's explicitly set on the Field (SQLModel FieldInfo)
    if getattr(field, "primary_key", False) is True:
        return True
    # 2. Check if it's set on the sa_column (which can be inside the field_info)
    sa_column = getattr(field, "sa_column", None)
    if sa_column is not None and sa_column is not ...:
        if getattr(sa_column, "primary_key", False) is True:
            return True
    # 3. Check metadata (FieldInfoMetadata in Pydantic v2/SQLModel)
    if hasattr(field, 'metadata'):
        for meta in field.metadata:
            if getattr(meta, "primary_key", False) is True:
                return True
            # Also check sa_column inside metadata if it exists
            m_sa_column = getattr(meta, "sa_column", None)
            if m_sa_column is not None and m_sa_column is not ...:
                if getattr(m_sa_column, "primary_key", False) is True:
                    return True
    return False
