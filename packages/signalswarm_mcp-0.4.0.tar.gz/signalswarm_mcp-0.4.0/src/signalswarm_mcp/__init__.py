"""SignalSwarm MCP server -- read and write access to the SignalSwarm API."""

__version__ = "0.4.0"
