# Mesh

**Architectural coherence layer for AI-generated codebases**

Mesh ensures AI-generated code follows your codebase's architecture. It detects duplicate functions, circular dependencies, naming violations, and data flow issues before they enter your codebase.

## Quickstart

**Two steps. Everything else is automatic.**

### Step 1 — Install Mesh

```bash
pip install mesh-ai
```

### Step 2 — Set up in your project

```bash
cd your-project
mesh setup
```

The setup wizard will:
- Analyse your codebase
- Check for Ollama (install guide if needed)
- Show all your installed AI models with compatibility ratings
- Register Mesh with Cursor and Claude Code automatically

### That's it

Open Cursor or Claude Code. Every AI coding session now automatically receives your codebase's architectural context.

The AI will never create duplicate functions, never introduce circular dependencies, and always follow your naming conventions.

---

**Don't have a model yet?**

```bash
ollama pull qwen3.5:9b   # recommended (6.6GB)
ollama pull qwen3.5:4b   # smaller option (3.4GB)
```

Then run `mesh setup` again.

## Commands

| Command | Description |
|---------|-------------|
| `mesh init` | Analyse codebase and build graphs |
| `mesh setup` | Run interactive setup wizard |
| `mesh serve` | Start MCP server for AI coding tools |
| `mesh check` | Check for code violations |
| `mesh doctor` | Comprehensive health check |
| `mesh model list` | List installed Ollama models |
| `mesh model select <name>` | Select a specific model |
| `mesh model status` | Show configured model status |
| `mesh model test` | Test model with sample prompt |
| `mesh install-hook` | Install git pre-commit hook |

## Architecture

Mesh works in three layers:

1. **Analysis (Phase 1)** — Builds call graphs, data flow graphs, and type dependency graphs
2. **Enforcement (Phase 2)** — Git hooks and CI checks that block incoherent code
3. **Context Injection (Phase 3/4.5)** — MCP server that injects architectural context into AI sessions

## Requirements

- Python 3.10+
- Ollama (for AI model inference)
- Git (for pre-commit hooks)

## Development

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Run linting
black mesh/ tests/
mypy mesh/
ruff check mesh/
```

## License

MIT
