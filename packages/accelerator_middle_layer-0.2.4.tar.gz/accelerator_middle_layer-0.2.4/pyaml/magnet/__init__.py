"""
PyAML Magnet module
"""
