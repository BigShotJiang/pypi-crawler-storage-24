"""Sync engine for GreyMatter distributed mode.

Provides change tracking, full sync, delta sync, conflict resolution,
and a background scheduler for continuous synchronization between
Solo (SQLite) and Distributed (CockroachDB) nodes.
"""

# Core tables that always participate in sync
SYNC_TABLES = [
    "patterns",
    "pattern_evidence",
    "knowledge_entries",
    "work_items",
    "sessions",
    "observations",
    "documents",
]

# SalesOS tables eligible for sync (added via migration 002)
SALESOS_SYNC_TABLES = [
    "salesos_accounts",
    "salesos_contacts",
    "salesos_hunting_list",
    "salesos_meddpicc_scores",
    "salesos_research_docs",
    "salesos_snapshots",
    "salesos_trigger_alerts",
    "deal_forecasts",
    "proposals",
]


def get_all_sync_tables() -> list[str]:
    """Return all sync-eligible tables (core + SalesOS)."""
    return SYNC_TABLES + SALESOS_SYNC_TABLES
