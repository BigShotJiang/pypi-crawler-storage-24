"""Context retrieval engine for GreyMatter.

Builds optimized context payloads for agents by combining quality standards,
recent documents, and active patterns. Tracks what context gets served
for self-optimization.
"""
import json
from typing import Any

from .db import Database
from .documents import DocumentStore
from .standards import StandardsManager
from .patterns import PatternManager


class ContextEngine:
    """Builds optimized context payloads for any consumer."""

    def __init__(
        self,
        db: Database,
        doc_store: DocumentStore,
        standards: StandardsManager,
        patterns: PatternManager,
    ) -> None:
        self.db = db
        self.doc_store = doc_store
        self.standards = standards
        self.patterns = patterns

    def build_session_context(
        self,
        project: str | None = None,
        max_tokens: int = 4000,
    ) -> dict[str, Any]:
        """Build optimized context payload for an agent."""
        quality_payload = self.standards.get_context_payload()
        quality_tokens = len(quality_payload) // 4
        remaining = max_tokens - quality_tokens

        recent_docs = self.doc_store.get_context(
            project=project, max_tokens=max(remaining - 500, 0)
        )

        active_patterns = self.patterns.get_for_session_load(max_count=10)

        return {
            "quality_standards": quality_payload,
            "recent_context": recent_docs,
            "active_patterns": active_patterns,
        }

    def record_request(
        self,
        session_id: str,
        query: str,
        doc_ids: list[str],
        tokens: int,
    ) -> None:
        """Record a context request for tracking and self-optimization."""
        self.db.execute(
            """INSERT INTO context_requests
               (session_id, query, documents_served, tokens_served)
               VALUES (?, ?, ?, ?)""",
            (session_id, query, json.dumps(doc_ids), tokens),
        )

    def evaluate_relevance(self, request_id: int, score: float) -> None:
        """Record a relevance score for a previously served context request."""
        self.db.execute(
            "UPDATE context_requests SET relevance_score = ? WHERE id = ?",
            (score, request_id),
        )
