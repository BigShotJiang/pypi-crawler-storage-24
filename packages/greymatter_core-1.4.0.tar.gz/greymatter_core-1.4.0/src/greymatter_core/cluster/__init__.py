"""Cluster management for GreyMatter distributed mode.

Handles node lifecycle: Solo → Joining → Spoke → Leaving → Solo.
Manages discovery, certificates, join/leave protocols, and health monitoring.
"""
