"""Cognitive schema: observations, observation sessions, knowledge (cognitive layer).

These tables power the neuroscience-grounded memory system (FSRS-6 decay,
retroactive interference, cross-session consolidation).
"""

SQLITE_DDL = """
CREATE TABLE IF NOT EXISTS observations (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    trigger TEXT NOT NULL,
    category TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    raw_context TEXT,
    confidence REAL DEFAULT 0.5,
    stability_days REAL DEFAULT 45,
    last_confirmed_at TEXT,
    token_count INTEGER DEFAULT 0,
    context_usage_pct REAL DEFAULT 0.0,
    knowledge_id TEXT,
    pattern_id TEXT,
    source_tool TEXT DEFAULT '',
    domains TEXT DEFAULT '',
    invalidated_by TEXT,
    pruned INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_observations_session ON observations(session_id);
CREATE INDEX IF NOT EXISTS idx_observations_category ON observations(category);
CREATE INDEX IF NOT EXISTS idx_observations_confidence ON observations(confidence);
CREATE INDEX IF NOT EXISTS idx_observations_pruned ON observations(pruned);

CREATE TABLE IF NOT EXISTS observation_sessions (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    trigger TEXT NOT NULL,
    context_usage_pct REAL DEFAULT 0.0,
    observations_extracted INTEGER DEFAULT 0,
    observations_deduplicated INTEGER DEFAULT 0,
    observations_stored INTEGER DEFAULT 0,
    extraction_method TEXT DEFAULT '',
    extraction_time_ms INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS knowledge (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL DEFAULT 'reference',
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    domain TEXT DEFAULT 'general',
    applications INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);
"""

CRDB_DDL = """
CREATE TABLE IF NOT EXISTS observations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id TEXT NOT NULL,
    trigger TEXT NOT NULL,
    category TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    raw_context TEXT,
    confidence DECIMAL(5,4) DEFAULT 0.5,
    stability_days DECIMAL(8,2) DEFAULT 45,
    last_confirmed_at TIMESTAMPTZ,
    token_count INT DEFAULT 0,
    context_usage_pct DECIMAL(5,2) DEFAULT 0.0,
    knowledge_id TEXT,
    pattern_id TEXT,
    source_tool TEXT DEFAULT '',
    domains TEXT DEFAULT '',
    invalidated_by TEXT,
    pruned INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_observations_session ON observations(session_id);
CREATE INDEX IF NOT EXISTS idx_observations_category ON observations(category);
CREATE INDEX IF NOT EXISTS idx_observations_confidence ON observations(confidence);
CREATE INDEX IF NOT EXISTS idx_observations_pruned ON observations(pruned);
CREATE INDEX IF NOT EXISTS idx_observations_source ON observations(source_tool);
CREATE INDEX IF NOT EXISTS idx_observations_created ON observations(created_at);

CREATE TABLE IF NOT EXISTS observation_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id TEXT NOT NULL UNIQUE,
    transcript_path TEXT,
    observations_extracted INT DEFAULT 0,
    processed_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS observation_domains (
    observation_id UUID NOT NULL,
    domain TEXT NOT NULL,
    PRIMARY KEY (observation_id, domain),
    CONSTRAINT fk_observation_domains_obs
        FOREIGN KEY (observation_id) REFERENCES observations(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_observation_domains_obs ON observation_domains(observation_id);
CREATE INDEX IF NOT EXISTS idx_observation_domains_domain ON observation_domains(domain);

CREATE TABLE IF NOT EXISTS knowledge (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type TEXT NOT NULL DEFAULT 'reference',
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    domain TEXT DEFAULT 'general',
    applications INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);
"""


def get_sqlite_ddl() -> str:
    return SQLITE_DDL


def get_crdb_ddl() -> str:
    return CRDB_DDL
