"""Unified schema module for GreyMatter.

Provides both SQLite and CockroachDB DDL for all table groups.
Each submodule covers one logical domain and exposes get_sqlite_ddl()
and get_crdb_ddl() functions.

Usage:
    from greymatter_core.schema import get_full_sqlite_schema, get_full_crdb_schema
    ddl = get_full_sqlite_schema()   # for Solo mode
    ddl = get_full_crdb_schema()     # for Distributed mode
"""
from __future__ import annotations

from typing import Callable

SCHEMA_VERSION = "1.0"

# Lazy imports to avoid circular deps — modules register on first access
_modules: list[tuple[str, Callable[[], str], Callable[[], str]]] = []


def _ensure_loaded() -> None:
    """Load all schema submodules on first access."""
    if _modules:
        return
    from . import core, cognitive, distributed, salesos, twin
    _modules.extend([
        ("core", core.get_sqlite_ddl, core.get_crdb_ddl),
        ("cognitive", cognitive.get_sqlite_ddl, cognitive.get_crdb_ddl),
        ("distributed", distributed.get_sqlite_ddl, distributed.get_crdb_ddl),
        ("salesos", salesos.get_sqlite_ddl, salesos.get_crdb_ddl),
        ("twin", twin.get_sqlite_ddl, twin.get_crdb_ddl),
    ])


def get_full_sqlite_schema() -> str:
    """Return combined SQLite DDL for all modules."""
    _ensure_loaded()
    parts = [f"-- Schema module: {name}" for name, _, _ in _modules]
    return "\n\n".join(
        f"-- Schema module: {name}\n{sqlite_fn()}"
        for name, sqlite_fn, _ in _modules
    )


def get_full_crdb_schema() -> str:
    """Return combined CockroachDB DDL for all modules."""
    _ensure_loaded()
    return "\n\n".join(
        f"-- Schema module: {name}\n{crdb_fn()}"
        for name, _, crdb_fn in _modules
    )


def get_module_names() -> list[str]:
    """Return list of registered schema module names."""
    _ensure_loaded()
    return [name for name, _, _ in _modules]
