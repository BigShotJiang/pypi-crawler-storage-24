"""Distributed schema: agents, workers, worktrees, work queue, API keys.

These tables only exist in distributed (cluster) deployments. Solo mode
does not create them.
"""

SQLITE_DDL = """
-- Distributed tables use TEXT IDs in SQLite for compatibility.
-- These are typically only created when running distributed tests.

CREATE TABLE IF NOT EXISTS agents (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    status TEXT DEFAULT 'idle',
    worktree_id TEXT,
    current_work_item TEXT,
    session_id TEXT,
    soul_variant TEXT NOT NULL,
    pid INTEGER,
    tmux_session TEXT,
    started_at TEXT,
    last_heartbeat TEXT,
    owned_domain TEXT,
    worker_node_id TEXT,
    worktree_path TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agent_capabilities (
    agent_id TEXT NOT NULL,
    capability TEXT NOT NULL,
    PRIMARY KEY (agent_id, capability),
    FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_tools (
    agent_id TEXT NOT NULL,
    tool TEXT NOT NULL,
    PRIMARY KEY (agent_id, tool),
    FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_task_stats (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    tasks_completed INTEGER DEFAULT 0,
    tasks_failed INTEGER DEFAULT 0,
    avg_completion_time_ms INTEGER DEFAULT 0,
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agent_souls (
    id TEXT PRIMARY KEY,
    variant TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agent_types (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    default_soul_variant TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS worktrees (
    id TEXT PRIMARY KEY,
    path TEXT NOT NULL,
    status TEXT DEFAULT 'available',
    assigned_agent TEXT,
    assigned_at TEXT,
    FOREIGN KEY (assigned_agent) REFERENCES agents(id)
);

CREATE TABLE IF NOT EXISTS review_assignments (
    id TEXT PRIMARY KEY,
    work_item_id TEXT NOT NULL,
    implementer_agent TEXT NOT NULL,
    reviewer_agent TEXT NOT NULL,
    review_type TEXT NOT NULL,
    assigned_at TEXT DEFAULT (datetime('now')),
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS work_queue (
    work_item_id TEXT PRIMARY KEY,
    queue_status TEXT NOT NULL,
    assigned_agent TEXT,
    assigned_at TEXT,
    blocking_item TEXT
);

CREATE TABLE IF NOT EXISTS work_sessions (
    id TEXT PRIMARY KEY,
    work_item_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    outcome TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS work_reviews (
    id TEXT PRIMARY KEY,
    work_item_id TEXT NOT NULL,
    review_type TEXT NOT NULL,
    status TEXT NOT NULL,
    session_id TEXT,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS work_item_files (
    id TEXT PRIMARY KEY,
    work_item_id TEXT NOT NULL,
    file_path TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS work_item_capabilities (
    work_item_id TEXT NOT NULL,
    capability TEXT NOT NULL,
    PRIMARY KEY (work_item_id, capability)
);

CREATE TABLE IF NOT EXISTS work_item_domain_tags (
    work_item_id TEXT NOT NULL,
    domain_tag TEXT NOT NULL,
    PRIMARY KEY (work_item_id, domain_tag)
);

CREATE TABLE IF NOT EXISTS worker_nodes (
    id TEXT PRIMARY KEY,
    hostname TEXT NOT NULL,
    ip_address TEXT NOT NULL,
    port INTEGER NOT NULL DEFAULT 8001,
    status TEXT NOT NULL DEFAULT 'online',
    last_heartbeat TEXT DEFAULT (datetime('now')),
    agent_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY,
    key_hash TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    last_used_at TEXT,
    revoked_at TEXT
);
"""

CRDB_DDL = """
CREATE TABLE IF NOT EXISTS agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type TEXT NOT NULL,
    status TEXT DEFAULT 'idle',
    worktree_id UUID,
    current_work_item UUID,
    session_id UUID,
    soul_variant TEXT NOT NULL,
    pid INT,
    tmux_session TEXT,
    started_at TIMESTAMPTZ,
    last_heartbeat TIMESTAMPTZ,
    owned_domain TEXT,
    worker_node_id UUID,
    worktree_path TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agent_capabilities (
    agent_id UUID NOT NULL,
    capability TEXT NOT NULL,
    PRIMARY KEY (agent_id, capability),
    CONSTRAINT fk_agent_capabilities_agent
        FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_tools (
    agent_id UUID NOT NULL,
    tool TEXT NOT NULL,
    PRIMARY KEY (agent_id, tool),
    CONSTRAINT fk_agent_tools_agent
        FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_task_stats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(id),
    tasks_completed INT DEFAULT 0,
    tasks_failed INT DEFAULT 0,
    avg_completion_time_ms INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agent_souls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    variant TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agent_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    default_soul_variant TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS worktrees (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    path TEXT NOT NULL,
    status TEXT DEFAULT 'available',
    assigned_agent UUID,
    assigned_at TIMESTAMPTZ,
    CONSTRAINT fk_worktrees_agent
        FOREIGN KEY (assigned_agent) REFERENCES agents(id)
);

CREATE TABLE IF NOT EXISTS review_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_item_id UUID NOT NULL,
    implementer_agent UUID NOT NULL,
    reviewer_agent UUID NOT NULL,
    review_type TEXT NOT NULL,
    assigned_at TIMESTAMPTZ DEFAULT now(),
    completed_at TIMESTAMPTZ,
    CONSTRAINT chk_different_agents
        CHECK (implementer_agent != reviewer_agent)
);

CREATE TABLE IF NOT EXISTS work_queue (
    work_item_id UUID PRIMARY KEY,
    queue_status TEXT NOT NULL,
    assigned_agent UUID,
    assigned_at TIMESTAMPTZ,
    blocking_item UUID,
    CONSTRAINT fk_work_queue_agent
        FOREIGN KEY (assigned_agent) REFERENCES agents(id)
);

CREATE TABLE IF NOT EXISTS work_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_item_id UUID NOT NULL,
    session_id UUID NOT NULL,
    outcome TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_item_id UUID NOT NULL,
    review_type TEXT NOT NULL,
    status TEXT NOT NULL,
    session_id UUID,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS work_item_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_item_id UUID NOT NULL,
    file_path TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS work_item_capabilities (
    work_item_id UUID NOT NULL,
    capability TEXT NOT NULL,
    PRIMARY KEY (work_item_id, capability)
);

CREATE TABLE IF NOT EXISTS work_item_domain_tags (
    work_item_id UUID NOT NULL,
    domain_tag TEXT NOT NULL,
    PRIMARY KEY (work_item_id, domain_tag)
);

CREATE TABLE IF NOT EXISTS worker_nodes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hostname TEXT NOT NULL,
    ip_address TEXT NOT NULL,
    port INT NOT NULL DEFAULT 8001,
    status TEXT NOT NULL DEFAULT 'online',
    last_heartbeat TIMESTAMPTZ DEFAULT now(),
    agent_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key_hash TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    last_used_at TIMESTAMPTZ,
    revoked_at TIMESTAMPTZ
);

-- Distributed indexes
CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status);
CREATE INDEX IF NOT EXISTS idx_agents_type ON agents(type);
CREATE INDEX IF NOT EXISTS idx_worktrees_status ON worktrees(status);
CREATE INDEX IF NOT EXISTS idx_worktrees_agent ON worktrees(assigned_agent);
CREATE INDEX IF NOT EXISTS idx_work_queue_status ON work_queue(queue_status);
CREATE INDEX IF NOT EXISTS idx_work_queue_agent ON work_queue(assigned_agent);
CREATE INDEX IF NOT EXISTS idx_work_sessions_item ON work_sessions(work_item_id);
CREATE INDEX IF NOT EXISTS idx_work_reviews_item ON work_reviews(work_item_id);
CREATE INDEX IF NOT EXISTS idx_work_item_files_item ON work_item_files(work_item_id);
CREATE INDEX IF NOT EXISTS idx_review_assignments_item ON review_assignments(work_item_id);
"""


def get_sqlite_ddl() -> str:
    return SQLITE_DDL


def get_crdb_ddl() -> str:
    return CRDB_DDL
