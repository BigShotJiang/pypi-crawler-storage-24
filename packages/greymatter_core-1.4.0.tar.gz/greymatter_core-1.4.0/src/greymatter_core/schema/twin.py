"""Digital Twin schema: profiles, values, energy, growth, interventions.

These tables power the Digital Twin behavioral modeling system.
"""

SQLITE_DDL = """
CREATE TABLE IF NOT EXISTS twin_profiles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS twin_values (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL REFERENCES twin_profiles(id),
    dimension TEXT NOT NULL,
    description TEXT NOT NULL,
    priority INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS twin_energy_readings (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL REFERENCES twin_profiles(id),
    state TEXT NOT NULL,
    intensity INTEGER NOT NULL DEFAULT 5,
    context TEXT,
    source TEXT DEFAULT 'observation',
    recorded_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS twin_growth_entries (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL REFERENCES twin_profiles(id),
    dimension TEXT NOT NULL,
    observation TEXT NOT NULL,
    evidence TEXT,
    direction TEXT NOT NULL DEFAULT 'forward',
    recorded_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS twin_interventions (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL REFERENCES twin_profiles(id),
    trigger_pattern TEXT NOT NULL,
    message TEXT NOT NULL,
    style TEXT NOT NULL DEFAULT 'direct_challenge',
    dimension TEXT,
    outcome TEXT,
    outcome_notes TEXT,
    delivered_at TEXT DEFAULT (datetime('now')),
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS twin_energy_patterns (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL REFERENCES twin_profiles(id),
    pattern_name TEXT NOT NULL,
    description TEXT NOT NULL,
    trigger_signals TEXT,
    typical_duration_hours INTEGER,
    confidence TEXT DEFAULT 'low',
    occurrences INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now')),
    last_seen_at TEXT
);
"""

CRDB_DDL = """
CREATE TABLE IF NOT EXISTS twin_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS twin_values (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL,
    dimension TEXT NOT NULL,
    description TEXT NOT NULL,
    priority INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT fk_twin_values_profile
        FOREIGN KEY (profile_id) REFERENCES twin_profiles(id)
);

CREATE TABLE IF NOT EXISTS twin_energy_readings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL,
    state TEXT NOT NULL,
    intensity INT NOT NULL DEFAULT 5,
    context TEXT,
    source TEXT DEFAULT 'observation',
    recorded_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT fk_twin_energy_profile
        FOREIGN KEY (profile_id) REFERENCES twin_profiles(id)
);

CREATE TABLE IF NOT EXISTS twin_growth_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL,
    dimension TEXT NOT NULL,
    observation TEXT NOT NULL,
    evidence TEXT,
    direction TEXT NOT NULL DEFAULT 'forward',
    recorded_at TIMESTAMPTZ DEFAULT now(),
    CONSTRAINT fk_twin_growth_profile
        FOREIGN KEY (profile_id) REFERENCES twin_profiles(id)
);

CREATE TABLE IF NOT EXISTS twin_interventions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL,
    trigger_pattern TEXT NOT NULL,
    message TEXT NOT NULL,
    style TEXT NOT NULL DEFAULT 'direct_challenge',
    dimension TEXT,
    outcome TEXT,
    outcome_notes TEXT,
    delivered_at TIMESTAMPTZ DEFAULT now(),
    resolved_at TIMESTAMPTZ,
    CONSTRAINT fk_twin_interventions_profile
        FOREIGN KEY (profile_id) REFERENCES twin_profiles(id)
);

CREATE TABLE IF NOT EXISTS twin_energy_patterns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL,
    pattern_name TEXT NOT NULL,
    description TEXT NOT NULL,
    trigger_signals JSONB,
    typical_duration_hours INT,
    confidence TEXT DEFAULT 'low',
    occurrences INT DEFAULT 1,
    created_at TIMESTAMPTZ DEFAULT now(),
    last_seen_at TIMESTAMPTZ,
    CONSTRAINT fk_twin_energy_patterns_profile
        FOREIGN KEY (profile_id) REFERENCES twin_profiles(id)
);

-- Twin indexes
CREATE INDEX IF NOT EXISTS idx_twin_values_profile ON twin_values(profile_id);
CREATE INDEX IF NOT EXISTS idx_twin_energy_profile ON twin_energy_readings(profile_id);
CREATE INDEX IF NOT EXISTS idx_twin_energy_state ON twin_energy_readings(state);
CREATE INDEX IF NOT EXISTS idx_twin_growth_profile ON twin_growth_entries(profile_id);
CREATE INDEX IF NOT EXISTS idx_twin_growth_dimension ON twin_growth_entries(dimension);
CREATE INDEX IF NOT EXISTS idx_twin_interventions_profile ON twin_interventions(profile_id);
CREATE INDEX IF NOT EXISTS idx_twin_energy_patterns_profile ON twin_energy_patterns(profile_id);
"""


def get_sqlite_ddl() -> str:
    return SQLITE_DDL


def get_crdb_ddl() -> str:
    return CRDB_DDL
