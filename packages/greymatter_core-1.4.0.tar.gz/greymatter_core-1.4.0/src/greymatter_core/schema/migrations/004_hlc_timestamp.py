"""Migration 004: Add _hlc_timestamp column for Hybrid Logical Clock.

The HLC timestamp provides causally consistent ordering across nodes,
tolerating clock skew. Stored as TEXT in format "wall_ms.counter.node_id".
Falls back to _sync_version when _hlc_timestamp is not set.
"""
from . import register
from greymatter_core.sync import SYNC_TABLES


@register(4, "Add _hlc_timestamp column for causal ordering")
def migrate(db) -> None:
    """Add _hlc_timestamp column to all syncable tables."""
    for table in SYNC_TABLES:
        try:
            db.execute(
                f"ALTER TABLE {table} ADD COLUMN _hlc_timestamp TEXT DEFAULT ''"
            )
        except Exception:
            pass  # Column already exists
