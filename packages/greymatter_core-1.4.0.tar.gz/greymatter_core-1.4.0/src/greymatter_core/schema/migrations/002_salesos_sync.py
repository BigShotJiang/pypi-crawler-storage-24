"""Migration 002: Add sync tracking columns to SalesOS tables.

Extends the sync engine to cover SalesOS data — accounts, contacts,
hunting list, MEDDPICC scores, research docs, snapshots, trigger alerts,
deal forecasts, and proposals.
"""
from . import register
from greymatter_core.sync import SALESOS_SYNC_TABLES


@register(2, "Add sync columns to SalesOS tables")
def migrate(db) -> None:
    """Add _sync_version and _node_id columns to SalesOS tables."""
    for table in SALESOS_SYNC_TABLES:
        for col, col_type in [
            ("_sync_version", "INTEGER DEFAULT 0"),
            ("_node_id", "TEXT DEFAULT ''"),
        ]:
            try:
                db.execute(
                    f"ALTER TABLE {table} ADD COLUMN {col} {col_type}"
                )
            except Exception:
                pass  # Column already exists or table doesn't exist yet
