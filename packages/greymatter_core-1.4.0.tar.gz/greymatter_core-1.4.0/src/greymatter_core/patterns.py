"""Pattern tracking for GreyMatter.

Patterns represent learned behaviors with confidence escalation:
- low: 0-2 confirmations
- medium: 3-6 confirmations
- high: 7+ confirmations
"""
from typing import Any, Optional

from .db import Database
from .ids import generate_pattern_id

CONFIDENCE_THRESHOLDS = {"low": 0, "medium": 3, "high": 7}


class PatternManager:
    """Manages pattern lifecycle: creation, evidence, confidence escalation."""

    def __init__(self, db: Database):
        self.db = db

    def create(self, type: str, domain: str, title: str, observation: str) -> dict[str, Any]:
        pattern_id = generate_pattern_id()
        self.db.execute(
            "INSERT INTO patterns (id, type, domain, title, observation) VALUES (?, ?, ?, ?, ?)",
            (pattern_id, type, domain, title, observation),
        )
        return self.get(pattern_id)

    def get(self, pattern_id: str) -> dict[str, Any] | None:
        return self.db.execute_one("SELECT * FROM patterns WHERE id = ?", (pattern_id,))

    def add_evidence(self, pattern_id: str, session_id: str,
                     work_item_id: str | None = None, outcome: str = "confirmed") -> None:
        self.db.execute(
            "INSERT INTO pattern_evidence (pattern_id, session_id, work_item_id, outcome) VALUES (?, ?, ?, ?)",
            (pattern_id, session_id, work_item_id, outcome),
        )
        self.db.execute(
            "UPDATE patterns SET applications = applications + 1, last_applied_at = datetime('now') WHERE id = ?",
            (pattern_id,),
        )
        self._update_confidence(pattern_id)

    def _update_confidence(self, pattern_id: str) -> None:
        rows = self.db.execute(
            "SELECT COUNT(*) as cnt FROM pattern_evidence WHERE pattern_id = ? AND outcome = 'confirmed'",
            (pattern_id,),
        )
        count = rows[0]["cnt"] if rows else 0

        new_confidence = "low"
        if count >= CONFIDENCE_THRESHOLDS["high"]:
            new_confidence = "high"
        elif count >= CONFIDENCE_THRESHOLDS["medium"]:
            new_confidence = "medium"

        self.db.execute(
            "UPDATE patterns SET confidence = ?, confirmations = ? WHERE id = ?",
            (new_confidence, count, pattern_id),
        )

    def search(self, domain: str | None = None, type: str | None = None,
               min_confidence: str = "low") -> list[dict[str, Any]]:
        query = "SELECT * FROM patterns WHERE 1=1"
        params: list = []
        if domain:
            query += " AND domain = ?"
            params.append(domain)
        if type:
            query += " AND type = ?"
            params.append(type)

        results = self.db.execute(query, tuple(params))
        confidence_order = {"low": 0, "medium": 1, "high": 2}
        min_val = confidence_order.get(min_confidence, 0)
        return [p for p in results if confidence_order.get(p["confidence"], 0) >= min_val]

    def get_for_session_load(self, max_count: int = 20) -> list[dict[str, Any]]:
        return self.db.execute(
            """SELECT * FROM patterns WHERE confidence IN ('medium', 'high')
               ORDER BY CASE confidence WHEN 'high' THEN 0 ELSE 1 END, applications DESC
               LIMIT ?""",
            (max_count,),
        )

    def list_all(self) -> list[dict[str, Any]]:
        return self.db.execute("SELECT * FROM patterns ORDER BY created_at DESC")

    def list_summary(self, limit: int = 25, confidence: str | None = None) -> dict[str, Any]:
        """List patterns as compact summaries without observation bodies."""
        where = "WHERE 1=1"
        params: list = []
        if confidence:
            where += " AND confidence = ?"
            params.append(confidence)
        count_row = self.db.execute_one(
            f"SELECT COUNT(*) as total FROM patterns {where}", tuple(params)
        )
        total = count_row["total"] if count_row else 0
        results = self.db.execute(
            f"""SELECT id, type, domain, title, confidence, confirmations, created_at
                FROM patterns {where}
                ORDER BY created_at DESC LIMIT ?""",
            tuple(params + [limit]),
        )
        return {"total": total, "returned": len(results), "patterns": results}

    def search_summary(
        self,
        domain: str | None = None,
        type: str | None = None,
        min_confidence: str = "low",
        limit: int = 25,
    ) -> dict[str, Any]:
        """Search patterns returning compact summaries."""
        where = "WHERE 1=1"
        params: list = []
        if domain:
            where += " AND domain = ?"
            params.append(domain)
        if type:
            where += " AND type = ?"
            params.append(type)

        all_results = self.db.execute(
            f"SELECT id, type, domain, title, confidence, confirmations, created_at FROM patterns {where}",
            tuple(params),
        )
        confidence_order = {"low": 0, "medium": 1, "high": 2}
        min_val = confidence_order.get(min_confidence, 0)
        filtered = [p for p in all_results if confidence_order.get(p["confidence"], 0) >= min_val]
        return {
            "total": len(filtered),
            "returned": min(limit, len(filtered)),
            "patterns": filtered[:limit],
        }


    def count(self, confidence: str | None = None) -> int:
        """Count patterns, optionally filtered by confidence."""
        where = "WHERE 1=1"
        params: list = []
        if confidence:
            where += " AND confidence = ?"
            params.append(confidence)
        row = self.db.execute_one(
            f"SELECT COUNT(*) as total FROM patterns {where}", tuple(params)
        )
        return row["total"] if row else 0

    def delete(self, pattern_id: str) -> bool:
        if self.get(pattern_id) is None:
            return False
        self.db.execute("DELETE FROM pattern_evidence WHERE pattern_id = ?", (pattern_id,))
        self.db.execute("DELETE FROM patterns WHERE id = ?", (pattern_id,))
        return True
