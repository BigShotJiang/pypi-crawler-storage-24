"""ID generation for GreyMatter entities."""
import secrets
import string
from datetime import datetime

ALPHABET = string.ascii_lowercase + string.digits


def _short_id(length: int = 8) -> str:
    """Generate a short alphanumeric ID."""
    return "".join(secrets.choice(ALPHABET) for _ in range(length))


def generate_pattern_id() -> str:
    """Generate pattern ID: pat-xxxxxxxx"""
    return f"pat-{_short_id(8)}"


def generate_knowledge_id() -> str:
    """Generate knowledge entry ID: kn-xxxxxxxx"""
    return f"kn-{_short_id(8)}"


def generate_session_id() -> str:
    """Generate session ID: YYYY-MM-DD-xxxxxxxx"""
    date_str = datetime.now().strftime("%Y-%m-%d")
    return f"{date_str}-{_short_id(8)}"


def generate_work_item_id() -> str:
    """Generate work item ID: wi-xxxxxxxx"""
    return f"wi-{_short_id(8)}"


def generate_standard_id(category: str) -> str:
    """Generate quality standard ID: qs-{category}-xxxxxxxx"""
    return f"qs-{category}-{_short_id(8)}"


def generate_build_run_id() -> str:
    """Generate build run ID: br-xxxxxxxx"""
    return f"br-{_short_id(8)}"


def generate_document_id() -> str:
    """Generate document ID: doc-xxxxxxxx"""
    return f"doc-{_short_id(8)}"


def generate_id(prefix: str) -> str:
    """Generate a generic ID: {prefix}-xxxxxxxx"""
    return f"{prefix}-{_short_id(8)}"

