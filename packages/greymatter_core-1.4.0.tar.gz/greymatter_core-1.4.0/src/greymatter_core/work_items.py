"""Work item management for GreyMatter.

Simple local task list with priority ordering and status tracking.
No distributed locking -- single user, single process.
"""
from typing import Any

from .db import Database
from .ids import generate_work_item_id


class WorkItemManager:
    """Manages work items: create, update, complete, list."""

    def __init__(self, db: Database):
        self.db = db

    def create(
        self,
        title: str,
        description: str | None = None,
        priority: int = 100,
        domain_tags: str | None = None,
        project: str = "greymatter",
        feature: str = "general",
    ) -> dict[str, Any]:
        item_id = generate_work_item_id()
        short_id = item_id[-4:]
        self.db.execute(
            """INSERT INTO work_items (id, title, description, priority, domain_tags,
               project, feature, type, short_id, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'task', ?, 'queued')""",
            (item_id, title, description, priority, domain_tags,
             project, feature, short_id),
        )
        return self.get(item_id)

    def get(self, item_id: str) -> dict[str, Any] | None:
        return self.db.execute_one("SELECT * FROM work_items WHERE id = ?", (item_id,))

    def list(
        self,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM work_items WHERE 1=1"
        params: list = []
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY priority ASC, created_at ASC LIMIT ?"
        params.append(limit)
        return self.db.execute(query, tuple(params))

    def update_status(self, item_id: str, status: str) -> dict[str, Any] | None:
        if self.get(item_id) is None:
            return None
        self.db.execute("UPDATE work_items SET status = ? WHERE id = ?", (status, item_id))
        return self.get(item_id)

    def update_review(
        self, item_id: str, status: str, review_notes: str | None = None
    ) -> dict[str, Any] | None:
        """Update work item status with review notes."""
        if self.get(item_id) is None:
            return None
        self.db.execute(
            "UPDATE work_items SET status = ?, review_notes = ? WHERE id = ?",
            (status, review_notes, item_id),
        )
        return self.get(item_id)

    def complete(self, item_id: str) -> dict[str, Any] | None:
        if self.get(item_id) is None:
            return None
        self.db.execute(
            "UPDATE work_items SET status = 'completed', completed_at = datetime('now') WHERE id = ?",
            (item_id,),
        )
        return self.get(item_id)


    def count(self, status: str | None = None) -> int:
        """Count work items, optionally filtered by status."""
        where = "WHERE 1=1"
        params: list = []
        if status:
            where += " AND status = ?"
            params.append(status)
        row = self.db.execute_one(
            f"SELECT COUNT(*) as total FROM work_items {where}", tuple(params)
        )
        return row["total"] if row else 0

    def delete(self, item_id: str) -> bool:
        if self.get(item_id) is None:
            return False
        self.db.execute("DELETE FROM work_items WHERE id = ?", (item_id,))
        return True
