"""GreyMatter Core — soul, patterns, knowledge, LLM gateway."""

__version__ = "1.4.0"
