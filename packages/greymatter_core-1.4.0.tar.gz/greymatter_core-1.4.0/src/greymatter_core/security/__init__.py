"""GreyMatter Security — 4-layer defense in depth.

Layer 1: API Authentication (Bearer tokens, HMAC-signed)
Layer 2: TLS everywhere (pqx hybrid certs: ECDSA + ML-DSA-65)
Layer 3: Encryption at rest (SQLCipher / AES-256)
Layer 4: Sync payload encryption (AES-256-GCM, ML-KEM key wrap)
"""

from greymatter_core.security.tokens import (
    generate_node_token,
    verify_node_token,
    TokenStore,
)
from greymatter_core.security.encryption import (
    encrypt_sync_payload,
    decrypt_sync_payload,
    MLKEM_AVAILABLE,
)

__all__ = [
    "generate_node_token",
    "verify_node_token",
    "TokenStore",
    "encrypt_sync_payload",
    "decrypt_sync_payload",
    "MLKEM_AVAILABLE",
]

# Middleware requires FastAPI — import only when available
try:
    from greymatter_core.security.middleware import require_auth, AuthMiddleware
    __all__.extend(["require_auth", "AuthMiddleware"])
except ImportError:
    pass
