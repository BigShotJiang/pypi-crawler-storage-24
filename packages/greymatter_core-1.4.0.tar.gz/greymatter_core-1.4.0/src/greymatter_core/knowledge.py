"""Unified Knowledge Graph for GreyMatter.

Entry types: pattern, correction, expertise, gotcha, reference.
Scopes: cross-cutting, domain-specific.
"""
import re
from typing import Any, Optional

from .db import Database
from .ids import generate_knowledge_id


ENTRY_TYPES = {"pattern", "correction", "expertise", "gotcha", "reference", "observation"}
SCOPES = {"cross-cutting", "domain-specific"}


class KnowledgeStore:
    """CRUD operations for the unified knowledge graph."""

    def __init__(self, db: Database):
        self.db = db

    def create(
        self,
        entry_type: str,
        title: str,
        content: str,
        domain: str | None = None,
        scope: str = "cross-cutting",
        valence: str | None = None,
        tags: str | None = None,
    ) -> dict[str, Any]:
        if entry_type not in ENTRY_TYPES:
            raise ValueError(f"Invalid entry_type: {entry_type}. Must be one of {ENTRY_TYPES}")
        entry_id = generate_knowledge_id()
        try:
            # Legacy schema: has NOT NULL on 'type', 'source', 'valence' columns
            self.db.execute(
                """INSERT INTO knowledge_entries
                   (id, entry_type, type, source, scope, domain, title, content, valence, tags)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (entry_id, entry_type, entry_type, "import", scope, domain, title, content,
                 valence or "neutral", tags),
            )
        except Exception:
            # New schema (no type/source columns)
            self.db.execute(
                """INSERT INTO knowledge_entries
                   (id, entry_type, scope, domain, title, content, valence, tags)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (entry_id, entry_type, scope, domain, title, content, valence, tags),
            )
        return self.get(entry_id)

    def get(self, entry_id: str) -> dict[str, Any] | None:
        return self.db.execute_one("SELECT * FROM knowledge_entries WHERE id = ?", (entry_id,))

    def search(
        self,
        entry_type: str | None = None,
        domain: str | None = None,
        text: str | None = None,
        include_pruned: bool = False,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM knowledge_entries WHERE 1=1"
        params: list = []

        if not include_pruned:
            query += " AND pruned_at IS NULL"
        if entry_type:
            query += " AND entry_type = ?"
            params.append(entry_type)
        if domain:
            query += " AND domain = ?"
            params.append(domain)
        if text:
            query += " AND (title LIKE ? OR content LIKE ?)"
            params.extend([f"%{text}%", f"%{text}%"])

        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        return self.db.execute(query, tuple(params))

    def search_summary(
        self,
        entry_type: str | None = None,
        domain: str | None = None,
        text: str | None = None,
        limit: int = 25,
    ) -> dict[str, Any]:
        """Search returning compact summaries without full content."""
        where = "WHERE pruned_at IS NULL"
        params: list = []
        if entry_type:
            where += " AND entry_type = ?"
            params.append(entry_type)
        if domain:
            where += " AND domain = ?"
            params.append(domain)
        if text:
            where += " AND (title LIKE ? OR content LIKE ?)"
            params.extend([f"%{text}%", f"%{text}%"])

        count_row = self.db.execute_one(
            f"SELECT COUNT(*) as total FROM knowledge_entries {where}", tuple(params)
        )
        total = count_row["total"] if count_row else 0
        results = self.db.execute(
            f"""SELECT id, entry_type, title, substr(content, 1, 200) as content_preview,
                       domain, scope, tags, created_at
                FROM knowledge_entries {where}
                ORDER BY created_at DESC LIMIT ?""",
            tuple(params + [limit]),
        )
        return {"total": total, "returned": len(results), "entries": results}

    def update(self, entry_id: str, **kwargs) -> dict[str, Any] | None:
        if self.get(entry_id) is None:
            return None
        allowed = {"title", "content", "domain", "scope", "valence", "tags"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return self.get(entry_id)
        # Validate column names are safe identifiers
        for k in updates:
            if not re.match(r'^[a-z_]+$', k):
                raise ValueError(f"Invalid column name: {k}")
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        params = list(updates.values()) + [entry_id]
        self.db.execute(
            f"UPDATE knowledge_entries SET {set_clause}, updated_at = datetime('now') WHERE id = ?",
            tuple(params),
        )
        return self.get(entry_id)

    def prune(self, entry_id: str) -> bool:
        if self.get(entry_id) is None:
            return False
        self.db.execute(
            "UPDATE knowledge_entries SET pruned_at = datetime('now') WHERE id = ?",
            (entry_id,),
        )
        return True


    def count(self, entry_type: str | None = None, domain: str | None = None) -> int:
        """Count knowledge entries, optionally filtered."""
        where = "WHERE pruned_at IS NULL"
        params: list = []
        if entry_type:
            where += " AND entry_type = ?"
            params.append(entry_type)
        if domain:
            where += " AND domain = ?"
            params.append(domain)
        row = self.db.execute_one(
            f"SELECT COUNT(*) as total FROM knowledge_entries {where}", tuple(params)
        )
        return row["total"] if row else 0

    def record_application(self, entry_id: str) -> None:
        self.db.execute(
            "UPDATE knowledge_entries SET applied_count = applied_count + 1, updated_at = datetime('now') WHERE id = ?",
            (entry_id,),
        )
