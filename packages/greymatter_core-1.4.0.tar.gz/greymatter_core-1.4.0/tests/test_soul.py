"""Tests for soul document management."""
import pytest
from pathlib import Path
from greymatter_core.soul import SoulManager


def test_create_initial_soul(tmp_path):
    soul_path = tmp_path / "soul" / "default.md"
    mgr = SoulManager(soul_path)
    assert not mgr.exists()
    mgr.create_initial_soul("Keith")
    assert mgr.exists()
    content = mgr.load()
    assert "Keith" in content
    assert "## Identity" in content


def test_load_nonexistent(tmp_path):
    mgr = SoulManager(tmp_path / "nonexistent.md")
    assert mgr.load() == ""


def test_get_section(tmp_path):
    soul_path = tmp_path / "soul.md"
    mgr = SoulManager(soul_path)
    mgr.create_initial_soul("Keith")
    identity = mgr.get_section("Identity")
    assert identity is not None
    assert "Keith" in identity


def test_add_learned_preference(tmp_path):
    soul_path = tmp_path / "soul.md"
    mgr = SoulManager(soul_path)
    mgr.create_initial_soul("Keith")
    mgr.add_learned_preference("Prefers TDD workflow")
    content = mgr.load()
    assert "Prefers TDD workflow" in content


def test_increment_session_count(tmp_path):
    soul_path = tmp_path / "soul.md"
    mgr = SoulManager(soul_path)
    mgr.create_initial_soul("Keith")
    count = mgr.increment_session_count()
    assert count == 1
    count = mgr.increment_session_count()
    assert count == 2
