"""Tests for unified knowledge graph."""
import pytest
from greymatter_core.db import SQLiteDatabase
from greymatter_core.knowledge import KnowledgeStore


@pytest.fixture
def db():
    return SQLiteDatabase(":memory:")


@pytest.fixture
def knowledge(db):
    return KnowledgeStore(db)


def test_create_entry(knowledge):
    entry = knowledge.create(
        entry_type="expertise", title="SQLite WAL Mode",
        content="WAL mode allows concurrent reads during writes",
        domain="database",
    )
    assert entry["id"].startswith("kn-")
    assert entry["entry_type"] == "expertise"
    assert entry["scope"] == "cross-cutting"


def test_get_entry(knowledge):
    created = knowledge.create(entry_type="gotcha", title="Test", content="Content")
    fetched = knowledge.get(created["id"])
    assert fetched is not None
    assert fetched["title"] == "Test"


def test_search_by_type(knowledge):
    knowledge.create(entry_type="expertise", title="A", content="A")
    knowledge.create(entry_type="correction", title="B", content="B")
    results = knowledge.search(entry_type="expertise")
    assert len(results) == 1
    assert results[0]["title"] == "A"


def test_search_by_domain(knowledge):
    knowledge.create(entry_type="expertise", title="A", content="A", domain="auth")
    knowledge.create(entry_type="expertise", title="B", content="B", domain="database")
    results = knowledge.search(domain="auth")
    assert len(results) == 1


def test_search_by_text(knowledge):
    knowledge.create(entry_type="expertise", title="SQLite WAL", content="WAL mode details")
    knowledge.create(entry_type="expertise", title="PostgreSQL", content="Postgres details")
    results = knowledge.search(text="WAL")
    assert len(results) == 1
    assert results[0]["title"] == "SQLite WAL"


def test_prune_entry(knowledge):
    entry = knowledge.create(entry_type="gotcha", title="Old", content="Outdated")
    knowledge.prune(entry["id"])
    fetched = knowledge.get(entry["id"])
    assert fetched["pruned_at"] is not None
    # Pruned entries excluded from search by default
    results = knowledge.search()
    assert len(results) == 0


def test_record_application(knowledge):
    entry = knowledge.create(entry_type="expertise", title="A", content="A")
    knowledge.record_application(entry["id"])
    knowledge.record_application(entry["id"])
    fetched = knowledge.get(entry["id"])
    assert fetched["applied_count"] == 2


def test_invalid_entry_type_rejected(knowledge):
    with pytest.raises(ValueError, match="Invalid entry_type"):
        knowledge.create(entry_type="bogus", title="X", content="X")


def test_update_rejects_unknown_columns(knowledge):
    entry = knowledge.create(entry_type="expertise", title="A", content="A")
    # Allowed column names should work
    updated = knowledge.update(entry["id"], title="B")
    assert updated["title"] == "B"
    # Unknown columns are silently ignored (filtered by allowed set)
    updated = knowledge.update(entry["id"], **{"evil_col": "bad"})
    assert updated["title"] == "B"  # unchanged


def test_update_column_regex_validation(knowledge):
    """Defense-in-depth: column names must match ^[a-z_]+$ even if in allowed set."""
    import re
    from greymatter_core.knowledge import KnowledgeStore

    # Verify all allowed column names pass the regex
    allowed = {"title", "content", "domain", "scope", "valence", "tags"}
    for col in allowed:
        assert re.match(r'^[a-z_]+$', col), f"Allowed column '{col}' fails regex"
