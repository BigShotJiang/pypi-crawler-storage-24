"""Tests for cluster configuration."""
import os

import pytest

from greymatter_core.config import ClusterConfig, SyncConfig, CertConfig


class TestSyncConfig:
    def test_defaults(self):
        sc = SyncConfig()
        assert sc.active_interval == 30.0
        assert sc.idle_interval == 300.0
        assert sc.batch_size == 500
        assert sc.retry_max == 5
        assert sc.retention_days == 7


class TestCertConfig:
    def test_cert_path_expands_user(self):
        cc = CertConfig()
        assert "~" not in str(cc.cert_path)


class TestClusterConfig:
    def test_defaults(self):
        cc = ClusterConfig()
        assert cc.node_id == ""
        assert cc.tailscale_tag == "greymatter"
        assert isinstance(cc.sync, SyncConfig)
        assert isinstance(cc.certs, CertConfig)

    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("GM_NODE_ID", "node-test")
        monkeypatch.setenv("GM_HUB_URL", "http://hub:8000")
        monkeypatch.setenv("GM_SYNC_INTERVAL", "10")
        monkeypatch.setenv("GM_SYNC_BATCH_SIZE", "100")

        cc = ClusterConfig.from_env()
        assert cc.node_id == "node-test"
        assert cc.hub_url == "http://hub:8000"
        assert cc.sync.active_interval == 10.0
        assert cc.sync.batch_size == 100

    def test_from_env_defaults(self, monkeypatch):
        for key in list(os.environ):
            if key.startswith("GM_"):
                monkeypatch.delenv(key, raising=False)

        cc = ClusterConfig.from_env()
        assert cc.node_id == ""
        assert cc.sync.active_interval == 30.0
