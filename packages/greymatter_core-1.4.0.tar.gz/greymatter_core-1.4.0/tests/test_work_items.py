"""Tests for work item management."""
import pytest
from greymatter_core.db import SQLiteDatabase
from greymatter_core.work_items import WorkItemManager


@pytest.fixture
def db():
    return SQLiteDatabase(":memory:")


@pytest.fixture
def work(db):
    return WorkItemManager(db)


def test_create_work_item(work):
    item = work.create(title="Build login page", description="OAuth2 login flow")
    assert item["id"].startswith("wi-")
    assert item["status"] == "queued"
    assert item["priority"] == 100


def test_list_by_status(work):
    work.create(title="A")
    item_b = work.create(title="B")
    work.update_status(item_b["id"], "in_progress")
    queued = work.list(status="queued")
    assert len(queued) == 1
    assert queued[0]["title"] == "A"
    in_progress = work.list(status="in_progress")
    assert len(in_progress) == 1
    assert in_progress[0]["title"] == "B"


def test_complete_work_item(work):
    item = work.create(title="Do thing")
    work.complete(item["id"])
    completed = work.get(item["id"])
    assert completed["status"] == "completed"
    assert completed["completed_at"] is not None


def test_priority_ordering(work):
    work.create(title="Low priority", priority=200)
    work.create(title="High priority", priority=10)
    items = work.list()
    assert items[0]["title"] == "High priority"
    assert items[1]["title"] == "Low priority"


def test_get_nonexistent(work):
    assert work.get("wi-nonexistent") is None


def test_update_to_pending_review(work):
    item = work.create(title="Implement login")
    work.update_status(item["id"], "in_progress")
    result = work.update_status(item["id"], "pending_review")
    assert result["status"] == "pending_review"


def test_update_to_needs_revision(work):
    item = work.create(title="Implement login")
    work.update_status(item["id"], "pending_review")
    result = work.update_status(item["id"], "needs_revision")
    assert result["status"] == "needs_revision"


def test_update_to_approved(work):
    item = work.create(title="Implement login")
    work.update_status(item["id"], "pending_review")
    result = work.update_status(item["id"], "approved")
    assert result["status"] == "approved"


def test_update_review_notes(work):
    item = work.create(title="Implement login")
    work.update_status(item["id"], "pending_review")
    result = work.update_review(item["id"], "needs_revision", "Missing error handling for 401")
    assert result["status"] == "needs_revision"
    assert result["review_notes"] == "Missing error handling for 401"


def test_update_review_notes_nonexistent(work):
    result = work.update_review("wi-nonexistent", "approved", "LGTM")
    assert result is None


def test_list_pending_review(work):
    a = work.create(title="A")
    b = work.create(title="B")
    work.update_status(a["id"], "pending_review")
    work.update_status(b["id"], "in_progress")
    pending = work.list(status="pending_review")
    assert len(pending) == 1
    assert pending[0]["title"] == "A"
