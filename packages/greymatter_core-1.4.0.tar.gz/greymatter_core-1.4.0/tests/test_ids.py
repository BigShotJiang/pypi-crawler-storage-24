"""Tests for ID generation."""
from greymatter_core.ids import (
    generate_pattern_id,
    generate_knowledge_id,
    generate_session_id,
    generate_work_item_id,
    generate_standard_id,
    generate_build_run_id,
    generate_document_id,
)


def test_pattern_id_format():
    pid = generate_pattern_id()
    assert pid.startswith("pat-")
    assert len(pid) == 12  # pat- + 8 chars


def test_knowledge_id_format():
    kid = generate_knowledge_id()
    assert kid.startswith("kn-")
    assert len(kid) == 11  # kn- + 8 chars


def test_session_id_has_date():
    sid = generate_session_id()
    # Format: YYYY-MM-DD-xxxxxxxx
    parts = sid.split("-")
    assert len(parts) == 4
    assert len(parts[0]) == 4  # year
    assert len(parts[3]) == 8  # 8-char suffix


def test_work_item_id_format():
    wid = generate_work_item_id()
    assert wid.startswith("wi-")
    assert len(wid) == 11  # wi- + 8 chars


def test_generate_standard_id():
    sid = generate_standard_id("typing")
    assert sid.startswith("qs-typing-")
    assert len(sid) == len("qs-typing-") + 8


def test_generate_build_run_id():
    bid = generate_build_run_id()
    assert bid.startswith("br-")
    assert len(bid) == len("br-") + 8


def test_generate_document_id():
    did = generate_document_id()
    assert did.startswith("doc-")
    assert len(did) == len("doc-") + 8


def test_ids_are_unique():
    ids = {generate_pattern_id() for _ in range(100)}
    assert len(ids) == 100  # all unique
