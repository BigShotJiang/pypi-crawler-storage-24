"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "0.1.6"
