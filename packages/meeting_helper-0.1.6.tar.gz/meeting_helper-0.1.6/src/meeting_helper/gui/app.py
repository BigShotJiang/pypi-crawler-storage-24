"""PySide6 application entry point for Meeting Helper GUI."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from PySide6.QtWidgets import QApplication

from meeting_helper.gui.main_window import MainWindow
from meeting_helper.gui.menubar import MenuBarIcon

if TYPE_CHECKING:
    from meeting_helper.config import Config


def run_gui(config: "Config") -> None:
    """Launch the main GUI application."""
    app = QApplication(sys.argv)
    app.setApplicationName("Meeting Helper")
    app.setQuitOnLastWindowClosed(False)

    window = MainWindow(config=config)
    tray = MenuBarIcon(window, port=config.port)
    window.set_tray_icon(tray)

    tray.show()
    window.show()

    sys.exit(app.exec())
