# System Architecture Analysis

## Overview

- **Project**: proxy
- **Language**: python
- **Files**: 207
- **Lines**: 52784
- **Functions**: 1876
- **Classes**: 141
- **Avg CC**: 4.4
- **Critical (CC≥10)**: 164

## Architecture

### docs/open-webui-tools/ (1 files, 90L, 9 functions)

- `proxym_tools.py` — 90L, 9 methods, CC↑1

### frontend/ (1 files, 6L, 0 functions)

- `proxym-dashboard.jsx` — 6L, 0 methods, CC↑0

### htmlcov/ (1 files, 735L, 65 functions)

- `coverage_html_cb_dd2e7eb5.js` — 735L, 65 methods, CC↑21

### root/ (7 files, 251L, 6 functions)

- `validate_dispatch_table_refactoring.py` — 39L, 1 methods, CC↑1
- `validate_human_task_refactoring.py` — 39L, 1 methods, CC↑1
- `validate_refactoring.py` — 37L, 1 methods, CC↑1
- `validate_tasks_panel_refactoring.py` — 39L, 1 methods, CC↑1
- `validate_tool_health_refactoring.py` — 39L, 1 methods, CC↑1
- _2 more files_

### scripts/ (8 files, 1328L, 25 functions)

- `seed_sprint8.py` — 229L, 1 methods, CC↑10
- `proxym-voice-chat.py` — 73L, 3 methods, CC↑5
- `check_dashboard.sh` — 126L, 8 methods, CC↑0
- `evaluate_llm_work.sh` — 169L, 2 methods, CC↑0
- `jetson-entrypoint.sh` — 43L, 0 methods, CC↑0
- _3 more files_

### services/vscode/ (1 files, 333L, 1 functions)

- `entrypoint.sh` — 333L, 1 methods, CC↑0

### src/proxym/ (5 files, 789L, 26 functions)

- `main.py` — 224L, 2 methods, CC↑11
- `ctl.py` — 273L, 15 methods, CC↑7
- `storage.py` — 136L, 6 methods, CC↑6
- `config.py` — 153L, 3 methods, CC↑3
- `__init__.py` — 3L, 0 methods, CC↑0

### src/proxym/accounts/ (1 files, 398L, 20 functions)

- `__init__.py` — 398L, 20 methods, CC↑15

### src/proxym/api/ (18 files, 2539L, 105 functions)

- `_diag_providers.py` — 60L, 1 methods, CC↑19
- `_diag_agent.py` — 221L, 3 methods, CC↑14
- `_diag_roo.py` — 81L, 1 methods, CC↑14
- `_diag_vscode.py` — 143L, 2 methods, CC↑14
- `completions.py` — 262L, 12 methods, CC↑13
- _13 more files_

### src/proxym/cache/ (1 files, 333L, 10 functions)

- `__init__.py` — 333L, 10 methods, CC↑9

### src/proxym/cli/ (16 files, 2151L, 105 functions)

- `smart_defaults.py` — 109L, 4 methods, CC↑13
- `tickets.py` — 307L, 14 methods, CC↑12
- `diagnostics.py` — 148L, 7 methods, CC↑11
- `observability.py` — 147L, 6 methods, CC↑10
- `_client.py` — 47L, 4 methods, CC↑9
- _11 more files_

### src/proxym/cli/_groups/ (13 files, 1219L, 69 functions)

- `do_ctl.py` — 182L, 8 methods, CC↑8
- `projects_ctl.py` — 202L, 7 methods, CC↑8
- `tickets_ctl.py` — 200L, 13 methods, CC↑7
- `tools_ctl.py` — 139L, 6 methods, CC↑6
- `_shared.py` — 84L, 7 methods, CC↑2
- _8 more files_

### src/proxym/cli/utils/ (1 files, 22L, 1 functions)

- `cmd_sessions_list.py` — 22L, 1 methods, CC↑3

### src/proxym/context/ (5 files, 607L, 23 functions)

- `detector.py` — 202L, 8 methods, CC↑9
- `session.py` — 247L, 12 methods, CC↑7
- `tool_selector.py` — 101L, 2 methods, CC↑5
- `_context.py` — 33L, 1 methods, CC↑3
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/dashboard/ (13 files, 2983L, 173 functions)

- `_tickets_api.py` — 457L, 20 methods, CC↑17
- `panel.jsx` — 79L, 7 methods, CC↑17
- `_projects_api.py` — 255L, 10 methods, CC↑14
- `_environments_api.py` — 460L, 33 methods, CC↑13
- `_system.py` — 156L, 4 methods, CC↑13
- _8 more files_

### src/proxym/dashboard/components/ (21 files, 8928L, 610 functions)

- `tasks.jsx` — 1569L, 96 methods, CC↑104
- `tickets.jsx` — 1449L, 87 methods, CC↑94
- `tools.jsx` — 1563L, 110 methods, CC↑87
- `human.jsx` — 366L, 18 methods, CC↑65
- `environments.jsx` — 611L, 30 methods, CC↑59
- _16 more files_

### src/proxym/dashboard/components/diagnostics/ (5 files, 211L, 16 functions)

- `DiagConfig.jsx` — 59L, 4 methods, CC↑29
- `DiagExtensions.jsx` — 51L, 3 methods, CC↑20
- `DiagAgent.jsx` — 51L, 3 methods, CC↑11
- `DiagInfrastructure.jsx` — 28L, 2 methods, CC↑10
- `helpers.jsx` — 22L, 4 methods, CC↑4

### src/proxym/dashboard/components/human/ (7 files, 474L, 15 functions)

- `HumanJobsList.jsx` — 81L, 1 methods, CC↑37
- `HumanTaskPanelRefactored.jsx` — 140L, 9 methods, CC↑11
- `HumanTaskTable.jsx` — 95L, 1 methods, CC↑11
- `HumanTaskBoard.jsx` — 34L, 1 methods, CC↑5
- `HumanViewControls.jsx` — 67L, 1 methods, CC↑5
- _2 more files_

### src/proxym/dashboard/components/tasks/ (6 files, 403L, 11 functions)

- `TasksRecentJobs.jsx` — 81L, 1 methods, CC↑37
- `TasksTable.jsx` — 95L, 1 methods, CC↑11
- `TasksPanelRefactored.jsx` — 102L, 6 methods, CC↑10
- `TasksBoard.jsx` — 34L, 1 methods, CC↑5
- `TasksViewControls.jsx` — 67L, 1 methods, CC↑5
- _1 more files_

### src/proxym/dashboard/components/tickets/ (5 files, 771L, 43 functions)

- `TicketsPanelRefactored.jsx` — 208L, 19 methods, CC↑31
- `BulkOperations.jsx` — 157L, 7 methods, CC↑20
- `TicketList.jsx` — 209L, 14 methods, CC↑12
- `TicketFilters.jsx` — 151L, 2 methods, CC↑7
- `TicketStats.jsx` — 46L, 1 methods, CC↑2

### src/proxym/dashboard/components/tools/ (17 files, 1194L, 74 functions)

- `ToolsJobQueue.jsx` — 164L, 8 methods, CC↑48
- `ToolHealthPanelRefactored.jsx` — 168L, 14 methods, CC↑31
- `DiagnosticActions.jsx` — 86L, 3 methods, CC↑17
- `TicketStatusBadges.jsx` — 75L, 11 methods, CC↑16
- `BulkAutoFix.jsx` — 62L, 1 methods, CC↑15
- _12 more files_

### src/proxym/dashboard/hooks/ (1 files, 393L, 62 functions)

- `useDashboardData.js` — 393L, 62 methods, CC↑17

### src/proxym/dashboard/tickets/ (4 files, 962L, 63 functions)

- `_manager.py` — 387L, 33 methods, CC↑22
- `_models.py` — 243L, 4 methods, CC↑12
- `TicketManagerRefactored.py` — 296L, 26 methods, CC↑10
- `__init__.py` — 36L, 0 methods, CC↑0

### src/proxym/dashboard/tickets/utils/ (1 files, 25L, 1 functions)

- `delete_ticket.py` — 25L, 1 methods, CC↑2

### src/proxym/dashboard/tools/ (10 files, 1203L, 47 functions)

- `_health.py` — 199L, 5 methods, CC↑28
- `HealthCheckerRefactored.py` — 257L, 15 methods, CC↑12
- `_autofix.py` — 243L, 5 methods, CC↑12
- `_queue.py` — 205L, 8 methods, CC↑12
- `_dispatch.py` — 78L, 2 methods, CC↑10
- _5 more files_

### src/proxym/dashboard/tools/utils/ (3 files, 56L, 4 functions)

- `_aider_install_fix.py` — 31L, 1 methods, CC↑4
- `start_executor.py` — 24L, 3 methods, CC↑3
- `__init__.py` — 1L, 0 methods, CC↑0

### src/proxym/dashboard/utils/ (5 files, 76L, 17 functions)

- `formatters.js` — 34L, 12 methods, CC↑7
- `delete_ticket.py` — 18L, 2 methods, CC↑3
- `_delete_item.py` — 10L, 1 methods, CC↑2
- `delete_milestone.py` — 13L, 2 methods, CC↑1
- `__init__.py` — 1L, 0 methods, CC↑0

### src/proxym/mcp/ (10 files, 1012L, 37 functions)

- `client.py` — 151L, 4 methods, CC↑6
- `router.py` — 95L, 4 methods, CC↑5
- `_tools_tickets.py` — 198L, 5 methods, CC↑4
- `_tools_vm.py` — 194L, 7 methods, CC↑4
- `registry.py` — 113L, 8 methods, CC↑4
- _5 more files_

### src/proxym/middleware/ (1 files, 70L, 4 functions)

- `__init__.py` — 70L, 4 methods, CC↑6

### src/proxym/observability/ (4 files, 953L, 37 functions)

- `repair_agent.py` — 341L, 9 methods, CC↑14
- `__init__.py` — 308L, 8 methods, CC↑9
- `watchdog.py` — 211L, 13 methods, CC↑7
- `health_events.py` — 93L, 7 methods, CC↑6

### src/proxym/projects/ (1 files, 299L, 14 functions)

- `__init__.py` — 299L, 14 methods, CC↑21

### src/proxym/providers/ (1 files, 331L, 4 functions)

- `__init__.py` — 331L, 4 methods, CC↑8

### src/proxym/router/ (2 files, 684L, 32 functions)

- `__init__.py` — 352L, 13 methods, CC↑9
- `strategy.py` — 332L, 19 methods, CC↑9

### src/proxym/tools/ (2 files, 961L, 36 functions)

- `executor.py` — 389L, 17 methods, CC↑21
- `__init__.py` — 572L, 19 methods, CC↑10

### src/proxym/tools/adapters/ (9 files, 747L, 18 functions)

- `_llm_fallback.py` — 241L, 3 methods, CC↑13
- `_base.py` — 100L, 3 methods, CC↑7
- `_shell.py` — 96L, 2 methods, CC↑7
- `_vscode.py` — 113L, 3 methods, CC↑7
- `_aider.py` — 23L, 1 methods, CC↑5
- _4 more files_

### src/proxym/utils/ (3 files, 24L, 2 functions)

- `messages.py` — 11L, 1 methods, CC↑4
- `get_settings.py` — 12L, 1 methods, CC↑2
- `__init__.py` — 1L, 0 methods, CC↑0

### src/proxym/virt/ (13 files, 1590L, 70 functions)

- `_config.py` — 94L, 1 methods, CC↑9
- `_vm_config.py` — 220L, 7 methods, CC↑9
- `browser_profiles.py` — 314L, 12 methods, CC↑9
- `_lifecycle.py` — 236L, 12 methods, CC↑7
- `_state.py` — 94L, 5 methods, CC↑7
- _8 more files_

### src/proxym/virt/profiles/ (1 files, 69L, 4 functions)

- `__init__.py` — 69L, 4 methods, CC↑5

### src/proxym/virt/utils/ (1 files, 27L, 3 functions)

- `detect_chrome_profiles.py` — 27L, 3 methods, CC↑1

### src/proxym/watch/ (2 files, 150L, 5 functions)

- `__init__.py` — 146L, 5 methods, CC↑5
- `client.py` — 4L, 0 methods, CC↑0

### utils/ (2 files, 207L, 9 functions)

- `validation_common.py` — 206L, 9 methods, CC↑10
- `__init__.py` — 1L, 0 methods, CC↑0

## Key Exports

- **TableExport** (function, CC=16) ⚠ split
- **TaskCardMeta** (function, CC=37) ⚠ split
- **TaskJobBadge** (function, CC=25) ⚠ split
- **TaskBulkEditBar** (function, CC=30) ⚠ split
- **TaskTicketCard** (function, CC=18) ⚠ split
- **QuickTaskCreator** (function, CC=31) ⚠ split
- **TasksPanel** (function, CC=104) ⚠ split
- **filtered** (function, CC=18) ⚠ split
- **result** (function, CC=15) ⚠ split
- **TicketCard** (function, CC=42) ⚠ split
- **SprintCard** (function, CC=19) ⚠ split
- **TicketHistoryItem** (function, CC=42) ⚠ split
- **TicketDetailPanel** (function, CC=94) ⚠ split
- **TicketsPanel** (function, CC=87) ⚠ split
- **filtered** (function, CC=31) ⚠ split
- **TableExport** (function, CC=16) ⚠ split
- **ToolCard** (function, CC=26) ⚠ split
- **JobRow** (function, CC=35) ⚠ split
- **JobDetailsPanel** (function, CC=77) ⚠ split
- **TicketDispatchTable** (function, CC=87) ⚠ split
- **renderCurrentTool** (function, CC=20) ⚠ split
- **HealthTrends** (function, CC=15) ⚠ split
- **ToolHealthPanel** (function, CC=76) ⚠ split
- **ToolsPanel** (function, CC=57) ⚠ split
- **useHumanTasks** (function, CC=18) ⚠ split
- **HumanTaskPanel** (function, CC=65) ⚠ split
- **EnvironmentsPanel** (function, CC=59) ⚠ split
- **ToolsJobQueue** (function, CC=48) ⚠ split
- **HumanJobsList** (function, CC=37) ⚠ split
- **TasksRecentJobs** (function, CC=37) ⚠ split
- **VMsPanel** (function, CC=36) ⚠ split
- **LogPanel** (function, CC=34) ⚠ split
- **useTicketFilters** (function, CC=31) ⚠ split
- **ToolHealthPanelRefactored** (function, CC=31) ⚠ split
- **DiagRooConfig** (function, CC=29) ⚠ split
- **DiagnosticsPanel** (function, CC=26) ⚠ split
- **ProjectCard** (function, CC=26) ⚠ split
- **VoiceChat** (function, CC=24) ⚠ split
- **TicketManager** (class, CC̄=4.6)
  - `_apply_filters` CC=22 ⚠ split
  - `update_ticket` CC=18 ⚠ split
  - `_load` CC=18 ⚠ split
- **table** (function, CC=21) ⚠ split
- **table_body_rows** (function, CC=21) ⚠ split
- **no_rows** (function, CC=21) ⚠ split
- **footer** (function, CC=21) ⚠ split
- **ratio_columns** (function, CC=21) ⚠ split
- **filter_handler** (function, CC=21) ⚠ split
- **UsersPanel** (function, CC=21) ⚠ split
- **ProjectRegistry** (class, CC̄=5.4)
  - `_enrich_local` CC=21 ⚠ split
- **ToolExecutor** (class, CC̄=5.3)
  - `_sync_ticket_execution` CC=21 ⚠ split
- **DiagExtensions** (function, CC=20) ⚠ split
- **BulkOperations** (function, CC=20) ⚠ split
- **check_providers_config** (function, CC=19) ⚠ split
- **create_ticket** (function, CC=17) ⚠ split
- **SetupPanel** (function, CC=17) ⚠ split
- **DiagnosticActions** (function, CC=17) ⚠ split
- **useDashboardData** (function, CC=17) ⚠ split
- **useState** (function, CC=17) ⚠ split
- **useEffect** (function, CC=17) ⚠ split
- **useCallback** (function, CC=17) ⚠ split
- **Dashboard** (function, CC=17) ⚠ split
- **TicketStatusBadges** (function, CC=16) ⚠ split
- **AccountCredentials** (class, CC̄=5.0)
- **AccountManager** (class, CC̄=4.4)
  - `_load` CC=15 ⚠ split
- **BulkAutoFix** (function, CC=15) ⚠ split
- **RepairAgent** (class, CC̄=5.4)
- **Milestone** (class, CC̄=12.0)
- **Ticket** (class, CC̄=7.5)
- **Sprint** (class, CC̄=7.0)
- **InstanceHealthCheck** (class, CC̄=6.7)
- **HealthStatusCalculator** (class, CC̄=12.0)
- **TicketValidator** (class, CC̄=8.5)
- **ToolInstance** (class, CC̄=5.0)
- **ProjectsConfig** (class, CC̄=9.0)
- **ShellAdapter** (class, CC̄=5.5)
- **_StateMixin** (class, CC̄=5.0)
- **_SnapshotMixin** (class, CC̄=5.0)
- **AiderAdapter** (class, CC̄=5.0)

## Hotspots (High Fan-Out)

- **TicketsPanel** — fan-out=56: Orchestrates 56 calls
- **TasksPanel** — fan-out=44: Orchestrates 44 calls
- **EnvironmentsPanel** — fan-out=42: Orchestrates 42 calls
- **useDashboardData** — fan-out=39: Orchestrates 39 calls
- **VoiceChat** — fan-out=31: Orchestrates 31 calls
- **create_ticket** — fan-out=29: Create a new ticket. Accepts 'task' (new) or 'title' (legacy).
- **run_all_tests** — fan-out=28: Run all diagnostic tests and return comprehensive status.

## Refactoring Priorities

| # | Action | Impact | Effort |
|---|--------|--------|--------|
| 1 | Split _apply_runtime_health (CC=28 → target CC<10) | high | low |
| 2 | Split DiagnosticsPanel (CC=26 → target CC<10) | high | low |
| 3 | Split LogPanel (CC=34 → target CC<10) | high | low |
| 4 | Split HumanTaskPanel (CC=65 → target CC<10) | high | low |
| 5 | Split VMsPanel (CC=36 → target CC<10) | high | low |
| 6 | Split TicketCard (CC=42 → target CC<10) | high | low |
| 7 | Split TicketHistoryItem (CC=42 → target CC<10) | high | low |
| 8 | Split TicketDetailPanel (CC=94 → target CC<10) | high | low |
| 9 | Split TicketsPanel (CC=87 → target CC<10) | high | low |
| 10 | Split filtered (CC=31 → target CC<10) | high | low |

## Context for LLM

When suggesting changes:
1. Start from hotspots and high-CC functions
2. Follow refactoring priorities above
3. Maintain public API surface — keep backward compatibility
4. Prefer minimal, incremental changes

