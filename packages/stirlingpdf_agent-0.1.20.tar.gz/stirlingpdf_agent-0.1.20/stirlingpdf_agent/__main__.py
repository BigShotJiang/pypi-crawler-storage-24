from stirlingpdf_agent.agent_server import agent_server

if __name__ == "__main__":
    agent_server()
