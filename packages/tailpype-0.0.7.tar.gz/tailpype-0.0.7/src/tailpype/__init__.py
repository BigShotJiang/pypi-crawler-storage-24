"""
A really cool package that does a lot of stuff !
"""
