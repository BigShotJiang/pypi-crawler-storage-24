"""Auto-generated. Do not edit manually."""

from catapa.auth import GrantType
from catapa.auth.catapa_auth import CatapaConfig
from openapi_client import Configuration

# Import all leaf API classes (e.g., CoreEmployeesApi, PayrollPaygroupsApi)
from openapi_client.api import (
    AnomalydetectionAnomalyDetectionTypesAnomalySuspectsApi,
    CoreAdditionalAssignmentsApprovalsApi,
    CoreAdditionalIncomePaymentsApi,
    CoreAnalyticsChartsApi,
    CoreBankAccountConfigurationsApi,
    CoreBankAccountConfigurationsApprovalsApi,
    CoreBankBranchesApi,
    CoreBanksApi,
    CoreBpjsHealthcarePremiumsSummariesApi,
    CoreBpjsHealthcarePremiumsSummariesDetailsApi,
    CoreBpjsHealthcareProvidersApi,
    CoreBpjsHealthcareReportsEdabuAdvanceMembersApi,
    CoreBpjsHealthcareReportsEdabuEmployeeIdentityCardNumberCheckApi,
    CoreBpjsHealthcareReportsEdabuNewMembersApi,
    CoreBpjsHealthcareReportsEdabuWageUpdateApi,
    CoreBpjsHealthcareReportsPaymentDetailsApi,
    CoreBpjsHealthcareTemplatesApi,
    CoreBpjsManpowerPremiumsSummariesApi,
    CoreBpjsManpowerPremiumsSummariesDetailsApi,
    CoreBpjsManpowerProvidersApi,
    CoreBpjsManpowerReportsPaymentDetailsApi,
    CoreBpjsManpowerReportsPensionDebtReportApi,
    CoreBpjsManpowerReportsSippAdvanceMembersApi,
    CoreBpjsManpowerReportsSippNewMembersApi,
    CoreBpjsManpowerReportsSippTerminatedMemberApi,
    CoreBpjsManpowerReportsSippWageUpdateApi,
    CoreBpjsManpowerTemplatesApi,
    CoreCitiesApi,
    CoreCompaniesApi,
    CoreCompanyBankAccountsApi,
    CoreCompanyGroupsApi,
    CoreContactInformationApi,
    CoreCostCentersApi,
    CoreCountriesApi,
    CoreCurrenciesApi,
    CoreCustomTablesApi,
    CoreCustomTablesEntriesApi,
    CoreEditableSalaryPreprocessApi,
    CoreEducationLevelsApi,
    CoreEducationsApi,
    CoreEmployeeDetailsApi,
    CoreEmployeePaygroupsApi,
    CoreEmployeeVariableMetadataApi,
    CoreEmployeeVariablesAperiodicAllApi,
    CoreEmployeeVariablesAperiodicApi,
    CoreEmployeeVariablesApi,
    CoreEmployeeVariablesPeriodicApi,
    CoreEmployeesApi,
    CoreEmployeesBankAccountConfigurationsApi,
    CoreEmployeesBankAccountConfigurationsHistoriesApi,
    CoreEmployeesBpjsHealthcareMembershipsApi,
    CoreEmployeesBpjsManpowerMembershipsApi,
    CoreEmployeesContactInformationApi,
    CoreEmployeesEmployeeDetailsApi,
    CoreEmployeesEmployeeIdentityCardsApi,
    CoreEmployeesEmployeeSalaryTemplatesApi,
    CoreEmployeesEmployeeSalaryTemplatesEffectiveApi,
    CoreEmployeesEmploymentDataApi,
    CoreEmployeesFamiliesApi,
    CoreEmployeesFamiliesApprovalsApi,
    CoreEmployeesHiringDataApi,
    CoreEmployeesJobExperiencesApprovalsApi,
    CoreEmployeesManagerApi,
    CoreEmployeesPaymentItemGroupsLastSequenceApi,
    CoreEmployeesPaymentItemGroupsSequencesApi,
    CoreEmployeesPayslipApi,
    CoreEmployeesPayslipSeveranceApi,
    CoreEmployeesSupervisorsApprovalsApi,
    CoreEmployeesTaxMembershipHistoriesApi,
    CoreEmployeesTaxMembershipsApi,
    CoreEmployeesTaxMembershipsTaxSubjectsApi,
    CoreEmployeesTerminationEntriesApi,
    CoreEmploymentStatusHistoriesApi,
    CoreEmploymentStatusTypesApi,
    CoreEmploymentStatusesApi,
    CoreEmploymentTypesApi,
    CoreFamiliesApi,
    CoreFamiliesApprovalsApi,
    CoreFamilyRelationsApi,
    CoreFieldOfStudiesApi,
    CoreFormerEmployeeIncomeEmployeesApi,
    CoreFormerEmployeeIncomesApi,
    CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployeesAmountsApi,
    CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployeesApi,
    CoreIdentityCardsApi,
    CoreInstitutionsApi,
    CoreJobExperiencesApprovalsApi,
    CoreJobLevelsApi,
    CoreJobTitleLevelsApi,
    CoreJobTitlesApi,
    CoreKppsApi,
    CoreLocationGroupsApi,
    CoreLocationsApi,
    CoreMonthlyRecapitulationApi,
    CoreMonthlyTaxDetailsApi,
    CoreMonthlyTaxReportsApi,
    CoreOperationalGroupsApi,
    CoreOrganizationGroupsApi,
    CoreOrganizationHierarchiesApi,
    CoreOrganizationsApi,
    CoreOrganizationsHeadsApi,
    CoreOrganizationsHistoriesApi,
    CoreOrganizationsSuperiorsApi,
    CorePaygroupsApi,
    CorePayrollProcessSnapshotsApi,
    CorePayslipAdditionalNotesApi,
    CorePayslipLayoutsApi,
    CorePositionsApi,
    CorePositionsCostCentersApi,
    CorePositionsHistoriesApi,
    CorePositionsVacancyStatusesApi,
    CorePph21PoliciesApi,
    CorePph21ReportsBy1721ViApi,
    CorePph21ReportsBy1721ViDetailApi,
    CorePph21ReportsBy1721ViDownloadApi,
    CorePph21ReportsBy1721ViiApi,
    CorePph21ReportsBy1721ViiDownloadApi,
    CorePtkpCategoriesApi,
    CoreReligionsApi,
    CoreSalaryCalculationsApi,
    CoreSalaryCalculationsDetailsApi,
    CoreSalaryCalculationsDetailsTimeAllowanceDetailsApi,
    CoreSalaryItemAddOnAddApi,
    CoreSalaryItemAddOnApi,
    CoreSalaryItemAddOnSubtractApi,
    CoreSalaryItemsApi,
    CoreSalaryPaymentSummariesApi,
    CoreSalaryPaymentsApi,
    CoreSalaryPaymentsDatesApi,
    CoreSalaryPaymentsPaymentItemGroupsApi,
    CoreSalaryPaymentsProcessProcessableProcessedApi,
    CoreSalaryTemplatesApi,
    CoreSeverancePaymentPlansApi,
    CoreSeverancePlansApi,
    CoreStatesApi,
    CoreSubLocationsApi,
    CoreTaxCalculationsApi,
    CoreTaxCalculatorsApi,
    CoreTaxCalculatorsMonthlyApi,
    CoreTaxMembershipHistoriesApi,
    CoreTaxMembershipHistoriesTaxSubjectsApi,
    CoreTaxReportsBy1721A1Api,
    CoreTaxReportsBy1721A1DownloadApi,
    CoreTaxReportsBy1721ViApi,
    CoreTaxReportsBy1721ViDetailApi,
    CoreTaxReportsBy1721ViDownloadApi,
    CoreTaxReportsBy1721ViiApi,
    CoreTaxReportsBy1721ViiDownloadApi,
    CoreTaxReportsBy1721ViiiApi,
    CoreTaxReportsBy1721ViiiDownloadApi,
    CoreTerminationBpjsManpowerReasonsApi,
    CoreTerminationEntriesSeverancePlansApi,
    CoreTerminationReasonCategoriesApi,
    CoreTerminationReasonsApi,
    CoreTerminationTaxReasonsApi,
    CoreTransitionCalculationsProcessCountApi,
    CoreTransitionCalculationsProcessProcessableProcessedApi,
    CoreTransitionCalculationsProcessProcessableUnprocessedApi,
    CoreTransitionCalculationsTimeAllowancesProcessProcessableApi,
    CoreUsersApi,
    CoreUsersMeAnalyticsChartsDataApi,
    CoreUsersMeWidgetsApi,
    CoreVendorsApi,
    CoreWorkflowActivitiesApi,
    CoreWorkflowReasonCategoriesApi,
    CoreWorkflowReasonsApi,
    OauthClientsApi,
    OauthClientsValidateAccessTokenApi,
    RolesApi,
    RolesAuthoritiesApi,
    RolesPermissionsApi,
    TimemanagementAbsenceEntriesApi,
    TimemanagementAttendanceCancellationsApi,
    TimemanagementAttendanceRecapitulationsDetailsApi,
    TimemanagementAttendancesApi,
    TimemanagementEmployeeWorkdayConfigurationsApi,
    TimemanagementFingerprintsApi,
    TimemanagementHolidaysApi,
    TimemanagementLeaveBalancesApi,
    TimemanagementOtherLeaveBalancesApi,
    TimemanagementShiftPatternTemplatesApi,
    TimemanagementWorkgroupWorkdayConfigurationsApi,
    UsersMeApi,
)

# Intermediate namespace stub classes for multi-level hierarchies
# Example: client.core.employees -> Core class with employees property
class Anomalydetection:
    """Resource API"""
    @property
    def anomaly_detection_types(self) -> AnomalydetectionAnomalyDetectionTypes:
        """Resource API"""
        ...

class AnomalydetectionAnomalyDetectionTypes:
    """Resource API"""
    @property
    def anomaly_suspects(self) -> AnomalydetectionAnomalyDetectionTypesAnomalySuspects:
        """These endpoints let you manage anomaly detection features in the system.\n  It allows you to retrieve and configure anomaly detection settings for various modules.\n"""
        ...

class AnomalydetectionAnomalyDetectionTypesAnomalySuspects(AnomalydetectionAnomalyDetectionTypesAnomalySuspectsApi):
    """These endpoints let you manage anomaly detection features in the system.\n  It allows you to retrieve and configure anomaly detection settings for various modules.\n"""

class Core:
    """Resource API"""
    @property
    def additional_assignments(self) -> CoreAdditionalAssignments:
        """Resource API"""
        ...
    @property
    def additional_income_payments(self) -> CoreAdditionalIncomePayments:
        """These endpoints let you manage other payroll-related features in the system.\nIt allows you to retrieve, create, update, and delete various payroll records that do not fall under specific categories.\n"""
        ...
    @property
    def analytics(self) -> CoreAnalytics:
        """Resource API"""
        ...
    @property
    def bank_account_configurations(self) -> CoreBankAccountConfigurations:
        """These endpoints let you manage bank account configurations for employees in the system.\nIt allows you to retrieve, create, update, and delete bank account configuration records.\n"""
        ...
    @property
    def bank_branches(self) -> CoreBankBranches:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def banks(self) -> CoreBanks:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def bpjs_healthcare_premiums(self) -> CoreBpjsHealthcarePremiums:
        """Resource API"""
        ...
    @property
    def bpjs_healthcare_providers(self) -> CoreBpjsHealthcareProviders:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...
    @property
    def bpjs_healthcare_reports(self) -> CoreBpjsHealthcareReports:
        """Resource API"""
        ...
    @property
    def bpjs_healthcare_templates(self) -> CoreBpjsHealthcareTemplates:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...
    @property
    def bpjs_manpower_premiums(self) -> CoreBpjsManpowerPremiums:
        """Resource API"""
        ...
    @property
    def bpjs_manpower_providers(self) -> CoreBpjsManpowerProviders:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...
    @property
    def bpjs_manpower_reports(self) -> CoreBpjsManpowerReports:
        """Resource API"""
        ...
    @property
    def bpjs_manpower_templates(self) -> CoreBpjsManpowerTemplates:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...
    @property
    def cities(self) -> CoreCities:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def companies(self) -> CoreCompanies:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def company_bank_accounts(self) -> CoreCompanyBankAccounts:
        """These endpoints let you manage company bank accounts in the system.\nIt allows you to retrieve, create, update, and delete company bank account records.\n"""
        ...
    @property
    def company_groups(self) -> CoreCompanyGroups:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def contact_information(self) -> CoreContactInformation:
        """These endpoints let you manage contact information for employees in the system.\nIt allows you to retrieve, create, update, and delete contact information records.\n"""
        ...
    @property
    def cost_centers(self) -> CoreCostCenters:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def countries(self) -> CoreCountries:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def currencies(self) -> CoreCurrencies:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def custom_tables(self) -> CoreCustomTables:
        """These endpoints let you manage custom tables in the system.\nIt allows you to retrieve, create, update, and delete custom table records.\n"""
        ...
    @property
    def editable_salary_preprocess(self) -> CoreEditableSalaryPreprocess:
        """These endpoints let you manage editable salary preprocess settings in the system.\nIt allows you to retrieve, create, update, and delete editable salary preprocess records.\n"""
        ...
    @property
    def education_levels(self) -> CoreEducationLevels:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def educations(self) -> CoreEducations:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def employee_details(self) -> CoreEmployeeDetails:
        """These endpoints let you manage detailed information about employees in the system.\nIt allows you to retrieve and update comprehensive employee profiles, including personal, employment, and other related details.\n"""
        ...
    @property
    def employee_paygroups(self) -> CoreEmployeePaygroups:
        """These endpoints let you manage paygroups specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific paygroup records.\n"""
        ...
    @property
    def employee_variable_metadata(self) -> CoreEmployeeVariableMetadata:
        """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""
        ...
    @property
    def employee_variables(self) -> CoreEmployeeVariables:
        """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""
        ...
    @property
    def employees(self) -> CoreEmployees:
        """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""
        ...
    @property
    def employment_status_histories(self) -> CoreEmploymentStatusHistories:
        """These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n"""
        ...
    @property
    def employment_status_types(self) -> CoreEmploymentStatusTypes:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def employment_statuses(self) -> CoreEmploymentStatuses:
        """These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n"""
        ...
    @property
    def employment_types(self) -> CoreEmploymentTypes:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def families(self) -> CoreFamilies:
        """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""
        ...
    @property
    def family_relations(self) -> CoreFamilyRelations:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def field_of_studies(self) -> CoreFieldOfStudies:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def former_employee_income_employees(self) -> CoreFormerEmployeeIncomeEmployees:
        """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""
        ...
    @property
    def former_employee_incomes(self) -> CoreFormerEmployeeIncomes:
        """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""
        ...
    @property
    def identity_cards(self) -> CoreIdentityCards:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def institutions(self) -> CoreInstitutions:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def job_experiences(self) -> CoreJobExperiences:
        """Resource API"""
        ...
    @property
    def job_levels(self) -> CoreJobLevels:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def job_title_levels(self) -> CoreJobTitleLevels:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def job_titles(self) -> CoreJobTitles:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def kpps(self) -> CoreKpps:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def location_groups(self) -> CoreLocationGroups:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def locations(self) -> CoreLocations:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def monthly_recapitulation(self) -> CoreMonthlyRecapitulation:
        """These endpoints let you manage other payroll-related features in the system.\nIt allows you to retrieve, create, update, and delete various payroll records that do not fall under specific categories.\n"""
        ...
    @property
    def monthly_tax_details(self) -> CoreMonthlyTaxDetails:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def monthly_tax_reports(self) -> CoreMonthlyTaxReports:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def operational_groups(self) -> CoreOperationalGroups:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def organization_groups(self) -> CoreOrganizationGroups:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def organization_hierarchies(self) -> CoreOrganizationHierarchies:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def organizations(self) -> CoreOrganizations:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def paygroups(self) -> CorePaygroups:
        """These endpoints let you manage paygroups in the system.\nIt allows you to retrieve, create, update, and delete paygroup records.\n"""
        ...
    @property
    def payroll_process_snapshots(self) -> CorePayrollProcessSnapshots:
        """These endpoints let you manage payroll process snapshots in the system.\nIt allows you to retrieve, create, update, and delete payroll process snapshot records.\n"""
        ...
    @property
    def payslip_additional_notes(self) -> CorePayslipAdditionalNotes:
        """These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n"""
        ...
    @property
    def payslip_layouts(self) -> CorePayslipLayouts:
        """These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n"""
        ...
    @property
    def positions(self) -> CorePositions:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def pph21_policies(self) -> CorePph21Policies:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def pph21_reports(self) -> CorePph21Reports:
        """Resource API"""
        ...
    @property
    def ptkp_categories(self) -> CorePtkpCategories:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def religions(self) -> CoreReligions:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def salary_calculations(self) -> CoreSalaryCalculations:
        """These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n"""
        ...
    @property
    def salary_item_add_on(self) -> CoreSalaryItemAddOn:
        """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""
        ...
    @property
    def salary_items(self) -> CoreSalaryItems:
        """These endpoints let you manage salary items in the system.\nIt allows you to retrieve, create, update, and delete salary item records.\n"""
        ...
    @property
    def salary_payment_summaries(self) -> CoreSalaryPaymentSummaries:
        """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""
        ...
    @property
    def salary_payments(self) -> CoreSalaryPayments:
        """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""
        ...
    @property
    def salary_templates(self) -> CoreSalaryTemplates:
        """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""
        ...
    @property
    def severance_payment_plans(self) -> CoreSeverancePaymentPlans:
        """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""
        ...
    @property
    def severance_plans(self) -> CoreSeverancePlans:
        """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""
        ...
    @property
    def states(self) -> CoreStates:
        """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""
        ...
    @property
    def sub_locations(self) -> CoreSubLocations:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def tax_calculations(self) -> CoreTaxCalculations:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def tax_calculators(self) -> CoreTaxCalculators:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def tax_membership_histories(self) -> CoreTaxMembershipHistories:
        """These endpoints let you manage(retrieve and update) tax membership histories for employees.\n"""
        ...
    @property
    def tax_reports(self) -> CoreTaxReports:
        """Resource API"""
        ...
    @property
    def termination_bpjs_manpower_reasons(self) -> CoreTerminationBpjsManpowerReasons:
        """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""
        ...
    @property
    def termination_entries(self) -> CoreTerminationEntries:
        """Resource API"""
        ...
    @property
    def termination_reason_categories(self) -> CoreTerminationReasonCategories:
        """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""
        ...
    @property
    def termination_reasons(self) -> CoreTerminationReasons:
        """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""
        ...
    @property
    def termination_tax_reasons(self) -> CoreTerminationTaxReasons:
        """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""
        ...
    @property
    def transition_calculations(self) -> CoreTransitionCalculations:
        """Resource API"""
        ...
    @property
    def users(self) -> CoreUsers:
        """These endpoints let you manage users in the system.\nIt allows you to retrieve user information, roles, and permissions.\n"""
        ...
    @property
    def vendors(self) -> CoreVendors:
        """These endpoints let you manage vendor master data in the system.\nIt allows you to retrieve vendor records.\n"""
        ...
    @property
    def workflow_activities(self) -> CoreWorkflowActivities:
        """These endpoints let you manage custom workflows in the system.\n"""
        ...
    @property
    def workflow_reason_categories(self) -> CoreWorkflowReasonCategories:
        """These endpoints let you manage custom workflows in the system.\n"""
        ...
    @property
    def workflow_reasons(self) -> CoreWorkflowReasons:
        """These endpoints let you manage custom workflows in the system.\n"""
        ...

class CoreAdditionalAssignments:
    """Resource API"""
    @property
    def approvals(self) -> CoreAdditionalAssignmentsApprovals:
        """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""
        ...

class CoreAdditionalAssignmentsApprovals(CoreAdditionalAssignmentsApprovalsApi):
    """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""

class CoreAdditionalIncomePayments(CoreAdditionalIncomePaymentsApi):
    """These endpoints let you manage other payroll-related features in the system.\nIt allows you to retrieve, create, update, and delete various payroll records that do not fall under specific categories.\n"""

class CoreAnalytics:
    """Resource API"""
    @property
    def charts(self) -> CoreAnalyticsCharts:
        """These endpoints let you manage analytics features in the system.\nIt consist of various sub-modules related to data analysis, reporting, and visualization.\n"""
        ...

class CoreAnalyticsCharts(CoreAnalyticsChartsApi):
    """These endpoints let you manage analytics features in the system.\nIt consist of various sub-modules related to data analysis, reporting, and visualization.\n"""

class CoreBankAccountConfigurations(CoreBankAccountConfigurationsApi):
    """These endpoints let you manage bank account configurations for employees in the system.\nIt allows you to retrieve, create, update, and delete bank account configuration records.\n"""
    @property
    def approvals(self) -> CoreBankAccountConfigurationsApprovals:
        """These endpoints let you manage bank account configurations for employees in the system.\nIt allows you to retrieve, create, update, and delete bank account configuration records.\n"""
        ...

class CoreBankAccountConfigurationsApprovals(CoreBankAccountConfigurationsApprovalsApi):
    """These endpoints let you manage bank account configurations for employees in the system.\nIt allows you to retrieve, create, update, and delete bank account configuration records.\n"""

class CoreBankBranches(CoreBankBranchesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreBanks(CoreBanksApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreBpjsHealthcarePremiums:
    """Resource API"""
    @property
    def summaries(self) -> CoreBpjsHealthcarePremiumsSummaries:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...

class CoreBpjsHealthcarePremiumsSummaries(CoreBpjsHealthcarePremiumsSummariesApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
    @property
    def details(self) -> CoreBpjsHealthcarePremiumsSummariesDetails:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...

class CoreBpjsHealthcarePremiumsSummariesDetails(CoreBpjsHealthcarePremiumsSummariesDetailsApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsHealthcareProviders(CoreBpjsHealthcareProvidersApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsHealthcareReports:
    """Resource API"""
    @property
    def edabu_advance_members(self) -> CoreBpjsHealthcareReportsEdabuAdvanceMembers:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...
    @property
    def edabu_employee_identity_card_number_check(self) -> CoreBpjsHealthcareReportsEdabuEmployeeIdentityCardNumberCheck:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...
    @property
    def edabu_new_members(self) -> CoreBpjsHealthcareReportsEdabuNewMembers:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...
    @property
    def edabu_wage_update(self) -> CoreBpjsHealthcareReportsEdabuWageUpdate:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...
    @property
    def payment_details(self) -> CoreBpjsHealthcareReportsPaymentDetails:
        """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""
        ...

class CoreBpjsHealthcareReportsEdabuAdvanceMembers(CoreBpjsHealthcareReportsEdabuAdvanceMembersApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsHealthcareReportsEdabuEmployeeIdentityCardNumberCheck(CoreBpjsHealthcareReportsEdabuEmployeeIdentityCardNumberCheckApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsHealthcareReportsEdabuNewMembers(CoreBpjsHealthcareReportsEdabuNewMembersApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsHealthcareReportsEdabuWageUpdate(CoreBpjsHealthcareReportsEdabuWageUpdateApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsHealthcareReportsPaymentDetails(CoreBpjsHealthcareReportsPaymentDetailsApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsHealthcareTemplates(CoreBpjsHealthcareTemplatesApi):
    """These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n"""

class CoreBpjsManpowerPremiums:
    """Resource API"""
    @property
    def summaries(self) -> CoreBpjsManpowerPremiumsSummaries:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...

class CoreBpjsManpowerPremiumsSummaries(CoreBpjsManpowerPremiumsSummariesApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
    @property
    def details(self) -> CoreBpjsManpowerPremiumsSummariesDetails:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...

class CoreBpjsManpowerPremiumsSummariesDetails(CoreBpjsManpowerPremiumsSummariesDetailsApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerProviders(CoreBpjsManpowerProvidersApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerReports:
    """Resource API"""
    @property
    def payment_details(self) -> CoreBpjsManpowerReportsPaymentDetails:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...
    @property
    def pension_debt_report(self) -> CoreBpjsManpowerReportsPensionDebtReport:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...
    @property
    def sipp_advance_members(self) -> CoreBpjsManpowerReportsSippAdvanceMembers:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...
    @property
    def sipp_new_members(self) -> CoreBpjsManpowerReportsSippNewMembers:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...
    @property
    def sipp_terminated_member(self) -> CoreBpjsManpowerReportsSippTerminatedMember:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...
    @property
    def sipp_wage_update(self) -> CoreBpjsManpowerReportsSippWageUpdate:
        """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""
        ...

class CoreBpjsManpowerReportsPaymentDetails(CoreBpjsManpowerReportsPaymentDetailsApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerReportsPensionDebtReport(CoreBpjsManpowerReportsPensionDebtReportApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerReportsSippAdvanceMembers(CoreBpjsManpowerReportsSippAdvanceMembersApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerReportsSippNewMembers(CoreBpjsManpowerReportsSippNewMembersApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerReportsSippTerminatedMember(CoreBpjsManpowerReportsSippTerminatedMemberApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerReportsSippWageUpdate(CoreBpjsManpowerReportsSippWageUpdateApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreBpjsManpowerTemplates(CoreBpjsManpowerTemplatesApi):
    """These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n"""

class CoreCities(CoreCitiesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreCompanies(CoreCompaniesApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreCompanyBankAccounts(CoreCompanyBankAccountsApi):
    """These endpoints let you manage company bank accounts in the system.\nIt allows you to retrieve, create, update, and delete company bank account records.\n"""

class CoreCompanyGroups(CoreCompanyGroupsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreContactInformation(CoreContactInformationApi):
    """These endpoints let you manage contact information for employees in the system.\nIt allows you to retrieve, create, update, and delete contact information records.\n"""

class CoreCostCenters(CoreCostCentersApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreCountries(CoreCountriesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreCurrencies(CoreCurrenciesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreCustomTables(CoreCustomTablesApi):
    """These endpoints let you manage custom tables in the system.\nIt allows you to retrieve, create, update, and delete custom table records.\n"""
    @property
    def entries(self) -> CoreCustomTablesEntries:
        """These endpoints let you manage entries in custom tables in the system.\nIt allows you to retrieve, create, update, and delete custom table entry records.\n"""
        ...

class CoreCustomTablesEntries(CoreCustomTablesEntriesApi):
    """These endpoints let you manage entries in custom tables in the system.\nIt allows you to retrieve, create, update, and delete custom table entry records.\n"""

class CoreEditableSalaryPreprocess(CoreEditableSalaryPreprocessApi):
    """These endpoints let you manage editable salary preprocess settings in the system.\nIt allows you to retrieve, create, update, and delete editable salary preprocess records.\n"""

class CoreEducationLevels(CoreEducationLevelsApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreEducations(CoreEducationsApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreEmployeeDetails(CoreEmployeeDetailsApi):
    """These endpoints let you manage detailed information about employees in the system.\nIt allows you to retrieve and update comprehensive employee profiles, including personal, employment, and other related details.\n"""

class CoreEmployeePaygroups(CoreEmployeePaygroupsApi):
    """These endpoints let you manage paygroups specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific paygroup records.\n"""

class CoreEmployeeVariableMetadata(CoreEmployeeVariableMetadataApi):
    """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""

class CoreEmployeeVariables(CoreEmployeeVariablesApi):
    """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""
    @property
    def aperiodic(self) -> CoreEmployeeVariablesAperiodic:
        """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""
        ...
    @property
    def periodic(self) -> CoreEmployeeVariablesPeriodic:
        """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""
        ...

class CoreEmployeeVariablesAperiodic(CoreEmployeeVariablesAperiodicApi):
    """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""
    @property
    def all(self) -> CoreEmployeeVariablesAperiodicAll:
        """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""
        ...

class CoreEmployeeVariablesAperiodicAll(CoreEmployeeVariablesAperiodicAllApi):
    """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""

class CoreEmployeeVariablesPeriodic(CoreEmployeeVariablesPeriodicApi):
    """These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n"""

class CoreEmployees(CoreEmployeesApi):
    """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""
    @property
    def bank_account_configurations(self) -> CoreEmployeesBankAccountConfigurations:
        """These endpoints let you manage bank account configurations specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific bank account configuration records.\n"""
        ...
    @property
    def bpjs_healthcare_memberships(self) -> CoreEmployeesBpjsHealthcareMemberships:
        """These endpoints let you manage BPJS memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete BPJS membership records.\n"""
        ...
    @property
    def bpjs_manpower_memberships(self) -> CoreEmployeesBpjsManpowerMemberships:
        """These endpoints let you manage BPJS memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete BPJS membership records.\n"""
        ...
    @property
    def contact_information(self) -> CoreEmployeesContactInformation:
        """These endpoints let you manage contact information for employees in the system.\nIt allows you to retrieve, create, update, and delete contact information records.\n"""
        ...
    @property
    def employee_details(self) -> CoreEmployeesEmployeeDetails:
        """These endpoints let you manage detailed information about employees in the system.\nIt allows you to retrieve and update comprehensive employee profiles, including personal, employment, and other related details.\n"""
        ...
    @property
    def employee_identity_cards(self) -> CoreEmployeesEmployeeIdentityCards:
        """These endpoints let you manage identity cards for employees in the system.\nIt allows you to retrieve, create, update, and delete identity card records.\n"""
        ...
    @property
    def employee_salary_templates(self) -> CoreEmployeesEmployeeSalaryTemplates:
        """These endpoints let you manage salary templates specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific salary template records.\n"""
        ...
    @property
    def employment_data(self) -> CoreEmployeesEmploymentData:
        """These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n"""
        ...
    @property
    def families(self) -> CoreEmployeesFamilies:
        """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""
        ...
    @property
    def hiring_data(self) -> CoreEmployeesHiringData:
        """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""
        ...
    @property
    def job_experiences(self) -> CoreEmployeesJobExperiences:
        """Resource API"""
        ...
    @property
    def manager(self) -> CoreEmployeesManager:
        """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""
        ...
    @property
    def payment_item_groups(self) -> CoreEmployeesPaymentItemGroups:
        """Resource API"""
        ...
    @property
    def payslip(self) -> CoreEmployeesPayslip:
        """These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n"""
        ...
    @property
    def supervisors(self) -> CoreEmployeesSupervisors:
        """Resource API"""
        ...
    @property
    def tax_membership_histories(self) -> CoreEmployeesTaxMembershipHistories:
        """These endpoints let you manage(retrieve and update) tax membership histories for employees.\n"""
        ...
    @property
    def tax_memberships(self) -> CoreEmployeesTaxMemberships:
        """These endpoints let you manage tax memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete tax membership records.\n"""
        ...
    @property
    def termination_entries(self) -> CoreEmployeesTerminationEntries:
        """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""
        ...

class CoreEmployeesBankAccountConfigurations(CoreEmployeesBankAccountConfigurationsApi):
    """These endpoints let you manage bank account configurations specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific bank account configuration records.\n"""
    @property
    def histories(self) -> CoreEmployeesBankAccountConfigurationsHistories:
        """These endpoints let you manage bank account configurations specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific bank account configuration records.\n"""
        ...

class CoreEmployeesBankAccountConfigurationsHistories(CoreEmployeesBankAccountConfigurationsHistoriesApi):
    """These endpoints let you manage bank account configurations specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific bank account configuration records.\n"""

class CoreEmployeesBpjsHealthcareMemberships(CoreEmployeesBpjsHealthcareMembershipsApi):
    """These endpoints let you manage BPJS memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete BPJS membership records.\n"""

class CoreEmployeesBpjsManpowerMemberships(CoreEmployeesBpjsManpowerMembershipsApi):
    """These endpoints let you manage BPJS memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete BPJS membership records.\n"""

class CoreEmployeesContactInformation(CoreEmployeesContactInformationApi):
    """These endpoints let you manage contact information for employees in the system.\nIt allows you to retrieve, create, update, and delete contact information records.\n"""

class CoreEmployeesEmployeeDetails(CoreEmployeesEmployeeDetailsApi):
    """These endpoints let you manage detailed information about employees in the system.\nIt allows you to retrieve and update comprehensive employee profiles, including personal, employment, and other related details.\n"""

class CoreEmployeesEmployeeIdentityCards(CoreEmployeesEmployeeIdentityCardsApi):
    """These endpoints let you manage identity cards for employees in the system.\nIt allows you to retrieve, create, update, and delete identity card records.\n"""

class CoreEmployeesEmployeeSalaryTemplates(CoreEmployeesEmployeeSalaryTemplatesApi):
    """These endpoints let you manage salary templates specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific salary template records.\n"""
    @property
    def effective(self) -> CoreEmployeesEmployeeSalaryTemplatesEffective:
        """These endpoints let you manage salary templates specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific salary template records.\n"""
        ...

class CoreEmployeesEmployeeSalaryTemplatesEffective(CoreEmployeesEmployeeSalaryTemplatesEffectiveApi):
    """These endpoints let you manage salary templates specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific salary template records.\n"""

class CoreEmployeesEmploymentData(CoreEmployeesEmploymentDataApi):
    """These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n"""

class CoreEmployeesFamilies(CoreEmployeesFamiliesApi):
    """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""
    @property
    def approvals(self) -> CoreEmployeesFamiliesApprovals:
        """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""
        ...

class CoreEmployeesFamiliesApprovals(CoreEmployeesFamiliesApprovalsApi):
    """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""

class CoreEmployeesHiringData(CoreEmployeesHiringDataApi):
    """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""

class CoreEmployeesJobExperiences:
    """Resource API"""
    @property
    def approvals(self) -> CoreEmployeesJobExperiencesApprovals:
        """These endpoints let you manage job experience records for employees in the system.\nIt allows you to retrieve job experience approval records.\n"""
        ...

class CoreEmployeesJobExperiencesApprovals(CoreEmployeesJobExperiencesApprovalsApi):
    """These endpoints let you manage job experience records for employees in the system.\nIt allows you to retrieve job experience approval records.\n"""

class CoreEmployeesManager(CoreEmployeesManagerApi):
    """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""

class CoreEmployeesPaymentItemGroups:
    """Resource API"""
    @property
    def last_sequence(self) -> CoreEmployeesPaymentItemGroupsLastSequence:
        """These endpoints let you manage payment item group sequences for employees.\nIt allows you to retrieve sequences related to payment item groups (or payroll processes).\nThis is useful for payroll processing and ensuring accurate payment calculations.\nIt is created after a payroll process is completed, and it is used to track the sequence of payment item groups \nfor each employee.\n"""
        ...
    @property
    def sequences(self) -> CoreEmployeesPaymentItemGroupsSequences:
        """These endpoints let you manage payment item group sequences for employees.\nIt allows you to retrieve sequences related to payment item groups (or payroll processes).\nThis is useful for payroll processing and ensuring accurate payment calculations.\nIt is created after a payroll process is completed, and it is used to track the sequence of payment item groups \nfor each employee.\n"""
        ...

class CoreEmployeesPaymentItemGroupsLastSequence(CoreEmployeesPaymentItemGroupsLastSequenceApi):
    """These endpoints let you manage payment item group sequences for employees.\nIt allows you to retrieve sequences related to payment item groups (or payroll processes).\nThis is useful for payroll processing and ensuring accurate payment calculations.\nIt is created after a payroll process is completed, and it is used to track the sequence of payment item groups \nfor each employee.\n"""

class CoreEmployeesPaymentItemGroupsSequences(CoreEmployeesPaymentItemGroupsSequencesApi):
    """These endpoints let you manage payment item group sequences for employees.\nIt allows you to retrieve sequences related to payment item groups (or payroll processes).\nThis is useful for payroll processing and ensuring accurate payment calculations.\nIt is created after a payroll process is completed, and it is used to track the sequence of payment item groups \nfor each employee.\n"""

class CoreEmployeesPayslip(CoreEmployeesPayslipApi):
    """These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n"""
    @property
    def severance(self) -> CoreEmployeesPayslipSeverance:
        """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""
        ...

class CoreEmployeesPayslipSeverance(CoreEmployeesPayslipSeveranceApi):
    """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""

class CoreEmployeesSupervisors:
    """Resource API"""
    @property
    def approvals(self) -> CoreEmployeesSupervisorsApprovals:
        """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""
        ...

class CoreEmployeesSupervisorsApprovals(CoreEmployeesSupervisorsApprovalsApi):
    """These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n"""

class CoreEmployeesTaxMembershipHistories(CoreEmployeesTaxMembershipHistoriesApi):
    """These endpoints let you manage(retrieve and update) tax membership histories for employees.\n"""

class CoreEmployeesTaxMemberships(CoreEmployeesTaxMembershipsApi):
    """These endpoints let you manage tax memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete tax membership records.\n"""
    @property
    def tax_subjects(self) -> CoreEmployeesTaxMembershipsTaxSubjects:
        """These endpoints let you manage tax memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete tax membership records.\n"""
        ...

class CoreEmployeesTaxMembershipsTaxSubjects(CoreEmployeesTaxMembershipsTaxSubjectsApi):
    """These endpoints let you manage tax memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete tax membership records.\n"""

class CoreEmployeesTerminationEntries(CoreEmployeesTerminationEntriesApi):
    """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""

class CoreEmploymentStatusHistories(CoreEmploymentStatusHistoriesApi):
    """These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n"""

class CoreEmploymentStatusTypes(CoreEmploymentStatusTypesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreEmploymentStatuses(CoreEmploymentStatusesApi):
    """These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n"""

class CoreEmploymentTypes(CoreEmploymentTypesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreFamilies(CoreFamiliesApi):
    """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""
    @property
    def approvals(self) -> CoreFamiliesApprovals:
        """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""
        ...

class CoreFamiliesApprovals(CoreFamiliesApprovalsApi):
    """These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n"""

class CoreFamilyRelations(CoreFamilyRelationsApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreFieldOfStudies(CoreFieldOfStudiesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreFormerEmployeeIncomeEmployees(CoreFormerEmployeeIncomeEmployeesApi):
    """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""

class CoreFormerEmployeeIncomes(CoreFormerEmployeeIncomesApi):
    """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""
    @property
    def former_employee_income_employees(self) -> CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployees:
        """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""
        ...

class CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployees(CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployeesApi):
    """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""
    @property
    def amounts(self) -> CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployeesAmounts:
        """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""
        ...

class CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployeesAmounts(CoreFormerEmployeeIncomesFormerEmployeeIncomeEmployeesAmountsApi):
    """These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n"""

class CoreIdentityCards(CoreIdentityCardsApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreInstitutions(CoreInstitutionsApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreJobExperiences:
    """Resource API"""
    @property
    def approvals(self) -> CoreJobExperiencesApprovals:
        """These endpoints let you manage job experience records for employees in the system.\nIt allows you to retrieve job experience approval records.\n"""
        ...

class CoreJobExperiencesApprovals(CoreJobExperiencesApprovalsApi):
    """These endpoints let you manage job experience records for employees in the system.\nIt allows you to retrieve job experience approval records.\n"""

class CoreJobLevels(CoreJobLevelsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreJobTitleLevels(CoreJobTitleLevelsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreJobTitles(CoreJobTitlesApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreKpps(CoreKppsApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreLocationGroups(CoreLocationGroupsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreLocations(CoreLocationsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreMonthlyRecapitulation(CoreMonthlyRecapitulationApi):
    """These endpoints let you manage other payroll-related features in the system.\nIt allows you to retrieve, create, update, and delete various payroll records that do not fall under specific categories.\n"""

class CoreMonthlyTaxDetails(CoreMonthlyTaxDetailsApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreMonthlyTaxReports(CoreMonthlyTaxReportsApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreOperationalGroups(CoreOperationalGroupsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreOrganizationGroups(CoreOrganizationGroupsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreOrganizationHierarchies(CoreOrganizationHierarchiesApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreOrganizations(CoreOrganizationsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
    @property
    def heads(self) -> CoreOrganizationsHeads:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def histories(self) -> CoreOrganizationsHistories:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def superiors(self) -> CoreOrganizationsSuperiors:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...

class CoreOrganizationsHeads(CoreOrganizationsHeadsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreOrganizationsHistories(CoreOrganizationsHistoriesApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreOrganizationsSuperiors(CoreOrganizationsSuperiorsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CorePaygroups(CorePaygroupsApi):
    """These endpoints let you manage paygroups in the system.\nIt allows you to retrieve, create, update, and delete paygroup records.\n"""

class CorePayrollProcessSnapshots(CorePayrollProcessSnapshotsApi):
    """These endpoints let you manage payroll process snapshots in the system.\nIt allows you to retrieve, create, update, and delete payroll process snapshot records.\n"""

class CorePayslipAdditionalNotes(CorePayslipAdditionalNotesApi):
    """These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n"""

class CorePayslipLayouts(CorePayslipLayoutsApi):
    """These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n"""

class CorePositions(CorePositionsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
    @property
    def cost_centers(self) -> CorePositionsCostCenters:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def histories(self) -> CorePositionsHistories:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...
    @property
    def vacancy_statuses(self) -> CorePositionsVacancyStatuses:
        """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""
        ...

class CorePositionsCostCenters(CorePositionsCostCentersApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CorePositionsHistories(CorePositionsHistoriesApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CorePositionsVacancyStatuses(CorePositionsVacancyStatusesApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CorePph21Policies(CorePph21PoliciesApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CorePph21Reports:
    """Resource API"""
    @property
    def by_1721_vi(self) -> CorePph21ReportsBy1721Vi:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def by_1721_vii(self) -> CorePph21ReportsBy1721Vii:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CorePph21ReportsBy1721Vi(CorePph21ReportsBy1721ViApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
    @property
    def detail(self) -> CorePph21ReportsBy1721ViDetail:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def download(self) -> CorePph21ReportsBy1721ViDownload:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CorePph21ReportsBy1721ViDetail(CorePph21ReportsBy1721ViDetailApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CorePph21ReportsBy1721ViDownload(CorePph21ReportsBy1721ViDownloadApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CorePph21ReportsBy1721Vii(CorePph21ReportsBy1721ViiApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
    @property
    def download(self) -> CorePph21ReportsBy1721ViiDownload:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CorePph21ReportsBy1721ViiDownload(CorePph21ReportsBy1721ViiDownloadApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CorePtkpCategories(CorePtkpCategoriesApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreReligions(CoreReligionsApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreSalaryCalculations(CoreSalaryCalculationsApi):
    """These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n"""
    @property
    def details(self) -> CoreSalaryCalculationsDetails:
        """These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n"""
        ...

class CoreSalaryCalculationsDetails(CoreSalaryCalculationsDetailsApi):
    """These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n"""
    @property
    def time_allowance_details(self) -> CoreSalaryCalculationsDetailsTimeAllowanceDetails:
        """These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n"""
        ...

class CoreSalaryCalculationsDetailsTimeAllowanceDetails(CoreSalaryCalculationsDetailsTimeAllowanceDetailsApi):
    """These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n"""

class CoreSalaryItemAddOn(CoreSalaryItemAddOnApi):
    """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""
    @property
    def add(self) -> CoreSalaryItemAddOnAdd:
        """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""
        ...
    @property
    def subtract(self) -> CoreSalaryItemAddOnSubtract:
        """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""
        ...

class CoreSalaryItemAddOnAdd(CoreSalaryItemAddOnAddApi):
    """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""

class CoreSalaryItemAddOnSubtract(CoreSalaryItemAddOnSubtractApi):
    """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""

class CoreSalaryItems(CoreSalaryItemsApi):
    """These endpoints let you manage salary items in the system.\nIt allows you to retrieve, create, update, and delete salary item records.\n"""

class CoreSalaryPaymentSummaries(CoreSalaryPaymentSummariesApi):
    """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""

class CoreSalaryPayments(CoreSalaryPaymentsApi):
    """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""
    @property
    def dates(self) -> CoreSalaryPaymentsDates:
        """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""
        ...
    @property
    def payment_item_groups(self) -> CoreSalaryPaymentsPaymentItemGroups:
        """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""
        ...
    @property
    def process(self) -> CoreSalaryPaymentsProcess:
        """Resource API"""
        ...

class CoreSalaryPaymentsDates(CoreSalaryPaymentsDatesApi):
    """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""

class CoreSalaryPaymentsPaymentItemGroups(CoreSalaryPaymentsPaymentItemGroupsApi):
    """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""

class CoreSalaryPaymentsProcess:
    """Resource API"""
    @property
    def processable(self) -> CoreSalaryPaymentsProcessProcessable:
        """Resource API"""
        ...

class CoreSalaryPaymentsProcessProcessable:
    """Resource API"""
    @property
    def processed(self) -> CoreSalaryPaymentsProcessProcessableProcessed:
        """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""
        ...

class CoreSalaryPaymentsProcessProcessableProcessed(CoreSalaryPaymentsProcessProcessableProcessedApi):
    """These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n"""

class CoreSalaryTemplates(CoreSalaryTemplatesApi):
    """These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n"""

class CoreSeverancePaymentPlans(CoreSeverancePaymentPlansApi):
    """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""

class CoreSeverancePlans(CoreSeverancePlansApi):
    """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""

class CoreStates(CoreStatesApi):
    """These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n"""

class CoreSubLocations(CoreSubLocationsApi):
    """These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n"""

class CoreTaxCalculations(CoreTaxCalculationsApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreTaxCalculators(CoreTaxCalculatorsApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
    @property
    def monthly(self) -> CoreTaxCalculatorsMonthly:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CoreTaxCalculatorsMonthly(CoreTaxCalculatorsMonthlyApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreTaxMembershipHistories(CoreTaxMembershipHistoriesApi):
    """These endpoints let you manage(retrieve and update) tax membership histories for employees.\n"""
    @property
    def tax_subjects(self) -> CoreTaxMembershipHistoriesTaxSubjects:
        """These endpoints let you manage(retrieve and update) tax membership histories for employees.\n"""
        ...

class CoreTaxMembershipHistoriesTaxSubjects(CoreTaxMembershipHistoriesTaxSubjectsApi):
    """These endpoints let you manage(retrieve and update) tax membership histories for employees.\n"""

class CoreTaxReports:
    """Resource API"""
    @property
    def by_1721_a1(self) -> CoreTaxReportsBy1721A1:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def by_1721_vi(self) -> CoreTaxReportsBy1721Vi:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def by_1721_vii(self) -> CoreTaxReportsBy1721Vii:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def by_1721_viii(self) -> CoreTaxReportsBy1721Viii:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CoreTaxReportsBy1721A1(CoreTaxReportsBy1721A1Api):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
    @property
    def download(self) -> CoreTaxReportsBy1721A1Download:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CoreTaxReportsBy1721A1Download(CoreTaxReportsBy1721A1DownloadApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreTaxReportsBy1721Vi(CoreTaxReportsBy1721ViApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
    @property
    def detail(self) -> CoreTaxReportsBy1721ViDetail:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...
    @property
    def download(self) -> CoreTaxReportsBy1721ViDownload:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CoreTaxReportsBy1721ViDetail(CoreTaxReportsBy1721ViDetailApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreTaxReportsBy1721ViDownload(CoreTaxReportsBy1721ViDownloadApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreTaxReportsBy1721Vii(CoreTaxReportsBy1721ViiApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
    @property
    def download(self) -> CoreTaxReportsBy1721ViiDownload:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CoreTaxReportsBy1721ViiDownload(CoreTaxReportsBy1721ViiDownloadApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreTaxReportsBy1721Viii(CoreTaxReportsBy1721ViiiApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
    @property
    def download(self) -> CoreTaxReportsBy1721ViiiDownload:
        """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""
        ...

class CoreTaxReportsBy1721ViiiDownload(CoreTaxReportsBy1721ViiiDownloadApi):
    """These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n"""

class CoreTerminationBpjsManpowerReasons(CoreTerminationBpjsManpowerReasonsApi):
    """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""

class CoreTerminationEntries:
    """Resource API"""
    @property
    def severance_plans(self) -> CoreTerminationEntriesSeverancePlans:
        """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""
        ...

class CoreTerminationEntriesSeverancePlans(CoreTerminationEntriesSeverancePlansApi):
    """These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n"""

class CoreTerminationReasonCategories(CoreTerminationReasonCategoriesApi):
    """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""

class CoreTerminationReasons(CoreTerminationReasonsApi):
    """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""

class CoreTerminationTaxReasons(CoreTerminationTaxReasonsApi):
    """These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n"""

class CoreTransitionCalculations:
    """Resource API"""
    @property
    def process(self) -> CoreTransitionCalculationsProcess:
        """Resource API"""
        ...
    @property
    def time_allowances(self) -> CoreTransitionCalculationsTimeAllowances:
        """Resource API"""
        ...

class CoreTransitionCalculationsProcess:
    """Resource API"""
    @property
    def count(self) -> CoreTransitionCalculationsProcessCount:
        """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""
        ...
    @property
    def processable(self) -> CoreTransitionCalculationsProcessProcessable:
        """Resource API"""
        ...

class CoreTransitionCalculationsProcessCount(CoreTransitionCalculationsProcessCountApi):
    """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""

class CoreTransitionCalculationsProcessProcessable:
    """Resource API"""
    @property
    def processed(self) -> CoreTransitionCalculationsProcessProcessableProcessed:
        """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""
        ...
    @property
    def unprocessed(self) -> CoreTransitionCalculationsProcessProcessableUnprocessed:
        """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""
        ...

class CoreTransitionCalculationsProcessProcessableProcessed(CoreTransitionCalculationsProcessProcessableProcessedApi):
    """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""

class CoreTransitionCalculationsProcessProcessableUnprocessed(CoreTransitionCalculationsProcessProcessableUnprocessedApi):
    """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""

class CoreTransitionCalculationsTimeAllowances:
    """Resource API"""
    @property
    def process(self) -> CoreTransitionCalculationsTimeAllowancesProcess:
        """Resource API"""
        ...

class CoreTransitionCalculationsTimeAllowancesProcess:
    """Resource API"""
    @property
    def processable(self) -> CoreTransitionCalculationsTimeAllowancesProcessProcessable:
        """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""
        ...

class CoreTransitionCalculationsTimeAllowancesProcessProcessable(CoreTransitionCalculationsTimeAllowancesProcessProcessableApi):
    """These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n"""

class CoreUsers(CoreUsersApi):
    """These endpoints let you manage users in the system.\nIt allows you to retrieve user information, roles, and permissions.\n"""
    @property
    def me(self) -> CoreUsersMe:
        """Resource API"""
        ...

class CoreUsersMe:
    """Resource API"""
    @property
    def analytics(self) -> CoreUsersMeAnalytics:
        """Resource API"""
        ...
    @property
    def widgets(self) -> CoreUsersMeWidgets:
        """These endpoints let you manage widgets in the system.\nIt allows you to retrieve, create, update, and delete widget records.\n"""
        ...

class CoreUsersMeAnalytics:
    """Resource API"""
    @property
    def charts(self) -> CoreUsersMeAnalyticsCharts:
        """Resource API"""
        ...

class CoreUsersMeAnalyticsCharts:
    """Resource API"""
    @property
    def data(self) -> CoreUsersMeAnalyticsChartsData:
        """These endpoints let you manage analytics features in the system.\nIt consist of various sub-modules related to data analysis, reporting, and visualization.\n"""
        ...

class CoreUsersMeAnalyticsChartsData(CoreUsersMeAnalyticsChartsDataApi):
    """These endpoints let you manage analytics features in the system.\nIt consist of various sub-modules related to data analysis, reporting, and visualization.\n"""

class CoreUsersMeWidgets(CoreUsersMeWidgetsApi):
    """These endpoints let you manage widgets in the system.\nIt allows you to retrieve, create, update, and delete widget records.\n"""

class CoreVendors(CoreVendorsApi):
    """These endpoints let you manage vendor master data in the system.\nIt allows you to retrieve vendor records.\n"""

class CoreWorkflowActivities(CoreWorkflowActivitiesApi):
    """These endpoints let you manage custom workflows in the system.\n"""

class CoreWorkflowReasonCategories(CoreWorkflowReasonCategoriesApi):
    """These endpoints let you manage custom workflows in the system.\n"""

class CoreWorkflowReasons(CoreWorkflowReasonsApi):
    """These endpoints let you manage custom workflows in the system.\n"""

class OauthClients(OauthClientsApi):
    """These endpoints let you manage OAuth clients in the system.\n"""
    @property
    def validate_access_token(self) -> OauthClientsValidateAccessToken:
        """OAuth 2.0 token endpoint for authentication.\n"""
        ...

class OauthClientsValidateAccessToken(OauthClientsValidateAccessTokenApi):
    """OAuth 2.0 token endpoint for authentication.\n"""

class Roles(RolesApi):
    """These endpoints let you manage roles in the system.\n"""
    @property
    def authorities(self) -> RolesAuthorities:
        """These endpoints let you manage roles in the system.\n"""
        ...
    @property
    def permissions(self) -> RolesPermissions:
        """These endpoints let you manage roles in the system.\n"""
        ...

class RolesAuthorities(RolesAuthoritiesApi):
    """These endpoints let you manage roles in the system.\n"""

class RolesPermissions(RolesPermissionsApi):
    """These endpoints let you manage roles in the system.\n"""

class Timemanagement:
    """Resource API"""
    @property
    def absence_entries(self) -> TimemanagementAbsenceEntries:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def attendance_cancellations(self) -> TimemanagementAttendanceCancellations:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def attendance_recapitulations(self) -> TimemanagementAttendanceRecapitulations:
        """Resource API"""
        ...
    @property
    def attendances(self) -> TimemanagementAttendances:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def employee_workday_configurations(self) -> TimemanagementEmployeeWorkdayConfigurations:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def fingerprints(self) -> TimemanagementFingerprints:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def holidays(self) -> TimemanagementHolidays:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def leave_balances(self) -> TimemanagementLeaveBalances:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def other_leave_balances(self) -> TimemanagementOtherLeaveBalances:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def shift_pattern_templates(self) -> TimemanagementShiftPatternTemplates:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...
    @property
    def workgroup_workday_configurations(self) -> TimemanagementWorkgroupWorkdayConfigurations:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...

class TimemanagementAbsenceEntries(TimemanagementAbsenceEntriesApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementAttendanceCancellations(TimemanagementAttendanceCancellationsApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementAttendanceRecapitulations:
    """Resource API"""
    @property
    def details(self) -> TimemanagementAttendanceRecapitulationsDetails:
        """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""
        ...

class TimemanagementAttendanceRecapitulationsDetails(TimemanagementAttendanceRecapitulationsDetailsApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementAttendances(TimemanagementAttendancesApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementEmployeeWorkdayConfigurations(TimemanagementEmployeeWorkdayConfigurationsApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementFingerprints(TimemanagementFingerprintsApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementHolidays(TimemanagementHolidaysApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementLeaveBalances(TimemanagementLeaveBalancesApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementOtherLeaveBalances(TimemanagementOtherLeaveBalancesApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementShiftPatternTemplates(TimemanagementShiftPatternTemplatesApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class TimemanagementWorkgroupWorkdayConfigurations(TimemanagementWorkgroupWorkdayConfigurationsApi):
    """These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n"""

class Users:
    """Resource API"""
    @property
    def me(self) -> UsersMe:
        """These endpoints let you manage users in the system.\nIt allows you to retrieve user information, roles, and permissions.\n"""
        ...

class UsersMe(UsersMeApi):
    """These endpoints let you manage users in the system.\nIt allows you to retrieve user information, roles, and permissions.\n"""

# Main SDK client class
class Catapa:
    config: CatapaConfig
    configuration: Configuration
    default_headers: dict[str, str]

    def __init__(
        self,
        tenant: str,
        client_id: str,
        client_secret: str,
        base_url: str = "https://api.catapa.com",
        grant_type: GrantType | None = None,
    ) -> None: ...

    @property
    def anomalydetection(self) -> Anomalydetection:
        """Resource API"""
        ...
    @property
    def core(self) -> Core:
        """Resource API"""
        ...
    @property
    def oauth_clients(self) -> OauthClients:
        """These endpoints let you manage OAuth clients in the system.\n"""
        ...
    @property
    def roles(self) -> Roles:
        """These endpoints let you manage roles in the system.\n"""
        ...
    @property
    def timemanagement(self) -> Timemanagement:
        """Resource API"""
        ...
    @property
    def users(self) -> Users:
        """Resource API"""
        ...

    def get_configuration(self) -> Configuration: ...
    def refresh_auth(self) -> None: ...
