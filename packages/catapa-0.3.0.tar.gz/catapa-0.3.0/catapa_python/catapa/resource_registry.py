"""Auto-generated. Do not edit manually."""

from catapa.resource_node import ResourceNode

ROOT_RESOURCES: list[ResourceNode] = [
    ResourceNode(
            resource_chain=['anomalydetection'],
            description="Resource API",
            children=[
                ResourceNode(
                        resource_chain=['anomalydetection', 'anomaly_detection_types'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['anomalydetection', 'anomaly_detection_types', 'anomaly_suspects'],
                                    description="These endpoints let you manage anomaly detection features in the system.\n  It allows you to retrieve and configure anomaly detection settings for various modules.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
            ],
            is_api=False
        )
,
    ResourceNode(
            resource_chain=['core'],
            description="Resource API",
            children=[
                ResourceNode(
                        resource_chain=['core', 'additional_assignments'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'additional_assignments', 'approvals'],
                                    description="These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'additional_income_payments'],
                        description="These endpoints let you manage other payroll-related features in the system.\nIt allows you to retrieve, create, update, and delete various payroll records that do not fall under specific categories.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'analytics'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'analytics', 'charts'],
                                    description="These endpoints let you manage analytics features in the system.\nIt consist of various sub-modules related to data analysis, reporting, and visualization.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bank_account_configurations'],
                        description="These endpoints let you manage bank account configurations for employees in the system.\nIt allows you to retrieve, create, update, and delete bank account configuration records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'bank_account_configurations', 'approvals'],
                                    description="These endpoints let you manage bank account configurations for employees in the system.\nIt allows you to retrieve, create, update, and delete bank account configuration records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bank_branches'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'banks'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_healthcare_premiums'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_healthcare_premiums', 'summaries'],
                                    description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'bpjs_healthcare_premiums', 'summaries', 'details'],
                                                description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_healthcare_providers'],
                        description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_healthcare_reports'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_healthcare_reports', 'edabu_advance_members'],
                                    description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_healthcare_reports', 'edabu_employee_identity_card_number_check'],
                                    description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_healthcare_reports', 'edabu_new_members'],
                                    description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_healthcare_reports', 'edabu_wage_update'],
                                    description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_healthcare_reports', 'payment_details'],
                                    description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_healthcare_templates'],
                        description="These endpoints let you manage BPJS Healthcare features in the system.\nIt allows you to retrieve BPJS Healthcare configurations, calculate related contributions, and manage BPJS Healthcare records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_manpower_premiums'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_manpower_premiums', 'summaries'],
                                    description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'bpjs_manpower_premiums', 'summaries', 'details'],
                                                description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_manpower_providers'],
                        description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_manpower_reports'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_manpower_reports', 'payment_details'],
                                    description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_manpower_reports', 'pension_debt_report'],
                                    description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_manpower_reports', 'sipp_advance_members'],
                                    description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_manpower_reports', 'sipp_new_members'],
                                    description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_manpower_reports', 'sipp_terminated_member'],
                                    description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'bpjs_manpower_reports', 'sipp_wage_update'],
                                    description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'bpjs_manpower_templates'],
                        description="These endpoints let you manage BPJS Manpower features in the system.\nIt allows you to retrieve BPJS Manpower configurations, calculate related contributions, and manage BPJS Manpower records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'cities'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'companies'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'company_bank_accounts'],
                        description="These endpoints let you manage company bank accounts in the system.\nIt allows you to retrieve, create, update, and delete company bank account records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'company_groups'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'contact_information'],
                        description="These endpoints let you manage contact information for employees in the system.\nIt allows you to retrieve, create, update, and delete contact information records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'cost_centers'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'countries'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'currencies'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'custom_tables'],
                        description="These endpoints let you manage custom tables in the system.\nIt allows you to retrieve, create, update, and delete custom table records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'custom_tables', 'entries'],
                                    description="These endpoints let you manage entries in custom tables in the system.\nIt allows you to retrieve, create, update, and delete custom table entry records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'editable_salary_preprocess'],
                        description="These endpoints let you manage editable salary preprocess settings in the system.\nIt allows you to retrieve, create, update, and delete editable salary preprocess records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'education_levels'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'educations'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employee_details'],
                        description="These endpoints let you manage detailed information about employees in the system.\nIt allows you to retrieve and update comprehensive employee profiles, including personal, employment, and other related details.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employee_paygroups'],
                        description="These endpoints let you manage paygroups specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific paygroup records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employee_variable_metadata'],
                        description="These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employee_variables'],
                        description="These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'employee_variables', 'aperiodic'],
                                    description="These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employee_variables', 'aperiodic', 'all'],
                                                description="These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employee_variables', 'periodic'],
                                    description="These endpoints let you manage employee variables in the system.\nIt allows you to retrieve and update custom variables associated with employees.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employees'],
                        description="These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'bank_account_configurations'],
                                    description="These endpoints let you manage bank account configurations specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific bank account configuration records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'bank_account_configurations', 'histories'],
                                                description="These endpoints let you manage bank account configurations specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific bank account configuration records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'bpjs_healthcare_memberships'],
                                    description="These endpoints let you manage BPJS memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete BPJS membership records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'bpjs_manpower_memberships'],
                                    description="These endpoints let you manage BPJS memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete BPJS membership records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'contact_information'],
                                    description="These endpoints let you manage contact information for employees in the system.\nIt allows you to retrieve, create, update, and delete contact information records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'employee_details'],
                                    description="These endpoints let you manage detailed information about employees in the system.\nIt allows you to retrieve and update comprehensive employee profiles, including personal, employment, and other related details.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'employee_identity_cards'],
                                    description="These endpoints let you manage identity cards for employees in the system.\nIt allows you to retrieve, create, update, and delete identity card records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'employee_salary_templates'],
                                    description="These endpoints let you manage salary templates specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific salary template records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'employee_salary_templates', 'effective'],
                                                description="These endpoints let you manage salary templates specific to employees in the system.\nIt allows you to retrieve, create, update, and delete employee-specific salary template records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'employment_data'],
                                    description="These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'families'],
                                    description="These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'families', 'approvals'],
                                                description="These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'hiring_data'],
                                    description="These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'job_experiences'],
                                    description="Resource API",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'job_experiences', 'approvals'],
                                                description="These endpoints let you manage job experience records for employees in the system.\nIt allows you to retrieve job experience approval records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=False
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'manager'],
                                    description="These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'payment_item_groups'],
                                    description="Resource API",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'payment_item_groups', 'last_sequence'],
                                                description="These endpoints let you manage payment item group sequences for employees.\nIt allows you to retrieve sequences related to payment item groups (or payroll processes).\nThis is useful for payroll processing and ensuring accurate payment calculations.\nIt is created after a payroll process is completed, and it is used to track the sequence of payment item groups \nfor each employee.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'payment_item_groups', 'sequences'],
                                                description="These endpoints let you manage payment item group sequences for employees.\nIt allows you to retrieve sequences related to payment item groups (or payroll processes).\nThis is useful for payroll processing and ensuring accurate payment calculations.\nIt is created after a payroll process is completed, and it is used to track the sequence of payment item groups \nfor each employee.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=False
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'payslip'],
                                    description="These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'payslip', 'severance'],
                                                description="These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'supervisors'],
                                    description="Resource API",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'supervisors', 'approvals'],
                                                description="These endpoints let you manage employees in the system.\nIt allows you to retrieve and update employee data, including personal details, employment status, and more.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=False
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'tax_membership_histories'],
                                    description="These endpoints let you manage(retrieve and update) tax membership histories for employees.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'tax_memberships'],
                                    description="These endpoints let you manage tax memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete tax membership records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'employees', 'tax_memberships', 'tax_subjects'],
                                                description="These endpoints let you manage tax memberships for employees in the system.\nIt allows you to retrieve, create, update, and delete tax membership records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'employees', 'termination_entries'],
                                    description="These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employment_status_histories'],
                        description="These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employment_status_types'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employment_statuses'],
                        description="These endpoints let you manage employment statuses in the system.\nIt allows you to retrieve, create, update, and delete employment status records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'employment_types'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'families'],
                        description="These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'families', 'approvals'],
                                    description="These endpoints let you manage family information for employees in the system.\nIt allows you to retrieve, create, update, and delete family records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'family_relations'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'field_of_studies'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'former_employee_income_employees'],
                        description="These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'former_employee_incomes'],
                        description="These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'former_employee_incomes', 'former_employee_income_employees'],
                                    description="These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'former_employee_incomes', 'former_employee_income_employees', 'amounts'],
                                                description="These endpoints let you manage former employee income features in the system.\nIt allows you to retrieve former employee income configurations, calculate related contributions, and manage former employee income records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'identity_cards'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'institutions'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'job_experiences'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'job_experiences', 'approvals'],
                                    description="These endpoints let you manage job experience records for employees in the system.\nIt allows you to retrieve job experience approval records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'job_levels'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'job_title_levels'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'job_titles'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'kpps'],
                        description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'location_groups'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'locations'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'monthly_recapitulation'],
                        description="These endpoints let you manage other payroll-related features in the system.\nIt allows you to retrieve, create, update, and delete various payroll records that do not fall under specific categories.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'monthly_tax_details'],
                        description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'monthly_tax_reports'],
                        description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'operational_groups'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'organization_groups'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'organization_hierarchies'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'organizations'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'organizations', 'heads'],
                                    description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'organizations', 'histories'],
                                    description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'organizations', 'superiors'],
                                    description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'paygroups'],
                        description="These endpoints let you manage paygroups in the system.\nIt allows you to retrieve, create, update, and delete paygroup records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'payroll_process_snapshots'],
                        description="These endpoints let you manage payroll process snapshots in the system.\nIt allows you to retrieve, create, update, and delete payroll process snapshot records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'payslip_additional_notes'],
                        description="These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'payslip_layouts'],
                        description="These endpoints let you manage payslip features in the system.\nIt allows you to generate, retrieve, and manage payslip records for employees.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'positions'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'positions', 'cost_centers'],
                                    description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'positions', 'histories'],
                                    description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'positions', 'vacancy_statuses'],
                                    description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'pph21_policies'],
                        description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'pph21_reports'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'pph21_reports', 'by_1721_vi'],
                                    description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'pph21_reports', 'by_1721_vi', 'detail'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                        ResourceNode(
                                                resource_chain=['core', 'pph21_reports', 'by_1721_vi', 'download'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'pph21_reports', 'by_1721_vii'],
                                    description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'pph21_reports', 'by_1721_vii', 'download'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'ptkp_categories'],
                        description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'religions'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'salary_calculations'],
                        description="These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'salary_calculations', 'details'],
                                    description="These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'salary_calculations', 'details', 'time_allowance_details'],
                                                description="These endpoints let you manage salary calculations in the system.\nIt allows you to perform salary calculations based on various parameters and settings.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'salary_item_add_on'],
                        description="These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'salary_item_add_on', 'add'],
                                    description="These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'salary_item_add_on', 'subtract'],
                                    description="These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'salary_items'],
                        description="These endpoints let you manage salary items in the system.\nIt allows you to retrieve, create, update, and delete salary item records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'salary_payment_summaries'],
                        description="These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'salary_payments'],
                        description="These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'salary_payments', 'dates'],
                                    description="These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'salary_payments', 'payment_item_groups'],
                                    description="These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'salary_payments', 'process'],
                                    description="Resource API",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'salary_payments', 'process', 'processable'],
                                                description="Resource API",
                                                children=[
                                                    ResourceNode(
                                                            resource_chain=['core', 'salary_payments', 'process', 'processable', 'processed'],
                                                            description="These endpoints let you manage salary payment features in the system.\nIt allows you to process salary payments, retrieve payment records, and manage related configurations.\n",
                                                            children=[
                                                            ],
                                                            is_api=True
                                                        )
,
                                                ],
                                                is_api=False
                                            )
,
                                    ],
                                    is_api=False
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'salary_templates'],
                        description="These endpoints let you manage salary templates in the system.\nIt allows you to retrieve, create, update, and delete salary template records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'severance_payment_plans'],
                        description="These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'severance_plans'],
                        description="These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'states'],
                        description="These endpoints let you manage master data in the system.\nIt allows you to retrieve, create, update, and delete master data records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'sub_locations'],
                        description="These endpoints let you manage organizations in the system.\nIt allows you to retrieve, create, update, and delete organization records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'tax_calculations'],
                        description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'tax_calculators'],
                        description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'tax_calculators', 'monthly'],
                                    description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'tax_membership_histories'],
                        description="These endpoints let you manage(retrieve and update) tax membership histories for employees.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'tax_membership_histories', 'tax_subjects'],
                                    description="These endpoints let you manage(retrieve and update) tax membership histories for employees.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'tax_reports'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'tax_reports', 'by_1721_a1'],
                                    description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'tax_reports', 'by_1721_a1', 'download'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'tax_reports', 'by_1721_vi'],
                                    description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'tax_reports', 'by_1721_vi', 'detail'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                        ResourceNode(
                                                resource_chain=['core', 'tax_reports', 'by_1721_vi', 'download'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'tax_reports', 'by_1721_vii'],
                                    description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'tax_reports', 'by_1721_vii', 'download'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'tax_reports', 'by_1721_viii'],
                                    description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'tax_reports', 'by_1721_viii', 'download'],
                                                description="These endpoints let you manage tax-related features in the system.\nIt allows you to retrieve tax configurations, calculate taxes, and manage tax records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'termination_bpjs_manpower_reasons'],
                        description="These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'termination_entries'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'termination_entries', 'severance_plans'],
                                    description="These endpoints let you manage severance features in the system.\nIt allows you to retrieve severance configurations, calculate related contributions, and manage severance records.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'termination_reason_categories'],
                        description="These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'termination_reasons'],
                        description="These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'termination_tax_reasons'],
                        description="These endpoints let you manage employee terminations in the system.\nIt allows you to retrieve, create, update, and delete termination records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'transition_calculations'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'transition_calculations', 'process'],
                                    description="Resource API",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'transition_calculations', 'process', 'count'],
                                                description="These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                        ResourceNode(
                                                resource_chain=['core', 'transition_calculations', 'process', 'processable'],
                                                description="Resource API",
                                                children=[
                                                    ResourceNode(
                                                            resource_chain=['core', 'transition_calculations', 'process', 'processable', 'processed'],
                                                            description="These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n",
                                                            children=[
                                                            ],
                                                            is_api=True
                                                        )
,
                                                    ResourceNode(
                                                            resource_chain=['core', 'transition_calculations', 'process', 'processable', 'unprocessed'],
                                                            description="These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n",
                                                            children=[
                                                            ],
                                                            is_api=True
                                                        )
,
                                                ],
                                                is_api=False
                                            )
,
                                    ],
                                    is_api=False
                                )
,
                            ResourceNode(
                                    resource_chain=['core', 'transition_calculations', 'time_allowances'],
                                    description="Resource API",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'transition_calculations', 'time_allowances', 'process'],
                                                description="Resource API",
                                                children=[
                                                    ResourceNode(
                                                            resource_chain=['core', 'transition_calculations', 'time_allowances', 'process', 'processable'],
                                                            description="These endpoints let you manage transition calculations in the system.\nIt allows you to perform transition calculations based on various parameters and settings.\n",
                                                            children=[
                                                            ],
                                                            is_api=True
                                                        )
,
                                                ],
                                                is_api=False
                                            )
,
                                    ],
                                    is_api=False
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['core', 'users'],
                        description="These endpoints let you manage users in the system.\nIt allows you to retrieve user information, roles, and permissions.\n",
                        children=[
                            ResourceNode(
                                    resource_chain=['core', 'users', 'me'],
                                    description="Resource API",
                                    children=[
                                        ResourceNode(
                                                resource_chain=['core', 'users', 'me', 'analytics'],
                                                description="Resource API",
                                                children=[
                                                    ResourceNode(
                                                            resource_chain=['core', 'users', 'me', 'analytics', 'charts'],
                                                            description="Resource API",
                                                            children=[
                                                                ResourceNode(
                                                                        resource_chain=['core', 'users', 'me', 'analytics', 'charts', 'data'],
                                                                        description="These endpoints let you manage analytics features in the system.\nIt consist of various sub-modules related to data analysis, reporting, and visualization.\n",
                                                                        children=[
                                                                        ],
                                                                        is_api=True
                                                                    )
,
                                                            ],
                                                            is_api=False
                                                        )
,
                                                ],
                                                is_api=False
                                            )
,
                                        ResourceNode(
                                                resource_chain=['core', 'users', 'me', 'widgets'],
                                                description="These endpoints let you manage widgets in the system.\nIt allows you to retrieve, create, update, and delete widget records.\n",
                                                children=[
                                                ],
                                                is_api=True
                                            )
,
                                    ],
                                    is_api=False
                                )
,
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'vendors'],
                        description="These endpoints let you manage vendor master data in the system.\nIt allows you to retrieve vendor records.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'workflow_activities'],
                        description="These endpoints let you manage custom workflows in the system.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'workflow_reason_categories'],
                        description="These endpoints let you manage custom workflows in the system.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['core', 'workflow_reasons'],
                        description="These endpoints let you manage custom workflows in the system.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
            ],
            is_api=False
        )
,
    ResourceNode(
            resource_chain=['oauth_clients'],
            description="These endpoints let you manage OAuth clients in the system.\n",
            children=[
                ResourceNode(
                        resource_chain=['oauth_clients', 'validate_access_token'],
                        description="OAuth 2.0 token endpoint for authentication.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
            ],
            is_api=True
        )
,
    ResourceNode(
            resource_chain=['roles'],
            description="These endpoints let you manage roles in the system.\n",
            children=[
                ResourceNode(
                        resource_chain=['roles', 'authorities'],
                        description="These endpoints let you manage roles in the system.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['roles', 'permissions'],
                        description="These endpoints let you manage roles in the system.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
            ],
            is_api=True
        )
,
    ResourceNode(
            resource_chain=['timemanagement'],
            description="Resource API",
            children=[
                ResourceNode(
                        resource_chain=['timemanagement', 'absence_entries'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'attendance_cancellations'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'attendance_recapitulations'],
                        description="Resource API",
                        children=[
                            ResourceNode(
                                    resource_chain=['timemanagement', 'attendance_recapitulations', 'details'],
                                    description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                                    children=[
                                    ],
                                    is_api=True
                                )
,
                        ],
                        is_api=False
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'attendances'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'employee_workday_configurations'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'fingerprints'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'holidays'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'leave_balances'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'other_leave_balances'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'shift_pattern_templates'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
                ResourceNode(
                        resource_chain=['timemanagement', 'workgroup_workday_configurations'],
                        description="These endpoints let you manage time management features in the system.\nIt consists of various sub-modules related to attendance, shifts, workday configurations, and more.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
            ],
            is_api=False
        )
,
    ResourceNode(
            resource_chain=['users'],
            description="Resource API",
            children=[
                ResourceNode(
                        resource_chain=['users', 'me'],
                        description="These endpoints let you manage users in the system.\nIt allows you to retrieve user information, roles, and permissions.\n",
                        children=[
                        ],
                        is_api=True
                    )
,
            ],
            is_api=False
        )
,
]
