"""Base class for OAuth2 Grant Types.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    [1] https://developer.catapa.com/#section/Authentication
    [2] https://www.rfc-editor.org/rfc/rfc6749 (OAuth 2.0 Framework)
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

import requests
from requests.auth import HTTPBasicAuth

if TYPE_CHECKING:
    from catapa.auth.catapa_auth import CatapaConfig


class GrantType(ABC):
    """Abstract base class for OAuth2 grant types.

    Subclasses must implement ``_get_access_token_body`` and ``_refresh_access_token``.

    Example:
        class CustomGrant(GrantType):
            def _get_access_token_body(self) -> dict[str, str]:
                return {"grant_type": "custom", ...}

            def _refresh_access_token(self, config: CatapaConfig) -> dict[str, Any]:
                return self._fetch_access_token(config)
    """

    def _fetch_access_token(self, config: "CatapaConfig") -> dict[str, Any]:
        """Fetch an access token from the authorization server.

        Args:
            config (CatapaConfig): OAuth2 credentials and endpoint configuration.

        Returns:
            dict[str, Any]: Token response from the authorization server.
        """
        url = f"{config.base_url}/oauth/token"

        headers = {
            "Tenant": config.tenant,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        }

        response = requests.post(
            url,
            headers=headers,
            data=self._get_access_token_body(),
            auth=HTTPBasicAuth(config.client_id, config.client_secret),
        )
        response.raise_for_status()
        return response.json()

    @abstractmethod
    def _get_access_token_body(self) -> dict[str, str]:
        """Return the POST body for token acquisition."""

    @abstractmethod
    def _refresh_access_token(self, config: "CatapaConfig") -> dict[str, Any]:
        """Refresh the access token using a grant-specific strategy.

        Args:
            config (CatapaConfig): OAuth2 credentials and endpoint configuration.

        Returns:
            dict[str, Any]: Token response from the authorization server.
        """
