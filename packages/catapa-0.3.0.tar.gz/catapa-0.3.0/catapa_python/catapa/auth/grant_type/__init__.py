"""CATAPA OAuth2 Grant Types.

This package provides OAuth2 grant type implementations.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    [1] https://developer.catapa.com/#section/Authentication
"""

from catapa.auth.grant_type.authorization_code import AuthorizationCodeGrant
from catapa.auth.grant_type.client_credentials import ClientCredentialsGrant
from catapa.auth.grant_type.grant_type import GrantType

__all__ = [
    "GrantType",
    "ClientCredentialsGrant",
    "AuthorizationCodeGrant",
]
