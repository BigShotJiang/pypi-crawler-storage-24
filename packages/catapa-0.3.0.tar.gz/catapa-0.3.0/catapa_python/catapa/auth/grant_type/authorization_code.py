"""OAuth2 Authorization Code Grant Type.

This module provides the Authorization Code grant type implementation,
suitable for authenticating on behalf of a user via the authorization code flow.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    [1] https://developer.catapa.com/#section/Authentication
"""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import requests
from catapa.auth.grant_type.grant_type import GrantType
from requests.auth import HTTPBasicAuth

if TYPE_CHECKING:
    from catapa.auth.catapa_auth import CatapaConfig


@dataclass
class AuthorizationCodeGrant(GrantType):
    """OAuth2 Authorization Code grant type.

    Use this when authenticating on behalf of a user via the authorization
    code flow.

    Attributes:
        code (str): Single-use authorization code from the server.
        redirect_uri (str): The redirect URI used during the authorization request.

    Example:
        grant = AuthorizationCodeGrant(code="abc123", redirect_uri="https://myapp.com/callback")
        client = Catapa(tenant="...", client_id="...", client_secret="...", grant_type=grant)
    """

    code: str = field(repr=False)
    redirect_uri: str
    _stored_refresh_token: str | None = field(default=None, init=False, repr=False)

    def _fetch_access_token(self, config: "CatapaConfig") -> dict[str, Any]:
        """Fetch access token and store the refresh token from the response."""
        if self._stored_refresh_token is not None and not self.code:
            return self._refresh_access_token(config)

        token_response = super()._fetch_access_token(config)
        self.code = ""

        if "refresh_token" in token_response:
            self._stored_refresh_token = token_response["refresh_token"]

        return token_response

    def _get_access_token_body(self) -> dict[str, str]:
        """Return the POST body for token acquisition."""
        return {
            "grant_type": "authorization_code",
            "code": self.code,
            "redirect_uri": self.redirect_uri,
        }

    def _refresh_access_token(self, config: "CatapaConfig") -> dict[str, Any]:
        """Refresh the access token using the stored refresh token.

        Args:
            config (CatapaConfig): OAuth2 credentials and endpoint configuration.

        Returns:
            dict[str, Any]: Token response from the authorization server.

        Raises:
            ValueError: If no refresh token is available.
        """
        if self._stored_refresh_token is None:
            raise ValueError(
                "No refresh token available. Authorization code grant requires a refresh_token "
                "from the initial token response to support automatic token refresh."
            )

        url = f"{config.base_url}/oauth/token"

        headers = {
            "Tenant": config.tenant,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        }

        body = {
            "grant_type": "refresh_token",
            "refresh_token": self._stored_refresh_token,
        }

        response = requests.post(
            url,
            headers=headers,
            data=body,
            auth=HTTPBasicAuth(config.client_id, config.client_secret),
        )
        response.raise_for_status()
        token_response = response.json()

        if "refresh_token" in token_response:
            self._stored_refresh_token = token_response["refresh_token"]

        return token_response
