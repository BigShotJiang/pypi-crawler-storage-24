from django.contrib import admin
from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from admin_json_view.mixins import JsonViewMixin
from .models import Article, Author, Tag


# Register test models with the admin
class ArticleAdmin(JsonViewMixin, admin.ModelAdmin):
    json_depth = 1
    json_exclude_fields = []


class ArticleAdminDepth0(JsonViewMixin, admin.ModelAdmin):
    json_depth = 0


admin.site.register(Article, ArticleAdmin)
admin.site.register(Author)
admin.site.register(Tag)


class JsonViewPermissionTest(TestCase):

    def setUp(self):
        self.author = Author.objects.create(name="Edwin", email="e@example.com")
        self.article = Article.objects.create(
            title="Test", body="Body", author=self.author
        )
        self.superuser = User.objects.create_superuser(
            username="admin", password="password", email="admin@example.com"
        )
        self.regular_user = User.objects.create_user(
            username="user", password="password"
        )

    def test_superuser_can_access_json_view(self):
        self.client.force_login(self.superuser)
        url = reverse(
            "admin:tests_article_json_view", args=[self.article.pk]
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "application/json")

    def test_anonymous_user_redirected(self):
        url = reverse(
            "admin:tests_article_json_view", args=[self.article.pk]
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)

    def test_json_response_contains_expected_fields(self):
        self.client.force_login(self.superuser)
        url = reverse(
            "admin:tests_article_json_view", args=[self.article.pk]
        )
        response = self.client.get(url)
        data = response.json()
        self.assertIn("id", data)
        self.assertIn("title", data)
        self.assertIn("body", data)

    def test_nonexistent_object_returns_404(self):
        self.client.force_login(self.superuser)
        url = reverse(
            "admin:tests_article_json_view", args=[99999]
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 404)