from django.test import TestCase

from admin_json_view.serializer import serialize_instance
from .models import Article, Author, Tag


class SerializerDepth0Test(TestCase):
    """depth=0 should return scalar fields and IDs for relations."""

    def setUp(self):
        self.author = Author.objects.create(
            name="Edwin", email="edwin@example.com", secret_token="tok123"
        )
        self.tag1 = Tag.objects.create(name="django")
        self.tag2 = Tag.objects.create(name="python")
        self.article = Article.objects.create(
            title="Hello World", body="Some body", author=self.author
        )
        self.article.tags.set([self.tag1, self.tag2])

    def test_scalar_fields(self):
        data = serialize_instance(self.article, depth=0)
        self.assertEqual(data["id"], self.article.pk)
        self.assertEqual(data["title"], "Hello World")
        self.assertEqual(data["body"], "Some body")

    def test_fk_returns_id_only(self):
        data = serialize_instance(self.article, depth=0)
        self.assertIn("author_id", data)
        self.assertEqual(data["author_id"], self.author.pk)
        self.assertNotIn("author", data)

    def test_m2m_returns_pk_list(self):
        data = serialize_instance(self.article, depth=0)
        self.assertIn("tags", data)
        self.assertIsInstance(data["tags"], list)
        self.assertIn(self.tag1.pk, data["tags"])
        self.assertIn(self.tag2.pk, data["tags"])

    def test_exclude_fields(self):
        data = serialize_instance(self.author, depth=0, exclude=["secret_token"])
        self.assertNotIn("secret_token", data)
        self.assertIn("name", data)
        self.assertIn("email", data)

    def test_exclude_multiple_fields(self):
        data = serialize_instance(self.author, depth=0, exclude=["secret_token", "email"])
        self.assertNotIn("secret_token", data)
        self.assertNotIn("email", data)
        self.assertIn("name", data)


class SerializerDepth1Test(TestCase):
    """depth=1 should expand FK and M2M into nested objects."""

    def setUp(self):
        self.author = Author.objects.create(
            name="Edwin", email="edwin@example.com"
        )
        self.tag1 = Tag.objects.create(name="django")
        self.tag2 = Tag.objects.create(name="python")
        self.article = Article.objects.create(
            title="Hello World", body="Some body", author=self.author
        )
        self.article.tags.set([self.tag1, self.tag2])

    def test_fk_expands_to_object(self):
        data = serialize_instance(self.article, depth=1)
        self.assertIn("author", data)
        self.assertIsInstance(data["author"], dict)
        self.assertEqual(data["author"]["id"], self.author.pk)
        self.assertEqual(data["author"]["name"], "Edwin")
        self.assertEqual(data["author"]["email"], "edwin@example.com")

    def test_m2m_expands_to_list_of_objects(self):
        data = serialize_instance(self.article, depth=1)
        self.assertIn("tags", data)
        self.assertIsInstance(data["tags"], list)
        self.assertEqual(len(data["tags"]), 2)
        names = [t["name"] for t in data["tags"]]
        self.assertIn("django", names)
        self.assertIn("python", names)

    def test_nested_fk_is_depth0(self):
        """At depth=1 the nested author should not further expand its own relations."""
        data = serialize_instance(self.article, depth=1)
        # Author has no FK, just check it's a flat dict
        self.assertIsInstance(data["author"], dict)


class SerializerNullRelationTest(TestCase):
    """Null FK should serialize as None."""

    def test_null_fk(self):
        # Article requires author so test with a model that allows null FK
        # We'll test directly by checking None handling in a Author with no relations
        author = Author.objects.create(name="Solo", email="solo@example.com")
        data = serialize_instance(author, depth=1)
        self.assertEqual(data["name"], "Solo")


class SerializerCoercionTest(TestCase):
    """Special field types should be coerced to JSON-safe values."""

    def test_email_field_as_string(self):
        author = Author.objects.create(name="Edwin", email="edwin@example.com")
        data = serialize_instance(author, depth=0)
        self.assertIsInstance(data["email"], str)

    def test_no_unserializable_values(self):
        """All values in output should be JSON serializable."""
        import json
        author = Author.objects.create(name="Edwin", email="edwin@example.com")
        tag = Tag.objects.create(name="test")
        article = Article.objects.create(title="T", body="B", author=author)
        article.tags.set([tag])

        data = serialize_instance(article, depth=1)
        # Should not raise
        json.dumps(data)