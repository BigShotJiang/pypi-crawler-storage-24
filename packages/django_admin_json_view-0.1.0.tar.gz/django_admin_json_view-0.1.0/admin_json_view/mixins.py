from django.contrib.admin.utils import unquote
from django.core.exceptions import PermissionDenied
from django.http import JsonResponse
from django.urls import path

from .serializer import serialize_instance


class JsonViewMixin:
    """
    Mixin for ModelAdmin that adds a "View as JSON" button to the change form.

    Options:
        json_depth (int): How deep to serialize relations.
                          0 = direct fields only (default)
                          1 = one level of related objects
        json_exclude_fields (list): Field names to exclude from the output.
    """

    json_depth: int = 0
    json_exclude_fields: list = []
    change_form_template = "admin_json_view/change_form.html"

    # URLs
    def get_urls(self):
        info = self.model._meta.app_label, self.model._meta.model_name
        custom_urls = [
            path(
                "<path:object_id>/json-view/",
                self.admin_site.admin_view(self.json_view),
                name="%s_%s_json_view" % info,
            ),
        ]
        return custom_urls + super().get_urls()

    # View
    def json_view(self, request, object_id):
        if not self.has_view_or_change_permission(request):
            raise PermissionDenied

        obj = self.get_object(request, unquote(object_id))
        if obj is None:
            return JsonResponse({"error": "Object not found."}, status=404)

        data = serialize_instance(
            obj,
            depth=self.json_depth,
            exclude=self.json_exclude_fields,
        )
        return JsonResponse(data, json_dumps_params={"indent": 2})

    # Inject context into change form
    def change_view(self, request, object_id, form_url="", extra_context=None):
        extra_context = extra_context or {}

        info = self.model._meta.app_label, self.model._meta.model_name
        extra_context["json_view_url_name"] = "%s_%s_json_view" % info
        extra_context["object_id"] = object_id

        return super().change_view(request, object_id, form_url, extra_context)