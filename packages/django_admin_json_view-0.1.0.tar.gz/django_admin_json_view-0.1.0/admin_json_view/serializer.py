from django.db import models


def serialize_instance(obj, depth: int = 0, exclude: list = None) -> dict:
    """
    Serialize a Django model instance to a plain dict.

    Args:
        obj:     The model instance to serialize.
        depth:   How deep to follow related objects (ForeignKey, OneToOne).
                 0 = only direct field values (IDs for relations).
                 1 = serialize one level of related objects.
        exclude: List of field names to skip.
    """
    exclude = exclude or []
    data = {}

    for field in obj._meta.get_fields():
        # Skip reverse relations (e.g. reverse FK, M2M accessors)
        if field.is_relation and not field.concrete:
            continue

        name = field.name

        if name in exclude:
            continue

        try:
            value = getattr(obj, name)
        except AttributeError:
            continue

        # Related field (FK, OneToOne) --------------------------------- #
        if field.is_relation and field.many_to_one or field.one_to_one:
            if value is None:
                data[name] = None
            elif depth > 0:
                data[name] = serialize_instance(value, depth=depth - 1, exclude=exclude)
            else:
                # depth == 0: just return the raw ID
                data[name + "_id"] = getattr(obj, field.attname)
            continue

        # ManyToMany --------------------------------------------------- #
        if field.many_to_many:
            if depth > 0:
                data[name] = [
                    serialize_instance(related, depth=depth - 1, exclude=exclude)
                    for related in value.all()
                ]
            else:
                data[name] = list(value.values_list("pk", flat=True))
            continue

        # Scalar fields ------------------------------------------------ #
        data[name] = _coerce(value)

    return data


def _coerce(value):
    """Convert non-JSON-serializable scalar values to safe types."""
    import datetime
    import decimal
    import uuid

    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, decimal.Decimal):
        return float(value)
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value