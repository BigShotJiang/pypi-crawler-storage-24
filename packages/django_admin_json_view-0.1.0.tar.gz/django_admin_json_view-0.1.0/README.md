# django-admin-json-view

A simple Django admin mixin that adds a **"View as JSON"** button to any model's change form. Click it to open a modal with the record's data as formatted JSON — ready to copy.

---

## Installation

```bash
pip install django-admin-json-view
```

Add to `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    "admin_json_view",
]
```

Include the URLs in your `urls.py`:

```python
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("admin-json-view/", include("admin_json_view.urls")),
]
```

---

## Usage

Add `JsonViewMixin` to any `ModelAdmin`:

```python
from admin_json_view.mixins import JsonViewMixin
from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(JsonViewMixin, admin.ModelAdmin):
    pass
```

That's it. A **"{ } View as JSON"** button will appear in the top-right of the change form.

---

## Configuration

| Option | Default | Description |
|---|---|---|
| `json_depth` | `0` | How deep to serialize relations. `0` = direct fields only, `1` = one level of related objects |
| `json_exclude_fields` | `[]` | List of field names to exclude from the output |

```python
@admin.register(Student)
class StudentAdmin(JsonViewMixin, admin.ModelAdmin):
    json_depth = 1
    json_exclude_fields = ["password", "token"]
```

---

## License

MIT