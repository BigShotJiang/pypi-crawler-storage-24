"""Wafer AI environment with minimal toolset for code editing tasks.
Tools: read, write, edit, glob, grep, bash, skill, subagent, pull_session_files
"""
from __future__ import annotations

import os
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import trio

from wafer.core.dtypes import (
    AgentState,
    Message,
    RunConfig,
    Tool,
    ToolCall,
    ToolRenderConfig,
    ToolResult,
    ToolResultDelta,
)
from wafer.core.tools import (
    BASH_TOOL,
    EDIT_TOOL,
    GLOB_TOOL,
    GREP_TOOL,
    PULL_SESSION_FILES_TOOL,
    READ_TOOL,
    SANDBOX_RUN_TOOL,
    SKILL_TOOL,
    SUBAGENT_TOOL,
    WRITE_TOOL,
    ApprovalCallback,
    exec_bash,
    exec_edit,
    exec_glob,
    exec_grep,
    exec_pull_session_files,
    exec_read,
    exec_sandbox_run,
    exec_skill,
    exec_subagent,
    exec_write,
)

_TOOL_ENTRIES = (
    ("read", READ_TOOL, lambda env, tc, _cs, _rc: exec_read(tc, env.working_dir)),
    ("write", WRITE_TOOL, lambda env, tc, _cs, _rc: exec_write(tc, env.working_dir)),
    ("edit", EDIT_TOOL, lambda env, tc, _cs, _rc: exec_edit(tc, env.working_dir)),
    ("glob", GLOB_TOOL, lambda env, tc, _cs, _rc: exec_glob(tc, env.working_dir)),
    ("grep", GREP_TOOL, lambda env, tc, _cs, _rc: exec_grep(tc, env.working_dir)),
    ("bash", BASH_TOOL, lambda env, tc, cs, _rc: exec_bash(
        tc, env.working_dir, cs,
        env.bash_allowlist, env.bash_denylist,
        env.bash_approval_callback, env.bash_default_timeout,
    )),
    ("sandbox_run", SANDBOX_RUN_TOOL, lambda env, tc, _cs, rc: exec_sandbox_run(
        tc, env.working_dir, on_output=lambda delta: rc.on_chunk(delta),
    )),
    ("skill", SKILL_TOOL, lambda _env, tc, _cs, _rc: exec_skill(tc)),
    ("subagent", SUBAGENT_TOOL, lambda env, tc, _cs, rc: env._exec_subagent_tracked(
        tc, on_output=lambda delta: rc.on_chunk(delta),
    )),
    ("pull_session_files", PULL_SESSION_FILES_TOOL, lambda env, tc, _cs, _rc: env._exec_pull_with_resolve(tc)),
)

ALL_TOOLS: dict[str, Tool] = {name: schema for name, schema, _ in _TOOL_ENTRIES}
_TOOL_EXECUTORS = {name: executor for name, _, executor in _TOOL_ENTRIES}


_FINGERPRINT_PATHS = (
    "core/tools",
    "core/agent",
    "core/environments",
    "core/utils",
    "core/config",
    "core/logging",
    "core/sandbox",
    "eval",
)


def tools_fingerprint() -> str:
    """Hash of runtime-critical source files. Detects stale target installations.

    Only includes paths that participate in agent execution on targets:
    tools, agent, environments, eval, and their shared dependencies.
    Excludes profiling libs (core/lib/), target management (core/targets/),
    roofline analysis (core/roofline/), CLI code, and tests/.
    """
    import hashlib
    pkg_root = Path(__file__).resolve().parent.parent.parent
    h = hashlib.sha256()
    for subpath in _FINGERPRINT_PATHS:
        dir_path = pkg_root / subpath
        if not dir_path.exists():
            continue
        for py_file in sorted(dir_path.rglob("*.py")):
            if py_file.parent.name == "tests":
                continue
            h.update(str(py_file.relative_to(pkg_root)).encode())
            h.update(py_file.read_bytes())
    return h.hexdigest()[:12]


@dataclass
class CodingEnvironment:
    """Local filesystem environment with read, write, edit, glob, grep, bash tools."""

    working_dir: Path = field(default_factory=Path.cwd)
    allowed_paths: list[Path] | None = None
    enabled_tools: list[str] | None = None
    bash_allowlist: list[str] | None = None
    bash_denylist: list[str] | None = None
    bash_approval_callback: ApprovalCallback | None = None
    bash_default_timeout: int = 1200
    target_name: str | None = None
    gpu_type: str | None = None
    confirm_tools: list[str] | None = None
    sandbox_id: str | None = None
    _subagent_session_ids: list[str] = field(default_factory=list, repr=False)

    def record_subagent_session(self, session_id: str) -> None:
        self._subagent_session_ids.append(session_id)

    def resolve_subagent_session(self, session_id: str | None) -> str | None:
        """Resolve a session_id, falling back to last subagent if omitted or mistyped."""
        if not self._subagent_session_ids:
            return session_id
        if not session_id:
            return self._subagent_session_ids[-1]
        if session_id in self._subagent_session_ids:
            return session_id
        prefix = session_id[:8]
        for sid in reversed(self._subagent_session_ids):
            if sid.startswith(prefix):
                return sid
        return self._subagent_session_ids[-1]

    def __post_init__(self) -> None:
        if self.enabled_tools is not None:
            valid_tools = set(ALL_TOOLS.keys())
            unknown = set(self.enabled_tools) - valid_tools
            if unknown:
                raise ValueError(
                    f"Unknown tools: {sorted(unknown)}. Available: {sorted(valid_tools)}"
                )

    def get_name(self) -> str:
        return "coding"

    def get_status_info(self) -> dict[str, str] | None:
        info: dict[str, str] = {}
        if self.sandbox_id:
            info["sandbox"] = self.sandbox_id
        if self.target_name:
            info["target"] = self.target_name
        if self.gpu_type:
            info["accelerator"] = self.gpu_type
        return info or None

    async def serialize(self) -> dict:
        d: dict = {
            "working_dir": str(self.working_dir),
            "allowed_paths": [str(p) for p in self.allowed_paths] if self.allowed_paths else None,
            "enabled_tools": self.enabled_tools,
            "bash_allowlist": self.bash_allowlist,
            "bash_denylist": self.bash_denylist,
            "target_name": self.target_name,
            "gpu_type": self.gpu_type,
            "sandbox_id": self.sandbox_id,
        }
        if self.confirm_tools is not None:
            d["confirm_tools"] = self.confirm_tools
        if self.bash_default_timeout != 180:
            d["bash_default_timeout"] = self.bash_default_timeout
        return d

    @staticmethod
    async def deserialize(data: dict) -> CodingEnvironment:
        allowed = data.get("allowed_paths")
        return CodingEnvironment(
            working_dir=Path(data["working_dir"]),
            allowed_paths=[Path(p) for p in allowed] if allowed else None,
            enabled_tools=data.get("enabled_tools"),
            bash_allowlist=data.get("bash_allowlist"),
            bash_denylist=data.get("bash_denylist"),
            bash_default_timeout=data.get("bash_default_timeout", 180),
            target_name=data.get("target_name"),
            gpu_type=data.get("gpu_type"),
            confirm_tools=data.get("confirm_tools"),
            sandbox_id=data.get("sandbox_id"),
        )

    async def close(self) -> None:
        """No-op — sandbox lifecycle is managed by wafer sandbox create/destroy."""

    def requires_confirmation(self, tool_call: ToolCall) -> bool:
        if self.confirm_tools is not None:
            return tool_call.name in self.confirm_tools
        return tool_call.name == "bash"

    def get_tools(self) -> list[Tool]:
        if self.enabled_tools is None:
            return list(ALL_TOOLS.values())
        return [ALL_TOOLS[name] for name in self.enabled_tools if name in ALL_TOOLS]

    def get_tool_render_config(self, tool_name: str) -> ToolRenderConfig | None:
        if tool_name == "subagent":
            def _subagent_header(name: str, args: dict[str, Any]) -> str:
                config = args.get("config", "?")
                label = config if isinstance(config, str) else "inline"
                return f"{name}(config={label!r})"
            return ToolRenderConfig(header_fn=_subagent_header)
        return None

    async def on_assistant_message(self, message: Message, state: AgentState) -> AgentState:
        return state

    async def exec_tool(
        self,
        tool_call: ToolCall,
        current_state: AgentState,
        run_config: RunConfig,
        cancel_scope: trio.CancelScope | None = None,
    ) -> ToolResult:
        if self.enabled_tools is not None and tool_call.name not in self.enabled_tools:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Tool '{tool_call.name}' is not enabled. Enabled tools: {', '.join(self.enabled_tools)}",
            )
        executor = _TOOL_EXECUTORS.get(tool_call.name)
        if executor is None:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Unknown tool: {tool_call.name}",
            )
        try:
            return await executor(self, tool_call, cancel_scope, run_config)
        except Exception as e:
            return ToolResult(tool_call_id=tool_call.id, is_error=True, content="", error=str(e))

    async def _exec_subagent_tracked(
        self,
        tool_call: ToolCall,
        on_output: Callable[[ToolResultDelta], Awaitable[None]] | None = None,
    ) -> ToolResult:
        result = await exec_subagent(
            tool_call,
            on_output=on_output,
            api_url=os.environ.get("WAFER_API_URL"),
            auth_token=os.environ.get("WAFER_AUTH_TOKEN"),
        )
        match = re.search(r"\[subagent_session:([a-f0-9-]+)\]", result.content or "")
        if match:
            self.record_subagent_session(match.group(1))
        return result

    async def _exec_pull_with_resolve(self, tool_call: ToolCall) -> ToolResult:
        raw_id = tool_call.args.get("session_id", "")
        resolved = self.resolve_subagent_session(raw_id or None)
        if resolved and resolved != raw_id:
            tool_call = ToolCall(
                id=tool_call.id,
                name=tool_call.name,
                args={**tool_call.args, "session_id": resolved},
            )
        return await exec_pull_session_files(
            tool_call,
            self.working_dir,
            api_url=os.environ.get("WAFER_API_URL"),
            auth_token=os.environ.get("WAFER_AUTH_TOKEN"),
        )


WaferAiEnvironment = CodingEnvironment
