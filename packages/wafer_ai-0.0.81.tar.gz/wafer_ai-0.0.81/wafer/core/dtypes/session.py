from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from .core import Endpoint
from .messages import Message


# ── Session Types ──────────────────────────────────────────────────────────────
# Types for persisting agent sessions (trajectories, config, environment state).
# See internal-docs/designs/agent-session-design.md for design details.
class SessionStatus(Enum):
    """Session status."""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"
    WAITING = "waiting"  # Interactive detached mode: agent paused for user input


@dataclass
class EnvironmentConfig:
    """Environment configuration.
    Stored in session for reproducibility.
    """
    type: str  # e.g., "wafer_ai", "repl", "ask_user", "binary_search"
    # Environment-specific config
    config: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.type,
            "config": self.config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EnvironmentConfig:
        return cls(
            type=data["type"],
            config=data.get("config", {}),
        )


@dataclass
class AgentSession:
    """A persisted agent session.
    This is the record stored in ~/.wafer/sessions/<session_id>/
    """
    # Identity
    session_id: str
    parent_id: str | None = None  # None for root sessions
    branch_point: int | None = None  # message index where branched from parent
    # Config (serializable, stored in session.json)
    # Endpoint stored with secrets excluded via to_dict(exclude_secrets=True)
    endpoint: Endpoint = field(default_factory=lambda: Endpoint(provider="", model=""))
    environment: EnvironmentConfig = field(default_factory=lambda: EnvironmentConfig(type=""))
    # Trajectory - uses Message directly (with optional timestamp field)
    messages: list[Message] = field(default_factory=list)
    message_count: int | None = None  # Set when listing (without loading messages)
    # Environment state (opaque, env-specific)
    environment_state: dict[str, Any] | None = None
    # Outcome
    status: SessionStatus = SessionStatus.RUNNING
    reward: float | dict[str, float] | None = None
    # Metadata
    tags: dict[str, str] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for JSON storage."""
        return {
            "session_id": self.session_id,
            "parent_id": self.parent_id,
            "branch_point": self.branch_point,
            "endpoint": self.endpoint.to_dict(exclude_secrets=True),
            "environment": self.environment.to_dict(),
            # messages are stored separately in messages.jsonl
            "environment_state": self.environment_state,
            "status": self.status.value,
            "reward": self.reward,
            "tags": self.tags,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any], messages: list[Message] | None = None
    ) -> AgentSession:
        """Deserialize from dict."""
        return cls(
            session_id=data["session_id"],
            parent_id=data.get("parent_id"),
            branch_point=data.get("branch_point"),
            endpoint=Endpoint.from_dict(data["endpoint"]),
            environment=EnvironmentConfig.from_dict(data["environment"]),
            messages=messages or [],
            environment_state=data.get("environment_state"),
            status=SessionStatus(data.get("status", "running")),
            reward=data.get("reward"),
            tags=data.get("tags", {}),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
        )
