from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import asdict, dataclass
from enum import IntEnum
from typing import Any, Self

import dacite

# TUI formatter type - receives (tool_name, args, result, detail_level, theme) and returns formatted string
# Theme is optional to allow headless/non-TUI usage
ToolFormatter = Callable[[str, dict[str, Any], dict[str, Any] | None, "DetailLevel", Any], str]


class DetailLevel(IntEnum):
    """Detail level for displaying content in TUI.
    Controls how much information is shown for tool outputs, messages, and errors.
    Use +/- keys to cycle through levels globally.
    """
    COMPACT = 0  # Header + 1-2 line summary only
    STANDARD = 1  # Default preview (5-10 lines)
    EXPANDED = 2  # Full output, no truncation
    # Future levels (not yet implemented):
    # VERBOSE = 3   # Full output + metadata
    # DEBUG = 4     # Everything including internal state


@dataclass
class ToolRenderConfig:
    """Rendering config for tool output in TUI.
    Environments can optionally provide this to customize how tools render.
    All fields have sensible defaults, so most tools need no config at all.
    For simple tools: just override header_fn and maybe summaries
    For complex tools: provide custom_formatter for full control
    Example:
        # Simple tool - just customize header
        ToolRenderConfig(
            header_fn=lambda name, args: f"bash(command={repr(args.get('command', '...'))})",
            success_summary="Command completed",
        )
        # Complex tool - full control
        ToolRenderConfig(custom_formatter=my_custom_format_fn)
    """
    # How to build the header line
    # If None, uses default: tool_name(arg1=..., arg2=...)
    header_fn: Callable[[str, dict[str, Any]], str] | None = None
    # Output display settings - lines shown at each detail level
    # COMPACT: minimal preview, STANDARD: default, EXPANDED: full output
    lines_compact: int = 1  # First line only
    lines_standard: int = 1  # First line + "... (N more lines)"
    lines_expanded: int = -1  # -1 = unlimited
    streaming_max_lines: int = 1
    style_fn: str = "diff_context_fg"  # Theme method name for styling output lines
    # Summary lines (shown after header, before output)
    # If None, no summary shown - tool name is usually self-documenting
    success_summary: str | None = None
    error_summary: str | None = None
    # For complex tools that need full control over rendering
    # If provided, all other fields are ignored
    # Signature: (tool_name, args, result, detail_level, theme) -> str
    custom_formatter: ToolFormatter | None = None

    def get_max_lines(self, level: DetailLevel) -> int:
        """Get the max lines for a given detail level.
        Args:
            level: The detail level to get lines for
        Returns:
            Max lines to display (-1 for unlimited)
        """
        if level == DetailLevel.COMPACT:
            return self.lines_compact
        elif level == DetailLevel.STANDARD:
            return self.lines_standard
        else:  # EXPANDED or higher
            return self.lines_expanded


def parse_streaming_json(partial_json: str) -> dict[str, Any]:
    """Parse partial JSON string, returning best-effort partial object.
    During streaming, tool call arguments arrive incrementally as incomplete JSON.
    This function attempts to extract valid key-value pairs from incomplete JSON.
    Examples:
        '{"foo": "bar"'          -> {"foo": "bar"}
        '{"foo": "bar", "baz":'  -> {"foo": "bar"}
        '{"nested": {"a": 1'     -> {"nested": {"a": 1}}
        '{"arr": [1, 2'          -> {"arr": [1, 2]}
        ''                       -> {}
        '{'                      -> {}
    Tiger Style: Best-effort parsing, crash-loud on programmer error.
    - Invalid UTF-8 -> crash (caller must ensure valid encoding)
    - Incomplete JSON -> return partial parsed dict (expected during streaming)
    - Malformed JSON -> return empty dict (streaming hasn't started yet)
    """
    assert isinstance(partial_json, str), f"Expected str, got {type(partial_json)}"
    if not partial_json or partial_json.strip() == "":
        return {}
    # Try parsing as complete JSON first
    try:
        result = json.loads(partial_json)
    except json.JSONDecodeError:
        pass
    else:
        # Model might return non-object JSON (e.g., "8" instead of {"result": 8})
        if not isinstance(result, dict):
            return {}
        return result
    # Incomplete JSON - try to extract what we can
    # Strategy: Progressively trim incomplete parts from the end
    # 1. Close incomplete string values
    # 2. Remove incomplete keys
    # 3. Close incomplete arrays
    # 4. Close incomplete objects
    cleaned = partial_json.strip()
    if cleaned in ("{", "[", ""):
        return {}
    # Try adding closing braces/brackets progressively
    attempts = [
        cleaned + '"}',  # Close incomplete string value
        cleaned + "]",  # Close incomplete array
        cleaned + "}",  # Close incomplete object
        cleaned + '"}]',  # Close string in array
        cleaned + '"}}',  # Close string in nested object
    ]
    # Also try removing trailing incomplete key/value
    if "," in cleaned:
        # Remove everything after the last comma (incomplete key-value pair)
        last_comma = cleaned.rfind(",")
        truncated = cleaned[:last_comma]
        attempts.extend([truncated + "}", truncated + "]}", truncated + "}}"])
    # If there's a colon without a value, remove the incomplete pair
    if ":" in cleaned:

        parts = cleaned.split(",")
        for i in range(len(parts) - 1, -1, -1):
            truncated = ",".join(parts[:i])
            if truncated:
                attempts.extend([truncated + "}", truncated + "]}", truncated + "}}"])
    # Try each repair strategy
    for attempt in attempts:
        try:
            result = json.loads(attempt)
            if isinstance(result, dict):
                return result
            elif isinstance(result, list):
                # Array of objects - return last object if available
                if result and isinstance(result[-1], dict):
                    return result[-1]
        except json.JSONDecodeError:
            continue
    # All strategies failed - return empty dict
    return {}


class JsonSerializable:
    """Base class for dataclasses with JSON serialization support.
    Tiger Style: Pure serialization, no I/O side effects.
    Caller controls where the JSON goes (file, network, memory, etc.).
    TODO: Consider replacing inheritance with standalone functions:
        def to_json(obj: Any) -> str: return json.dumps(asdict(obj), ensure_ascii=False)
        def from_json(cls: type[T], s: str) -> T: return dacite.from_dict(cls, json.loads(s))
    This would eliminate the base class and make each dataclass independent.
    """
    def to_json(self) -> str:
        """Serialize to JSON string"""
        assert self is not None
        result = json.dumps(asdict(self), ensure_ascii=False)  # type:ignore
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0
        return result

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        """Deserialize from JSON string using dacite"""
        assert json_str is not None
        assert isinstance(json_str, str)
        assert len(json_str) > 0
        data = json.loads(json_str)
        assert data is not None
        assert isinstance(data, dict)
        result = dacite.from_dict(data_class=cls, data=data)
        assert result is not None
        return result
