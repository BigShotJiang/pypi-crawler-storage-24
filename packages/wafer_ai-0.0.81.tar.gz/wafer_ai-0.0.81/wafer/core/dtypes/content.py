from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from ._base import JsonSerializable


@dataclass(frozen=True)
class TextContent(JsonSerializable):
    """Text content block in a message."""
    type: Literal["text"] = "text"
    text: str = ""
    text_signature: str | None = None  # Provider-specific identifier


@dataclass(frozen=True)
class ThinkingContent(JsonSerializable):
    """Thinking/reasoning content block in a message.
    Used by Anthropic (thinking blocks) and OpenAI o1/o3 (reasoning_content).
    """
    type: Literal["thinking"] = "thinking"
    thinking: str = ""
    thinking_signature: str | None = (
        None  # Provider-specific identifier (e.g., GPT-5 Codex reasoning item ID)
    )


@dataclass(frozen=True)
class ToolCallContent(JsonSerializable):
    """Tool call content block in a message."""
    type: Literal["toolCall"] = "toolCall"
    id: str = ""
    name: str = ""
    arguments: dict[str, Any] = field(default_factory=dict)
    thought_signature: str | None = None  # Google-specific opaque context
    parse_error: str | None = None
    raw_arguments: str | None = None  # Original malformed JSON string


@dataclass(frozen=True)
class ImageContent(JsonSerializable):
    """Image content block in a message (for vision models)."""
    type: Literal["image"] = "image"
    image_url: str = ""  # base64 data URL or HTTP URL
    detail: str | None = None  # OpenAI detail parameter: "low", "high", "auto"


@dataclass(frozen=True)
class CompactionContent(JsonSerializable):
    """Compaction summary block from Anthropic context management.
    Replaces older conversation context with a summarized version.
    """
    type: Literal["compaction"] = "compaction"
    content: str = ""  # Summary text


# Union type for all content blocks
ContentBlock = TextContent | ThinkingContent | ToolCallContent | ImageContent | CompactionContent
