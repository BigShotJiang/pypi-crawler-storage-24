from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ._base import JsonSerializable


@dataclass(frozen=True)
class ToolCall(JsonSerializable):
    id: str
    name: str
    args: Mapping[str, Any]
    parse_error: str | None = None


@dataclass(frozen=True)
class ToolFunctionParameter(JsonSerializable):
    properties: dict[str, Any]
    type: str = "object"


@dataclass(frozen=True)
class ToolFunction(JsonSerializable):
    name: str
    description: str
    parameters: ToolFunctionParameter
    required: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class Tool(JsonSerializable):
    function: ToolFunction
    type: str = "function"


class StopReason(Enum):
    MAX_TURNS = "MAX_TURNS"
    TOOL_ERROR = "TOOL_ERROR"
    USER_ABORT = "USER_ABORT"
    PROVIDER_ERROR = "PROVIDER_ERROR"
    NO_TOOL_CALLED = "NO_TOOL_CALLED"
    TASK_COMPLETED = "TASK_COMPLETED"
    ABORTED = "ABORTED"
    NEEDS_INPUT = "NEEDS_INPUT"  # Agent waiting for user input (interactive mode)


@dataclass(frozen=True)
class ToolResult(JsonSerializable):
    tool_call_id: str = ""
    is_error: bool = False
    content: str | list[ContentBlock] = ""
    error: str | None = None
    stop_reason: StopReason | None = None
    # UI-only structured data (stripped before LLM)
    details: dict[str, Any] | None = None


@dataclass(frozen=True)
class ToolConfirmResult(JsonSerializable):
    """Result of tool confirmation"""
    proceed: bool
    tool_result: ToolResult | None = None
    user_message: str | None = None


# Avoid circular import: ContentBlock is needed for ToolResult.content type annotation.
# With `from __future__ import annotations`, the annotation is a string at runtime,
# so we only need the import for type checkers.
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .content import ContentBlock
