"""Shared domain types for the Wafer agent framework.

Re-exports every public name so callers can do:
    from wafer.core.dtypes import AgentState
"""
from __future__ import annotations

from ._base import (
    DetailLevel,
    JsonSerializable,
    ToolFormatter,
    ToolRenderConfig,
    parse_streaming_json,
)
from .content import (
    CompactionContent,
    ContentBlock,
    ImageContent,
    TextContent,
    ThinkingContent,
    ToolCallContent,
)
from .core import (
    Actor,
    AgentState,
    Endpoint,
    RunConfig,
    default_confirm_tool,
    default_no_tool_handler,
    default_stdin_handler,
)
from .environment import Environment
from .evaluation import (
    Metric,
    Sample,
    Score,
    ScoreFn,
    Status,
    TurnScore,
)
from .messages import (
    ChatCompletion,
    Choice,
    Cost,
    Logprob,
    Logprobs,
    Message,
    PromptLogprob,
    TokenInfo,
    Trajectory,
    Usage,
)
from .session import (
    AgentSession,
    EnvironmentConfig,
    SessionStatus,
)
from .streaming import (
    AgentCheckpoint,
    CompactionEvent,
    CompactionStart,
    LLMCallEnd,
    LLMCallStart,
    RetryEnd,
    RetryStart,
    SemaphoreAcquired,
    SemaphoreWaitStart,
    StreamDone,
    StreamError,
    StreamEvent,
    StreamStart,
    TextDelta,
    TextEnd,
    TextStart,
    ThinkingDelta,
    ThinkingEnd,
    ThinkingStart,
    ToolCallDelta,
    ToolCallEnd,
    ToolCallError,
    ToolCallStart,
    ToolExecutionEnd,
    ToolExecutionStart,
    ToolResultDelta,
    ToolResultReceived,
)
from .tools import (
    StopReason,
    Tool,
    ToolCall,
    ToolConfirmResult,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)

__all__ = [
    # _base
    "DetailLevel",
    "JsonSerializable",
    "ToolFormatter",
    "ToolRenderConfig",
    "parse_streaming_json",
    # content
    "CompactionContent",
    "ContentBlock",
    "ImageContent",
    "TextContent",
    "ThinkingContent",
    "ToolCallContent",
    # core
    "Actor",
    "AgentState",
    "Endpoint",
    "RunConfig",
    "default_confirm_tool",
    "default_no_tool_handler",
    "default_stdin_handler",
    # environment
    "Environment",
    # evaluation
    "Metric",
    "Sample",
    "Score",
    "ScoreFn",
    "Status",
    "TurnScore",
    # messages
    "ChatCompletion",
    "Choice",
    "Cost",
    "Logprob",
    "Logprobs",
    "Message",
    "PromptLogprob",
    "TokenInfo",
    "Trajectory",
    "Usage",
    # session
    "AgentSession",
    "EnvironmentConfig",
    "SessionStatus",
    # streaming
    "AgentCheckpoint",
    "CompactionEvent",
    "CompactionStart",
    "LLMCallEnd",
    "LLMCallStart",
    "RetryEnd",
    "RetryStart",
    "SemaphoreAcquired",
    "SemaphoreWaitStart",
    "StreamDone",
    "StreamError",
    "StreamEvent",
    "StreamStart",
    "TextDelta",
    "TextEnd",
    "TextStart",
    "ThinkingDelta",
    "ThinkingEnd",
    "ThinkingStart",
    "ToolCallDelta",
    "ToolCallEnd",
    "ToolCallError",
    "ToolCallStart",
    "ToolExecutionEnd",
    "ToolExecutionStart",
    "ToolResultDelta",
    "ToolResultReceived",
    # tools
    "StopReason",
    "Tool",
    "ToolCall",
    "ToolConfirmResult",
    "ToolFunction",
    "ToolFunctionParameter",
    "ToolResult",
]
