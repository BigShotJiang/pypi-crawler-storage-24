from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Literal

from ._base import JsonSerializable
from .content import ContentBlock
from .tools import ToolCall


@dataclass(frozen=True)
class AgentCheckpoint(JsonSerializable):
    """Checkpoint event emitted during agent loop (turn_start, turn_end, final)."""
    checkpoint: str
    turn: int
    session_id: str | None = None
    type: Literal["agent_checkpoint"] = "agent_checkpoint"
    timestamp: float = field(default_factory=time.time)


# New granular streaming events (inspired by pi-ai)
# Each event includes content_index for tracking which content block and timestamp for logging
@dataclass(frozen=True)
class SemaphoreWaitStart(JsonSerializable):
    """Emitted when waiting to acquire a semaphore (api_limiter or tool_limiter).
    Enables distinguishing "waiting (queue)" from "waiting (api)" in status display.
    """
    limiter_type: Literal["api", "tool"]
    type: Literal["semaphore_wait_start"] = "semaphore_wait_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class SemaphoreAcquired(JsonSerializable):
    """Emitted when semaphore is acquired (waiting is over)."""
    limiter_type: Literal["api", "tool"]
    wait_duration_ms: float  # How long we waited for the semaphore
    type: Literal["semaphore_acquired"] = "semaphore_acquired"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class LLMCallStart(JsonSerializable):
    """Emitted before making the LLM API call (before connection established)"""
    type: Literal["llm_call_start"] = "llm_call_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class StreamStart(JsonSerializable):
    """Emitted at the start of a streaming response (connection established, first event received)"""
    type: Literal["start"] = "start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class TextStart(JsonSerializable):
    """Emitted when a text content block begins"""
    content_index: int
    type: Literal["text_start"] = "text_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class TextDelta(JsonSerializable):
    """Emitted for each text token/chunk during streaming"""
    content_index: int
    delta: str
    type: Literal["text_delta"] = "text_delta"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class TextEnd(JsonSerializable):
    """Emitted when a text content block completes"""
    content_index: int
    content: str  # Complete accumulated text
    type: Literal["text_end"] = "text_end"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ThinkingStart(JsonSerializable):
    """Emitted when a thinking/reasoning content block begins"""
    content_index: int
    type: Literal["thinking_start"] = "thinking_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ThinkingDelta(JsonSerializable):
    """Emitted for each thinking token/chunk during streaming"""
    content_index: int
    delta: str
    type: Literal["thinking_delta"] = "thinking_delta"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ThinkingEnd(JsonSerializable):
    """Emitted when a thinking/reasoning content block completes"""
    content_index: int
    content: str  # Complete accumulated thinking
    type: Literal["thinking_end"] = "thinking_end"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolCallStart(JsonSerializable):
    """Emitted when a tool call content block begins"""
    content_index: int
    tool_call_id: str
    tool_name: str
    type: Literal["toolcall_start"] = "toolcall_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolCallDelta(JsonSerializable):
    """Emitted for each chunk of tool call arguments during streaming
    The partial_args field contains the best-effort parsed JSON from the
    accumulated argument string so far. May be incomplete objects/arrays.
    """
    content_index: int
    tool_call_id: str
    delta: str  # Raw JSON chunk
    partial_args: dict[str, Any]  # Best-effort parsed partial JSON
    type: Literal["toolcall_delta"] = "toolcall_delta"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolCallEnd(JsonSerializable):
    """Emitted when a tool call content block completes"""
    content_index: int
    tool_call: ToolCall  # Complete parsed tool call
    type: Literal["toolcall_end"] = "toolcall_end"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolCallError(JsonSerializable):
    """Emitted when tool call argument parsing fails"""
    content_index: int
    tool_call_id: str
    tool_name: str
    error: str
    raw_arguments: str
    type: Literal["toolcall_error"] = "toolcall_error"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolExecutionStart(JsonSerializable):
    """Emitted when a tool begins execution (after confirmation, before result)"""
    tool_call_id: str
    tool_name: str
    type: Literal["tool_execution_start"] = "tool_execution_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolResultDelta(JsonSerializable):
    """Emitted for incremental tool output (e.g., bash stdout chunks as they arrive)."""
    tool_call_id: str
    delta: str
    type: Literal["tool_result_delta"] = "tool_result_delta"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolResultReceived(JsonSerializable):
    """Emitted when a tool execution result is received"""
    tool_call_id: str
    content: str | list[ContentBlock]
    is_error: bool = False
    error: str | None = None
    details: dict[str, Any] | None = None  # UI-only structured data (e.g., diff for edit tool)
    type: Literal["tool_result"] = "tool_result"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class StreamDone(JsonSerializable):
    """Emitted when streaming completes successfully"""
    finish_reason: str  # "stop", "length", "tool_calls", etc.
    type: Literal["done"] = "done"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class StreamError(JsonSerializable):
    """Emitted when streaming encounters an error"""
    error: str
    type: Literal["error"] = "error"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class RetryStart(JsonSerializable):
    """Emitted when starting a retry attempt after a transient error.
    Allows TUI to show retry status (e.g., "Retrying (1/3) in 2s... (esc to cancel)")
    instead of raw print() statements that mess up the display.
    """
    attempt: int  # Current attempt number (1-indexed)
    max_attempts: int  # Total number of attempts allowed
    delay_seconds: float  # Seconds until retry
    error_message: str  # What error triggered the retry
    provider: str  # "anthropic", "openai", etc.
    type: Literal["retry_start"] = "retry_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class RetryEnd(JsonSerializable):
    """Emitted when retry completes (either success or final failure).
    Allows TUI to clean up retry display and show appropriate status.
    """
    success: bool  # True if retry succeeded, False if all attempts exhausted
    attempt: int  # Final attempt number
    final_error: str | None = None  # Error message if failed
    type: Literal["retry_end"] = "retry_end"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class CompactionStart(JsonSerializable):
    """Emitted when a compaction content block begins streaming."""
    content_index: int
    type: Literal["compaction_start"] = "compaction_start"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class CompactionEvent(JsonSerializable):
    """Emitted when context compaction completes. TUI can show status."""
    summary: str
    tokens_cleared: int | None = None
    type: Literal["compaction_event"] = "compaction_event"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class LLMCallEnd(JsonSerializable):
    """Emitted after LLM API call completes (success or error).
    Wide event: includes all context needed for profiling without correlation.
    """
    duration_ms: float
    provider: str  # "anthropic", "openai", etc.
    model: str
    tokens_in: int | None = None
    tokens_out: int | None = None
    cache_read_tokens: int | None = None
    cache_write_tokens: int | None = None
    status: Literal["success", "error"] = "success"
    error: str | None = None
    type: Literal["llm_call_end"] = "llm_call_end"
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ToolExecutionEnd(JsonSerializable):
    """Emitted after tool execution completes (success or error).
    Wide event: includes result summary for profiling without correlation.
    """
    tool_call_id: str
    tool_name: str
    duration_ms: float
    status: Literal["success", "error"] = "success"
    is_error: bool = False  # Tool returned error result
    # Result summary (tool-specific, optional)
    result_summary: dict[str, Any] | None = None
    type: Literal["tool_execution_end"] = "tool_execution_end"
    timestamp: float = field(default_factory=time.time)


# Union type for all streaming events
StreamEvent = (
    SemaphoreWaitStart
    | SemaphoreAcquired
    | LLMCallStart
    | LLMCallEnd
    | StreamStart
    | TextStart
    | TextDelta
    | TextEnd
    | ThinkingStart
    | ThinkingDelta
    | ThinkingEnd
    | CompactionStart
    | CompactionEvent
    | ToolCallStart
    | ToolCallDelta
    | ToolCallEnd
    | ToolCallError
    | ToolExecutionStart
    | ToolExecutionEnd
    | ToolResultDelta
    | ToolResultReceived
    | StreamDone
    | StreamError
    | RetryStart
    | RetryEnd
    | AgentCheckpoint
)
