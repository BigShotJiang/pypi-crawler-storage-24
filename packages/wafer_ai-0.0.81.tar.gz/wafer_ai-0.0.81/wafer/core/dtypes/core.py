from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any

import trio

from ._base import JsonSerializable
from .environment import Environment
from .messages import Trajectory
from .streaming import StreamEvent
from .tools import (
    StopReason,
    Tool,
    ToolCall,
    ToolConfirmResult,
    ToolResult,
)


# TODO: Add provider-specific max_tokens limits and validate in Endpoint.__post_init__
# Article quote: "Some providers have lower max_tokens than advertised, resulting in cut-off
# responses, even though a higher limit was set via the API request. This affects SiliconFlow,
# Friendly and Cerebras."
#
# Article quote: "Some providers have max_tokens limits which are lower than needed to evaluate
# the corresponding model. These providers were dropped completely for the given eval."
#
# Problem: No validation that max_tokens is within provider/model limits. This causes silent
# truncation where responses are cut off but we don't detect it.
#
# Fix: Add max_output_tokens to ModelInfo in models.py, then validate in __post_init__:
#     model_meta = get_model(self.provider, self.model)
#     if model_meta and model_meta.max_output_tokens:
#         assert self.max_tokens <= model_meta.max_output_tokens
@dataclass(frozen=True)
class Endpoint(JsonSerializable):
    provider: str
    model: str
    api_base: str = ""
    api_key: str = ""
    oauth_token: str = ""  # OAuth bearer token (takes precedence over api_key for Anthropic)
    # TODO: Callbacks on a frozen dataclass are a code smell. This exists because wafer.core
    # can't depend on wafer.cli (where the Supabase refresh logic lives). A cleaner approach
    # would be a TokenProvider protocol that Endpoint delegates to, keeping the dataclass pure.
    api_key_refresh: Callable[[], Awaitable[str | None]] | None = field(
        default=None, repr=False, compare=False
    )
    is_claude_code_api_key: bool = (
        False  # API key created via Claude Code OAuth (requires special headers)
    )
    max_tokens: int = 8192
    # TODO: Document temperature choice for evaluations
    # Article quote: "Evaluators must also decide on the sampling parameters that models will
    # be run with, in particular the temperature... Default temperature is 0.0 for API-based
    # models [lm-evaluation-harness]... Default temperature is 0.5 [simple-evals]...
    # Default temperature is 1.0 (when invoking the script via command line) [gpt-oss]"
    #
    # Problem: Different temperature defaults make results incomparable across frameworks.
    # Our default of 1.0 increases variance. For reproducible evals, consider 0.0.
    #
    # Decision needed: Document why we chose 1.0, or change to 0.0 for deterministic evals.
    temperature: float = 1.0
    tool_choice: str | dict[str, Any] | None = None
    parallel_tool_calls: bool | None = None
    reasoning_effort: str | None = None  # for openai
    max_completion_tokens: int | None = None  # for openai
    thinking: dict[str, Any] | None = None  # for anthropic
    # Retry configuration
    max_retries: int = 10  # Number of retries for rate limits/transient errors
    timeout: float = 120.0  # Timeout in seconds for API calls
    # Extra params merged into the raw chat request for custom servers
    extra_params: dict[str, Any] | None = None
    # Anthropic context management (compaction, tool result clearing, thinking clearing)
    context_management: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        """Validate endpoint configuration.
        Tiger Style: Crash loud on invalid config, explicit error messages.
        """
        # Validate Claude thinking budget (Anthropic requires >= 1024 tokens)
        if self.thinking is not None and self.provider == "anthropic":
            assert isinstance(self.thinking, dict), (
                f"thinking must be dict, got {type(self.thinking)}"
            )
            if self.thinking.get("type") == "enabled":
                budget = self.thinking.get("budget_tokens", 0)
                assert isinstance(budget, int), f"budget_tokens must be int, got {type(budget)}"
                assert budget >= 1024, (
                    f"Claude thinking budget_tokens must be >= 1024, got {budget}. "
                    "Anthropic API requirement for extended thinking mode."
                )
                # max_tokens must be greater than thinking budget
                assert self.max_tokens > budget, (
                    f"max_tokens ({self.max_tokens}) must be greater than thinking.budget_tokens ({budget}). "
                    f"Anthropic requires max_tokens > budget_tokens to allow space for both thinking and response. "
                    f"See https://docs.claude.com/en/docs/build-with-claude/extended-thinking#max-tokens-and-context-window-size"
                )
                # Anthropic requires temperature=1.0 when thinking is enabled
                assert self.temperature == 1.0, (
                    f"Anthropic requires temperature=1.0 when thinking is enabled, got {self.temperature}. "
                    "See https://docs.claude.com/en/docs/build-with-claude/extended-thinking"
                )

    def to_dict(self, exclude_secrets: bool = True) -> dict[str, Any]:
        """Serialize to dict for storage.
        Args:
            exclude_secrets: If True (default), omits api_key and oauth_token.
        """
        d = asdict(self)
        d.pop("api_key_refresh", None)  # Callable, not serializable
        if exclude_secrets:
            d.pop("api_key", None)
            d.pop("oauth_token", None)
        return d

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        api_key: str = "",
        oauth_token: str = "",
        api_key_refresh: Callable[[], Awaitable[str | None]] | None = None,
    ) -> Endpoint:
        """Deserialize from dict, injecting secrets at runtime.
        Args:
            data: Dict from to_dict()
            api_key: API key to inject (not stored in session)
            oauth_token: OAuth token to inject (not stored in session)
            api_key_refresh: Callback to refresh api_key mid-session (not stored)
        """
        # Remove secrets/callables if present (they shouldn't be, but be safe)
        data = data.copy()
        data.pop("api_key", None)
        data.pop("oauth_token", None)
        data.pop("api_key_refresh", None)
        return cls(
            **data, api_key=api_key, oauth_token=oauth_token, api_key_refresh=api_key_refresh
        )


@dataclass(frozen=True)
class Actor(JsonSerializable):
    trajectory: Trajectory
    endpoint: Endpoint
    tools: list[Tool] = field(default_factory=list)


@dataclass(frozen=True)
class AgentState:
    actor: Actor
    environment: Environment | None
    stop: StopReason | None = None
    turn_idx: int = 0
    pending_tool_calls: list[ToolCall] = field(default_factory=list)
    next_tool_idx: int = 0  # Which tool we're about to process
    timestamp: str = datetime.now(UTC).isoformat() + "Z"
    session_id: str | None = None  # Session ID for persistence (set by run_agent)
    # For forking: when resuming with different config, create child session
    parent_session_id: str | None = None  # Parent session to branch from
    branch_point: int | None = None  # Message index where branching from parent
    confirm_tools: bool = False  # Whether tool confirmation is required
    consecutive_failures: int = 0  # Track consecutive tool errors for stop-and-think nudge


# Forward declarations for RunConfig (needs to be after AgentState but before default handlers)
async def default_stdin_handler(prompt: str) -> str:
    """Default input handler using trio.to_thread.run_sync for non-blocking input."""
    return await trio.to_thread.run_sync(input, prompt)


async def default_confirm_tool(
    tc: ToolCall, state: AgentState, run_config: RunConfig
) -> tuple[AgentState, ToolConfirmResult]:
    """Default tool confirmation handler - auto-confirm all tools."""
    return state, ToolConfirmResult(proceed=True)


async def default_no_tool_handler(state: AgentState, run_config: RunConfig) -> AgentState:
    """Default no-tool handler - mark task as complete."""
    from dataclasses import replace
    return replace(state, stop=StopReason.TASK_COMPLETED)


@dataclass(frozen=True)
class RunConfig:
    # TODO: Add runtime validation for on_chunk parameter to catch sync functions early
    # Currently if a sync function is passed, it gets set to None silently, causing
    # "object NoneType can't be used in 'await' expression" errors later. Should validate
    # that on_chunk is properly async and has correct signature at construction time.
    on_chunk: Callable[[StreamEvent], Awaitable[None]]
    on_input: Callable[[str], Awaitable[str]] = field(default_factory=lambda: default_stdin_handler)
    confirm_tool: Callable[
        [ToolCall, AgentState, RunConfig], Awaitable[tuple[AgentState, ToolConfirmResult]]
    ] = field(default_factory=lambda: default_confirm_tool)
    on_step_start: Callable[[AgentState], AgentState] = lambda s: s
    handle_stop: Callable[[AgentState], AgentState] = lambda s: s
    handle_no_tool: Callable[[AgentState, RunConfig], Awaitable[AgentState]] = field(
        default_factory=lambda: default_no_tool_handler
    )
    user_message_for_thinking: str | None = None
    inline_thinking: str | None = None
    show_progress: bool = False  # Enable turn-level progress tracking
    cancel_scope: trio.CancelScope | None = (
        None  # Optional Trio cancel scope for graceful cancellation. When cancel_scope.cancel() is called, any in-flight HTTP request is immediately cancelled and trio.Cancelled is raised. The agent loop catches this and sets stop=StopReason.ABORTED.
    )
    # Session persistence
    session_store: Any | None = (
        None  # SessionStore instance for persistence (session_id is on AgentState)
    )
    # Two-level concurrency control for maximizing API throughput
    # API limiter: controls concurrent LLM API calls (saturate tokens/min)
    # Tool limiter: controls concurrent tool executions (respect file descriptors, GPU limits)
    # When set, samples yield their slot while waiting for the other resource type
    api_limiter: trio.CapacityLimiter | None = None
    tool_limiter: trio.CapacityLimiter | None = None
    on_session_created: Callable[[str], Awaitable[None]] | None = None
