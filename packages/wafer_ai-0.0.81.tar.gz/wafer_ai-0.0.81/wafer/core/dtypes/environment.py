from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

import trio

from ._base import ToolFormatter
from .tools import Tool, ToolCall, ToolResult

if TYPE_CHECKING:
    from .core import AgentState, RunConfig
    from .messages import Message


@runtime_checkable
class Environment(Protocol):
    """Protocol that all environments must satisfy for composition over inheritance."""
    def get_tools(self) -> list[Tool]:
        """Return available tools for this environment."""
        ...

    async def exec_tool(
        self,
        tool_call: ToolCall,
        current_state: AgentState,
        run_config: RunConfig,
        cancel_scope: trio.CancelScope | None = None,
    ) -> ToolResult:
        """Execute a tool call in this environment.
        Args:
            tool_call: The tool call to execute
            current_state: Current agent state
            run_config: Run configuration
            cancel_scope: Optional Trio cancel scope for graceful cancellation
        """
        ...

    def requires_confirmation(self, tool_call: ToolCall) -> bool:
        """Check if tool requires confirmation."""
        ...

    def get_tool_formatter(self, tool_name: str) -> ToolFormatter | None:
        """Return optional TUI formatter for this tool.
        Args:
            tool_name: Name of the tool to format
        Returns:
            A formatter function or None to use the default formatter.
            The formatter receives (tool_name, args, result, expanded) and returns
            a formatted string for display in the TUI.
        """
        ...

    def get_status_info(self) -> dict[str, str] | None:
        """Return key-value pairs to display in TUI status line.
        Optional method - environments can return None or not implement this.
        Example: {"cwd": "~/research", "branch": "main"}
        """
        ...

    def get_system_prompt(self) -> str | None:
        """Return environment-specific system prompt content.
        Optional method - environments can return None or not implement this.
        The returned string will be appended to the base system prompt.
        Use this to explain environment-specific concepts, tools, or strategies
        that the model needs to understand.
        Example (REPL environment):
            return '''
            The input context is stored in a Python variable called `context`.
            Use the repl tool to explore it programmatically.
            '''
        """
        ...

    async def on_session_start(self, session_id: str) -> None:
        """Called when an agent session starts, before any tools execute.
        Optional method - environments can use this to initialize session-specific
        resources (e.g., git worktrees, temp directories, etc.).
        Args:
            session_id: The session ID for this agent run
        """
        ...

    async def on_assistant_message(self, message: Message, state: AgentState) -> AgentState:
        """Called after each assistant message, before tool processing.
        Allows environment to respond to assistant messages with feedback, regardless
        of whether tools were called. Useful for message-based environments that need
        to execute code, provide feedback, or inject responses.
        Args:
            message: The assistant's message (may contain tool calls)
            state: Current agent state
        Returns:
            Updated agent state with environment feedback injected into trajectory.
            Return unchanged state for no response.
        Example (backend-bench):
            Parse code from message, execute it, inject feedback:
            ```python
            async def on_assistant_message(self, message, state):
                code = self.parser.parse([{"role": "assistant", "content": message.content}])
                result = await self.code_evaluator(code)
                feedback_msg = Message(role="user", content=result.feedback)
                # Inject feedback into trajectory
                return replace(state, actor=replace(state.actor, trajectory=replace(
                    state.actor.trajectory,
                    messages=[*state.actor.trajectory.messages, feedback_msg]
                )))
            ```
        """
        ...

    async def serialize(self) -> dict:
        """Serialize environment state to dictionary.
        Must include:
            - env_kind: str (e.g., "calculator", "code_exec", "browser")
            - version: str (e.g., "1.0.0", "2.0.0")
            - ...rest of environment-specific state
        The env_kind and version enable safe restore validation:
        - Prevents restoring snapshots into wrong environment types
        - Prevents restoring incompatible versions (schema changes)
        Example:
            >>> async def serialize(self) -> dict:
            ...     return {
            ...         "env_kind": self.ENV_KIND,  # Class constant
            ...         "version": self.VERSION,    # Class constant
            ...         "history": self._history,
            ...         "state": self._state,
            ...     }
        """
        ...

    @staticmethod
    async def deserialize(data: dict) -> Environment:
        """Deserialize environment from dictionary.
        Should validate env_kind and version before restoring state.
        Example:
            >>> @staticmethod
            ... async def deserialize(data: dict) -> 'MyEnvironment':
            ...     assert data["env_kind"] == MyEnvironment.ENV_KIND
            ...     assert data["version"].startswith("1.")  # compatible versions
            ...     env = MyEnvironment()
            ...     env._history = data["history"]
            ...     return env
        """
        ...
