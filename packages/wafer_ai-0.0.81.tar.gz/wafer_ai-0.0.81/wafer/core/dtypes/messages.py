from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from ._base import JsonSerializable
from .content import (
    ContentBlock,
    TextContent,
    ThinkingContent,
    ToolCallContent,
)
from .tools import ToolCall


@dataclass(frozen=True)
class Message(JsonSerializable):
    """Unified message type supporting all providers.
    Content can be:
    - str: Simple text message (most common)
    - list[ContentBlock]: Structured message with text/thinking/tools/images
    Role can be:
    - "user": User input
    - "assistant": Model response
    - "tool": Tool execution result
    """
    role: str
    content: str | list[ContentBlock] | None
    # Provider metadata for message transformation
    provider: str | None = None  # e.g., "anthropic", "openai", "google"
    api: str | None = None  # e.g., "anthropic-messages", "openai-completions", "openai-responses"
    model: str | None = None  # e.g., "claude-3-5-sonnet-20241022", "gpt-4o"
    # For tool role messages: which tool call this is responding to
    tool_call_id: str | None = None
    # UI-only structured data (stripped before LLM)
    details: dict[str, Any] | None = None
    # Session storage timestamp (optional, only set when persisting)
    timestamp: str | None = None

    def get_tool_calls(self) -> list[ToolCall]:
        """Extract tool calls from ContentBlocks.
        Tiger Style: Helper for common operation, makes migration easier.
        """
        if not isinstance(self.content, list):
            return []
        tool_calls = []
        for block in self.content:
            if isinstance(block, ToolCallContent):
                tool_calls.append(
                    ToolCall(
                        id=block.id,
                        name=block.name,
                        args=block.arguments,
                        parse_error=block.parse_error,
                    )
                )
        return tool_calls

    def __repr__(self) -> str:
        """Tiger Style: Bounded repr, truncate large content.
        Vision messages can contain base64 images (100KB+).
        Always truncate to prevent terminal spam.
        """

        if isinstance(self.content, str):
            content_preview = (
                self.content[:100] + "..." if len(self.content) > 100 else self.content
            )
        elif isinstance(self.content, list):
            # Show ContentBlock types
            block_types = [b.type for b in self.content if hasattr(b, "type")]
            content_preview = f"[{len(self.content)} blocks: {', '.join(block_types)}]"
        else:
            content_preview = str(self.content)
        return f"Message(role={self.role!r}, content={content_preview!r})"


@dataclass(frozen=True)
class Cost(JsonSerializable):
    """Cost breakdown in USD. Immutable.
    Following IMMUTABILITY_AND_FP: frozen dataclass for data that doesn't change.
    """
    input: float = 0.0
    output: float = 0.0
    cache_read: float = 0.0
    cache_write: float = 0.0

    @property
    def total(self) -> float:
        return self.input + self.output + self.cache_read + self.cache_write


@dataclass(frozen=True)
class Usage(JsonSerializable):
    """Token usage with cost tracking. Immutable.
    Following IMMUTABILITY_AND_FP: state changes are explicit via replace().
    Following SSA: each transformation creates a new binding.
    Example:
        # SSA style - named intermediate values
        raw_usage = Usage(input_tokens=100, output_tokens=50)
        usage_with_cost = replace(raw_usage, cost=calculated_cost)
    """
    # Token counts (primary fields)
    input_tokens: int = 0  # Non-cached input tokens
    output_tokens: int = 0  # Output/completion tokens (excludes reasoning)
    reasoning_tokens: int = 0  # Reasoning/thinking tokens (OpenAI o1/o3, Anthropic thinking)
    cache_read_tokens: int = 0  # Tokens read from cache (Anthropic/OpenAI)
    cache_write_tokens: int = 0  # Tokens written to cache (Anthropic)
    # Cost breakdown (computed by provider after API response)
    cost: Cost = field(default_factory=Cost)

    # Computed properties
    @property
    def total_tokens(self) -> int:
        return (
            self.input_tokens
            + self.output_tokens
            + self.reasoning_tokens
            + self.cache_read_tokens
            + self.cache_write_tokens
        )

@dataclass(frozen=True)
class Logprob(JsonSerializable):
    token: str
    logprob: float
    bytes: list[int]
    top_logprobs: list[float]


@dataclass(frozen=True)
class Logprobs(JsonSerializable):
    content: list[Logprob] = field(default_factory=list)


@dataclass(frozen=True)
class Choice(JsonSerializable):
    index: int
    message: Message
    finish_reason: str
    logprobs: Logprobs | None = None
    stop_reason: Any | None = None
    token_ids: tuple[int, ...] | None = None  # Generated token IDs for TI/TO


@dataclass(frozen=True)
class TokenInfo(JsonSerializable):
    logprob: float
    rank: int
    decoded_token: str


PromptLogprob = dict[str, TokenInfo] | None
"""
{
"8948": { # key is different every token
"logprob": -12.845086097717285,
"rank": 60822,
"decoded_token": "system"
}
}
"""


@dataclass(frozen=True)
class ChatCompletion(JsonSerializable):
    id: str
    object: str
    created: int
    model: str
    usage: Usage
    kv_transfer_params: Any | None = None
    choices: list[Choice] = field(default_factory=list)
    prompt_logprobs: list[PromptLogprob] | None = None


@dataclass
class Trajectory(JsonSerializable):
    completions: list[ChatCompletion] = field(default_factory=list)
    messages: list[Message] = field(default_factory=list)  # debugging only
    rewards: float = 0.0
    group: int = 0
    replica: int = 0
    advantages: float = 0.0  # scalar; broadcast later if needed
    metadata: dict[str, Any] = field(
        default_factory=dict
    )  # For dataset-specific info (e.g., ground truth)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> Trajectory:
        """Rebuild nested dataclasses so type hints stay correct."""
        assert data is not None
        assert isinstance(data, dict)
        comps: list[ChatCompletion] = []
        for comp in data.get("completions", []):
            assert comp is not None
            assert isinstance(comp, dict)
            usage_dict = comp.get("usage", {})
            assert "prompt_tokens" in usage_dict
            assert "completion_tokens" in usage_dict
            assert "total_tokens" in usage_dict
            usage = Usage(
                input_tokens=usage_dict["prompt_tokens"],
                output_tokens=usage_dict["completion_tokens"],
            )
            assert usage is not None
            # Construct ChatCompletion with explicit parameters for type safety
            comps.append(
                ChatCompletion(
                    id=comp.get("id", "unknown"),
                    object=comp.get("object", "chat.completion"),
                    created=comp.get("created", 0),
                    model=comp.get("model", "unknown"),
                    usage=usage,
                    kv_transfer_params=comp.get("kv_transfer_params"),
                    choices=comp.get("choices", []),
                    prompt_logprobs=comp.get("prompt_logprobs"),
                )
            )
        result = Trajectory(
            completions=comps,
            messages=data.get("messages", []),
            rewards=data.get("rewards", 0.0),
            group=data.get("group", 0),
            replica=data.get("replica", 0),
            advantages=data.get("advantages", 0.0),
            metadata=data.get("metadata", {}),
        )
        assert result is not None
        return result

    # ---------- JSONL convenience layer -----------------------------------
    def to_json(self) -> str:
        assert self is not None
        result = json.dumps(asdict(self), ensure_ascii=False)
        assert result is not None
        assert isinstance(result, str)
        return result

    @staticmethod
    def to_jsonl(trajectories: list[Trajectory]) -> str:
        assert trajectories is not None
        assert isinstance(trajectories, list)
        result = "\n".join(t.to_json() for t in trajectories)
        assert isinstance(result, str)
        return result

    @staticmethod
    def from_json(json_str: str) -> Trajectory:
        assert json_str is not None
        assert isinstance(json_str, str)
        assert len(json_str) > 0
        data = json.loads(json_str)
        result = Trajectory.from_dict(data)
        assert result is not None
        return result

    @staticmethod
    def from_jsonl(jsonl_str: str) -> list[Trajectory]:
        assert jsonl_str is not None
        assert isinstance(jsonl_str, str)
        result = [Trajectory.from_json(line) for line in jsonl_str.strip().splitlines() if line]
        assert isinstance(result, list)
        return result

    # ---------- disk I/O ---------------------------------------------------
    @staticmethod
    def save_jsonl(trajectories: list[Trajectory], filepath: str) -> None:
        assert trajectories is not None
        assert isinstance(trajectories, list)
        assert filepath is not None
        assert len(filepath) > 0
        jsonl_content = Trajectory.to_jsonl(trajectories)
        assert jsonl_content is not None
        path_obj = Path(filepath)
        path_obj.write_text(jsonl_content, encoding="utf-8")
        assert path_obj.exists()

    @staticmethod
    def load_jsonl(filepath: str) -> list[Trajectory]:
        assert filepath is not None
        assert len(filepath) > 0
        path_obj = Path(filepath)
        assert path_obj.exists(), f"File not found: {filepath}"
        assert path_obj.is_file()
        content = path_obj.read_text(encoding="utf-8")
        result = Trajectory.from_jsonl(content)
        assert result is not None
        assert isinstance(result, list)
        return result

    @staticmethod
    def load_jsonl_streaming(filepath: str) -> Iterator[Trajectory]:
        assert filepath is not None
        assert len(filepath) > 0
        path_obj = Path(filepath)
        assert path_obj.exists(), f"File not found: {filepath}"
        assert path_obj.is_file()
        with open(filepath, encoding="utf-8") as f:
            for line in f:
                line_stripped = line.strip()
                if line_stripped:  # Skip empty lines
                    yield Trajectory.from_json(line_stripped)

    @staticmethod
    def hash(trajectory: Trajectory) -> str:
        """Generate a hash for a single trajectory."""
        import hashlib
        assert trajectory is not None
        assert isinstance(trajectory, Trajectory)
        traj_dict = asdict(trajectory)
        assert traj_dict is not None
        traj_str = json.dumps(traj_dict, sort_keys=True)
        assert traj_str is not None
        result = hashlib.sha256(traj_str.encode()).hexdigest()[:16]
        assert result is not None
        assert isinstance(result, str)
        assert len(result) == 16
        return result
