from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field, fields
from enum import Enum
from typing import Any

from ._base import JsonSerializable
from .content import TextContent, ThinkingContent
from .messages import Message, Trajectory
from .tools import StopReason


@dataclass(frozen=True)
class Metric:
    """A measured dimension. Weight=0 means track-only, weight>0 means contributes to reward.
    Tiger Style: Immutable, explicit, composable.
    Examples:
        >>> # Reward component (contributes to training signal)
        >>> Metric("correct", 1.0, weight=1.0)
        >>> # Tracking-only metric (logged but not used for optimization)
        >>> Metric("latency_ms", 145.2, weight=0)
        >>> # With metadata for debugging
        >>> Metric("format_valid", 0.0, weight=0.2, metadata={"error": "missing closing tag"})
    Future consideration: Add a `format` field (e.g., "percent", "multiplier", "boolean")
    to hint how the dashboard should display the value. Currently the dashboard infers
    format from the value type (boolean → Yes/No, 0-1 float → percent, else number).
    This works for most cases but can't distinguish 0.85 (percent) from 0.85x (multiplier).
    """
    name: str
    value: float
    weight: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Score:
    """Collection of metrics, some of which are rewards (weight > 0).
    Tiger Style: Immutable, explicit breakdown, single reward property for training.
    Examples:
        >>> score = Score(metrics=(
        ...     Metric("correct", 1.0, weight=1.0),
        ...     Metric("format", 0.5, weight=0.2),
        ...     Metric("tokens", 150, weight=0),  # tracked only
        ... ))
        >>> score.reward  # Weighted average: (1.0*1.0 + 0.5*0.2) / (1.0 + 0.2) = 0.917
        0.9166666666666666
    """
    metrics: tuple[Metric, ...]

    @property
    def reward(self) -> float:
        """Weighted average of metrics with weight > 0."""
        weighted = [(m.value, m.weight) for m in self.metrics if m.weight > 0]
        if not weighted:
            return 0.0
        total_weight = sum(w for _, w in weighted)
        return sum(v * w for v, w in weighted) / total_weight

    def to_dict(self) -> dict[str, Any]:
        """Serialize Score to dict for JSON output."""
        return {
            "metrics": [
                {"name": m.name, "value": m.value, "weight": m.weight, "metadata": m.metadata}
                for m in self.metrics
            ],
            "reward": self.reward,
        }

    @staticmethod
    def from_dict(data: dict[str, Any]) -> Score:
        """Deserialize Score from dict."""
        assert "metrics" in data, f"Score dict must have 'metrics' key, got: {list(data.keys())}"
        return Score(metrics=tuple(
            Metric(
                name=m["name"],
                value=m["value"],
                weight=m.get("weight", 0.0),
                metadata=m.get("metadata", {}),
            )
            for m in data["metrics"]
        ))


@dataclass(frozen=True)
class TurnScore:
    """A Score anchored to a specific message in the trajectory.

    Used for per-turn reward signals: each time the agent calls eval_task,
    the Score JSON lands in a tool output. extract_turn_scores() scans the
    trajectory and records a TurnScore at each such message index.
    """
    message_index: int
    score: Score


class Status(Enum):
    """Sample status."""
    PENDING = "pending"
    COMPLETED = "completed"
    TRUNCATED = "truncated"
    ABORTED = "aborted"


@dataclass
class Sample:
    """Unified sample type for evaluation and agent runs."""
    # Identity
    id: str = ""
    index: int | None = None
    group_index: int | None = None
    # Input
    input: dict[str, Any] = field(default_factory=dict)
    prompt: str | list[dict[str, str]] = ""
    ground_truth: Any | None = None
    # Generated
    trajectory: Trajectory | None = None
    # Evaluation-specific
    code_score: Score | None = None
    trajectory_score: Score | None = None
    score: Score | None = None
    reward: float = 0.0
    turn_scores: tuple[TurnScore, ...] = ()
    # Status and metadata
    status: Status = Status.PENDING
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def response(self) -> str:
        """Extract final assistant response from trajectory.
        Handles both Message objects and raw dicts (Trajectory.from_dict does not
        reconstruct Message objects for the messages list).
        """
        if not self.trajectory or not self.trajectory.messages:
            return ""
        for msg in reversed(self.trajectory.messages):
            role = msg.role if hasattr(msg, "role") else msg.get("role")
            content = msg.content if hasattr(msg, "content") else msg.get("content")
            if role != "assistant":
                continue
            if isinstance(content, str):
                return content
            if content is None:
                continue
            parts = []
            for block in content:
                if isinstance(block, TextContent):
                    parts.append(block.text)
                elif isinstance(block, ThinkingContent):
                    parts.append(block.thinking)
                elif isinstance(block, dict):
                    if block.get("type") == "text":
                        parts.append(block.get("text", ""))
                    elif block.get("type") == "thinking":
                        parts.append(block.get("thinking", ""))
            return "".join(parts)
        return ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict for serialization."""
        d: dict[str, Any] = {}
        for key, value in self.__dict__.items():
            if key == "status":
                d[key] = value.value
            elif key == "trajectory" and isinstance(value, Trajectory):
                d[key] = json.loads(value.to_json())
            elif key in ("score", "code_score", "trajectory_score") and value is not None:
                d[key] = value.to_dict()
            elif key == "turn_scores":
                d[key] = [
                    {"message_index": ts.message_index, "score": ts.score.to_dict()}
                    for ts in value
                ]
            else:
                d[key] = value
        return d

    @staticmethod
    def from_dict(data: dict[str, Any]) -> Sample:
        """Create Sample from dict."""
        data = data.copy()
        if "status" in data:
            data["status"] = Status(data["status"])
        if "trajectory" in data and data["trajectory"] is not None:
            data["trajectory"] = Trajectory.from_dict(data["trajectory"])
        for score_key in ("score", "code_score", "trajectory_score"):
            if score_key in data and data[score_key] is not None:
                data[score_key] = Score.from_dict(data[score_key])
        if "turn_scores" in data and data["turn_scores"] is not None:
            data["turn_scores"] = tuple(
                TurnScore(
                    message_index=ts["message_index"],
                    score=Score.from_dict(ts["score"]),
                )
                for ts in data["turn_scores"]
            )
        valid_fields = {f.name for f in fields(Sample)}
        data = {k: v for k, v in data.items() if k in valid_fields}
        return Sample(**data)

# Score function: pure transform from Sample -> Score
# Sample has trajectory, ground_truth, input, etc. - access via sample.trajectory
# Supports both sync and async (for external verifiers that need network calls)
ScoreFn = Callable[[Sample], Score] | Callable[[Sample], Awaitable[Score]]
