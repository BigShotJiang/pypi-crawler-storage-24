"""Backward-compat re-export. Canonical location: wafer.core.infra.gpu_detect."""
from wafer.core.infra.gpu_detect import *  # noqa: F401,F403
