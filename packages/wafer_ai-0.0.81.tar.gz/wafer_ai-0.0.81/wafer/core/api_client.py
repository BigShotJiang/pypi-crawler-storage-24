"""Backward-compat re-export. Canonical location: wafer.core.infra.api_client."""
from wafer.core.infra.api_client import *  # noqa: F401,F403
