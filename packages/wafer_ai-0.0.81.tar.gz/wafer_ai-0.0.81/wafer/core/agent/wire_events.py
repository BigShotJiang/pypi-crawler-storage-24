"""Canonical wire event contract for streaming events.

Defines the typed event shapes that flow over NDJSON and SSE between
producers (JsonFrontend) and consumers
(subprocess_agents._flush_line, cmd_agent._render_sse_event, TS UIs, eval harness).

Usage:
    raw = json.loads(line)
    event = normalize_wire_event(raw)
    match event["type"]:
        case "text_delta": ...
        case "tool_call_start": ...
"""
from __future__ import annotations

from typing import Any

PASSTHROUGH_EVENT_TYPES = frozenset({
    "status",
    "text_delta",
    "thinking_delta",
    "tool_call_start",
    "tool_call_delta",
    "tool_call_end",
    "tool_result",
    "tool_result_delta",
    "turn_end",
    "score",
    "error",
})

_TYPE_ALIASES: dict[str, str] = {
    "session_start": "session_started",
    "session_end": "session_complete",
}


def normalize_wire_event(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize a raw JSON event dict to canonical wire format.

    Handles legacy field names and event type aliases so consumers
    only need to handle one shape per event type.

    Mutations:
    - type aliases: session_start -> session_started, session_end -> session_complete
    - tool_call_start/end: tool_name -> name
    """
    if not isinstance(raw, dict):
        raise TypeError(f"Expected dict, got {type(raw).__name__}")
    etype = raw.get("type", "")
    canonical_type = _TYPE_ALIASES.get(etype, etype)
    if canonical_type != etype:
        raw = {**raw, "type": canonical_type}

    if canonical_type in ("tool_call_start", "tool_call_end"):
        raw = _normalize_tool_call_fields(raw)

    return raw


def _normalize_tool_call_fields(raw: dict[str, Any]) -> dict[str, Any]:
    """Ensure tool_call_start/end have canonical 'name' field."""
    if "name" not in raw and "tool_name" in raw:
        raw = {**raw, "name": raw["tool_name"]}
    return raw


# ── Cursor native event translation ──────────────────────────────────────────

_CURSOR_NATIVE_TYPES = frozenset({"system", "user", "assistant", "tool_call", "result"})


def is_cursor_native_event(raw: dict[str, Any]) -> bool:
    """True when the event uses Cursor CLI stream-json types rather than wafer wire types."""
    return raw.get("type", "") in _CURSOR_NATIVE_TYPES


def translate_cursor_events(raw: dict[str, Any]) -> list[dict[str, Any]]:
    """Translate a Cursor CLI stream-json event into wafer wire event(s).

    Cursor emits: system, user, assistant, tool_call (started/completed), result.
    Returns a list because tool_call completed expands into two events.
    Returns empty list for events that should be skipped.
    """
    etype = raw.get("type", "")

    if etype == "system" and raw.get("subtype") == "init":
        return [{"type": "session_started", "session_id": raw.get("session_id", "")}]

    if etype == "assistant":
        content_blocks = raw.get("message", {}).get("content", [])
        if isinstance(content_blocks, list):
            text = "\n".join(b.get("text", "") for b in content_blocks if b.get("type") == "text")
        else:
            text = str(content_blocks)
        if text:
            return [{"type": "text_delta", "delta": text}]
        return []

    if etype == "tool_call":
        subtype = raw.get("subtype", "")
        call_id = raw.get("call_id", "")
        tool_call = raw.get("tool_call", {})
        name, args, result_content = _extract_cursor_tool_info(tool_call)
        if subtype == "started":
            return [{"type": "tool_call_start", "name": name, "id": call_id, "input": args}]
        if subtype == "completed":
            return [
                {"type": "tool_call_end", "id": call_id, "name": name, "args": args},
                {"type": "tool_result", "id": call_id, "content": result_content[:16_000]},
            ]
        return []

    if etype == "result":
        stop_reason = "end_turn" if raw.get("subtype") == "success" else "error"
        ev: dict[str, Any] = {"type": "turn_end", "stop_reason": stop_reason}
        if "duration_ms" in raw:
            ev["duration_ms"] = raw["duration_ms"]
        if "duration_api_ms" in raw:
            ev["duration_api_ms"] = raw["duration_api_ms"]
        usage = raw.get("usage")
        if isinstance(usage, dict):
            ev["usage"] = usage
        return [ev]

    return []


def _extract_cursor_tool_info(tool_call: dict[str, Any]) -> tuple[str, Any, str]:
    """Extract (name, args, result_content) from a Cursor tool_call payload."""
    for key, inner in tool_call.items():
        if not isinstance(inner, dict):
            continue
        if key == "function":
            return inner.get("name", "function"), inner.get("arguments", {}), str(inner.get("result", ""))
        tool_name = key.replace("ToolCall", "").replace("_call", "")
        args = inner.get("args", {})
        result_data = inner.get("result", {})
        if isinstance(result_data, dict):
            success = result_data.get("success", {})
            result_content = success.get("content", "")
            if not result_content and success:
                import json as _json
                result_content = _json.dumps(success, default=str)[:16_000]
        else:
            import json as _json
            result_content = _json.dumps(result_data, default=str)[:16_000] if isinstance(result_data, (dict, list)) else str(result_data)[:16_000]
        return tool_name, args, result_content
    return "unknown", tool_call, ""
