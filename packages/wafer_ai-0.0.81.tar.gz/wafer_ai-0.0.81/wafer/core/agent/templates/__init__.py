"""Template system for constrained, task-specific agents.

Templates are loaded from bundled TOML files in wafer/core/config/templates/.
"""

from .loader import list_templates, load_all_templates, load_template

__all__ = [
    "load_all_templates",
    "load_template",
    "list_templates",
]
