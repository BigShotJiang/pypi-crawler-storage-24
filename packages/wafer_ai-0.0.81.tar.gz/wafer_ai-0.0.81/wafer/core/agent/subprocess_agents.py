"""CLI Agent Adapter for Evaluation.

Runs wafer or Cursor as subprocess and parses output into Trajectory format.
"""
from __future__ import annotations

import json
import logging
import shlex
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from wafer.core.dtypes import (
    Message,
    Trajectory,
)

from .cli_commands import build_cursor_cli_args
from .frontends.terminal_renderer import TerminalRenderer
from .parsers import (
    parse_claude_code_stream_json,
    parse_cursor_wire_events,
    parse_raw_text_fallback,
    parse_wafer_stream_json,
)
from .wire_events import is_cursor_native_event, normalize_wire_event, translate_cursor_events

logger = logging.getLogger(__name__)
# ── Types ─────────────────────────────────────────────────────────────────────
AgentName = Literal["wafer", "cursor"]


@dataclass(frozen=True)
class CLIAgentConfig:
    """Configuration for CLI agent execution.
    Frozen dataclass: immutable, serializable, explicit.

    agent: CLI to execute (always "wafer" for cloud routing).
    source_agent: real agent type from TOML for parser selection (e.g. "cursor").
    """
    agent: AgentName
    model: str | None = None
    system_prompt: str | None = None
    timeout_sec: float = 600.0
    allowed_tools: list[str] | None = None
    extra_args: list[str] = field(default_factory=list)
    use_modal: bool = False
    source_agent: AgentName | None = None

    @classmethod
    def from_toml(cls, path: Path, *, timeout_sec: float = 600.0) -> "CLIAgentConfig":
        """Build CLIAgentConfig from a TOML config file.
        For wafer: passes -t <path> so wafer reads all settings from the file.
        For claude/codex: reads model, system_prompt at load time.
        """
        from wafer.core.config.agent import load_agent_config

        path = path.resolve()
        assert path.exists(), f"Config file not found: {path}"
        file_config = load_agent_config(path)
        agent = file_config.agent or "wafer"
        assert agent in ("wafer", "cursor"), (
            f"agent must be wafer or cursor. Got: {agent!r}"
        )
        if agent == "wafer":
            return cls(
                agent="wafer",
                model=None,
                system_prompt=None,
                timeout_sec=timeout_sec,
                allowed_tools=None,
                extra_args=["-t", str(path)],
                use_modal=False,
            )
        return cls(
            agent=agent,
            model=file_config.model,
            system_prompt=file_config.system_prompt,
            timeout_sec=timeout_sec,
            allowed_tools=None,
            extra_args=[],
            use_modal=False,
        )

    @classmethod
    def for_template(
        cls,
        template_name: str,
        *,
        timeout_sec: float = 600.0,
        config_template_args: dict[str, str] | None = None,
    ) -> "CLIAgentConfig":
        """Build CLIAgentConfig for a bundled template.
        Uses -t template_name so the sandbox resolves from its installed package.
        config_template_args become --args KEY=VALUE for template variable substitution.
        agent is always "wafer" for cloud routing; source_agent tracks the real agent
        type from the TOML for parser selection.
        """
        from wafer.core.config.agent import get_bundled_template_path, load_agent_config

        path = get_bundled_template_path(template_name)
        if path is None:
            from wafer.core.config.agent import list_bundled_templates
            available = list_bundled_templates()
            raise ValueError(
                f"Template not found: {template_name}. "
                f"Available: {', '.join(available) if available else '(none)'}"
            )
        file_config = load_agent_config(path)
        real_agent = file_config.agent or "wafer"
        extra_args: list[str] = ["-t", template_name]
        if config_template_args:
            for k, v in config_template_args.items():
                extra_args.extend(["--args", f"{k}={v}"])
        return cls(
            agent="wafer",
            model=None,
            timeout_sec=timeout_sec,
            allowed_tools=None,
            extra_args=extra_args,
            use_modal=False,
            source_agent=real_agent if real_agent != "wafer" else None,
        )


@dataclass(frozen=True)
class CLIAgentResult:
    """Result of running a CLI agent.
    Frozen dataclass: all fields explicit, immutable after creation.
    """
    trajectory: Trajectory
    raw_output: str
    duration_sec: float
    exit_code: int
    session_id: str | None = None
    error: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens + self.cache_read_tokens + self.cache_write_tokens


# ── Command Building (Pure) ───────────────────────────────────────────────────
def build_cli_command(
    config: CLIAgentConfig,
    instruction: str,
    *,
    use_cloud: bool = False,
    working_dir: Path | None = None,
    cloud_target: str | None = None,
) -> list[str]:
    """Build CLI command for the specified agent.
    Pure function: config + instruction -> command list.
    When use_cloud, injects --cloud and --dir for wafer agent.
    """
    assert config is not None, "config must not be None"
    assert instruction is not None, "instruction must not be None"
    assert len(instruction) > 0, "instruction must not be empty"
    if config.agent == "wafer":
        cmd = _build_wafer_command(config, instruction)
        if use_cloud and working_dir is not None:
            cloud_flags = ["--cloud", "--json", "--dir", str(working_dir)]
            if cloud_target:
                cloud_flags += ["--target", cloud_target]
            cmd = cmd[:2] + cloud_flags + cmd[2:]
        return cmd
    assert config.agent == "cursor"
    return build_cursor_cli_args(
        instruction,
        model=config.model,
    )


def _build_wafer_command(config: CLIAgentConfig, instruction: str) -> list[str]:
    """Build wafer-cli agent command.
    wafer agent "instruction" --output-format stream-json [extra_args]
    Agent config (model, tools) comes from -t in extra_args.
    stream-json implies single-turn.
    """
    cmd = [
        "wafer",
        "agent",
        instruction,
        "--output-format",
        "stream-json",
    ]
    cmd.extend(config.extra_args)
    return cmd


# ── Agent Execution ───────────────────────────────────────────────────────────
async def run_cli_agent(
    config: CLIAgentConfig,
    instruction: str,
    working_dir: Path,
    on_stream_line: Callable[[dict[str, Any]], None] | None = None,
    output_prefix: str | None = None,
    stdout_lock: threading.Lock | None = None,
    use_modal: bool = False,
    use_cloud: bool = False,
    cloud_target: str | None = None,
    quiet: bool = False,
) -> CLIAgentResult:
    """Run CLI agent and return structured result.
    Args:
        config: Agent configuration (agent name, model, timeout)
        instruction: Task instruction for the agent
        working_dir: Directory where agent will execute
        on_stream_line: Optional callback for each parsed JSON line from agent stdout
        output_prefix: When set, prefix each line of stdout (for concurrent runs)
        use_modal: When True, run inside a Modal Sandbox instead of local subprocess
        cloud_target: When set with use_cloud, passes --target to route agent to a specific GPU
    Returns:
        CLIAgentResult with trajectory, raw output, timing, exit code
    """
    import trio

    assert config is not None
    assert instruction is not None
    assert len(instruction) > 0

    if use_modal:
        from .modal_runner import run_cli_agent_modal
        return await run_cli_agent_modal(
            config=config,
            instruction=instruction,
            working_dir=working_dir,
            on_stream_line=on_stream_line,
        )

    assert working_dir.exists()  # noqa: ASYNC240 - sync assertion before async work
    assert working_dir.is_dir()  # noqa: ASYNC240 - sync assertion before async work
    cmd = build_cli_command(
        config, instruction,
        use_cloud=use_cloud,
        working_dir=working_dir if use_cloud else None,
        cloud_target=cloud_target,
    )
    if output_prefix:
        flat = instruction.replace("\n", " ").strip()
        if len(flat) > 200:
            flat = flat[:200] + "..."
        logger.info(f"[{output_prefix}] {flat}")
    else:
        logger.info(f"Running {config.agent}: {shlex.join(cmd[:5])}...")
    start_time = time.perf_counter()
    raw_output_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    stdout_line_buf = ""
    renderer = TerminalRenderer(
        mode="eval",
        prefix=output_prefix,
        stdout_lock=stdout_lock,
        quiet=quiet or output_prefix is not None,
    )

    def _flush_line(line: str) -> None:
        stripped = line.strip()
        if not stripped:
            return
        try:
            obj = json.loads(stripped)
        except json.JSONDecodeError:
            if not renderer._quiet:
                renderer.flush()
                renderer.write_raw(
                    (line if line.endswith("\n") else line + "\n"),
                    "\033[2m",
                )
            return
        if on_stream_line is not None:
            if is_cursor_native_event(obj):
                for translated in translate_cursor_events(obj):
                    on_stream_line(translated)
            else:
                on_stream_line(obj)
        event = normalize_wire_event(obj)
        renderer.render(event)

    process = await trio.lowlevel.open_process(
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(working_dir),
    )
    assert process.stdout is not None
    assert process.stderr is not None

    async def read_stdout() -> None:
        nonlocal stdout_line_buf
        async for chunk in process.stdout:
            raw_output_chunks.append(chunk)
            text = chunk.decode("utf-8", errors="replace")
            stdout_line_buf += text
            while "\n" in stdout_line_buf:
                line, stdout_line_buf = stdout_line_buf.split("\n", 1)
                _flush_line(line)

    async def read_stderr() -> None:
        async for chunk in process.stderr:
            stderr_chunks.append(chunk)
            sys.stderr.buffer.write(chunk)
            sys.stderr.flush()

    async def _kill_process(proc: trio.Process) -> None:
        """Terminate then kill. Used both for timeout and external cancellation."""
        if proc.returncode is not None:
            return
        proc.terminate()
        with trio.move_on_after(5):
            await proc.wait()
        if proc.returncode is None:
            proc.kill()
            await proc.wait()

    timed_out = False
    try:
        with trio.move_on_after(config.timeout_sec) as cancel_scope:
            async with trio.open_nursery() as nursery:
                nursery.start_soon(read_stdout)
                nursery.start_soon(read_stderr)
        timed_out = cancel_scope.cancelled_caught
    except BaseException:
        await _kill_process(process)
        raise
    if stdout_line_buf.strip():
        _flush_line(stdout_line_buf)
        stdout_line_buf = ""
    renderer.flush()
    sys.stdout.write("\n")
    sys.stdout.flush()
    if timed_out:
        await _kill_process(process)
        duration_sec = time.perf_counter() - start_time
        raw_output = b"".join(raw_output_chunks).decode("utf-8", errors="replace")
        parse_agent = config.source_agent or config.agent
        messages = _parse_agent_output(parse_agent, raw_output)
        return CLIAgentResult(
            trajectory=Trajectory(messages=messages),
            raw_output=raw_output,
            duration_sec=duration_sec,
            exit_code=-1,
            session_id=renderer.session_id,
            error=f"Timeout after {config.timeout_sec}s",
            input_tokens=renderer.input_tokens,
            output_tokens=renderer.output_tokens,
            cache_read_tokens=renderer.cache_read_tokens,
            cache_write_tokens=renderer.cache_write_tokens,
        )

    await process.wait()
    duration_sec = time.perf_counter() - start_time
    raw_output = b"".join(raw_output_chunks).decode("utf-8", errors="replace")
    stderr = b"".join(stderr_chunks).decode("utf-8", errors="replace")
    parse_agent = config.source_agent or config.agent
    messages = _parse_agent_output(parse_agent, raw_output)
    error = None
    if process.returncode != 0:
        sig_killed = process.returncode is not None and process.returncode < 0
        signal_num = -process.returncode if sig_killed else (process.returncode - 128 if process.returncode and process.returncode > 128 else None)
        stderr_msg = stderr[:500].strip()
        if not stderr_msg:
            tail = raw_output[-2000:] if len(raw_output) > 2000 else raw_output
            stderr_msg = f"(no stderr captured, stdout tail: {tail[-500:]})"
        signal_hint = ""
        if signal_num == 15 or process.returncode == 143:
            signal_hint = " [SIGTERM — agent was killed externally, likely cloud sandbox timeout]"
        elif signal_num == 9 or process.returncode == 137:
            signal_hint = " [SIGKILL — agent was force-killed, likely OOM or sandbox limit]"
        error = f"Exit code {process.returncode}{signal_hint}: {stderr_msg}"
        logger.warning(
            "Agent process exited rc=%d duration=%.1fs turns=%d session=%s%s stderr=%s",
            process.returncode, duration_sec, len(messages),
            renderer.session_id or "(none)", signal_hint, stderr[:300],
        )
    return CLIAgentResult(
        trajectory=Trajectory(messages=messages),
        raw_output=raw_output,
        duration_sec=duration_sec,
        exit_code=process.returncode or 0,
        session_id=renderer.session_id,
        error=error,
        input_tokens=renderer.input_tokens,
        output_tokens=renderer.output_tokens,
        cache_read_tokens=renderer.cache_read_tokens,
        cache_write_tokens=renderer.cache_write_tokens,
    )


def _parse_agent_output(agent: AgentName, output: str) -> list[Message]:
    """Parse agent output into Messages."""
    if agent == "cursor":
        messages = parse_cursor_wire_events(output)
        if not messages and output.strip():
            messages = parse_raw_text_fallback(output)
        return messages
    assert agent == "wafer"
    messages = parse_claude_code_stream_json(output)
    if not messages:
        messages = parse_wafer_stream_json(output)
    if not messages and output.strip():
        messages = parse_raw_text_fallback(output)
    return messages
