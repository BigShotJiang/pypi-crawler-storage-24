"""Package configuration and asset discovery.

Provides paths to package assets (README, docs, presets) that work with:
- `uv tool install -e ~/wafer` (editable/dev install)
- `uv tool install wafer-ai` (from PyPI)
- `python -m wafer` (direct execution)

For editable installs, assets are found relative to the source tree.
For installed packages, key docs should be bundled in wafer/_docs/.
"""

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

# =============================================================================
# User Config Directory
# =============================================================================


def get_config_dir() -> Path:
    """Get the wafer config directory (~/.wafer/).

    This is where global user configuration lives:
    - AGENTS.md or CLAUDE.md for global context
    - sessions/ for session persistence
    - Future: skills/, themes/, etc.
    """
    return Path.home() / ".wafer"


# =============================================================================
# Version
# =============================================================================


def get_version() -> str:
    """Get wafer-ai package version."""
    try:
        return version("wafer-ai")
    except PackageNotFoundError:
        return "dev"
