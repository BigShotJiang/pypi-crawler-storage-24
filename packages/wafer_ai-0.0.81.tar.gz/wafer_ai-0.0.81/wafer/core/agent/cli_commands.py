"""CLI command builder for Cursor agent.

Used by subprocess_agents for top-level eval and subagent execution.
"""
from __future__ import annotations

import shlex


_CURSOR_AGENT_ARGS: tuple[str, ...] = (
    "--yolo", "--sandbox", "disabled", "--output-format", "stream-json",
)

_RESOLVE_AGENT = (
    'AGENT_BIN=$(command -v agent 2>/dev/null '
    '|| echo "$HOME/.local/bin/agent"); '
    'exec "$AGENT_BIN"'
)


def build_cursor_cli_args(
    prompt: str,
    *,
    model: str | None = None,
) -> list[str]:
    """Build Cursor CLI command as bash -c wrapper.

    Cursor installs to ~/.local/bin/agent which isn't in PATH inside
    Modal containers or Cursor's own sandbox. Wrapping via bash -c
    resolves the path at execution time on the target.
    """
    tail: list[str] = [*_CURSOR_AGENT_ARGS, "-p", prompt]
    if model:
        tail.extend(["--model", model])
    inner = " ".join(shlex.quote(a) for a in tail)
    return ["bash", "-c", f'{_RESOLVE_AGENT} {inner}']
