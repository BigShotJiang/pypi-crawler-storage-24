"""Config fingerprinting for reproducibility.
Provides stable hashes of configuration to enable:
- Code version tracking (git sha + dirty status)
Usage:
    from .fingerprint import require_clean_git
"""
from __future__ import annotations

import subprocess
import sys


def git_info(*, paths: list[str] | None = None) -> tuple[str, bool]:
    """Get current git hash (8 chars) and dirty status.

    Args:
        paths: If provided, only check these paths for dirty status.
            This narrows the check so config changes don't block evals.
    Returns:
        ("unknown", False) if not in a git repo or git unavailable.
    """
    try:
        sha = (
            subprocess.check_output(
                ["git", "rev-parse", "HEAD"],
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            .decode()
            .strip()[:8]
        )
        porcelain_cmd = ["git", "status", "--porcelain"]
        if paths:
            porcelain_cmd.extend(["--"] + paths)
        dirty = bool(
            subprocess.check_output(
                porcelain_cmd,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            .decode()
            .strip()
        )
        return sha, dirty
    except (subprocess.SubprocessError, FileNotFoundError, OSError, UnicodeDecodeError):
        return "unknown", False


def require_clean_git(
    *,
    allow_dirty: bool = False,
    paths: list[str] | None = None,
) -> tuple[str, bool]:
    """Get git info, erroring if there are uncommitted changes.

    Args:
        allow_dirty: If True, warn instead of error on dirty state.
        paths: If provided, only check these paths for dirty status.
            Allows config changes while enforcing clean harness code.
    Returns:
        (git_sha, git_dirty) tuple
    Raises:
        RuntimeError: If git is dirty and allow_dirty=False
    """
    sha, dirty = git_info(paths=paths)
    if dirty and not allow_dirty:
        scope = f" in {paths}" if paths else ""
        raise RuntimeError(
            f"Uncommitted changes detected{scope}. Eval results may not be reproducible.\n"
            "Options:\n"
            "  1. Commit your changes: git commit -am 'wip'\n"
            "  2. Override with --allow-dirty flag\n"
            f"Git SHA: {sha} (dirty)"
        )
    if dirty and allow_dirty:
        print(
            "[warn] Running with uncommitted changes (git_dirty=True). Results may not be reproducible.",
            file=sys.stderr,
        )
    return sha, dirty


