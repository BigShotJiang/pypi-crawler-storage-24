"""Core authentication and credential management.

Handles storing/loading credentials from ~/.wafer/credentials.json,
token expiry checks, and automatic token refresh via Supabase.

Extracted from wafer.cli.auth so that core code can authenticate
without depending on the CLI package. CLI-interactive flows
(browser_login, device_code_login) remain in wafer.cli.auth.
"""
from __future__ import annotations

import base64
import binascii
import json
import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path

import httpx

from wafer.core.infra.api_config import get_supabase_anon_key, get_supabase_url

logger = logging.getLogger(__name__)

CREDENTIALS_DIR = Path.home() / ".wafer"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.json"

EXPIRY_MARGIN_SECONDS = 30


@dataclass
class Credentials:
    """Stored credentials."""
    access_token: str
    refresh_token: str | None = None
    email: str | None = None
    provider_token: str | None = None


def token_expired(token: str) -> bool:
    """Check if a token has expired.

    Service tokens (wfr_cloud_*) encode expiry as the second underscore-
    delimited field.  JWTs are decoded via the base64 payload.  Returns
    True if the token is expired or unparseable (fail closed).
    """
    if token.startswith("wfr_cloud_"):
        parts = token.split("_")
        try:
            exp = int(parts[3])
            remaining = exp - time.time()
            if remaining <= EXPIRY_MARGIN_SECONDS:
                logger.debug("service token expired (%.0fs past expiry)", -remaining)
                return True
            logger.debug("service token valid (%.0fs remaining)", remaining)
            return False
        except (IndexError, ValueError) as exc:
            logger.warning("could not parse service token expiry: %s", exc)
            return True
    try:
        payload_b64 = token.split(".")[1]
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
        exp = payload["exp"]
        remaining = exp - time.time()
        if remaining <= EXPIRY_MARGIN_SECONDS:
            logger.debug("token expired (%.0fs past expiry)", -remaining)
            return True
        logger.debug("token valid (%.0fs remaining)", remaining)
        return False
    except (binascii.Error, json.JSONDecodeError, KeyError, IndexError, TypeError) as exc:
        logger.warning("could not decode token exp claim: %s", exc)
        return True


def save_credentials(
    access_token: str,
    refresh_token: str | None = None,
    email: str | None = None,
    provider_token: str | None = None,
) -> None:
    """Save credentials to ~/.wafer/credentials.json.

    Merges with existing credentials so that fields not explicitly passed
    (e.g. provider_token during a token refresh) are preserved.
    """
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    existing: dict = {}
    if CREDENTIALS_FILE.exists():
        try:
            existing = json.loads(CREDENTIALS_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    existing["access_token"] = access_token
    if refresh_token is not None:
        existing["refresh_token"] = refresh_token
    if email is not None:
        existing["email"] = email
    if provider_token is not None:
        existing["provider_token"] = provider_token
    fd = os.open(str(CREDENTIALS_FILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(existing, f, indent=2)


def load_credentials() -> Credentials | None:
    """Load credentials from ~/.wafer/credentials.json."""
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        data = json.loads(CREDENTIALS_FILE.read_text())
        return Credentials(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            email=data.get("email"),
            provider_token=data.get("provider_token"),
        )
    except (json.JSONDecodeError, KeyError):
        return None


def clear_credentials() -> bool:
    """Remove credentials file."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
        return True
    return False


def refresh_access_token(refresh_token: str) -> tuple[str, str]:
    """Use refresh token to get a new access token from Supabase."""
    supabase_url = get_supabase_url()
    anon_key = get_supabase_anon_key()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(
            f"{supabase_url}/auth/v1/token?grant_type=refresh_token",
            json={"refresh_token": refresh_token},
            headers={
                "Content-Type": "application/json",
                "apikey": anon_key,
            },
        )
        if not response.is_success:
            raise RuntimeError(
                f"Token refresh failed ({response.status_code}). Run: wafer login"
            )
        data = response.json()
        return data["access_token"], data["refresh_token"]


def get_valid_token() -> str | None:
    """Get a valid access token, refreshing if necessary.

    Checks WAFER_AUTH_TOKEN env var first. If the env token is expired,
    falls through to the credentials file path so the refresh token can
    be used.
    """
    env_token = os.environ.get("WAFER_AUTH_TOKEN")
    if env_token and not token_expired(env_token):
        return env_token

    creds = load_credentials()
    if not creds:
        logger.debug("no credentials file found")
        return None
    if not token_expired(creds.access_token):
        return creds.access_token
    if not creds.refresh_token:
        logger.warning("token expired and no refresh token available")
        return None
    try:
        new_access, new_refresh = refresh_access_token(creds.refresh_token)
        save_credentials(new_access, new_refresh, creds.email)
        if env_token:
            os.environ["WAFER_AUTH_TOKEN"] = new_access
        logger.debug("token refreshed successfully")
        return new_access
    except (httpx.HTTPStatusError, httpx.RequestError, RuntimeError, KeyError, json.JSONDecodeError) as e:
        logger.warning("token refresh failed: %s", e)
        return None


def get_auth_headers() -> dict[str, str]:
    """Get Authorization headers with a valid token.

    Automatically refreshes expired tokens if a refresh token is available.
    Returns empty dict if not logged in or refresh fails.
    """
    token = get_valid_token()
    if token:
        return {"Authorization": f"Bearer {token}"}
    return {}
