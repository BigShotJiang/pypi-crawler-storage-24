"""Infrastructure utilities: auth, API config, SSH, remote execution, retry."""
