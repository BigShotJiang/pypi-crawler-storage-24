"""Backward-compat re-export. Canonical location: wafer.core.infra.remote_jobs."""
from wafer.core.infra.remote_jobs import *  # noqa: F401,F403
