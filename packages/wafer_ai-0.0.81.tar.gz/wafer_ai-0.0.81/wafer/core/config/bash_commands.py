"""Bash command allowlists and denylists for agent sandboxing."""
from __future__ import annotations

SAFE_BASH_COMMANDS: list[str] = [
    # File inspection
    "ls",
    "cat",
    "head",
    "tail",
    "less",
    "more",
    "file",
    "stat",
    "wc",
    # Search
    "find",
    "grep",
    "rg",
    "fd",
    # Navigation
    "pwd",
    "tree",
    "which",
    "whereis",
    # Comparison/processing
    "diff",
    "sort",
    "uniq",
    # Disk info
    "du",
    "df",
    # Git read-only
    "git status",
    "git log",
    "git diff",
    "git show",
    # Data processing
    "jq",
]

DANGEROUS_BASH_COMMANDS: list[str] = []
