"""Configuration loading for Wafer.

Handles config file loading, agent configuration, and bash command policies.
"""

from wafer.core.config.agent import AgentConfig, load_agent_config
from wafer.core.config.loader import load_config, merge_configs
from wafer.core.config.schema import WaferConfig

__all__ = [
    "AgentConfig",
    "WaferConfig",
    "load_agent_config",
    "load_config",
    "merge_configs",
]
