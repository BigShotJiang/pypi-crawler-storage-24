"""Analyzer for kernel trace output.
Parses profiler output to extract kernel information and identify the primary kernel.
"""
import json
import re
from dataclasses import dataclass
from typing import Any

from wafer.core.tools.dispatch_baseline.dtypes import KernelInfo, KernelTraceResult, OpSpec


@dataclass(frozen=True)
class ParsedTraceResult:
    """Parsed trace output with environment info for caching."""
    result: KernelTraceResult
    pytorch_version: str
    runtime_version: str
    gpu_arch: str


def parse_trace_output(output: str, op_spec: OpSpec, hardware: str) -> ParsedTraceResult:
    """Parse kernel trace script output and extract kernel information.
    Args:
        output: Raw output from the trace script (stdout)
        op_spec: The operation that was traced
        hardware: Target hardware name
    Returns:
        ParsedTraceResult with extracted kernel information and environment info
    """
    # Look for our JSON marker in the output
    json_match = re.search(r"KERNEL_TRACE_RESULT_JSON:(.+)$", output, re.MULTILINE)
    if not json_match:
        return ParsedTraceResult(
            result=KernelTraceResult(
                op_spec=op_spec,
                hardware=hardware,
                kernels=[],
                primary_kernel=None,
                raw_output=output,
                error="Could not find KERNEL_TRACE_RESULT_JSON marker in output",
            ),
            pytorch_version="unknown",
            runtime_version="unknown",
            gpu_arch="unknown",
        )
    try:
        result_json = json.loads(json_match.group(1))
    except json.JSONDecodeError as e:
        return ParsedTraceResult(
            result=KernelTraceResult(
                op_spec=op_spec,
                hardware=hardware,
                kernels=[],
                primary_kernel=None,
                raw_output=output,
                error=f"Failed to parse JSON: {e}",
            ),
            pytorch_version="unknown",
            runtime_version="unknown",
            gpu_arch="unknown",
        )
    env_info = result_json.get("environment", {})
    pytorch_version = env_info.get("pytorch_version", "unknown")
    runtime_version = env_info.get("runtime_version", "unknown")
    gpu_arch = env_info.get("gpu_arch", "unknown")
    kernels = []
    for k in result_json.get("kernels", []):
        kernel_info = _parse_kernel_dict(k)
        if kernel_info:
            kernels.append(kernel_info)

    primary_kernel = kernels[0] if kernels else None
    return ParsedTraceResult(
        result=KernelTraceResult(
            op_spec=op_spec,
            hardware=hardware,
            kernels=kernels,
            primary_kernel=primary_kernel,
            raw_output=output,
        ),
        pytorch_version=pytorch_version,
        runtime_version=runtime_version,
        gpu_arch=gpu_arch,
    )


def _parse_kernel_dict(kernel_dict: dict[str, Any]) -> KernelInfo | None:
    """Parse a kernel dictionary into KernelInfo."""
    name = kernel_dict.get("name", "")
    if not name:
        return None
    return KernelInfo(
        name=name,
        duration_us=kernel_dict.get("duration_us", 0.0),
    )
