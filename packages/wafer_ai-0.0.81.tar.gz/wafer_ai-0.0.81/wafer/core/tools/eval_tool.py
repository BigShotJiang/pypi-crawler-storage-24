"""Gated eval submission tool.

Tarballs a solution directory and POSTs it to a scoring endpoint.
Returns the full scoring result including per-workload details.
"""

import base64
import io
import json
import logging
import tarfile
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import httpx

from wafer.core.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)

logger = logging.getLogger(__name__)

EVAL_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="eval_task",
        description=(
            "Submit a solution directory for official evaluation. "
            "Tarballs the directory, sends it to the scoring endpoint, "
            "and returns JSON with scored metrics (correct, speedup, score) "
            "and per-workload details. "
            "Use in a loop: edit code -> eval_task(url, dir) -> read score -> repeat."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "url": {
                    "type": "string",
                    "description": "Evaluation endpoint URL with task_id and target query params",
                },
                "dir": {
                    "type": "string",
                    "description": "Path to solution directory to submit (default: '.')",
                },
            },
        ),
        required=["url"],
    ),
)

_ZERO_METRICS: list[dict] = [
    {"name": "correct", "value": 0.0, "weight": 1.0},
    {"name": "score", "value": 0.0, "weight": 1.0},
]


def _error_result(tool_call_id: str, msg: str) -> ToolResult:
    """Return an error ToolResult that always carries zero metrics for score emission."""
    return ToolResult(
        tool_call_id=tool_call_id,
        is_error=True,
        content=msg,
        error=msg,
        details={"metrics": _ZERO_METRICS},
    )


def _tarball_directory(dir_path: Path) -> bytes:
    """Create a gzipped tarball of a directory with files at the root."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for item in dir_path.rglob("*"):
            if item.is_file():
                arcname = str(item.relative_to(dir_path))
                tar.add(str(item), arcname=arcname)
    return buf.getvalue()


async def exec_eval(
    tool_call: ToolCall,
    working_dir: Path,
    auth_token: str | None = None,
) -> ToolResult:
    """Tarball solution dir, POST to scoring endpoint, return result."""
    assert tool_call.name == "eval_task"
    assert "url" in tool_call.args, "url is required"

    url = tool_call.args["url"]
    dir_rel = tool_call.args.get("dir", ".")

    dir_path = Path(dir_rel)
    if not dir_path.is_absolute():
        dir_path = working_dir / dir_path
    dir_path = dir_path.resolve()
    assert dir_path.is_dir(), f"Directory not found: {dir_path}"

    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    task_id = params.get("task_id", [None])[0]
    target_name = params.get("target", [None])[0]
    token = params.get("token", [None])[0]
    assert task_id, f"URL missing 'task_id' query param: {url}"
    assert target_name, f"URL missing 'target' query param: {url}"

    base_url = f"{parsed.scheme}://{parsed.netloc}"
    post_url = f"{base_url}{parsed.path}"
    if token:
        post_url += f"?token={token}"

    # Health-check: assert eval server is reachable before uploading tarball
    async with httpx.AsyncClient(timeout=httpx.Timeout(10.0)) as health_client:
        health_resp = await health_client.get(f"{base_url}/health")
        assert health_resp.status_code == 200, (
            f"Eval server health check failed at {base_url}/health "
            f"(HTTP {health_resp.status_code}): {health_resp.text[:500]}"
        )

    tarball_bytes = _tarball_directory(dir_path)
    solution_b64 = base64.b64encode(tarball_bytes).decode()

    headers = {}
    if auth_token:
        headers["Authorization"] = f"Bearer {auth_token}"

    logger.info("eval_task: task_id=%s target=%s url=%s", task_id, target_name, post_url)

    async with httpx.AsyncClient(timeout=httpx.Timeout(660.0)) as client:
        async with client.stream(
            "POST",
            post_url,
            json={
                "task_id": task_id,
                "target_name": target_name,
                "solution_tarball_b64": solution_b64,
            },
            headers=headers,
        ) as stream:
            if stream.status_code != 200:
                body = (await stream.aread()).decode()[:2000]
                error_msg = (
                    f"Eval scoring failed for {task_id} on {target_name} "
                    f"(HTTP {stream.status_code}): {body}"
                )
                logger.error(error_msg)
                return _error_result(tool_call.id, error_msg)

            last_line = ""
            async for line in stream.aiter_lines():
                stripped = line.strip()
                if stripped:
                    last_line = stripped

    assert last_line, f"Eval server returned no result for {task_id}"
    result = json.loads(last_line)

    if "detail" in result and "metrics" not in result:
        return _error_result(tool_call.id, f"Eval error: {result['detail']}")

    metrics = result["metrics"]
    assert isinstance(metrics, list), f"Expected metrics list, got {type(metrics)}"
    details = {m["name"]: m["value"] for m in metrics}
    details["metrics"] = metrics

    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=json.dumps(result, indent=2),
        details=details,
    )
