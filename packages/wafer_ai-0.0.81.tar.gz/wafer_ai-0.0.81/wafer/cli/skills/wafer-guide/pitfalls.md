# Common Pitfalls

- **Old eval syntax**: Use `wafer tool eval --task gpumode` not `wafer evaluate gpumode --impl ...` (unified eval, no old flags)
- **Eval with target flag**: Don't use `wafer tool eval --target <name>`. Compose with sandbox run: `wafer sandbox run --target <target> -- wafer tool eval --task <name>`
- **make-template removed**: `wafer tool eval make-template` no longer exists
- **Wrong remote path**: Synced files land at `/workspace/`, not `/workspace/<name>/`
- **Wrong function names**: GPUMode format requires `custom_kernel()`, `ref_kernel()`, and `generate_input()` — not `kernel()` / `reference()`
- **Missing generate_input**: The reference file must export both `ref_kernel` AND `generate_input`
- **Target init**: Use `wafer target init ssh` to register SSH hosts (not `wafer config targets init ssh`)
- **Sandbox is SSH-only**: Use `wafer sandbox run --target <name> --` for SSH targets only. For workspaces, use `wafer target sync` and `wafer target ssh` (interactive)
