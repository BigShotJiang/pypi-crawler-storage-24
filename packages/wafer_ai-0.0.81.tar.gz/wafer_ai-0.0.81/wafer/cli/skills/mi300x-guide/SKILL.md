---
name: mi300x-guide
description: AMD MI300X (CDNA3 gfx942) optimization guide. Sandbox commands, HIP vs CUDA differences, profiling.
---

# AMD MI300X (CDNA3) — HIP Optimization Guide

## Hardware Specs

- Architecture: CDNA3 (gfx942)
- Compute Units: 304
- Memory: 192GB HBM3, ~5.3 TB/s bandwidth
- Target name: `mi300x`

## Sandbox Commands

```bash
# Score your solution: run bash("python submit_eval.py") — see the Eval Submission section in your instruction.
# Do NOT run task.py directly — it is not in your workspace during evals.

# Run any command with local file sync
wafer sandbox run --target mi300x --sync . -- <command>

# Profile with rocprof-compute (sync first so binary is on remote)
wafer sandbox run --target mi300x --sync . -- rocprof-compute profile <binary>

# Check GPU status (no sync needed)
wafer sandbox run --target mi300x -- rocm-smi
```

## Building HIP Extensions with torch.utils.cpp_extension.load

Use this proven working pattern for compiling HIP kernels with PyTorch on MI300X:

```python
import os
from filelock import FileLock
from torch.utils.cpp_extension import load

# Required env vars — MUST be set before calling load()
os.environ.update({
    "CXX": "/opt/rocm-7.0.0/bin/hipcc",
    "PYTORCH_ROCM_ARCH": "gfx942",
})

HIP_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
#include <ATen/hip/HIPContext.h>

// Your HIP kernel here
__global__ void my_kernel(...) { ... }

// Wrapper function
torch::Tensor my_op(torch::Tensor input) {
    // launch kernel
    hipStream_t stream = at::hip::getCurrentHIPStream();
    hipLaunchKernelGGL(my_kernel, grid, block, 0, stream,
        input.data_ptr<float>(), ...
    );
    return output;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("my_op", &my_op, "My HIP operation");
}
"""

# Write source to file (required — do NOT use load_inline on MI300X)
with open("my_kernel.cu", "w") as f:
    f.write(HIP_SRC)

# Build with FileLock to prevent race conditions
with FileLock("build.lock"):
    os.makedirs("torch-build", exist_ok=True)
    module = load(
        name="my_kernel",
        sources=["my_kernel.cu"],
        build_directory="torch-build",
        verbose=False,
        extra_cuda_cflags=["--offload-arch=gfx942", "-std=c++20", "-O2"],
        extra_cflags=["-O2"],
    )

# Use the compiled module
result = module.my_op(input_tensor)
```

**Critical notes:**

- **Use `load()` not `load_inline()`** — file-based compilation is more reliable on ROCm
- **CXX must be clang++** — gcc will not work for HIP compilation
- **PYTORCH_ROCM_ARCH=gfx942** — must match the MI300X architecture
- **--offload-arch=gfx942** in extra_cuda_cflags — required for correct GPU targeting
- **FileLock** prevents race conditions when multiple processes compile simultaneously

## HIP-Specific Headers

Available on MI300X:

| Header | Purpose |
| ------ | ------- |
| `hip/hip_runtime.h` | Core HIP runtime |
| `hip/hip_fp16.h` | Half precision support |
| `hip/hip_cooperative_groups.h` | Cooperative groups |
| `hip/hip_ext.h` | Extensions (e.g., hipExtMallocWithFlags) |
| `rocwmma/rocwmma.hpp` | Wavefront matrix multiply-accumulate (matrix cores) |
| `torch/extension.h` | PyTorch/pybind11 bindings |

## Key HIP vs CUDA Differences

- **Wavefront size: 64** (not 32) — adjust all warp-level code
- **Warp shuffle**: `__shfl()` works but takes 64 lanes
- **Atomics**: `__hip_atomic_*` with explicit memory scope (`__HIP_MEMORY_SCOPE_AGENT`, `__HIP_MEMORY_SCOPE_SYSTEM`)
- **Built-in intrinsics**: `__builtin_amdgcn_*` (e.g., `__builtin_amdgcn_readfirstlane`, `__builtin_amdgcn_wave_barrier`)
- **Compiler**: Use `hipcc` instead of `nvcc` for standalone compilation
- **Diagnostics**: Use `rocm-smi` instead of `nvidia-smi`
- **Profiling**: Use `rocprof-compute` for profiling
- **Kernel syntax**: Nearly identical to CUDA (`__global__`, `<<<blocks, threads>>>`)

## Optimization Strategy Tiers

Use these in order. Assign distinct seeds — no two optimizers start from the same strategy.

### Tier 1 — Start here

**1. Non-temporal streaming** (best for bandwidth-bound kernels)
Use `__builtin_nontemporal_load` / `__builtin_nontemporal_store` on scalar `float`. This emits the `sc0 sc1` GCN memory modifiers that bypass L1/L2 caches entirely. For streaming workloads with no reuse this is the single most effective technique on MI300X.
- Process 4 floats/thread using pointer arithmetic: `float* p = A + i*4; __builtin_nontemporal_store(__builtin_nontemporal_load(p+0) + ..., C+i*4);`
- Use `float` not `float4` — `__builtin_nontemporal_*` does not accept HIP vector types
- Start with block=512; sweep 256/384/512 after a working version exists

**2. Vectorized float4 loads** (reliable, no cache bypass)
Cast pointers to `float4*`, one element per thread, `__restrict__` + `const` on both inputs. No nontemporal.

**3. MFMA matrix cores** (matrix workloads only)
`__builtin_amdgcn_mfma_f32_32x32x8f16` for fp16 GEMM. Use rocWMMA (`rocwmma/rocwmma.hpp`) for a higher-level API.

### Tier 2 — After Tier 1 saturates

**4. LDS tiling**
`__shared__` with bank-conflict-free layout (pad +1 column for 32-bank LDS), double-buffer with `__syncthreads`.

**5. Wavefront occupancy hints**
`__attribute__((amdgpu_flat_work_group_size(N, N)))` — controls min/max wavefronts per CU.
`__launch_bounds__(N, M)` — limits register pressure.

**6. Thread coarsening + full grid**
2–4 elements/thread with a full grid (no grid-stride reduction). Sweep element counts once a working version exists.

### Tier 3 — Last resort

**7. Block-size sweep**
Embed multiple block sizes in one compilation pass and measure all at once.

## Dead-End Warnings

These approaches fail reliably on MI300X. Abandon after **one** fix attempt if the same error class recurs.

| Approach | Error you'll see | What to use instead |
|----------|-----------------|---------------------|
| GCN inline asm (`flat_store_dwordx4`, `global_load_dwordx4`, `v[n:n+1]` address pairs) | `"invalid operand for instruction"` or `"Don't know how to handle indirect register inputs"` | `__builtin_nontemporal_load/store` |
| `__builtin_nontemporal_store` on `float4` or `HIP_vector_type` | `"address argument to nontemporal builtin must be a pointer to integer, float, pointer, or a vector"` | Use scalar `float`, not `float4` |
| `reqd_work_group_size` attribute | `"attribute can only be applied to an OpenCL kernel"` | `__attribute__((amdgpu_flat_work_group_size(N,N)))` |
| `load_inline()` for PyTorch HIP extensions | Silent build failure or wrong arch | Use file-based `load()` — see Building HIP Extensions section |

## Key HIP vs CUDA Differences

- **Wavefront size: 64** (not 32) — adjust all warp-level tiling and reduction code
- **Warp shuffle**: `__shfl()` operates over 64 lanes
- **Atomics**: `__hip_atomic_*` with explicit memory scope (`__HIP_MEMORY_SCOPE_AGENT`)
- **Built-in intrinsics**: `__builtin_amdgcn_*` (e.g., `__builtin_amdgcn_readfirstlane`)
- **Profiling**: `rocprof-compute` (not Nsight Compute)
- **Diagnostics**: `rocm-smi` (not nvidia-smi)

## Kernel Format (KernelBench)

The reference file contains a PyTorch `Model` class. You must write a `ModelNew` class that:

1. Has the same `__init__` signature as `Model`
2. Has a `forward()` method with the same input/output signature
3. Uses custom HIP kernels (with `__global__` definitions), **NOT** PyTorch ops

**Use the `load()` pattern above** — do **NOT** use `load_inline()`; file-based compilation is more reliable on ROCm/MI300X.

The reference file also provides:

- `get_inputs()` — generates test inputs for forward()
- `get_init_inputs()` — generates constructor arguments

Score your solution by running `bash("python submit_eval.py")` when provided in your instruction.

## Scoring

- Score = geometric mean speedup across all workloads (if all pass correctness)
- If any workload fails correctness: score = pass_rate * 0.1
