---
name: mi355x-guide
description: AMD MI355X (CDNA4 gfx950) optimization guide. Sandbox environment, package installation, profiling, HIP differences.
---

# AMD MI355X (CDNA4) — HIP Optimization Guide

## Hardware Specs

- Architecture: CDNA4 (gfx950)
- Compute Units: 304
- Memory: 288GB HBM3e per GPU, ~8 GPUs per node
- Target name: `mi355x`

## Sandbox Environment

The MI355X sandbox runs ROCm 7.1 with PyTorch 2.10.0+rocm7.1 pre-installed.

**Pre-installed and available:**

| Package | Notes |
|---------|-------|
| PyTorch 2.10.0+rocm7.1 | DO NOT reinstall or upgrade |
| hipcc / ROCm toolchain | At `/opt/rocm/` |
| rocprof-compute | For profiling |
| amdsmi | At `/usr/local/lib/python3.12/dist-packages/amdsmi` — add to sys.path if needed |
| python3, pip | Use `python3 -m pip install` for packages. Use `--no-deps` when torch is a dependency. |

**Pre-installed software (paths vary by sandbox — always probe first):**

| What | How to find |
|------|-------------|
| vllm (ROCm) | `python3 -c "import vllm; print(vllm.__file__)"` or `find /home /opt -name "vllm" -maxdepth 4 -type d 2>/dev/null` |
| aiter | `python3 -c "import aiter; print(aiter.__file__)"` or `find /home /opt -name "aiter" -maxdepth 4 -type d 2>/dev/null` |
| ROCm toolchain | `ls /opt/rocm*/bin/hipcc` |
| amdsmi | `python3 -c "import amdsmi; print(amdsmi.__file__)"` or `find /usr/local -name "amdsmi" -type d 2>/dev/null` |

If a package is importable but not on `sys.path`, add it: `python3 -c "import sys; sys.path.insert(0, '/path'); import <pkg>"`.

**Check what's available before installing anything:**
```bash
python3 -c "import torch; print(torch.__version__, torch.version.hip)"
python3 -c "import <pkg>; print(<pkg>.__version__)"
find /home /opt /usr -name "<pkg>" -maxdepth 5 -type d 2>/dev/null
```

## Package Installation

**vllm on ROCm:**
The PyPI `vllm` package is CUDA-only — never `pip install vllm` without `--no-deps`.
```bash
# 1. Check if pre-installed vllm works on this GPU:
python3 -c "
import torch, vllm
x = torch.randn(4, 4, device='cuda')
print('vllm', vllm.__version__, '- torch OK on', torch.cuda.get_device_name(0))
"

# 2. If it fails with 'HIP error: invalid device function', the pre-installed
#    vllm was compiled for a different arch (e.g. gfx942). Rebuild from source:
git clone https://github.com/vllm-project/vllm.git
cd vllm
export PYTORCH_ROCM_ARCH=gfx950
python3 -m pip install -e . --no-deps
python3 -m pip install transformers tokenizers sentencepiece uvloop msgspec

# The local clone shadows the broken pre-installed version — this is intentional.
# Verify: python3 -c "import vllm; print(vllm.__file__)"  # should point to ./vllm/
```

**aiter (AMD's operator library):**
```bash
# 1. Check if pre-installed aiter works:
python3 -c "import aiter; print(aiter.__file__)"

# 2. If it segfaults, points to a dead path, or has stale .so files — rebuild:
export LD_LIBRARY_PATH=/opt/rocm/lib:$(python3 -c "import torch; print(torch.__path__[0])")/lib:$LD_LIBRARY_PATH
export PYTORCH_ROCM_ARCH=gfx950
git clone https://github.com/ROCm/aiter.git
cd aiter
python3 -m pip install -e . --no-deps
python3 -m pip install -r requirements.txt

# Run MoE GEMM tests:
python3 op_tests/test_moe.py -t g1u1_fp8quant -m 128 256 512
python3 op_tests/test_moe_2stage.py
```

If the pre-installed aiter has stale `.so` files from a prior session, delete them before rebuilding:
```bash
find $(python3 -c "import aiter; import os; print(os.path.dirname(aiter.__file__))") -name "*.so" -delete
```

**General rules:**
- Use `python3 -m pip install` (not bare `pip install`).
- NEVER `pip install torch` or `pip install vllm` without `--no-deps` — it will replace ROCm torch with CUDA torch.
- Always check pre-installed locations first (see Sandbox Environment section).
- If pip wants to upgrade/downgrade torch, abort and use `--no-deps`.

## LD_LIBRARY_PATH Setup

ROCm and PyTorch each bundle their own `libamdhip64.so`. If they conflict, JIT modules segfault. Always set this before running aiter or any JIT-compiled ROCm code:
```bash
export LD_LIBRARY_PATH=/opt/rocm/lib:$(python3 -c "import torch; print(torch.__path__[0])")/lib:$LD_LIBRARY_PATH
```
Put `/opt/rocm/lib` **first** so `libamdhip64.so.6` resolves from the system ROCm (which has a compat symlink to .so.7), not from PyTorch's bundled copy.

## Stale JIT Modules

Sandboxes may have `.so` files compiled by prior sessions against a different PyTorch or ROCm version. Symptoms: segfault on import, `TypeMeta` errors, symbol mismatches.

Fix: delete all stale `.so` files and let them rebuild:
```bash
find /path/to/aiter/aiter/jit -name "*.so" -delete
find /path/to/aiter/aiter/jit/build -type d -name "build" -exec rm -rf {} + 2>/dev/null
```

## Profiling

```bash
# ROCm profiling
rocprof-compute profile <binary_or_script>

# PyTorch profiler (works on ROCm)
python3 -c "
import torch
with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as prof:
    # your code here
    pass
print(prof.key_averages().table(sort_by='cuda_time_total'))
prof.export_chrome_trace('trace.json')
"

# System info
rocm-smi --showproductname
rocm-smi --showmeminfo vram
```

## Building HIP Extensions with torch.utils.cpp_extension.load

```python
import os
from filelock import FileLock
from torch.utils.cpp_extension import load

os.environ.update({
    "CXX": "/opt/rocm/bin/hipcc",
    "PYTORCH_ROCM_ARCH": "gfx950",
})

# Write source to file (required — do NOT use load_inline on ROCm)
with open("my_kernel.cu", "w") as f:
    f.write(HIP_SRC)

with FileLock("build.lock"):
    os.makedirs("torch-build", exist_ok=True)
    module = load(
        name="my_kernel",
        sources=["my_kernel.cu"],
        build_directory="torch-build",
        verbose=False,
        extra_cuda_cflags=["--offload-arch=gfx950", "-std=c++20", "-O2"],
        extra_cflags=["-O2"],
    )
```

**Critical notes:**
- **Use `load()` not `load_inline()`** — file-based compilation is more reliable on ROCm
- **PYTORCH_ROCM_ARCH=gfx950** — must match MI355X architecture (not gfx942 which is MI300X)
- **--offload-arch=gfx950** in extra_cuda_cflags — required for correct GPU targeting

## HIP vs CUDA Differences

- **Wavefront size: 64** (not 32) — adjust all warp-level code
- **Warp shuffle**: `__shfl()` operates over 64 lanes
- **Atomics**: `__hip_atomic_*` with explicit memory scope (`__HIP_MEMORY_SCOPE_AGENT`)
- **Built-in intrinsics**: `__builtin_amdgcn_*` (e.g., `__builtin_amdgcn_readfirstlane`)
- **Compiler**: `hipcc` instead of `nvcc`
- **Diagnostics**: `rocm-smi` instead of `nvidia-smi`
- **Profiling**: `rocprof-compute` instead of ncu/nsys

## Optimization Strategy Tiers

### Tier 1 — Start here

**1. Non-temporal streaming** (bandwidth-bound kernels)
`__builtin_nontemporal_load` / `__builtin_nontemporal_store` on scalar `float`. Use `float` not `float4`.

**2. Vectorized float4 loads**
Cast pointers to `float4*`, `__restrict__` + `const` on both inputs.

**3. MFMA matrix cores** (matrix workloads)
`__builtin_amdgcn_mfma_f32_32x32x8f16` for fp16 GEMM. Use rocWMMA for higher-level API.

### Tier 2 — After Tier 1 saturates

**4. LDS tiling** — `__shared__` with bank-conflict-free layout (pad +1 for 32-bank LDS).

**5. Wavefront occupancy hints** — `__attribute__((amdgpu_flat_work_group_size(N, N)))`.

### Tier 3 — Last resort

**6. Block-size sweep** — multiple block sizes in one compilation pass.

## Architecture Compatibility (gfx950)

MI355X is gfx950, which is very new. Many libraries don't have native support yet. When you encounter architecture-related errors:

**HSA_OVERRIDE_GFX_VERSION:**
This env var tells ROCm to pretend the GPU is a different architecture. Useful when a library has gfx942 (MI300X) or gfx1100 (RX 7900) support but not gfx950:

| Override value | Pretends to be | When to try |
|---------------|---------------|-------------|
| `11.0.0` | gfx1100 (RDNA3) | vllm, general PyTorch inference |
| `9.4.2` | gfx942 (MI300X/CDNA3) | aiter, libraries with CDNA3 JIT kernels |

```bash
HSA_OVERRIDE_GFX_VERSION=11.0.0 python3 my_script.py
HSA_OVERRIDE_GFX_VERSION=9.4.2 python3 my_script.py
```

**Detecting and fixing architecture mismatch:**
If a library fails with `HIP error: invalid device function`, check what it was compiled for:
```bash
strings /path/to/library/_C.abi3.so | grep -i "gfx9" | sort -u
```
If it shows `gfx942` or `gfx94` but not `gfx950`, the binary was compiled for the wrong arch.

**Fix: clone and rebuild from source for gfx950.** The sandbox is your machine — rebuild what's broken:
```bash
export PYTORCH_ROCM_ARCH=gfx950
export LD_LIBRARY_PATH=/opt/rocm/lib:$(python3 -c "import torch; print(torch.__path__[0])")/lib:$LD_LIBRARY_PATH
git clone <repo_url>
cd <repo>
python3 -m pip install -e . --no-deps
```
The local clone will shadow the broken pre-installed version. This is intentional and correct.

**When JIT `.so` files cause problems:**
If a library JIT-compiles kernels for a specific arch, delete the stale `.so` files and let them rebuild:
```bash
find /path/to/lib -name "*.so" -delete
find /path/to/lib -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null
```

## Dead-End Warnings

| Approach | Error | Use instead |
|----------|-------|-------------|
| GCN inline asm | `"invalid operand for instruction"` | `__builtin_nontemporal_load/store` |
| `__builtin_nontemporal_store` on `float4` | `"address argument to nontemporal builtin..."` | Scalar `float` |
| `load_inline()` | Silent build failure or wrong arch | File-based `load()` |
| `pip install vllm` (no --no-deps) | Replaces ROCm torch with CUDA torch | See Package Installation section |
