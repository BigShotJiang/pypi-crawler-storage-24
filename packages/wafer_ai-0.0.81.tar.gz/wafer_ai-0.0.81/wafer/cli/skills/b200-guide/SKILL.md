---
name: b200-guide
description: NVIDIA B200 (Blackwell sm_100) optimization guide. Sandbox commands, profiling, kernel format.
---

# NVIDIA B200 (Blackwell) — CUDA Optimization Guide

## Hardware Specs

- Architecture: Blackwell (sm_100)
- SMs: 192
- Shared memory: 192KB per SM
- Memory: HBM3e, ~8 TB/s bandwidth
- Target name: `b200`

## Sandbox Commands

```bash
# Score your solution: run bash("python submit_eval.py") — see the Eval Submission section in your instruction.
# Do NOT run task.py directly — it is not in your workspace during evals.

# Run any command with local file sync
wafer sandbox run --target b200 --sync . -- <command>

# Profile with NVIDIA Nsight Compute (sync first so binary is on remote)
wafer sandbox run --target b200 --sync . -- ncu --set full ./binary

# Profile with NVIDIA Nsight Systems
wafer sandbox run --target b200 --sync . -- nsys profile ./binary

# Check GPU status (no sync needed)
wafer sandbox run --target b200 -- nvidia-smi
```

## Kernel Format (KernelBench)

The reference file contains a PyTorch `Model` class. You must write a `ModelNew` class that:
1. Has the same `__init__` signature as `Model`
2. Has a `forward()` method with the same input/output signature
3. Uses custom CUDA kernels (with `__global__` definitions and `torch.utils.cpp_extension.load_inline`), NOT PyTorch ops

The reference file also provides:
- `get_inputs()` — generates test inputs for forward()
- `get_init_inputs()` — generates constructor arguments

## Optimization Strategy Tiers

Use these in order. Assign distinct seeds — no two optimizers start from the same strategy.

### Tier 1 — Start here

**1. Warpgroup MMA** (matrix workloads — GEMM, attention, etc.)
`wmma::fragment` + `wmma::mma_sync` for sm_90; `cute::SM100_MMA_F32F16F16` for Blackwell (sm_100).
Build: `nvcc -O3 -std=c++17 --generate-code=arch=compute_100,code=sm_100`. Do NOT substitute sm_87 or sm_90.

**2. TMA bulk async copy**
`cuda::memcpy_async` with `__pipeline_commit` / `__pipeline_wait_prior` for async smem loads. Replaces `__ldg` + shared memory for Blackwell. Pair with double-buffering: one tile loading while another computes.

**3. Vectorized float4 loads**
Cast to `float4*` with `__ldg` for read-only inputs. Requires 128-byte aligned base pointers. Combine with `__restrict__` for alias disambiguation.

### Tier 2 — After Tier 1 saturates

**4. Persistent kernel + stream-K**
Grid-stride loop with atomic work counters for dynamic load balancing across SMs.

**5. Warp shuffle reductions**
`__shfl_xor_sync(0xffffffff, val, delta)` tree reductions. Eliminate shared memory for reduction-only patterns.

**6. 2D register tiling**
Each thread owns an NxM output sub-tile (e.g., 8×8). Reduces indexing overhead and maximizes arithmetic intensity per register.

### Tier 3 — Last resort

**7. PTX streaming stores**
`ld.global.cs` (streaming load, L2 bypass) and `st.global.cs` (streaming store) via inline PTX. Useful for bandwidth-bound kernels with no reuse.

**8. L2 residency hints**
`__builtin_assume_aligned` for alignment guarantees, `__restrict__` for alias elimination. Combine with `-Xptxas -O3` for more aggressive PTXAS optimization.

## Profiling Permissions

**ncu (Nsight Compute)** requires elevated permissions for GPU hardware counters. On B200 sandboxes:
- `ncu` may fail with `ERR_NVGPUCTRPERM` if hardware counters are restricted.
- Try `sudo ncu --set full ./binary` to get full hardware counter access.
- If `sudo` is not available or ncu still fails, fall back to nsys or torch.profiler.

**nsys (Nsight Systems)** works without elevated permissions. It provides:
- Kernel durations and launch parameters
- Memory transfer timing and throughput
- CUDA API call overhead
- GPU utilization timeline
- Does NOT provide hardware counter metrics (SM throughput, tensor pipe utilization)

**torch.profiler** works everywhere and provides kernel timing, memory usage, and CUDA event traces:
```python
import torch
with torch.profiler.profile(
    activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA],
    with_stack=True,
) as prof:
    # your code here
    pass
prof.export_chrome_trace("trace.json")
print(prof.key_averages().table(sort_by="cuda_time_total"))
```

Always save profiler output to files (.ncu-rep, .nsys-rep, trace.json) so they can be pulled back with `pull_session_files`.

## Build Notes

- sm_100 requires `--generate-code=arch=compute_100,code=sm_100` — no substitutions
- FP8 requires sm_90a: `--generate-code=arch=compute_90a,code=sm_90a`
- Add `-lcublas` only if the benchmark explicitly links it
- `torch.utils.cpp_extension.load_inline` works on NVIDIA (unlike MI300X/MI355X)

## Scoring

- Score = geometric mean speedup across all workloads (if all pass correctness)
- If any workload fails correctness: score = pass_rate * 0.1
- All workloads must pass accuracy checks for full score
