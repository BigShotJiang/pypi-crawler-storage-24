"""CLI authentication and credential management.
Handles storing/loading credentials from ~/.wafer/credentials.json
and verifying tokens against the wafer-api.
Supports automatic token refresh using Supabase refresh tokens.
Token validity is checked locally via JWT exp claim — no network
round-trip on the hot path.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from wafer.core.infra.auth import (
    CREDENTIALS_DIR,
    CREDENTIALS_FILE,
    Credentials,
    EXPIRY_MARGIN_SECONDS,
    clear_credentials,
    get_auth_headers,
    get_valid_token,
    load_credentials,
    refresh_access_token,
    save_credentials,
    token_expired,
)


__all__ = [
    "Credentials",
    "EXPIRY_MARGIN_SECONDS",
    "UserInfo",
    "clear_credentials",
    "get_auth_headers",
    "get_valid_token",
    "load_credentials",
    "refresh_access_token",
    "save_credentials",
    "token_expired",
    "verify_token",
    "browser_login",
    "device_code_login",
]

# Safe symbols for terminal output
CHECK = "[ok]"
CROSS = "[fail]"


@dataclass
class UserInfo:
    """User info from token verification."""
    user_id: str
    email: str | None


def verify_token(token: str) -> UserInfo:
    """Verify token with wafer-api and return user info.
    Raises:
        httpx.HTTPStatusError: If token is invalid (401) or other HTTP error
        httpx.RequestError: If API is unreachable
    """
    import httpx

    from wafer.core.infra.api_config import get_api_url

    api_url = get_api_url()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(
            f"{api_url}/v1/auth/verify",
            json={"token": token},
        )
        if not response.is_success:
            if response.status_code == 401:
                raise RuntimeError("Token is invalid or expired. Run: wafer login")
            raise RuntimeError(f"Token verification failed ({response.status_code})")
        data = response.json()
        return UserInfo(
            user_id=data["user_id"],
            email=data.get("email"),
        )


def _find_free_port() -> int:
    """Find a free port for the callback server."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def _get_oauth_handler_class():
    """Build OAuthCallbackHandler lazily to avoid importing http.server at module level."""
    from http.server import BaseHTTPRequestHandler
    from urllib.parse import parse_qs, urlparse

    class OAuthCallbackHandler(BaseHTTPRequestHandler):
        """HTTP handler that catches the OAuth callback with access token."""
        access_token: str | None = None
        refresh_token: str | None = None
        provider_token: str | None = None
        error: str | None = None

        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass

        def do_GET(self) -> None:
            """Handle GET request - catch the callback or serve the HTML page."""
            parsed = urlparse(self.path)
            if parsed.path == "/callback":
                html = """<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Wafer CLI Login</title></head>
<body>
<h2>Completing login...</h2>
<script>
const hash = window.location.hash.substring(1);
const params = new URLSearchParams(hash);
const accessToken = params.get('access_token');
const refreshToken = params.get('refresh_token');
const providerToken = params.get('provider_token');
const error = params.get('error_description') || params.get('error');
if (accessToken) {
    let url = '/token?access_token=' + encodeURIComponent(accessToken);
    if (refreshToken) url += '&refresh_token=' + encodeURIComponent(refreshToken);
    if (providerToken) url += '&provider_token=' + encodeURIComponent(providerToken);
    fetch(url).then(() => {
        document.body.innerHTML = '<h2>Login successful!</h2><p>You can close this window.</p>';
    });
} else if (error) {
    fetch('/token?error=' + encodeURIComponent(error));
    document.body.innerHTML = '<h2>Login failed</h2><p>' + error + '</p>';
} else {
    document.body.innerHTML = '<h2>No token received</h2>';
}
</script>
</body>
</html>"""
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html.encode())
            elif parsed.path == "/token":
                params = parse_qs(parsed.query)
                if "access_token" in params:
                    OAuthCallbackHandler.access_token = params["access_token"][0]
                    if "refresh_token" in params:
                        OAuthCallbackHandler.refresh_token = params["refresh_token"][0]
                    if "provider_token" in params:
                        OAuthCallbackHandler.provider_token = params["provider_token"][0]
                elif "error" in params:
                    OAuthCallbackHandler.error = params["error"][0]
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(b"OK")
            else:
                self.send_response(404)
                self.end_headers()

    return OAuthCallbackHandler


def browser_login(timeout: int = 120, port: int | None = None) -> tuple[str, str | None, str | None]:
    """Open browser for GitHub OAuth and return tokens.
    Starts a local HTTP server, opens browser to Supabase OAuth,
    and waits for the callback with the tokens.
    Args:
        timeout: Seconds to wait for callback (default 120)
        port: Port for callback server. If None, finds a free port (default None)
    Returns:
        Tuple of (access_token, refresh_token, provider_token).
        refresh_token and provider_token may be None.
    Raises:
        TimeoutError: If no callback received within timeout
        RuntimeError: If OAuth flow failed
    """
    import webbrowser
    from http.server import HTTPServer

    from wafer.core.infra.api_config import get_supabase_url

    if port is None:
        port = _find_free_port()
    redirect_uri = f"http://localhost:{port}/callback"
    supabase_url = get_supabase_url()
    auth_url = f"{supabase_url}/auth/v1/authorize?provider=github&redirect_to={redirect_uri}"
    OAuthCallbackHandler = _get_oauth_handler_class()
    OAuthCallbackHandler.access_token = None
    OAuthCallbackHandler.refresh_token = None
    OAuthCallbackHandler.provider_token = None
    OAuthCallbackHandler.error = None
    server = HTTPServer(("localhost", port), OAuthCallbackHandler)
    server.timeout = 1
    print("Opening browser for GitHub authentication...")
    print(f"If browser doesn't open, visit: {auth_url}")
    webbrowser.open(auth_url)
    start = time.time()
    print("Waiting for authentication...", end="", flush=True)
    while time.time() - start < timeout:
        server.handle_request()
        if OAuthCallbackHandler.access_token:
            print(f" {CHECK}")
            server.server_close()
            return OAuthCallbackHandler.access_token, OAuthCallbackHandler.refresh_token, OAuthCallbackHandler.provider_token
        if OAuthCallbackHandler.error:
            print(f" {CROSS}")
            server.server_close()
            raise RuntimeError(f"OAuth failed: {OAuthCallbackHandler.error}")
    server.server_close()
    raise TimeoutError(f"No response within {timeout} seconds")


def device_code_login(timeout: int = 600) -> tuple[str, str | None, str | None]:
    """Authenticate using state-based flow (no browser/port forwarding needed).
    This is the SSH-friendly auth flow similar to GitHub CLI:
    1. Request a state token from the API
    2. Display the auth URL with state parameter
    3. User visits URL on any device and signs in normally
    4. Poll API until user completes authentication
    Args:
        timeout: Seconds to wait for authentication (default 600 = 10 minutes)
    Returns:
        Tuple of (access_token, refresh_token, provider_token).
        refresh_token and provider_token may be None.
    Raises:
        TimeoutError: If user doesn't authenticate within timeout
        RuntimeError: If auth flow failed
    """
    import webbrowser

    import httpx

    from wafer.core.infra.api_config import get_api_url

    api_url = get_api_url()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(f"{api_url}/v1/auth/cli-auth/start", json={})
        if not response.is_success:
            raise RuntimeError(
                f"Failed to start auth flow ({response.status_code}). Is the API reachable?"
            )
        data = response.json()
    state = data["state"]
    auth_url = data["auth_url"]
    expires_in = data["expires_in"]
    print("\n" + "=" * 60)
    print("  WAFER CLI - Authentication")
    print("=" * 60)
    print(f"\n  Visit: {auth_url}")
    print("\n  Sign in with GitHub to complete authentication")
    print("\n" + "=" * 60 + "\n")
    webbrowser.open(auth_url)
    start = time.time()
    poll_interval = 5
    last_poll = 0.0
    print("Waiting for authentication", end="", flush=True)
    while time.time() - start < min(timeout, expires_in):
        if time.time() - last_poll >= poll_interval:
            print(".", end="", flush=True)
            with httpx.Client(timeout=10.0) as client:
                try:
                    response = client.post(
                        f"{api_url}/v1/auth/cli-auth/token", json={"state": state}
                    )
                    if response.status_code == 200:
                        data = response.json()
                        print(f" {CHECK}\n")
                        return data["access_token"], data.get("refresh_token"), data.get("provider_token")
                    if response.status_code == 428:
                        last_poll = time.time()
                        time.sleep(1)
                        continue
                    print(f" {CROSS}\n")
                    raise RuntimeError(
                        f"CLI auth flow failed: {response.status_code} {response.text}"
                    )
                except httpx.RequestError:
                    print("!", end="", flush=True)
                    last_poll = time.time()
                    time.sleep(1)
                    continue
        time.sleep(0.5)
    print(f" {CROSS}\n")
    raise TimeoutError(f"Authentication not completed within {expires_in} seconds")
