from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import typer

megakernel_app = typer.Typer(name="megakernel", help="Megakernel benchmark")


@megakernel_app.command("submit")
def submit(
    solution_dir: Path = typer.Option(..., help="Directory containing solution.py"),
    problem: str = typer.Option(..., help="Problem name (e.g. llama3_70b_dense_single)"),
    model_path: str | None = typer.Option(None, help="HF model path for stages 4-5"),
) -> None:
    """Submit a megakernel for evaluation."""
    assert solution_dir.is_dir(), f"Not a directory: {solution_dir}"
    assert (solution_dir / "solution.py").is_file(), (
        f"No solution.py in {solution_dir}"
    )

    cmd = [
        sys.executable,
        "-m",
        "megakernel_bench.bench",
        "run",
        "--problem",
        problem,
        "--solution-dir",
        str(solution_dir),
    ]
    if model_path is not None:
        cmd.extend(["--model-path", model_path])

    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    typer.echo(result.stdout)
    if result.returncode != 0:
        typer.echo(result.stderr, err=True)
        raise typer.Exit(code=result.returncode)
