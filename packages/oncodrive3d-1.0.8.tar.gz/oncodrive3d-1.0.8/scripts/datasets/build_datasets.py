"""
Module to generate datasets necessary to run Oncodrive3D.

The build is a pipeline that perform the following tasks:
    - Download the PDB structures of the selected proteome
      predicted by AlphaFold 2 from AlphaFold DB.
    - Merge the overlapping structures processed as fragments.
    - Optionally download the PDB structures corresponding to
      the MANE Select transcripts.
    - Optionally copy and parse custom PDB structures.  
    - Generate a dataframe including Uniprot_ID, HUGO Symbol,
      protein, DNA sequence, and other gene's information.
    - Extract AlphaFold model confidence (pLDDT).
    - Download AlphaFold predicted aligned error (PAE) from
      AlphaFold DB and convert the files into npy format.
    - Use the PDB structure and PAE to create maps of
      probability of contacts (pCMAPs) for any protein of the
      downloaded proteome with available PAE.
    - Remove unnecessary temp files.
"""


import os
import shutil
import daiquiri

from scripts import __logger_name__
from scripts.datasets.af_merge import merge_af_fragments
from scripts.datasets.get_pae import get_pae
from scripts.datasets.get_structures import get_structures, mv_mane_pdb
from scripts.datasets.model_confidence import get_confidence
from scripts.datasets.parse_pae import parse_pae
from scripts.datasets.prob_contact_maps import get_prob_cmaps_mp
from scripts.datasets.seq_for_mut_prob import get_seq_df
from scripts.datasets.custom_pdb import copy_and_parse_custom_pdbs
from scripts.datasets.utils import get_species
from scripts.globals import clean_dir, clean_temp_files

logger = daiquiri.getLogger(__logger_name__ + ".build")


def build(output_datasets,
          organism,
          mane,
          mane_only,
          custom_pdb_dir,
          custom_pae_dir,
          custom_mane_metadata_path,
          distance_threshold,
          num_cores,
          af_version,
          mane_version):
    """
    Build datasets necessary to run Oncodrive3D.
    """

    # Empty directory
    clean_dir(output_datasets, 'd', txt_file=True)

    # Download PDB structures
    species = get_species(organism)
    if mane and str(af_version) != "4":
      logger.warning(
        "MANE structures are only available in AlphaFold DB v4. "
        "Ignoring --af_version=%s and using v4 for this build.",
        af_version,
      )
      af_version = 4
    if not mane_only:
      logger.info("Downloading AlphaFold (AF) predicted structures...")
      get_structures(
        path=os.path.join(output_datasets,"pdb_structures"),
        species=species,
        af_version=str(af_version),
        threads=num_cores
        )
      logger.info("Download of structures completed!")

      # Merge fragmented structures
      logger.info("Merging fragmented structures...")
      merge_af_fragments(
        input_dir=os.path.join(output_datasets,"pdb_structures"),
        af_version=af_version,
        gzip=True
        )

    # Download PDB MANE structures
    if species == "Homo sapiens" and mane:
        logger.info("Downloading AlphaFold (AF) predicted structures overlap with MANE...")
        get_structures(
          path=os.path.join(output_datasets,"pdb_structures_mane"),
          species=species,
          mane=True,
          af_version=str(af_version),
          threads=num_cores
          )
        mv_mane_pdb(output_datasets, "pdb_structures", "pdb_structures_mane")
        logger.info("Download of MANE structures completed!")
        
    # Copy custom PDB structures and optinally add SEQRES
    if custom_pdb_dir is not None:
      if not mane_only:
        logger.error(
          "custom_pdb_dir requires --mane_only. Use --mane_only when providing custom MANE structures."
          )
        raise ValueError(
          "custom_pdb_dir requires --mane_only"
          )
      if custom_mane_metadata_path is None:
        logger.error(
          "custom_mane_metadata_path must be provided when custom_pdb_dir is specified"
          )
        raise ValueError(
          "Both custom_pdb_dir and custom_mane_metadata_path must be provided together"
          )
      
      logger.info("Copying custom PDB structures...")
      if os.path.exists(custom_pdb_dir):
        copy_and_parse_custom_pdbs(
          src_dir=custom_pdb_dir,
          dst_dir=os.path.join(output_datasets,"pdb_structures"), 
          af_version=int(af_version),
          custom_mane_metadata_path=custom_mane_metadata_path
          )
      else:
          logger.error(f"Custom PDB directory does not exist: {custom_pdb_dir}")
          raise FileNotFoundError(f"Custom PDB directory not found: {custom_pdb_dir}")
    
    # Create df including genes and proteins sequences & Hugo to Uniprot_ID mapping
    logger.info("Generating dataframe for genes and proteins sequences...")
    seq_df = get_seq_df(
      datasets_dir=output_datasets,
      output_seq_df=os.path.join(output_datasets, "seq_for_mut_prob.tsv"),
      organism=species,
      mane=mane,
      mane_only=mane_only,
      num_cores=num_cores,
      mane_version=mane_version,
      custom_mane_metadata_path=custom_mane_metadata_path,
      af_version=af_version,
      )
    logger.info("Generation of sequences dataframe completed!")

    # Get model confidence
    logger.info("Extracting AF model confidence...")
    get_confidence(
      input=os.path.join(output_datasets, "pdb_structures"),
      output_dir=os.path.join(output_datasets),
      seq_df=seq_df
      )

    # Get PAE
    pae_output_dir = os.path.join(output_datasets, "pae")
    if custom_pae_dir is not None:
      logger.info("Copying precomputed PAE directory...")
      if os.path.exists(custom_pae_dir):
        if os.path.exists(pae_output_dir):
          shutil.rmtree(pae_output_dir)
        shutil.copytree(custom_pae_dir, pae_output_dir)
      else:
        logger.warning(
          "Custom PAE directory does not exist: %s. Skipping copy. "
          "Contact maps will be computed without PAE (binary maps).",
          custom_pae_dir,
        )
    else:
      logger.info("Downloading AF predicted aligned error (PAE)...")
      get_pae(
        input_dir=os.path.join(output_datasets,"pdb_structures"),
        output_dir=pae_output_dir,
        num_cores=num_cores,
        af_version=str(af_version),
        custom_pdb_dir=custom_pdb_dir
        )

    # Parse PAE
    logger.info("Parsing PAE...")
    parse_pae(input=pae_output_dir)
    logger.info("Parsing PAE completed!")

    # Get pCAMPs
    logger.info("Generating contact probability maps (pCMAPs)..")
    get_prob_cmaps_mp(
      input_pdb=os.path.join(output_datasets, "pdb_structures"),
      input_pae=os.path.join(output_datasets, "pae"),
      output=os.path.join(output_datasets,"prob_cmaps"),
      distance=distance_threshold,
      num_cores=num_cores
                      )
    logger.info("Generation pCMAPs completed!")

    # Clean datasets
    logger.info("Cleaning datasets...")
    clean_temp_files(path=output_datasets)
    logger.info("Datasets cleaning completed!")
    logger.info("Datasets have been successfully built and are ready for analysis!")

if __name__ == "__main__":
    raise SystemExit(
        "This module is intended to be used via the CLI: `oncodrive3d build-datasets`."
    )
