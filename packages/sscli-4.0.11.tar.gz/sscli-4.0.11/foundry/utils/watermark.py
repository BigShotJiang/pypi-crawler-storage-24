"""
foundry.utils.watermark — Alpha package watermarking.

Injects a human-readable WATERMARK.txt into a package directory so that
every alpha delivery can be traced back to the licensee.

Usage:
    from foundry.utils.watermark import inject_watermark

    package_id = inject_watermark("/tmp/my-package", "alice@example.com", "alpha")
"""

import uuid
from datetime import datetime, timezone
from pathlib import Path

WATERMARK_FILENAME = "WATERMARK.txt"

WATERMARK_TEMPLATE = """\
================================================================================
  Seed & Source Alpha Package
================================================================================
Licensed to: {user_email}
License tier: {tier}
Generated:   {timestamp}
Package ID:  {package_id}
================================================================================
WARNING: This software is confidential. Do not redistribute.
Sharing this package violates the Alpha Tester Agreement.
If received in error, contact support@seedsource.dev immediately.
================================================================================
"""


def inject_watermark(target_dir: str, user_email: str, tier: str) -> str:
    """
    Inject a WATERMARK.txt into *target_dir*.

    Parameters
    ----------
    target_dir : str
        Absolute or relative path to the package root directory.
    user_email : str
        Email address of the licensee (embedded in the watermark).
    tier : str
        License tier label, e.g. "alpha", "pro".

    Returns
    -------
    str
        The generated package UUID (``package_id``).

    Raises
    ------
    ValueError
        If *user_email* or *tier* are empty.
    NotADirectoryError
        If *target_dir* does not exist as a directory.
    """
    if not user_email:
        raise ValueError("user_email must not be empty")
    if not tier:
        raise ValueError("tier must not be empty")

    target = Path(target_dir)
    if not target.is_dir():
        raise NotADirectoryError(f"target_dir does not exist or is not a directory: {target_dir}")

    package_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    content = WATERMARK_TEMPLATE.format(
        user_email=user_email,
        tier=tier,
        timestamp=timestamp,
        package_id=package_id,
    )

    watermark_path = target / WATERMARK_FILENAME
    watermark_path.write_text(content, encoding="utf-8")

    return package_id
