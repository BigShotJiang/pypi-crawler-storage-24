import warnings
from pathlib import Path
from dotenv import load_dotenv
from foundry.cli import app
from foundry.observability import init_sentry

# Initialize Sentry for error tracking (SSA-58)
init_sentry()

# Security: only load env from the user-level config file, never from CWD.
# Loading from CWD would allow any cloned repo to poison environment variables
# such as LICENSE_SERVER_URL, FOUNDRY_ROOT, or VIRTUAL_ENV.
_safe_env = Path.home() / ".config" / "foundry" / ".env"
load_dotenv(dotenv_path=_safe_env, override=False)

# Warn if a .env exists in CWD — it will NOT be loaded (C-11).
_cwd_env = Path.cwd() / ".env"
if _cwd_env.exists():
    warnings.warn(
        f"A .env file was found at '{_cwd_env}' but was NOT loaded. "
        "Foundry only reads environment configuration from "
        f"'{_safe_env}'. Remove the CWD .env or move its contents "
        "to the safe config path to silence this warning.",
        stacklevel=1,
    )

if __name__ == "__main__":
    app()
