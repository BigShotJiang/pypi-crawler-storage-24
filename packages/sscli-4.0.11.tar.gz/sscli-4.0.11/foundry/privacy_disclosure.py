# Privacy & Telemetry Disclosure for sscli Login Flow
# SSA-58: GDPR-compliant user consent before telemetry initialization

import os
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

console = Console()

PRIVACY_DISCLOSURE_TEXT = """
## 🔒 Privacy & Telemetry Notice

By logging in, you agree to our [Privacy & Telemetry Policy](https://docs.seedsource.dev/privacy-and-telemetry).

**What we collect:**
- Non-identifiable usage metrics (commands, success/failure)
- Error reports and stack traces (for debugging)
- Performance data (response times)

**What we DON'T collect:**
- Email addresses or usernames
- Your source code or project files
- Passwords or API keys
- Personal identifiable information (PII)

**Your rights:**
- Opt-out anytime: `export SSCLI_NO_TELEMETRY=1`
- Request data deletion: legal@seedsource.dev
- Full details: https://docs.seedsource.dev/privacy-and-telemetry

**GDPR Compliant** ✅ — Your data is never sold or shared.
"""


def show_privacy_disclosure():
    """
    Display privacy and telemetry disclosure during login flow.
    Shown once per login attempt (not on every command).
    """
    # Don't show if telemetry is already disabled
    if os.getenv("SSCLI_NO_TELEMETRY", "0").strip() == "1":
        return

    # Don't show if already shown in this session
    if os.getenv("_FOUNDRY_PRIVACY_SHOWN", "0") == "1":
        return

    panel = Panel(
        Markdown(PRIVACY_DISCLOSURE_TEXT),
        title="🔐 Privacy & Telemetry",
        border_style="blue",
        padding=(1, 2),
    )
    console.print(panel)
    console.print()

    # Mark as shown in this session
    os.environ["_FOUNDRY_PRIVACY_SHOWN"] = "1"
