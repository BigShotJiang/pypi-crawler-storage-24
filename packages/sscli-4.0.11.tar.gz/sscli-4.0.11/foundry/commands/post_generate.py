from __future__ import annotations

import subprocess
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

_console = Console()


def run_post_generate_checklist(
    project_name: str,
    template: str,
    project_path: Path,
) -> None:
    """Print actionable next-steps after project generation."""
    docker_ok = _check_docker()
    env_exists = (project_path / ".env").exists()

    table = Table.grid(padding=(0, 1))
    table.add_column(style="bold")
    table.add_column()

    env_icon = "✅" if env_exists else "📋"
    if not env_exists:
        table.add_row(f"{env_icon} 1.", f"[bold]Copy config:[/bold]  cd {project_name} && cp .env.example .env")
    else:
        table.add_row(f"{env_icon} 1.", "[dim].env already exists — skip[/dim]")

    docker_label = "Start dev:" if docker_ok else "[yellow]Start Docker Desktop first, then run:[/yellow]"
    docker_icon = "✅" if docker_ok else "⚠️ "
    table.add_row(f"{docker_icon} 2.", f"[bold]{docker_label}[/bold]  docker compose up")
    table.add_row("📖 3.", "[bold]Getting started:[/bold]  https://docs.seedsource.dev/getting-started")
    table.add_row("✏️  4.", "[bold]Customize:[/bold]  edit README.md for your project")

    panel = Panel(
        table,
        title=f"[green]✅ Project created: {project_name}[/green]",
        subtitle=f"[dim]Template: {template}[/dim]",
        border_style="green",
        padding=(1, 2),
    )
    _console.print(panel)


def _check_docker() -> bool:
    """Return True if Docker daemon is reachable."""
    try:
        result = subprocess.run(["docker", "info"], capture_output=True, timeout=3)
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False
