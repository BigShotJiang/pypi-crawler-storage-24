import typer
import time
from typing import Optional
from rich.console import Console
from rich.panel import Panel
from foundry.auth import login_flow, logout, get_current_license_info, save_credentials
from foundry.constants import console
from foundry.telemetry import log_event
from foundry.privacy_disclosure import show_privacy_disclosure


auth_app = typer.Typer(help="Manage authentication and licenses.")


@auth_app.command("login")
def auth_login(
    force: bool = typer.Option(False, "--force", help="Force re-authentication even if already logged in"),
    token: Optional[str] = typer.Option(None, "--token", help="Use an existing GitHub token for non-browser login"),
):
    """Login to Seed & Source using browser-based GitHub OAuth."""
    # Show privacy and telemetry disclosure (GDPR compliance)
    show_privacy_disclosure()

    token_value = token.strip() if isinstance(token, str) else None

    # Token login path: validate token against server and cache only when valid.
    if token_value:
        save_credentials({
            "access_token": token_value,
            "issued_at": int(time.time()),
            "status": "active",
            "authorized": True,
        })
        auth_info = get_current_license_info(verify=True)
        if auth_info.get("authorized"):
            console.print(f"\n[green]✓ Authentication succeeded: {auth_info.get('tier', 'free').upper()}[/green]")
            log_event("auth_login", f"success tier={auth_info.get('tier', 'unknown')}")
        else:
            console.print("\n[red]Authentication did not complete. The token was not validated.[/red]")
            log_event("auth_login", "failure invalid_token")
        return

    # Check if already logged in
    current_info = get_current_license_info(verify=True)
    if current_info.get("authorized") and not force:
        label = current_info.get("email") or current_info.get("user_id") or "Account"
        console.print(f"\n[green]✓ Already authenticated as {label}[/green]")
        console.print(f"  Tier: {current_info.get('tier', 'free').upper()}")
        console.print("\n  Use [bold]sscli auth login --force[/bold] to re-authenticate")
        log_event("auth_login", "skipped_already_logged_in")
        return
    
    if login_flow():
        auth_info = get_current_license_info(verify=True)
        if auth_info.get("authorized"):
            email = auth_info.get("email")
            if email:
                console.print(f"\n[green]✓ Authentication succeeded for {email}[/green]")
            else:
                console.print("\n[green]✓ Authentication succeeded[/green]")
            console.print(f"  Tier: {auth_info.get('tier', 'free').upper()}")
            log_event("auth_login", f"success tier={auth_info.get('tier', 'unknown')}")
        else:
            console.print("\n[red]Authentication completed, but the session could not be verified. Try again in a moment.[/red]")
            log_event("auth_login", "failure verification_failed")
    else:
        console.print("\n[yellow]\u26a0\ufe0f  Login wasn't completed. Visit https://seedsource.dev/membership to get your account, then run 'sscli auth login' again.[/yellow]")
        log_event("auth_login", "failure user_cancelled")


@auth_app.command("logout")
def auth_logout():
    """Logout and clear local credentials."""
    logout()
    log_event("auth_logout", "success")


def run_whoami():
    """Display current user and license tier."""
    info = get_current_license_info(verify=True)
    if not info or not info.get("authorized", False):
        console.print("Not logged in. Use 'sscli auth login' to authenticate.")
        return

    stat_console = Console()
    status_color = "green" if info.get("status") != "expired" else "red"

    tier_str = info.get('tier', 'free').upper()
    org_name = info.get('org_name')
    if org_name:
        tier_display = f"{tier_str} (via {org_name})"
    else:
        tier_display = tier_str

    stat_console.print(
        Panel(
            f"👤 [bold]Account:[/bold] {info.get('email') or info.get('user_id') or 'Unknown'}\n"
            f"🏆 [bold]Tier:[/bold] {tier_display}\n"
            f"📅 [bold]Expires:[/bold] {info.get('expires', 'N/A')}\n"
            f"✨ [bold]Status:[/bold] [{status_color}]{info.get('status', 'active').upper()}[/{status_color}]",
            title="Account Profile",
            expand=False,
        )
    )
