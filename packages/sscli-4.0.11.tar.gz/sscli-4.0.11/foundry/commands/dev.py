"""Development tools sub-application."""
from typing import Optional
import typer
from foundry.constants import console
from foundry.actions.development import (
    dev_tools_menu,
    show_status,
    run_build,
    run_swap,
    mount_feature,
)

dev_app = typer.Typer(help="Development and maintenance tools", invoke_without_command=True)


@dev_app.callback()
def dev_callback(ctx: typer.Context):
    """Development tools for maintenance and local testing."""
    if ctx.invoked_subcommand is None:
        dev_tools_menu()



@dev_app.command("status")
def status(
    verbose: bool = typer.Option(
        False, "--verbose", help="Show detailed dependency information"
    ),
):
    """Show development environment status (local build vs pip package)."""
    show_status(verbose=verbose)


@dev_app.command("build")
def build(
    clean: bool = typer.Option(
        False, "--clean", help="Clean build artifacts before building"
    ),
):
    """Build distribution packages (wheel and sdist)."""
    if run_build(clean=clean):
        console.print("[green]✓[/green] Build successful")
    else:
        console.print("[red]✗[/red] Build failed")
        raise typer.Exit(code=1)


@dev_app.command("swap")
def swap(
    target: Optional[str] = typer.Option(
        None, help="Target: 'local' or 'pip' (interactive if not specified)"
    ),
):
    """Switch between local and pip package installations."""
    if not run_swap(target=target):
        console.print("[red]✗[/red] Swap failed")
        raise typer.Exit(code=1)


@dev_app.command("mount")
def mount(
    feature: str = typer.Argument(..., help="Feature name (commerce, tunnel, admin, etc.)"),
    template: str = typer.Option(..., "--template", help="Target template name"),
    target_dir: str = typer.Option(".", help="Target directory for mounting"),
):
    """Mount a feature from the feature vault via symlinks."""
    if not mount_feature(feature, template, target_dir):
        console.print("[red]✗[/red] Mount failed")
        raise typer.Exit(code=1)
