import os
import json
import tempfile
import urllib.parse
import time
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from foundry.constants import console, API_BASE_URL

# Allowed hostnames for outbound authenticated requests (C-5)
_ALLOWED_HOSTS = {"seedsource.dev", "auth.seedsource.dev", "localhost"}

# Allowed hostnames for browser-opened verification URIs (H-3)
# Includes github.com because GitHub device flow sends verification_uri there.
# seedsource.dev covers /activate endpoint; auth.seedsource.dev covers the auth subdomain.
_ALLOWED_VERIFICATION_HOSTS = {"github.com", "seedsource.dev", "auth.seedsource.dev", "localhost"}


def _http_error_message(status_code: int) -> str:
    """Map HTTP status codes from the license server to actionable user messages."""
    if status_code == 401:
        return "Invalid or expired credentials. Run: sscli auth login"
    if status_code == 403:
        return "Access denied. Your license may not cover this feature. Check: sscli whoami"
    if status_code == 404:
        return "Account not found. Have you registered? Visit: account.seedsource.dev"
    if status_code == 422:
        return "Validation error from server. Try logging out and back in: sscli auth logout && sscli auth login"
    if status_code == 429:
        return "Too many requests. Please wait a moment and try again."
    if 500 <= status_code < 600:
        return "License server is temporarily unavailable. Check status at: seedsource.dev"
    return f"Authentication failed (code: {status_code}). Run sscli auth login to refresh."


def _validate_request_url(url: str) -> None:
    """Validate that a URL is safe to send Bearer tokens to.

    Enforces HTTPS (except localhost) and hostname allowlist.
    Raises ValueError if the URL does not meet security requirements.
    """
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.hostname or ""
    if hostname not in _ALLOWED_HOSTS:
        raise ValueError(f"Request URL hostname not in allowed list: {hostname!r}")
    if parsed.scheme == "http" and hostname != "localhost":
        raise ValueError(f"HTTP only allowed for localhost; got scheme {parsed.scheme!r} for {hostname!r}")
    if parsed.scheme not in ("https", "http"):
        raise ValueError(f"Insecure URL scheme: {parsed.scheme!r}")

# Configuration
# The base URL is managed in foundry/constants.py (configurable via environment variables)
LICENSE_SERVER = API_BASE_URL
CREDENTIALS_FILE = Path.home() / ".config" / "sscli" / "credentials.json"


def save_credentials(data: Dict[str, Any]) -> None:
    """Cache authentication data locally.
    
    Stores access token, tier, and org info for CLI operations.
    Token is stored securely with owner-only file permissions (0600).
    """
    # Create directory with restrictive permissions (owner only)
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    
    # Store all authentication data
    cached_data = {
        "access_token": data.get("access_token"),
        "tier": data.get("tier", "free"),
        "org_name": data.get("org_name"),
        "email": data.get("email"),
        "status": data.get("status", "active"),
        "authorized": True,  # If we're caching, user just authenticated successfully
        "issued_at": int(data.get("issued_at", int(time.time()))),
        "expires_in": data.get("expires_in"),
        "expires_at": data.get("expires_at"),
    }

    if not cached_data.get("expires_at") and cached_data.get("expires_in"):
        try:
            cached_data["expires_at"] = int(cached_data["issued_at"]) + int(cached_data["expires_in"])
        except Exception:
            pass
    
    # Write to a securely created temp file (0600 at creation) then atomically replace.
    fd, temp_path = tempfile.mkstemp(
        prefix=f"{CREDENTIALS_FILE.name}.",
        suffix=".tmp",
        dir=str(CREDENTIALS_FILE.parent),
        text=True,
    )
    temp_file = Path(temp_path)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(cached_data, f, indent=2)
        os.chmod(temp_file, 0o600)
        temp_file.replace(CREDENTIALS_FILE)
        CREDENTIALS_FILE.chmod(0o600)
    finally:
        try:
            if temp_file.exists():
                temp_file.unlink()
        except Exception:
            pass


def _free_unauthorized_info() -> Dict[str, Any]:
    return {"tier": "free", "authorized": False, "org_name": None, "status": "unauthorized"}


def _clear_cached_credentials() -> None:
    try:
        CREDENTIALS_FILE.unlink()
    except FileNotFoundError:
        pass
    except Exception:
        pass



def login_flow() -> bool:
    """Authenticate via GitHub Device Flow.

    Requests a device code from the license server, prints the verification URL
    and one-time code for the user to open manually, then polls until GitHub
    confirms authorization or the code expires.

    No local HTTP server or browser auto-open is used.

    Returns:
        True if authentication succeeded, False otherwise.
    """
    console.print("\n[bold blue]Seed & Source Authentication[/bold blue]")
    console.print("Authenticating with GitHub...\n")

    try:
        # Step 1 — request a device code from the license server
        device_code_url = f"{LICENSE_SERVER}/v1/auth/device/code"
        _validate_request_url(device_code_url)
        dc_response = requests.post(
            device_code_url,
            timeout=10,
            verify=True,
            allow_redirects=False,
        )
        if dc_response.status_code != 200:
            _raw = dc_response.text or ""
            _safe = _raw.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")[:200]
            console.print(f"[red]{_http_error_message(dc_response.status_code)}[/red]")
            if _safe:
                console.print(f"[red]{_safe}[/red]")
            return False

        dc_data = dc_response.json()
        device_code = dc_data.get("device_code")
        user_code = dc_data.get("user_code")
        verification_uri = dc_data.get("verification_uri") or dc_data.get("verification_url")
        expires_in = int(dc_data.get("expires_in", 900))
        poll_interval = max(int(dc_data.get("interval", 5)), 5)  # GitHub minimum is 5 s

        if not device_code or not user_code or not verification_uri:
            console.print("[red]Invalid response from authentication server. Try again.[/red]")
            return False

        # H-3: validate verification URI before displaying
        _parsed_vuri = urllib.parse.urlparse(verification_uri)
        _vuri_host = _parsed_vuri.hostname or ""
        if _vuri_host not in _ALLOWED_VERIFICATION_HOSTS or _parsed_vuri.scheme != "https":
            console.print(f"[red]Unsafe verification URI blocked: {verification_uri!r}[/red]")
            return False

        # Step 2 — prompt user (no auto-open)
        console.print("[bold yellow]Action required:[/bold yellow] Open the URL below and enter the code.\n")
        console.print(f"  [bold cyan]URL :[/bold cyan]  {verification_uri}")
        console.print(f"  [bold cyan]Code:[/bold cyan]  [bold white]{user_code}[/bold white]\n")
        console.print(f"[dim]Code expires in {expires_in // 60} minutes. Waiting for authorization...[/dim]\n")

        # Step 3 — poll the license server until authorized or expired
        token_url = f"{LICENSE_SERVER}/v1/auth/device/token"
        _validate_request_url(token_url)
        deadline = time.time() + expires_in

        while time.time() < deadline:
            time.sleep(poll_interval)
            token_response = requests.post(
                token_url,
                data={"device_code": device_code},
                timeout=10,
                verify=True,
                allow_redirects=False,
            )

            if token_response.status_code != 200:
                # Non-200 from license server is unexpected; surface and abort
                console.print(f"[red]{_http_error_message(token_response.status_code)}[/red]")
                return False

            token_data = token_response.json()
            error = token_data.get("error")

            if error == "authorization_pending":
                continue  # still waiting — normal
            if error == "slow_down":
                poll_interval += 5  # GitHub asked us to back off
                continue
            if error in ("expired_token", "access_denied", "server_error"):
                msg = token_data.get("error_description") or error
                console.print(f"\n[red]Authorization failed: {msg}[/red]")
                return False
            if error:
                console.print(f"\n[red]Unexpected error: {error}[/red]")
                return False

            # Success — token_data contains access_token + tier info from license server
            access_token = token_data.get("access_token")
            if not access_token:
                console.print("[red]No access token in response. Try again.[/red]")
                return False

            save_credentials({
                "access_token": access_token,
                "tier": token_data.get("tier", "free"),
                "org_name": token_data.get("org_name"),
                "email": token_data.get("email"),
                "issued_at": int(time.time()),
                "expires_in": token_data.get("expires_in"),
                "expires_at": token_data.get("expires_at"),
                "status": "active",
                "authorized": True,
            })

            email = token_data.get("email")
            tier_str = token_data.get("tier", "free").upper()
            org_name = token_data.get("org_name")
            if email:
                console.print(f"✓ [green]Authenticated as[/green] {email}")
            else:
                console.print("✓ [green]Authentication completed successfully[/green]")
            if org_name:
                console.print(f"License Tier: {tier_str} (via {org_name})")
            else:
                console.print(f"License Tier: {tier_str}")
            return True

        console.print("\n[yellow]⚠️  Code expired. Run 'sscli auth login' to try again.[/yellow]")
        return False

    except requests.RequestException:
        console.print("[red]Couldn't reach the Seed & Source server. Check your internet connection and try again.[/red]")
        return False
    except Exception as e:
        console.print(f"[red]Unexpected error during authentication:[/] {e}")
        return False


def get_current_license_info(verify: bool = False) -> Dict[str, Any]:
    """Get current license/tier info from local cache or validate with server.

    If verify=True, validates stored token with License Server to ensure authenticity.
    If verification fails, returns cached tier (or free if no cache).
    
    Token is stored locally in credentials file with restricted permissions (0600).
    """
    default_info = _free_unauthorized_info()
    
    # Check if cached credentials exist — TOCTOU-safe (H-24)
    cached_info = None
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            cached_info = json.load(f)
        if not isinstance(cached_info, dict):
            cached_info = None
        else:
            # Ensure authorized flag is set for cached credentials
            if "authorized" not in cached_info:
                cached_info["authorized"] = cached_info.get("tier", "free") != "free"
    except (FileNotFoundError, json.JSONDecodeError):
        cached_info = None
    except Exception:
        cached_info = None
    
    # If not verifying, return cached info but never trust local tier (C-14)
    if not verify:
        if cached_info:
            try:
                expires_at = cached_info.get("expires_at")
                if expires_at and int(expires_at) <= int(time.time()):
                    return default_info
            except Exception:
                pass
            return {**cached_info, "tier": "free"}
        return default_info
    
    # Verification mode: get token from cache and validate with License Server
    if not cached_info or not cached_info.get("access_token"):
        # No token available: never return local/tampered tier data.
        return default_info
    
    token = cached_info["access_token"]
    
    try:
        _validate_url = f"{LICENSE_SERVER}/v1/auth/validate"
        _validate_request_url(_validate_url)  # C-5
        response = requests.get(
            _validate_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=2.0,
            verify=True,           # H-1
            allow_redirects=False, # H-2
        )
        if response.status_code == 200:
            server_data = response.json()
            # Ensure authorized flag is set
            server_data["authorized"] = True
            server_data["access_token"] = token  # Preserve token
            # Update cache with fresh server data
            save_credentials(server_data)
            return server_data
        elif response.status_code == 401:
            # Token is invalid/revoked; clear local credentials and downgrade immediately.
            _clear_cached_credentials()
            console.print(f"[yellow]{_http_error_message(401)}[/yellow]")
            return default_info
        else:
            # Non-200: cannot verify tier — never trust local JSON tier (C-14)
            console.print(f"[yellow]{_http_error_message(response.status_code)}[/yellow]")
            return default_info
    except Exception:
        # Server unreachable — never trust local JSON tier (C-14)
        return default_info


def logout() -> None:
    """Clear authentication credentials.

    Removes locally stored access token and cached credentials.
    """
    # TOCTOU-safe unlink (H-24)
    try:
        CREDENTIALS_FILE.unlink()
        console.print("[green]✓ Logged out successfully.[/green]")
    except FileNotFoundError:
        console.print("[yellow]No active session found.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error during logout:[/] {e}")


# Legacy function - no longer used (kept for compatibility)
def get_access_token() -> Optional[str]:
    """Retrieve token from credentials file.
    
    Legacy function kept for backward compatibility.
    Returns stored access token or None if not authenticated.
    """
    # TOCTOU-safe read (H-24)
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
        return data.get("access_token")
    except (FileNotFoundError, json.JSONDecodeError):
        return None
    except Exception:
        return None
