from typing import Optional, List
from pathlib import Path
from foundry.constants import console, DISABLED_FEATURES_POLICY
from foundry.telemetry import log_event
import typer
from foundry.actions.explore import run_explore, run_explore_list, run_explore_json
from foundry.actions.generator import run_generator
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup
from foundry.actions.validation import run_smoke_tests
from foundry.actions.verify import run_verification
from foundry.actions.upgrade import run_upgrade
from foundry.auth import logout
from foundry.commands.auth import auth_app, run_whoami
from foundry.commands.interactive import interactive_app
from foundry.commands.observability import observability_app
from foundry.commands.internals import internals_app
from foundry.commands.feedback import feedback_app
from foundry.commands.report import report_app
from foundry.commands.codegen import app as generate_app
from foundry.commands.doctor import app as doctor_app
from foundry.commands.wizard import app as wizard_app
from foundry.utils import is_internal_dev

app = typer.Typer(
    help="Seed & Source CLI Tool",
    no_args_is_help=False,
    add_completion=True,
)

COMING_SOON_FLAG_MESSAGES = {
    cfg["flag"]: cfg["message"] for cfg in DISABLED_FEATURES_POLICY.values()
}


def _exit_coming_soon(flag: str) -> None:
    console.print(f"[red]❌ Error: {flag} is coming soon.[/red]")
    console.print(f"[yellow]{COMING_SOON_FLAG_MESSAGES[flag]}[/yellow]")
    raise typer.Exit(code=1)

# Add sub-apps from separate modules
app.add_typer(auth_app, name="auth")
app.add_typer(interactive_app, name="interactive")
app.add_typer(observability_app, name="obs", help="Observability, diff, and workspace tools")
app.add_typer(feedback_app, name="feedback", help="Submit feedback, bugs, and feature requests")
app.add_typer(report_app, name="report", help="Report errors and submit system diagnostics")
app.add_typer(generate_app, name="generate", help="Generate boilerplate files from templates")
app.add_typer(doctor_app, name="doctor")
app.add_typer(wizard_app, name="wizard", help="Configuration wizard and setup tools")

# Only expose dev tools in internal development mode
if is_internal_dev():
    app.add_typer(internals_app, name="internals", help="Internal-projects execution and annotation tools")
    from foundry.commands.dev import dev_app
    app.add_typer(dev_app, name="dev", help="Development and maintenance tools")


@app.callback(invoke_without_command=True)
def default_action(ctx: typer.Context):
    """Default action: show interactive menu if no command is provided."""
    if ctx.invoked_subcommand is None:
        from foundry.interactive import interactive_menu
        interactive_menu()


@app.command("whoami")
def whoami():
    run_whoami()


@app.command("login")
def login_cmd(
    force: bool = typer.Option(False, "--force", help="Force re-authentication even if already logged in"),
    token: Optional[str] = typer.Option(None, "--token", help="Use an existing token (from account.seedsource.dev)"),
):
    """Login to Seed & Source to unlock ALPHA/PRO templates."""
    from foundry.commands.auth import auth_login
    auth_login(force=force, token=token)
    log_event("COMMAND", "login")


@app.command("logout")
def logout_cmd():
    """Clear local credentials and logout."""
    logout()
    log_event("COMMAND", "logout")


@app.command("explore")
def explore(
    list_mode: bool = typer.Option(False, "--list", help="Non-interactive plain-text list (safe in pipes)"),
    json_mode: bool = typer.Option(False, "--json", help="Non-interactive JSON catalog output (safe in pipes)"),
):
    """List available templates. Use --list or --json for pipe-safe non-interactive output."""
    import sys
    if json_mode:
        run_explore_json()
        log_event("COMMAND", "explore")
        return
    if list_mode:
        run_explore_list()
        log_event("COMMAND", "explore")
        return
    if not sys.stdout.isatty():
        # Non-interactive terminal (piped output) — fall back to plain list
        run_explore_list()
        log_event("COMMAND", "explore")
        return
    run_explore()
    log_event("COMMAND", "explore")


@app.command("new")
def new(
    template: str = typer.Option(..., help="Template to use — try 'rails-api', 'python-saas', 'react-client', or 'static-landing'"),
    name: str = typer.Option(..., help="Your app name — used as the project directory and package name"),
    target: Optional[str] = typer.Option(
        None, help="Where to create the project (defaults to --name if not set)"
    ),
    no_lint: bool = typer.Option(False, "--no-lint", help="Skip the built-in linter setup (ruff for Python, rubocop for Rails, eslint for React)"),
    with_commerce: bool = typer.Option(
        False, "--with-commerce", help="Add a full e-commerce layer (products, orders, Stripe checkout) to your project"
    ),
    with_payment: bool = typer.Option(
        False, "--with-payment", help="Add Stripe payment processing to your project"
    ),
    with_tunnel: bool = typer.Option(
        False, "--with-tunnel", help="Add ngrok tunnel support for local development & webhooks"
    ),
    with_landing: bool = typer.Option(
        False, "--with-landing", help="Add a static landing page template to your project"
    ),
    with_admin: bool = typer.Option(
        False, "--with-admin", help="Add an admin dashboard with user management"
    ),
    with_sqlite: bool = typer.Option(
        False, "--with-sqlite", help="Use SQLite for local development (no database setup required)"
    ),
    with_ingestor: bool = typer.Option(
        False, "--with-ingestor", help="Add a data ingestion pipeline to your project"
    ),
    with_auth: bool = typer.Option(
        False, "--with-auth", help="Add authentication (login, sessions, JWT) to your project"
    ),
    with_seo_analyzer: bool = typer.Option(
        False, "--with-seo-analyzer", help="Add SEO analysis tools to your project"
    ),
    with_merchant_dashboard: bool = typer.Option(
        False, "--with-merchant-dashboard", help="Add a merchant dashboard with sales analytics"
    ),
    with_sidekiq: bool = typer.Option(
        False, "--with-sidekiq", help="Add background job processing with Sidekiq"
    ),
    with_sandbox: bool = typer.Option(
        False, "--with-sandbox", help="Inject sandbox mode policy and local safety toggles"
    ),
    with_ui_lib: Optional[str] = typer.Option(
        None, "--with-ui-lib", help="Add a pre-built UI component library to your project"
    ),
    use_ast_injection: bool = typer.Option(
        False, "--use-ast-injection", help="Use precise syntax-aware code injection (recommended for complex projects)"
    ),
    secrets: str = typer.Option(
        "Dotenv (Standard .env files)", help="How to manage secrets — default: .env files"
    ),
    content: Optional[str] = typer.Option(
        None, "--content", help="Path to a JSON blueprint file to pre-fill your landing page content (static-landing)"
    ),
    theme: Optional[str] = typer.Option(
        None, "--theme", help="Color theme for your landing page: emerald, midnight, slate, rose, amber (static-landing)"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview what would be generated without writing any files"),
    only_safe: bool = typer.Option(
        False,
        "--only-safe",
        help="Apply only when generation is conflict-free (requires target path not to exist)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Replace target directory if it already exists and is non-empty",
    ),
    json: bool = typer.Option(False, "--json", help="Output the dry-run plan as JSON (use with --dry-run)"),
    stats: bool = typer.Option(False, "--stats", help="Show only file/line counts in dry-run output (use with --dry-run)"),
    output: Optional[str] = typer.Option(None, "--output", help="Save the dry-run output to a file instead of printing it (use with --dry-run)"),
):
    """Generate a new project from a template. Run 'sscli explore' to see all available templates."""
    _flag_map = {
        "auth": with_auth,
        "admin": with_admin,
        "tunnel": with_tunnel,
        "ingestor": with_ingestor,
        "merchant_dashboard": with_merchant_dashboard,
    }
    for key, cfg in DISABLED_FEATURES_POLICY.items():
        if _flag_map.get(key, False):
            _exit_coming_soon(cfg["flag"])

    # Validation: merchant-dashboard requires commerce
    if with_merchant_dashboard and not with_commerce:
        console.print("[red]❌ Error: --with-merchant-dashboard requires --with-commerce to be enabled.[/red]")
        console.print("[yellow]Use: sscli new react-client --with-commerce --with-merchant-dashboard --name [name][/yellow]")
        raise typer.Exit(code=1)
    
    run_generator(
        template_name=template,
        app_name=name,
        target_dir_name=target,
        use_linters=not no_lint,
        with_commerce=with_commerce,
        with_payment=with_payment,
        with_tunnel=with_tunnel,
        with_landing=with_landing,
        with_admin=with_admin,
        with_sqlite=with_sqlite,
        with_ingestor=with_ingestor,
        with_auth=with_auth,
        with_seo_analyzer=with_seo_analyzer,
        with_merchant_dashboard=with_merchant_dashboard,
        with_sidekiq=with_sidekiq,
        with_sandbox=with_sandbox,
        with_ui_lib=with_ui_lib,
        use_ast_injection=use_ast_injection,
        interactive=False,
        secrets_strategy=secrets,
        content_path=content,
        theme=theme,
        dry_run=dry_run,
        only_safe=only_safe,
        force=force,
        json_output=json,
        stats_only=stats,
        output_file=output,
    )


@app.command("inject")
def inject(
    path: Path = typer.Option(..., "--path", help="Path to the project"),
    template: Optional[str] = typer.Option(None, "--template", help="Template type (optional, auto-detects otherwise)"),
    features: List[str] = typer.Option([], "--features", help="List of features to inject (e.g. commerce, auth, admin, sqlite, ingestor, tunnel, sandbox)"),
    use_ast_injection: bool = typer.Option(False, "--use-ast-injection", help="🔬 Use AST-based feature injection (experimental)"),
    with_shopify_embedded: bool = typer.Option(False, "--with-shopify-embedded", help="[PRO] Inject Shopify App Bridge embedded app support (App Bridge 3.x, Polaris)"),
):
    """Inject features into an existing project."""
    from foundry.actions.features import inject_features
    from foundry.constants import console
    
    if not path.exists():
        console.print(f"[bold red]✗ Error: Path {path} does not exist[/bold red]")
        raise typer.Exit(1)
    
    # Boundary validation for path safety (run after existence check)
    import tempfile
    resolved_path = path.resolve()
    cwd_root = Path.cwd().resolve()
    home_root = Path.home().resolve()
    temp_root = Path(tempfile.gettempdir()).resolve()

    try:
        resolved_path.relative_to(cwd_root)
    except ValueError:
        # Allow home directory as fallback
        try:
            resolved_path.relative_to(home_root)
        except ValueError:
            # Allow system temp directory (for tests and legitimate temp operations)
            try:
                resolved_path.relative_to(temp_root)
            except ValueError:
                console.print("[red]Error: Path must be within cwd, home directory, or temp directory[/red]")
                raise typer.Exit(1)
    
    # Auto-detect template if not provided
    if not template:
        if (path / "pyproject.toml").exists():
            template = "python-saas"
        elif (path / "astro.config.mjs").exists():
            if (path / "src" / "content" / "docs").exists():
                template = "docs-site"
            else:
                template = "static-landing"
        elif (path / "package.json").exists():
            template = "react-client"
        elif (path / "Gemfile").exists():
            template = "rails-api"
        else:
            console.print("[bold red]✗ Error: Could not auto-detect template type. Please provide --template[/bold red]")
            raise typer.Exit(1)
        console.print(f"   - Auto-detected template: [bold cyan]{template}[/bold cyan]")

    # Map features list to boolean flags
    feat_map = {f.lower().replace("-", "_"): True for f in features}
    # --with-shopify-embedded flag also sets shopify_embedded in the feature map
    if with_shopify_embedded:
        feat_map["shopify_embedded"] = True

    for feature_key, config in DISABLED_FEATURES_POLICY.items():
        if feat_map.get(feature_key, False):
            _exit_coming_soon(config["flag"])
    
    inject_features(
        path=path,
        template=template,
        commerce=feat_map.get("commerce", False),
        tunnel=feat_map.get("tunnel", False),
        admin=feat_map.get("admin", False),
        sqlite=feat_map.get("sqlite", False),
        ingestor=feat_map.get("ingestor", False),
        auth=feat_map.get("auth", False),
        seo_analyzer=feat_map.get("seo_analyzer", False),
        merchant_dashboard=feat_map.get("merchant_dashboard", False),
        sandbox=feat_map.get("sandbox", False),
        payment=feat_map.get("payment", False),
        use_ast_injection=use_ast_injection,
        inject_static_premium_base=False,
        shopify_embedded=feat_map.get("shopify_embedded", False),
    )
    console.print("\n[bold green]✅ Injection complete![/bold green]")


@app.command("setup")
def setup(
    verbose: bool = typer.Option(
        False, "--verbose", help="Enable detailed logging"
    ),
    force: bool = typer.Option(
        False, "--force", help="Force setup even if already configured"
    ),
    skip_deps: bool = typer.Option(
        False, "--skip-deps", help="Skip dependency installation"
    ),
    env: str = typer.Option("dev", "--env", help="Environment to setup (default: dev)"),
    strategy: Optional[str] = typer.Option(
        None, "--strategy", help="Setup strategy (docker, etc)"
    ),
):
    """Run setup for templates."""
    run_setup(
        verbose=verbose, force=force, skip_deps=skip_deps, env=env, strategy=strategy
    )
    log_event("COMMAND", "setup")


@app.command("validate")
def validate():
    """Run smoke tests."""
    run_smoke_tests()
    log_event("COMMAND", "validate")


@app.command("health")
def health():
    """Check configuration and health of templates."""
    run_health_check()
    log_event("COMMAND", "health")


@app.command("advise")
def advise(
    path: Path = typer.Argument(Path("."), help="Path to the project to analyze (defaults to current directory)"),
):
    """Analyze project structure and emit infrastructure recommendations."""
    from foundry.commands.advisor import analyze_project, render_findings
    findings = analyze_project(path.resolve())
    render_findings(findings)
    raise typer.Exit(1 if any(f.severity == "critical" for f in findings) else 0)


@app.command("verify")
def verify(
    skip_docker: bool = typer.Option(
        False, "--skip-docker", help="Skip Docker builds (faster, less thorough)"
    ),
    no_reports: bool = typer.Option(
        False, "--no-reports", help="Skip generating CSV/MD reports"
    ),
    features: bool = typer.Option(
        False, "--features", help="Run integration feature matrix tests"
    ),
):
    """Verify template integrity and buildability."""
    _result = run_verification(include_docker=not skip_docker, output_reports=not no_reports, include_features=features)
    log_event("COMMAND", "verify")
    if _result is False:
        raise typer.Exit(code=1)


@app.command("ready")
def ready(
    path: Optional[Path] = typer.Argument(
        None, help="Path to your generated project (defaults to current directory)"
    ),
):
    """Check if your project is ready to run locally with 'sscli dev'."""
    
    from foundry.actions.verification.project_validator import ProjectValidator
    
    project_path = path or Path.cwd()
    
    if not project_path.exists():
        console.print(f"[bold red]✗ Error: Path {project_path} does not exist[/bold red]")
        raise typer.Exit(code=1)
    
    validator = ProjectValidator(project_path)
    is_ready = validator.validate_all()
    
    if is_ready:
        raise typer.Exit(code=0)
    else:
        raise typer.Exit(code=1)


@app.command("upgrade")
def upgrade(
    project_path: Optional[str] = typer.Argument(
        None, help="Path to project (defaults to current directory)"
    ),
    to_version: Optional[str] = typer.Option(
        None, "--to-version", help="Target version (defaults to latest)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview changes without applying them"
    ),
    force: bool = typer.Option(
        False, "--force", help="Skip git status checks"
    ),
    only_safe: bool = typer.Option(
        False,
        "--only-safe",
        help="Abort when upgrade contains high/critical risk codemods or manual-review steps",
    ),
    interactive: bool = typer.Option(
        False, "--interactive", help="Confirm each codemod before applying"
    ),
    skip_verification: bool = typer.Option(
        False, "--skip-verification", help="Skip post-upgrade verification checks"
    ),
):
    """Upgrade a project to a newer template version."""
    
    if not run_upgrade(
        project_path=project_path,
        to_version=to_version,
        dry_run=dry_run,
        force=force,
        only_safe=only_safe,
        interactive=interactive,
        skip_verification=skip_verification,
    ):
        log_event("COMMAND", "upgrade")
        raise typer.Exit(code=1)
    log_event("COMMAND", "upgrade")


@app.command("preflight")
def preflight(
    fix: bool = typer.Option(
        False, "--fix", help="Print fix instructions for any failed checks"
    ),
):
    """Check cross-platform environment prerequisites (token, Python, git, Docker, network).

    Runs environment verification checks ported from legacy PowerShell scripts (SSA-14).
    Exit code 0 when all checks pass, 1 when any check fails.
    """
    from foundry.commands.verify import print_results, run_env_checks

    results = run_env_checks()
    log_event("COMMAND", "preflight")
    print_results(results, fix=fix)
    if any(r.status == "FAIL" for r in results.values()):
        raise typer.Exit(code=1)


@app.command("check-compliance")
def check_compliance(
    path: Path = typer.Option(
        Path("."),
        "--path",
        help="Project directory to check (defaults to current directory)",
    ),
):
    """Validate a project directory for Seed & Source architectural compliance (SSA-17).

    Checks: Dockerfile, docker-compose.yml, README, secret exposure, hardcoded
    localhost, license presence, and .gitignore coverage for .env files.
    Exit code 0 when no FAIL results (WARNs allowed), 1 when any FAIL.
    """
    from foundry.commands.compliance import print_compliance_results, run_compliance_checks

    target = path.resolve()
    if not target.is_dir():
        console.print(f"[red]✗ Error: {target} is not a directory[/red]")
        raise typer.Exit(code=1)
    results = run_compliance_checks(target)
    log_event("COMMAND", "check-compliance")
    print_compliance_results(results)
    if any(r.status == "FAIL" for r in results.values()):
        raise typer.Exit(code=1)