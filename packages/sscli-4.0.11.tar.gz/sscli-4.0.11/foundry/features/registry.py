"""SSA-67: Feature registry — defines injectable features and their tier gates.

All features are documented here with:
- name: feature key (used in --features flag)
- tier: minimum tier required ('free', 'alpha', 'pro')
- templates: which templates support this feature
- description: shown in sscli features list
- stable: False if still in beta rollout
- coming_soon: if True, CLI displays a coming-soon message instead
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class Feature:
    name: str
    tier: str
    templates: List[str]
    description: str
    stable: bool = True
    coming_soon: bool = False


# Registry of injectable features keyed by feature name.
# These augment the existing FEATURES_REGISTRY in constants.py with
# structured metadata for the registry module.
FEATURES: dict[str, Feature] = {
    "shopify-embedded": Feature(
        name="shopify-embedded",
        tier="pro",
        templates=["react-client"],
        description=(
            "Shopify App Bridge embedded app support "
            "(App Bridge 3.x, Polaris, session tokens)"
        ),
        stable=True,  # Stable as of v4.0.0 rollout
        coming_soon=False,
    ),
}


def get_feature(name: str) -> Feature | None:
    """Return a Feature by name, or None if not found."""
    return FEATURES.get(name)


def list_features(
    tier: str | None = None,
    template: str | None = None,
) -> list[Feature]:
    """Return features optionally filtered by accessible tier and/or template."""
    tier_order = {"free": 0, "alpha": 1, "pro": 2, "enterprise": 3}
    features = list(FEATURES.values())
    if tier:
        user_level = tier_order.get(tier, 0)
        features = [
            f for f in features
            if tier_order.get(f.tier, 99) <= user_level
        ]
    if template:
        features = [f for f in features if template in f.templates]
    return features
