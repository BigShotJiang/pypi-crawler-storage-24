# Sentry error tracking and observability for sscli
# SSA-58: CLI telemetry with GDPR compliance

import os
import sys
import sentry_sdk
from sentry_sdk.integrations.logging import LoggingIntegration

def init_sentry():
    """
    Initialize Sentry for the sscli CLI.

    - Disabled if SENTRY_DSN is not set (safe for local dev)
    - Respects SSCLI_NO_TELEMETRY=1 environment variable (GDPR/privacy)
    - Logs integration captures application logs and structured errors
    - Captures 10% of transactions for performance monitoring
    - Never sends PII (email, usernames) to Sentry (GDPR compliance)
    - Release tracking enabled for version identification
    """
    sentry_dsn = os.getenv("SENTRY_DSN", "").strip()
    no_telemetry = os.getenv("SSCLI_NO_TELEMETRY", "0").strip() == "1"

    if not sentry_dsn or no_telemetry:
        return  # Sentry disabled

    try:
        sentry_sdk.init(
            dsn=sentry_dsn,
            integrations=[
                LoggingIntegration(
                    level=None,  # Capture all log levels
                    event_level=None,  # Capture logs as structured data
                ),
            ],
            traces_sample_rate=0.1,  # Capture 10% of transactions
            send_default_pii=False,  # GDPR: Never send PII
            environment=os.getenv("APP_ENV", "development"),
            release=os.getenv("APP_RELEASE", "unknown"),  # Version tracking
            enable_tracing=True,  # Enable distributed tracing
        )
    except Exception:
        pass  # Silently fail if Sentry init fails (never break CLI startup)
