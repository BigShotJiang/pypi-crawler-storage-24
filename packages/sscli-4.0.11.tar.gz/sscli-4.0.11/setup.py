from setuptools import setup, find_packages

setup(
    name="sscli",
    version="3.1.3",
    description="Seed & Source CLI - Multi-stack application generator with golden standards and Hexagonal architecture",
    long_description=open("README.md").read() if open("README.md").name else "",
    packages=find_packages(include=["foundry*"], exclude=["foundry.ops*", "foundry.alpha*"]),
    package_data={
        "": ["*.md", "*.json"],
    },
    entry_points={
        "console_scripts": [
            "sscli=foundry.manage:app",
        ],
    },
    install_requires=[
        "typer>=0.12.3",
        "rich",
        "questionary",
        "requests",
        "python-dotenv",
        "pydantic>=2.0.0",
        "tomlkit>=0.12.0",
        "pyyaml>=6.0",
        "packaging",
        "libcst>=0.4.0",
    ],
    python_requires=">=3.9",
)
