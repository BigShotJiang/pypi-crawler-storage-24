import json
import subprocess
from pathlib import Path

import pytest

from foundry.actions.ast_grep_runner import AstGrepRunner, AstGrepError, ensure_ast_grep_available


def test_ast_grep_runner_unavailable(monkeypatch, tmp_path):
    monkeypatch.setattr(AstGrepRunner, "_locate_ast_grep", lambda self: None)
    runner = AstGrepRunner(rule_dir=tmp_path)
    assert runner.is_available() is False
    assert runner.get_version() is None


def test_validate_rule_missing(tmp_path):
    runner = AstGrepRunner(rule_dir=tmp_path)
    ok, err = runner.validate_rule("nope")
    assert ok is False
    assert "not found" in err


def test_validate_rule_invalid_yaml(tmp_path, monkeypatch):
    rule_dir = tmp_path
    rule_file = rule_dir / "bad.yml"
    rule_file.write_text(":")
    runner = AstGrepRunner(rule_dir=rule_dir)
    ok, err = runner.validate_rule("bad")
    assert ok is False
    assert "Invalid YAML" in err or "Rule is empty" in err


def test_inject_rule_missing_target(tmp_path, monkeypatch):
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"
    assert runner.inject_rule(tmp_path / "missing.astro", "rule") is False


def test_inject_rule_success(tmp_path, monkeypatch):
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "index.astro"
    target.write_text("<main>$$$/PRICING_COMPONENT</main>")

    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"

    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    class FakeResult:
        returncode = 0
        stdout = "ok"
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    assert runner.inject_rule(target, "rule", content_vars={"PRICING_COMPONENT": "<X />"}) is True


def test_parse_file_success(tmp_path, monkeypatch):
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"

    class FakeResult:
        returncode = 0
        stdout = json.dumps({"ast": "ok"})
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    assert runner.parse_file(tmp_path / "x.astro") == {"ast": "ok"}


def test_parse_file_not_available(tmp_path):
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = None

    assert runner.parse_file(tmp_path / "x.astro") is None


def test_get_rule_info(tmp_path):
    rule_dir = tmp_path
    (rule_dir / "rule.yml").write_text("id: rule\nlanguage: astro\nmessage: hi\n")
    runner = AstGrepRunner(rule_dir=rule_dir)
    info = runner.get_rule_info("rule")
    assert info["id"] == "rule"
    assert info["language"] == "astro"


def test_get_rule_info_missing_file(tmp_path):
    """Test get_rule_info with non-existent rule file (line 320)."""
    rule_dir = tmp_path
    runner = AstGrepRunner(rule_dir=rule_dir)
    # This should hit line 320 (return None when file doesn't exist)
    info = runner.get_rule_info("nonexistent")
    assert info is None


def test_list_available_rules(tmp_path):
    (tmp_path / "a.yml").write_text("id: a\n")
    (tmp_path / "b.yml").write_text("id: b\n")
    runner = AstGrepRunner(rule_dir=tmp_path)
    assert runner.list_available_rules() == ["a", "b"]


def test_list_available_rules_missing_dir(tmp_path):
    runner = AstGrepRunner(rule_dir=tmp_path / "missing")
    assert runner.list_available_rules() == []


def test_ensure_ast_grep_available_when_missing(monkeypatch, tmp_path):
    monkeypatch.setattr(AstGrepRunner, "_locate_ast_grep", lambda self: None)
    assert ensure_ast_grep_available() is False


def test_inject_rule_ast_grep_error(tmp_path, monkeypatch):
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "index.astro"
    target.write_text("<main>$$$/PRICING_COMPONENT</main>")

    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"

    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    class FakeResult:
        returncode = 2
        stdout = ""
        stderr = "bad"

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())

    assert runner.inject_rule(target, "rule", content_vars={"PRICING_COMPONENT": "<X />"}) is False


def test_inject_rule_timeout(tmp_path, monkeypatch):
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "index.astro"
    target.write_text("<main>$$$/PRICING_COMPONENT</main>")

    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    def _raise_timeout(*_args, **_kwargs):
        raise subprocess.TimeoutExpired(cmd=["sg"], timeout=30)

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", _raise_timeout)

    assert runner.inject_rule(target, "rule", content_vars={"PRICING_COMPONENT": "<X />"}) is False


def test_get_version_success(tmp_path, monkeypatch):
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"

    class FakeResult:
        returncode = 0
        stdout = "ast-grep 0.20.0"
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())

    assert runner.get_version() == "ast-grep 0.20.0"


def test_get_version_exception(tmp_path, monkeypatch):
    """Test get_version when subprocess.run raises exception (lines 95-96)."""
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"

    def _raise(*_args, **_kwargs):
        raise RuntimeError("subprocess failed")

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", _raise)
    assert runner.get_version() is None


def test_get_version_nonzero_returncode(tmp_path, monkeypatch):
    """Test get_version when returncode is not 0."""
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"

    class FakeResult:
        returncode = 1
        stdout = ""
        stderr = "error"

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    assert runner.get_version() is None


def test_validate_rule_empty_yaml(tmp_path):
    """Test validate_rule with empty YAML file (line 119)."""
    rule_dir = tmp_path
    (rule_dir / "empty.yml").write_text("")
    runner = AstGrepRunner(rule_dir=rule_dir)
    ok, err = runner.validate_rule("empty")
    assert ok is False
    assert "empty" in err


def test_inject_rule_not_available(tmp_path, monkeypatch):
    """Test inject_rule raises AstGrepError when ast-grep not available (line 151)."""
    monkeypatch.setattr(AstGrepRunner, "_locate_ast_grep", lambda self: None)
    runner = AstGrepRunner(rule_dir=tmp_path)
    
    target = tmp_path / "test.astro"
    target.write_text("<main></main>")

    with pytest.raises(AstGrepError, match="ast-grep is not installed"):
        runner.inject_rule(target, "rule")


def test_inject_rule_file_not_found(tmp_path, monkeypatch):
    """Test inject_rule with non-existent target file (lines 156-157)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    
    missing_file = tmp_path / "missing.astro"
    assert runner.inject_rule(missing_file, "rule") is False


def test_inject_rule_invalid_rule(tmp_path, monkeypatch):
    """Test inject_rule with invalid rule (lines 162-163)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    # Don't create the rule file so validation fails
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    
    target = tmp_path / "test.astro"
    target.write_text("<main></main>")
    
    # This should fail validation and hit lines 162-163
    assert runner.inject_rule(target, "nonexistent_rule") is False


def test_inject_rule_content_vars_exception(tmp_path, monkeypatch):
    """Test inject_rule when content_vars processing fails (lines 174-176)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "test.astro"
    target.write_text("<main>$$$/VAR</main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    # Make write_text fail
    original_write = Path.write_text
    def failing_write(self, *args, **kwargs):
        if "test.astro" in str(self):
            raise IOError("Write failed")
        return original_write(self, *args, **kwargs)
    
    monkeypatch.setattr(Path, "write_text", failing_write)
    
    result = runner.inject_rule(target, "rule", content_vars={"VAR": "<X />"})
    assert result is False


def test_inject_rule_interactive_mode(tmp_path, monkeypatch):
    """Test inject_rule with interactive mode (lines 188-192)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "test.astro"
    target.write_text("<main></main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    calls = []
    class FakeResult:
        returncode = 0
        stdout = "ok"
        stderr = ""

    def track_call(*args, **kwargs):
        calls.append(args)
        return FakeResult()

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", track_call)
    
    result = runner.inject_rule(target, "rule", auto_accept=False, dry_run=False)
    assert result is True
    assert "--interactive" in calls[0][0]


def test_inject_rule_dry_run_console_print(tmp_path, monkeypatch):
    """Test inject_rule dry_run prints command (line 197)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "test.astro"
    target.write_text("<main></main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    class FakeResult:
        returncode = 0
        stdout = ""
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    
    result = runner.inject_rule(target, "rule", dry_run=True)
    assert result is True


def test_inject_rule_generic_exception(tmp_path, monkeypatch):
    """Test inject_rule generic exception handling (lines 218-221)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "test.astro"
    target.write_text("<main></main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    def _raise(*args, **kwargs):
        raise ValueError("Generic error")

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", _raise)
    
    result = runner.inject_rule(target, "rule")
    assert result is False


def test_inject_rule_batch_success(tmp_path, monkeypatch):
    """Test inject_rule_batch with multiple files (lines 245-258)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    file1 = tmp_path / "file1.astro"
    file2 = tmp_path / "file2.astro"
    file1.write_text("<main></main>")
    file2.write_text("<main></main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    class FakeResult:
        returncode = 0
        stdout = "ok"
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    
    successes, failures = runner.inject_rule_batch([file1, file2], "rule")
    assert successes == 2
    assert failures == 0


def test_inject_rule_batch_with_failures(tmp_path, monkeypatch):
    """Test inject_rule_batch with mixed success/failure."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    file1 = tmp_path / "file1.astro"
    file2 = tmp_path / "missing.astro"  # Does not exist
    file1.write_text("<main></main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    class FakeResult:
        returncode = 0
        stdout = "ok"
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    
    successes, failures = runner.inject_rule_batch([file1, file2], "rule")
    assert successes == 1
    assert failures == 1


def test_inject_rule_batch_exception(tmp_path, monkeypatch):
    """Test inject_rule_batch when inject_rule raises exception."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    file1 = tmp_path / "file1.astro"
    file1.write_text("<main></main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    
    # Make inject_rule raise exception
    def _failing_inject(*args, **kwargs):
        raise RuntimeError("Inject failed")
    
    monkeypatch.setattr(runner, "inject_rule", _failing_inject)
    
    successes, failures = runner.inject_rule_batch([file1], "rule")
    assert successes == 0
    assert failures == 1


def test_parse_file_exception(tmp_path, monkeypatch):
    """Test parse_file when subprocess raises exception (lines 287-292)."""
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"

    def _raise(*args, **kwargs):
        raise RuntimeError("Parse failed")

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", _raise)
    
    result = runner.parse_file(tmp_path / "test.astro")
    assert result is None


def test_parse_file_nonzero_returncode(tmp_path, monkeypatch):
    """Test parse_file when ast-grep returns error."""
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"

    class FakeResult:
        returncode = 1
        stdout = ""
        stderr = "parse error"

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    
    result = runner.parse_file(tmp_path / "test.astro")
    assert result is None


def test_test_rule(tmp_path, monkeypatch):
    """Test test_rule method (line 305)."""
    rule_dir = tmp_path / "rules"
    rule_dir.mkdir()
    (rule_dir / "rule.yml").write_text("id: rule\n")

    target = tmp_path / "test.astro"
    target.write_text("<main></main>")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    runner._ast_grep_path = "sg"
    monkeypatch.setattr(runner, "validate_rule", lambda name: (True, None))

    class FakeResult:
        returncode = 0
        stdout = "match found"
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    
    result = runner.test_rule("rule", target)
    assert result is True


def test_get_rule_info_yaml_exception(tmp_path, monkeypatch):
    """Test get_rule_info when YAML parsing fails (lines 320, 333-336)."""
    rule_dir = tmp_path
    # Create file with invalid YAML that causes parsing exception
    (rule_dir / "bad.yml").write_text("{\n")  # Unclosed bracket causes yaml.scanner.ScannerError
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    info = runner.get_rule_info("bad")
    # Should handle exception and return None
    assert info is None


def test_get_rule_info_file_open_exception(tmp_path, monkeypatch):
    """Test get_rule_info when file open raises exception (line 320)."""
    rule_dir = tmp_path
    (rule_dir / "file.yml").write_text("id: test\n")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    
    # Mock open to raise exception
    import builtins
    original_open = builtins.open
    def failing_open(file, *args, **kwargs):
        if "file.yml" in str(file):
            raise OSError("Cannot open file")
        return original_open(file, *args, **kwargs)
    
    monkeypatch.setattr("builtins.open", failing_open)
    
    info = runner.get_rule_info("file")
    assert info is None


def test_get_rule_info_not_dict(tmp_path):
    """Test get_rule_info when YAML is not a dict."""
    rule_dir = tmp_path
    (rule_dir / "list.yml").write_text("- item1\n- item2\n")
    
    runner = AstGrepRunner(rule_dir=rule_dir)
    info = runner.get_rule_info("list")
    assert info is None


def test_ensure_ast_grep_available_when_available(monkeypatch, tmp_path):
    """Test ensure_ast_grep_available when ast-grep is available (lines 365-367)."""
    runner = AstGrepRunner(rule_dir=tmp_path)
    runner._ast_grep_path = "sg"
    
    class FakeResult:
        returncode = 0
        stdout = "ast-grep 0.20.0"
        stderr = ""

    monkeypatch.setattr("foundry.actions.ast_grep_runner.subprocess.run", lambda *a, **k: FakeResult())
    monkeypatch.setattr("foundry.actions.ast_grep_runner.shutil.which", lambda x: "sg")
    
    result = ensure_ast_grep_available()
    assert result is True
