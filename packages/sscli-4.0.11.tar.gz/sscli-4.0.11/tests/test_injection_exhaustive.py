"""
Exhaustive tests for all injection paths in foundry.actions.features.

Coverage targets:
- inject_features()          : every feature flag branch (commerce, tunnel, auth,
                               landing, admin, sqlite, ingestor, merchant_dashboard)
- inject_merchant_dashboard(): file copy, route injection, import injection, env vars
- _inject_sqlite_config()    : duplicate-guard idempotency
- _inject_commerce_env_vars(): duplicate-guard idempotency
- _inject_tunnel_config()    : env, compose, readme mutations + idempotency
- _inject_landing_instructions(): readme append + idempotency
- _inject_rails_routes_fallback(): injection + idempotency + missing file guard
- AST-injection flag         : success, exception-fallback
"""

import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock, call

from foundry.actions.features import (
    inject_features,
    inject_merchant_dashboard,
    _inject_sqlite_config,
    _inject_commerce_env_vars,
    _inject_tunnel_config,
    _inject_landing_instructions,
    _inject_rails_routes_fallback,
)


# ---------------------------------------------------------------------------
# Shared helpers / fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def project(tmp_path) -> Path:
    """A minimal project directory with common files."""
    p = tmp_path / "app"
    p.mkdir()
    (p / ".env").write_text("DEBUG=true\n")
    (p / ".env.example").write_text("DEBUG=true\n")
    (p / "README.md").write_text("# App\n")
    return p


@pytest.fixture
def rails_project(project: Path) -> Path:
    """Extends project fixture with Rails directory layout."""
    config = project / "config"
    config.mkdir()
    (config / "routes.rb").write_text(
        "Rails.application.routes.draw do\n  root to: 'home#index'\nend\n"
    )
    return project


@pytest.fixture
def react_project(project: Path) -> Path:
    """Extends project fixture with React/Vite layout."""
    src = project / "src"
    src.mkdir()
    (src / "App.jsx").write_text(
        "import React from 'react';\n"
        "\n"
        "function App() {\n"
        "  return (\n"
        "    <Routes>\n"
        "      <Route path='/' element={<Home />} />\n"
        "    </Routes>\n"
        "  );\n"
        "}\n"
        "\n"
        "export default App;\n"
    )
    return project


@pytest.fixture
def astro_project(project: Path) -> Path:
    """Extends project fixture with Astro layout."""
    pages = project / "src" / "pages"
    pages.mkdir(parents=True)
    (pages / "index.astro").write_text(
        "---\n// frontmatter\n---\n<main>Hello</main>\n"
    )
    styles = project / "src" / "styles"
    styles.mkdir(parents=True)
    (styles / "themes.css").write_text(":root { --color: blue; }\n")
    return project


# ── Patch helper: blocks _perform_feature_injection (vault reads) globally ─────
_NO_VAULT = "foundry.actions.features._perform_feature_injection"


# ===========================================================================
# 1.  _inject_sqlite_config — basic + idempotency + missing .env
# ===========================================================================

class TestInjectSqliteConfig:
    def test_injects_database_url_into_env(self, project: Path):
        _inject_sqlite_config(project)
        content = (project / ".env").read_text()
        assert "DATABASE_URL=sqlite+aiosqlite" in content

    def test_injects_into_env_example(self, project: Path):
        _inject_sqlite_config(project)
        content = (project / ".env.example").read_text()
        assert "DATABASE_URL=sqlite+aiosqlite" in content

    def test_idempotent_does_not_duplicate(self, project: Path):
        _inject_sqlite_config(project)
        _inject_sqlite_config(project)
        content = (project / ".env").read_text()
        assert content.count("DATABASE_URL") == 1

    def test_missing_env_does_not_raise(self, tmp_path):
        # No .env files at all — must not raise
        _inject_sqlite_config(tmp_path)


# ===========================================================================
# 2.  _inject_commerce_env_vars — basic + idempotency + missing .env
# ===========================================================================

class TestInjectCommerceEnvVars:
    def test_injects_shopify_vars(self, project: Path):
        _inject_commerce_env_vars(project)
        content = (project / ".env").read_text()
        assert "SHOPIFY_SHOP_NAME" in content
        assert "SHOPIFY_API_KEY" in content
        assert "COMMERCE_IDEMPOTENCY_ENABLED" in content

    def test_injects_into_env_example(self, project: Path):
        _inject_commerce_env_vars(project)
        assert "SHOPIFY_SHOP_NAME" in (project / ".env.example").read_text()

    def test_idempotent_does_not_duplicate(self, project: Path):
        _inject_commerce_env_vars(project)
        _inject_commerce_env_vars(project)
        count = (project / ".env").read_text().count("SHOPIFY_SHOP_NAME")
        assert count == 1

    def test_missing_env_does_not_raise(self, tmp_path):
        _inject_commerce_env_vars(tmp_path)


# ===========================================================================
# 3.  _inject_tunnel_config — env var, docker-compose, readme + idempotency
# ===========================================================================

class TestInjectTunnelConfig:
    def test_adds_ngrok_token_to_env(self, project: Path):
        _inject_tunnel_config(project, "python-saas")
        assert "NGROK_AUTHTOKEN" in (project / ".env").read_text()

    def test_adds_ngrok_token_to_env_example(self, project: Path):
        _inject_tunnel_config(project, "python-saas")
        assert "NGROK_AUTHTOKEN" in (project / ".env.example").read_text()

    def test_appends_tunnel_service_to_compose(self, project: Path):
        (project / "docker-compose.yml").write_text(
            "services:\n  python-saas:\n    image: python:3.12\n"
        )
        _inject_tunnel_config(project, "python-saas")
        content = (project / "docker-compose.yml").read_text()
        assert "tunnel:" in content
        assert "ngrok/ngrok" in content

    def test_compose_uses_correct_port_for_python_saas(self, project: Path):
        (project / "docker-compose.yml").write_text("services:\n  api:\n    image: x\n")
        _inject_tunnel_config(project, "python-saas")
        assert "8080" in (project / "docker-compose.yml").read_text()

    def test_compose_uses_correct_port_for_rails(self, project: Path):
        (project / "docker-compose.yml").write_text("services:\n  api:\n    image: x\n")
        _inject_tunnel_config(project, "rails-api")
        assert "3000" in (project / "docker-compose.yml").read_text()

    def test_appends_readme_section(self, project: Path):
        _inject_tunnel_config(project, "python-saas")
        assert "## 🌐 Local Tunneling" in (project / "README.md").read_text()

    def test_idempotent_env_no_duplicate(self, project: Path):
        _inject_tunnel_config(project, "python-saas")
        _inject_tunnel_config(project, "python-saas")
        assert (project / ".env").read_text().count("NGROK_AUTHTOKEN") == 1

    def test_idempotent_compose_no_duplicate(self, project: Path):
        (project / "docker-compose.yml").write_text("services:\n  api:\n    image: x\n")
        _inject_tunnel_config(project, "rails-api")
        _inject_tunnel_config(project, "rails-api")
        assert (project / "docker-compose.yml").read_text().count("tunnel:") == 1

    def test_missing_compose_does_not_raise(self, project: Path):
        _inject_tunnel_config(project, "python-saas")

    def test_missing_readme_does_not_raise(self, tmp_path: Path):
        (tmp_path / ".env").write_text("X=1")
        _inject_tunnel_config(tmp_path, "python-saas")


# ===========================================================================
# 4.  _inject_landing_instructions — basic + idempotency + missing readme
# ===========================================================================

class TestInjectLandingInstructions:
    def test_injects_astro_section_into_readme(self, project: Path):
        _inject_landing_instructions(project)
        assert "## 🚀 Static Landing Page" in (project / "README.md").read_text()

    def test_includes_npm_commands(self, project: Path):
        _inject_landing_instructions(project)
        assert "npm run dev" in (project / "README.md").read_text()

    def test_missing_readme_does_not_raise(self, tmp_path: Path):
        _inject_landing_instructions(tmp_path)


# ===========================================================================
# 5.  _inject_rails_routes_fallback — basic + idempotency + missing file
# ===========================================================================

class TestInjectRailsRoutesFallback:
    def test_injects_webhook_namespace(self, rails_project: Path):
        _inject_rails_routes_fallback(rails_project)
        content = (rails_project / "config" / "routes.rb").read_text()
        assert "namespace :webhooks" in content

    def test_injects_shopify_post_route(self, rails_project: Path):
        _inject_rails_routes_fallback(rails_project)
        content = (rails_project / "config" / "routes.rb").read_text()
        assert "post 'shopify'" in content

    def test_output_is_valid_ruby_structure(self, rails_project: Path):
        """The file must still end with 'end' and not leave dangling blocks."""
        _inject_rails_routes_fallback(rails_project)
        content = (rails_project / "config" / "routes.rb").read_text()
        # Every opened 'do' or 'namespace ... do' should have a matching 'end'
        assert content.strip().endswith("end")

    def test_idempotent_no_duplicate_namespace(self, rails_project: Path):
        _inject_rails_routes_fallback(rails_project)
        _inject_rails_routes_fallback(rails_project)
        count = (rails_project / "config" / "routes.rb").read_text().count("namespace :webhooks")
        assert count == 1

    def test_missing_routes_file_does_not_raise(self, tmp_path: Path):
        _inject_rails_routes_fallback(tmp_path)


# ===========================================================================
# 6.  inject_merchant_dashboard — route, import, env vars, idempotency
# ===========================================================================

class TestInjectMerchantDashboard:
    def test_injects_import_into_app_jsx(self, react_project: Path):
        with patch("foundry.actions.features.FOUNDRY_ROOT", react_project):
            inject_merchant_dashboard(react_project)
        app = (react_project / "src" / "App.jsx").read_text()
        assert "MerchantDashboard" in app

    def test_injects_route_into_routes_block(self, react_project: Path):
        with patch("foundry.actions.features.FOUNDRY_ROOT", react_project):
            inject_merchant_dashboard(react_project)
        app = (react_project / "src" / "App.jsx").read_text()
        assert "/dashboard" in app

    def test_injects_vite_env_vars(self, react_project: Path):
        with patch("foundry.actions.features.FOUNDRY_ROOT", react_project):
            inject_merchant_dashboard(react_project)
        env = (react_project / ".env").read_text()
        assert "VITE_API_BASE_URL" in env
        assert "VITE_DASHBOARD_ENABLED" in env

    def test_injects_into_env_example(self, react_project: Path):
        with patch("foundry.actions.features.FOUNDRY_ROOT", react_project):
            inject_merchant_dashboard(react_project)
        env = (react_project / ".env.example").read_text()
        assert "VITE_API_BASE_URL" in env

    def test_idempotent_import_not_duplicated(self, react_project: Path):
        with patch("foundry.actions.features.FOUNDRY_ROOT", react_project):
            inject_merchant_dashboard(react_project)
            inject_merchant_dashboard(react_project)
        app = (react_project / "src" / "App.jsx").read_text()
        assert app.count("MerchantDashboard") <= 3  # import + 1-2 JSX usages

    def test_idempotent_env_not_duplicated(self, react_project: Path):
        with patch("foundry.actions.features.FOUNDRY_ROOT", react_project):
            inject_merchant_dashboard(react_project)
            inject_merchant_dashboard(react_project)
        env = (react_project / ".env").read_text()
        assert env.count("VITE_API_BASE_URL") == 1

    def test_missing_app_jsx_does_not_raise(self, project: Path):
        """Merchant dashboard must degrade gracefully when App.jsx is absent."""
        with patch("foundry.actions.features.FOUNDRY_ROOT", project):
            inject_merchant_dashboard(project)

    def test_missing_env_does_not_raise(self, tmp_path: Path):
        src = tmp_path / "src"
        src.mkdir()
        (src / "App.jsx").write_text("import React from 'react';\n")
        with patch("foundry.actions.features.FOUNDRY_ROOT", tmp_path):
            inject_merchant_dashboard(tmp_path)


# ===========================================================================
# 7.  inject_features() — every feature flag branch
# ===========================================================================

class TestInjectFeaturesDispatcher:
    """Tests for inject_features() using mocks to isolate the dispatch logic."""

    # ── commerce ──────────────────────────────────────────────────────────

    @patch("foundry.actions.features._inject_astro_commerce")
    @patch("foundry.actions.features._inject_rails_commerce_routes")
    @patch("foundry.actions.features._inject_commerce_env_vars")
    @patch(_NO_VAULT)
    def test_commerce_python_saas(self, mock_vault, mock_env, mock_rails, mock_astro, project):
        inject_features(project, "python-saas", commerce=True, tunnel=False)
        mock_vault.assert_any_call(project, "python-saas", "commerce")
        mock_env.assert_called_once()
        mock_rails.assert_not_called()
        mock_astro.assert_not_called()

    @patch("foundry.actions.features._inject_astro_commerce")
    @patch("foundry.actions.features._inject_rails_commerce_routes")
    @patch("foundry.actions.features._inject_commerce_env_vars")
    @patch(_NO_VAULT)
    def test_commerce_rails(self, mock_vault, mock_env, mock_rails, mock_astro, rails_project):
        inject_features(rails_project, "rails-api", commerce=True, tunnel=False)
        mock_rails.assert_called_once_with(rails_project)
        mock_astro.assert_not_called()

    @patch("foundry.actions.features._inject_astro_commerce")
    @patch("foundry.actions.features._inject_rails_commerce_routes")
    @patch("foundry.actions.features._inject_commerce_env_vars")
    @patch(_NO_VAULT)
    def test_commerce_static_landing(self, mock_vault, mock_env, mock_rails, mock_astro, astro_project):
        inject_features(astro_project, "static-landing", commerce=True, tunnel=False)
        mock_astro.assert_called_once_with(astro_project)
        mock_rails.assert_not_called()

    # ── tunnel ────────────────────────────────────────────────────────────

    @patch("foundry.actions.features._inject_tunnel_config")
    @patch(_NO_VAULT)
    def test_tunnel_calls_injector(self, mock_vault, mock_tunnel, project):
        inject_features(project, "python-saas", commerce=False, tunnel=True)
        mock_tunnel.assert_called_once_with(project, "python-saas")

    @patch("foundry.actions.features._inject_tunnel_config")
    @patch(_NO_VAULT)
    def test_tunnel_false_does_not_call_injector(self, mock_vault, mock_tunnel, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False)
        mock_tunnel.assert_not_called()

    # ── auth ──────────────────────────────────────────────────────────────

    @patch("foundry.actions.features._inject_astro_auth")
    @patch(_NO_VAULT)
    def test_auth_static_landing_calls_astro_auth(self, mock_vault, mock_auth, astro_project):
        inject_features(astro_project, "static-landing", commerce=False, tunnel=False, auth=True)
        mock_auth.assert_called_once_with(astro_project)

    @patch("foundry.actions.features._inject_astro_auth")
    @patch(_NO_VAULT)
    def test_auth_python_saas_does_not_call_astro_auth(self, mock_vault, mock_auth, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, auth=True)
        mock_auth.assert_not_called()

    # ── landing (for non-landing templates) ───────────────────────────────

    @patch("foundry.actions.features._inject_landing_instructions")
    @patch(_NO_VAULT)
    def test_landing_flag_injects_instructions(self, mock_vault, mock_landing_instr, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, landing=True)
        mock_landing_instr.assert_called_once_with(project)

    @patch("foundry.actions.features._inject_landing_instructions")
    @patch(_NO_VAULT)
    def test_landing_flag_false_no_instructions(self, mock_vault, mock_landing_instr, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, landing=False)
        mock_landing_instr.assert_not_called()

    # Static-landing template always injects components+themes regardless of flag
    @patch("foundry.actions.features._inject_landing_instructions")
    @patch(_NO_VAULT)
    def test_static_landing_template_injects_components_and_themes(
        self, mock_vault, mock_instr, astro_project
    ):
        inject_features(astro_project, "static-landing", commerce=False, tunnel=False)
        calls = mock_vault.call_args_list
        paths_called = [(c.args[1], c.args[2]) for c in calls]
        assert ("landing", "components") in paths_called
        assert ("landing", "themes") in paths_called

    # ── admin ─────────────────────────────────────────────────────────────

    @patch("foundry.actions.features._inject_python_dependencies")
    @patch(_NO_VAULT)
    def test_admin_injects_nicegui_dependency(self, mock_vault, mock_deps, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, admin=True)
        mock_deps.assert_called_once_with(project, ["nicegui"])

    @patch("foundry.actions.features._inject_python_dependencies")
    @patch(_NO_VAULT)
    def test_admin_false_no_dependency_injection(self, mock_vault, mock_deps, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, admin=False)
        mock_deps.assert_not_called()

    # ── sqlite ────────────────────────────────────────────────────────────

    @patch("foundry.actions.features._inject_python_dependencies")
    @patch("foundry.actions.features._inject_sqlite_config")
    @patch(_NO_VAULT)
    def test_sqlite_injects_config_and_dependencies(
        self, mock_vault, mock_sqlite_cfg, mock_deps, project
    ):
        inject_features(project, "python-saas", commerce=False, tunnel=False, sqlite=True)
        mock_sqlite_cfg.assert_called_once_with(project)
        mock_deps.assert_called_once()
        deps = mock_deps.call_args.args[1]
        assert "sqlalchemy" in deps

    @patch("foundry.actions.features._inject_sqlite_config")
    @patch(_NO_VAULT)
    def test_sqlite_false_no_config(self, mock_vault, mock_sqlite_cfg, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, sqlite=False)
        mock_sqlite_cfg.assert_not_called()

    # ── ingestor ──────────────────────────────────────────────────────────

    @patch(_NO_VAULT)
    def test_ingestor_calls_vault(self, mock_vault, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, ingestor=True)
        mock_vault.assert_any_call(project, "python-saas", "data-ingestor")

    @patch(_NO_VAULT)
    def test_ingestor_false_does_not_call_vault(self, mock_vault, project):
        inject_features(project, "python-saas", commerce=False, tunnel=False, ingestor=False)
        called_features = [c.args[2] for c in mock_vault.call_args_list]
        assert "data-ingestor" not in called_features

    # ── merchant_dashboard ────────────────────────────────────────────────

    @patch("foundry.actions.features.inject_merchant_dashboard")
    @patch(_NO_VAULT)
    def test_merchant_dashboard_react_calls_injector(
        self, mock_vault, mock_md, react_project
    ):
        inject_features(
            react_project, "react-client",
            commerce=False, tunnel=False, merchant_dashboard=True
        )
        mock_md.assert_called_once_with(react_project)

    @patch("foundry.actions.features.inject_merchant_dashboard")
    @patch(_NO_VAULT)
    def test_merchant_dashboard_wrong_template_skips_injector(
        self, mock_vault, mock_md, project
    ):
        inject_features(
            project, "python-saas",
            commerce=False, tunnel=False, merchant_dashboard=True
        )
        mock_md.assert_not_called()

    # ── use_ast_injection ─────────────────────────────────────────────────

    @patch("foundry.actions.features.inject_features_ast")
    @patch(_NO_VAULT)
    def test_ast_injection_flag_routes_to_ast_function(
        self, mock_vault, mock_ast, project
    ):
        mock_ast.return_value = {"success": True, "changes": [], "errors": [], "skipped": []}
        inject_features(
            project, "python-saas",
            commerce=True, tunnel=True,
            use_ast_injection=True
        )
        mock_ast.assert_called_once()
        # Since AST succeeded, the vault-based injector should NOT be called
        mock_vault.assert_not_called()

    @patch("foundry.actions.features._inject_commerce_env_vars")
    @patch(_NO_VAULT)
    @patch("foundry.actions.features.inject_features_ast")
    def test_ast_injection_exception_falls_back_to_string_markers(
        self, mock_ast, mock_vault, mock_env, project
    ):
        mock_ast.side_effect = RuntimeError("libcst broke")
        inject_features(
            project, "python-saas",
            commerce=True, tunnel=False,
            use_ast_injection=True
        )
        # Must have fallen through to string-marker path
        mock_vault.assert_any_call(project, "python-saas", "commerce")

    @patch("foundry.actions.features.inject_features_ast")
    @patch(_NO_VAULT)
    def test_ast_injection_builds_correct_features_dict(
        self, mock_vault, mock_ast, project
    ):
        mock_ast.return_value = {"success": True, "changes": [], "errors": [], "skipped": []}
        inject_features(
            project, "python-saas",
            commerce=True, tunnel=True, admin=True,
            use_ast_injection=True
        )
        call_kwargs = mock_ast.call_args[1]
        features = call_kwargs["features"]
        # AST injection uses structured operations, not boolean flags
        assert "imports" in features or "calls" in features or "dependencies" in features
        assert "tunnel" not in features  # No AST mapping for tunnel

        import_modules = {imp["module"] for imp in features.get("imports", [])}
        assert "foundry_commerce" in import_modules
        assert "nicegui_admin" in import_modules


# ===========================================================================
# 8.  inject_features_ast() — template routing + unknown template error
# ===========================================================================

class TestInjectFeaturesAst:
    def test_unknown_template_returns_failure(self, project: Path):
        from foundry.actions.features import inject_features_ast
        result = inject_features_ast(project, "unknown-template", {})
        assert result["success"] is False
        assert result["errors"]

    @patch("foundry.actions.features._inject_react_codemods")
    def test_react_client_routes_to_react_codemods(self, mock_react, project: Path):
        from foundry.actions.features import inject_features_ast
        mock_react.return_value = {"success": True, "changes": [], "errors": [], "skipped": []}
        inject_features_ast(project, "react-client", {})
        mock_react.assert_called_once()

    @patch("foundry.actions.features._inject_python_saas_codemods")
    def test_python_saas_routes_to_python_codemods(self, mock_py, project: Path):
        from foundry.actions.features import inject_features_ast
        mock_py.return_value = {"success": True, "changes": [], "errors": [], "skipped": []}
        inject_features_ast(project, "python-saas", {})
        mock_py.assert_called_once()

    @patch("foundry.actions.features._inject_rails_codemods")
    def test_rails_api_routes_to_rails_codemods(self, mock_rails, project: Path):
        from foundry.actions.features import inject_features_ast
        mock_rails.return_value = {"success": True, "changes": [], "errors": [], "skipped": []}
        inject_features_ast(project, "rails-api", {})
        mock_rails.assert_called_once()

    @patch("foundry.actions.features._inject_python_saas_codemods")
    def test_exception_in_codemod_captured_gracefully(self, mock_py, project: Path):
        from foundry.actions.features import inject_features_ast
        mock_py.side_effect = RuntimeError("cst crashed")
        result = inject_features_ast(project, "python-saas", {})
        assert result["success"] is False
        assert "cst crashed" in result["errors"][0]
