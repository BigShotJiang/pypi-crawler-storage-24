"""
Comprehensive tests for foundry.commands.auth module.

Tests:
- auth login command
- auth logout command  
- whoami command (run_whoami)
- Successful and failed authentication flows
- User tier display
- Organization membership display
- License status handling (active, expired)
"""

import pytest
from unittest.mock import patch, MagicMock, call
from foundry.commands import auth as auth_commands


class TestAuthLogin:
    """Test auth login command."""
    
    @patch("foundry.commands.auth.login_flow")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_login_success(self, mock_get_license, mock_login_flow):
        """Test successful login flow."""
        mock_login_flow.return_value = True
        mock_get_license.side_effect = [
            {"authorized": False},              # first call: not yet logged in
            {"tier": "pro", "authorized": True}, # second call: after successful login
        ]
        
        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.auth_login()
            
            # Should call login flow
            mock_login_flow.assert_called_once()
            
            # Should get license info twice (pre-check + post-login)
            assert mock_get_license.call_count == 2
            
            # Should print success message
            print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
            assert any("authenticated" in str(call_obj).lower() for call_obj in print_calls)
            assert any("PRO" in str(call_obj) for call_obj in print_calls)
    
    @patch("foundry.commands.auth.login_flow")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_login_cancelled(self, mock_get_license, mock_login_flow):
        """Test login flow cancelled by user."""
        mock_login_flow.return_value = False
        mock_get_license.return_value = {"authorized": False}
        
        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.auth_login()
            
            # Should print warning message
            print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
            assert any("completed" in str(call_obj).lower() for call_obj in print_calls)
    
    @patch("foundry.commands.auth.login_flow")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_login_alpha_tier(self, mock_get_license, mock_login_flow):
        """Test login with alpha tier."""
        mock_login_flow.return_value = True
        mock_get_license.side_effect = [
            {"authorized": False},                # first call: not yet logged in
            {"tier": "alpha", "authorized": True}, # second call: after successful login
        ]
        
        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.auth_login()
            
            # Should show ALPHA tier
            print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
            assert any("ALPHA" in str(call_obj) for call_obj in print_calls)
    
    @patch("foundry.commands.auth.login_flow")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_login_exception_handling(self, mock_get_license, mock_login_flow):
        """Test exception handling during login."""
        mock_get_license.return_value = {"authorized": False}  # not already logged in
        mock_login_flow.side_effect = Exception("Network error")
        
        # Should propagate exception (or handle it gracefully)
        with pytest.raises(Exception):
            auth_commands.auth_login()

    @patch("foundry.commands.auth.save_credentials")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_login_with_token_success(self, mock_get_license, mock_save_credentials):
        """Test token-based login succeeds when token validates."""
        mock_get_license.return_value = {"authorized": True, "tier": "pro"}

        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.auth_login(token="ghu_example")

            mock_save_credentials.assert_called_once()
            mock_get_license.assert_called_once_with(verify=True)
            print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
            assert any("authenticated" in str(call_obj).lower() for call_obj in print_calls)
            assert any("PRO" in str(call_obj) for call_obj in print_calls)

    @patch("foundry.commands.auth.save_credentials")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_login_with_token_failure(self, mock_get_license, mock_save_credentials):
        """Test token-based login shows explicit failure for invalid token."""
        mock_get_license.return_value = {"authorized": False}

        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.auth_login(token="ghu_invalid")

            mock_save_credentials.assert_called_once()
            mock_get_license.assert_called_once_with(verify=True)
            print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
            assert any("invalid token" in str(call_obj).lower() for call_obj in print_calls)


class TestAuthLogout:
    """Test auth logout command."""
    
    @patch("foundry.commands.auth.logout")
    def test_logout_success(self, mock_logout):
        """Test successful logout."""
        auth_commands.auth_logout()
        
        # Should call logout
        mock_logout.assert_called_once()
    
    @patch("foundry.commands.auth.logout")
    def test_logout_exception_handling(self, mock_logout):
        """Test exception handling during logout."""
        mock_logout.side_effect = Exception("Credential file error")
        
        # Should propagate exception
        with pytest.raises(Exception):
            auth_commands.auth_logout()


class TestRunWhoami:
    """Test run_whoami command."""
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_not_logged_in(self, mock_get_license):
        """Test whoami when not logged in."""
        mock_get_license.return_value = None
        
        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.run_whoami()
            
            # Should print not logged in message
            mock_print.assert_called_once()
            assert "Not logged in" in str(mock_print.call_args)
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_unauthorized(self, mock_get_license):
        """Test whoami when unauthorized."""
        mock_get_license.return_value = {"authorized": False}
        
        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.run_whoami()
            
            # Should print not logged in message
            assert "Not logged in" in str(mock_print.call_args)
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_free_tier_no_org(self, mock_get_license):
        """Test whoami for free tier user without organization."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "free",
            "status": "active",
            "org_name": None
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            auth_commands.run_whoami()
            
            # Should display tier as "FREE"
            assert mock_console_instance.print.called
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_pro_tier_with_org(self, mock_get_license):
        """Test whoami for pro tier user with organization."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "pro",
            "status": "active",
            "org_name": "Acme Corp"
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            auth_commands.run_whoami()
            
            # Should display tier with org name
            assert mock_console_instance.print.called
            # The display should include "PRO (via Acme Corp)"
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_expired_status(self, mock_get_license):
        """Test whoami with expired license."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "pro",
            "status": "expired",
            "org_name": None
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            auth_commands.run_whoami()
            
            # Should show status with red color (status_color = "red")
            assert mock_console_instance.print.called
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_alpha_tier(self, mock_get_license):
        """Test whoami for alpha tier user."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "alpha",
            "status": "active",
            "org_name": "Internal Team"
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            auth_commands.run_whoami()
            
            # Should display "ALPHA (via Internal Team)"
            assert mock_console_instance.print.called
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_verify_called(self, mock_get_license):
        """Test that get_current_license_info is called with verify=True."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "pro",
            "status": "active"
        }
        
        with patch("foundry.commands.auth.Console"):
            auth_commands.run_whoami()
            
            # Should call with verify=True
            mock_get_license.assert_called_once_with(verify=True)


class TestAuthAppTyper:
    """Test the Typer app configuration."""
    
    def test_auth_app_exists(self):
        """Test that auth_app Typer instance exists."""
        assert hasattr(auth_commands, "auth_app")
        assert auth_commands.auth_app is not None
    
    def test_auth_app_has_login_command(self):
        """Test that login command is registered."""
        # The command should be decorated with @auth_app.command("login")
        assert hasattr(auth_commands, "auth_login")
        assert callable(auth_commands.auth_login)
    
    def test_auth_app_has_logout_command(self):
        """Test that logout command is registered."""
        assert hasattr(auth_commands, "auth_logout")
        assert callable(auth_commands.auth_logout)


class TestEdgeCases:
    """Test edge cases and error scenarios."""
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_missing_tier_field(self, mock_get_license):
        """Test whoami when tier field is missing."""
        mock_get_license.return_value = {
            "authorized": True,
            "status": "active"
            # tier field missing
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            auth_commands.run_whoami()
            
            # Should handle gracefully with default "free"
            assert mock_console_instance.print.called
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_missing_status_field(self, mock_get_license):
        """Test whoami when status field is missing."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "pro"
            # status field missing
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            # Should handle missing status gracefully
            try:
                auth_commands.run_whoami()
            except KeyError:
                # Document that this might fail - needs .get() with default
                pytest.skip("Missing status handling not implemented")
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_empty_org_name(self, mock_get_license):
        """Test whoami with empty string org_name."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "pro",
            "status": "active",
            "org_name": ""
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            auth_commands.run_whoami()
            
            # Empty string should be falsy, so no org display
            assert mock_console_instance.print.called
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_exception_in_get_license(self, mock_get_license):
        """Test whoami when get_current_license_info raises exception."""
        mock_get_license.side_effect = Exception("License server unreachable")
        
        # Should propagate or handle gracefully
        with pytest.raises(Exception):
            auth_commands.run_whoami()


class TestBehaviorIntegration:
    """Test behavioral integration of auth commands (telemetry removed in commit 05a0a63)."""
    
    @patch("foundry.commands.auth.login_flow")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_login_invokes_flow(self, mock_get_license, mock_login_flow):
        """Test that login invokes login_flow when not already authenticated."""
        mock_login_flow.return_value = False
        mock_get_license.return_value = {"authorized": False}
        
        with patch.object(auth_commands.console, "print"):
            auth_commands.auth_login()
            
            mock_login_flow.assert_called_once()
    
    @patch("foundry.commands.auth.logout")
    def test_logout_calls_logout_function(self, mock_logout):
        """Test that auth_logout calls the underlying logout function."""
        auth_commands.auth_logout()
        
        mock_logout.assert_called_once()
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_whoami_calls_get_license_with_verify(self, mock_get_license):
        """Test that whoami calls get_current_license_info with verify=True."""
        mock_get_license.return_value = None
        
        with patch.object(auth_commands.console, "print"):
            auth_commands.run_whoami()
            
            mock_get_license.assert_called_once_with(verify=True)


class TestRichIntegration:
    """Test Rich console and panel integration."""
    
    @patch("foundry.commands.auth.get_current_license_info")
    def test_panel_created_for_authenticated_user(self, mock_get_license):
        """Test that Panel is created for authenticated user."""
        mock_get_license.return_value = {
            "authorized": True,
            "tier": "pro",
            "status": "active"
        }
        
        with patch("foundry.commands.auth.Console") as mock_console_class, \
             patch("foundry.commands.auth.Panel") as mock_panel_class:
            mock_console_instance = MagicMock()
            mock_console_class.return_value = mock_console_instance
            
            auth_commands.run_whoami()
            
            # Panel should be created
            assert mock_panel_class.called
            # Console should print the panel
            assert mock_console_instance.print.called
    
    @patch("foundry.commands.auth.login_flow")
    @patch("foundry.commands.auth.get_current_license_info")
    def test_console_colors_in_login(self, mock_get_license, mock_login_flow):
        """Test that console uses Rich markup in login."""
        mock_login_flow.return_value = True
        mock_get_license.side_effect = [
            {"authorized": False},               # first call: not yet logged in
            {"tier": "pro", "authorized": True},  # second call: after successful login
        ]
        
        with patch.object(auth_commands.console, "print") as mock_print:
            auth_commands.auth_login()
            
            # Should use [green] for success
            print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
            assert any("[green]" in str(call_obj) for call_obj in print_calls)


class TestCommandDocstrings:
    """Test that commands have proper docstrings."""
    
    def test_auth_login_docstring(self):
        """Test that auth_login has docstring."""
        assert auth_commands.auth_login.__doc__ is not None
        assert "login" in auth_commands.auth_login.__doc__.lower()
    
    def test_auth_logout_docstring(self):
        """Test that auth_logout has docstring."""
        assert auth_commands.auth_logout.__doc__ is not None
        assert "logout" in auth_commands.auth_logout.__doc__.lower()
    
    def test_run_whoami_docstring(self):
        """Test that run_whoami has docstring."""
        assert auth_commands.run_whoami.__doc__ is not None
