import shutil
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from foundry.actions.features import (
    setup_secrets,
    inject_features,
    _perform_feature_injection,
    _inject_python_dependencies,
    _inject_sqlite_config,
    _inject_commerce_env_vars,
    _inject_astro_themes
)

@pytest.fixture
def mock_foundry_root(tmp_path):
    root = tmp_path / "foundry"
    root.mkdir()
    
    # Create features vault
    features = root / "features"
    features.mkdir()
    
    # Generic feature
    tunnel = features / "tunnel"
    tunnel.mkdir()
    (tunnel / "tunnel-config.json").write_text('{"tunnel": true}')
    
    # Template specific feature
    python_commerce = features / "python-saas" / "commerce"
    python_commerce.mkdir(parents=True)
    (python_commerce / "commerce_logic.py").write_text("def commerce(): pass")
    
    # Astro themes
    astro_themes = features / "landing" / "themes"
    astro_themes.mkdir(parents=True)
    (astro_themes / "themes.css").write_text(".premium-theme { color: gold; }")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", root):
        yield root

def test_setup_secrets_dotenv(tmp_path):
    # Setup .env.example
    (tmp_path / ".env.example").write_text("KEY=VALUE")
    
    setup_secrets(tmp_path, "Dotenv")
    
    assert (tmp_path / ".env").exists()
    assert (tmp_path / ".env").read_text() == "KEY=VALUE"

def test_setup_secrets_doppler(tmp_path):
    setup_secrets(tmp_path, "Doppler")
    
    assert (tmp_path / "doppler.yaml").exists()
    assert "project: my-project" in (tmp_path / "doppler.yaml").read_text()

def test_perform_feature_injection_generic(mock_foundry_root, tmp_path):
    project_path = tmp_path / "my-project"
    project_path.mkdir()
    
    _perform_feature_injection(project_path, "python-saas", "tunnel")
    
    assert (project_path / "tunnel-config.json").exists()
    assert (project_path / "tunnel-config.json").read_text() == '{"tunnel": true}'

def test_perform_feature_injection_template_specific(mock_foundry_root, tmp_path):
    project_path = tmp_path / "my-project"
    project_path.mkdir()
    
    _perform_feature_injection(project_path, "python-saas", "commerce")
    
    assert (project_path / "commerce_logic.py").exists()

def test_inject_python_dependencies(tmp_path):
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("[tool.poetry.dependencies]\npython = '^3.9'\n")
    
    _inject_python_dependencies(tmp_path, ["requests", "flask"])
    
    content = pyproject.read_text()
    assert "requests =" in content
    assert "flask =" in content

def test_inject_sqlite_config(tmp_path):
    env_file = tmp_path / ".env"
    env_file.write_text("DEBUG=true\n")
    
    _inject_sqlite_config(tmp_path)
    
    content = env_file.read_text()
    assert "DATABASE_URL=sqlite+aiosqlite" in content

def test_inject_commerce_env_vars(tmp_path):
    env_file = tmp_path / ".env"
    env_file.write_text("PORT=8000\n")
    
    _inject_commerce_env_vars(tmp_path)
    
    content = env_file.read_text()
    assert "SHOPIFY_SHOP_NAME" in content
    assert "COMMERCE_IDEMPOTENCY_ENABLED" in content

@patch("foundry.actions.features.AstGrepRunner")
def test_inject_astro_themes(mock_runner_class, mock_foundry_root, tmp_path):
    # Setup project themes file
    themes_dir = tmp_path / "src" / "styles"
    themes_dir.mkdir(parents=True)
    themes_file = themes_dir / "themes.css"
    themes_file.write_text(":root { --primary: blue; }")
    
    # Mock runner
    mock_runner = MagicMock()
    mock_runner.is_available.return_value = True
    mock_runner.inject_rule.return_value = True
    mock_runner_class.return_value = mock_runner
    
    _inject_astro_themes(tmp_path)
    
    assert mock_runner.inject_rule.called

def test_inject_features_simple(mock_foundry_root, tmp_path):
    # Test a simple feature injection (tunnel)
    project_path = tmp_path / "my-project"
    project_path.mkdir()
    
    inject_features(
        path=project_path,
        template="python-saas",
        commerce=False,
        tunnel=True
    )
    
    assert (project_path / "tunnel-config.json").exists()
