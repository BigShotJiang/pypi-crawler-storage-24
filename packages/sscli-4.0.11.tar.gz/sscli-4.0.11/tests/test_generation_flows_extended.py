"""
Extended generation-flow tests.

Covers scenarios NOT already tested in test_generator_coverage.py:
  - Project-name / app_name validation (inject_metadata raises on bad names)
  - Target path collision: non-empty → blocked (existing); empty dir → allowed
  - check_feature_tier_access: real tier comparisons, unknown feature, coming-soon guard
  - check_tier_access: free/pro/enterprise/invalid tiers
  - validate_and_fix_pyproject: valid file, missing version, malformed bytes
  - download_template: checksum match/mismatch, network error, dest dir creation,
    missing header
  - _write_fingerprint: file written, overwrite, parent dir auto-created, no-op on None
  - initialize_github_repo: success, git failure, unauthenticated gh, remote-exists stderr,
    invalid visibility
"""
import hashlib
import subprocess
import tarfile
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
import requests


# =============================================================================
# TestRunGeneratorProjectNameValidation
# =============================================================================


class TestRunGeneratorProjectNameValidation:
    """inject_metadata rejects bad app names; generator.py blocks path-traversal
    in target_dir_name before any download is attempted."""

    def test_spaces_in_name_raise_value_error(self, tmp_path):
        """'my app' has a space and fails _APP_NAME_RE → ValueError."""
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError, match=r"Invalid app_name"):
            inject_metadata(tmp_path, "python-saas", "my app")

    def test_at_sign_in_name_raises_value_error(self, tmp_path):
        """'my@app!' contains @ and ! → ValueError."""
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError, match=r"Invalid app_name"):
            inject_metadata(tmp_path, "python-saas", "my@app!")

    def test_slash_in_name_raises_value_error(self, tmp_path):
        """'some/path' is not a valid project name → ValueError."""
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError, match=r"Invalid app_name"):
            inject_metadata(tmp_path, "python-saas", "some/path")

    def test_empty_string_raises_value_error(self, tmp_path):
        """Empty string app_name fails regex match → ValueError."""
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError, match=r"Invalid app_name"):
            inject_metadata(tmp_path, "python-saas", "")

    def test_path_traversal_in_target_dir_rejected(self, tmp_path, monkeypatch):
        """target_dir_name='../evil' resolves outside cwd → error printed,
        download_template is never called."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr("foundry.actions.generator.check_tier_access", lambda *a: True)
        download = MagicMock()
        monkeypatch.setattr("foundry.actions.generator.download_template", download)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name="python-saas", app_name="app", target_dir_name="../evil")

        assert any("must resolve within" in str(m) for m in printed)
        download.assert_not_called()

    def test_valid_hyphenated_name_passes(self, tmp_path):
        """Hyphenated name with digits satisfies _APP_NAME_RE; no exception raised."""
        from foundry.actions.generation_utils import inject_metadata

        # No files to rewrite in an empty tmp_path, but validation must not raise.
        inject_metadata(tmp_path, "python-saas", "my-project-123")


# =============================================================================
# TestRunGeneratorTargetPathCollision
# =============================================================================


class TestRunGeneratorTargetPathCollision:
    """Collision handling: empty existing dirs are allowed; non-empty dirs stop
    the run before any download occurs."""

    def _patch_base(self, monkeypatch):
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr("foundry.actions.generator.check_tier_access", lambda *a: True)

    def test_empty_existing_dir_proceeds_to_download(self, tmp_path, monkeypatch):
        """A pre-existing but empty target directory is not treated as a collision;
        download_template is called."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        self._patch_base(monkeypatch)

        target = tmp_path / "empty-project"
        target.mkdir()  # exists, but has no children

        download = MagicMock(return_value=False)  # return False to halt after first call
        monkeypatch.setattr("foundry.actions.generator.download_template", download)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(
            template_name="python-saas",
            app_name="empty-project",
            target_dir_name=str(target),
        )

        download.assert_called_once()
        assert not any("already exists" in str(m) for m in printed)

    def test_non_empty_existing_dir_blocked_no_download(self, tmp_path, monkeypatch):
        """A pre-existing non-empty target directory triggers an error message and
        returns before any download is attempted."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        self._patch_base(monkeypatch)

        target = tmp_path / "collision-project"
        target.mkdir()
        (target / "some_file.py").write_text("# already here")

        download = MagicMock()
        monkeypatch.setattr("foundry.actions.generator.download_template", download)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(
            template_name="python-saas",
            app_name="collision-project",
            target_dir_name=str(target),
        )

        assert any("already exists" in str(m) for m in printed)
        download.assert_not_called()


# =============================================================================
# TestCheckFeatureTierAccess
# =============================================================================


class TestCheckFeatureTierAccess:
    """Unit tests for generation_utils.check_feature_tier_access.

    Patches is_internal_dev (local import inside the function, must be patched at
    source: foundry.utils.is_internal_dev) and get_current_license_info (module-level
    import, patch at foundry.actions.generation_utils.get_current_license_info).
    """

    def _patch(self, monkeypatch, user_tier: str):
        monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: False)
        monkeypatch.setattr(
            "foundry.actions.generation_utils.get_current_license_info",
            lambda verify=False: {"tier": user_tier},
        )

    def test_pro_feature_blocked_for_free_user(self, monkeypatch):
        """commerce requires 'pro'; free-tier user → returns False."""
        from foundry.actions.generation_utils import check_feature_tier_access

        self._patch(monkeypatch, "free")
        assert check_feature_tier_access("commerce") is False

    def test_pro_feature_allowed_for_pro_user(self, monkeypatch):
        """commerce requires 'pro'; pro-tier user has enough rank → returns True."""
        from foundry.actions.generation_utils import check_feature_tier_access

        self._patch(monkeypatch, "pro")
        assert check_feature_tier_access("commerce") is True

    def test_pro_feature_allowed_for_enterprise_user(self, monkeypatch):
        """enterprise > pro, so enterprise user can access any pro feature."""
        from foundry.actions.generation_utils import check_feature_tier_access

        self._patch(monkeypatch, "enterprise")
        assert check_feature_tier_access("commerce") is True

    def test_unknown_feature_allowed_by_default(self, monkeypatch):
        """Unknown feature key is not in FEATURES_REGISTRY → returns True
        (will fail at injection time, not at the gate)."""
        from foundry.actions.generation_utils import check_feature_tier_access

        self._patch(monkeypatch, "free")
        assert check_feature_tier_access("nonexistent_xyz_feature") is True

    def test_internal_dev_bypasses_all_checks(self, monkeypatch):
        """is_internal_dev=True causes an unconditional True regardless of tier."""
        from foundry.actions.generation_utils import check_feature_tier_access

        monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
        # No license mock needed — function returns before touching it.
        assert check_feature_tier_access("commerce") is True

    def test_coming_soon_flag_blocks_generator_early(self, tmp_path, monkeypatch):
        """A feature present in DISABLED_FEATURES_POLICY causes run_generator to
        print a 'coming soon' message and return before download_template is called."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "foundry.actions.generator.DISABLED_FEATURES_POLICY",
            {"auth": {"flag": "--with-auth", "message": "Auth is coming soon."}},
        )
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr("foundry.actions.generator.check_tier_access", lambda *a: True)
        download = MagicMock()
        monkeypatch.setattr("foundry.actions.generator.download_template", download)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name="python-saas", app_name="app", with_auth=True)

        download.assert_not_called()
        assert any("coming soon" in str(m).lower() for m in printed)


# =============================================================================
# TestCheckTierAccess
# =============================================================================


class TestCheckTierAccess:
    """Unit tests for generation_utils.check_tier_access.

    Same patching rules as TestCheckFeatureTierAccess.
    """

    def _patch(self, monkeypatch, user_tier: str):
        monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: False)
        monkeypatch.setattr(
            "foundry.actions.generation_utils.get_current_license_info",
            lambda verify=False: {"tier": user_tier},
        )

    def test_free_user_blocked_from_pro_template(self, monkeypatch):
        """free (rank 0) < pro (rank 2) → returns False."""
        from foundry.actions.generation_utils import check_tier_access

        self._patch(monkeypatch, "free")
        assert check_tier_access("python-saas", "pro") is False

    def test_pro_user_allowed_pro_template(self, monkeypatch):
        """pro == pro → returns True."""
        from foundry.actions.generation_utils import check_tier_access

        self._patch(monkeypatch, "pro")
        assert check_tier_access("python-saas", "pro") is True

    def test_enterprise_user_allowed_pro_template(self, monkeypatch):
        """enterprise (rank 3) > pro (rank 2) → returns True."""
        from foundry.actions.generation_utils import check_tier_access

        self._patch(monkeypatch, "enterprise")
        assert check_tier_access("python-saas", "pro") is True

    def test_enterprise_user_allowed_free_template(self, monkeypatch):
        """enterprise can access free-tier templates."""
        from foundry.actions.generation_utils import check_tier_access

        self._patch(monkeypatch, "enterprise")
        assert check_tier_access("python-saas", "free") is True

    def test_alpha_user_blocked_from_pro_template(self, monkeypatch):
        """alpha (rank 1) < pro (rank 2) → returns False."""
        from foundry.actions.generation_utils import check_tier_access

        self._patch(monkeypatch, "alpha")
        assert check_tier_access("python-saas", "pro") is False

    def test_invalid_tier_string_defaults_to_zero_and_is_blocked(self, monkeypatch):
        """An unknown tier string maps to rank 0 in TIER_HIERARCHY.get(_, 0)
        and therefore cannot access pro templates."""
        from foundry.actions.generation_utils import check_tier_access

        self._patch(monkeypatch, "garbage_tier")
        assert check_tier_access("python-saas", "pro") is False

    def test_internal_dev_bypasses_tier_check(self, monkeypatch):
        """is_internal_dev=True returns True unconditionally."""
        from foundry.actions.generation_utils import check_tier_access

        monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
        assert check_tier_access("python-saas", "enterprise") is True


# =============================================================================
# TestValidateAndFixPyproject
# =============================================================================


class TestValidateAndFixPyproject:
    """Unit tests for generation_utils.validate_and_fix_pyproject."""

    def test_no_pyproject_is_noop(self, tmp_path, monkeypatch):
        """When pyproject.toml is absent the function returns without error
        and prints nothing."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )
        validate_and_fix_pyproject(tmp_path)
        assert printed == []

    def test_valid_file_preserved_and_validated_message_printed(self, tmp_path, monkeypatch):
        """A well-formed pyproject.toml is written back with its core values intact
        and a 'Validated' confirmation is printed."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        content = (
            '[tool.poetry]\n'
            'name = "myapp"\n'
            'version = "0.1.0"\n\n'
            '[tool.poetry.dependencies]\n'
            'python = "^3.11"\n'
        )
        (tmp_path / "pyproject.toml").write_text(content)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        validate_and_fix_pyproject(tmp_path)

        result = (tmp_path / "pyproject.toml").read_text()
        assert 'name = "myapp"' in result
        assert 'version = "0.1.0"' in result
        assert any("Validated" in str(m) for m in printed)

    def test_unquoted_dependency_version_gets_quoted(self, tmp_path, monkeypatch):
        """A bare version string like `python = ^3.11` (no quotes) is auto-quoted."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        content = (
            '[tool.poetry]\n'
            'name = "app"\n'
            'version = "0.1.0"\n\n'
            '[tool.poetry.dependencies]\n'
            'python = ^3.11\n'
        )
        (tmp_path / "pyproject.toml").write_text(content)
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda msg: None),
        )

        validate_and_fix_pyproject(tmp_path)

        result = (tmp_path / "pyproject.toml").read_text()
        assert '"^3.11"' in result

    def test_missing_version_in_tool_poetry_is_inserted(self, tmp_path, monkeypatch):
        """When [tool.poetry] is the last section and lacks a version field,
        the function inserts a default version = "0.1.0" line.

        The insertion guard checks `in_tool_poetry` after the loop, which is
        True only when [tool.poetry] is the last (or only) section in the file.
        """
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        # [tool.poetry] must be the last section so that `in_tool_poetry` is
        # still True when the post-loop insertion guard runs.
        content = '[tool.poetry]\nname = "app"\n'
        (tmp_path / "pyproject.toml").write_text(content)
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda msg: None),
        )

        validate_and_fix_pyproject(tmp_path)

        result = (tmp_path / "pyproject.toml").read_text()
        assert "version" in result

    def test_malformed_binary_file_does_not_crash(self, tmp_path, monkeypatch):
        """A file with non-UTF-8 bytes is caught and a warning is printed;
        no exception propagates to the caller."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        (tmp_path / "pyproject.toml").write_bytes(b"\xff\xfe malformed \x00\x01")
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        validate_and_fix_pyproject(tmp_path)  # must not raise

        assert any("Could not validate" in str(m) or "pyproject" in str(m) for m in printed)


# =============================================================================
# TestDownloadTemplateIntegrity
# =============================================================================


class TestDownloadTemplateIntegrity:
    """Tests for repo_utils.download_template covering the remote-download path:
    checksum verification, network failures, header validation, and directory creation."""

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _make_tar_gz(contents: dict) -> bytes:
        """Build a minimal in-memory .tar.gz from {relative_path: bytes}."""
        buf = BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as tar:
            for name, data in contents.items():
                info = tarfile.TarInfo(name=name)
                info.size = len(data)
                tar.addfile(info, BytesIO(data))
        return buf.getvalue()

    @staticmethod
    def _mock_response(body: bytes, checksum: str, status: int = 200):
        resp = MagicMock()
        resp.status_code = status
        resp.content = body
        resp.text = ""
        resp.headers = {
            "X-Template-Sha256": checksum,
            "X-Foundry-User-Id": "user-abc",
        }
        return resp

    def _common_patches(self, monkeypatch):
        monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
        monkeypatch.setattr(
            "foundry.actions.repo_utils.get_current_license_info",
            lambda verify=False: {"tier": "pro", "authorized": True},
        )
        monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok-123")
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: None),
        )

    # ------------------------------------------------------------------
    # Tests
    # ------------------------------------------------------------------

    def test_valid_checksum_returns_true(self, tmp_path, monkeypatch):
        """When X-Template-Sha256 matches the downloaded file, returns True."""
        from foundry.actions.repo_utils import download_template

        tar_bytes = self._make_tar_gz({"README.md": b"hello world"})
        checksum = hashlib.sha256(tar_bytes).hexdigest()
        resp = self._mock_response(tar_bytes, checksum)
        self._common_patches(monkeypatch)

        target = tmp_path / "out"
        with patch("foundry.actions.repo_utils.requests.get", return_value=resp):
            result = download_template("python-saas", {}, target)

        assert result is True
        assert target.exists()

    def test_checksum_mismatch_returns_false(self, tmp_path, monkeypatch):
        """When the file content doesn't match the X-Template-Sha256 header,
        returns False and prints a checksum-mismatch error."""
        from foundry.actions.repo_utils import download_template

        tar_bytes = self._make_tar_gz({"README.md": b"tampered content"})
        wrong_checksum = "a" * 64  # valid hex format but intentionally wrong
        resp = self._mock_response(tar_bytes, wrong_checksum)
        printed = []
        monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
        monkeypatch.setattr(
            "foundry.actions.repo_utils.get_current_license_info",
            lambda verify=False: {"tier": "pro", "authorized": True},
        )
        monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok-123")
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        target = tmp_path / "out"
        with patch("foundry.actions.repo_utils.requests.get", return_value=resp):
            result = download_template("python-saas", {}, target)

        assert result is False
        assert any("checksum mismatch" in str(m) for m in printed)

    def test_network_error_returns_false(self, tmp_path, monkeypatch):
        """A requests.RequestException during GET is caught; returns False and
        the error message is printed."""
        from foundry.actions.repo_utils import download_template

        printed = []
        monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
        monkeypatch.setattr(
            "foundry.actions.repo_utils.get_current_license_info",
            lambda verify=False: {"tier": "pro", "authorized": True},
        )
        monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok-123")
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        target = tmp_path / "out"
        with patch(
            "foundry.actions.repo_utils.requests.get",
            side_effect=requests.RequestException("connection refused"),
        ):
            result = download_template("python-saas", {}, target)

        assert result is False
        assert any("connection refused" in str(m) for m in printed)

    def test_destination_dir_created_when_absent(self, tmp_path, monkeypatch):
        """target_path is created by the function even when deeply nested
        directories don't yet exist."""
        from foundry.actions.repo_utils import download_template

        tar_bytes = self._make_tar_gz({"hello.txt": b"hi"})
        checksum = hashlib.sha256(tar_bytes).hexdigest()
        resp = self._mock_response(tar_bytes, checksum)
        self._common_patches(monkeypatch)

        new_target = tmp_path / "nested" / "path" / "project"
        assert not new_target.exists()

        with patch("foundry.actions.repo_utils.requests.get", return_value=resp):
            download_template("python-saas", {}, new_target)

        assert new_target.exists()

    def test_single_root_archive_is_flattened_into_target(self, tmp_path, monkeypatch):
        """Archives with one top-level folder (e.g. rails-api/...) are extracted
        directly into target_path without an extra nested directory."""
        from foundry.actions.repo_utils import download_template

        tar_bytes = self._make_tar_gz(
            {
                "rails-api/README.md": b"hello",
                "rails-api/app/main.rb": b"puts 'ok'",
            }
        )
        checksum = hashlib.sha256(tar_bytes).hexdigest()
        resp = self._mock_response(tar_bytes, checksum)
        self._common_patches(monkeypatch)

        target = tmp_path / "out"
        with patch("foundry.actions.repo_utils.requests.get", return_value=resp):
            result = download_template("rails-api", {}, target)

        assert result is True
        assert (target / "README.md").exists()
        assert (target / "app" / "main.rb").exists()
        assert not (target / "rails-api").exists()

    def test_repeated_root_prefixes_are_collapsed(self, tmp_path, monkeypatch):
        """Archives containing repeated root prefixes are normalized so no extra
        template-name folder remains at target root."""
        from foundry.actions.repo_utils import download_template

        tar_bytes = self._make_tar_gz(
            {
                "rails-api/README.md": b"hello",
                "rails-api/rails-api/app/main.rb": b"puts 'ok'",
            }
        )
        checksum = hashlib.sha256(tar_bytes).hexdigest()
        resp = self._mock_response(tar_bytes, checksum)
        self._common_patches(monkeypatch)

        target = tmp_path / "out"
        with patch("foundry.actions.repo_utils.requests.get", return_value=resp):
            result = download_template("rails-api", {}, target)

        assert result is True
        assert (target / "README.md").exists()
        assert (target / "app" / "main.rb").exists()
        assert not (target / "rails-api").exists()

    def test_missing_sha256_header_returns_false(self, tmp_path, monkeypatch):
        """A 200 response without X-Template-Sha256 header returns False
        and prints the missing-header error."""
        from foundry.actions.repo_utils import download_template

        resp = MagicMock()
        resp.status_code = 200
        resp.content = b"data"
        resp.text = ""
        resp.headers = {"X-Foundry-User-Id": "user-abc"}  # deliberately omit sha256

        printed = []
        monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
        monkeypatch.setattr(
            "foundry.actions.repo_utils.get_current_license_info",
            lambda verify=False: {"tier": "pro", "authorized": True},
        )
        monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok-123")
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        target = tmp_path / "out"
        with patch("foundry.actions.repo_utils.requests.get", return_value=resp):
            result = download_template("python-saas", {}, target)

        assert result is False
        assert any("X-Template-Sha256" in str(m) for m in printed)

    def test_non_200_status_returns_false(self, tmp_path, monkeypatch):
        """A non-200 HTTP status code returns False and prints the status."""
        from foundry.actions.repo_utils import download_template

        resp = MagicMock()
        resp.status_code = 403
        resp.content = b""
        resp.text = "Forbidden"
        resp.headers = {}

        printed = []
        monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
        monkeypatch.setattr(
            "foundry.actions.repo_utils.get_current_license_info",
            lambda verify=False: {"tier": "pro", "authorized": True},
        )
        monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok-123")
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        target = tmp_path / "out"
        with patch("foundry.actions.repo_utils.requests.get", return_value=resp):
            result = download_template("python-saas", {}, target)

        assert result is False
        assert any("403" in str(m) for m in printed)


# =============================================================================
# TestWriteFingerprint
# =============================================================================


class TestWriteFingerprint:
    """Unit tests for repo_utils._write_fingerprint.

    Fingerprint sidecar files were removed; function is now a no-op.
    """

    def test_owner_file_is_not_written(self, tmp_path):
        """Calling _write_fingerprint should not create .foundry/owner."""
        from foundry.actions.repo_utils import _write_fingerprint

        _write_fingerprint(tmp_path, "user-42")

        owner = tmp_path / ".foundry" / "owner"
        assert not owner.exists()

    def test_second_call_remains_noop(self, tmp_path):
        """Repeated calls are no-ops and create no files."""
        from foundry.actions.repo_utils import _write_fingerprint

        _write_fingerprint(tmp_path, "user-1")
        _write_fingerprint(tmp_path, "user-2")
        assert not (tmp_path / ".foundry" / "owner").exists()

    def test_parent_dir_not_created(self, tmp_path):
        """No .foundry directory should be created on disk."""
        from foundry.actions.repo_utils import _write_fingerprint

        nested = tmp_path / "brand-new-project"
        assert not nested.exists()

        _write_fingerprint(nested, "user-99")

        assert not (nested / ".foundry").exists()

    def test_none_user_id_is_noop(self, tmp_path):
        """When user_id is None, the function returns early and creates nothing."""
        from foundry.actions.repo_utils import _write_fingerprint

        _write_fingerprint(tmp_path, None)

        assert not (tmp_path / ".foundry").exists()

    def test_empty_string_user_id_is_noop(self, tmp_path):
        """An empty-string user_id is falsy and also skips file creation."""
        from foundry.actions.repo_utils import _write_fingerprint

        _write_fingerprint(tmp_path, "")

        assert not (tmp_path / ".foundry").exists()


# =============================================================================
# TestInitializeGithubRepo
# =============================================================================


class TestInitializeGithubRepo:
    """Tests for repo_utils.initialize_github_repo subprocess interactions.

    All subprocess.run calls are mocked so no real git or gh CLI invocations occur.
    """

    _CFG = {
        "owner": "myorg",
        "name": "my-repo",
        "description": "Test repo",
        "visibility": "private",
    }

    def test_all_steps_succeed_returns_true(self, tmp_path, monkeypatch):
        """When all subprocess calls return rc=0, the function returns True and
        prints a success message."""
        from foundry.actions.repo_utils import initialize_github_repo

        printed = []
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        def _success(cmd, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            return result

        with patch("foundry.actions.repo_utils.subprocess.run", side_effect=_success):
            result = initialize_github_repo(tmp_path, self._CFG)

        assert result is True
        assert any("Successfully" in str(m) for m in printed)

    def test_git_init_failure_returns_false_no_crash(self, tmp_path, monkeypatch):
        """A CalledProcessError from git init is caught; returns False and prints
        an error message without raising."""
        from foundry.actions.repo_utils import initialize_github_repo

        printed = []
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        def _fail_git_init(cmd, **kwargs):
            if "init" in cmd:
                raise subprocess.CalledProcessError(1, cmd)
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            return result

        with patch("foundry.actions.repo_utils.subprocess.run", side_effect=_fail_git_init):
            result = initialize_github_repo(tmp_path, self._CFG)

        assert result is False
        assert any("Error" in str(m) for m in printed)

    def test_gh_not_authenticated_returns_false(self, tmp_path, monkeypatch):
        """When gh auth status returns non-zero, returns False with a message
        about authentication; no git init is attempted."""
        from foundry.actions.repo_utils import initialize_github_repo

        printed = []
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        def _unauthenticated(cmd, **kwargs):
            result = MagicMock()
            if "auth" in cmd and "status" in cmd:
                result.returncode = 1
            else:
                result.returncode = 0
            result.stderr = ""
            return result

        with patch("foundry.actions.repo_utils.subprocess.run", side_effect=_unauthenticated):
            result = initialize_github_repo(tmp_path, self._CFG)

        assert result is False
        assert any(
            "not authenticated" in str(m).lower()
            or "gh" in str(m).lower()
            or "auth" in str(m).lower()
            for m in printed
        )

    def test_remote_origin_already_exists_in_stderr_returns_false(self, tmp_path, monkeypatch):
        """When gh repo create exits with rc=1 and 'remote origin already exists'
        in stderr, the function returns False and reports the failure."""
        from foundry.actions.repo_utils import initialize_github_repo

        printed = []
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        def _origin_exists(cmd, **kwargs):
            result = MagicMock()
            if "repo" in cmd and "create" in cmd:
                result.returncode = 1
                result.stderr = "error creating repo: remote origin already exists"
            else:
                result.returncode = 0
                result.stderr = ""
            return result

        with patch("foundry.actions.repo_utils.subprocess.run", side_effect=_origin_exists):
            result = initialize_github_repo(tmp_path, self._CFG)

        assert result is False
        assert any("Failed" in str(m) or "origin" in str(m) for m in printed)

    def test_invalid_visibility_rejected_before_subprocess(self, tmp_path, monkeypatch):
        """An invalid visibility string is caught immediately; no subprocess call
        is made and a helpful message is printed."""
        from foundry.actions.repo_utils import initialize_github_repo

        printed = []
        monkeypatch.setattr(
            "foundry.actions.repo_utils.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )
        bad_cfg = {**self._CFG, "visibility": "world"}

        with patch("foundry.actions.repo_utils.subprocess.run") as mock_run:
            result = initialize_github_repo(tmp_path, bad_cfg)

        assert result is False
        mock_run.assert_not_called()
        assert any("Invalid visibility" in str(m) for m in printed)
