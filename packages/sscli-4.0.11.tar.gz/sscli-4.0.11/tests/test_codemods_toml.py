import pytest
import tomlkit
from pathlib import Path
from foundry.codemods.toml_codemods import (
    AddPythonDependencyCM,
    RemovePythonDependencyCM,
    RemoveToolSectionsCM,
    UpdateValueCM,
    AddPythonVersionCM,
    IdempotentAddDependencyCM
)

@pytest.fixture
def sample_pyproject():
    return """
[project]
name = "test-project"
version = "0.1.0"
dependencies = [
    "requests>=2.28.0",
    "flask",
]

[tool.poetry]
name = "poetry-project"
dependencies = { python = "^3.10", "django" = "^4.0" }

[tool.ruff]
line-length = 88

[tool.mypy]
strict = true
"""

def test_add_python_dependency_project(sample_pyproject):
    doc = tomlkit.parse(sample_pyproject)
    codemod = AddPythonDependencyCM(["pytest"], version="7.0")
    new_doc = codemod.transform(doc)
    
    deps = new_doc["project"]["dependencies"]
    assert "pytest>=7.0" in deps
    assert "requests>=2.28.0" in deps

def test_add_python_dependency_poetry():
    # Test with poetry-only file
    content = '[tool.poetry.dependencies]\npython = "^3.10"'
    doc = tomlkit.parse(content)
    codemod = AddPythonDependencyCM(["requests"], version="^2.28")
    new_doc = codemod.transform(doc)
    
    assert new_doc["tool"]["poetry"]["dependencies"]["requests"] == "^2.28"

def test_remove_python_dependency(sample_pyproject):
    doc = tomlkit.parse(sample_pyproject)
    codemod = RemovePythonDependencyCM(["requests"])
    new_doc = codemod.transform(doc)
    
    deps = new_doc["project"]["dependencies"]
    assert not any("requests" in d for d in deps)
    assert "flask" in deps

def test_remove_tool_sections(sample_pyproject):
    doc = tomlkit.parse(sample_pyproject)
    codemod = RemoveToolSectionsCM(["ruff", "mypy"])
    new_doc = codemod.transform(doc)
    
    assert "ruff" not in new_doc["tool"]
    assert "mypy" not in new_doc["tool"]

def test_update_value(sample_pyproject):
    doc = tomlkit.parse(sample_pyproject)
    codemod = UpdateValueCM(["project", "version"], "0.2.0")
    new_doc = codemod.transform(doc)
    
    assert new_doc["project"]["version"] == "0.2.0"

def test_add_python_version(sample_pyproject):
    doc = tomlkit.parse(sample_pyproject)
    # project doesn't have requires-python, it will fallback to poetry
    codemod = AddPythonVersionCM("^3.11")
    new_doc = codemod.transform(doc)
    
    assert new_doc["tool"]["poetry"]["dependencies"]["python"] == "^3.11"

def test_idempotent_add_dependency(sample_pyproject):
    doc = tomlkit.parse(sample_pyproject)
    codemod = IdempotentAddDependencyCM(["requests"], version="3.0.0")
    # should NOT add because requests already exists (case-insensitive)
    new_doc = codemod.transform(doc)
    
    deps = new_doc["project"]["dependencies"]
    assert len(deps) == 2
    assert "requests>=2.28.0" in deps
    assert "requests>=3.0.0" not in deps


# ========== COMPREHENSIVE EDGE CASE TESTS FOR 95% COVERAGE ==========

def test_add_dependency_with_version_operator():
    """Test AddPythonDependencyCM with various version operators (lines 56, 64, 66)"""
    doc = tomlkit.parse('[project]\nname = "test"\ndependencies = []')
    
    # Test with >= operator
    codemod = AddPythonDependencyCM(["pytest"], version=">=7.0")
    new_doc = codemod.transform(doc)
    assert "pytest>=7.0" in new_doc["project"]["dependencies"]
    
    # Test with == operator
    codemod2 = AddPythonDependencyCM(["black"], version="==23.0")
    new_doc2 = codemod2.transform(new_doc)
    assert "black==23.0" in new_doc2["project"]["dependencies"]
    
    # Test with wildcard version
    codemod3 = AddPythonDependencyCM(["mypy"], version="*")
    new_doc3 = codemod3.transform(new_doc2)
    assert "mypy" in new_doc3["project"]["dependencies"]


def test_add_dependency_creates_poetry_sections_from_scratch():
    """Test AddPythonDependencyCM creating [tool.poetry] structure (lines 74, 78, 82)"""
    # Empty document - must create all sections
    doc = tomlkit.parse('')
    codemod = AddPythonDependencyCM(["requests"], version="^2.28")
    new_doc = codemod.transform(doc)
    
    assert "tool" in new_doc
    assert "poetry" in new_doc["tool"]
    assert "dependencies" in new_doc["tool"]["poetry"]
    assert new_doc["tool"]["poetry"]["dependencies"]["requests"] == "^2.28"
    
    # Document with tool but no poetry
    doc2 = tomlkit.parse('[tool.ruff]\nline-length = 88')
    codemod2 = AddPythonDependencyCM(["django"], version="^4.0")
    new_doc2 = codemod2.transform(doc2)
    
    assert "poetry" in new_doc2["tool"]
    assert new_doc2["tool"]["poetry"]["dependencies"]["django"] == "^4.0"


def test_remove_dependency_when_poetry_missing():
    """Test RemovePythonDependencyCM when poetry section missing (line 120)"""
    doc = tomlkit.parse('[project]\nname = "test"\ndependencies = ["requests"]')
    codemod = RemovePythonDependencyCM(["requests"])
    new_doc = codemod.transform(doc)
    
    deps = new_doc["project"]["dependencies"]
    assert len(deps) == 0


def test_remove_tool_sections_when_no_tool():
    """Test RemoveToolSectionsCM when [tool] missing (line 137)"""
    doc = tomlkit.parse('[project]\nname = "test"')
    codemod = RemoveToolSectionsCM(["ruff", "mypy"])
    new_doc = codemod.transform(doc)
    
    assert "tool" not in new_doc


def test_remove_tool_sections_leaves_empty_tool():
    """Test RemoveToolSectionsCM cleanup logic (line 146)"""
    doc = tomlkit.parse('[tool.ruff]\nline-length = 88')
    codemod = RemoveToolSectionsCM(["ruff"])
    new_doc = codemod.transform(doc)
    
    # Should remove [tool] entirely if empty
    assert "tool" not in new_doc


def test_update_value_with_missing_path():
    """Test UpdateValueCM with missing intermediate sections (lines 176-180)"""
    doc = tomlkit.parse('[project]\nname = "test"')
    
    # Try to update nested path that doesn't exist without create_missing
    codemod = UpdateValueCM(["tool", "poetry", "version"], "1.0.0", create_missing=False)
    new_doc = codemod.transform(doc)
    
    # Should not crash, just not create the path
    assert "tool" not in new_doc or "poetry" not in new_doc.get("tool", {})
    
    # Now with create_missing=True
    codemod2 = UpdateValueCM(["tool", "poetry", "version"], "1.0.0", create_missing=True)
    new_doc2 = codemod2.transform(doc)
    
    assert new_doc2["tool"]["poetry"]["version"] == "1.0.0"


def test_add_python_version_no_poetry():
    """Test AddPythonVersionCM when no poetry section exists (lines 199-202)"""
    doc = tomlkit.parse('[project]\nname = "test"')
    codemod = AddPythonVersionCM("^3.11")
    new_doc = codemod.transform(doc)
    
    # Should not crash when tool.poetry.dependencies missing
    assert "project" in new_doc


def test_add_python_version_with_requires_python():
    """Test AddPythonVersionCM with project.requires-python"""
    doc = tomlkit.parse('[project]\nname = "test"\nrequires-python = "^3.10"')
    codemod = AddPythonVersionCM("^3.11")
    new_doc = codemod.transform(doc)
    
    assert new_doc["project"]["requires-python"] == "^3.11"


def test_parse_dependency_complex():
    """Test parse_dependency with complex specs (lines 225-227)"""
    from foundry.codemods.toml_codemods import parse_dependency
    
    # Test with version specifier
    name, version = parse_dependency("requests>=2.28.0")
    assert name == "requests"
    assert version == ">=2.28.0"
    
    # Test with extras and version
    name2, version2 = parse_dependency("django[postgres]>=4.0")
    assert name2 == "django[postgres]"
    assert version2 == ">=4.0"
    
    # Test without version
    name3, version3 = parse_dependency("pytest")
    assert name3 == "pytest"
    assert version3 == "*"
    
    # Test with caret
    name4, version4 = parse_dependency("black^23.0")
    assert name4 == "black"
    assert version4 == "^23.0"


def test_idempotent_add_to_empty_project_section():
    """Test IdempotentAddDependencyCM with empty project (line 243)"""
    doc = tomlkit.parse('[project]\nname = "test"\ndependencies = []')
    codemod = IdempotentAddDependencyCM(["requests>=2.28.0"])
    new_doc = codemod.transform(doc)
    
    assert "requests>=2.28.0" in new_doc["project"]["dependencies"]


def test_idempotent_add_creates_poetry_from_scratch():
    """Test IdempotentAddDependencyCM creating poetry sections (lines 243-245)"""
    # Empty document
    doc = tomlkit.parse('')
    codemod = IdempotentAddDependencyCM(["requests"], version="^2.28")
    new_doc = codemod.transform(doc)
    
    assert "tool" in new_doc
    assert "poetry" in new_doc["tool"]
    assert "dependencies" in new_doc["tool"]["poetry"]
    assert new_doc["tool"]["poetry"]["dependencies"]["requests"] == "^2.28"


def test_idempotent_add_poetry_duplicate_detection():
    """Test IdempotentAddDependencyCM duplicate detection in poetry (lines 280-286)"""
    doc = tomlkit.parse('[tool.poetry.dependencies]\npython = "^3.10"\nrequests = "^2.28"')
    
    # Try to add Requests (different case) - should detect duplicate
    codemod = IdempotentAddDependencyCM(["Requests"], version="^3.0")
    new_doc = codemod.transform(doc)
    
    deps = new_doc["tool"]["poetry"]["dependencies"]
    # Should not add duplicate
    assert "Requests" not in deps  # Case-sensitive key check
    assert "requests" in deps
    assert deps["requests"] == "^2.28"  # Original version preserved


def test_idempotent_add_poetry_new_package():
    """Test IdempotentAddDependencyCM adding new package to poetry (lines 290-317)"""
    doc = tomlkit.parse('[tool.poetry.dependencies]\npython = "^3.10"')
    
    # Add various version formats
    codemod = IdempotentAddDependencyCM(["django>=4.0", "flask^2.0", "pytest"])
    new_doc = codemod.transform(doc)
    
    deps = new_doc["tool"]["poetry"]["dependencies"]
    assert "django" in deps
    assert "flask" in deps
    assert "pytest" in deps


def test_add_dependency_duplicate_case_insensitive():
    """Test AddPythonDependencyCM doesn't add duplicates case-insensitively"""
    doc = tomlkit.parse('[project]\ndependencies = ["requests>=2.28.0"]')
    
    # Try to add Requests (different case)
    codemod = AddPythonDependencyCM(["Requests"], version="3.0")
    new_doc = codemod.transform(doc)
    
    deps = new_doc["project"]["dependencies"]
    # Should not add because "requests" already exists (case-insensitive check)
    assert len(deps) == 1
    assert "requests>=2.28.0" in deps


def test_add_python_version_comparison():
    """Test AddPythonVersionCM version comparison logic"""
    doc = tomlkit.parse('[tool.poetry.dependencies]\npython = "^3.10"')
    
    # Try to update to lower version (should not update)
    codemod = AddPythonVersionCM("^3.9")
    new_doc = codemod.transform(doc)
    assert new_doc["tool"]["poetry"]["dependencies"]["python"] == "^3.10"
    
    # Try to update to higher version (should update)
    codemod2 = AddPythonVersionCM("^3.12")
    new_doc2 = codemod2.transform(doc)
    assert new_doc2["tool"]["poetry"]["dependencies"]["python"] == "^3.12"


def test_idempotent_add_with_version_specifiers():
    """Test IdempotentAddDependencyCM correctly builds version specs"""
    doc = tomlkit.parse('[project]\ndependencies = []')
    
    # Test with plain version number (should add >=)
    codemod = IdempotentAddDependencyCM(["requests"], version="2.28.0")
    new_doc = codemod.transform(doc)
    assert "requests>=2.28.0" in new_doc["project"]["dependencies"]
    
    # Test with operator prefix (should use as-is)
    codemod2 = IdempotentAddDependencyCM(["django"], version=">=4.0")
    new_doc2 = codemod2.transform(new_doc)
    assert "django>=4.0" in new_doc2["project"]["dependencies"]
    
    # Test with wildcard (should not add version)
    codemod3 = IdempotentAddDependencyCM(["pytest"], version="*")
    new_doc3 = codemod3.transform(new_doc2)
    assert "pytest" in new_doc3["project"]["dependencies"]


def test_extract_package_name():
    """Test extract_package_name helper function"""
    from foundry.codemods.toml_codemods import extract_package_name
    
    assert extract_package_name("requests>=2.28.0") == "requests"
    assert extract_package_name("django[postgres]>=4.0") == "django"
    assert extract_package_name("pytest ~= 7.0") == "pytest"
    assert extract_package_name("black==23.0") == "black"
    assert extract_package_name("mypy") == "mypy"


def test_remove_multiple_dependencies():
    """Test RemovePythonDependencyCM with multiple packages"""
    doc = tomlkit.parse('''
[project]
dependencies = ["requests", "flask", "django", "pytest"]

[tool.poetry.dependencies]
python = "^3.10"
requests = "^2.28"
flask = "^2.0"
''')
    
    codemod = RemovePythonDependencyCM(["requests", "flask"])
    new_doc = codemod.transform(doc)
    
    # Check project.dependencies
    project_deps = new_doc["project"]["dependencies"]
    assert not any("requests" in str(d).lower() for d in project_deps)
    assert not any("flask" in str(d).lower() for d in project_deps)
    assert "django" in project_deps
    
    # Check poetry.dependencies
    poetry_deps = new_doc["tool"]["poetry"]["dependencies"]
    assert "requests" not in poetry_deps
    assert "flask" not in poetry_deps
    assert "python" in poetry_deps


def test_remove_tool_sections_partial():
    """Test RemoveToolSectionsCM removing some but not all sections"""
    doc = tomlkit.parse('''
[tool.ruff]
line-length = 88

[tool.mypy]
strict = true

[tool.pytest]
testpaths = ["tests"]
''')
    
    codemod = RemoveToolSectionsCM(["ruff", "mypy"])
    new_doc = codemod.transform(doc)
    
    assert "ruff" not in new_doc["tool"]
    assert "mypy" not in new_doc["tool"]
    assert "pytest" in new_doc["tool"]
    assert "tool" in new_doc  # Should not remove [tool] entirely


def test_update_value_creates_nested_structure():
    """Test UpdateValueCM with create_missing for deeply nested paths"""
    doc = tomlkit.parse('[project]\nname = "test"')
    
    codemod = UpdateValueCM(
        ["tool", "poetry", "group", "dev", "dependencies", "pytest"],
        "^7.0",
        create_missing=True
    )
    new_doc = codemod.transform(doc)
    
    assert new_doc["tool"]["poetry"]["group"]["dev"]["dependencies"]["pytest"] == "^7.0"


# ========== ADDITIONAL TESTS TO REACH 95%+ COVERAGE ==========

def test_extract_package_name_malformed():
    """Test extract_package_name with malformed input (line 29)"""
    from foundry.codemods.toml_codemods import extract_package_name
    
    # Test with no valid package name pattern
    result = extract_package_name("   ")
    assert result == ""
    
    # Test with special characters only
    result2 = extract_package_name("!!!***")
    assert result2 == "!!!***"


def test_add_dependency_poetry_existing_check():
    """Test AddPythonDependencyCM duplicate detection in poetry (line 56)"""
    doc = tomlkit.parse('[tool.poetry.dependencies]\npython = "^3.10"\nrequests = "^2.28"')
    
    # Try to add requests again - should skip due to duplicate check
    codemod = AddPythonDependencyCM(["requests"], version="^3.0")
    new_doc = codemod.transform(doc)
    
    # Should not add duplicate
    deps = new_doc["tool"]["poetry"]["dependencies"]
    assert deps["requests"] == "^2.28"  # Original version preserved


def test_update_value_exception_handling_with_create():
    """Test UpdateValueCM exception handling when path errors occur (lines 176-180)"""
    doc = tomlkit.parse('[project]\nname = "test"')
    
    # Create a scenario where KeyError/TypeError would occur
    # Try to update a deeply nested non-existent path with create_missing
    codemod = UpdateValueCM(
        ["tool", "nonexistent", "deeply", "nested", "value"],
        "test",
        create_missing=True
    )
    new_doc = codemod.transform(doc)
    
    # Should handle exception and create the path
    assert new_doc["tool"]["nonexistent"]["deeply"]["nested"]["value"] == "test"
    
    # Now test without create_missing - should handle gracefully
    doc2 = tomlkit.parse('[project]\nname = "test2"')
    codemod2 = UpdateValueCM(
        ["nonexistent", "path"],
        "value",
        create_missing=False
    )
    new_doc2 = codemod2.transform(doc2)
    # Should not crash, just not create the path
    assert "nonexistent" not in new_doc2


def test_is_more_restrictive_exception_handling():
    """Test AddPythonVersionCM._is_more_restrictive with invalid versions (lines 225-227)"""
    from foundry.codemods.toml_codemods import AddPythonVersionCM
    
    # Test with non-numeric versions (should trigger ValueError)
    result = AddPythonVersionCM._is_more_restrictive("^abc", "^def")
    assert result is False
    
    # Test with malformed version strings
    result2 = AddPythonVersionCM._is_more_restrictive("^1.2.x", "^1.3.y")
    assert result2 is False
    
    # Test with versions missing caret
    result3 = AddPythonVersionCM._is_more_restrictive("3.10", "3.11")
    assert result3 is False


def test_parse_dependency_edge_cases():
    """Test parse_dependency with various edge cases"""
    from foundry.codemods.toml_codemods import parse_dependency
    
    # Test with tilde operator
    name, version = parse_dependency("pytest~=7.0")
    assert name == "pytest"
    assert version == "~=7.0"
    
    # Test with caret operator
    name2, version2 = parse_dependency("django^4.0")
    assert name2 == "django"
    assert version2 == "^4.0"
    
    # Test with spaces
    name3, version3 = parse_dependency("  requests  >=  2.28.0  ")
    assert name3 == "requests"
    assert version3 == ">=  2.28.0"


def test_add_dependency_to_project_without_dependencies():
    """Test AddPythonDependencyCM when project section exists but dependencies doesn't"""
    doc = tomlkit.parse('[project]\nname = "test"\nversion = "0.1.0"')
    
    codemod = AddPythonDependencyCM(["pytest"], version="7.0")
    new_doc = codemod.transform(doc)
    
    assert "dependencies" in new_doc["project"]
    assert "pytest>=7.0" in new_doc["project"]["dependencies"]


def test_idempotent_add_various_version_formats():
    """Test IdempotentAddDependencyCM with all version format branches"""
    doc = tomlkit.parse('[project]\ndependencies = []')
    
    # Test with caret prefix
    codemod = IdempotentAddDependencyCM(["django"], version="^4.0")
    new_doc = codemod.transform(doc)
    assert "django^4.0" in new_doc["project"]["dependencies"]
    
    # Test with tilde prefix
    codemod2 = IdempotentAddDependencyCM(["flask"], version="~2.0")
    new_doc2 = codemod2.transform(new_doc)
    assert "flask~2.0" in new_doc2["project"]["dependencies"]
    
    # Test with exclamation (!=)
    codemod3 = IdempotentAddDependencyCM(["black"], version="!=23.0")
    new_doc3 = codemod3.transform(new_doc2)
    assert "black!=23.0" in new_doc3["project"]["dependencies"]


def test_update_value_type_error_handling():
    """Test UpdateValueCM exception handling when current is not dict-like (lines 176-180)"""
    # Create a document where a value is a string, not a table
    doc = tomlkit.parse('[project]\nname = "test"\nversion = "1.0.0"')
    
    # Try to update a nested path where intermediate value is NOT a table
    # This should trigger TypeError/KeyError internally but be handled gracefully
    codemod = UpdateValueCM(
        ["project", "name", "nested"],  # "name" is a string, not a table
        "value",
        create_missing=False  # Don't try to create, just handle error
    )
    
    new_doc = codemod.transform(doc)
    
    # Should handle the exception gracefully and not crash
    # The transform should return the doc unchanged
    assert "project" in new_doc
    assert new_doc["project"]["name"] == "test"  # Original value preserved


def test_update_value_key_error_recovery():
    """Test UpdateValueCM KeyError handling and recovery with create_missing (lines 176-180)"""
    # Create scenario where navigate_path succeeds but value assignment might fail
    doc = tomlkit.parse('[tool]\nruff = "simple-string"')
    
    # Try to navigate to a path where setting might cause issues
    codemod = UpdateValueCM(
        ["tool", "mypy", "strict"],
        True,
        create_missing=True
    )
    
    new_doc = codemod.transform(doc)
    
    # Should successfully create the nested path
    assert new_doc["tool"]["mypy"]["strict"] is True


def test_update_value_exception_with_recovery():
    """Test UpdateValueCM exception handler with create_missing recovery (lines 178-180)"""
    from unittest.mock import patch, MagicMock
    
    doc = tomlkit.parse('[project]\nname = "test"')
    codemod = UpdateValueCM(["tool", "new", "key"], "value", create_missing=True)
    
    # Mock navigate_path to raise KeyError on first call, succeed on second
    original_navigate = codemod.navigate_path
    call_count = [0]
    
    def mock_navigate(doc_arg, path_arg, create_arg):
        call_count[0] += 1
        if call_count[0] == 1:
            # First call raises exception to trigger except block
            raise KeyError("Simulated error")
        else:
            # Second call in except block succeeds
            return original_navigate(doc_arg, path_arg, create_arg)
    
    with patch.object(codemod, 'navigate_path', side_effect=mock_navigate):
        new_doc = codemod.transform(doc)
    
    # Should have created the path via exception recovery
    assert "tool" in new_doc
    assert new_doc["tool"]["new"]["key"] == "value"


def test_update_value_exception_unable_to_recover():
    """Test UpdateValueCM exception handler when recovery also fails (lines 178-180)"""
    from unittest.mock import patch
    
    doc = tomlkit.parse('[project]\nname = "test"')
    codemod = UpdateValueCM(["nonexistent", "path"], "value", create_missing=True)
    
    # Mock navigate_path to always return None (unable to navigate/create)
    with patch.object(codemod, 'navigate_path', return_value=None):
        new_doc = codemod.transform(doc)
    
    # Should handle gracefully without crashing
    assert "project" in new_doc
