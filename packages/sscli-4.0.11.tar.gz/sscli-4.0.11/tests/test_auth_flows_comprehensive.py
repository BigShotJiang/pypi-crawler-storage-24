"""
Comprehensive flow coverage for foundry/auth.py.

Covers poll edge cases, _http_error_message branches, save_credentials,
get_current_license_info, and logout scenarios not already exercised by
test_auth.py or test_security_auth.py.
"""
import json
import time
from unittest.mock import MagicMock, patch

import pytest
import requests

import foundry.auth as auth_module
from foundry.auth import (
    _http_error_message,
    get_current_license_info,
    login_flow,
    logout,
    save_credentials,
)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _device_ok_resp(uri="https://github.com/login/device", interval=0):
    r = MagicMock()
    r.status_code = 200
    r.json.return_value = {
        "device_code": "dc_abc",
        "user_code": "AA-1111",
        "verification_uri": uri,
        "interval": interval,
    }
    r.text = ""
    return r


def _poll_resp(status, json_data=None, text=""):
    r = MagicMock()
    r.status_code = status
    r.json.return_value = json_data or {}
    r.text = text
    return r


@pytest.fixture(autouse=True)
def _auto_confirm_login(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda *args, **kwargs: "")


# ============================================================================
# TestLoginFlowPollTimeout
# ============================================================================

class TestLoginFlowPollTimeout:
    """All 60 poll attempts return HTTP 428; login_flow must time out and return False."""

    def test_timeout_returns_false(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _device_ok_resp()
        pending = _poll_resp(428)

        with patch("requests.post", side_effect=[device_resp] + [pending] * 61), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            result = auth_module.login_flow()

        assert result is False

    def test_timeout_prints_yellow_warning(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _device_ok_resp()
        pending = _poll_resp(428)

        printed: list[str] = []
        monkeypatch.setattr(
            auth_module.console, "print", lambda *a, **kw: printed.extend(str(x) for x in a)
        )

        with patch("requests.post", side_effect=[device_resp] + [pending] * 61), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        combined = " ".join(printed)
        assert "timed out" in combined.lower(), (
            f"Expected 'timed out' in console output; got: {combined!r}"
        )


# ============================================================================
# TestLoginFlowPoll200WithOrg
# ============================================================================

class TestLoginFlowPoll200WithOrg:
    """Poll returns 200 with org_name; credentials saved with tier+org, org name printed."""

    def test_returns_true(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(200, json_data={
            "access_token": "tok_org",
            "tier": "pro",
            "org_name": "AcmeCorp",
            "email": "dev@acme.com",
        })

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            result = auth_module.login_flow()

        assert result is True

    def test_credentials_persisted_with_tier_and_org(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        poll = _poll_resp(200, json_data={
            "access_token": "tok_org",
            "tier": "pro",
            "org_name": "AcmeCorp",
        })

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        saved = json.loads(creds_path.read_text())
        assert saved["access_token"] == "tok_org"
        assert saved["tier"] == "pro"
        assert saved["org_name"] == "AcmeCorp"

    def test_org_name_appears_in_output(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(200, json_data={
            "access_token": "tok_org",
            "tier": "pro",
            "org_name": "AcmeCorp",
        })

        printed: list[str] = []
        monkeypatch.setattr(
            auth_module.console, "print", lambda *a, **kw: printed.extend(str(x) for x in a)
        )

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        combined = " ".join(printed)
        assert "AcmeCorp" in combined, (
            f"Expected org name 'AcmeCorp' in output; got: {combined!r}"
        )


# ============================================================================
# TestLoginFlowPoll200WithoutOrg
# ============================================================================

class TestLoginFlowPoll200WithoutOrg:
    """Poll returns 200 with org_name absent/None; returns True, org line not printed."""

    def test_returns_true(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(200, json_data={
            "access_token": "tok_solo",
            "tier": "free",
            "org_name": None,
        })

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            result = auth_module.login_flow()

        assert result is True

    def test_org_line_not_printed(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(200, json_data={
            "access_token": "tok_solo",
            "tier": "free",
            "org_name": None,
        })

        printed: list[str] = []
        monkeypatch.setattr(
            auth_module.console, "print", lambda *a, **kw: printed.extend(str(x) for x in a)
        )

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        combined = " ".join(printed)
        # "via" only appears in the org-present branch: "License Tier: X (via OrgName)"
        assert "via" not in combined, (
            f"Expected no 'via' in output when org_name is None; got: {combined!r}"
        )


# ============================================================================
# TestLoginFlowPoll404Expiry
# ============================================================================

class TestLoginFlowPoll404Expiry:
    """Poll returns 404; login_flow returns False and prints code-expired message."""

    def test_returns_false(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(404, text="device code not found")

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            result = auth_module.login_flow()

        assert result is False

    def test_expired_message_printed(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(404, text="expired")

        printed: list[str] = []
        monkeypatch.setattr(
            auth_module.console, "print", lambda *a, **kw: printed.extend(str(x) for x in a)
        )

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        combined = " ".join(printed)
        assert "expired" in combined.lower(), (
            f"Expected 'expired' in output after 404 poll; got: {combined!r}"
        )

    def test_credentials_file_not_created(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        poll = _poll_resp(404, text="expired")

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        assert not creds_path.exists()


# ============================================================================
# TestLoginFlowNetworkRetry
# ============================================================================

class TestLoginFlowNetworkRetry:
    """RequestException on poll attempt 1 is retried; success on attempt 2 returns True."""

    def test_returns_true_after_retry(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        success_poll = _poll_resp(200, json_data={
            "access_token": "tok_retry",
            "tier": "free",
            "org_name": None,
        })

        with patch(
            "requests.post",
            side_effect=[
                _device_ok_resp(),
                requests.RequestException("connection refused"),
                success_poll,
            ],
        ), patch("webbrowser.open"), patch("time.sleep"):
            result = auth_module.login_flow()

        assert result is True

    def test_credentials_saved_after_retry(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        success_poll = _poll_resp(200, json_data={
            "access_token": "tok_retry",
            "tier": "free",
            "org_name": None,
        })

        with patch(
            "requests.post",
            side_effect=[
                _device_ok_resp(),
                requests.RequestException("connection refused"),
                success_poll,
            ],
        ), patch("webbrowser.open"), patch("time.sleep"):
            auth_module.login_flow()

        assert creds_path.exists()
        saved = json.loads(creds_path.read_text())
        assert saved["access_token"] == "tok_retry"


# ============================================================================
# TestLoginFlowPoll503SanitizedText
# ============================================================================

class TestLoginFlowPoll503SanitizedText:
    """HTTP 503 with multiline server text: output sanitized, no raw newlines, returns False."""

    _RAW_TEXT = "line1\nline2\n" * 50

    def test_returns_false(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(503, text=self._RAW_TEXT)

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            result = auth_module.login_flow()

        assert result is False

    def test_sanitized_output_contains_server_content(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(503, text=self._RAW_TEXT)

        printed: list[str] = []
        monkeypatch.setattr(
            auth_module.console, "print", lambda *a, **kw: printed.extend(str(x) for x in a)
        )

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        combined = " ".join(printed)
        assert "line1" in combined or "line2" in combined, (
            f"Expected sanitized server text in output; got: {combined!r}"
        )

    def test_no_raw_newlines_in_server_payload(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        poll = _poll_resp(503, text=self._RAW_TEXT)

        printed: list[str] = []
        monkeypatch.setattr(
            auth_module.console, "print", lambda *a, **kw: printed.extend(str(x) for x in a)
        )

        with patch("requests.post", side_effect=[_device_ok_resp(), poll]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        error_chunks = [c for c in printed if "line1" in c or "line2" in c]
        assert error_chunks, "Expected at least one printed chunk containing sanitized server error"

        for chunk in error_chunks:
            idx = chunk.find("line1")
            if idx == -1:
                idx = chunk.find("line2")
            payload = chunk[idx:]
            assert "\n" not in payload, (
                f"Server text payload must not contain raw newlines (H-5); got: {payload!r}"
            )
            assert len(payload) <= 300, (
                f"Sanitized server payload too long ({len(payload)} chars)"
            )


# ============================================================================
# TestHttpErrorMessageBranches
# ============================================================================

class TestHttpErrorMessageBranches:
    """Direct unit tests for _http_error_message covering every branch."""

    def test_401_references_login_or_credentials(self):
        msg = _http_error_message(401)
        assert "login" in msg.lower() or "credentials" in msg.lower()

    def test_403_references_access_or_license(self):
        msg = _http_error_message(403)
        assert "access" in msg.lower() or "denied" in msg.lower() or "license" in msg.lower()

    def test_404_references_account_or_registered(self):
        msg = _http_error_message(404)
        assert "account" in msg.lower() or "registered" in msg.lower()

    def test_422_references_validation(self):
        msg = _http_error_message(422)
        assert "validation" in msg.lower()

    def test_429_references_rate_limiting(self):
        msg = _http_error_message(429)
        assert "many" in msg.lower() or "wait" in msg.lower()

    def test_500_hits_5xx_branch(self):
        msg = _http_error_message(500)
        assert "unavailable" in msg.lower() or "server" in msg.lower()

    def test_503_same_message_as_500(self):
        assert _http_error_message(503) == _http_error_message(500)

    def test_599_hits_5xx_branch(self):
        msg = _http_error_message(599)
        assert "unavailable" in msg.lower() or "server" in msg.lower()

    def test_400_hits_fallback_with_code(self):
        msg = _http_error_message(400)
        assert "400" in msg

    def test_999_hits_fallback_with_code(self):
        msg = _http_error_message(999)
        assert "999" in msg

    def test_499_below_5xx_range_hits_fallback(self):
        msg = _http_error_message(499)
        assert "499" in msg

    def test_600_above_5xx_range_hits_fallback(self):
        msg = _http_error_message(600)
        assert "600" in msg


# ============================================================================
# TestSaveCredentials
# ============================================================================

class TestSaveCredentials:
    """save_credentials correctly persists tier, org_name, access_token and overwrites."""

    def test_writes_access_token_tier_and_org(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        save_credentials({
            "access_token": "tok_abc",
            "tier": "pro",
            "org_name": "MyOrg",
        })

        saved = json.loads(creds_path.read_text())
        assert saved["access_token"] == "tok_abc"
        assert saved["tier"] == "pro"
        assert saved["org_name"] == "MyOrg"

    def test_org_name_none_still_valid_json(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        save_credentials({
            "access_token": "tok_solo",
            "tier": "free",
            "org_name": None,
        })

        saved = json.loads(creds_path.read_text())
        assert saved["org_name"] is None
        assert saved["access_token"] == "tok_solo"

    def test_overwrites_existing_file(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        save_credentials({"access_token": "old_tok", "tier": "free"})
        assert json.loads(creds_path.read_text())["access_token"] == "old_tok"

        save_credentials({"access_token": "new_tok", "tier": "pro", "org_name": "Corp"})
        second = json.loads(creds_path.read_text())
        assert second["access_token"] == "new_tok"
        assert second["tier"] == "pro"
        assert second["org_name"] == "Corp"

    def test_authorized_flag_always_true(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        save_credentials({"access_token": "tok", "tier": "free"})

        saved = json.loads(creds_path.read_text())
        assert saved["authorized"] is True


# ============================================================================
# TestGetCurrentLicenseInfo
# ============================================================================

class TestGetCurrentLicenseInfo:
    """get_current_license_info returns correct data across cache states and verify modes."""

    def test_valid_cache_returns_expected_keys(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        save_credentials({
            "access_token": "tok",
            "tier": "pro",
            "org_name": "Org",
            "email": "user@org.com",
            "status": "active",
        })

        info = get_current_license_info(verify=False)
        for key in ("tier", "authorized", "org_name"):
            assert key in info, f"Expected key {key!r} in result"

    def test_missing_fields_return_free_tier(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        # Minimal cache — no tier field
        creds_path.parent.mkdir(parents=True, exist_ok=True)
        creds_path.write_text(json.dumps({"access_token": "tok"}))

        info = get_current_license_info(verify=False)
        # Spreading cached_info overrides tier back to "free" (C-14)
        assert info["tier"] == "free"

    def test_expired_token_returns_default_free_info(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)

        past_time = int(time.time()) - 3600  # expired 1 hour ago
        creds_path.parent.mkdir(parents=True, exist_ok=True)
        creds_path.write_text(json.dumps({
            "access_token": "tok_old",
            "tier": "pro",
            "expires_at": past_time,
        }))

        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"
        assert info["authorized"] is False

    def test_verify_true_server_200_returns_server_tier(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)
        creds_path.parent.mkdir(parents=True, exist_ok=True)
        creds_path.write_text(json.dumps({"access_token": "tok_valid", "tier": "free"}))

        server_resp = MagicMock()
        server_resp.status_code = 200
        server_resp.json.return_value = {
            "tier": "enterprise",
            "authorized": True,
            "access_token": "tok_valid",
        }

        with patch("requests.get", return_value=server_resp):
            info = get_current_license_info(verify=True)

        assert info["tier"] == "enterprise"
        assert info["authorized"] is True

    def test_verify_true_401_clears_credentials_and_returns_free(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)
        creds_path.parent.mkdir(parents=True, exist_ok=True)
        creds_path.write_text(json.dumps({"access_token": "tok_expired", "tier": "pro"}))

        server_resp = MagicMock()
        server_resp.status_code = 401

        with patch("requests.get", return_value=server_resp):
            info = get_current_license_info(verify=True)

        assert info["tier"] == "free"
        assert info["authorized"] is False
        assert not creds_path.exists(), "Credentials file must be deleted on 401"


# ============================================================================
# TestLogout
# ============================================================================

class TestLogout:
    """logout() deletes the credentials file; does not raise when already absent."""

    def test_credentials_file_deleted(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)
        creds_path.parent.mkdir(parents=True, exist_ok=True)
        creds_path.write_text(json.dumps({"access_token": "tok"}))
        assert creds_path.exists()

        logout()

        assert not creds_path.exists()

    def test_no_error_when_file_already_gone(self, tmp_path, monkeypatch):
        creds_path = tmp_path / "creds.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_path)
        assert not creds_path.exists()

        # Must not raise FileNotFoundError or any exception
        logout()
