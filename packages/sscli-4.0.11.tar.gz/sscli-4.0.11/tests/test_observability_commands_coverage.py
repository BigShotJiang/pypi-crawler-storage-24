"""
Test coverage for foundry/commands/observability.py

This test file specifically targets uncovered lines to achieve 95%+ coverage.
"""

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import typer
from typer.testing import CliRunner

from foundry.commands.observability import (
    observability_app,
    observability_callback,
    _show_observability_menu,
    diff_command,
    workspace_command,
    workspace_create_command,
    workspace_list_command,
)

runner = CliRunner()


@pytest.fixture(autouse=True)
def _bypass_auth_and_stable_cwd(monkeypatch):
    # Security hardening added an auth gate and cwd containment checks.
    # This coverage suite focuses on command output/flow, so bypass auth
    # and use root cwd to keep absolute test paths valid.
    monkeypatch.setattr("foundry.commands.observability._require_auth", lambda: None)
    monkeypatch.chdir(Path("/"))


# ============================================================================
# Test: observability_callback and menu display (covers lines 22-23, 28-56)
# ============================================================================


def test_observability_callback_invokes_menu_when_no_subcommand(monkeypatch, capsys):
    """Test that observability_callback shows menu when no subcommand is provided."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    
    # Create a context without invoked subcommand
    ctx = MagicMock()
    ctx.invoked_subcommand = None
    
    observability_callback(ctx)
    
    # Verify menu was displayed
    assert len(printed) == 1
    menu_text = str(printed[0])
    assert "Observability & Insights Tools" in menu_text
    assert "sscli obs diff" in menu_text
    assert "sscli obs workspace create" in menu_text
    assert "sscli obs workspace list" in menu_text


def test_observability_callback_no_menu_with_subcommand(monkeypatch):
    """Test that observability_callback does NOT show menu when subcommand is provided."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    
    # Create a context WITH invoked subcommand
    ctx = MagicMock()
    ctx.invoked_subcommand = "diff"
    
    observability_callback(ctx)
    
    # Menu should NOT be shown
    assert len(printed) == 0


def test_show_observability_menu_displays_all_sections(monkeypatch):
    """Test that _show_observability_menu displays complete menu with all commands."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    
    _show_observability_menu()
    
    # Verify all major sections are present
    assert len(printed) == 1
    menu = str(printed[0])
    
    # Check for command sections
    assert "Available Commands:" in menu
    assert "sscli obs diff" in menu
    assert "sscli obs workspace create" in menu
    assert "sscli obs workspace list" in menu
    
    # Check for examples section
    assert "Examples:" in menu
    assert "See what changed when commerce feature was injected" in menu
    assert "Create isolated workspace for tunnel feature" in menu
    assert "Find all workspaces" in menu
    
    # Check for usage details
    assert "--project-path" in menu
    assert "--feature" in menu
    assert "--template" in menu
    assert "--output" in menu
    assert "--search-path" in menu


# ============================================================================
# Test: diff_command with metadata display (covers lines 112-120)
# ============================================================================


def test_diff_command_displays_metadata(monkeypatch, tmp_path):
    """Test that diff_command displays project metadata when available."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    # Mock compute_diff to return metadata
    def fake_compute_diff(**kwargs):
        return {
            "success": True,
            "formatted_output": "Diff output here",
            "metadata": {
                "base_template_version": "2.5.0",
                "created_at": "2024-01-15",
                "features_injected": [
                    {"name": "commerce", "version": "1.0"},
                    "tunnel"
                ]
            }
        }
    
    monkeypatch.setattr("foundry.commands.observability.compute_diff", fake_compute_diff)
    
    diff_command(
        project_path=str(tmp_path),
        output_format="colored",
        output_file=None
    )
    
    # Verify metadata was displayed
    output_text = "".join([str(p) for p in printed])
    assert "Project Metadata:" in output_text
    assert "Base Template: 2.5.0" in output_text
    assert "Created: 2024-01-15" in output_text
    assert "Features: commerce, tunnel" in output_text


def test_diff_command_without_metadata(monkeypatch, tmp_path):
    """Test diff_command when no metadata is available."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_compute_diff(**kwargs):
        return {
            "success": True,
            "formatted_output": "Diff output here",
            "metadata": {}  # Empty metadata
        }
    
    monkeypatch.setattr("foundry.commands.observability.compute_diff", fake_compute_diff)
    
    diff_command(
        project_path=str(tmp_path),
        output_format="colored",
        output_file=None
    )
    
    # Should not crash and should display output
    output_text = "".join([str(p) for p in printed])
    assert "Diff output here" in output_text


def test_diff_command_saves_to_file(monkeypatch, tmp_path):
    """Test diff_command with output file option."""
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_compute_diff(**kwargs):
        return {
            "success": True,
            "formatted_output": "Diff content",
            "metadata": {"base_template_version": "2.5.0"}
        }
    
    monkeypatch.setattr("foundry.commands.observability.compute_diff", fake_compute_diff)
    
    output_file = tmp_path / "diff_output.txt"
    
    diff_command(
        project_path=str(tmp_path),
        output_format="colored",
        output_file=str(output_file)
    )
    
    # Verify file was created with content
    assert output_file.exists()
    content = output_file.read_text()
    assert "Diff content" in content
    assert "Base Template: 2.5.0" in content


def test_diff_command_all_parameters(monkeypatch, tmp_path):
    """Test diff_command with all optional parameters."""
    called_with = {}
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_compute_diff(**kwargs):
        called_with.update(kwargs)
        return {
            "success": True,
            "formatted_output": "Diff output",
            "metadata": {}
        }
    
    monkeypatch.setattr("foundry.commands.observability.compute_diff", fake_compute_diff)
    
    diff_command(
        project_path=str(tmp_path),
        base_template="/path/to/base",
        feature="commerce",
        template="python-saas",
        output_format="unified",
        output_file=None
    )
    
    # Verify all parameters were passed to compute_diff
    assert called_with["project_path"] == str(tmp_path)
    assert called_with["base_template_path"] == "/path/to/base"
    assert called_with["feature_name"] == "commerce"
    assert called_with["template_name"] == "python-saas"
    assert called_with["output_format"] == "unified"


# ============================================================================
# Test: workspace_command callback (covers line 127)
# ============================================================================


def test_workspace_command_without_subcommand(monkeypatch):
    """Test workspace_command shows message when no subcommand is provided."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    
    # Create a context without invoked subcommand
    ctx = MagicMock()
    ctx.invoked_subcommand = None
    
    workspace_command(ctx)
    
    # Verify helpful message was displayed
    assert len(printed) == 1
    assert "sscli obs workspace create" in str(printed[0])
    assert "sscli obs workspace list" in str(printed[0])


# ============================================================================
# Test: workspace_create_command success path (covers lines 133-134, 187-190)
# ============================================================================


def test_workspace_create_command_success_with_panel(monkeypatch):
    """Test workspace_create_command displays success panel."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_create_workspace(**kwargs):
        return {
            "success": True,
            "workspace_path": "/tmp/workspace",
            "files_created": 42
        }
    
    monkeypatch.setattr("foundry.commands.observability.create_feature_workspace", fake_create_workspace)
    
    workspace_create_command(
        feature="commerce",
        template="rails-api",
        output="/tmp/workspace"
    )
    
    # Verify Panel was displayed
    output_text = "".join([str(p) for p in printed])
    assert "Creating feature workspace" in output_text
    assert "commerce" in output_text
    assert "rails-api" in output_text
    
    # Check for success panel - the Panel object is printed with workspace info
    # Check if any printed item is a Panel or contains the workspace path in its content
    from rich.panel import Panel
    assert any(isinstance(p, Panel) for p in printed) or len(printed) >= 2


def test_workspace_create_command_with_all_options(monkeypatch):
    """Test workspace_create_command with all optional parameters."""
    called_with = {}
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: None)
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_create_workspace(**kwargs):
        called_with.update(kwargs)
        return {
            "success": True,
            "workspace_path": "/tmp/ws",
            "files_created": 10
        }
    
    monkeypatch.setattr("foundry.commands.observability.create_feature_workspace", fake_create_workspace)
    
    workspace_create_command(
        feature="tunnel",
        template="python-saas",
        output="/tmp/ws",
        description="Test workspace",
        include_tests=False,
        include_docs=False
    )
    
    # Verify all parameters were passed
    assert called_with["feature_name"] == "tunnel"
    assert called_with["template_name"] == "python-saas"
    assert called_with["output_path"] == "/tmp/ws"
    assert called_with["description"] == "Test workspace"
    assert called_with["include_tests"] is False
    assert called_with["include_docs"] is False


# ============================================================================
# Test: workspace_list_command paths (covers lines 227-228, 233-234, 239-244)
# ============================================================================


def test_workspace_list_command_json_output(monkeypatch):
    """Test workspace_list_command with JSON output format."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_list_workspaces(search_path):
        return {
            "success": True,
            "workspaces": [
                {
                    "feature_name": "commerce",
                    "template_name": "rails-api",
                    "path": "/tmp/ws1",
                    "files_included": 20,
                    "created_at": "2024-01-15"
                }
            ]
        }
    
    monkeypatch.setattr("foundry.commands.observability.list_workspaces", fake_list_workspaces)
    
    workspace_list_command(search_path="/tmp", json_output=True)
    
    # Verify JSON output was printed
    output_text = "".join([str(p) for p in printed])
    # The JSON should be in the output
    assert "commerce" in output_text or len(printed) >= 2


def test_workspace_list_command_error_handling(monkeypatch):
    """Test workspace_list_command error handling."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_list_workspaces(search_path):
        return {
            "success": False,
            "error": "Directory not found"
        }
    
    monkeypatch.setattr("foundry.commands.observability.list_workspaces", fake_list_workspaces)
    
    with pytest.raises(typer.Exit) as excinfo:
        workspace_list_command(search_path="/invalid")
    
    assert excinfo.value.exit_code == 1
    
    # Verify error message was displayed
    output_text = "".join([str(p) for p in printed])
    assert "Error" in output_text
    assert "Directory not found" in output_text


def test_workspace_list_command_empty_workspaces(monkeypatch):
    """Test workspace_list_command when no workspaces are found."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_list_workspaces(search_path):
        return {
            "success": True,
            "workspaces": []
        }
    
    monkeypatch.setattr("foundry.commands.observability.list_workspaces", fake_list_workspaces)
    
    workspace_list_command(search_path=".", json_output=False)
    
    # Verify "no workspaces" message was displayed
    output_text = "".join([str(p) for p in printed])
    assert "No workspaces found" in output_text


def test_workspace_list_command_with_multiple_workspaces(monkeypatch):
    """Test workspace_list_command with multiple workspaces."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_list_workspaces(search_path):
        return {
            "success": True,
            "workspaces": [
                {
                    "feature_name": "commerce",
                    "template_name": "rails-api",
                    "path": "/tmp/ws1",
                    "files_included": 20,
                    "created_at": "2024-01-15"
                },
                {
                    "feature_name": "tunnel",
                    "template_name": "python-saas",
                    "path": "/tmp/ws2",
                    "files_included": 35,
                    "created_at": "2024-01-20"
                }
            ]
        }
    
    monkeypatch.setattr("foundry.commands.observability.list_workspaces", fake_list_workspaces)
    
    workspace_list_command(search_path="/tmp", json_output=False)
    
    # Verify workspace details were displayed
    output_text = "".join([str(p) for p in printed])
    assert "Found 2 workspace(s)" in output_text
    assert "commerce" in output_text
    assert "tunnel" in output_text
    assert "rails-api" in output_text
    assert "python-saas" in output_text
    assert "/tmp/ws1" in output_text
    assert "/tmp/ws2" in output_text


def test_workspace_list_command_default_search_path(monkeypatch):
    """Test workspace_list_command uses current directory when no search path provided."""
    called_with = {}
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: None)
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_list_workspaces(search_path):
        called_with["search_path"] = search_path
        return {
            "success": True,
            "workspaces": []
        }
    
    monkeypatch.setattr("foundry.commands.observability.list_workspaces", fake_list_workspaces)
    
    workspace_list_command(search_path=None, json_output=False)
    
    # Verify default path resolves to current directory absolute path
    assert called_with["search_path"] == str(Path(".").resolve())


# ============================================================================
# Edge cases and error paths
# ============================================================================


def test_diff_command_json_format_with_metadata(monkeypatch, tmp_path):
    """Test diff_command JSON output includes all metadata."""
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_compute_diff(**kwargs):
        return {
            "success": True,
            "formatted_output": "Diff",
            "metadata": {
                "base_template_version": "2.5.0",
                "features_injected": ["commerce"]
            },
            "additional_data": "test"
        }
    
    monkeypatch.setattr("foundry.commands.observability.compute_diff", fake_compute_diff)
    
    output_file = tmp_path / "output.json"
    
    diff_command(
        project_path=str(tmp_path),
        output_format="json",
        output_file=str(output_file)
    )
    
    # Verify JSON file content
    content = json.loads(output_file.read_text())
    assert content["success"] is True
    assert content["metadata"]["base_template_version"] == "2.5.0"
    assert content["additional_data"] == "test"


def test_workspace_create_command_logs_event(monkeypatch):
    """Test workspace_create_command logs telemetry event."""
    logged_events = []
    
    def fake_log_event(event_type, message):
        logged_events.append((event_type, message))
    
    monkeypatch.setattr("foundry.commands.observability.log_event", fake_log_event)
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: None)
    monkeypatch.setattr(
        "foundry.commands.observability.create_feature_workspace",
        lambda **kwargs: {"success": True, "workspace_path": "/tmp", "files_created": 1}
    )
    
    workspace_create_command(
        feature="commerce",
        template="rails-api",
        output="/tmp/ws"
    )
    
    # Verify event was logged
    assert len(logged_events) == 1
    assert logged_events[0][0] == "COMMAND"
    assert "commerce" in logged_events[0][1]
    assert "rails-api" in logged_events[0][1]


def test_workspace_list_command_logs_event(monkeypatch):
    """Test workspace_list_command logs telemetry event."""
    logged_events = []
    
    def fake_log_event(event_type, message):
        logged_events.append((event_type, message))
    
    monkeypatch.setattr("foundry.commands.observability.log_event", fake_log_event)
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: None)
    monkeypatch.setattr(
        "foundry.commands.observability.list_workspaces",
        lambda search_path: {"success": True, "workspaces": []}
    )
    
    workspace_list_command(search_path="/tmp", json_output=False)
    
    # Verify event was logged
    assert len(logged_events) == 1
    assert logged_events[0][0] == "COMMAND"
    assert "obs workspace list" in logged_events[0][1]


def test_diff_command_logs_event(monkeypatch, tmp_path):
    """Test diff_command logs telemetry event."""
    logged_events = []
    
    def fake_log_event(event_type, message):
        logged_events.append((event_type, message))
    
    monkeypatch.setattr("foundry.commands.observability.log_event", fake_log_event)
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: None)
    monkeypatch.setattr(
        "foundry.commands.observability.compute_diff",
        lambda **kwargs: {"success": True, "formatted_output": "OK", "metadata": {}}
    )
    
    diff_command(project_path=str(tmp_path), output_file=None)
    
    # Verify event was logged
    assert len(logged_events) == 1
    assert logged_events[0][0] == "COMMAND"
    assert str(tmp_path) in logged_events[0][1]


def test_diff_command_json_output_format(monkeypatch, tmp_path):
    """Test diff_command with json output format (covers lines 103-104)."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    def fake_compute_diff(**kwargs):
        return {
            "success": True,
            "data": "test",
            "metadata": {"version": "1.0"}
        }
    
    monkeypatch.setattr("foundry.commands.observability.compute_diff", fake_compute_diff)
    
    diff_command(
        project_path=str(tmp_path),
        output_format="json",
        output_file=None
    )
    
    # Verify JSON was printed
    import json
    output_text = "".join([str(p) for p in printed])
    # Should contain JSON stringified result
    assert "success" in output_text
    assert "true" in output_text.lower() or "True" in output_text


def test_workspace_create_success_extracts_result_data(monkeypatch):
    """Test workspace_create_command extracts workspace_path and files_created (covers lines 183-184)."""
    printed = []
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr("foundry.commands.observability.log_event", lambda *args, **kwargs: None)
    
    # Return specific values to ensure they are extracted
    def fake_create_workspace(**kwargs):
        return {
            "success": True,
            "workspace_path": "/tmp/test-workspace-123",
            "files_created": 99
        }
    
    monkeypatch.setattr("foundry.commands.observability.create_feature_workspace", fake_create_workspace)
    
    workspace_create_command(
        feature="test-feature",
        template="python-saas",
        output="/tmp/test"
    )
    
    # Verify the Panel was created with the extracted values
    # Check that Panel is in printed items
    from rich.panel import Panel
    panel_found = any(isinstance(p, Panel) for p in printed)
    assert panel_found
