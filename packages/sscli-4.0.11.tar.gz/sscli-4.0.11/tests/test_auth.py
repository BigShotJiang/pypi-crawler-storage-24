import json
import os
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests
from foundry.auth import (
    CREDENTIALS_FILE,
    get_access_token,
    get_current_license_info,
    login_flow,
    logout,
    save_credentials,
)

@pytest.fixture
def temp_credentials_file(tmp_path):
    """Fixture to mock CREDENTIALS_FILE path."""
    creds_dir = tmp_path / ".config" / "sscli"
    creds_file = creds_dir / "credentials.json"
    with patch("foundry.auth.CREDENTIALS_FILE", creds_file):
        yield creds_file


@pytest.fixture(autouse=True)
def _auto_confirm_login(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda *args, **kwargs: "")

class TestAccessToken:
    def test_get_access_token_success(self, temp_credentials_file):
        """Test legacy get_access_token function reads from cache."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps({
            "access_token": "ghu_token_123",
            "tier": "free"
        }))
        assert get_access_token() == "ghu_token_123"

    def test_get_access_token_failure(self, temp_credentials_file):
        """Test get_access_token returns None when no credentials."""
        assert get_access_token() is None

    def test_get_access_token_corrupted_json(self, temp_credentials_file):
        """Test get_access_token handles corrupted credentials file."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text("invalid json")
        assert get_access_token() is None

class TestSaveCredentials:
    def test_save_credentials_creates_file(self, temp_credentials_file):
        data = {"tier": "pro", "org_name": "TestOrg", "email": "test@example.com", "status": "active", "access_token": "token_123"}
        save_credentials(data)
        
        assert temp_credentials_file.exists()
        with open(temp_credentials_file, "r") as f:
            saved = json.load(f)
            assert saved["tier"] == "pro"
            assert saved["org_name"] == "TestOrg"
            assert saved["email"] == "test@example.com"  # Email IS cached
            assert saved["authorized"] is True

    def test_permissions_are_restrictive(self, temp_credentials_file):
        data = {"tier": "free", "access_token": "token_456"}
        save_credentials(data)
        # 0o600 is octal for -rw-------
        assert (os.stat(temp_credentials_file).st_mode & 0o777) == 0o600

class TestLoginFlow:
    @pytest.mark.timeout(5)  # 70 polling iterations + mocks may take longer
    @patch("webbrowser.open")
    @patch("time.sleep")
    @patch("foundry.auth.requests.get")
    @patch("foundry.auth.requests.post")
    def test_login_flow_success(self, mock_post, mock_get, mock_sleep, mock_browser, temp_credentials_file):
        """Test login_flow success with device flow."""
        # Mock POST request for device code
        mock_post_resp = MagicMock()
        mock_post_resp.status_code = 200
        mock_post_resp.json.return_value = {
            "device_code": "device_123",
            "user_code": "ABC-DEF",
            "verification_uri": "https://github.com/login/device",
            "interval": 1
        }
        
        # Mock GET request for polling (succeeds on first try)
        mock_get_resp = MagicMock()
        mock_get_resp.status_code = 200
        mock_get_resp.json.return_value = {
            "access_token": "ghu_token_123",
            "tier": "enterprise", 
            "org_name": "BigCo", 
            "email": "user@big.co"
        }
        
        mock_post.return_value = mock_post_resp
        mock_get.return_value = mock_get_resp
        mock_browser.return_value = True  # Don't actually open browser
        mock_sleep.return_value = None  # Don't wait
        
        assert login_flow() is True
        assert temp_credentials_file.exists()
        mock_browser.assert_called_once()  # Verify browser was attempted
        mock_sleep.assert_called()  # Verify polling happened

    @patch("webbrowser.open")
    @patch("time.sleep")
    @patch("foundry.auth.requests.get")
    @patch("foundry.auth.requests.post")
    def test_login_flow_success_without_org(self, mock_post, mock_get, mock_sleep, mock_browser, temp_credentials_file):
        """Test login_flow success when user has no org_name (individual account)."""
        # Mock POST request for device code
        mock_post_resp = MagicMock()
        mock_post_resp.status_code = 200
        mock_post_resp.json.return_value = {
            "device_code": "device_456",
            "user_code": "XYZ-ABC",
            "verification_uri": "https://github.com/login/device",
            "interval": 1
        }
        
        # Mock GET request for polling
        mock_get_resp = MagicMock()
        mock_get_resp.status_code = 200
        mock_get_resp.json.return_value = {
            "access_token": "ghu_token_456",
            "tier": "free", 
            "org_name": None,  # No organization
            "email": "user@example.com"
        }
        
        mock_post.return_value = mock_post_resp
        mock_get.return_value = mock_get_resp
        mock_browser.return_value = True
        mock_sleep.return_value = None
        
        assert login_flow() is True
        assert temp_credentials_file.exists()

    @pytest.mark.timeout(10)  # OAuth server setup + error handling
    @patch("webbrowser.open")
    @patch("foundry.auth.requests.post")
    def test_login_flow_device_code_request_fail(self, mock_post, mock_browser):
        """Test login_flow when device code request fails."""
        mock_post.return_value = MagicMock(status_code=500, text="Server error")
        assert login_flow() is False

    @pytest.mark.timeout(5)  # 70 polling iterations may take longer
    @patch("webbrowser.open")
    @patch("time.sleep")
    @patch("foundry.auth.requests.get")
    @patch("foundry.auth.requests.post")
    def test_login_flow_polling_timeout(self, mock_post, mock_get, mock_sleep, mock_browser):
        """Test login_flow when polling times out.

        NOTE: Per RFC 8628 (fix H-6), polling uses POST not GET.
        mock_post handles BOTH the device-code request (first call)
        and all polling attempts (subsequent calls), so we use side_effect.
        """
        # First POST: device code request
        mock_device_resp = MagicMock()
        mock_device_resp.status_code = 200
        mock_device_resp.json.return_value = {
            "device_code": "device_789",
            "user_code": "TEST-CODE",
            "verification_uri": "https://github.com/login/device",
            "interval": 1
        }
        # Subsequent POSTs: polling always returns 428 (authorization_pending)
        mock_poll_resp = MagicMock(status_code=428)
        mock_post.side_effect = [mock_device_resp] + [mock_poll_resp] * 70

        mock_browser.return_value = True
        mock_sleep.return_value = None

        assert login_flow() is False  # Should timeout after max_attempts

class TestLicenseInfo:
    def test_get_license_info_cached_no_verify(self, temp_credentials_file):
        # C-14 security fix: verify=False never trusts cached tier (prevents local file tampering).
        # All security-critical gates use verify=True; verify=False is display-only and returns 'free'.
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps({"tier": "pro", "org_name": "Org"}))
        
        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"  # C-14: tier stripped to 'free' for verify=False
        assert info["org_name"] == "Org"  # non-tier fields still returned from cache

    def test_get_license_info_empty_no_verify(self, temp_credentials_file):
        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"
        assert info["authorized"] is False

    @patch("foundry.auth.requests.get")
    def test_get_license_info_verify_success(self, mock_requests_get, temp_credentials_file):
        # First save a cached token
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps({
            "access_token": "ghu_test_token",
            "tier": "free"
        }))
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"tier": "alpha", "org_name": "Org", "access_token": "ghu_test_token"}
        mock_requests_get.return_value = mock_response
        
        info = get_current_license_info(verify=True)
        assert info["tier"] == "alpha"
        assert temp_credentials_file.exists()

class TestLogout:
    def test_logout_removes_file(self, temp_credentials_file):
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text("{}")
        
        logout()
        assert not temp_credentials_file.exists()

    def test_logout_no_file(self, temp_credentials_file):
        logout()  # Should not raise exception

    def test_logout_file_removal_exception(self, temp_credentials_file):
        """Test logout handles exception when removing credentials file."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text("{}")
        
        # Mock Path.unlink to raise an exception
        with patch.object(Path, "unlink") as mock_unlink:
            mock_unlink.side_effect = PermissionError("Cannot remove file")
            logout()  # Should not raise exception


class TestGetLicenseInfoEdgeCases:
    def test_get_license_info_corrupted_cache(self, temp_credentials_file):
        """Test handling of corrupted cached credentials."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text("invalid json{{{")
        
        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"
        assert info["authorized"] is False

    def test_get_license_info_non_dict_cache(self, temp_credentials_file):
        """Test handling when cached data is not a dictionary."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps(["not", "a", "dict"]))
        
        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"
        assert info["authorized"] is False

    def test_get_license_info_cache_missing_authorized(self, temp_credentials_file):
        """Test that authorized flag is present and tier is 'free' for verify=False (C-14)."""
        # C-14 security fix: tier is always 'free' when verify=False to prevent
        # local credential file tampering from granting elevated access.
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps({"tier": "pro", "org_name": "Org"}))
        
        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"  # C-14: tier always 'free' without server verification
        assert "authorized" in info

    @patch("foundry.auth.get_access_token")
    def test_get_license_info_verify_no_token(self, mock_get_token, temp_credentials_file):
        """Test verify mode when credentials file has no access_token.
        C-14: Never trust cached tier data when verification is not possible."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps({"tier": "pro"}))
        
        mock_get_token.return_value = None
        info = get_current_license_info(verify=True)
        # C-14: no access_token in cached data → cannot verify → must return free
        assert info["tier"] == "free"

    @patch("foundry.auth.requests.get")
    @patch("foundry.auth.get_access_token")
    def test_get_license_info_verify_invalid_token(self, mock_get_token, mock_requests_get, temp_credentials_file):
        """Test verify mode with invalid/expired token (non-200 response)."""
        mock_get_token.return_value = "expired_token"
        
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_requests_get.return_value = mock_response
        
        info = get_current_license_info(verify=True)
        assert info["tier"] == "free"
        assert info["authorized"] is False

    @patch("foundry.auth.requests.get")
    @patch("foundry.auth.get_access_token")
    def test_get_license_info_verify_server_error(self, mock_get_token, mock_requests_get, temp_credentials_file):
        """Test verify mode with server error (500, etc)."""
        mock_get_token.return_value = "token"
        
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_requests_get.return_value = mock_response
        
        info = get_current_license_info(verify=True)
        assert info["tier"] == "free"

    @patch("foundry.auth.requests.get")
    @patch("foundry.auth.get_access_token")
    def test_get_license_info_verify_network_exception(self, mock_get_token, mock_requests_get, temp_credentials_file):
        """Test verify mode with network exception.
        C-14: Server unreachable — never trust local JSON tier, return free."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps({"tier": "pro", "org_name": "Org", "access_token": "valid_token"}))
        
        mock_get_token.return_value = "token"
        mock_requests_get.side_effect = requests.ConnectionError("Network unreachable")
        
        info = get_current_license_info(verify=True)
        # C-14: server unreachable → never trust cached tier → free
        assert info["tier"] == "free"

    @patch("foundry.auth.requests.get")
    @patch("foundry.auth.get_access_token")
    def test_get_license_info_verify_timeout(self, mock_get_token, mock_requests_get, temp_credentials_file):
        """Test verify mode with timeout.
        C-14: Server unreachable — never trust local JSON tier, return free."""
        temp_credentials_file.parent.mkdir(parents=True, exist_ok=True)
        temp_credentials_file.write_text(json.dumps({"tier": "enterprise", "access_token": "valid_token"}))
        
        mock_get_token.return_value = "token"
        mock_requests_get.side_effect = requests.Timeout("Request timed out")
        
        info = get_current_license_info(verify=True)
        # C-14: server timeout → never trust cached tier → free
        assert info["tier"] == "free"
