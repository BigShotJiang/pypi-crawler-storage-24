# FILE: tests/test_commands_interactive_comprehensive.py
"""Comprehensive tests for foundry/commands/interactive.py"""

import pytest
import typer
from unittest.mock import MagicMock, patch


class TestInteractiveDefaultNoSubcommand:
    """interactive_default calls interactive_menu when no subcommand is invoked."""

    def test_calls_interactive_menu_when_no_subcommand(self):
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = None

        with patch("foundry.interactive.interactive_menu") as mock_menu:
            from foundry.commands.interactive import interactive_default

            interactive_default(ctx)
            mock_menu.assert_called_once()

    def test_calls_interactive_menu_exactly_once(self):
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = None

        with patch("foundry.interactive.interactive_menu") as mock_menu:
            from foundry.commands.interactive import interactive_default

            interactive_default(ctx)
            assert mock_menu.call_count == 1


class TestInteractiveDefaultWithSubcommand:
    """interactive_default does NOT call interactive_menu when a subcommand is present."""

    def test_does_not_call_interactive_menu_when_subcommand_present(self):
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = "animated"

        with patch("foundry.interactive.interactive_menu") as mock_menu:
            from foundry.commands.interactive import interactive_default

            interactive_default(ctx)
            mock_menu.assert_not_called()

    def test_does_not_call_for_any_subcommand_name(self):
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = "some-other-command"

        with patch("foundry.interactive.interactive_menu") as mock_menu:
            from foundry.commands.interactive import interactive_default

            interactive_default(ctx)
            mock_menu.assert_not_called()


class TestInteractiveAnimated:
    """interactive_animated calls run_animated_experience."""

    def test_calls_run_animated_experience(self):
        with patch("foundry.interactive.run_animated_experience") as mock_run:
            from foundry.commands.interactive import interactive_animated

            interactive_animated()
            mock_run.assert_called_once()

    def test_calls_run_animated_experience_exactly_once(self):
        with patch("foundry.interactive.run_animated_experience") as mock_run:
            from foundry.commands.interactive import interactive_animated

            interactive_animated()
            assert mock_run.call_count == 1

    def test_calls_with_no_arguments(self):
        with patch("foundry.interactive.run_animated_experience") as mock_run:
            from foundry.commands.interactive import interactive_animated

            interactive_animated()
            mock_run.assert_called_once_with()


class TestInteractiveAnimatedPropagatesException:
    """run_animated_experience exceptions propagate out of interactive_animated."""

    def test_propagates_runtime_error(self):
        with patch(
            "foundry.interactive.run_animated_experience",
            side_effect=RuntimeError("animation failed"),
        ):
            from foundry.commands.interactive import interactive_animated

            with pytest.raises(RuntimeError, match="animation failed"):
                interactive_animated()

    def test_propagates_value_error(self):
        with patch(
            "foundry.interactive.run_animated_experience",
            side_effect=ValueError("bad value"),
        ):
            from foundry.commands.interactive import interactive_animated

            with pytest.raises(ValueError, match="bad value"):
                interactive_animated()


class TestInteractiveDefaultMenuPropagatesException:
    """Exceptions from interactive_menu propagate out of interactive_default."""

    def test_propagates_keyboard_interrupt(self):
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = None

        with patch(
            "foundry.interactive.interactive_menu",
            side_effect=KeyboardInterrupt,
        ):
            from foundry.commands.interactive import interactive_default

            with pytest.raises(KeyboardInterrupt):
                interactive_default(ctx)

    def test_propagates_runtime_error(self):
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = None

        with patch(
            "foundry.interactive.interactive_menu",
            side_effect=RuntimeError("menu exploded"),
        ):
            from foundry.commands.interactive import interactive_default

            with pytest.raises(RuntimeError, match="menu exploded"):
                interactive_default(ctx)


class TestInteractiveAppRegistered:
    """Structural tests for interactive_app registration."""

    def test_interactive_app_is_typer_instance(self):
        from foundry.commands.interactive import interactive_app

        assert isinstance(interactive_app, typer.Typer)

    def test_animated_command_is_registered(self):
        from foundry.commands.interactive import interactive_app

        registered_names = [cmd.name for cmd in interactive_app.registered_commands]
        assert "animated" in registered_names

    def test_app_has_help_text(self):
        from foundry.commands.interactive import interactive_app

        assert interactive_app.info.help is not None
        assert len(interactive_app.info.help) > 0


class TestInteractiveDefaultImportPath:
    """interactive_default imports from foundry.interactive (not another module)."""

    def test_import_path_is_foundry_interactive(self):
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = None

        # Patching the exact module path proves the import resolves to foundry.interactive
        with patch("foundry.interactive.interactive_menu") as mock_menu:
            from foundry.commands.interactive import interactive_default

            interactive_default(ctx)
            mock_menu.assert_called_once()

    def test_wrong_import_path_does_not_intercept_call(self):
        """Patching a wrong path should NOT prevent the real call from happening
        (this ensures we are patching at exactly the right location)."""
        ctx = MagicMock(spec=typer.Context)
        ctx.invoked_subcommand = None

        reached = []

        with patch("foundry.interactive.interactive_menu", side_effect=lambda: reached.append(1)):
            from foundry.commands.interactive import interactive_default

            interactive_default(ctx)

        assert reached == [1]


class TestInteractiveAnimatedImportPath:
    """interactive_animated imports run_animated_experience from foundry.interactive."""

    def test_import_path_is_foundry_interactive(self):
        with patch("foundry.interactive.run_animated_experience") as mock_run:
            from foundry.commands.interactive import interactive_animated

            interactive_animated()
            mock_run.assert_called_once()

    def test_side_effect_confirming_correct_module_is_patched(self):
        results = []

        with patch(
            "foundry.interactive.run_animated_experience",
            side_effect=lambda: results.append("called"),
        ):
            from foundry.commands.interactive import interactive_animated

            interactive_animated()

        assert results == ["called"]
