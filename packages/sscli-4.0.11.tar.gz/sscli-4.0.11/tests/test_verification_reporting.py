from pathlib import Path

from foundry.actions.verification.models import TemplateType, VerificationResult, VerificationStatus
from foundry.actions.verification.reports import generate_reports, print_summary
from foundry.actions.verification.verifier import TemplateVerifier


def test_generate_reports_writes_files(tmp_path):
    results = {
        "python-saas": VerificationResult(
            name="python-saas",
            template_type=TemplateType.DOCKER,
            status=VerificationStatus.SUCCESS,
            git_ignore=True,
            git_attributes=True,
            docker_success=True,
            duration_seconds=1.23,
        ),
        "terraform-infra": VerificationResult(
            name="terraform-infra",
            template_type=TemplateType.TERRAFORM,
            status=VerificationStatus.FAILED,
            git_ignore=True,
            git_attributes=False,
            docker_success=False,
            duration_seconds=2.34,
            notes="bad",
        ),
    }

    generate_reports(results, tmp_path)

    docs_dir = tmp_path / "docs" / "verification"
    assert docs_dir.exists()
    assert (docs_dir / "verification_results_latest.csv").exists()
    assert (docs_dir / "verification_results_latest.md").exists()


def test_print_summary_exit_code():
    results = {
        "ok": VerificationResult(
            name="ok",
            template_type=TemplateType.DOCKER,
            status=VerificationStatus.SUCCESS,
            git_ignore=True,
            git_attributes=True,
            docker_success=True,
            duration_seconds=1.0,
        ),
        "bad": VerificationResult(
            name="bad",
            template_type=TemplateType.DOCKER,
            status=VerificationStatus.FAILED,
            git_ignore=False,
            git_attributes=False,
            docker_success=False,
            duration_seconds=1.0,
        ),
    }

    assert print_summary(results) == 1


def test_verifier_check_files_missing_gitignore(tmp_path):
    verifier = TemplateVerifier(tmp_path)
    template_path = tmp_path / "templates" / "python-saas"
    template_path.mkdir(parents=True)
    res = verifier._verify_template("python-saas", TemplateType.DOCKER, include_docker=False)
    assert res.status == VerificationStatus.FAILED
    assert "Missing .gitignore" in res.notes
