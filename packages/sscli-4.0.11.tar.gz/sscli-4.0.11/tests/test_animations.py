import sys
import types

import pytest
from rich.text import Text

from foundry.animations.canvas import Canvas
from foundry.animations.rendering import pad_content, draw_frame
from foundry.animations.utils import align_content
from foundry.animations.engine.frame_buffer import FrameBuffer
from foundry.animations.engine.clock import AnimationClock
from foundry.animations.components import render_base_background
from foundry.animations.scenes.logo_disperse import LogoDisperseAnimation
from foundry.animations.scenes.rain import RainAnimation
from foundry.animations.scenes.logo_reveal import LogoStaticAnimation
from foundry.animations.scenes.logo_reveal import LogoRevealAnimation
from foundry.animations.engine.state import AnimationState


def test_canvas_draw_text_clips():
    canvas = Canvas(width=5, height=2)
    canvas.draw_text("abcdef", 0, 0)
    assert canvas.buffer[0].plain == "abcde"


def test_canvas_draw_text_transparent_preserves():
    canvas = Canvas(width=5, height=1)
    canvas.draw_text("xxxxx", 0, 0)
    canvas.draw_text_transparent("  y  ", 0, 0)
    assert canvas.buffer[0].plain == "xxyxx"


def test_frame_buffer_merge_transparency():
    fb = FrameBuffer(width=5, height=1)
    fb.add_layer("base", [Text("aaaaa")])
    fb.add_layer("overlay", [Text("  b  ")])
    merged = fb.render()[0].plain
    assert merged == "aabaa"


def test_animation_clock_pause_resume(monkeypatch):
    current = {"t": 0.0}

    def fake_time():
        current["t"] += 0.01
        return current["t"]

    monkeypatch.setattr("foundry.animations.engine.clock.time.time", fake_time)
    monkeypatch.setattr("foundry.animations.engine.clock.time.sleep", lambda s: None)

    clock = AnimationClock(fps=60)
    dt = clock.tick()
    assert dt >= 0.0

    clock.pause()
    assert clock.tick() == 0.0
    clock.resume()
    assert clock.tick() >= 0.0


def test_rendering_pad_content_and_draw_frame():
    lines = ["hello", "world"]
    padded = pad_content(lines, height=3, width=10)
    assert len(padded) == 3

    frame = draw_frame(lines, height=2, width=10, status_line="OK")
    assert frame is not None


def test_align_content_center():
    aligned = align_content(["hello"], width=20, mode="center")
    assert aligned[0].plain.strip() == "hello"


def test_render_base_background_smoke():
    canvas = Canvas()
    render_base_background(canvas, tree_growth=0.5, grass_wind=0.8)
    assert len(canvas.render()) > 0


def test_logo_disperse_animation_updates():
    anim = LogoDisperseAnimation(duration=0.1)
    state = AnimationState()
    state = anim.update(0.1, state)
    assert anim.particles

    fb = FrameBuffer(width=80, height=24)
    anim.render(fb, state)
    assert "background" in fb.layers


def test_rain_animation_updates():
    anim = RainAnimation(duration=0.1)
    state = AnimationState()
    state = anim.update(0.1, state)
    assert anim.particles

    fb = FrameBuffer(width=80, height=24)
    anim.render(fb, state)
    assert "rain" in fb.layers


def test_logo_static_animation_render_smoke():
    anim = LogoStaticAnimation(duration=0.1)
    state = AnimationState()
    fb = FrameBuffer(width=80, height=24)
    anim.render(fb, state)
    assert "logo" in fb.layers


def test_logo_reveal_animation_render_smoke():
    anim = LogoRevealAnimation(duration=0.5)
    state = AnimationState()
    fb = FrameBuffer(width=80, height=24)
    anim.update(0.25, state)
    anim.render(fb, state)
    assert "logo" in fb.layers


def test_animated_experience_exit_flow(monkeypatch):
    from foundry import animated_experience as anim_exp

    class FakeEngine:
        def __init__(self, fps=60, console=None):
            self.calls = 0
        def play(self, anim):
            self.calls += 1
            return "Exit" if self.calls > 1 else None

    fake_anim_mod = types.SimpleNamespace(
        AnimationSequence=lambda seq: "intro",
        InteractiveAnimationEngine=FakeEngine,
    )
    fake_scene_mod = types.SimpleNamespace(
        LogoDisperseAnimation=lambda duration=1.0: "disperse",
        LogoRevealAnimation=lambda duration=1.0: "reveal",
        LogoStaticAnimation=lambda duration=1.0: "static",
        TranquilityAnimation=lambda duration=1.0: "tranquility",
        ForgeAnimation=lambda duration=1.0: "forge",
    )

    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim_mod)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scene_mod)
    monkeypatch.setattr(anim_exp, "run_explore", lambda: None)
    monkeypatch.setattr(anim_exp, "run_generator", lambda interactive=True: None)
    monkeypatch.setattr(anim_exp, "manage_config_menu", lambda: None)
    monkeypatch.setattr(anim_exp, "run_smoke_tests", lambda: None)
    monkeypatch.setattr(anim_exp, "run_view_docs", lambda interactive=True: None)
    monkeypatch.setattr(anim_exp, "pause", lambda: None)

    anim_exp.run_animated_experience()
