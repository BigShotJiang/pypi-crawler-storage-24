# FILE: tests/test_validation_comprehensive.py
"""Comprehensive tests for foundry/actions/validation.py (system validation menu
and script runner — security + control-flow coverage)."""

import sys
from pathlib import Path
from unittest.mock import patch, MagicMock, call

import pytest

from foundry.actions.validation import _run_script, _clear_report, run_smoke_tests


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _all_print_args(mock_console) -> list[str]:
    """Flatten every positional arg passed to console.print as a list of strings."""
    return [str(c.args[0]) for c in mock_console.print.call_args_list if c.args]


# ---------------------------------------------------------------------------
# 1. _run_script — missing script
# ---------------------------------------------------------------------------

class TestRunScriptMissing:
    """_run_script returns immediately and prints an error when the script file
    does not exist under TEMPLATES_DIR."""

    def test_returns_without_raising(self, tmp_path, monkeypatch):
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)
        with patch("foundry.actions.validation.console"):
            _run_script("scripts/verify_templates.py", "Build")
            # no exception expected

    def test_prints_error_message(self, tmp_path, monkeypatch):
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)
        with patch("foundry.actions.validation.console") as mock_console:
            _run_script("scripts/verify_templates.py", "Build")
        args = _all_print_args(mock_console)
        assert any("not found" in a.lower() or "Error" in a for a in args)

    def test_subprocess_never_called(self, tmp_path, monkeypatch):
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)
        with patch("foundry.actions.validation.console"), \
             patch("foundry.actions.validation.subprocess.Popen") as mock_popen:
            _run_script("scripts/missing.py", "T")
        mock_popen.assert_not_called()


# ---------------------------------------------------------------------------
# 2. _run_script — .py success
# ---------------------------------------------------------------------------

class TestRunScriptPyExtension:
    """_run_script uses sys.executable for .py scripts and prints success on
    returncode 0."""

    def test_popen_called_with_sys_executable(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "verify_templates.py"
        script.parent.mkdir(parents=True)
        script.write_text("print('ok')")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        mock_proc = MagicMock()
        mock_proc.stdout = iter(["line\n"])
        mock_proc.returncode = 0

        with patch("foundry.actions.validation.subprocess.Popen",
                   return_value=mock_proc) as mock_popen, \
             patch("foundry.actions.validation.console"):
            _run_script("scripts/verify_templates.py", "Build Verification")

        cmd = mock_popen.call_args[0][0]
        assert cmd[0] == sys.executable
        assert str(script) in cmd[1]

    def test_success_message_printed(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "verify_templates.py"
        script.parent.mkdir(parents=True)
        script.write_text("")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        mock_proc = MagicMock()
        mock_proc.stdout = iter([])
        mock_proc.returncode = 0

        with patch("foundry.actions.validation.subprocess.Popen",
                   return_value=mock_proc), \
             patch("foundry.actions.validation.console") as mock_console:
            _run_script("scripts/verify_templates.py", "Build Verification")

        args = _all_print_args(mock_console)
        assert any("Completed Successfully" in a for a in args)

    def test_stdout_lines_printed(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "verify_templates.py"
        script.parent.mkdir(parents=True)
        script.write_text("")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        mock_proc = MagicMock()
        mock_proc.stdout = iter(["output line\n"])
        mock_proc.returncode = 0

        with patch("foundry.actions.validation.subprocess.Popen",
                   return_value=mock_proc), \
             patch("foundry.actions.validation.console") as mock_console:
            _run_script("scripts/verify_templates.py", "Build")

        args = _all_print_args(mock_console)
        assert any("output line" in a for a in args)


# ---------------------------------------------------------------------------
# 3. _run_script — .py failure
# ---------------------------------------------------------------------------

class TestRunScriptPyFailed:
    """_run_script prints a failure message when subprocess returncode != 0."""

    def test_failure_message_on_nonzero_returncode(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "verify_templates.py"
        script.parent.mkdir(parents=True)
        script.write_text("")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        mock_proc = MagicMock()
        mock_proc.stdout = iter([])
        mock_proc.returncode = 1

        with patch("foundry.actions.validation.subprocess.Popen",
                   return_value=mock_proc), \
             patch("foundry.actions.validation.console") as mock_console:
            _run_script("scripts/verify_templates.py", "Build Verification")

        args = _all_print_args(mock_console)
        assert any("Failed" in a for a in args)

    def test_no_exception_on_nonzero_returncode(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "verify_templates.py"
        script.parent.mkdir(parents=True)
        script.write_text("")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        mock_proc = MagicMock()
        mock_proc.stdout = iter([])
        mock_proc.returncode = 2

        with patch("foundry.actions.validation.subprocess.Popen",
                   return_value=mock_proc), \
             patch("foundry.actions.validation.console"):
            _run_script("scripts/verify_templates.py", "Build")  # no raise


# ---------------------------------------------------------------------------
# 4. _run_script — .sh extension
# ---------------------------------------------------------------------------

class TestRunScriptShExtension:
    """_run_script uses /bin/sh as the interpreter for .sh scripts."""

    def test_sh_cmd_uses_bin_sh(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "run.sh"
        script.parent.mkdir(parents=True)
        script.write_text("#!/bin/sh\necho ok")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        mock_proc = MagicMock()
        mock_proc.stdout = iter([])
        mock_proc.returncode = 0

        with patch("foundry.actions.validation.subprocess.Popen",
                   return_value=mock_proc) as mock_popen, \
             patch("foundry.actions.validation.console"):
            _run_script("scripts/run.sh", "Shell Test")

        cmd = mock_popen.call_args[0][0]
        assert cmd[0] == "/bin/sh"
        assert str(script) in cmd[1]


# ---------------------------------------------------------------------------
# 5. _run_script — .ps1 extension
# ---------------------------------------------------------------------------

class TestRunScriptPs1Extension:
    """_run_script uses powershell.exe -File for .ps1 scripts."""

    def test_ps1_cmd_uses_powershell(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "setup.ps1"
        script.parent.mkdir(parents=True)
        script.write_text("Write-Output 'ok'")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        mock_proc = MagicMock()
        mock_proc.stdout = iter([])
        mock_proc.returncode = 0

        with patch("foundry.actions.validation.subprocess.Popen",
                   return_value=mock_proc) as mock_popen, \
             patch("foundry.actions.validation.console"):
            _run_script("scripts/setup.ps1", "PowerShell Test")

        cmd = mock_popen.call_args[0][0]
        assert cmd[0] == "powershell.exe"
        assert cmd[1] == "-File"
        assert str(script) in cmd[2]


# ---------------------------------------------------------------------------
# 6. _run_script — forbidden extension (H-18 security)
# ---------------------------------------------------------------------------

class TestRunScriptForbiddenExtension:
    """_run_script raises ValueError (caught internally) for extensions not in
    the allowlist (.py, .ps1, .sh) and prints an error — never executes."""

    @pytest.mark.parametrize("script_name", [
        "scripts/hack.exe",
        "scripts/evil.rb",
        "scripts/payload.js",
        "scripts/dangerous.bat",
    ])
    def test_forbidden_extension_no_raise(self, script_name, tmp_path, monkeypatch):
        full_script = tmp_path / script_name
        full_script.parent.mkdir(parents=True, exist_ok=True)
        full_script.write_bytes(b"malicious")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        with patch("foundry.actions.validation.subprocess.Popen") as mock_popen, \
             patch("foundry.actions.validation.console") as mock_console:
            _run_script(script_name, "Bad Script")

        mock_popen.assert_not_called()
        args = _all_print_args(mock_console)
        assert any("Failed to execute" in a or "Refusing" in a for a in args)

    def test_no_extension_file_is_rejected(self, tmp_path, monkeypatch):
        no_ext = tmp_path / "scripts" / "noscript"
        no_ext.parent.mkdir(parents=True)
        no_ext.write_bytes(b"")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        with patch("foundry.actions.validation.subprocess.Popen") as mock_popen, \
             patch("foundry.actions.validation.console"):
            _run_script("scripts/noscript", "No Ext")

        mock_popen.assert_not_called()


# ---------------------------------------------------------------------------
# 7. _run_script — subprocess OSError
# ---------------------------------------------------------------------------

class TestRunScriptSubprocessException:
    """When Popen raises OSError, _run_script prints an error and does not
    re-raise."""

    def test_oserror_suppressed(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "verify_templates.py"
        script.parent.mkdir(parents=True)
        script.write_text("")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        with patch("foundry.actions.validation.subprocess.Popen",
                   side_effect=OSError("exec failed")), \
             patch("foundry.actions.validation.console") as mock_console:
            _run_script("scripts/verify_templates.py", "Build")

        args = _all_print_args(mock_console)
        assert any("Failed to execute" in a for a in args)

    def test_file_not_found_suppressed(self, tmp_path, monkeypatch):
        script = tmp_path / "scripts" / "verify_templates.py"
        script.parent.mkdir(parents=True)
        script.write_text("")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        with patch("foundry.actions.validation.subprocess.Popen",
                   side_effect=FileNotFoundError("interpreter missing")), \
             patch("foundry.actions.validation.console"):
            _run_script("scripts/verify_templates.py", "Build")  # no raise



# ---------------------------------------------------------------------------
# 8. _clear_report — normal cases
# ---------------------------------------------------------------------------

class TestClearReport:
    """_clear_report deletes verification_results.csv when present, and
    silently skips when it is absent."""

    def test_existing_csv_is_deleted(self, tmp_path, monkeypatch):
        csv = tmp_path / "verification_results.csv"
        csv.write_text("col1,col2\n1,2\n")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)
        with patch("foundry.actions.validation.console"):
            _clear_report()
        assert not csv.exists()

    def test_success_message_printed_after_delete(self, tmp_path, monkeypatch):
        csv = tmp_path / "verification_results.csv"
        csv.write_text("data")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)
        with patch("foundry.actions.validation.console") as mock_console:
            _clear_report()
        assert mock_console.print.called

    def test_missing_csv_does_not_raise(self, tmp_path, monkeypatch):
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)
        with patch("foundry.actions.validation.console"):
            _clear_report()  # should not raise

    def test_missing_csv_no_console_print(self, tmp_path, monkeypatch):
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)
        with patch("foundry.actions.validation.console") as mock_console:
            _clear_report()
        mock_console.print.assert_not_called()


# ---------------------------------------------------------------------------
# 9. _clear_report — unlink failure
# ---------------------------------------------------------------------------

class TestClearReportUnlinkFails:
    """When unlink raises, _clear_report prints a warning and does not re-raise."""

    def test_unlink_permission_error_suppressed(self, tmp_path, monkeypatch):
        csv = tmp_path / "verification_results.csv"
        csv.write_text("data")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        with patch.object(Path, "unlink", side_effect=PermissionError("locked")), \
             patch("foundry.actions.validation.console") as mock_console:
            _clear_report()  # must not raise

        args = _all_print_args(mock_console)
        assert any("Warning" in a or "Could not" in a for a in args)

    def test_unlink_oserror_suppressed(self, tmp_path, monkeypatch):
        csv = tmp_path / "verification_results.csv"
        csv.write_text("data")
        monkeypatch.setattr("foundry.actions.validation.TEMPLATES_DIR", tmp_path)

        with patch.object(Path, "unlink", side_effect=OSError("disk")), \
             patch("foundry.actions.validation.console"):
            _clear_report()  # must not raise


# ---------------------------------------------------------------------------
# 10. run_smoke_tests — "Back" exits loop
# ---------------------------------------------------------------------------

class TestRunSmokeTestsBack:
    """Selecting 'Back' exits the while-loop immediately without calling any
    script runner."""

    def test_back_exits_immediately(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script") as mock_run, \
             patch("foundry.actions.validation._pause") as mock_pause:
            mock_sel.return_value.ask.return_value = "Back"
            run_smoke_tests()

        mock_run.assert_not_called()
        mock_pause.assert_not_called()

    def test_back_on_second_iteration(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script"), \
             patch("foundry.actions.validation._pause"):
            mock_sel.return_value.ask.side_effect = ["smoke", "Back"]
            run_smoke_tests()  # should finish cleanly


# ---------------------------------------------------------------------------
# 11. run_smoke_tests — "smoke" choice
# ---------------------------------------------------------------------------

class TestRunSmokeTestsSmoke:
    """Selecting 'smoke' calls _run_script with verify_templates.py and _pause
    exactly once, then 'Back' exits."""

    def test_smoke_calls_correct_script(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script") as mock_run, \
             patch("foundry.actions.validation._pause") as mock_pause:
            mock_sel.return_value.ask.side_effect = ["smoke", "Back"]
            run_smoke_tests()

        mock_run.assert_called_once_with(
            "scripts/verify_templates.py", "Build Verification"
        )
        mock_pause.assert_called_once()

    def test_install_calls_correct_script(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script") as mock_run, \
             patch("foundry.actions.validation._pause") as mock_pause:
            mock_sel.return_value.ask.side_effect = ["install", "Back"]
            run_smoke_tests()

        mock_run.assert_called_once_with(
            "scripts/verify_installation.py", "Installation Verification"
        )
        mock_pause.assert_called_once()

    def test_runtime_calls_correct_script(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script") as mock_run, \
             patch("foundry.actions.validation._pause") as mock_pause:
            mock_sel.return_value.ask.side_effect = ["runtime", "Back"]
            run_smoke_tests()

        mock_run.assert_called_once_with(
            "scripts/verify_runtime.py", "Runtime Verification"
        )
        mock_pause.assert_called_once()


# ---------------------------------------------------------------------------
# 12. run_smoke_tests — "all" choice
# ---------------------------------------------------------------------------

class TestRunSmokeTestsAll:
    """Selecting 'all' calls _clear_report once, then _run_script three times in
    the correct order, then _pause once."""

    def test_all_calls_clear_report(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script"), \
             patch("foundry.actions.validation._pause"), \
             patch("foundry.actions.validation._clear_report") as mock_clear:
            mock_sel.return_value.ask.side_effect = ["all", "Back"]
            run_smoke_tests()

        mock_clear.assert_called_once()

    def test_all_calls_three_scripts(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script") as mock_run, \
             patch("foundry.actions.validation._pause"), \
             patch("foundry.actions.validation._clear_report"):
            mock_sel.return_value.ask.side_effect = ["all", "Back"]
            run_smoke_tests()

        assert mock_run.call_count == 3

    def test_all_scripts_called_in_order(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script") as mock_run, \
             patch("foundry.actions.validation._pause"), \
             patch("foundry.actions.validation._clear_report"):
            mock_sel.return_value.ask.side_effect = ["all", "Back"]
            run_smoke_tests()

        mock_run.assert_has_calls([
            call("scripts/verify_templates.py", "Build Verification"),
            call("scripts/verify_installation.py", "Installation Verification"),
            call("scripts/verify_runtime.py", "Runtime Verification"),
        ], any_order=False)

    def test_all_pause_called_once(self, monkeypatch):
        with patch("foundry.actions.validation.questionary.select") as mock_sel, \
             patch("foundry.actions.validation._run_script"), \
             patch("foundry.actions.validation._pause") as mock_pause, \
             patch("foundry.actions.validation._clear_report"):
            mock_sel.return_value.ask.side_effect = ["all", "Back"]
            run_smoke_tests()

        mock_pause.assert_called_once()
