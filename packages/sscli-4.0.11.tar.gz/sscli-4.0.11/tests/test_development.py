import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
import sys
import os
from foundry.actions.development import (
    get_venv_path,
    get_stack_cli_root,
    get_local_version,
)

@pytest.fixture
def mock_foundry_root(tmp_path):
    # Setup a mock monorepo structure
    root = tmp_path / "monorepo"
    root.mkdir()
    (root / ".github").mkdir()
    tooling = (root / "tooling")
    tooling.mkdir()
    stack_cli = (tooling / "stack-cli")
    stack_cli.mkdir()
    (stack_cli / "pyproject.toml").write_text('name = "sscli"\nversion = "2.0.0"')
    return root

def test_get_stack_cli_root(mock_foundry_root):
    with patch("foundry.actions.development.FOUNDRY_ROOT", mock_foundry_root):
        root = get_stack_cli_root()
        assert root == mock_foundry_root / "tooling" / "stack-cli"

def test_get_local_version_valid(mock_foundry_root):
    with patch("foundry.actions.development.FOUNDRY_ROOT", mock_foundry_root):
        version = get_local_version()
        assert version == "2.0.0"

def test_get_local_version_missing():
    with patch("foundry.actions.development.get_stack_cli_root", return_value=None):
        version = get_local_version()
        assert version == "unknown"

def test_get_venv_path_env(tmp_path):
    venv = tmp_path / "venv"
    venv.mkdir()
    (venv / "bin").mkdir()
    (venv / "bin" / "pip").touch()
    
    with patch.dict(os.environ, {"VIRTUAL_ENV": str(venv)}):
        path = get_venv_path()
        assert path == venv

def test_get_venv_path_fallback(mock_foundry_root):
    # Create venv folder inside stack-cli root
    stack_cli_root = mock_foundry_root / "tooling" / "stack-cli"
    venv = stack_cli_root / "venv"
    venv.mkdir()
    (venv / "bin").mkdir()
    (venv / "bin" / "python").touch()
    
    with patch("foundry.actions.development.get_stack_cli_root", return_value=stack_cli_root):
        with patch.dict(os.environ, {}, clear=True):
            path = get_venv_path()
            assert path == venv
