"""
Full coverage tests for foundry/animated_experience.py.
Targets the following missing branches:
  - Animation import failure (lines 27-29)
  - KeyboardInterrupt during intro (lines 46-50)
  - Generic Exception during intro (except branch ~50)
  - Menu loop continuation after each action (74->53)
  - KeyboardInterrupt in menu loop (78-79)
  - Generic Exception in menu loop (80-83)
  - None choice breaks loop
"""
import sys
import types

import pytest
from types import SimpleNamespace

from foundry import animated_experience


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fake_modules(engine_cls):
    """Return (fake_anim, fake_scenes) with the given engine class."""
    class _Seq:
        def __init__(self, _a):
            pass

    class _Scene:
        def __init__(self, duration=None):
            pass

    fake_anim = types.SimpleNamespace(
        AnimationSequence=_Seq,
        InteractiveAnimationEngine=engine_cls,
    )
    fake_scenes = types.SimpleNamespace(
        LogoDisperseAnimation=_Scene,
        LogoRevealAnimation=_Scene,
        LogoStaticAnimation=_Scene,
        TranquilityAnimation=_Scene,
        ForgeAnimation=_Scene,
    )
    return fake_anim, fake_scenes


def _noop_license():
    return {"tier": "free"}


# ---------------------------------------------------------------------------
# TASK 1.1 — Animation import failure (lines 27-29)
# ---------------------------------------------------------------------------

def test_animation_import_failure(monkeypatch):
    """Setting foundry.animations to None triggers ImportError inside the function,
    prints the error banner, and returns immediately."""
    printed = []
    monkeypatch.setattr(
        animated_experience.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )
    # None in sys.modules causes ImportError on 'from foundry.animations import ...'
    monkeypatch.setitem(sys.modules, "foundry.animations", None)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", None)

    animated_experience.run_animated_experience()

    assert any("Animation system not fully loaded" in msg for msg in printed)


# ---------------------------------------------------------------------------
# TASK 1.2 — KeyboardInterrupt during intro (lines 46-50)
# ---------------------------------------------------------------------------

def test_intro_keyboard_interrupt(monkeypatch):
    """engine.play(intro) raises KeyboardInterrupt → prints Goodbye! and returns."""
    printed = []
    monkeypatch.setattr(
        animated_experience.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)

    class RaisesKBIEngine:
        def __init__(self, fps, console):
            pass

        def play(self, _scene):
            raise KeyboardInterrupt

    fake_anim, fake_scenes = _make_fake_modules(RaisesKBIEngine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert any("Goodbye" in msg for msg in printed)


# ---------------------------------------------------------------------------
# TASK 1.3 — Generic Exception during intro (except Exception branch ~50)
# ---------------------------------------------------------------------------

def test_intro_generic_exception(monkeypatch):
    """engine.play(intro) raises RuntimeError → prints error, continues to menu loop."""
    printed = []
    monkeypatch.setattr(
        animated_experience.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)

    class IntroErrorEngine:
        def __init__(self, fps, console):
            self._returns = [RuntimeError("test intro error"), "Exit"]

        def play(self, _scene):
            ret = self._returns.pop(0)
            if isinstance(ret, Exception):
                raise ret
            return ret

    fake_anim, fake_scenes = _make_fake_modules(IntroErrorEngine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert any("test intro error" in msg for msg in printed)


# ---------------------------------------------------------------------------
# TASK 1.4 — Menu: Explore Templates then Exit (loop continuation 74->53)
# ---------------------------------------------------------------------------

def test_menu_explore_then_exit(monkeypatch):
    """Intro OK, first menu returns 'Explore Templates', second returns 'Exit'."""
    called = {"explore": 0, "pause": 0}
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)
    monkeypatch.setattr(animated_experience, "run_explore", lambda: called.__setitem__("explore", called["explore"] + 1))
    monkeypatch.setattr(animated_experience, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))
    monkeypatch.setattr(animated_experience.console, "print", lambda *a, **k: None)

    class Engine:
        def __init__(self, fps, console):
            self._r = [None, "Explore Templates", "Exit"]

        def play(self, _s):
            return self._r.pop(0)

    fake_anim, fake_scenes = _make_fake_modules(Engine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert called["explore"] == 1
    assert called["pause"] == 1


# ---------------------------------------------------------------------------
# TASK 1.5 — Menu: Generate Project then Exit
# ---------------------------------------------------------------------------

def test_menu_generate_then_exit(monkeypatch):
    called = {"generate": 0}
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)
    monkeypatch.setattr(animated_experience, "run_generator", lambda interactive: called.__setitem__("generate", called["generate"] + 1))
    monkeypatch.setattr(animated_experience, "pause", lambda: None)
    monkeypatch.setattr(animated_experience.console, "print", lambda *a, **k: None)

    class Engine:
        def __init__(self, fps, console):
            self._r = [None, "Generate Project", "Exit"]

        def play(self, _s):
            return self._r.pop(0)

    fake_anim, fake_scenes = _make_fake_modules(Engine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert called["generate"] == 1


# ---------------------------------------------------------------------------
# TASK 1.6 — Menu: Manage Config then Exit
# ---------------------------------------------------------------------------

def test_menu_config_then_exit(monkeypatch):
    called = {"config": 0}
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)
    monkeypatch.setattr(animated_experience, "manage_config_menu", lambda: called.__setitem__("config", called["config"] + 1))
    monkeypatch.setattr(animated_experience.console, "print", lambda *a, **k: None)

    class Engine:
        def __init__(self, fps, console):
            self._r = [None, "Manage Config", "Exit"]

        def play(self, _s):
            return self._r.pop(0)

    fake_anim, fake_scenes = _make_fake_modules(Engine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert called["config"] == 1


# ---------------------------------------------------------------------------
# TASK 1.7 — Menu: System Validation then Exit
# ---------------------------------------------------------------------------

def test_menu_validation_then_exit(monkeypatch):
    called = {"validation": 0}
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)
    monkeypatch.setattr(animated_experience, "run_smoke_tests", lambda: called.__setitem__("validation", called["validation"] + 1))
    monkeypatch.setattr(animated_experience, "pause", lambda: None)
    monkeypatch.setattr(animated_experience.console, "print", lambda *a, **k: None)

    class Engine:
        def __init__(self, fps, console):
            self._r = [None, "System Validation", "Exit"]

        def play(self, _s):
            return self._r.pop(0)

    fake_anim, fake_scenes = _make_fake_modules(Engine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert called["validation"] == 1


# ---------------------------------------------------------------------------
# TASK 1.8 — Menu: View Docs then Exit
# ---------------------------------------------------------------------------

def test_menu_view_docs_then_exit(monkeypatch):
    called = {"docs": 0}
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)
    monkeypatch.setattr(animated_experience, "run_view_docs", lambda **_k: called.__setitem__("docs", called["docs"] + 1))
    monkeypatch.setattr(animated_experience, "pause", lambda: None)
    monkeypatch.setattr(animated_experience.console, "print", lambda *a, **k: None)

    class Engine:
        def __init__(self, fps, console):
            self._r = [None, "View Docs", "Exit"]

        def play(self, _s):
            return self._r.pop(0)

    fake_anim, fake_scenes = _make_fake_modules(Engine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert called["docs"] == 1


# ---------------------------------------------------------------------------
# TASK 1.9 — Menu: KeyboardInterrupt breaks loop (lines 78-79)
# ---------------------------------------------------------------------------

def test_menu_keyboard_interrupt(monkeypatch):
    """First menu engine.play raises KeyboardInterrupt → prints Goodbye! and breaks."""
    printed = []
    monkeypatch.setattr(
        animated_experience.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)

    class MenuKBIEngine:
        def __init__(self, fps, console):
            self._calls = 0

        def play(self, _scene):
            self._calls += 1
            if self._calls == 1:
                return None  # intro succeeds
            raise KeyboardInterrupt  # menu raises KBI

    fake_anim, fake_scenes = _make_fake_modules(MenuKBIEngine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert any("Goodbye" in msg for msg in printed)


# ---------------------------------------------------------------------------
# TASK 1.10 — Menu: Generic Exception breaks loop (lines 80-83)
# ---------------------------------------------------------------------------

def test_menu_generic_exception(monkeypatch):
    """First menu engine.play raises RuntimeError → prints error and breaks."""
    printed = []
    monkeypatch.setattr(
        animated_experience.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)

    class MenuErrorEngine:
        def __init__(self, fps, console):
            self._calls = 0

        def play(self, _scene):
            self._calls += 1
            if self._calls == 1:
                return None  # intro ok
            raise RuntimeError("menu crashed")

    fake_anim, fake_scenes = _make_fake_modules(MenuErrorEngine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    assert any("menu crashed" in msg for msg in printed)


# ---------------------------------------------------------------------------
# TASK 1.11 — Menu: None choice breaks loop immediately
# ---------------------------------------------------------------------------

def test_menu_none_choice(monkeypatch):
    """engine.play(TranquilityAnimation()) returns None → breaks loop (not choice is True)."""
    printed = []
    monkeypatch.setattr(
        animated_experience.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )
    monkeypatch.setattr(animated_experience, "get_current_license_info", _noop_license)

    class NoneChoiceEngine:
        def __init__(self, fps, console):
            self._calls = 0

        def play(self, _scene):
            self._calls += 1
            return None  # both intro and menu return None

    fake_anim, fake_scenes = _make_fake_modules(NoneChoiceEngine)
    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    animated_experience.run_animated_experience()

    # None choice triggers "Goodbye!" message from the `if not choice or choice == "Exit"` branch
    assert any("Goodbye" in msg for msg in printed)
