import sys
import types
from pathlib import Path
import subprocess

import pytest

from foundry.tools.development import build_tools


def test_get_sscli_version_from_pyproject(tmp_path, monkeypatch):
    pkg_root = tmp_path / "pkg"
    pkg_root.mkdir()
    (pkg_root / "pyproject.toml").write_text("[project]\nversion = '9.9.9'\n")

    fake_foundry = types.SimpleNamespace(__file__=str(pkg_root / "foundry" / "__init__.py"))
    (pkg_root / "foundry").mkdir()
    (pkg_root / "foundry" / "__init__.py").write_text("# stub\n")

    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)

    version = build_tools.get_sscli_version()
    assert version == "9.9.9"


def test_get_sscli_version_no_tomllib(tmp_path, monkeypatch):
    """Test fallback when tomllib/tomli not available"""
    pkg_root = tmp_path / "pkg"
    pkg_root.mkdir()
    (pkg_root / "pyproject.toml").write_text("[project]\nversion = '9.9.9'\n")

    fake_foundry = types.SimpleNamespace(__file__=str(pkg_root / "foundry" / "__init__.py"))
    (pkg_root / "foundry").mkdir()
    (pkg_root / "foundry" / "__init__.py").write_text("# stub\n")

    # Block tomllib and tomli imports
    import builtins
    real_import = builtins.__import__

    def mock_import(name, *args):
        if name in ("tomllib", "tomli"):
            raise ImportError(f"No module named '{name}'")
        return real_import(name, *args)

    monkeypatch.setattr(builtins, "__import__", mock_import)
    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)

    version = build_tools.get_sscli_version()
    assert version == "unknown"


def test_get_sscli_version_file_not_found(tmp_path, monkeypatch):
    """Test when pyproject.toml doesn't exist"""
    pkg_root = tmp_path / "pkg"
    pkg_root.mkdir()
    # Don't create pyproject.toml

    fake_foundry = types.SimpleNamespace(__file__=str(pkg_root / "foundry" / "__init__.py"))
    (pkg_root / "foundry").mkdir()
    (pkg_root / "foundry" / "__init__.py").write_text("# stub\n")

    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)

    version = build_tools.get_sscli_version()
    assert version == "unknown"


def test_get_sscli_version_exception(monkeypatch):
    """Test exception handling in get_sscli_version"""
    
    # Make foundry module raise an exception
    fake_foundry = types.SimpleNamespace()
    # Don't set __file__ attribute to trigger exception
    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)

    version = build_tools.get_sscli_version()
    assert version == "unknown"


def test_check_build_differences(monkeypatch):
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "1.0.0")

    class FakeResult:
        returncode = 0
        stdout = "Name: sscli\nVersion: 1.0.0\n"
        stderr = ""

    monkeypatch.setattr(build_tools.subprocess, "run", lambda *a, **k: FakeResult())
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_differences()
    assert any("Versions match" in str(msg) for msg in printed)


def test_check_build_differences_mismatch(monkeypatch):
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "1.0.0")

    class FakeResult:
        returncode = 0
        stdout = "Name: sscli\nVersion: 2.0.0\n"
        stderr = ""

    monkeypatch.setattr(build_tools.subprocess, "run", lambda *a, **k: FakeResult())
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_differences()
    assert any("Versions differ" in str(msg) for msg in printed)


def test_check_build_differences_not_installed(monkeypatch):
    """Test when sscli is not installed via pip"""
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "1.0.0")

    class FakeResult:
        returncode = 1
        stdout = ""
        stderr = "ERROR: Package not found"

    monkeypatch.setattr(build_tools.subprocess, "run", lambda *a, **k: FakeResult())
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_differences()
    assert any("not installed" in str(msg) for msg in printed)


def test_check_build_differences_exception(monkeypatch):
    """Test exception handling in check_build_differences"""
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "1.0.0")

    def raise_error(*args, **kwargs):
        raise RuntimeError("subprocess failed")

    monkeypatch.setattr(build_tools.subprocess, "run", raise_error)
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_differences()
    assert any("Error checking versions" in str(msg) for msg in printed)


def test_check_build_version_local_dev(monkeypatch):
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "1.0.0")
    fake_foundry = types.SimpleNamespace(__file__="/tmp/.venv/lib/python3.12/site-packages/foundry/__init__.py")
    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_version()
    assert any("Local development build" in str(msg) for msg in printed)


def test_check_build_version_site_packages(monkeypatch):
    """Test detection of pip-installed package"""
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "1.0.0")
    fake_foundry = types.SimpleNamespace(__file__="/usr/lib/python3.12/site-packages/foundry/__init__.py")
    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_version()
    assert any("Installed pip package" in str(msg) for msg in printed)


def test_check_build_version_exception(monkeypatch):
    """Test exception handling in check_build_version"""
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "1.0.0")
    
    # Make foundry module raise exception
    fake_foundry = types.SimpleNamespace()
    # Missing __file__ attribute
    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)
    
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_version()
    assert any("Could not determine source" in str(msg) for msg in printed)


def test_show_development_info_env(monkeypatch):
    monkeypatch.setenv("VIRTUAL_ENV", "/tmp/venv")
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.show_development_info()
    assert printed


def test_show_development_info_no_venv(monkeypatch):
    """Test when no virtual environment is active"""
    monkeypatch.delenv("VIRTUAL_ENV", raising=False)
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.show_development_info()
    assert any("Not detected" in str(msg) for msg in printed)


def test_show_development_info_package_import_error(monkeypatch):
    """Test when a package is not installed"""
    import builtins
    import sys
    
    # Save the original __import__
    original_import = builtins.__import__
    
    def mock_import(name, *args, **kwargs):
        # Only block 'typer' at the top level, allow everything else
        if name == "typer" and not args:
            raise ImportError("No module named 'typer'")
        return original_import(name, *args, **kwargs)
    
    monkeypatch.setattr(builtins, "__import__", mock_import)
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.show_development_info()
    
    output = "\n".join(str(msg) for msg in printed)
    assert "NOT INSTALLED" in output or "✗ typer" in output


def test_check_build_version_custom_location(monkeypatch):
    monkeypatch.setattr(build_tools, "get_sscli_version", lambda: "2.0.0")
    fake_foundry = types.SimpleNamespace(__file__="/opt/custom/foundry/__init__.py")
    monkeypatch.setitem(sys.modules, "foundry", fake_foundry)
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.check_build_version()

    assert any("Custom location" in str(msg) for msg in printed)


def test_run_development_tests_executes(monkeypatch):
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.run_development_tests()

    assert printed


def test_run_development_tests_import_failure(monkeypatch):
    """Test import failure handling in run_development_tests"""
    import sys
    
    # Store original modules
    original_cli = sys.modules.get('foundry.cli')
    original_animations = sys.modules.get('foundry.animations')
    original_auth = sys.modules.get('foundry.auth')
    original_gate = sys.modules.get('foundry.gate')
    
    # Remove cli module to trigger ImportError
    if 'foundry.cli' in sys.modules:
        del sys.modules['foundry.cli']
    
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.run_development_tests()
    
    # Restore original modules
    if original_cli:
        sys.modules['foundry.cli'] = original_cli
    if original_animations:
        sys.modules['foundry.animations'] = original_animations
    if original_auth:
        sys.modules['foundry.auth'] = original_auth
    if original_gate:
        sys.modules['foundry.gate'] = original_gate
    
    assert any("Import failed" in str(msg) for msg in printed)


def test_run_development_tests_environment_failure(monkeypatch):
    """Test environment check failure in run_development_tests"""
    
    def mock_platform_system():
        raise RuntimeError("Platform check failed")
    
    monkeypatch.setattr(build_tools.platform, "system", mock_platform_system)
    printed = []
    monkeypatch.setattr(build_tools.console, "print", lambda msg: printed.append(msg))

    build_tools.run_development_tests()
    assert any("Environment check failed" in str(msg) for msg in printed)
