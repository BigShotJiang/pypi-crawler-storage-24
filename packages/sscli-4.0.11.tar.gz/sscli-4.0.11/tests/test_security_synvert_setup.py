"""
Security tests for:
 - C-1  : synvert_adapter._safe_synvert_input() injection prevention
 - C-15 : synvert_adapter gem install pins version + --no-document
 - H-12 : setup.run_setup() confirms before executing scripts
 - H-16 : project_validator SKIP → FAIL in exception handlers
 - H-25 : observability_interactive output_path validator
 - H-26 : observability_interactive search_path validator
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Replicate the validators exactly as they appear in observability_interactive.py
# so we can test them in isolation without triggering questionary I/O.

_output_path_validator = lambda x: (  # noqa: E731
    True
    if not x
    else (
        True
        if not Path(x).is_absolute()
        else (
            True
            if Path(x).resolve().is_relative_to(Path.cwd())
            or Path(x).resolve().is_relative_to(Path.home())
            else "Absolute path must be within your home or working directory"
        )
    )
)

_search_path_validator = lambda x: not x or Path(x).exists() or "Path does not exist"  # noqa: E731


# ---------------------------------------------------------------------------
# C-1: _safe_synvert_input injection prevention
# ---------------------------------------------------------------------------

class TestSafeSnvertInput:
    """C-1 – allowlist-based input sanitisation."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from foundry.tools.synvert_adapter import _safe_synvert_input
        self.fn = _safe_synvert_input

    def test_safe_name_returned_unchanged(self):
        assert self.fn("safe-name", "label") == "safe-name"

    def test_path_with_slash_and_dot_accepted(self):
        assert self.fn("app/models/user.rb", "path") == "app/models/user.rb"

    def test_shell_injection_raises_value_error(self):
        with pytest.raises(ValueError, match="Unsafe synvert input"):
            self.fn("'; system('id') #", "label")

    def test_semicolon_raises_value_error(self):
        with pytest.raises(ValueError):
            self.fn("foo; bar", "label")

    def test_backtick_raises_value_error(self):
        with pytest.raises(ValueError):
            self.fn("`id`", "label")

    def test_dollar_sign_raises_value_error(self):
        with pytest.raises(ValueError):
            self.fn("$(whoami)", "label")

    def test_empty_string_raises_value_error(self):
        """Empty string does not match the 1-500 char allowlist."""
        with pytest.raises(ValueError):
            self.fn("", "label")

    def test_newline_raises_value_error(self):
        with pytest.raises(ValueError):
            self.fn("foo\nbar", "label")


# ---------------------------------------------------------------------------
# C-1: SynvertAdapter rejects malicious path before snippet generation
# ---------------------------------------------------------------------------

class TestSynvertAdapterInjectionPrevention:
    """C-1 – SynvertAdapter must call _safe_synvert_input before any Ruby."""

    @pytest.fixture
    def adapter(self, tmp_path):
        """Return a SynvertAdapter with Ruby/gem checks mocked out."""
        ruby_ok = MagicMock(returncode=0, stdout="ruby 3.2.0", stderr="")
        gem_ok = MagicMock(returncode=0, stdout="synvert-core (1.23.0)", stderr="")

        with patch("subprocess.run", side_effect=[ruby_ok, gem_ok]):
            from foundry.tools.synvert_adapter import SynvertAdapter
            return SynvertAdapter(tmp_path)

    def test_malicious_path_raises_before_snippet(self, adapter, tmp_path):
        """Verify ValueError is raised for a shell-injection path."""
        evil_path = "'; exec('rm -rf /') #"
        with pytest.raises(ValueError, match="Unsafe synvert input"):
            from foundry.tools.synvert_adapter import _safe_synvert_input
            _safe_synvert_input(evil_path, "path")


# ---------------------------------------------------------------------------
# C-15: gem install pins version and adds --no-document
# ---------------------------------------------------------------------------

class TestSynvertGemInstallPinsVersion:
    """C-15 – gem install must use a pinned version and --no-document."""

    def test_gem_install_uses_pinned_version(self, tmp_path):
        from foundry.tools.synvert_adapter import _SYNVERT_CORE_VERSION

        # First call: ruby -v succeeds.
        ruby_result = MagicMock(returncode=0, stdout="ruby 3.2.0", stderr="")
        # Second call: gem list returns nothing (not installed).
        gem_list_result = MagicMock(returncode=0, stdout="", stderr="")
        # Third call: gem install.
        gem_install_result = MagicMock(returncode=0, stdout="Successfully installed", stderr="")
        # Fourth call: post-install gem list verification.
        gem_verify_result = MagicMock(returncode=0, stdout=f"synvert-core ({_SYNVERT_CORE_VERSION})", stderr="")

        side_effects = [ruby_result, gem_list_result, gem_install_result, gem_verify_result]

        with patch("subprocess.run", side_effect=side_effects) as mock_run:
            from foundry.tools.synvert_adapter import SynvertAdapter
            SynvertAdapter(tmp_path)

        # Find the gem install call
        gem_install_call = None
        for c in mock_run.call_args_list:
            args = c.args[0] if c.args else c.kwargs.get("args", [])
            if "gem" in args and "install" in args:
                gem_install_call = args
                break

        assert gem_install_call is not None, "gem install was never called"
        assert "--version" in gem_install_call, "--version flag missing from gem install"
        assert _SYNVERT_CORE_VERSION in gem_install_call, (
            f"Pinned version {_SYNVERT_CORE_VERSION!r} not in gem install args"
        )
        assert "--no-document" in gem_install_call, "--no-document flag missing"

    def test_gem_install_not_called_when_already_installed(self, tmp_path):
        """If synvert-core is already listed, gem install must NOT run."""
        ruby_result = MagicMock(returncode=0, stdout="ruby 3.2.0", stderr="")
        gem_list_result = MagicMock(
            returncode=0, stdout="synvert-core (1.23.0)", stderr=""
        )

        with patch("subprocess.run", side_effect=[ruby_result, gem_list_result]) as mock_run:
            from foundry.tools.synvert_adapter import SynvertAdapter
            SynvertAdapter(tmp_path)

        install_calls = [
            c for c in mock_run.call_args_list
            if "install" in (c.args[0] if c.args else [])
        ]
        assert not install_calls, "gem install should NOT run when gem is already present"


# ---------------------------------------------------------------------------
# H-25: output_path validator
# ---------------------------------------------------------------------------

class TestOutputPathValidator:
    """H-25 – output_path must be relative or inside home/cwd."""

    def test_empty_string_accepted(self):
        """Empty → user will take the default; must be accepted."""
        assert _output_path_validator("") is True

    def test_relative_path_accepted(self):
        assert _output_path_validator("./reports/output.json") is True

    def test_relative_path_no_dot_accepted(self):
        assert _output_path_validator("reports/output.json") is True

    def test_etc_cron_rejected(self):
        result = _output_path_validator("/etc/cron.d/evil")
        assert result != True, "Absolute path outside home/cwd must be rejected"
        assert isinstance(result, str), "Rejected value should be an error message string"

    def test_tilde_ssh_key_accepted(self):
        """~/.ssh/authorized_keys starts with ~ — not absolute — so accepted."""
        # Path("~/.ssh/...").is_absolute() is False; validator treats it as relative.
        result = _output_path_validator("~/.ssh/authorized_keys")
        assert result is True, (
            "~ paths are not absolute; they should pass the validator "
            "(the shell never expands ~)"
        )

    def test_absolute_path_inside_cwd_accepted(self, tmp_path, monkeypatch):
        """An absolute path that resolves inside cwd must be accepted."""
        monkeypatch.chdir(tmp_path)
        child = str(tmp_path / "sub" / "output.json")
        result = _output_path_validator(child)
        assert result is True

    def test_absolute_path_inside_home_accepted(self, monkeypatch):
        """An absolute path inside the user's home dir must be accepted."""
        home = Path.home()
        candidate = str(home / "Documents" / "output.json")
        result = _output_path_validator(candidate)
        assert result is True


# ---------------------------------------------------------------------------
# H-26: search_path validator
# ---------------------------------------------------------------------------

class TestSearchPathValidator:
    """H-26 – search_path must exist; blank is accepted (uses default)."""

    def test_empty_string_accepted(self):
        """Blank → user will get current dir default."""
        assert _search_path_validator("") is True

    def test_dot_accepted(self):
        """Current directory always exists."""
        assert _search_path_validator(".") is True

    def test_nonexistent_path_rejected(self):
        result = _search_path_validator("./nonexistent_path_xyz_abc_999")
        assert result != True, "Non-existent path must be rejected"
        assert isinstance(result, str), "Rejected value should return an error string"

    def test_existing_tmp_dir_accepted(self, tmp_path):
        result = _search_path_validator(str(tmp_path))
        assert result is True


# ---------------------------------------------------------------------------
# H-12: setup.run_setup() confirms before executing scripts
# ---------------------------------------------------------------------------

class TestSetupConfirmBeforeScript:
    """H-12 – User must confirm before a setup script is executed."""

    @pytest.fixture(autouse=True)
    def _patch_auth(self, monkeypatch):
        """Avoid real auth calls."""
        monkeypatch.setattr(
            "foundry.actions.setup.get_current_license_info",
            lambda: {"tier": "alpha"},
        )

    def _make_setup_script(self, tmpl_path: Path) -> Path:
        """Create a minimal bin/setup.py inside a fake template dir."""
        (tmpl_path / "bin").mkdir(parents=True, exist_ok=True)
        script = tmpl_path / "bin" / "setup.py"
        script.write_text("# dummy setup script\nprint('running')\n")
        (tmpl_path / "Dockerfile").write_text("FROM python:3.12\n")
        return script

    def test_user_declines_skips_subprocess(self, tmp_path, monkeypatch):
        """When user answers No, subprocess.check_call must never be called."""
        tmpl = tmp_path / "python-saas"
        tmpl.mkdir()
        self._make_setup_script(tmpl)

        monkeypatch.setattr("foundry.actions.setup.TEMPLATES_DIR", tmp_path)

        with (
            patch("foundry.actions.setup.Confirm.ask", return_value=False),
            patch("subprocess.check_call") as mock_call,
            patch("sys.exit"),  # prevent test process from dying
        ):
            from foundry.actions import setup as setup_mod
            import importlib
            importlib.reload(setup_mod)

            # re-patch after reload
            with (
                patch("foundry.actions.setup.Confirm.ask", return_value=False),
                patch("foundry.actions.setup.TEMPLATES_DIR", tmp_path),
                patch("foundry.actions.setup.get_current_license_info", return_value={"tier": "alpha"}),
                patch("subprocess.check_call") as mock_cc,
            ):
                try:
                    setup_mod.run_setup(env="dev")
                except SystemExit:
                    pass

            mock_cc.assert_not_called()

    def test_user_accepts_calls_subprocess(self, tmp_path, monkeypatch):
        """When user answers Yes, subprocess.check_call must be invoked."""
        tmpl = tmp_path / "python-saas"
        tmpl.mkdir()
        self._make_setup_script(tmpl)

        with (
            patch("foundry.actions.setup.Confirm.ask", return_value=True),
            patch("foundry.actions.setup.TEMPLATES_DIR", tmp_path),
            patch("foundry.actions.setup.get_current_license_info", return_value={"tier": "alpha"}),
            patch("subprocess.check_call") as mock_cc,
        ):
            from foundry.actions import setup as setup_mod

            try:
                setup_mod.run_setup(env="dev")
            except SystemExit:
                pass

            mock_cc.assert_called_once()

    def test_force_flag_skips_confirmation(self, tmp_path, monkeypatch):
        """--force must bypass the Confirm prompt (CI/CD mode)."""
        tmpl = tmp_path / "python-saas"
        tmpl.mkdir()
        self._make_setup_script(tmpl)

        with (
            patch("foundry.actions.setup.Confirm.ask") as mock_ask,
            patch("foundry.actions.setup.TEMPLATES_DIR", tmp_path),
            patch("foundry.actions.setup.get_current_license_info", return_value={"tier": "alpha"}),
            patch("subprocess.check_call"),
        ):
            from foundry.actions import setup as setup_mod
            try:
                setup_mod.run_setup(env="dev", force=True)
            except SystemExit:
                pass

            mock_ask.assert_not_called()


# ---------------------------------------------------------------------------
# H-16: SKIP → FAIL in exception handlers
# ---------------------------------------------------------------------------

class TestProjectValidatorExceptionHandlersFail:
    """H-16 – Unexpected exceptions in check methods must produce FAIL, not SKIP."""

    def _make_python_project(self, tmp_path: Path) -> Path:
        """Minimal python-saas project so validator picks the right checker."""
        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\nname = 'test'\n")
        (tmp_path / "Dockerfile").write_text("FROM python:3.12\n")
        (tmp_path / ".gitignore").write_text("__pycache__/\n")
        (tmp_path / "README.md").write_text("# test\n")
        return tmp_path

    def test_check_python_deps_exception_yields_fail(self, tmp_path):
        """If subprocess raises unexpectedly, result must be FAIL not SKIP."""
        from foundry.actions.verification.project_validator import (
            CheckStatus,
            ProjectValidator,
        )

        project = self._make_python_project(tmp_path)
        validator = ProjectValidator(project)

        with patch("subprocess.run", side_effect=RuntimeError("mocked failure")):
            validator.results.clear()
            validator._check_python_deps()

        statuses = [r.status for r in validator.results]
        assert CheckStatus.FAIL in statuses, (
            "Expected FAIL when subprocess raises; got: "
            + str([r.status for r in validator.results])
        )
        assert CheckStatus.SKIP not in statuses, (
            "SKIP must not appear when an unexpected exception occurs"
        )

    def test_check_docker_exception_yields_fail(self, tmp_path):
        """If docker subprocess raises, result must be FAIL not SKIP."""
        from foundry.actions.verification.project_validator import (
            CheckStatus,
            ProjectValidator,
        )

        project = self._make_python_project(tmp_path)
        validator = ProjectValidator(project)

        with patch("subprocess.run", side_effect=OSError("docker not found")):
            validator.results.clear()
            validator._check_docker()

        statuses = [r.status for r in validator.results]
        assert CheckStatus.FAIL in statuses, (
            "Expected FAIL when subprocess raises in _check_docker; got: "
            + str([r.status for r in validator.results])
        )
        assert CheckStatus.SKIP not in statuses

    def test_check_python_deps_returncode_fail_gives_fail_not_skip(self, tmp_path):
        """Non-zero pip returncode must produce FAIL (not SKIP)."""
        from foundry.actions.verification.project_validator import (
            CheckStatus,
            ProjectValidator,
        )

        project = self._make_python_project(tmp_path)
        validator = ProjectValidator(project)

        broken_pip = MagicMock(returncode=1, stdout="", stderr="error")
        with patch("subprocess.run", return_value=broken_pip):
            validator.results.clear()
            validator._check_python_deps()

        statuses = [r.status for r in validator.results]
        # returncode != 0 → SKIP in legacy code; H-16 fixes it to FAIL
        assert CheckStatus.FAIL in statuses, (
            "Non-zero pip returncode must yield FAIL; got: "
            + str([r.status for r in validator.results])
        )
