"""
Comprehensive Test Suite: Astro Feature Injection Pipeline
==========================================================

Covers all paths of the Astro injection system:
- Legacy marker-based injection (commerce, auth, themes)
- ast-grep based injection (mocked success + unavailable fallback)
- inject_features() dispatcher for static-landing template
- Idempotency: safe to call twice
- Error resilience: missing vault files, missing markers

Plan reference: docs/plans/in-progress/001_ASTRO_INJECTION_PLAN.md
SDR-009, SDR-014 (GUARDIAN_MEMORY.md)
"""

import pytest
import shutil
from pathlib import Path
from unittest.mock import MagicMock, patch, call


# ---------------------------------------------------------------------------
# Fixtures: minimal Astro project + vault
# ---------------------------------------------------------------------------

@pytest.fixture
def vault(tmp_path):
    """Build a minimal features vault that mirrors the real FOUNDRY_ROOT/features/
    directory structure used by the injection paths."""
    root = tmp_path / "foundry_root"

    # --- commerce vault ---
    commerce_dir = root / "features" / "landing" / "commerce"
    commerce_dir.mkdir(parents=True)
    (commerce_dir / "pricing.astro").write_text(
        "<section id='pricing'><!-- pricing content --></section>",
        encoding="utf-8",
    )
    (commerce_dir / "astro.integrations.mjs").write_text(
        "// commerce integrations\n",
        encoding="utf-8",
    )

    # --- auth vault ---
    auth_dir = root / "features" / "landing" / "auth"
    auth_dir.mkdir(parents=True)
    (auth_dir / "auth-section.astro").write_text(
        "<section id='auth'><!-- auth content --></section>",
        encoding="utf-8",
    )

    # --- themes vault ---
    themes_dir = root / "features" / "landing" / "themes"
    themes_dir.mkdir(parents=True)
    (themes_dir / "themes.css").write_text(
        ".premium-theme { color: gold; }",
        encoding="utf-8",
    )

    # --- seo analyzer vault ---
    seo_dir = root / "features" / "landing" / "seo-analyzer" / "bin"
    seo_dir.mkdir(parents=True)
    (seo_dir / "seo-analyzer.mjs").write_text(
        "console.log('seo analyzer');\n",
        encoding="utf-8",
    )

    return root


@pytest.fixture
def astro_project(tmp_path):
    """Build a realistic minimal static-landing project structure."""
    project = tmp_path / "my-landing"
    project.mkdir()

    # --- src/pages/index.astro ---
    pages = project / "src" / "pages"
    pages.mkdir(parents=True)
    (pages / "index.astro").write_text(
        "---\n"
        "import Hero from '../components/Hero.astro';\n"
        "---\n"
        "\n"
        "<Hero />\n"
        "\n"
        "{/* [SS-FEATURE-COMMERCE-START] */}\n"
        "{/* Pricing components injected here */}\n"
        "{/* [SS-FEATURE-COMMERCE-END] */}\n"
        "\n"
        "{/* [SS-FEATURE-AUTH-START] */}\n"
        "{/* Auth components injected here */}\n"
        "{/* [SS-FEATURE-AUTH-END] */}\n"
        "\n"
        "<footer>Ready.</footer>\n",
        encoding="utf-8",
    )

    # --- src/styles/themes.css ---
    styles = project / "src" / "styles"
    styles.mkdir(parents=True)
    (styles / "themes.css").write_text(
        ":root { --color-foundry-primary: #064E3B; }\n"
        "\n"
        "/* [SS-FEATURE-THEMES-START] */\n"
        "/* Premium themes injected here */\n"
        "/* [SS-FEATURE-THEMES-END] */\n",
        encoding="utf-8",
    )

    # --- astro.config.mjs ---
    (project / "astro.config.mjs").write_text(
        "import { defineConfig } from 'astro/config';\n"
        "\n"
        "export default defineConfig({\n"
        "  integrations: [\n"
        "    /* [SS-FEATURE-SDK-INTEGRATIONS-START] */\n"
        "    // Commerce SDKs injected here\n"
        "    /* [SS-FEATURE-SDK-INTEGRATIONS-END] */\n"
        "  ],\n"
        "});\n",
        encoding="utf-8",
    )

    # --- package.json ---
    (project / "package.json").write_text(
        "{\n"
        "  \"name\": \"my-landing\",\n"
        "  \"scripts\": {\n"
        "    \"dev\": \"astro dev\"\n"
        "  },\n"
        "  \"devDependencies\": {\n"
        "    \"vitest\": \"^2.0.0\"\n"
        "  }\n"
        "}\n",
        encoding="utf-8",
    )

    return project


# ---------------------------------------------------------------------------
# 1. Legacy commerce injection
# ---------------------------------------------------------------------------

class TestInjectAstroCommerceLegacy:
    """Unit-tests for _inject_astro_commerce_legacy."""

    def test_injects_pricing_between_markers(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_commerce_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_commerce_legacy(astro_project)

        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        assert "<section id='pricing'>" in content
        assert "{/* [SS-FEATURE-COMMERCE-START] */}" in content
        assert "{/* [SS-FEATURE-COMMERCE-END] */}" in content

    def test_injects_sdk_integrations_into_config(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_commerce_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_commerce_legacy(astro_project)

        config = (astro_project / "astro.config.mjs").read_text()
        assert "// commerce integrations" in config
        assert "/* [SS-FEATURE-SDK-INTEGRATIONS-START] */" in config

    def test_noop_when_index_missing(self, vault, tmp_path):
        """Should not raise when no index.astro exists."""
        from foundry.actions.features import _inject_astro_commerce_legacy

        empty_project = tmp_path / "empty"
        empty_project.mkdir()

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            # Must not raise
            _inject_astro_commerce_legacy(empty_project)

    def test_noop_when_vault_missing(self, astro_project, tmp_path):
        """Should not raise when vault pricing.astro is absent."""
        from foundry.actions.features import _inject_astro_commerce_legacy

        empty_vault = tmp_path / "empty_vault"
        empty_vault.mkdir()

        with patch("foundry.actions.features.FOUNDRY_ROOT", empty_vault):
            _inject_astro_commerce_legacy(astro_project)

        # index.astro should be unchanged (no pricing injected)
        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        assert "<section id='pricing'>" not in content

    def test_noop_when_markers_absent(self, vault, tmp_path):
        """Content must not be altered when markers are stripped from the file."""
        from foundry.actions.features import _inject_astro_commerce_legacy

        project = tmp_path / "no_markers"
        pages = project / "src" / "pages"
        pages.mkdir(parents=True)
        clean = pages / "index.astro"
        original = "<Hero />\n<footer>done</footer>\n"
        clean.write_text(original, encoding="utf-8")

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_commerce_legacy(project)

        assert clean.read_text() == original

    def test_idempotent_double_injection(self, astro_project, vault):
        """Calling legacy injection twice must NOT duplicate pricing content."""
        from foundry.actions.features import _inject_astro_commerce_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_commerce_legacy(astro_project)
            _inject_astro_commerce_legacy(astro_project)

        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        # Only one occurrence of the sentinel text
        assert content.count("<section id='pricing'>") == 1


# ---------------------------------------------------------------------------
# 2. Legacy auth injection
# ---------------------------------------------------------------------------

class TestInjectAstroAuthLegacy:
    """Unit-tests for _inject_astro_auth_legacy."""

    def test_injects_auth_between_markers(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_auth_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_auth_legacy(astro_project)

        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        assert "<section id='auth'>" in content
        assert "{/* [SS-FEATURE-AUTH-START] */}" in content
        assert "{/* [SS-FEATURE-AUTH-END] */}" in content

    def test_noop_when_vault_missing(self, astro_project, tmp_path):
        from foundry.actions.features import _inject_astro_auth_legacy

        empty_vault = tmp_path / "nv"
        empty_vault.mkdir()
        with patch("foundry.actions.features.FOUNDRY_ROOT", empty_vault):
            _inject_astro_auth_legacy(astro_project)

        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        assert "<section id='auth'>" not in content

    def test_idempotent_double_injection(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_auth_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_auth_legacy(astro_project)
            _inject_astro_auth_legacy(astro_project)

        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        assert content.count("<section id='auth'>") == 1


# ---------------------------------------------------------------------------
# 3. Legacy themes injection
# ---------------------------------------------------------------------------

class TestInjectAstroThemesLegacy:
    """Unit-tests for _inject_astro_themes_legacy."""

    def test_injects_premium_themes(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_themes_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_themes_legacy(astro_project)

        content = (astro_project / "src" / "styles" / "themes.css").read_text()
        assert ".premium-theme { color: gold; }" in content
        assert "/* [SS-FEATURE-THEMES-START] */" in content
        assert "/* [SS-FEATURE-THEMES-END] */" in content

    def test_noop_when_vault_missing(self, astro_project, tmp_path):
        from foundry.actions.features import _inject_astro_themes_legacy

        empty_vault = tmp_path / "nv"
        empty_vault.mkdir()
        with patch("foundry.actions.features.FOUNDRY_ROOT", empty_vault):
            before = (astro_project / "src" / "styles" / "themes.css").read_text()
            _inject_astro_themes_legacy(astro_project)
            after = (astro_project / "src" / "styles" / "themes.css").read_text()

        assert before == after

    def test_noop_when_themes_file_missing(self, vault, tmp_path):
        from foundry.actions.features import _inject_astro_themes_legacy

        project = tmp_path / "no_themes"
        project.mkdir()  # no src/styles/themes.css

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            # Should not raise
            _inject_astro_themes_legacy(project)


# ---------------------------------------------------------------------------
# 4. ast-grep commerce injection (with mocked runner)
# ---------------------------------------------------------------------------

class TestInjectAstroCommerce:
    """Tests for _inject_astro_commerce — mocked ast-grep layer."""

    def test_uses_astgrep_when_available(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_commerce

        mock_runner = MagicMock()
        mock_runner.is_available.return_value = True
        mock_runner.inject_rule.return_value = True

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features.AstGrepRunner", return_value=mock_runner):
            _inject_astro_commerce(astro_project)

        assert mock_runner.inject_rule.called

    def test_falls_back_to_legacy_when_unavailable(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_commerce

        mock_runner = MagicMock()
        mock_runner.is_available.return_value = False

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features.AstGrepRunner", return_value=mock_runner), \
             patch("foundry.actions.features._inject_astro_commerce_legacy") as mock_legacy:
            _inject_astro_commerce(astro_project)

        mock_legacy.assert_called_once_with(astro_project)

    def test_falls_back_to_legacy_on_exception(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_commerce

        mock_runner = MagicMock()
        mock_runner.is_available.return_value = True
        mock_runner.inject_rule.side_effect = RuntimeError("ast-grep exploded")

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features.AstGrepRunner", return_value=mock_runner), \
             patch("foundry.actions.features._inject_astro_commerce_legacy") as mock_legacy:
            _inject_astro_commerce(astro_project)

        mock_legacy.assert_called_once_with(astro_project)

    def test_noop_when_vault_missing(self, tmp_path):
        """Should silently return when the vault pricing.astro is absent."""
        from foundry.actions.features import _inject_astro_commerce

        project = tmp_path / "proj"
        pages = project / "src" / "pages"
        pages.mkdir(parents=True)
        (pages / "index.astro").write_text("<page />")
        empty_vault = tmp_path / "empty_vault"
        empty_vault.mkdir()

        with patch("foundry.actions.features.FOUNDRY_ROOT", empty_vault):
            # Should not raise
            _inject_astro_commerce(project)


# ---------------------------------------------------------------------------
# 5. ast-grep auth injection (with mocked runner)
# ---------------------------------------------------------------------------

class TestInjectAstroAuth:
    """Tests for _inject_astro_auth — mocked ast-grep layer."""

    def test_uses_astgrep_when_available(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_auth

        mock_runner = MagicMock()
        mock_runner.is_available.return_value = True
        mock_runner.inject_rule.return_value = True

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features.AstGrepRunner", return_value=mock_runner):
            _inject_astro_auth(astro_project)

        assert mock_runner.inject_rule.called

    def test_falls_back_to_legacy_when_unavailable(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_auth

        mock_runner = MagicMock()
        mock_runner.is_available.return_value = False

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features.AstGrepRunner", return_value=mock_runner), \
             patch("foundry.actions.features._inject_astro_auth_legacy") as mock_legacy:
            _inject_astro_auth(astro_project)

        mock_legacy.assert_called_once_with(astro_project)

    def test_falls_back_to_legacy_on_exception(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_auth

        mock_runner = MagicMock()
        mock_runner.is_available.return_value = True
        mock_runner.inject_rule.side_effect = RuntimeError("broken pipe")

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features.AstGrepRunner", return_value=mock_runner), \
             patch("foundry.actions.features._inject_astro_auth_legacy") as mock_legacy:
            _inject_astro_auth(astro_project)

        mock_legacy.assert_called_once_with(astro_project)

    def test_noop_when_vault_missing(self, tmp_path):
        from foundry.actions.features import _inject_astro_auth

        project = tmp_path / "proj"
        pages = project / "src" / "pages"
        pages.mkdir(parents=True)
        (pages / "index.astro").write_text("<page />")
        empty_vault = tmp_path / "empty_vault"
        empty_vault.mkdir()

        with patch("foundry.actions.features.FOUNDRY_ROOT", empty_vault):
            _inject_astro_auth(project)


# ---------------------------------------------------------------------------
# 6. inject_features dispatcher — static-landing template
# ---------------------------------------------------------------------------

class TestInjectFeaturesStaticLanding:
    """Tests for inject_features() when template='static-landing'."""

    def test_always_injects_components_and_themes(self, astro_project, vault):
        """Even without any feature flags, components+themes are injected for static-landing."""
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features._perform_feature_injection") as mock_inject, \
             patch("foundry.actions.features._inject_astro_commerce"), \
             patch("foundry.actions.features._inject_astro_auth"):
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
            )

        calls = [c.args for c in mock_inject.call_args_list]
        assert (astro_project, "landing", "components") in calls
        assert (astro_project, "landing", "themes") in calls

    def test_commerce_flag_triggers_astro_commerce_injection(self, astro_project, vault):
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features._perform_feature_injection"), \
             patch("foundry.actions.features._inject_commerce_env_vars"), \
             patch("foundry.actions.features._inject_astro_commerce") as mock_commerce, \
             patch("foundry.actions.features._inject_astro_auth"):
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=True,
                tunnel=False,
            )

        mock_commerce.assert_called_once_with(astro_project)

    def test_auth_flag_triggers_astro_auth_injection(self, astro_project, vault):
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features._perform_feature_injection"), \
             patch("foundry.actions.features._inject_astro_commerce"), \
             patch("foundry.actions.features._inject_astro_auth") as mock_auth:
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
                auth=True,
            )

        mock_auth.assert_called_once_with(astro_project)

    def test_seo_flag_triggers_astro_seo_injection(self, astro_project, vault):
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features._perform_feature_injection"), \
             patch("foundry.actions.features._inject_astro_commerce"), \
             patch("foundry.actions.features._inject_astro_auth"), \
             patch("foundry.actions.features._inject_astro_seo_analyzer") as mock_seo:
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
                seo_analyzer=True,
            )

        mock_seo.assert_called_once_with(astro_project)

    def test_can_skip_static_base_injection_for_surgical_mode(self, astro_project, vault):
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features._perform_feature_injection") as mock_inject, \
             patch("foundry.actions.features._inject_astro_seo_analyzer"):
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
                seo_analyzer=True,
                inject_static_premium_base=False,
            )

        calls = [c.args for c in mock_inject.call_args_list]
        assert (astro_project, "landing", "components") not in calls
        assert (astro_project, "landing", "themes") not in calls

    def test_commerce_not_triggered_when_flag_false(self, astro_project, vault):
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features._perform_feature_injection"), \
             patch("foundry.actions.features._inject_astro_commerce") as mock_commerce, \
             patch("foundry.actions.features._inject_astro_auth"):
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
            )

        mock_commerce.assert_not_called()

    def test_auth_not_triggered_when_flag_false(self, astro_project, vault):
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features._perform_feature_injection"), \
             patch("foundry.actions.features._inject_astro_commerce"), \
             patch("foundry.actions.features._inject_astro_auth") as mock_auth:
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
            )

        mock_auth.assert_not_called()

    def test_ast_injection_builds_correct_features_dict(self, astro_project):
        """When use_ast_injection=True, inject_features_ast must receive a
        proper features dict — not individual kwarg booleans."""
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.inject_features_ast") as mock_ast:
            mock_ast.return_value = {
                "success": True,
                "changes": [],
                "errors": [],
                "skipped": [],
            }
            inject_features(
                path=astro_project,
                template="python-saas",  # Use template with AST injection logic
                commerce=True,
                tunnel=False,
                auth=True,
                use_ast_injection=True,
            )

        mock_ast.assert_called_once()
        # Get features dict from call (could be positional arg[2] or kwarg)
        if mock_ast.call_args.kwargs:
            features = mock_ast.call_args.kwargs.get("features")
        else:
            features = mock_ast.call_args.args[2] if len(mock_ast.call_args.args) > 2 else None
        
        assert features is not None, "features dict not found in mock call"
        # Verify the boolean flags were translated into structured AST operations
        assert "imports" in features or "calls" in features or "dependencies" in features
        assert len(features) > 0, "features dict should not be empty"

    def test_ast_injection_falls_back_on_exception(self, astro_project, vault):
        """When inject_features_ast raises, the string-marker path must still run."""
        from foundry.actions.features import inject_features

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault), \
             patch("foundry.actions.features.inject_features_ast", side_effect=RuntimeError("boom")), \
             patch("foundry.actions.features._perform_feature_injection") as mock_inject, \
             patch("foundry.actions.features._inject_astro_commerce"), \
             patch("foundry.actions.features._inject_astro_auth"):
            inject_features(
                path=astro_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
                use_ast_injection=True,
            )

        # Fallback string-marker path should have executed
        assert mock_inject.called


# ---------------------------------------------------------------------------
# 7. Full integration test (legacy pipeline, real file mutations)
# ---------------------------------------------------------------------------

class TestAstroInjectionIntegration:
    """End-to-end tests that exercise real file mutations without mocking
    the legacy injection path (vault is mocked, fs is real)."""

    def test_commerce_end_to_end(self, astro_project, vault):
        """Full legacy commerce injection: markers replaced, config updated."""
        from foundry.actions.features import (
            _inject_astro_commerce_legacy,
        )

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_commerce_legacy(astro_project)

        index = (astro_project / "src" / "pages" / "index.astro").read_text()
        config = (astro_project / "astro.config.mjs").read_text()

        # Pricing content was injected
        assert "<section id='pricing'>" in index

        # SDK integrations were injected into config
        assert "// commerce integrations" in config

        # Markers are preserved (wrapper is kept)
        assert "{/* [SS-FEATURE-COMMERCE-START] */}" in index
        assert "{/* [SS-FEATURE-COMMERCE-END] */}" in index

        # Auth section must remain untouched
        assert "{/* [SS-FEATURE-AUTH-START] */}" in index
        assert "<section id='auth'>" not in index

    def test_auth_end_to_end(self, astro_project, vault):
        """Full legacy auth injection: markers replaced."""
        from foundry.actions.features import _inject_astro_auth_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_auth_legacy(astro_project)

        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        assert "<section id='auth'>" in content

        # Commerce section must remain untouched
        assert "<section id='pricing'>" not in content

    def test_themes_end_to_end(self, astro_project, vault):
        """Full legacy themes injection: CSS tokens injected between markers."""
        from foundry.actions.features import _inject_astro_themes_legacy

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_themes_legacy(astro_project)

        themes = (astro_project / "src" / "styles" / "themes.css").read_text()
        assert ".premium-theme { color: gold; }" in themes
        assert "/* [SS-FEATURE-THEMES-START] */" in themes
        assert ":root { --color-foundry-primary: #064E3B; }" in themes  # base preserved

    def test_combined_commerce_and_auth(self, astro_project, vault):
        """Both features can be injected sequentially without conflict."""
        from foundry.actions.features import (
            _inject_astro_commerce_legacy,
            _inject_astro_auth_legacy,
        )

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_commerce_legacy(astro_project)
            _inject_astro_auth_legacy(astro_project)

        content = (astro_project / "src" / "pages" / "index.astro").read_text()
        assert "<section id='pricing'>" in content
        assert "<section id='auth'>" in content

    def test_all_three_features_combined(self, astro_project, vault):
        """Commerce + auth + themes injected together without corruption."""
        from foundry.actions.features import (
            _inject_astro_commerce_legacy,
            _inject_astro_auth_legacy,
            _inject_astro_themes_legacy,
        )

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_commerce_legacy(astro_project)
            _inject_astro_auth_legacy(astro_project)
            _inject_astro_themes_legacy(astro_project)

        index = (astro_project / "src" / "pages" / "index.astro").read_text()
        themes = (astro_project / "src" / "styles" / "themes.css").read_text()

        assert "<section id='pricing'>" in index
        assert "<section id='auth'>" in index
        assert ".premium-theme { color: gold; }" in themes

    def test_seo_analyzer_end_to_end(self, astro_project, vault):
        from foundry.actions.features import _inject_astro_seo_analyzer

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            _inject_astro_seo_analyzer(astro_project)
            _inject_astro_seo_analyzer(astro_project)

        package_data = (astro_project / "package.json").read_text()
        analyzer_file = astro_project / "bin" / "seo-analyzer.mjs"

        assert analyzer_file.exists()
        assert package_data.count('"seo:score": "node ./bin/seo-analyzer.mjs"') == 1
        assert package_data.count('"lighthouse": "^12.6.0"') == 1

    def test_idempotency_all_three(self, astro_project, vault):
        """Calling all three inject functions twice must not duplicate content."""
        from foundry.actions.features import (
            _inject_astro_commerce_legacy,
            _inject_astro_auth_legacy,
            _inject_astro_themes_legacy,
        )

        with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
            for _ in range(2):
                _inject_astro_commerce_legacy(astro_project)
                _inject_astro_auth_legacy(astro_project)
                _inject_astro_themes_legacy(astro_project)

        index = (astro_project / "src" / "pages" / "index.astro").read_text()
        themes = (astro_project / "src" / "styles" / "themes.css").read_text()

        assert index.count("<section id='pricing'>") == 1
        assert index.count("<section id='auth'>") == 1
        assert themes.count(".premium-theme { color: gold; }") == 1
