import pytest
from unittest.mock import MagicMock, patch, call
from pathlib import Path
from foundry.actions.generator import run_generator

def test_run_generator_dry_run():
    # Test dry run logic without actual generation
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}):
        with patch("foundry.actions.generator.check_tier_access", return_value=True):
            run_generator(
                template_name="python-saas",
                app_name="test-app",
                dry_run=True
            )
            # Just verify it doesn't crash

def test_run_generator_tier_denied():
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "pro"}):
        with patch("foundry.actions.generator.check_tier_access", return_value=False):
            with patch("foundry.actions.generator.console") as mock_console:
                run_generator(template_name="python-saas")
                # Should return early

def test_run_generator_full_flow(tmp_path):
    # Setup mock destination
    target_path = tmp_path / "my-app"
    
    # Mock all external dependencies
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.check_feature_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.disable_linters"), \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class:
        
        run_generator(
            template_name="python-saas",
            app_name="my-app",
            use_linters=False,
            with_commerce=True
        )
        
        # Verify tracker was used
        assert mock_tracker_class.called
        mock_tracker = mock_tracker_class.return_value
        assert mock_tracker.init_project.called
        args, kwargs = mock_tracker.init_project.call_args
        assert kwargs["template_name"] == "python-saas"
        assert "commerce" in kwargs["features"]

def test_run_generator_existing_dir(tmp_path, monkeypatch):
    target_path = tmp_path / "existing-app"
    target_path.mkdir()
    (target_path / "file.txt").touch()
    monkeypatch.chdir(tmp_path)
    
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.console") as mock_console:
        
        run_generator(
            template_name="python-saas",
            app_name="existing-app",
            target_dir_name=str(target_path)
        )
        
        mock_console.print.assert_any_call(f"[red]Error: {target_path.name} already exists and is not empty![/red]")

def test_run_generator_download_fail(tmp_path):
    target_path = tmp_path / "new-app"
    
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", return_value=False):
        
        res = run_generator(
            template_name="python-saas",
            app_name="new-app",
            target_dir_name=str(target_path)
        )
        assert res is None # Should return early

def test_run_generator_interactive_mode():
    """Test interactive mode configuration (lines 48-64)"""
    mock_config = {
        "template_name": "python-saas",
        "app_name": "interactive-app",
        "with_commerce": True,
        "with_tunnel": False,
        "with_landing": True,
        "with_admin": False,
        "with_sqlite": True,
        "with_ingestor": False,
        "with_auth": False,
        "with_merchant_dashboard": False,
        "use_linters": False,
        "use_ast_injection": True,
        "secrets_strategy": "AWS Secrets Manager",
        "github_config": {"owner": "test", "repo": "test-repo"}
    }
    
    with patch("foundry.actions.generator.get_interactive_config", return_value=mock_config), \
         patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.check_feature_tier_access", return_value=True), \
         patch("foundry.actions.generator.questionary.text") as mock_text, \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.disable_linters"), \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.initialize_github_repo") as mock_github, \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
         patch("foundry.actions.generator.shutil.rmtree"):
        
        # Mock questionary for path selection
        mock_text.return_value.ask.return_value = "/tmp/test-path"
        
        run_generator(interactive=True)
        
        # Verify GitHub repo initialization was called
        assert mock_github.called
        
        # Verify all features were tracked
        mock_tracker = mock_tracker_class.return_value
        args, kwargs = mock_tracker.init_project.call_args
        features = kwargs["features"]
        assert "commerce" in features
        assert "landing" in features
        assert "sqlite-local" in features

def test_run_generator_interactive_no_config():
    """Test interactive mode when user cancels (lines 48-50)"""
    with patch("foundry.actions.generator.get_interactive_config", return_value=None):
        result = run_generator(interactive=True)
        assert result is None

def test_run_generator_interactive_no_path(tmp_path):
    """Test interactive mode when user doesn't provide path (lines 77-79)"""
    mock_config = {
        "template_name": "python-saas",
        "app_name": "test-app",
        "with_commerce": False,
        "with_tunnel": False,
        "with_landing": False,
        "use_linters": True,
        "secrets_strategy": "Dotenv (Standard .env files)"
    }
    
    with patch("foundry.actions.generator.get_interactive_config", return_value=mock_config), \
         patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.questionary.text") as mock_text, \
         patch("foundry.actions.generator.console") as mock_console:
        
        # Mock questionary to return None (user cancelled)
        mock_text.return_value.ask.return_value = None
        
        result = run_generator(interactive=True)
        
        # Should print error and return
        mock_console.print.assert_any_call("[red]Error: Installation path required.[/red]")
        assert result is None

def test_run_generator_no_template_name():
    """Test error when template_name is not provided (lines 89-90)"""
    with patch("foundry.actions.generator.console") as mock_console:
        result = run_generator(template_name=None, app_name="test-app")
        mock_console.print.assert_any_call("[red]Error: Template name required.[/red]")
        assert result is None

def test_run_generator_dry_run_all_features():
    """Test dry run with all features enabled (lines 102-149)"""
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.check_feature_tier_access", return_value=True), \
         patch("foundry.actions.generator.console") as mock_console, \
         patch("foundry.actions.generator.log_event") as mock_log:
        
        run_generator(
            template_name="python-saas",
            app_name="full-app",
            dry_run=True,
            with_commerce=True,
            with_landing=True,
            with_sqlite=True,
            use_linters=True,
            secrets_strategy="Custom Strategy"
        )
        
        # Verify all features shown in dry run output
        calls = [str(c) for c in mock_console.print.call_args_list]
        output = " ".join(calls)
        
        assert "Commerce" in output
        assert "Landing" in output or "Astro" in output
        assert "SQLite" in output
        assert "Linters" in output
        assert "Custom Strategy" in output
        
        # Verify log event
        mock_log.assert_any_call("GENERATE_DRY_RUN", "Template: python-saas, App: full-app")

def test_run_generator_github_repo_initialization(tmp_path, monkeypatch):
    """Test GitHub repository initialization (line 193)"""
    target_path = tmp_path / "github-app"
    github_config = {"owner": "test-owner", "repo": "test-repo", "private": True}
    monkeypatch.chdir(tmp_path)
    
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.initialize_github_repo") as mock_github, \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
         patch("foundry.actions.generator.shutil.rmtree"):
        
        run_generator(
            template_name="python-saas",
            app_name="github-app",
            target_dir_name=str(target_path),
            github_config=github_config
        )
        
        # Verify GitHub repo initialization was called with correct args
        mock_github.assert_called_once()
        args = mock_github.call_args[0]
        assert args[0] == target_path
        assert args[1] == github_config

def test_run_generator_exception_handling(tmp_path):
    """Test exception handling in generation (lines 199-201)"""
    
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", side_effect=Exception("Test error")), \
         patch("foundry.actions.generator.console") as mock_console, \
         patch("foundry.actions.generator.log_event") as mock_log:
        
        run_generator(
            template_name="python-saas",
            app_name="error-app"
        )
        
        # Verify error was logged and printed
        mock_console.print.assert_any_call("[bold red]Deployment failed:[/bold red] Test error")
        mock_log.assert_any_call("GENERATE_ERROR", "Test error")

def test_run_generator_static_landing_with_blueprint(tmp_path, monkeypatch):
    """Test static-landing template with blueprint application"""
    target_path = tmp_path / "landing-app"
    monkeypatch.chdir(tmp_path)
    
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.apply_landing_blueprint") as mock_blueprint, \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
         patch("foundry.actions.generator.shutil.rmtree"):
        
        run_generator(
            template_name="static-landing",
            app_name="landing-app",
            target_dir_name=str(target_path),
            content_path="/path/to/content",
            theme="dark"
        )
        
        # Verify blueprint was applied
        mock_blueprint.assert_called_once_with(target_path, "/path/to/content", "dark")

def test_run_generator_default_secrets_strategy():
    """Test default secrets strategy is set correctly (line 67)"""
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.setup_secrets") as mock_secrets, \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
         patch("foundry.actions.generator.shutil.rmtree"), \
         patch("foundry.actions.generator.Path") as mock_path_class:
        
        # Mock Path to handle target_path.exists() and iterdir()
        mock_target = MagicMock()
        mock_target.exists.return_value = False
        mock_target.name = "test-app"
        mock_path_class.return_value = mock_target
        
        run_generator(
            template_name="python-saas",
            app_name="test-app",
            secrets_strategy=None  # Should use default
        )
        
        # Verify setup_secrets was called with default strategy
        args = mock_secrets.call_args[0]
        assert args[1] == "Dotenv (Standard .env files)"

def test_run_generator_features_dir_cleanup(tmp_path):
    """Test that features directory is cleaned up after generation"""
    target_path = tmp_path / "cleanup-app"
    
    # Create a mock function that creates features dir during download
    def mock_download_with_features(template_name, template_info, target):
        target.mkdir(parents=True, exist_ok=True)
        features_dir = target / "features"
        features_dir.mkdir(parents=True)
        (features_dir / "test.txt").touch()
        return True
    
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", side_effect=mock_download_with_features), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class:
        
        run_generator(
            template_name="python-saas",
            app_name="cleanup-app",
            target_dir_name=str(target_path)
        )
        
        # Verify features directory was removed
        features_dir = target_path / "features"
        assert not features_dir.exists()

def test_run_generator_all_features_tracked(tmp_path, monkeypatch):
    """Test that supported feature flags are properly tracked in metadata"""
    target_path = tmp_path / "tracked-app"
    monkeypatch.chdir(tmp_path)
    
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.check_feature_tier_access", return_value=True), \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
         patch("foundry.actions.generator.shutil.rmtree"):
        
        run_generator(
            template_name="python-saas",
            app_name="tracked-app",
            target_dir_name=str(target_path),
            with_commerce=True,
            with_landing=True,
            with_sqlite=True,
        )
        
        # Verify all features are in metadata
        mock_tracker = mock_tracker_class.return_value
        args, kwargs = mock_tracker.init_project.call_args
        features = kwargs["features"]
        
        expected_features = [
            "commerce", "landing", "sqlite-local"
        ]
        for feature in expected_features:
            assert feature in features


def test_run_generator_formerly_disabled_flags_now_proceed(tmp_path):
    """Formerly-disabled flags (auth, tunnel, admin, ingestor, merchant_dashboard)
    must no longer be blocked at the guard layer — _guard_disabled_features must
    return True for all five flags simultaneously.
    """
    from foundry.actions.generator import _guard_disabled_features

    result = _guard_disabled_features(
        with_auth=True,
        with_admin=True,
        with_tunnel=True,
        with_ingestor=True,
        with_merchant_dashboard=True,
    )

    assert result is True, (
        "All formerly-disabled feature flags should now pass _guard_disabled_features. "
        "Check that DISABLED_FEATURES_POLICY in constants.py is empty."
    )

def test_run_generator_default_target_path():
    """Test default target_path when no target_dir_name or app_name provided (line 84)"""
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.Path") as mock_path_class, \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
         patch("foundry.actions.generator.shutil.rmtree"):
        
        # Setup mock for Path.cwd()
        mock_cwd = MagicMock()
        mock_cwd.exists.return_value = False
        mock_cwd.name = "current-dir"
        mock_path_class.cwd.return_value = mock_cwd
        
        # Call without target_dir_name or app_name
        run_generator(template_name="python-saas")
        
        # Verify Path.cwd() was called (line 84)
        mock_path_class.cwd.assert_called()

def test_run_generator_app_name_as_target():
    """Test using app_name as target directory when target_dir_name is None"""
    with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
         patch("foundry.actions.generator.check_tier_access", return_value=True), \
         patch("foundry.actions.generator.Path") as mock_path_class, \
         patch("foundry.actions.generator.download_template", return_value=True), \
         patch("foundry.actions.generator.inject_metadata"), \
         patch("foundry.actions.generator.validate_and_fix_pyproject"), \
         patch("foundry.actions.generator.setup_secrets"), \
         patch("foundry.actions.generator.inject_features"), \
         patch("foundry.actions.generator.regenerate_poetry_lock"), \
         patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
         patch("foundry.actions.generator.shutil.rmtree"):
        
        # Setup mock for Path operations
        mock_cwd = MagicMock()
        mock_target = MagicMock()
        mock_target.exists.return_value = False
        mock_target.name = "my-app"
        mock_cwd.__truediv__.return_value = mock_target
        mock_path_class.cwd.return_value = mock_cwd
        
        # Call with app_name but no target_dir_name
        run_generator(template_name="python-saas", app_name="my-app")
        
        # Verify Path.cwd() / app_name was constructed
        mock_path_class.cwd.assert_called()
