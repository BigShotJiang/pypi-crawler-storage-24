"""
Comprehensive tests for foundry.actions.explore module.

Tests:
- _get_template_tech() technology mapping
- _strip_markup() Rich markup removal
- _render_templates_tree() tree visualization
- _show_template_info() template details display
- run_explore() interactive flow
- Template categorization (Backend, Frontend, Mobile, Data, Infrastructure)
- Tier-based access control (free, pro, enterprise)
- User interaction flows (selection, details, back navigation)
"""

from types import SimpleNamespace
from pathlib import Path
import pytest
from rich.panel import Panel


def test_get_template_tech_known_templates():
    """Test technology mapping for known templates."""
    from foundry.actions.explore import _get_template_tech
    
    assert "Python" in _get_template_tech("python-saas")
    assert "Ruby on Rails" in _get_template_tech("rails-api")
    assert "React/Vite" in _get_template_tech("react-client")
    assert "Rails + ViewComponent" in _get_template_tech("rails-ui-kit")
    assert "Astro" in _get_template_tech("static-landing")
    assert "Android" in _get_template_tech("mobile-android")
    assert "iOS" in _get_template_tech("mobile-ios")
    assert "Data Stack" in _get_template_tech("data-pipeline")
    assert "Terraform" in _get_template_tech("terraform-infra")
    assert "Docker" in _get_template_tech("wiring")


def test_get_template_tech_unknown_template():
    """Test technology mapping for unknown template returns default."""
    from foundry.actions.explore import _get_template_tech
    
    assert "Multi-tech Stack" in _get_template_tech("unknown-template")
    assert "Multi-tech Stack" in _get_template_tech("new-service")


def test_strip_markup_basic():
    """Test removing Rich markup tags from text."""
    from foundry.actions.explore import _strip_markup
    
    assert _strip_markup("[bold]Hello[/bold]") == "Hello"
    assert _strip_markup("[bold cyan]Text[/bold cyan]") == "Text"
    assert _strip_markup("Plain text") == "Plain text"


def test_strip_markup_complex():
    """Test removing multiple Rich markup tags."""
    from foundry.actions.explore import _strip_markup
    
    assert _strip_markup("[bold]Test[/bold] [yellow]text[/yellow]") == "Test text"
    assert _strip_markup("[bold cyan]Name:[/bold cyan] value") == "Name: value"
    assert _strip_markup("[italic][dim]Nested[/dim][/italic]") == "Nested"


def test_render_templates_tree_empty_buckets(monkeypatch):
    """Test rendering tree with empty buckets."""
    from foundry.actions.explore import _render_templates_tree
    from foundry.actions import explore as explore_mod
    
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    buckets = {}
    _render_templates_tree(buckets)
    
    # Should still print a panel with tree (even if empty)
    assert len(printed) == 1


def test_render_templates_tree_with_categories(monkeypatch):
    """Test rendering tree with multiple categories."""
    from foundry.actions.explore import _render_templates_tree
    from foundry.actions import explore as explore_mod
    
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    buckets = {
        "Backend Services": [
            {"name": "python-saas", "tier": "free", "locked": False},
            {"name": "rails-api", "tier": "pro", "locked": False},
        ],
        "Frontend & UI": [
            {"name": "react-client", "tier": "free", "locked": False},
        ],
    }
    
    _render_templates_tree(buckets)
    
    assert len(printed) == 1


def test_render_templates_tree_with_locked_templates(monkeypatch):
    """Test rendering tree with locked templates."""
    from foundry.actions.explore import _render_templates_tree
    from foundry.actions import explore as explore_mod
    
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    buckets = {
        "Backend Services": [
            {"name": "python-saas", "tier": "free", "locked": False},
            {"name": "rails-api", "tier": "enterprise", "locked": True},
        ],
    }
    
    _render_templates_tree(buckets)
    
    assert len(printed) == 1


def test_show_template_info_basic(monkeypatch):
    """Test showing template information with features inside the panel."""
    from foundry.actions.explore import _show_template_info
    from foundry.actions import explore as explore_mod
    
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    monkeypatch.setattr(
        explore_mod,
        "get_template_info",
        lambda name: {
            "tier": "free",
            "repo": "git@github.com:seed-source/python-saas.git",
            "description": "Python SaaS backend template",
        },
    )
    
    pressed = []
    monkeypatch.setattr(
        explore_mod.questionary,
        "press_any_key_to_continue",
        lambda: SimpleNamespace(ask=lambda: pressed.append(True)),
    )
    
    _show_template_info("python-saas")
    
    # Should print: Panel (with features inside) + code example prints + press key
    # Now features are inside the panel, so fewer separate print calls
    assert len(printed) >= 1  # At least the Panel with all content inside
    # Check that panel was printed
    assert any(isinstance(p[0] if p else None, Panel) for p in printed)
    assert len(pressed) == 1


def test_show_template_info_missing_fields(monkeypatch):
    """Test showing template info with missing fields."""
    from foundry.actions.explore import _show_template_info
    from foundry.actions import explore as explore_mod
    
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    # Missing tier, repo, description
    monkeypatch.setattr(explore_mod, "get_template_info", lambda name: {})
    
    pressed = []
    monkeypatch.setattr(
        explore_mod.questionary,
        "press_any_key_to_continue",
        lambda: SimpleNamespace(ask=lambda: pressed.append(True)),
    )
    
    _show_template_info("unknown-template")
    
    # Should print at least: Panel + press key confirmation
    assert len(printed) >= 1
    assert len(pressed) == 1


def test_run_explore_free_tier_basic(monkeypatch):
    """Test explore with free tier user."""
    from foundry.actions import explore as explore_mod
    
    # Mock console.clear and console.print
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    # Mock user as free tier
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    # Mock template list
    mock_templates = [
        SimpleNamespace(name="python-saas"),
        SimpleNamespace(name="react-client"),
        SimpleNamespace(name="rails-api"),
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    # Mock template info
    def mock_get_template_info(name):
        tiers = {
            "python-saas": "free",
            "react-client": "free",
            "rails-api": "pro",
        }
        return {
            "tier": tiers.get(name, "free"),
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    # Mock questionary to exit immediately
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    # Should have printed header and panel
    assert len(printed) >= 1


def test_run_explore_pro_tier(monkeypatch):
    """Test explore with pro tier user accessing pro templates."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    # Mock user as pro tier
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "pro"},
    )
    
    mock_templates = [
        SimpleNamespace(name="python-saas"),
        SimpleNamespace(name="rails-api"),
        SimpleNamespace(name="mobile-android"),
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        tiers = {
            "python-saas": "free",
            "rails-api": "pro",
            "mobile-android": "enterprise",
        }
        return {
            "tier": tiers.get(name, "free"),
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    assert len(printed) >= 1


def test_run_explore_enterprise_tier(monkeypatch):
    """Test explore with enterprise tier user accessing all templates."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    # Mock user as enterprise tier
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "enterprise"},
    )
    
    mock_templates = [
        SimpleNamespace(name="python-saas"),
        SimpleNamespace(name="rails-api"),
        SimpleNamespace(name="mobile-android"),
        SimpleNamespace(name="data-pipeline"),
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        return {
            "tier": "enterprise",
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    assert len(printed) >= 1


def test_run_explore_template_categorization(monkeypatch):
    """Test that templates are correctly categorized."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "enterprise"},
    )
    
    # Create templates for all categories
    mock_templates = [
        SimpleNamespace(name="python-saas"),  # Backend
        SimpleNamespace(name="rails-api"),  # Backend
        SimpleNamespace(name="react-client"),  # Frontend
        SimpleNamespace(name="rails-ui-kit"),  # Frontend
        SimpleNamespace(name="static-landing"),  # Frontend
        SimpleNamespace(name="mobile-android"),  # Mobile
        SimpleNamespace(name="mobile-ios"),  # Mobile
        SimpleNamespace(name="data-pipeline"),  # Data Engineering
        SimpleNamespace(name="terraform-infra"),  # Infrastructure
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        return {
            "tier": "free",
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    assert len(printed) >= 1


def test_run_explore_toggle_category_expansion(monkeypatch):
    """Test expanding and collapsing categories."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    mock_templates = [
        SimpleNamespace(name="python-saas"),
        SimpleNamespace(name="react-client"),
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        return {
            "tier": "free",
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    # Simulate: expand Backend, collapse Backend, then exit
    choices = iter(["toggle:Backend Services", "toggle:Backend Services", "back"])
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices)),
    )
    
    explore_mod.run_explore()
    
    # Test passes if no exceptions


def test_run_explore_view_template_details(monkeypatch):
    """Test viewing template details from the explorer."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    mock_templates = [SimpleNamespace(name="python-saas")]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        return {
            "tier": "free",
            "repo": "git@github.com:seed-source/python-saas.git",
            "description": "Python SaaS backend template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    # Track questionary calls
    select_calls = []
    
    def mock_select(*args, **kwargs):
        select_calls.append(kwargs)
        if len(select_calls) == 1:
            # First call: expand category
            return SimpleNamespace(ask=lambda: "toggle:Backend Services")
        elif len(select_calls) == 2:
            # Second call: select template
            return SimpleNamespace(ask=lambda: "tmpl:python-saas")
        else:
            # Third call: exit
            return SimpleNamespace(ask=lambda: "back")
    
    monkeypatch.setattr(explore_mod.questionary, "select", mock_select)
    
    pressed = []
    monkeypatch.setattr(
        explore_mod.questionary,
        "press_any_key_to_continue",
        lambda: SimpleNamespace(ask=lambda: pressed.append(True)),
    )
    
    explore_mod.run_explore()
    
    assert len(pressed) == 1
    assert len(select_calls) == 3


def test_run_explore_cancel_with_none(monkeypatch):
    """Test canceling explore with Ctrl+C (returns None)."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    mock_templates = [SimpleNamespace(name="python-saas")]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    monkeypatch.setattr(
        explore_mod,
        "get_template_info",
        lambda name: {"tier": "free", "repo": "...", "description": "..."},
    )
    
    # Return None to simulate Ctrl+C
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: None),
    )
    
    explore_mod.run_explore()
    
    # Test passes if no exceptions


def test_run_explore_locked_templates_for_free_user(monkeypatch):
    """Test that free user sees locked enterprise templates."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    mock_templates = [
        SimpleNamespace(name="python-saas"),
        SimpleNamespace(name="mobile-android"),
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        tiers = {
            "python-saas": "free",
            "mobile-android": "enterprise",
        }
        return {
            "tier": tiers.get(name, "free"),
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    # Test passes if no exceptions


def test_run_explore_other_category(monkeypatch):
    """Test templates that don't match known categories go to 'Other'."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    # Create a template that doesn't match any category
    mock_templates = [
        SimpleNamespace(name="wiring"),  # Should go to "Other" or be filtered
        SimpleNamespace(name="custom-service"),  # Unknown, should go to "Other"
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        return {
            "tier": "free",
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    # Test passes if no exceptions


def test_run_explore_multiple_navigation_cycles(monkeypatch):
    """Test navigating through multiple expand/collapse cycles."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    mock_templates = [
        SimpleNamespace(name="python-saas"),
        SimpleNamespace(name="react-client"),
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        return {
            "tier": "free",
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    # Simulate multiple interactions: expand, view template, expand another, exit
    choices = iter([
        "toggle:Backend Services",
        "tmpl:python-saas",
        "toggle:Frontend & UI",
        "tmpl:react-client",
        "back",
    ])
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices)),
    )
    
    pressed = []
    monkeypatch.setattr(
        explore_mod.questionary,
        "press_any_key_to_continue",
        lambda: SimpleNamespace(ask=lambda: pressed.append(True)),
    )
    
    explore_mod.run_explore()
    
    # Should have pressed key twice (once for each template details view)
    assert len(pressed) == 2


def test_run_explore_preserves_last_selected_value(monkeypatch):
    """Test that last selected value is preserved across menu redraws."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    mock_templates = [SimpleNamespace(name="python-saas")]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        return {
            "tier": "free",
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    select_calls = []
    
    def mock_select(*args, **kwargs):
        select_calls.append(kwargs)
        if len(select_calls) == 1:
            return SimpleNamespace(ask=lambda: "toggle:Backend Services")
        elif len(select_calls) == 2:
            # On second call, should have default set to previous selection
            return SimpleNamespace(ask=lambda: "back")
        else:
            return SimpleNamespace(ask=lambda: "back")
    
    monkeypatch.setattr(explore_mod.questionary, "select", mock_select)
    
    explore_mod.run_explore()
    
    # Check that default was set on second call
    assert len(select_calls) >= 2
    if len(select_calls) >= 2:
        # Second call should have 'default' set
        assert "default" in select_calls[1]


def test_run_explore_empty_template_list(monkeypatch):
    """Test explore with no templates available."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    # Empty template list
    monkeypatch.setattr(explore_mod, "get_templates", lambda: [])
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    # Test passes if no exceptions


def test_run_explore_all_categories_empty_filtered_out(monkeypatch):
    """Test that empty categories are filtered out."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    # Only templates that don't fit standard categories
    mock_templates = []
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "back"),
    )
    
    explore_mod.run_explore()
    
    # Should still print something
    assert len(printed) >= 1


def test_render_templates_tree_skip_empty_categories(monkeypatch):
    """Test that _render_templates_tree skips empty categories (line 40 coverage)."""
    from foundry.actions.explore import _render_templates_tree
    from foundry.actions import explore as explore_mod
    
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: printed.append(args))
    
    # Mix of empty and non-empty categories
    buckets = {
        "Backend Services": [],  # Empty, should be skipped
        "Frontend & UI": [
            {"name": "react-client", "tier": "free", "locked": False},
        ],
        "Mobile App": [],  # Empty, should be skipped
    }
    
    _render_templates_tree(buckets)
    
    # Should print tree but skip empty categories
    assert len(printed) == 1


def test_run_explore_locked_template_display(monkeypatch):
    """Test that locked templates show LOCKED label (line 176 coverage)."""
    from foundry.actions import explore as explore_mod
    
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(explore_mod.console, "print", lambda *args, **kwargs: None)
    
    # Free tier user
    monkeypatch.setattr(
        explore_mod,
        "get_current_license_info",
        lambda: {"tier": "free"},
    )
    
    mock_templates = [
        SimpleNamespace(name="python-saas"),
        SimpleNamespace(name="mobile-android"),
    ]
    monkeypatch.setattr(explore_mod, "get_templates", lambda: mock_templates)
    
    def mock_get_template_info(name):
        tiers = {
            "python-saas": "free",
            "mobile-android": "pro",  # Locked for free user
        }
        return {
            "tier": tiers.get(name, "free"),
            "repo": f"git@github.com:seed-source/{name}.git",
            "description": f"{name} template",
        }
    
    monkeypatch.setattr(explore_mod, "get_template_info", mock_get_template_info)
    
    select_calls = []
    
    def mock_select(*args, **kwargs):
        select_calls.append(kwargs)
        # First call: expand Backend
        if len(select_calls) == 1:
            return SimpleNamespace(ask=lambda: "toggle:Backend Services")
        # Second call: expand Mobile  
        elif len(select_calls) == 2:
            return SimpleNamespace(ask=lambda: "toggle:Mobile App")
        # Third call: exit
        else:
            return SimpleNamespace(ask=lambda: "back")
    
    monkeypatch.setattr(explore_mod.questionary, "select", mock_select)
    
    explore_mod.run_explore()
    
    # Check that we got multiple selection calls with locked templates displayed
    assert len(select_calls) == 3
