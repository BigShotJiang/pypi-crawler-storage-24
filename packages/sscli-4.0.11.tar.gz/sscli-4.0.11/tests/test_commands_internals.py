from pathlib import Path

import pytest
import typer

from foundry.commands import internals as internals_cmd


def test_annotate_generates_reports(tmp_path: Path, monkeypatch):
    workspace_root = tmp_path
    internal_projects_dir = workspace_root / "internal-projects"
    internal_projects_dir.mkdir(parents=True)
    log_path = internal_projects_dir / ".session.log"
    log_path.write_text(
        "[2026-03-01 11:48:41] GENERATE_SUCCESS: Template: static-landing, Target: /tmp/proj\n",
        encoding="utf-8",
    )

    printed = []
    monkeypatch.setattr(internals_cmd.console, "print", lambda msg: printed.append(msg))

    internals_cmd.annotate(workspace_root=workspace_root, strict=False)

    assert (internal_projects_dir / "reports" / "internals" / "internal-projects-failure-report.json").exists()
    assert (internal_projects_dir / "reports" / "internals" / "internal-projects-failure-report.md").exists()
    assert printed


def test_annotate_strict_exits_on_failures(tmp_path: Path, monkeypatch):
    workspace_root = tmp_path
    internal_projects_dir = workspace_root / "internal-projects"
    internal_projects_dir.mkdir(parents=True)
    log_path = internal_projects_dir / ".session.log"
    log_path.write_text(
        "[2026-03-01 11:44:59] GENERATE_ERROR: test failure\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(internals_cmd.console, "print", lambda *_args, **_kwargs: None)

    with pytest.raises(typer.Exit) as exc_info:
        internals_cmd.annotate(workspace_root=workspace_root, strict=True)

    assert exc_info.value.exit_code == 1
