import subprocess
from pathlib import Path

import pytest

from foundry.tools.synvert_adapter import SynvertAdapter


def _make_adapter(tmp_path):
    adapter = SynvertAdapter.__new__(SynvertAdapter)
    adapter.project_path = tmp_path
    return adapter


def test_parse_changed_files():
    adapter = SynvertAdapter.__new__(SynvertAdapter)
    output = "modify: app/models/user.rb\nchanged app/controllers/home_controller.rb\n"

    changed = adapter._parse_changed_files(output, success=True)

    assert "app/models/user.rb" in changed
    assert "app/controllers/home_controller.rb" in changed


def test_parse_changed_files_no_success():
    """Test parsing when success=False"""
    adapter = SynvertAdapter.__new__(SynvertAdapter)
    output = "modify: app/models/user.rb\n"

    changed = adapter._parse_changed_files(output, success=False)

    assert changed == []


def test_parse_changed_files_empty_output():
    """Test parsing with empty output"""
    adapter = SynvertAdapter.__new__(SynvertAdapter)
    output = ""

    changed = adapter._parse_changed_files(output, success=True)

    assert changed == []


def test_inline_rewrite_timeout(tmp_path, monkeypatch):
    adapter = _make_adapter(tmp_path)

    def _raise_timeout(*_args, **_kwargs):
        raise subprocess.TimeoutExpired(cmd=["synvert"], timeout=30)

    monkeypatch.setattr(subprocess, "run", _raise_timeout)

    result = adapter.inline_rewrite("class Synvert::Rewriter; end")

    assert result["success"] is False
    assert "timed out" in result["error_message"]
    assert not (tmp_path / ".synvert_tmp_rewriter.rb").exists()


def test_inline_rewrite_success(tmp_path, monkeypatch):
    adapter = _make_adapter(tmp_path)

    def _ok_run(cmd, **_kwargs):
        return subprocess.CompletedProcess(cmd, 0, stdout="modify: app/models/user.rb\n", stderr="")

    monkeypatch.setattr(subprocess, "run", _ok_run)

    result = adapter.inline_rewrite("class Synvert::Rewriter; end")

    assert result["success"] is True
    assert "app/models/user.rb" in result["changed_files"]
    assert not (tmp_path / ".synvert_tmp_rewriter.rb").exists()


def test_inline_rewrite_failure(tmp_path, monkeypatch):
    """Test inline_rewrite when synvert command fails"""
    adapter = _make_adapter(tmp_path)

    def _failed_run(cmd, **_kwargs):
        return subprocess.CompletedProcess(
            cmd, 1, 
            stdout="", 
            stderr="Synvert error: invalid syntax"
        )

    monkeypatch.setattr(subprocess, "run", _failed_run)

    result = adapter.inline_rewrite("invalid rewriter code")

    assert result["success"] is False
    assert "Synvert error" in result["stderr"]
    assert not (tmp_path / ".synvert_tmp_rewriter.rb").exists()


def test_inline_rewrite_exception(tmp_path, monkeypatch):
    """Test inline_rewrite exception handling"""
    adapter = _make_adapter(tmp_path)

    def _raise_error(*args, **kwargs):
        raise RuntimeError("Unexpected error")

    monkeypatch.setattr(subprocess, "run", _raise_error)

    result = adapter.inline_rewrite("class Synvert::Rewriter; end")

    assert result["success"] is False
    assert "Unexpected error" in result["error_message"]
    assert not (tmp_path / ".synvert_tmp_rewriter.rb").exists()


def test_check_ruby_not_found(tmp_path, monkeypatch):
    """Test when Ruby is not installed"""
    
    def _raise_not_found(*args, **kwargs):
        raise FileNotFoundError("ruby not found")

    monkeypatch.setattr(subprocess, "run", _raise_not_found)

    with pytest.raises(RuntimeError, match="Ruby not found"):
        SynvertAdapter(tmp_path)


def test_check_ruby_old_version(tmp_path, monkeypatch):
    """Test when Ruby version is too old"""
    
    def _old_ruby(*args, **kwargs):
        return subprocess.CompletedProcess(
            args[0], 0, 
            stdout="ruby 2.7.0 (2019-12-25 revision abc123)\n", 
            stderr=""
        )

    monkeypatch.setattr(subprocess, "run", _old_ruby)

    with pytest.raises(RuntimeError, match="Ruby 3.0\\+ required"):
        SynvertAdapter(tmp_path)


def test_check_ruby_returncode_error(tmp_path, monkeypatch):
    """Test when ruby -v command fails"""
    
    def _failed_ruby(*args, **kwargs):
        return subprocess.CompletedProcess(
            args[0], 1, 
            stdout="", 
            stderr="Command not found"
        )

    monkeypatch.setattr(subprocess, "run", _failed_ruby)

    with pytest.raises(RuntimeError, match="Ruby not installed or not in PATH"):
        SynvertAdapter(tmp_path)


def test_check_ruby_version_parse_error(tmp_path, monkeypatch):
    """Test when Ruby version string is malformed - returns as-is"""
    call_count = {"count": 0}
    
    def _mock_run(*args, **kwargs):
        call_count["count"] += 1
        if call_count["count"] == 1:
            # First call: ruby -v with malformed output
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="ruby\n",  # No version number
                stderr=""
            )
        else:
            # Second call: gem list synvert-core (returns correct version)
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="synvert-core (1.23.0)\n", 
                stderr=""
            )

    monkeypatch.setattr(subprocess, "run", _mock_run)

    # Should succeed but return malformed version string
    adapter = SynvertAdapter(tmp_path)
    assert adapter.ruby_version == "ruby"


def test_verify_synvert_gem_not_installed(tmp_path, monkeypatch):
    """Test when synvert-core gem is not installed"""
    call_count = {"count": 0}
    
    def _mock_run(*args, **kwargs):
        call_count["count"] += 1
        if call_count["count"] == 1:
            # First call: ruby -v
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="ruby 3.2.0 (2022-12-25 revision abc123)\n", 
                stderr=""
            )
        elif call_count["count"] == 2:
            # Second call: gem list synvert-core (not found)
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="other-gem (1.0.0)\n",  # synvert-core not in list
                stderr=""
            )
        elif call_count["count"] == 3:
            # Third call: gem install synvert-core
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="Successfully installed synvert-core\n", 
                stderr=""
            )
        else:
            # Fourth call: gem list verify — returns correct version
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="synvert-core (1.23.0)\n", 
                stderr=""
            )

    monkeypatch.setattr(subprocess, "run", _mock_run)

    # Should succeed after auto-installing
    adapter = SynvertAdapter(tmp_path)
    assert adapter.ruby_version.startswith("ruby 3.2")


def test_verify_synvert_gem_install_fails(tmp_path, monkeypatch):
    """Test when synvert-core gem installation fails"""
    call_count = {"count": 0}
    
    def _mock_run(*args, **kwargs):
        call_count["count"] += 1
        if call_count["count"] == 1:
            # First call: ruby -v
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="ruby 3.2.0 (2022-12-25 revision abc123)\n", 
                stderr=""
            )
        elif call_count["count"] == 2:
            # Second call: gem list synvert-core
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="other-gem (1.0.0)\n",
                stderr=""
            )
        else:
            # Third call: gem install synvert-core (fails)
            return subprocess.CompletedProcess(
                args[0], 1, 
                stdout="", 
                stderr="Permission denied"
            )

    monkeypatch.setattr(subprocess, "run", _mock_run)

    with pytest.raises(RuntimeError, match="Failed to install synvert-core"):
        SynvertAdapter(tmp_path)


def test_verify_synvert_gem_exception(tmp_path, monkeypatch):
    """Test when gem verification raises exception"""
    call_count = {"count": 0}
    
    def _mock_run(*args, **kwargs):
        call_count["count"] += 1
        if call_count["count"] == 1:
            # First call: ruby -v (succeeds)
            return subprocess.CompletedProcess(
                args[0], 0, 
                stdout="ruby 3.2.0 (2022-12-25 revision abc123)\n", 
                stderr=""
            )
        else:
            # Second call: gem list (raises exception)
            raise RuntimeError("Gem command failed")

    monkeypatch.setattr(subprocess, "run", _mock_run)

    with pytest.raises(RuntimeError, match="Synvert gem verification failed"):
        SynvertAdapter(tmp_path)


def test_add_webhook_routes_default(tmp_path, monkeypatch):
    """Test add_webhook_routes with default parameters"""
    adapter = _make_adapter(tmp_path)

    def _ok_run(cmd, **kwargs):
        return subprocess.CompletedProcess(
            cmd, 0, 
            stdout="modify: config/routes.rb\n", 
            stderr=""
        )

    monkeypatch.setattr(subprocess, "run", _ok_run)

    result = adapter.add_webhook_routes()

    assert result["success"] is True
    assert "config/routes.rb" in result["changed_files"]
    assert "rewriter_code" in result


def test_add_webhook_routes_custom(tmp_path, monkeypatch):
    """Test add_webhook_routes with custom namespace and routes"""
    adapter = _make_adapter(tmp_path)

    def _ok_run(cmd, **kwargs):
        return subprocess.CompletedProcess(
            cmd, 0, 
            stdout="modify: config/routes.rb\n", 
            stderr=""
        )

    monkeypatch.setattr(subprocess, "run", _ok_run)

    route_specs = [
        ("post", "stripe", "webhooks/stripe#handle"),
        ("post", "paypal", "webhooks/paypal#process")
    ]

    result = adapter.add_webhook_routes(
        namespace="api/v1/webhooks",
        route_specs=route_specs
    )

    assert result["success"] is True
    assert "api_v1_webhooks_routes" in result["rewriter_code"]


def test_add_model_association_basic(tmp_path, monkeypatch):
    """Test add_model_association with basic parameters"""
    adapter = _make_adapter(tmp_path)

    def _ok_run(cmd, **kwargs):
        return subprocess.CompletedProcess(
            cmd, 0, 
            stdout="modify: app/models/order.rb\n", 
            stderr=""
        )

    monkeypatch.setattr(subprocess, "run", _ok_run)

    result = adapter.add_model_association(
        model_name="Order",
        association_type="has_many",
        target="items"
    )

    assert result["success"] is True
    assert "app/models/order.rb" in result["changed_files"]
    assert "has_many :items" in result["rewriter_code"]


def test_add_model_association_with_options(tmp_path, monkeypatch):
    """Test add_model_association with additional options"""
    adapter = _make_adapter(tmp_path)

    def _ok_run(cmd, **kwargs):
        return subprocess.CompletedProcess(
            cmd, 0, 
            stdout="modify: app/models/tenant.rb\n", 
            stderr=""
        )

    monkeypatch.setattr(subprocess, "run", _ok_run)

    result = adapter.add_model_association(
        model_name="Tenant",
        association_type="belongs_to",
        target="organization",
        class_name="Org",
        foreign_key="org_id",
        dependent="destroy"
    )

    assert result["success"] is True
    assert "class_name: 'Org'" in result["rewriter_code"]
    assert "foreign_key: 'org_id'" in result["rewriter_code"]
    assert "dependent: 'destroy'" in result["rewriter_code"]


def test_add_model_association_boolean_options(tmp_path, monkeypatch):
    """Test add_model_association with boolean options"""
    adapter = _make_adapter(tmp_path)

    def _ok_run(cmd, **kwargs):
        return subprocess.CompletedProcess(
            cmd, 0, 
            stdout="modify: app/models/user.rb\n", 
            stderr=""
        )

    monkeypatch.setattr(subprocess, "run", _ok_run)

    result = adapter.add_model_association(
        model_name="User",
        association_type="has_one",
        target="profile",
        optional=True,
        autosave=False
    )

    assert result["success"] is True
    assert "optional: true" in result["rewriter_code"]
    assert "autosave: false" in result["rewriter_code"]


def test_validate_ruby_syntax_valid(tmp_path, monkeypatch):
    """Test validate_ruby_syntax with valid Ruby file"""
    adapter = _make_adapter(tmp_path)
    test_file = tmp_path / "test.rb"
    test_file.write_text("class User\nend\n")

    def _ok_run(*args, **kwargs):
        return subprocess.CompletedProcess(
            args[0], 0, 
            stdout="Syntax OK\n", 
            stderr=""
        )

    monkeypatch.setattr(subprocess, "run", _ok_run)

    result = adapter.validate_ruby_syntax(test_file)

    assert result["valid"] is True
    assert result["error"] is None


def test_validate_ruby_syntax_invalid(tmp_path, monkeypatch):
    """Test validate_ruby_syntax with invalid Ruby file"""
    adapter = _make_adapter(tmp_path)
    test_file = tmp_path / "test.rb"
    test_file.write_text("class User\n")  # Missing end

    def _failed_run(*args, **kwargs):
        return subprocess.CompletedProcess(
            args[0], 1, 
            stdout="", 
            stderr="test.rb:2: syntax error, unexpected end-of-input"
        )

    monkeypatch.setattr(subprocess, "run", _failed_run)

    result = adapter.validate_ruby_syntax(test_file)

    assert result["valid"] is False
    assert "syntax error" in result["error"]


def test_validate_ruby_syntax_exception(tmp_path, monkeypatch):
    """Test validate_ruby_syntax exception handling"""
    adapter = _make_adapter(tmp_path)
    test_file = tmp_path / "test.rb"

    def _raise_error(*args, **kwargs):
        raise RuntimeError("Ruby command failed")

    monkeypatch.setattr(subprocess, "run", _raise_error)

    result = adapter.validate_ruby_syntax(test_file)

    assert result["valid"] is False
    assert "Ruby command failed" in result["error"]


def test_synvert_adapter_init_success(tmp_path, monkeypatch):
    """Test successful SynvertAdapter initialization"""
    
    def _mock_run(*args, **kwargs):
        cmd = args[0]
        if "ruby" in cmd[0]:
            return subprocess.CompletedProcess(
                cmd, 0, 
                stdout="ruby 3.2.0 (2022-12-25 revision abc123)\n", 
                stderr=""
            )
        else:
            return subprocess.CompletedProcess(
                cmd, 0, 
                stdout="synvert-core (1.23.0)\n", 
                stderr=""
            )

    monkeypatch.setattr(subprocess, "run", _mock_run)

    adapter = SynvertAdapter(tmp_path)
    assert adapter.project_path == tmp_path
    assert "ruby 3.2" in adapter.ruby_version
