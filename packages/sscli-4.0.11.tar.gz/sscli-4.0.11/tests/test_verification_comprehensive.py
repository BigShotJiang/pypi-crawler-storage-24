"""
Comprehensive verification tests to increase coverage for:
- foundry/actions/verification/verifier.py
- foundry/actions/verification_interactive.py
- foundry/actions/verify.py
"""
import subprocess
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from foundry.actions.verification.models import (
    TemplateType,
    VerificationResult,
    VerificationStatus,
)
from foundry.actions.verification.verifier import TemplateVerifier


# =================== VERIFIER.PY TESTS ===================

def test_verify_all_with_progress(tmp_path, monkeypatch):
    """Test verify_all with full progress tracking."""
    # Create two templates
    for template_name in ["python-saas", "rails-api"]:
        template_dir = tmp_path / "templates" / template_name
        template_dir.mkdir(parents=True)
        (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
        (template_dir / "Dockerfile").write_text("FROM python:3.11\n", encoding="utf-8")
        (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")

    # Mock docker to succeed
    def mock_run(cmd, **kwargs):
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(subprocess, "run", mock_run)
    monkeypatch.setattr("foundry.actions.verification.verifier.console", MagicMock())

    verifier = TemplateVerifier(tmp_path)
    results = verifier.verify_all(include_docker=True)

    assert len(results) == 8  # All templates in TEMPLATES dict
    assert "python-saas" in results
    assert "rails-api" in results
    assert results["python-saas"].status in [VerificationStatus.SUCCESS, VerificationStatus.FAILED]


def test_verify_all_skip_docker(tmp_path, monkeypatch):
    """Test verify_all without Docker builds."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
    (template_dir / "Dockerfile").write_text("FROM python:3.11\n", encoding="utf-8")
    (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")

    monkeypatch.setattr("foundry.actions.verification.verifier.console", MagicMock())

    verifier = TemplateVerifier(tmp_path)
    results = verifier.verify_all(include_docker=False)

    # When include_docker=False, docker_success should be False
    for name, result in results.items():
        if result.status == VerificationStatus.SUCCESS:
            assert result.docker_success is False


def test_run_docker_failed_build_with_stderr(tmp_path, monkeypatch):
    """Test Docker build failure with stderr output."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
    (template_dir / "Dockerfile").write_text("FROM scratch\n", encoding="utf-8")
    (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")

    def mock_run(cmd, **kwargs):
        return subprocess.CompletedProcess(
            cmd, 1, stdout="", stderr="Error: missing base image\nFailed to build\n"
        )

    monkeypatch.setattr(subprocess, "run", mock_run)

    result = VerificationResult(
        name="python-saas",
        template_type=TemplateType.DOCKER,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier = TemplateVerifier(tmp_path)
    verifier._run_docker(template_dir, "python-saas", result)

    assert result.status == VerificationStatus.FAILED
    assert result.docker_success is False
    assert "Failed to build" in result.notes


def test_run_docker_failed_build_no_stderr(tmp_path, monkeypatch):
    """Test Docker build failure without stderr (empty)."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)

    def mock_run(cmd, **kwargs):
        return subprocess.CompletedProcess(cmd, 1, stdout="", stderr="")

    monkeypatch.setattr(subprocess, "run", mock_run)

    result = VerificationResult(
        name="python-saas",
        template_type=TemplateType.DOCKER,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier = TemplateVerifier(tmp_path)
    verifier._run_docker(template_dir, "python-saas", result)

    assert result.status == VerificationStatus.FAILED
    assert "Docker build failed" in result.notes


def test_run_terraform_validation_failed(tmp_path, monkeypatch):
    """Test Terraform validation failure with CalledProcessError."""
    template_dir = tmp_path / "templates" / "terraform-infra"
    template_dir.mkdir(parents=True)

    def mock_run(cmd, **kwargs):
        if "validate" in cmd:
            raise subprocess.CalledProcessError(1, cmd, stderr="Invalid syntax")
        return subprocess.CompletedProcess(cmd, 0)

    monkeypatch.setattr(subprocess, "run", mock_run)

    result = VerificationResult(
        name="terraform-infra",
        template_type=TemplateType.TERRAFORM,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier = TemplateVerifier(tmp_path)
    verifier._run_terraform(template_dir, result)

    assert result.status == VerificationStatus.FAILED
    assert result.docker_success is False
    assert "Terraform validation failed" in result.notes


def test_run_terraform_generic_exception(tmp_path, monkeypatch):
    """Test Terraform run with generic exception."""
    template_dir = tmp_path / "templates" / "terraform-infra"
    template_dir.mkdir(parents=True)

    def mock_run(cmd, **kwargs):
        raise ValueError("Unexpected error")

    monkeypatch.setattr(subprocess, "run", mock_run)

    result = VerificationResult(
        name="terraform-infra",
        template_type=TemplateType.TERRAFORM,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier = TemplateVerifier(tmp_path)
    verifier._run_terraform(template_dir, result)

    assert result.status == VerificationStatus.ERROR
    assert "Unexpected error" in result.notes


def test_check_files_missing_gitignore(tmp_path):
    """Test check_files when .gitignore is missing."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    # Don't create .gitignore

    verifier = TemplateVerifier(tmp_path)
    result = VerificationResult(
        name="python-saas",
        template_type=TemplateType.DOCKER,
        status=VerificationStatus.SUCCESS,
        git_ignore=False,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier._check_files(template_dir, TemplateType.DOCKER, result)

    assert result.status == VerificationStatus.FAILED
    assert result.git_ignore is False
    assert "Missing .gitignore" in result.notes


def test_check_files_missing_dockerfile(tmp_path):
    """Test check_files when Dockerfile is missing."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
    (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")
    # Don't create Dockerfile

    verifier = TemplateVerifier(tmp_path)
    result = VerificationResult(
        name="python-saas",
        template_type=TemplateType.DOCKER,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier._check_files(template_dir, TemplateType.DOCKER, result)

    assert result.status == VerificationStatus.FAILED
    assert "Missing Dockerfile" in result.notes


def test_check_files_missing_readme(tmp_path):
    """Test check_files when README.md is missing."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
    (template_dir / "Dockerfile").write_text("FROM python:3.11\n", encoding="utf-8")
    # Don't create README.md

    verifier = TemplateVerifier(tmp_path)
    result = VerificationResult(
        name="python-saas",
        template_type=TemplateType.DOCKER,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier._check_files(template_dir, TemplateType.DOCKER, result)

    assert result.status == VerificationStatus.FAILED
    assert "Missing README.md" in result.notes


def test_check_files_terraform_missing_maintf(tmp_path):
    """Test check_files for Terraform template missing main.tf."""
    template_dir = tmp_path / "templates" / "terraform-infra"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.tfstate", encoding="utf-8")
    (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")
    # Don't create main.tf

    verifier = TemplateVerifier(tmp_path)
    result = VerificationResult(
        name="terraform-infra",
        template_type=TemplateType.TERRAFORM,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier._check_files(template_dir, TemplateType.TERRAFORM, result)

    assert result.status == VerificationStatus.FAILED
    assert "Missing main.tf" in result.notes


def test_check_files_has_gitattributes(tmp_path):
    """Test check_files detects .gitattributes."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
    (template_dir / ".gitattributes").write_text("* text=auto", encoding="utf-8")
    (template_dir / "Dockerfile").write_text("FROM python:3.11\n", encoding="utf-8")
    (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")

    verifier = TemplateVerifier(tmp_path)
    result = VerificationResult(
        name="python-saas",
        template_type=TemplateType.DOCKER,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )

    verifier._check_files(template_dir, TemplateType.DOCKER, result)

    assert result.git_attributes is True
    assert result.status == VerificationStatus.SUCCESS


# =================== VERIFY.PY TESTS ===================

def test_run_verification_full_workflow(tmp_path, monkeypatch):
    """Test run_verification with full workflow."""
    # Create a minimal template structure
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
    (template_dir / "Dockerfile").write_text("FROM python:3.11\n", encoding="utf-8")
    (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")

    # Mock subprocess to avoid actual docker builds
    def mock_run(cmd, **kwargs):
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(subprocess, "run", mock_run)

    # Mock console to avoid output
    from foundry.actions import verify
    monkeypatch.setattr(verify, "console", MagicMock())
    
    # Mock generate_reports and print_summary
    mock_generate = MagicMock()
    mock_print = MagicMock(return_value=0)
    monkeypatch.setattr(verify, "generate_reports", mock_generate)
    monkeypatch.setattr(verify, "print_summary", mock_print)

    # Adjust __file__ path to point to tmp_path
    original_file = verify.__file__
    fake_file = tmp_path / "foundry" / "actions" / "verify.py"
    fake_file.parent.mkdir(parents=True, exist_ok=True)
    fake_file.touch()
    monkeypatch.setattr(verify, "__file__", str(fake_file))

    # Run verification
    verify.run_verification(include_docker=False, output_reports=True, include_features=False)

    # Verify reports and summary were called
    assert mock_generate.called
    assert mock_print.called


def test_run_verification_with_features(tmp_path, monkeypatch):
    """Test run_verification with feature matrix tests enabled."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("*.pyc", encoding="utf-8")
    (template_dir / "Dockerfile").write_text("FROM python:3.11\n", encoding="utf-8")
    (template_dir / "README.md").write_text("# Test\n", encoding="utf-8")

    def mock_run(cmd, **kwargs):
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(subprocess, "run", mock_run)

    from foundry.actions import verify
    monkeypatch.setattr(verify, "console", MagicMock())
    
    mock_generate = MagicMock()
    mock_print = MagicMock(return_value=0)
    mock_feature_tests = MagicMock(return_value=True)
    
    monkeypatch.setattr(verify, "generate_reports", mock_generate)
    monkeypatch.setattr(verify, "print_summary", mock_print)
    monkeypatch.setattr(verify, "run_feature_matrix_tests", mock_feature_tests)

    original_file = verify.__file__
    fake_file = tmp_path / "foundry" / "actions" / "verify.py"
    fake_file.parent.mkdir(parents=True, exist_ok=True)
    fake_file.touch()
    monkeypatch.setattr(verify, "__file__", str(fake_file))

    verify.run_verification(include_docker=False, output_reports=True, include_features=True)

    assert mock_feature_tests.called


def test_run_feature_matrix_tests_failure(monkeypatch):
    """Test run_feature_matrix_tests when tests fail."""
    class FakeResult:
        returncode = 1

    monkeypatch.setattr("subprocess.run", lambda *a, **k: FakeResult())
    
    from foundry.actions import verify
    monkeypatch.setattr(verify.console, "print", lambda *_a, **_k: None)

    assert verify.run_feature_matrix_tests() is False


def test_run_feature_matrix_tests_exception(monkeypatch):
    """Test run_feature_matrix_tests with generic exception."""
    def mock_run(*args, **kwargs):
        raise RuntimeError("Unexpected error")

    monkeypatch.setattr("subprocess.run", mock_run)
    
    from foundry.actions import verify
    monkeypatch.setattr(verify.console, "print", lambda *_a, **_k: None)

    assert verify.run_feature_matrix_tests() is False


# =================== VERIFICATION_INTERACTIVE.PY TESTS ===================

def test_interactive_mount_feature_full_flow(monkeypatch):
    """Test interactive_mount_feature with full workflow."""
    import sys
    from foundry.actions import verification_interactive

    # Mock all dependencies
    mock_templates = [SimpleNamespace(name="python-saas"), SimpleNamespace(name="rails-api")]
    mock_extensions = {
        "commerce": {"templates": ["python-saas", "rails-api"]},
        "tunnel": {"templates": ["python-saas"]},
    }

    monkeypatch.setattr("foundry.utils.get_templates", lambda: mock_templates)
    monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
    
    # Mock the features module
    import types
    fake_features = types.SimpleNamespace(AVAILABLE_EXTENSIONS=mock_extensions)
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    # Mock questionary responses
    selections = iter(["python-saas", "commerce", "/tmp/test", True])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections, None)),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections, None)),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections, None)),
    )

    # Mock mount_feature to succeed
    mock_mount = MagicMock(return_value=True)
    monkeypatch.setattr("foundry.actions.development.mount_feature", mock_mount)

    # Mock console output
    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    # Mock Path.exists to return True
    monkeypatch.setattr(Path, "exists", lambda self: True)

    verification_interactive.interactive_mount_feature()

    assert mock_mount.called


def test_interactive_mount_feature_no_compatible_features(monkeypatch):
    """Test interactive_mount_feature when no features available for template."""
    import sys
    from foundry.actions import verification_interactive

    mock_templates = [SimpleNamespace(name="mobile-android")]
    mock_extensions = {
        "commerce": {"templates": ["python-saas"]},
    }

    monkeypatch.setattr("foundry.utils.get_templates", lambda: mock_templates)
    monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
    
    import types
    fake_features = types.SimpleNamespace(AVAILABLE_EXTENSIONS=mock_extensions)
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    selections = iter(["mobile-android"])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections, None)),
    )

    printed = []
    monkeypatch.setattr(verification_interactive.console, "print", lambda msg: printed.append(msg))

    verification_interactive.interactive_mount_feature()

    assert any("No features available" in str(msg) for msg in printed)


def test_interactive_mount_feature_user_cancels(monkeypatch):
    """Test interactive_mount_feature when user cancels at various stages."""
    import sys
    from foundry.actions import verification_interactive

    mock_templates = [SimpleNamespace(name="python-saas")]
    mock_extensions = {"commerce": {"templates": ["python-saas"]}}

    monkeypatch.setattr("foundry.utils.get_templates", lambda: mock_templates)
    monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
    
    import types
    fake_features = types.SimpleNamespace(AVAILABLE_EXTENSIONS=mock_extensions)
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    # User cancels at template selection
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )

    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    verification_interactive.interactive_mount_feature()
    # Should return without error


def test_interactive_mount_feature_mount_fails(monkeypatch):
    """Test interactive_mount_feature when mount_feature fails."""
    import sys
    from foundry.actions import verification_interactive

    mock_templates = [SimpleNamespace(name="python-saas")]
    mock_extensions = {"commerce": {"templates": ["python-saas"]}}

    monkeypatch.setattr("foundry.utils.get_templates", lambda: mock_templates)
    monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
    
    import types
    fake_features = types.SimpleNamespace(AVAILABLE_EXTENSIONS=mock_extensions)
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    selections = iter(["python-saas", "commerce", "/tmp/test", True])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )

    mock_mount = MagicMock(return_value=False)
    monkeypatch.setattr("foundry.actions.development.mount_feature", mock_mount)

    printed = []
    monkeypatch.setattr(verification_interactive.console, "print", lambda msg: printed.append(msg))
    monkeypatch.setattr(Path, "exists", lambda self: True)

    verification_interactive.interactive_mount_feature()

    assert any("Mounting failed" in str(msg) for msg in printed)


def test_interactive_mount_feature_exception(monkeypatch):
    """Test interactive_mount_feature when exception occurs."""
    import sys
    from foundry.actions import verification_interactive

    mock_templates = [SimpleNamespace(name="python-saas")]
    mock_extensions = {"commerce": {"templates": ["python-saas"]}}

    monkeypatch.setattr("foundry.utils.get_templates", lambda: mock_templates)
    monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
    
    import types
    fake_features = types.SimpleNamespace(AVAILABLE_EXTENSIONS=mock_extensions)
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    selections = iter(["python-saas", "commerce", "/tmp/test", True])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )

    def mock_mount(*args, **kwargs):
        raise RuntimeError("Mount error")

    monkeypatch.setattr("foundry.actions.development.mount_feature", mock_mount)

    printed = []
    monkeypatch.setattr(verification_interactive.console, "print", lambda msg: printed.append(msg))
    monkeypatch.setattr(Path, "exists", lambda self: True)

    verification_interactive.interactive_mount_feature()

    assert any("Error" in str(msg) for msg in printed)


def test_interactive_matrix_tests_with_test_file(monkeypatch, tmp_path):
    """Test interactive_matrix_tests when test file exists and runs."""
    from foundry.actions import verification_interactive

    # Create fake test file
    test_file = tmp_path / "tests" / "integration" / "test_feature_matrix.py"
    test_file.parent.mkdir(parents=True)
    test_file.write_text("# test file", encoding="utf-8")

    confirms = iter([False, True])  # skip_docker=False, verbose=True
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(confirms)),
    )

    # Mock Path to return our test file
    original_file = verification_interactive.__file__
    fake_file = tmp_path / "verification_interactive.py"
    fake_file.touch()
    monkeypatch.setattr(verification_interactive, "__file__", str(fake_file))

    # Mock subprocess to succeed
    mock_result = SimpleNamespace(returncode=0)
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: mock_result)

    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    verification_interactive.interactive_matrix_tests()


def test_interactive_matrix_tests_failure(monkeypatch, tmp_path):
    """Test interactive_matrix_tests when tests fail."""
    from foundry.actions import verification_interactive

    test_file = tmp_path / "tests" / "integration" / "test_feature_matrix.py"
    test_file.parent.mkdir(parents=True)
    test_file.write_text("# test file", encoding="utf-8")

    confirms = iter([True, False])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(confirms)),
    )

    fake_file = tmp_path / "verification_interactive.py"
    fake_file.touch()
    monkeypatch.setattr(verification_interactive, "__file__", str(fake_file))

    mock_result = SimpleNamespace(returncode=1)
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: mock_result)

    printed = []
    monkeypatch.setattr(verification_interactive.console, "print", lambda *args, **kwargs: printed.append(str(args)))

    verification_interactive.interactive_matrix_tests()

    # Should have captured some output including the failure message
    assert len(printed) > 0


def test_interactive_matrix_tests_exception(monkeypatch, tmp_path):
    """Test interactive_matrix_tests when exception occurs."""
    from foundry.actions import verification_interactive

    test_file = tmp_path / "tests" / "integration" / "test_feature_matrix.py"
    test_file.parent.mkdir(parents=True)
    test_file.write_text("# test file", encoding="utf-8")

    confirms = iter([True, False])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(confirms)),
    )

    fake_file = tmp_path / "verification_interactive.py"
    fake_file.touch()
    monkeypatch.setattr(verification_interactive, "__file__", str(fake_file))

    def mock_run(*args, **kwargs):
        raise RuntimeError("Test failure")

    monkeypatch.setattr(subprocess, "run", mock_run)

    printed = []
    monkeypatch.setattr(verification_interactive.console, "print", lambda *args, **kwargs: printed.append(str(args)))

    verification_interactive.interactive_matrix_tests()

    # Should have captured some output including the error
    assert len(printed) > 0


def test_interactive_verify_all_no_selection(monkeypatch):
    """Test interactive_verify_all when user cancels."""
    from foundry.actions import verification_interactive

    monkeypatch.setattr(
        verification_interactive.questionary,
        "checkbox",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )

    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    verification_interactive.interactive_verify_all()
    # Should return without error


def test_interactive_verify_all_all_options(monkeypatch):
    """Test interactive_verify_all with all verification steps selected."""
    from foundry.actions import verification_interactive

    monkeypatch.setattr(
        verification_interactive.questionary,
        "checkbox",
        lambda *a, **k: SimpleNamespace(ask=lambda: ["matrix", "linters", "tests", "docker"]),
    )

    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    verification_interactive.interactive_verify_all()


def test_interactive_verify_all_with_exception(monkeypatch):
    """Test interactive_verify_all when exception occurs during verification."""
    from foundry.actions import verification_interactive

    monkeypatch.setattr(
        verification_interactive.questionary,
        "checkbox",
        lambda *a, **k: SimpleNamespace(ask=lambda: ["matrix"]),
    )

    def mock_print(msg):
        if "Running" in str(msg):
            raise RuntimeError("Verification error")

    monkeypatch.setattr(verification_interactive.console, "print", mock_print)

    try:
        verification_interactive.interactive_verify_all()
    except RuntimeError:
        pass  # Expected


def test_verification_menu_none_selection(monkeypatch):
    """Test verification_menu when user returns None (ESC key)."""
    from foundry.actions import verification_interactive

    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )

    verification_interactive.verification_menu()
    # Should exit cleanly
