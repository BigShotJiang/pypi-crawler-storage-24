import pytest
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock
from foundry.actions.features import (
    _inject_rails_commerce_routes,
    _inject_rails_routes_fallback,
    _inject_tunnel_config,
    _inject_landing_instructions,
    _remove_commerce_files
)

def test_inject_rails_routes_fallback(tmp_path):
    # Setup mock Rails project
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    routes_rb = config_dir / "routes.rb"
    routes_rb.write_text("Rails.application.routes.draw do\n  root to: 'home#index'\nend")
    
    _inject_rails_routes_fallback(tmp_path)
    
    content = routes_rb.read_text()
    assert "namespace :webhooks" in content
    assert "post 'shopify'" in content
    assert content.endswith("end\n")

@patch("foundry.actions.features.SynvertAdapter")
def test_inject_rails_commerce_routes_synvert(mock_adapter_class, tmp_path):
    # Setup mock Rails project
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    routes_rb = config_dir / "routes.rb"
    routes_rb.write_text("Rails.application.routes.draw do\nend")
    
    # Mock SynvertAdapter
    mock_adapter = MagicMock()
    mock_adapter.add_webhook_routes.return_value = {"success": True}
    mock_adapter.validate_ruby_syntax.return_value = {"valid": True}
    mock_adapter_class.return_value = mock_adapter
    
    _inject_rails_commerce_routes(tmp_path)
    
    assert mock_adapter.add_webhook_routes.called
    assert mock_adapter.validate_ruby_syntax.called

@patch("foundry.actions.features._inject_rails_routes_fallback")
@patch("foundry.actions.features.SynvertAdapter")
def test_inject_rails_commerce_routes_synvert_fail_fallback(mock_adapter_class, mock_fallback, tmp_path):
    # Setup mock Rails project
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    routes_rb = config_dir / "routes.rb"
    routes_rb.write_text("Rails.application.routes.draw do\nend")
    
    # Mock SynvertAdapter failure
    mock_adapter_class.side_effect = RuntimeError("Synvert not found")
    
    _inject_rails_commerce_routes(tmp_path)
    
    assert mock_fallback.called

def test_inject_tunnel_config(tmp_path):
    # Setup mock project
    (tmp_path / "docker-compose.yml").write_text("services:\n  api:\n    image: rails:latest")
    (tmp_path / ".env.example").write_text("PORT=3000")
    (tmp_path / "README.md").write_text("# Project")
    
    _inject_tunnel_config(tmp_path, "rails-api")
    
    assert "tunnel:" in (tmp_path / "docker-compose.yml").read_text()
    assert "NGROK_AUTHTOKEN" in (tmp_path / ".env.example").read_text()
    assert "## 🌐 Local Tunneling (ngrok)" in (tmp_path / "README.md").read_text()

def test_inject_landing_instructions(tmp_path):
    readme = tmp_path / "README.md"
    readme.write_text("# Project")
    
    _inject_landing_instructions(tmp_path)
    
    assert "## 🚀 Static Landing Page" in readme.read_text()

def test_remove_commerce_files(tmp_path):
    # Setup mock project with commerce files
    infra_dir = tmp_path / "src" / "infrastructure" / "commerce"
    infra_dir.mkdir(parents=True)
    (infra_dir / "stripe.py").write_text("stripe")
    
    _remove_commerce_files(tmp_path, "python-saas")
    
    assert not infra_dir.exists()
