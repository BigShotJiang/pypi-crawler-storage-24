from pathlib import Path
from unittest.mock import patch

from foundry.commands.post_generate import run_post_generate_checklist


def test_checklist_no_env(tmp_path):
    run_post_generate_checklist("my-project", "python-saas", tmp_path)


def test_checklist_with_env(tmp_path):
    (tmp_path / ".env").write_text("KEY=value\n", encoding="utf-8")
    run_post_generate_checklist("my-project", "react-client", tmp_path)


def test_checklist_no_docker(tmp_path):
    with patch("subprocess.run", side_effect=FileNotFoundError):
        run_post_generate_checklist("my-project", "rails-api", tmp_path)
