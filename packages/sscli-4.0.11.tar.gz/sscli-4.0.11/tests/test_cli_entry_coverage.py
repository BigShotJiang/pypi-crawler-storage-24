"""
Comprehensive test coverage for foundry/cli.py entry points.
Target: Increase coverage from 71% to 95%+

Missing lines to cover:
- 40-41: default_action callback
- 46: whoami command
- 52-53: logout command
- 59-60: explore command
- 164-172: inject auto-detection paths
- 210-211: setup command
- 219-220: validate command
- 226-227: health command
- 243-244: verify command
- 269-279: upgrade command
"""

import pytest
from pathlib import Path
from typer.testing import CliRunner
from foundry.cli import app


runner = CliRunner()


class TestDefaultAction:
    """Test default_action callback - covers lines 40-41"""

    def test_invokes_interactive_menu_when_no_command(self, monkeypatch):
        """Test that running sscli with no args invokes interactive menu."""
        menu_called = {"called": False}

        def fake_interactive_menu():
            menu_called["called"] = True

        monkeypatch.setattr("foundry.interactive.interactive_menu", fake_interactive_menu)
        
        # This should invoke default_action which calls interactive_menu
        result = runner.invoke(app, [])
        assert menu_called["called"] is True

    def test_does_not_invoke_menu_when_command_provided(self, monkeypatch):
        """Test that default_action doesn't trigger when a command is provided."""
        menu_called = {"called": False}

        def fake_interactive_menu():
            menu_called["called"] = True

        monkeypatch.setattr("foundry.interactive.interactive_menu", fake_interactive_menu)
        monkeypatch.setattr("foundry.cli.run_whoami", lambda: None)
        
        # This should NOT invoke default_action
        result = runner.invoke(app, ["whoami"])
        assert menu_called["called"] is False


class TestWhoamiCommand:
    """Test whoami command - covers line 46"""

    def test_whoami_invokes_run_whoami(self, monkeypatch):
        """Test that 'sscli whoami' command calls run_whoami."""
        whoami_called = {"called": False}

        def fake_run_whoami():
            whoami_called["called"] = True

        monkeypatch.setattr("foundry.cli.run_whoami", fake_run_whoami)
        
        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0
        assert whoami_called["called"] is True


class TestLogoutCommand:
    """Test logout command - covers lines 52-53"""

    def test_logout_logs_event_and_calls_logout(self, monkeypatch):
        """Test that 'sscli logout' logs event and calls logout function."""
        logout_called = {"called": False}
        events = []

        def fake_logout():
            logout_called["called"] = True

        def fake_log_event(category, action):
            events.append((category, action))

        monkeypatch.setattr("foundry.cli.logout", fake_logout)
        monkeypatch.setattr("foundry.cli.log_event", fake_log_event)
        
        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0
        assert logout_called["called"] is True
        assert ("COMMAND", "logout") in events


class TestExploreCommand:
    """Test explore command - covers lines 59-60"""

    def test_explore_logs_event_and_calls_run_explore(self, monkeypatch):
        """Test that 'sscli explore' logs event and calls run_explore."""
        explore_called = {"interactive": False, "list": False}
        events = []

        def fake_run_explore():
            explore_called["interactive"] = True

        def fake_run_explore_list():
            explore_called["list"] = True

        def fake_log_event(category, action):
            events.append((category, action))

        monkeypatch.setattr("foundry.cli.run_explore", fake_run_explore)
        monkeypatch.setattr("foundry.cli.run_explore_list", fake_run_explore_list)
        monkeypatch.setattr("foundry.cli.log_event", fake_log_event)
        
        result = runner.invoke(app, ["explore"])
        assert result.exit_code == 0
        assert explore_called["interactive"] or explore_called["list"]
        assert ("COMMAND", "explore") in events


class TestInjectCommand:
    """Test inject command auto-detection - covers lines 164-172"""

    def test_inject_nonexistent_path_prints_error(self, tmp_path):
        """Test inject with nonexistent path prints error - covers lines 157-158."""
        fake_path = tmp_path / "does_not_exist"
        
        result = runner.invoke(app, [
            "inject",
            "--path", str(fake_path),
            "--features", "commerce"
        ])
        assert result.exit_code == 1
        assert "Error: Path" in result.stdout
        assert "does not exist" in result.stdout

    def test_inject_autodetects_python_saas(self, tmp_path, monkeypatch):
        """Test inject auto-detects python-saas from pyproject.toml - covers line 163."""
        (tmp_path / "pyproject.toml").write_text('[project]\nname = "app"')
        captured = {}

        def fake_inject_features(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr("foundry.actions.features.inject_features", fake_inject_features)
        
        result = runner.invoke(app, ["inject", "--path", str(tmp_path), "--features", "commerce"])
        assert result.exit_code == 0
        assert captured["template"] == "python-saas"

    def test_inject_autodetects_react_client(self, tmp_path, monkeypatch):
        """Test inject auto-detects react-client from package.json."""
        (tmp_path / "package.json").write_text('{"name": "app"}')
        captured = {}

        def fake_inject_features(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr("foundry.actions.features.inject_features", fake_inject_features)
        
        result = runner.invoke(app, ["inject", "--path", str(tmp_path), "--features", "commerce"])
        assert result.exit_code == 0
        assert captured["template"] == "react-client"

    def test_inject_autodetects_rails_api(self, tmp_path, monkeypatch):
        """Test inject auto-detects rails-api from Gemfile."""
        (tmp_path / "Gemfile").write_text('source "https://rubygems.org"\ngem "rails"')
        captured = {}

        def fake_inject_features(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr("foundry.actions.features.inject_features", fake_inject_features)
        
        result = runner.invoke(app, ["inject", "--path", str(tmp_path), "--features", "commerce"])
        assert result.exit_code == 0
        assert captured["template"] == "rails-api"

    def test_inject_autodetects_static_landing(self, tmp_path, monkeypatch):
        """Test inject auto-detects static-landing from astro.config.mjs."""
        (tmp_path / "astro.config.mjs").write_text('export default {}')
        captured = {}

        def fake_inject_features(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr("foundry.actions.features.inject_features", fake_inject_features)
        
        result = runner.invoke(app, ["inject", "--path", str(tmp_path), "--features", "commerce"])
        assert result.exit_code == 0
        assert captured["template"] == "static-landing"

    def test_inject_fails_when_cannot_autodetect(self, tmp_path, monkeypatch):
        """Test inject fails gracefully when it cannot auto-detect template."""
        # Empty directory with no recognizable files
        result = runner.invoke(app, ["inject", "--path", str(tmp_path), "--features", "commerce"])
        assert result.exit_code != 0
        assert "Could not auto-detect template type" in result.stdout


class TestSetupCommand:
    """Test setup command - covers lines 210-211"""

    def test_setup_logs_event_and_calls_run_setup(self, monkeypatch):
        """Test that 'sscli setup' logs event and calls run_setup."""
        setup_called = {"called": False}
        events = []
        captured = {}

        def fake_run_setup(**kwargs):
            setup_called["called"] = True
            captured.update(kwargs)

        def fake_log_event(category, action):
            events.append((category, action))

        monkeypatch.setattr("foundry.cli.run_setup", fake_run_setup)
        monkeypatch.setattr("foundry.cli.log_event", fake_log_event)
        
        result = runner.invoke(app, ["setup", "--env", "dev", "--verbose"])
        assert result.exit_code == 0
        assert setup_called["called"] is True
        assert any("setup" in str(e).lower() for e in events)
        assert captured["env"] == "dev"
        assert captured["verbose"] is True


class TestValidateCommand:
    """Test validate command - covers lines 219-220"""

    def test_validate_logs_event_and_calls_run_smoke_tests(self, monkeypatch):
        """Test that 'sscli validate' logs event and calls run_smoke_tests."""
        validate_called = {"called": False}
        events = []

        def fake_run_smoke_tests():
            validate_called["called"] = True

        def fake_log_event(category, action):
            events.append((category, action))

        monkeypatch.setattr("foundry.cli.run_smoke_tests", fake_run_smoke_tests)
        monkeypatch.setattr("foundry.cli.log_event", fake_log_event)
        
        result = runner.invoke(app, ["validate"])
        assert result.exit_code == 0
        assert validate_called["called"] is True
        assert ("COMMAND", "validate") in events


class TestHealthCommand:
    """Test health command - covers lines 226-227"""

    def test_health_logs_event_and_calls_run_health_check(self, monkeypatch):
        """Test that 'sscli health' logs event and calls run_health_check."""
        health_called = {"called": False}
        events = []

        def fake_run_health_check():
            health_called["called"] = True

        def fake_log_event(category, action):
            events.append((category, action))

        monkeypatch.setattr("foundry.cli.run_health_check", fake_run_health_check)
        monkeypatch.setattr("foundry.cli.log_event", fake_log_event)
        
        result = runner.invoke(app, ["health"])
        assert result.exit_code == 0
        assert health_called["called"] is True
        assert ("COMMAND", "health") in events


class TestVerifyCommand:
    """Test verify command - covers lines 243-244"""

    def test_verify_logs_event_and_calls_run_verification(self, monkeypatch):
        """Test that 'sscli verify' logs event and calls run_verification."""
        verify_called = {"called": False}
        events = []
        captured = {}

        def fake_run_verification(**kwargs):
            verify_called["called"] = True
            captured.update(kwargs)

        def fake_log_event(category, action):
            events.append((category, action))

        monkeypatch.setattr("foundry.cli.run_verification", fake_run_verification)
        monkeypatch.setattr("foundry.cli.log_event", fake_log_event)
        
        result = runner.invoke(app, ["verify"])
        assert result.exit_code == 0
        assert verify_called["called"] is True
        assert ("COMMAND", "verify") in events

    def test_verify_with_options(self, monkeypatch):
        """Test verify command with various options."""
        captured = {}

        def fake_run_verification(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr("foundry.cli.run_verification", fake_run_verification)
        monkeypatch.setattr("foundry.cli.log_event", lambda c, a: None)
        
        result = runner.invoke(app, ["verify", "--skip-docker", "--no-reports", "--features"])
        assert result.exit_code == 0
        assert captured["include_docker"] is False
        assert captured["output_reports"] is False
        assert captured["include_features"] is True


class TestUpgradeCommand:
    """Test upgrade command - covers lines 269-279"""

    def test_upgrade_logs_event_and_calls_run_upgrade_success(self, monkeypatch):
        """Test that 'sscli upgrade' logs event and calls run_upgrade successfully."""
        upgrade_called = {"called": False}
        events = []
        captured = {}

        def fake_run_upgrade(**kwargs):
            upgrade_called["called"] = True
            captured.update(kwargs)
            return True  # Success

        def fake_log_event(category, action):
            events.append((category, action))

        monkeypatch.setattr("foundry.cli.run_upgrade", fake_run_upgrade)
        monkeypatch.setattr("foundry.cli.log_event", fake_log_event)
        
        result = runner.invoke(app, ["upgrade"])
        assert result.exit_code == 0
        assert upgrade_called["called"] is True
        assert any("upgrade" in str(e).lower() for e in events)

    def test_upgrade_exits_on_failure(self, monkeypatch):
        """Test upgrade command exits with code 1 on failure."""
        def fake_run_upgrade(**kwargs):
            return False  # Failure

        monkeypatch.setattr("foundry.cli.run_upgrade", fake_run_upgrade)
        monkeypatch.setattr("foundry.cli.log_event", lambda c, a: None)
        
        result = runner.invoke(app, ["upgrade"])
        assert result.exit_code == 1

    def test_upgrade_with_all_options(self, monkeypatch):
        """Test upgrade command with all options enabled."""
        captured = {}

        def fake_run_upgrade(**kwargs):
            captured.update(kwargs)
            return True

        monkeypatch.setattr("foundry.cli.run_upgrade", fake_run_upgrade)
        monkeypatch.setattr("foundry.cli.log_event", lambda c, a: None)
        
        result = runner.invoke(app, [
            "upgrade",
            "/some/path",
            "--to-version", "2.0.0",
            "--dry-run",
            "--force",
            "--interactive",
            "--skip-verification"
        ])
        assert result.exit_code == 0
        assert captured["project_path"] == "/some/path"
        assert captured["to_version"] == "2.0.0"
        assert captured["dry_run"] is True
        assert captured["force"] is True
        assert captured["interactive"] is True
        assert captured["skip_verification"] is True


class TestNewCommandEdgeCases:
    """Additional edge cases for new command to ensure complete coverage."""

    def test_new_merchant_dashboard_without_commerce_prints_error(self, monkeypatch):
        """Test that merchant-dashboard without --with-commerce prints a validation error."""
        monkeypatch.setattr("foundry.cli.log_event", lambda c, a: None)
        
        result = runner.invoke(app, [
            "new",
            "--template", "react-client",
            "--name", "myapp",
            "--with-merchant-dashboard"
        ])
        assert result.exit_code == 1
        assert "--with-commerce" in result.stdout.lower()

    def test_new_with_content_and_theme_options(self, monkeypatch):
        """Test new command with content and theme options."""
        captured = {}

        def fake_run_generator(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr("foundry.cli.run_generator", fake_run_generator)
        
        result = runner.invoke(app, [
            "new",
            "--template", "static-landing",
            "--name", "mysite",
            "--content", "/path/to/blueprint.json",
            "--theme", "midnight",
            "--stats"
        ])
        assert result.exit_code == 0
        assert captured["content_path"] == "/path/to/blueprint.json"
        assert captured["theme"] == "midnight"
        assert captured["stats_only"] is True

    def test_new_with_output_option(self, monkeypatch):
        """Test new command with output file option."""
        captured = {}

        def fake_run_generator(**kwargs):
            captured.update(kwargs)

        monkeypatch.setattr("foundry.cli.run_generator", fake_run_generator)
        
        result = runner.invoke(app, [
            "new",
            "--template", "python-saas",
            "--name", "api",
            "--output", "/tmp/output.json"
        ])
        assert result.exit_code == 0
        assert captured["output_file"] == "/tmp/output.json"


class TestAppSubcommandStructure:
    """Test that subcommands are properly registered."""

    def test_auth_subcommand_exists(self):
        """Test that auth subcommand is registered."""
        result = runner.invoke(app, ["auth", "--help"])
        assert result.exit_code == 0
        assert "auth" in result.stdout.lower()

    def test_interactive_subcommand_exists(self):
        """Test that interactive subcommand is registered."""
        result = runner.invoke(app, ["interactive", "--help"])
        assert result.exit_code == 0

    def test_obs_subcommand_exists(self):
        """Test that obs subcommand is registered."""
        result = runner.invoke(app, ["obs", "--help"])
        assert result.exit_code == 0

    def test_hidden_flags_not_exposed_in_new_help(self):
        """Ensure hidden roadmap flags are not discoverable in CLI help."""
        result = runner.invoke(app, ["new", "--help"])
        assert result.exit_code == 0
        assert "--with-sso" not in result.stdout
        assert "--with-multi-tenant" not in result.stdout
        assert "--with-audit-logs" not in result.stdout
