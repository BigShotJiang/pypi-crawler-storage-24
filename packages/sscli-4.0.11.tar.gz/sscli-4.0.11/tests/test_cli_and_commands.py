import json
from pathlib import Path
from types import SimpleNamespace

import pytest
import typer
from typer.testing import CliRunner

from foundry.cli import app
from foundry import cli as cli_module
from foundry.constants import DISABLED_FEATURES_POLICY
from foundry.commands.auth import auth_login, run_whoami
from foundry.commands.dev import build, swap, mount, dev_callback
from foundry.commands.interactive import interactive_default, interactive_animated
from foundry.commands.observability import diff_command, workspace_create_command, workspace_list_command


runner = CliRunner()


def test_coming_soon_messages_synced_with_disabled_policy():
    expected = {
        cfg["flag"]: cfg["message"] for cfg in DISABLED_FEATURES_POLICY.values()
    }
    assert cli_module.COMING_SOON_FLAG_MESSAGES == expected


def test_new_requires_commerce_for_merchant_dashboard(monkeypatch):
    monkeypatch.setattr("foundry.cli.run_generator", lambda **kwargs: None)
    result = runner.invoke(
        app,
        [
            "new",
            "--template",
            "react-client",
            "--name",
            "app",
            "--with-merchant-dashboard",
        ],
    )
    assert result.exit_code != 0


def test_new_passes_flags_to_generator(monkeypatch):
    captured = {}

    def fake_run_generator(**kwargs):
        captured.update(kwargs)

    monkeypatch.setattr("foundry.cli.run_generator", fake_run_generator)

    result = runner.invoke(
        app,
        [
            "new",
            "--template",
            "python-saas",
            "--name",
            "api",
            "--with-commerce",
            "--with-sqlite",
            "--use-ast-injection",
            "--dry-run",
            "--json",
        ],
    )
    assert result.exit_code == 0
    assert captured["template_name"] == "python-saas"
    assert captured["app_name"] == "api"
    assert captured["with_commerce"] is True
    assert captured["with_sqlite"] is True
    assert captured["use_ast_injection"] is True
    assert captured["dry_run"] is True
    assert captured["json_output"] is True


def test_inject_autodetects_template_and_maps_features(tmp_path, monkeypatch):
    (tmp_path / "pyproject.toml").write_text("[project]\nname='demo'\n")
    captured = {}

    def fake_inject_features(**kwargs):
        captured.update(kwargs)

    monkeypatch.setattr("foundry.actions.features.inject_features", fake_inject_features)

    result = runner.invoke(
        app,
        [
            "inject",
            "--path",
            str(tmp_path),
            "--features",
            "commerce",
            "--features",
            "sqlite",
            "--use-ast-injection",
        ],
    )
    assert result.exit_code == 0
    assert captured["template"] == "python-saas"
    assert captured["commerce"] is True
    assert captured["sqlite"] is True
    assert captured["use_ast_injection"] is True


@pytest.mark.parametrize(
    "flag",
    [
        "--with-auth",
        "--with-admin",
        "--with-tunnel",
        "--with-ingestor",
    ],
)
def test_new_live_feature_flags_succeed(monkeypatch, flag):
    """All 5 features are live (DISABLED_FEATURES_POLICY={}). Auth/admin/tunnel/ingestor
    should be accepted and proceed to the generator."""
    called = {"generator": False}

    def fake_run_generator(**kwargs):
        called["generator"] = True

    monkeypatch.setattr("foundry.cli.run_generator", fake_run_generator)

    result = runner.invoke(
        app,
        [
            "new",
            "--template",
            "python-saas",
            "--name",
            "api",
            flag,
        ],
    )
    assert result.exit_code == 0
    assert called["generator"] is True


@pytest.mark.parametrize(
    "feature",
    ["auth", "admin", "tunnel", "ingestor", "merchant-dashboard"],
)
def test_inject_live_features_proceed(tmp_path, monkeypatch, feature):
    """All features are live. Inject should call inject_features and exit 0."""
    (tmp_path / "pyproject.toml").write_text("[project]\nname='demo'\n")
    called = {"inject": False}

    def fake_inject_features(**kwargs):
        called["inject"] = True

    monkeypatch.setattr("foundry.actions.features.inject_features", fake_inject_features)

    result = runner.invoke(
        app,
        ["inject", "--path", str(tmp_path), "--features", feature],
    )
    assert result.exit_code == 0
    assert called["inject"] is True


def test_inject_multiple_live_features_proceed(tmp_path, monkeypatch):
    """commerce + auth are both live; inject should proceed and exit 0."""
    (tmp_path / "pyproject.toml").write_text("[project]\nname='demo'\n")
    called = {"inject": False}

    def fake_inject_features(**kwargs):
        called["inject"] = True

    monkeypatch.setattr("foundry.actions.features.inject_features", fake_inject_features)

    result = runner.invoke(
        app,
        [
            "inject",
            "--path",
            str(tmp_path),
            "--features",
            "commerce",
            "--features",
            "auth",
        ],
    )
    assert result.exit_code == 0
    assert called["inject"] is True


def test_inject_invalid_path(monkeypatch):
    result = runner.invoke(app, ["inject", "--path", "./does-not-exist"])
    assert result.exit_code != 0


def test_auth_login_success(monkeypatch):
    monkeypatch.setattr("foundry.commands.auth.login_flow", lambda: True)
    monkeypatch.setattr(
        "foundry.commands.auth.get_current_license_info",
        lambda verify=False: {"tier": "pro"},
    )
    printed = []
    monkeypatch.setattr("foundry.commands.auth.console.print", lambda msg: printed.append(msg))
    auth_login()
    assert any("PRO" in str(msg) for msg in printed)


def test_auth_login_failure(monkeypatch):
    monkeypatch.setattr("foundry.commands.auth.login_flow", lambda: False)
    printed = []
    monkeypatch.setattr("foundry.commands.auth.console.print", lambda msg: printed.append(msg))
    auth_login()
    assert any("completed" in str(msg).lower() for msg in printed)


def test_auth_login_with_token(monkeypatch):
    saved = {"called": False}

    def fake_save_credentials(_payload):
        saved["called"] = True

    monkeypatch.setattr("foundry.commands.auth.save_credentials", fake_save_credentials)
    monkeypatch.setattr(
        "foundry.commands.auth.get_current_license_info",
        lambda verify=False: {"authorized": True, "tier": "alpha"} if verify else {"authorized": False},
    )
    printed = []
    monkeypatch.setattr("foundry.commands.auth.console.print", lambda msg: printed.append(msg))

    auth_login(token="ghu_example")

    assert saved["called"] is True
    assert any("ALPHA" in str(msg) for msg in printed)


def test_run_whoami_not_logged_in(monkeypatch):
    monkeypatch.setattr(
        "foundry.commands.auth.get_current_license_info",
        lambda verify=True: {"authorized": False},
    )
    printed = []
    monkeypatch.setattr("foundry.commands.auth.console.print", lambda msg: printed.append(msg))
    run_whoami()
    assert any("Not logged in" in str(msg) for msg in printed)


def test_run_whoami_logged_in(monkeypatch):
    monkeypatch.setattr(
        "foundry.commands.auth.get_current_license_info",
        lambda verify=True: {
            "authorized": True,
            "tier": "alpha",
            "user_id": "u1",
            "status": "active",
        },
    )
    printed = []
    monkeypatch.setattr("rich.console.Console.print", lambda self, *args, **kwargs: printed.append(args))
    run_whoami()
    assert printed


def test_dev_callback_invokes_menu(monkeypatch):
    called = {"menu": False}
    monkeypatch.setattr("foundry.commands.dev.dev_tools_menu", lambda: called.__setitem__("menu", True))
    dev_callback(SimpleNamespace(invoked_subcommand=None))
    assert called["menu"] is True


def test_dev_build_failure_raises(monkeypatch):
    monkeypatch.setattr("foundry.commands.dev.run_build", lambda clean=False: False)
    with pytest.raises(typer.Exit):
        build(clean=True)


def test_dev_swap_failure_raises(monkeypatch):
    monkeypatch.setattr("foundry.commands.dev.run_swap", lambda target=None: False)
    with pytest.raises(typer.Exit):
        swap(target="local")


def test_dev_mount_failure_raises(monkeypatch):
    monkeypatch.setattr("foundry.commands.dev.mount_feature", lambda feature, template, target_dir: False)
    with pytest.raises(typer.Exit):
        mount(feature="commerce", template="react-client", target_dir=".")


def test_interactive_default_calls_menu(monkeypatch):
    called = {"menu": False}
    monkeypatch.setattr("foundry.interactive.interactive_menu", lambda: called.__setitem__("menu", True))
    interactive_default(SimpleNamespace(invoked_subcommand=None))
    assert called["menu"] is True


def test_interactive_animated_calls_runner(monkeypatch):
    called = {"run": False}
    monkeypatch.setattr("foundry.interactive.run_animated_experience", lambda: called.__setitem__("run", True))
    interactive_animated()
    assert called["run"] is True


def test_obs_diff_json_output(tmp_path, monkeypatch):
    def fake_compute_diff(**kwargs):
        return {"success": True, "formatted_output": "OK", "metadata": {"features_injected": []}}

    monkeypatch.setattr("foundry.commands.observability._require_auth", lambda: None)
    monkeypatch.setattr("foundry.commands.observability.compute_diff", fake_compute_diff)
    output_file = tmp_path / "diff.json"
    diff_command(
        project_path=str(tmp_path),
        output_format="json",
        output_file=str(output_file),
    )
    assert output_file.exists()
    content = json.loads(output_file.read_text())
    assert content["success"] is True


def test_obs_diff_error_raises(monkeypatch):
    monkeypatch.setattr("foundry.commands.observability._require_auth", lambda: None)
    monkeypatch.setattr(
        "foundry.commands.observability.compute_diff",
        lambda **kwargs: {"success": False, "error": "boom"},
    )
    with pytest.raises(typer.Exit):
        diff_command(project_path=".")


def test_obs_workspace_create_error_raises(monkeypatch):
    monkeypatch.setattr("foundry.commands.observability._require_auth", lambda: None)
    monkeypatch.setattr(
        "foundry.commands.observability.create_feature_workspace",
        lambda **kwargs: {"success": False, "error": "bad"},
    )
    with pytest.raises(typer.Exit):
        workspace_create_command(feature="commerce", template="react-client", output="/tmp/x")


def test_obs_workspace_list_empty(monkeypatch):
    printed = []
    monkeypatch.setattr("foundry.commands.observability._require_auth", lambda: None)
    monkeypatch.setattr("foundry.commands.observability.console.print", lambda msg: printed.append(msg))
    monkeypatch.setattr(
        "foundry.commands.observability.list_workspaces",
        lambda search_path=None: {"success": True, "workspaces": []},
    )
    workspace_list_command(search_path=".", json_output=False)
    assert any("No workspaces found" in str(msg) for msg in printed)
