"""
Comprehensive tests for foundry.interactive_utils module.

Tests:
- Config management menu navigation
- Health check invocation
- Template setup invocation  
- Menu flow and user interaction
- Pause functionality
"""

import pytest
from unittest.mock import patch, MagicMock, call
from foundry import interactive_utils


class TestManageConfigMenu:
    """Test the manage_config_menu function."""
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_health_check")
    @patch("builtins.input")
    def test_view_validation_status(self, mock_input, mock_health_check, mock_questionary):
        """Test selecting 'View Validation Status' option."""
        # First iteration: select validation, second: select back
        mock_select = MagicMock()
        mock_select.ask.side_effect = ["validate", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        mock_input.return_value = ""  # User presses Enter after health check
        
        interactive_utils.manage_config_menu()
        
        # Should call health check once
        mock_health_check.assert_called_once()
        # Should call input for pause
        mock_input.assert_called_once()
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_setup")
    @patch("builtins.input")
    def test_run_template_setup(self, mock_input, mock_setup, mock_questionary):
        """Test selecting 'Run Template Setup' option."""
        # First iteration: select setup, second: select back
        mock_select = MagicMock()
        mock_select.ask.side_effect = ["setup", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        mock_input.return_value = ""
        
        interactive_utils.manage_config_menu()
        
        # Should call setup once
        mock_setup.assert_called_once()
        # Should call input for pause
        mock_input.assert_called_once()
    
    @patch("foundry.interactive_utils.questionary")
    def test_back_option_exits_immediately(self, mock_questionary):
        """Test that selecting 'Back' exits the menu."""
        mock_select = MagicMock()
        mock_select.ask.return_value = "Back"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        # Should exit without calling any actions
        with patch("foundry.interactive_utils.run_health_check") as mock_health, \
             patch("foundry.interactive_utils.run_setup") as mock_setup:
            interactive_utils.manage_config_menu()
            
            mock_health.assert_not_called()
            mock_setup.assert_not_called()
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_health_check")
    @patch("builtins.input")
    def test_multiple_menu_interactions(self, mock_input, mock_health_check, mock_questionary):
        """Test multiple menu selections before exiting."""
        # Simulate: validate -> setup -> back
        mock_select = MagicMock()
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        choices = ["validate", "setup", "validate", "Back"]
        mock_select.ask.side_effect = choices
        
        mock_input.return_value = ""
        
        with patch("foundry.interactive_utils.run_setup") as mock_setup:
            interactive_utils.manage_config_menu()
            
            # Should call health check twice (first and third selection)
            assert mock_health_check.call_count == 2
            # Should call setup once (second selection)
            mock_setup.assert_called_once()
            # Should pause 3 times (after each action)
            assert mock_input.call_count == 3
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_health_check")
    def test_health_check_exception_handling(self, mock_health_check, mock_questionary):
        """Test that exceptions in health check don't crash the menu."""
        mock_select = MagicMock()
        mock_select.ask.side_effect = ["validate", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        # Health check raises exception
        mock_health_check.side_effect = Exception("Health check failed")
        
        with patch("builtins.input", return_value=""):
            # Should not crash
            try:
                interactive_utils.manage_config_menu()
            except Exception as e:
                # Exception should propagate for testing
                assert "Health check failed" in str(e)
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_setup")
    def test_setup_exception_handling(self, mock_setup, mock_questionary):
        """Test that exceptions in setup don't crash the menu."""
        mock_select = MagicMock()
        mock_select.ask.side_effect = ["setup", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        # Setup raises exception
        mock_setup.side_effect = Exception("Setup failed")
        
        with patch("builtins.input", return_value=""):
            # Should not crash
            try:
                interactive_utils.manage_config_menu()
            except Exception as e:
                assert "Setup failed" in str(e)


class TestPauseFunction:
    """Test the pause helper function."""
    
    @patch("builtins.input")
    def test_pause_waits_for_enter(self, mock_input):
        """Test that pause waits for user input."""
        mock_input.return_value = ""
        
        interactive_utils.pause()
        
        mock_input.assert_called_once()
        # Check that the prompt message is correct
        call_args = mock_input.call_args[0][0]
        assert "Press Enter" in call_args or "return" in call_args.lower()
    
    @patch("builtins.input")
    def test_pause_handles_user_input(self, mock_input):
        """Test that pause works with any user input."""
        # User types something before pressing Enter
        mock_input.return_value = "some random text"
        
        # Should not raise exception
        interactive_utils.pause()
        mock_input.assert_called_once()
    
    @patch("builtins.input")
    def test_pause_keyboard_interrupt(self, mock_input):
        """Test that pause handles KeyboardInterrupt gracefully."""
        mock_input.side_effect = KeyboardInterrupt()
        
        # Should propagate KeyboardInterrupt
        with pytest.raises(KeyboardInterrupt):
            interactive_utils.pause()


class TestMenuChoiceMapping:
    """Test the choice value mapping in menu."""
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_health_check")
    @patch("builtins.input")
    def test_validate_choice_mapping(self, mock_input, mock_health_check, mock_questionary):
        """Test that 'validate' value maps to health check action."""
        mock_select = MagicMock()
        mock_select.ask.side_effect = ["validate", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        mock_input.return_value = ""
        
        interactive_utils.manage_config_menu()
        
        # Verify correct action was called
        mock_health_check.assert_called_once()
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_setup")
    @patch("builtins.input")
    def test_setup_choice_mapping(self, mock_input, mock_setup, mock_questionary):
        """Test that 'setup' value maps to setup action."""
        mock_select = MagicMock()
        mock_select.ask.side_effect = ["setup", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        mock_input.return_value = ""
        
        interactive_utils.manage_config_menu()
        
        # Verify correct action was called
        mock_setup.assert_called_once()


class TestQuestionaryStyleIntegration:
    """Test questionary styling configuration."""
    
    @patch("foundry.interactive_utils.questionary")
    def test_questionary_style_constant_used(self, mock_questionary):
        """Test that QUESTIONARY_STYLE constant is used."""
        mock_select = MagicMock()
        mock_select.ask.return_value = "Back"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        interactive_utils.manage_config_menu()
        
        # Verify Style was called with QUESTIONARY_STYLE
        mock_questionary.Style.assert_called_once()
        style_arg = mock_questionary.Style.call_args[0][0]
        # QUESTIONARY_STYLE should be a list or dict
        assert style_arg is not None


class TestMenuLoopBehavior:
    """Test the infinite loop behavior of the menu."""
    
    @patch("foundry.interactive_utils.questionary")
    def test_menu_loops_until_back(self, mock_questionary):
        """Test that menu continues looping until 'Back' is selected."""
        mock_select = MagicMock()
        # Simulate multiple selections before back
        mock_select.ask.side_effect = ["validate", "setup", "validate", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        with patch("foundry.interactive_utils.run_health_check"), \
             patch("foundry.interactive_utils.run_setup"), \
             patch("builtins.input", return_value=""):
            
            interactive_utils.manage_config_menu()
            
            # Should have called select 4 times
            assert mock_select.ask.call_count == 4
    
    @patch("foundry.interactive_utils.questionary")
    def test_menu_immediate_exit(self, mock_questionary):
        """Test that menu can exit immediately."""
        mock_select = MagicMock()
        mock_select.ask.return_value = "Back"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        interactive_utils.manage_config_menu()
        
        # Should only call select once
        mock_select.ask.assert_called_once()


class TestInternalDevGuard:
    """Test is_internal_dev usage in menu."""
    
    @patch("foundry.interactive_utils.questionary")
    def test_internal_dev_import(self, mock_questionary):
        """Test that manage_config_menu works without exceptions."""
        mock_select = MagicMock()
        mock_select.ask.return_value = "Back"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        # The function should work cleanly
        interactive_utils.manage_config_menu()
        
        # Just verify the menu executes without exception
        assert True


class TestEdgeCases:
    """Test edge cases and error scenarios."""
    
    @patch("foundry.interactive_utils.questionary")
    def test_none_selection_handling(self, mock_questionary):
        """Test handling when user cancels (returns None)."""
        mock_select = MagicMock()
        # Questionary returns None when user cancels (Ctrl+C handled)
        mock_select.ask.return_value = None
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        # None is treated as "Back" — menu exits cleanly
        interactive_utils.manage_config_menu()
        mock_select.ask.assert_called_once()
    
    @patch("foundry.interactive_utils.questionary")
    @patch("builtins.input")
    def test_input_eof_error(self, mock_input, mock_questionary):
        """Test handling of EOF in pause (e.g., piped input)."""
        mock_select = MagicMock()
        mock_select.ask.side_effect = ["validate", "Back"]
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        # Simulate EOF error
        mock_input.side_effect = EOFError()
        
        with patch("foundry.interactive_utils.run_health_check"):
            # Should propagate or handle EOF
            with pytest.raises(EOFError):
                interactive_utils.manage_config_menu()
    
    @patch("foundry.interactive_utils.questionary")
    @patch("foundry.interactive_utils.run_health_check")
    @patch("builtins.input")
    def test_rapid_menu_cycling(self, mock_input, mock_health_check, mock_questionary):
        """Test rapid menu selection cycling."""
        mock_select = MagicMock()
        # Cycle through options rapidly
        selections = ["validate", "setup", "validate", "setup", "validate", "Back"]
        mock_select.ask.side_effect = selections
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        mock_questionary.Choice = lambda display, value: {"display": display, "value": value}
        
        mock_input.return_value = ""
        
        with patch("foundry.interactive_utils.run_setup") as mock_setup:
            interactive_utils.manage_config_menu()
            
            # Should handle all selections correctly
            assert mock_health_check.call_count == 3
            assert mock_setup.call_count == 2
            assert mock_input.call_count == 5


class TestImportDependencies:
    """Test module imports and dependencies."""
    
    def test_questionary_imported(self):
        """Test that questionary is imported."""
        assert hasattr(interactive_utils, 'questionary')
    
    def test_choice_imported(self):
        """Test that Choice is imported from questionary."""
        from questionary import Choice
        assert Choice is not None
    
    def test_constants_imported(self):
        """Test that required action functions are imported."""
        assert hasattr(interactive_utils, 'run_health_check')
        assert hasattr(interactive_utils, 'run_setup')
    
    def test_actions_imported(self):
        """Test that action functions are imported and accessible."""
        assert callable(interactive_utils.run_health_check)
        assert callable(interactive_utils.run_setup)
