from pathlib import Path

from foundry.actions.internals import (
    build_internals_report,
    generate_internals_report,
    parse_session_log,
)


def test_parse_session_log_extracts_events(tmp_path: Path):
    log_path = tmp_path / ".session.log"
    log_path.write_text(
        "\n".join(
            [
                "[2026-03-01 11:44:47] GENERATE_START: Template: static-landing, App: seedsource-marketing-rebuild",
                "[2026-03-01 11:44:59] GENERATE_ERROR: Compressed file ended before the end-of-stream marker was reached",
                "[2026-03-01 11:48:41] GENERATE_SUCCESS: Template: static-landing, Target: /tmp/seedsource-marketing-rebuild",
            ]
        ),
        encoding="utf-8",
    )

    events = parse_session_log(log_path)

    assert len(events) == 3
    assert events[0]["event"] == "GENERATE_START"
    assert events[0]["template"] == "static-landing"
    assert events[0]["app"] == "seedsource-marketing-rebuild"
    assert events[1]["is_failure"] is True
    assert events[2]["event"] == "GENERATE_SUCCESS"


def test_build_internals_report_summarizes_failures(tmp_path: Path):
    events = [
        {
            "timestamp": "2026-03-01 11:44:47",
            "event": "GENERATE_START",
            "details": "Template: static-landing, App: seedsource-marketing-rebuild",
            "template": "static-landing",
            "app": "seedsource-marketing-rebuild",
            "is_failure": False,
        },
        {
            "timestamp": "2026-03-01 11:44:59",
            "event": "GENERATE_ERROR",
            "details": "Compressed file ended before the end-of-stream marker was reached",
            "template": None,
            "app": None,
            "is_failure": True,
        },
    ]

    report = build_internals_report(events, tmp_path / ".session.log")

    assert report["summary"]["total_events"] == 2
    assert report["summary"]["failure_events"] == 1
    assert report["summary"]["generate_start"] == 1
    assert report["summary"]["generate_errors"] == 1
    assert len(report["failures"]) == 1


def test_generate_internals_report_writes_json_and_markdown(tmp_path: Path):
    log_path = tmp_path / ".session.log"
    log_path.write_text(
        "[2026-03-01 11:44:59] GENERATE_ERROR: test failure\n",
        encoding="utf-8",
    )
    output_dir = tmp_path / "reports"

    result = generate_internals_report(log_path, output_dir)

    assert result["json_path"].exists()
    assert result["markdown_path"].exists()
    markdown = result["markdown_path"].read_text(encoding="utf-8")
    assert "Internal-projects Failure Report" in markdown
    assert "Failure events: 1" in markdown


def test_generate_internals_report_escapes_bracket_payloads(tmp_path: Path):
    log_path = tmp_path / ".session.log"
    log_path.write_text(
        "[2026-03-01 11:44:59] GENERATE_ERROR: [link](javascript:alert(1))\n",
        encoding="utf-8",
    )
    output_dir = tmp_path / "reports"

    result = generate_internals_report(log_path, output_dir)

    markdown = result["markdown_path"].read_text(encoding="utf-8")
    assert " - [link](javascript:alert(1))" not in markdown
    assert "\\[link](javascript:alert(1))" in markdown
