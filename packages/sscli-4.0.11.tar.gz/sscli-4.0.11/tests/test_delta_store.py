"""
Test suite for Delta Store: Versioned Codemod Catalog Manager

Tests catalog loading, codemod retrieval, version matching, dependency
resolution, and upgrade path validation.
"""

import pytest
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import yaml

from foundry.codemods.delta_store import (
    CodemodMetadata,
    CodemodDefinition,
    DeltaStore
)


class TestCodemodMetadata:
    """Test CodemodMetadata dataclass."""
    
    def test_metadata_creation(self):
        """Test creating metadata object."""
        metadata = CodemodMetadata(
            id="010-001-PY-test",
            name="Test Codemod",
            description="Test description",
            from_version="2.0.0",
            to_version="2.1.0",
            affected_templates=["python-saas"],
            risk_level="low"
        )
        
        assert metadata.id == "010-001-PY-test"
        assert metadata.name == "Test Codemod"
        assert metadata.risk_level == "low"
        assert metadata.requires_manual_review is False
        assert metadata.rollback_safe is True
    
    def test_metadata_to_dict(self):
        """Test converting metadata to dictionary."""
        metadata = CodemodMetadata(
            id="010-001-PY-test",
            name="Test Codemod",
            description="Test description",
            from_version="2.0.0",
            to_version="2.1.0",
            affected_templates=["python-saas"],
            risk_level="low",
            tags=["test"]
        )
        
        data = metadata.to_dict()
        assert isinstance(data, dict)
        assert data["id"] == "010-001-PY-test"
        assert data["tags"] == ["test"]
    
    def test_metadata_from_dict(self):
        """Test creating metadata from dictionary."""
        data = {
            "id": "010-001-PY-test",
            "name": "Test Codemod",
            "description": "Test description",
            "from_version": "2.0.0",
            "to_version": "2.1.0",
            "affected_templates": ["python-saas"],
            "risk_level": "low"
        }
        
        metadata = CodemodMetadata.from_dict(data)
        assert metadata.id == "010-001-PY-test"
        assert metadata.name == "Test Codemod"


class TestDeltaStoreLoading:
    """Test Delta Store catalog loading."""
    
    def test_load_catalog_from_real_path(self):
        """Test loading catalog from actual directory."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            catalog = store.load_catalog()
            
            # Should load at least the sample codemods
            assert len(catalog) > 0
            assert isinstance(catalog, dict)
            
            # Check that loaded items are CodemodDefinition objects
            for codemod_id, codemod_def in catalog.items():
                assert isinstance(codemod_def, CodemodDefinition)
                assert isinstance(codemod_def.metadata, CodemodMetadata)
    
    def test_load_missing_catalog(self):
        """Test loading from non-existent catalog."""
        store = DeltaStore(Path("/nonexistent/catalog"))
        
        with pytest.raises(FileNotFoundError):
            store.load_catalog()
    
    def test_load_catalog_caching(self):
        """Test that catalog is cached after first load."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            # Load twice
            catalog1 = store.load_catalog()
            catalog2 = store.load_catalog()
            
            # Should return the same cached object
            assert catalog1 is catalog2


class TestCodemodRetrieval:
    """Test retrieving specific codemods."""
    
    def test_get_specific_codemod(self):
        """Test retrieving a specific codemod by ID."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            # Get a codemod if any exist
            all_codemods = store.list_available_codemods()
            if all_codemods:
                codemod_id = all_codemods[0].id
                codemod = store.get_codemod(codemod_id)
                
                assert codemod is not None
                assert codemod.metadata.id == codemod_id
    
    def test_get_nonexistent_codemod(self):
        """Test retrieving a non-existent codemod."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemod = store.get_codemod("nonexistent-id")
            
            assert codemod is None
    
    def test_list_available_codemods(self):
        """Test listing all available codemods."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods()
            
            assert isinstance(codemods, list)
            for metadata in codemods:
                assert isinstance(metadata, CodemodMetadata)
    
    def test_list_codemods_by_template(self):
        """Test filtering codemods by template."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods(template="python-saas")
            
            for metadata in codemods:
                assert "python-saas" in metadata.affected_templates
    
    def test_list_codemods_by_risk_level(self):
        """Test filtering codemods by risk level."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods(risk_level="low")
            
            for metadata in codemods:
                assert metadata.risk_level == "low"


class TestVersionMatching:
    """Test version range matching logic."""
    
    def test_get_codemods_for_upgrade(self):
        """Test retrieving codemods for a version upgrade."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            # Try to get codemods for python-saas upgrade
            codemods = store.get_codemods_for_template(
                "python-saas", "2.2.0", "2.3.0"
            )
            
            assert isinstance(codemods, list)
            for codemod in codemods:
                assert isinstance(codemod, CodemodDefinition)
    
    def test_invalid_version_format(self):
        """Test that invalid version format raises error."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "python-saas", "invalid", "2.3.0"
                )
    
    def test_to_version_less_than_from_version(self):
        """Test that to_version < from_version raises error."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "python-saas", "2.3.0", "2.2.0"
                )
    
    def test_same_versions_rejected(self):
        """Test that same from and to versions are rejected."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "python-saas", "2.3.0", "2.3.0"
                )


class TestDependencyResolution:
    """Test codemod dependency resolution."""
    
    def test_dependency_ordering(self):
        """Test that codemods are ordered correctly for dependencies."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.get_codemods_for_template(
                "python-saas", "2.2.0", "2.3.0"
            )
            
            # Build a set of seen IDs to verify ordering
            seen_ids = set()
            for codemod in codemods:
                # All dependencies should have been seen already
                for dep_id in codemod.metadata.dependencies:
                    assert dep_id in seen_ids
                seen_ids.add(codemod.metadata.id)
    
    def test_circular_dependency_detection(self):
        """Test that circular dependencies are detected."""
        with TemporaryDirectory() as tmpdir:
            catalog_root = Path(tmpdir)
            template_root = catalog_root / "test-template" / "1.0.0-2.0.0"
            template_root.mkdir(parents=True)
            
            # Create codemods with circular dependency
            codemod1 = {
                "metadata": {
                    "id": "001",
                    "name": "CM 1",
                    "description": "Test",
                    "from_version": "1.0.0",
                    "to_version": "2.0.0",
                    "affected_templates": ["test-template"],
                    "risk_level": "low",
                    "dependencies": ["002"]
                },
                "implementation": {}
            }
            
            codemod2 = {
                "metadata": {
                    "id": "002",
                    "name": "CM 2",
                    "description": "Test",
                    "from_version": "1.0.0",
                    "to_version": "2.0.0",
                    "affected_templates": ["test-template"],
                    "risk_level": "low",
                    "dependencies": ["001"]
                },
                "implementation": {}
            }
            
            with open(template_root / "001.yaml", "w") as f:
                yaml.dump(codemod1, f)
            
            with open(template_root / "002.yaml", "w") as f:
                yaml.dump(codemod2, f)
            
            store = DeltaStore(catalog_root)
            store.load_catalog()
            
            # Should raise error on circular dependency
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "test-template", "1.0.0", "2.0.0"
                )


class TestUpgradePathValidation:
    """Test upgrade path validation."""
    
    def test_valid_upgrade_path(self):
        """Test validating a valid upgrade path."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "python-saas", "2.2.0", "2.3.0"
            )
            
            assert isinstance(result, dict)
            assert "valid" in result
            assert "codemods" in result
            assert "warnings" in result
            assert "errors" in result
            assert "requires_review" in result
            assert "risk_level" in result
    
    def test_invalid_version_in_validation(self):
        """Test validation with invalid version."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "python-saas", "invalid", "2.3.0"
            )
            
            assert result["valid"] is False
            assert len(result["errors"]) > 0
    
    def test_validation_risk_tracking(self):
        """Test that validation tracks maximum risk level."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "rails-api", "2.2.0", "2.3.0"
            )
            
            if result["valid"] and result["codemods"]:
                # Check that risk_level is one of the valid options
                assert result["risk_level"] in ["low", "medium", "high", "critical"]
    
    def test_validation_manual_review_flag(self):
        """Test that manual review requirement is tracked."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "rails-api", "2.2.0", "2.3.0"
            )
            
            # Rails API has high-risk codemod that requires review
            if result["valid"] and "010-004-RAILS-upgrade-7-2" in result["codemods"]:
                assert result["requires_review"] is True


class TestManifestHandling:
    """Test handling of manifest.json files."""
    
    def test_get_catalogs_for_template(self):
        """Test retrieving available version ranges for a template."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            catalogs = store.get_catalogs_for_template("python-saas")
            
            assert isinstance(catalogs, list)
            for catalog_range in catalogs:
                assert "-" in catalog_range


class TestCatalogExport:
    """Test exporting the catalog."""
    
    def test_export_catalog(self):
        """Test exporting entire catalog as dictionary."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            export = store.export_catalog()
            
            assert isinstance(export, dict)
            for codemod_id, codemod_data in export.items():
                assert "metadata" in codemod_data
                assert "implementation" in codemod_data


class TestDeltaStoreInMemory:
    """Test DeltaStore behavior with in-memory catalog cache."""

    def _make_codemod(
        self,
        codemod_id,
        from_version,
        to_version,
        templates,
        dependencies=None,
        risk_level="low",
        requires_review=False,
        rollback_safe=True,
    ):
        metadata = CodemodMetadata(
            id=codemod_id,
            name=f"Codemod {codemod_id}",
            description="Test codemod",
            from_version=from_version,
            to_version=to_version,
            affected_templates=templates,
            risk_level=risk_level,
            requires_manual_review=requires_review,
            rollback_safe=rollback_safe,
            dependencies=dependencies or [],
        )
        return CodemodDefinition(metadata=metadata, implementation={})

    def test_get_codemods_for_template_orders_dependencies(self, tmp_path):
        store = DeltaStore(tmp_path)
        store._loaded = True
        codemod_b = self._make_codemod("B", "1.0.0", "2.0.0", ["python-saas"])
        codemod_a = self._make_codemod(
            "A",
            "1.0.0",
            "2.0.0",
            ["python-saas"],
            dependencies=["B"],
        )
        store._catalog_cache = {"A": codemod_a, "B": codemod_b}

        ordered = store.get_codemods_for_template("python-saas", "1.0.0", "2.0.0")

        assert [cm.metadata.id for cm in ordered] == ["B", "A"]

    def test_get_codemods_for_template_invalid_version(self, tmp_path):
        store = DeltaStore(tmp_path)
        store._loaded = True
        store._catalog_cache = {}

        with pytest.raises(ValueError):
            store.get_codemods_for_template("python-saas", "bad", "2.0.0")

    def test_get_codemods_for_template_invalid_range(self, tmp_path):
        store = DeltaStore(tmp_path)
        store._loaded = True
        store._catalog_cache = {}

        with pytest.raises(ValueError):
            store.get_codemods_for_template("python-saas", "2.0.0", "1.0.0")

    def test_validate_upgrade_path_invalid_version(self, tmp_path):
        store = DeltaStore(tmp_path)
        store._loaded = True
        store._catalog_cache = {}

        result = store.validate_upgrade_path("python-saas", "bad", "2.0.0")

        assert result["valid"] is False
        assert result["errors"]

    def test_validate_upgrade_path_no_codemods(self, tmp_path):
        store = DeltaStore(tmp_path)
        store._loaded = True
        store._catalog_cache = {}

        result = store.validate_upgrade_path("python-saas", "1.0.0", "2.0.0")

        assert result["valid"] is True
        assert result["warnings"]

    def test_validate_upgrade_path_risk_and_review(self, tmp_path):
        store = DeltaStore(tmp_path)
        store._loaded = True
        codemod = self._make_codemod(
            "R1",
            "1.0.0",
            "2.0.0",
            ["python-saas"],
            risk_level="high",
            requires_review=True,
            rollback_safe=False,
        )
        store._catalog_cache = {"R1": codemod}

        result = store.validate_upgrade_path("python-saas", "1.0.0", "2.0.0")

        assert result["requires_review"] is True
        assert result["risk_level"] == "high"
        assert result["warnings"]


class TestEmptyCatalog:
    """Test behavior with empty catalog."""
    
    def test_empty_catalog_operations(self):
        """Test operations on empty catalog."""
        with TemporaryDirectory() as tmpdir:
            store = DeltaStore(Path(tmpdir))
            store.load_catalog()
            
            # Should return empty results
            assert len(store.list_available_codemods()) == 0
            assert store.get_codemod("any-id") is None
            
            # Should return empty codemod list for upgrade
            codemods = store.get_codemods_for_template(
                "python-saas", "2.2.0", "2.3.0"
            )
            assert len(codemods) == 0


class TestCodemodDefinitionLoading:
    """Test loading complete codemod definitions."""
    
    def test_codemod_definition_structure(self):
        """Test that loaded codemods have complete structure."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods()
            
            if codemods:
                codemod_id = codemods[0].id
                codemod_def = store.get_codemod(codemod_id)
                
                assert codemod_def is not None
                assert hasattr(codemod_def, "metadata")
                assert hasattr(codemod_def, "implementation")
                assert hasattr(codemod_def, "test_instructions")
                assert hasattr(codemod_def, "rollback_instructions")


class TestDefaultCatalogPath:
    """Test default catalog path initialization."""
    
    def test_default_catalog_path(self):
        """Test that default catalog path is set correctly when None is provided."""
        store = DeltaStore(catalog_root=None)
        
        expected_path = Path(__file__).parent.parent / "foundry" / "codemods" / "catalog"
        assert store.catalog_root == expected_path


class TestFileLoadingErrors:
    """Test error handling during file loading."""
    
    def test_malformed_yaml_file(self, tmp_path):
        """Test handling of malformed YAML file."""
        catalog_root = tmp_path / "catalog"
        catalog_root.mkdir()
        
        # Create a malformed YAML file
        malformed_file = catalog_root / "001-bad.yaml"
        malformed_file.write_text("invalid: yaml: content: [[[")
        
        store = DeltaStore(catalog_root)
        
        with pytest.raises(ValueError, match="Failed to load codemod"):
            store.load_catalog()
    
    def test_missing_required_fields(self, tmp_path):
        """Test handling when required metadata fields are missing."""
        catalog_root = tmp_path / "catalog"
        catalog_root.mkdir()
        
        # Create a YAML file missing required fields
        incomplete_codemod = {
            "metadata": {
                "id": "001",
                "name": "Incomplete"
                # Missing: description, from_version, to_version, etc.
            },
            "implementation": {}
        }
        
        yaml_file = catalog_root / "001-incomplete.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(incomplete_codemod, f)
        
        store = DeltaStore(catalog_root)
        
        with pytest.raises(ValueError, match="Missing required metadata fields"):
            store.load_catalog()
    
    def test_missing_metadata_key(self, tmp_path):
        """Test handling when metadata key is completely missing."""
        catalog_root = tmp_path / "catalog"
        catalog_root.mkdir()
        
        # Create a YAML file without metadata key
        no_metadata = {
            "implementation": {}
        }
        
        yaml_file = catalog_root / "001-no-metadata.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(no_metadata, f)
        
        store = DeltaStore(catalog_root)
        
        with pytest.raises(ValueError, match="Missing required metadata fields"):
            store.load_catalog()


class TestOptionalMetadataDefaults:
    """Test that optional metadata fields get default values."""
    
    def test_optional_fields_set_to_defaults(self, tmp_path):
        """Test that optional metadata fields are set with defaults."""
        catalog_root = tmp_path / "catalog"
        catalog_root.mkdir()
        
        # Create a minimal codemod (only required fields)
        minimal_codemod = {
            "metadata": {
                "id": "001-minimal",
                "name": "Minimal Codemod",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["test"],
                "risk_level": "low"
                # Missing optional fields
            },
            "implementation": {}
        }
        
        yaml_file = catalog_root / "001-minimal.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(minimal_codemod, f)
        
        store = DeltaStore(catalog_root)
        store.load_catalog()
        
        codemod = store.get_codemod("001-minimal")
        assert codemod is not None
        assert codemod.metadata.requires_manual_review is False
        assert codemod.metadata.rollback_safe is True
        assert codemod.metadata.implementation_type == "yaml"
        assert codemod.metadata.file_patterns == []
        assert codemod.metadata.tags == []
        assert codemod.metadata.dependencies == []


class TestVersionRangeFiltering:
    """Test version range filtering for applicable codemods."""
    
    def test_codemod_outside_version_range(self, tmp_path):
        """Test that codemods outside the version range are excluded."""
        catalog_root = tmp_path / "catalog"
        template_dir = catalog_root / "test-template" / "3.0.0-4.0.0"
        template_dir.mkdir(parents=True)
        
        # Create codemod for 3.0.0-4.0.0 (outside 1.0.0-2.0.0)
        future_codemod = {
            "metadata": {
                "id": "future-001",
                "name": "Future Codemod",
                "description": "Test",
                "from_version": "3.0.0",
                "to_version": "4.0.0",
                "affected_templates": ["test"],
                "risk_level": "low"
            },
            "implementation": {}
        }
        
        yaml_file = template_dir / "001-future.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(future_codemod, f)
        
        store = DeltaStore(catalog_root)
        store.load_catalog()
        
        # Query for 1.0.0 to 2.0.0 - should not include future codemod
        codemods = store.get_codemods_for_template("test", "1.0.0", "2.0.0")
        
        assert len(codemods) == 0


class TestListFilteringEdgeCases:
    """Test edge cases in list_available_codemods filtering."""
    
    def test_filter_by_template_excludes_others(self, tmp_path):
        """Test that filtering by template excludes non-matching templates."""
        catalog_root = tmp_path / "catalog"
        template_dir = catalog_root / "test-template" / "1.0.0-2.0.0"
        template_dir.mkdir(parents=True)
        
        # Create codemods for different templates
        python_codemod = {
            "metadata": {
                "id": "py-001",
                "name": "Python Codemod",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["python-saas"],
                "risk_level": "low"
            },
            "implementation": {}
        }
        
        rails_codemod = {
            "metadata": {
                "id": "rb-001",
                "name": "Rails Codemod",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["rails-api"],
                "risk_level": "low"
            },
            "implementation": {}
        }
        
        for name, data in [("001-py.yaml", python_codemod), ("002-rb.yaml", rails_codemod)]:
            with open(template_dir / name, "w") as f:
                yaml.dump(data, f)
        
        store = DeltaStore(catalog_root)
        store.load_catalog()
        
        # Filter by python-saas should exclude rails-api
        codemods = store.list_available_codemods(template="python-saas")
        
        assert len(codemods) == 1
        assert codemods[0].id == "py-001"
    
    def test_filter_by_risk_level_excludes_others(self, tmp_path):
        """Test that filtering by risk level excludes non-matching levels."""
        catalog_root = tmp_path / "catalog"
        template_dir = catalog_root / "test-template" / "1.0.0-2.0.0"
        template_dir.mkdir(parents=True)
        
        # Create codemods with different risk levels
        low_risk = {
            "metadata": {
                "id": "low-001",
                "name": "Low Risk",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["test"],
                "risk_level": "low"
            },
            "implementation": {}
        }
        
        high_risk = {
            "metadata": {
                "id": "high-001",
                "name": "High Risk",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["test"],
                "risk_level": "high"
            },
            "implementation": {}
        }
        
        for name, data in [("001-low.yaml", low_risk), ("002-high.yaml", high_risk)]:
            with open(template_dir / name, "w") as f:
                yaml.dump(data, f)
        
        store = DeltaStore(catalog_root)
        store.load_catalog()
        
        # Filter by low should exclude high
        codemods = store.list_available_codemods(risk_level="low")
        
        assert len(codemods) == 1
        assert codemods[0].id == "low-001"


class TestValidationEdgeCases:
    """Test edge cases in validate_upgrade_path."""
    
    def test_validation_with_non_rollback_safe_codemod(self, tmp_path):
        """Test validation warns about non-rollback-safe codemods."""
        catalog_root = tmp_path / "catalog"
        template_dir = catalog_root / "test-template" / "1.0.0-2.0.0"
        template_dir.mkdir(parents=True)
        
        # Create non-rollback-safe codemod
        risky_codemod = {
            "metadata": {
                "id": "risky-001",
                "name": "Risky Codemod",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["test"],
                "risk_level": "high",
                "rollback_safe": False
            },
            "implementation": {}
        }
        
        yaml_file = template_dir / "001-risky.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(risky_codemod, f)
        
        store = DeltaStore(catalog_root)
        store.load_catalog()
        
        result = store.validate_upgrade_path("test", "1.0.0", "2.0.0")
        
        assert result["valid"] is True
        assert any("not rollback-safe" in warning for warning in result["warnings"])
        assert result["risk_level"] == "high"
    
    def test_validation_tracks_critical_risk_level(self, tmp_path):
        """Test validation tracks critical risk level correctly."""
        catalog_root = tmp_path / "catalog"
        template_dir = catalog_root / "test-template" / "1.0.0-2.0.0"
        template_dir.mkdir(parents=True)
        
        # Create critical risk codemod
        critical_codemod = {
            "metadata": {
                "id": "critical-001",
                "name": "Critical Codemod",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["test"],
                "risk_level": "critical"
            },
            "implementation": {}
        }
        
        yaml_file = template_dir / "001-critical.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(critical_codemod, f)
        
        store = DeltaStore(catalog_root)
        store.load_catalog()
        
        result = store.validate_upgrade_path("test", "1.0.0", "2.0.0")
        
        assert result["risk_level"] == "critical"


class TestGetCatalogsForTemplate:
    """Test get_catalogs_for_template method."""
    
    def test_get_catalogs_nonexistent_root(self, tmp_path):
        """Test get_catalogs when catalog root doesn't exist."""
        nonexistent = tmp_path / "nonexistent"
        store = DeltaStore(nonexistent)
        
        catalogs = store.get_catalogs_for_template("test")
        
        assert catalogs == []
    
    def test_get_catalogs_nonexistent_template(self, tmp_path):
        """Test get_catalogs for a template that doesn't exist."""
        catalog_root = tmp_path / "catalog"
        catalog_root.mkdir()
        
        store = DeltaStore(catalog_root)
        
        catalogs = store.get_catalogs_for_template("nonexistent-template")
        
        assert catalogs == []
    
    def test_get_catalogs_with_version_dirs(self, tmp_path):
        """Test get_catalogs returns version range directories."""
        catalog_root = tmp_path / "catalog"
        template_dir = catalog_root / "test-template"
        template_dir.mkdir(parents=True)
        
        # Create version range directories
        (template_dir / "1.0.0-2.0.0").mkdir()
        (template_dir / "2.0.0-3.0.0").mkdir()
        (template_dir / "invalid_name").mkdir()  # Should be excluded (no dash)
        
        store = DeltaStore(catalog_root)
        
        catalogs = store.get_catalogs_for_template("test-template")
        
        assert len(catalogs) == 2
        assert "1.0.0-2.0.0" in catalogs
        assert "2.0.0-3.0.0" in catalogs
        assert "invalid_name" not in catalogs


class TestExportCatalog:
    """Test export_catalog method."""
    
    def test_export_catalog_structure(self, tmp_path):
        """Test that export_catalog returns correct structure."""
        catalog_root = tmp_path / "catalog"
        template_dir = catalog_root / "test-template" / "1.0.0-2.0.0"
        template_dir.mkdir(parents=True)
        
        # Create a complete codemod
        complete_codemod = {
            "metadata": {
                "id": "export-001",
                "name": "Export Test",
                "description": "Test",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "affected_templates": ["test"],
                "risk_level": "low"
            },
            "implementation": {"type": "yaml", "rules": []},
            "test_instructions": "Run tests",
            "rollback_instructions": "Revert changes"
        }
        
        yaml_file = template_dir / "001-export.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(complete_codemod, f)
        
        store = DeltaStore(catalog_root)
        export = store.export_catalog()
        
        assert "export-001" in export
        assert "metadata" in export["export-001"]
        assert "implementation" in export["export-001"]
        assert "test_instructions" in export["export-001"]
        assert "rollback_instructions" in export["export-001"]
        
        # Verify metadata is a dict
        assert isinstance(export["export-001"]["metadata"], dict)
        assert export["export-001"]["metadata"]["id"] == "export-001"
        
        # Verify optional fields are included
        assert export["export-001"]["test_instructions"] == "Run tests"
        assert export["export-001"]["rollback_instructions"] == "Revert changes"
