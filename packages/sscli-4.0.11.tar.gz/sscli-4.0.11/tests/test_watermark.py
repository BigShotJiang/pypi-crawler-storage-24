"""
Tests for foundry.utils.watermark — inject_watermark() coverage.

Coverage targets:
  - Happy-path: file created, contents correct
  - Return value is a valid UUID
  - Overwrite / idempotency behaviour
  - Validation errors (empty email, empty tier, missing dir)
  - Multiple tier labels supported
  - Legal warning and timestamp present
"""

import re
import uuid
from pathlib import Path

import pytest

from foundry.utils.watermark import WATERMARK_FILENAME, inject_watermark


# ---------------------------------------------------------------------------
# Happy-path: file creation & content
# ---------------------------------------------------------------------------


class TestWatermarkCreatesFile:
    def test_watermark_creates_file(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        assert (tmp_path / WATERMARK_FILENAME).exists()

    def test_watermark_creates_file_with_correct_name(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "alpha")
        assert (tmp_path / "WATERMARK.txt").exists()

    def test_watermark_file_is_readable_utf8(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text(encoding="utf-8")
        assert len(content) > 0


class TestWatermarkFileContents:
    def test_watermark_file_contains_email(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        assert "test@example.com" in content

    def test_watermark_file_contains_tier(self, tmp_path):
        inject_watermark(str(tmp_path), "user@seedsource.dev", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        assert "pro" in content

    def test_watermark_file_contains_alpha_tier(self, tmp_path):
        inject_watermark(str(tmp_path), "alpha@example.com", "alpha")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        assert "alpha" in content

    def test_watermark_file_contains_uuid(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        uuid_pattern = re.compile(
            r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
            re.IGNORECASE,
        )
        assert uuid_pattern.search(content), "WATERMARK.txt does not contain a UUID"

    def test_watermark_file_contains_iso_timestamp(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        # e.g. 2026-03-22T14:30:00Z
        ts_pattern = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
        assert ts_pattern.search(content), "No ISO timestamp found in WATERMARK.txt"

    def test_watermark_file_contains_legal_warning(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        assert "confidential" in content.lower() or "WARNING" in content

    def test_watermark_file_contains_seed_and_source_branding(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        assert "Seed & Source" in content


# ---------------------------------------------------------------------------
# Return value
# ---------------------------------------------------------------------------


class TestWatermarkReturnValue:
    def test_watermark_returns_string(self, tmp_path):
        result = inject_watermark(str(tmp_path), "test@example.com", "pro")
        assert isinstance(result, str)

    def test_watermark_returns_valid_uuid(self, tmp_path):
        result = inject_watermark(str(tmp_path), "test@example.com", "pro")
        # Raises ValueError if not a valid UUID
        parsed = uuid.UUID(result)
        assert str(parsed) == result

    def test_watermark_returned_uuid_matches_file(self, tmp_path):
        result = inject_watermark(str(tmp_path), "test@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        assert result in content


# ---------------------------------------------------------------------------
# Overwrite / idempotency
# ---------------------------------------------------------------------------


class TestWatermarkOverwrite:
    def test_watermark_overwrites_existing(self, tmp_path):
        first_id = inject_watermark(str(tmp_path), "test@example.com", "pro")
        second_id = inject_watermark(str(tmp_path), "test@example.com", "pro")
        # Each call should generate a distinct UUID
        assert first_id != second_id

    def test_watermark_overwrites_file_content(self, tmp_path):
        inject_watermark(str(tmp_path), "first@example.com", "alpha")
        inject_watermark(str(tmp_path), "second@example.com", "pro")
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        # Second call's email should be present; first should NOT
        assert "second@example.com" in content
        assert "first@example.com" not in content

    def test_watermark_double_inject_only_one_file(self, tmp_path):
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        inject_watermark(str(tmp_path), "test@example.com", "pro")
        watermark_files = list(tmp_path.glob("WATERMARK*"))
        assert len(watermark_files) == 1


# ---------------------------------------------------------------------------
# Validation / error handling
# ---------------------------------------------------------------------------


class TestWatermarkValidation:
    def test_watermark_empty_email_raises_value_error(self, tmp_path):
        with pytest.raises(ValueError, match="user_email"):
            inject_watermark(str(tmp_path), "", "pro")

    def test_watermark_empty_tier_raises_value_error(self, tmp_path):
        with pytest.raises(ValueError, match="tier"):
            inject_watermark(str(tmp_path), "test@example.com", "")

    def test_watermark_nonexistent_dir_raises(self, tmp_path):
        missing = str(tmp_path / "does_not_exist")
        with pytest.raises(NotADirectoryError):
            inject_watermark(missing, "test@example.com", "pro")

    def test_watermark_file_path_as_dir_raises(self, tmp_path):
        # Pass a file path where a directory is expected
        file_path = tmp_path / "somefile.txt"
        file_path.write_text("not a directory")
        with pytest.raises(NotADirectoryError):
            inject_watermark(str(file_path), "test@example.com", "pro")

    def test_watermark_accepts_pathlike_dir(self, tmp_path):
        # target_dir accepts str; passing Path object should work via str coercion
        result = inject_watermark(str(tmp_path), "test@example.com", "alpha")
        assert isinstance(result, str)

    def test_watermark_unexpected_tier_value_does_not_raise(self, tmp_path):
        # Non-standard but non-empty tier should still succeed (no whitelist)
        result = inject_watermark(str(tmp_path), "test@example.com", "enterprise")
        assert isinstance(result, str)
        content = (tmp_path / WATERMARK_FILENAME).read_text()
        assert "enterprise" in content
