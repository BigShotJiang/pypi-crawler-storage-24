import json
from types import SimpleNamespace

from foundry.actions import observability_interactive


def test_observability_menu_routes(monkeypatch):
    selections = iter(["diff", "workspace", "list", "metadata", "back"])

    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )

    called = {"diff": 0, "workspace": 0, "list": 0, "metadata": 0, "pause": 0}
    monkeypatch.setattr(observability_interactive, "interactive_diff", lambda: called.__setitem__("diff", called["diff"] + 1))
    monkeypatch.setattr(observability_interactive, "interactive_workspace_create", lambda: called.__setitem__("workspace", called["workspace"] + 1))
    monkeypatch.setattr(observability_interactive, "interactive_workspace_list", lambda: called.__setitem__("list", called["list"] + 1))
    monkeypatch.setattr(observability_interactive, "interactive_view_metadata", lambda: called.__setitem__("metadata", called["metadata"] + 1))
    monkeypatch.setattr(observability_interactive, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))

    observability_interactive.observability_menu()

    assert called["diff"] == 1
    assert called["workspace"] == 1
    assert called["list"] == 1
    assert called["metadata"] == 1
    assert called["pause"] == 4


def test_interactive_diff_json(monkeypatch):
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: "json"),
    )
    monkeypatch.setattr(observability_interactive, "compute_diff", lambda **_k: {"ok": True})

    printed = {"json": 0}
    monkeypatch.setattr(observability_interactive.console, "print_json", lambda **_k: printed.__setitem__("json", printed["json"] + 1))
    monkeypatch.setattr(observability_interactive.console, "print", lambda *_a, **_k: None)

    observability_interactive.interactive_diff()

    assert printed["json"] == 1


def test_interactive_view_metadata_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: str(tmp_path)),
    )
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))

    observability_interactive.interactive_view_metadata()

    assert any("No metadata found" in str(msg) for msg in printed)


def test_interactive_view_metadata_success(tmp_path, monkeypatch):
    metadata = {
        "features_injected": [
            {"name": "commerce", "version": "1.0", "injected_at": "now"}
        ]
    }
    metadata_file = tmp_path / ".sscli-metadata.json"
    metadata_file.write_text(json.dumps(metadata), encoding="utf-8")

    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: str(tmp_path)),
    )
    monkeypatch.setattr(observability_interactive.console, "print", lambda *_a, **_k: None)

    observability_interactive.interactive_view_metadata()
