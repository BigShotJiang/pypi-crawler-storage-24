"""Tests for foundry.commands.compliance — SSA-17 project compliance checker."""
from __future__ import annotations

from pathlib import Path

import pytest

from foundry.commands.compliance import ComplianceResult, run_compliance_checks


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _scaffold(tmp_path: Path, **overrides) -> Path:
    """Create a minimal compliant project directory.

    Pass dockerfile=False / compose=False / etc. to omit specific files.
    """
    cfg = dict(
        dockerfile=True,
        compose=True,
        readme=True,
        gitignore_env=True,
        license=True,
    )
    cfg.update(overrides)

    if cfg["dockerfile"]:
        (tmp_path / "Dockerfile").write_text("FROM python:3.12-slim\nRUN echo ok\n")
    if cfg["compose"]:
        (tmp_path / "docker-compose.yml").write_text(
            "services:\n  app:\n    image: app:latest\n"
        )
    if cfg["readme"]:
        (tmp_path / "README.md").write_text("# Test Project\n")
    if cfg["gitignore_env"]:
        (tmp_path / ".gitignore").write_text(".env\n*.pyc\n__pycache__/\n")
    if cfg["license"]:
        (tmp_path / "LICENSE").write_text("MIT License\nCopyright 2026\n")

    return tmp_path


# ---------------------------------------------------------------------------
# Structural contract
# ---------------------------------------------------------------------------


def test_results_are_dict_with_expected_keys(tmp_path):
    """run_compliance_checks returns a dict with all expected check keys."""
    _scaffold(tmp_path)
    results = run_compliance_checks(tmp_path)
    expected = {
        "dockerfile",
        "docker_compose",
        "readme",
        "no_secrets",
        "no_hardcoded_localhost",
        "license",
        "gitignore_env",
    }
    assert set(results.keys()) == expected


def test_all_values_are_compliance_result_instances(tmp_path):
    """Every value in the dict must be a ComplianceResult."""
    _scaffold(tmp_path)
    results = run_compliance_checks(tmp_path)
    assert all(isinstance(v, ComplianceResult) for v in results.values())


# ---------------------------------------------------------------------------
# PASS — fully compliant project
# ---------------------------------------------------------------------------


def test_fully_compliant_project_has_no_failures(tmp_path):
    """A project with all required files should produce zero FAIL results."""
    _scaffold(tmp_path)
    results = run_compliance_checks(tmp_path)
    failures = [r for r in results.values() if r.status == "FAIL"]
    assert failures == [], f"Unexpected failures: {[f.name for f in failures]}"


# ---------------------------------------------------------------------------
# FAIL cases
# ---------------------------------------------------------------------------


def test_missing_dockerfile_is_fail(tmp_path):
    """Missing Dockerfile at root AND no subdirectory Dockerfile → FAIL."""
    _scaffold(tmp_path, dockerfile=False)
    results = run_compliance_checks(tmp_path)
    assert results["dockerfile"].status == "FAIL"


def test_missing_readme_is_fail(tmp_path):
    """Missing README.md at root → FAIL."""
    _scaffold(tmp_path, readme=False)
    results = run_compliance_checks(tmp_path)
    assert results["readme"].status == "FAIL"


def test_missing_docker_compose_is_fail(tmp_path):
    """Missing docker-compose.yml at root → FAIL."""
    _scaffold(tmp_path, compose=False)
    results = run_compliance_checks(tmp_path)
    assert results["docker_compose"].status == "FAIL"


def test_subdirectory_dockerfile_is_pass(tmp_path):
    """A Dockerfile in a subdirectory (not root) still satisfies the check."""
    _scaffold(tmp_path, dockerfile=False)
    subdir = tmp_path / "backend"
    subdir.mkdir()
    (subdir / "Dockerfile").write_text("FROM python:3.12-slim\n")
    results = run_compliance_checks(tmp_path)
    assert results["dockerfile"].status == "PASS"


# ---------------------------------------------------------------------------
# WARN cases
# ---------------------------------------------------------------------------


def test_env_with_live_secret_is_warn(tmp_path):
    """.env containing a sk_live_ key should produce a WARN on no_secrets."""
    _scaffold(tmp_path)
    # Build the fake key via concatenation so static scanners don't flag it
    _fake_live_key = "sk_live" + "_abc123xyz_fake_test_only"
    (tmp_path / ".env").write_text(f"STRIPE_KEY={_fake_live_key}\nDB_URL=postgres://x\n")
    results = run_compliance_checks(tmp_path)
    assert results["no_secrets"].status == "WARN"


def test_env_with_test_secret_is_pass(tmp_path):
    """.env file containing only test-mode keys (sk_test_) should PASS."""
    _scaffold(tmp_path)
    _fake_test_key = "sk_test" + "_abc123_fake_test_only"
    (tmp_path / ".env").write_text(f"STRIPE_KEY={_fake_test_key}\nDB_URL=postgres://x\n")
    results = run_compliance_checks(tmp_path)
    assert results["no_secrets"].status == "PASS"


def test_gitignore_missing_env_entry_is_warn(tmp_path):
    """.gitignore that omits .env should produce a WARN."""
    _scaffold(tmp_path, gitignore_env=False)
    (tmp_path / ".gitignore").write_text("*.pyc\n__pycache__/\n")  # no .env
    results = run_compliance_checks(tmp_path)
    assert results["gitignore_env"].status == "WARN"


def test_no_gitignore_is_warn(tmp_path):
    """Absent .gitignore file should produce a WARN for gitignore_env."""
    _scaffold(tmp_path, gitignore_env=False)
    gi = tmp_path / ".gitignore"
    if gi.exists():
        gi.unlink()
    results = run_compliance_checks(tmp_path)
    assert results["gitignore_env"].status == "WARN"


def test_no_license_file_is_warn(tmp_path):
    """Project with neither LICENSE file nor license headers should WARN."""
    _scaffold(tmp_path, license=False)
    # Make sure there are no source files with license headers
    results = run_compliance_checks(tmp_path)
    assert results["license"].status == "WARN"


def test_hardcoded_localhost_in_src_is_warn(tmp_path):
    """A source file in src/ containing http://localhost should produce a WARN."""
    _scaffold(tmp_path)
    src = tmp_path / "src"
    src.mkdir()
    (src / "client.py").write_text("API_URL = 'http://localhost:8000/api'\n")
    results = run_compliance_checks(tmp_path)
    assert results["no_hardcoded_localhost"].status == "WARN"


def test_localhost_in_test_files_is_pass(tmp_path):
    """http://localhost inside a tests/ subdirectory is ignored."""
    _scaffold(tmp_path)
    src = tmp_path / "src"
    src.mkdir()
    tests = src / "tests"
    tests.mkdir()
    (tests / "test_client.py").write_text("BASE = 'http://localhost:8000'\n")
    results = run_compliance_checks(tmp_path)
    assert results["no_hardcoded_localhost"].status == "PASS"


# ---------------------------------------------------------------------------
# Real template smoke test
# ---------------------------------------------------------------------------


def test_python_saas_template_has_no_failures():
    """The python-saas template should pass all FAIL-level compliance checks."""
    template_path = (
        Path(__file__).parent.parent.parent.parent.parent / "templates" / "python-saas"
    )
    if not template_path.exists():
        pytest.skip(f"python-saas template not found at {template_path}")
    results = run_compliance_checks(template_path)
    failures = [r for r in results.values() if r.status == "FAIL"]
    assert failures == [], f"Template compliance failures: {[f.name for f in failures]}"
