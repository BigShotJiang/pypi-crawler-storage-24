from foundry.actions import explore


def test_render_templates_tree_prints_panel(monkeypatch):
    buckets = {
        "Backend Services": [
            {"name": "python-saas", "tier": "pro", "locked": False},
            {"name": "rails-api", "tier": "free", "locked": True},
        ],
        "Frontend & UI": [
            {"name": "react-client", "tier": "free", "locked": False}
        ],
    }
    printed = []

    monkeypatch.setattr(explore.console, "print", lambda *args, **_k: printed.append(args))

    explore._render_templates_tree(buckets)

    assert printed


def test_show_template_info_calls_prompt(monkeypatch):
    monkeypatch.setattr(explore, "get_template_info", lambda _name: {"tier": "pro", "repo": "repo", "description": "desc"})
    printed = []
    monkeypatch.setattr(explore.console, "print", lambda *args, **_k: printed.append(args))

    class DummyPrompt:
        def ask(self):
            return None

    monkeypatch.setattr(explore.questionary, "press_any_key_to_continue", lambda: DummyPrompt())

    explore._show_template_info("python-saas")

    assert printed


def test_run_explore_toggle_and_show(monkeypatch):
    class Template:
        def __init__(self, name):
            self.name = name

    monkeypatch.setattr(explore, "get_templates", lambda: [Template("python-saas")])
    monkeypatch.setattr(explore, "get_template_info", lambda _name: {"tier": "free", "description": "desc"})
    monkeypatch.setattr(explore, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(explore.console, "clear", lambda: None)
    monkeypatch.setattr(explore.console, "print", lambda *args, **_k: None)

    selections = iter(["toggle:Backend Services", "tmpl:python-saas", "back"])

    class DummySelect:
        def ask(self):
            return next(selections)

    monkeypatch.setattr(explore.questionary, "select", lambda *a, **k: DummySelect())

    class DummyPrompt:
        def ask(self):
            return None

    monkeypatch.setattr(explore.questionary, "press_any_key_to_continue", lambda: DummyPrompt())

    explore.run_explore()
