"""
Comprehensive safety module coverage tests.
Targets uncovered lines in integration.py, dry_run_engine.py, and git_guard.py.
"""

import pytest
import subprocess
import json
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch
from types import SimpleNamespace

from foundry.safety import (
    GitGuard,
    GitGuardConfig,
    GitStatusError,
    DryRunEngine,
    FileModification,
    DryRunCodemodWrapper,
)
from foundry.safety.integration import (
    require_git_status_check,
    verify_git_status,
    _print_git_suggestions,
    CodemodSafetyContext,
    get_git_status_display,
)
from foundry.safety.git_guard import get_git_guard_suggestions
import typer


class TestIntegrationModule:
    """Test integration.py uncovered lines."""

    def test_decorator_no_force_clean_repo(self, monkeypatch):
        """Test decorator with clean repo (no force)."""
        class FakeGuard:
            def __init__(self, config=None):
                pass
            def require_clean_status(self):
                pass  # Clean
        
        monkeypatch.setattr("foundry.safety.integration.GitGuard", FakeGuard)
        
        @require_git_status_check()
        def test_cmd(force: bool = False):
            return "success"
        
        result = test_cmd(force=False)
        assert result == "success"

    def test_decorator_with_allow_untracked(self, monkeypatch):
        """Test decorator respects allow_untracked config."""
        called_with_config = []
        
        class FakeGuard:
            def __init__(self, config=None):
                called_with_config.append(config)
            def require_clean_status(self):
                pass
        
        monkeypatch.setattr("foundry.safety.integration.GitGuard", FakeGuard)
        
        @require_git_status_check(allow_untracked=True)
        def test_cmd(force: bool = False):
            return "ok"
        
        test_cmd(force=False)
        assert called_with_config[0].allow_untracked is True

    def test_print_git_suggestions(self, monkeypatch):
        """Test _print_git_suggestions helper."""
        printed = []
        mock_console = Mock()
        mock_console.print = lambda *args: printed.append(str(args[0]) if args else "")
        
        monkeypatch.setattr("foundry.safety.integration.console", mock_console)
        
        _print_git_suggestions()
        
        output = "\n".join(printed)
        assert "git add" in output.lower()
        assert "git commit" in output.lower()
        assert "git stash" in output.lower()

    def test_verify_git_status_force(self, capsys):
        """Test verify_git_status with force=True."""
        verify_git_status(force=True)
        captured = capsys.readouterr()
        assert "bypass" in captured.out.lower() or "force" in captured.out.lower()

    def test_codemod_safety_context_exit_with_error(self, monkeypatch, capsys):
        """Test CodemodSafetyContext.__exit__ with exception."""
        class FakeGuard:
            def __init__(self, config=None):
                pass
            def require_clean_status(self):
                pass
        
        monkeypatch.setattr("foundry.safety.integration.GitGuard", FakeGuard)
        
        try:
            with CodemodSafetyContext(force=False) as ctx:
                raise ValueError("Test error")
        except ValueError:
            pass
        
        captured = capsys.readouterr()
        assert "failed" in captured.out.lower() or "error" in captured.out.lower()

    def test_get_git_status_display_not_git_repo(self, monkeypatch):
        """Test get_git_status_display when not a git repo."""
        class FakeGuard:
            def get_status_summary(self):
                return {"is_git_repo": False}
        
        monkeypatch.setattr("foundry.safety.integration.GitGuard", FakeGuard)
        
        result = get_git_status_display()
        assert result == "NOT_IN_GIT_REPO"

    def test_get_git_status_display_clean(self, monkeypatch):
        """Test get_git_status_display for clean repo."""
        class FakeGuard:
            def get_status_summary(self):
                return {
                    "is_git_repo": True,
                    "staged_files": [],
                    "unstaged_files": [],
                    "untracked_files": [],
                    "merge_conflicts": [],
                }
        
        monkeypatch.setattr("foundry.safety.integration.GitGuard", FakeGuard)
        
        result = get_git_status_display()
        assert result == "CLEAN"

    def test_get_git_status_display_with_conflicts(self, monkeypatch):
        """Test get_git_status_display with merge conflicts."""
        class FakeGuard:
            def get_status_summary(self):
                return {
                    "is_git_repo": True,
                    "staged_files": ["a.py"],
                    "unstaged_files": [],
                    "untracked_files": [],
                    "merge_conflicts": ["conflict.py"],
                }
        
        monkeypatch.setattr("foundry.safety.integration.GitGuard", FakeGuard)
        
        result = get_git_status_display()
        assert "staged:1" in result
        assert "conflicts:1" in result


class TestDryRunEngineEdgeCases:
    """Test dry_run_engine.py uncovered lines."""

    def test_file_modification_post_init_with_error(self):
        """Test FileModification.__post_init__ sets success=False on error."""
        mod = FileModification(
            file_path="test.py",
            original_content="old",
            modified_content="new",
            error="Parse error"
        )
        assert mod.success is False

    def test_file_modification_post_init_auto_changes(self):
        """Test __post_init__ auto-calculates changes_made."""
        mod = FileModification(
            file_path="test.py",
            original_content="old",
            modified_content="new"
            # changes_made not provided
        )
        assert mod.changes_made == 1

    def test_preview_all_skip_with_none_return(self):
        """Test preview_all skips files when codemod returns (None, None)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            (tmppath / "skip.py").write_text("skip_me")
            (tmppath / "process.py").write_text("process_me")
            
            def selective_codemod(file_path: Path, content: str):
                if "skip" in content:
                    return (None, None)  # Skip
                return (content.replace("process", "processed"), None)
            
            engine = DryRunEngine()
            result = engine.preview_all(tmppath, selective_codemod, "*.py")
            
            # Only one file should have changes
            assert len(result.get_files_with_changes()) == 1

    def test_preview_all_file_read_exception(self):
        """Test preview_all handles exceptions during file processing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            (tmppath / "test.py").write_text("content")
            
            def failing_codemod(file_path: Path, content: str):
                raise RuntimeError("Codemod error")
            
            engine = DryRunEngine()
            result = engine.preview_all(tmppath, failing_codemod, "*.py")
            
            assert result.failed_files > 0

    def test_preview_all_nonexistent_path(self):
        """Test preview_all with nonexistent project path."""
        engine = DryRunEngine()
        
        def dummy_codemod(file_path: Path, content: str):
            return (content, None)
        
        result = engine.preview_all(
            Path("/nonexistent/path/xyz123"),
            dummy_codemod
        )
        
        assert result.total_files > 0
        assert not result.modifications[0].success

    def test_as_unified_diff_no_changes(self):
        """Test unified diff output with no changes."""
        engine = DryRunEngine()
        engine.preview_transformation(
            Path("test.py"),
            original_content="same",
            modified_content="same"
        )
        
        diff = engine.as_unified_diff()
        assert "Files with changes: 0" in diff

    def test_dry_run_codemod_wrapper_not_exists(self):
        """Test DryRunCodemodWrapper with non-existent file."""
        engine = DryRunEngine()
        
        class DummyCodemod:
            pass
        
        wrapper = DryRunCodemodWrapper(engine, DummyCodemod)
        mod = wrapper.apply_to_file(Path("/nonexistent/file.py"))
        
        assert mod.success is False
        assert "not found" in mod.error.lower()

    def test_dry_run_codemod_wrapper_codemod_failure(self):
        """Test wrapper handles codemod failure."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            test_file = tmppath / "test.py"
            test_file.write_text("content")
            
            class FailingCodemod:
                def apply(self, path: Path):
                    return SimpleNamespace(
                        success=False,
                        changes_made=0,
                        error="Codemod failed"
                    )
            
            engine = DryRunEngine()
            wrapper = DryRunCodemodWrapper(engine, FailingCodemod)
            mod = wrapper.apply_to_file(test_file)
            
            assert mod.success is False

    def test_dry_run_codemod_wrapper_exception(self):
        """Test wrapper handles exception during execution."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            test_file = tmppath / "test.py"
            test_file.write_text("content")
            
            class ExceptionCodemod:
                def apply(self, path: Path):
                    raise RuntimeError("Crash!")
            
            engine = DryRunEngine()
            wrapper = DryRunCodemodWrapper(engine, ExceptionCodemod)
            mod = wrapper.apply_to_file(test_file)
            
            assert mod.success is False
            assert "failed" in mod.error.lower()


class TestGitGuardEdgeCases:
    """Test git_guard.py uncovered lines."""

    def test_get_git_guard_suggestions_function(self):
        """Test the standalone get_git_guard_suggestions function."""
        suggestions = get_git_guard_suggestions()
        
        assert isinstance(suggestions, str)
        assert "git add" in suggestions.lower()
        assert "git commit" in suggestions.lower()
        assert "--force" in suggestions.lower()

    def test_status_summary_merge_conflicts(self, tmp_path):
        """Test merge conflict detection in status summary."""
        # Setup git repo
        subprocess.run(["git", "init"], cwd=str(tmp_path), capture_output=True, check=True)
        subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=str(tmp_path), capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test User"], cwd=str(tmp_path), capture_output=True)
        
        guard = GitGuard(cwd=tmp_path)
        
        # Mock git status to return conflict markers
        original_run = subprocess.run
        
        def mock_run(*args, **kwargs):
            if len(args) > 0 and "status" in str(args[0]) and "--porcelain" in str(args[0]):
                return SimpleNamespace(
                    returncode=0,
                    stdout="UU conflict.txt\n",
                    stderr=""
                )
            return original_run(*args, **kwargs)
        
        with patch('subprocess.run', side_effect=mock_run):
            status = guard.get_status_summary()
            assert len(status["merge_conflicts"]) > 0

    def test_file_not_found_error_is_git_repo(self, tmp_path):
        """Test is_git_repo handles FileNotFoundError."""
        guard = GitGuard(cwd=tmp_path)
        
        def mock_run(*args, **kwargs):
            raise FileNotFoundError("git not found")
        
        with patch('subprocess.run', side_effect=mock_run):
            result = guard.is_git_repo()
            assert result is False

    def test_file_not_found_error_get_git_root(self, tmp_path):
        """Test get_git_root handles FileNotFoundError."""
        guard = GitGuard(cwd=tmp_path)
        
        def mock_run(*args, **kwargs):
            raise FileNotFoundError("git not found")
        
        with patch('subprocess.run', side_effect=mock_run):
            result = guard.get_git_root()
            assert result is None

    def test_status_summary_empty_line_handling(self, tmp_path):
        """Test that empty lines in git status are ignored."""
        subprocess.run(["git", "init"], cwd=str(tmp_path), capture_output=True, check=True)
        
        guard = GitGuard(cwd=tmp_path)
        
        original_run = subprocess.run
        
        def mock_run(*args, **kwargs):
            if len(args) > 0 and "status" in str(args[0]) and "--porcelain" in str(args[0]):
                return SimpleNamespace(
                    returncode=0,
                    stdout="M  file1.txt\n\n\n M file2.txt\n",  # Empty lines
                    stderr=""
                )
            return original_run(*args, **kwargs)
        
        with patch('subprocess.run', side_effect=mock_run):
            status = guard.get_status_summary()
            # Should parse correctly despite empty lines
            assert status["is_git_repo"] is True


class TestIntegrationWorkflows:
    """Test integration between safety systems."""

    def test_full_safety_workflow(self, tmp_path):
        """Test complete workflow: git check → dry-run → results."""
        # Setup clean repo
        subprocess.run(["git", "init"], cwd=str(tmp_path), capture_output=True, check=True)
        subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=str(tmp_path), capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test User"], cwd=str(tmp_path), capture_output=True)
        
        test_file = tmp_path / "code.py"
        test_file.write_text("old_code")
        subprocess.run(["git", "add", "."], cwd=str(tmp_path), capture_output=True, check=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=str(tmp_path), capture_output=True, check=True)
        
        # Step 1: Git check
        guard = GitGuard(cwd=tmp_path)
        guard.require_clean_status()  # Should pass
        
        # Step 2: Dry run
        engine = DryRunEngine()
        engine.preview_transformation(
            test_file,
            original_content="old_code",
            modified_content="new_code"
        )
        
        # Step 3: Verify
        assert engine.has_changes()
        assert not engine.has_errors()
        
        # Step 4: Export
        diff = engine.as_unified_diff()
        assert "old_code" in diff
        assert "new_code" in diff

    def test_safety_context_with_dry_run(self, tmp_path):
        """Test CodemodSafetyContext integrates with DryRunEngine."""
        subprocess.run(["git", "init"], cwd=str(tmp_path), capture_output=True, check=True)
        subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=str(tmp_path), capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test User"], cwd=str(tmp_path), capture_output=True)
        
        test_file = tmp_path / "test.py"
        test_file.write_text("code")
        subprocess.run(["git", "add", "."], cwd=str(tmp_path), capture_output=True, check=True)
        subprocess.run(["git", "commit", "-m", "Init"], cwd=str(tmp_path), capture_output=True, check=True)
        
        guard = GitGuard(cwd=tmp_path)
        
        with CodemodSafetyContext(force=True) as safety:
            if safety.is_safe:
                engine = DryRunEngine()
                engine.preview_transformation(
                    test_file,
                    original_content="code",
                    modified_content="modified_code"
                )
                assert engine.has_changes()
