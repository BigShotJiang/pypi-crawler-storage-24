"""
Comprehensive tests for foundry.actions.documentation module.

Tests:
- Interactive documentation viewing
- Non-interactive documentation listing
- Markdown rendering
- Missing docs folder handling
- File selection and navigation
"""

import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock, call
from foundry.actions import documentation as doc_mod


@pytest.fixture
def mock_templates_dir(tmp_path):
    """Create a mock templates directory with docs."""
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create docs folder
    docs_dir = templates_dir / "docs"
    docs_dir.mkdir()
    
    # Create some markdown files
    (docs_dir / "README.md").write_text("# Main README\n\nDocumentation content")
    (docs_dir / "GUIDE.md").write_text("# User Guide\n\nGuide content")
    
    # Create nested docs
    nested = docs_dir / "advanced"
    nested.mkdir()
    (nested / "ADVANCED.md").write_text("# Advanced Topics\n\nAdvanced content")
    
    # Create root-level docs
    (templates_dir / "CHANGELOG.md").write_text("# Changelog\n\nVersion history")
    
    return templates_dir


class TestRunViewDocsNonInteractive:
    """Test non-interactive documentation viewing."""
    
    def test_list_docs_success(self, mock_templates_dir, monkeypatch):
        """Test listing documentation in non-interactive mode."""
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", mock_templates_dir)
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod.run_view_docs(interactive=False)
            
            # Should print header and all docs
            print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
            assert any("Available Documentation" in str(call_obj) for call_obj in print_calls)
            assert any("README.md" in str(call_obj) for call_obj in print_calls)
            assert any("GUIDE.md" in str(call_obj) for call_obj in print_calls)
            assert any("CHANGELOG.md" in str(call_obj) for call_obj in print_calls)
    
    def test_no_docs_folder(self, tmp_path, monkeypatch):
        """Test handling of missing docs folder."""
        templates_dir = tmp_path / "templates"
        templates_dir.mkdir()
        
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", templates_dir)
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod.run_view_docs(interactive=False)
            
            # Should print error message
            mock_print.assert_called_once()
            assert "No docs folder found" in str(mock_print.call_args)
    
    def test_empty_docs_folder(self, tmp_path, monkeypatch):
        """Test handling of empty docs folder."""
        templates_dir = tmp_path / "templates"
        templates_dir.mkdir()
        docs_dir = templates_dir / "docs"
        docs_dir.mkdir()
        
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", templates_dir)
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod.run_view_docs(interactive=False)
            
            # Should still print header
            assert mock_print.call_count >= 1
            assert any("Available Documentation" in str(call_obj) for call_obj in mock_print.call_args_list)


class TestRunViewDocsInteractive:
    """Test interactive documentation viewing."""
    
    @patch("foundry.actions.documentation.questionary")
    def test_select_and_render_doc(self, mock_questionary, mock_templates_dir, monkeypatch):
        """Test selecting and rendering a document interactively."""
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", mock_templates_dir)
        
        # Mock questionary to select README.md
        mock_select = MagicMock()
        mock_select.ask.return_value = "README.md"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod.run_view_docs(interactive=True)
            
            # Should render the markdown
            mock_print.assert_called_once()
            # Check if Markdown object was printed
            assert mock_print.call_count == 1
    
    @patch("foundry.actions.documentation.questionary")
    def test_select_back_option(self, mock_questionary, mock_templates_dir, monkeypatch):
        """Test selecting 'Back' option in interactive mode."""
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", mock_templates_dir)
        
        # Mock questionary to select "Back"
        mock_select = MagicMock()
        mock_select.ask.return_value = "Back"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod.run_view_docs(interactive=True)
            
            # Should not render anything
            mock_print.assert_not_called()
    
    @patch("foundry.actions.documentation.questionary")
    def test_select_nonexistent_doc(self, mock_questionary, mock_templates_dir, monkeypatch):
        """Test selecting a document that doesn't exist."""
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", mock_templates_dir)
        
        # Mock questionary to select non-existent file
        mock_select = MagicMock()
        mock_select.ask.return_value = "NONEXISTENT.md"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod.run_view_docs(interactive=True)
            
            # Should not render (no match found)
            mock_print.assert_not_called()
    
    @patch("foundry.actions.documentation.questionary")
    def test_interactive_with_nested_docs(self, mock_questionary, mock_templates_dir, monkeypatch):
        """Test that nested documents are included in choices."""
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", mock_templates_dir)
        
        # Mock questionary
        mock_select = MagicMock()
        mock_select.ask.return_value = "Back"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        # Import the actual Choice class
        from questionary import Choice
        mock_questionary.Choice = Choice
        
        doc_mod.run_view_docs(interactive=True)
        
        # Check that select was called with all doc files
        call_args = mock_questionary.select.call_args
        if call_args:
            choices = call_args[1]["choices"]
            
            # Should include all markdown files (4 total + "Back")
            # Check that we have multiple choices
            assert len(choices) >= 2  # At least some files + Back


class TestRenderDoc:
    """Test the _render_doc helper function."""
    
    def test_render_markdown_file(self, tmp_path, monkeypatch):
        """Test rendering a markdown file."""
        doc_file = tmp_path / "test.md"
        doc_file.write_text("# Test Doc\n\nThis is a test document.\n\n## Section 1\n\nContent here.")
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod._render_doc(doc_file)
            
            # Should print a Markdown object
            mock_print.assert_called_once()
            printed_arg = mock_print.call_args[0][0]
            # Rich's Markdown object should be passed
            assert hasattr(printed_arg, "__class__")
    
    def test_render_empty_file(self, tmp_path):
        """Test rendering an empty markdown file."""
        doc_file = tmp_path / "empty.md"
        doc_file.write_text("")
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod._render_doc(doc_file)
            
            # Should still render (empty Markdown)
            mock_print.assert_called_once()
    
    def test_render_unicode_content(self, tmp_path):
        """Test rendering markdown with unicode characters."""
        doc_file = tmp_path / "unicode.md"
        doc_file.write_text("# Документация\n\n日本語のテキスト\n\n🚀 Emoji content", encoding="utf-8")
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod._render_doc(doc_file)
            
            # Should handle unicode correctly
            mock_print.assert_called_once()
            printed_arg = mock_print.call_args[0][0]
            assert printed_arg is not None


class TestEdgeCases:
    """Test edge cases and error scenarios."""
    
    def test_docs_folder_permission_error(self, tmp_path, monkeypatch):
        """Test handling of permission errors when accessing docs."""
        templates_dir = tmp_path / "templates"
        templates_dir.mkdir()
        docs_dir = templates_dir / "docs"
        docs_dir.mkdir()
        
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", templates_dir)
        
        # Make docs folder unreadable (Unix only)
        import platform
        if platform.system() != "Windows":
            docs_dir.chmod(0o000)
            
            try:
                with patch.object(doc_mod.console, "print"):
                    # Should handle gracefully
                    doc_mod.run_view_docs(interactive=False)
            finally:
                # Restore permissions for cleanup
                docs_dir.chmod(0o755)
    
    def test_malformed_markdown_rendering(self, tmp_path):
        """Test rendering malformed markdown."""
        doc_file = tmp_path / "malformed.md"
        # Write markdown with intentionally broken syntax
        doc_file.write_text("# Heading\n\n[Broken link]()\n\n```\nUnclosed code block\n")
        
        with patch.object(doc_mod.console, "print") as mock_print:
            # Should not crash, Rich handles malformed markdown gracefully
            doc_mod._render_doc(doc_file)
            mock_print.assert_called_once()


class TestQuestitionaryIntegration:
    """Test integration with questionary styling."""
    
    @patch("foundry.actions.documentation.questionary")
    def test_questionary_style_applied(self, mock_questionary, mock_templates_dir, monkeypatch):
        """Test that QUESTIONARY_STYLE is properly applied."""
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", mock_templates_dir)
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "Back"
        mock_questionary.select.return_value = mock_select
        mock_questionary.Style.return_value = {}
        
        doc_mod.run_view_docs(interactive=True)
        
        # Verify Style was called with QUESTIONARY_STYLE
        mock_questionary.Style.assert_called_once()
        style_arg = mock_questionary.Style.call_args[0][0]
        assert isinstance(style_arg, list) or isinstance(style_arg, dict)


# Performance test for large doc sets
class TestPerformance:
    """Test performance with large doc sets."""
    
    def test_many_docs_listing(self, tmp_path, monkeypatch):
        """Test listing a large number of documentation files."""
        templates_dir = tmp_path / "templates"
        templates_dir.mkdir()
        docs_dir = templates_dir / "docs"
        docs_dir.mkdir()
        
        # Create 100 doc files
        for i in range(100):
            (docs_dir / f"doc_{i:03d}.md").write_text(f"# Doc {i}")
        
        monkeypatch.setattr(doc_mod, "TEMPLATES_DIR", templates_dir)
        
        with patch.object(doc_mod.console, "print") as mock_print:
            doc_mod.run_view_docs(interactive=False)
            
            # Should handle large sets without issues
            assert mock_print.call_count >= 100
