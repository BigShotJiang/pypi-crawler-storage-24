"""
Comprehensive test suite for foundry/commands/feedback.py
Target: ≥95% statement coverage.

Covers:
- All helper functions (_consent_for_context, _redact_text, _redact_collection,
  get_system_context, get_user_context, save_feedback_locally,
  display_feedback_instructions)
- All Typer commands via CliRunner (quick, detailed, bug, feature, nps, list, export)
- All branch paths (with/without context, score ranges, empty/non-empty dirs)
"""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner

import foundry.commands.feedback as fb_mod
from foundry.commands.feedback import (
    feedback_app,
    _consent_for_context,
    _redact_text,
    _redact_collection,
    get_system_context,
    get_user_context,
    save_feedback_locally,
    display_feedback_instructions,
)

runner = CliRunner()


# ── Autouse fixtures ──────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _no_log_event(monkeypatch):
    """No-op: feedback.py does not import log_event directly."""
    # feedback.py has no telemetry import — fixture is harmless no-op retained
    # for documentation purposes only.
    pass


@pytest.fixture(autouse=True)
def _mock_license(monkeypatch):
    """Provide a default PRO license mock for all feedback tests."""
    monkeypatch.setattr(
        "foundry.commands.feedback.get_current_license_info",
        MagicMock(return_value={"tier": "pro", "user_id": "test-unit-user"}),
    )


def _capture(monkeypatch):
    """Patch fb_mod.console.print and return the captured-output list."""
    captured = []
    monkeypatch.setattr(
        fb_mod.console,
        "print",
        lambda *a, **kw: captured.append(str(a[0]) if a else ""),
    )
    return captured


# ── _consent_for_context ──────────────────────────────────────────────────────

def test_consent_for_context_returns_true(monkeypatch):
    monkeypatch.setattr("rich.prompt.Confirm.ask", lambda *a, **kw: True)
    assert _consent_for_context() is True


def test_consent_for_context_returns_false(monkeypatch):
    monkeypatch.setattr("rich.prompt.Confirm.ask", lambda *a, **kw: False)
    assert _consent_for_context() is False


# ── _redact_text ─────────────────────────────────────────────────────────────

def test_redact_text_empty_string_returns_immediately():
    assert _redact_text("") == ""


def test_redact_text_no_secrets_unchanged():
    text = "Building a SaaS product with templates."
    assert _redact_text(text) == text


def test_redact_text_api_key_redacted():
    result = _redact_text("api_key=supersecret123")
    assert "REDACTED" in result
    assert "supersecret123" not in result


def test_redact_text_token_redacted():
    # token=value (no space) is fully consumed by [^\s,;]+
    result = _redact_text("token=tkn_abc123")
    assert "REDACTED" in result
    assert "tkn_abc123" not in result


def test_redact_text_password_redacted():
    result = _redact_text("password=hunter2")
    assert "REDACTED" in result
    assert "hunter2" not in result


def test_redact_text_secret_colon_redacted():
    result = _redact_text("secret: mySecretVal")
    assert "REDACTED" in result
    assert "mySecretVal" not in result


def test_redact_text_token_equals_form():
    result = _redact_text("token=leaked")
    assert "REDACTED" in result
    assert "leaked" not in result


# ── _redact_collection ────────────────────────────────────────────────────────

def test_redact_collection_empty_list():
    assert _redact_collection([]) == []


def test_redact_collection_all_clean():
    vals = ["step one", "step two", "step three"]
    assert _redact_collection(vals) == vals


def test_redact_collection_with_secret():
    vals = ["ok step", "api_key=exposed", "clean step"]
    result = _redact_collection(vals)
    assert result[0] == "ok step"
    assert "REDACTED" in result[1]
    assert "exposed" not in result[1]
    assert result[2] == "clean step"


# ── get_system_context ────────────────────────────────────────────────────────

def test_get_system_context_required_keys():
    ctx = get_system_context()
    assert "os" in ctx
    assert "python_version" in ctx
    assert "cli_version" in ctx
    assert "timestamp" in ctx


def test_get_system_context_os_from_platform(monkeypatch):
    import platform
    monkeypatch.setattr(platform, "system", lambda: "MockOS")
    assert get_system_context()["os"] == "MockOS"


def test_get_system_context_cli_version_is_string():
    """foundry.__version__ is now set via importlib.metadata — cli_version must be a string."""
    ctx = get_system_context()
    assert isinstance(ctx["cli_version"], str)
    assert ctx["cli_version"]  # not empty


def test_get_system_context_cli_version_read_when_available(monkeypatch):
    """When foundry.__version__ is set, it propagates into the context."""
    import foundry
    monkeypatch.setattr(foundry, "__version__", "9.9.9", raising=False)
    ctx = get_system_context()
    assert ctx["cli_version"] == "9.9.9"


# ── get_user_context ──────────────────────────────────────────────────────────

def test_get_user_context_returns_only_tier(monkeypatch):
    monkeypatch.setattr(
        "foundry.commands.feedback.get_current_license_info",
        MagicMock(return_value={"tier": "pro", "user_id": "pii-id", "email": "pii@x.com"}),
    )
    result = get_user_context()
    assert result == {"tier": "pro"}
    assert "user_id" not in result
    assert "email" not in result


def test_get_user_context_free_tier(monkeypatch):
    monkeypatch.setattr(
        "foundry.commands.feedback.get_current_license_info",
        MagicMock(return_value={"tier": "free"}),
    )
    assert get_user_context()["tier"] == "free"


def test_get_user_context_missing_tier_defaults_to_unknown(monkeypatch):
    monkeypatch.setattr(
        "foundry.commands.feedback.get_current_license_info",
        MagicMock(return_value={}),
    )
    assert get_user_context()["tier"] == "unknown"


# ── save_feedback_locally ─────────────────────────────────────────────────────

def test_save_feedback_locally_creates_json_file(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    data = {"type": "quick", "message": "hello"}
    saved = save_feedback_locally(data)
    assert saved.exists()
    assert json.loads(saved.read_text()) == data


def test_save_feedback_locally_creates_directory_tree(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    save_feedback_locally({"type": "test"})
    assert (tmp_path / ".sscli" / "feedback").is_dir()


def test_save_feedback_locally_file_naming(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    path = save_feedback_locally({"type": "bug"})
    assert path.name.startswith("feedback_")
    assert path.suffix == ".json"


# ── display_feedback_instructions ─────────────────────────────────────────────

def test_display_feedback_instructions_does_not_raise(monkeypatch):
    _capture(monkeypatch)
    display_feedback_instructions()  # must not raise


# ── feedback_main callback ────────────────────────────────────────────────────

def test_feedback_main_no_subcommand_shows_instructions(monkeypatch):
    output = _capture(monkeypatch)
    result = runner.invoke(feedback_app, [])
    assert result.exit_code == 0
    assert len(output) > 0


# ── quick_feedback ────────────────────────────────────────────────────────────

def test_quick_feedback_no_context_saves_correct_data(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False):
        result = runner.invoke(feedback_app, ["quick", "great tool"])
    assert result.exit_code == 0
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    assert len(files) == 1
    data = json.loads(files[0].read_text())
    assert data["type"] == "quick"
    assert data["message"] == "great tool"
    assert "system" not in data
    assert "user" not in data


def test_quick_feedback_with_context_includes_system_and_user(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=True):
        result = runner.invoke(feedback_app, ["quick", "context included"])
    assert result.exit_code == 0
    data = json.loads(
        list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))[0].read_text()
    )
    assert "system" in data
    assert "user" in data
    assert "tier" in data["user"]


def test_quick_feedback_category_bug(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False):
        runner.invoke(feedback_app, ["quick", "crash", "--category", "bug"])
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    assert json.loads(files[0].read_text())["category"] == "bug"


def test_quick_feedback_category_feature(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False):
        runner.invoke(feedback_app, ["quick", "dark mode", "--category", "feature"])
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    assert json.loads(files[0].read_text())["category"] == "feature"


def test_quick_feedback_category_praise(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False):
        result = runner.invoke(feedback_app, ["quick", "love it", "--category", "praise"])
    assert result.exit_code == 0


def test_quick_feedback_category_general_default(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False):
        runner.invoke(feedback_app, ["quick", "general comment"])
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    assert json.loads(files[0].read_text())["category"] == "general"


def test_quick_feedback_redacts_secret_in_message(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False):
        runner.invoke(feedback_app, ["quick", "api_key=mysecrettoken"])
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    data = json.loads(files[0].read_text())
    assert "mysecrettoken" not in data["message"]
    assert "REDACTED" in data["message"]


# ── detailed_feedback ─────────────────────────────────────────────────────────

def test_detailed_feedback_no_context_all_fields(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = [
        "Building a SaaS app",    # project_description
        "4",                      # experience_rating
        "Templates are great",    # working_well
        "Docs could improve",     # needs_improvement
        "More examples",          # top_feature_request
        "8",                      # nps_score
        "Nothing else",           # additional_comments
    ]
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        result = runner.invoke(feedback_app, ["detailed"])
    assert result.exit_code == 0
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    assert len(files) == 1
    data = json.loads(files[0].read_text())
    assert data["type"] == "detailed"
    assert data["project_description"] == "Building a SaaS app"
    assert data["experience_rating"] == "4"
    assert data["working_well"] == "Templates are great"
    assert data["needs_improvement"] == "Docs could improve"
    assert data["top_feature_request"] == "More examples"
    assert data["nps_score"] == "8"
    assert data["additional_comments"] == "Nothing else"
    assert "system" not in data


def test_detailed_feedback_with_context(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = ["My project", "3", "Good bits", "Bad bits", "Feature X", "7", ""]
    with patch("rich.prompt.Confirm.ask", return_value=True), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        result = runner.invoke(feedback_app, ["detailed"])
    assert result.exit_code == 0
    data = json.loads(
        list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))[0].read_text()
    )
    assert "system" in data
    assert "user" in data


# ── bug_report ────────────────────────────────────────────────────────────────

def test_bug_report_no_context_two_steps(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = [
        "Crash on startup",      # summary
        "sscli new myapp",       # step 1
        "select python-saas",    # step 2
        "done",                  # terminate loop
        "App should start",      # expected_behavior
        "Error message shown",   # actual_behavior
        "4",                     # severity
    ]
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        result = runner.invoke(feedback_app, ["bug"])
    assert result.exit_code == 0
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    data = json.loads(files[0].read_text())
    assert data["type"] == "bug"
    assert data["summary"] == "Crash on startup"
    assert data["steps_to_reproduce"] == ["sscli new myapp", "select python-saas"]
    assert data["expected_behavior"] == "App should start"
    assert data["actual_behavior"] == "Error message shown"
    assert data["severity"] == "4"
    assert "system" not in data


def test_bug_report_with_context(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = ["Network error", "step1", "done", "Works", "Fails", "3"]
    with patch("rich.prompt.Confirm.ask", return_value=True), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        result = runner.invoke(feedback_app, ["bug"])
    assert result.exit_code == 0
    data = json.loads(
        list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))[0].read_text()
    )
    assert "system" in data
    assert "user" in data


def test_bug_report_empty_steps_list(tmp_path, monkeypatch):
    """Immediate 'done' produces an empty steps_to_reproduce list."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = ["Quick bug", "done", "Expected to work", "Failed hard", "2"]
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        result = runner.invoke(feedback_app, ["bug"])
    assert result.exit_code == 0
    data = json.loads(
        list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))[0].read_text()
    )
    assert data["steps_to_reproduce"] == []


def test_bug_report_step_with_secret_is_redacted(tmp_path, monkeypatch):
    """Steps containing secrets are redacted before saving."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = ["Token leak", "token=leaked123", "done", "Private", "Visible", "5"]
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        runner.invoke(feedback_app, ["bug"])
    data = json.loads(
        list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))[0].read_text()
    )
    assert "leaked123" not in data["steps_to_reproduce"][0]
    assert "REDACTED" in data["steps_to_reproduce"][0]


# ── feature_request ───────────────────────────────────────────────────────────

def test_feature_request_no_context_all_fields(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = [
        "Auto-deploy to Render",     # feature_summary
        "Manual deploys take time",  # problem_statement
        "sscli deploy --env prod",   # use_case
        "5",                         # priority
    ]
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        result = runner.invoke(feedback_app, ["feature"])
    assert result.exit_code == 0
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    data = json.loads(files[0].read_text())
    assert data["type"] == "feature"
    assert data["feature_summary"] == "Auto-deploy to Render"
    assert data["problem_statement"] == "Manual deploys take time"
    assert data["use_case"] == "sscli deploy --env prod"
    assert data["priority"] == "5"
    assert "system" not in data


def test_feature_request_with_context(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    prompts = ["Dark mode", "Eye strain", "Click a toggle", "2"]
    with patch("rich.prompt.Confirm.ask", return_value=True), \
         patch("rich.prompt.Prompt.ask", side_effect=prompts):
        result = runner.invoke(feedback_app, ["feature"])
    assert result.exit_code == 0
    data = json.loads(
        list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))[0].read_text()
    )
    assert "system" in data
    assert "user" in data


# ── nps_survey ────────────────────────────────────────────────────────────────

def _nps_data(tmp_path):
    files = list((tmp_path / ".sscli" / "feedback").glob("feedback_*.json"))
    return json.loads(files[0].read_text())


def test_nps_promoter_score_9(tmp_path, monkeypatch):
    """Score 9 → promoter path → stores 'reason', no 'improvement' or 'issue'."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=["9", "Love the templates"]):
        result = runner.invoke(feedback_app, ["nps"])
    assert result.exit_code == 0
    data = _nps_data(tmp_path)
    assert data["score"] == 9
    assert "reason" in data
    assert "improvement" not in data
    assert "issue" not in data


def test_nps_promoter_score_10(tmp_path, monkeypatch):
    """Score 10 → promoter path."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=["10", "Everything rocks!"]):
        result = runner.invoke(feedback_app, ["nps"])
    assert result.exit_code == 0
    data = _nps_data(tmp_path)
    assert data["score"] == 10
    assert "reason" in data


def test_nps_passive_score_7(tmp_path, monkeypatch):
    """Score 7 → passive path → stores 'improvement', no 'reason' or 'issue'."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=["7", "Better docs"]):
        result = runner.invoke(feedback_app, ["nps"])
    assert result.exit_code == 0
    data = _nps_data(tmp_path)
    assert data["score"] == 7
    assert "improvement" in data
    assert "reason" not in data
    assert "issue" not in data


def test_nps_passive_score_8(tmp_path, monkeypatch):
    """Score 8 → passive path."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=["8", "Onboarding"]):
        result = runner.invoke(feedback_app, ["nps"])
    assert result.exit_code == 0
    assert "improvement" in _nps_data(tmp_path)


def test_nps_detractor_score_6(tmp_path, monkeypatch):
    """Score 6 → detractor path → stores 'issue', no 'reason' or 'improvement'."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=["6", "Too complicated"]):
        result = runner.invoke(feedback_app, ["nps"])
    assert result.exit_code == 0
    data = _nps_data(tmp_path)
    assert data["score"] == 6
    assert "issue" in data
    assert "reason" not in data
    assert "improvement" not in data


def test_nps_detractor_score_0(tmp_path, monkeypatch):
    """Score 0 → detractor path."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=False), \
         patch("rich.prompt.Prompt.ask", side_effect=["0", "Everything broken"]):
        result = runner.invoke(feedback_app, ["nps"])
    assert result.exit_code == 0
    data = _nps_data(tmp_path)
    assert data["score"] == 0
    assert "issue" in data


def test_nps_with_context_includes_system_user(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(fb_mod.console, "print", MagicMock())
    with patch("rich.prompt.Confirm.ask", return_value=True), \
         patch("rich.prompt.Prompt.ask", side_effect=["9", "Great!"]):
        result = runner.invoke(feedback_app, ["nps"])
    assert result.exit_code == 0
    data = _nps_data(tmp_path)
    assert "system" in data
    assert "user" in data


# ── list_feedback ─────────────────────────────────────────────────────────────

def test_list_feedback_no_dir_prints_not_found(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["list"])
    assert result.exit_code == 0
    assert any("No feedback submissions found" in s for s in printed)


def test_list_feedback_empty_dir_prints_not_found(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    (tmp_path / ".sscli" / "feedback").mkdir(parents=True)
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["list"])
    assert result.exit_code == 0
    assert any("No feedback submissions found" in s for s in printed)


def test_list_feedback_quick_item_displayed(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    fb_dir = tmp_path / ".sscli" / "feedback"
    fb_dir.mkdir(parents=True)
    item = {
        "type": "quick",
        "message": "Great tool!",
        "system": {"timestamp": "2026-01-01T00:00:00"},
    }
    (fb_dir / "feedback_20260101_000000.json").write_text(json.dumps(item))
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["list"])
    assert result.exit_code == 0
    output = " ".join(printed)
    assert "feedback_20260101_000000.json" in output
    assert "quick" in output


def test_list_feedback_bug_item_displayed(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    fb_dir = tmp_path / ".sscli" / "feedback"
    fb_dir.mkdir(parents=True)
    (fb_dir / "feedback_20260102_000000.json").write_text(
        json.dumps({"type": "bug", "summary": "App crashes", "system": {"timestamp": ""}})
    )
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["list"])
    assert result.exit_code == 0
    assert any("bug" in s for s in printed)


def test_list_feedback_feature_item_displayed(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    fb_dir = tmp_path / ".sscli" / "feedback"
    fb_dir.mkdir(parents=True)
    (fb_dir / "feedback_20260103_000000.json").write_text(
        json.dumps({"type": "feature", "feature_summary": "Dark mode", "system": {"timestamp": ""}})
    )
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["list"])
    assert result.exit_code == 0
    assert any("feature" in s for s in printed)


def test_list_feedback_three_items_count(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    fb_dir = tmp_path / ".sscli" / "feedback"
    fb_dir.mkdir(parents=True)
    for i, t in enumerate(["quick", "bug", "feature"], 1):
        (fb_dir / f"feedback_2026010{i}_000000.json").write_text(json.dumps({"type": t}))
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["list"])
    assert result.exit_code == 0
    assert any("3 feedback submission" in s for s in printed)


# ── export_feedback ───────────────────────────────────────────────────────────

def test_export_feedback_no_dir_prints_message(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["export"])
    assert result.exit_code == 0
    assert any("No feedback to export" in s for s in printed)


def test_export_feedback_empty_dir_prints_message(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    (tmp_path / ".sscli" / "feedback").mkdir(parents=True)
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["export"])
    assert result.exit_code == 0
    assert any("No feedback to export" in s for s in printed)


def test_export_feedback_single_file_custom_output(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    fb_dir = tmp_path / ".sscli" / "feedback"
    fb_dir.mkdir(parents=True)
    (fb_dir / "feedback_20260101_000000.json").write_text(
        json.dumps({"type": "quick", "message": "hello"})
    )
    out = str(tmp_path / "out.json")
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["export", "--output", out])
    assert result.exit_code == 0
    assert any("Exported" in s for s in printed)
    exported = json.loads(Path(out).read_text())
    assert len(exported) == 1
    assert exported[0]["type"] == "quick"


def test_export_feedback_multiple_files(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    fb_dir = tmp_path / ".sscli" / "feedback"
    fb_dir.mkdir(parents=True)
    for i in range(3):
        (fb_dir / f"feedback_2026010{i+1}_000000.json").write_text(
            json.dumps({"type": "quick", "idx": i})
        )
    out = str(tmp_path / "multi.json")
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["export", "--output", out])
    assert result.exit_code == 0
    exported = json.loads(Path(out).read_text())
    assert len(exported) == 3
    assert any("3 feedback item" in s for s in printed)


def test_export_feedback_default_output_path(tmp_path, monkeypatch):
    """Default output is 'feedback_export.json' written to CWD."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    fb_dir = tmp_path / ".sscli" / "feedback"
    fb_dir.mkdir(parents=True)
    (fb_dir / "feedback_20260101_000000.json").write_text(json.dumps({"type": "nps", "score": 9}))
    printed = _capture(monkeypatch)
    result = runner.invoke(feedback_app, ["export"])
    assert result.exit_code == 0
    assert any("Exported" in s for s in printed)
    # Clean up default output file if created in cwd
    default = Path("feedback_export.json")
    if default.exists():
        default.unlink()
