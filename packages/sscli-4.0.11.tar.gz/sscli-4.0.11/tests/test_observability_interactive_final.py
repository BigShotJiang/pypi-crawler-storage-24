"""
Final comprehensive tests for observability_interactive.py to achieve 95%+ coverage.
Covers cancellations, error paths, and edge cases.
"""

import json
import sys
from types import SimpleNamespace, ModuleType
from pathlib import Path
import pytest

from foundry.actions import observability_interactive


def test_observability_menu_user_cancels(monkeypatch):
    """Test menu when user cancels (returns None)."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )
    
    # Should exit cleanly without crashing
    observability_interactive.observability_menu()


def test_interactive_diff_user_cancels_project_path(monkeypatch):
    """Test diff when user cancels project path input."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_diff()
    
    assert any("Cancelled" in str(msg) for msg in printed)


def test_interactive_diff_user_cancels_output_format(monkeypatch):
    """Test diff when user cancels output format selection."""
    responses = iter([".", None])  # First returns path, second returns None
    
    def mock_input(*args, **kwargs):
        return SimpleNamespace(ask=lambda: next(responses))
    
    monkeypatch.setattr(observability_interactive.questionary, "text", mock_input)
    monkeypatch.setattr(observability_interactive.questionary, "select", mock_input)
    
    monkeypatch.setattr(
        observability_interactive,
        "compute_diff",
        lambda **k: f"Diff with format={k.get('format')}"
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda *a, **k: printed.append(str(a)))
    
    observability_interactive.interactive_diff()
    
    # Should handle None output_format and default to "colored"
    assert any("complete" in str(msg) for msg in printed)


def test_interactive_diff_compute_error(monkeypatch):
    """Test diff when compute_diff raises exception."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: "colored"),
    )
    
    def raise_error(**kwargs):
        raise ValueError("Git repository not found")
    
    monkeypatch.setattr(observability_interactive, "compute_diff", raise_error)
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_diff()
    
    assert any("Error" in str(msg) and "Git repository" in str(msg) for msg in printed)


def test_interactive_workspace_create_user_cancels_template(monkeypatch):
    """Test workspace creation when user cancels template selection."""
    import foundry.utils
    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas")],
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_create()
    
    assert any("Cancelled" in str(msg) for msg in printed)


def test_interactive_workspace_create_no_compatible_features(monkeypatch):
    """Test workspace creation when template has no compatible features."""
    import foundry.utils
    
    # Create a mock module for foundry.features
    mock_features = ModuleType("foundry.features")
    mock_features. AVAILABLE_EXTENSIONS = {"commerce": {"templates": ["python-saas"]}}
    
    monkeypatch.setitem(sys.modules, "foundry.features", mock_features)
    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="test-template")],
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: "test-template"),
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_create()
    
    assert any("No features available" in str(msg) for msg in printed)


def test_interactive_workspace_create_user_cancels_feature(monkeypatch):
    """Test workspace creation when user cancels feature selection."""
    import foundry.utils
    
    # Create a mock module for foundry.features
    mock_features = ModuleType("foundry.features")
    mock_features.AVAILABLE_EXTENSIONS = {"commerce": {"templates": ["python-saas"]}}
    
    responses = iter(["python-saas", None])  # Template selected, then feature cancelled
    
    monkeypatch.setitem(sys.modules, "foundry.features", mock_features)
    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas")],
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(responses)),
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_create()
    
    assert any("Cancelled" in str(msg) for msg in printed)


def test_interactive_workspace_create_user_cancels_output_path(monkeypatch):
    """Test workspace creation when user cancels output path input."""
    import foundry.utils
    
    # Create a mock module for foundry.features
    mock_features = ModuleType("foundry.features")
    mock_features.AVAILABLE_EXTENSIONS = {"commerce": {"templates": ["python-saas"]}}
    
    select_responses = iter(["python-saas", "commerce"])
    
    monkeypatch.setitem(sys.modules, "foundry.features", mock_features)
    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas")],
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_responses)),
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),  # Cancel output path
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_create()
    
    assert any("Cancelled" in str(msg) for msg in printed)


def test_interactive_workspace_create_error(monkeypatch):
    """Test workspace creation when create_feature_workspace raises exception."""
    import foundry.utils
    
    # Create a mock module for foundry.features
    mock_features = ModuleType("foundry.features")
    mock_features.AVAILABLE_EXTENSIONS = {"commerce": {"templates": ["python-saas"]}}
    
    select_responses = iter(["python-saas", "commerce"])
    
    monkeypatch.setitem(sys.modules, "foundry.features", mock_features)
    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas")],
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_responses)),
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "./test-workspace"),
    )
    
    def raise_error(**kwargs):
        raise RuntimeError("Failed to create workspace")
    
    monkeypatch.setattr(observability_interactive, "create_feature_workspace", raise_error)
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_create()
    
    assert any("Error" in str(msg) and "Failed to create" in str(msg) for msg in printed)


def test_interactive_workspace_list_user_cancels(monkeypatch):
    """Test workspace list when user cancels search path input."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )
    
    # Should exit cleanly without printing anything
    observability_interactive.interactive_workspace_list()


def test_interactive_workspace_list_no_workspaces(monkeypatch):
    """Test workspace list when no workspaces are found."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )
    monkeypatch.setattr(observability_interactive, "list_workspaces", lambda path: [])
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_list()
    
    assert any("No workspaces found" in str(msg) for msg in printed)


def test_interactive_workspace_list_error(monkeypatch):
    """Test workspace list when list_workspaces raises exception."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )
    
    def raise_error(path):
        raise PermissionError("Cannot access directory")
    
    monkeypatch.setattr(observability_interactive, "list_workspaces", raise_error)
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_list()
    
    assert any("Error" in str(msg) and "Cannot access" in str(msg) for msg in printed)


def test_interactive_view_metadata_user_cancels(monkeypatch):
    """Test view metadata when user cancels project path input."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: None),
    )
    
    # Should exit cleanly without printing anything
    observability_interactive.interactive_view_metadata()


def test_interactive_view_metadata_error(tmp_path, monkeypatch):
    """Test view metadata when JSON file is corrupted."""
    metadata_file = tmp_path / ".sscli-metadata.json"
    metadata_file.write_text("{ invalid json }", encoding="utf-8")
    
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: str(tmp_path)),
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_view_metadata()
    
    assert any("Error" in str(msg) for msg in printed)


def test_interactive_workspace_create_success(monkeypatch, tmp_path):
    """Test successful workspace creation (covers success path lines 151-155)."""
    import foundry.utils
    
    # Create a mock module for foundry.features
    mock_features = ModuleType("foundry.features")
    mock_features.AVAILABLE_EXTENSIONS = {"commerce": {"templates": ["python-saas"]}}
    
    select_responses = iter(["python-saas", "commerce"])
    
    monkeypatch.setitem(sys.modules, "foundry.features", mock_features)
    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas")],
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_responses)),
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: str(tmp_path / "test-workspace")),
    )
    
    # Mock successful workspace creation
    monkeypatch.setattr(
        observability_interactive,
        "create_feature_workspace",
        lambda **k: str(tmp_path / "test-workspace")
    )
    
    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))
    
    observability_interactive.interactive_workspace_create()
    
    # Verify success messages including "Next steps"
    output = "\n".join(str(m) for m in printed)
    assert "Workspace created" in output
    assert "Next steps" in output
    assert "cd" in output
    assert "sscli obs diff" in output


def test_interactive_workspace_create_supports_dict_contract(monkeypatch, tmp_path):
    import foundry.utils

    mock_features = ModuleType("foundry.features")
    mock_features.AVAILABLE_EXTENSIONS = {"commerce": {"templates": ["python-saas"]}}

    select_responses = iter(["python-saas", "commerce"])

    monkeypatch.setitem(sys.modules, "foundry.features", mock_features)
    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas")],
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_responses)),
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: str(tmp_path / "test-workspace")),
    )
    monkeypatch.setattr(
        observability_interactive,
        "create_feature_workspace",
        lambda **k: {
            "success": True,
            "workspace_path": str(tmp_path / "test-workspace"),
            "files_created": 3,
        },
    )

    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg: printed.append(msg))

    observability_interactive.interactive_workspace_create()

    output = "\n".join(str(m) for m in printed)
    assert "Workspace created" in output
    assert str(tmp_path / "test-workspace") in output


def test_interactive_workspace_list_success(monkeypatch):
    """Test successful workspace listing with results (covers success path lines 180-186)."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )
    
    # Mock list_workspaces to return workspace data
    mock_workspaces = [
        {
            "workspace_id": "commerce-ws-001",
            "feature_name": "commerce",
            "template_name": "python-saas",
            "files_included": 15,
            "created_at": "2024-02-27T10:00:00",
        },
        {
            "workspace_id": "tunnel-ws-002",
            "feature_name": "tunnel",
            "template_name": "python-saas",
            "files_included": 8,
            "created_at": "2024-02-27T11:00:00",
        },
    ]
    monkeypatch.setattr(observability_interactive, "list_workspaces", lambda path: mock_workspaces)
    
    printed = []
    # Allow console.print to be called with or without arguments
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg=None: printed.append(msg))
    
    observability_interactive.interactive_workspace_list()
    
    # Verify workspace details are printed
    output = "\n".join(str(m) for m in printed if m is not None)
    assert "Found 2 workspace(s)" in output
    assert "commerce-ws-001" in output
    assert "tunnel-ws-002" in output
    assert "commerce" in output
    assert "tunnel" in output
    assert "15" in output  # files_included for first workspace
    assert "8" in output  # files_included for second workspace


def test_interactive_workspace_list_supports_dict_contract(monkeypatch):
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )

    payload = {
        "success": True,
        "search_path": ".",
        "workspaces_found": 1,
        "workspaces": [
            {
                "workspace_id": "commerce-ws-001",
                "feature_name": "commerce",
                "template_name": "python-saas",
                "files_included": 15,
                "created_at": "2024-02-27T10:00:00",
            }
        ],
    }
    monkeypatch.setattr(observability_interactive, "list_workspaces", lambda path: payload)

    printed = []
    monkeypatch.setattr(observability_interactive.console, "print", lambda msg=None: printed.append(msg))

    observability_interactive.interactive_workspace_list()

    output = "\n".join(str(m) for m in printed if m is not None)
    assert "Found 1 workspace(s)" in output
    assert "commerce-ws-001" in output


# ---------------------------------------------------------------------------
# TASK 3 — New gap-closing tests
# ---------------------------------------------------------------------------

def test_workspace_create_failure_dict(monkeypatch):
    """create_feature_workspace returns dict with success=False → prints error and returns."""
    import foundry.utils

    mock_features = ModuleType("foundry.features")
    mock_features.AVAILABLE_EXTENSIONS = {"commerce": {"templates": ["python-saas"]}}
    monkeypatch.setitem(sys.modules, "foundry.features", mock_features)

    monkeypatch.setattr(
        foundry.utils,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas")],
    )
    monkeypatch.setattr(
        foundry.utils,
        "get_template_info",
        lambda name: {},
    )

    select_responses = iter(["python-saas", "commerce"])
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_responses)),
    )
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "./test-output"),
    )
    monkeypatch.setattr(
        observability_interactive,
        "create_feature_workspace",
        lambda **kwargs: {"success": False, "error": "Not enough space"},
    )

    printed = []
    monkeypatch.setattr(
        observability_interactive.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )

    observability_interactive.interactive_workspace_create()

    output = "\n".join(printed)
    assert "Not enough space" in output


def test_workspace_list_returns_plain_list(monkeypatch):
    """list_workspaces returns a plain list (backward compat path, isinstance list branch)."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )

    plain_list = [
        {
            "workspace_id": "ws1",
            "feature_name": "auth",
            "template_name": "python-saas",
            "files_included": 10,
            "created_at": "2024-03-01T10:00:00",
        }
    ]
    monkeypatch.setattr(
        observability_interactive,
        "list_workspaces",
        lambda path: plain_list,
    )

    printed = []
    monkeypatch.setattr(
        observability_interactive.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )

    observability_interactive.interactive_workspace_list()

    output = "\n".join(printed)
    assert "Found 1 workspace(s)" in output
    assert "ws1" in output


def test_workspace_list_empty_workspaces_from_dict(monkeypatch):
    """list_workspaces returns dict with empty workspaces list → prints 'No workspaces found'."""
    monkeypatch.setattr(
        observability_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "."),
    )
    monkeypatch.setattr(
        observability_interactive,
        "list_workspaces",
        lambda path: {"workspaces": []},
    )

    printed = []
    monkeypatch.setattr(
        observability_interactive.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )

    observability_interactive.interactive_workspace_list()

    output = "\n".join(printed)
    assert "No workspaces found" in output


def test_observability_menu_list_then_back(monkeypatch):
    """Select 'list', list runs, loop iterates, then select 'back' exits (covers 46->20)."""
    menu_calls = iter(["list", "back"])
    monkeypatch.setattr(
        observability_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(menu_calls)),
    )

    listed = {"count": 0}
    monkeypatch.setattr(
        observability_interactive,
        "interactive_workspace_list",
        lambda: listed.__setitem__("count", listed["count"] + 1),
    )
    monkeypatch.setattr(observability_interactive, "pause", lambda: None)

    observability_interactive.observability_menu()

    assert listed["count"] == 1
