"""
Coverage tests for foundry/actions/generator.py — run_generator happy paths,
error branches, dry-run, interactive mode, and all feature flags.
"""
import shutil
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch, call

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_tracker():
    tracker = MagicMock()
    tracker.init_project = MagicMock()
    return tracker


def _base_patches():
    """Return a dict of patch targets that every test that reaches
    the download path needs to neutralise."""
    return {
        "foundry.actions.generator.check_tier_access": True,
        "foundry.actions.generator.download_template": True,
        "foundry.actions.generator.inject_metadata": None,
        "foundry.actions.generator.validate_and_fix_pyproject": None,
        "foundry.actions.generator.disable_linters": None,
        "foundry.actions.generator.apply_landing_blueprint": None,
        "foundry.actions.generator.setup_secrets": None,
        "foundry.actions.generator.inject_features": None,
        "foundry.actions.generator.regenerate_poetry_lock": None,
        "foundry.actions.generator.MetadataTracker": MagicMock,
        "foundry.actions.generator.get_template_info": lambda name: {"tier": "free"},
        "foundry.actions.generator.initialize_github_repo": None,
    }


# ---------------------------------------------------------------------------
# Interactive mode
# ---------------------------------------------------------------------------

class TestInteractiveMode:
    def test_interactive_config_none_returns_early(self, tmp_path, monkeypatch):
        """When get_interactive_config returns None, run_generator exits early."""
        from foundry.actions.generator import run_generator

        monkeypatch.setattr(
            "foundry.actions.generator.get_interactive_config", lambda _: None
        )
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )
        # Should return without error
        run_generator(interactive=True)
        # No "Deploying" message should appear
        assert not any("Deploying" in str(m) for m in printed)

    def test_interactive_config_sets_all_fields(self, tmp_path, monkeypatch):
        """Interactive mode reads all flags from config dict."""
        from foundry.actions.generator import run_generator

        config = dict(
            template_name="python-saas",
            app_name="my-app",
            with_commerce=False,
            with_tunnel=False,
            with_landing=False,
            with_admin=False,
            with_sqlite=False,
            with_ingestor=False,
            with_auth=False,
            with_merchant_dashboard=False,
            use_linters=True,
            use_ast_injection=False,
            secrets_strategy="Dotenv (Standard .env files)",
            github_config=None,
        )
        monkeypatch.setattr(
            "foundry.actions.generator.get_interactive_config", lambda _: config
        )
        # Provide fake target path via questionary
        monkeypatch.setattr(
            "foundry.actions.generator.questionary",
            SimpleNamespace(
                text=lambda *a, **k: SimpleNamespace(ask=lambda: str(tmp_path / "out"))
            ),
        )
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr("foundry.actions.generator.download_template", lambda *a, **k: True)
        monkeypatch.setattr("foundry.actions.generator.inject_metadata", MagicMock())
        monkeypatch.setattr("foundry.actions.generator.validate_and_fix_pyproject", MagicMock())
        monkeypatch.setattr("foundry.actions.generator.setup_secrets", MagicMock())
        monkeypatch.setattr("foundry.actions.generator.inject_features", MagicMock())
        monkeypatch.setattr("foundry.actions.generator.regenerate_poetry_lock", MagicMock())
        mock_tracker = MagicMock()
        monkeypatch.setattr("foundry.actions.generator.MetadataTracker", lambda **kw: mock_tracker)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(interactive=True)
        mock_tracker.init_project.assert_called_once()


# ---------------------------------------------------------------------------
# Tier access guard
# ---------------------------------------------------------------------------

class TestTierAccessGuard:
    def test_blocked_tier_returns_early(self, monkeypatch):
        """check_tier_access returning False causes early exit."""
        from foundry.actions.generator import run_generator

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "pro"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: False
        )
        download = MagicMock()
        monkeypatch.setattr("foundry.actions.generator.download_template", download)

        run_generator(template_name="python-saas", app_name="app")
        download.assert_not_called()

    def test_allowed_tier_proceeds(self, tmp_path, monkeypatch):
        """check_tier_access returning True proceeds past the guard."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        download = MagicMock(return_value=False)  # Return False to stop early
        monkeypatch.setattr("foundry.actions.generator.download_template", download)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name="python-saas", app_name="app", target_dir_name=str(tmp_path / "new"))
        download.assert_called_once()


# ---------------------------------------------------------------------------
# Target path resolution
# ---------------------------------------------------------------------------

class TestTargetPathResolution:
    def test_no_template_name_prints_error(self, monkeypatch):
        """Missing template_name triggers an error message."""
        from foundry.actions.generator import run_generator

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name=None)
        assert any("Template name required" in str(m) for m in printed)

    def test_existing_non_empty_dir_prints_error(self, tmp_path, monkeypatch):
        """A non-empty target directory causes an error."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        target = tmp_path / "project"
        target.mkdir()
        (target / "file.txt").write_text("exists")

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name="python-saas", target_dir_name=str(target))
        assert any("already exists" in str(m) for m in printed)

    def test_download_failure_returns_early(self, tmp_path, monkeypatch):
        """download_template returning False stops execution."""
        from foundry.actions.generator import run_generator

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.download_template", lambda *a, **k: False
        )
        inject = MagicMock()
        monkeypatch.setattr("foundry.actions.generator.inject_metadata", inject)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name="python-saas", target_dir_name=str(tmp_path / "new"))
        inject.assert_not_called()


# ---------------------------------------------------------------------------
# Dry-run mode
# ---------------------------------------------------------------------------

class TestDryRun:
    def _run_dry(self, monkeypatch, **kwargs):
        from foundry.actions.generator import run_generator

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_feature_tier_access", lambda *a: True
        )
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )
        run_generator(template_name="python-saas", app_name="demo", dry_run=True, **kwargs)
        return printed

    def test_dry_run_no_features_shows_preview(self, monkeypatch):
        """Dry-run without features prints preview and no changes."""
        msgs = self._run_dry(monkeypatch)
        assert any("DRY-RUN" in str(m) for m in msgs)
        assert any("no changes" in str(m).lower() for m in msgs)

    def test_dry_run_with_commerce(self, monkeypatch):
        """Dry-run with commerce flag shows commerce config item."""
        msgs = self._run_dry(monkeypatch, with_commerce=True)
        assert any("Commerce" in str(m) for m in msgs)

    def test_dry_run_with_payment(self, monkeypatch):
        """Dry-run with payment flag shows payment config item."""
        msgs = self._run_dry(monkeypatch, with_payment=True)
        assert any("Payment" in str(m) for m in msgs)

    def test_dry_run_with_tunnel(self, monkeypatch):
        """Dry-run with tunnel flag shows tunneling config item."""
        msgs = self._run_dry(monkeypatch, with_tunnel=True)
        assert any("tunnel" in str(m).lower() or "ngrok" in str(m).lower() for m in msgs)

    def test_dry_run_with_landing(self, monkeypatch):
        """Dry-run with landing flag shows landing page config item."""
        msgs = self._run_dry(monkeypatch, with_landing=True)
        assert any("Landing" in str(m) for m in msgs)

    def test_dry_run_with_admin(self, monkeypatch):
        msgs = self._run_dry(monkeypatch, with_admin=True)
        assert any("admin" in str(m).lower() or "NiceGUI" in str(m) for m in msgs)

    def test_dry_run_with_sqlite(self, monkeypatch):
        msgs = self._run_dry(monkeypatch, with_sqlite=True)
        assert any("SQLite" in str(m) for m in msgs)

    def test_dry_run_with_ingestor(self, monkeypatch):
        msgs = self._run_dry(monkeypatch, with_ingestor=True)
        assert any("ingestor" in str(m).lower() or "data ingestor" in str(m).lower() for m in msgs)

    def test_dry_run_with_all_features(self, monkeypatch):
        """Dry-run with all features shows all config items."""
        msgs = self._run_dry(
            monkeypatch,
            with_commerce=True, with_payment=True,
            with_landing=True, with_sqlite=True,
            use_linters=True,
        )
        assert any("Linters" in str(m) for m in msgs)

    @pytest.mark.parametrize(
        "blocked_flag",
        [
            {"with_tunnel": True},
            {"with_admin": True},
            {"with_ingestor": True},
            {"with_auth": True},
            {"with_merchant_dashboard": True},
        ],
    )
    def test_guarded_flags_skip_generation(self, monkeypatch, blocked_flag):
        from foundry.actions.generator import run_generator

        download_called = {"called": False}
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )

        def fake_download(*args, **kwargs):
            download_called["called"] = True
            return True

        monkeypatch.setattr("foundry.actions.generator.download_template", fake_download)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name="python-saas", app_name="demo", dry_run=True, **blocked_flag)
        assert download_called["called"] is False


# ---------------------------------------------------------------------------
# Happy path generation
# ---------------------------------------------------------------------------

class TestHappyPathGeneration:
    def _setup(self, tmp_path, monkeypatch, template="python-saas", **extra):
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        target = tmp_path / "new-project"

        inject_meta = MagicMock()
        validate_pyproject = MagicMock()
        setup_secrets_mock = MagicMock()
        inject_features_mock = MagicMock()
        regen_lock = MagicMock()
        disable_lint = MagicMock()
        apply_blueprint = MagicMock()
        init_repo = MagicMock()
        tracker = MagicMock()

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.download_template", lambda *a, **k: True
        )
        monkeypatch.setattr("foundry.actions.generator.inject_metadata", inject_meta)
        monkeypatch.setattr("foundry.actions.generator.validate_and_fix_pyproject", validate_pyproject)
        monkeypatch.setattr("foundry.actions.generator.setup_secrets", setup_secrets_mock)
        monkeypatch.setattr("foundry.actions.generator.inject_features", inject_features_mock)
        monkeypatch.setattr("foundry.actions.generator.regenerate_poetry_lock", regen_lock)
        monkeypatch.setattr("foundry.actions.generator.disable_linters", disable_lint)
        monkeypatch.setattr("foundry.actions.generator.apply_landing_blueprint", apply_blueprint)
        monkeypatch.setattr("foundry.actions.generator.initialize_github_repo", init_repo)
        monkeypatch.setattr("foundry.actions.generator.MetadataTracker", lambda **kw: tracker)
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        mocks = dict(
            target=target,
            inject_meta=inject_meta,
            validate_pyproject=validate_pyproject,
            setup_secrets_mock=setup_secrets_mock,
            inject_features_mock=inject_features_mock,
            regen_lock=regen_lock,
            disable_lint=disable_lint,
            apply_blueprint=apply_blueprint,
            init_repo=init_repo,
            tracker=tracker,
            printed=printed,
        )

        run_generator(
            template_name=template,
            app_name="new-project",
            target_dir_name=str(target),
            **extra,
        )
        return mocks

    def test_inject_metadata_called(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        m["inject_meta"].assert_called_once()

    def test_validate_pyproject_called(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        m["validate_pyproject"].assert_called_once()

    def test_setup_secrets_called(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        m["setup_secrets_mock"].assert_called_once()

    def test_inject_features_called(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        m["inject_features_mock"].assert_called_once()

    def test_regen_lock_called(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        m["regen_lock"].assert_called_once()

    def test_tracker_init_project_called(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        m["tracker"].init_project.assert_called_once()


    def test_success_message_printed(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        assert any("Success" in str(msg) for msg in m["printed"])

    def test_disable_linters_called_when_requested(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch, use_linters=False)
        m["disable_lint"].assert_called_once()

    def test_disable_linters_not_called_by_default(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch, use_linters=True)
        m["disable_lint"].assert_not_called()

    def test_apply_landing_blueprint_called_for_static_landing(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch, template="static-landing")
        m["apply_blueprint"].assert_called_once()

    def test_apply_landing_blueprint_not_called_for_python_saas(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch, template="python-saas")
        m["apply_blueprint"].assert_not_called()

    def test_github_repo_init_called_when_config_provided(self, tmp_path, monkeypatch):
        gh_cfg = {"name": "my-repo", "private": True}
        m = self._setup(tmp_path, monkeypatch, github_config=gh_cfg)
        m["init_repo"].assert_called_once()

    def test_github_repo_init_not_called_without_config(self, tmp_path, monkeypatch):
        m = self._setup(tmp_path, monkeypatch)
        m["init_repo"].assert_not_called()

    def test_features_dir_removed_for_non_python_saas(self, tmp_path, monkeypatch):
        """features/ dir is cleaned up for non-python-saas templates."""
        target = tmp_path / "new-project"
        # NOTE: do NOT pre-create target — the non-empty check would abort.
        # download_template mock creates the features dir to simulate post-download state.
        features_dir = target / "features"

        def fake_download(template_name, template_info, path):
            path.mkdir(parents=True, exist_ok=True)
            (path / "features").mkdir()
            return True

        from foundry.actions.generator import run_generator

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.download_template", fake_download
        )
        for fn in [
            "inject_metadata", "validate_and_fix_pyproject", "setup_secrets",
            "inject_features", "regenerate_poetry_lock",
        ]:
            monkeypatch.setattr(f"foundry.actions.generator.{fn}", MagicMock())
        monkeypatch.setattr("foundry.actions.generator.MetadataTracker", lambda **kw: MagicMock())
        monkeypatch.setattr(
            "foundry.actions.generator.console", SimpleNamespace(print=MagicMock())
        )

        run_generator(
            template_name="react-client",
            app_name="new-project",
            target_dir_name=str(target),
        )
        assert not features_dir.exists()

    def test_features_dir_kept_for_python_saas(self, tmp_path, monkeypatch):
        """features/ dir is NOT removed for python-saas."""
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "new-project"
        features_dir = target / "features"

        def fake_download(template_name, template_info, path):
            path.mkdir(parents=True, exist_ok=True)
            (path / "features").mkdir()
            return True

        from foundry.actions.generator import run_generator

        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.download_template", fake_download
        )
        for fn in [
            "inject_metadata", "validate_and_fix_pyproject", "setup_secrets",
            "inject_features", "regenerate_poetry_lock",
        ]:
            monkeypatch.setattr(f"foundry.actions.generator.{fn}", MagicMock())
        monkeypatch.setattr("foundry.actions.generator.MetadataTracker", lambda **kw: MagicMock())
        monkeypatch.setattr(
            "foundry.actions.generator.console", SimpleNamespace(print=MagicMock())
        )

        run_generator(
            template_name="python-saas",
            app_name="new-project",
            target_dir_name=str(target),
        )
        assert features_dir.exists()


# ---------------------------------------------------------------------------
# Exception handling
# ---------------------------------------------------------------------------

class TestExceptionHandling:
    def test_exception_during_download_logs_error(self, tmp_path, monkeypatch):
        """Exceptions inside the try block are caught and logged."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.download_template",
            lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")),
        )
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generator.console",
            SimpleNamespace(print=lambda msg: printed.append(msg)),
        )

        run_generator(template_name="python-saas", target_dir_name=str(tmp_path / "new"))
        assert any("boom" in str(m) for m in printed)

    def test_feature_metadata_collected_with_all_flags(self, tmp_path, monkeypatch):
        """Allowed feature flags produce correct metadata entries."""
        from foundry.actions.generator import run_generator

        monkeypatch.chdir(tmp_path)
        tracker = MagicMock()
        monkeypatch.setattr(
            "foundry.actions.generator.get_template_info", lambda _: {"tier": "free"}
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.check_feature_tier_access", lambda *a: True
        )
        monkeypatch.setattr(
            "foundry.actions.generator.download_template", lambda *a, **k: True
        )
        for fn in [
            "inject_metadata", "validate_and_fix_pyproject", "setup_secrets",
            "inject_features", "regenerate_poetry_lock",
        ]:
            monkeypatch.setattr(f"foundry.actions.generator.{fn}", MagicMock())
        monkeypatch.setattr("foundry.actions.generator.MetadataTracker", lambda **kw: tracker)
        monkeypatch.setattr(
            "foundry.actions.generator.console", SimpleNamespace(print=MagicMock())
        )

        run_generator(
            template_name="python-saas",
            app_name="app",
            target_dir_name=str(tmp_path / "new"),
            with_commerce=True,
            with_payment=True,
            with_landing=True,
            with_sqlite=True,
        )
        _, kwargs = tracker.init_project.call_args
        features = kwargs["features"]
        for feat in ["commerce", "payment", "landing", "sqlite-local"]:
            assert feat in features, f"{feat} missing from features_injected"
