"""Security regression tests for foundry/auth.py.

Each test class is labelled with the fix ID it covers:
  C-5  — _validate_request_url allowlist
  C-14 — Tier trust only from server (verify=False always returns 'free')
  H-1  — All requests use verify=True
  H-2  — allow_redirects=False on auth endpoints
  H-3  — verification_uri validated before webbrowser.open
  H-4  — 401/403 in polling loop raises SystemExit
  H-5  — poll_response.text sanitized (no newlines, ≤200 chars)
  H-24 — TOCTOU replaced with try/except (FileNotFoundError / JSONDecodeError)
  M-7  — Credentials file 0o600, parent dir 0o700

Tests must FAIL on the old vulnerable code and PASS with the current fixed code.
"""
import json
import os
import stat
from unittest.mock import MagicMock, patch

import pytest

import foundry.auth as auth_module
from foundry.auth import (
    _validate_request_url,
    get_current_license_info,
    get_access_token,
    save_credentials,
)


# ---------------------------------------------------------------------------
# Helpers shared across tests
# ---------------------------------------------------------------------------

def _make_device_resp(uri="https://seedsource.dev/activate", interval=0):
    r = MagicMock()
    r.status_code = 200
    r.json.return_value = {
        "device_code": "dc_test",
        "user_code": "UC-1234",
        "verification_uri": uri,
        "interval": interval,
    }
    r.text = ""
    return r


def _make_poll_resp(status=200, access_token="tok_ok", tier="free", text="ok"):
    r = MagicMock()
    r.status_code = status
    r.json.return_value = {"access_token": access_token, "tier": tier}
    r.text = text
    return r


# ============================================================================
# C-5 — _validate_request_url allowlist
# ============================================================================

class TestValidateRequestUrl:
    """C-5: URL allowlist rejects anything outside seedsource.dev / localhost."""

    def test_http_evil_com_raises_value_error(self):
        with pytest.raises(ValueError, match="not in allowed list"):
            _validate_request_url("http://evil.com/steal-tokens")

    def test_https_auth_seedsource_passes(self):
        # Should complete without raising
        _validate_request_url("https://auth.seedsource.dev/api/something")

    def test_https_localhost_passes(self):
        _validate_request_url("https://localhost:8000/health")

    def test_http_localhost_passes(self):
        # HTTP is only acceptable for localhost
        _validate_request_url("http://localhost:8000/dev")

    def test_ftp_scheme_raises(self):
        with pytest.raises(ValueError):
            _validate_request_url("ftp://auth.seedsource.dev/path")

    def test_evil_subdomain_spoofing_raises(self):
        # evil.seedsource.dev.evil.com does NOT end with .seedsource.dev → rejected
        with pytest.raises(ValueError, match="not in allowed list"):
            _validate_request_url("https://evil.seedsource.dev.evil.com/path")

    def test_http_on_seedsource_raises(self):
        # HTTP over a real seedsource host must still be rejected
        with pytest.raises(ValueError):
            _validate_request_url("http://auth.seedsource.dev/api")


# ============================================================================
# C-14 — Tier trust only from server
# ============================================================================

class TestTierTrustOnlyFromServer:
    """C-14: verify=False must always return tier='free', ignoring local cache."""

    def test_cached_pro_returns_free_when_not_verifying(self, tmp_path, monkeypatch):
        creds = tmp_path / "credentials.json"
        creds.write_text(json.dumps({"access_token": "tok", "tier": "pro", "authorized": True}))
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds)

        info = get_current_license_info(verify=False)
        assert info["tier"] == "free", "C-14: verify=False must shadow local tier with 'free'"

    def test_tampered_enterprise_tier_returns_free(self, tmp_path, monkeypatch):
        creds = tmp_path / "credentials.json"
        creds.write_text(json.dumps({
            "access_token": "mallory_tok",
            "tier": "enterprise",
            "authorized": True,
        }))
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds)

        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"

    def test_missing_cache_verify_false_returns_free(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "nonexistent.json")

        info = get_current_license_info(verify=False)
        assert info["tier"] == "free"


# ============================================================================
# H-1 — All requests use verify=True
# ============================================================================

class TestTlsVerification:
    """H-1: requests.post / requests.get must never be called with verify=False."""

    def test_login_flow_posts_with_verify_true(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp()
        poll_resp = _make_poll_resp()

        with patch("requests.post", side_effect=[device_resp, poll_resp]) as mock_post, \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            try:
                auth_module.login_flow()
            except SystemExit:
                pass

        for c in mock_post.call_args_list:
            kwargs = c[1]  # keyword args dict
            assert kwargs.get("verify") is True, \
                f"H-1: requests.post called without verify=True: {c}"

    def test_validate_endpoint_get_with_verify_true(self, tmp_path, monkeypatch):
        creds = tmp_path / "credentials.json"
        creds.write_text(json.dumps({"access_token": "tok", "tier": "free", "authorized": True}))
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds)

        server_resp = MagicMock()
        server_resp.status_code = 200
        server_resp.json.return_value = {"tier": "free", "authorized": True, "access_token": "tok"}

        with patch("requests.get", return_value=server_resp) as mock_get:
            get_current_license_info(verify=True)

        for c in mock_get.call_args_list:
            kwargs = c[1]
            assert kwargs.get("verify") is True, \
                f"H-1: requests.get called without verify=True: {c}"

    def test_verify_false_never_passed_to_requests(self, tmp_path, monkeypatch):
        """Explicit regression: no call path may supply verify=False."""
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp()
        poll_resp = _make_poll_resp(status=404, text="expired")

        with patch("requests.post", side_effect=[device_resp, poll_resp]) as mock_post, \
             patch("requests.get") as mock_get, \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        all_calls = mock_post.call_args_list + mock_get.call_args_list
        for c in all_calls:
            kwargs = c[1]
            assert kwargs.get("verify") is not False, \
                f"H-1: verify=False detected in call: {c}"


# ============================================================================
# H-2 — allow_redirects=False on auth endpoints
# ============================================================================

class TestNoRedirects:
    """H-2: auth endpoint calls must set allow_redirects=False."""

    def test_device_code_request_no_redirects(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp()
        poll_resp = _make_poll_resp()

        with patch("requests.post", side_effect=[device_resp, poll_resp]) as mock_post, \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            try:
                auth_module.login_flow()
            except Exception:
                pass

        # First POST is the device/code request
        first_kwargs = mock_post.call_args_list[0][1]
        assert first_kwargs.get("allow_redirects") is False, \
            "H-2: device/code request must have allow_redirects=False"

    def test_poll_request_no_redirects(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp()
        poll_resp = _make_poll_resp()

        with patch("requests.post", side_effect=[device_resp, poll_resp]) as mock_post, \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            try:
                auth_module.login_flow()
            except Exception:
                pass

        # Second POST is the poll request
        if len(mock_post.call_args_list) >= 2:
            poll_kwargs = mock_post.call_args_list[1][1]
            assert poll_kwargs.get("allow_redirects") is False, \
                "H-2: poll request must have allow_redirects=False"

    def test_validate_endpoint_no_redirects(self, tmp_path, monkeypatch):
        creds = tmp_path / "credentials.json"
        creds.write_text(json.dumps({"access_token": "tok", "tier": "free", "authorized": True}))
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds)

        server_resp = MagicMock()
        server_resp.status_code = 200
        server_resp.json.return_value = {"tier": "free", "authorized": True, "access_token": "tok"}

        with patch("requests.get", return_value=server_resp) as mock_get:
            get_current_license_info(verify=True)

        call_kwargs = mock_get.call_args_list[0][1]
        assert call_kwargs.get("allow_redirects") is False, \
            "H-2: validate endpoint must have allow_redirects=False"


# ============================================================================
# H-3 — verification_uri validated before webbrowser.open
# ============================================================================

class TestVerificationUriValidation:
    """H-3: an attacker-controlled verification_uri must never reach webbrowser.open."""

    def test_evil_uri_does_not_open_browser(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp(uri="https://evil.com/phish")
        poll_resp = _make_poll_resp(status=404, text="expired")

        with patch("requests.post", side_effect=[device_resp, poll_resp]), \
             patch("webbrowser.open") as mock_browser, \
             patch("time.sleep"):
            auth_module.login_flow()

        mock_browser.assert_not_called()

    def test_http_uri_does_not_open_browser(self, tmp_path, monkeypatch):
        """Plain HTTP verification URIs must be blocked even for seedsource.dev."""
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp(uri="http://seedsource.dev/activate")
        poll_resp = _make_poll_resp(status=404, text="expired")

        with patch("requests.post", side_effect=[device_resp, poll_resp]), \
             patch("webbrowser.open") as mock_browser, \
             patch("time.sleep"):
            auth_module.login_flow()

        mock_browser.assert_not_called()

    def test_valid_seedsource_uri_opens_browser(self, tmp_path, monkeypatch):
        """Exact seedsource.dev host (in _ALLOWED_HOSTS) must reach webbrowser.open."""
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp(uri="https://seedsource.dev/activate")
        poll_resp = _make_poll_resp(status=404, text="expired")

        with patch("requests.post", side_effect=[device_resp, poll_resp]), \
             patch("webbrowser.open") as mock_browser, \
             patch("time.sleep"):
            auth_module.login_flow()

        mock_browser.assert_called_once_with("https://seedsource.dev/activate")


# ============================================================================
# H-4 — 401/403 in polling loop raises SystemExit
# ============================================================================

class TestPollingAuthFailure:
    """H-4: server-side credential rejection must immediately raise SystemExit."""

    def _run_with_poll_status(self, status: int, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")
        device_resp = _make_device_resp()
        poll_resp = _make_poll_resp(status=status, text="rejected")

        with patch("requests.post", side_effect=[device_resp, poll_resp]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

    def test_401_raises_system_exit(self, tmp_path, monkeypatch):
        with pytest.raises(SystemExit):
            self._run_with_poll_status(401, tmp_path, monkeypatch)

    def test_403_raises_system_exit(self, tmp_path, monkeypatch):
        with pytest.raises(SystemExit):
            self._run_with_poll_status(403, tmp_path, monkeypatch)


# ============================================================================
# H-5 — poll_response.text sanitized
# ============================================================================

class TestPollResponseSanitization:
    """H-5: error text from server must be truncated and stripped of newlines."""

    def test_multiline_text_sanitized(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "creds.json")

        device_resp = _make_device_resp()
        malicious_text = "line1\nline2\n" * 100  # 1 200+ chars with embedded newlines

        poll_resp = MagicMock()
        poll_resp.status_code = 503   # hits the else → sanitize branch
        poll_resp.text = malicious_text

        printed_chunks: list[str] = []

        def capture(*args, **kwargs):
            printed_chunks.extend(str(a) for a in args)

        monkeypatch.setattr(auth_module.console, "print", capture)

        with patch("requests.post", side_effect=[device_resp, poll_resp]), \
             patch("webbrowser.open"), \
             patch("time.sleep"):
            auth_module.login_flow()

        # Find the chunk that references 'line1' (the sanitized server error)
        error_chunks = [c for c in printed_chunks if "line1" in c or "line2" in c]
        assert error_chunks, "Expected at least one printed chunk containing sanitized server error"

        for chunk in error_chunks:
            # The format string may prepend a "\n" for Rich visual spacing — that is fine.
            # What must NOT appear is a raw newline WITHIN the server-supplied text payload.
            # Find the 'line1' position and inspect the payload portion.
            idx = chunk.find("line1")
            if idx == -1:
                idx = chunk.find("line2")
            payload = chunk[idx:]  # server text starts here
            assert "\n" not in payload, \
                f"H-5: server text payload must not contain raw newlines; got: {payload!r}"
            # The sanitized slice is capped at 200 chars; the whole chunk adds a tag prefix
            assert len(payload) <= 300, \
                f"H-5: sanitized server payload too long ({len(payload)} chars)"


# ============================================================================
# H-24 — TOCTOU replaced with try/except
# ============================================================================

class TestToctouSafety:
    """H-24: file operations must never surface FileNotFoundError or JSONDecodeError."""

    def test_missing_credentials_file_returns_defaults(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "nonexistent.json")

        # Must not raise
        result = get_current_license_info(verify=False)
        assert isinstance(result, dict)
        assert result.get("tier") == "free"

    def test_corrupted_json_returns_defaults(self, tmp_path, monkeypatch):
        creds = tmp_path / "credentials.json"
        creds.write_text("{INVALID:::JSON}")
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds)

        result = get_current_license_info(verify=False)
        assert isinstance(result, dict)
        assert result.get("tier") == "free"

    def test_missing_file_does_not_raise_file_not_found(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "gone.json")

        try:
            get_current_license_info(verify=False)
        except FileNotFoundError:
            pytest.fail("H-24: FileNotFoundError must not propagate from get_current_license_info")

    def test_corrupted_json_does_not_raise_json_decode_error(self, tmp_path, monkeypatch):
        import json as _json
        creds = tmp_path / "credentials.json"
        creds.write_text("[[[broken")
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds)

        try:
            get_current_license_info(verify=False)
        except _json.JSONDecodeError:
            pytest.fail("H-24: JSONDecodeError must not propagate from get_current_license_info")

    def test_get_access_token_missing_file_returns_none(self, tmp_path, monkeypatch):
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", tmp_path / "nope.json")
        assert get_access_token() is None

    def test_get_access_token_corrupted_json_returns_none(self, tmp_path, monkeypatch):
        creds = tmp_path / "credentials.json"
        creds.write_text("not json!!!")
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds)
        assert get_access_token() is None


# ============================================================================
# M-7 — License file permissions
# ============================================================================

class TestFilePermissions:
    """M-7: credentials file must be 0o600; parent directory must be 0o700."""

    def test_credentials_file_mode_is_0o600(self, tmp_path, monkeypatch):
        creds_file = tmp_path / "credentials.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_file)

        save_credentials({"access_token": "tok", "tier": "free"})

        file_mode = stat.S_IMODE(os.stat(creds_file).st_mode)
        assert file_mode == 0o600, \
            f"M-7: credentials.json must be 0o600, got {oct(file_mode)}"

    def test_credentials_dir_mode_is_0o700(self, tmp_path, monkeypatch):
        # Use a fresh subdirectory so mkdir is guaranteed to run
        creds_dir = tmp_path / "sscli_test_dir"
        creds_file = creds_dir / "credentials.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_file)

        save_credentials({"access_token": "tok", "tier": "free"})

        dir_mode = stat.S_IMODE(os.stat(creds_dir).st_mode)
        assert dir_mode == 0o700, \
            f"M-7: parent directory must be 0o700, got {oct(dir_mode)}"

    def test_file_not_world_readable(self, tmp_path, monkeypatch):
        """Explicit check: other users must have zero permissions."""
        creds_file = tmp_path / "credentials.json"
        monkeypatch.setattr(auth_module, "CREDENTIALS_FILE", creds_file)

        save_credentials({"access_token": "tok", "tier": "free"})

        file_mode = stat.S_IMODE(os.stat(creds_file).st_mode)
        # No group or other bits (rwx for group/other = 0o077)
        assert file_mode & 0o077 == 0, \
            f"M-7: credentials.json must not be readable by group/other, got {oct(file_mode)}"
