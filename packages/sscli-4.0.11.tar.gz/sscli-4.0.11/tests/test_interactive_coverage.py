"""
Comprehensive tests for foundry.interactive module.

Tests:
- Interactive menu flow
- Auth state handling
- Menu navigation
- Login/logout flows
- Feature menu access
- Developer tools access
- Animation handling
"""

from types import SimpleNamespace
import pytest


def test_interactive_menu_generate_project(monkeypatch):
    """Test generating a new project from interactive menu."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    
    called = {"generate": 0, "pause": 0}
    monkeypatch.setattr(
        interactive,
        "run_generator",
        lambda interactive: called.__setitem__("generate", called["generate"] + 1)
    )
    monkeypatch.setattr(interactive, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))
    
    choices = iter(["generate", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    interactive.interactive_menu()
    
    assert called["generate"] == 1
    assert called["pause"] == 1


def test_interactive_menu_manage_config(monkeypatch):
    """Test managing stack configuration from interactive menu."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    
    called = {"config": 0}
    monkeypatch.setattr(
        interactive,
        "manage_config_menu",
        lambda: called.__setitem__("config", called["config"] + 1)
    )
    
    choices = iter(["config", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    interactive.interactive_menu()
    
    assert called["config"] == 1


def test_interactive_menu_dev_tools_internal(monkeypatch):
    """Test dev tools menu is accessible for internal devs."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "pro"})
    monkeypatch.setattr(interactive, "is_internal_dev", lambda: True)
    
    called = {"dev_tools": 0}
    monkeypatch.setattr(
        interactive,
        "dev_tools_menu",
        lambda: called.__setitem__("dev_tools", called["dev_tools"] + 1)
    )
    
    choices = iter(["dev_tools", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    interactive.interactive_menu()
    
    assert called["dev_tools"] == 1


def test_interactive_menu_animations_disabled(monkeypatch):
    """Test interactive menu with animations disabled."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    
    choices = iter(["Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    printed = []
    monkeypatch.setattr(interactive.console, "print", lambda msg: printed.append(msg))
    
    interactive.interactive_menu()
    
    # Should print static banner
    assert len(printed) > 0


def test_interactive_menu_animations_enabled_but_fail(monkeypatch):
    """Test fallback when animations are available but fail."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", True)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mock animation engine to raise exception
    def fake_engine(*args, **kwargs):
        raise Exception("Animation failed")
    
    import foundry.animations
    monkeypatch.setattr(foundry.animations, "InteractiveAnimationEngine", fake_engine)
    
    choices = iter(["Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    printed = []
    monkeypatch.setattr(interactive.console, "print", lambda msg: printed.append(msg))
    
    # Should not crash, should show static banner
    interactive.interactive_menu()
    assert len(printed) > 0


def test_interactive_menu_keyboard_interrupt_during_animation(monkeypatch):
    """Test handling keyboard interrupt during animation."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", True)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    
    class FakeEngine:
        def __init__(self, *args, **kwargs):
            pass
        
        def play(self, animation):
            raise KeyboardInterrupt()
    
    import foundry.animations
    monkeypatch.setattr(foundry.animations, "InteractiveAnimationEngine", FakeEngine)
    monkeypatch.setattr(foundry.animations, "AnimationSequence", lambda x: None)
    
    printed = []
    monkeypatch.setattr(interactive.console, "print", lambda msg: printed.append(msg))
    
    interactive.interactive_menu()
    
    # Should print goodbye message
    assert any("Goodbye" in str(p) for p in printed)


def test_interactive_menu_login_failed(monkeypatch):
    """Test login flow failure handling."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(interactive, "login_flow", lambda: False)
    
    choices = iter(["login", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    printed = []
    monkeypatch.setattr(interactive.console, "print", lambda msg: printed.append(msg))
    
    interactive.interactive_menu()
    
    # Should show warning message
    assert any("not completed" in str(p) for p in printed)


def test_interactive_menu_login_exception(monkeypatch):
    """Test login flow exception handling."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    
    def fake_login():
        raise Exception("Network error")
    
    monkeypatch.setattr(interactive, "login_flow", fake_login)
    
    choices = iter(["login", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    printed = []
    monkeypatch.setattr(interactive.console, "print", lambda msg: printed.append(msg))
    
    interactive.interactive_menu()
    
    # Should show error message
    assert any("failed" in str(p) for p in printed)


def test_interactive_menu_account_logout_flow(monkeypatch):
    """Test account menu with logout returning False."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    
    auth_states = iter([
        {"tier": "pro", "authorized": True},
        {"tier": "free"}  # After logout
    ])
    monkeypatch.setattr(
        interactive,
        "get_current_license_info",
        lambda: next(auth_states)
    )
    
    # First call returns False (logout), then back to menu
    monkeypatch.setattr(interactive, "account_info_menu", lambda auth_info: False)
    
    choices = iter(["account", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    interactive.interactive_menu()


def test_interactive_menu_observability(monkeypatch):
    """Test accessing observability menu."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "pro"})
    
    called = {"obs": 0, "pause": 0}
    
    from foundry.actions import observability_interactive
    monkeypatch.setattr(
        observability_interactive,
        "observability_menu",
        lambda: called.__setitem__("obs", called["obs"] + 1)
    )
    monkeypatch.setattr(interactive, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))
    
    choices = iter(["observability", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    interactive.interactive_menu()
    
    assert called["obs"] == 1
    assert called["pause"] == 1


def test_interactive_menu_verification(monkeypatch):
    """Test accessing verification menu."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "pro"})
    
    called = {"verify": 0, "pause": 0}
    
    from foundry.actions import verification_interactive
    monkeypatch.setattr(
        verification_interactive,
        "verification_menu",
        lambda: called.__setitem__("verify", called["verify"] + 1)
    )
    monkeypatch.setattr(interactive, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))
    
    choices = iter(["verification", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    interactive.interactive_menu()
    
    assert called["verify"] == 1
    assert called["pause"] == 1


def test_run_animated_experience_proxy(monkeypatch):
    """Test run_animated_experience proxy function."""
    from foundry import interactive
    
    called = []
    
    # Mock the imported function
    import foundry.animated_experience
    monkeypatch.setattr(
        foundry.animated_experience,
        "run_animated_experience",
        lambda: called.append(True)
    )
    
    interactive.run_animated_experience()
    
    assert len(called) == 1


def test_interactive_menu_free_user_shows_login(monkeypatch):
    """Test that free users see login option."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})
    
    # Capture the choices passed to questionary
    captured_choices = []
    
    def fake_select(*args, **kwargs):
        if "choices" in kwargs:
            captured_choices.extend(kwargs["choices"])
        return SimpleNamespace(ask=lambda: "Exit")
    
    monkeypatch.setattr(interactive.questionary, "select", fake_select)
    
    interactive.interactive_menu()
    
    # Should have login option in choices
    choices_text = [c.title if hasattr(c, "title") else str(c) for c in captured_choices]
    assert any("Login" in t for t in choices_text)


def test_interactive_menu_pro_user_shows_account(monkeypatch):
    """Test that pro users see account option."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "pro", "authorized": True})
    
    # Capture the choices passed to questionary
    captured_choices = []
    
    def fake_select(*args, **kwargs):
        if "choices" in kwargs:
            captured_choices.extend(kwargs["choices"])
        return SimpleNamespace(ask=lambda: "Exit")
    
    monkeypatch.setattr(interactive.questionary, "select", fake_select)
    
    interactive.interactive_menu()
    
    # Should have account option in choices
    choices_text = [c.title if hasattr(c, "title") else str(c) for c in captured_choices]
    assert any("Account" in t for t in choices_text)


def test_interactive_menu_alpha_user(monkeypatch):
    """Test interactive menu for alpha tier users."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "alpha"})
    
    choices = iter(["Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    # Should not crash for alpha users
    interactive.interactive_menu()


def test_interactive_menu_not_internal_dev(monkeypatch):
    """Test that dev tools are not shown for non-internal devs."""
    from foundry import interactive
    
    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "pro"})
    monkeypatch.setattr(interactive, "is_internal_dev", lambda: False)
    
    # Capture the choices
    captured_choices = []
    
    def fake_select(*args, **kwargs):
        if "choices" in kwargs:
            captured_choices.extend(kwargs["choices"])
        return SimpleNamespace(ask=lambda: "Exit")
    
    monkeypatch.setattr(interactive.questionary, "select", fake_select)
    
    interactive.interactive_menu()
    
    # Should NOT have dev tools option
    assert not any("Development Tools" in str(c) for c in captured_choices)


# ---------------------------------------------------------------------------
# TASK 4 — New gap-closing tests for foundry/interactive.py
# ---------------------------------------------------------------------------

def test_interactive_menu_has_animations_false_uses_banner(monkeypatch):
    """HAS_ANIMATIONS=False → FOUNDRY_BANNER is printed as the fallback (lines 20-21)."""
    from foundry import interactive
    from foundry.animations.assets import FOUNDRY_BANNER

    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {"tier": "free"})

    printed = []
    monkeypatch.setattr(interactive.console, "print", lambda *a, **k: printed.extend(a))
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: "Exit"),
    )

    interactive.interactive_menu()

    assert FOUNDRY_BANNER in printed


def test_interactive_menu_pro_tier_choice_insert(monkeypatch):
    """PRO tier → else branch inserts account choice with tier label (line ~92)."""
    from foundry import interactive

    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {
        "authorized": True,
        "tier": "pro",
        "email": "user@example.com",
    })

    captured_choices = []

    def fake_select(*args, **kwargs):
        if "choices" in kwargs:
            captured_choices.extend(kwargs["choices"])
        return SimpleNamespace(ask=lambda: "Exit")

    monkeypatch.setattr(interactive.questionary, "select", fake_select)
    monkeypatch.setattr(interactive.console, "print", lambda *a, **k: None)

    interactive.interactive_menu()

    choices_text = [c.title if hasattr(c, "title") else str(c) for c in captured_choices]
    # PRO tier inserts account choice showing "PRO"
    assert any("PRO" in t for t in choices_text)


def test_interactive_menu_account_value_authorized_pro(monkeypatch):
    """Returning 'account' when PRO authorized → maps to account display → account_info_menu called."""
    from foundry import interactive

    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {
        "authorized": True,
        "tier": "pro",
        "email": "user@example.com",
    })

    account_menu_called = {"count": 0}
    monkeypatch.setattr(
        interactive,
        "account_info_menu",
        lambda auth_info: (account_menu_called.__setitem__("count", account_menu_called["count"] + 1) or True),
    )

    choices = iter(["account", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(choices)),
    )
    monkeypatch.setattr(interactive.console, "print", lambda *a, **k: None)

    interactive.interactive_menu()

    assert account_menu_called["count"] == 1


def test_interactive_menu_account_value_not_authorized(monkeypatch):
    """'account' value when not authorized → remaps to Login path (line 128) → login_flow called."""
    from foundry import interactive

    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)
    monkeypatch.setattr(interactive, "get_current_license_info", lambda: {
        "authorized": False,
        "tier": "free",
    })

    login_called = {"count": 0}
    monkeypatch.setattr(
        interactive,
        "login_flow",
        lambda: (login_called.__setitem__("count", login_called["count"] + 1) or False),
    )

    choices = iter(["account", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(choices)),
    )
    monkeypatch.setattr(interactive.console, "print", lambda *a, **k: None)

    interactive.interactive_menu()

    assert login_called["count"] == 1


def test_interactive_menu_login_flow_success(monkeypatch):
    """login_flow() returns True → auth is refreshed via get_current_license_info(verify=True)."""
    from foundry import interactive

    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)

    call_count = {"n": 0}

    def fake_license_info(verify=False):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return {"authorized": False, "tier": "free"}
        return {"authorized": True, "tier": "pro", "email": "user@example.com"}

    monkeypatch.setattr(interactive, "get_current_license_info", fake_license_info)
    monkeypatch.setattr(interactive, "login_flow", lambda: True)

    choices = iter(["login", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(choices)),
    )
    monkeypatch.setattr(interactive.console, "print", lambda *a, **k: None)

    interactive.interactive_menu()

    # get_current_license_info called at least twice: initial load + post-login refresh
    assert call_count["n"] >= 2


def test_interactive_menu_logout_then_continue(monkeypatch):
    """account_info_menu returns False (logged out) → auth reloaded → continue loop (145->71)."""
    from foundry import interactive

    monkeypatch.setattr(interactive, "HAS_ANIMATIONS", False)

    call_count = {"n": 0}

    def fake_license_info(verify=False):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return {"authorized": True, "tier": "pro", "email": "user@example.com"}
        return {"authorized": False, "tier": "free"}

    monkeypatch.setattr(interactive, "get_current_license_info", fake_license_info)
    # account_info_menu returning False means user logged out
    monkeypatch.setattr(interactive, "account_info_menu", lambda auth_info: False)

    choices = iter(["account", "Exit"])
    monkeypatch.setattr(
        interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(choices)),
    )
    monkeypatch.setattr(interactive.console, "print", lambda *a, **k: None)

    interactive.interactive_menu()

    # auth should have been reloaded after logout
    assert call_count["n"] >= 2


# ---------------------------------------------------------------------------
# TASK 5 — commands/interactive.py: subcommand prevents menu invocation
# ---------------------------------------------------------------------------

def test_interactive_subcommand_does_not_call_menu(monkeypatch):
    """When 'sscli interactive animated' is called, the callback skips interactive_menu()."""
    from typer.testing import CliRunner
    from foundry.cli import app
    from foundry import interactive as interactive_mod

    menu_called = {"count": 0}
    monkeypatch.setattr(
        interactive_mod,
        "interactive_menu",
        lambda: menu_called.__setitem__("count", menu_called["count"] + 1),
    )
    monkeypatch.setattr(interactive_mod, "run_animated_experience", lambda: None)

    runner = CliRunner()
    result = runner.invoke(app, ["interactive", "animated"])

    assert menu_called["count"] == 0
