"""Tests for foundry.commands.verify — SSA-14 cross-platform environment checks."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest

from foundry.commands.verify import (
    FAIL,
    PASS,
    CheckResult,
    check_docker,
    check_git,
    check_python_version,
    check_token,
    run_env_checks,
)


# ---------------------------------------------------------------------------
# run_env_checks — structural contract
# ---------------------------------------------------------------------------


def test_run_env_checks_returns_dict_with_expected_keys():
    """run_env_checks returns a dict keyed by all check names."""
    with (
        patch("foundry.commands.verify.check_docker") as mock_docker,
        patch("foundry.commands.verify.check_connectivity") as mock_conn,
    ):
        mock_docker.return_value = CheckResult("docker", PASS, "ok")
        mock_conn.side_effect = [
            CheckResult("github_connectivity", PASS, "ok"),
            CheckResult("pypi_connectivity", PASS, "ok"),
        ]
        results = run_env_checks()

    assert isinstance(results, dict)
    expected_keys = {
        "SSCLI_TOKEN",
        "python_version",
        "git",
        "docker",
        "github_connectivity",
        "pypi_connectivity",
    }
    assert set(results.keys()) == expected_keys


def test_run_env_checks_values_are_check_results():
    """All values in the returned dict are CheckResult instances."""
    with (
        patch("foundry.commands.verify.check_docker") as mock_docker,
        patch("foundry.commands.verify.check_connectivity") as mock_conn,
    ):
        mock_docker.return_value = CheckResult("docker", PASS, "ok")
        mock_conn.side_effect = [
            CheckResult("github_connectivity", PASS, "ok"),
            CheckResult("pypi_connectivity", PASS, "ok"),
        ]
        results = run_env_checks()

    assert all(isinstance(v, CheckResult) for v in results.values())


# ---------------------------------------------------------------------------
# Python version check
# ---------------------------------------------------------------------------


def test_python_version_check_passes_for_current_interpreter():
    """Current Python interpreter must be >= 3.11 — if not, the venv is misconfigured."""
    result = check_python_version()
    assert sys.version_info >= (3, 11), "Test environment Python is below 3.11"
    assert result.status == PASS


def test_python_version_check_contains_version_string():
    """The reason string should mention the Python version."""
    result = check_python_version()
    v = f"{sys.version_info.major}.{sys.version_info.minor}"
    assert v in result.reason


# ---------------------------------------------------------------------------
# Token check
# ---------------------------------------------------------------------------


def test_token_check_fails_when_env_var_missing(monkeypatch):
    """SSCLI_TOKEN check returns FAIL when env var is absent."""
    monkeypatch.delenv("SSCLI_TOKEN", raising=False)
    result = check_token()
    assert result.status == FAIL


def test_token_check_fails_when_env_var_empty(monkeypatch):
    """SSCLI_TOKEN check returns FAIL when env var is whitespace only."""
    monkeypatch.setenv("SSCLI_TOKEN", "   ")
    result = check_token()
    assert result.status == FAIL


def test_token_check_passes_when_token_set(monkeypatch):
    """SSCLI_TOKEN check passes when the variable has a non-empty value."""
    monkeypatch.setenv("SSCLI_TOKEN", "test-token-abc123")
    result = check_token()
    assert result.status == PASS


def test_failed_token_check_includes_fix_text(monkeypatch):
    """A failed SSCLI_TOKEN check must include non-empty fix instructions."""
    monkeypatch.delenv("SSCLI_TOKEN", raising=False)
    result = check_token()
    assert result.fix is not None
    assert len(result.fix) > 10  # must be meaningful, not a placeholder


# ---------------------------------------------------------------------------
# Git check
# ---------------------------------------------------------------------------


def test_git_check_passes_when_git_available():
    """git check passes when git is on PATH (standard on all dev machines)."""
    import shutil

    if shutil.which("git") is None:
        pytest.skip("git not available in this environment")
    result = check_git()
    assert result.status == PASS


def test_git_check_fails_when_git_missing():
    """git check returns FAIL when shutil.which returns None."""
    with patch("foundry.commands.verify.shutil.which", return_value=None):
        result = check_git()
    assert result.status == FAIL
    assert result.fix is not None


# ---------------------------------------------------------------------------
# Docker check
# ---------------------------------------------------------------------------


def test_docker_check_fails_when_docker_not_in_path():
    """docker check returns FAIL when the docker binary is absent."""
    with patch("foundry.commands.verify.shutil.which", return_value=None):
        result = check_docker()
    assert result.status == FAIL
    assert "not found" in result.reason.lower()


def test_docker_check_fails_when_docker_not_running():
    """docker check returns FAIL when docker is present but 'docker info' fails."""
    mock_proc = MagicMock()
    mock_proc.returncode = 1
    with (
        patch("foundry.commands.verify.shutil.which", return_value="/usr/bin/docker"),
        patch("foundry.commands.verify.subprocess.run", return_value=mock_proc),
    ):
        result = check_docker()
    assert result.status == FAIL
    assert "not running" in result.reason.lower()


def test_docker_check_passes_when_running():
    """docker check returns PASS when docker info exits 0."""
    mock_proc = MagicMock()
    mock_proc.returncode = 0
    with (
        patch("foundry.commands.verify.shutil.which", return_value="/usr/bin/docker"),
        patch("foundry.commands.verify.subprocess.run", return_value=mock_proc),
    ):
        result = check_docker()
    assert result.status == PASS


def test_docker_check_includes_fix_when_missing():
    """docker FAIL result must carry fix instructions."""
    with patch("foundry.commands.verify.shutil.which", return_value=None):
        result = check_docker()
    assert result.fix is not None
    assert len(result.fix) > 10
