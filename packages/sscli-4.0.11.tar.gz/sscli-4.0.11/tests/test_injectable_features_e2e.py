"""
SSA-51: Injectable Features Engine — E2E validation suite.

Tests the inject_features() pipeline, FEATURES_REGISTRY schema, tier gating,
idempotency, and isolation guarantees.

No network calls are made — auth is monkeypatched throughout.
"""
import json
import pytest
from pathlib import Path

import foundry.constants as constants_mod
from foundry.actions.features import (
    inject_features,
    inject_features_ast,
    _inject_sandbox_mode,
)
from foundry.constants import FEATURES_REGISTRY


# ---------------------------------------------------------------------------
# 1. Feature registry — list is non-empty
# ---------------------------------------------------------------------------
def test_features_registry_is_non_empty():
    """FEATURES_REGISTRY must expose at least one injectable feature."""
    assert len(FEATURES_REGISTRY) >= 1, (
        "Expected at least 1 feature in FEATURES_REGISTRY"
    )


# ---------------------------------------------------------------------------
# 2. Feature schema — each entry has required fields
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("feature_key,meta", list(FEATURES_REGISTRY.items()))
def test_each_feature_has_required_fields(feature_key, meta):
    """Every registry entry must have name, description, and templates."""
    assert "name" in meta, f"{feature_key}: missing 'name'"
    assert isinstance(meta["name"], str) and meta["name"], (
        f"{feature_key}: 'name' must be a non-empty string"
    )
    assert "description" in meta, f"{feature_key}: missing 'description'"
    assert isinstance(meta["description"], str) and meta["description"], (
        f"{feature_key}: 'description' must be a non-empty string"
    )
    assert "templates" in meta, f"{feature_key}: missing 'templates'"
    assert isinstance(meta["templates"], list) and meta["templates"], (
        f"{feature_key}: 'templates' must be a non-empty list"
    )


# ---------------------------------------------------------------------------
# 3. Injection isolation — sandbox doesn't write auth-related files
# ---------------------------------------------------------------------------
def test_sandbox_injection_does_not_affect_auth_files(tmp_path):
    """
    Enabling sandbox must not create JWT env vars or auth-related files.
    This verifies feature injection isolation.
    """
    _inject_sandbox_mode(tmp_path, "python-saas")

    # Sandbox policy should be present
    assert (tmp_path / ".seedsource" / "sandbox.policy.json").exists()

    # Auth artifacts must NOT exist
    env_file = tmp_path / ".env"
    if env_file.exists():
        assert "JWT_SECRET_KEY" not in env_file.read_text(encoding="utf-8"), (
            "Sandbox injection must not write auth env vars"
        )
    assert not (tmp_path / "auth").exists()
    assert not (tmp_path / "src" / "auth").exists()


# ---------------------------------------------------------------------------
# 4. Full generation with feature — sandbox creates expected files
# ---------------------------------------------------------------------------
def test_sandbox_injection_creates_policy_file(tmp_path):
    """_inject_sandbox_mode must write .seedsource/sandbox.policy.json."""
    _inject_sandbox_mode(tmp_path, "python-saas")

    policy_file = tmp_path / ".seedsource" / "sandbox.policy.json"
    assert policy_file.exists(), "sandbox.policy.json was not created"

    data = json.loads(policy_file.read_text(encoding="utf-8"))
    assert data["mode"] == "sandbox"
    assert data["template"] == "python-saas"
    assert data["public_read"] is True
    assert "sandbox_write_auth_required" in data


def test_sandbox_injection_for_react_creates_public_config(tmp_path):
    """react-client sandbox injection must also write public/sandbox-config.json."""
    _inject_sandbox_mode(tmp_path, "react-client")

    assert (tmp_path / ".seedsource" / "sandbox.policy.json").exists()
    public_cfg = tmp_path / "public" / "sandbox-config.json"
    assert public_cfg.exists(), "public/sandbox-config.json must be created for react-client"

    cfg = json.loads(public_cfg.read_text(encoding="utf-8"))
    assert cfg["publicRead"] is True


def test_inject_features_sandbox_via_main_entrypoint(tmp_path, monkeypatch):
    """
    inject_features(sandbox=True) must create .seedsource/sandbox.policy.json.
    The sandbox feature is tier=free so no license check is triggered.
    """
    # Defensive monkeypatch — free features should not call auth, but guard anyway.
    monkeypatch.setattr(
        "foundry.actions.features.get_current_license_info",
        lambda verify=False: {"tier": "free", "authorized": False},
    )

    inject_features(
        path=tmp_path,
        template="python-saas",
        commerce=False,
        tunnel=False,
        sandbox=True,
    )

    assert (tmp_path / ".seedsource" / "sandbox.policy.json").exists()


# ---------------------------------------------------------------------------
# 5. No-feature baseline — inject_features with all flags False makes no
#    feature-specific files
# ---------------------------------------------------------------------------
def test_generate_without_features_produces_no_feature_files(tmp_path, monkeypatch):
    """
    Calling inject_features with no features enabled must not create any
    feature-specific artifacts under tmp_path.
    """
    monkeypatch.setattr(
        "foundry.actions.features.get_current_license_info",
        lambda verify=False: {"tier": "free", "authorized": False},
    )

    inject_features(
        path=tmp_path,
        template="python-saas",
        commerce=False,
        tunnel=False,
        landing=False,
        admin=False,
        sqlite=False,
        ingestor=False,
        auth=False,
        merchant_dashboard=False,
        sandbox=False,
        payment=False,
        seo_analyzer=False,
    )

    assert not (tmp_path / ".seedsource").exists(), (
        "sandbox policy dir must NOT be created without sandbox=True"
    )
    assert not (tmp_path / "features").exists(), (
        "features/ dir must NOT be created for a no-feature baseline"
    )
    assert not (tmp_path / ".env").exists(), (
        ".env must NOT be created by a no-feature baseline run"
    )


# ---------------------------------------------------------------------------
# 6. Disabled features raise SystemExit
# ---------------------------------------------------------------------------
def test_disabled_feature_raises_system_exit(tmp_path, monkeypatch):
    """
    When a flag maps to an entry in DISABLED_FEATURES_POLICY, inject_features
    must raise SystemExit(1) before touching the filesystem.
    """
    stubbed_policy = {
        "auth": {
            "flag": "--with-auth",
            "message": "Auth is coming soon — join the waitlist.",
        }
    }
    monkeypatch.setattr(constants_mod, "DISABLED_FEATURES_POLICY", stubbed_policy)
    monkeypatch.setattr(
        "foundry.actions.features.DISABLED_FEATURES_POLICY",
        stubbed_policy,
    )

    with pytest.raises(SystemExit) as exc_info:
        inject_features(
            path=tmp_path,
            template="python-saas",
            commerce=False,
            tunnel=False,
            auth=True,  # triggers disabled policy
        )
    assert exc_info.value.code == 1

    # Filesystem must be untouched
    assert not list(tmp_path.iterdir()), (
        "No files must be written when a disabled feature is requested"
    )


# ---------------------------------------------------------------------------
# 7. Idempotency — injecting the same feature twice is safe
# ---------------------------------------------------------------------------
def test_inject_sandbox_twice_is_idempotent(tmp_path):
    """Calling _inject_sandbox_mode twice must not corrupt the policy file."""
    _inject_sandbox_mode(tmp_path, "python-saas")
    _inject_sandbox_mode(tmp_path, "python-saas")

    policy_file = tmp_path / ".seedsource" / "sandbox.policy.json"
    # File must still be valid JSON (not doubled/corrupted)
    data = json.loads(policy_file.read_text(encoding="utf-8"))
    assert data["mode"] == "sandbox"


def test_inject_sandbox_env_vars_not_duplicated(tmp_path):
    """
    Calling _inject_sandbox_mode twice on a project with an existing .env
    must NOT duplicate SS_SANDBOX_MODE entries.
    """
    env_file = tmp_path / ".env"
    env_file.write_text("APP_ENV=development\n", encoding="utf-8")

    _inject_sandbox_mode(tmp_path, "python-saas")
    _inject_sandbox_mode(tmp_path, "python-saas")

    content = env_file.read_text(encoding="utf-8")
    count = content.count("SS_SANDBOX_MODE=1")
    assert count == 1, (
        f"SS_SANDBOX_MODE must appear exactly once, found {count} occurrences"
    )


# ---------------------------------------------------------------------------
# 8. AST injection engine — result dict has correct shape
# ---------------------------------------------------------------------------
def test_inject_features_ast_returns_correct_shape(tmp_path):
    """inject_features_ast must always return a dict with the four standard keys."""
    result = inject_features_ast(
        project_path=tmp_path,
        template="python-saas",
        features={},
    )
    assert isinstance(result, dict)
    for key in ("success", "changes", "errors", "skipped"):
        assert key in result, f"result dict missing key: '{key}'"
    assert isinstance(result["success"], bool)
    assert isinstance(result["changes"], list)
    assert isinstance(result["errors"], list)
    assert isinstance(result["skipped"], list)


def test_inject_features_ast_fails_gracefully_for_unknown_template(tmp_path):
    """
    inject_features_ast with an unrecognised template must return
    success=False and a descriptive error — not raise an exception.
    """
    result = inject_features_ast(
        project_path=tmp_path,
        template="does-not-exist-xyz",
        features={},
    )
    assert result["success"] is False
    assert result["errors"], "errors list must be non-empty for unknown template"
    assert any("Unknown template type" in e for e in result["errors"]), (
        "Error message must mention 'Unknown template type'"
    )


# ---------------------------------------------------------------------------
# 9. Tier gate — pro feature blocked for free-tier user
# ---------------------------------------------------------------------------
def test_tier_gate_blocks_commerce_for_free_user(tmp_path, monkeypatch):
    """
    inject_features with commerce=True must raise SystemExit(1) when the
    authenticated user's tier is 'free' (commerce requires 'pro').
    """
    monkeypatch.setattr(
        "foundry.actions.features.get_current_license_info",
        lambda verify=False: {"tier": "free", "authorized": False},
    )

    with pytest.raises(SystemExit) as exc_info:
        inject_features(
            path=tmp_path,
            template="python-saas",
            commerce=True,  # pro feature
            tunnel=False,
        )
    assert exc_info.value.code == 1


def test_tier_gate_allows_commerce_for_pro_user(tmp_path, monkeypatch):
    """
    inject_features with commerce=True must NOT raise SystemExit when the
    user holds a 'pro' tier license.  The injection may silently skip if the
    private vault is absent (test environment), but must not gate-block.
    """
    monkeypatch.setattr(
        "foundry.actions.features.get_current_license_info",
        lambda verify=False: {"tier": "pro", "authorized": True},
    )
    # Also stub _perform_feature_injection to be a no-op so we don't need
    # the real vault on disk.
    monkeypatch.setattr(
        "foundry.actions.features._perform_feature_injection",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(
        "foundry.actions.features._inject_commerce_env_vars",
        lambda *args, **kwargs: None,
    )

    # Must not raise SystemExit
    inject_features(
        path=tmp_path,
        template="python-saas",
        commerce=True,
        tunnel=False,
    )
