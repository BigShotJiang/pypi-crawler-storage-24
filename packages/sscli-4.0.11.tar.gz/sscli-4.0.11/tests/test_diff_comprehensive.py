"""
Comprehensive tests for foundry.actions.diff module.

Tests 3-way diff engine that compares:
1. Base template (original scaffold)
2. Current code (user's modified project)
3. Injected features

Coverage goals: 90%+ of diff.py (419 lines)
"""

import json
from pathlib import Path
from typing import Dict
import pytest


@pytest.fixture
def mock_project_structure(tmp_path):
    """Create a realistic project structure with metadata."""
    project_dir = tmp_path / "test_project"
    project_dir.mkdir()
    
    # Create .sscli-metadata.json
    metadata = {
        "base_template_version": "python-saas/1.0.0",
        "features_injected": [
            {"name": "commerce", "version": "1.0.0"},
        ],
        "generated_at": "2026-02-01T10:00:00Z",
    }
    (project_dir / ".sscli-metadata.json").write_text(
        json.dumps(metadata, indent=2),
        encoding="utf-8",
    )
    
    # Create some project files
    (project_dir / "main.py").write_text(
        "# Current project code\nprint('hello')\n",
        encoding="utf-8",
    )
    
    src_dir = project_dir / "src"
    src_dir.mkdir()
    (src_dir / "app.py").write_text(
        "def main():\n    return 'current'\n",
        encoding="utf-8",
    )
    
    return {
        "project_dir": project_dir,
        "metadata": metadata,
    }


@pytest.fixture
def mock_template_structure(tmp_path):
    """Create base template structure."""
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    
    (template_dir / "main.py").write_text(
        "# Base template code\nprint('hello world')\n",
        encoding="utf-8",
    )
    
    src_dir = template_dir / "src"
    src_dir.mkdir()
    (src_dir / "app.py").write_text(
        "def main():\n    return 'base'\n",
        encoding="utf-8",
    )
    
    return template_dir


@pytest.fixture
def mock_feature_structure(tmp_path):
    """Create feature structure."""
    feature_dir = tmp_path / "features" / "commerce"
    feature_dir.mkdir(parents=True)
    
    (feature_dir / "main.py").write_text(
        "# Feature code\nprint('commerce')\n",
        encoding="utf-8",
    )
    
    return feature_dir


# ============================================================================
# Tests for compute_diff() main function
# ============================================================================


def test_compute_diff_no_metadata(tmp_path):
    """Test compute_diff when project has no metadata file."""
    from foundry.actions.diff import compute_diff
    
    project = tmp_path / "no_metadata"
    project.mkdir()
    
    result = compute_diff(str(project))
    
    assert result["success"] is False
    assert "No .sscli-metadata.json found" in result["error"]
    assert result["project_path"] == str(project.resolve())


def test_compute_diff_missing_template_path(mock_project_structure, monkeypatch):
    """Test compute_diff when base template path is not found."""
    from foundry.actions import diff as diff_mod
    
    # Mock _infer_template_path to return None
    monkeypatch.setattr(diff_mod, "_infer_template_path", lambda *args: None)
    
    result = diff_mod.compute_diff(str(mock_project_structure["project_dir"]))
    
    assert result["success"] is False
    assert "Base template path not found" in result["error"]


def test_compute_diff_basic_success(
    mock_project_structure,
    mock_template_structure,
    mock_feature_structure,
    monkeypatch,
):
    """Test successful 3-way diff computation."""
    from foundry.actions import diff as diff_mod
    
    # Mock template and feature path inference
    monkeypatch.setattr(
        diff_mod,
        "_infer_template_path",
        lambda *args: str(mock_template_structure),
    )
    monkeypatch.setattr(
        diff_mod,
        "_infer_feature_path",
        lambda *args: str(mock_feature_structure),
    )
    
    result = diff_mod.compute_diff(
        str(mock_project_structure["project_dir"]),
        output_format="json",
    )
    
    assert result["success"] is True
    assert result["template_type"] == "python-saas"
    assert "commerce" in result["features_compared"]
    assert "statistics" in result
    assert result["statistics"]["total_files"] >= 0


def test_compute_diff_colored_output(
    mock_project_structure,
    mock_template_structure,
    monkeypatch,
):
    """Test colored output format."""
    from foundry.actions import diff as diff_mod
    
    monkeypatch.setattr(
        diff_mod,
        "_infer_template_path",
        lambda *args: str(mock_template_structure),
    )
    monkeypatch.setattr(
        diff_mod,
        "_infer_feature_path",
        lambda *args: None,
    )
    
    result = diff_mod.compute_diff(
        str(mock_project_structure["project_dir"]),
        output_format="colored",
    )
    
    assert result["success"] is True
    assert "formatted_output" in result
    assert "3-Way Diff" in result["formatted_output"]
    assert "Summary" in result["formatted_output"]


def test_compute_diff_unified_output(
    mock_project_structure,
    mock_template_structure,
    monkeypatch,
):
    """Test unified diff output format."""
    from foundry.actions import diff as diff_mod
    
    monkeypatch.setattr(
        diff_mod,
        "_infer_template_path",
        lambda *args: str(mock_template_structure),
    )
    monkeypatch.setattr(
        diff_mod,
        "_infer_feature_path",
        lambda *args: None,
    )
    
    result = diff_mod.compute_diff(
        str(mock_project_structure["project_dir"]),
        output_format="unified",
    )
    
    assert result["success"] is True
    assert "formatted_output" in result
    assert "3-Way Diff" in result["formatted_output"]
    assert "Statistics" in result["formatted_output"]


def test_compute_diff_with_explicit_template_path(
    mock_project_structure,
    mock_template_structure,
):
    """Test compute_diff with explicitly provided template path."""
    from foundry.actions.diff import compute_diff
    
    result = compute_diff(
        str(mock_project_structure["project_dir"]),
        base_template_path=str(mock_template_structure),
    )
    
    assert result["success"] is True
    assert str(mock_template_structure) in result["base_template"]


def test_compute_diff_statistics_calculation(
    mock_project_structure,
    mock_template_structure,
    tmp_path,
    monkeypatch,
):
    """Test that statistics are correctly calculated."""
    from foundry.actions import diff as diff_mod
    
    # Add an additional file only in current project
    (mock_project_structure["project_dir"] / "added_file.py").write_text(
        "# New file\n",
        encoding="utf-8",
    )
    
    monkeypatch.setattr(
        diff_mod,
        "_infer_template_path",
        lambda *args: str(mock_template_structure),
    )
    monkeypatch.setattr(
        diff_mod,
        "_infer_feature_path",
        lambda *args: None,
    )
    
    result = diff_mod.compute_diff(
        str(mock_project_structure["project_dir"]),
    )
    
    stats = result["statistics"]
    assert "total_files" in stats
    assert "added" in stats
    assert "modified" in stats
    assert "deleted" in stats
    assert "unchanged" in stats
    assert "total_additions" in stats
    assert "total_deletions" in stats
    assert "total_modifications" in stats


# ============================================================================
# Tests for _read_project_metadata()
# ============================================================================


def test_read_project_metadata_success(tmp_path):
    """Test reading valid project metadata."""
    from foundry.actions.diff import _read_project_metadata
    
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    
    metadata = {"base_template_version": "python-saas/1.0.0"}
    (project_dir / ".sscli-metadata.json").write_text(
        json.dumps(metadata),
        encoding="utf-8",
    )
    
    result = _read_project_metadata(project_dir)
    
    assert result is not None
    assert result["base_template_version"] == "python-saas/1.0.0"


def test_read_project_metadata_missing_file(tmp_path):
    """Test reading metadata when file doesn't exist."""
    from foundry.actions.diff import _read_project_metadata
    
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    
    result = _read_project_metadata(project_dir)
    
    assert result is None


def test_read_project_metadata_invalid_json(tmp_path):
    """Test reading metadata with invalid JSON."""
    from foundry.actions.diff import _read_project_metadata
    
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    
    (project_dir / ".sscli-metadata.json").write_text(
        "invalid { json",
        encoding="utf-8",
    )
    
    result = _read_project_metadata(project_dir)
    
    assert result is None


def test_read_project_metadata_encoding_error(tmp_path):
    """Test reading metadata with encoding issues."""
    from foundry.actions.diff import _read_project_metadata
    
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    
    # Write binary content that's not valid UTF-8
    (project_dir / ".sscli-metadata.json").write_bytes(b"\xff\xfe")
    
    result = _read_project_metadata(project_dir)
    
    assert result is None


# ============================================================================
# Tests for _infer_template_path()
# ============================================================================


def test_infer_template_path_in_templates_dir(tmp_path, monkeypatch):
    """Test inferring template path from templates directory."""
    from foundry.actions import diff as diff_mod
    
    # Mock FOUNDRY_ROOT
    foundry_root = tmp_path / "foundry"
    foundry_root.mkdir()
    
    templates_dir = foundry_root / "templates" / "python-saas"
    templates_dir.mkdir(parents=True)
    
    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)
    
    result = diff_mod._infer_template_path("python-saas", None)
    
    assert result == str(templates_dir)


def test_infer_template_path_in_parent_dir(tmp_path, monkeypatch):
    """C-8 security fix: parent-dir template lookup is blocked (path traversal prevention).
    A template in foundry_root.parent is OUTSIDE the templates/ directory and must not
    be resolved — this was CVE C-8 in the security audit.
    """
    from foundry.actions import diff as diff_mod
    
    foundry_root = tmp_path / "foundry"
    foundry_root.mkdir()
    
    template_dir = foundry_root.parent / "python-saas"
    template_dir.mkdir()
    
    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)
    
    result = diff_mod._infer_template_path("python-saas", None)
    
    # C-8 fix: parent-dir path is rejected; only foundry_root/templates/ is trusted
    assert result is None


def test_infer_template_path_not_found(tmp_path, monkeypatch):
    """Test inferring template path when it doesn't exist."""
    from foundry.actions import diff as diff_mod
    
    foundry_root = tmp_path / "foundry"
    foundry_root.mkdir()
    
    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)
    
    result = diff_mod._infer_template_path("nonexistent-template", None)
    
    assert result is None


def test_infer_template_path_no_template_name(tmp_path, monkeypatch):
    """Test inferring template path with empty template name."""
    from foundry.actions import diff as diff_mod
    
    result = diff_mod._infer_template_path("", None)
    
    assert result is None


# ============================================================================
# Tests for _infer_feature_path()
# ============================================================================


def test_infer_feature_path_nested_structure(tmp_path, monkeypatch):
    """Test inferring feature path from nested structure."""
    from foundry.actions import diff as diff_mod
    
    foundry_root = tmp_path / "foundry"
    foundry_root.mkdir()
    
    feature_dir = foundry_root / "features" / "commerce" / "python-saas"
    feature_dir.mkdir(parents=True)
    
    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)
    
    result = diff_mod._infer_feature_path("python-saas", "commerce")
    
    assert result == str(feature_dir)


def test_infer_feature_path_flat_structure(tmp_path, monkeypatch):
    """Test inferring feature path from flat structure."""
    from foundry.actions import diff as diff_mod
    
    foundry_root = tmp_path / "foundry"
    foundry_root.mkdir()
    
    feature_dir = foundry_root / "features" / "commerce"
    feature_dir.mkdir(parents=True)
    
    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)
    
    result = diff_mod._infer_feature_path("python-saas", "commerce")
    
    assert result == str(feature_dir)


def test_infer_feature_path_parent_directory(tmp_path, monkeypatch):
    """C-7 security fix: parent-dir feature lookup is blocked (path traversal prevention).
    A feature in foundry_root.parent is OUTSIDE the features/ directory and must not
    be resolved — this was CVE C-7 in the security audit.
    """
    from foundry.actions import diff as diff_mod
    
    foundry_root = tmp_path / "foundry"
    foundry_root.mkdir()
    
    feature_dir = foundry_root.parent / "features" / "commerce"
    feature_dir.mkdir(parents=True)
    
    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)
    
    result = diff_mod._infer_feature_path("python-saas", "commerce")
    
    # C-7 fix: parent-dir path is rejected; only foundry_root/features/ is trusted
    assert result is None


def test_infer_feature_path_not_found(tmp_path, monkeypatch):
    """Test inferring feature path when it doesn't exist."""
    from foundry.actions import diff as diff_mod
    
    foundry_root = tmp_path / "foundry"
    foundry_root.mkdir()
    
    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)
    
    result = diff_mod._infer_feature_path("python-saas", "nonexistent")
    
    assert result is None


# ============================================================================
# Tests for _get_all_files()
# ============================================================================


def test_get_all_files_empty_directory(tmp_path):
    """Test getting files from empty directory."""
    from foundry.actions.diff import _get_all_files
    
    empty_dir = tmp_path / "empty"
    empty_dir.mkdir()
    
    files = _get_all_files(empty_dir)
    
    assert files == []


def test_get_all_files_with_files(tmp_path):
    """Test getting all files from directory with files."""
    from foundry.actions.diff import _get_all_files
    
    test_dir = tmp_path / "test"
    test_dir.mkdir()
    
    (test_dir / "file1.py").write_text("content")
    (test_dir / "file2.txt").write_text("content")
    
    subdir = test_dir / "subdir"
    subdir.mkdir()
    (subdir / "file3.py").write_text("content")
    
    files = _get_all_files(test_dir)
    
    assert len(files) == 3
    assert all(f.is_file() for f in files)


def test_get_all_files_skips_ignored_directories(tmp_path):
    """Test that ignored directories are skipped."""
    from foundry.actions.diff import _get_all_files
    
    test_dir = tmp_path / "test"
    test_dir.mkdir()
    
    (test_dir / "good.py").write_text("content")
    
    # Create files in ignored directories
    node_modules = test_dir / "node_modules"
    node_modules.mkdir()
    (node_modules / "bad.js").write_text("content")
    
    pycache = test_dir / "__pycache__"
    pycache.mkdir()
    (pycache / "bad.pyc").write_text("content")
    
    files = _get_all_files(test_dir)
    
    # Should only get good.py, not files in ignored dirs
    assert len(files) == 1
    assert files[0].name == "good.py"


def test_get_all_files_nested_structure(tmp_path):
    """Test getting files from deeply nested structure."""
    from foundry.actions.diff import _get_all_files
    
    test_dir = tmp_path / "test"
    test_dir.mkdir()
    
    # Create nested structure
    deep = test_dir / "a" / "b" / "c"
    deep.mkdir(parents=True)
    (deep / "deep_file.py").write_text("content")
    
    files = _get_all_files(test_dir)
    
    assert len(files) == 1
    assert files[0].name == "deep_file.py"


# ============================================================================
# Tests for _should_skip_directory()
# ============================================================================


def test_should_skip_directory_git(tmp_path):
    """Test that .git directories are skipped."""
    from foundry.actions.diff import _should_skip_directory
    
    git_file = tmp_path / ".git" / "objects" / "file"
    
    assert _should_skip_directory(git_file) is True


def test_should_skip_directory_node_modules(tmp_path):
    """Test that node_modules directories are skipped."""
    from foundry.actions.diff import _should_skip_directory
    
    npm_file = tmp_path / "project" / "node_modules" / "package" / "file.js"
    
    assert _should_skip_directory(npm_file) is True


def test_should_skip_directory_pycache(tmp_path):
    """Test that __pycache__ directories are skipped."""
    from foundry.actions.diff import _should_skip_directory
    
    cache_file = tmp_path / "src" / "__pycache__" / "module.pyc"
    
    assert _should_skip_directory(cache_file) is True


def test_should_skip_directory_build_dirs(tmp_path):
    """Test that build directories are skipped."""
    from foundry.actions.diff import _should_skip_directory
    
    build_file = tmp_path / "build" / "lib" / "file.o"
    dist_file = tmp_path / "dist" / "app.exe"
    
    assert _should_skip_directory(build_file) is True
    assert _should_skip_directory(dist_file) is True


def test_should_skip_directory_normal_path(tmp_path):
    """Test that normal paths are not skipped."""
    from foundry.actions.diff import _should_skip_directory
    
    normal_file = tmp_path / "src" / "app" / "main.py"
    
    assert _should_skip_directory(normal_file) is False


# ============================================================================
# Tests for _should_skip_file()
# ============================================================================


def test_should_skip_file_metadata(tmp_path):
    """Test that metadata files are skipped."""
    from foundry.actions.diff import _should_skip_file
    
    metadata = Path(".sscli-metadata.json")
    feature_ws = Path(".feature-workspace.json")
    
    assert _should_skip_file(metadata) is True
    assert _should_skip_file(feature_ws) is True


def test_should_skip_file_env_files(tmp_path):
    """Test that environment files are skipped."""
    from foundry.actions.diff import _should_skip_file
    
    assert _should_skip_file(Path(".env")) is True
    assert _should_skip_file(Path(".env.local")) is True
    assert _should_skip_file(Path(".env.example")) is True


def test_should_skip_file_gitignore(tmp_path):
    """Test that .gitignore is skipped."""
    from foundry.actions.diff import _should_skip_file
    
    assert _should_skip_file(Path(".gitignore")) is True


def test_should_skip_file_compiled_files(tmp_path):
    """Test that compiled files are skipped."""
    from foundry.actions.diff import _should_skip_file
    
    assert _should_skip_file(Path("module.pyc")) is True
    assert _should_skip_file(Path("Class.class")) is True


def test_should_skip_file_in_ignored_directory(tmp_path):
    """Test that files in ignored directories are skipped."""
    from foundry.actions.diff import _should_skip_file
    
    node_file = Path("node_modules/package/index.js")
    cache_file = Path("__pycache__/module.pyc")
    
    assert _should_skip_file(node_file) is True
    assert _should_skip_file(cache_file) is True


def test_should_skip_file_normal_files(tmp_path):
    """Test that normal files are not skipped."""
    from foundry.actions.diff import _should_skip_file
    
    assert _should_skip_file(Path("main.py")) is False
    assert _should_skip_file(Path("src/app.py")) is False
    assert _should_skip_file(Path("README.md")) is False


# ============================================================================
# Tests for _compute_file_diff()
# ============================================================================


def test_compute_file_diff_unchanged_files(tmp_path):
    """Test diff computation for unchanged files."""
    from foundry.actions.diff import _compute_file_diff
    
    # Create identical files
    base = tmp_path / "base.py"
    current = tmp_path / "current.py"
    feature = tmp_path / "feature.py"
    
    content = "def hello():\n    print('world')\n"
    base.write_text(content, encoding="utf-8")
    current.write_text(content, encoding="utf-8")
    feature.write_text(content, encoding="utf-8")
    
    diff = _compute_file_diff("test.py", current, base, feature)
    
    assert diff is not None
    assert diff.change_type == "unchanged"
    assert diff.exists_in_base is True
    assert diff.exists_in_current is True
    assert diff.exists_in_feature is True
    assert diff.additions == 0
    assert diff.deletions == 0


def test_compute_file_diff_added_file(tmp_path):
    """Test diff computation for added files."""
    from foundry.actions.diff import _compute_file_diff
    
    current = tmp_path / "current.py"
    current.write_text("# New file\nprint('hello')\n", encoding="utf-8")
    
    base = tmp_path / "base.py"  # Doesn't exist
    
    diff = _compute_file_diff("new.py", current, base, None)
    
    assert diff is not None
    assert diff.change_type == "added"
    assert diff.exists_in_current is True
    assert diff.exists_in_base is False
    assert diff.additions == 2


def test_compute_file_diff_deleted_file(tmp_path):
    """Test diff computation for deleted files."""
    from foundry.actions.diff import _compute_file_diff
    
    base = tmp_path / "base.py"
    base.write_text("# Old file\nprint('goodbye')\n", encoding="utf-8")
    
    current = tmp_path / "current.py"  # Doesn't exist
    
    diff = _compute_file_diff("deleted.py", current, base, None)
    
    assert diff is not None
    assert diff.change_type == "deleted"
    assert diff.exists_in_base is True
    assert diff.exists_in_current is False
    assert diff.deletions == 2


def test_compute_file_diff_modified_file(tmp_path):
    """Test diff computation for modified files."""
    from foundry.actions.diff import _compute_file_diff
    
    base = tmp_path / "base.py"
    current = tmp_path / "current.py"
    
    base.write_text("def hello():\n    print('base')\n", encoding="utf-8")
    current.write_text("def hello():\n    print('modified')\n", encoding="utf-8")
    
    diff = _compute_file_diff("modified.py", current, base, None)
    
    assert diff is not None
    assert diff.change_type == "modified"
    assert diff.exists_in_base is True
    assert diff.exists_in_current is True
    assert diff.modifications > 0


def test_compute_file_diff_binary_file(tmp_path):
    """Test that binary files return None."""
    from foundry.actions.diff import _compute_file_diff
    
    current = tmp_path / "image.bin"
    current.write_bytes(b"\x89PNG\r\n\x1a\n")
    
    diff = _compute_file_diff("image.bin", current, None, None)
    
    # Should return None for binary/non-UTF-8 files
    assert diff is None


def test_compute_file_diff_empty_files(tmp_path):
    """Test diff computation for empty files."""
    from foundry.actions.diff import _compute_file_diff
    
    base = tmp_path / "base.py"
    current = tmp_path / "current.py"
    
    base.write_text("", encoding="utf-8")
    current.write_text("", encoding="utf-8")
    
    diff = _compute_file_diff("empty.py", current, base, None)
    
    assert diff is not None
    assert diff.change_type == "unchanged"


def test_compute_file_diff_with_feature(tmp_path):
    """Test diff computation with feature file included."""
    from foundry.actions.diff import _compute_file_diff
    
    base = tmp_path / "base.py"
    current = tmp_path / "current.py"
    feature = tmp_path / "feature.py"
    
    base.write_text("# base\n", encoding="utf-8")
    current.write_text("# current\n", encoding="utf-8")
    feature.write_text("# feature\n", encoding="utf-8")
    
    diff = _compute_file_diff("test.py", current, base, feature)
    
    assert diff is not None
    assert diff.exists_in_feature is True


def test_compute_file_diff_io_error(tmp_path, monkeypatch):
    """Test handling of IO errors during diff computation."""
    from foundry.actions.diff import _compute_file_diff
    
    current = tmp_path / "current.py"
    current.write_text("content", encoding="utf-8")
    
    # Monkeypatch read_text to raise IOError
    original_read_text = Path.read_text
    def mock_read_text(*args, **kwargs):
        raise IOError("Simulated IO error")
    
    monkeypatch.setattr(Path, "read_text", mock_read_text)
    
    diff = _compute_file_diff("error.py", current, None, None)
    
    # Should return None on IO error
    assert diff is None


# ============================================================================
# Tests for _serialize_diff()
# ============================================================================


def test_serialize_diff():
    """Test serialization of FileDiff to dict."""
    from foundry.actions.diff import FileDiff, DiffSection, _serialize_diff
    
    sections = [
        DiffSection(
            file_path="test.py",
            diff_type="modified_by_user",
            lines=["line1", "line2"],
            start_line=1,
            end_line=2,
            context="test context",
        )
    ]
    
    diff = FileDiff(
        file_path="test.py",
        exists_in_base=True,
        exists_in_current=True,
        exists_in_feature=False,
        sections=sections,
        change_type="modified",
        additions=5,
        deletions=3,
        modifications=8,
    )
    
    result = _serialize_diff(diff)
    
    assert isinstance(result, dict)
    assert result["file_path"] == "test.py"
    assert result["exists_in_base"] is True
    assert result["exists_in_current"] is True
    assert result["exists_in_feature"] is False
    assert result["change_type"] == "modified"
    assert result["additions"] == 5
    assert result["deletions"] == 3
    assert result["modifications"] == 8
    assert len(result["sections"]) == 1
    assert result["sections"][0]["diff_type"] == "modified_by_user"


# ============================================================================
# Tests for _format_diff_colored()
# ============================================================================


def test_format_diff_colored(tmp_path):
    """Test colored diff output formatting."""
    from foundry.actions.diff import FileDiff, _format_diff_colored
    
    file_diffs = {
        "test.py": FileDiff(
            file_path="test.py",
            exists_in_base=True,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="modified",
            additions=5,
            deletions=2,
            modifications=7,
        ),
        "new.py": FileDiff(
            file_path="new.py",
            exists_in_base=False,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="added",
            additions=10,
            deletions=0,
            modifications=10,
        ),
    }
    
    stats = {
        "unchanged": 3,
        "modified": 1,
        "added": 1,
        "deleted": 0,
        "total_additions": 15,
        "total_deletions": 2,
        "total_modifications": 17,
    }
    
    output = _format_diff_colored(file_diffs, stats)
    
    assert "3-Way Diff" in output
    assert "Summary" in output
    assert "Statistics" in output
    assert "Changed Files" in output
    assert "test.py" in output
    assert "new.py" in output


def test_format_diff_colored_no_changes(tmp_path):
    """Test colored output when no files changed."""
    from foundry.actions.diff import FileDiff, _format_diff_colored
    
    file_diffs = {
        "unchanged.py": FileDiff(
            file_path="unchanged.py",
            exists_in_base=True,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="unchanged",
            additions=0,
            deletions=0,
            modifications=0,
        ),
    }
    
    stats = {
        "unchanged": 1,
        "modified": 0,
        "added": 0,
        "deleted": 0,
        "total_additions": 0,
        "total_deletions": 0,
        "total_modifications": 0,
    }
    
    output = _format_diff_colored(file_diffs, stats)
    
    assert "3-Way Diff" in output
    # Unchanged files should not appear in "Changed Files" section
    assert "unchanged.py" not in output or output.count("unchanged.py") == 0


# ============================================================================
# Tests for _format_diff_unified()
# ============================================================================


def test_format_diff_unified(tmp_path):
    """Test unified diff output formatting."""
    from foundry.actions.diff import FileDiff, _format_diff_unified
    
    file_diffs = {
        "modified.py": FileDiff(
            file_path="modified.py",
            exists_in_base=True,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="modified",
            additions=8,
            deletions=4,
            modifications=12,
        ),
    }
    
    stats = {
        "unchanged": 5,
        "modified": 1,
        "added": 0,
        "deleted": 1,
        "total_additions": 8,
        "total_deletions": 4,
        "total_modifications": 12,
    }
    
    output = _format_diff_unified(file_diffs, stats)
    
    assert "3-Way Diff" in output
    assert "Summary" in output
    assert "Statistics" in output
    assert "Unchanged:" in output
    assert "Modified:" in output
    assert "modified.py" in output


def test_format_diff_unified_all_types(tmp_path):
    """Test unified output with all change types."""
    from foundry.actions.diff import FileDiff, _format_diff_unified
    
    file_diffs = {
        "added.py": FileDiff(
            file_path="added.py",
            exists_in_base=False,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="added",
            additions=20,
            deletions=0,
            modifications=20,
        ),
        "deleted.py": FileDiff(
            file_path="deleted.py",
            exists_in_base=True,
            exists_in_current=False,
            exists_in_feature=False,
            sections=[],
            change_type="deleted",
            additions=0,
            deletions=15,
            modifications=15,
        ),
        "modified.py": FileDiff(
            file_path="modified.py",
            exists_in_base=True,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="modified",
            additions=5,
            deletions=3,
            modifications=8,
        ),
    }
    
    stats = {
        "unchanged": 10,
        "modified": 1,
        "added": 1,
        "deleted": 1,
        "total_additions": 25,
        "total_deletions": 18,
        "total_modifications": 43,
    }
    
    output = _format_diff_unified(file_diffs, stats)
    
    assert "added.py" in output
    assert "deleted.py" in output
    assert "modified.py" in output
    assert "+25" in output
    assert "-18" in output


# ============================================================================
# Tests for dataclasses
# ============================================================================


def test_diff_section_dataclass():
    """Test DiffSection dataclass creation."""
    from foundry.actions.diff import DiffSection
    
    section = DiffSection(
        file_path="test.py",
        diff_type="added_by_feature",
        lines=["line1", "line2"],
        start_line=10,
        end_line=12,
        context="feature injection",
    )
    
    assert section.file_path == "test.py"
    assert section.diff_type == "added_by_feature"
    assert section.lines == ["line1", "line2"]
    assert section.start_line == 10
    assert section.end_line == 12
    assert section.context == "feature injection"


def test_diff_section_default_context():
    """Test DiffSection with default context."""
    from foundry.actions.diff import DiffSection
    
    section = DiffSection(
        file_path="test.py",
        diff_type="unchanged",
        lines=[],
        start_line=1,
        end_line=1,
    )
    
    assert section.context == ""


def test_file_diff_dataclass():
    """Test FileDiff dataclass creation."""
    from foundry.actions.diff import FileDiff
    
    diff = FileDiff(
        file_path="app.py",
        exists_in_base=True,
        exists_in_current=True,
        exists_in_feature=True,
        sections=[],
        change_type="modified",
        additions=10,
        deletions=5,
        modifications=15,
    )
    
    assert diff.file_path == "app.py"
    assert diff.exists_in_base is True
    assert diff.exists_in_current is True
    assert diff.exists_in_feature is True
    assert diff.change_type == "modified"
    assert diff.additions == 10
    assert diff.deletions == 5
    assert diff.modifications == 15


def test_file_diff_default_values():
    """Test FileDiff with default values."""
    from foundry.actions.diff import FileDiff
    
    diff = FileDiff(
        file_path="test.py",
        exists_in_base=False,
        exists_in_current=True,
        exists_in_feature=False,
        sections=[],
        change_type="added",
    )
    
    assert diff.additions == 0
    assert diff.deletions == 0
    assert diff.modifications == 0


# ============================================================================
# Integration tests
# ============================================================================


def test_integration_complete_workflow(tmp_path, monkeypatch):
    """Integration test for complete diff workflow."""
    from foundry.actions import diff as diff_mod
    
    # Setup project
    project = tmp_path / "project"
    project.mkdir()
    
    metadata = {
        "base_template_version": "python-saas/1.0.0",
        "features_injected": [],
    }
    (project / ".sscli-metadata.json").write_text(json.dumps(metadata))
    (project / "main.py").write_text("# Project file\n")
    (project / "README.md").write_text("# README\n")
    
    # Setup template
    template = tmp_path / "template"
    template.mkdir()
    (template / "main.py").write_text("# Template file\n")
    
    # Mock path inference
    monkeypatch.setattr(diff_mod, "_infer_template_path", lambda *args: str(template))
    monkeypatch.setattr(diff_mod, "_infer_feature_path", lambda *args: None)
    
    # Run diff
    result = diff_mod.compute_diff(str(project), output_format="unified")
    
    assert result["success"] is True
    assert "statistics" in result
    assert "file_diffs" in result
    assert "formatted_output" in result


def test_integration_with_multiple_features(tmp_path, monkeypatch):
    """Integration test with multiple injected features."""
    from foundry.actions import diff as diff_mod
    
    # Setup project with multiple features
    project = tmp_path / "project"
    project.mkdir()
    
    metadata = {
        "base_template_version": "python-saas/1.0.0",
        "features_injected": [
            {"name": "commerce", "version": "1.0"},
            {"name": "auth", "version": "1.0"},
        ],
    }
    (project / ".sscli-metadata.json").write_text(json.dumps(metadata))
    (project / "app.py").write_text("# App\n")
    
    # Setup template
    template = tmp_path / "template"
    template.mkdir()
    (template / "app.py").write_text("# Template\n")
    
    # Setup features
    commerce_feature = tmp_path / "features" / "commerce"
    commerce_feature.mkdir(parents=True)
    (commerce_feature / "app.py").write_text("# Commerce feature\n")
    
    auth_feature = tmp_path / "features" / "auth"
    auth_feature.mkdir(parents=True)
    
    # Mock path inference
    monkeypatch.setattr(diff_mod, "_infer_template_path", lambda *args: str(template))
    
    def mock_infer_feature(template_name, feature_name):
        if feature_name == "commerce":
            return str(commerce_feature)
        elif feature_name == "auth":
            return str(auth_feature)
        return None
    
    monkeypatch.setattr(diff_mod, "_infer_feature_path", mock_infer_feature)
    
    # Run diff
    result = diff_mod.compute_diff(str(project))
    
    assert result["success"] is True
    assert "commerce" in result["features_compared"]
    assert "auth" in result["features_compared"]


def test_integration_large_file_set(tmp_path, monkeypatch):
    """Integration test with many files."""
    from foundry.actions import diff as diff_mod
    
    # Setup project with many files
    project = tmp_path / "project"
    project.mkdir()
    
    metadata = {"base_template_version": "python-saas/1.0.0", "features_injected": []}
    (project / ".sscli-metadata.json").write_text(json.dumps(metadata))
    
    # Create multiple directories and files
    for i in range(10):
        dir_path = project / f"module_{i}"
        dir_path.mkdir()
        for j in range(5):
            (dir_path / f"file_{j}.py").write_text(f"# File {i}-{j}\n")
    
    # Setup template
    template = tmp_path / "template"
    template.mkdir()
    
    for i in range(10):
        dir_path = template / f"module_{i}"
        dir_path.mkdir()
        for j in range(5):
            (dir_path / f"file_{j}.py").write_text(f"# Template {i}-{j}\n")
    
    # Mock path inference
    monkeypatch.setattr(diff_mod, "_infer_template_path", lambda *args: str(template))
    monkeypatch.setattr(diff_mod, "_infer_feature_path", lambda *args: None)
    
    # Run diff
    result = diff_mod.compute_diff(str(project))
    
    assert result["success"] is True
    # Should process 50 files (10 dirs * 5 files)
    assert result["statistics"]["total_files"] == 50
