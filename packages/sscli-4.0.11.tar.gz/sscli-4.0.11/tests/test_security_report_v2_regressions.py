"""Regression tests for security-report-v2 remediations.

These tests target the hardening changes added after the v2 audit so regressions
are caught early in CI.
"""

import json
import io
import tarfile
import hashlib
from pathlib import Path

import pytest
import typer
from typer.testing import CliRunner

import foundry.auth as auth_mod
import foundry.cli as cli_mod
from foundry.actions.upgrade import UpgradeCommand, UpgradeStep, ProjectMetadata
from foundry.actions.repo_utils import download_template
from foundry.actions.verification.project_validator import ProjectValidator
from foundry.actions.ast_grep_runner import AstGrepRunner
from foundry.codemods.js_codemods import (
    InjectCallCodemod,
    InjectConstantCodemod,
    InjectImportCodemod,
)
from foundry.commands import feedback as feedback_mod
from foundry.commands import internals as internals_mod
from foundry.commands import observability as obs_mod
from foundry.safety.integration import require_git_status_check
from foundry.safety.verification_hook import ProjectType, VerificationHook
import foundry.constants as constants_mod
import foundry.telemetry as telemetry_mod


runner = CliRunner()


def test_auth_verify_with_missing_token_returns_free(tmp_path, monkeypatch):
    creds = tmp_path / "credentials.json"
    creds.write_text(json.dumps({"tier": "enterprise", "authorized": True}), encoding="utf-8")
    monkeypatch.setattr(auth_mod, "CREDENTIALS_FILE", creds)

    info = auth_mod.get_current_license_info(verify=True)
    assert info["tier"] == "free"
    assert info["authorized"] is False


def test_auth_verify_401_clears_cached_credentials(tmp_path, monkeypatch):
    creds = tmp_path / "credentials.json"
    creds.write_text(json.dumps({"access_token": "tok", "tier": "pro", "authorized": True}), encoding="utf-8")
    monkeypatch.setattr(auth_mod, "CREDENTIALS_FILE", creds)

    class _Resp:
        status_code = 401

        @staticmethod
        def json():
            return {}

    monkeypatch.setattr(auth_mod.requests, "get", lambda *args, **kwargs: _Resp())

    info = auth_mod.get_current_license_info(verify=True)
    assert info["tier"] == "free"
    assert info["authorized"] is False
    assert not creds.exists()


def test_cli_verify_exits_nonzero_on_failed_verification(monkeypatch):
    monkeypatch.setattr(cli_mod, "run_verification", lambda **kwargs: False)

    result = runner.invoke(cli_mod.app, ["verify"])
    assert result.exit_code == 1


def test_log_event_sanitizes_event_type_newlines(tmp_path, monkeypatch):
    log_file = tmp_path / ".session.log"
    monkeypatch.setattr(telemetry_mod, "LOG_FILE", log_file)

    telemetry_mod.log_event("BUILD\nINJECT", "ok")
    content = log_file.read_text(encoding="utf-8")

    assert "BUILD INJECT" in content
    assert "BUILD\nINJECT" not in content


def test_internals_path_escape_rejected(tmp_path):
    with pytest.raises(typer.BadParameter):
        internals_mod._resolve_within_root(
            tmp_path.parent / "outside.log",
            tmp_path,
            "--session-log",
        )


def test_observability_requires_auth(monkeypatch):
    monkeypatch.setattr(obs_mod, "get_current_license_info", lambda verify=True: {"authorized": False})

    with pytest.raises(typer.Exit) as exc:
        obs_mod._require_auth()
    assert exc.value.exit_code == 1


def test_observability_workspace_list_rejects_path_outside_cwd(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "in").mkdir()
    monkeypatch.chdir(workspace)

    monkeypatch.setattr(obs_mod, "_require_auth", lambda: None)

    with pytest.raises(typer.BadParameter):
        obs_mod.workspace_list_command(search_path=str(tmp_path), json_output=False)


def test_observability_workspace_list_uses_resolved_search_path(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    search_dir = workspace / "in"
    search_dir.mkdir(parents=True)
    monkeypatch.chdir(workspace)

    called = {}
    monkeypatch.setattr(obs_mod, "_require_auth", lambda: None)
    monkeypatch.setattr(obs_mod.console, "print", lambda *args, **kwargs: None)

    def _fake_list(search_path):
        called["search_path"] = search_path
        return {"success": True, "workspaces": []}

    monkeypatch.setattr(obs_mod, "list_workspaces", _fake_list)
    obs_mod.workspace_list_command(search_path="./in", json_output=False)

    assert called["search_path"] == str(search_dir.resolve())


def test_repo_utils_requires_checksum_header(tmp_path, monkeypatch):
    target = tmp_path / "proj"

    monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
    monkeypatch.setattr("foundry.actions.repo_utils.get_current_license_info", lambda verify=True: {"tier": "pro", "authorized": True})
    monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok")

    class _Resp:
        status_code = 200
        headers = {"X-Foundry-User-Id": "1"}
        content = b"archive"
        text = ""

    monkeypatch.setattr("foundry.actions.repo_utils.requests.get", lambda *args, **kwargs: _Resp())

    assert download_template("python-saas", {}, target) is False


def test_repo_utils_rejects_invalid_checksum_header(tmp_path, monkeypatch):
    target = tmp_path / "proj"

    monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
    monkeypatch.setattr("foundry.actions.repo_utils.get_current_license_info", lambda verify=True: {"tier": "pro", "authorized": True})
    monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok")

    class _Resp:
        status_code = 200
        headers = {"X-Template-Sha256": "not-a-sha", "X-Foundry-User-Id": "1"}
        content = b"archive"
        text = ""

    monkeypatch.setattr("foundry.actions.repo_utils.requests.get", lambda *args, **kwargs: _Resp())

    assert download_template("python-saas", {}, target) is False


def test_verification_hook_rejects_shell_interpreter_custom_validator():
    hook = VerificationHook()
    with pytest.raises(ValueError, match="shell interpreter not allowed"):
        hook.add_custom_validator(ProjectType.PYTHON, "bad", ["bash", "-c", "echo hi"], "bad")


def test_verification_hook_rejects_env_wrapped_shell():
    hook = VerificationHook()
    with pytest.raises(ValueError, match="wrapper not allowed"):
        hook.add_custom_validator(ProjectType.PYTHON, "bad", ["env", "bash", "-c", "echo hi"], "bad")


def test_project_validator_docker_check_uses_check_flag(tmp_path, monkeypatch):
    (tmp_path / "Dockerfile").write_text("FROM alpine:3.20\n", encoding="utf-8")

    captured = {}

    class _Resp:
        returncode = 0
        stderr = ""

    def _fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return _Resp()

    monkeypatch.setattr("foundry.actions.verification.project_validator.subprocess.run", _fake_run)

    validator = ProjectValidator(project_path=tmp_path)
    validator._check_docker()

    assert captured["cmd"][:3] == ["docker", "build", "--check"]


def test_require_git_status_check_does_not_inject_force_kwarg_when_not_supported(monkeypatch):
    class _Guard:
        def __init__(self, config=None):
            self.config = config

        def require_clean_status(self):
            return None

    monkeypatch.setattr("foundry.safety.integration.GitGuard", _Guard)

    calls = []

    @require_git_status_check()
    def _cmd(name):
        calls.append(name)
        return "ok"

    assert _cmd("demo", force=True) == "ok"
    assert calls == ["demo"]


def test_ast_grep_runner_rejects_invalid_rule_name(tmp_path):
    runner_obj = AstGrepRunner(rule_dir=tmp_path)
    ok, error = runner_obj.validate_rule("../../escape")

    assert ok is False
    assert "Invalid rule name" in str(error)


def test_js_codemod_constructor_input_validation():
    with pytest.raises(ValueError):
        InjectImportCodemod(module="react;rm -rf /", names=["useState"])

    with pytest.raises(ValueError):
        InjectCallCodemod("init();alert(1)")

    with pytest.raises(ValueError):
        InjectCallCodemod("init()\nalert(1)")

    with pytest.raises(ValueError):
        InjectConstantCodemod("BAD-NAME", "42")


def test_feedback_redaction_and_consent_gate(monkeypatch):
    captured = {}

    monkeypatch.setattr(feedback_mod, "_consent_for_context", lambda: False)
    monkeypatch.setattr(feedback_mod, "save_feedback_locally", lambda payload: captured.setdefault("payload", payload) or Path("/tmp/f.json"))


    feedback_mod.quick_feedback(message="token=abc123", category="bug")

    payload = captured["payload"]
    assert payload["message"] == "REDACTED"
    assert "system" not in payload
    assert "user" not in payload


def test_feedback_consent_true_includes_context(monkeypatch):
    captured = {}

    monkeypatch.setattr(feedback_mod, "_consent_for_context", lambda: True)
    monkeypatch.setattr(feedback_mod, "get_system_context", lambda: {"os": "Darwin"})
    monkeypatch.setattr(feedback_mod, "get_user_context", lambda: {"tier": "pro"})
    monkeypatch.setattr(feedback_mod, "save_feedback_locally", lambda payload: captured.setdefault("payload", payload) or Path("/tmp/f.json"))


    feedback_mod.quick_feedback(message="hello", category="feature")

    payload = captured["payload"]
    assert payload["system"]["os"] == "Darwin"
    assert payload["user"]["tier"] == "pro"


def test_constants_ignore_mismatched_foundry_root_override(monkeypatch, tmp_path):
    monkeypatch.setenv("FOUNDRY_ROOT", str(tmp_path / "malicious-root"))

    root = constants_mod._get_foundry_root()
    assert root != (tmp_path / "malicious-root")


def test_observability_require_auth_accepts_authorized(monkeypatch):
    monkeypatch.setattr(obs_mod, "get_current_license_info", lambda verify=True: {"authorized": True})
    obs_mod._require_auth()


def test_internals_output_dir_escape_rejected(tmp_path):
    with pytest.raises(typer.BadParameter):
        internals_mod._resolve_within_root(
            tmp_path.parent / "outside-report-dir",
            tmp_path,
            "--output-dir",
        )


def test_repo_utils_download_sets_allow_redirects_false(tmp_path, monkeypatch):
    target = tmp_path / "proj"
    called = {}

    monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
    monkeypatch.setattr("foundry.actions.repo_utils.get_current_license_info", lambda verify=True: {"tier": "pro", "authorized": True})
    monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok")

    class _Resp:
        status_code = 500
        headers = {}
        content = b""
        text = "err"

    def _fake_get(*args, **kwargs):
        called.update(kwargs)
        return _Resp()

    monkeypatch.setattr("foundry.actions.repo_utils.requests.get", _fake_get)

    assert download_template("python-saas", {}, target) is False
    assert called.get("allow_redirects") is False


def test_repo_utils_rejects_symlink_member_in_archive(tmp_path, monkeypatch):
    target = tmp_path / "proj"

    monkeypatch.setattr("foundry.actions.repo_utils.is_internal_dev", lambda: False)
    monkeypatch.setattr("foundry.actions.repo_utils.get_current_license_info", lambda verify=True: {"tier": "pro", "authorized": True})
    monkeypatch.setattr("foundry.actions.repo_utils.get_access_token", lambda: "tok")

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        info = tarfile.TarInfo("link")
        info.type = tarfile.SYMTYPE
        info.linkname = "../../etc/passwd"
        tf.addfile(info)
    archive = buf.getvalue()
    checksum = hashlib.sha256(archive).hexdigest()

    class _Resp:
        status_code = 200
        headers = {"X-Template-Sha256": checksum, "X-Foundry-User-Id": "1"}
        content = archive
        text = ""

    monkeypatch.setattr("foundry.actions.repo_utils.requests.get", lambda *args, **kwargs: _Resp())

    assert download_template("python-saas", {}, target) is False


def test_upgrade_blocks_manual_review_step_without_interactive(tmp_path, monkeypatch):
    project = tmp_path / "project"
    project.mkdir()
    (project / "pyproject.toml").write_text('version = "1.0.0"\n', encoding="utf-8")

    step = UpgradeStep(
        index=1,
        codemod_id="cm-1",
        codemod_name="manual",
        from_version="1.0.0",
        to_version="1.1.0",
        description="requires review",
        risk_level="high",
        requires_manual_review=True,
    )

    metadata = ProjectMetadata(
        current_version="1.0.0",
        template_type="python-saas",
        created_at="2026-01-01T00:00:00",
        upgrade_history=[],
    )

    cmd = UpgradeCommand(project_path=project)
    monkeypatch.setattr(cmd, "plan_upgrade", lambda **kwargs: ([step], "1.1.0"))
    monkeypatch.setattr(cmd, "_create_backup", lambda: project)
    monkeypatch.setattr(cmd, "_rollback_to_backup", lambda: None)
    monkeypatch.setattr(cmd.metadata_tracker, "load", lambda: metadata)
    monkeypatch.setattr(cmd.metadata_tracker, "save", lambda _m: None)

    assert cmd.execute_upgrade(force=True, interactive=False) is False


def test_upgrade_backup_writes_manifest(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    (project / "pyproject.toml").write_text('version = "1.0.0"\n', encoding="utf-8")
    (project / "README.md").write_text("hello\n", encoding="utf-8")

    cmd = UpgradeCommand(project_path=project)
    backup = cmd._create_backup()

    manifest = backup / cmd.BACKUP_MANIFEST_FILE
    assert manifest.exists()
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    assert "README.md" in payload["files"]


def test_upgrade_rollback_rejects_incomplete_manifest(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    (project / "pyproject.toml").write_text('version = "2.0.0"\n', encoding="utf-8")

    backup_dir = tmp_path / ".upgrades" / "backup_bad"
    backup_dir.mkdir(parents=True)
    (backup_dir / UpgradeCommand.BACKUP_MANIFEST_FILE).write_text(
        json.dumps({"files": ["missing.txt"]}),
        encoding="utf-8",
    )

    meta = {
        "current_version": "2.0.0",
        "template_type": "python-saas",
        "created_at": "2024-01-01T00:00:00",
        "last_upgraded": "2024-01-02T00:00:00",
        "upgrade_history": [
            {
                "timestamp": "2024-01-02T00:00:00",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "steps_applied": 1,
                "steps_successful": 1,
                "status": "success",
                "error_message": None,
                "backup_path": str(backup_dir),
                "codemod_ids": [],
                "git_commit_sha": None,
            }
        ],
    }
    (project / ".seed-source-metadata.json").write_text(json.dumps(meta), encoding="utf-8")

    cmd = UpgradeCommand(project_path=project)
    assert cmd.rollback_upgrade() is False
