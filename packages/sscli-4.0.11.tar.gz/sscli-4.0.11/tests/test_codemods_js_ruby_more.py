from pathlib import Path

import subprocess

from foundry.codemods import js_codemods

from foundry.codemods.base import ModificationResult
from foundry.codemods.js_codemods import (
    JsCodemod,
    InjectImportCodemod,
    InjectRouteCodemod,
    InjectCallCodemod,
    InjectConstantCodemod,
)
from foundry.codemods.ruby_codemods import (
    InjectRouteCodemod as RubyRouteCodemod,
    InjectCallCodemod as RubyCallCodemod,
    InjectConstantCodemod as RubyConstantCodemod,
)


def test_js_inject_import_string_based(tmp_path):
    path = tmp_path / "app.js"
    path.write_text("import React from 'react';\n\nconst x = 1;\n")

    codemod = InjectImportCodemod(module="react-router", names=["Route"], import_type="esm")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "import { Route }" in path.read_text()


def test_js_inject_import_duplicate(tmp_path):
    path = tmp_path / "app.js"
    path.write_text("import { Route } from 'react-router';\n")

    codemod = InjectImportCodemod(module="react-router", names=["Route"], import_type="esm")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert result.changes_made == 0


def test_js_inject_route_react(tmp_path):
    path = tmp_path / "App.jsx"
    path.write_text("<Routes>\n  <Route path=\"/\" element={<Home />} />\n</Routes>\n")

    codemod = InjectRouteCodemod(path_pattern="/dashboard", component="Dashboard", framework="react")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "Dashboard" in path.read_text()


def test_js_inject_route_astro(tmp_path):
    path = tmp_path / "routes.js"
    path.write_text("export const routes = [\n  { path: '/', component: Home }\n]\n")

    codemod = InjectRouteCodemod(path_pattern="/about", component="About", framework="astro")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "path: '/about'" in path.read_text()


def test_js_inject_route_missing_insertion(tmp_path):
    path = tmp_path / "App.jsx"
    path.write_text("const x = 1;\n")

    codemod = InjectRouteCodemod(path_pattern="/dashboard", component="Dashboard", framework="react")
    result = codemod._apply_string_based(path)

    assert result.success is False
    assert "insertion" in result.error


def test_js_inject_call_target(tmp_path):
    path = tmp_path / "main.js"
    path.write_text("function main() {\n  return true;\n}\n")

    codemod = InjectCallCodemod(call_statement="init()", target_function="main")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "init()" in path.read_text()


def test_js_inject_constant(tmp_path):
    path = tmp_path / "config.js"
    path.write_text("import x from 'y';\n\nexport default {};\n")

    codemod = InjectConstantCodemod(name="API_URL", value="'https://x'" )
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "const API_URL" in path.read_text()


def test_ruby_inject_route(tmp_path):
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")

    codemod = RubyRouteCodemod(http_method="get", path="users", controller_action="users#index")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "users#index" in path.read_text()


def test_ruby_inject_route_namespaced(tmp_path):
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\n  namespace :admin do\n  end\nend\n")

    codemod = RubyRouteCodemod(http_method="post", path="webhooks/shopify", controller_action="webhooks#handle", namespace="admin")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "webhooks/shopify" in path.read_text()


def test_ruby_inject_call(tmp_path):
    path = tmp_path / "application.rb"
    path.write_text("module App\n  class Application\n  end\nend\n")

    codemod = RubyCallCodemod(call_statement="config.middleware.use Rack::Cors")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "Rack::Cors" in path.read_text()


def test_ruby_inject_constant(tmp_path):
    path = tmp_path / "application.rb"
    path.write_text("require 'rails'\nmodule App\nend\n")

    codemod = RubyConstantCodemod(name="API_KEY", value="ENV['API_KEY']")
    result = codemod._apply_string_based(path)

    assert result.success is True
    assert "API_KEY" in path.read_text()


class _DummyCodemod(JsCodemod):
    def __init__(self, rule):
        self._rule = rule

    def get_rule(self):
        return self._rule

    def _apply_string_based(self, path):
        return ModificationResult(success=True, modified_path=path, changes_made=0)


def test_js_codemod_apply_missing_file(tmp_path):
    codemod = _DummyCodemod({"rule": "const x = 1"})
    missing = tmp_path / "missing.js"

    result = codemod.apply(missing)

    assert result.success is False
    assert "File not found" in result.error


def test_js_codemod_ast_grep_timeout(tmp_path, monkeypatch):
    path = tmp_path / "app.js"
    path.write_text("const x = 1;\n")

    codemod = _DummyCodemod({"rule": "const x = 1"})

    monkeypatch.setattr("foundry.codemods.js_codemods.is_ast_grep_available", lambda: True)
    monkeypatch.setattr("foundry.codemods.js_codemods._resolve_ast_grep_path", lambda: "/usr/bin/ast-grep")

    def _raise_timeout(*_args, **_kwargs):
        raise subprocess.TimeoutExpired(cmd=["ast-grep"], timeout=10)

    monkeypatch.setattr("foundry.codemods.js_codemods.subprocess.run", _raise_timeout)

    result = codemod.apply(path)

    assert result.success is False
    assert "timeout" in result.error


def test_js_codemod_ast_grep_changes(tmp_path, monkeypatch):
    path = tmp_path / "app.js"
    path.write_text("const x = 1;\n")

    codemod = _DummyCodemod({"rule": "const x = 1", "replace": "const y = 2"})

    def _mutating_run(*_args, **_kwargs):
        path.write_text("const y = 2;\n")
        return subprocess.CompletedProcess(_args[0], 0)

    monkeypatch.setattr("foundry.codemods.js_codemods.subprocess.run", _mutating_run)
    monkeypatch.setattr("foundry.codemods.js_codemods._resolve_ast_grep_path", lambda: "/usr/bin/ast-grep")

    result = codemod._apply_ast_grep(path, {"rule": "const x = 1", "replace": "const y = 2"})

    assert result.success is True
    assert result.changes_made == 1


def test_is_ast_grep_available(monkeypatch):
    monkeypatch.setattr(js_codemods.shutil, "which", lambda _name: None)
    js_codemods._resolve_ast_grep_path.cache_clear()
    js_codemods.is_ast_grep_available.cache_clear()
    assert js_codemods.is_ast_grep_available() is False

    monkeypatch.setattr(js_codemods.shutil, "which", lambda _name: "/usr/bin/sg")
    js_codemods._resolve_ast_grep_path.cache_clear()
    js_codemods.is_ast_grep_available.cache_clear()
    assert js_codemods.is_ast_grep_available() is True
