"""
Comprehensive tests for foundry.actions.setup module.

Tests:
- Template setup orchestration
- Tier-based access control
- Setup script execution
- Error handling and reporting
- Force and skip-deps flags
"""

import sys
import subprocess
from pathlib import Path
from types import SimpleNamespace
import pytest


def test_run_setup_basic_success(monkeypatch, tmp_path):
    """Test basic setup with successful execution."""
    from foundry.actions import setup as setup_mod
    
    # Mock templates directory
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create python-saas template directory with setup.py
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup script")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mark python-saas as free tier
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"python-saas": {"tier": "free", "description": "Python SaaS"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    monkeypatch.setattr(setup_mod, "Confirm", SimpleNamespace(ask=lambda *a, **k: True))
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append({"cmd": cmd, "cwd": cwd})
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    setup_mod.run_setup()
    
    assert len(called) == 1
    assert "--env" in called[0]["cmd"]
    assert "dev" in called[0]["cmd"]


def test_run_setup_with_force_and_skip_deps(monkeypatch, tmp_path):
    """Test setup with force and skip-deps flags."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mark python-saas as free tier
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"python-saas": {"tier": "free", "description": "Python SaaS"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    setup_mod.run_setup(force=True, skip_deps=True, env="prod")
    
    assert len(called) == 1
    assert "--force" in called[0]
    assert "--skip-deps" in called[0]
    assert "prod" in called[0]


def test_run_setup_with_strategy(monkeypatch, tmp_path):
    """Test setup with strategy parameter."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mark python-saas as free tier
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"python-saas": {"tier": "free", "description": "Python SaaS"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    monkeypatch.setattr(setup_mod, "Confirm", SimpleNamespace(ask=lambda *a, **k: True))
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    setup_mod.run_setup(strategy="docker")
    
    assert len(called) == 1
    assert "--strategy" in called[0]
    assert "docker" in called[0]


def test_run_setup_tier_restriction(monkeypatch, tmp_path):
    """Test that tier restrictions are enforced."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create a PRO tier template
    mobile_ios = templates_dir / "mobile-ios"
    mobile_ios.mkdir()
    bin_dir = mobile_ios / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mock TEMPLATE_REGISTRY to mark mobile-ios as PRO tier
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"mobile-ios": {"tier": "pro", "description": "iOS"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    setup_mod.run_setup()
    
    # Should not call setup for blocked template
    assert len(called) == 0


def test_run_setup_missing_setup_script(monkeypatch, tmp_path):
    """Test handling of template without setup script."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create template without setup.py
    rails_api = templates_dir / "rails-api"
    rails_api.mkdir()
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    # Should not raise, just skip
    setup_mod.run_setup()
    assert len(called) == 0


def test_run_setup_subprocess_error(monkeypatch, tmp_path):
    """Test handling of subprocess failure."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mark python-saas as free tier
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"python-saas": {"tier": "free", "description": "Python SaaS"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    monkeypatch.setattr(setup_mod, "Confirm", SimpleNamespace(ask=lambda *a, **k: True))
    
    def fake_check_call(cmd, cwd):
        raise subprocess.CalledProcessError(1, cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    with pytest.raises(SystemExit) as excinfo:
        setup_mod.run_setup()
    
    assert excinfo.value.code == 1


def test_run_setup_unexpected_error(monkeypatch, tmp_path):
    """Test handling of unexpected exceptions."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mark python-saas as free tier
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"python-saas": {"tier": "free", "description": "Python SaaS"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    monkeypatch.setattr(setup_mod, "Confirm", SimpleNamespace(ask=lambda *a, **k: True))
    
    def fake_check_call(cmd, cwd):
        raise RuntimeError("Unexpected error")
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    with pytest.raises(SystemExit) as excinfo:
        setup_mod.run_setup()
    
    assert excinfo.value.code == 1


def test_run_setup_multiple_templates(monkeypatch, tmp_path):
    """Test setup with multiple templates."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create multiple templates
    for name in ["python-saas", "rails-api", "react-client"]:
        tmpl_dir = templates_dir / name
        tmpl_dir.mkdir()
        bin_dir = tmpl_dir / "bin"
        bin_dir.mkdir()
        setup_script = bin_dir / "setup.py"
        setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "pro"})
    monkeypatch.setattr(setup_mod, "Confirm", SimpleNamespace(ask=lambda *a, **k: True))
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(str(cwd))
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    setup_mod.run_setup()
    
    # Should call all three templates
    assert len(called) == 3


def test_run_setup_pro_user_can_access_pro_templates(monkeypatch, tmp_path):
    """Test that PRO users can access PRO tier templates."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    mobile_android = templates_dir / "mobile-android"
    mobile_android.mkdir()
    bin_dir = mobile_android / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "pro"})
    
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"mobile-android": {"tier": "pro", "description": "Android"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    monkeypatch.setattr(setup_mod, "Confirm", SimpleNamespace(ask=lambda *a, **k: True))
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    setup_mod.run_setup()
    
    # PRO user should access PRO template
    assert len(called) == 1


def test_run_setup_nonexistent_template_path(monkeypatch, tmp_path):
    """Test handling of templates that don't exist on disk."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Don't create any template directories
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    # Should complete without calling any setup scripts
    setup_mod.run_setup()
    assert len(called) == 0


def test_run_setup_verbose_flag(monkeypatch, tmp_path):
    """Test that verbose flag is accepted (even if not used in logic)."""
    from foundry.actions import setup as setup_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    setup_script = bin_dir / "setup.py"
    setup_script.write_text("# setup")
    
    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", templates_dir)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    
    # Mark python-saas as free tier
    monkeypatch.setattr(
        setup_mod,
        "TEMPLATE_REGISTRY",
        {"python-saas": {"tier": "free", "description": "Python SaaS"}},
    )
    monkeypatch.setattr(setup_mod, "TIER_HIERARCHY", {"free": 0, "pro": 1, "alpha": 2})
    monkeypatch.setattr(setup_mod, "Confirm", SimpleNamespace(ask=lambda *a, **k: True))
    
    called = []
    def fake_check_call(cmd, cwd):
        called.append(cmd)
    
    monkeypatch.setattr(subprocess, "check_call", fake_check_call)
    
    # Should accept verbose flag without error
    setup_mod.run_setup(verbose=True)
    assert len(called) == 1
