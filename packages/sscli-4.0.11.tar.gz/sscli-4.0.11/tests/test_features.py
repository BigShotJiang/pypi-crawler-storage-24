import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch, call
from foundry.actions.features import (
    inject_features, 
    setup_secrets,
    _inject_python_dependencies,
    _inject_sqlite_config,
    _inject_commerce_env_vars,
    _inject_tunnel_config,
    _inject_landing_instructions,
    _inject_rails_routes_fallback,
    _inject_rails_commerce_hexagonal_layers,
    _remove_commerce_files,
    inject_merchant_dashboard,
    _inject_astro_themes_legacy,
    _inject_astro_commerce_legacy,
    _inject_astro_auth_legacy,
    _inject_python_payment_routes,
    _inject_payment_env_vars,
)

@pytest.fixture
def temp_project(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    return project

# ============================================================================
# setup_secrets Tests
# ============================================================================

def test_setup_secrets_dotenv(temp_project):
    example_env = temp_project / ".env.example"
    example_env.write_text("DEBUG=true")
    
    setup_secrets(temp_project, "Dotenv")
    
    target_env = temp_project / ".env"
    assert target_env.exists()
    assert target_env.read_text() == "DEBUG=true"

def test_setup_secrets_dotenv_no_example(temp_project):
    """Test Dotenv strategy when .env.example doesn't exist"""
    setup_secrets(temp_project, "Dotenv")
    target_env = temp_project / ".env"
    assert not target_env.exists()

def test_setup_secrets_dotenv_existing_env(temp_project):
    """Test Dotenv strategy when .env already exists"""
    example_env = temp_project / ".env.example"
    example_env.write_text("DEBUG=true")
    existing_env = temp_project / ".env"
    existing_env.write_text("EXISTING=data")
    
    setup_secrets(temp_project, "Dotenv")
    
    # Should not overwrite existing
    assert existing_env.read_text() == "EXISTING=data"

def test_setup_secrets_doppler(temp_project):
    setup_secrets(temp_project, "Doppler")
    
    doppler_yaml = temp_project / "doppler.yaml"
    assert doppler_yaml.exists()
    assert "project: my-project" in doppler_yaml.read_text()

def test_setup_secrets_other_strategy(temp_project):
    """Test with unrecognized strategy"""
    setup_secrets(temp_project, "UnknownStrategy")
    # Should not create any files
    assert not (temp_project / ".env").exists()
    assert not (temp_project / "doppler.yaml").exists()

# ============================================================================
# inject_features Tests
# ============================================================================

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_commerce_env_vars")
def test_inject_features_commerce_python(mock_env_vars, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=True,
        tunnel=False
    )
    
    mock_inject.assert_any_call(temp_project, "python-saas", "commerce")
    mock_env_vars.assert_called_once_with(temp_project)

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_commerce_env_vars")
@patch("foundry.actions.features._inject_rails_commerce_routes")
@patch("foundry.actions.features._inject_rails_commerce_hexagonal_layers")
def test_inject_features_commerce_rails(mock_layers, mock_routes, mock_env_vars, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="rails-api",
        commerce=True,
        tunnel=False
    )
    
    mock_inject.assert_any_call(temp_project, "rails-api", "commerce")
    mock_env_vars.assert_called_once()
    mock_routes.assert_called_once()
    mock_layers.assert_called_once()


@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_commerce_env_vars")
@patch("foundry.actions.features._inject_rails_commerce_routes")
@patch("foundry.actions.features._inject_rails_commerce_hexagonal_layers")
def test_inject_features_commerce_rails_fullstack(mock_layers, mock_routes, mock_env_vars, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="rails-fullstack",
        commerce=True,
        tunnel=False
    )

    mock_inject.assert_any_call(temp_project, "rails-fullstack", "commerce")
    mock_env_vars.assert_called_once()
    mock_routes.assert_called_once()
    mock_layers.assert_called_once()


def test_inject_rails_commerce_hexagonal_layers_adds_block(temp_project):
    initializer_dir = temp_project / "config" / "initializers"
    initializer_dir.mkdir(parents=True)
    initializer_file = initializer_dir / "hexagonal_layers.rb"
    initializer_file.write_text("require Rails.root.join('app/domain/ports/user_repository')\n")

    _inject_rails_commerce_hexagonal_layers(temp_project)

    content = initializer_file.read_text()
    assert "# commerce-hexagonal-requires" in content
    assert "app/domain/ports/product_repository" in content
    assert "app/infrastructure/repositories/active_record_order_repository" in content
    assert 'File.exist?("#{absolute_path}.rb")' in content


def test_inject_rails_commerce_hexagonal_layers_idempotent(temp_project):
    initializer_dir = temp_project / "config" / "initializers"
    initializer_dir.mkdir(parents=True)
    initializer_file = initializer_dir / "hexagonal_layers.rb"
    initializer_file.write_text("require Rails.root.join('app/domain/ports/user_repository')\n")

    _inject_rails_commerce_hexagonal_layers(temp_project)
    _inject_rails_commerce_hexagonal_layers(temp_project)

    content = initializer_file.read_text()
    assert content.count("# commerce-hexagonal-requires") == 1

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_astro_commerce")
def test_inject_features_commerce_astro(mock_astro, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="static-landing",
        commerce=True,
        tunnel=False
    )
    
    mock_astro.assert_called_once()

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_tunnel_config")
def test_inject_features_tunnel(mock_config, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=True
    )
    
    mock_inject.assert_any_call(temp_project, "python-saas", "tunnel")
    mock_config.assert_called_once_with(temp_project, "python-saas")

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_astro_auth")
def test_inject_features_auth_astro(mock_auth, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="static-landing",
        commerce=False,
        tunnel=False,
        auth=True
    )
    
    mock_auth.assert_called_once()

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_landing_instructions")
def test_inject_features_landing_non_astro(mock_instructions, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        landing=True
    )
    
    mock_inject.assert_any_call(temp_project, "python-saas", "landing")
    mock_instructions.assert_called_once()

@patch("foundry.actions.features._perform_feature_injection")
def test_inject_features_landing_with_dir(mock_inject, temp_project):
    """Test landing injection when static-landing dir exists"""
    landing_dir = temp_project / "static-landing"
    landing_dir.mkdir()
    
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        landing=True
    )
    
    # Should call for base landing, components, and themes
    assert mock_inject.call_count >= 3

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_python_dependencies")
def test_inject_features_admin(mock_deps, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        admin=True
    )
    
    mock_inject.assert_any_call(temp_project, "python-saas", "nicegui-admin")
    mock_deps.assert_called_once_with(temp_project, ["nicegui"])

@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.features._inject_sqlite_config")
@patch("foundry.actions.features._inject_python_dependencies")
def test_inject_features_sqlite(mock_deps, mock_config, mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        sqlite=True
    )
    
    mock_inject.assert_any_call(temp_project, "python-saas", "sqlite-local")
    mock_config.assert_called_once()
    mock_deps.assert_called_once_with(temp_project, ["sqlalchemy", "alembic", "aiosqlite"])

@patch("foundry.actions.features._perform_feature_injection")
def test_inject_features_ingestor(mock_inject, temp_project):
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        ingestor=True
    )
    
    mock_inject.assert_any_call(temp_project, "python-saas", "data-ingestor")

@patch("foundry.actions.features.inject_merchant_dashboard")
def test_inject_features_merchant_dashboard(mock_dashboard, temp_project):
    inject_features(
        path=temp_project,
        template="react-client",
        commerce=False,
        tunnel=False,
        merchant_dashboard=True
    )
    
    mock_dashboard.assert_called_once_with(temp_project)

def test_inject_features_merchant_dashboard_wrong_template(temp_project, capsys):
    """Test merchant dashboard with wrong template"""
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        merchant_dashboard=True
    )
    
    captured = capsys.readouterr()
    assert "only available for react-client" in captured.out.lower()

@patch("foundry.actions.features._perform_feature_injection")
def test_inject_features_static_landing_premium(mock_inject, temp_project):
    """Test static-landing gets premium components"""
    inject_features(
        path=temp_project,
        template="static-landing",
        commerce=False,
        tunnel=False
    )
    
    # Should inject components and themes for premium
    mock_inject.assert_any_call(temp_project, "landing", "components")
    mock_inject.assert_any_call(temp_project, "landing", "themes")

@patch("foundry.actions.features.inject_features_ast")
@patch("foundry.actions.features._perform_feature_injection")
def test_inject_features_ast_mode(mock_inject, mock_ast, temp_project):
    """Test AST injection mode"""
    mock_ast.return_value = None
    
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=True,
        tunnel=False,
        use_ast_injection=True
    )
    
    mock_ast.assert_called_once()

def test_inject_features_ast_fallback(temp_project):
    # Test that if AST injection fails, it falls back to normal injection
    with patch("foundry.actions.features.inject_features_ast") as mock_ast:
        mock_ast.side_effect = Exception("AST failed")
        
        with patch("foundry.actions.features._perform_feature_injection") as mock_perform:
            inject_features(
                path=temp_project,
                template="python-saas",
                commerce=True,
                tunnel=False,
                use_ast_injection=True
            )
            
            # Should have called both
            mock_ast.assert_called()
            mock_perform.assert_called_with(temp_project, "python-saas", "commerce")

# ============================================================================
# Helper Function Tests
# ============================================================================

def test_inject_python_dependencies(temp_project):
    """Test Python dependency injection into pyproject.toml"""
    pyproject = temp_project / "pyproject.toml"
    pyproject.write_text("""[project]
name = "test"
dependencies = []
""")
    
    with patch("foundry.actions.features.IdempotentAddDependencyCM") as mock_cm:
        mock_result = MagicMock(success=True)
        mock_cm.return_value.apply.return_value = mock_result
        
        _inject_python_dependencies(temp_project, ["sqlalchemy", "pytest"])
        
        mock_cm.assert_called_once()
        assert mock_cm.return_value.apply.called

def test_inject_python_dependencies_no_pyproject(temp_project):
    """Test Python dependency injection when pyproject.toml doesn't exist"""
    _inject_python_dependencies(temp_project, ["sqlalchemy"])
    # Should not crash

def test_inject_sqlite_config(temp_project):
    """Test SQLite configuration injection"""
    env_file = temp_project / ".env"
    env_file.write_text("DEBUG=true\n")
    
    _inject_sqlite_config(temp_project)
    
    content = env_file.read_text()
    assert "DATABASE_URL" in content
    assert "sqlite+aiosqlite" in content

def test_inject_sqlite_config_existing_var(temp_project):
    """Test SQLite config doesn't duplicate"""
    env_file = temp_project / ".env"
    env_file.write_text("DATABASE_URL=existing\n")
    
    _inject_sqlite_config(temp_project)
    
    content = env_file.read_text()
    # Should not add another DATABASE_URL
    assert content.count("DATABASE_URL") == 1

def test_inject_sqlite_config_multiple_files(temp_project):
    """Test SQLite config injects into both .env files"""
    env_file = temp_project / ".env"
    env_example = temp_project / ".env.example"
    env_file.write_text("DEBUG=true\n")
    env_example.write_text("DEBUG=false\n")
    
    _inject_sqlite_config(temp_project)
    
    assert "DATABASE_URL" in env_file.read_text()
    assert "DATABASE_URL" in env_example.read_text()

def test_inject_commerce_env_vars(temp_project):
    """Test commerce environment variable injection"""
    env_file = temp_project / ".env"
    env_file.write_text("DEBUG=true\n")
    
    _inject_commerce_env_vars(temp_project)
    
    content = env_file.read_text()
    assert "SHOPIFY_SHOP_NAME" in content
    assert "SHOPIFY_API_KEY" in content
    assert "COMMERCE_ADAPTER_TYPE" in content

def test_inject_commerce_env_vars_existing(temp_project):
    """Test commerce env vars don't duplicate"""
    env_file = temp_project / ".env"
    env_file.write_text("SHOPIFY_SHOP_NAME=existing\n")
    
    _inject_commerce_env_vars(temp_project)
    
    content = env_file.read_text()
    assert content.count("SHOPIFY_SHOP_NAME") == 1

def test_inject_tunnel_config_env(temp_project):
    """Test tunnel configuration injection"""
    env_file = temp_project / ".env"
    env_file.write_text("DEBUG=true\n")
    
    _inject_tunnel_config(temp_project, "python-saas")
    
    content = env_file.read_text()
    assert "NGROK_AUTHTOKEN" in content

def test_inject_tunnel_config_docker_compose(temp_project):
    """Test tunnel Docker Compose service injection"""
    compose = temp_project / "docker-compose.yml"
    compose.write_text("""version: '3.8'
services:
  python-saas:
    image: test
""")
    
    _inject_tunnel_config(temp_project, "python-saas")
    
    content = compose.read_text()
    assert "tunnel:" in content
    assert "ngrok/ngrok" in content

def test_inject_tunnel_config_existing(temp_project):
    """Test tunnel config doesn't duplicate"""
    compose = temp_project / "docker-compose.yml"
    compose.write_text("""services:
  tunnel:
    image: ngrok/ngrok
""")
    
    _inject_tunnel_config(temp_project, "python-saas")
    
    content = compose.read_text()
    assert content.count("tunnel:") == 1

def test_inject_tunnel_config_readme(temp_project):
    """Test tunnel instructions added to README"""
    readme = temp_project / "README.md"
    readme.write_text("# Project\n")
    
    _inject_tunnel_config(temp_project, "python-saas")
    
    content = readme.read_text()
    assert "ngrok" in content.lower()

def test_inject_landing_instructions(temp_project):
    """Test landing page instructions injection"""
    readme = temp_project / "README.md"
    readme.write_text("# Project\n")
    
    _inject_landing_instructions(temp_project)
    
    content = readme.read_text()
    assert "Static Landing Page" in content
    assert "Astro" in content
    assert "npm run dev" in content

def test_inject_landing_instructions_no_readme(temp_project):
    """Test landing instructions when README doesn't exist"""
    _inject_landing_instructions(temp_project)
    # Should not crash

def test_inject_rails_routes_fallback(temp_project):
    """Test Rails routes fallback injection"""
    config_dir = temp_project / "config"
    config_dir.mkdir()
    routes = config_dir / "routes.rb"
    routes.write_text("""Rails.application.routes.draw do
  root 'pages#home'
end
""")
    
    _inject_rails_routes_fallback(temp_project)
    
    content = routes.read_text()
    assert "namespace :webhooks" in content
    assert "shopify" in content

def test_inject_rails_routes_fallback_existing(temp_project):
    """Test Rails routes fallback doesn't duplicate"""
    config_dir = temp_project / "config"
    config_dir.mkdir()
    routes = config_dir / "routes.rb"
    routes.write_text("""Rails.application.routes.draw do
  namespace :webhooks do
    post 'shopify', to: 'shopify#handle'
  end
end
""")
    
    _inject_rails_routes_fallback(temp_project)
    
    content = routes.read_text()
    assert content.count("namespace :webhooks") == 1

def test_inject_rails_routes_fallback_no_file(temp_project):
    """Test Rails routes fallback when file doesn't exist"""
    _inject_rails_routes_fallback(temp_project)
    # Should not crash

def test_remove_commerce_files_python(temp_project):
    """Test commerce file removal for Python"""
    src = temp_project / "src"
    src.mkdir()
    
    # Create commerce files
    infra = src / "infrastructure" / "commerce"
    infra.mkdir(parents=True)
    (infra / "test.py").write_text("test")
    
    core = src / "core" / "interfaces"
    core.mkdir(parents=True)
    (core / "commerce.py").write_text("test")
    
    _remove_commerce_files(temp_project, "python-saas")
    
    assert not infra.exists()
    assert not (core / "commerce.py").exists()

def test_remove_commerce_files_rails(temp_project):
    """Test commerce file removal for Rails"""
    app = temp_project / "app"
    app.mkdir()
    
    services = app / "services" / "commerce"
    services.mkdir(parents=True)
    (services / "test.rb").write_text("test")
    
    controllers = app / "controllers" / "webhooks"
    controllers.mkdir(parents=True)
    (controllers / "shopify_controller.rb").write_text("test")
    
    _remove_commerce_files(temp_project, "rails-api")
    
    assert not services.exists()
    assert not (controllers / "shopify_controller.rb").exists()


def test_remove_commerce_files_rails_fullstack(temp_project):
    """Test commerce file removal for Rails Fullstack"""
    app = temp_project / "app"
    app.mkdir()

    services = app / "services" / "commerce"
    services.mkdir(parents=True)
    (services / "test.rb").write_text("test")

    controllers = app / "controllers" / "webhooks"
    controllers.mkdir(parents=True)
    (controllers / "shopify_controller.rb").write_text("test")

    _remove_commerce_files(temp_project, "rails-fullstack")

    assert not services.exists()
    assert not (controllers / "shopify_controller.rb").exists()


def test_inject_merchant_dashboard(temp_project):
    """Test merchant dashboard injection"""
    src = temp_project / "src"
    src.mkdir()
    app_jsx = src / "App.jsx"
    app_jsx.write_text("""import React from 'react';
import { Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
    </Routes>
  );
}
""")
    
    env_file = temp_project / ".env"
    env_file.write_text("DEBUG=true\n")
    
    # Mock vault directory that doesn't exist
    vault = temp_project / "vault" / "features" / "react-client" / "merchant-dashboard"
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        inject_merchant_dashboard(temp_project)
    
    # Check imports and routes added
    content = app_jsx.read_text()
    assert "MerchantDashboard" in content
    assert "/dashboard" in content
    
    # Check env vars added
    env_content = env_file.read_text()
    assert "VITE_API_BASE_URL" in env_content
    assert "DASHBOARD_ENABLED" in env_content

def test_inject_merchant_dashboard_with_vault(temp_project):
    """Test merchant dashboard with vault files"""
    src = temp_project / "src"
    src.mkdir()
    app_jsx = src / "App.jsx"
    app_jsx.write_text("""import React from 'react';
import { Routes, Route } from 'react-router-dom';

function App() {
  return <Routes><Route path="/" element={<Home />} /></Routes>;
}
""")
    
    # Create temp vault structure
    vault_base = temp_project / "vault"
    dashboard_dir = vault_base / "features" / "react-client" / "merchant-dashboard"
    dashboard_dir.mkdir(parents=True)
    (dashboard_dir / "test.jsx").write_text("test component")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", vault_base):
        inject_merchant_dashboard(temp_project)
    
    # Vault file should be copied
    assert (temp_project / "test.jsx").exists()

def test_inject_astro_themes_legacy(temp_project):
    """Test legacy Astro themes injection"""
    src = temp_project / "src" / "styles"
    src.mkdir(parents=True)
    themes_file = src / "themes.css"
    themes_file.write_text("""/* Base styles */
/* [SS-FEATURE-THEMES-START] */
/* [SS-FEATURE-THEMES-END] */
/* More styles */
""")
    
    # Mock vault
    vault = temp_project / "vault" / "features"
    vault_landing = vault / "landing" / "themes"
    vault_landing.mkdir(parents=True)
    vault_themes = vault_landing / "themes.css"
    vault_themes.write_text(":root { --premium: #gold; }")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _inject_astro_themes_legacy(temp_project)
    
    content = themes_file.read_text()
    assert "--premium" in content

def test_inject_astro_commerce_legacy(temp_project):
    """Test legacy Astro commerce injection"""
    src = temp_project / "src" / "pages"
    src.mkdir(parents=True)
    index_file = src / "index.astro"
    index_file.write_text("""<div>
{/* [SS-FEATURE-COMMERCE-START] */}
{/* [SS-FEATURE-COMMERCE-END] */}
</div>
""")
    
    # Mock vault
    vault = temp_project / "vault" / "features"
    vault_landing = vault / "landing" / "commerce"
    vault_landing.mkdir(parents=True)
    pricing = vault_landing / "pricing.astro"
    pricing.write_text("<PricingComponent />")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _inject_astro_commerce_legacy(temp_project)
    
    content = index_file.read_text()
    assert "PricingComponent" in content

def test_inject_astro_commerce_legacy_with_config(temp_project):
    """Test legacy Astro commerce with config injection"""
    # Create index.astro with markers
    src_pages = temp_project / "src" / "pages"
    src_pages.mkdir(parents=True)
    index_file = src_pages / "index.astro"
    index_file.write_text("""{/* [SS-FEATURE-COMMERCE-START] */}
{/* [SS-FEATURE-COMMERCE-END] */}
""")
    
    # Create astro.config.mjs with markers
    config_file = temp_project / "astro.config.mjs"
    config_file.write_text("""export default {
  integrations: [
    /* [SS-FEATURE-SDK-INTEGRATIONS-START] */
    /* [SS-FEATURE-SDK-INTEGRATIONS-END] */
  ]
};
""")
    
    # Mock vault
    vault = temp_project / "vault" / "features"
    vault_landing = vault / "landing" / "commerce"
    vault_landing.mkdir(parents=True)
    pricing = vault_landing / "pricing.astro"
    pricing.write_text("<Pricing />")
    integrations = vault_landing / "astro.integrations.mjs"
    integrations.write_text("shopify()")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _inject_astro_commerce_legacy(temp_project)
    
    config_content = config_file.read_text()
    assert "shopify()" in config_content

def test_inject_astro_auth_legacy(temp_project):
    """Test legacy Astro auth injection"""
    src = temp_project / "src" / "pages"
    src.mkdir(parents=True)
    index_file = src / "index.astro"
    index_file.write_text("""<div>
{/* [SS-FEATURE-AUTH-START] */}
{/* [SS-FEATURE-AUTH-END] */}
</div>
""")
    
    # Mock vault
    vault = temp_project / "vault" / "features"
    vault_landing = vault / "landing" / "auth"
    vault_landing.mkdir(parents=True)
    auth_section = vault_landing / "auth-section.astro"
    auth_section.write_text("<AuthComponent />")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _inject_astro_auth_legacy(temp_project)
    
    content = index_file.read_text()
    assert "AuthComponent" in content

# ============================================================================
# Advanced Function Tests (_perform_feature_injection, AST helpers)
# ============================================================================

def test_perform_feature_injection_from_vault(temp_project):
    """Test feature injection from vault directory"""
    from foundry.actions.features import _perform_feature_injection
    
    # Create mock vault structure
    vault = temp_project / "vault" / "features"
    feature_dir = vault / "python-saas" / "commerce"
    feature_dir.mkdir(parents=True)
    (feature_dir / "test.py").write_text("commerce code")
    
    # Create target project
    target = temp_project / "target"
    target.mkdir()
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _perform_feature_injection(target, "python-saas", "commerce")
    
    # Check file was copied
    assert (target / "test.py").exists()

def test_perform_feature_injection_generic_feature(temp_project):
    """Test generic feature injection (not template-specific)"""
    from foundry.actions.features import _perform_feature_injection
    
    # Create mock vault with generic feature
    vault = temp_project / "vault" / "features"
    feature_dir = vault / "commerce"
    feature_dir.mkdir(parents=True)
    (feature_dir / "generic.py").write_text("generic commerce")
    
    target = temp_project / "target"
    target.mkdir()
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _perform_feature_injection(target, "python-saas", "commerce")
    
    # File should be copied from generic location
    assert (target / "generic.py").exists()

def test_perform_feature_injection_with_themes(temp_project):
    """Test feature injection with theme triggers"""
    from foundry.actions.features import _perform_feature_injection
    
    vault = temp_project / "vault" / "features"
    feature_dir = vault / "landing" / "themes"
    feature_dir.mkdir(parents=True)
    (feature_dir / "theme.css").write_text("theme")
    
    target = temp_project / "target"
    src_styles = target / "src" / "styles"
    src_styles.mkdir(parents=True)
    themes_css = src_styles / "themes.css"
    themes_css.write_text("/* [SS-FEATURE-THEMES-START] */\n/* [SS-FEATURE-THEMES-END] */")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features._inject_astro_themes") as mock_themes:
            _perform_feature_injection(target, "landing", "themes")
            mock_themes.assert_called_once()

def test_inject_astro_themes_with_ast_grep(temp_project):
    """Test Astro themes injection with ast-grep"""
    from foundry.actions.features import _inject_astro_themes
    
    src = temp_project / "src" / "styles"
    src.mkdir(parents=True)
    themes_file = src / "themes.css"
    themes_file.write_text(":root { }")
    
    vault = temp_project / "vault" / "features"
    vault_landing = vault / "landing" / "themes"
    vault_landing.mkdir(parents=True)
    vault_themes = vault_landing / "themes.css"
    vault_themes.write_text(":root { --premium: #gold; }")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features.AstGrepRunner") as mock_runner:
            runner_instance = MagicMock()
            runner_instance.is_available.return_value = True
            runner_instance.inject_rule.return_value = True
            mock_runner.return_value = runner_instance
            
            _inject_astro_themes(temp_project)
            
            runner_instance.inject_rule.assert_called_once()

def test_inject_astro_themes_ast_grep_unavailable(temp_project):
    """Test Astro themes falls back when ast-grep unavailable"""
    from foundry.actions.features import _inject_astro_themes
    
    src = temp_project / "src" / "styles"
    src.mkdir(parents=True)
    themes_file = src / "themes.css"
    themes_file.write_text(":root { }")
    
    vault = temp_project / "vault" / "features"
    vault_landing = vault / "landing" / "themes"
    vault_landing.mkdir(parents=True)
    vault_themes = vault_landing / "themes.css"
    vault_themes.write_text(":root { --premium: #gold; }")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features.AstGrepRunner") as mock_runner:
            runner_instance = MagicMock()
            runner_instance.is_available.return_value = False
            mock_runner.return_value = runner_instance
            
            with patch("foundry.actions.features._inject_astro_themes_legacy") as mock_legacy:
                _inject_astro_themes(temp_project)
                mock_legacy.assert_called_once()

def test_inject_astro_themes_ast_grep_exception(temp_project):
    """Test Astro themes handles ast-grep exceptions"""
    from foundry.actions.features import _inject_astro_themes
    
    src = temp_project / "src" / "styles"
    src.mkdir(parents=True)
    themes_file = src / "themes.css"
    themes_file.write_text(":root { }")
    
    vault = temp_project / "vault" / "features"
    vault_landing = vault / "landing" / "themes"
    vault_landing.mkdir(parents=True)
    vault_themes = vault_landing / "themes.css"
    vault_themes.write_text(":root { --premium: #gold; }")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features.AstGrepRunner") as mock_runner:
            runner_instance = MagicMock()
            runner_instance.is_available.return_value = True
            runner_instance.inject_rule.side_effect = Exception("ast-grep failed")
            mock_runner.return_value = runner_instance
            
            with patch("foundry.actions.features._inject_astro_themes_legacy") as mock_legacy:
                _inject_astro_themes(temp_project)
                mock_legacy.assert_called_once()

def test_inject_astro_commerce_with_ast_grep(temp_project):
    """Test Astro commerce injection with ast-grep"""
    from foundry.actions.features import _inject_astro_commerce
    
    src = temp_project / "src" / "pages"
    src.mkdir(parents=True)
    index_file = src / "index.astro"
    index_file.write_text("<div></div>")
    
    vault = temp_project / "vault" / "features"
    vault_commerce = vault / "landing" / "commerce"
    vault_commerce.mkdir(parents=True)
    (vault_commerce / "pricing.astro").write_text("<Pricing />")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features.AstGrepRunner") as mock_runner:
            runner_instance = MagicMock()
            runner_instance.is_available.return_value = True
            runner_instance.inject_rule.return_value = True
            mock_runner.return_value = runner_instance
            
            _inject_astro_commerce(temp_project)
            
            assert runner_instance.inject_rule.call_count >= 1

def test_inject_astro_commerce_ast_unavailable(temp_project):
    """Test Astro commerce falls back when ast-grep unavailable"""
    from foundry.actions.features import _inject_astro_commerce
    
    src = temp_project / "src" / "pages"
    src.mkdir(parents=True)
    index_file = src / "index.astro"
    index_file.write_text("<div></div>")
    
    vault = temp_project / "vault" / "features"
    vault_commerce = vault / "landing" / "commerce"
    vault_commerce.mkdir(parents=True)
    (vault_commerce / "pricing.astro").write_text("<Pricing />")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features.AstGrepRunner") as mock_runner:
            runner_instance = MagicMock()
            runner_instance.is_available.return_value = False
            mock_runner.return_value = runner_instance
            
            with patch("foundry.actions.features._inject_astro_commerce_legacy") as mock_legacy:
                _inject_astro_commerce(temp_project)
                mock_legacy.assert_called_once()

def test_inject_astro_auth_with_ast_grep(temp_project):
    """Test Astro auth injection with ast-grep"""
    from foundry.actions.features import _inject_astro_auth
    
    src = temp_project / "src" / "pages"
    src.mkdir(parents=True)
    index_file = src / "index.astro"
    index_file.write_text("<div></div>")
    
    vault = temp_project / "vault" / "features"
    vault_auth = vault / "landing" / "auth"
    vault_auth.mkdir(parents=True)
    (vault_auth / "auth-section.astro").write_text("<Auth />")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features.AstGrepRunner") as mock_runner:
            runner_instance = MagicMock()
            runner_instance.is_available.return_value = True
            runner_instance.inject_rule.return_value = True
            mock_runner.return_value = runner_instance
            
            _inject_astro_auth(temp_project)
            
            runner_instance.inject_rule.assert_called_once()

def test_inject_rails_commerce_routes_with_synvert(temp_project):
    """Test Rails commerce routes with Synvert"""
    from foundry.actions.features import _inject_rails_commerce_routes
    
    config_dir = temp_project / "config"
    config_dir.mkdir()
    routes = config_dir / "routes.rb"
    routes.write_text("Rails.application.routes.draw do\nend\n")
    
    with patch("foundry.actions.features.SynvertAdapter") as mock_adapter:
        adapter_instance = MagicMock()
        adapter_instance.add_webhook_routes.return_value = {"success": True}
        adapter_instance.validate_ruby_syntax.return_value = {"valid": True}
        mock_adapter.return_value = adapter_instance
        
        _inject_rails_commerce_routes(temp_project)
        
        adapter_instance.add_webhook_routes.assert_called_once()

def test_inject_rails_commerce_routes_synvert_failure(temp_project):
    """Test Rails commerce routes falls back when Synvert fails"""
    from foundry.actions.features import _inject_rails_commerce_routes
    
    config_dir = temp_project / "config"
    config_dir.mkdir()
    routes = config_dir / "routes.rb"
    routes.write_text("Rails.application.routes.draw do\nend\n")
    
    with patch("foundry.actions.features.SynvertAdapter") as mock_adapter:
        adapter_instance = MagicMock()
        adapter_instance.add_webhook_routes.return_value = {"success": False, "error_message": "Failed"}
        mock_adapter.return_value = adapter_instance
        
        _inject_rails_commerce_routes(temp_project)
        
        # Should still attempt the injection
        adapter_instance.add_webhook_routes.assert_called_once()

def test_inject_rails_commerce_routes_synvert_unavailable(temp_project):
    """Test Rails commerce routes when Synvert unavailable"""
    from foundry.actions.features import _inject_rails_commerce_routes
    
    config_dir = temp_project / "config"
    config_dir.mkdir()
    routes = config_dir / "routes.rb"
    routes.write_text("Rails.application.routes.draw do\nend\n")
    
    with patch("foundry.actions.features.SynvertAdapter") as mock_adapter:
        mock_adapter.side_effect = RuntimeError("Synvert not available")
        
        with patch("foundry.actions.features._inject_rails_routes_fallback") as mock_fallback:
            _inject_rails_commerce_routes(temp_project)
            mock_fallback.assert_called_once()

def test_inject_rails_commerce_routes_invalid_syntax(temp_project):
    """Test Rails commerce routes with syntax validation failure"""
    from foundry.actions.features import _inject_rails_commerce_routes
    
    config_dir = temp_project / "config"
    config_dir.mkdir()
    routes = config_dir / "routes.rb"
    routes.write_text("Rails.application.routes.draw do\nend\n")
    
    with patch("foundry.actions.features.SynvertAdapter") as mock_adapter:
        adapter_instance = MagicMock()
        adapter_instance.add_webhook_routes.return_value = {"success": True}
        adapter_instance.validate_ruby_syntax.return_value = {"valid": False, "error": "Syntax error"}
        mock_adapter.return_value = adapter_instance
        
        _inject_rails_commerce_routes(temp_project)
        
        # Should still complete but print error
        adapter_instance.validate_ruby_syntax.assert_called_once()

# ============================================================================
# AST Codemods Tests (inject_features_ast and helpers)
# ============================================================================

def test_inject_python_saas_codemods_imports(tmp_path):
    """Test Python SaaS codemods for imports"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    app_py = src / "app.py"
    app_py.write_text("# Main app\n")
    
    features = {
        'imports': [
            {'module': 'commerce', 'names': ['init_commerce']},
        ]
    }
    
    with patch("foundry.actions.features.PythonInjectImportCodemod") as mock_cm:
        mock_result = MagicMock(changes_made=1, metadata={})
        mock_cm.return_value.apply.return_value = mock_result
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        assert len(result['changes']) > 0
        mock_cm.assert_called_once()

def test_inject_python_saas_codemods_calls(tmp_path):
    """Test Python SaaS codemods for function calls"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    app_py = src / "app.py"
    app_py.write_text("def init_ui():\n    pass\n")
    
    features = {
        'calls': [
            {'target': 'init_ui', 'stmt': 'init_commerce(ui)'},
        ]
    }
    
    with patch("foundry.actions.features.PythonInjectCallCodemod") as mock_cm:
        mock_result = MagicMock(changes_made=1, metadata={'target_found': True})
        mock_cm.return_value.apply.return_value = mock_result
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        mock_cm.assert_called()

def test_inject_python_saas_codemods_calls_already_present(tmp_path):
    """Test Python SaaS codemods when calls already present"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    app_py = src / "app.py"
    app_py.write_text("def init_ui():\n    init_commerce(ui)\n")
    
    features = {
        'calls': [
            {'stmt': 'init_commerce(ui)'},
        ]
    }
    
    with patch("foundry.actions.features.PythonInjectCallCodemod") as mock_cm:
        mock_result = MagicMock(
            changes_made=0, 
            metadata={'already_present': True, 'target_found': True}
        )
        mock_cm.return_value.apply.return_value = mock_result
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        assert result['success'] is True

def test_inject_python_saas_codemods_calls_fallback_targets(tmp_path):
    """Test Python SaaS codemods tries fallback targets"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    app_py = src / "app.py"
    app_py.write_text("def main():\n    pass\n")
    
    features = {
        'calls': [
            {'stmt': 'setup()'},  # No explicit target
        ]
    }
    
    with patch("foundry.actions.features.PythonInjectCallCodemod") as mock_cm:
        # First 3 calls fail, 4th succeeds
        mock_cm.return_value.apply.side_effect = [
            MagicMock(changes_made=0, metadata={'target_found': False}),
            MagicMock(changes_made=1, metadata={'target_found': True}),
        ]
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        # Should have tried multiple targets
        assert mock_cm.call_count >= 1

def test_inject_python_saas_codemods_constants(tmp_path):
    """Test Python SaaS codemods for constants"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    app_py = src / "app.py"
    app_py.write_text("# Config\n")
    
    features = {
        'constants': [
            {'name': 'VERSION', 'value': "'1.0.0'"},
        ]
    }
    
    with patch("foundry.actions.features.PythonInjectConstantCodemod") as mock_cm:
        mock_result = MagicMock(changes_made=1, metadata={})
        mock_cm.return_value.apply.return_value = mock_result
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        mock_cm.assert_called_once()

def test_inject_python_saas_codemods_dependencies(tmp_path):
    """Test Python SaaS codemods for dependencies"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("[project]\ndependencies = []\n")
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    (src / "app.py").write_text("# App")
    
    features = {
        'dependencies': ['sqlalchemy', 'pytest']
    }
    
    with patch("foundry.actions.features.IdempotentAddDependencyCM") as mock_cm:
        mock_result = MagicMock(success=True, changes_made=2)
        mock_cm.return_value.apply.return_value = mock_result
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        mock_cm.assert_called_once()

def test_inject_python_saas_codemods_no_entry_point(tmp_path):
    """Test Python SaaS codemods when no entry point found"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    features = {
        'imports': [{'module': 'test'}]
    }
    
    result = _inject_python_saas_codemods(tmp_path, features, False)
    
    assert result['success'] is True
    assert len(result['skipped']) > 0

def test_inject_python_saas_codemods_error_handling(tmp_path):
    """Test Python SaaS codemods error handling"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    (src / "app.py").write_text("# App")
    
    features = {
        'imports': [{'module': 'test'}]
    }
    
    with patch("foundry.actions.features.PythonInjectImportCodemod") as mock_cm:
        mock_cm.return_value.apply.side_effect = Exception("Test error")
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        assert len(result['errors']) > 0

def test_inject_react_codemods_success(tmp_path):
    """Test React codemods injection"""
    from foundry.actions.features import _inject_react_codemods
    
    src = tmp_path / "src"
    src.mkdir()
    app_jsx = src / "App.jsx"
    app_jsx.write_text("import React from 'react';\n")
    
    features = {
        'imports': [{'module': 'Dashboard', 'type': 'esm'}],
        'routes': [{'path': '/dashboard', 'component': 'Dashboard'}],
        'constants': [{'name': 'API_URL', 'value': "'http://localhost'"}]
    }
    
    with patch("foundry.actions.features.JsInjectImportCodemod") as mock_import, \
         patch("foundry.actions.features.JsInjectRouteCodemod") as mock_route, \
         patch("foundry.actions.features.JsInjectConstantCodemod") as mock_const:
        
        result = _inject_react_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        assert mock_import.called
        assert mock_route.called
        assert mock_const.called

def test_inject_react_codemods_no_app_jsx(tmp_path):
    """Test React codemods when App.jsx not found"""
    from foundry.actions.features import _inject_react_codemods
    
    features = {'imports': [{'module': 'Test'}]}
    
    result = _inject_react_codemods(tmp_path, features, False)
    
    assert result['success'] is True
    assert len(result['skipped']) > 0

def test_inject_react_codemods_error_handling(tmp_path):
    """Test React codemods error handling"""
    from foundry.actions.features import _inject_react_codemods
    
    src = tmp_path / "src"
    src.mkdir()
    (src / "App.jsx").write_text("import React from 'react';\n")
    
    features = {'imports': [{'module': 'Test'}]}
    
    with patch("foundry.actions.features.JsInjectImportCodemod") as mock_cm:
        mock_cm.return_value.apply.side_effect = Exception("Test error")
        
        result = _inject_react_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        assert len(result['errors']) > 0

def test_inject_rails_codemods_success(tmp_path):
    """Test Rails codemods injection"""
    from foundry.actions.features import _inject_rails_codemods
    
    config = tmp_path / "config"
    config.mkdir()
    routes = config / "routes.rb"
    routes.write_text("Rails.application.routes.draw do\nend\n")
    
    features = {
        'routes': [
            {
                'method': 'post',
                'path': '/webhooks/shopify',
                'action': 'webhooks#shopify'
            }
        ]
    }
    
    with patch("foundry.actions.features.RubyInjectRouteCodemod") as mock_cm:
        result = _inject_rails_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        mock_cm.assert_called_once()

def test_inject_rails_codemods_no_routes_file(tmp_path):
    """Test Rails codemods when routes.rb not found"""
    from foundry.actions.features import _inject_rails_codemods
    
    features = {'routes': [{'path': '/test', 'action': 'test#index'}]}
    
    result = _inject_rails_codemods(tmp_path, features, False)
    
    assert result['success'] is True
    assert len(result['skipped']) > 0

def test_inject_rails_codemods_dependencies(tmp_path):
    """Test Rails codemods dependency handling"""
    from foundry.actions.features import _inject_rails_codemods
    
    config = tmp_path / "config"
    config.mkdir()
    (config / "routes.rb").write_text("Rails.application.routes.draw do\nend\n")
    
    features = {'dependencies': ['devise', 'pundit']}
    
    result = _inject_rails_codemods(tmp_path, features, False)
    
    # Dependencies not yet implemented for Rails
    assert 'Gemfile dependency injection not yet implemented' in result['skipped']

def test_inject_features_ast_unknown_template(tmp_path):
    """Test inject_features_ast with unknown template"""
    from foundry.actions.features import inject_features_ast
    
    result = inject_features_ast(tmp_path, "unknown-template", {})
    
    assert result['success'] is False
    assert "Unknown template" in result['errors'][0]

def test_inject_features_ast_exception_handling(tmp_path):
    """Test inject_features_ast exception handling"""
    from foundry.actions.features import inject_features_ast
    
    with patch("foundry.actions.features._inject_python_saas_codemods") as mock_cm:
        mock_cm.side_effect = Exception("Unexpected error")
        
        result = inject_features_ast(tmp_path, "python-saas", {})
        
        assert result['success'] is False
        assert len(result['errors']) > 0

def test_inject_features_ast_checks_binaries(tmp_path):
    """Test inject_features_ast checks for required binaries"""
    from foundry.actions.features import inject_features_ast
    
    # The function does local imports of is_ast_grep_available
    # We need to patch them where they're used
    with patch("foundry.codemods.js_codemods.is_ast_grep_available") as mock_js, \
         patch("foundry.codemods.ruby_codemods.is_ast_grep_available") as mock_rb:
        
        mock_js.return_value = False
        mock_rb.return_value = False
        
        # Should still succeed but print warnings
        result = inject_features_ast(tmp_path, "react-client", {})
        
        # Will fail because no App.jsx, but binary check should have run
        mock_js.assert_called_once()

# ============================================================================
# Additional Coverage Tests for 95%+ Target
# ============================================================================

def test_inject_features_ast_rails_commerce(temp_project):
    """Test AST injection for Rails commerce"""
    with patch("foundry.actions.features.inject_features_ast") as mock_ast:
        mock_ast.return_value = None
        
        inject_features(
            path=temp_project,
            template="rails-api",
            commerce=True,
            tunnel=False,
            use_ast_injection=True
        )
        
        # Should call inject_features_ast with rails commerce features
        mock_ast.assert_called_once()
        call_args = mock_ast.call_args
        assert "rails" in call_args[1]['template']


def test_inject_features_ast_rails_fullstack_commerce(temp_project):
    """Test AST injection for Rails Fullstack commerce"""
    with patch("foundry.actions.features.inject_features_ast") as mock_ast:
        mock_ast.return_value = None

        inject_features(
            path=temp_project,
            template="rails-fullstack",
            commerce=True,
            tunnel=False,
            use_ast_injection=True
        )

        # Should call inject_features_ast with rails-fullstack commerce features
        mock_ast.assert_called_once()
        call_args = mock_ast.call_args
        assert "rails" in call_args[1]['template']


def test_inject_features_ast_auth_python(temp_project):
    """Test AST injection for Python auth"""
    with patch("foundry.actions.features.inject_features_ast") as mock_ast:
        mock_ast.return_value = None
        
        inject_features(
            path=temp_project,
            template="python-saas",
            commerce=False,
            tunnel=False,
            auth=True,
            use_ast_injection=True
        )
        
        mock_ast.assert_called_once()

def test_inject_features_ast_auth_react(temp_project):
    """Test AST injection for React auth"""
    with patch("foundry.actions.features.inject_features_ast") as mock_ast:
        mock_ast.return_value = None
        
        inject_features(
            path=temp_project,
            template="react-client",
            commerce=False,
            tunnel=False,
            auth=True,
            use_ast_injection=True
        )
        
        mock_ast.assert_called_once()

def test_inject_features_ast_admin(temp_project):
    """Test AST injection for admin panel"""
    with patch("foundry.actions.features.inject_features_ast") as mock_ast:
        mock_ast.return_value = None
        
        inject_features(
            path=temp_project,
            template="python-saas",
            commerce=False,
            tunnel=False,
            admin=True,
            use_ast_injection=True
        )
        
        mock_ast.assert_called_once()

def test_inject_features_ast_sqlite(temp_project):
    """Test AST injection for SQLite"""
    with patch("foundry.actions.features.inject_features_ast") as mock_ast:
        mock_ast.return_value = None
        
        inject_features(
            path=temp_project,
            template="python-saas",
            commerce=False,
            tunnel=False,
            sqlite=True,
            use_ast_injection=True
        )
        
        mock_ast.assert_called_once()

def test_perform_feature_injection_local_folder(temp_project):
    """Test feature injection from local project features/ folder"""
    from foundry.actions.features import _perform_feature_injection
    
    # No vault, but local features folder exists
    local_features = temp_project / "features" / "commerce"
    local_features.mkdir(parents=True)
    (local_features / "local.py").write_text("local feature")
    
    # Mock FOUNDRY_ROOT to point to non-existent vault
    vault = temp_project / "nonexistent"
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", vault):
        _perform_feature_injection(temp_project, "python-saas", "commerce")
    
    # Local file should be  copied
    assert (temp_project / "local.py").exists()

def test_inject_python_saas_codemods_call_not_found(tmp_path):
    """Test Python SaaS codemods when no suitable target function found"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    app_py = src / "app.py"
    app_py.write_text("# No functions\n")
    
    features = {
        'calls': [
            {'stmt': 'setup()'},  # No target, no matching functions
        ]
    }
    
    with patch("foundry.actions.features.PythonInjectCallCodemod") as mock_cm:
        # All targets fail
        mock_cm.return_value.apply.return_value = MagicMock(
            changes_made=0, 
            metadata={'target_found': False}
        )
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        # Should have skipped
        assert len(result['skipped']) > 0

def test_inject_python_saas_codemods_dependency_no_changes(tmp_path):
    """Test Python SaaS codemods when dependencies already present"""
    from foundry.actions.features import _inject_python_saas_codemods
    
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("[project]\ndependencies = ['sqlalchemy']\n")
    
    src = tmp_path / "src" / "ui"
    src.mkdir(parents=True)
    (src / "app.py").write_text("# App")
    
    features = {
        'dependencies': ['sqlalchemy']
    }
    
    with patch("foundry.actions.features.IdempotentAddDependencyCM") as mock_cm:
        mock_result = MagicMock(success=True, changes_made=0)
        mock_cm.return_value.apply.return_value = mock_result
        
        result = _inject_python_saas_codemods(tmp_path, features, False)
        
        assert result['success'] is True

def test_inject_rails_codemods_error_handling(tmp_path):
    """Test Rails codemods error handling"""
    from foundry.actions.features import _inject_rails_codemods
    
    config = tmp_path / "config"
    config.mkdir()
    (config / "routes.rb").write_text("Rails.application.routes.draw do\nend\n")
    
    features = {'routes': [{'path': '/test', 'action': 'test#index'}]}
    
    with patch("foundry.actions.features.RubyInjectRouteCodemod") as mock_cm:
        mock_cm.return_value.apply.side_effect = Exception("Test error")
        
        result = _inject_rails_codemods(tmp_path, features, False)
        
        assert result['success'] is True
        assert len(result['errors']) > 0

def test_inject_astro_commerce_with_config_integration(temp_project):
    """Test Astro commerce with config file integration"""
    from foundry.actions.features import _inject_astro_commerce
    
    # Create all necessary files
    src = temp_project / "src" / "pages"
    src.mkdir(parents=True)
    index_file = src / "index.astro"
    index_file.write_text("<div></div>")
    
    config_file = temp_project / "astro.config.mjs"
    config_file.write_text("export default { integrations: [] };")
    
    vault = temp_project / "vault" / "features"
    vault_commerce = vault / "landing" / "commerce"
    vault_commerce.mkdir(parents=True)
    (vault_commerce / "pricing.astro").write_text("<Pricing />")
    (vault_commerce / "astro.integrations.mjs").write_text("shopify()")
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        with patch("foundry.actions.features.AstGrepRunner") as mock_runner:
            runner_instance = MagicMock()
            runner_instance.is_available.return_value = True
            runner_instance.inject_rule.return_value = True
            mock_runner.return_value = runner_instance
            
            _inject_astro_commerce(temp_project)
            
            # Should call inject_rule twice (pricing + integrations)
            assert runner_instance.inject_rule.call_count >= 1

def test_inject_python_dependencies_failure(temp_project):
    """Test Python dependency injection failure"""
    pyproject = temp_project / "pyproject.toml"
    pyproject.write_text("[project]\ndependencies = []\n")
    
    with patch("foundry.actions.features.IdempotentAddDependencyCM") as mock_cm:
        mock_result = MagicMock(success=False, error="Test error")
        mock_cm.return_value.apply.return_value = mock_result
        
        _inject_python_dependencies(temp_project, ["sqlalchemy"])
        
        # Should handle failure gracefully
        mock_cm.assert_called_once()

def test_inject_tunnel_config_no_services_key(temp_project):
    """Test tunnel config when docker-compose has no services key"""
    compose = temp_project / "docker-compose.yml"
    compose.write_text("version: '3.8'\n")
    
    _inject_tunnel_config(temp_project, "python-saas")
    
    # Should not crash even without services key
    content = compose.read_text()
    # Content won't be modified if no "services:" found

def test_inject_rails_commerce_routes_no_file(temp_project):
    """Test Rails commerce routes when routes.rb doesn't exist"""
    from foundry.actions.features import _inject_rails_commerce_routes
    
    _inject_rails_commerce_routes(temp_project)
    
    # Should not crash

def test_inject_astro_themes_no_files(temp_project):
    """Test Astro themes when files don't exist"""
    from foundry.actions.features import _inject_astro_themes
    
    vault = temp_project / "vault" / "features"
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _inject_astro_themes(temp_project)
        
        # Should not crash

def test_inject_astro_commerce_no_files(temp_project):
    """Test Astro commerce when files don't exist"""
    from foundry.actions.features import _inject_astro_commerce
    
    vault = temp_project / "vault" / "features"
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _inject_astro_commerce(temp_project)
        
        # Should not crash

def test_inject_astro_auth_no_files(temp_project):
    """Test Astro auth when files don't exist"""
    from foundry.actions.features import _inject_astro_auth
    
    vault = temp_project / "vault" / "features"
    
    with patch("foundry.actions.features.FOUNDRY_ROOT", temp_project / "vault"):
        _inject_astro_auth(temp_project)
        
        # Should not crash


# ============================================================================
# _inject_python_payment_routes Tests
# ============================================================================

def test_inject_python_payment_routes_saas_main(temp_project):
    """Wires router into src/ui/main.py via SS-FEATURE-ROUTER marker."""
    main_py = temp_project / "src" / "ui" / "main.py"
    main_py.parent.mkdir(parents=True, exist_ok=True)
    main_py.write_text(
        "from nicegui import app as fastapi_app\n"
        "fastapi_app.include_router(auth_router)\n"
        "# SS-FEATURE-ROUTER (injection marker — do not remove this comment)\n"
    )
    _inject_python_payment_routes(temp_project)
    content = main_py.read_text()
    assert "payment_router" in content
    assert "from src.ui.api.payments import router as payment_router" in content
    assert "/api/payments" in content


def test_inject_python_payment_routes_saas_main_idempotent(temp_project):
    """Re-injecting does not duplicate payment_router."""
    main_py = temp_project / "src" / "ui" / "main.py"
    main_py.parent.mkdir(parents=True, exist_ok=True)
    main_py.write_text(
        "from src.ui.api.payments import router as payment_router  # injected by sscli\n"
        "fastapi_app.include_router(payment_router, prefix=\"/api/payments\", tags=[\"payments\"])  # injected by sscli\n"
        "# SS-FEATURE-ROUTER (injection marker — do not remove this comment)\n"
    )
    _inject_python_payment_routes(temp_project)
    content = main_py.read_text()
    assert content.count("payment_router") == 2  # import line + include_router line, not duplicated


def test_inject_python_payment_routes_app_main(temp_project):
    """Wires router into app/main.py when src/ui/main.py is absent (correct app. namespace)."""
    app_main = temp_project / "app" / "main.py"
    app_main.parent.mkdir(parents=True, exist_ok=True)
    app_main.write_text(
        "from app.routes import auth\n"
        "app = FastAPI()\n"
        "app.include_router(auth.router, prefix=\"/api/v1/auth\")\n"
    )
    _inject_python_payment_routes(temp_project)
    content = app_main.read_text()
    assert "payment_router" in content
    assert 'prefix="/api/v1"' in content
    # Must use app. namespace, NOT src.
    assert "from app.routes.payments import" in content
    assert "from src.ui.api.payments import" not in content


def test_inject_python_payment_routes_app_main_auto_relocates(temp_project):
    """When vault files exist, auto-relocates them to app/-rooted paths with fixed imports."""
    from foundry.constants import FOUNDRY_ROOT

    # Set up app/main.py
    app_main = temp_project / "app" / "main.py"
    app_main.parent.mkdir(parents=True, exist_ok=True)
    app_main.write_text(
        "from app.routes import auth\n"
        "app = FastAPI()\n"
        "app.include_router(auth.router, prefix=\"/api/v1/auth\")\n"
    )

    vault_payment = FOUNDRY_ROOT / "features" / "python-saas" / "payment"
    vault_routes_src = vault_payment / "src" / "ui" / "api" / "payments.py"
    vault_adapter_src = vault_payment / "src" / "infrastructure" / "payment" / "stripe_payment_adapter.py"
    vault_gateway_src = vault_payment / "src" / "core" / "interfaces" / "payment_gateway.py"

    if not all(p.exists() for p in [vault_routes_src, vault_adapter_src, vault_gateway_src]):
        pytest.skip("Vault payment files not present in this environment")

    _inject_python_payment_routes(temp_project)

    # Vault files should be copied to app/-rooted destinations
    assert (temp_project / "app" / "routes" / "payments.py").exists()
    assert (temp_project / "app" / "payment" / "stripe_payment_adapter.py").exists()
    assert (temp_project / "app" / "payment" / "payment_gateway.py").exists()

    # Import fix applied inside copied routes file
    routes_content = (temp_project / "app" / "routes" / "payments.py").read_text()
    assert "from app.payment.stripe_payment_adapter import" in routes_content
    assert "from src.infrastructure.payment.stripe_payment_adapter import" not in routes_content

    # Import fix applied inside adapter
    adapter_content = (temp_project / "app" / "payment" / "stripe_payment_adapter.py").read_text()
    assert "from app.payment.payment_gateway import" in adapter_content
    assert "from src.core.interfaces.payment_gateway import" not in adapter_content

    # app/main.py wired correctly
    content = app_main.read_text()
    assert "from app.routes.payments import" in content
    assert 'prefix="/api/v1"' in content


def test_inject_python_payment_routes_no_main(temp_project, capsys):
    """Prints a clear warning when neither main.py is found."""
    _inject_python_payment_routes(temp_project)
    # Rich console captures to stdout — just check no exception raised


def test_inject_payment_env_vars_appends(temp_project):
    """Stripe env stubs are appended when not present."""
    env = temp_project / ".env"
    env.write_text("DEBUG=true\n")
    _inject_payment_env_vars(temp_project)
    content = env.read_text()
    assert "STRIPE_SECRET_KEY" in content
    assert "STRIPE_WEBHOOK_SECRET" in content
    assert "PAYMENT_SUCCESS_URL" in content


def test_inject_payment_env_vars_idempotent(temp_project):
    """Stripe stubs are not appended a second time."""
    env = temp_project / ".env"
    env.write_text("STRIPE_SECRET_KEY=already_here\n")
    _inject_payment_env_vars(temp_project)
    assert env.read_text().count("STRIPE_SECRET_KEY") == 1


@patch("foundry.actions.features._inject_python_payment_routes")
@patch("foundry.actions.features._inject_python_dependencies")
@patch("foundry.actions.features._inject_payment_env_vars")
@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.generation_utils.check_payment_entitlement", return_value=True)
def test_inject_features_payment_python(
    mock_gate, mock_inject, mock_env, mock_deps, mock_routes, temp_project
):
    """Payment branch calls correct helpers for python-saas template."""
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        payment=True,
    )
    mock_inject.assert_any_call(temp_project, "python-saas", "payment")
    mock_env.assert_called_once_with(temp_project)
    mock_deps.assert_any_call(temp_project, ["stripe"])
    mock_routes.assert_called_once_with(temp_project)


@patch("foundry.actions.features._inject_rails_payment_routes")
@patch("foundry.actions.features._inject_python_dependencies")
@patch("foundry.actions.features._inject_payment_env_vars")
@patch("foundry.actions.features._perform_feature_injection")
@patch("foundry.actions.generation_utils.check_payment_entitlement", return_value=True)
def test_inject_features_payment_rails(
    mock_gate, mock_inject, mock_env, mock_deps, mock_rails_routes, temp_project
):
    """Payment branch calls Rails route injection (not Python) for rails-api template."""
    inject_features(
        path=temp_project,
        template="rails-api",
        commerce=False,
        tunnel=False,
        payment=True,
    )
    mock_inject.assert_any_call(temp_project, "rails-api", "payment")
    mock_rails_routes.assert_called_once_with(temp_project)
    mock_deps.assert_any_call(temp_project, ["stripe"])


@patch("foundry.actions.generation_utils.check_payment_entitlement", return_value=False)
def test_inject_features_payment_gate_blocks(mock_gate, temp_project):
    """inject_features returns early when entitlement gate denies access."""
    # Should not raise — but also not inject anything
    inject_features(
        path=temp_project,
        template="python-saas",
        commerce=False,
        tunnel=False,
        payment=True,
    )
    # No files injected into temp_project proves early return
    assert not (temp_project / "src" / "ui" / "api" / "payments.py").exists()


def test_payment_env_keys_are_canonical(temp_project):
    """Injected env vars use STRIPE_SECRET_KEY family, never STRIPE_API_KEY."""
    env = temp_project / ".env"
    env.write_text("DEBUG=true\n")
    _inject_payment_env_vars(temp_project)
    content = env.read_text()
    assert "STRIPE_SECRET_KEY" in content
    assert "STRIPE_API_KEY" not in content  # deprecated alias must not appear


def test_payment_webhook_route_is_canonical(temp_project):
    """Payment router is wired under /api/payments — canonical path."""
    main_py = temp_project / "src" / "ui" / "main.py"
    main_py.parent.mkdir(parents=True, exist_ok=True)
    main_py.write_text(
        "fastapi_app.include_router(auth_router)\n"
        "# SS-FEATURE-ROUTER (injection marker — do not remove this comment)\n"
    )
    _inject_python_payment_routes(temp_project)
    content = main_py.read_text()
    assert 'prefix="/api/payments"' in content
    assert '/webhooks/stripe' not in content  # webhook lives inside the router, not at prefix level
