"""
Comprehensive tests for foundry.actions.diff module.

Tests:
- DiffSection dataclass
- FileDiff dataclass
- compute_diff function with 3-way diff logic
- Diff format types (colored, unified, json)
- Project metadata reading
- Template path inference
- File comparison logic
- Error handling for missing metadata
"""

import pytest
import json
from pathlib import Path
from unittest.mock import patch, MagicMock, mock_open
from foundry.actions import diff as diff_mod
from foundry.actions.diff import DiffSection, FileDiff, compute_diff


class TestDiffSection:
    """Test DiffSection dataclass."""
    
    def test_diff_section_creation(self):
        """Test creating a DiffSection."""
        section = DiffSection(
            file_path="src/test.py",
            diff_type="added_by_feature",
            lines=["line1", "line2"],
            start_line=10,
            end_line=12,
            context="Test context"
        )
        
        assert section.file_path == "src/test.py"
        assert section.diff_type == "added_by_feature"
        assert section.lines == ["line1", "line2"]
        assert section.start_line == 10
        assert section.end_line == 12
        assert section.context == "Test context"
    
    def test_diff_section_default_context(self):
        """Test DiffSection with default context."""
        section = DiffSection(
            file_path="test.py",
            diff_type="modified_by_user",
            lines=["test"],
            start_line=1,
            end_line=2
        )
        
        assert section.context == ""
    
    def test_diff_section_types(self):
        """Test valid diff section types."""
        valid_types = [
            "added_by_base",
            "added_by_feature",
            "modified_by_user",
            "unchanged"
        ]
        
        for diff_type in valid_types:
            section = DiffSection(
                file_path="test.py",
                diff_type=diff_type,
                lines=[],
                start_line=1,
                end_line=1
            )
            assert section.diff_type == diff_type


class TestFileDiff:
    """Test FileDiff dataclass."""
    
    def test_file_diff_creation(self):
        """Test creating a FileDiff."""
        section = DiffSection(
            file_path="test.py",
            diff_type="added_by_feature",
            lines=["line1"],
            start_line=1,
            end_line=2
        )
        
        file_diff = FileDiff(
            file_path="test.py",
            exists_in_base=True,
            exists_in_current=True,
            exists_in_feature=True,
            sections=[section],
            change_type="modified",
            additions=1,
            deletions=0,
            modifications=2
        )
        
        assert file_diff.file_path == "test.py"
        assert file_diff.exists_in_base is True
        assert file_diff.exists_in_current is True
        assert file_diff.exists_in_feature is True
        assert len(file_diff.sections) == 1
        assert file_diff.change_type == "modified"
        assert file_diff.additions == 1
        assert file_diff.deletions == 0
        assert file_diff.modifications == 2
    
    def test_file_diff_default_counters(self):
        """Test FileDiff with default counters."""
        file_diff = FileDiff(
            file_path="test.py",
            exists_in_base=True,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="unchanged"
        )
        
        assert file_diff.additions == 0
        assert file_diff.deletions == 0
        assert file_diff.modifications == 0
    
    def test_file_diff_change_types(self):
        """Test valid change types."""
        change_types = ["added", "deleted", "modified", "unchanged"]
        
        for change_type in change_types:
            file_diff = FileDiff(
                file_path="test.py",
                exists_in_base=False,
                exists_in_current=True,
                exists_in_feature=False,
                sections=[],
                change_type=change_type
            )
            assert file_diff.change_type == change_type


class TestComputeDiff:
    """Test compute_diff function."""
    
    @patch("foundry.actions.diff._read_project_metadata")
    def test_compute_diff_no_metadata(self, mock_read_metadata, tmp_path):
        """Test compute_diff when no metadata found."""
        mock_read_metadata.return_value = None
        
        result = compute_diff(str(tmp_path))
        
        assert result["success"] is False
        assert "No .sscli-metadata.json found" in result["error"]
        assert "project_path" in result
    
    @patch("foundry.actions.diff._read_project_metadata")
    @patch("foundry.actions.diff._infer_template_path")
    def test_compute_diff_missing_template_path(self, mock_infer, mock_read_metadata, tmp_path):
        """Test compute_diff when template path cannot be inferred."""
        mock_read_metadata.return_value = {
            "base_template_version": "python-saas/v1.0.0",
            "features": []
        }
        mock_infer.return_value = None
        
        result = compute_diff(str(tmp_path))
        
        # Should handle missing template path gracefully
        assert "error" in result or "success" in result
    
    @patch("foundry.actions.diff._read_project_metadata")
    @patch("foundry.actions.diff._infer_template_path")
    def test_compute_diff_with_metadata(self, mock_infer, mock_read_metadata, tmp_path):
        """Test compute_diff with valid metadata."""
        # Create a project structure
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("print('hello')")
        
        mock_read_metadata.return_value = {
            "base_template_version": "python-saas/v1.0.0",
            "features": [],
            "template": "python-saas"
        }
        
        # Mock template path
        template_path = tmp_path / "template"
        template_path.mkdir()
        mock_infer.return_value = str(template_path)
        
        result = compute_diff(str(tmp_path))
        
        # Should return a result dict
        assert isinstance(result, dict)
    
    @patch("foundry.actions.diff._read_project_metadata")
    def test_compute_diff_output_formats(self, mock_read_metadata, tmp_path):
        """Test different output formats."""
        mock_read_metadata.return_value = {
            "base_template_version": "python-saas/v1.0.0",
            "features": []
        }
        
        # Test colored format
        result_colored = compute_diff(str(tmp_path), output_format="colored")
        assert isinstance(result_colored, dict)
        
        # Test unified format
        result_unified = compute_diff(str(tmp_path), output_format="unified")
        assert isinstance(result_unified, dict)
        
        # Test json format
        result_json = compute_diff(str(tmp_path), output_format="json")
        assert isinstance(result_json, dict)
    
    @patch("foundry.actions.diff._read_project_metadata")
    @patch("foundry.actions.diff._infer_template_path")
    def test_compute_diff_with_feature_name(self, mock_infer, mock_read_metadata, tmp_path):
        """Test compute_diff with specific feature name."""
        mock_read_metadata.return_value = {
            "base_template_version": "python-saas/v1.0.0",
            "features": ["commerce", "auth"]
        }
        
        template_path = tmp_path / "template"
        template_path.mkdir()
        mock_infer.return_value = str(template_path)
        
        result = compute_diff(
            str(tmp_path),
            feature_name="commerce"
        )
        
        assert isinstance(result, dict)
    
    @patch("foundry.actions.diff._read_project_metadata")
    @patch("foundry.actions.diff._infer_template_path")
    def test_compute_diff_with_explicit_template_name(self, mock_infer, mock_read_metadata, tmp_path):
        """Test compute_diff with explicit template name."""
        mock_read_metadata.return_value = {
            "base_template_version": "rails-api/v1.0.0",
            "features": []
        }
        
        template_path = tmp_path / "template"
        template_path.mkdir()
        mock_infer.return_value = str(template_path)
        
        result = compute_diff(
            str(tmp_path),
            template_name="rails-api"
        )
        
        assert isinstance(result, dict)


class TestReadProjectMetadata:
    """Test _read_project_metadata helper function."""
    
    def test_read_metadata_success(self, tmp_path):
        """Test reading valid metadata file."""
        if hasattr(diff_mod, "_read_project_metadata"):
            (tmp_path / ".sscli-metadata.json").write_text('{"template": "python-saas"}')
            result = diff_mod._read_project_metadata(tmp_path)
            assert result == {"template": "python-saas"}
    
    def test_read_metadata_missing_file(self, tmp_path):
        """Test reading metadata when file doesn't exist."""
        if hasattr(diff_mod, "_read_project_metadata"):
            result = diff_mod._read_project_metadata(tmp_path)
            
            # Should return None or empty dict
            assert result is None or result == {}
    
    def test_read_metadata_invalid_json(self, tmp_path):
        """Test reading metadata with invalid JSON."""
        metadata_file = tmp_path / ".sscli-metadata.json"
        metadata_file.write_text("{ invalid json }")
        
        if hasattr(diff_mod, "_read_project_metadata"):
            # Should handle parsing errors gracefully
            try:
                result = diff_mod._read_project_metadata(tmp_path)
            except json.JSONDecodeError:
                # Expected if not handling errors
                pass


class TestInferTemplatePath:
    """Test _infer_template_path helper function."""
    
    @patch("foundry.actions.diff.FOUNDRY_ROOT")
    def test_infer_template_path(self, mock_root, tmp_path):
        """Test inferring template path from template name."""
        mock_root.return_value = tmp_path
        
        if hasattr(diff_mod, "_infer_template_path"):
            # Create template directory
            templates_dir = tmp_path / "templates" / "python-saas"
            templates_dir.mkdir(parents=True)
            
            result = diff_mod._infer_template_path("python-saas", "python-saas/v1.0.0")
            
            # Should return path or None
            assert result is None or isinstance(result, (str, Path))
    
    def test_infer_template_path_missing_template(self, tmp_path):
        """Test inferring path for non-existent template."""
        if hasattr(diff_mod, "_infer_template_path"):
            result = diff_mod._infer_template_path("nonexistent", "nonexistent/v1.0.0")
            
            # Should return None
            assert result is None


class TestDiffComparisonLogic:
    """Test file comparison and diff generation logic."""
    
    def test_diff_section_serialization(self):
        """Test that DiffSection can be serialized."""
        from dataclasses import asdict
        
        section = DiffSection(
            file_path="test.py",
            diff_type="added_by_feature",
            lines=["line1", "line2"],
            start_line=1,
            end_line=3
        )
        
        # Should be serializable to dict
        data = asdict(section)
        assert data["file_path"] == "test.py"
        assert data["diff_type"] == "added_by_feature"
        assert data["lines"] == ["line1", "line2"]
    
    def test_file_diff_serialization(self):
        """Test that FileDiff can be serialized."""
        from dataclasses import asdict
        
        file_diff = FileDiff(
            file_path="test.py",
            exists_in_base=True,
            exists_in_current=True,
            exists_in_feature=False,
            sections=[],
            change_type="modified",
            additions=5,
            deletions=2,
            modifications=3
        )
        
        data = asdict(file_diff)
        assert data["file_path"] == "test.py"
        assert data["additions"] == 5
        assert data["deletions"] == 2


class TestEdgeCases:
    """Test edge cases and error scenarios."""
    
    @patch("foundry.actions.diff._read_project_metadata")
    def test_compute_diff_empty_project_path(self, mock_read_metadata):
        """Test compute_diff with empty project path."""
        mock_read_metadata.return_value = None
        
        # Should handle gracefully
        result = compute_diff("")
        assert "error" in result or "success" in result
    
    @patch("foundry.actions.diff._read_project_metadata")
    def test_compute_diff_invalid_project_path(self, mock_read_metadata):
        """Test compute_diff with invalid path."""
        mock_read_metadata.return_value = None
        
        result = compute_diff("/nonexistent/path/12345")
        assert result["success"] is False
    
    def test_diff_section_empty_lines(self):
        """Test DiffSection with empty lines list."""
        section = DiffSection(
            file_path="test.py",
            diff_type="unchanged",
            lines=[],
            start_line=0,
            end_line=0
        )
        
        assert section.lines == []
        assert len(section.lines) == 0
    
    def test_file_diff_no_sections(self):
        """Test FileDiff with no sections."""
        file_diff = FileDiff(
            file_path="test.py",
            exists_in_base=False,
            exists_in_current=False,
            exists_in_feature=False,
            sections=[],
            change_type="unchanged"
        )
        
        assert len(file_diff.sections) == 0


class TestModuleDocumentation:
    """Test module documentation."""
    
    def test_module_docstring(self):
        """Test that module has docstring."""
        assert diff_mod.__doc__ is not None
        assert "3-way diff" in diff_mod.__doc__.lower()
    
    def test_compute_diff_docstring(self):
        """Test that compute_diff has comprehensive docstring."""
        assert compute_diff.__doc__ is not None
        assert "Args:" in compute_diff.__doc__
        assert "Returns:" in compute_diff.__doc__


class TestDifflibIntegration:
    """Test integration with difflib."""
    
    def test_difflib_available(self):
        """Test that difflib is imported."""
        assert hasattr(diff_mod, "difflib")
    
    def test_unified_diff_usage(self):
        """Test that unified_diff can be used."""
        # Test basic difflib functionality
        from foundry.actions.diff import difflib
        
        old_lines = ["line1", "line2", "line3"]
        new_lines = ["line1", "line2_modified", "line3"]
        
        diff = list(difflib.unified_diff(old_lines, new_lines))
        
        # Should generate diff output
        assert len(diff) > 0


class TestPathHandling:
    """Test path handling and resolution."""
    
    @patch("foundry.actions.diff._read_project_metadata")
    def test_path_resolution(self, mock_read_metadata, tmp_path):
        """Test that paths are resolved correctly."""
        mock_read_metadata.return_value = None
        
        # Use relative path
        relative_path = "."
        
        result = compute_diff(relative_path)
        
        # Should resolve to absolute path
        assert "project_path" in result
        assert Path(result["project_path"]).is_absolute()
    
    @patch("foundry.actions.diff._read_project_metadata")
    def test_path_with_spaces(self, mock_read_metadata, tmp_path):
        """Test paths with spaces."""
        project_dir = tmp_path / "project with spaces"
        project_dir.mkdir()
        
        mock_read_metadata.return_value = None
        
        result = compute_diff(str(project_dir))
        
        # Should handle spaces correctly
        assert "project with spaces" in result["project_path"]
