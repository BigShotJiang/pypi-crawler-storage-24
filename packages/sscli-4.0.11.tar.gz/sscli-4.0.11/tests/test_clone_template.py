"""Tests for foundry.actions.clone — template git-clone module.

All tests are offline (no real network calls). subprocess.run is patched
throughout so the test suite never touches GitHub.
"""
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from foundry.actions.clone import clone_template, _build_clone_url, TEMPLATE_REGISTRY


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

def test_registry_contains_all_templates():
    for t in ["python-saas", "react-client", "rails-api", "static-landing"]:
        assert t in TEMPLATE_REGISTRY


def test_registry_slugs_are_strings():
    for name, slug in TEMPLATE_REGISTRY.items():
        assert isinstance(slug, str), f"{name} slug must be a string"
        assert "/" in slug, f"{name} slug must be in org/repo format"


# ---------------------------------------------------------------------------
# URL builder
# ---------------------------------------------------------------------------

def test_build_clone_url_with_token():
    url = _build_clone_url("seed-source/python-saas", token="tok123")
    assert "tok123@github.com" in url
    assert url.startswith("https://")
    assert url.endswith(".git")


def test_build_clone_url_no_token_uses_ssh():
    url = _build_clone_url("seed-source/python-saas", token=None)
    assert url.startswith("git@github.com:")
    assert "seed-source/python-saas" in url


def test_build_clone_url_bare_slug_gets_org_prefix(monkeypatch):
    monkeypatch.delenv("SSCLI_TEMPLATE_ORG", raising=False)
    url = _build_clone_url("python-saas", token="tok")
    # default org should be injected
    assert "seed-source/python-saas" in url


def test_build_clone_url_custom_org_env(monkeypatch):
    monkeypatch.setenv("SSCLI_TEMPLATE_ORG", "my-org")
    url = _build_clone_url("python-saas", token="tok")
    assert "my-org/python-saas" in url


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------

def test_unknown_template_raises_valueerror(tmp_path):
    with pytest.raises(ValueError, match="Unknown template"):
        clone_template("does-not-exist", tmp_path)


def test_unknown_template_error_lists_available(tmp_path):
    with pytest.raises(ValueError) as exc_info:
        clone_template("bogus", tmp_path)
    msg = str(exc_info.value)
    assert "python-saas" in msg


def test_clone_failure_raises_runtimeerror(tmp_path):
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stderr="fatal: repository not found")
        with pytest.raises(RuntimeError, match="Clone failed"):
            clone_template("python-saas", tmp_path)


# ---------------------------------------------------------------------------
# Security: token redaction
# ---------------------------------------------------------------------------

def test_token_redacted_in_error(tmp_path, monkeypatch):
    monkeypatch.setenv("SSCLI_TOKEN", "secrettoken99")
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=1,
            stderr="https://secrettoken99@github.com failed",
        )
        with pytest.raises(RuntimeError) as exc_info:
            clone_template("python-saas", tmp_path)
        assert "secrettoken99" not in str(exc_info.value)
        assert "[REDACTED]" in str(exc_info.value)


def test_token_arg_redacted_in_error(tmp_path, monkeypatch):
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.delenv("SSCLI_TOKEN", raising=False)
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=1,
            stderr="https://myexplicitsecret@github.com/seed-source/python-saas.git failed",
        )
        with pytest.raises(RuntimeError) as exc_info:
            clone_template("python-saas", tmp_path, token="myexplicitsecret")
        assert "myexplicitsecret" not in str(exc_info.value)
        assert "[REDACTED]" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Successful clone
# ---------------------------------------------------------------------------

def test_git_dir_stripped_after_clone(tmp_path):
    git_dir = tmp_path / ".git"
    git_dir.mkdir()
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        clone_template("python-saas", tmp_path)
    assert not git_dir.exists()


def test_clone_success_returns_destination(tmp_path):
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        result = clone_template("react-client", tmp_path)
    assert result == tmp_path


def test_clone_creates_destination_if_missing(tmp_path):
    dest = tmp_path / "new-project"
    assert not dest.exists()
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        clone_template("rails-api", dest)
    assert dest.exists()


def test_clone_passes_depth_1_and_branch(tmp_path):
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        clone_template("static-landing", tmp_path, branch="develop")
    call_args = mock_run.call_args[0][0]
    assert "--depth" in call_args
    assert "1" in call_args
    assert "--branch" in call_args
    assert "develop" in call_args


def test_clone_uses_github_token_env(tmp_path, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "ghp_envtoken")
    monkeypatch.delenv("SSCLI_TOKEN", raising=False)
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        clone_template("python-saas", tmp_path)
    call_args = mock_run.call_args[0][0]
    clone_url = next(a for a in call_args if "github.com" in a)
    assert "ghp_envtoken" in clone_url


def test_clone_sscli_token_env_fallback(tmp_path, monkeypatch):
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.setenv("SSCLI_TOKEN", "sscli_token_abc")
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        clone_template("python-saas", tmp_path)
    call_args = mock_run.call_args[0][0]
    clone_url = next(a for a in call_args if "github.com" in a)
    assert "sscli_token_abc" in clone_url
