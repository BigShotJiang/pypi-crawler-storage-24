"""Tests for sscli generate command."""
import pytest
from pathlib import Path
from typer.testing import CliRunner
from foundry.commands.codegen import app

runner = CliRunner()


def test_generate_endpoint_dry_run():
    result = runner.invoke(app, ["endpoint", "order", "--dry-run"])
    assert result.exit_code == 0
    assert "dry-run" in result.output or "router" in result.output.lower()


def test_generate_endpoint_writes_file(tmp_path):
    result = runner.invoke(app, ["endpoint", "product", "--output-dir", str(tmp_path)])
    assert result.exit_code == 0
    generated = list(tmp_path.rglob("*.py"))
    assert len(generated) >= 1


def test_generate_component_dry_run():
    result = runner.invoke(app, ["component", "UserCard", "--dry-run"])
    assert result.exit_code == 0


def test_generate_component_writes_file(tmp_path):
    result = runner.invoke(app, ["component", "MyWidget", "--output-dir", str(tmp_path)])
    assert result.exit_code == 0
    generated = list(tmp_path.rglob("*.tsx"))
    assert len(generated) >= 1
    assert "MyWidget" in generated[0].read_text()


def test_generate_use_case_dry_run():
    result = runner.invoke(app, ["use-case", "process_payment", "--dry-run"])
    assert result.exit_code == 0


def test_generate_unknown_template_fails():
    result = runner.invoke(app, ["endpoint", "foo", "--template", "unknown-stack"])
    assert result.exit_code != 0


def test_generate_endpoint_with_methods(tmp_path):
    result = runner.invoke(app, ["endpoint", "invoice", "--methods", "index,show", "--output-dir", str(tmp_path)])
    assert result.exit_code == 0


def test_generate_migration_python_dry_run():
    result = runner.invoke(app, ["migration", "create_invoices", "--template", "python-saas", "--dry-run"])
    assert result.exit_code == 0


def test_generate_migration_rails_dry_run():
    result = runner.invoke(app, ["migration", "create_products", "--template", "rails-api", "--dry-run"])
    assert result.exit_code == 0


def test_generate_migration_python_writes_file(tmp_path):
    result = runner.invoke(app, ["migration", "create_orders", "--template", "python-saas", "--output-dir", str(tmp_path)])
    assert result.exit_code == 0
    generated = list(tmp_path.rglob("*.py"))
    assert len(generated) >= 1


def test_generate_spec_request_dry_run():
    result = runner.invoke(app, ["spec", "order", "--template", "rails-api", "--dry-run"])
    assert result.exit_code == 0


def test_generate_migration_unknown_template():
    result = runner.invoke(app, ["migration", "foo", "--template", "unknown"])
    assert result.exit_code != 0
