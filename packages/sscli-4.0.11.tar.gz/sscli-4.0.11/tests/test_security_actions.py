"""
Security regression tests for the actions layer.

Covers:
  H-10  upgrade.py   — backup_path containment in rollback_upgrade()
  H-11  upgrade.py   — empty backup guard in rollback_upgrade() / _rollback_to_backup()
  C-7   diff.py      — _infer_feature_path() traversal rejection
  C-8   diff.py      — _infer_template_path() rejects /tmp and unknown names
  H-20  generation_utils.py — app_name regex validation in inject_metadata()
  H-21  generation_utils.py — content_path containment in apply_landing_blueprint()
  H-17  verifier.py  — docker/terraform absolute path resolution via shutil.which
  H-18  validation.py — unknown extension blocks in _run_script()
  H-28  verify.py    — run_verification() always returns bool
"""

import json
import sys
import shutil
import subprocess
from pathlib import Path
from datetime import datetime
from unittest.mock import patch, MagicMock

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_metadata(backup_path: str, project_dir: Path) -> dict:
    """Return a .seed-source-metadata.json dict with *one* upgrade history entry."""
    return {
        "current_version": "2.0.0",
        "template_type": "python-saas",
        "created_at": "2024-01-01T00:00:00",
        "last_upgraded": "2024-01-02T00:00:00",
        "upgrade_history": [
            {
                "timestamp": "2024-01-02T00:00:00",
                "from_version": "1.0.0",
                "to_version": "2.0.0",
                "steps_applied": 1,
                "steps_successful": 1,
                "status": "success",
                "error_message": None,
                "backup_path": backup_path,
                "codemod_ids": [],
                "git_commit_sha": None,
            }
        ],
    }


# ===========================================================================
# H-10 — backup_path containment
# ===========================================================================

class TestH10BackupPathContainment:
    """rollback_upgrade() must reject a backup_path outside the expected root."""

    def test_rejects_absolute_evil_path(self, tmp_path):
        from foundry.actions.upgrade import UpgradeCommand

        project_dir = tmp_path / "my-project"
        project_dir.mkdir()

        evil_path = "/tmp/evil"
        meta = _make_metadata(evil_path, project_dir)
        (project_dir / ".seed-source-metadata.json").write_text(json.dumps(meta))

        with patch("foundry.actions.upgrade.shutil.rmtree") as mock_rmtree:
            cmd = UpgradeCommand(project_path=project_dir)
            result = cmd.rollback_upgrade()

        assert result is False, "rollback_upgrade() must return False for out-of-root backup_path"

        # shutil.rmtree must NEVER have been called with the evil path
        called_paths = [str(call.args[0]) for call in mock_rmtree.call_args_list]
        assert evil_path not in called_paths, (
            f"shutil.rmtree was called with {evil_path!r} — containment guard failed"
        )

    def test_rejects_parent_traversal_path(self, tmp_path):
        """A backup_path that traverses out via .. must also be rejected."""
        from foundry.actions.upgrade import UpgradeCommand

        project_dir = tmp_path / "my-project"
        project_dir.mkdir()

        # This resolves to tmp_path which is NOT inside project_parent/.upgrades
        traversal_path = str(project_dir / ".." / ".." / "evil")
        meta = _make_metadata(traversal_path, project_dir)
        (project_dir / ".seed-source-metadata.json").write_text(json.dumps(meta))

        with patch("foundry.actions.upgrade.shutil.rmtree") as mock_rmtree:
            cmd = UpgradeCommand(project_path=project_dir)
            result = cmd.rollback_upgrade()

        assert result is False

    def test_valid_backup_path_accepted(self, tmp_path):
        """A backup inside <project_parent>/.upgrades/ must be accepted (if non-empty)."""
        from foundry.actions.upgrade import UpgradeCommand

        project_dir = tmp_path / "my-project"
        project_dir.mkdir()

        # Create a proper backup inside the allowed root
        backup_root = tmp_path / ".upgrades"
        backup_dir = backup_root / "backup_20240101_000000"
        backup_dir.mkdir(parents=True)
        # Populate with a dummy file so the empty-guard passes
        (backup_dir / "dummy.txt").write_text("content")

        meta = _make_metadata(str(backup_dir), project_dir)
        (project_dir / ".seed-source-metadata.json").write_text(json.dumps(meta))

        with patch("foundry.actions.upgrade.shutil.rmtree"), \
             patch("foundry.actions.upgrade.shutil.copytree"), \
             patch("foundry.actions.upgrade.shutil.copy2"):
            cmd = UpgradeCommand(project_path=project_dir)
            # Patch save so we don't need a full metadata round-trip
            cmd.metadata_tracker.save = MagicMock()
            result = cmd.rollback_upgrade()

        assert result is True


# ===========================================================================
# H-11 — empty backup guard
# ===========================================================================

class TestH11EmptyBackupGuard:
    """rollback_upgrade() must refuse to wipe the project when the backup is empty."""

    def test_empty_backup_returns_false(self, tmp_path):
        from foundry.actions.upgrade import UpgradeCommand

        project_dir = tmp_path / "my-project"
        project_dir.mkdir()
        (project_dir / "important.py").write_text("# keep me")

        # Create an empty backup inside the allowed root
        backup_dir = tmp_path / ".upgrades" / "backup_empty"
        backup_dir.mkdir(parents=True)

        meta = _make_metadata(str(backup_dir), project_dir)
        (project_dir / ".seed-source-metadata.json").write_text(json.dumps(meta))

        with patch("foundry.actions.upgrade.shutil.rmtree") as mock_rmtree:
            cmd = UpgradeCommand(project_path=project_dir)
            result = cmd.rollback_upgrade()

        assert result is False, "Must return False when backup is empty"
        # Project directory must not be wiped
        assert (project_dir / "important.py").exists(), (
            "Project file was deleted despite empty backup guard"
        )
        # rmtree must NOT have touched project contents via the early-exit path
        project_rmtree_calls = [
            c for c in mock_rmtree.call_args_list
            if str(project_dir) in str(c.args[0])
        ]
        assert not project_rmtree_calls, "rmtree was called on project dir before guard fired"

    def test_internal_rollback_skips_on_empty_backup(self, tmp_path):
        """_rollback_to_backup() must not delete project files when backup is empty."""
        from foundry.actions.upgrade import UpgradeCommand

        project_dir = tmp_path / "my-project"
        project_dir.mkdir()
        (project_dir / "app.py").write_text("# app")

        cmd = UpgradeCommand(project_path=project_dir)

        # Point to an empty backup
        empty_backup = tmp_path / "empty_backup"
        empty_backup.mkdir()
        cmd.backup_path = empty_backup

        with patch("foundry.actions.upgrade.shutil.rmtree") as mock_rmtree:
            cmd._rollback_to_backup()

        # Must not wipe the project
        assert (project_dir / "app.py").exists()
        # rmtree must NOT have been called on project items
        call_paths = [str(c.args[0]) for c in mock_rmtree.call_args_list]
        assert not any(str(project_dir) in p for p in call_paths)


# ===========================================================================
# C-7 — _infer_feature_path() traversal rejection
# ===========================================================================

class TestC7InferFeaturePathTraversal:
    """_infer_feature_path() must reject feature names that can traverse directories."""

    def test_dotdot_traversal_returns_none(self):
        from foundry.actions.diff import _infer_feature_path

        result = _infer_feature_path("rails-api", "../../etc")
        assert result is None, "Traversal feature name must be rejected"

    def test_slash_in_name_returns_none(self):
        from foundry.actions.diff import _infer_feature_path

        result = _infer_feature_path("rails-api", "valid/../evil")
        assert result is None

    def test_dot_in_name_returns_none(self):
        from foundry.actions.diff import _infer_feature_path

        # ".hidden" starts with a dot — not allowed by regex
        result = _infer_feature_path("rails-api", ".hidden")
        assert result is None

    def test_valid_feature_name_does_not_raise(self):
        """Valid alphanumeric/hyphen/underscore names must not raise — may return None if absent."""
        from foundry.actions.diff import _infer_feature_path

        # Should not raise even if the feature directory doesn't exist in this env
        result = _infer_feature_path("rails-api", "valid-feature-name")
        assert result is None or isinstance(result, str)

    def test_valid_underscore_name_does_not_raise(self):
        from foundry.actions.diff import _infer_feature_path

        result = _infer_feature_path("python-saas", "auth_provider")
        assert result is None or isinstance(result, str)


# ===========================================================================
# C-8 — _infer_template_path() allowlist enforcement
# ===========================================================================

class TestC8InferTemplatePathAllowlist:
    """_infer_template_path() must reject unknown names and never return /tmp paths."""

    def test_dotdot_traversal_returns_none(self):
        from foundry.actions.diff import _infer_template_path

        result = _infer_template_path("../../evil", "1.0")
        assert result is None

    def test_unknown_template_returns_none(self):
        from foundry.actions.diff import _infer_template_path

        result = _infer_template_path("unknown-template", "1.0")
        assert result is None

    def test_tmp_prefix_never_returned(self):
        """Even if a known template name were somehow mapped to /tmp, it must not leak."""
        from foundry.actions.diff import _infer_template_path

        # These are all unknown; result must be None regardless
        for name in ["/tmp/evil", "../../tmp/evil", " rails-api"]:
            result = _infer_template_path(name, "1.0")
            assert result is None, f"Expected None for {name!r}, got {result!r}"

    def test_known_template_does_not_return_tmp(self):
        """Known templates must never produce a path starting with /tmp."""
        from foundry.actions.diff import _infer_template_path

        result = _infer_template_path("rails-api", "1.0")
        if result is not None:
            assert not result.startswith("/tmp"), (
                f"Template path must not be under /tmp, got: {result}"
            )


# ===========================================================================
# H-20 — inject_metadata() app_name regex
# ===========================================================================

class TestH20AppNameRegex:
    """inject_metadata() must reject unsafe / malformed app_name values."""

    def test_newline_injection_raises(self, tmp_path):
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError):
            inject_metadata(tmp_path, "python-saas", "evil\nrm -rf /")

    def test_semicolon_injection_raises(self, tmp_path):
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError):
            inject_metadata(tmp_path, "python-saas", "app;rm -rf /")

    def test_space_in_name_raises(self, tmp_path):
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError):
            inject_metadata(tmp_path, "python-saas", "my app")

    def test_empty_string_raises(self, tmp_path):
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError):
            inject_metadata(tmp_path, "python-saas", "")

    def test_too_long_name_raises(self, tmp_path):
        """65-character name should exceed the 64-char max (1 + at-most-63)."""
        from foundry.actions.generation_utils import inject_metadata

        with pytest.raises(ValueError):
            inject_metadata(tmp_path, "python-saas", "a" * 65)

    def test_valid_name_does_not_raise(self, tmp_path):
        """Valid names must pass without raising."""
        from foundry.actions.generation_utils import inject_metadata

        # No files to touch → runs cleanly with no errors
        inject_metadata(tmp_path, "python-saas", "my-app_123")

    def test_max_length_name_does_not_raise(self, tmp_path):
        """Exactly 64 characters must be accepted."""
        from foundry.actions.generation_utils import inject_metadata

        inject_metadata(tmp_path, "python-saas", "a" * 64)

    def test_numeric_start_raises(self, tmp_path):
        """Names starting with digits should fail — wait, digits ARE allowed as first char."""
        # Per the regex: ^[a-zA-Z0-9][a-zA-Z0-9_\-]{0,63}$  — digits ARE valid as first char.
        # This test confirms a digit-starting name is accepted.
        from foundry.actions.generation_utils import inject_metadata

        inject_metadata(tmp_path, "python-saas", "1myapp")  # should not raise


# ===========================================================================
# H-21 — apply_landing_blueprint() content_path containment
# ===========================================================================

class TestH21ContentPathContainment:
    """apply_landing_blueprint() must reject content_path values outside the project dir."""

    def _make_project(self, directory: Path) -> Path:
        """Return a project dir with a minimal blueprint.json."""
        directory.mkdir(parents=True, exist_ok=True)
        (directory / "blueprint.json").write_text(json.dumps({"title": "Test"}))
        return directory

    def test_etc_passwd_rejected(self, tmp_path):
        """content_path /etc/passwd must be silently rejected — blueprint.json unchanged."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        project = self._make_project(tmp_path / "proj")
        original = json.loads((project / "blueprint.json").read_text())

        # ValueError is raised internally but caught by the function's own except block
        apply_landing_blueprint(project, content_path="/etc/passwd")

        # blueprint.json must be identical to the original — /etc/passwd was NOT read
        result = json.loads((project / "blueprint.json").read_text())
        assert result == original, (
            "blueprint.json was modified despite /etc/passwd being rejected"
        )

    def test_dotdot_traversal_rejected(self, tmp_path):
        """A traversal content_path outside the project must be rejected silently."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        project = self._make_project(tmp_path / "proj")
        original = json.loads((project / "blueprint.json").read_text())

        evil = str(tmp_path / "proj" / ".." / ".." / "secrets.json")
        apply_landing_blueprint(project, content_path=evil)

        result = json.loads((project / "blueprint.json").read_text())
        assert result == original, (
            "blueprint.json was modified despite traversal path being rejected"
        )

    def test_valid_path_inside_project_no_error(self, tmp_path):
        from foundry.actions.generation_utils import apply_landing_blueprint

        project = self._make_project(tmp_path / "proj")
        custom = project / "custom.json"
        custom.write_text(json.dumps({"subtitle": "hello"}))

        # Must not raise; blueprint.json should be updated
        apply_landing_blueprint(project, content_path=str(custom))
        data = json.loads((project / "blueprint.json").read_text())
        assert data.get("subtitle") == "hello"

    def test_symlink_rejected(self, tmp_path):
        """Symlinked content_path must be silently rejected — blueprint.json unchanged."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        project = self._make_project(tmp_path / "proj")
        original = json.loads((project / "blueprint.json").read_text())

        target = tmp_path / "real.json"
        target.write_text(json.dumps({"injected": True}))
        link = project / "link.json"
        link.symlink_to(target)

        # ValueError is raised internally but caught; should NOT corrupt blueprint.json
        apply_landing_blueprint(project, content_path=str(link))

        result = json.loads((project / "blueprint.json").read_text())
        assert result == original, (
            "blueprint.json was modified even though content_path was a symlink"
        )
        assert result.get("injected") is not True, (
            "Symlinked data leaked into blueprint.json"
        )


# ===========================================================================
# H-17 — verifier.py docker/terraform absolute path resolution
# ===========================================================================

class TestH17DockerAbsolutePath:
    """_run_docker() must use shutil.which() result; never bare 'docker' string."""

    def _make_result(self):
        from foundry.actions.verification.models import (
            VerificationResult, VerificationStatus, TemplateType,
        )
        return VerificationResult(
            name="test",
            template_type=TemplateType.DOCKER,
            status=VerificationStatus.SUCCESS,
            git_ignore=True,
            git_attributes=False,
            docker_success=False,
            duration_seconds=0.0,
            timestamp=datetime.now().isoformat(),
        )

    def test_docker_not_found_skips_without_exception(self, tmp_path):
        """When docker is absent, status becomes FAILED with a message and no subprocess call."""
        from foundry.actions.verification.verifier import TemplateVerifier
        from foundry.actions.verification.models import VerificationStatus

        verifier = TemplateVerifier(root_dir=tmp_path)
        res = self._make_result()

        with patch("foundry.actions.verification.verifier.shutil.which", return_value=None) as _, \
             patch("foundry.actions.verification.verifier.subprocess.run") as mock_run:
            verifier._run_docker(tmp_path, "test-template", res)

        assert res.status == VerificationStatus.FAILED
        assert "docker not found" in (res.notes or "").lower()
        mock_run.assert_not_called()

    def test_docker_found_uses_absolute_path(self, tmp_path):
        """When docker is found via which(), subprocess.run must be called with that absolute path."""
        from foundry.actions.verification.verifier import TemplateVerifier
        from foundry.actions.verification.models import VerificationStatus

        verifier = TemplateVerifier(root_dir=tmp_path)
        res = self._make_result()

        fake_docker = "/usr/bin/docker"
        mock_proc = MagicMock()
        mock_proc.returncode = 0
        mock_proc.stderr = ""

        with patch("foundry.actions.verification.verifier.shutil.which", return_value=fake_docker), \
             patch("foundry.actions.verification.verifier.subprocess.run", return_value=mock_proc) as mock_run:
            verifier._run_docker(tmp_path, "test-template", res)

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]  # first positional arg is the command list
        assert cmd[0] == fake_docker, (
            f"Expected first element to be {fake_docker!r}, got {cmd[0]!r}"
        )
        assert cmd[0] != "docker", "Bare 'docker' string must not be used"

    def test_docker_command_never_bare_string(self, tmp_path):
        """Subprocess must receive the full path, not just 'docker'."""
        from foundry.actions.verification.verifier import TemplateVerifier

        verifier = TemplateVerifier(root_dir=tmp_path)
        res = self._make_result()

        captured_cmds = []

        def fake_run(cmd, **kwargs):
            captured_cmds.append(cmd)
            mock = MagicMock()
            mock.returncode = 0
            mock.stderr = ""
            return mock

        with patch("foundry.actions.verification.verifier.shutil.which", return_value="/usr/local/bin/docker"), \
             patch("foundry.actions.verification.verifier.subprocess.run", side_effect=fake_run):
            verifier._run_docker(tmp_path, "test-template", res)

        assert captured_cmds, "subprocess.run was not called"
        assert captured_cmds[0][0] == "/usr/local/bin/docker"
        assert "docker" not in [c[0] for c in captured_cmds if c[0] == "docker"], \
            "Bare 'docker' should never appear as first element"


# ===========================================================================
# H-18 — validation.py unknown extension blocks
# ===========================================================================

class TestH18UnknownExtensionBlocks:
    """_run_script() must raise ValueError for disallowed file extensions."""

    def test_bat_extension_blocks_subprocess(self, tmp_path, monkeypatch):
        """A .bat file must be blocked — ValueError is caught internally, Popen never called."""
        import foundry.actions.validation as val_mod

        monkeypatch.setattr(val_mod, "TEMPLATES_DIR", tmp_path)
        bat_file = tmp_path / "evil.bat"
        bat_file.write_text("echo evil")

        with patch("foundry.actions.validation.subprocess.Popen") as mock_popen:
            val_mod._run_script("evil.bat", "Test")

        mock_popen.assert_not_called(), (
            "subprocess.Popen must never be called for a .bat file"
        )

    def test_no_extension_blocks_subprocess(self, tmp_path, monkeypatch):
        """A file with no recognised extension must be blocked — Popen never called."""
        import foundry.actions.validation as val_mod

        monkeypatch.setattr(val_mod, "TEMPLATES_DIR", tmp_path)
        no_ext = tmp_path / "script"
        no_ext.write_text("#!/bin/bash")

        with patch("foundry.actions.validation.subprocess.Popen") as mock_popen:
            val_mod._run_script("script", "Test")

        mock_popen.assert_not_called(), (
            "subprocess.Popen must never be called for a file with no allowed extension"
        )

    def test_py_extension_uses_sys_executable(self, tmp_path, monkeypatch):
        import foundry.actions.validation as val_mod

        monkeypatch.setattr(val_mod, "TEMPLATES_DIR", tmp_path)
        py_file = tmp_path / "verify.py"
        py_file.write_text("print('ok')")

        mock_proc = MagicMock()
        mock_proc.stdout = iter([])  # no output lines

        with patch("foundry.actions.validation.subprocess.Popen", return_value=mock_proc) as mock_popen:
            val_mod._run_script("verify.py", "Test")

        mock_popen.assert_called_once()
        cmd = mock_popen.call_args[0][0]
        assert cmd[0] == sys.executable, (
            f"Expected sys.executable ({sys.executable!r}), got {cmd[0]!r}"
        )

    def test_sh_extension_uses_bin_sh(self, tmp_path, monkeypatch):
        import foundry.actions.validation as val_mod

        monkeypatch.setattr(val_mod, "TEMPLATES_DIR", tmp_path)
        sh_file = tmp_path / "run.sh"
        sh_file.write_text("#!/bin/sh\necho ok")

        mock_proc = MagicMock()
        mock_proc.stdout = iter([])

        with patch("foundry.actions.validation.subprocess.Popen", return_value=mock_proc) as mock_popen:
            val_mod._run_script("run.sh", "Test")

        mock_popen.assert_called_once()
        cmd = mock_popen.call_args[0][0]
        assert cmd[0] == "/bin/sh", (
            f"Expected '/bin/sh', got {cmd[0]!r}"
        )


# ===========================================================================
# H-28 — run_verification() always returns bool
# ===========================================================================

class TestH28RunVerificationReturnsBool:
    """run_verification() must always return True or False, never None."""

    def _make_mock_results(self):
        from foundry.actions.verification.models import (
            VerificationResult, VerificationStatus, TemplateType,
        )
        return {
            "python-saas": VerificationResult(
                name="python-saas",
                template_type=TemplateType.DOCKER,
                status=VerificationStatus.SUCCESS,
                git_ignore=True,
                git_attributes=False,
                docker_success=True,
                duration_seconds=1.0,
                timestamp=datetime.now().isoformat(),
            )
        }

    def test_returns_true_on_success(self, monkeypatch):
        from foundry.actions.verify import run_verification

        mock_results = self._make_mock_results()

        with patch("foundry.actions.verify.TemplateVerifier") as MockVerifier, \
             patch("foundry.actions.verify.generate_reports"), \
             patch("foundry.actions.verify.print_summary", return_value=0):
            MockVerifier.return_value.verify_all.return_value = mock_results
            result = run_verification(include_docker=False, output_reports=False)

        assert isinstance(result, bool), f"Expected bool, got {type(result)}"
        assert result is True

    def test_returns_false_on_failure(self, monkeypatch):
        from foundry.actions.verify import run_verification

        mock_results = self._make_mock_results()

        with patch("foundry.actions.verify.TemplateVerifier") as MockVerifier, \
             patch("foundry.actions.verify.generate_reports"), \
             patch("foundry.actions.verify.print_summary", return_value=1):
            MockVerifier.return_value.verify_all.return_value = mock_results
            result = run_verification(include_docker=False, output_reports=False)

        assert isinstance(result, bool), f"Expected bool, got {type(result)}"
        assert result is False

    def test_return_type_is_bool_not_none(self):
        """Explicit isinstance check — result must never be None."""
        from foundry.actions.verify import run_verification

        with patch("foundry.actions.verify.TemplateVerifier") as MockVerifier, \
             patch("foundry.actions.verify.generate_reports"), \
             patch("foundry.actions.verify.print_summary", return_value=0):
            MockVerifier.return_value.verify_all.return_value = {}
            result = run_verification(include_docker=False, output_reports=False)

        assert result is not None, "run_verification() must not return None"
        assert isinstance(result, bool)
