"""
Security tests for workspaces.py and features.py.

Covers:
  C-7  — feature name path traversal (_infer_feature_path)
  H-19 — symlink escape protection (create_feature_workspace copy loop)
  M-8  — absolute paths not written to .feature-workspace.json
  M-9  — output_path containment (ValueError before any writes)
  C-6  — license gate on PRO features (inject_features)
"""
import shutil
from unittest.mock import patch

import pytest

from pathlib import Path

from foundry.workspaces import _infer_feature_path, create_feature_workspace
from foundry.actions.features import inject_features


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

MOCK_FREE = {"tier": "free", "email": "user@example.com"}
MOCK_PRO = {"tier": "pro", "email": "user@example.com"}


def _base_inject_kwargs(tmp_path: Path) -> dict:
    """Return a minimal all-False kwargs dict for inject_features."""
    return dict(
        path=tmp_path,
        template="python-saas",
        commerce=False,
        tunnel=False,
        landing=False,
        admin=False,
        sqlite=False,
        ingestor=False,
        auth=False,
        merchant_dashboard=False,
        payment=False,
    )


# ---------------------------------------------------------------------------
# C-7 — Feature name path traversal
# ---------------------------------------------------------------------------

class TestC7FeatureNameTraversal:
    """_infer_feature_path must reject any feature_name that fails the
    [a-zA-Z0-9_-]+ regex — this blocks directory traversal attacks."""

    def test_dotdot_slash_rejected(self):
        assert _infer_feature_path("rails-api", "../../root") is None

    def test_dotdot_alone_rejected(self):
        assert _infer_feature_path("rails-api", "..") is None

    def test_absolute_path_rejected(self):
        assert _infer_feature_path("rails-api", "/etc/passwd") is None

    def test_null_byte_rejected(self):
        assert _infer_feature_path("rails-api", "feature\x00name") is None

    def test_spaces_rejected(self):
        assert _infer_feature_path("rails-api", "feature name with spaces") is None

    def test_slash_in_name_rejected(self):
        assert _infer_feature_path("rails-api", "foo/bar") is None

    def test_valid_alphanumeric_name_does_not_raise(self):
        # Returns None if path doesn't exist — that's fine; the important
        # thing is it doesn't raise and doesn't return something dangerous.
        result = _infer_feature_path("rails-api", "valid_feature-name")
        assert result is None or isinstance(result, str)

    def test_valid_name_with_digits_does_not_raise(self):
        result = _infer_feature_path("python-saas", "feature123")
        assert result is None or isinstance(result, str)


# ---------------------------------------------------------------------------
# H-19 — Symlink escape protection
# ---------------------------------------------------------------------------

class TestH19SymlinkEscape:
    """Symlinks inside the feature directory that point outside it must be
    skipped silently — their content must NOT appear in the workspace."""

    def test_symlink_escaping_to_etc_passwd_not_copied(self, tmp_path, monkeypatch):
        # Make tmp_path appear to be inside home so M-9 does not fire
        monkeypatch.setattr(Path, "home", lambda: tmp_path.parent)

        # Build a minimal fake feature directory
        feature_dir = tmp_path / "features" / "evil_feature"
        feature_dir.mkdir(parents=True)

        legit_file = feature_dir / "legit.py"
        legit_file.write_text("# legit code\n")

        # Symlink pointing OUTSIDE the feature directory
        evil_link = feature_dir / "escaped.txt"
        evil_link.symlink_to("/etc/passwd")

        output_dir = tmp_path / "ws_out"
        output_dir.mkdir()

        with patch("foundry.workspaces._infer_feature_path", return_value=str(feature_dir)):
            with patch("foundry.workspaces._infer_template_path", return_value=str(tmp_path)):
                result = create_feature_workspace(
                    feature_name="evil_feature",
                    template_name="rails-api",
                    output_path=str(output_dir),
                )

        assert result["success"] is True
        # Symlinked file must NOT appear in the output (exfiltration blocked)
        assert not (output_dir / "escaped.txt").exists()
        # Legitimate file MUST be present
        assert (output_dir / "legit.py").exists()

    def test_symlink_pointing_inside_feature_is_allowed(self, tmp_path, monkeypatch):
        """A symlink whose resolved target stays inside the feature dir is safe."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path.parent)

        feature_dir = tmp_path / "features" / "safe_feature"
        feature_dir.mkdir(parents=True)

        real_file = feature_dir / "real.py"
        real_file.write_text("# real\n")

        safe_link = feature_dir / "alias.py"
        safe_link.symlink_to(real_file)  # points inside the feature dir

        output_dir = tmp_path / "ws_safe"
        output_dir.mkdir()

        with patch("foundry.workspaces._infer_feature_path", return_value=str(feature_dir)):
            with patch("foundry.workspaces._infer_template_path", return_value=str(tmp_path)):
                result = create_feature_workspace(
                    feature_name="safe_feature",
                    template_name="rails-api",
                    output_path=str(output_dir),
                )

        assert result["success"] is True
        # Both the real file and the safe symlink should be copied
        assert (output_dir / "real.py").exists()


# ---------------------------------------------------------------------------
# M-8 — Absolute paths not written to JSON
# ---------------------------------------------------------------------------

class TestM8AbsolutePathsNotInJson:
    """.feature-workspace.json must not leak /Users/... or /home/... prefixes."""

    def test_metadata_json_contains_no_absolute_user_paths(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path.parent)

        feature_dir = tmp_path / "features" / "clean_feature"
        feature_dir.mkdir(parents=True)
        (feature_dir / "module.py").write_text("# module\n")

        output_dir = tmp_path / "ws_meta"
        output_dir.mkdir()

        with patch("foundry.workspaces._infer_feature_path", return_value=str(feature_dir)):
            with patch("foundry.workspaces._infer_template_path", return_value=str(tmp_path)):
                result = create_feature_workspace(
                    feature_name="clean_feature",
                    template_name="python-saas",
                    output_path=str(output_dir),
                )

        assert result["success"] is True
        metadata_file = output_dir / ".feature-workspace.json"
        assert metadata_file.exists(), ".feature-workspace.json was not created"

        raw = metadata_file.read_text()
        assert "/Users/" not in raw, "Absolute /Users/ path leaked into JSON"
        assert "/home/" not in raw, "Absolute /home/ path leaked into JSON"

    def test_metadata_injected_paths_are_relative(self, tmp_path, monkeypatch):
        """All file paths recorded inside injected_paths must be relative."""
        import json

        monkeypatch.setattr(Path, "home", lambda: tmp_path.parent)

        feature_dir = tmp_path / "features" / "rel_feature"
        feature_dir.mkdir(parents=True)
        (feature_dir / "service.py").write_text("# service\n")

        output_dir = tmp_path / "ws_rel"
        output_dir.mkdir()

        with patch("foundry.workspaces._infer_feature_path", return_value=str(feature_dir)):
            with patch("foundry.workspaces._infer_template_path", return_value=str(tmp_path)):
                result = create_feature_workspace(
                    feature_name="rel_feature",
                    template_name="python-saas",
                    output_path=str(output_dir),
                )

        assert result["success"] is True
        metadata = json.loads((output_dir / ".feature-workspace.json").read_text())

        for entry in metadata.get("injected_paths", []):
            original = entry.get("original_path", "")
            workspace = entry.get("workspace_path", "")
            assert not original.startswith("/"), f"original_path is absolute: {original}"
            assert not workspace.startswith("/"), f"workspace_path is absolute: {workspace}"


# ---------------------------------------------------------------------------
# M-9 — output_path containment
# ---------------------------------------------------------------------------

class TestM9OutputPathContainment:
    """output_path outside cwd and home must raise ValueError before any I/O."""

    def test_tmp_evil_output_raises_value_error(self):
        with pytest.raises(ValueError, match="output_path must be within"):
            create_feature_workspace(
                feature_name="any",
                template_name="rails-api",
                output_path="/tmp/evil-output",
            )

    def test_no_directory_created_when_output_rejected(self):
        evil_dir = Path("/tmp/evil-output-security-test")
        if evil_dir.exists():
            shutil.rmtree(evil_dir)

        with pytest.raises(ValueError):
            create_feature_workspace(
                feature_name="any",
                template_name="rails-api",
                output_path=str(evil_dir),
            )

        assert not evil_dir.exists(), "Directory was created despite ValueError"

    def test_path_within_home_is_accepted(self, tmp_path, monkeypatch):
        """A path inside the home directory must NOT raise ValueError
        (it falls through to the feature-not-found branch)."""
        # Use a sub-path of tmp_path which is always under home on CI runners
        # but to be safe, monkeypatch home to tmp_path itself.
        monkeypatch.setattr(
            "foundry.workspaces.Path.home",
            lambda: tmp_path,
            raising=False,
        )
        # We expect success:False (feature not found), not ValueError
        try:
            result = create_feature_workspace(
                feature_name="nonexistent",
                template_name="rails-api",
                output_path=str(tmp_path / "workspace"),
            )
            # Should fail gracefully with feature-not-found, not ValueError
            assert result["success"] is False
        except ValueError:
            pytest.fail("ValueError raised for path inside home directory")


# ---------------------------------------------------------------------------
# C-6 — License gate on PRO features
# ---------------------------------------------------------------------------

class TestC6LicenseGate:
    """inject_features must enforce tier checks for PRO-only features."""

    def test_free_tier_auth_raises_system_exit_1(self, tmp_path):
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["auth"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value=MOCK_FREE,
        ):
            with pytest.raises(SystemExit) as exc_info:
                inject_features(**kwargs)
        assert exc_info.value.code == 1

    def test_free_tier_commerce_raises_system_exit_1(self, tmp_path):
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["commerce"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value=MOCK_FREE,
        ):
            with pytest.raises(SystemExit) as exc_info:
                inject_features(**kwargs)
        assert exc_info.value.code == 1

    def test_free_tier_admin_raises_system_exit_1(self, tmp_path):
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["admin"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value=MOCK_FREE,
        ):
            with pytest.raises(SystemExit) as exc_info:
                inject_features(**kwargs)
        assert exc_info.value.code == 1

    def test_pro_tier_auth_does_not_raise_system_exit(self, tmp_path):
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["auth"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value=MOCK_PRO,
        ):
            try:
                inject_features(**kwargs)
            except SystemExit as e:
                pytest.fail(f"SystemExit raised on pro tier: code={e.code}")
            except Exception:
                pass  # Non-license errors (missing files, etc.) are acceptable

    def test_pro_tier_commerce_does_not_raise_system_exit(self, tmp_path):
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["commerce"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value=MOCK_PRO,
        ):
            try:
                inject_features(**kwargs)
            except SystemExit as e:
                pytest.fail(f"SystemExit raised on pro tier: code={e.code}")
            except Exception:
                pass

    def test_sqlite_free_tier_does_not_raise_and_skips_license_check(self, tmp_path):
        """SQLite is a free feature — license API must never be called."""
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["sqlite"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value=MOCK_FREE,
        ) as mock_gci:
            try:
                inject_features(**kwargs)
            except SystemExit as e:
                pytest.fail(f"SystemExit raised for free sqlite feature: code={e.code}")
            except Exception:
                pass
            mock_gci.assert_not_called()

    def test_tunnel_free_tier_is_blocked_and_checks_license(self, tmp_path):
        """Tunnel is a paid feature in hardened gating and must be blocked for free tier."""
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["tunnel"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value=MOCK_FREE,
        ) as mock_gci:
            with pytest.raises(SystemExit) as exc:
                inject_features(**kwargs)
            assert exc.value.code == 1
            mock_gci.assert_called_once()

    def test_enterprise_tier_unlocks_pro_features(self, tmp_path):
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["ingestor"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "enterprise", "email": "corp@example.com"},
        ):
            try:
                inject_features(**kwargs)
            except SystemExit as e:
                pytest.fail(f"SystemExit raised for enterprise tier: code={e.code}")
            except Exception:
                pass

    def test_alpha_tier_unlocks_pro_features(self, tmp_path):
        kwargs = _base_inject_kwargs(tmp_path)
        kwargs["merchant_dashboard"] = True
        with patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "alpha", "email": "alpha@example.com"},
        ):
            try:
                inject_features(**kwargs)
            except SystemExit as e:
                pytest.fail(f"SystemExit raised for alpha tier: code={e.code}")
            except Exception:
                pass
