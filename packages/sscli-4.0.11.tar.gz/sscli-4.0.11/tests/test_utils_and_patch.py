import os
from pathlib import Path
from types import SimpleNamespace

import questionary.prompts.common

from foundry import utils
from foundry import patch as patch_mod


def test_is_valid_template_markers(tmp_path, monkeypatch):
    tmpl = tmp_path / "custom"
    tmpl.mkdir()
    (tmpl / "Dockerfile").write_text("FROM python:3.12\n")

    assert utils.is_valid_template(tmpl) is True

    hidden = tmp_path / ".hidden"
    hidden.mkdir()
    assert utils.is_valid_template(hidden) is False


def test_is_internal_dev_env_flag(monkeypatch, tmp_path):
    monkeypatch.setenv("FOUNDRY_INTERNAL_DEV", "0")
    assert utils.is_internal_dev() is False

    monkeypatch.setenv("FOUNDRY_INTERNAL_DEV", "1")
    monkeypatch.setattr(utils, "FOUNDRY_ROOT", tmp_path)
    for marker in [".github", "docs", "tooling", "wiring"]:
        (tmp_path / marker).mkdir()
    assert utils.is_internal_dev() is True


def test_get_templates_local(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "TEMPLATES_DIR", tmp_path)
    (tmp_path / "python-saas").mkdir()
    (tmp_path / "python-saas" / "Dockerfile").write_text("x")

    templates = utils.get_templates()
    assert templates
    assert templates[0].name == "python-saas"


def test_get_template_info_fallback():
    info = utils.get_template_info("unknown")
    assert info["tier"] == "free"


def test_apply_description_patch(monkeypatch):
    class FakeChoiceList:
        def _get_choice_tokens(self):
            return [("class:text", "  Description: test")]

    monkeypatch.setattr(questionary.prompts.common, "ChoiceList", FakeChoiceList, raising=False)
    patch_mod.apply_description_patch()

    inst = FakeChoiceList()
    tokens = inst._get_choice_tokens()
    assert tokens[0][0] in ("class:text", "class:description")


def test_apply_description_patch_ansi(monkeypatch):
    class FakeChoiceList:
        def _get_choice_tokens(self):
            return [("class:highlighted", "\x1b[31mRed\x1b[0m")]

    monkeypatch.setattr(questionary.prompts.common, "ChoiceList", FakeChoiceList, raising=False)

    class FakeANSI:
        def __init__(self, _text):
            pass

        def __iter__(self):
            return iter([("ansired", "Red")])

    monkeypatch.setattr("prompt_toolkit.formatted_text.ANSI", FakeANSI)

    patch_mod.apply_description_patch()

    inst = FakeChoiceList()
    tokens = inst._get_choice_tokens()
    assert tokens[0][0].startswith("class:highlighted")


def test_apply_description_patch_no_target(monkeypatch):
    monkeypatch.delattr(questionary.prompts.common, "ChoiceList", raising=False)
    monkeypatch.delattr(questionary.prompts.common, "InquirerControl", raising=False)

    patch_mod.apply_description_patch()
