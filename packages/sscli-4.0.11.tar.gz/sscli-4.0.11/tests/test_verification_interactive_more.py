from types import SimpleNamespace

from foundry.actions import verification_interactive


def test_verification_menu_routes(monkeypatch):
    selections = iter(["mount", "matrix", "verify", "back"])

    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )

    called = {"mount": 0, "matrix": 0, "verify": 0, "pause": 0}
    monkeypatch.setattr(verification_interactive, "interactive_mount_feature", lambda: called.__setitem__("mount", called["mount"] + 1))
    monkeypatch.setattr(verification_interactive, "interactive_matrix_tests", lambda: called.__setitem__("matrix", called["matrix"] + 1))
    monkeypatch.setattr(verification_interactive, "interactive_verify_all", lambda: called.__setitem__("verify", called["verify"] + 1))
    monkeypatch.setattr(verification_interactive, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))

    verification_interactive.verification_menu()

    assert called["mount"] == 1
    assert called["matrix"] == 1
    assert called["verify"] == 1
    assert called["pause"] == 3


def test_interactive_mount_feature_not_internal(monkeypatch):
    import sys
    import types

    fake_features = types.SimpleNamespace(AVAILABLE_EXTENSIONS={})
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)
    monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: False)
    printed = []
    monkeypatch.setattr(verification_interactive.console, "print", lambda msg: printed.append(msg))

    verification_interactive.interactive_mount_feature()

    assert any("only available" in str(msg) for msg in printed)


def test_interactive_matrix_tests_missing_suite(monkeypatch):
    confirms = iter([True, False])

    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(confirms)),
    )

    monkeypatch.setattr(verification_interactive.Path, "exists", lambda _self: False)
    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    verification_interactive.interactive_matrix_tests()


def test_interactive_verify_all_runs(monkeypatch):
    monkeypatch.setattr(
        verification_interactive.questionary,
        "checkbox",
        lambda *a, **k: SimpleNamespace(ask=lambda: ["matrix", "linters"]),
    )
    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    verification_interactive.interactive_verify_all()


# ---------------------------------------------------------------------------
# TASK 2 — New gap-closing tests
# ---------------------------------------------------------------------------

def test_mount_feature_no_compatible_features(monkeypatch):
    """is_internal_dev=True, AVAILABLE_EXTENSIONS has no features for the selected template."""
    import sys
    import types
    import foundry.utils as futils

    monkeypatch.setattr(futils, "is_internal_dev", lambda: True)
    monkeypatch.setattr(futils, "get_templates", lambda: [SimpleNamespace(name="python-saas")])
    fake_features = types.SimpleNamespace(
        AVAILABLE_EXTENSIONS={"commerce": {"templates": ["rails-api"]}},  # python-saas not listed
    )
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    select_calls = iter(["python-saas"])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_calls)),
    )

    printed = []
    monkeypatch.setattr(
        verification_interactive.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )

    verification_interactive.interactive_mount_feature()

    assert any("No features available" in msg for msg in printed)


def test_mount_feature_cancel_feature_select(monkeypatch):
    """is_internal_dev=True, features exist but user cancels feature selection (None)."""
    import sys
    import types
    import foundry.utils as futils

    monkeypatch.setattr(futils, "is_internal_dev", lambda: True)
    monkeypatch.setattr(futils, "get_templates", lambda: [SimpleNamespace(name="python-saas")])
    fake_features = types.SimpleNamespace(
        AVAILABLE_EXTENSIONS={"commerce": {"templates": ["python-saas"]}},
    )
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    select_results = iter(["python-saas", None])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_results)),
    )

    confirm_called = {"value": False}
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: (confirm_called.__setitem__("value", True) or SimpleNamespace(ask=lambda: False)),
    )
    monkeypatch.setattr(verification_interactive.console, "print", lambda *_a, **_k: None)

    verification_interactive.interactive_mount_feature()

    # confirm dialog should never be reached since feature_name is None
    assert not confirm_called["value"]


def test_mount_feature_confirm_cancelled(monkeypatch):
    """template+feature+dir selected, confirm returns False → prints Cancelled."""
    import sys
    import types
    import foundry.utils as futils

    monkeypatch.setattr(futils, "is_internal_dev", lambda: True)
    monkeypatch.setattr(futils, "get_templates", lambda: [SimpleNamespace(name="python-saas")])
    fake_features = types.SimpleNamespace(
        AVAILABLE_EXTENSIONS={"commerce": {"templates": ["python-saas"]}},
    )
    monkeypatch.setitem(sys.modules, "foundry.features", fake_features)

    select_results = iter(["python-saas", "commerce"])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(select_results)),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "text",
        lambda *a, **k: SimpleNamespace(ask=lambda: "/tmp"),
    )
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: False),
    )

    printed = []
    monkeypatch.setattr(
        verification_interactive.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )

    verification_interactive.interactive_mount_feature()

    assert any("Cancelled" in msg for msg in printed)


def test_matrix_tests_verbose_failure(monkeypatch):
    """skip_docker=False, verbose=True, subprocess returns returncode=1 → 'Some tests failed'."""
    confirms = iter([False, True])  # skip_docker=False, verbose=True
    monkeypatch.setattr(
        verification_interactive.questionary,
        "confirm",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(confirms)),
    )
    monkeypatch.setattr(
        verification_interactive.Path,
        "exists",
        lambda _self: True,
    )
    monkeypatch.setattr(
        verification_interactive.subprocess,
        "run",
        lambda cmd, **kwargs: SimpleNamespace(returncode=1),
    )

    printed = []
    monkeypatch.setattr(
        verification_interactive.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )

    verification_interactive.interactive_matrix_tests()

    assert any("Some tests failed" in msg for msg in printed)


def test_verify_all_exception_handler(monkeypatch):
    """Table() raises RuntimeError → except block prints the error."""
    monkeypatch.setattr(
        verification_interactive.questionary,
        "checkbox",
        lambda *a, **k: SimpleNamespace(ask=lambda: ["matrix"]),
    )

    def raise_error(*a, **k):
        raise RuntimeError("forced table error")

    monkeypatch.setattr(verification_interactive, "Table", raise_error)

    printed = []
    monkeypatch.setattr(
        verification_interactive.console,
        "print",
        lambda *a, **k: printed.append(str(a[0]) if a else ""),
    )

    verification_interactive.interactive_verify_all()

    assert any("forced table error" in msg for msg in printed)


def test_verification_menu_loops_back_after_mount(monkeypatch):
    """Select 'mount', mount executes, loop continues, then select 'back'."""
    selections = iter(["mount", "back"])
    monkeypatch.setattr(
        verification_interactive.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )

    called = {"mount": 0}
    monkeypatch.setattr(
        verification_interactive,
        "interactive_mount_feature",
        lambda: called.__setitem__("mount", called["mount"] + 1),
    )
    monkeypatch.setattr(verification_interactive, "pause", lambda: None)

    verification_interactive.verification_menu()

    assert called["mount"] == 1
