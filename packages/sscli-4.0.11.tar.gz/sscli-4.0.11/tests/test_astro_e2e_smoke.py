"""
E2E Smoke Test: Static Landing Full Injection Pipeline
=======================================================

Runs `inject_features` against real template source files (no auth layer).
Validates every injection point and idempotency.

Running:  pytest tests/test_astro_e2e_smoke.py -v --no-cov
"""
import os
import shutil
import pytest
from pathlib import Path

# Locate the real vault and template
FOUNDRY_META = Path(__file__).resolve().parent.parent.parent.parent  # foundry-meta/
TEMPLATE_SRC = FOUNDRY_META / "templates" / "static-landing"
VAULT_ROOT   = FOUNDRY_META / "features" / "landing"

REQUIRED_TEMPLATE_FILES = [
    "src/pages/index.astro",
    "src/styles/themes.css",
    "astro.config.mjs",
    "package.json",
]


def _skip_unless_template_and_vault(path: Path, vault: Path):
    if not path.exists():
        pytest.skip(f"static-landing template not available at {path}")
    if not vault.exists():
        pytest.skip(f"features/landing vault not available at {vault}")
    for f in REQUIRED_TEMPLATE_FILES:
        if not (path / f).exists():
            pytest.skip(f"Template missing required file: {f}")


@pytest.fixture
def smoke_project(tmp_path):
    """Copies only the injection-relevant source files into a tmp directory."""
    _skip_unless_template_and_vault(TEMPLATE_SRC, VAULT_ROOT)

    for rel in REQUIRED_TEMPLATE_FILES:
        (tmp_path / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(TEMPLATE_SRC / rel, tmp_path / rel)

    return tmp_path


class TestAstroE2ESmokeCommerceAuth:
    """End-to-end smoke: inject commerce + auth into a real template copy."""

    @pytest.fixture(autouse=True)
    def _mock_pro_license(self, monkeypatch):
        """Grant pro tier so commerce feature gate passes in all tests."""
        import foundry.actions.features as feat
        monkeypatch.setattr(feat, "get_current_license_info", lambda **kw: {"tier": "pro", "authorized": True})

    def test_pricing_injected(self, smoke_project):
        from foundry.actions.features import inject_features
        with pytest.MonkeyPatch.context() as mp:
            mp.setenv("FOUNDRY_ROOT", str(FOUNDRY_META))
            # re-import so the constant reflects the env var
            import importlib, foundry.constants as c
            mp.setattr(c, "FOUNDRY_ROOT", FOUNDRY_META)
            import foundry.actions.features as feat
            mp.setattr(feat, "FOUNDRY_ROOT", FOUNDRY_META)
            inject_features(path=smoke_project, template="static-landing", commerce=True, tunnel=False, auth=False)

        content = (smoke_project / "src/pages/index.astro").read_text()
        assert 'id="pricing"' in content, "pricing section was not injected"

    def test_auth_injected(self, smoke_project):
        from foundry.actions.features import inject_features
        import foundry.actions.features as feat
        orig = feat.FOUNDRY_ROOT
        feat.FOUNDRY_ROOT = FOUNDRY_META
        try:
            inject_features(path=smoke_project, template="static-landing", commerce=False, tunnel=False, auth=True)
        finally:
            feat.FOUNDRY_ROOT = orig

        content = (smoke_project / "src/pages/index.astro").read_text()
        assert 'id="auth"' in content, "auth section was not injected"

    def test_commerce_sdk_injected_into_config(self, smoke_project):
        import foundry.actions.features as feat
        orig = feat.FOUNDRY_ROOT
        feat.FOUNDRY_ROOT = FOUNDRY_META
        try:
            from foundry.actions.features import inject_features
            inject_features(path=smoke_project, template="static-landing", commerce=True, tunnel=False, auth=False)
        finally:
            feat.FOUNDRY_ROOT = orig

        config = (smoke_project / "astro.config.mjs").read_text()
        assert "Commerce" in config or "commerce" in config.lower(), \
            "commerce SDK was not injected into astro.config.mjs"

    def test_themes_injected(self, smoke_project):
        import foundry.actions.features as feat
        orig = feat.FOUNDRY_ROOT
        feat.FOUNDRY_ROOT = FOUNDRY_META
        try:
            from foundry.actions.features import inject_features
            inject_features(path=smoke_project, template="static-landing", commerce=False, tunnel=False, auth=False)
        finally:
            feat.FOUNDRY_ROOT = orig

        css = (smoke_project / "src/styles/themes.css").read_text()
        assert "midnight" in css or "crimson" in css or "amber" in css, \
            "premium themes were not injected into themes.css"

    def test_all_features_combined(self, smoke_project):
        """Full combination: commerce + auth + themes in one run."""
        import foundry.actions.features as feat
        orig = feat.FOUNDRY_ROOT
        feat.FOUNDRY_ROOT = FOUNDRY_META
        try:
            from foundry.actions.features import inject_features
            inject_features(path=smoke_project, template="static-landing", commerce=True, tunnel=False, auth=True)
        finally:
            feat.FOUNDRY_ROOT = orig

        idx = (smoke_project / "src/pages/index.astro").read_text()
        cfg = (smoke_project / "astro.config.mjs").read_text()
        css = (smoke_project / "src/styles/themes.css").read_text()

        assert 'id="pricing"' in idx
        assert 'id="auth"' in idx
        assert "Commerce" in cfg or "commerce" in cfg.lower()
        assert "midnight" in css or "crimson" in css

    def test_idempotency_no_duplication(self, smoke_project):
        """Running inject_features twice must not duplicate any content."""
        import foundry.actions.features as feat
        orig = feat.FOUNDRY_ROOT
        feat.FOUNDRY_ROOT = FOUNDRY_META
        try:
            from foundry.actions.features import inject_features
            inject_features(path=smoke_project, template="static-landing", commerce=True, tunnel=False, auth=True)
            inject_features(path=smoke_project, template="static-landing", commerce=True, tunnel=False, auth=True)
        finally:
            feat.FOUNDRY_ROOT = orig

        idx = (smoke_project / "src/pages/index.astro").read_text()
        css = (smoke_project / "src/styles/themes.css").read_text()

        assert idx.count('id="pricing"') == 1,   "pricing section duplicated"
        assert idx.count('id="auth"') == 1,       "auth section duplicated"
        assert css.count("midnight") == 1,        "midnight theme duplicated"

    def test_markers_preserved_after_injection(self, smoke_project):
        """Injection wrappers must remain in place after content is inserted."""
        import foundry.actions.features as feat
        orig = feat.FOUNDRY_ROOT
        feat.FOUNDRY_ROOT = FOUNDRY_META
        try:
            from foundry.actions.features import inject_features
            inject_features(path=smoke_project, template="static-landing", commerce=True, tunnel=False, auth=True)
        finally:
            feat.FOUNDRY_ROOT = orig

        idx = (smoke_project / "src/pages/index.astro").read_text()
        assert "{/* [SS-FEATURE-COMMERCE-START] */}" in idx
        assert "{/* [SS-FEATURE-COMMERCE-END] */}" in idx
        assert "{/* [SS-FEATURE-AUTH-START] */}" in idx
        assert "{/* [SS-FEATURE-AUTH-END] */}" in idx

    def test_seo_analyzer_injected(self, smoke_project):
        import foundry.actions.features as feat
        orig = feat.FOUNDRY_ROOT
        feat.FOUNDRY_ROOT = FOUNDRY_META
        try:
            from foundry.actions.features import inject_features
            inject_features(
                path=smoke_project,
                template="static-landing",
                commerce=False,
                tunnel=False,
                auth=False,
                seo_analyzer=True,
            )
        finally:
            feat.FOUNDRY_ROOT = orig

        package_json = (smoke_project / "package.json").read_text()
        seo_script = smoke_project / "bin" / "seo-analyzer.mjs"

        assert seo_script.exists(), "seo analyzer script was not injected"
        assert '"seo:score": "node ./bin/seo-analyzer.mjs"' in package_json
        assert '"lighthouse"' in package_json
