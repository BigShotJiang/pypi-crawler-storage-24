"""
Coverage tests for:
  - foundry/actions/generation_utils.py
  - foundry/actions/setup.py
"""
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch, call

import pytest


# ===========================================================================
# check_tier_access
# ===========================================================================

class TestCheckTierAccess:
    def test_internal_dev_always_allowed(self):
        """is_internal_dev() == True bypasses all checks."""
        from foundry.actions.generation_utils import check_tier_access

        with patch("foundry.utils.is_internal_dev", return_value=True):
            assert check_tier_access("any-template", "enterprise") is True

    def test_sufficient_tier_returns_true(self, monkeypatch):
        """User with sufficient tier level gains access."""
        from foundry.actions.generation_utils import check_tier_access

        with patch("foundry.utils.is_internal_dev", return_value=False):
            monkeypatch.setattr(
                "foundry.actions.generation_utils.get_current_license_info",
                lambda verify=False: {"tier": "pro", "user_id": "u1"},
            )
            monkeypatch.setattr(
                "foundry.actions.generation_utils.console",
                SimpleNamespace(print=MagicMock()),
            )
            # "pro" (level 2) vs required "alpha" (level 1) → OK
            assert check_tier_access("python-saas", "alpha") is True

    def test_insufficient_tier_returns_false_and_prints(self, monkeypatch):
        """User with lower tier is denied and a panel is printed."""
        from foundry.actions.generation_utils import check_tier_access

        with patch("foundry.utils.is_internal_dev", return_value=False):
            monkeypatch.setattr(
                "foundry.actions.generation_utils.get_current_license_info",
                lambda verify=False: {"tier": "free", "user_id": "u2"},
            )
            log = MagicMock()
            monkeypatch.setattr("foundry.actions.generation_utils.log_event", log)
            printed = []
            monkeypatch.setattr(
                "foundry.actions.generation_utils.console",
                SimpleNamespace(print=lambda msg: printed.append(msg)),
            )

            result = check_tier_access("python-saas", "pro")
        assert result is False
        assert printed  # Panel was printed

    def test_insufficient_tier_logs_forbidden_event(self, monkeypatch):
        from foundry.actions.generation_utils import check_tier_access

        with patch("foundry.utils.is_internal_dev", return_value=False):
            monkeypatch.setattr(
                "foundry.actions.generation_utils.get_current_license_info",
                lambda verify=False: {"tier": "free", "user_id": "u3"},
            )
            log = MagicMock()
            monkeypatch.setattr("foundry.actions.generation_utils.log_event", log)
            monkeypatch.setattr(
                "foundry.actions.generation_utils.console",
                SimpleNamespace(print=MagicMock()),
            )

            check_tier_access("some-template", "enterprise")
        log.assert_called_once()
        assert "GENERATE_FORBIDDEN" in log.call_args[0][0]

    def test_same_tier_level_allowed(self, monkeypatch):
        """Exact match on tier level should be allowed."""
        from foundry.actions.generation_utils import check_tier_access

        with patch("foundry.utils.is_internal_dev", return_value=False):
            monkeypatch.setattr(
                "foundry.actions.generation_utils.get_current_license_info",
                lambda verify=False: {"tier": "alpha", "user_id": "u4"},
            )
            monkeypatch.setattr(
                "foundry.actions.generation_utils.console",
                SimpleNamespace(print=MagicMock()),
            )
            assert check_tier_access("python-saas", "alpha") is True


# ===========================================================================
# check_payment_entitlement
# ===========================================================================

class TestCheckPaymentEntitlement:
    def test_internal_dev_always_allowed(self):
        from foundry.actions.generation_utils import check_payment_entitlement

        with patch("foundry.utils.is_internal_dev", return_value=True):
            assert check_payment_entitlement() is True

    def test_payment_feature_unlocked_returns_true(self, monkeypatch):
        from foundry.actions.generation_utils import check_payment_entitlement

        with patch("foundry.utils.is_internal_dev", return_value=False):
            monkeypatch.setattr(
                "foundry.actions.generation_utils.get_current_license_info",
                lambda verify=False: {"payment_feature_unlocked": True},
            )
            assert check_payment_entitlement() is True

    def test_payment_feature_locked_returns_false(self, monkeypatch):
        from foundry.actions.generation_utils import check_payment_entitlement

        with patch("foundry.utils.is_internal_dev", return_value=False):
            monkeypatch.setattr(
                "foundry.actions.generation_utils.get_current_license_info",
                lambda verify=False: {"payment_feature_unlocked": False},
            )
            log = MagicMock()
            monkeypatch.setattr("foundry.actions.generation_utils.log_event", log)
            monkeypatch.setattr(
                "foundry.actions.generation_utils.console",
                SimpleNamespace(print=MagicMock()),
            )

            result = check_payment_entitlement()
        assert result is False
        log.assert_called_once()
        assert "PAYMENT_FEATURE_FORBIDDEN" in log.call_args[0][0]

    def test_payment_feature_missing_key_returns_false(self, monkeypatch):
        """Missing key defaults to False (locked)."""
        from foundry.actions.generation_utils import check_payment_entitlement

        with patch("foundry.utils.is_internal_dev", return_value=False):
            monkeypatch.setattr(
                "foundry.actions.generation_utils.get_current_license_info",
                lambda verify=False: {},
            )
            monkeypatch.setattr("foundry.actions.generation_utils.log_event", MagicMock())
            monkeypatch.setattr(
                "foundry.actions.generation_utils.console",
                SimpleNamespace(print=MagicMock()),
            )

            assert check_payment_entitlement() is False


# ===========================================================================
# apply_landing_blueprint
# ===========================================================================

class TestApplyLandingBlueprint:
    def test_no_blueprint_file_does_nothing(self, tmp_path):
        """If blueprint.json doesn't exist, function exits silently."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        # No blueprint.json in tmp_path
        apply_landing_blueprint(tmp_path)  # Should not raise

    def test_basic_blueprint_preserved(self, tmp_path, monkeypatch):
        """Blueprint without overrides is read and written back correctly."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        data = {"site_name": "TestSite", "theme": "default"}
        (tmp_path / "blueprint.json").write_text(json.dumps(data))
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        apply_landing_blueprint(tmp_path)
        result = json.loads((tmp_path / "blueprint.json").read_text())
        assert result["site_name"] == "TestSite"

    def test_custom_content_path_merges_data(self, tmp_path, monkeypatch):
        """content_path JSON is merged into blueprint."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        blueprint = {"site_name": "OldName"}
        (tmp_path / "blueprint.json").write_text(json.dumps(blueprint))

        custom = tmp_path / "custom.json"
        custom.write_text(json.dumps({"site_name": "NewName", "extra_key": "value"}))

        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        apply_landing_blueprint(tmp_path, content_path=str(custom))
        result = json.loads((tmp_path / "blueprint.json").read_text())
        assert result["site_name"] == "NewName"
        assert result["extra_key"] == "value"
        assert any("custom content" in str(m).lower() for m in printed)

    def test_missing_content_path_prints_warning(self, tmp_path, monkeypatch):
        """Non-existent content_path prints a warning instead of raising."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        (tmp_path / "blueprint.json").write_text(json.dumps({"x": 1}))
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        # Use a path within tmp_path that doesn't exist (security check requires project-relative path)
        apply_landing_blueprint(tmp_path, content_path=str(tmp_path / "nonexistent.json"))
        assert any("not found" in str(m).lower() for m in printed)

    def test_theme_override_applied(self, tmp_path, monkeypatch):
        """Providing a theme updates blueprint.json theme field."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        (tmp_path / "blueprint.json").write_text(json.dumps({"theme": "light"}))
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        apply_landing_blueprint(tmp_path, theme="dark")
        result = json.loads((tmp_path / "blueprint.json").read_text())
        assert result["theme"] == "dark"
        assert any("dark" in str(m) for m in printed)

    def test_exception_in_json_parsing_prints_warning(self, tmp_path, monkeypatch):
        """Invalid JSON in blueprint.json prints a warning."""
        from foundry.actions.generation_utils import apply_landing_blueprint

        (tmp_path / "blueprint.json").write_text("{invalid json")
        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        apply_landing_blueprint(tmp_path)  # Should not raise
        assert any("Failed" in str(m) for m in printed)


# ===========================================================================
# inject_metadata
# ===========================================================================

class TestInjectMetadata:
    def test_replaces_template_name_in_package_json(self, tmp_path, monkeypatch):
        """Template name in package.json is replaced with app_name."""
        from foundry.actions.generation_utils import inject_metadata

        pkg = tmp_path / "package.json"
        pkg.write_text('{"name": "python-saas", "version": "1.0.0"}')
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        inject_metadata(tmp_path, "python-saas", "my-cool-app")
        assert "my-cool-app" in pkg.read_text()
        assert "python-saas" not in pkg.read_text()

    def test_replaces_stackapp_with_capitalized_name(self, tmp_path, monkeypatch):
        """StackApp placeholder is replaced with capitalized app_name."""
        from foundry.actions.generation_utils import inject_metadata

        readme = tmp_path / "README.md"
        readme.write_text("# StackApp Documentation")
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        inject_metadata(tmp_path, "python-saas", "myapp")
        content = readme.read_text()
        assert "Myapp" in content

    def test_missing_files_skipped_gracefully(self, tmp_path, monkeypatch):
        """Files that don't exist are skipped without error."""
        from foundry.actions.generation_utils import inject_metadata

        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )
        # No files exist at all — should not raise
        inject_metadata(tmp_path, "python-saas", "app")

    def test_multiple_files_updated(self, tmp_path, monkeypatch):
        """Template name replaced in every applicable file."""
        from foundry.actions.generation_utils import inject_metadata

        for fname in ["pyproject.toml", "README.md", ".env.example"]:
            (tmp_path / fname).write_text(f"template=python-saas\n")

        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        inject_metadata(tmp_path, "python-saas", "better-app")

        for fname in ["pyproject.toml", "README.md", ".env.example"]:
            content = (tmp_path / fname).read_text()
            assert "better-app" in content


# ===========================================================================
# disable_linters
# ===========================================================================

class TestDisableLinters:
    def test_removes_rubocop_from_gemfile(self, tmp_path, monkeypatch):
        """rubocop gems are commented out in Gemfile."""
        from foundry.actions.generation_utils import disable_linters

        gemfile = tmp_path / "Gemfile"
        gemfile.write_text("gem 'rubocop'\ngem 'rubocop-rails'\n")

        monkeypatch.setattr(
            "foundry.actions.generation_utils.RemoveToolSectionsCM",
            MagicMock(return_value=MagicMock(apply=MagicMock())),
        )
        monkeypatch.setattr(
            "foundry.actions.generation_utils.RemovePythonDependencyCM",
            MagicMock(return_value=MagicMock(execute=MagicMock())),
        )
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        disable_linters(tmp_path)
        content = gemfile.read_text()
        assert "# gem 'rubocop'" in content
        assert "# gem 'rubocop-rails'" in content

    def test_pyproject_codemod_called_when_exists(self, tmp_path, monkeypatch):
        """RemoveToolSectionsCM.apply is called on pyproject.toml."""
        from foundry.actions.generation_utils import disable_linters

        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("[tool.ruff]\nline-length = 88\n")

        mock_sections_cm = MagicMock()
        mock_dep_cm = MagicMock()
        monkeypatch.setattr(
            "foundry.actions.generation_utils.RemoveToolSectionsCM",
            lambda sections: mock_sections_cm,
        )
        monkeypatch.setattr(
            "foundry.actions.generation_utils.RemovePythonDependencyCM",
            lambda dependencies: mock_dep_cm,
        )
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        disable_linters(tmp_path)
        mock_sections_cm.apply.assert_called_once_with(pyproject)
        mock_dep_cm.execute.assert_called_once_with(pyproject)

    def test_no_files_does_nothing(self, tmp_path, monkeypatch):
        """No pyproject.toml or Gemfile — function exits silently."""
        from foundry.actions.generation_utils import disable_linters

        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )
        disable_linters(tmp_path)  # Should not raise


# ===========================================================================
# regenerate_poetry_lock
# ===========================================================================

class TestRegeneratePoetryLock:
    def test_skips_when_no_pyproject(self, tmp_path, monkeypatch):
        """Neither pyproject.toml nor poetry.lock present → no subprocess call."""
        from foundry.actions.generation_utils import regenerate_poetry_lock

        with patch("foundry.actions.generation_utils.subprocess.run") as mock_run:
            regenerate_poetry_lock(tmp_path)
            mock_run.assert_not_called()

    def test_skips_when_no_poetry_lock(self, tmp_path, monkeypatch):
        """pyproject.toml exists but poetry.lock absent → no subprocess call."""
        from foundry.actions.generation_utils import regenerate_poetry_lock

        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\n")
        with patch("foundry.actions.generation_utils.subprocess.run") as mock_run:
            regenerate_poetry_lock(tmp_path)
            mock_run.assert_not_called()

    def test_poetry_not_found_prints_warning(self, tmp_path, monkeypatch):
        """FileNotFoundError when checking poetry version prints a warning."""
        from foundry.actions.generation_utils import regenerate_poetry_lock

        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\n")
        (tmp_path / "poetry.lock").write_text("")

        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )
        with patch(
            "foundry.actions.generation_utils.subprocess.run",
            side_effect=FileNotFoundError,
        ):
            regenerate_poetry_lock(tmp_path)
        assert any("Poetry not found" in str(m) for m in printed)

    def test_poetry_runs_successfully(self, tmp_path, monkeypatch):
        """Successful poetry lock prints success message."""
        from foundry.actions.generation_utils import regenerate_poetry_lock

        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\n")
        (tmp_path / "poetry.lock").write_text("")

        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        success_result = MagicMock()
        success_result.returncode = 0

        def fake_run(cmd, **kwargs):
            if cmd == ["poetry", "--version"]:
                return MagicMock()
            return success_result

        with patch("foundry.actions.generation_utils.subprocess.run", side_effect=fake_run):
            regenerate_poetry_lock(tmp_path)
        assert any("regenerated successfully" in str(m) for m in printed)

    def test_poetry_lock_fails_prints_warning(self, tmp_path, monkeypatch):
        """Non-zero returncode from poetry lock prints relevant warning."""
        from foundry.actions.generation_utils import regenerate_poetry_lock

        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\n")
        (tmp_path / "poetry.lock").write_text("")

        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        fail_result = MagicMock()
        fail_result.returncode = 1
        fail_result.stderr = "Something went wrong"

        def fake_run(cmd, **kwargs):
            if cmd == ["poetry", "--version"]:
                return MagicMock()
            return fail_result

        with patch("foundry.actions.generation_utils.subprocess.run", side_effect=fake_run):
            regenerate_poetry_lock(tmp_path)
        assert any("Poetry lock failed" in str(m) for m in printed)

    def test_unexpected_exception_prints_warning(self, tmp_path, monkeypatch):
        """Unexpected exception inside regenerate prints a warning."""
        from foundry.actions.generation_utils import regenerate_poetry_lock

        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\n")
        (tmp_path / "poetry.lock").write_text("")

        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        def fake_run(cmd, **kwargs):
            if cmd == ["poetry", "--version"]:
                return MagicMock()
            raise Exception("unexpected")

        with patch("foundry.actions.generation_utils.subprocess.run", side_effect=fake_run):
            regenerate_poetry_lock(tmp_path)
        assert any("Unexpected" in str(m) for m in printed)


# ===========================================================================
# validate_and_fix_pyproject
# ===========================================================================

class TestValidateAndFixPyproject:
    def test_no_pyproject_does_nothing(self, tmp_path, monkeypatch):
        """Missing pyproject.toml is handled silently."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )
        validate_and_fix_pyproject(tmp_path)  # Should not raise

    def test_valid_pyproject_writes_back(self, tmp_path, monkeypatch):
        """A well-formed pyproject.toml is read, validated, and written back."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        pyproject_content = '[tool.poetry]\nname = "app"\nversion = "0.1.0"\n\n[tool.poetry.dependencies]\npython = "^3.11"\n'
        (tmp_path / "pyproject.toml").write_text(pyproject_content)

        printed = []
        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=lambda m: printed.append(m)),
        )

        validate_and_fix_pyproject(tmp_path)
        assert any("Validated" in str(m) for m in printed)

    def test_unquoted_dependency_version_gets_quoted(self, tmp_path, monkeypatch):
        """Dependency versions not wrapped in quotes are auto-quoted."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        content = '[tool.poetry]\nname = "app"\nversion = "0.1.0"\n\n[tool.poetry.dependencies]\npython = ^3.11\n'
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(content)

        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        validate_and_fix_pyproject(tmp_path)
        result = pyproject.read_text()
        assert 'python = "^3.11"' in result

    def test_missing_version_field_gets_default(self, tmp_path, monkeypatch):
        """Missing version in [tool.poetry] as the LAST section gets default '0.1.0'.
        The code only inserts a version when in_tool_poetry=True at end-of-loop,
        which only happens when [tool.poetry] is the last section in the file.
        """
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        # [tool.poetry] must be the last (or only) section for the post-loop
        # insertion logic to trigger (in_tool_poetry stays True after the loop).
        content = '[tool.poetry]\nname = "app"\n'
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(content)

        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        validate_and_fix_pyproject(tmp_path)
        result = pyproject.read_text()
        assert '0.1.0' in result

    def test_empty_version_value_gets_default(self, tmp_path, monkeypatch):
        """Empty version value is replaced with default '0.1.0'."""
        from foundry.actions.generation_utils import validate_and_fix_pyproject

        content = '[tool.poetry]\nname = "app"\nversion = ""\n\n[tool.poetry.dependencies]\npython = "^3.11"\n'
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(content)

        monkeypatch.setattr(
            "foundry.actions.generation_utils.console",
            SimpleNamespace(print=MagicMock()),
        )

        validate_and_fix_pyproject(tmp_path)
        result = pyproject.read_text()
        assert '0.1.0' in result


# ===========================================================================
# run_setup
# ===========================================================================

class TestRunSetup:
    def _patch_setup(self, monkeypatch, tmp_path, user_tier="pro"):
        """Patch constants and auth so run_setup uses tmp_path as TEMPLATES_DIR."""
        import foundry.actions.setup as setup_mod

        monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", tmp_path)
        monkeypatch.setattr(
            setup_mod, "get_current_license_info",
            lambda: {"tier": user_tier},
        )
        monkeypatch.setattr(
            setup_mod, "TIER_HIERARCHY",
            {"free": 0, "alpha": 1, "pro": 2, "enterprise": 3, "admin": 10},
        )
        monkeypatch.setattr(
            setup_mod, "TEMPLATE_REGISTRY",
            {
                "python-saas": {"tier": "free"},
                "rails-api": {"tier": "pro"},
            },
        )
        printed = []
        # console.print is called with 0 or 1 positional args — accept *args
        monkeypatch.setattr(
            setup_mod, "console",
            SimpleNamespace(print=lambda *args: printed.append(args[0] if args else "")),
        )
        monkeypatch.setattr(
            setup_mod, "Confirm",
            SimpleNamespace(ask=lambda *args, **kwargs: True),
        )
        return printed

    def test_no_template_dirs_completes_without_error(self, tmp_path, monkeypatch):
        """When no template directories exist, setup suite completes cleanly."""
        from foundry.actions.setup import run_setup

        printed = self._patch_setup(monkeypatch, tmp_path)
        run_setup()  # No dirs → should skip all, print final message
        assert any("completed" in str(m).lower() for m in printed)

    def test_no_setup_script_skips_template(self, tmp_path, monkeypatch):
        """Templates without bin/setup.py are skipped gracefully."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "python-saas"
        tmpl_path.mkdir(parents=True)
        # No bin/setup.py

        printed = self._patch_setup(monkeypatch, tmp_path)
        run_setup()
        assert any("No setup.py found" in str(m) for m in printed)

    def test_blocked_template_skipped_with_message(self, tmp_path, monkeypatch):
        """Templates requiring higher tier than user has are skipped."""
        from foundry.actions.setup import run_setup

        # rails-api requires "pro", user only has "free"
        tmpl_path = tmp_path / "rails-api"
        tmpl_path.mkdir(parents=True)

        printed = self._patch_setup(monkeypatch, tmp_path, user_tier="free")
        run_setup()
        assert any("Skipping rails-api" in str(m) for m in printed)

    def test_blocked_templates_summary_printed(self, tmp_path, monkeypatch):
        """Summary of blocked templates is printed at the end."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "rails-api"
        tmpl_path.mkdir(parents=True)

        printed = self._patch_setup(monkeypatch, tmp_path, user_tier="free")
        run_setup()
        assert any("tier restrictions" in str(m) for m in printed)

    def test_successful_setup_script_prints_complete(self, tmp_path, monkeypatch):
        """A working setup script results in a 'setup complete' message."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "python-saas"
        bin_dir = tmpl_path / "bin"
        bin_dir.mkdir(parents=True)
        setup_script = bin_dir / "setup.py"
        setup_script.write_text("# setup")

        printed = self._patch_setup(monkeypatch, tmp_path, user_tier="pro")

        with patch("foundry.actions.setup.subprocess.check_call", return_value=0):
            run_setup()

        assert any("setup complete" in str(m).lower() for m in printed)

    def test_failed_setup_script_calls_sys_exit(self, tmp_path, monkeypatch):
        """A CalledProcessError from setup script triggers sys.exit(1)."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "python-saas"
        bin_dir = tmpl_path / "bin"
        bin_dir.mkdir(parents=True)
        (bin_dir / "setup.py").write_text("# setup")

        self._patch_setup(monkeypatch, tmp_path, user_tier="pro")

        with patch(
            "foundry.actions.setup.subprocess.check_call",
            side_effect=subprocess.CalledProcessError(1, "python"),
        ):
            with pytest.raises(SystemExit) as exc:
                run_setup()
        assert exc.value.code == 1

    def test_unexpected_exception_calls_sys_exit(self, tmp_path, monkeypatch):
        """An unexpected exception from setup script triggers sys.exit(1)."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "python-saas"
        bin_dir = tmpl_path / "bin"
        bin_dir.mkdir(parents=True)
        (bin_dir / "setup.py").write_text("# setup")

        self._patch_setup(monkeypatch, tmp_path, user_tier="pro")

        with patch(
            "foundry.actions.setup.subprocess.check_call",
            side_effect=OSError("permission denied"),
        ):
            with pytest.raises(SystemExit) as exc:
                run_setup()
        assert exc.value.code == 1

    def test_force_flag_passed_to_subprocess(self, tmp_path, monkeypatch):
        """--force flag is forwarded to the setup subprocess command."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "python-saas"
        bin_dir = tmpl_path / "bin"
        bin_dir.mkdir(parents=True)
        (bin_dir / "setup.py").write_text("# setup")

        self._patch_setup(monkeypatch, tmp_path, user_tier="pro")

        calls = []
        with patch(
            "foundry.actions.setup.subprocess.check_call",
            side_effect=lambda cmd, **kw: calls.append(cmd),
        ):
            run_setup(force=True)

        assert "--force" in calls[0]

    def test_skip_deps_flag_passed_to_subprocess(self, tmp_path, monkeypatch):
        """--skip-deps flag is forwarded to the setup subprocess command."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "python-saas"
        bin_dir = tmpl_path / "bin"
        bin_dir.mkdir(parents=True)
        (bin_dir / "setup.py").write_text("# setup")

        self._patch_setup(monkeypatch, tmp_path, user_tier="pro")

        calls = []
        with patch(
            "foundry.actions.setup.subprocess.check_call",
            side_effect=lambda cmd, **kw: calls.append(cmd),
        ):
            run_setup(skip_deps=True)

        assert "--skip-deps" in calls[0]

    def test_strategy_flag_passed_to_subprocess(self, tmp_path, monkeypatch):
        """--strategy flag is forwarded to the setup subprocess command."""
        from foundry.actions.setup import run_setup

        tmpl_path = tmp_path / "python-saas"
        bin_dir = tmpl_path / "bin"
        bin_dir.mkdir(parents=True)
        (bin_dir / "setup.py").write_text("# setup")

        self._patch_setup(monkeypatch, tmp_path, user_tier="pro")

        calls = []
        with patch(
            "foundry.actions.setup.subprocess.check_call",
            side_effect=lambda cmd, **kw: calls.append(cmd),
        ):
            run_setup(strategy="docker")

        assert "--strategy" in calls[0]
        assert "docker" in calls[0]
