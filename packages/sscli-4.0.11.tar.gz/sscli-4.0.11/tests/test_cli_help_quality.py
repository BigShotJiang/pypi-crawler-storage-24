"""
SSA-53: Auto-docs quality gates for sscli CLI.

Validates that every CLI command and command group has non-empty help text.
Uses typer.testing.CliRunner — does NOT call real auth/network code.
"""

import pytest
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner
from foundry.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Root-level gate
# ---------------------------------------------------------------------------

class TestRootHelp:
    def test_root_help_exits_zero(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0

    def test_root_help_has_meaningful_output(self):
        result = runner.invoke(app, ["--help"])
        assert len(result.output) > 50, "Root --help output is too short"

    def test_root_help_mentions_top_level_commands(self):
        result = runner.invoke(app, ["--help"])
        output = result.output.lower()
        # Core commands must appear in help
        for cmd in ("explore", "new", "upgrade", "login", "logout", "whoami"):
            assert cmd in output, f"Command '{cmd}' missing from root --help"


# ---------------------------------------------------------------------------
# Top-level command help strings
# ---------------------------------------------------------------------------

class TestTopLevelCommandHelp:
    """Each top-level command must expose --help without crashing."""

    def _assert_help_ok(self, *args):
        result = runner.invoke(app, list(args) + ["--help"])
        assert result.exit_code == 0, (
            f"{' '.join(args)} --help exited {result.exit_code}:\n{result.output}"
        )
        assert len(result.output.strip()) > 10, (
            f"{' '.join(args)} --help returned almost no output"
        )

    def test_explore_help(self):
        self._assert_help_ok("explore")

    def test_new_help(self):
        self._assert_help_ok("new")

    def test_inject_help(self):
        self._assert_help_ok("inject")

    def test_setup_help(self):
        self._assert_help_ok("setup")

    def test_validate_help(self):
        self._assert_help_ok("validate")

    def test_health_help(self):
        self._assert_help_ok("health")

    def test_verify_help(self):
        self._assert_help_ok("verify")

    def test_ready_help(self):
        self._assert_help_ok("ready")

    def test_upgrade_help(self):
        self._assert_help_ok("upgrade")

    def test_login_help(self):
        self._assert_help_ok("login")

    def test_logout_help(self):
        self._assert_help_ok("logout")

    def test_whoami_help(self):
        self._assert_help_ok("whoami")


# ---------------------------------------------------------------------------
# Sub-app command group help
# ---------------------------------------------------------------------------

class TestCommandGroupHelp:
    """Every registered sub-app must have a non-empty group-level --help."""

    def _assert_group_help_ok(self, group: str):
        result = runner.invoke(app, [group, "--help"])
        assert result.exit_code == 0, (
            f"sscli {group} --help exited {result.exit_code}:\n{result.output}"
        )
        assert len(result.output.strip()) > 10

    def test_auth_group_help(self):
        self._assert_group_help_ok("auth")

    def test_interactive_group_help(self):
        self._assert_group_help_ok("interactive")

    def test_obs_group_help(self):
        self._assert_group_help_ok("obs")

    def test_feedback_group_help(self):
        self._assert_group_help_ok("feedback")

    def test_report_group_help(self):
        self._assert_group_help_ok("report")


# ---------------------------------------------------------------------------
# Sub-command help: auth
# ---------------------------------------------------------------------------

class TestAuthSubcommandHelp:
    def test_auth_login_help(self):
        result = runner.invoke(app, ["auth", "login", "--help"])
        assert result.exit_code == 0
        assert "login" in result.output.lower()

    def test_auth_logout_help(self):
        result = runner.invoke(app, ["auth", "logout", "--help"])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Sub-command help: obs
# ---------------------------------------------------------------------------

class TestObsSubcommandHelp:
    def test_obs_diff_help(self):
        result = runner.invoke(app, ["obs", "diff", "--help"])
        assert result.exit_code == 0
        assert len(result.output.strip()) > 10


# ---------------------------------------------------------------------------
# Sub-command help: feedback
# ---------------------------------------------------------------------------

class TestFeedbackSubcommandHelp:
    def _check(self, *args):
        result = runner.invoke(app, ["feedback"] + list(args) + ["--help"])
        assert result.exit_code == 0, (
            f"sscli feedback {' '.join(args)} --help exited {result.exit_code}:\n{result.output}"
        )
        assert len(result.output.strip()) > 10

    def test_feedback_quick_help(self):
        self._check("quick")

    def test_feedback_detailed_help(self):
        self._check("detailed")

    def test_feedback_bug_help(self):
        self._check("bug")

    def test_feedback_feature_help(self):
        self._check("feature")

    def test_feedback_nps_help(self):
        self._check("nps")

    def test_feedback_list_help(self):
        self._check("list")

    def test_feedback_export_help(self):
        self._check("export")


# ---------------------------------------------------------------------------
# Sub-command help: report
# ---------------------------------------------------------------------------

class TestReportSubcommandHelp:
    def test_report_submit_help(self):
        result = runner.invoke(app, ["report", "submit", "--help"])
        assert result.exit_code == 0

    def test_report_view_help(self):
        result = runner.invoke(app, ["report", "view", "--help"])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Help text quality: required options must have descriptions
# ---------------------------------------------------------------------------

class TestHelpTextQuality:
    def test_new_command_required_options_have_help(self):
        result = runner.invoke(app, ["new", "--help"])
        assert result.exit_code == 0
        output = result.output
        # --template and --name are required — they must appear with descriptions
        assert "--template" in output
        assert "--name" in output

    def test_inject_command_path_option_has_help(self):
        result = runner.invoke(app, ["inject", "--help"])
        assert result.exit_code == 0
        assert "--path" in result.output or "-p" in result.output

    def test_upgrade_command_dry_run_option_has_help(self):
        result = runner.invoke(app, ["upgrade", "--help"])
        assert result.exit_code == 0
        assert "--dry-run" in result.output

    def test_verify_command_options_have_help(self):
        result = runner.invoke(app, ["verify", "--help"])
        assert result.exit_code == 0
        assert "--skip-docker" in result.output
