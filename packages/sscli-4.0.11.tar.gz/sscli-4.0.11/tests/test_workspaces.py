import os
import json
import pytest
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock
from foundry.workspaces import (
    create_feature_workspace,
    list_workspaces,
    _infer_template_path,
    _infer_feature_path,
    _should_skip_workspace_file,
    _copy_file_with_annotation
)

@pytest.fixture
def mock_foundry_root(tmp_path):
    root = tmp_path / "foundry"
    root.mkdir()
    
    # Create templates structure
    templates = root / "templates"
    templates.mkdir()
    python_saas = templates / "python-saas"
    python_saas.mkdir()
    (python_saas / "pyproject.toml").write_text("[tool.poetry]\nname='python-saas'")
    (python_saas / "README.md").write_text("# Python SaaS")
    
    # Create features structure
    features = root / "features"
    features.mkdir()
    commerce = features / "commerce" / "python-saas"
    commerce.mkdir(parents=True)
    (commerce / "models.py").write_text("class Product: pass")
    (commerce / "views.py").write_text("def list_products(): pass")
    
    # Create a sub-directory in feature
    utils = commerce / "utils"
    utils.mkdir()
    (utils / "helper.py").write_text("def help(): pass")
    
    with patch("foundry.workspaces.FOUNDRY_ROOT", str(root)):
        yield root

def test_infer_template_path(mock_foundry_root):
    path = _infer_template_path("python-saas")
    assert path is not None
    assert Path(path).name == "python-saas"
    assert Path(path).exists()

    # Test non-existent template
    path = _infer_template_path("non-existent")
    assert path is None

def test_infer_feature_path(mock_foundry_root):
    # Test hierarchical path: features/commerce/python-saas
    path = _infer_feature_path("python-saas", "commerce")
    assert path is not None
    assert "commerce" in path
    assert "python-saas" in path
    assert Path(path).exists()

    # Test fallback path (simulated)
    flat_feature = mock_foundry_root / "features" / "flat"
    flat_feature.mkdir()
    path = _infer_feature_path("any-template", "flat")
    assert path is not None
    assert "flat" in path

def test_should_skip_workspace_file():
    assert _should_skip_workspace_file(Path("venv/bin/python")) is True
    assert _should_skip_workspace_file(Path("src/main.py")) is False
    assert _should_skip_workspace_file(Path(".git/config")) is True
    assert _should_skip_workspace_file(Path("__pycache__/main.cpython-39.pyc")) is True
    assert _should_skip_workspace_file(Path(".env")) is True
    assert _should_skip_workspace_file(Path("node_modules/package.json")) is True

def test_copy_file_with_annotation(tmp_path):
    src = tmp_path / "source.py"
    src.write_text("print('hello')")
    dst = tmp_path / "dest.py"
    
    _copy_file_with_annotation(src, dst, "feature")
    assert dst.exists()
    assert dst.read_text() == "print('hello')"

def test_create_feature_workspace_success(mock_foundry_root, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    output_dir = tmp_path / "my-workspace"
    
    result = create_feature_workspace(
        feature_name="commerce",
        template_name="python-saas",
        output_path=str(output_dir)
    )
    
    assert result["success"] is True
    assert output_dir.exists()
    assert (output_dir / "models.py").exists()
    assert (output_dir / "utils" / "helper.py").exists()
    assert (output_dir / ".template-context-pyproject.toml").exists()
    assert (output_dir / ".feature-workspace.json").exists()
    assert (output_dir / "WORKSPACE_README.md").exists()
    
    # Verify metadata
    metadata_file = output_dir / ".feature-workspace.json"
    metadata = json.loads(metadata_file.read_text())
    assert metadata["feature_name"] == "commerce"
    assert metadata["template_name"] == "python-saas"
    assert metadata["files_included"] > 0

def test_create_feature_workspace_not_found(mock_foundry_root, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    output_dir = tmp_path / "fail-workspace"
    
    # Missing feature
    result = create_feature_workspace(
        feature_name="missing",
        template_name="python-saas",
        output_path=str(output_dir)
    )
    assert result["success"] is False
    assert "Feature not found" in result["error"]
    
    # Missing template
    result = create_feature_workspace(
        feature_name="commerce",
        template_name="missing-template",
        output_path=str(output_dir)
    )
    assert result["success"] is False
    assert "Base template not found" in result["error"]

def test_list_workspaces(tmp_path):
    # Create mock workspaces
    ws1 = tmp_path / "ws1"
    ws1.mkdir()
    (ws1 / ".feature-workspace.json").write_text(json.dumps({
        "workspace_id": "ws1-id",
        "feature_name": "feat1",
        "template_name": "temp1",
        "created_at": "2023-01-01T10:00:00"
    }))
    
    ws2 = tmp_path / "ws2" / "sub"
    ws2.mkdir(parents=True)
    (ws2 / ".feature-workspace.json").write_text(json.dumps({
        "workspace_id": "ws2-id",
        "feature_name": "feat2",
        "template_name": "temp2",
        "created_at": "2023-01-02T10:00:00"
    }))
    
    result = list_workspaces(str(tmp_path))
    assert result["success"] is True
    assert result["workspaces_found"] == 2
    assert result["workspaces"][0]["feature_name"] == "feat2"  # Sorted by date
    assert result["workspaces"][1]["feature_name"] == "feat1"
