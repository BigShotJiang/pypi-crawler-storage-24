"""
Comprehensive test coverage for foundry/actions/transformation.py.

Tests TransformationCommand class, registry, and dry-run integration.
Targets: 90%+ coverage of transformation.py (208 lines).
"""

import pytest
import json
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch, call
from foundry.actions.transformation import (
    TransformationCommand,
    TransformationCommandRegistry,
    register_command,
    get_command,
    handle_dry_run_output,
    _registry,
)


class TestTransformationCommandInit:
    """Test TransformationCommand.__init__()."""

    def test_init_basic(self):
        """Test basic initialization with name and description."""
        cmd = TransformationCommand(name="test", description="Test command")
        assert cmd.name == "test"
        assert cmd.description == "Test command"
        assert cmd.dry_run_engine is None

    def test_init_with_different_values(self):
        """Test initialization with various names and descriptions."""
        cmd = TransformationCommand(name="refactor", description="Refactor code")
        assert cmd.name == "refactor"
        assert cmd.description == "Refactor code"
        assert cmd.dry_run_engine is None


class MockTransformationCommand(TransformationCommand):
    """Mock subclass that implements _run_transformation."""
    
    def __init__(self, name: str, description: str, should_succeed: bool = True):
        super().__init__(name, description)
        self.should_succeed = should_succeed
        self.run_kwargs = None
    
    def _run_transformation(self, **kwargs) -> bool:
        """Store kwargs and return success/failure."""
        self.run_kwargs = kwargs
        return self.should_succeed


class TestTransformationCommandExecute:
    """Test TransformationCommand.execute() method."""

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_execute_dry_run_mode(self, mock_dry_run_cls, mock_console):
        """Test execute with dry_run=True."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_unified_diff.return_value = "diff output"
        mock_engine.get_summary_line.return_value = "2 files changed"
        
        cmd = MockTransformationCommand("test", "Test")
        result = cmd.execute(dry_run=True, foo="bar")
        
        assert result is True
        assert cmd.dry_run_engine is mock_engine
        assert cmd.run_kwargs == {"foo": "bar"}
        
        # Verify console prints
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any("DRY-RUN" in s for s in print_calls)
        assert any("Dry-run complete" in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_execute_normal_mode(self, mock_console):
        """Test execute with dry_run=False (normal mode)."""
        cmd = MockTransformationCommand("test", "Test")
        result = cmd.execute(dry_run=False, foo="bar")
        
        assert result is True
        assert cmd.dry_run_engine is None
        assert cmd.run_kwargs == {"foo": "bar"}
        
        # Verify success message
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any("completed successfully" in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_execute_transformation_failure(self, mock_console):
        """Test execute when _run_transformation returns False."""
        cmd = MockTransformationCommand("test", "Test", should_succeed=False)
        result = cmd.execute(dry_run=False)
        
        assert result is False

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_execute_transformation_failure_in_dry_run(self, mock_dry_run_cls, mock_console):
        """Test execute when _run_transformation fails during dry-run."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        
        cmd = MockTransformationCommand("test", "Test", should_succeed=False)
        result = cmd.execute(dry_run=True)
        
        assert result is False

    @patch("foundry.actions.transformation.console")
    def test_execute_exception_handling(self, mock_console):
        """Test execute handles exceptions properly."""
        class FailingCommand(TransformationCommand):
            def _run_transformation(self, **kwargs):
                raise RuntimeError("Test error")
        
        cmd = FailingCommand("test", "Test")
        result = cmd.execute(dry_run=False, verbose=False)
        
        assert result is False
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any("failed" in s.lower() for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_execute_exception_with_verbose(self, mock_console):
        """Test execute with verbose=True prints traceback."""
        class FailingCommand(TransformationCommand):
            def _run_transformation(self, **kwargs):
                raise ValueError("Test error")
        
        cmd = FailingCommand("test", "Test")
        
        with patch("traceback.print_exc") as mock_traceback:
            result = cmd.execute(dry_run=False, verbose=True)
            assert result is False
            mock_traceback.assert_called_once()

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_execute_with_json_output(self, mock_dry_run_cls, mock_console):
        """Test execute with json_output=True."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_json.return_value = '{"changes": []}'
        mock_engine.get_summary_line.return_value = "0 files changed"
        
        cmd = MockTransformationCommand("test", "Test")
        result = cmd.execute(dry_run=True, json_output=True)
        
        assert result is True
        mock_engine.as_json.assert_called_once_with(include_content=False)

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_execute_with_stats_only(self, mock_dry_run_cls, mock_console):
        """Test execute with stats_only=True."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_stats.return_value = "Stats output"
        
        cmd = MockTransformationCommand("test", "Test")
        result = cmd.execute(dry_run=True, stats_only=True, verbose=False)
        
        assert result is True
        mock_engine.as_stats.assert_called_once_with(verbose=False)

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_execute_with_stats_only_verbose(self, mock_dry_run_cls, mock_console):
        """Test execute with stats_only=True and verbose=True."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_stats.return_value = "Verbose stats output"
        
        cmd = MockTransformationCommand("test", "Test")
        result = cmd.execute(dry_run=True, stats_only=True, verbose=True)
        
        assert result is True
        mock_engine.as_stats.assert_called_once_with(verbose=True)

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_execute_with_output_file(self, mock_dry_run_cls, mock_console, tmp_path):
        """Test execute with output_file specified."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_unified_diff.return_value = "diff content"
        mock_engine.get_summary_line.return_value = "1 file changed"
        
        output_file = tmp_path / "output.txt"
        cmd = MockTransformationCommand("test", "Test")
        result = cmd.execute(dry_run=True, output_file=str(output_file))
        
        assert result is True
        assert output_file.exists()
        assert output_file.read_text() == "diff content"
        
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any("Output written to" in s for s in print_calls)


class TestTransformationCommandRunTransformation:
    """Test TransformationCommand._run_transformation() abstract method."""

    def test_run_transformation_not_implemented(self):
        """Test that _run_transformation must be overridden."""
        cmd = TransformationCommand("test", "Test")
        with pytest.raises(NotImplementedError, match="must implement _run_transformation"):
            cmd._run_transformation()


class TestTransformationCommandShowDryRunOutput:
    """Test TransformationCommand._show_dry_run_output() method."""

    @patch("foundry.actions.transformation.console")
    def test_show_dry_run_output_no_engine(self, mock_console):
        """Test _show_dry_run_output when engine is None."""
        cmd = MockTransformationCommand("test", "Test")
        cmd._show_dry_run_output()
        
        # Should not print anything if engine is None
        mock_console.print.assert_not_called()

    @patch("foundry.actions.transformation.console")
    def test_show_dry_run_output_unified_diff(self, mock_console):
        """Test _show_dry_run_output with default unified diff."""
        mock_engine = Mock()
        mock_engine.as_unified_diff.return_value = "unified diff output"
        mock_engine.get_summary_line.return_value = "3 files changed"
        
        cmd = MockTransformationCommand("test", "Test")
        cmd.dry_run_engine = mock_engine
        cmd._show_dry_run_output(json_output=False, stats_only=False)
        
        mock_engine.as_unified_diff.assert_called_once()
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert "unified diff output" in print_calls
        assert any("Summary" in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_show_dry_run_output_json(self, mock_console):
        """Test _show_dry_run_output with json_output=True."""
        mock_engine = Mock()
        json_data = '{"files": ["a.py", "b.py"]}'
        mock_engine.as_json.return_value = json_data
        mock_engine.get_summary_line.return_value = "2 files"
        
        cmd = MockTransformationCommand("test", "Test")
        cmd.dry_run_engine = mock_engine
        cmd._show_dry_run_output(json_output=True)
        
        mock_engine.as_json.assert_called_once_with(include_content=False)
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert json_data in print_calls

    @patch("foundry.actions.transformation.console")
    def test_show_dry_run_output_stats(self, mock_console):
        """Test _show_dry_run_output with stats_only=True."""
        mock_engine = Mock()
        mock_engine.as_stats.return_value = "Stats: 5 files, 42 lines"
        
        cmd = MockTransformationCommand("test", "Test")
        cmd.dry_run_engine = mock_engine
        cmd._show_dry_run_output(stats_only=True, verbose=False)
        
        mock_engine.as_stats.assert_called_once_with(verbose=False)
        # When stats_only is True, summary should NOT be shown
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert "Stats: 5 files, 42 lines" in print_calls
        # Summary should not appear when stats_only=True
        mock_engine.get_summary_line.assert_not_called()

    @patch("foundry.actions.transformation.console")
    def test_show_dry_run_output_to_file(self, mock_console, tmp_path):
        """Test _show_dry_run_output with output_file."""
        mock_engine = Mock()
        mock_engine.as_unified_diff.return_value = "file content"
        mock_engine.get_summary_line.return_value = "summary"
        
        output_file = tmp_path / "result.txt"
        cmd = MockTransformationCommand("test", "Test")
        cmd.dry_run_engine = mock_engine
        cmd._show_dry_run_output(output_file=str(output_file))
        
        assert output_file.exists()
        assert output_file.read_text() == "file content"
        
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any(str(output_file) in s for s in print_calls)


class TestTransformationCommandRegistry:
    """Test TransformationCommandRegistry class."""

    def test_registry_init(self):
        """Test registry initialization."""
        registry = TransformationCommandRegistry()
        assert registry._commands == {}

    def test_register_command(self):
        """Test registering a command."""
        registry = TransformationCommandRegistry()
        cmd = MockTransformationCommand("test", "Test command")
        registry.register(cmd)
        assert "test" in registry._commands
        assert registry._commands["test"] is cmd

    def test_register_multiple_commands(self):
        """Test registering multiple commands."""
        registry = TransformationCommandRegistry()
        cmd1 = MockTransformationCommand("cmd1", "Command 1")
        cmd2 = MockTransformationCommand("cmd2", "Command 2")
        registry.register(cmd1)
        registry.register(cmd2)
        assert len(registry._commands) == 2
        assert registry._commands["cmd1"] is cmd1
        assert registry._commands["cmd2"] is cmd2

    def test_get_existing_command(self):
        """Test getting an existing command."""
        registry = TransformationCommandRegistry()
        cmd = MockTransformationCommand("test", "Test")
        registry.register(cmd)
        retrieved = registry.get("test")
        assert retrieved is cmd

    def test_get_nonexistent_command(self):
        """Test getting a non-existent command returns None."""
        registry = TransformationCommandRegistry()
        result = registry.get("nonexistent")
        assert result is None

    def test_list_commands_empty(self):
        """Test list_commands when empty."""
        registry = TransformationCommandRegistry()
        assert registry.list_commands() == []

    def test_list_commands_with_entries(self):
        """Test list_commands with registered commands."""
        registry = TransformationCommandRegistry()
        cmd1 = MockTransformationCommand("cmd1", "Command 1")
        cmd2 = MockTransformationCommand("cmd2", "Command 2")
        registry.register(cmd1)
        registry.register(cmd2)
        commands = registry.list_commands()
        assert set(commands) == {"cmd1", "cmd2"}

    def test_register_overwrites_existing(self):
        """Test that registering same name overwrites previous command."""
        registry = TransformationCommandRegistry()
        cmd1 = MockTransformationCommand("test", "First")
        cmd2 = MockTransformationCommand("test", "Second")
        registry.register(cmd1)
        registry.register(cmd2)
        assert registry.get("test") is cmd2


class TestGlobalRegistry:
    """Test global registry functions."""

    def teardown_method(self):
        """Clean up global registry after each test."""
        _registry._commands.clear()

    def test_register_command_function(self):
        """Test global register_command function."""
        cmd = MockTransformationCommand("global_test", "Global test")
        register_command(cmd)
        assert "global_test" in _registry._commands

    def test_get_command_function(self):
        """Test global get_command function."""
        cmd = MockTransformationCommand("global_test", "Global test")
        register_command(cmd)
        retrieved = get_command("global_test")
        assert retrieved is cmd

    def test_get_command_not_found(self):
        """Test get_command returns None for missing command."""
        result = get_command("nonexistent_global")
        assert result is None

    def test_multiple_commands_in_global_registry(self):
        """Test multiple commands can be registered globally."""
        cmd1 = MockTransformationCommand("global1", "Global 1")
        cmd2 = MockTransformationCommand("global2", "Global 2")
        register_command(cmd1)
        register_command(cmd2)
        assert get_command("global1") is cmd1
        assert get_command("global2") is cmd2


class TestHandleDryRunOutput:
    """Test handle_dry_run_output() utility function."""

    @patch("foundry.actions.transformation.console")
    def test_handle_dry_run_output_unified_diff(self, mock_console):
        """Test handle_dry_run_output with unified diff."""
        mock_engine = Mock()
        mock_engine.as_unified_diff.return_value = "diff output"
        mock_engine.get_summary_line.return_value = "summary"
        
        handle_dry_run_output(mock_engine)
        
        mock_engine.as_unified_diff.assert_called_once()
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert "diff output" in print_calls
        assert any("Summary" in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_handle_dry_run_output_json_format(self, mock_console):
        """Test handle_dry_run_output with json_format=True."""
        mock_engine = Mock()
        json_output = '{"test": "data"}'
        mock_engine.as_json.return_value = json_output
        mock_engine.get_summary_line.return_value = "summary"
        
        handle_dry_run_output(mock_engine, json_format=True)
        
        mock_engine.as_json.assert_called_once_with(include_content=False)
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert json_output in print_calls

    @patch("foundry.actions.transformation.console")
    def test_handle_dry_run_output_stats_only(self, mock_console):
        """Test handle_dry_run_output with stats_only=True."""
        mock_engine = Mock()
        mock_engine.as_stats.return_value = "Stats content"
        
        handle_dry_run_output(mock_engine, stats_only=True, verbose=False)
        
        mock_engine.as_stats.assert_called_once_with(verbose=False)
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert "Stats content" in print_calls
        # With stats_only, summary should not appear
        mock_engine.get_summary_line.assert_not_called()

    @patch("foundry.actions.transformation.console")
    def test_handle_dry_run_output_stats_verbose(self, mock_console):
        """Test handle_dry_run_output with stats_only=True and verbose=True."""
        mock_engine = Mock()
        mock_engine.as_stats.return_value = "Verbose stats"
        
        handle_dry_run_output(mock_engine, stats_only=True, verbose=True)
        
        mock_engine.as_stats.assert_called_once_with(verbose=True)

    @patch("foundry.actions.transformation.console")
    def test_handle_dry_run_output_to_file(self, mock_console, tmp_path):
        """Test handle_dry_run_output with output_file."""
        mock_engine = Mock()
        mock_engine.as_unified_diff.return_value = "output data"
        mock_engine.get_summary_line.return_value = "summary"
        
        output_file = tmp_path / "dry_run.txt"
        handle_dry_run_output(mock_engine, output_file=str(output_file))
        
        assert output_file.exists()
        assert output_file.read_text() == "output data"
        
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any(str(output_file) in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_handle_dry_run_output_json_to_file(self, mock_console, tmp_path):
        """Test handle_dry_run_output with json_format and output_file."""
        mock_engine = Mock()
        json_content = '{"key": "value"}'
        mock_engine.as_json.return_value = json_content
        mock_engine.get_summary_line.return_value = "summary"
        
        output_file = tmp_path / "output.json"
        handle_dry_run_output(mock_engine, json_format=True, output_file=str(output_file))
        
        assert output_file.exists()
        assert output_file.read_text() == json_content


class TestIntegrationScenarios:
    """Test realistic integration scenarios."""

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_full_dry_run_workflow(self, mock_dry_run_cls, mock_console):
        """Test complete dry-run workflow from start to finish."""
        # Setup mock engine
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_unified_diff.return_value = "--- a/file.py\n+++ b/file.py\n@@ -1 +1 @@\n-old\n+new"
        mock_engine.get_summary_line.return_value = "1 file changed, 1 insertion(+), 1 deletion(-)"
        
        # Create command and execute
        cmd = MockTransformationCommand("refactor", "Refactor codebase")
        result = cmd.execute(
            dry_run=True,
            json_output=False,
            stats_only=False,
            output_file=None,
            verbose=False,
            project_path="/test/project"
        )
        
        assert result is True
        assert cmd.dry_run_engine is mock_engine
        assert cmd.run_kwargs == {"project_path": "/test/project"}
        
        # Verify console output
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any("DRY-RUN" in s for s in print_calls)
        assert any("Dry-run complete" in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_full_normal_execution_workflow(self, mock_console):
        """Test complete normal execution workflow."""
        cmd = MockTransformationCommand("upgrade", "Upgrade template")
        result = cmd.execute(
            dry_run=False,
            template="python-saas",
            version="2.0.0"
        )
        
        assert result is True
        assert cmd.run_kwargs == {"template": "python-saas", "version": "2.0.0"}
        
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any("completed successfully" in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_dry_run_with_json_and_file_output(self, mock_dry_run_cls, mock_console, tmp_path):
        """Test dry-run with JSON output written to file."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        json_data = json.dumps({"changes": [{"file": "test.py", "status": "modified"}]})
        mock_engine.as_json.return_value = json_data
        mock_engine.get_summary_line.return_value = "1 file modified"
        
        output_file = tmp_path / "changes.json"
        cmd = MockTransformationCommand("new", "Generate new feature")
        result = cmd.execute(
            dry_run=True,
            json_output=True,
            output_file=str(output_file),
            feature="auth"
        )
        
        assert result is True
        assert output_file.exists()
        data = json.loads(output_file.read_text())
        assert data["changes"][0]["file"] == "test.py"

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_command_reuse_with_different_modes(self, mock_dry_run_cls, mock_console):
        """Test reusing command instance for multiple executions."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_unified_diff.return_value = "diff"
        mock_engine.get_summary_line.return_value = "summary"
        
        cmd = MockTransformationCommand("test", "Test")
        
        # First execution: dry-run
        result1 = cmd.execute(dry_run=True, param1="value1")
        assert result1 is True
        assert cmd.dry_run_engine is mock_engine
        
        # Second execution: normal
        result2 = cmd.execute(dry_run=False, param2="value2")
        assert result2 is True
        assert cmd.run_kwargs == {"param2": "value2"}


class TestEdgeCases:
    """Test edge cases and error conditions."""

    @patch("foundry.actions.transformation.console")
    def test_empty_kwargs(self, mock_console):
        """Test execute with no kwargs."""
        cmd = MockTransformationCommand("test", "Test")
        result = cmd.execute(dry_run=False)
        assert result is True
        assert cmd.run_kwargs == {}

    @patch("foundry.actions.transformation.console")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_dry_run_engine_methods_called_correctly(self, mock_dry_run_cls, mock_console):
        """Test that DryRunEngine methods are called with correct parameters."""
        mock_engine = Mock()
        mock_dry_run_cls.return_value = mock_engine
        mock_engine.as_stats.return_value = "stats"
        
        cmd = MockTransformationCommand("test", "Test")
        cmd.execute(dry_run=True, stats_only=True, verbose=True)
        
        # Verify as_stats called with verbose=True
        mock_engine.as_stats.assert_called_once_with(verbose=True)
        # Verify get_summary_line NOT called when stats_only=True
        mock_engine.get_summary_line.assert_not_called()

    @patch("foundry.actions.transformation.console")
    def test_command_name_in_messages(self, mock_console):
        """Test that command name appears in console messages."""
        cmd = MockTransformationCommand("custom_cmd", "Custom command")
        cmd.execute(dry_run=False)
        
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        # Check if command name appears in success message
        assert any("custom_cmd" in s.lower() or "completed successfully" in s for s in print_calls)

    @patch("foundry.actions.transformation.console")
    def test_exception_message_includes_command_name(self, mock_console):
        """Test that exception messages include command name."""
        class FailingCommand(TransformationCommand):
            def _run_transformation(self, **kwargs):
                raise Exception("Test error")
        
        cmd = FailingCommand("failing_cmd", "Failing command")
        result = cmd.execute(dry_run=False, verbose=False)
        
        assert result is False
        print_calls = [str(call[0][0]) for call in mock_console.print.call_args_list]
        assert any("failing_cmd" in s.lower() for s in print_calls)

    def test_registry_isolation(self):
        """Test that each registry instance is independent."""
        registry1 = TransformationCommandRegistry()
        registry2 = TransformationCommandRegistry()
        
        cmd = MockTransformationCommand("test", "Test")
        registry1.register(cmd)
        
        assert registry1.get("test") is cmd
        assert registry2.get("test") is None

    @patch("foundry.actions.transformation.console")
    def test_output_file_path_creation(self, mock_console, tmp_path):
        """Test that output file with nested path is created correctly."""
        mock_engine = Mock()
        mock_engine.as_unified_diff.return_value = "content"
        mock_engine.get_summary_line.return_value = "summary"
        
        # Create nested directory structure
        nested_dir = tmp_path / "reports" / "transformations"
        nested_dir.mkdir(parents=True)
        output_file = nested_dir / "result.txt"
        
        cmd = MockTransformationCommand("test", "Test")
        cmd.dry_run_engine = mock_engine
        cmd._show_dry_run_output(output_file=str(output_file))
        
        assert output_file.exists()
        assert output_file.read_text() == "content"
