"""
Security regression tests for foundry/constants.py and foundry/actions/repo_utils.py.

Covers:
  C-3  _get_api_url() host allowlist
  H-7  SEED_SOURCE_DOMAIN regex validation
  M-10 file:// URI only in dev mode
  C-4  Tar-slip protection in download_template()
  H-9  repo_vis allowlist in initialize_github_repo()
  M-11 subprocess timeout enforcement
"""
from __future__ import annotations

import io
import os
import sys
import tarfile
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _drop_constants_cache() -> None:
    """Remove foundry.constants from sys.modules so the next import re-executes."""
    sys.modules.pop("foundry.constants", None)


def _make_evil_tar_gz(member_name: str = "../evil.txt") -> bytes:
    """Return a gzipped tar archive that contains one path-traversal member."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        payload = b"pwned"
        info = tarfile.TarInfo(name=member_name)
        info.size = len(payload)
        tar.addfile(info, io.BytesIO(payload))
    return buf.getvalue()


# ─────────────────────────────────────────────────────────────────────────────
# C-3 — _get_api_url() host allowlist
# ─────────────────────────────────────────────────────────────────────────────

class TestGetApiUrl:
    """LICENSE_SERVER_URL must point to an explicitly allowlisted host."""

    @staticmethod
    def _call(monkeypatch, url: str | None):
        if url is None:
            monkeypatch.delenv("LICENSE_SERVER_URL", raising=False)
        else:
            monkeypatch.setenv("LICENSE_SERVER_URL", url)
        # Import the live function (reads os.getenv at call time)
        from foundry.constants import _get_api_url
        return _get_api_url()

    def test_http_evil_com_raises(self, monkeypatch):
        """Plain http:// to a non-allowlisted host must be rejected."""
        with pytest.raises(ValueError, match="LICENSE_SERVER_URL"):
            self._call(monkeypatch, "http://evil.com")

    def test_https_evil_com_raises(self, monkeypatch):
        """https:// to a non-allowlisted host must also be rejected."""
        with pytest.raises(ValueError, match="LICENSE_SERVER_URL"):
            self._call(monkeypatch, "https://evil.com")

    def test_valid_auth_seedsource_accepted(self, monkeypatch):
        """auth.seedsource.dev is an explicitly allowlisted host."""
        result = self._call(monkeypatch, "https://auth.seedsource.dev/api")
        assert result == "https://auth.seedsource.dev/api"

    def test_localhost_accepted(self, monkeypatch):
        """localhost is allowed for local development."""
        result = self._call(monkeypatch, "https://localhost:8080")
        assert result == "https://localhost:8080"

    def test_phishing_seedsource_attacker_rejected(self, monkeypatch):
        """A hostname that embeds 'seedsource.dev' as a subdomain of attacker.com
        must NOT be mistaken for a legitimate host."""
        with pytest.raises(ValueError, match="LICENSE_SERVER_URL"):
            self._call(monkeypatch, "https://phishing.seedsource.dev.attacker.com")

    def test_no_env_returns_production_url(self, monkeypatch):
        """Without an env-var override the production URL is returned."""
        result = self._call(monkeypatch, None)
        assert result == "https://auth.seedsource.dev/api"


# ─────────────────────────────────────────────────────────────────────────────
# H-7 — SEED_SOURCE_DOMAIN regex validation (import-time check)
# ─────────────────────────────────────────────────────────────────────────────

class TestSeedSourceDomainValidation:
    """SEED_SOURCE_DOMAIN must be a syntactically-valid hostname at import time."""

    @pytest.fixture(autouse=True)
    def _restore_cache(self):
        """Always restore the original module after each test."""
        yield
        _drop_constants_cache()
        # Re-import with clean env so the module is valid again
        import foundry.constants  # noqa: F401

    def _import_with_domain(self, monkeypatch, domain: str):
        monkeypatch.setenv("SEED_SOURCE_DOMAIN", domain)
        monkeypatch.delenv("LICENSE_SERVER_URL", raising=False)
        _drop_constants_cache()
        import importlib
        return importlib.import_module("foundry.constants")

    def test_invalid_evil_dollar_com_raises(self, monkeypatch):
        """Dollar sign is illegal in a hostname — must raise ValueError."""
        with pytest.raises(ValueError, match="SEED_SOURCE_DOMAIN"):
            self._import_with_domain(monkeypatch, "evil$.com")

    def test_valid_seedsource_dev_accepted(self, monkeypatch):
        """The canonical domain must be accepted without error."""
        mod = self._import_with_domain(monkeypatch, "seedsource.dev")
        assert mod.SEED_SOURCE_DOMAIN == "seedsource.dev"

    def test_path_traversal_rejected(self, monkeypatch):
        """../etc/passwd starts with a dot — illegal hostname, must raise."""
        with pytest.raises(ValueError, match="SEED_SOURCE_DOMAIN"):
            self._import_with_domain(monkeypatch, "../etc/passwd")

    def test_default_domain_is_valid(self, monkeypatch):
        """With no env-var set the default 'seedsource.dev' must be used."""
        monkeypatch.delenv("SEED_SOURCE_DOMAIN", raising=False)
        monkeypatch.delenv("LICENSE_SERVER_URL", raising=False)
        _drop_constants_cache()
        import importlib
        mod = importlib.import_module("foundry.constants")
        assert mod.SEED_SOURCE_DOMAIN == "seedsource.dev"


# ─────────────────────────────────────────────────────────────────────────────
# M-10 — file:// URI only in dev mode
# ─────────────────────────────────────────────────────────────────────────────

class TestTemplateRegistryDevMode:
    """TEMPLATE_REGISTRY must not expose file:// URIs in production."""

    @pytest.fixture(autouse=True)
    def _restore_cache(self):
        yield
        _drop_constants_cache()
        import foundry.constants  # noqa: F401

    def test_no_file_uri_without_dev_flag(self, monkeypatch):
        """Without FOUNDRY_INTERNAL_DEV=1 no repo entry should be a file:// URI."""
        monkeypatch.delenv("FOUNDRY_INTERNAL_DEV", raising=False)
        monkeypatch.delenv("LICENSE_SERVER_URL", raising=False)
        _drop_constants_cache()
        import importlib
        mod = importlib.import_module("foundry.constants")
        for key, entry in mod.TEMPLATE_REGISTRY.items():
            repo = entry.get("repo", "")
            assert not repo.startswith("file://"), (
                f"TEMPLATE_REGISTRY[{key!r}]['repo'] leaks a file:// URI "
                f"without FOUNDRY_INTERNAL_DEV: {repo!r}"
            )

    def test_file_uri_present_with_dev_flag_and_local_git(self, monkeypatch, tmp_path):
        """With FOUNDRY_INTERNAL_DEV=1 and a local .git dir the static-landing
        entry should become a file:// URI pointing at the local path."""
        # Build a fake monorepo layout so FOUNDRY_ROOT resolves to tmp_path
        templates_dir = tmp_path / "templates" / "static-landing"
        templates_dir.mkdir(parents=True)
        (templates_dir / ".git").mkdir()
        # Also create the markers _get_foundry_root() looks for
        (tmp_path / ".github").mkdir()
        (tmp_path / "tooling").mkdir()

        monkeypatch.setenv("FOUNDRY_INTERNAL_DEV", "1")
        monkeypatch.setenv("FOUNDRY_ROOT", str(tmp_path))
        monkeypatch.delenv("LICENSE_SERVER_URL", raising=False)

        _drop_constants_cache()
        import importlib
        mod = importlib.import_module("foundry.constants")

        repo = mod.TEMPLATE_REGISTRY["static-landing"]["repo"]
        assert repo.startswith("file://"), (
            f"Expected file:// URI for static-landing in dev mode, got: {repo!r}"
        )
        assert "static-landing" in repo


# ─────────────────────────────────────────────────────────────────────────────
# C-4 — Tar-slip protection
# ─────────────────────────────────────────────────────────────────────────────

class TestTarSlipProtection:
    """Extraction must refuse members whose resolved paths escape the target dir."""

    @pytest.fixture()
    def mock_license_ok(self):
        with patch(
            "foundry.actions.repo_utils.get_current_license_info",
            return_value={"tier": "alpha", "authorized": True},
        ):
            yield

    @pytest.fixture()
    def mock_token_ok(self):
        with patch(
            "foundry.actions.repo_utils.get_access_token",
            return_value="fake_token",
        ):
            yield

    def _make_mock_response(self, tar_bytes: bytes) -> MagicMock:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = tar_bytes
        mock_resp.headers = {}   # no checksum header → skip checksum check
        mock_resp.text = ""
        return mock_resp

    def test_path_traversal_member_raises_or_is_skipped(
        self, tmp_path, mock_license_ok, mock_token_ok
    ):
        """A tar member with '../' traversal must not be extracted outside target."""
        evil_tar = _make_evil_tar_gz("../evil_escape.txt")
        target = tmp_path / "output"
        target.mkdir()

        with patch(
            "foundry.actions.repo_utils.requests.get",
            return_value=self._make_mock_response(evil_tar),
        ):
            from foundry.actions.repo_utils import download_template

            result = download_template(
                "fake-template",
                {"name": "Fake", "tier": "alpha"},
                target,
            )

        # Either the function returned False (TarError caught → safe failure)
        # OR the file was not written outside target dir (belt-and-suspenders)
        escaped_file = tmp_path / "evil_escape.txt"
        assert not escaped_file.exists(), (
            "Tar-slip: malicious member was extracted outside the target dir!"
        )
        # The function must signal failure when a malicious archive is detected
        assert result is False, (
            "download_template should return False after a tar-slip attempt"
        )

    def test_deeply_nested_traversal_blocked(
        self, tmp_path, mock_license_ok, mock_token_ok
    ):
        """../../ traversal (double-hop) must also be blocked."""
        evil_tar = _make_evil_tar_gz("../../deep_escape.txt")
        target = tmp_path / "output2"
        target.mkdir()

        with patch(
            "foundry.actions.repo_utils.requests.get",
            return_value=self._make_mock_response(evil_tar),
        ):
            from foundry.actions.repo_utils import download_template

            result = download_template(
                "fake-template",
                {"name": "Fake", "tier": "alpha"},
                target,
            )

        assert result is False
        assert not (tmp_path.parent / "deep_escape.txt").exists()


# ─────────────────────────────────────────────────────────────────────────────
# H-9 — repo_vis allowlist
# ─────────────────────────────────────────────────────────────────────────────

class TestRepoVisAllowlist:
    """initialize_github_repo() must reject any visibility not in the allowlist."""

    @staticmethod
    def _call(repo_vis: str, tmp_path: Path) -> bool:
        from foundry.actions.repo_utils import initialize_github_repo

        config = {
            "owner": "acme",
            "name": "test-repo",
            "description": "Test",
            "visibility": repo_vis,
        }
        return initialize_github_repo(tmp_path, config)

    def test_public_accepted(self, tmp_path):
        """'public' is an explicitly allowed visibility value."""
        # We only need the visibility check to pass; short-circuit the gh calls.
        gh_ok = MagicMock()
        gh_ok.returncode = 0
        gh_ok.stdout = ""
        gh_ok.stderr = ""

        with patch("foundry.actions.repo_utils.subprocess.run", return_value=gh_ok):
            result = self._call("public", tmp_path)
        # May succeed or fail at a later step, but must not be rejected by the
        # allowlist check (which returns False immediately without calling gh).
        # We confirm by checking subprocess.run WAS called (allowlist passed).
        assert result is not None  # function ran past the allowlist guard

    def test_secret_rejected(self, tmp_path):
        """'secret' is not in the allowlist and must return False immediately."""
        with patch("foundry.actions.repo_utils.subprocess.run") as mock_sub:
            result = self._call("secret", tmp_path)
        assert result is False
        mock_sub.assert_not_called()

    def test_injection_string_rejected(self, tmp_path):
        """A shell-injection payload must not reach subprocess."""
        with patch("foundry.actions.repo_utils.subprocess.run") as mock_sub:
            result = self._call("public; rm -rf /", tmp_path)
        assert result is False
        mock_sub.assert_not_called()

    def test_empty_string_rejected(self, tmp_path):
        """An empty string is not in the allowlist."""
        with patch("foundry.actions.repo_utils.subprocess.run") as mock_sub:
            result = self._call("", tmp_path)
        assert result is False
        mock_sub.assert_not_called()

    def test_private_accepted_reaches_subprocess(self, tmp_path):
        """'private' (the default) must pass the allowlist guard."""
        gh_ok = MagicMock(returncode=0, stdout="", stderr="")
        with patch(
            "foundry.actions.repo_utils.subprocess.run", return_value=gh_ok
        ) as mock_sub:
            self._call("private", tmp_path)
        mock_sub.assert_called()


# ─────────────────────────────────────────────────────────────────────────────
# M-11 — subprocess timeout enforcement
# ─────────────────────────────────────────────────────────────────────────────

class TestSubprocessTimeouts:
    """Every subprocess.run call in initialize_github_repo must pass timeout=."""

    def test_all_subprocess_calls_have_timeout(self, tmp_path):
        """Simulate a full happy-path and assert every subprocess.run call
        carries a non-None, positive timeout kwarg."""
        call_log: list[dict] = []

        def _fake_run(cmd, *args, **kwargs):
            call_log.append({"cmd": cmd, "kwargs": kwargs})
            mock = MagicMock()
            mock.returncode = 0
            mock.stdout = "ok"
            mock.stderr = ""
            return mock

        with patch("foundry.actions.repo_utils.subprocess.run", side_effect=_fake_run):
            from foundry.actions.repo_utils import initialize_github_repo

            initialize_github_repo(
                tmp_path,
                {
                    "owner": "acme",
                    "name": "myrepo",
                    "description": "desc",
                    "visibility": "private",
                },
            )

        assert call_log, "subprocess.run was never called — test is invalid"

        for entry in call_log:
            kw = entry["kwargs"]
            assert "timeout" in kw, (
                f"subprocess.run({entry['cmd']!r}) missing timeout= kwarg"
            )
            assert kw["timeout"] is not None, (
                f"subprocess.run({entry['cmd']!r}) has timeout=None"
            )
            assert kw["timeout"] > 0, (
                f"subprocess.run({entry['cmd']!r}) has non-positive timeout={kw['timeout']}"
            )
