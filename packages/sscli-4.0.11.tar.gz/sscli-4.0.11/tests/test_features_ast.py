import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from foundry.actions.features import inject_features_ast

def test_inject_react_codemods_success(tmp_path):
    # Setup mock project
    src_dir = tmp_path / "src"
    src_dir.mkdir()
    app_jsx = src_dir / "App.jsx"
    app_jsx.write_text("import React from 'react';\n\nfunction App() { return <div>Root</div>; }")
    
    features = {
        'imports': [
            {'module': 'Dashboard', 'names': ['Dashboard'], 'type': 'esm'}
        ],
        'routes': [
            {'path': '/dashboard', 'component': 'Dashboard'}
        ],
        'constants': [
            {'name': 'VERSION', 'value': "'1.0.0'"}
        ]
    }
    
    # Mock the codemods to avoid needing actual JS parsing in this unit test
    # (since JsInjectImportCodemod might depend on external tools like synvert-ruby/ast-grep)
    with patch("foundry.actions.features.JsInjectImportCodemod") as mock_import_cm, \
         patch("foundry.actions.features.JsInjectRouteCodemod") as mock_route_cm, \
         patch("foundry.actions.features.JsInjectConstantCodemod") as mock_const_cm:
        
        # Make the mock apply() method return a success object
        mock_res = MagicMock(success=True)
        mock_import_cm.return_value.apply.return_value = mock_res
        mock_route_cm.return_value.apply.return_value = mock_res
        mock_const_cm.return_value.apply.return_value = mock_res
        
        result = inject_features_ast(
            project_path=tmp_path,
            template="react-client",
            features=features
        )
        
        assert result['success'] is True
        assert len(result['changes']) >= 3
        assert mock_import_cm.called
        assert mock_route_cm.called
        assert mock_const_cm.called

def test_inject_python_saas_codemods_success(tmp_path):
    # Setup mock project
    src_dir = tmp_path / "src" / "ui"
    src_dir.mkdir(parents=True)
    app_py = src_dir / "app.py"
    app_py.write_text("from fastapi import FastAPI\napp = FastAPI()")
    
    features = {
        'imports': [
            {'module': 'commerce', 'from': 'infrastructure'}
        ]
    }
    
    # Mock python codemods
    with patch("foundry.actions.features.PythonInjectImportCodemod") as mock_import_cm:
        mock_res = MagicMock(success=True)
        mock_res.changes_made = 1
        mock_res.metadata = {}
        mock_import_cm.return_value.apply.return_value = mock_res
        
        result = inject_feature_ast_python_wrapper(tmp_path, features)
        
        assert result['success'] is True
        assert len(result['changes']) == 1
        assert mock_import_cm.called

def inject_feature_ast_python_wrapper(path, features):
    # The actual function is _inject_python_saas_codemods which is "private"
    # but inject_features_ast calls it.
    from foundry.actions.features import inject_features_ast
    return inject_features_ast(path, "python-saas", features)

def test_inject_features_ast_unknown_template(tmp_path):
    result = inject_features_ast(tmp_path, "unknown", {})
    assert result['success'] is False
    assert "Unknown template" in result['errors'][0]
