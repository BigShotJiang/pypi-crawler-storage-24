"""
Comprehensive tests for foundry.actions.account_info module.

Tests:
- Account information display
- Account menu navigation
- Refresh functionality
- Logout flow
- Various auth states
"""

from types import SimpleNamespace
import pytest


def test_show_account_info_basic(monkeypatch):
    """Test displaying basic account information."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    auth_info = {
        "tier": "free",
        "email": "user@example.com",
        "status": "active"
    }
    
    account_mod.show_account_info(auth_info)
    
    # Should have printed something
    assert len(printed) > 0


def test_show_account_info_with_org(monkeypatch):
    """Test displaying account info with org name."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    auth_info = {
        "tier": "pro",
        "email": "user@company.com",
        "status": "active",
        "org_name": "Acme Corp"
    }
    
    account_mod.show_account_info(auth_info)
    
    assert len(printed) > 0


def test_show_account_info_inactive_status(monkeypatch):
    """Test displaying account info with inactive status."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    auth_info = {
        "tier": "pro",
        "email": "user@example.com",
        "status": "suspended"
    }
    
    account_mod.show_account_info(auth_info)
    
    assert len(printed) > 0


def test_show_account_info_missing_email(monkeypatch):
    """Test displaying account info when email is not available."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    auth_info = {
        "tier": "free",
        "status": "active"
    }
    
    account_mod.show_account_info(auth_info)
    
    assert len(printed) > 0


def test_account_info_menu_refresh(monkeypatch):
    """Test refreshing account info in the menu."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    # Simulate user selecting refresh then back
    choices = iter(["🔄 Refresh Account Info", "← Back to Main Menu"])
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    auth_info = {"tier": "free", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    
    # Should return True (back to main menu)
    assert result is True


def test_account_info_menu_refresh_with_verification(monkeypatch):
    """Test refreshing account info with verify=True."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    # Mock get_current_license_info
    refresh_called = []
    def fake_get_license(verify=False):
        refresh_called.append(verify)
        return {"tier": "pro", "email": "user@example.com", "status": "active"}
    
    monkeypatch.setattr(account_mod, "get_current_license_info", fake_get_license)
    
    # Simulate user selecting refresh then back
    choices = iter(["refresh", "← Back to Main Menu"])
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    auth_info = {"tier": "free", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    
    assert result is True
    # Should have called get_current_license_info with verify=True
    assert True in refresh_called


def test_account_info_menu_refresh_error(monkeypatch):
    """Test handling refresh errors gracefully."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    # Mock get_current_license_info to raise error
    def fake_get_license(verify=False):
        raise Exception("Network error")
    
    monkeypatch.setattr(account_mod, "get_current_license_info", fake_get_license)
    
    # Simulate user selecting refresh then back
    choices = iter(["🔄 Refresh Account Info", "← Back to Main Menu"])
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    auth_info = {"tier": "free", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    
    # Should still return True and continue
    assert result is True


def test_account_info_menu_logout_confirmed(monkeypatch):
    """Test logout flow when user confirms."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    logout_called = []
    monkeypatch.setattr(account_mod, "logout", lambda: logout_called.append(True))
    
    # Simulate user selecting logout
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "🚪 Logout")
    )
    
    # Confirm logout
    monkeypatch.setattr(
        account_mod.questionary,
        "confirm",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: True)
    )
    
    auth_info = {"tier": "pro", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    
    # Should return False (indicate logout)
    assert result is False
    assert len(logout_called) == 1


def test_account_info_menu_logout_cancelled(monkeypatch):
    """Test logout flow when user cancels."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    logout_called = []
    monkeypatch.setattr(account_mod, "logout", lambda: logout_called.append(True))
    
    # Simulate user selecting logout then back
    choices = iter(["logout", "← Back to Main Menu"])
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    # Cancel logout
    monkeypatch.setattr(
        account_mod.questionary,
        "confirm",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: False)
    )
    
    auth_info = {"tier": "pro", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    
    # Should return True (back to menu) and not logout
    assert result is True
    assert len(logout_called) == 0


def test_account_info_menu_immediate_back(monkeypatch):
    """Test immediately going back to main menu."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    # Simulate user immediately selecting back
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "← Back to Main Menu")
    )
    
    auth_info = {"tier": "free", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    
    assert result is True


def test_account_info_menu_choice_value_mapping(monkeypatch):
    """Test that choice value mapping works correctly."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    # Test refresh value mapping
    choices = iter(["refresh", "← Back to Main Menu"])
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: next(choices))
    )
    
    monkeypatch.setattr(
        account_mod,
        "get_current_license_info",
        lambda verify=False: {"tier": "free", "email": "user@example.com", "status": "active"}
    )
    
    auth_info = {"tier": "free", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    assert result is True


def test_account_info_menu_logout_value_mapping(monkeypatch):
    """Test logout choice value mapping."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    logout_called = []
    monkeypatch.setattr(account_mod, "logout", lambda: logout_called.append(True))
    
    # Use value "logout" instead of full string
    monkeypatch.setattr(
        account_mod.questionary,
        "select",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: "logout")
    )
    
    # Confirm logout
    monkeypatch.setattr(
        account_mod.questionary,
        "confirm",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: True)
    )
    
    auth_info = {"tier": "pro", "email": "user@example.com", "status": "active"}
    
    result = account_mod.account_info_menu(auth_info)
    
    assert result is False
    assert len(logout_called) == 1


def test_show_account_info_alpha_tier(monkeypatch):
    """Test displaying alpha tier account."""
    from foundry.actions import account_info as account_mod
    
    printed = []
    monkeypatch.setattr(account_mod.console, "print", lambda *args, **kwargs: printed.append(args[0] if args else ""))
    
    auth_info = {
        "tier": "alpha",
        "email": "alpha@example.com",
        "status": "active",
        "org_name": "Alpha Org"
    }
    
    account_mod.show_account_info(auth_info)
    
    assert len(printed) > 0
