import subprocess

from foundry.actions import verify


def test_run_feature_matrix_tests_success(monkeypatch):
    class FakeResult:
        returncode = 0

    monkeypatch.setattr(verify.subprocess, "run", lambda *a, **k: FakeResult())
    monkeypatch.setattr(verify.console, "print", lambda *_a, **_k: None)

    assert verify.run_feature_matrix_tests() is True


def test_run_feature_matrix_tests_timeout(monkeypatch):
    def _raise_timeout(*_args, **_kwargs):
        raise subprocess.TimeoutExpired(cmd=["pytest"], timeout=600)

    monkeypatch.setattr(verify.subprocess, "run", _raise_timeout)
    monkeypatch.setattr(verify.console, "print", lambda *_a, **_k: None)

    assert verify.run_feature_matrix_tests() is False
