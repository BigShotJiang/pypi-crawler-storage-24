"""
Comprehensive tests for foundry.actions.explore module.

Tests:
- Template technology mapping
- Rich markup stripping
- Tree rendering for templates
- Template detail display
- run_explore interactive flow
- Tier-based access control
- Template categorization
- User interaction flows
"""

import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock, call
from foundry.actions import explore as explore_mod
from rich.tree import Tree
from rich.panel import Panel


class TestGetTemplateTech:
    """Test _get_template_tech function."""
    
    def test_python_saas_tech(self):
        """Test Python SaaS technology mapping."""
        tech = explore_mod._get_template_tech("python-saas")
        assert "Python" in tech
        assert "FastAPI" in tech or "SQLAlchemy" in tech
    
    def test_rails_api_tech(self):
        """Test Rails API technology mapping."""
        tech = explore_mod._get_template_tech("rails-api")
        assert "Rails" in tech
    
    def test_react_client_tech(self):
        """Test React client technology mapping."""
        tech = explore_mod._get_template_tech("react-client")
        assert "React" in tech and "Vite" in tech
    
    def test_rails_ui_kit_tech(self):
        """Test Rails UI Kit technology mapping."""
        tech = explore_mod._get_template_tech("rails-ui-kit")
        assert "Rails" in tech
    
    def test_static_landing_tech(self):
        """Test static landing technology mapping."""
        tech = explore_mod._get_template_tech("static-landing")
        assert "Astro" in tech
    
    def test_mobile_android_tech(self):
        """Test Android technology mapping."""
        tech = explore_mod._get_template_tech("mobile-android")
        assert "Android" in tech or "Kotlin" in tech
    
    def test_mobile_ios_tech(self):
        """Test iOS technology mapping."""
        tech = explore_mod._get_template_tech("mobile-ios")
        assert "iOS" in tech or "Swift" in tech
    
    def test_data_pipeline_tech(self):
        """Test data pipeline technology mapping."""
        tech = explore_mod._get_template_tech("data-pipeline")
        assert "dbt" in tech or "Data" in tech
    
    def test_terraform_infra_tech(self):
        """Test Terraform technology mapping."""
        tech = explore_mod._get_template_tech("terraform-infra")
        assert "Terraform" in tech
    
    def test_wiring_tech(self):
        """Test wiring technology mapping."""
        tech = explore_mod._get_template_tech("wiring")
        assert "Docker" in tech
    
    def test_unknown_template(self):
        """Test unknown template fallback."""
        tech = explore_mod._get_template_tech("unknown-template")
        assert "Multi-tech" in tech or tech != ""


class TestStripMarkup:
    """Test _strip_markup function."""
    
    def test_strip_bold_markup(self):
        """Test stripping bold markup."""
        text = "[bold]text[/bold]"
        result = explore_mod._strip_markup(text)
        assert result == "text"
    
    def test_strip_color_markup(self):
        """Test stripping color markup."""
        text = "[red]error[/red]"
        result = explore_mod._strip_markup(text)
        assert result == "error"
    
    def test_strip_combined_markup(self):
        """Test stripping combined markup."""
        text = "[bold yellow]warning[/bold yellow]"
        result = explore_mod._strip_markup(text)
        assert result == "warning"
    
    def test_strip_multiple_tags(self):
        """Test stripping multiple tags."""
        text = "[green]success[/green] and [red]failure[/red]"
        result = explore_mod._strip_markup(text)
        assert result == "success and failure"
    
    def test_no_markup(self):
        """Test text without markup."""
        text = "plain text"
        result = explore_mod._strip_markup(text)
        assert result == "plain text"
    
    def test_empty_string(self):
        """Test empty string."""
        result = explore_mod._strip_markup("")
        assert result == ""
    
    def test_nested_markup(self):
        """Test nested markup."""
        text = "[bold][red]error[/red][/bold]"
        result = explore_mod._strip_markup(text)
        assert result == "error"


class TestRenderTemplatesTree:
    """Test _render_templates_tree function."""
    
    @patch.object(explore_mod.console, "print")
    def test_render_empty_buckets(self, mock_print):
        """Test rendering with empty buckets."""
        buckets = {}
        explore_mod._render_templates_tree(buckets)
        
        # Should still print tree
        mock_print.assert_called_once()
    
    @patch.object(explore_mod.console, "print")
    def test_render_single_category(self, mock_print):
        """Test rendering single category."""
        buckets = {
            "Backend Templates": [
                {
                    "name": "python-saas",
                    "tier": "free",
                    "locked": False
                }
            ]
        }
        
        explore_mod._render_templates_tree(buckets)
        
        # Should print Panel with Tree
        mock_print.assert_called_once()
        panel_arg = mock_print.call_args[0][0]
        assert isinstance(panel_arg, Panel)
    
    @patch.object(explore_mod.console, "print")
    def test_render_multiple_categories(self, mock_print):
        """Test rendering multiple categories."""
        buckets = {
            "Backend Templates": [
                {"name": "python-saas", "tier": "free", "locked": False}
            ],
            "Frontend Templates": [
                {"name": "react-client", "tier": "free", "locked": False}
            ]
        }
        
        explore_mod._render_templates_tree(buckets)
        
        mock_print.assert_called_once()
    
    @patch.object(explore_mod.console, "print")
    def test_render_locked_template(self, mock_print):
        """Test rendering locked template."""
        buckets = {
            "Backend Templates": [
                {
                    "name": "python-saas",
                    "tier": "pro",
                    "locked": True
                }
            ]
        }
        
        explore_mod._render_templates_tree(buckets)
        
        # Should display lock icon or indicator
        mock_print.assert_called_once()
    
    @patch.object(explore_mod.console, "print")
    def test_render_unlocked_pro_template(self, mock_print):
        """Test rendering unlocked pro template."""
        buckets = {
            "Backend Templates": [
                {
                    "name": "python-saas",
                    "tier": "pro",
                    "locked": False
                }
            ]
        }
        
        explore_mod._render_templates_tree(buckets)
        
        # Should display checkmark or unlocked indicator
        mock_print.assert_called_once()
    
    @patch.object(explore_mod.console, "print")
    def test_render_with_tech_info(self, mock_print):
        """Test that technology info is displayed."""
        buckets = {
            "Backend Templates": [
                {"name": "python-saas", "tier": "free", "locked": False},
                {"name": "rails-api", "tier": "free", "locked": False}
            ]
        }
        
        with patch.object(explore_mod, "_get_template_tech") as mock_get_tech:
            mock_get_tech.side_effect = lambda name: f"Tech for {name}"
            
            explore_mod._render_templates_tree(buckets)
            
            # Should call _get_template_tech for each template
            assert mock_get_tech.call_count == 2


class TestShowTemplateInfo:
    """Test _show_template_info function."""
    
    @patch.object(explore_mod.console, "print")
    @patch("foundry.actions.explore.get_template_info")
    @patch("foundry.actions.explore.questionary")
    def test_show_basic_template_info(self, mock_questionary, mock_get_info, mock_print):
        """Test showing basic template info."""
        mock_get_info.return_value = {
            "tier": "free",
            "repo": "https://github.com/test/repo",
            "description": "Test description"
        }
        mock_questionary.press_any_key_to_continue.return_value.ask.return_value = None
        
        explore_mod._show_template_info("python-saas")
        
        # Should print at least once (may include examples for python-saas)
        assert mock_print.call_count >= 1
        panel_arg = mock_print.call_args_list[0][0][0]
        assert isinstance(panel_arg, Panel)
        
        # Should wait for keypress
        mock_questionary.press_any_key_to_continue.assert_called_once()
    
    @patch.object(explore_mod.console, "print")
    @patch("foundry.actions.explore.get_template_info")
    @patch("foundry.actions.explore.questionary")
    def test_show_template_info_with_all_fields(self, mock_questionary, mock_get_info, mock_print):
        """Test showing template info with all fields."""
        mock_get_info.return_value = {
            "tier": "pro",
            "repo": "https://github.com/test/repo",
            "description": "Comprehensive description"
        }
        mock_questionary.press_any_key_to_continue.return_value.ask.return_value = None
        
        explore_mod._show_template_info("python-saas")
        
        # Should print Panel at minimum (multiple calls for examples)
        assert mock_print.call_count >= 1
        # Verify first call is a Panel
        first_call_arg = mock_print.call_args_list[0][0][0]
        assert isinstance(first_call_arg, Panel)
    
    @patch.object(explore_mod.console, "print")
    @patch("foundry.actions.explore.get_template_info")
    @patch("foundry.actions.explore.questionary")
    def test_show_template_info_missing_fields(self, mock_questionary, mock_get_info, mock_print):
        """Test showing template info with missing fields."""
        mock_get_info.return_value = {
            "tier": "free"
            # Missing repo and description
        }
        mock_questionary.press_any_key_to_continue.return_value.ask.return_value = None
        
        explore_mod._show_template_info("python-saas")
        
        # Should handle missing fields gracefully (may include examples)
        assert mock_print.call_count >= 1


class TestRunExplore:
    """Test run_explore function."""
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    @patch("foundry.actions.explore._render_templates_tree")
    def test_run_explore_exit_immediately(self, mock_render, mock_questionary, mock_get_templates, mock_get_license):
        """Test exiting explore immediately."""
        mock_get_license.return_value = {"tier": "free"}
        mock_get_templates.return_value = []
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "back"
        mock_questionary.select.return_value = mock_select
        
        explore_mod.run_explore()
        
        # Should call questionary.select
        mock_questionary.select.assert_called()
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    @patch("foundry.actions.explore._render_templates_tree")
    def test_run_explore_with_free_tier(self, mock_render, mock_questionary, mock_get_templates, mock_get_license):
        """Test explore with free tier user."""
        mock_get_license.return_value = {"tier": "free"}
        mock_get_templates.return_value = [Path("python-saas"), Path("react-client")]
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "back"
        mock_questionary.select.return_value = mock_select
        
        explore_mod.run_explore()
        
        # Should get license info
        mock_get_license.assert_called_once()
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    @patch("foundry.actions.explore._render_templates_tree")
    def test_run_explore_with_pro_tier(self, mock_render, mock_questionary, mock_get_templates, mock_get_license):
        """Test explore with pro tier user."""
        mock_get_license.return_value = {"tier": "pro"}
        mock_get_templates.return_value = [Path("python-saas"), Path("rails-api")]
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "back"
        mock_questionary.select.return_value = mock_select
        
        explore_mod.run_explore()
        
        # Should handle pro tier templates
        mock_get_license.assert_called_once()
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    @patch("foundry.actions.explore._render_templates_tree")
    @patch("foundry.actions.explore._show_template_info")
    def test_run_explore_view_template_details(
        self, mock_show_info, mock_render, mock_questionary, mock_get_templates, mock_get_license
    ):
        """Test viewing template details."""
        mock_get_license.return_value = {"tier": "free"}
        mock_get_templates.return_value = [Path("python-saas")]
        
        mock_select = MagicMock()
        # Expand category, then select template, then exit
        mock_select.ask.side_effect = ["toggle:Backend Services", "tmpl:python-saas", "back"]
        mock_questionary.select.return_value = mock_select
        
        explore_mod.run_explore()
        
        # Should show template info
        mock_show_info.assert_called_once_with("python-saas", locked=True)


class TestTierBasedFiltering:
    """Test tier-based template filtering."""
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    @patch("foundry.actions.explore._render_templates_tree")
    def test_free_user_sees_locked_pro_templates(
        self, mock_render, mock_questionary, mock_get_templates, mock_get_license
    ):
        """Test that free users see pro templates as locked."""
        mock_get_license.return_value = {"tier": "free"}
        mock_get_templates.return_value = [Path("python-saas"), Path("rails-api")]
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "back"
        mock_questionary.select.return_value = mock_select
        
        explore_mod.run_explore()
        
        # Should process templates and complete successfully
        mock_get_license.assert_called_once()


class TestTemplateCategorization:
    """Test template grouping by category."""
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    @patch("foundry.actions.explore._render_templates_tree")
    def test_templates_grouped_by_category(
        self, mock_render, mock_questionary, mock_get_templates, mock_get_license
    ):
        """Test that templates are grouped by category."""
        mock_get_license.return_value = {"tier": "free"}
        mock_get_templates.return_value = [Path("python-saas"), Path("react-client")]
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "back"
        mock_questionary.select.return_value = mock_select
        
        explore_mod.run_explore()
        
        # Should render with buckets
        if mock_render.called:
            buckets = mock_render.call_args[0][0]
            # Check that buckets are organized
            assert isinstance(buckets, dict)


class TestEdgeCases:
    """Test edge cases and error scenarios."""
    
    @patch("foundry.actions.explore.get_current_license_info")
    def test_explore_with_no_license_info(self, mock_get_license):
        """Test explore when license info is unavailable."""
        mock_get_license.return_value = None
        
        # Should handle gracefully
        try:
            with patch("foundry.actions.explore.get_templates") as mock_get_templates, \
                 patch("foundry.actions.explore.questionary") as mock_questionary:
                mock_get_templates.return_value = []
                mock_select = MagicMock()
                mock_select.ask.return_value = "back"
                mock_questionary.select.return_value = mock_select
                
                explore_mod.run_explore()
        except:
            pytest.skip("License info handling not implemented")
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    def test_explore_with_empty_templates(self, mock_questionary, mock_get_templates, mock_get_license):
        """Test explore with no templates available."""
        mock_get_license.return_value = {"tier": "free"}
        mock_get_templates.return_value = []
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "back"
        mock_questionary.select.return_value = mock_select
        
        # Should handle empty templates gracefully
        explore_mod.run_explore()


class TestQuestionaryIntegration:
    """Test questionary integration."""
    
    @patch("foundry.actions.explore.get_current_license_info")
    @patch("foundry.actions.explore.get_templates")
    @patch("foundry.actions.explore.questionary")
    @patch("foundry.actions.explore._render_templates_tree")
    def test_questionary_style_applied(
        self, mock_render, mock_questionary, mock_get_templates, mock_get_license
    ):
        """Test that QUESTIONARY_STYLE is applied."""
        mock_get_license.return_value = {"tier": "free"}
        mock_get_templates.return_value = []
        
        mock_select = MagicMock()
        mock_select.ask.return_value = "back"
        mock_questionary.select.return_value = mock_select
        
        explore_mod.run_explore()
        
        # Should use QUESTIONARY_STYLE
        # (check if questionary.select was called with style parameter)


class TestModuleImports:
    """Test module imports."""
    
    def test_console_imported(self):
        """Test that console is imported."""
        assert hasattr(explore_mod, "console")
    
    def test_tier_hierarchy_imported(self):
        """Test that TIER_HIERARCHY is imported."""
        assert hasattr(explore_mod, "TIER_HIERARCHY")
    
    def test_tree_imported(self):
        """Test that Tree is imported."""
        assert hasattr(explore_mod, "Tree")
    
    def test_panel_imported(self):
        """Test that Panel is imported."""
        assert hasattr(explore_mod, "Panel")
    
    def test_questionary_imported(self):
        """Test that questionary is imported."""
        assert hasattr(explore_mod, "questionary")
