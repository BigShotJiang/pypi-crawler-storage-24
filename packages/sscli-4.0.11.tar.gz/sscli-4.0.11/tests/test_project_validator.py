"""Tests for ProjectValidator."""

import tempfile
import json
from pathlib import Path
from foundry.actions.verification.project_validator import ProjectValidator, CheckStatus
import pytest


def test_detect_template_type_python():
    """Test template detection for python-saas."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        
        # Create pyproject.toml to match python-saas
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        
        validator = ProjectValidator(project_dir)
        assert validator.template_type == "python-saas"


def test_detect_template_type_react():
    """Test template detection for react-client."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        
        # Create package.json to match react-client
        package_json = {
            "name": "my-app",
            "dependencies": {
                "react": "^18.0.0",
                "vite": "^4.0.0"
            }
        }
        (project_dir / "package.json").write_text(json.dumps(package_json))
        
        validator = ProjectValidator(project_dir)
        assert validator.template_type == "react-client"


def test_detect_template_type_rails():
    """Test template detection for rails-api."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        
        # Create Gemfile to match rails-api
        (project_dir / "Gemfile").write_text("source 'https://rubygems.org'\n")
        
        validator = ProjectValidator(project_dir)
        assert validator.template_type == "rails-api"


def test_directory_structure_check_missing_dockerfile():
    """Test that missing Dockerfile is detected as FAIL."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        
        validator = ProjectValidator(project_dir)
        validator._check_directory_structure()
        
        # Find the Dockerfile check result
        dockerfile_result = next(
            (r for r in validator.results if r.name == "Dockerfile"),
            None
        )
        assert dockerfile_result is not None
        assert dockerfile_result.status == CheckStatus.FAIL


def test_directory_structure_check_has_dockerfile():
    """Test that existing Dockerfile is detected as PASS."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        (project_dir / "Dockerfile").write_text("FROM python:3.11\n")
        
        validator = ProjectValidator(project_dir)
        validator._check_directory_structure()
        
        # Find the Dockerfile check result
        dockerfile_result = next(
            (r for r in validator.results if r.name == "Dockerfile"),
            None
        )
        assert dockerfile_result is not None
        assert dockerfile_result.status == CheckStatus.PASS


def test_environment_check_with_env_file():
    """Test that .env file is detected."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        (project_dir / ".env").write_text("DATABASE_URL=postgresql://localhost/mydb\n")
        
        validator = ProjectValidator(project_dir)
        validator._check_environment()
        
        # Find the .env check
        env_result = next(
            (r for r in validator.results if r.name == ".env file"),
            None
        )
        assert env_result is not None
        assert env_result.status == CheckStatus.PASS


def test_environment_check_missing_env_file():
    """Test detection of missing .env file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        
        validator = ProjectValidator(project_dir)
        validator._check_environment()
        
        # Find the .env check
        env_result = next(
            (r for r in validator.results if r.name == ".env file"),
            None
        )
        assert env_result is not None
        assert env_result.status == CheckStatus.SKIP


def test_environment_check_missing_vars():
    """Test detection of missing environment variables."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        (project_dir / ".env").write_text("SOME_VAR=value\n")
        
        validator = ProjectValidator(project_dir)
        validator._check_environment()
        
        # Find the required vars check
        vars_result = next(
            (r for r in validator.results if "required env" in r.name.lower()),
            None
        )
        assert vars_result is not None
        # Should warn about missing required vars
        assert vars_result.status in [CheckStatus.WARN, CheckStatus.FAIL]


def test_features_detection_no_features():
    """Test detection of project without features directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        
        validator = ProjectValidator(project_dir)
        validator._check_features()
        
        # Find the features check
        features_result = next(
            (r for r in validator.results if "Feature injection" in r.name),
            None
        )
        assert features_result is not None
        assert features_result.status == CheckStatus.SKIP


def test_features_detection_with_features():
    """Test detection of injected features."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        
        # Create features directory with some features
        features_dir = project_dir / "features"
        features_dir.mkdir()
        (features_dir / "commerce").mkdir()
        (features_dir / "auth").mkdir()
        
        validator = ProjectValidator(project_dir)
        validator._check_features()
        
        # Find the features injected result
        features_result = next(
            (r for r in validator.results if "Features injected" in r.name),
            None
        )
        assert features_result is not None
        assert features_result.status == CheckStatus.PASS
        assert "Commerce" in features_result.message
        assert "Auth" in features_result.message


def test_validate_returns_false_on_failures():
    """Test that validate_all returns False if there are failures."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_dir = Path(tmpdir)
        (project_dir / "pyproject.toml").write_text("[tool.poetry]\n")
        # Missing Dockerfile, should fail
        
        validator = ProjectValidator(project_dir)
        # Don't call validate_all, just check the results directly
        validator._check_directory_structure()
        
        has_failures = any(r.status == CheckStatus.FAIL for r in validator.results)
        assert has_failures


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
