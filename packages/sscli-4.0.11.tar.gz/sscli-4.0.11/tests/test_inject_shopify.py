"""Tests for SSA-67/SSA-68: feature registry, inject command, shopify-embedded tier gate."""
from __future__ import annotations

import os
from pathlib import Path
from unittest import mock

import pytest
from typer.testing import CliRunner

from foundry.features.registry import FEATURES, Feature, get_feature, list_features

runner = CliRunner()


# ---------------------------------------------------------------------------
# Feature Registry tests
# ---------------------------------------------------------------------------

class TestFeatureRegistry:
    def test_get_feature_returns_none_for_unknown(self):
        assert get_feature("unknown-feature") is None

    def test_shopify_embedded_in_registry(self):
        feat = get_feature("shopify-embedded")
        assert feat is not None
        assert isinstance(feat, Feature)

    def test_shopify_embedded_tier_is_pro(self):
        feat = get_feature("shopify-embedded")
        assert feat.tier == "pro"

    def test_shopify_embedded_templates_include_react_client(self):
        feat = get_feature("shopify-embedded")
        assert "react-client" in feat.templates

    def test_shopify_embedded_not_coming_soon(self):
        feat = get_feature("shopify-embedded")
        assert feat.coming_soon is False

    def test_shopify_embedded_is_stable(self):
        """Stable as of v4.0.0 rollout (Stream G)."""
        feat = get_feature("shopify-embedded")
        assert feat.stable is True

    def test_list_features_returns_all(self):
        feats = list_features()
        assert len(feats) >= 1

    def test_list_features_includes_shopify_embedded(self):
        feats = list_features()
        names = [f.name for f in feats]
        assert "shopify-embedded" in names

    def test_list_features_pro_tier_includes_shopify(self):
        feats = list_features(tier="pro")
        names = [f.name for f in feats]
        assert "shopify-embedded" in names

    def test_list_features_free_tier_excludes_shopify(self):
        feats = list_features(tier="free")
        names = [f.name for f in feats]
        assert "shopify-embedded" not in names

    def test_list_features_filter_by_template_react(self):
        feats = list_features(template="react-client")
        assert all("react-client" in f.templates for f in feats)

    def test_list_features_filter_by_template_python(self):
        feats = list_features(template="python-saas")
        names = [f.name for f in feats]
        # shopify-embedded is not for python-saas
        assert "shopify-embedded" not in names


# ---------------------------------------------------------------------------
# inject command CLI tests
# ---------------------------------------------------------------------------

class TestInjectCommandShopifyFlag:
    def test_inject_help_includes_shopify_embedded(self):
        """--with-shopify-embedded should appear in inject --help."""
        from foundry.cli import app
        result = runner.invoke(app, ["inject", "--help"])
        assert result.exit_code == 0
        assert "shopify-embedded" in result.output

    def test_inject_wrong_template_prints_warning(self, tmp_path):
        """shopify-embedded on a non-react-client template should warn."""
        # Create a fake python-saas project
        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\nname='test'")

        from foundry.actions.features import inject_features
        from io import StringIO
        from unittest.mock import patch

        # Bypass auth tier gate by mocking get_current_license_info
        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "pro"},
        ):
            # Should not raise — just print a warning
            inject_features(
                path=tmp_path,
                template="python-saas",
                commerce=False,
                tunnel=False,
                shopify_embedded=True,
            )


class TestInjectFeaturesShopifyEmbedded:
    def test_shopify_embedded_creates_provider_file(self, tmp_path):
        """AppBridgeProvider.jsx should be created in src/providers/."""
        (tmp_path / "package.json").write_text('{"name": "test"}')

        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "pro"},
        ):
            from foundry.actions.features import inject_features
            inject_features(
                path=tmp_path,
                template="react-client",
                commerce=False,
                tunnel=False,
                shopify_embedded=True,
            )

        provider = tmp_path / "src" / "providers" / "AppBridgeProvider.jsx"
        assert provider.exists(), "AppBridgeProvider.jsx should be created"
        content = provider.read_text()
        assert "AppBridgeProvider" in content
        assert "VITE_SHOPIFY_API_KEY" in content

    def test_shopify_embedded_injects_env_vars_into_env_example(self, tmp_path):
        """Shopify env vars should be appended to .env.example."""
        env_example = tmp_path / ".env.example"
        env_example.write_text("VITE_APP_NAME=test\n")
        (tmp_path / "package.json").write_text('{"name": "test"}')

        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "pro"},
        ):
            from foundry.actions.features import inject_features
            inject_features(
                path=tmp_path,
                template="react-client",
                commerce=False,
                tunnel=False,
                shopify_embedded=True,
            )

        content = env_example.read_text()
        assert "VITE_SHOPIFY_API_KEY" in content
        assert "VITE_SHOPIFY_SHOP_DOMAIN" in content

    def test_shopify_embedded_idempotent_env_vars(self, tmp_path):
        """Running injection twice should not duplicate env vars."""
        env_example = tmp_path / ".env.example"
        env_example.write_text("VITE_SHOPIFY_API_KEY=already_set\n")
        (tmp_path / "package.json").write_text('{"name": "test"}')

        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "pro"},
        ):
            from foundry.actions.features import inject_features
            inject_features(
                path=tmp_path,
                template="react-client",
                commerce=False,
                tunnel=False,
                shopify_embedded=True,
            )

        content = env_example.read_text()
        assert content.count("VITE_SHOPIFY_API_KEY") == 1, "Env var should not be duplicated"


class TestInjectTierGate:
    """SSA-70 Stream F: tier gate enforcement for shopify-embedded."""

    def test_free_tier_inject_is_denied(self, tmp_path):
        """inject_features with free tier should raise SystemExit(1) with a clear message."""
        (tmp_path / "package.json").write_text('{"name": "test"}')

        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "free"},
        ):
            from foundry.actions.features import inject_features
            with pytest.raises(SystemExit) as exc_info:
                inject_features(
                    path=tmp_path,
                    template="react-client",
                    commerce=False,
                    tunnel=False,
                    shopify_embedded=True,
                )
            assert exc_info.value.code == 1

    def test_pro_tier_inject_all_files_created(self, tmp_path):
        """inject_features with pro tier should succeed and create all expected files."""
        (tmp_path / "package.json").write_text('{"name": "test"}')
        env_example = tmp_path / ".env.example"
        env_example.write_text("VITE_APP_NAME=test\n")

        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "pro"},
        ):
            from foundry.actions.features import inject_features
            inject_features(
                path=tmp_path,
                template="react-client",
                commerce=False,
                tunnel=False,
                shopify_embedded=True,
            )

        provider = tmp_path / "src" / "providers" / "AppBridgeProvider.jsx"
        assert provider.exists(), "AppBridgeProvider.jsx must be created for pro tier"
        assert "VITE_SHOPIFY_API_KEY" in env_example.read_text(), ".env.example must contain VITE_SHOPIFY_API_KEY"

    def test_provider_file_idempotent_on_double_inject(self, tmp_path):
        """Running injection twice must not overwrite or duplicate AppBridgeProvider.jsx."""
        (tmp_path / "package.json").write_text('{"name": "test"}')

        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "pro"},
        ):
            from foundry.actions.features import inject_features
            inject_features(
                path=tmp_path, template="react-client",
                commerce=False, tunnel=False, shopify_embedded=True,
            )
            content_after_first = (tmp_path / "src" / "providers" / "AppBridgeProvider.jsx").read_text()

            inject_features(
                path=tmp_path, template="react-client",
                commerce=False, tunnel=False, shopify_embedded=True,
            )
            content_after_second = (tmp_path / "src" / "providers" / "AppBridgeProvider.jsx").read_text()

        assert content_after_first == content_after_second, "Provider file must not change on double inject"
        provider_files = list((tmp_path / "src" / "providers").glob("AppBridgeProvider*.jsx"))
        assert len(provider_files) == 1, "Only one AppBridgeProvider.jsx should exist"

    def test_inject_wrong_template_warning_message(self, tmp_path):
        """inject on a non-react-client template should emit the correct warning text."""
        from io import StringIO
        from rich.console import Console
        (tmp_path / "pyproject.toml").write_text("[tool.poetry]\nname='test'")

        output_buf = StringIO()
        patch_console = Console(file=output_buf, highlight=False)

        with mock.patch(
            "foundry.actions.features.get_current_license_info",
            return_value={"tier": "pro"},
        ), mock.patch("foundry.actions.features.console", patch_console):
            from foundry.actions.features import inject_features
            inject_features(
                path=tmp_path,
                template="python-saas",
                commerce=False,
                tunnel=False,
                shopify_embedded=True,
            )

        output = output_buf.getvalue()
        assert "shopify-embedded" in output and "only supported" in output, (
            f"Expected template-restriction warning, got: {output!r}"
        )


class TestConstantsIntegration:
    def test_shopify_embedded_in_features_registry_constants(self):
        """shopify_embedded should exist in FEATURES_REGISTRY in constants."""
        from foundry.constants import FEATURES_REGISTRY
        assert "shopify_embedded" in FEATURES_REGISTRY

    def test_shopify_embedded_tier_in_features_registry(self):
        from foundry.constants import FEATURES_REGISTRY
        feat = FEATURES_REGISTRY["shopify_embedded"]
        assert feat.get("tier") == "pro"

    def test_shopify_embedded_in_available_extensions(self):
        from foundry.constants import AVAILABLE_EXTENSIONS
        assert "shopify-embedded" in AVAILABLE_EXTENSIONS

    def test_shopify_embedded_extension_tier(self):
        from foundry.constants import AVAILABLE_EXTENSIONS
        ext = AVAILABLE_EXTENSIONS["shopify-embedded"]
        assert ext.get("tier") == "pro"
