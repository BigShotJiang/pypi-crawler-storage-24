import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
import sys
import os
import subprocess
from foundry.actions.development import (
    show_status,
    run_swap,
    mount_feature,
    is_using_local
)

@pytest.fixture
def mock_foundry_env(tmp_path):
    root = tmp_path / "monorepo"
    root.mkdir()
    (root / "tooling" / "stack-cli").mkdir(parents=True)
    (root / "tooling" / "stack-cli" / "pyproject.toml").write_text('version = "2.0.0"\nname = "sscli"')
    
    venv = root / "venv"
    venv.mkdir()
    (venv / "bin").mkdir()
    (venv / "bin" / "python").touch()
    
    with patch("foundry.actions.development.FOUNDRY_ROOT", root), \
         patch("foundry.actions.development.get_venv_path", return_value=venv), \
         patch("foundry.actions.development.get_pip_version", return_value="1.9.0"):
        yield root

def test_show_status(mock_foundry_env):
    # Mocking console and its dependencies
    with patch("foundry.actions.development.console.print") as mock_print:
        # Mocking is_using_local to return True
        with patch("foundry.actions.development.is_using_local", return_value=True):
            res = show_status(verbose=True)
            assert res is True
            assert mock_print.called

def test_run_swap_local_success(mock_foundry_env):
    stack_cli_root = mock_foundry_env / "tooling" / "stack-cli"
    dist_dir = stack_cli_root / "dist"
    dist_dir.mkdir()
    wheel = dist_dir / "sscli-2.0.0-py3-none-any.whl"
    wheel.touch()
    
    with patch("foundry.actions.development.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0)
        
        # Test swap to local
        res = run_swap(target="local")
        
        assert res is True
        assert mock_run.called
        # Check if pip install --force-reinstall was called with the wheel
        args = mock_run.call_args[0][0]
        assert "pip" in args
        assert "install" in args
        assert "--force-reinstall" in args
        assert str(wheel) in args

def test_run_swap_pip_success(mock_foundry_env):
    with patch("foundry.actions.development.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0)
        
        # Test swap to pip
        res = run_swap(target="pip")
        
        assert res is True
        assert mock_run.called
        args = mock_run.call_args[0][0]
        assert "sscli==1.9.0" in args

@patch("foundry.actions.development.is_internal_dev", return_value=True)
def test_mount_feature_success(mock_internal, mock_foundry_env, tmp_path):
    # Setup feature vault
    vault = mock_foundry_env / "features" / "python-saas" / "commerce"
    vault.mkdir(parents=True)
    (vault / "app.py").write_text("print('hello')")
    
    # Setup target project (outside vault)
    target_project = tmp_path / "target-project"
    target_project.mkdir()
    
    # Mock os.symlink
    with patch("os.symlink") as mock_symlink:
        from foundry.constants import AVAILABLE_EXTENSIONS
        # Force "commerce" to be in AVAILABLE_EXTENSIONS if it's not
        with patch.dict("foundry.constants.AVAILABLE_EXTENSIONS", {"commerce": {}}):
            res = mount_feature("commerce", "python-saas", str(target_project))
            
            assert res is True
            assert mock_symlink.called

def test_is_using_local(mock_foundry_env):
    # This function uses sys.modules and file paths. 
    # Let's just verify it runs without crashing and check the logic.
    with patch("foundry.__file__", "/some/path/foundry/__init__.py"):
        # Not in site-packages
        assert is_using_local() is True
    
    with patch("foundry.__file__", "/lib/python3.9/site-packages/foundry/__init__.py"):
        # In site-packages
        assert is_using_local() is False

@patch("foundry.actions.development.is_internal_dev", return_value=True)
def test_dev_tools_menu_exit(mock_internal, mock_foundry_env):
    with patch("questionary.select") as mock_select:
        # Mock choice "back"
        mock_select.return_value.ask.return_value = "back"
        
        from foundry.actions.development import dev_tools_menu
        dev_tools_menu()
        
        assert mock_select.called
