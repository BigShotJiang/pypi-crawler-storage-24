"""
UI Library Injection Tests — sscli --with-ui-lib flag
======================================================

Covers inject_ui_lib() for all 5 supported libraries: shadcn, chakra, mui, antd, tailwind.

Plan reference: docs/plans/054_REACT_UI_LIBRARY_SELECTION_PLAN.md
"""

import json
from pathlib import Path

import pytest

from foundry.actions.generation_utils import inject_ui_lib, VALID_UI_LIBS


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def react_project(tmp_path: Path) -> Path:
    """Minimal react-client project tree mirroring the template structure."""
    src = tmp_path / "src"
    src.mkdir()

    # main.jsx — minimal content matching the real template
    (src / "main.jsx").write_text(
        "import React from 'react'\n"
        "import ReactDOM from 'react-dom/client'\n"
        "import App from './App.jsx'\n"
        "import './index.css'\n\n"
        "ReactDOM.createRoot(document.getElementById('root')).render(\n"
        "  <React.StrictMode>\n"
        "    <App />\n"
        "  </React.StrictMode>,\n"
        ")\n",
        encoding="utf-8",
    )

    # package.json — minimal baseline (Tailwind already present)
    pkg = {
        "name": "test-react-app",
        "version": "1.0.0",
        "dependencies": {
            "react": "18.3.0",
            "react-dom": "18.3.0",
            "tailwindcss": "^3.4.0",
        },
    }
    (tmp_path / "package.json").write_text(json.dumps(pkg, indent=2), encoding="utf-8")

    return tmp_path


# ---------------------------------------------------------------------------
# Baseline / validation
# ---------------------------------------------------------------------------


def test_valid_ui_libs_constant():
    """VALID_UI_LIBS must contain exactly the 5 documented libraries."""
    assert VALID_UI_LIBS == {"shadcn", "chakra", "mui", "antd", "tailwind"}


def test_no_flag_leaves_tailwind_baseline(react_project: Path):
    """Not calling inject_ui_lib must leave package.json unchanged."""
    before = (react_project / "package.json").read_text()
    # Nothing called — assert nothing changed
    after = (react_project / "package.json").read_text()
    assert before == after


def test_invalid_lib_raises_value_error(react_project: Path):
    """An unknown library name must raise ValueError."""
    with pytest.raises(ValueError, match="Unknown UI library"):
        inject_ui_lib(react_project, "bootstrap")


def test_invalid_lib_error_message_lists_valid_options(react_project: Path):
    """ValueError must mention all valid options."""
    with pytest.raises(ValueError) as exc_info:
        inject_ui_lib(react_project, "foundation")
    msg = str(exc_info.value)
    for lib in VALID_UI_LIBS:
        assert lib in msg


def test_tailwind_is_noop(react_project: Path):
    """--with-ui-lib=tailwind must not modify any files (it's the baseline)."""
    before_pkg = (react_project / "package.json").read_text()
    before_main = (react_project / "src" / "main.jsx").read_text()
    inject_ui_lib(react_project, "tailwind")
    assert (react_project / "package.json").read_text() == before_pkg
    assert (react_project / "src" / "main.jsx").read_text() == before_main


# ---------------------------------------------------------------------------
# shadcn
# ---------------------------------------------------------------------------


def test_shadcn_adds_packages(react_project: Path):
    inject_ui_lib(react_project, "shadcn")
    deps = json.loads((react_project / "package.json").read_text())["dependencies"]
    assert "clsx" in deps
    assert "tailwind-merge" in deps
    assert "class-variance-authority" in deps
    assert "@radix-ui/react-slot" in deps


def test_shadcn_creates_components_json(react_project: Path):
    inject_ui_lib(react_project, "shadcn")
    components_json = react_project / "components.json"
    assert components_json.exists()
    data = json.loads(components_json.read_text())
    assert data.get("$schema") == "https://ui.shadcn.com/schema.json"


def test_shadcn_creates_utils_ts(react_project: Path):
    inject_ui_lib(react_project, "shadcn")
    utils_ts = react_project / "src" / "lib" / "utils.ts"
    assert utils_ts.exists()
    content = utils_ts.read_text()
    assert "cn" in content
    assert "twMerge" in content


def test_shadcn_creates_button_component(react_project: Path):
    inject_ui_lib(react_project, "shadcn")
    button = react_project / "src" / "components" / "ui" / "button.tsx"
    assert button.exists()
    content = button.read_text()
    assert "Button" in content
    assert "forwardRef" in content


def test_shadcn_idempotent(react_project: Path):
    """Running shadcn injection twice must produce the same files (no duplicates)."""
    inject_ui_lib(react_project, "shadcn")
    first_pkg = (react_project / "package.json").read_text()
    first_utils = (react_project / "src" / "lib" / "utils.ts").read_text()
    inject_ui_lib(react_project, "shadcn")
    assert (react_project / "package.json").read_text() == first_pkg
    assert (react_project / "src" / "lib" / "utils.ts").read_text() == first_utils


# ---------------------------------------------------------------------------
# chakra
# ---------------------------------------------------------------------------


def test_chakra_adds_packages(react_project: Path):
    inject_ui_lib(react_project, "chakra")
    deps = json.loads((react_project / "package.json").read_text())["dependencies"]
    assert "@chakra-ui/react" in deps
    assert "@emotion/react" in deps


def test_chakra_wraps_provider_in_main(react_project: Path):
    inject_ui_lib(react_project, "chakra")
    content = (react_project / "src" / "main.jsx").read_text()
    assert "ChakraProvider" in content


def test_chakra_provider_idempotent(react_project: Path):
    """Running chakra injection twice must not double-wrap ChakraProvider."""
    inject_ui_lib(react_project, "chakra")
    first = (react_project / "src" / "main.jsx").read_text()
    inject_ui_lib(react_project, "chakra")
    assert (react_project / "src" / "main.jsx").read_text() == first


# ---------------------------------------------------------------------------
# mui
# ---------------------------------------------------------------------------


def test_mui_adds_packages(react_project: Path):
    inject_ui_lib(react_project, "mui")
    deps = json.loads((react_project / "package.json").read_text())["dependencies"]
    assert "@mui/material" in deps
    assert "@emotion/react" in deps
    assert "@emotion/styled" in deps
    assert "@mui/icons-material" in deps


def test_mui_adds_theme_provider_in_main(react_project: Path):
    inject_ui_lib(react_project, "mui")
    content = (react_project / "src" / "main.jsx").read_text()
    assert "ThemeProvider" in content
    assert "CssBaseline" in content


def test_mui_provider_idempotent(react_project: Path):
    inject_ui_lib(react_project, "mui")
    first = (react_project / "src" / "main.jsx").read_text()
    inject_ui_lib(react_project, "mui")
    assert (react_project / "src" / "main.jsx").read_text() == first


# ---------------------------------------------------------------------------
# antd
# ---------------------------------------------------------------------------


def test_antd_adds_package(react_project: Path):
    inject_ui_lib(react_project, "antd")
    deps = json.loads((react_project / "package.json").read_text())["dependencies"]
    assert "antd" in deps


def test_antd_adds_usage_note_in_main(react_project: Path):
    inject_ui_lib(react_project, "antd")
    content = (react_project / "src" / "main.jsx").read_text()
    assert "antd" in content


def test_antd_note_idempotent(react_project: Path):
    inject_ui_lib(react_project, "antd")
    first = (react_project / "src" / "main.jsx").read_text()
    inject_ui_lib(react_project, "antd")
    assert (react_project / "src" / "main.jsx").read_text() == first


# ---------------------------------------------------------------------------
# Template guard — only applies to react-client
# ---------------------------------------------------------------------------


def test_case_insensitive_lib_name(react_project: Path):
    """Library name matching must be case-insensitive."""
    # Should not raise
    inject_ui_lib(react_project, "Shadcn")
    inject_ui_lib(react_project, "MUI")
    inject_ui_lib(react_project, "ANTD")
