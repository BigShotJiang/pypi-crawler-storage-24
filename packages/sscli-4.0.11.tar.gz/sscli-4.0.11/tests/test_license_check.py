"""Tests for foundry.license_check — verify_license and _get_token."""
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests
import typer

from foundry.license_check import _get_token, verify_license


# ---------------------------------------------------------------------------
# _get_token
# ---------------------------------------------------------------------------


class TestGetToken:
    """Unit tests for the token-retrieval helper."""

    def test_env_var_takes_precedence(self, monkeypatch, tmp_path):
        monkeypatch.setenv("SSCLI_TOKEN", "env-token-123")
        creds = tmp_path / "credentials.json"
        creds.write_text(json.dumps({"access_token": "file-token"}))
        with patch("foundry.license_check.CREDENTIALS_FILE", creds):
            assert _get_token() == "env-token-123"

    def test_reads_from_credentials_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("SSCLI_TOKEN", raising=False)
        creds = tmp_path / "credentials.json"
        creds.write_text(json.dumps({"access_token": "file-token-456"}))
        with patch("foundry.license_check.CREDENTIALS_FILE", creds):
            assert _get_token() == "file-token-456"

    def test_returns_none_when_file_missing(self, monkeypatch, tmp_path):
        monkeypatch.delenv("SSCLI_TOKEN", raising=False)
        with patch("foundry.license_check.CREDENTIALS_FILE", tmp_path / "ghost.json"):
            assert _get_token() is None

    def test_returns_none_on_corrupted_json(self, monkeypatch, tmp_path):
        monkeypatch.delenv("SSCLI_TOKEN", raising=False)
        creds = tmp_path / "credentials.json"
        creds.write_text("not-valid-json{")
        with patch("foundry.license_check.CREDENTIALS_FILE", creds):
            assert _get_token() is None

    def test_returns_none_when_access_token_key_absent(self, monkeypatch, tmp_path):
        monkeypatch.delenv("SSCLI_TOKEN", raising=False)
        creds = tmp_path / "credentials.json"
        creds.write_text(json.dumps({"tier": "alpha"}))
        with patch("foundry.license_check.CREDENTIALS_FILE", creds):
            assert _get_token() is None


# ---------------------------------------------------------------------------
# verify_license helpers
# ---------------------------------------------------------------------------


def _mock_ok_response(json_data=None):
    resp = MagicMock()
    resp.status_code = 200
    resp.ok = True
    resp.json.return_value = json_data or {"user": "testuser", "tier": "alpha", "authorized": True}
    return resp


def _mock_error_response(status_code: int):
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = False
    resp.json.return_value = {}
    return resp


# ---------------------------------------------------------------------------
# verify_license
# ---------------------------------------------------------------------------


class TestVerifyLicense:
    """Unit tests for verify_license.

    The autouse conftest fixture is skipped for this file (test_license_check
    is excluded from the verify_license mock), so these tests exercise the
    real function.
    """

    # --- happy path -------------------------------------------------------

    def test_valid_token_returns_user_dict(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "valid-token-123")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_ok_response({"user": "alice", "tier": "alpha"})),
        ):
            result = verify_license()
        assert result["tier"] == "alpha"
        assert result["user"] == "alice"

    def test_internal_dev_bypasses_server_check(self, monkeypatch):
        """is_internal_dev() == True skips the HTTP call entirely."""
        monkeypatch.delenv("SSCLI_TOKEN", raising=False)
        with (
            patch("foundry.utils.is_internal_dev", return_value=True),
            patch("requests.get") as mock_get,
        ):
            result = verify_license()
        mock_get.assert_not_called()
        assert result["authorized"] is True

    # --- no token ---------------------------------------------------------

    def test_no_token_exits_with_1(self, monkeypatch):
        monkeypatch.delenv("SSCLI_TOKEN", raising=False)
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("foundry.license_check.CREDENTIALS_FILE", Path("/nonexistent/credentials.json")),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    # --- HTTP error codes -------------------------------------------------

    def test_401_exits(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "expired-token")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_error_response(401)),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    def test_403_exits(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "valid-but-wrong-tier")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_error_response(403)),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    def test_500_exits(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "some-token")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_error_response(500)),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    # --- network errors ---------------------------------------------------

    def test_timeout_exits(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "some-token")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", side_effect=requests.exceptions.Timeout("timeout")),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    def test_connection_error_exits(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "some-token")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", side_effect=requests.exceptions.ConnectionError("no route")),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    def test_generic_request_exception_exits(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "some-token")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", side_effect=requests.exceptions.RequestException("err")),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    # --- malformed server response ----------------------------------------

    def test_invalid_json_response_exits(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "some-token")
        bad_resp = MagicMock()
        bad_resp.status_code = 200
        bad_resp.ok = True
        bad_resp.json.side_effect = ValueError("bad json")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=bad_resp),
        ):
            with pytest.raises(typer.Exit):
                verify_license()

    # --- HTTP call parameters ---------------------------------------------

    def test_uses_10s_timeout(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "tok")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_ok_response()) as mock_get,
        ):
            verify_license()
        _, kwargs = mock_get.call_args
        assert kwargs["timeout"] == 10.0

    def test_bearer_token_sent_in_header(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "mytoken")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_ok_response()) as mock_get,
        ):
            verify_license()
        _, kwargs = mock_get.call_args
        assert kwargs["headers"]["Authorization"] == "Bearer mytoken"

    def test_redirects_not_followed(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "tok")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_ok_response()) as mock_get,
        ):
            verify_license()
        _, kwargs = mock_get.call_args
        assert kwargs["allow_redirects"] is False

    def test_tls_verified(self, monkeypatch):
        monkeypatch.setenv("SSCLI_TOKEN", "tok")
        with (
            patch("foundry.utils.is_internal_dev", return_value=False),
            patch("requests.get", return_value=_mock_ok_response()) as mock_get,
        ):
            verify_license()
        _, kwargs = mock_get.call_args
        assert kwargs["verify"] is True
