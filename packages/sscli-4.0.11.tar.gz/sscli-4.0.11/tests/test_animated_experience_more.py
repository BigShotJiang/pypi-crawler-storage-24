import sys
import types

from foundry import animated_experience


def test_run_animated_experience_dispatches_choices(monkeypatch):
    calls = {
        "explore": 0,
        "generate": 0,
        "config": 0,
        "validation": 0,
        "docs": 0,
        "pause": 0,
    }
    generate_args = {}

    def _record(key):
        calls[key] += 1

    def _run_generator(**kwargs):
        generate_args.update(kwargs)
        _record("generate")

    class FakeEngine:
        def __init__(self, fps, console):
            self._returns = [
                None,
                "Explore Templates",
                "Generate Project",
                "Manage Config",
                "System Validation",
                "View Docs",
                "Exit",
            ]

        def play(self, _scene):
            return self._returns.pop(0)

    class FakeAnimationSequence:
        def __init__(self, _animations):
            self.animations = _animations

    class FakeScene:
        def __init__(self, duration=None):
            self.duration = duration

    fake_anim = types.SimpleNamespace(
        AnimationSequence=FakeAnimationSequence,
        InteractiveAnimationEngine=FakeEngine,
    )
    fake_scenes = types.SimpleNamespace(
        LogoDisperseAnimation=FakeScene,
        LogoRevealAnimation=FakeScene,
        LogoStaticAnimation=FakeScene,
        TranquilityAnimation=FakeScene,
        ForgeAnimation=FakeScene,
    )

    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)
    monkeypatch.setattr(animated_experience, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(animated_experience, "run_explore", lambda: _record("explore"))
    monkeypatch.setattr(animated_experience, "run_generator", _run_generator)
    monkeypatch.setattr(animated_experience, "manage_config_menu", lambda: _record("config"))
    monkeypatch.setattr(animated_experience, "run_smoke_tests", lambda: _record("validation"))
    monkeypatch.setattr(animated_experience, "run_view_docs", lambda **_k: _record("docs"))
    monkeypatch.setattr(animated_experience, "pause", lambda: _record("pause"))

    animated_experience.run_animated_experience()

    assert calls["explore"] == 1
    assert calls["generate"] == 1
    assert calls["config"] == 1
    assert calls["validation"] == 1
    assert calls["docs"] == 1
    assert calls["pause"] == 4
    assert generate_args.get("interactive") is True
