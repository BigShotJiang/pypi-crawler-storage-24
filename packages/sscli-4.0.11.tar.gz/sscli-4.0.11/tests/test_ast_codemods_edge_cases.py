"""
Extended edge case tests for AST codemods.

These tests cover the edge cases identified in the review checklist:
1. Missing ast-grep binary handling
2. Non-standard Python/Ruby projects  
3. Syntax errors in target files
4. Mixed injection (markers + AST)
5. Large files (>10MB)
6. Unicode in comments/strings
7. Windows path handling
8. Circular import detection
9. Timeout handling
"""

import unittest
from pathlib import Path
import tempfile
import shutil
import sys


class TestEdgeCase1_MissingBinaries(unittest.TestCase):
    """Test handling of missing ast-grep binary."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_js_fallback_when_ast_grep_missing(self):
        """Test that JS codemods fall back to string-based when ast-grep is unavailable."""
        from foundry.codemods import JsInjectImportCodemod

        test_file = self.test_dir / "app.js"
        test_file.write_text("console.log('hello');\n")

        codemod = JsInjectImportCodemod(
            "react",
            ["useState"],
            import_type="esm"
        )
        result = codemod.apply(test_file)

        # Should succeed with fallback
        self.assertTrue(result.success, f"Fallback failed: {result.error}")
        content = test_file.read_text()
        self.assertIn("react", content)

    def test_ruby_fallback_when_tools_missing(self):
        """Test that Ruby codemods fall back gracefully."""
        from foundry.codemods import RubyInjectRouteCodemod

        test_file = self.test_dir / "routes.rb"
        test_file.write_text("Rails.application.routes.draw do\nend\n")

        codemod = RubyInjectRouteCodemod(
            "get",
            "users",
            "users#index"
        )
        result = codemod.apply(test_file)

        # Should succeed with string fallback
        self.assertTrue(result.success, f"Fallback failed: {result.error}")


class TestEdgeCase2_NonStandardProjects(unittest.TestCase):
    """Test handling of non-standard Python/Ruby patterns."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_matplotlib_style_imports(self):
        """Test handling of matplotlib-style imports (import as)."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "viz.py"
        test_file.write_text("import matplotlib.pyplot as plt\n")

        codemod = PythonInjectImportCodemod("numpy")
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        self.assertIn("matplotlib", content)
        self.assertIn("numpy", content)

    def test_relative_imports(self):
        """Test handling of relative imports."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "module.py"
        test_file.write_text("from .utils import helper\n")

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        self.assertIn(".utils", content)
        self.assertIn("Flask", content)


class TestEdgeCase3_SyntaxErrors(unittest.TestCase):
    """Test handling of syntax errors in target files."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_syntax_error_detection_python(self):
        """Test that Python syntax errors are detected and handled."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "broken.py"
        test_file.write_text("def broken(\n    # Missing closing paren\n    pass\n")

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(test_file)

        self.assertFalse(result.success)
        self.assertIn("syntax", result.error.lower())

    def test_malformed_js_jsx(self):
        """Test handling of malformed JSX."""
        from foundry.codemods import JsInjectImportCodemod

        test_file = self.test_dir / "broken.jsx"
        test_file.write_text("<Component>\n  <Unclosed>\n")  # Malformed JSX

        codemod = JsInjectImportCodemod("react", ["useState"])
        result = codemod.apply(test_file)

        # Should either succeed with fallback or fail gracefully
        self.assertTrue(result.success or result.error is not None)


class TestEdgeCase4_MixedInjection(unittest.TestCase):
    """Test handling of projects with both markers and AST injection."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_idempotency_with_existing_code(self):
        """Test that AST injection is idempotent with existing code."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "app.py"
        test_file.write_text("from flask import Flask\n\ndef main():\n    pass\n")

        # Inject Flask import twice
        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result1 = codemod.apply(test_file)
        result2 = codemod.apply(test_file)

        self.assertTrue(result1.success)
        self.assertTrue(result2.success)
        
        # Second injection should report 0 changes
        self.assertEqual(result2.changes_made, 0)

        # Should still only have one Flask import
        content = test_file.read_text()
        self.assertEqual(content.count("from flask import Flask"), 1)


class TestEdgeCase5_LargeFiles(unittest.TestCase):
    """Test handling of large files."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_large_python_file(self):
        """Test handling of large Python files (1000+ lines)."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "large.py"
        
        # Create a large file
        large_content = "# Large file\n"
        for i in range(1000):
            large_content += f"def function_{i}():\n    pass\n\n"
        
        test_file.write_text(large_content)

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(test_file)

        self.assertTrue(result.success, f"Large file injection failed: {result.error}")
        content = test_file.read_text()
        self.assertIn("Flask", content)


class TestEdgeCase6_Unicode(unittest.TestCase):
    """Test unicode and emoji preservation."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_python_unicode_comments(self):
        """Test that unicode in Python comments is preserved."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "unicode.py"
        test_file.write_text(
            "# 🚀 Rocket ship\n"
            "# こんにちは (Hello in Japanese)\n"
            "# 你好 (Hello in Chinese)\n"
            "# 💻 Computer emoji\n"
            "def main():\n"
            "    print('Hello 🌍')\n"
        )

        codemod = PythonInjectImportCodemod("os")
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        
        # Verify all unicode is preserved
        self.assertIn("🚀", content)
        self.assertIn("こんにちは", content)
        self.assertIn("你好", content)
        self.assertIn("💻", content)
        self.assertIn("🌍", content)
        self.assertIn("import os", content)

    def test_javascript_unicode_strings(self):
        """Test that unicode in JS strings is preserved."""
        from foundry.codemods import JsInjectConstantCodemod

        test_file = self.test_dir / "unicode.js"
        test_file.write_text(
            "// 🎨 Color palette\n"
            "const GREETING = '¡Hola! 你好! こんにちは! 🌟';\n"
        )

        codemod = JsInjectConstantCodemod("EMOJI", "'✨'")
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        
        # Verify unicode preservation
        self.assertIn("🎨", content)
        self.assertIn("¡Hola!", content)
        self.assertIn("你好", content)
        self.assertIn("こんにちは", content)
        self.assertIn("🌟", content)


class TestEdgeCase7_WindowsPaths(unittest.TestCase):
    """Test cross-platform path handling."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_pathlib_usage(self):
        """Verify that Path objects are used consistently."""
        from foundry.codemods import PythonInjectImportCodemod

        # Use Path objects throughout
        test_file = self.test_dir / "cross_platform.py"
        test_file.write_text("def main():\n    pass\n")

        codemod = PythonInjectImportCodemod("pathlib", ["Path"])
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        self.assertIsInstance(test_file, Path)


class TestEdgeCase8_CircularImports(unittest.TestCase):
    """Test circular import detection (if implemented)."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_self_import_prevention(self):
        """Test that a module doesn't try to import itself."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "mymodule.py"
        test_file.write_text("def hello():\n    pass\n")

        # Try to inject an import of the module into itself
        # (This should ideally be prevented, but we test graceful handling)
        codemod = PythonInjectImportCodemod("mymodule", ["hello"])
        result = codemod.apply(test_file)

        # Should either prevent it or handle gracefully
        self.assertTrue(result.success or result.error is not None)


class TestEdgeCase9_Timeouts(unittest.TestCase):
    """Test timeout handling for long operations."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_reasonable_timeout(self):
        """Test that operations complete within reasonable time."""
        from foundry.codemods import PythonInjectImportCodemod
        import time

        test_file = self.test_dir / "timeout_test.py"
        
        # Create moderately large file
        content = "# Test file\n"
        for i in range(500):
            content += f"def func_{i}():\n    return {i}\n\n"
        
        test_file.write_text(content)

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        
        start = time.time()
        result = codemod.apply(test_file)
        elapsed = time.time() - start

        self.assertTrue(result.success)
        # Should complete in under 5 seconds for 500+ lines
        self.assertLess(elapsed, 5.0, f"Operation took {elapsed:.2f}s (too slow)")


class TestCodemodSafety(unittest.TestCase):
    """Test safety features of codemods."""

    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_no_data_loss(self):
        """Test that failed operations don't corrupt files."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "important.py"
        original = "# Important code\ndef critical():\n    return 42\n"
        test_file.write_text(original)

        # Force an error by injecting invalid syntax
        codemod = PythonInjectImportCodemod("", [])  # Invalid
        result = codemod.apply(test_file)

        # File should remain unchanged if operation failed
        current = test_file.read_text()
        self.assertEqual(current, original, "File was corrupted despite error")

    def test_atomic_operations(self):
        """Test that operations are atomic (all or nothing)."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "atomic.py"
        original = "def main():\n    pass\n"
        test_file.write_text(original)

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(test_file)

        # If success, file should be modified
        # If failure, file should be unchanged
        content = test_file.read_text()
        
        if result.success:
            self.assertNotEqual(content, original)
            self.assertIn("Flask", content)
        else:
            self.assertEqual(content, original)


if __name__ == "__main__":
    unittest.main()
