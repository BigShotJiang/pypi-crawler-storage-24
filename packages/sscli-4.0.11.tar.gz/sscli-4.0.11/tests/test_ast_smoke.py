import os
import shutil
import pytest
from pathlib import Path

# Paths to the actual codemods and templates for integration testing
FOUNDRY_ROOT = Path(__file__).resolve().parent.parent.parent.parent
TEMPLATE_PATH = FOUNDRY_ROOT / "templates" / "python-saas"

@pytest.fixture
def smoke_project_python(tmp_path):
    """Setup a temporary directory with some real Python files from the template."""
    app_src = TEMPLATE_PATH / "src" / "ui" / "main.py"
    if not app_src.exists():
        pytest.skip(f"python-saas template main.py not found at {app_src}")

    # Create the structure
    target_dir = tmp_path / "src" / "ui"
    target_dir.mkdir(parents=True)

    # Copy main.py
    shutil.copy2(app_src, target_dir / "main.py")

    return tmp_path

def test_python_saas_ast_injection_smoke(smoke_project_python):
    """
    Smoke test for Python AST injection.
    Ensures that real codemods work against real template files.
    """
    from foundry.actions.features import inject_features_ast

    main_py_path = smoke_project_python / "src" / "ui" / "main.py"

    # Define features to inject
    features = {
        'imports': [
            {'module': 'myapp.core.commerce', 'names': ['CommerceSDK']}
        ],
        'calls': [
            {
                'target': 'main',
                'stmt': 'print("Initializing Commerce...")'
            }
        ]
    }

    # Run the real injection
    result = inject_features_ast(
        project_path=smoke_project_python,
        template="python-saas",
        features=features
    )

    assert result['success'] is True

    new_content = main_py_path.read_text()
    assert "from myapp.core.commerce import CommerceSDK" in new_content
    # Since print(...) is injected into init_ui (fallback discovery), we verify it
    assert 'print("Initializing Commerce...")' in new_content

    # Idempotency check: Run it again
    result2 = inject_features_ast(
        project_path=smoke_project_python,
        template="python-saas",
        features=features
    )
    assert result2['success'] is True

    final_content = main_py_path.read_text()
    assert final_content.count('print("Initializing Commerce...")') == 1, "Should not inject duplicate calls"
    assert final_content.count("CommerceSDK") == 1, "Should not inject duplicate imports"

def test_js_ast_smoke_if_available(tmp_path):
    """
    Smoke test for JS AST injection using ast-grep.
    Skips if ast-grep is not installed.
    """
    from foundry.codemods.js_codemods import is_ast_grep_available
    if not is_ast_grep_available():
        pytest.skip("ast-grep not found in PATH")

    from foundry.actions.features import inject_features_ast

    src_dir = tmp_path / "src"
    src_dir.mkdir()
    app_jsx = src_dir / "App.jsx"
    app_jsx.write_text("import React from 'react';\n\nexport function App() { return <div>Root</div>; }")

    features = {
        'imports': [
            {'module': 'lucide-react', 'names': ['Activity'], 'type': 'esm'}
        ]
    }

    result = inject_features_ast(
        project_path=tmp_path,
        template="react-client",
        features=features
    )

    assert result['success'] is True
    content = app_jsx.read_text()
    assert "import { Activity } from 'lucide-react'" in content

@pytest.mark.parametrize("invalid_code", [
    "def unfinished(",
    "import (",
    "x = [1, 2,"
])
def test_python_syntax_validation_smoke(tmp_path, invalid_code):
    """Ensures that invalid Python code is caught by our new validate_syntax."""
    from foundry.codemods.python_codemods import InjectImportCodemod

    buggy_path = tmp_path / "buggy.py"
    buggy_path.write_text(invalid_code)

    cm = InjectImportCodemod("os")
    result = cm.apply(buggy_path)

    assert result.success is False
    assert "syntax error" in result.error.lower()
