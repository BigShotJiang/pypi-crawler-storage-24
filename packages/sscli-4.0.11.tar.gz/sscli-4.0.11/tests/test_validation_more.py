import types

from foundry.actions import validation as validation_mod


def test_run_script_python_success(tmp_path, monkeypatch):
    monkeypatch.setattr(validation_mod, "TEMPLATES_DIR", tmp_path)
    script = tmp_path / "scripts" / "verify_templates.py"
    script.parent.mkdir(parents=True)
    script.write_text("print('ok')")

    class FakeProcess:
        def __init__(self):
            self.stdout = ["line1\n", "line2\n"]
            self.returncode = 0
        def wait(self):
            return 0

    monkeypatch.setattr(validation_mod.subprocess, "Popen", lambda *a, **k: FakeProcess())
    monkeypatch.setattr(validation_mod.console, "print", lambda *a, **k: None)

    validation_mod._run_script("scripts/verify_templates.py", "Build Verification")


def test_run_script_powershell(tmp_path, monkeypatch):
    monkeypatch.setattr(validation_mod, "TEMPLATES_DIR", tmp_path)
    script = tmp_path / "scripts" / "verify.ps1"
    script.parent.mkdir(parents=True)
    script.write_text("Write-Host ok")

    class FakeProcess:
        def __init__(self):
            self.stdout = []
            self.returncode = 1
        def wait(self):
            return 1

    monkeypatch.setattr(validation_mod.subprocess, "Popen", lambda *a, **k: FakeProcess())
    monkeypatch.setattr(validation_mod.console, "print", lambda *a, **k: None)

    validation_mod._run_script("scripts/verify.ps1", "PS")


def test_run_script_other_extension(tmp_path, monkeypatch):
    monkeypatch.setattr(validation_mod, "TEMPLATES_DIR", tmp_path)
    script = tmp_path / "scripts" / "verify.sh"
    script.parent.mkdir(parents=True)
    script.write_text("echo ok")

    class FakeProcess:
        def __init__(self):
            self.stdout = []
            self.returncode = 0
        def wait(self):
            return 0

    monkeypatch.setattr(validation_mod.subprocess, "Popen", lambda *a, **k: FakeProcess())
    monkeypatch.setattr(validation_mod.console, "print", lambda *a, **k: None)

    validation_mod._run_script("scripts/verify.sh", "SH")
