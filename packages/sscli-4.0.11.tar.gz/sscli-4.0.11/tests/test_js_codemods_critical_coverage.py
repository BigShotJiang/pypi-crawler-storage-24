"""
CRITICAL: JS Codemods Coverage Push to 95%

Targets 17 uncovered lines in foundry/codemods/js_codemods.py:
- Lines 52-64, 77: Exception handling in apply() and ast-grep checks
- Line 140: File write errors
- Lines 213-216: Import injection parsing errors
- Lines 243-244: Call injection exceptions
- Lines 360-361, 443-444, 511-512: Route/constant injection error paths

Goal: Cover at least 15 of 17 lines to push total project over 95%.
"""

import subprocess
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch, mock_open
import pytest
import tempfile

from foundry.codemods.base import ModificationResult
from foundry.codemods.js_codemods import (
    JsCodemod,
    InjectImportCodemod,
    InjectRouteCodemod,
    InjectCallCodemod,
    InjectConstantCodemod,
    is_ast_grep_available,
    _resolve_ast_grep_path,
)


# ============================================================
# Line 77: Exception handling in JsCodemod.apply()
# ============================================================

def test_js_codemod_apply_unexpected_exception():
    """Cover line 77: Exception handling in apply() when get_rule() raises unexpectedly."""
    
    class FailingCodemod(JsCodemod):
        def get_rule(self):
            raise RuntimeError("Unexpected rule generation error")
        
        def _apply_string_based(self, path):
            return ModificationResult(success=False, error="Not called")
    
    codemod = FailingCodemod()
    
    # Create a real temp file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("console.log('test');")
        temp_path = Path(f.name)
    
    try:
        # Mock is_ast_grep_available to return True so get_rule() is called
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=True):
            result = codemod.apply(temp_path)
            
            # Should catch the exception and return failure
            assert result.success is False
            assert "FailingCodemod" in result.error
            assert "Unexpected rule generation error" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_js_codemod_apply_exception_during_ast_grep():
    """Cover exception handling when ast-grep processing fails unexpectedly."""
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    # Create a real temp file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        # Mock ast-grep available but _apply_ast_grep raises exception
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=True):
            with patch.object(codemod, '_apply_ast_grep') as mock_ast_grep:
                mock_ast_grep.side_effect = ValueError("AST parsing failed")
                
                result = codemod.apply(temp_path)
                
                # Should catch exception
                assert result.success is False
                assert "InjectImportCodemod" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


# ============================================================
# Lines 52-64: ast-grep binary check and fallback logic
# ============================================================

def test_is_ast_grep_not_available():
    """Cover lines checking when ast-grep binary is not available."""
    
    with patch('shutil.which', return_value=None):
        # Clear both caches to force re-evaluation
        _resolve_ast_grep_path.cache_clear()
        is_ast_grep_available.cache_clear()
        
        result = is_ast_grep_available()
        assert result is False
        
        # Reset caches
        is_ast_grep_available.cache_clear()
        _resolve_ast_grep_path.cache_clear()


def test_js_codemod_fallback_when_no_ast_grep_and_no_string_implementation():
    """Cover fallback path when ast-grep unavailable and no string-based impl."""
    
    class MinimalCodemod(JsCodemod):
        def get_rule(self):
            return {"rule": "test", "replace": "test"}
    
    codemod = MinimalCodemod()
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            result = codemod.apply(temp_path)
            
            # Should use _apply_string_based which returns error by default
            assert result.success is False
            assert "ast-grep not available and no fallback implemented" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


# ============================================================
# Line 140: File write error in _apply_ast_grep
# ============================================================

def test_inject_import_file_write_permission_error():
    """Cover line 140: File write permission errors during import injection."""
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Mock path.write_text to raise PermissionError
            with patch.object(Path, 'write_text', side_effect=PermissionError("Permission denied")):
                result = codemod.apply(temp_path)
                
                # Should catch PermissionError
                assert result.success is False
                assert "Permission denied" in result.error or "String-based injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


# ============================================================
# Lines 213-216: Import injection parsing errors
# ============================================================

def test_inject_import_with_read_error():
    """Cover lines 213-216: Exception when reading file for import injection."""
    
    codemod = InjectImportCodemod(module="lodash", names=["map", "filter"])
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("import React from 'react';")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Mock read_text to raise exception
            with patch.object(Path, 'read_text', side_effect=UnicodeDecodeError('utf-8', b'', 0, 1, 'invalid')):
                result = codemod.apply(temp_path)
                
                # Should catch exception
                assert result.success is False
                assert "String-based injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_import_general_exception():
    """Cover import injection exception handling for unexpected errors."""
    
    codemod = InjectImportCodemod(module="axios", names=["axios"], import_type="esm")
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.ts', delete=False) as f:
        f.write("// TypeScript file")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Mock write_text to raise IOError
            with patch.object(Path, 'write_text', side_effect=IOError("Disk full")):
                result = codemod.apply(temp_path)
                
                assert result.success is False
                assert "String-based injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


# ============================================================
# Lines 360-361: Route injection error handling
# ============================================================

def test_inject_route_cannot_find_insertion_point():
    """Cover lines 360-361: Route injection when insertion point not found."""
    
    codemod = InjectRouteCodemod(
        path_pattern="/dashboard",
        component="Dashboard",
        framework="react"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.jsx', delete=False) as f:
        # File without <Routes> tag
        f.write("function App() { return <div>No routes here</div>; }")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            result = codemod.apply(temp_path)
            
            # Should fail to find insertion point
            assert result.success is False
            assert "Could not find route insertion point" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_route_astro_no_routes_array():
    """Cover route injection error for Astro when no routes array found."""
    
    codemod = InjectRouteCodemod(
        path_pattern="/about",
        component="About",
        framework="astro"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.astro', delete=False) as f:
        # File without routes array
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            result = codemod.apply(temp_path)
            
            assert result.success is False
            assert "Could not find route insertion point" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_route_exception_during_write():
    """Cover lines 360-361: Exception during route file write."""
    
    codemod = InjectRouteCodemod(
        path_pattern="/users",
        component="Users",
        framework="react"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.jsx', delete=False) as f:
        f.write("<Routes>\n  <Route path='/' element={<Home />} />\n</Routes>")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # First read succeeds, then write fails
            original_write = Path.write_text
            call_count = {'count': 0}
            
            def write_with_error(self, content, **kwargs):
                call_count['count'] += 1
                if call_count['count'] == 1:
                    raise OSError("Write failed")
                return original_write(self, content, **kwargs)
            
            with patch.object(Path, 'write_text', write_with_error):
                result = codemod.apply(temp_path)
                
                assert result.success is False
                assert "String-based route injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


# ============================================================
# Lines 443-444: Call injection exception handling
# ============================================================

def test_inject_call_read_exception():
    """Cover lines 443-444: Exception when reading file for call injection."""
    
    codemod = InjectCallCodemod(
        call_statement="app.use(cors())",
        target_function="main"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("function main() { console.log('app'); }")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Mock read_text to raise exception
            with patch.object(Path, 'read_text', side_effect=OSError("Read failed")):
                result = codemod.apply(temp_path)
                
                assert result.success is False
                assert "String-based call injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_call_write_exception():
    """Cover call injection write errors."""
    
    codemod = InjectCallCodemod(
        call_statement="console.log('initialized')",
        target_function=None  # Inject at end
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const app = {};\n")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Mock write_text to fail
            with patch.object(Path, 'write_text', side_effect=PermissionError("Cannot write")):
                result = codemod.apply(temp_path)
                
                assert result.success is False
                assert "String-based call injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


# ============================================================
# Lines 511-512: Constant injection exception handling
# ============================================================

def test_inject_constant_read_exception():
    """Cover lines 511-512: Exception when reading file for constant injection."""
    
    codemod = InjectConstantCodemod(
        name="API_URL",
        value="'https://api.example.com'"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("import React from 'react';\n")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Mock read_text to raise exception
            with patch.object(Path, 'read_text', side_effect=IOError("File locked")):
                result = codemod.apply(temp_path)
                
                assert result.success is False
                assert "String-based constant injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_constant_write_exception():
    """Cover constant injection write errors."""
    
    codemod = InjectConstantCodemod(
        name="MAX_RETRIES",
        value="3"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.ts', delete=False) as f:
        f.write("const PORT = 3000;\n")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Mock write_text to fail
            with patch.object(Path, 'write_text', side_effect=OSError("Disk error")):
                result = codemod.apply(temp_path)
                
                assert result.success is False
                assert "String-based constant injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_constant_general_exception():
    """Cover general exception handling in constant injection."""
    
    codemod = InjectConstantCodemod(
        name="CONFIG",
        value="{ timeout: 5000 }"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("// Config file\n")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # Simulate unexpected exception in string processing
            with patch.object(Path, 'read_text', side_effect=MemoryError("Out of memory")):
                result = codemod.apply(temp_path)
                
                assert result.success is False
                assert "String-based constant injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


# ============================================================
# Additional edge cases for maximum coverage
# ============================================================

def test_js_codemod_get_rule_returns_none():
    """Cover line 61: When get_rule() returns None, should use string-based fallback."""
    
    class NullRuleCodemod(JsCodemod):
        def get_rule(self):
            return None  # No rule available
        
        def _apply_string_based(self, path):
            # String-based implementation
            content = path.read_text()
            path.write_text(content + "\n// Added by fallback\n")
            return ModificationResult(success=True, modified_path=path, changes_made=1)
    
    codemod = NullRuleCodemod()
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=True):
            result = codemod.apply(temp_path)
            
            # Should fall back to string-based when rule is None
            assert result.success is True
            assert "Added by fallback" in temp_path.read_text()
    finally:
        temp_path.unlink(missing_ok=True)


def test_js_codemod_ast_grep_returns_failure():
    """Cover line 77: When ast-grep result is not successful, return that result."""
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=True):
            # Mock _apply_ast_grep to return a failure result (not success=True)
            fail_result = ModificationResult(success=False, error="ast-grep transformation failed")
            with patch.object(codemod, '_apply_ast_grep', return_value=fail_result):
                result = codemod.apply(temp_path)
                
                # Should return the failure result from ast-grep
                assert result.success is False
                assert "ast-grep transformation failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_import_esm_no_names_wildcard():
    """Cover line 213: ESM import with no specific names (wildcard import)."""
    
    codemod = InjectImportCodemod(module="lodash", names=[], import_type="esm")
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            result = codemod.apply(temp_path)
            
            # Should succeed with wildcard import
            assert result.success is True
            content = temp_path.read_text()
            assert "import * from 'lodash';" in content
    finally:
        temp_path.unlink(missing_ok=True)


def test_js_codemod_ast_grep_available_and_called():
    """Cover line 56: When ast-grep is available, call _apply_ast_grep."""
    
    codemod = InjectImportCodemod(module="axios", names=["get", "post"])
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=True):
            # Create a mock that returns success to trigger line 56-58 path
            success_result = ModificationResult(success=True, modified_path=temp_path, changes_made=1)
            with patch.object(codemod, '_apply_ast_grep', return_value=success_result) as mock_ast:
                result = codemod.apply(temp_path)
                
                # Should have called _apply_ast_grep
                mock_ast.assert_called_once()
                assert result.success is True
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_import_with_encoding_error():
    """Cover import injection with specific encoding errors."""
    
    codemod = InjectImportCodemod(module="fs", names=["readFile"], import_type="commonjs")
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("const x = 1;")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            # First read for duplicate check, then split fails
            with patch.object(Path, 'read_text', side_effect=[
                "const x = 1;",  # First read succeeds
                Exception("Encoding error")  # Second read fails
            ]):
                result = codemod.apply(temp_path)
                
                # May succeed on first read or fail on second
                # Either way, we're covering error paths
                if not result.success:
                    assert "String-based injection failed" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_route_with_malformed_content():
    """Cover route injection with malformed file content."""
    
    codemod = InjectRouteCodemod(
        path_pattern="/profile",
        component="Profile",
        framework="react"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.jsx', delete=False) as f:
        # Malformed: has <Routes> but in wrong place
        f.write("<Routes>\n  <!-- malformed -->\n")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            result = codemod.apply(temp_path)
            
            # rfind('</Routes>') returns -1, so should fail
            assert result.success is False
            assert "Could not find route insertion point" in result.error
    finally:
        temp_path.unlink(missing_ok=True)


def test_inject_call_with_target_function_not_found():
    """Cover call injection when target function not found but no exception raised."""
    
    codemod = InjectCallCodemod(
        call_statement="logger.info('start')",
        target_function="initialize"
    )
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        # File without the target function
        f.write("const x = 1;\nfunction other() {}\n")
        temp_path = Path(f.name)
    
    try:
        with patch('foundry.codemods.js_codemods.is_ast_grep_available', return_value=False):
            result = codemod.apply(temp_path)
            
            # Should inject at end when target not found
            assert result.success is True
            content = temp_path.read_text()
            assert "logger.info('start')" in content
    finally:
        temp_path.unlink(missing_ok=True)
