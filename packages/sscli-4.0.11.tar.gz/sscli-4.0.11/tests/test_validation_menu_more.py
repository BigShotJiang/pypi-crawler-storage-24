import questionary

from foundry.actions import validation


def test_run_smoke_tests_smoke_path(monkeypatch):
    selections = iter(["smoke", "Back"])

    class DummySelect:
        def ask(self):
            return next(selections)

    calls = {"run": 0, "pause": 0}

    monkeypatch.setattr(questionary, "select", lambda *a, **k: DummySelect())
    monkeypatch.setattr(validation, "_run_script", lambda *_a, **_k: calls.__setitem__("run", calls["run"] + 1))
    monkeypatch.setattr(validation, "_pause", lambda: calls.__setitem__("pause", calls["pause"] + 1))

    validation.run_smoke_tests()

    assert calls["run"] == 1
    assert calls["pause"] == 1


def test_run_smoke_tests_all_clears_report(tmp_path, monkeypatch):
    report_path = tmp_path / "verification_results.csv"
    report_path.write_text("old", encoding="utf-8")

    selections = iter(["all", "Back"])

    class DummySelect:
        def ask(self):
            return next(selections)

    calls = {"run": 0, "pause": 0}

    monkeypatch.setattr(validation, "TEMPLATES_DIR", tmp_path)
    monkeypatch.setattr(questionary, "select", lambda *a, **k: DummySelect())
    monkeypatch.setattr(validation, "_run_script", lambda *_a, **_k: calls.__setitem__("run", calls["run"] + 1))
    monkeypatch.setattr(validation, "_pause", lambda: calls.__setitem__("pause", calls["pause"] + 1))

    validation.run_smoke_tests()

    assert calls["run"] == 3
    assert calls["pause"] == 1
    assert not report_path.exists()
