"""
Comprehensive coverage tests for upgrade.py to achieve 90%+ coverage.

This file specifically targets uncovered lines:
- Error handling paths (JSON parse, version detection, git errors)
- User interaction paths (cancellation, interactive mode)
- Rollback scenarios
- Edge cases in template detection
"""

import pytest
import tempfile
import json
import shutil
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch, call

from foundry.actions.upgrade import (
    UpgradeCommand,
    MetadataTracker,
    ProjectMetadata,
    UpgradeHistory,
    UpgradeStep,
    run_upgrade,
)
from foundry.codemods.delta_store import CodemodMetadata, CodemodDefinition
from foundry.safety import GitStatusError


class TestMetadataTrackerErrorHandling:
    """Test error handling in MetadataTracker."""

    def test_load_invalid_json(self):
        """Test loading metadata with invalid JSON (lines 105-107)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            tracker = MetadataTracker(project_path)
            
            # Write invalid JSON
            tracker.metadata_file.write_text("{invalid json")
            
            # Should raise ValueError
            with pytest.raises(ValueError, match="Invalid metadata file"):
                tracker.load()

    def test_infer_metadata_no_version(self):
        """Test _infer_metadata when version cannot be detected (lines 120-125)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            tracker = MetadataTracker(project_path)
            
            # Create project without version info
            (project_path / "pyproject.toml").write_text("[tool.poetry]\n")
            
            # Should raise ValueError
            with pytest.raises(ValueError, match="Cannot detect project version"):
                tracker._infer_metadata()

    def test_detect_template_react_vite_in_package_json(self):
        """Test detecting react-client with vite in package.json (lines 149-150)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create react-client structure with vite in package.json
            (project_path / "package.json").write_text('{"name": "app", "devDependencies": {"vite": "^4.0.0"}}')
            (project_path / "src" / "components").mkdir(parents=True)
            
            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()
            
            assert template == "react-client"

    def test_detect_template_astro(self):
        """Test detecting static-landing template with astro (line 153)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create astro project
            (project_path / "package.json").write_text('{"name": "app", "dependencies": {"astro": "^2.0.0"}}')
            
            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()
            
            assert template == "static-landing"

    def test_detect_version_pyproject_error_handling(self):
        """Test _detect_version error handling for pyproject.toml (lines 168-169)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create pyproject.toml with no version
            (project_path / "pyproject.toml").write_text("[tool.poetry]\n")
            
            tracker = MetadataTracker(project_path)
            version = tracker._detect_version()
            
            # Should return None when version not found
            assert version is None

    def test_detect_version_package_json_error_handling(self):
        """Test _detect_version error handling for package.json (lines 178-181)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create invalid package.json
            (project_path / "package.json").write_text("{invalid json}")
            
            tracker = MetadataTracker(project_path)
            version = tracker._detect_version()
            
            # Should return None on exception
            assert version is None


class TestUpgradeCommandGitErrors:
    """Test git-related error handling in UpgradeCommand."""

    def test_plan_upgrade_git_status_error(self):
        """Test plan_upgrade with GitStatusError (lines 258-262)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            # Mock git_guard to raise GitStatusError
            with patch.object(cmd.git_guard, "require_clean_status") as mock_require:
                mock_require.side_effect = GitStatusError("Uncommitted changes")
                
                # Should raise GitStatusError
                with pytest.raises(GitStatusError, match="Uncommitted changes"):
                    cmd.plan_upgrade(force=False)

    def test_plan_upgrade_no_latest_version(self):
        """Test plan_upgrade when latest version cannot be determined (lines 275, 286-287)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create metadata
            (project_path / "pyproject.toml").write_text('version = "1.0.0"\n')
            (project_path / "src" / "core").mkdir(parents=True)
            
            cmd = UpgradeCommand(project_path)
            
            with patch.object(cmd, "_get_latest_version", return_value=None):
                with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                    metadata = ProjectMetadata(
                        current_version="1.0.0",
                        template_type="python-saas",
                        created_at="2025-01-01",
                    )
                    mock_load.return_value = metadata
                    
                    # Should raise ValueError
                    with pytest.raises(ValueError, match="Could not determine latest version"):
                        cmd.plan_upgrade(force=True)

    def test_plan_upgrade_invalid_codemod_path(self):
        """Test plan_upgrade with invalid codemod retrieval (line 286-287)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                metadata = ProjectMetadata(
                    current_version="1.0.0",
                    template_type="python-saas",
                    created_at="2025-01-01",
                )
                mock_load.return_value = metadata
                
                with patch.object(cmd.delta_store, "get_codemods_for_template") as mock_get:
                    mock_get.side_effect = ValueError("Invalid version range")
                    
                    # Should raise ValueError with message
                    with pytest.raises(ValueError, match="Cannot plan upgrade"):
                        cmd.plan_upgrade(to_version="99.9.9", force=True)


class TestUpgradeCommandUserInteraction:
    """Test user interaction paths in execute_upgrade."""

    def test_execute_upgrade_user_cancels(self):
        """Test execute_upgrade when user cancels (lines 338-339, 355-358)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            # Setup valid plan
            step = UpgradeStep(
                index=1,
                codemod_id="001",
                codemod_name="Test",
                from_version="1.0.0",
                to_version="1.1.0",
                description="Test upgrade",
                risk_level="low",
            )
            
            with patch.object(cmd, "plan_upgrade", return_value=([step], "1.1.0")):
                with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                    metadata = ProjectMetadata(
                        current_version="1.0.0",
                        template_type="python-saas",
                        created_at="2025-01-01",
                    )
                    mock_load.return_value = metadata
                    
                    with patch.object(cmd, "_create_backup", return_value=Path(tmpdir) / "backup"):
                        # User types "no" to cancel
                        with patch("foundry.constants.console.input", return_value="no"):
                            result = cmd.execute_upgrade(force=False)
            
            assert result is False

    def test_execute_upgrade_verification_fails(self):
        """Test execute_upgrade when verification fails (lines 390-404, 408)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            step = UpgradeStep(
                index=1,
                codemod_id="001",
                codemod_name="Test",
                from_version="1.0.0",
                to_version="1.1.0",
                description="Test",
                risk_level="low",
            )
            
            with patch.object(cmd, "plan_upgrade", return_value=([step], "1.1.0")):
                with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                    metadata = ProjectMetadata(
                        current_version="1.0.0",
                        template_type="python-saas",
                        created_at="2025-01-01",
                    )
                    mock_load.return_value = metadata
                    
                    backup_path = Path(tmpdir) / "backup"
                    backup_path.mkdir()
                    
                    with patch.object(cmd, "_create_backup", return_value=backup_path):
                        with patch.object(cmd, "_apply_codemod", return_value=True):
                            # Mock verification to fail
                            with patch("foundry.actions.upgrade.VerificationHook") as mock_hook:
                                mock_verifier = Mock()
                                mock_verifier.run_verification.return_value = False
                                mock_hook.return_value = mock_verifier
                                
                                with patch.object(cmd, "_rollback_to_backup") as mock_rollback:
                                    with patch("foundry.actions.upgrade.MetadataTracker.save"):
                                        result = cmd.execute_upgrade(
                                            force=True,
                                            skip_verification=False,
                                        )
                    
                    assert result is False
                    mock_rollback.assert_called_once()

    def test_execute_upgrade_general_exception(self):
        """Test execute_upgrade with general exception (lines 426-430)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            with patch.object(cmd, "plan_upgrade", side_effect=RuntimeError("Unexpected error")):
                result = cmd.execute_upgrade(force=True)
            
            assert result is False


class TestUpgradeCommandEdgeCases:
    """Test edge cases in upgrade command methods."""

    def test_get_upgrade_steps_value_error(self):
        """Test get_upgrade_steps with ValueError (lines 455-456)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                metadata = ProjectMetadata(
                    current_version="1.0.0",
                    template_type="python-saas",
                    created_at="2025-01-01",
                )
                mock_load.return_value = metadata
                
                with patch.object(cmd.delta_store, "get_codemods_for_template") as mock_get:
                    mock_get.side_effect = ValueError("Invalid version")
                    
                    steps = cmd.get_upgrade_steps("1.0.0", "99.9.9")
            
            # Should return empty list on error
            assert steps == []

    def test_preview_upgrade_with_steps(self):
        """Test preview_upgrade with valid steps (lines 490-509)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            step = UpgradeStep(
                index=1,
                codemod_id="001",
                codemod_name="Test Upgrade",
                from_version="1.0.0",
                to_version="1.1.0",
                description="Test",
                risk_level="medium",
            )
            
            with patch.object(cmd, "plan_upgrade", return_value=([step], "1.1.0")):
                result = cmd.preview_upgrade(to_version="1.1.0", force=True)
            
            # Should return DryRunResult
            assert result is not None

    def test_preview_upgrade_no_steps(self):
        """Test preview_upgrade when no steps needed."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            with patch.object(cmd, "plan_upgrade", return_value=([], "1.0.0")):
                result = cmd.preview_upgrade(force=True)
            
            # Should return None
            assert result is None

    def test_preview_upgrade_exception(self):
        """Test preview_upgrade with exception (line 509)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            with patch.object(cmd, "plan_upgrade", side_effect=Exception("Test error")):
                result = cmd.preview_upgrade(force=True)
            
            # Should return None on error
            assert result is None


class TestRollbackUpgrade:
    """Test rollback_upgrade functionality (lines 521-574)."""

    def test_rollback_upgrade_no_history(self):
        """Test rollback when no upgrade history exists (lines 521-533)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create metadata with no history
            metadata = ProjectMetadata(
                current_version="1.0.0",
                template_type="python-saas",
                created_at="2025-01-01",
                upgrade_history=[],
            )
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load", return_value=metadata):
                result = cmd.rollback_upgrade()
            
            assert result is False

    def test_rollback_upgrade_no_backup_path(self):
        """Test rollback when backup_path is None (lines 535-537)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create metadata with history but no backup
            history = UpgradeHistory(
                timestamp="2025-01-01T12:00:00",
                from_version="1.0.0",
                to_version="1.1.0",
                steps_applied=1,
                steps_successful=1,
                status="success",
                backup_path=None,
            )
            metadata = ProjectMetadata(
                current_version="1.1.0",
                template_type="python-saas",
                created_at="2025-01-01",
                upgrade_history=[history],
            )
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load", return_value=metadata):
                result = cmd.rollback_upgrade()
            
            assert result is False

    def test_rollback_upgrade_backup_not_exists(self):
        """Test rollback when backup path doesn't exist (lines 545-547)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            backup_path = Path(tmpdir) / "nonexistent_backup"
            
            # Create metadata with non-existent backup
            history = UpgradeHistory(
                timestamp="2025-01-01T12:00:00",
                from_version="1.0.0",
                to_version="1.1.0",
                steps_applied=1,
                steps_successful=1,
                status="success",
                backup_path=str(backup_path),
            )
            metadata = ProjectMetadata(
                current_version="1.1.0",
                template_type="python-saas",
                created_at="2025-01-01",
                upgrade_history=[history],
            )
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load", return_value=metadata):
                result = cmd.rollback_upgrade()
            
            assert result is False

    def test_rollback_upgrade_success(self):
        """Test successful rollback (lines 549-574)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a separate directory for project
            project_path = Path(tmpdir) / "project"
            project_path.mkdir()
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            # Create backup files
            (backup_path / "test.txt").write_text("backup content")
            backup_dir = backup_path / "subdir"
            backup_dir.mkdir()
            (backup_dir / "nested.txt").write_text("nested content")
            
            # Create current project files
            (project_path / "current.txt").write_text("current content")
            
            # Create metadata with backup
            history = UpgradeHistory(
                timestamp="2025-01-01T12:00:00",
                from_version="1.0.0",
                to_version="1.1.0",
                steps_applied=1,
                steps_successful=1,
                status="success",
                backup_path=str(backup_path),
            )
            metadata = ProjectMetadata(
                current_version="1.1.0",
                template_type="python-saas",
                created_at="2025-01-01",
                upgrade_history=[history],
            )
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load", return_value=metadata):
                with patch("foundry.actions.upgrade.MetadataTracker.save"):
                    result = cmd.rollback_upgrade()
            
            assert result is True
            # Verify files were restored
            assert (project_path / "test.txt").exists()
            assert (project_path / "subdir" / "nested.txt").exists()
            # Current file should be removed
            assert not (project_path / "current.txt").exists()

    def test_rollback_upgrade_exception(self):
        """Test rollback with exception during restore (lines 571-574)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            history = UpgradeHistory(
                timestamp="2025-01-01T12:00:00",
                from_version="1.0.0",
                to_version="1.1.0",
                steps_applied=1,
                steps_successful=1,
                status="success",
                backup_path=str(backup_path),
            )
            metadata = ProjectMetadata(
                current_version="1.1.0",
                template_type="python-saas",
                created_at="2025-01-01",
                upgrade_history=[history],
            )
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load", return_value=metadata):
                # Mock shutil operations to raise exception
                with patch("shutil.rmtree", side_effect=OSError("Permission denied")):
                    result = cmd.rollback_upgrade()
            
            assert result is False


class TestBackupAndRollbackOperations:
    """Test backup creation and rollback helper methods."""

    def test_create_backup_with_files(self):
        """Test _create_backup copies files correctly (line 606)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create project structure
            (project_path / "src").mkdir()
            (project_path / "src" / "main.py").write_text("# main")
            (project_path / ".gitignore").write_text("*.pyc")
            (project_path / ".env.example").write_text("ENV=example")
            
            cmd = UpgradeCommand(project_path)
            backup_path = cmd._create_backup()
            
            # Verify backup contains files
            assert (backup_path / "src" / "main.py").exists()
            assert (backup_path / ".gitignore").exists()
            assert (backup_path / ".env.example").exists()

    def test_rollback_to_backup_no_backup_path(self):
        """Test _rollback_to_backup with no backup_path (lines 623-624)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            cmd.backup_path = None
            
            # Should not crash, just print error
            cmd._rollback_to_backup()

    def test_rollback_to_backup_backup_not_exists(self):
        """Test _rollback_to_backup when backup doesn't exist (line 631)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            cmd.backup_path = Path(tmpdir) / "nonexistent"
            
            # Should not crash
            cmd._rollback_to_backup()

    def test_rollback_to_backup_with_directories(self):
        """Test _rollback_to_backup with both files and directories (lines 638-641)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create separate directories
            project_path = Path(tmpdir) / "project"
            project_path.mkdir()
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            # Create backup structure
            (backup_path / "file.txt").write_text("content")
            (backup_path / "dir1").mkdir()
            (backup_path / "dir1" / "nested.py").write_text("code")
            
            # Create current project files to be replaced
            (project_path / "old.txt").write_text("old")
            
            cmd = UpgradeCommand(project_path)
            cmd.backup_path = backup_path
            cmd._rollback_to_backup()
            
            # Verify restoration
            assert (project_path / "file.txt").exists()
            assert (project_path / "dir1" / "nested.py").exists()
            assert not (project_path / "old.txt").exists()


class TestCommitUpgrade:
    """Test _commit_upgrade functionality."""

    def test_commit_upgrade_success(self):
        """Test _commit_upgrade with successful git commands (lines 665-666)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            # Mock successful git commands
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = Mock(returncode=0, stderr=b"")
                
                cmd._commit_upgrade("1.0.0", "1.1.0")
                
                # Verify git commands were called
                assert mock_run.call_count == 2

    def test_commit_upgrade_git_failure(self):
        """Test _commit_upgrade when git commit fails (line 673)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            # Mock git command failure
            from subprocess import CalledProcessError
            
            with patch("subprocess.run") as mock_run:
                mock_run.side_effect = [
                    Mock(returncode=0),  # git add succeeds
                    CalledProcessError(1, "git commit", stderr=b"nothing to commit"),
                ]
                
                # Should not crash, just print warning
                cmd._commit_upgrade("1.0.0", "1.1.0")


class TestRunUpgradeFunction:
    """Test run_upgrade entry point function."""

    def test_run_upgrade_with_all_options(self):
        """Test run_upgrade with all options enabled."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            with patch.object(UpgradeCommand, "preview_upgrade") as mock_preview:
                mock_preview.return_value = Mock()
                
                result = run_upgrade(
                    project_path=project_path,
                    to_version="2.0.0",
                    dry_run=True,
                    force=True,
                )
                
                assert isinstance(result, bool)

    def test_run_upgrade_interactive_mode(self):
        """Test run_upgrade with interactive flag."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            with patch.object(UpgradeCommand, "execute_upgrade") as mock_execute:
                mock_execute.return_value = True
                
                result = run_upgrade(
                    project_path=project_path,
                    interactive=True,
                )
                
                # Verify interactive was passed
                mock_execute.assert_called_once()
                call_kwargs = mock_execute.call_args[1]
                assert call_kwargs["interactive"] is True

    def test_run_upgrade_skip_verification(self):
        """Test run_upgrade with skip_verification flag."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            with patch.object(UpgradeCommand, "execute_upgrade") as mock_execute:
                mock_execute.return_value = True
                
                result = run_upgrade(
                    project_path=project_path,
                    skip_verification=True,
                )
                
                # Verify skip_verification was passed
                call_kwargs = mock_execute.call_args[1]
                assert call_kwargs["skip_verification"] is True


class TestProjectMetadataOperations:
    """Test ProjectMetadata serialization and deserialization."""

    def test_project_metadata_to_dict(self):
        """Test ProjectMetadata.to_dict()."""
        metadata = ProjectMetadata(
            current_version="1.0.0",
            template_type="python-saas",
            created_at="2025-01-01",
        )
        
        data = metadata.to_dict()
        
        assert data["current_version"] == "1.0.0"
        assert data["template_type"] == "python-saas"
        assert "upgrade_history" in data

    def test_project_metadata_from_dict_with_history(self):
        """Test ProjectMetadata.from_dict() with upgrade history."""
        data = {
            "current_version": "1.1.0",
            "template_type": "react-client",
            "created_at": "2025-01-01",
            "upgrade_history": [
                {
                    "timestamp": "2025-01-02T10:00:00",
                    "from_version": "1.0.0",
                    "to_version": "1.1.0",
                    "steps_applied": 2,
                    "steps_successful": 2,
                    "status": "success",
                }
            ],
        }
        
        metadata = ProjectMetadata.from_dict(data)
        
        assert metadata.current_version == "1.1.0"
        assert len(metadata.upgrade_history) == 1
        assert isinstance(metadata.upgrade_history[0], UpgradeHistory)


class TestTemplateDetectionEdgeCases:
    """Test edge cases in template type detection."""

    def test_detect_template_rails(self):
        """Test detecting rails-api template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create Rails project
            (project_path / "Gemfile").write_text("gem 'rails'")
            
            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()
            
            assert template == "rails-api"

    def test_detect_template_unknown(self):
        """Test detecting unknown template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create project with no recognizable structure
            (project_path / "README.md").write_text("# Project")
            
            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()
            
            assert template == "unknown"


class TestExecuteUpgradeAdditionalPaths:
    """Additional tests for execute_upgrade to cover more paths."""

    def test_execute_upgrade_with_git_commit(self):
        """Test execute_upgrade commits to git when in git repo (lines 407-408)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            step = UpgradeStep(
                index=1,
                codemod_id="001",
                codemod_name="Test",
                from_version="1.0.0",
                to_version="1.1.0",
                description="Test",
                risk_level="low",
            )
            
            with patch.object(cmd, "plan_upgrade", return_value=([step], "1.1.0")):
                with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                    metadata = ProjectMetadata(
                        current_version="1.0.0",
                        template_type="python-saas",
                        created_at="2025-01-01",
                    )
                    mock_load.return_value = metadata
                    
                    backup_path = Path(tmpdir) / "backup"
                    backup_path.mkdir()
                    
                    with patch.object(cmd, "_create_backup", return_value=backup_path):
                        with patch.object(cmd, "_apply_codemod", return_value=True):
                            with patch.object(cmd.git_guard, "is_git_repo", return_value=True):
                                with patch.object(cmd, "_commit_upgrade") as mock_commit:
                                    with patch("foundry.actions.upgrade.MetadataTracker.save"):
                                        result = cmd.execute_upgrade(
                                            force=True,
                                            skip_verification=True,
                                        )
                    
                    assert result is True
                    mock_commit.assert_called_once_with("1.0.0", "1.1.0")

    def test_execute_upgrade_already_at_target(self):
        """Test execute_upgrade when already at target version (lines 338-339)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            # Mock plan_upgrade to return no steps
            with patch.object(cmd, "plan_upgrade", return_value=([], "1.0.0")):
                result = cmd.execute_upgrade(force=True)
            
            assert result is True

    def test_execute_upgrade_skip_verification_success(self):
        """Test execute_upgrade with skip_verification=True (lines 390-404 skipped)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            step = UpgradeStep(
                index=1,
                codemod_id="001",
                codemod_name="Test",
                from_version="1.0.0",
                to_version="1.1.0",
                description="Test",
                risk_level="low",
            )
            
            with patch.object(cmd, "plan_upgrade", return_value=([step], "1.1.0")):
                with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                    metadata = ProjectMetadata(
                        current_version="1.0.0",
                        template_type="python-saas",
                        created_at="2025-01-01",
                    )
                    mock_load.return_value = metadata
                    
                    backup_path = Path(tmpdir) / "backup"
                    backup_path.mkdir()
                    
                    with patch.object(cmd, "_create_backup", return_value=backup_path):
                        with patch.object(cmd, "_apply_codemod", return_value=True):
                            with patch("foundry.actions.upgrade.MetadataTracker.save"):
                                result = cmd.execute_upgrade(
                                    force=True,
                                    skip_verification=True,
                                )
            
            assert result is True


class TestMetadataTrackerAdditionalCoverage:
    """Additional tests for MetadataTracker to improve coverage."""

    def test_detect_version_no_files(self):
        """Test _detect_version when no version files exist (returns None)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # No pyproject.toml or package.json
            tracker = MetadataTracker(project_path)
            version = tracker._detect_version()
            
            assert version is None

    def test_detect_template_python_no_core_dir(self):
        """Test detecting python project without src/core."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create pyproject.toml with poetry but no src/core
            (project_path / "pyproject.toml").write_text("[tool.poetry]\n")
            
            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()
            
            # Should not return python-saas without src/core
            assert template != "python-saas"

    def test_detect_template_react_no_components(self):
        """Test detecting react project without src/components."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create package.json with vite but no src/components
            (project_path / "package.json").write_text('{"devDependencies": {"vite": "^4.0.0"}}')
            
            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()
            
            # Should not return react-client without src/components
            assert template != "react-client"


class TestUpgradeStepCoverage:
    """Additional tests for upgrade step operations."""

    def test_plan_upgrade_multiple_codemods(self):
        """Test plan_upgrade with multiple codemods in sequence."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            # Create multiple codemod steps
            codemod1 = CodemodMetadata(
                id="001",
                name="Step 1",
                description="First upgrade",
                from_version="1.0.0",
                to_version="1.0.5",
                affected_templates=["python-saas"],
                risk_level="low",
            )
            codemod2 = CodemodMetadata(
                id="002",
                name="Step 2",
                description="Second upgrade",
                from_version="1.0.5",
                to_version="1.1.0",
                affected_templates=["python-saas"],
                risk_level="medium",
            )
            
            with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                metadata = ProjectMetadata(
                    current_version="1.0.0",
                    template_type="python-saas",
                    created_at="2025-01-01",
                )
                mock_load.return_value = metadata
                
                with patch.object(cmd.delta_store, "get_codemods_for_template") as mock_get:
                    mock_get.return_value = [
                        CodemodDefinition(metadata=codemod1, implementation={}),
                        CodemodDefinition(metadata=codemod2, implementation={}),
                    ]
                    
                    with patch.object(cmd, "_get_latest_version", return_value="1.1.0"):
                        steps, target_version = cmd.plan_upgrade(force=True)
            
            assert len(steps) == 2
            assert steps[0].codemod_id == "001"
            assert steps[1].codemod_id == "002"
            assert target_version == "1.1.0"

    def test_execute_upgrade_partial_success(self):
        """Test execute_upgrade with partial success (some codemods succeed, one fails)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            cmd = UpgradeCommand(project_path)
            
            step1 = UpgradeStep(
                index=1,
                codemod_id="001",
                codemod_name="First",
                from_version="1.0.0",
                to_version="1.0.5",
                description="First",
                risk_level="low",
            )
            step2 = UpgradeStep(
                index=2,
                codemod_id="002",
                codemod_name="Second",
                from_version="1.0.5",
                to_version="1.1.0",
                description="Second",
                risk_level="low",
            )
            
            with patch.object(cmd, "plan_upgrade", return_value=([step1, step2], "1.1.0")):
                with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
                    metadata = ProjectMetadata(
                        current_version="1.0.0",
                        template_type="python-saas",
                        created_at="2025-01-01",
                    )
                    mock_load.return_value = metadata
                    
                    backup_path = Path(tmpdir) / "backup"
                    backup_path.mkdir()
                    
                    with patch.object(cmd, "_create_backup", return_value=backup_path):
                        # First codemod succeeds, second fails
                        with patch.object(cmd, "_apply_codemod", side_effect=[True, False]):
                            with patch.object(cmd, "_rollback_to_backup") as mock_rollback:
                                with patch("foundry.actions.upgrade.MetadataTracker.save"):
                                    result = cmd.execute_upgrade(force=True)
            
            assert result is False
            mock_rollback.assert_called_once()


class TestRollbackAdditionalCoverage:
    """Additional rollback tests for edge cases."""

    def test_rollback_upgrade_with_project_path_param(self):
        """Test rollback_upgrade with explicit project_path parameter (lines 521-523)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir) / "project"
            project_path.mkdir()
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            # Create backup files
            (backup_path / "test.txt").write_text("backup")
            
            history = UpgradeHistory(
                timestamp="2025-01-01T12:00:00",
                from_version="1.0.0",
                to_version="1.1.0",
                steps_applied=1,
                steps_successful=1,
                status="success",
                backup_path=str(backup_path),
            )
            metadata = ProjectMetadata(
                current_version="1.1.0",
                template_type="python-saas",
                created_at="2025-01-01",
                upgrade_history=[history],
            )
            
            # Create cmd with different path, then pass project_path to rollback
            cmd = UpgradeCommand(Path("/tmp"))
            
            with patch("foundry.actions.upgrade.MetadataTracker.load", return_value=metadata):
                with patch("foundry.actions.upgrade.MetadataTracker.save"):
                    result = cmd.rollback_upgrade(project_path=project_path)
            
            assert result is True
            assert (project_path / "test.txt").exists()


class TestGetLatestVersionCoverage:
    """Test _get_latest_version edge cases."""

    def test_get_latest_version_returns_none_on_network_error(self):
        """Test _get_latest_version returns None when PyPI is unreachable."""
        import urllib.request
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            cmd = UpgradeCommand(project_path)

            with patch("urllib.request.urlopen", side_effect=OSError("network error")):
                latest = cmd._get_latest_version("python-saas")

            assert latest is None


class TestFinalCoverageGaps:
    """Tests to cover the final remaining lines."""

    def test_detect_version_pyproject_exception(self):
        """Test _detect_version exception handling for pyproject.toml (lines 168-169)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create pyproject.toml that will cause exception during regex
            (project_path / "pyproject.toml").write_text("\x00\x00invalid content")
            
            tracker = MetadataTracker(project_path)
            
            # Should catch exception and return None
            version = tracker._detect_version()
            assert version is None

    def test_execute_upgrade_exception_with_backup(self):
        """Test execute_upgrade exception handler with backup_path set (line 429)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            cmd = UpgradeCommand(project_path)
            cmd.backup_path = backup_path
            
            # Force an exception in plan_upgrade
            with patch.object(cmd, "plan_upgrade", side_effect=RuntimeError("Test error")):
                result = cmd.execute_upgrade(force=True)
            
            assert result is False

    def test_rollback_upgrade_with_directory_files(self):
        """Test rollback_upgrade removing directories during restore (line 551)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir) / "project"
            project_path.mkdir()
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            # Create backup with directories
            (backup_path / "src").mkdir()
            (backup_path / "src" / "main.py").write_text("code")
            
            # Create current project with directory to remove
            (project_path / "old_dir").mkdir()
            (project_path / "old_dir" / "file.py").write_text("old")
            
            history = UpgradeHistory(
                timestamp="2025-01-01T12:00:00",
                from_version="1.0.0",
                to_version="1.1.0",
                steps_applied=1,
                steps_successful=1,
                status="success",
                backup_path=str(backup_path),
            )
            metadata = ProjectMetadata(
                current_version="1.1.0",
                template_type="python-saas",
                created_at="2025-01-01",
                upgrade_history=[history],
            )
            
            cmd = UpgradeCommand(project_path)
            
            with patch("foundry.actions.upgrade.MetadataTracker.load", return_value=metadata):
                with patch("foundry.actions.upgrade.MetadataTracker.save"):
                    result = cmd.rollback_upgrade()
            
            assert result is True
            assert (project_path / "src" / "main.py").exists()
            assert not (project_path / "old_dir").exists()

    def test_create_backup_iterates_files(self):
        """Test _create_backup iterating through project files (line 606)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            
            # Create variety of files and directories
            (project_path / "file1.py").write_text("content1")
            (project_path / "file2.txt").write_text("content2")
            (project_path / "src").mkdir()
            (project_path / "src" / "main.py").write_text("main")
            
            cmd = UpgradeCommand(project_path)
            backup_path = cmd._create_backup()
            
            # Verify all files were backed up
            assert (backup_path / "file1.py").exists()
            assert (backup_path / "file2.txt").exists()
            assert (backup_path / "src" / "main.py").exists()

    def test_rollback_to_backup_skips_dotfiles(self):
        """Test _rollback_to_backup skipping dot files during removal (line 631)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir) / "project"
            project_path.mkdir()
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            # Create backup
            (backup_path / "file.txt").write_text("backup")
            
            # Create current project with dotfile
            (project_path / ".git").mkdir()
            (project_path / ".git" / "config").write_text("git config")
            (project_path / "file.txt").write_text("current")
            
            cmd = UpgradeCommand(project_path)
            cmd.backup_path = backup_path
            cmd._rollback_to_backup()
            
            # Verify dotfiles were preserved
            assert (project_path / ".git").exists()
            assert (project_path / "file.txt").read_text() == "backup"

    def test_rollback_to_backup_existing_dest(self):
        """Test _rollback_to_backup with existing destination directory (line 640)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir) / "project"
            project_path.mkdir()
            backup_path = Path(tmpdir) / "backup"
            backup_path.mkdir()
            
            # Create backup directory
            (backup_path / "src").mkdir()
            (backup_path / "src" / "new.py").write_text("new code")
            
            # Create existing directory in project that should be replaced
            (project_path / "src").mkdir()
            (project_path / "src" / "old.py").write_text("old code")
            
            cmd = UpgradeCommand(project_path)
            cmd.backup_path = backup_path
            cmd._rollback_to_backup()
            
            # Verify existing dir was replaced
            assert (project_path / "src" / "new.py").exists()
            assert not (project_path / "src" / "old.py").exists()
