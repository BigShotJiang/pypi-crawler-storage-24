from types import SimpleNamespace

from rich.text import Text

from foundry.animations.engine.animation_engine import InteractiveAnimationEngine
from foundry.animations.engine.frame_buffer import FrameBuffer
from foundry.animations.engine.state import AnimationState
from foundry.animations.base import Animation, AnimationConfig
from foundry.animations.scenes.entrance import EntranceAnimation
from foundry.animations.scenes.info_slide import InfoSlideAnimation
from foundry.animations.scenes.logo_dissolve import LogoDissolveAnimation
from foundry.animations.scenes.logo_slide import LogoSlideAnimation
from foundry.animations.scenes.forge import ForgeAnimation
from foundry.animations.scenes.tranquility import TranquilityAnimation
from foundry.animations.scenes.logo_reveal import LogoRevealAnimation


def test_engine_get_renderable():
    engine = InteractiveAnimationEngine()
    engine.buffer.add_layer("base", [Text("x" * 80) for _ in range(24)])
    renderable = engine._get_renderable()
    assert "x" in renderable.plain


def test_engine_play_minimal(monkeypatch):
    engine = InteractiveAnimationEngine()

    class DummyAnim(Animation):
        def __init__(self):
            super().__init__(AnimationConfig(duration=0.01))
        def _update_impl(self, dt, state):
            return state
        def render(self, frame_buffer, state):
            frame_buffer.add_layer("dummy", [Text(" ") for _ in range(24)])

    dummy = DummyAnim()

    monkeypatch.setattr("foundry.animations.engine.animation_engine.select.select", lambda *a, **k: ([], [], []))
    monkeypatch.setattr("foundry.animations.engine.animation_engine.termios.tcgetattr", lambda fd: [])
    monkeypatch.setattr("foundry.animations.engine.animation_engine.tty.setcbreak", lambda fd: None)
    monkeypatch.setattr("foundry.animations.engine.animation_engine.termios.tcsetattr", lambda *a, **k: None)

    class FakeLive:
        def __init__(self, *a, **k):
            pass
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc_val, exc_tb):
            return False
        def update(self, *a, **k):
            pass
        def refresh(self):
            pass

    monkeypatch.setattr("foundry.animations.engine.animation_engine.Live", FakeLive)
    monkeypatch.setattr("foundry.animations.engine.animation_engine.sys.stdin", SimpleNamespace(fileno=lambda: 0, read=lambda n: ""))
    monkeypatch.setattr(engine.clock, "tick", lambda: 0.02)

    assert engine.play(dummy) is None


def test_engine_play_quit(monkeypatch):
    engine = InteractiveAnimationEngine()

    class DummyAnim(Animation):
        def __init__(self):
            super().__init__(AnimationConfig(duration=1.0))
        def _update_impl(self, dt, state):
            return state
        def render(self, frame_buffer, state):
            frame_buffer.add_layer("dummy", [Text(" ") for _ in range(24)])

    dummy = DummyAnim()

    monkeypatch.setattr("foundry.animations.engine.animation_engine.select.select", lambda *a, **k: ([object()], [], []))
    monkeypatch.setattr("foundry.animations.engine.animation_engine.termios.tcgetattr", lambda fd: [])
    monkeypatch.setattr("foundry.animations.engine.animation_engine.tty.setcbreak", lambda fd: None)
    monkeypatch.setattr("foundry.animations.engine.animation_engine.termios.tcsetattr", lambda *a, **k: None)
    monkeypatch.setattr("foundry.animations.engine.animation_engine.sys.stdin", SimpleNamespace(fileno=lambda: 0, read=lambda n: "q"))

    class FakeLive:
        def __init__(self, *a, **k):
            pass
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc_val, exc_tb):
            return False
        def update(self, *a, **k):
            pass
        def refresh(self):
            pass

    monkeypatch.setattr("foundry.animations.engine.animation_engine.Live", FakeLive)
    monkeypatch.setattr(engine.clock, "tick", lambda: 0.02)

    assert engine.play(dummy) is None


def test_scene_renders_smoke():
    fb = FrameBuffer(width=80, height=24)
    state = AnimationState()

    EntranceAnimation().render(fb, state)
    InfoSlideAnimation().render(fb, state)
    LogoDissolveAnimation().render(fb, state)
    LogoSlideAnimation().render(fb, state)
    ForgeAnimation().render(fb, state)
    TranquilityAnimation().render(fb, state)

    assert fb.layers


def test_scene_updates():
    state = AnimationState()

    state = EntranceAnimation().update(0.2, state)
    state = InfoSlideAnimation().update(0.2, state)
    state = LogoDissolveAnimation().update(0.2, state)
    state = LogoSlideAnimation().update(0.2, state)
    state = ForgeAnimation().update(0.2, state)
    state = TranquilityAnimation().update(0.2, state)
    state = LogoRevealAnimation().update(0.2, state)

    assert state is not None
