import json
from pathlib import Path
from types import SimpleNamespace

import pytest


def test_read_project_metadata_invalid_json(tmp_path, monkeypatch):
    from foundry.actions import diff as diff_mod

    meta = tmp_path / ".sscli-metadata.json"
    meta.write_text("{bad-json")
    printed = []
    monkeypatch.setattr(diff_mod.console, "print", lambda msg: printed.append(msg))
    assert diff_mod._read_project_metadata(tmp_path) is None
    assert any("Warning" in str(msg) for msg in printed)


def test_compute_diff_basic(tmp_path, monkeypatch):
    from foundry.actions import diff as diff_mod

    foundry_root = tmp_path / "root"
    templates_dir = foundry_root / "templates" / "python-saas"
    templates_dir.mkdir(parents=True)

    project = tmp_path / "project"
    project.mkdir()

    (templates_dir / "app.py").write_text("print('base')\n")
    (project / "app.py").write_text("print('current')\n")
    (project / ".sscli-metadata.json").write_text(
        json.dumps({"base_template_version": "python-saas/1.0.0", "features_injected": []})
    )

    monkeypatch.setattr(diff_mod, "FOUNDRY_ROOT", foundry_root)

    result = diff_mod.compute_diff(str(project), output_format="unified")
    assert result["success"] is True
    assert result["statistics"]["total_files"] == 1
    assert "app.py" in result["file_diffs"]


def test_run_view_docs_non_interactive(tmp_path, monkeypatch):
    from foundry.actions import documentation as docs_mod

    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "README.md").write_text("# Docs\n")

    monkeypatch.setattr(docs_mod, "TEMPLATES_DIR", tmp_path)
    printed = []
    monkeypatch.setattr(docs_mod.console, "print", lambda msg: printed.append(msg))

    docs_mod.run_view_docs(interactive=False)
    assert any("Available Documentation" in str(msg) for msg in printed)


def test_run_view_docs_interactive_selects_doc(tmp_path, monkeypatch):
    from foundry.actions import documentation as docs_mod

    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "GUIDE.md").write_text("# Guide\n")

    monkeypatch.setattr(docs_mod, "TEMPLATES_DIR", tmp_path)
    monkeypatch.setattr(docs_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: "GUIDE.md"))
    called = {"render": False}
    monkeypatch.setattr(docs_mod, "_render_doc", lambda path: called.__setitem__("render", True))

    docs_mod.run_view_docs(interactive=True)
    assert called["render"] is True


def test_run_health_check_with_template(tmp_path, monkeypatch):
    from foundry.actions import health as health_mod

    templates_dir = tmp_path / "python-saas"
    templates_dir.mkdir(parents=True)
    (templates_dir / "Dockerfile").write_text("FROM python:3.12\n")
    (templates_dir / ".gitignore").write_text("*.pyc\n")
    (templates_dir / "RUNBOOK.md").write_text("# Runbook\n")
    (templates_dir / ".env.example").write_text("KEY=VALUE\n")

    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", tmp_path)
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))

    health_mod.run_health_check()
    assert printed


def test_account_info_menu_refresh_and_logout(monkeypatch):
    from foundry.actions import account_info as account_mod

    seq = iter(["refresh", "logout"])
    monkeypatch.setattr(account_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(account_mod.questionary, "confirm", lambda *a, **k: SimpleNamespace(ask=lambda: True))

    refreshed = {"count": 0, "logout": 0}
    monkeypatch.setattr(account_mod, "get_current_license_info", lambda verify=True: refreshed.__setitem__("count", refreshed["count"] + 1) or {"tier": "pro"})
    monkeypatch.setattr(account_mod, "logout", lambda: refreshed.__setitem__("logout", refreshed["logout"] + 1))

    assert account_mod.account_info_menu({"tier": "free"}) is False
    assert refreshed["count"] == 1
    assert refreshed["logout"] == 1


def test_validation_clear_report(tmp_path, monkeypatch):
    from foundry.actions import validation as validation_mod

    monkeypatch.setattr(validation_mod, "TEMPLATES_DIR", tmp_path)
    report = tmp_path / "verification_results.csv"
    report.write_text("x")

    validation_mod._clear_report()
    assert not report.exists()


def test_validation_run_script_missing(tmp_path, monkeypatch):
    from foundry.actions import validation as validation_mod

    monkeypatch.setattr(validation_mod, "TEMPLATES_DIR", tmp_path)
    printed = []
    monkeypatch.setattr(validation_mod.console, "print", lambda msg: printed.append(msg))

    validation_mod._run_script("scripts/verify_templates.py", "Build Verification")
    assert any("not found" in str(msg) for msg in printed)


def test_transformation_execute_dry_run_writes_file(tmp_path, monkeypatch):
    from foundry.actions import transformation as trans_mod

    class FakeEngine:
        def as_json(self, include_content=False):
            return "{\"ok\": true}"
        def as_stats(self, verbose=False):
            return "stats"
        def as_unified_diff(self):
            return "diff"
        def get_summary_line(self):
            return "summary"

    class FakeCommand(trans_mod.TransformationCommand):
        def _run_transformation(self, **kwargs):
            return True

    monkeypatch.setattr(trans_mod, "DryRunEngine", lambda: FakeEngine())

    cmd = FakeCommand("new", "desc")
    output_file = tmp_path / "dry.json"
    assert cmd.execute(dry_run=True, json_output=True, output_file=str(output_file)) is True
    assert output_file.read_text() == "{\"ok\": true}"


def test_handle_dry_run_output_stats(tmp_path):
    from foundry.actions import transformation as trans_mod

    class FakeEngine:
        def as_json(self, include_content=False):
            return "json"
        def as_stats(self, verbose=False):
            return "stats"
        def as_unified_diff(self):
            return "diff"
        def get_summary_line(self):
            return "summary"

    output_file = tmp_path / "stats.txt"
    trans_mod.handle_dry_run_output(FakeEngine(), stats_only=True, output_file=str(output_file))
    assert output_file.read_text() == "stats"
