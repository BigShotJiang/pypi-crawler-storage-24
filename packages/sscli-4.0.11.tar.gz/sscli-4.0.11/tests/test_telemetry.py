"""
Tests for foundry.telemetry.record_event (structured opt-in JSONL telemetry).
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _patched_telemetry_file(tmp_path: Path):
    """Return a tmp telemetry file path inside tmp_path."""
    return tmp_path / "telemetry.jsonl"


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_record_event_writes_to_file(tmp_path):
    """record_event writes a valid JSONL line to the telemetry file."""
    tel_file = _patched_telemetry_file(tmp_path)

    with patch("foundry.telemetry.STRUCTURED_TELEMETRY_FILE", tel_file):
        from foundry.telemetry import record_event
        record_event("test_event", {"key": "value"})

    assert tel_file.exists(), "telemetry file should be created"
    lines = tel_file.read_text().strip().splitlines()
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["event"] == "test_event"
    assert parsed["properties"] == {"key": "value"}


def test_record_event_disabled_by_env(monkeypatch, tmp_path):
    """record_event writes nothing when SSCLI_NO_TELEMETRY is set."""
    tel_file = _patched_telemetry_file(tmp_path)
    monkeypatch.setenv("SSCLI_NO_TELEMETRY", "1")

    with patch("foundry.telemetry.STRUCTURED_TELEMETRY_FILE", tel_file):
        from foundry.telemetry import record_event
        record_event("should_not_write")

    assert not tel_file.exists(), "telemetry file must not be created when opt-out"


def test_record_event_non_fatal_on_permission_error(tmp_path):
    """record_event does not raise even when the file cannot be written."""
    read_only_dir = tmp_path / "readonly"
    read_only_dir.mkdir(mode=0o555)
    tel_file = read_only_dir / "sub" / "telemetry.jsonl"

    with patch("foundry.telemetry.STRUCTURED_TELEMETRY_FILE", tel_file):
        from foundry.telemetry import record_event
        # Should not raise — telemetry errors are swallowed
        record_event("risky_event")


def test_event_has_required_fields(tmp_path):
    """Written event contains event, timestamp, and properties keys."""
    tel_file = _patched_telemetry_file(tmp_path)

    with patch("foundry.telemetry.STRUCTURED_TELEMETRY_FILE", tel_file):
        from foundry.telemetry import record_event
        record_event("check_fields")

    parsed = json.loads(tel_file.read_text().strip())
    assert "event" in parsed
    assert "timestamp" in parsed
    assert "properties" in parsed
    assert isinstance(parsed["properties"], dict)
