import subprocess
from datetime import datetime
from pathlib import Path

import pytest

from foundry.actions.verification.models import (
    TemplateType,
    VerificationResult,
    VerificationStatus,
)
from foundry.actions.verification.verifier import TemplateVerifier


def _make_result(name, ttype):
    return VerificationResult(
        name=name,
        template_type=ttype,
        status=VerificationStatus.SUCCESS,
        git_ignore=True,
        git_attributes=False,
        docker_success=False,
        duration_seconds=0,
        timestamp=datetime.now().isoformat(),
    )


def test_verify_template_missing_dir(tmp_path):
    verifier = TemplateVerifier(tmp_path)

    result = verifier._verify_template("python-saas", TemplateType.DOCKER, True)

    assert result.status == VerificationStatus.FAILED
    assert "Directory not found" in result.notes


def test_run_docker_timeout(tmp_path, monkeypatch):
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("", encoding="utf-8")
    (template_dir / "Dockerfile").write_text("FROM scratch\n", encoding="utf-8")
    (template_dir / "README.md").write_text("Test\n", encoding="utf-8")

    def _raise_timeout(*_args, **_kwargs):
        raise subprocess.TimeoutExpired(cmd=["docker"], timeout=600)

    monkeypatch.setattr(subprocess, "run", _raise_timeout)

    result = _make_result("python-saas", TemplateType.DOCKER)
    verifier = TemplateVerifier(tmp_path)

    verifier._run_docker(template_dir, "python-saas", result)

    assert result.status == VerificationStatus.FAILED
    assert "timeout" in result.notes.lower()


def test_run_terraform_success(tmp_path, monkeypatch):
    template_dir = tmp_path / "templates" / "terraform-infra"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("", encoding="utf-8")
    (template_dir / "main.tf").write_text("", encoding="utf-8")
    (template_dir / "README.md").write_text("Test\n", encoding="utf-8")

    calls = []

    def _ok_run(cmd, **_kwargs):
        calls.append(cmd)
        return subprocess.CompletedProcess(cmd, 0)

    monkeypatch.setattr(subprocess, "run", _ok_run)

    result = _make_result("terraform-infra", TemplateType.TERRAFORM)
    verifier = TemplateVerifier(tmp_path)

    verifier._run_terraform(template_dir, result)

    assert result.status == VerificationStatus.SUCCESS
    assert result.docker_success is True
    assert calls


def test_check_files_missing_required(tmp_path):
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)
    (template_dir / ".gitignore").write_text("", encoding="utf-8")

    verifier = TemplateVerifier(tmp_path)
    result = _make_result("python-saas", TemplateType.DOCKER)

    verifier._check_files(template_dir, TemplateType.DOCKER, result)

    assert result.status == VerificationStatus.FAILED
    assert "Missing" in result.notes


def test_run_docker_exception(tmp_path, monkeypatch):
    template_dir = tmp_path / "templates" / "python-saas"
    template_dir.mkdir(parents=True)

    monkeypatch.setattr(subprocess, "run", lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("boom")))

    result = _make_result("python-saas", TemplateType.DOCKER)
    verifier = TemplateVerifier(tmp_path)

    verifier._run_docker(template_dir, "python-saas", result)

    assert result.status == VerificationStatus.ERROR
    assert "boom" in result.notes


def test_run_terraform_cli_missing(tmp_path, monkeypatch):
    template_dir = tmp_path / "templates" / "terraform-infra"
    template_dir.mkdir(parents=True)

    monkeypatch.setattr(subprocess, "run", lambda *_a, **_k: (_ for _ in ()).throw(FileNotFoundError()))

    result = _make_result("terraform-infra", TemplateType.TERRAFORM)
    verifier = TemplateVerifier(tmp_path)

    verifier._run_terraform(template_dir, result)

    assert result.status == VerificationStatus.FAILED
    assert "Terraform CLI" in result.notes
