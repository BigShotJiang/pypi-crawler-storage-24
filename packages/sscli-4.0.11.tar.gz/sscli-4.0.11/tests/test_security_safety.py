"""
Security regression tests for the safety layer.

Covers:
  C-9   GitStatusError is re-raised from CodemodSafetyContext.__enter__
  H-13  --force bypass writes a FORCE_BYPASS audit-log entry
  C-12  verification_skipped field is set and passed is False
  H-15  add_custom_validator rejects shell operators and relative-path traversal
  C-10  ImportError in safety.integration emits RuntimeWarning
  H-27  Dry-run temp files use .sscli_dry suffix in system tempdir, not source dir
"""

import importlib
import os
import sys
import tempfile
from pathlib import Path
from types import ModuleType
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _reload_safety_with_broken_integration(monkeypatch):
    """
    Remove foundry.safety from sys.modules and block foundry.safety.integration
    so that importing foundry.safety exercises the ImportError branch.
    Returns the freshly-imported foundry.safety module.
    """
    # Block the integration sub-module (sys.modules[x] = None → ImportError)
    monkeypatch.setitem(sys.modules, "foundry.safety.integration", None)  # type: ignore[arg-type]
    # Force foundry.safety to reload (re-execute __init__)
    monkeypatch.delitem(sys.modules, "foundry.safety", raising=False)

    import foundry.safety as fs  # noqa: PLC0415
    return fs


# ===========================================================================
# C-9  — GitStatusError is re-raised from CodemodSafetyContext.__enter__
# ===========================================================================

class TestC9GitStatusErrorReraised:
    """CodemodSafetyContext must propagate GitStatusError out of 'with' block."""

    def _make_ctx(self, raise_exc):
        from foundry.safety.integration import CodemodSafetyContext
        ctx = CodemodSafetyContext(force=False)
        # Patch the guard that will be constructed inside __enter__
        mock_guard = MagicMock()
        mock_guard.require_clean_status.side_effect = raise_exc
        with patch("foundry.safety.integration.GitGuard", return_value=mock_guard):
            return ctx, mock_guard

    def test_git_status_error_propagates(self):
        from foundry.safety import GitStatusError
        from foundry.safety.integration import CodemodSafetyContext

        mock_guard = MagicMock()
        mock_guard.require_clean_status.side_effect = GitStatusError("dirty repo")

        body_executed = False
        with patch("foundry.safety.integration.GitGuard", return_value=mock_guard):
            with pytest.raises(GitStatusError, match="dirty repo"):
                with CodemodSafetyContext(force=False):
                    body_executed = True  # must NOT run

        assert not body_executed, "With-body must not execute when GitStatusError is raised"

    def test_body_executes_when_clean(self):
        from foundry.safety.integration import CodemodSafetyContext

        mock_guard = MagicMock()
        mock_guard.require_clean_status.return_value = None  # clean

        body_executed = False
        with patch("foundry.safety.integration.GitGuard", return_value=mock_guard):
            with CodemodSafetyContext(force=False) as ctx:
                body_executed = True
                assert ctx.is_safe is True

        assert body_executed, "With-body must execute when git status is clean"


# ===========================================================================
# H-13  — --force bypass writes audit log with FORCE_BYPASS entry
# ===========================================================================

class TestH13ForceAuditLog:
    """_write_force_audit_log must append a timestamped FORCE_BYPASS entry."""

    def test_force_bypass_writes_audit_entry(self, tmp_path, monkeypatch):
        import foundry.safety.integration as integration

        # Redirect the audit directory to tmp_path
        fake_sscli_dir = tmp_path / ".sscli"
        monkeypatch.setattr(
            integration.os.path,
            "expanduser",
            lambda p: str(fake_sscli_dir) if p == "~/.sscli" else os.path.expanduser(p),
        )

        integration._write_force_audit_log(command_name="test_cmd")

        audit_file = fake_sscli_dir / "audit.log"
        assert audit_file.exists(), "audit.log must be created"
        content = audit_file.read_text()
        assert "FORCE_BYPASS" in content, f"FORCE_BYPASS not found in: {content!r}"
        assert "test_cmd" in content, f"command name not in audit entry: {content!r}"

    def test_force_bypass_via_context_manager(self, tmp_path, monkeypatch):
        import foundry.safety.integration as integration
        from foundry.safety.integration import CodemodSafetyContext

        fake_sscli_dir = tmp_path / ".sscli"
        monkeypatch.setattr(
            integration.os.path,
            "expanduser",
            lambda p: str(fake_sscli_dir) if p == "~/.sscli" else os.path.expanduser(p),
        )

        with CodemodSafetyContext(force=True) as ctx:
            assert ctx.is_safe is True

        audit_file = fake_sscli_dir / "audit.log"
        assert audit_file.exists()
        assert "FORCE_BYPASS" in audit_file.read_text()

    def test_audit_entry_contains_timestamp(self, tmp_path, monkeypatch):
        import foundry.safety.integration as integration

        fake_sscli_dir = tmp_path / ".sscli"
        monkeypatch.setattr(
            integration.os.path,
            "expanduser",
            lambda p: str(fake_sscli_dir) if p == "~/.sscli" else os.path.expanduser(p),
        )

        integration._write_force_audit_log()

        content = (fake_sscli_dir / "audit.log").read_text()
        # ISO timestamp must appear (contains 'T' separator and 'UTC' offset indicator)
        assert "T" in content and "+" in content or "Z" in content or "UTC" in content or \
               any(c.isdigit() for c in content), \
               f"No recognisable timestamp in: {content!r}"


# ===========================================================================
# C-12  — verification_skipped field set; passed is False
# ===========================================================================

class TestC12VerificationSkipped:
    """VerificationHook(skip_verification=True) must mark report properly."""

    def _get_report(self, tmp_path):
        from foundry.safety.verification_hook import VerificationHook
        hook = VerificationHook(skip_verification=True)
        return hook.run_validators(tmp_path)

    def test_verification_skipped_is_true(self, tmp_path):
        report = self._get_report(tmp_path)
        assert report.verification_skipped is True

    def test_passed_is_false_when_skipped(self, tmp_path):
        report = self._get_report(tmp_path)
        assert report.passed is False, (
            "passed must be False when verification is skipped (not vacuously True)"
        )

    def test_to_dict_verification_skipped(self, tmp_path):
        report = self._get_report(tmp_path)
        d = report.to_dict()
        assert d["verification_skipped"] is True
        assert d["passed"] is False

    def test_validators_run_is_zero_when_skipped(self, tmp_path):
        report = self._get_report(tmp_path)
        assert report.validators_run == 0


# ===========================================================================
# H-15  — add_custom_validator rejects shell operators and path traversal
# ===========================================================================

class TestH15CustomValidatorRestriction:
    """add_custom_validator must reject dangerous executables."""

    def _hook(self):
        from foundry.safety.verification_hook import VerificationHook, ProjectType
        return VerificationHook(), ProjectType.PYTHON

    def test_shell_operator_in_command_raises(self):
        """Executable name that contains a shell operator must be rejected."""
        hook, ptype = self._hook()
        # Semicolon embedded directly in the executable string triggers H-15
        with pytest.raises(ValueError, match="Unsafe executable"):
            hook.add_custom_validator(
                project_type=ptype,
                name="evil-shell",
                command=["sh;rm${IFS}-rf${IFS}/"],
                description="evil",
            )

    def test_relative_path_traversal_raises(self):
        hook, ptype = self._hook()
        with pytest.raises(ValueError):
            hook.add_custom_validator(
                project_type=ptype,
                name="traversal",
                command=["../../../usr/bin/evil"],
                description="traversal attempt",
            )

    def test_absolute_pipe_operator_raises(self):
        """Pipe character in the executable string must be rejected."""
        hook, ptype = self._hook()
        with pytest.raises(ValueError):
            hook.add_custom_validator(
                project_type=ptype,
                name="pipe-evil",
                command=["/bin/echo|evil"],
                description="pipe in path",
            )

    def test_absolute_valid_binary_succeeds(self):
        """An absolute path to a real binary must be accepted."""
        import shutil
        echo = shutil.which("echo") or "/bin/echo"
        if not Path(echo).exists():
            pytest.skip(f"{echo} not found on this system")

        hook, ptype = self._hook()
        # Should not raise
        hook.add_custom_validator(
            project_type=ptype,
            name="safe-echo",
            command=[echo, "hello"],
            description="safe absolute binary",
        )

    def test_empty_command_raises(self):
        hook, ptype = self._hook()
        with pytest.raises(ValueError):
            hook.add_custom_validator(
                project_type=ptype,
                name="empty",
                command=[],
                description="empty command",
            )


# ===========================================================================
# C-10  — ImportError in safety.integration emits RuntimeWarning
# ===========================================================================

class TestC10ImportErrorWarns:
    """Blocking foundry.safety.integration must emit RuntimeWarning."""

    def test_runtime_warning_emitted(self, monkeypatch):
        # Block integration then force reload of foundry.safety
        monkeypatch.setitem(sys.modules, "foundry.safety.integration", None)  # type: ignore[arg-type]
        monkeypatch.delitem(sys.modules, "foundry.safety", raising=False)

        with pytest.warns(RuntimeWarning, match="could not be loaded"):
            import foundry.safety  # noqa: PLC0415, F401

    def test_has_integration_is_false(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "foundry.safety.integration", None)  # type: ignore[arg-type]
        monkeypatch.delitem(sys.modules, "foundry.safety", raising=False)

        with pytest.warns(RuntimeWarning):
            import foundry.safety as fs  # noqa: PLC0415

        assert fs._has_integration is False

    def test_normal_import_has_integration_true(self, monkeypatch):
        """Ensure integration is present under normal conditions (sanity check)."""
        # Force a clean reimport without any blocking in place so we can
        # confirm that the un-poisoned import path sets _has_integration=True.
        monkeypatch.delitem(sys.modules, "foundry.safety", raising=False)
        # Make sure integration is NOT blocked (remove any None sentinel)
        current = sys.modules.get("foundry.safety.integration")
        if current is None:
            monkeypatch.delitem(sys.modules, "foundry.safety.integration", raising=False)

        import foundry.safety as fs  # noqa: PLC0415
        assert fs._has_integration is True


# ===========================================================================
# H-27  — Dry-run temp files use .sscli_dry in system tempdir, not source dir
# ===========================================================================

class TestH27DryRunTempFiles:
    """DryRunCodemodWrapper must not pollute the source directory."""

    def _make_mock_codemod_class(self, new_content: str):
        """
        Return a fake codemod class whose apply() method transforms content.
        The result object mimics the interface codemod.apply() returns.
        """
        ApplyResult = MagicMock
        orig_content_holder = {}

        class _FakeCodemod:
            def apply(self, path: Path):
                orig_content_holder["c"] = path.read_text(encoding="utf-8")
                path.write_text(new_content, encoding="utf-8")
                result = MagicMock()
                result.success = True
                result.changes_made = 1
                result.error = None
                return result

        return _FakeCodemod

    def test_no_new_py_files_in_source_dir(self, tmp_path):
        from foundry.safety.dry_run_engine import DryRunEngine, DryRunCodemodWrapper

        # Create a real .py source file
        source_file = tmp_path / "sample.py"
        source_file.write_text("x = 1\n", encoding="utf-8")

        py_files_before = set(tmp_path.glob("*.py"))

        engine = DryRunEngine()
        codemod_cls = self._make_mock_codemod_class("x = 2\n")
        wrapper = DryRunCodemodWrapper(engine, codemod_cls)
        wrapper.apply_to_file(source_file)

        py_files_after = set(tmp_path.glob("*.py"))
        new_py = py_files_after - py_files_before
        assert not new_py, f"Unexpected .py files created in source dir: {new_py}"

    def test_source_file_not_modified(self, tmp_path):
        from foundry.safety.dry_run_engine import DryRunEngine, DryRunCodemodWrapper

        source_file = tmp_path / "sample.py"
        source_file.write_text("x = 1\n", encoding="utf-8")

        engine = DryRunEngine()
        codemod_cls = self._make_mock_codemod_class("x = 999\n")
        wrapper = DryRunCodemodWrapper(engine, codemod_cls)
        wrapper.apply_to_file(source_file)

        # Content must be untouched (dry run)
        assert source_file.read_text(encoding="utf-8") == "x = 1\n"

    def test_temp_files_cleaned_up_after_run(self, tmp_path):
        from foundry.safety.dry_run_engine import DryRunEngine, DryRunCodemodWrapper

        sysdir = Path(tempfile.gettempdir())
        sscli_dry_before = set(sysdir.glob("*.sscli_dry"))

        source_file = tmp_path / "sample.py"
        source_file.write_text("x = 1\n", encoding="utf-8")

        engine = DryRunEngine()
        codemod_cls = self._make_mock_codemod_class("x = 2\n")
        wrapper = DryRunCodemodWrapper(engine, codemod_cls)
        wrapper.apply_to_file(source_file)

        sscli_dry_after = set(sysdir.glob("*.sscli_dry"))
        leaked = sscli_dry_after - sscli_dry_before
        assert not leaked, f"Temp .sscli_dry files leaked into {sysdir}: {leaked}"

    def test_no_files_created_in_source_dir_at_all(self, tmp_path):
        from foundry.safety.dry_run_engine import DryRunEngine, DryRunCodemodWrapper

        source_file = tmp_path / "sample.py"
        source_file.write_text("a = 'hello'\n", encoding="utf-8")

        all_before = set(tmp_path.iterdir())

        engine = DryRunEngine()
        codemod_cls = self._make_mock_codemod_class("a = 'world'\n")
        wrapper = DryRunCodemodWrapper(engine, codemod_cls)
        wrapper.apply_to_file(source_file)

        all_after = set(tmp_path.iterdir())
        new_items = all_after - all_before
        assert not new_items, f"New items created in source dir: {new_items}"
