"""
Test suite for error reporting command (SSA-3).

Covers:
- Command exists and is callable
- Preview shows formatted log lines (no sensitive data)
- Confirmation prompt works (user says N → exits, user says Y → proceeds)
- Email field is optional/validated
- Command returns exit code 0 on success
"""

import pytest
import json
from pathlib import Path
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner
import tempfile
import shutil

from foundry.commands.report import (
    report_app,
    _redact_text,
    _validate_email,
    _read_last_logs,
    _format_log_preview,
    _save_report_locally,
    submit_report,
)

runner = CliRunner()


@pytest.fixture
def temp_log_dir():
    """Create a temporary directory for test logs."""
    tmpdir = tempfile.mkdtemp()
    yield tmpdir
    if Path(tmpdir).exists():
        shutil.rmtree(tmpdir)


@pytest.fixture
def mock_log_file(monkeypatch, temp_log_dir):
    """Mock the log file path to use temp directory."""
    log_file = Path(temp_log_dir) / ".session.log"
    log_file.write_text(
        "[2024-01-20 10:00:00] COMMAND: new\n"
        "[2024-01-20 10:00:01] GENERATE_START: python-saas\n"
        "[2024-01-20 10:00:02] ERROR: api_key=test_secret_key_value invalid\n"
        "[2024-01-20 10:00:03] GENERATE_END: success\n"
    )

    with patch("foundry.commands.report._get_log_file_path", return_value=log_file):
        yield log_file


# ── Test _redact_text ────────────────────────────────────────────────────────

def test_redact_text_removes_api_keys():
    """Test: API keys are redacted."""
    result = _redact_text("api_key=test_secret_key_value")
    assert "test_secret_key_value" not in result
    assert "REDACTED" in result


def test_redact_text_removes_passwords():
    """Test: Passwords are redacted."""
    result = _redact_text("password=mysecretpass123")
    assert "mysecretpass123" not in result
    assert "REDACTED" in result


def test_redact_text_removes_tokens():
    """Test: Tokens are redacted."""
    result = _redact_text("token=eyJhbGc...")
    assert "eyJhbGc" not in result
    assert "REDACTED" in result


def test_redact_text_preserves_normal_text():
    """Test: Normal text without secrets is unchanged."""
    text = "Building a great project with Python"
    assert _redact_text(text) == text


def test_redact_text_empty_returns_empty():
    """Test: Empty string returns empty."""
    assert _redact_text("") == ""


# ── Test _validate_email ─────────────────────────────────────────────────────

def test_validate_email_valid():
    """Test: Valid emails pass."""
    assert _validate_email("user@example.com") is True


def test_validate_email_multiple_domains():
    """Test: Emails with multiple domain parts pass."""
    assert _validate_email("user@mail.example.co.uk") is True


def test_validate_email_empty_is_valid():
    """Test: Empty email is valid (optional field)."""
    assert _validate_email("") is True


def test_validate_email_none_is_valid():
    """Test: None is valid (optional field)."""
    # Empty string check happens at call site
    assert _validate_email("") is True


def test_validate_email_invalid_no_at():
    """Test: Email without @ is invalid."""
    assert _validate_email("useremail.com") is False


def test_validate_email_invalid_no_domain():
    """Test: Email without domain is invalid."""
    assert _validate_email("user@") is False


# ── Test _read_last_logs ─────────────────────────────────────────────────────

def test_read_last_logs_reads_file(mock_log_file):
    """Test: _read_last_logs reads from log file."""
    logs = _read_last_logs(10)
    assert len(logs) > 0
    assert "COMMAND" in " ".join(logs)


def test_read_last_logs_returns_last_n_lines(mock_log_file):
    """Test: _read_last_logs returns exactly N lines."""
    logs = _read_last_logs(2)
    assert len(logs) == 2


def test_read_last_logs_no_file_returns_error_message():
    """Test: If no log file, return informative message."""
    with patch("foundry.commands.report._get_log_file_path") as mock_path:
        mock_path.return_value = Path("/nonexistent/path/.session.log")
        logs = _read_last_logs(10)
        assert len(logs) > 0
        assert "no session log found" in logs[0].lower() or logs[0] == "(No session log found — this is the first CLI session)"


# ── Test _format_log_preview ─────────────────────────────────────────────────

def test_format_log_preview_redacts_secrets(mock_log_file):
    """Test: Format redacts sensitive info."""
    logs = _read_last_logs(10)
    formatted = _format_log_preview(logs)
    assert "api_key" not in formatted or "REDACTED" in formatted


def test_format_log_preview_joins_lines(mock_log_file):
    """Test: Format joins lines with newline."""
    logs = _read_last_logs(3)
    formatted = _format_log_preview(logs)
    assert "\n" in formatted


# ── Test _save_report_locally ────────────────────────────────────────────────

def test_save_report_locally_creates_file(temp_log_dir):
    """Test: Report is saved to local file."""
    report_data = {"type": "test", "message": "test report"}

    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)):
        report_file = _save_report_locally(report_data)
        assert report_file.exists()
        assert report_file.suffix == ".json"


def test_save_report_locally_contains_data(temp_log_dir):
    """Test: Saved report contains the original data."""
    report_data = {"type": "test", "message": "test report", "email": "user@example.com"}

    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)):
        report_file = _save_report_locally(report_data)
        saved_data = json.loads(report_file.read_text())
        assert saved_data["type"] == "test"
        assert saved_data["message"] == "test report"


# ── Test submit_report command ────────────────────────────────────────────────

def test_submit_report_command_runs(mock_log_file, temp_log_dir):
    """Test: submit command runs without error."""
    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)), patch(
        "rich.prompt.Confirm.ask", return_value=True
    ):
        result = runner.invoke(report_app, ["submit", "--email", "test@example.com"])
        assert result.exit_code == 0


def test_submit_report_command_shows_preview(mock_log_file, temp_log_dir):
    """Test: submit command shows preview before confirmation."""
    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)), patch(
        "rich.prompt.Confirm.ask", return_value=False
    ):
        result = runner.invoke(report_app, ["submit"])
        # Should cancel instead of error
        assert result.exit_code == 0 or "cancelled" in result.stdout.lower()


def test_submit_report_command_accepts_email_option(mock_log_file, temp_log_dir):
    """Test: Email option is accepted."""
    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)), patch(
        "rich.prompt.Confirm.ask", return_value=True
    ):
        result = runner.invoke(report_app, ["submit", "--email", "user@example.com"])
        assert result.exit_code == 0


def test_submit_report_command_email_optional(mock_log_file, temp_log_dir):
    """Test: Email is optional."""
    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)), patch(
        "rich.prompt.Confirm.ask", return_value=True
    ):
        result = runner.invoke(report_app, ["submit"])
        assert result.exit_code == 0


def test_submit_report_command_includes_logs_option(mock_log_file, temp_log_dir):
    """Test: --include-logs option works."""
    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)), patch(
        "rich.prompt.Confirm.ask", return_value=True
    ):
        result = runner.invoke(report_app, ["submit", "--include-logs"])
        assert result.exit_code == 0


def test_submit_report_command_skips_logs_when_disabled(mock_log_file, temp_log_dir):
    """Test: --no-logs option works."""
    with patch("pathlib.Path.home", return_value=Path(temp_log_dir)), patch(
        "rich.prompt.Confirm.ask", return_value=True
    ):
        result = runner.invoke(report_app, ["submit", "--no-logs"])
        assert result.exit_code == 0


# ── Test view_logs command ────────────────────────────────────────────────────

def test_view_logs_command_runs(mock_log_file):
    """Test: view command runs without error."""
    result = runner.invoke(report_app, ["view"])
    assert result.exit_code == 0


def test_view_logs_command_respects_lines_option(mock_log_file):
    """Test: --lines option is accepted."""
    result = runner.invoke(report_app, ["view", "--lines", "20"])
    assert result.exit_code == 0


def test_view_logs_command_rejects_invalid_lines(mock_log_file):
    """Test: Invalid line count is rejected."""
    result = runner.invoke(report_app, ["view", "--lines", "1000"])
    assert result.exit_code == 1


def test_view_logs_command_rejects_zero_lines(mock_log_file):
    """Test: Zero lines is rejected."""
    result = runner.invoke(report_app, ["view", "--lines", "0"])
    assert result.exit_code == 1


# ── Test command help ────────────────────────────────────────────────────────

def test_report_command_help():
    """Test: Report command has help."""
    result = runner.invoke(report_app, ["--help"])
    assert result.exit_code == 0
    assert "report" in result.stdout.lower() or "error" in result.stdout.lower()


def test_submit_command_help():
    """Test: Submit subcommand has help."""
    result = runner.invoke(report_app, ["submit", "--help"])
    assert result.exit_code == 0
    assert "submit" in result.stdout.lower() or "report" in result.stdout.lower()


def test_view_command_help():
    """Test: View subcommand has help."""
    result = runner.invoke(report_app, ["view", "--help"])
    assert result.exit_code == 0
    assert "view" in result.stdout.lower() or "log" in result.stdout.lower()
