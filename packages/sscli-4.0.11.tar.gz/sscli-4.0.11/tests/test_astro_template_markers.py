"""
Template Marker Smoke Tests: static-landing
============================================

These tests validate that the actual committed static-landing template
source files contain the expected injection markers. If a marker is
missing, injection silently becomes a no-op — these tests catch that
regression before it reaches users.

They do NOT modify any files. They are READ-ONLY validations.

Plan reference: docs/plans/in-progress/001_ASTRO_INJECTION_PLAN.md
"""

import pytest
from pathlib import Path

# ---------------------------------------------------------------------------
# Locate the real template directory
# ---------------------------------------------------------------------------

# Resolve: tests/ -> stack-cli/ -> tooling/ -> foundry-meta/ -> templates/
TEMPLATE_ROOT = (
    Path(__file__).resolve().parent.parent.parent.parent  # foundry-meta/
    / "templates"
    / "static-landing"
)


def _skip_if_missing(path: Path):
    """Pytest skip helper — allow CI without the submodule checked out."""
    if not path.exists():
        pytest.skip(f"static-landing template not found at {path}")


# ---------------------------------------------------------------------------
# index.astro markers
# ---------------------------------------------------------------------------

class TestIndexAstroMarkers:
    """Verify injection markers in src/pages/index.astro."""

    @pytest.fixture(autouse=True)
    def index_file(self):
        f = TEMPLATE_ROOT / "src" / "pages" / "index.astro"
        _skip_if_missing(f)
        self._content = f.read_text(encoding="utf-8")

    def test_commerce_start_marker(self):
        assert "{/* [SS-FEATURE-COMMERCE-START] */}" in self._content, \
            "Commerce START marker missing from index.astro"

    def test_commerce_end_marker(self):
        assert "{/* [SS-FEATURE-COMMERCE-END] */}" in self._content, \
            "Commerce END marker missing from index.astro"

    def test_auth_start_marker(self):
        assert "{/* [SS-FEATURE-AUTH-START] */}" in self._content, \
            "Auth START marker missing from index.astro"

    def test_auth_end_marker(self):
        assert "{/* [SS-FEATURE-AUTH-END] */}" in self._content, \
            "Auth END marker missing from index.astro"

    def test_commerce_marker_precedes_auth(self):
        """Commerce section must appear before auth section in page order."""
        c_pos = self._content.index("{/* [SS-FEATURE-COMMERCE-START] */}")
        a_pos = self._content.index("{/* [SS-FEATURE-AUTH-START] */}")
        assert c_pos < a_pos, \
            "Commerce section must appear before Auth section in index.astro"

    def test_markers_are_balanced(self):
        """Each START marker must have a corresponding END marker."""
        for feature in ("COMMERCE", "AUTH"):
            start_count = self._content.count(f"{{/* [SS-FEATURE-{feature}-START] */}}")
            end_count = self._content.count(f"{{/* [SS-FEATURE-{feature}-END] */}}")
            assert start_count == 1, f"Expected exactly 1 {feature} START marker, got {start_count}"
            assert end_count == 1, f"Expected exactly 1 {feature} END marker, got {end_count}"


# ---------------------------------------------------------------------------
# astro.config.mjs markers
# ---------------------------------------------------------------------------

class TestAstroConfigMarkers:
    """Verify injection markers in astro.config.mjs."""

    @pytest.fixture(autouse=True)
    def config_file(self):
        f = TEMPLATE_ROOT / "astro.config.mjs"
        _skip_if_missing(f)
        self._content = f.read_text(encoding="utf-8")

    def test_sdk_integrations_start_marker(self):
        assert "/* [SS-FEATURE-SDK-INTEGRATIONS-START] */" in self._content, \
            "SDK integrations START marker missing from astro.config.mjs"

    def test_sdk_integrations_end_marker(self):
        assert "/* [SS-FEATURE-SDK-INTEGRATIONS-END] */" in self._content, \
            "SDK integrations END marker missing from astro.config.mjs"

    def test_markers_are_inside_integrations_array(self):
        """The SDK markers must live within the integrations: [...] array."""
        integrations_pos = self._content.find("integrations:")
        start_marker_pos = self._content.find("/* [SS-FEATURE-SDK-INTEGRATIONS-START] */")
        assert integrations_pos != -1, "Could not find integrations: array in astro.config.mjs"
        assert start_marker_pos > integrations_pos, \
            "SDK integrations marker must appear after 'integrations:' declaration"


# ---------------------------------------------------------------------------
# themes.css markers
# ---------------------------------------------------------------------------

class TestThemesCssMarkers:
    """Verify injection markers in src/styles/themes.css."""

    @pytest.fixture(autouse=True)
    def themes_file(self):
        f = TEMPLATE_ROOT / "src" / "styles" / "themes.css"
        _skip_if_missing(f)
        self._content = f.read_text(encoding="utf-8")

    def test_themes_start_marker(self):
        assert "/* [SS-FEATURE-THEMES-START] */" in self._content, \
            "Themes START marker missing from themes.css"

    def test_themes_end_marker(self):
        assert "/* [SS-FEATURE-THEMES-END] */" in self._content, \
            "Themes END marker missing from themes.css"

    def test_base_root_token_preserved(self):
        """:root with base palette must be present (essential for all themes)."""
        assert ":root {" in self._content, \
            "Base :root block missing from themes.css"

    def test_markers_are_balanced(self):
        start_count = self._content.count("/* [SS-FEATURE-THEMES-START] */")
        end_count = self._content.count("/* [SS-FEATURE-THEMES-END] */")
        assert start_count == 1, f"Expected 1 THEMES START marker, got {start_count}"
        assert end_count == 1, f"Expected 1 THEMES END marker, got {end_count}"


# ---------------------------------------------------------------------------
# Vault file completeness
# ---------------------------------------------------------------------------

class TestVaultCompleteness:
    """Verify that required vault feature files exist in features/landing/."""

    @pytest.fixture(autouse=True)
    def vault_root(self):
        # Navigate: tests/ -> stack-cli/ -> tooling/ -> foundry-meta/ -> features/
        r = Path(__file__).resolve().parent.parent.parent.parent / "features" / "landing"
        self._vault = r

    def test_commerce_pricing_exists(self):
        f = self._vault / "commerce" / "pricing.astro"
        if not self._vault.exists():
            pytest.skip("features/landing vault not found")
        assert f.exists(), f"pricing.astro missing from vault at {f}"

    def test_commerce_integrations_exists(self):
        f = self._vault / "commerce" / "astro.integrations.mjs"
        if not self._vault.exists():
            pytest.skip("features/landing vault not found")
        assert f.exists(), f"astro.integrations.mjs missing from vault at {f}"

    def test_auth_section_exists(self):
        f = self._vault / "auth" / "auth-section.astro"
        if not self._vault.exists():
            pytest.skip("features/landing vault not found")
        assert f.exists(), f"auth-section.astro missing from vault at {f}"

    def test_pricing_has_section_element(self):
        f = self._vault / "commerce" / "pricing.astro"
        if not f.exists():
            pytest.skip("pricing.astro not found")
        assert "<section" in f.read_text(encoding="utf-8"), \
            "pricing.astro must contain at least one <section> element"

    def test_auth_has_section_element(self):
        f = self._vault / "auth" / "auth-section.astro"
        if not f.exists():
            pytest.skip("auth-section.astro not found")
        assert "<section" in f.read_text(encoding="utf-8"), \
            "auth-section.astro must contain at least one <section> element"
