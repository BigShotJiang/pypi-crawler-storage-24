import pytest
from pathlib import Path
from foundry.commands.advisor import (
    check_dockerfile,
    check_env_files,
    check_docker_compose,
    check_ci,
    analyze_project,
    Finding,
)


def test_missing_dockerfile_is_critical(tmp_path):
    findings = check_dockerfile(tmp_path)
    assert any(f.severity == "critical" for f in findings)


def test_dockerfile_without_healthcheck_is_warning(tmp_path):
    (tmp_path / "Dockerfile").write_text("FROM python:3.12-slim\nCMD python app.py")
    findings = check_dockerfile(tmp_path)
    assert any("HEALTHCHECK" in f.title for f in findings)


def test_dockerfile_with_healthcheck_passes(tmp_path):
    (tmp_path / "Dockerfile").write_text(
        "FROM python:3.12-slim\nHEALTHCHECK CMD curl http://localhost/health\nCMD python app.py"
    )
    findings = check_dockerfile(tmp_path)
    assert not any("HEALTHCHECK" in f.title for f in findings)


def test_env_not_in_gitignore_is_critical(tmp_path):
    (tmp_path / ".env").write_text("SECRET=abc")
    (tmp_path / ".gitignore").write_text("node_modules/")
    findings = check_env_files(tmp_path)
    assert any(f.severity == "critical" for f in findings)


def test_env_in_gitignore_passes(tmp_path):
    (tmp_path / ".env").write_text("SECRET=abc")
    (tmp_path / ".gitignore").write_text(".env\nnode_modules/")
    findings = check_env_files(tmp_path)
    assert not any("gitignore" in f.title.lower() for f in findings)


def test_no_github_actions_is_warning(tmp_path):
    findings = check_ci(tmp_path)
    assert any("CI" in f.title for f in findings)


def test_analyze_project_aggregates_all_checkers(tmp_path):
    findings = analyze_project(tmp_path)
    categories = {f.category for f in findings}
    assert "docker" in categories
