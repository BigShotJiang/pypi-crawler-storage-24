# FILE: tests/test_commands_internals_comprehensive.py
"""Comprehensive tests for foundry/commands/internals.py"""

import pytest
import typer
from pathlib import Path
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_report(total: int = 5, failures: int = 0, json_path: str = "/out/report.json", md_path: str = "/out/report.md"):
    return {
        "report": {
            "summary": {
                "total_events": total,
                "failure_events": failures,
            }
        },
        "json_path": json_path,
        "markdown_path": md_path,
    }


# ---------------------------------------------------------------------------
# annotate — happy path
# ---------------------------------------------------------------------------

class TestAnnotateHappyPath:
    """annotate completes successfully when session log exists and strict=False."""

    def test_exits_without_error_when_log_exists(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        session_log = log_dir / ".session.log"
        session_log.write_text("log content")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(),
        ), patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            # Should not raise
            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=False,
            )

    def test_calls_generate_internals_report_once(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("ok")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(),
        ) as mock_gen, patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=False,
            )
            mock_gen.assert_called_once()

    def test_resolved_log_passed_to_generate(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        session_log = log_dir / ".session.log"
        session_log.write_text("ok")
        expected_log = session_log.resolve()

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(),
        ) as mock_gen, patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=False,
            )
            call_args = mock_gen.call_args[0]
            assert call_args[0] == expected_log


# ---------------------------------------------------------------------------
# annotate — strict mode
# ---------------------------------------------------------------------------

class TestAnnotateStrictNoFailures:
    """strict=True does NOT raise Exit when failure_events == 0."""

    def test_no_exit_when_zero_failures(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("ok")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(failures=0),
        ), patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            # Must not raise
            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=True,
            )


class TestAnnotateStrictWithFailures:
    """strict=True raises typer.Exit(code=1) when failure_events > 0."""

    def test_raises_exit_code_1_with_failures(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("ok")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(failures=3),
        ), patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            with pytest.raises(typer.Exit) as exc_info:
                annotate(
                    workspace_root=tmp_path,
                    session_log=None,
                    output_dir=None,
                    strict=True,
                )
            assert exc_info.value.exit_code == 1

    def test_raises_for_single_failure(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("ok")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(failures=1),
        ), patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            with pytest.raises(typer.Exit) as exc_info:
                annotate(
                    workspace_root=tmp_path,
                    session_log=None,
                    output_dir=None,
                    strict=True,
                )
            assert exc_info.value.exit_code == 1

    def test_strict_false_does_not_raise_even_with_failures(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("ok")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(failures=99),
        ), patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            # Should NOT raise
            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=False,
            )


# ---------------------------------------------------------------------------
# annotate — explicit session-log
# ---------------------------------------------------------------------------

class TestAnnotateExplicitSessionLog:
    """--session-log pointing to an existing file within workspace resolves correctly."""

    def test_explicit_session_log_resolved_and_passed(self, tmp_path):
        log_file = tmp_path / "my.log"
        log_file.write_text("data")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(),
        ) as mock_gen, patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            annotate(
                workspace_root=tmp_path,
                session_log=log_file,
                output_dir=None,
                strict=False,
            )
            call_args = mock_gen.call_args[0]
            assert call_args[0] == log_file.resolve()

    def test_explicit_log_inside_subdir_is_accepted(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        log_file = sub / "exec.log"
        log_file.write_text("data")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(),
        ), patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            annotate(
                workspace_root=tmp_path,
                session_log=log_file,
                output_dir=None,
                strict=False,
            )


class TestAnnotateExplicitSessionLogMissing:
    """--session-log pointing to a nonexistent file raises typer.BadParameter."""

    def test_missing_explicit_log_raises_bad_parameter(self, tmp_path):
        nonexistent = tmp_path / "ghost.log"

        with patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            with pytest.raises(typer.BadParameter):
                annotate(
                    workspace_root=tmp_path,
                    session_log=nonexistent,
                    output_dir=None,
                    strict=False,
                )


# ---------------------------------------------------------------------------
# annotate — path-outside-root guards
# ---------------------------------------------------------------------------

class TestAnnotateSessionLogOutsideRoot:
    """--session-log that resolves outside workspace root raises typer.BadParameter."""

    def test_outside_root_raises_bad_parameter(self, tmp_path):
        root = tmp_path / "workspace"
        root.mkdir()
        outside_log = tmp_path / "outside.log"
        outside_log.write_text("data")

        with patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            with pytest.raises(typer.BadParameter):
                annotate(
                    workspace_root=root,
                    session_log=outside_log,
                    output_dir=None,
                    strict=False,
                )


class TestAnnotateOutputDirOutsideRoot:
    """--output-dir that resolves outside workspace root raises typer.BadParameter."""

    def test_outside_root_output_dir_raises(self, tmp_path):
        root = tmp_path / "workspace"
        root.mkdir()
        # Create a session log inside the workspace so we get past that check
        log_dir = root / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("ok")

        outside_dir = tmp_path / "outside_output"

        with patch("foundry.commands.internals.console"):
            from foundry.commands.internals import annotate

            with pytest.raises(typer.BadParameter):
                annotate(
                    workspace_root=root,
                    session_log=None,
                    output_dir=outside_dir,
                    strict=False,
                )


# ---------------------------------------------------------------------------
# _resolve_session_log — candidate resolution
# ---------------------------------------------------------------------------

class TestResolveSessionLogDefaultCandidates:
    """First candidate (internal-projects/.session.log) is returned when it exists."""

    def test_returns_first_candidate_when_it_exists(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        first = log_dir / ".session.log"
        first.write_text("first")

        from foundry.commands.internals import _resolve_session_log

        result = _resolve_session_log(tmp_path, None)
        assert result == first

    def test_returns_first_candidate_even_when_second_also_exists(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        first = log_dir / ".session.log"
        first.write_text("first")
        second = tmp_path / ".session.log"
        second.write_text("second")

        from foundry.commands.internals import _resolve_session_log

        result = _resolve_session_log(tmp_path, None)
        assert result == first


class TestResolveSessionLogSecondCandidate:
    """Second candidate (root/.session.log) is returned when first is absent."""

    def test_returns_second_when_first_missing(self, tmp_path):
        second = tmp_path / ".session.log"
        second.write_text("second")

        with patch("foundry.commands.internals.console"):
            from foundry.commands.internals import _resolve_session_log

            result = _resolve_session_log(tmp_path, None)
        assert result == second


class TestResolveSessionLogNoneFound:
    """When neither candidate exists, raises typer.Exit(code=1)."""

    def test_raises_exit_when_no_candidates(self, tmp_path):
        with patch("foundry.commands.internals.console"):
            from foundry.commands.internals import _resolve_session_log

            with pytest.raises(typer.Exit) as exc_info:
                _resolve_session_log(tmp_path, None)
            assert exc_info.value.exit_code == 1

    def test_raises_even_when_internal_projects_dir_exists_but_log_missing(self, tmp_path):
        (tmp_path / "internal-projects").mkdir()

        with patch("foundry.commands.internals.console"):
            from foundry.commands.internals import _resolve_session_log

            with pytest.raises(typer.Exit) as exc_info:
                _resolve_session_log(tmp_path, None)
            assert exc_info.value.exit_code == 1


# ---------------------------------------------------------------------------
# _normalize_optional_path
# ---------------------------------------------------------------------------

class TestNormalizeOptionalPathNone:
    """_normalize_optional_path(None) returns None."""

    def test_returns_none_for_none_input(self):
        from foundry.commands.internals import _normalize_optional_path

        assert _normalize_optional_path(None) is None


class TestNormalizeOptionalPathPath:
    """_normalize_optional_path(Path(...)) returns the Path unchanged."""

    def test_returns_path_unchanged(self, tmp_path):
        from foundry.commands.internals import _normalize_optional_path

        p = tmp_path / "some" / "path"
        result = _normalize_optional_path(p)
        assert result == p

    def test_returns_path_object(self, tmp_path):
        from foundry.commands.internals import _normalize_optional_path

        p = tmp_path / "file.txt"
        result = _normalize_optional_path(p)
        assert isinstance(result, Path)


# ---------------------------------------------------------------------------
# _normalize_path
# ---------------------------------------------------------------------------

class TestNormalizePathDefault:
    """_normalize_path returns default when value is None."""

    def test_returns_default_when_none(self):
        from foundry.commands.internals import _normalize_path

        default = Path("/some/default")
        result = _normalize_path(None, default=default)
        assert result == default

    def test_returns_value_when_path_provided(self, tmp_path):
        from foundry.commands.internals import _normalize_path

        p = tmp_path / "given"
        result = _normalize_path(p, default=Path("/ignored"))
        assert result == p

    def test_default_not_used_when_value_given(self, tmp_path):
        from foundry.commands.internals import _normalize_path

        given = tmp_path / "given.log"
        default = tmp_path / "default.log"
        result = _normalize_path(given, default=default)
        assert result != default


# ---------------------------------------------------------------------------
# annotate — output printed
# ---------------------------------------------------------------------------

class TestAnnotateOutputPrinted:
    """console.print is called and includes the success message."""

    def test_success_message_appears_in_panel(self, tmp_path):
        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("log")

        printed_content = []

        def capture_print(obj, *args, **kwargs):
            printed_content.append(str(obj))

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(total=10, failures=0),
        ), patch("foundry.commands.internals.console") as mock_console:
            mock_console.print.side_effect = capture_print

            from foundry.commands.internals import annotate

            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=False,
            )

        mock_console.print.assert_called_once()

    def test_panel_passed_to_console_print(self, tmp_path):
        from rich.panel import Panel

        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("log")

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(),
        ), patch("foundry.commands.internals.console") as mock_console:
            from foundry.commands.internals import annotate

            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=False,
            )

            call_args = mock_console.print.call_args
            # The first positional argument should be a Panel
            assert isinstance(call_args[0][0], Panel)

    def test_panel_contains_success_text(self, tmp_path):
        from rich.panel import Panel
        from io import StringIO
        from rich.console import Console as RichConsole

        log_dir = tmp_path / "internal-projects"
        log_dir.mkdir()
        (log_dir / ".session.log").write_text("log")

        captured_panel = []

        def capture(obj, *a, **kw):
            captured_panel.append(obj)

        with patch(
            "foundry.commands.internals.generate_internals_report",
            return_value=_make_report(total=7, failures=0),
        ), patch("foundry.commands.internals.console") as mock_console:
            mock_console.print.side_effect = capture

            from foundry.commands.internals import annotate

            annotate(
                workspace_root=tmp_path,
                session_log=None,
                output_dir=None,
                strict=False,
            )

        assert len(captured_panel) == 1
        panel = captured_panel[0]
        assert isinstance(panel, Panel)

        # Render the panel to a string buffer and check for key text
        buf = StringIO()
        rc = RichConsole(file=buf, no_color=True, width=120)
        rc.print(panel)
        rendered = buf.getvalue()
        assert "Internal-projects annotation report generated" in rendered
