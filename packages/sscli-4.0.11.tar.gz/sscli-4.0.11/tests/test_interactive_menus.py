from types import SimpleNamespace

import pytest


def _select_sequence(monkeypatch, values, target_module):
    iterator = iter(values)

    def fake_select(*args, **kwargs):
        return SimpleNamespace(ask=lambda: next(iterator))

    monkeypatch.setattr(f"{target_module}.questionary.select", fake_select)


def test_manage_config_menu_runs_actions(monkeypatch):
    called = {"health": 0, "setup": 0}
    monkeypatch.setattr("foundry.interactive_utils.run_health_check", lambda: called.__setitem__("health", called["health"] + 1))
    monkeypatch.setattr("foundry.interactive_utils.run_setup", lambda: called.__setitem__("setup", called["setup"] + 1))
    monkeypatch.setattr("foundry.interactive_utils.pause", lambda: None)

    _select_sequence(
        monkeypatch,
        ["validate", "setup", "Back"],
        "foundry.interactive_utils",
    )

    from foundry.interactive_utils import manage_config_menu

    manage_config_menu()
    assert called["health"] == 1
    assert called["setup"] == 1


def test_interactive_menu_explore_then_exit(monkeypatch):
    called = {"explore": 0, "pause": 0}
    monkeypatch.setattr("foundry.interactive.HAS_ANIMATIONS", False)
    monkeypatch.setattr("foundry.interactive.get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr("foundry.interactive.run_explore", lambda: called.__setitem__("explore", called["explore"] + 1))
    monkeypatch.setattr("foundry.interactive.pause", lambda: called.__setitem__("pause", called["pause"] + 1))

    _select_sequence(monkeypatch, ["explore", "Exit"], "foundry.interactive")

    from foundry.interactive import interactive_menu

    interactive_menu()
    assert called["explore"] == 1
    assert called["pause"] == 1


def test_interactive_menu_login_flow(monkeypatch):
    monkeypatch.setattr("foundry.interactive.HAS_ANIMATIONS", False)
    auth_states = iter([
        {"tier": "free"},
        {"tier": "pro"},
    ])
    monkeypatch.setattr("foundry.interactive.get_current_license_info", lambda: next(auth_states))
    monkeypatch.setattr("foundry.interactive.login_flow", lambda: True)
    monkeypatch.setattr("foundry.interactive.pause", lambda: None)

    _select_sequence(monkeypatch, ["login", "Exit"], "foundry.interactive")

    from foundry.interactive import interactive_menu

    interactive_menu()


def test_interactive_menu_account_and_validation(monkeypatch):
    monkeypatch.setattr("foundry.interactive.HAS_ANIMATIONS", False)
    monkeypatch.setattr("foundry.interactive.get_current_license_info", lambda: {"tier": "pro", "authorized": True})

    seq = iter(["account", "validation", "Exit"])
    monkeypatch.setattr("foundry.interactive.questionary.select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))

    monkeypatch.setattr("foundry.interactive.account_info_menu", lambda auth_info: False)
    called = {"validation": 0, "pause": 0}
    monkeypatch.setattr("foundry.interactive.run_smoke_tests", lambda: called.__setitem__("validation", called["validation"] + 1))
    monkeypatch.setattr("foundry.interactive.pause", lambda: called.__setitem__("pause", called["pause"] + 1))

    from foundry.interactive import interactive_menu
    interactive_menu()
    assert called["validation"] == 1


def test_interactive_menu_observability_and_verification(monkeypatch):
    monkeypatch.setattr("foundry.interactive.HAS_ANIMATIONS", False)
    monkeypatch.setattr("foundry.interactive.get_current_license_info", lambda: {"tier": "pro"})

    seq = iter(["observability", "verification", "Exit"])
    monkeypatch.setattr("foundry.interactive.questionary.select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))

    called = {"obs": 0, "verify": 0, "pause": 0}
    monkeypatch.setattr("foundry.actions.observability_interactive.observability_menu", lambda: called.__setitem__("obs", called["obs"] + 1))
    monkeypatch.setattr("foundry.actions.verification_interactive.verification_menu", lambda: called.__setitem__("verify", called["verify"] + 1))
    monkeypatch.setattr("foundry.interactive.pause", lambda: called.__setitem__("pause", called["pause"] + 1))

    from foundry.interactive import interactive_menu
    interactive_menu()

    assert called["obs"] == 1
    assert called["verify"] == 1
    assert called["pause"] == 2


def test_interactive_menu_animation_fallback(monkeypatch):
    import sys
    import types

    class FakeEngine:
        def __init__(self, fps, console):
            self.console = console

        def play(self, _seq):
            raise Exception("boom")

    class FakeSequence:
        def __init__(self, _items):
            self.items = _items

    class FakeScene:
        def __init__(self, duration=None):
            self.duration = duration

    fake_anim = types.SimpleNamespace(
        AnimationSequence=FakeSequence,
        InteractiveAnimationEngine=FakeEngine,
    )
    fake_scenes = types.SimpleNamespace(
        LogoDisperseAnimation=FakeScene,
        LogoRevealAnimation=FakeScene,
        LogoStaticAnimation=FakeScene,
    )

    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)

    monkeypatch.setattr("foundry.interactive.HAS_ANIMATIONS", True)
    monkeypatch.setattr("foundry.interactive.get_current_license_info", lambda: {"tier": "free"})

    printed = []
    monkeypatch.setattr("foundry.interactive.console.print", lambda msg: printed.append(msg))

    _select_sequence(monkeypatch, ["Exit"], "foundry.interactive")

    from foundry.interactive import interactive_menu
    interactive_menu()

    assert printed
