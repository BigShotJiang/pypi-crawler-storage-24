import sys
from types import SimpleNamespace

import pytest


def test_explore_helpers(monkeypatch):
    from foundry.actions import explore as explore_mod

    assert "Python" in explore_mod._get_template_tech("python-saas")
    assert explore_mod._strip_markup("[bold]X[/bold]") == "X"


def test_run_explore_minimal(monkeypatch):
    from foundry.actions import explore as explore_mod

    monkeypatch.setattr(explore_mod, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(
        explore_mod,
        "get_templates",
        lambda: [SimpleNamespace(name="python-saas"), SimpleNamespace(name="react-client")],
    )
    monkeypatch.setattr(
        explore_mod,
        "get_template_info",
        lambda name: {"tier": "free", "description": "ok", "repo": "x"},
    )
    monkeypatch.setattr(explore_mod.console, "clear", lambda: None)
    monkeypatch.setattr(
        explore_mod.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: "back"),
    )

    explore_mod.run_explore()


def test_show_template_info(monkeypatch):
    from foundry.actions import explore as explore_mod

    monkeypatch.setattr(
        explore_mod,
        "get_template_info",
        lambda name: {"tier": "free", "description": "Desc", "repo": "repo"},
    )
    monkeypatch.setattr(
        explore_mod.questionary,
        "confirm",
        lambda *args, **kwargs: SimpleNamespace(ask=lambda: None),
    )
    printed = []
    monkeypatch.setattr(explore_mod.console, "print", lambda msg: printed.append(msg))

    explore_mod._show_template_info("python-saas")
    assert printed


def test_get_interactive_config_cancel(monkeypatch):
    from foundry.actions import interactive_config as config_mod

    monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(config_mod, "get_templates", lambda: [SimpleNamespace(name="python-saas")])
    monkeypatch.setattr(config_mod, "get_template_info", lambda name: {"tier": "free"})
    monkeypatch.setattr(config_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: "Back"))

    assert config_mod.get_interactive_config() is None


def test_get_interactive_config_cancel_from_menu(monkeypatch):
    from foundry.actions import interactive_config as config_mod

    monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(config_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: "my-app"))
    monkeypatch.setattr(
        config_mod.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: "cancel"),
    )

    result = config_mod.get_interactive_config(template_name="python-saas")
    assert result is None


def test_repo_utils_download_template_internal_dev(tmp_path, monkeypatch):
    from foundry.actions import repo_utils as repo_mod

    template_dir = tmp_path / "python-saas"
    template_dir.mkdir()
    target_dir = tmp_path / "target"

    monkeypatch.setattr(repo_mod, "TEMPLATES_DIR", tmp_path)
    monkeypatch.setattr(repo_mod, "is_internal_dev", lambda: True)
    monkeypatch.setattr(repo_mod.shutil, "copytree", lambda src, dst, **kwargs: None)

    assert repo_mod.download_template("python-saas", {"repo": "x"}, target_dir) is True


def test_repo_utils_download_template_access_denied(tmp_path, monkeypatch):
    from foundry.actions import repo_utils as repo_mod

    monkeypatch.setattr(repo_mod, "TEMPLATES_DIR", tmp_path)
    monkeypatch.setattr(repo_mod, "is_internal_dev", lambda: False)
    monkeypatch.setattr(repo_mod, "get_current_license_info", lambda verify=True: {"tier": "free", "authorized": False})

    assert repo_mod.download_template("python-saas", {"repo": "x"}, tmp_path / "target") is False


def test_repo_utils_handle_clone_error(monkeypatch):
    from foundry.actions import repo_utils as repo_mod

    printed = []
    monkeypatch.setattr(repo_mod.console, "print", lambda msg: printed.append(msg))
    repo_mod.handle_clone_error("403 Forbidden")
    assert printed


def test_run_setup_success(tmp_path, monkeypatch):
    from foundry.actions import setup as setup_mod

    tmpl = tmp_path / "python-saas"
    (tmpl / "bin").mkdir(parents=True)
    (tmpl / "bin" / "setup.py").write_text("print('ok')\n")

    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", tmp_path)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(setup_mod, "TEMPLATE_REGISTRY", {"python-saas": {"tier": "free"}})
    monkeypatch.setattr(setup_mod.subprocess, "check_call", lambda *a, **k: None)
    monkeypatch.setattr(setup_mod.Confirm, "ask", lambda *a, **k: True)

    setup_mod.run_setup()


def test_run_feature_matrix_tests_success(monkeypatch):
    from foundry.actions import verify as verify_mod

    class FakeResult:
        returncode = 0

    monkeypatch.setattr(verify_mod.subprocess, "run", lambda *a, **k: FakeResult())
    assert verify_mod.run_feature_matrix_tests() is True


def test_run_verification_smoke(monkeypatch, tmp_path):
    from foundry.actions import verify as verify_mod

    class FakeVerifier:
        def __init__(self, root_dir):
            self.root_dir = root_dir
        def verify_all(self, include_docker=True):
            return {"x": "y"}

    monkeypatch.setattr(verify_mod, "TemplateVerifier", FakeVerifier)
    monkeypatch.setattr(verify_mod, "generate_reports", lambda results, root_dir: None)
    monkeypatch.setattr(verify_mod, "print_summary", lambda results: 0)

    verify_mod.run_verification(include_docker=False, output_reports=True, include_features=False)


def test_observability_interactive_diff_json(monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: "."))
    monkeypatch.setattr(obs_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: "json"))
    monkeypatch.setattr(obs_mod.console, "print_json", lambda data: None)
    monkeypatch.setattr(obs_mod.console, "print", lambda *a, **k: None)

    def fake_compute_diff(**kwargs):
        return {"success": True}

    monkeypatch.setattr(obs_mod, "compute_diff", fake_compute_diff)

    obs_mod.interactive_diff()


def test_observability_interactive_diff_cancel(monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: None))
    printed = []
    monkeypatch.setattr(obs_mod.console, "print", lambda msg: printed.append(msg))

    obs_mod.interactive_diff()
    assert printed


def test_observability_interactive_diff_colored(monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: "."))
    monkeypatch.setattr(obs_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: "colored"))
    monkeypatch.setattr(obs_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr(obs_mod, "compute_diff", lambda **k: "diff")

    obs_mod.interactive_diff()


def test_verification_interactive_verify_all(monkeypatch):
    from foundry.actions import verification_interactive as ver_mod

    monkeypatch.setattr(
        ver_mod.questionary,
        "checkbox",
        lambda *a, **k: SimpleNamespace(ask=lambda: ["matrix", "tests"]),
    )
    monkeypatch.setattr(ver_mod.console, "print", lambda *a, **k: None)

    ver_mod.interactive_verify_all()


def test_verification_interactive_mount_feature(monkeypatch):
    from foundry.actions import verification_interactive as ver_mod

    monkeypatch.setattr("foundry.utils.is_internal_dev", lambda: True)
    monkeypatch.setattr("foundry.utils.get_templates", lambda: [SimpleNamespace(name="python-saas")])
    monkeypatch.setitem(
        sys.modules,
        "foundry.features",
        SimpleNamespace(AVAILABLE_EXTENSIONS={"commerce": {"templates": ["python-saas"]}}),
    )

    seq = iter(["python-saas", "commerce", ".", True])
    monkeypatch.setattr(ver_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(ver_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(ver_mod.questionary, "confirm", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(ver_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr(ver_mod, "pause", lambda: None)

    monkeypatch.setattr("foundry.actions.development.mount_feature", lambda *a, **k: True)

    ver_mod.interactive_mount_feature()


def test_verification_interactive_matrix_tests(monkeypatch):
    from foundry.actions import verification_interactive as ver_mod

    seq = iter([True, False])
    monkeypatch.setattr(ver_mod.questionary, "confirm", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(ver_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr(ver_mod.Path, "exists", lambda self: True)
    monkeypatch.setattr(ver_mod.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=0))

    ver_mod.interactive_matrix_tests()
