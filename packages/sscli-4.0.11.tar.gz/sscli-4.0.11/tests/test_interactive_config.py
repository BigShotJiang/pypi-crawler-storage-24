"""Comprehensive tests for foundry.actions.interactive_config module."""
import subprocess
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
import pytest


class TestGetGitHubOwners:
    """Test _get_github_owners function."""

    def test_get_github_owners_success(self, monkeypatch):
        """Test successful fetching of GitHub owners."""
        from foundry.actions import interactive_config as config_mod

        def mock_run(cmd, **kwargs):
            if "user/orgs" in cmd:
                return SimpleNamespace(
                    stdout="org1\norg2\n",
                    stderr="",
                    returncode=0
                )
            else:  # user
                return SimpleNamespace(
                    stdout="testuser",
                    stderr="",
                    returncode=0
                )

        monkeypatch.setattr(subprocess, "run", mock_run)
        owners = config_mod._get_github_owners()
        
        assert len(owners) == 3
        assert owners[0].value == "testuser"
        assert owners[1].value == "org1"
        assert owners[2].value == "org2"

    def test_get_github_owners_no_gh_cli(self, monkeypatch):
        """Test when gh CLI is not available."""
        from foundry.actions import interactive_config as config_mod

        def mock_run(cmd, **kwargs):
            raise FileNotFoundError("gh not found")

        monkeypatch.setattr(subprocess, "run", mock_run)
        owners = config_mod._get_github_owners()
        
        assert owners == []

    def test_get_github_owners_command_error(self, monkeypatch):
        """Test when gh CLI command fails."""
        from foundry.actions import interactive_config as config_mod

        def mock_run(cmd, **kwargs):
            raise subprocess.CalledProcessError(1, cmd)

        monkeypatch.setattr(subprocess, "run", mock_run)
        owners = config_mod._get_github_owners()
        
        assert owners == []


class TestTemplateSelection:
    """Test template selection flow."""

    def test_no_templates_available_for_tier(self, monkeypatch):
        """Test when user has no templates available for their tier."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "free"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod, "get_templates", lambda: [])
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        
        result = config_mod.get_interactive_config()
        assert result is None

    def test_template_selection_success(self, monkeypatch):
        """Test successfully selecting a template from the list."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        
        # Mock get_templates to return a list of templates
        mock_template = SimpleNamespace(name="python-saas")
        monkeypatch.setattr(config_mod, "get_templates", lambda: [mock_template])
        monkeypatch.setattr(config_mod, "get_template_info", lambda x: {"tier": "free"})
        
        # User selects python-saas template, then generates
        select_seq = iter(["python-saas", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(select_seq))
        )
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        result = config_mod.get_interactive_config()
        assert result is not None
        assert result["template_name"] == "python-saas"

    def test_template_selection_back_button(self, monkeypatch):
        """Test selecting Back button returns None."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        
        # Mock get_templates to return a list of templates
        mock_template = SimpleNamespace(name="python-saas")
        monkeypatch.setattr(config_mod, "get_templates", lambda: [mock_template])
        monkeypatch.setattr(config_mod, "get_template_info", lambda x: {"tier": "free"})
        
        # User selects "Back"
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: "Back")
        )
        
        result = config_mod.get_interactive_config()
        assert result is None

    def test_template_selection_none(self, monkeypatch):
        """Test when template selection returns None (cancelled)."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        
        mock_template = SimpleNamespace(name="python-saas")
        monkeypatch.setattr(config_mod, "get_templates", lambda: [mock_template])
        monkeypatch.setattr(config_mod, "get_template_info", lambda x: {"tier": "free"})
        
        # User cancels selection (returns None)
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: None)
        )
        
        result = config_mod.get_interactive_config()
        assert result is None


class TestMainMenuNavigation:
    """Test main configuration menu navigation."""

    def test_cancel_from_main_menu(self, monkeypatch):
        """Test selecting Cancel from main menu."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: "cancel")
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is None

    def test_none_from_main_menu(self, monkeypatch):
        """Test returning None from main menu (ESC pressed)."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: None)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is None


class TestFeatureSelection:
    """Test feature selection flows."""

    def test_features_locked_for_free_tier(self, monkeypatch):
        """Test that features are locked for free tier users."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "free"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        seq = iter(["features", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq))
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        # Features should remain False for free tier
        assert result["with_commerce"] is False

    def test_feature_selection_with_none(self, monkeypatch):
        """Test when feature checkbox returns None (cancelled)."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        seq = iter(["features", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq))
        )
        # Checkbox returns None (user cancelled)
        monkeypatch.setattr(
            config_mod.questionary,
            "checkbox",
            lambda *a, **k: SimpleNamespace(ask=lambda: None)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None

    def test_feature_selection_react_client_template(self, monkeypatch):
        """Disabled features stay off while allowed features remain selectable."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        seq = iter(["features", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq))
        )
        # Attempt selecting disabled + allowed features
        monkeypatch.setattr(
            config_mod.questionary,
            "checkbox",
            lambda *a, **k: SimpleNamespace(ask=lambda: ["merchant_dashboard", "commerce", "landing", "auth", "tunnel"])
        )
        
        result = config_mod.get_interactive_config(template_name="react-client")
        assert result is not None
        assert result["with_merchant_dashboard"] is True
        assert result["with_auth"] is True
        assert result["with_tunnel"] is True
        assert result["with_commerce"] is True
        assert result["with_landing"] is True

    def test_feature_selection_python_saas_specific(self, monkeypatch):
        """Disabled Python-specific features stay off while sqlite remains selectable."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        seq = iter(["features", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq))
        )
        # Attempt selecting disabled + allowed features
        monkeypatch.setattr(
            config_mod.questionary,
            "checkbox",
            lambda *a, **k: SimpleNamespace(ask=lambda: ["admin", "sqlite", "ingestor", "auth", "landing"])
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["with_admin"] is True
        assert result["with_sqlite"] is True
        assert result["with_ingestor"] is True
        assert result["with_auth"] is True
        assert result["with_landing"] is True


class TestQualityAndLinting:
    """Test quality and linting configuration."""

    def test_quality_with_ast_injection(self, monkeypatch):
        """Test quality settings with AST injection for pro users."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        seq = iter(["quality", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq))
        )
        # Enable both linters and AST injection
        confirm_seq = iter([True, True])
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(confirm_seq))
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["use_linters"] is True
        assert result["use_ast_injection"] is True

    def test_quality_disable_linters(self, monkeypatch):
        """Test disabling linters."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        seq = iter(["quality", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq))
        )
        # Disable linters
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: False)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["use_linters"] is False


class TestSecretsConfiguration:
    """Test secrets management configuration."""

    def test_secrets_dotenv_strategy(self, monkeypatch):
        """Test dotenv secrets strategy."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        # Menu selections and secrets strategy selection
        menu_seq = iter(["secrets", "dotenv", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(menu_seq))
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert "Dotenv" in result["secrets_strategy"]

    def test_secrets_doppler_strategy(self, monkeypatch):
        """Test doppler secrets strategy."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        # Navigate to secrets menu and select doppler, then generate
        menu_seq = iter(["secrets", "doppler", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(menu_seq))
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert "Doppler" in result["secrets_strategy"]

    def test_secrets_env_only_strategy(self, monkeypatch):
        """Test environment-only secrets strategy."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        # Navigate to secrets menu and select env, then generate
        menu_seq = iter(["secrets", "env", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(menu_seq))
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert "Environment Only" in result["secrets_strategy"]


class TestGitHubConfiguration:
    """Test GitHub repository configuration."""

    def test_github_no_cli_available(self, monkeypatch):
        """Test GitHub config when gh CLI is not available."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        monkeypatch.setattr(config_mod.shutil, "which", lambda cmd: None)
        
        menu_seq = iter(["github", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(menu_seq))
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        # GitHub config should remain None since CLI is unavailable
        assert result["github_config"] is None

    def test_github_config_decline_creation(self, monkeypatch):
        """Test declining GitHub repository creation."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        monkeypatch.setattr(config_mod.shutil, "which", lambda cmd: "/usr/bin/gh")
        
        menu_seq = iter(["github", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(menu_seq))
        )
        # Decline GitHub repo creation
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: False)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["github_config"] is None

    def test_github_config_with_owners_list(self, monkeypatch):
        """Test GitHub config with owner selection from list."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        
        # Mock text inputs: app_name, repo_name, repo_description
        text_seq = iter(["my-app", "my-repo", "My cool project"])
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(text_seq))
        )
        
        monkeypatch.setattr(config_mod.shutil, "which", lambda cmd: "/usr/bin/gh")
        
        # Mock _get_github_owners to return some owners
        from questionary import Choice
        mock_owners = [
            Choice("👤 Personal Account (testuser)", value="testuser"),
            Choice("🏢 Organization (myorg)", value="myorg")
        ]
        monkeypatch.setattr(config_mod, "_get_github_owners", lambda: mock_owners)
        
        # Menu navigation: github -> (owner select) -> (visibility select) -> generate
        select_seq = iter(["github", "testuser", "private", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(select_seq))
        )
        
        # Confirm GitHub repo creation
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: True)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["github_config"] is not None
        assert result["github_config"]["owner"] == "testuser"
        assert result["github_config"]["name"] == "my-repo"
        assert result["github_config"]["visibility"] == "private"

    def test_github_config_without_owners_list(self, monkeypatch):
        """Test GitHub config when no owners are returned (manual entry)."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        
        # Mock text inputs: app_name, manual_owner, repo_name, repo_description
        text_seq = iter(["my-app", "manual-owner", "my-repo", "My cool project"])
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(text_seq))
        )
        
        monkeypatch.setattr(config_mod.shutil, "which", lambda cmd: "/usr/bin/gh")
        
        # Mock _get_github_owners to return empty list
        monkeypatch.setattr(config_mod, "_get_github_owners", lambda: [])
        
        # Menu navigation: github -> (visibility select) -> generate
        select_seq = iter(["github", "public", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(select_seq))
        )
        
        # Confirm GitHub repo creation
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: True)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["github_config"] is not None
        assert result["github_config"]["owner"] == "manual-owner"
        assert result["github_config"]["name"] == "my-repo"
        assert result["github_config"]["visibility"] == "public"

    def test_github_config_update_existing(self, monkeypatch):
        """Test updating existing GitHub configuration."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        
        # Mock text inputs: app_name, owner1, repo1, desc1, owner2, repo2, desc2
        text_seq = iter(["my-app", "owner1", "repo1", "desc1", "owner2", "repo2", "desc2"])
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(text_seq))
        )
        
        monkeypatch.setattr(config_mod.shutil, "which", lambda cmd: "/usr/bin/gh")
        monkeypatch.setattr(config_mod, "_get_github_owners", lambda: [])
        
        # Navigate to github twice, with visibility selections, then generate
        select_seq = iter(["github", "private", "github", "public", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(select_seq))
        )
        
        # Confirm both times
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: True)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["github_config"] is not None
        # Should have updated config from second iteration
        assert result["github_config"]["visibility"] == "public"
        assert result["github_config"]["owner"] == "owner2"


class TestCompleteFlows:
    """Test complete configuration flows."""

    def test_complete_flow_all_features_enabled(self, monkeypatch):
        """Disabled features are filtered out, allowed features continue to work."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: True)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        # Menu navigation: features -> quality -> secrets -> (dotenv choice) -> generate
        menu_seq = iter(["features", "quality", "secrets", "dotenv", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(menu_seq))
        )
        
        # Attempt selecting all features
        monkeypatch.setattr(
            config_mod.questionary,
            "checkbox",
            lambda *a, **k: SimpleNamespace(ask=lambda: ["commerce", "tunnel", "landing", "auth", "admin", "ingestor", "merchant_dashboard", "sqlite"])
        )
        
        # Enable all quality options
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: True)
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["with_commerce"] is True
        assert result["with_landing"] is True
        assert result["with_sqlite"] is True
        assert result["with_tunnel"] is True
        assert result["with_auth"] is True
        assert result["with_admin"] is True
        assert result["with_ingestor"] is True
        assert result["with_merchant_dashboard"] is True
        assert result["use_linters"] is True
        assert result["use_ast_injection"] is True

    def test_multiple_menu_iterations(self, monkeypatch):
        """Test navigating through menu multiple times before generating."""
        from foundry.actions import interactive_config as config_mod

        monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
        monkeypatch.setattr(config_mod, "is_internal_dev", lambda: False)
        monkeypatch.setattr(config_mod.console, "print", lambda *a, **k: None)
        monkeypatch.setattr(
            config_mod.questionary,
            "text",
            lambda *a, **k: SimpleNamespace(ask=lambda: "my-app")
        )
        
        # Navigate through features, quality, secrets (with env choice), then generate
        select_seq = iter(["features", "quality", "secrets", "env", "generate"])
        monkeypatch.setattr(
            config_mod.questionary,
            "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(select_seq))
        )
        
        monkeypatch.setattr(
            config_mod.questionary,
            "checkbox",
            lambda *a, **k: SimpleNamespace(ask=lambda: ["commerce"])
        )
        
        confirm_seq = iter([True, False])
        monkeypatch.setattr(
            config_mod.questionary,
            "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(confirm_seq))
        )
        
        result = config_mod.get_interactive_config(template_name="python-saas")
        assert result is not None
        assert result["with_commerce"] is True
        assert result["use_linters"] is True
        assert result["use_ast_injection"] is False
        assert "Environment Only" in result["secrets_strategy"]
