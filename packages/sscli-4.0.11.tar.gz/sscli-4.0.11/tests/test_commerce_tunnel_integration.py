"""
Integration tests for Commerce + Tunnel feature injection.

Tests Task 046: Generate Python SaaS with both Commerce and Tunnel features.
Validates that the CLI can successfully inject multiple features and the
generated project structure is correct.
"""
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from foundry.actions.generator import run_generator
from foundry.actions.features import inject_features


@pytest.fixture
def mock_template_root(tmp_path):
    """Create a mock template structure with commerce and tunnel features."""
    template_root = tmp_path / "template_root"
    template_root.mkdir()
    
    # Create commerce feature files
    commerce_feature = template_root / "features" / "commerce" / "src"
    (commerce_feature / "core" / "interfaces").mkdir(parents=True)
    (commerce_feature / "infrastructure" / "commerce").mkdir(parents=True)
    (commerce_feature / "ui" / "api").mkdir(parents=True)
    
    # Create commerce Python files
    (commerce_feature / "core" / "interfaces" / "commerce.py").write_text(
        "# Commerce interface\nclass ICommerceProvider:\n    pass\n"
    )
    (commerce_feature / "infrastructure" / "commerce" / "shopify_adapter.py").write_text(
        "# Shopify adapter\nclass ShopifyAdapter:\n    pass\n"
    )
    (commerce_feature / "infrastructure" / "commerce" / "webhook_dedupe.py").write_text(
        "# Webhook deduplication\nclass WebhookDedupe:\n    pass\n"
    )
    (commerce_feature / "infrastructure" / "commerce" / "log_redactor.py").write_text(
        "# PII redaction\nclass LogRedactor:\n    pass\n"
    )
    (commerce_feature / "infrastructure" / "commerce" / "qr_service.py").write_text(
        "# QR code service\nclass QRService:\n    pass\n"
    )
    (commerce_feature / "ui" / "api" / "webhooks.py").write_text(
        "# Webhook endpoints\ndef handle_shopify_webhook():\n    pass\n"
    )
    
    # Create tunnel feature files
    tunnel_feature = template_root / "features" / "tunnel"
    tunnel_feature.mkdir(parents=True)
    (tunnel_feature / ".env.tunnel").write_text("NGROK_AUTHTOKEN=your-token-here\n")
    (tunnel_feature / "docker-compose.override.yml").write_text(
        "version: '3.8'\nservices:\n  tunnel:\n    image: ngrok/ngrok:latest\n"
    )
    
    return template_root


@pytest.fixture
def project_dir(tmp_path):
    """Create a mock project directory."""
    project = tmp_path / "test-project"
    project.mkdir()
    
    # Create basic Python SaaS structure
    (project / "src" / "ui").mkdir(parents=True)
    (project / "src" / "core").mkdir(parents=True)
    (project / "src" / "infrastructure").mkdir(parents=True)
    
    # Create basic files
    (project / ".env.example").write_text("DEBUG=true\n")
    (project / "README.md").write_text("# Test Project\n")
    (project / "docker-compose.yml").write_text("version: '3.8'\nservices:\n  app:\n    image: test\n")
    (project / "pyproject.toml").write_text(
        '[tool.poetry]\nname = "test-project"\nversion = "0.1.0"\n\n[tool.poetry.dependencies]\npython = "^3.9"\n'
    )
    
    return project


class TestCommerceAndTunnelInjection:
    """Test suite for combined commerce and tunnel feature injection."""
    
    def test_inject_commerce_only(self, project_dir, mock_template_root):
        """Test injecting only commerce feature."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=False
            )
        
        # Verify commerce files were injected
        assert (project_dir / "src" / "core" / "interfaces" / "commerce.py").exists()
        assert (project_dir / "src" / "infrastructure" / "commerce" / "shopify_adapter.py").exists()
        assert (project_dir / "src" / "infrastructure" / "commerce" / "webhook_dedupe.py").exists()
        assert (project_dir / "src" / "infrastructure" / "commerce" / "log_redactor.py").exists()
        assert (project_dir / "src" / "ui" / "api" / "webhooks.py").exists()
        
        # Verify environment variables were added
        env_content = (project_dir / ".env.example").read_text()
        assert "SHOPIFY_SHOP_NAME" in env_content
        assert "SHOPIFY_API_KEY" in env_content
        assert "COMMERCE_IDEMPOTENCY_ENABLED" in env_content
        assert "COMMERCE_PII_REDACTION_ENABLED" in env_content
    
    def test_inject_tunnel_only(self, project_dir, mock_template_root):
        """Test injecting only tunnel feature."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=False,
                tunnel=True
            )
        
        # Verify tunnel files were injected
        assert (project_dir / ".env.tunnel").exists()
        assert (project_dir / "docker-compose.override.yml").exists()
        
        # Verify environment variables were added
        env_content = (project_dir / ".env.example").read_text()
        assert "NGROK_AUTHTOKEN" in env_content
        
        # Verify docker-compose was updated
        compose_content = (project_dir / "docker-compose.yml").read_text()
        # Note: Current implementation appends tunnel service if not present
    
    def test_inject_commerce_and_tunnel_together(self, project_dir, mock_template_root):
        """Test injecting both commerce and tunnel features together (Task 046)."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=True
            )
        
        # Verify BOTH sets of files were injected
        # Commerce files
        assert (project_dir / "src" / "core" / "interfaces" / "commerce.py").exists()
        assert (project_dir / "src" / "infrastructure" / "commerce" / "shopify_adapter.py").exists()
        assert (project_dir / "src" / "infrastructure" / "commerce" / "webhook_dedupe.py").exists()
        assert (project_dir / "src" / "ui" / "api" / "webhooks.py").exists()
        
        # Tunnel files
        assert (project_dir / ".env.tunnel").exists()
        assert (project_dir / "docker-compose.override.yml").exists()
        
        # Verify BOTH sets of environment variables
        env_content = (project_dir / ".env.example").read_text()
        assert "SHOPIFY_SHOP_NAME" in env_content
        assert "SHOPIFY_API_KEY" in env_content
        assert "COMMERCE_IDEMPOTENCY_ENABLED" in env_content
        assert "NGROK_AUTHTOKEN" in env_content
    
    def test_commerce_files_content_integrity(self, project_dir, mock_template_root):
        """Test that commerce files maintain their content after injection."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=False
            )
        
        # Verify file contents
        commerce_interface = (project_dir / "src" / "core" / "interfaces" / "commerce.py").read_text()
        assert "ICommerceProvider" in commerce_interface
        
        shopify_adapter = (project_dir / "src" / "infrastructure" / "commerce" / "shopify_adapter.py").read_text()
        assert "ShopifyAdapter" in shopify_adapter
    
    def test_idempotent_injection(self, project_dir, mock_template_root):
        """Test that injecting features twice doesn't break the project."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            # Inject once
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=True
            )
            
            # Get env content after first injection
            env_content_first = (project_dir / ".env.example").read_text()
            
            # Inject again
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=True
            )
            
            # Verify files still exist and content is reasonable
            assert (project_dir / "src" / "core" / "interfaces" / "commerce.py").exists()
            assert (project_dir / ".env.tunnel").exists()
            
            # Verify env vars aren't duplicated
            env_content_second = (project_dir / ".env.example").read_text()
            assert env_content_second.count("SHOPIFY_SHOP_NAME") == 1
            assert env_content_second.count("NGROK_AUTHTOKEN") == 1


class TestGeneratorWithCommerceAndTunnel:
    """Test run_generator with commerce and tunnel features."""
    
    def test_generator_tracks_both_features_in_metadata(self, tmp_path, monkeypatch):
        """Test that both features are tracked in project metadata."""
        monkeypatch.chdir(tmp_path)
        target_path = tmp_path / "commerce-tunnel-app"
        
        with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
             patch("foundry.actions.generator.check_tier_access", return_value=True), \
             patch("foundry.actions.generator.check_feature_tier_access", return_value=True), \
             patch("foundry.actions.generator.download_template", return_value=True), \
             patch("foundry.actions.generator.inject_metadata"), \
             patch("foundry.actions.generator.validate_and_fix_pyproject"), \
             patch("foundry.actions.generator.setup_secrets"), \
             patch("foundry.actions.generator.inject_features") as mock_inject, \
             patch("foundry.actions.generator.regenerate_poetry_lock"), \
             patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
             patch("foundry.actions.generator.shutil.rmtree"):
            
            run_generator(
                template_name="python-saas",
                app_name="commerce-tunnel-app",
                target_dir_name=str(target_path),
                with_commerce=True,
                with_tunnel=True
            )
            
            # Verify inject_features called with correct flags
            mock_inject.assert_called_once()
            args, kwargs = mock_inject.call_args
            assert kwargs.get('with_commerce') or args[2]  # Either in kwargs or positional
            assert kwargs.get('with_tunnel') or args[3]
            
            # Verify metadata tracking
            mock_tracker = mock_tracker_class.return_value
            args, kwargs = mock_tracker.init_project.call_args
            features = kwargs["features"]
            assert "commerce" in features
            assert "tunnel" in features
    
    def test_generator_with_all_features(self, tmp_path, monkeypatch):
        """Test generator with commerce, tunnel, and other features."""
        monkeypatch.chdir(tmp_path)
        target_path = tmp_path / "full-featured-app"
        
        with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
             patch("foundry.actions.generator.check_tier_access", return_value=True), \
             patch("foundry.actions.generator.check_feature_tier_access", return_value=True), \
             patch("foundry.actions.generator.download_template", return_value=True), \
             patch("foundry.actions.generator.inject_metadata"), \
             patch("foundry.actions.generator.validate_and_fix_pyproject"), \
             patch("foundry.actions.generator.setup_secrets"), \
             patch("foundry.actions.generator.inject_features") as mock_inject, \
             patch("foundry.actions.generator.regenerate_poetry_lock"), \
             patch("foundry.actions.generator.MetadataTracker") as mock_tracker_class, \
             patch("foundry.actions.generator.shutil.rmtree"):
            
            run_generator(
                template_name="python-saas",
                app_name="full-featured-app",
                target_dir_name=str(target_path),
                with_commerce=True,
                with_tunnel=True,
                with_admin=True,
                with_sqlite=True
            )
            
            # Verify all features tracked
            mock_tracker = mock_tracker_class.return_value
            args, kwargs = mock_tracker.init_project.call_args
            features = kwargs["features"]
            assert "commerce" in features
            assert "tunnel" in features
            assert "nicegui-admin" in features
            assert "sqlite-local" in features


class TestProjectStructureValidation:
    """Test that generated project has correct structure."""
    
    def test_commerce_hexagonal_architecture(self, project_dir, mock_template_root):
        """Test that commerce follows hexagonal architecture rules."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=False
            )
        
        # Verify hexagonal layers exist
        assert (project_dir / "src" / "core" / "interfaces" / "commerce.py").exists()
        assert (project_dir / "src" / "infrastructure" / "commerce").exists()
        assert (project_dir / "src" / "ui" / "api" / "webhooks.py").exists()
    
    def test_required_commerce_files_present(self, project_dir, mock_template_root):
        """Test all required commerce files from task 046 are present."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=False
            )
        
        required_files = [
            "src/core/interfaces/commerce.py",
            "src/infrastructure/commerce/shopify_adapter.py",
            "src/infrastructure/commerce/webhook_dedupe.py",
            "src/infrastructure/commerce/log_redactor.py",
            "src/ui/api/webhooks.py"
        ]
        
        for file_path in required_files:
            assert (project_dir / file_path).exists(), f"Missing required file: {file_path}"
    
    def test_commerce_gdpr_compliance_files(self, project_dir, mock_template_root):
        """Test that GDPR/PII compliance files are included."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=False
            )
        
        # Check for log redactor (PII redaction)
        assert (project_dir / "src" / "infrastructure" / "commerce" / "log_redactor.py").exists()
        
        # Verify PII redaction flag in env vars
        env_content = (project_dir / ".env.example").read_text()
        assert "COMMERCE_PII_REDACTION_ENABLED" in env_content


class TestCommerceEnvironmentVariables:
    """Test commerce environment variable injection."""
    
    def test_commerce_env_vars_completeness(self, project_dir, mock_template_root):
        """Test all required commerce env vars are added."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=True,
                tunnel=False
            )
        
        env_content = (project_dir / ".env.example").read_text()
        
        required_vars = [
            "SHOPIFY_SHOP_NAME",
            "SHOPIFY_API_KEY",
            "SHOPIFY_API_SECRET",
            "SHOPIFY_ACCESS_TOKEN",
            "COMMERCE_IDEMPOTENCY_ENABLED",
            "COMMERCE_PII_REDACTION_ENABLED",
            "COMMERCE_ADAPTER_TYPE",
            "COMMERCE_REPLAY_PROTECTION_ENABLED"
        ]
        
        for var in required_vars:
            assert var in env_content, f"Missing environment variable: {var}"
    
    def test_tunnel_env_vars(self, project_dir, mock_template_root):
        """Test tunnel environment variables."""
        with patch('foundry.actions.features.FOUNDRY_ROOT', mock_template_root):
            inject_features(
                path=project_dir,
                template="python-saas",
                commerce=False,
                tunnel=True
            )
        
        env_content = (project_dir / ".env.example").read_text()
        assert "NGROK_AUTHTOKEN" in env_content


class TestDryRunMode:
    """Test dry-run mode for commerce and tunnel generation."""
    
    def test_dry_run_with_commerce_and_tunnel(self):
        """Test dry run shows both features without creating files."""
        with patch("foundry.actions.generator.get_template_info", return_value={"tier": "free"}), \
             patch("foundry.actions.generator.check_tier_access", return_value=True), \
             patch("foundry.actions.generator.check_feature_tier_access", return_value=True), \
             patch("foundry.actions.generator.console") as mock_console, \
             patch("foundry.actions.generator.log_event"):
            
            run_generator(
                template_name="python-saas",
                app_name="test-app",
                dry_run=True,
                with_commerce=True,
                with_tunnel=True
            )
            
            # Verify output mentions both features
            calls = [str(c) for c in mock_console.print.call_args_list]
            output = " ".join(calls)
            
            assert "Commerce" in output or "Shopify" in output
            assert "Tunnel" in output or "ngrok" in output


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
