from types import SimpleNamespace
import types
import sys

from foundry import development_experience


def test_development_tools_menu_routes(monkeypatch):
    selections = iter([
        "Check Build Version",
        "Compare Build Differences",
        "Run Development Tests",
        "View Development Info",
        "Back to Main",
    ])

    monkeypatch.setattr(
        development_experience.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(selections)),
    )

    called = {"version": 0, "diff": 0, "tests": 0, "info": 0, "pause": 0}
    monkeypatch.setattr(development_experience, "check_build_version", lambda: called.__setitem__("version", called["version"] + 1))
    monkeypatch.setattr(development_experience, "check_build_differences", lambda: called.__setitem__("diff", called["diff"] + 1))
    monkeypatch.setattr(development_experience, "run_development_tests", lambda: called.__setitem__("tests", called["tests"] + 1))
    monkeypatch.setattr(development_experience, "show_development_info", lambda: called.__setitem__("info", called["info"] + 1))
    monkeypatch.setattr(development_experience, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))

    development_experience.development_tools_menu()

    assert called["version"] == 1
    assert called["diff"] == 1
    assert called["tests"] == 1
    assert called["info"] == 1
    assert called["pause"] == 4


def test_run_development_animated_experience(monkeypatch):
    called = {"menu": 0}

    class FakeEngine:
        def __init__(self, fps, console):
            self.fps = fps
            self.console = console

        def play(self, _seq):
            return None

    class FakeSequence:
        def __init__(self, _items):
            self.items = _items

    class FakeScene:
        def __init__(self, duration=None):
            self.duration = duration

    fake_anim = types.SimpleNamespace(
        AnimationSequence=FakeSequence,
        InteractiveAnimationEngine=FakeEngine,
    )
    fake_scenes = types.SimpleNamespace(
        LogoDisperseAnimation=FakeScene,
        LogoRevealAnimation=FakeScene,
        LogoStaticAnimation=FakeScene,
        ForgeAnimation=FakeScene,
    )

    monkeypatch.setitem(sys.modules, "foundry.animations", fake_anim)
    monkeypatch.setitem(sys.modules, "foundry.animations.scenes", fake_scenes)
    monkeypatch.setattr(development_experience, "development_tools_menu", lambda: called.__setitem__("menu", called["menu"] + 1))
    monkeypatch.setattr(development_experience.console, "print", lambda *_a, **_k: None)

    development_experience.run_development_animated_experience()

    assert called["menu"] == 1
