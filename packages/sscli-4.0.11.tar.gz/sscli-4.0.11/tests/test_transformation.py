"""
Comprehensive tests for foundry.actions.transformation module.

Tests cover:
- TransformationCommand base class
- Dry-run mode execution
- Error handling and rollback
- Output formatting (JSON, stats, diff)
- File output
- TransformationCommandRegistry
- Module-level utility functions
"""

import pytest
import json
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from foundry.actions.transformation import (
    TransformationCommand,
    TransformationCommandRegistry,
    register_command,
    get_command,
    handle_dry_run_output,
)
from foundry.safety.dry_run_engine import DryRunEngine, FileModification


class ConcreteTransformationCommand(TransformationCommand):
    """Concrete implementation for testing."""
    
    def __init__(self, name="test", description="Test command", should_succeed=True):
        super().__init__(name, description)
        self.should_succeed = should_succeed
        self.run_called = False
        self.kwargs_received = {}
    
    def _run_transformation(self, **kwargs) -> bool:
        """Implementation that tracks calls."""
        self.run_called = True
        self.kwargs_received = kwargs
        
        # Simulate dry-run engine usage if dry_run is active
        if self.dry_run_engine:
            self.dry_run_engine.preview_transformation(
                file_path="test.py",
                original_content="original",
                modified_content="modified"
            )
        
        return self.should_succeed


class TestTransformationCommand:
    """Tests for TransformationCommand base class."""
    
    def test_initialization(self):
        """Test command initialization."""
        cmd = ConcreteTransformationCommand(name="refactor", description="Refactor code")
        assert cmd.name == "refactor"
        assert cmd.description == "Refactor code"
        assert cmd.dry_run_engine is None
    
    def test_execute_success_no_dry_run(self, capsys):
        """Test successful execution without dry-run."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        result = cmd.execute(dry_run=False, custom_arg="value")
        
        assert result is True
        assert cmd.run_called is True
        assert cmd.kwargs_received == {"custom_arg": "value"}
        
        captured = capsys.readouterr()
        assert "completed successfully" in captured.out
    
    def test_execute_success_with_dry_run(self, capsys):
        """Test successful execution with dry-run enabled."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        result = cmd.execute(dry_run=True)
        
        assert result is True
        assert cmd.run_called is True
        assert cmd.dry_run_engine is not None
        
        captured = capsys.readouterr()
        assert "DRY-RUN" in captured.out
        assert "Dry-run complete" in captured.out
    
    def test_execute_failure(self, capsys):
        """Test failed execution."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        result = cmd.execute(dry_run=False)
        
        assert result is False
        assert cmd.run_called is True
        
        # Should not show success message
        captured = capsys.readouterr()
        assert "completed successfully" not in captured.out
    
    def test_execute_exception_handling(self, capsys):
        """Test exception handling in execute."""
        cmd = ConcreteTransformationCommand()
        
        # Mock _run_transformation to raise exception
        cmd._run_transformation = Mock(side_effect=RuntimeError("Test error"))
        
        result = cmd.execute(dry_run=False, verbose=False)
        
        assert result is False
        captured = capsys.readouterr()
        assert "failed" in captured.out
        assert "Test error" in captured.out
    
    def test_execute_exception_with_verbose(self, capsys):
        """Test exception handling with verbose mode."""
        cmd = ConcreteTransformationCommand()
        cmd._run_transformation = Mock(side_effect=ValueError("Verbose error"))
        
        result = cmd.execute(dry_run=False, verbose=True)
        
        assert result is False
        captured = capsys.readouterr()
        assert "Verbose error" in captured.out
    
    def test_run_transformation_not_implemented(self):
        """Test that base class _run_transformation raises NotImplementedError."""
        cmd = TransformationCommand(name="base", description="Base command")
        
        with pytest.raises(NotImplementedError, match="Subclasses must implement"):
            cmd._run_transformation()
    
    def test_show_dry_run_output_no_engine(self):
        """Test _show_dry_run_output when engine is None."""
        cmd = ConcreteTransformationCommand()
        # Should return early without error
        cmd._show_dry_run_output()
        assert cmd.dry_run_engine is None
    
    def test_show_dry_run_output_unified_diff(self, tmp_path, capsys):
        """Test dry-run output as unified diff (default)."""
        cmd = ConcreteTransformationCommand()
        cmd.execute(dry_run=True)
        
        # Engine should have been created and used
        captured = capsys.readouterr()
        assert "Summary" in captured.out
    
    def test_show_dry_run_output_json_format(self, capsys):
        """Test dry-run output as JSON."""
        cmd = ConcreteTransformationCommand()
        result = cmd.execute(dry_run=True, json_output=True)
        
        assert result is True
        captured = capsys.readouterr()
        
        # Should contain JSON structure
        assert "{" in captured.out
        assert "Summary" in captured.out
    
    def test_show_dry_run_output_stats_only(self, capsys):
        """Test dry-run output showing only statistics."""
        cmd = ConcreteTransformationCommand()
        result = cmd.execute(dry_run=True, stats_only=True)
        
        assert result is True
        captured = capsys.readouterr()
        # Stats output should not contain "Summary" (stats_only skips summary)
        # but should contain file info
        assert captured.out != ""
    
    def test_show_dry_run_output_with_verbose(self, capsys):
        """Test dry-run output with verbose statistics."""
        cmd = ConcreteTransformationCommand()
        result = cmd.execute(dry_run=True, stats_only=True, verbose=True)
        
        assert result is True
        captured = capsys.readouterr()
        assert captured.out != ""
    
    def test_show_dry_run_output_to_file(self, tmp_path, capsys):
        """Test dry-run output written to file."""
        output_file = tmp_path / "output.txt"
        
        cmd = ConcreteTransformationCommand()
        result = cmd.execute(
            dry_run=True,
            output_file=str(output_file)
        )
        
        assert result is True
        assert output_file.exists()
        
        content = output_file.read_text()
        assert content != ""
        
        captured = capsys.readouterr()
        assert "Output written to" in captured.out


class TestTransformationCommandRegistry:
    """Tests for TransformationCommandRegistry."""
    
    def test_registry_initialization(self):
        """Test registry initialization."""
        registry = TransformationCommandRegistry()
        assert len(registry.list_commands()) == 0
    
    def test_register_and_get_command(self):
        """Test registering and retrieving commands."""
        registry = TransformationCommandRegistry()
        cmd = ConcreteTransformationCommand(name="test", description="Test")
        
        registry.register(cmd)
        
        retrieved = registry.get("test")
        assert retrieved is cmd
        assert retrieved.name == "test"
    
    def test_get_nonexistent_command(self):
        """Test getting a command that doesn't exist."""
        registry = TransformationCommandRegistry()
        result = registry.get("nonexistent")
        assert result is None
    
    def test_list_commands(self):
        """Test listing all registered commands."""
        registry = TransformationCommandRegistry()
        
        cmd1 = ConcreteTransformationCommand(name="refactor", description="Refactor")
        cmd2 = ConcreteTransformationCommand(name="upgrade", description="Upgrade")
        
        registry.register(cmd1)
        registry.register(cmd2)
        
        commands = registry.list_commands()
        assert len(commands) == 2
        assert "refactor" in commands
        assert "upgrade" in commands
    
    def test_register_overwrites_duplicate(self):
        """Test that registering with same name overwrites."""
        registry = TransformationCommandRegistry()
        
        cmd1 = ConcreteTransformationCommand(name="test", description="First")
        cmd2 = ConcreteTransformationCommand(name="test", description="Second")
        
        registry.register(cmd1)
        registry.register(cmd2)
        
        retrieved = registry.get("test")
        assert retrieved is cmd2
        assert retrieved.description == "Second"


class TestModuleLevelFunctions:
    """Tests for module-level registry functions."""
    
    def test_register_and_get_command_global(self):
        """Test global register_command and get_command functions."""
        cmd = ConcreteTransformationCommand(name="global_test", description="Global")
        
        register_command(cmd)
        retrieved = get_command("global_test")
        
        assert retrieved is cmd
        assert retrieved.name == "global_test"
    
    def test_get_nonexistent_command_global(self):
        """Test getting non-existent command from global registry."""
        result = get_command("definitely_does_not_exist_12345")
        assert result is None


class TestHandleDryRunOutput:
    """Tests for handle_dry_run_output utility function."""
    
    def test_handle_dry_run_output_default(self, tmp_path, capsys):
        """Test handle_dry_run_output with default settings (unified diff)."""
        engine = DryRunEngine()
        engine.preview_transformation(
            file_path="test.py",
            original_content="old content\n",
            modified_content="new content\n"
        )
        
        handle_dry_run_output(engine)
        
        captured = capsys.readouterr()
        assert "Summary" in captured.out
        # Should show diff
        assert captured.out != ""
    
    def test_handle_dry_run_output_json(self, capsys):
        """Test handle_dry_run_output with JSON format."""
        engine = DryRunEngine()
        engine.preview_transformation(
            file_path="test.py",
            original_content="old",
            modified_content="new"
        )
        
        handle_dry_run_output(engine, json_format=True)
        
        captured = capsys.readouterr()
        assert "{" in captured.out
        # Should be valid JSON
        output_lines = [line for line in captured.out.split('\n') if line.strip() and not line.startswith('[')]
        json_content = '\n'.join(output_lines).replace('Summary:', '').strip()
        # The first JSON-like output should be parseable
        assert "files" in captured.out or "{" in captured.out
    
    def test_handle_dry_run_output_stats_only(self, capsys):
        """Test handle_dry_run_output with stats only."""
        engine = DryRunEngine()
        engine.preview_transformation(
            file_path="test.py",
            original_content="line1\n",
            modified_content="line1\nline2\n"
        )
        
        handle_dry_run_output(engine, stats_only=True)
        
        captured = capsys.readouterr()
        # Stats mode should not show summary
        assert captured.out != ""
    
    def test_handle_dry_run_output_stats_verbose(self, capsys):
        """Test handle_dry_run_output with verbose stats."""
        engine = DryRunEngine()
        engine.preview_transformation(
            file_path="test.py",
            original_content="old",
            modified_content="new"
        )
        
        handle_dry_run_output(engine, stats_only=True, verbose=True)
        
        captured = capsys.readouterr()
        assert captured.out != ""
    
    def test_handle_dry_run_output_to_file(self, tmp_path, capsys):
        """Test handle_dry_run_output writing to file."""
        output_file = tmp_path / "dry_run_output.txt"
        
        engine = DryRunEngine()
        engine.preview_transformation(
            file_path="test.py",
            original_content="original",
            modified_content="modified"
        )
        
        handle_dry_run_output(engine, output_file=str(output_file))
        
        assert output_file.exists()
        content = output_file.read_text()
        assert content != ""
        
        captured = capsys.readouterr()
        assert "Output written to" in captured.out
    
    def test_handle_dry_run_output_file_with_json(self, tmp_path):
        """Test handle_dry_run_output writing JSON to file."""
        output_file = tmp_path / "output.json"
        
        engine = DryRunEngine()
        engine.preview_transformation(
            file_path="test.py",
            original_content="a",
            modified_content="b"
        )
        
        handle_dry_run_output(
            engine,
            json_format=True,
            output_file=str(output_file)
        )
        
        assert output_file.exists()
        content = output_file.read_text()
        assert "{" in content


class TestEdgeCases:
    """Tests for edge cases and boundary conditions."""
    
    def test_execute_with_all_options(self, tmp_path, capsys):
        """Test execute with all options enabled."""
        output_file = tmp_path / "full_output.txt"
        
        cmd = ConcreteTransformationCommand()
        result = cmd.execute(
            dry_run=True,
            json_output=True,
            stats_only=False,
            output_file=str(output_file),
            verbose=True,
            custom_param="test"
        )
        
        assert result is True
        assert output_file.exists()
        assert cmd.kwargs_received == {"custom_param": "test"}
    
    def test_multiple_commands_in_registry(self):
        """Test registry with multiple commands."""
        registry = TransformationCommandRegistry()
        
        commands = [
            ConcreteTransformationCommand(name=f"cmd{i}", description=f"Command {i}")
            for i in range(5)
        ]
        
        for cmd in commands:
            registry.register(cmd)
        
        assert len(registry.list_commands()) == 5
        
        for i in range(5):
            retrieved = registry.get(f"cmd{i}")
            assert retrieved is not None
            assert retrieved.name == f"cmd{i}"
    
    def test_command_reuse_with_different_modes(self, tmp_path, capsys):
        """Test reusing command instance with different execution modes."""
        cmd = ConcreteTransformationCommand()
        
        # First execution: normal
        result1 = cmd.execute(dry_run=False)
        assert result1 is True
        assert cmd.dry_run_engine is None
        
        # Second execution: dry-run
        result2 = cmd.execute(dry_run=True)
        assert result2 is True
        assert cmd.dry_run_engine is not None
        
        # Third execution: normal again
        cmd.dry_run_engine = None  # Reset
        result3 = cmd.execute(dry_run=False)
        assert result3 is True


class TestIntegrationScenarios:
    """Integration-style tests combining multiple features."""
    
    def test_full_dry_run_workflow(self, tmp_path, capsys):
        """Test complete dry-run workflow from registration to output."""
        # Register command
        cmd = ConcreteTransformationCommand(name="integration", description="Integration test")
        register_command(cmd)
        
        # Retrieve and execute with dry-run
        retrieved = get_command("integration")
        assert retrieved is not None
        
        output_file = tmp_path / "integration_output.txt"
        result = retrieved.execute(
            dry_run=True,
            output_file=str(output_file),
            test_arg="value"
        )
        
        assert result is True
        assert output_file.exists()
        assert retrieved.kwargs_received == {"test_arg": "value"}
    
    def test_error_recovery_workflow(self, capsys):
        """Test error handling and recovery."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        
        # First attempt fails
        result1 = cmd.execute(dry_run=False)
        assert result1 is False
        
        # Fix and retry
        cmd.should_succeed = True
        result2 = cmd.execute(dry_run=False)
        assert result2 is True
    
    def test_dry_run_then_actual_execution(self, capsys):
        """Test pattern of dry-run followed by actual execution."""
        cmd = ConcreteTransformationCommand()
        
        # First: dry-run preview
        dry_result = cmd.execute(dry_run=True, preview_arg="test")
        assert dry_result is True
        assert cmd.dry_run_engine is not None
        
        # Then: actual execution
        cmd.dry_run_engine = None  # Reset for clarity
        actual_result = cmd.execute(dry_run=False, actual_arg="test")
        assert actual_result is True
        assert cmd.dry_run_engine is None
