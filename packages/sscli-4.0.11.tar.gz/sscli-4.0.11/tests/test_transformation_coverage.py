"""
Comprehensive tests for foundry.actions.transformation module.

Tests:
- TransformationCommand base class
- Dry-run mode with DryRunEngine integration
- JSON output formatting
- Stats-only mode
- Output file writing
- Error handling and verbose mode
- Subclass implementation patterns
"""

import pytest
import json
from pathlib import Path
from unittest.mock import patch, MagicMock, mock_open, call
from foundry.actions import transformation as transform_mod
from foundry.actions.transformation import TransformationCommand


class ConcreteTransformationCommand(TransformationCommand):
    """Concrete implementation for testing."""
    
    def __init__(self, **kwargs):
        super().__init__(name="test", description="Test transformation")
        self.run_called = False
        self.run_kwargs = {}
        self.should_succeed = kwargs.get("should_succeed", True)
    
    def _run_transformation(self, **kwargs) -> bool:
        """Test implementation."""
        self.run_called = True
        self.run_kwargs = kwargs
        
        if not self.should_succeed:
            raise Exception("Transformation failed")
        
        # Record some operations for dry-run testing
        if self.dry_run_engine:
            self.dry_run_engine.preview_transformation(
                Path("/test/file.py"),
                "original content",
                "print('hello')",
            )
        
        return self.should_succeed


class TestTransformationCommandInit:
    """Test TransformationCommand initialization."""
    
    def test_init_with_name_and_description(self):
        """Test basic initialization."""
        cmd = ConcreteTransformationCommand()
        
        assert cmd.name == "test"
        assert cmd.description == "Test transformation"
        assert cmd.dry_run_engine is None
    
    def test_init_sets_properties(self):
        """Test that properties are set correctly."""
        cmd = TransformationCommand(name="refactor", description="Refactor code")
        
        assert cmd.name == "refactor"
        assert cmd.description == "Refactor code"
        assert cmd.dry_run_engine is None


class TestTransformationCommandExecute:
    """Test the execute method."""
    
    @patch.object(transform_mod.console, "print")
    def test_execute_normal_mode_success(self, mock_print):
        """Test normal execution without dry-run."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=False, test_arg="value")
        
        assert result is True
        assert cmd.run_called
        assert cmd.run_kwargs == {"test_arg": "value"}
        
        # Should print success message
        print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
        assert any("completed successfully" in str(call_obj).lower() for call_obj in print_calls)
    
    @patch.object(transform_mod.console, "print")
    def test_execute_normal_mode_failure(self, mock_print):
        """Test normal execution that returns False."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        
        # Should not raise, just return False
        try:
            result = cmd.execute(dry_run=False)
        except Exception:
            result = False
        
        # The command should fail
        assert cmd.run_called
    
    @patch.object(transform_mod.console, "print")
    def test_execute_dry_run_mode(self, mock_print):
        """Test execution in dry-run mode."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=True)
        
        assert result is True
        assert cmd.run_called
        assert cmd.dry_run_engine is not None
        
        # Should print dry-run messages
        print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
        assert any("DRY-RUN" in str(call_obj) for call_obj in print_calls)
        assert any("no changes applied" in str(call_obj).lower() for call_obj in print_calls)
    
    @patch.object(transform_mod.console, "print")
    def test_execute_with_verbose(self, mock_print):
        """Test execution with verbose flag."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=False, verbose=True)
        
        assert result is True
        # Verbose should affect error output (tested in error case)
    
    @patch.object(transform_mod.console, "print")
    def test_execute_exception_with_verbose(self, mock_print):
        """Test exception handling with verbose mode."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        
        with patch("traceback.print_exc") as mock_traceback:
            result = cmd.execute(dry_run=False, verbose=True)
            
            # Should print traceback in verbose mode
            # Note: Exception is raised in _run_transformation, so traceback would be called
    
    @patch.object(transform_mod.console, "print")
    def test_execute_passes_kwargs(self, mock_print):
        """Test that kwargs are passed to _run_transformation."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(
            dry_run=False,
            custom_arg="test",
            another_arg=42
        )
        
        assert result is True
        assert cmd.run_kwargs["custom_arg"] == "test"
        assert cmd.run_kwargs["another_arg"] == 42


class TestDryRunIntegration:
    """Test dry-run engine integration."""
    
    @patch.object(transform_mod.console, "print")
    def test_dry_run_creates_engine(self, mock_print):
        """Test that dry-run creates DryRunEngine."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=True)
        
        assert result is True
        assert cmd.dry_run_engine is not None
        assert hasattr(cmd.dry_run_engine, "preview_transformation")
    
    @patch.object(transform_mod.console, "print")
    def test_dry_run_records_operations(self, mock_print):
        """Test that operations are recorded in dry-run mode."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=True)
        
        # The concrete implementation records one operation
        assert result is True
        # Verify operation was recorded (check print output)
        print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
        # Should have some output from dry-run
        assert len(print_calls) > 0
    
    @patch.object(transform_mod.console, "print")
    def test_dry_run_json_output(self, mock_print):
        """Test dry-run with JSON output format."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=True, json_output=True)
        
        assert result is True
        # _show_dry_run_output should be called with json_output=True
    
    @patch.object(transform_mod.console, "print")
    def test_dry_run_stats_only(self, mock_print):
        """Test dry-run with stats-only mode."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=True, stats_only=True)
        
        assert result is True
        # _show_dry_run_output should be called with stats_only=True
    
    @patch.object(transform_mod.console, "print")
    @patch("builtins.open", new_callable=mock_open)
    def test_dry_run_output_file(self, mock_file, mock_print):
        """Test dry-run with output to file."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=True, output_file="/tmp/output.txt")
        
        assert result is True
        # _show_dry_run_output should be called with output_file


class TestShowDryRunOutput:
    """Test the _show_dry_run_output method."""
    
    def test_show_dry_run_output_not_implemented(self):
        """Test that base class _show_dry_run_output is not implemented."""
        # The base TransformationCommand should implement _show_dry_run_output
        # or it should be abstract
        cmd = TransformationCommand(name="test", description="test")
        
        # Since our concrete class doesn't override it, test the behavior
        # This tests the actual implementation in transformation.py


class TestRunTransformation:
    """Test the _run_transformation method."""
    
    def test_run_transformation_not_implemented(self):
        """Test that base class raises NotImplementedError."""
        cmd = TransformationCommand(name="test", description="test")
        
        with pytest.raises(NotImplementedError):
            cmd._run_transformation()
    
    def test_run_transformation_error_message(self):
        """Test the error message from NotImplementedError."""
        cmd = TransformationCommand(name="test", description="test")
        
        with pytest.raises(NotImplementedError) as exc_info:
            cmd._run_transformation()
        
        assert "must implement" in str(exc_info.value).lower()


class TestErrorHandling:
    """Test error handling scenarios."""
    
    @patch.object(transform_mod.console, "print")
    def test_execute_catches_exceptions(self, mock_print):
        """Test that exceptions are caught and reported."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        
        result = cmd.execute(dry_run=False, verbose=False)
        
        # Should return False on exception
        # Check that error was printed
        print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
        # There should be error output
    
    @patch.object(transform_mod.console, "print")
    def test_execute_verbose_traceback(self, mock_print):
        """Test that verbose mode shows traceback."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        
        with patch("traceback.print_exc") as mock_traceback:
            result = cmd.execute(dry_run=False, verbose=True)
            
            # Traceback should be printed in verbose mode
            # (if exception is caught)
    
    @patch.object(transform_mod.console, "print")
    def test_execute_dry_run_with_exception(self, mock_print):
        """Test dry-run mode with exception."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        
        result = cmd.execute(dry_run=True, verbose=False)
        
        # Should still handle exception


class TestSubclassImplementation:
    """Test subclass implementation patterns."""
    
    def test_subclass_can_access_dry_run_engine(self):
        """Test that subclass can access dry_run_engine."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        # Before execute, engine is None
        assert cmd.dry_run_engine is None
        
        # After dry-run execute, engine is available
        cmd.execute(dry_run=True)
        assert cmd.dry_run_engine is not None
    
    def test_subclass_can_record_operations(self):
        """Test that subclass can record operations."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        with patch.object(transform_mod.console, "print"):
            cmd.execute(dry_run=True)
            
            # The ConcreteTransformationCommand records one operation
            assert cmd.dry_run_engine is not None


class TestParameterHandling:
    """Test parameter handling in execute method."""
    
    @patch.object(transform_mod.console, "print")
    def test_all_parameters_accepted(self, mock_print):
        """Test that all documented parameters are accepted."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(
            dry_run=True,
            json_output=True,
            stats_only=False,
            output_file="/tmp/out.txt",
            verbose=True,
            custom_param="test"
        )
        
        assert result is True
    
    @patch.object(transform_mod.console, "print")
    def test_default_parameters(self, mock_print):
        """Test execution with default parameters."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        # Should work with no parameters
        result = cmd.execute()
        
        assert result is True
    
    @patch.object(transform_mod.console, "print")
    def test_boolean_flags(self, mock_print):
        """Test boolean flag parameters."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        # Test various boolean combinations
        result1 = cmd.execute(dry_run=False, verbose=False)
        result2 = cmd.execute(dry_run=True, verbose=True)
        result3 = cmd.execute(dry_run=True, json_output=True, stats_only=True)
        
        assert all([result1, result2, result3])


class TestConsoleOutput:
    """Test console output messages."""
    
    @patch.object(transform_mod.console, "print")
    def test_normal_success_message(self, mock_print):
        """Test success message in normal mode."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        cmd.execute(dry_run=False)
        
        # Should print success message with command name
        print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
        assert any("test" in str(call_obj).lower() for call_obj in print_calls)
        assert any("completed successfully" in str(call_obj).lower() for call_obj in print_calls)
    
    @patch.object(transform_mod.console, "print")
    def test_dry_run_preview_message(self, mock_print):
        """Test preview message in dry-run mode."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        cmd.execute(dry_run=True)
        
        # Should print dry-run preview message
        print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
        assert any("DRY-RUN" in str(call_obj) for call_obj in print_calls)
        assert any("Previewing" in str(call_obj) for call_obj in print_calls)
    
    @patch.object(transform_mod.console, "print")
    def test_dry_run_complete_message(self, mock_print):
        """Test completion message in dry-run mode."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        cmd.execute(dry_run=True)
        
        # Should print dry-run complete message
        print_calls = [str(call_obj) for call_obj in mock_print.call_args_list]
        assert any("complete" in str(call_obj).lower() for call_obj in print_calls)
        assert any("no changes applied" in str(call_obj).lower() for call_obj in print_calls)
    
    @patch.object(transform_mod.console, "print")
    def test_error_message_format(self, mock_print):
        """Test error message format."""
        cmd = ConcreteTransformationCommand(should_succeed=False)
        
        try:
            cmd.execute(dry_run=False, verbose=False)
        except:
            pass
        
        # Should print error message
        # Format: "[red]✗ {name} failed: {error}[/red]"


class TestDocumentation:
    """Test module and class documentation."""
    
    def test_module_docstring(self):
        """Test that module has docstring."""
        assert transform_mod.__doc__ is not None
        assert "transformation" in transform_mod.__doc__.lower()
    
    def test_class_docstring(self):
        """Test that TransformationCommand has docstring."""
        assert TransformationCommand.__doc__ is not None
    
    def test_execute_docstring(self):
        """Test that execute method has docstring."""
        assert TransformationCommand.execute.__doc__ is not None
        assert "dry-run" in TransformationCommand.execute.__doc__.lower()
    
    def test_run_transformation_docstring(self):
        """Test that _run_transformation has docstring."""
        assert TransformationCommand._run_transformation.__doc__ is not None


class TestEdgeCases:
    """Test edge cases and boundary conditions."""
    
    @patch.object(transform_mod.console, "print")
    def test_empty_kwargs(self, mock_print):
        """Test execution with empty kwargs."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute()
        
        assert result is True
        assert cmd.run_kwargs == {}
    
    @patch.object(transform_mod.console, "print")
    def test_none_output_file(self, mock_print):
        """Test with output_file=None."""
        cmd = ConcreteTransformationCommand(should_succeed=True)
        
        result = cmd.execute(dry_run=True, output_file=None)
        
        assert result is True
    
    @patch.object(transform_mod.console, "print")
    def test_special_characters_in_name(self, mock_print):
        """Test command with special characters in name."""
        cmd = TransformationCommand(name="test-cmd_v2.0", description="Test")
        
        # Should not crash
        assert cmd.name == "test-cmd_v2.0"
    
    @patch.object(transform_mod.console, "print")
    def test_empty_description(self, mock_print):
        """Test command with empty description."""
        cmd = TransformationCommand(name="test", description="")
        
        assert cmd.description == ""


class TestIntegrationWithDryRunEngine:
    """Test integration with DryRunEngine."""
    
    @patch.object(transform_mod.console, "print")
    @patch("foundry.actions.transformation.DryRunEngine")
    def test_dry_run_engine_instantiation(self, mock_engine_class, mock_print):
        """Test that DryRunEngine is instantiated correctly."""
        mock_engine = MagicMock()
        mock_engine_class.return_value = mock_engine
        
        cmd = ConcreteTransformationCommand(should_succeed=True)
        cmd.execute(dry_run=True)
        
        # Should instantiate DryRunEngine
        mock_engine_class.assert_called_once()
