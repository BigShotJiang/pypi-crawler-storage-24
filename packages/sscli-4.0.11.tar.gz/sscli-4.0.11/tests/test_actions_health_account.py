"""
Coverage tests for:
  - foundry/actions/health.py      (run_health_check)
  - foundry/actions/account_info.py (show_account_info, account_info_menu)
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest


# ===========================================================================
# run_health_check
# ===========================================================================

class TestRunHealthCheck:
    """Tests for foundry/actions/health.py::run_health_check."""

    def _run(self, monkeypatch, tmp_path):
        import foundry.actions.health as health_mod

        monkeypatch.setattr(health_mod, "TEMPLATES_DIR", tmp_path)
        printed = []
        monkeypatch.setattr(health_mod.console, "print", lambda m: printed.append(m))
        health_mod.run_health_check()
        return printed

    def test_empty_templates_dir_still_runs(self, tmp_path, monkeypatch):
        """No template directories → health check completes without crashing."""
        msgs = self._run(monkeypatch, tmp_path)
        assert msgs  # Panel is still printed

    def test_template_with_all_required_files(self, tmp_path, monkeypatch):
        """Template with Dockerfile, .gitignore, RUNBOOK.md, .env.example passes checks."""
        tmpl = tmp_path / "python-saas"
        tmpl.mkdir()
        for f in ["Dockerfile", ".gitignore", "RUNBOOK.md", ".env.example"]:
            (tmpl / f).write_text(f"# {f}")
        # Add a bin/setup.py too
        bin_dir = tmpl / "bin"
        bin_dir.mkdir()
        (bin_dir / "setup.sh").write_text("#!/bin/bash")

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs

    def test_template_missing_dockerfile(self, tmp_path, monkeypatch):
        """Template without Dockerfile emits a '✘ Missing Dockerfile' indicator."""
        tmpl = tmp_path / "python-saas"
        tmpl.mkdir()
        (tmpl / ".gitignore").write_text("*.pyc")
        (tmpl / "RUNBOOK.md").write_text("# Runbook")
        (tmpl / ".env.example").write_text("KEY=VALUE")

        msgs = self._run(monkeypatch, tmp_path)
        # Panel text is inside a rich Panel object — check it was printed at all
        assert msgs

    def test_template_missing_gitignore(self, tmp_path, monkeypatch):
        """If .gitignore is absent, health_check still completes."""
        tmpl = tmp_path / "rails-api"
        tmpl.mkdir()
        (tmpl / "Dockerfile").write_text("FROM ruby:3.2")
        # .gitignore intentionally absent

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs

    def test_template_missing_runbook(self, tmp_path, monkeypatch):
        """If RUNBOOK.md is absent, health_check still completes."""
        tmpl = tmp_path / "react-client"
        tmpl.mkdir()
        (tmpl / "Dockerfile").write_text("FROM node:20")
        (tmpl / ".gitignore").write_text("node_modules/")
        # RUNBOOK.md intentionally absent

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs

    def test_mobile_template_no_env_example_needed(self, tmp_path, monkeypatch):
        """Mobile templates don't require .env.example."""
        tmpl = tmp_path / "mobile-android"
        tmpl.mkdir()
        (tmpl / "Dockerfile").write_text("FROM android:latest")
        (tmpl / ".gitignore").write_text("build/")
        (tmpl / "RUNBOOK.md").write_text("# Runbook")
        # No .env.example — mobile is exempt

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs

    def test_terraform_infra_special_case(self, tmp_path, monkeypatch):
        """terraform-infra is handled separately with main.tf + variables.tf checks."""
        tf = tmp_path / "terraform-infra"
        tf.mkdir()
        (tf / "main.tf").write_text("# main")
        (tf / "variables.tf").write_text("# vars")
        (tf / "RUNBOOK.md").write_text("# Runbook")

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs

    def test_multiple_templates_checked(self, tmp_path, monkeypatch):
        """Multiple templates each get their own node in the tree."""
        for name in ["rails-api", "python-saas"]:
            tmpl = tmp_path / name
            tmpl.mkdir()
            (tmpl / "Dockerfile").write_text("FROM base")

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs

    def test_template_with_setup_script_passes_bin_check(self, tmp_path, monkeypatch):
        """bin/setup* files trigger the 'Setup scripts' passing check."""
        tmpl = tmp_path / "python-saas"
        tmpl.mkdir()
        (tmpl / "Dockerfile").write_text("FROM python:3.12")
        (tmpl / ".gitignore").write_text("__pycache__/")
        (tmpl / "RUNBOOK.md").write_text("# Runbook")
        (tmpl / ".env.example").write_text("SECRET=x")
        bin_dir = tmpl / "bin"
        bin_dir.mkdir()
        (bin_dir / "setup.py").write_text("# setup")

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs

    def test_template_without_bin_dir(self, tmp_path, monkeypatch):
        """No bin/ directory → the setup warning branch is exercised."""
        tmpl = tmp_path / "react-client"
        tmpl.mkdir()
        (tmpl / "Dockerfile").write_text("FROM node:20")
        (tmpl / ".gitignore").write_text("node_modules/")
        (tmpl / "RUNBOOK.md").write_text("# Runbook")
        (tmpl / ".env.example").write_text("API_URL=x")

        msgs = self._run(monkeypatch, tmp_path)
        assert msgs


# ===========================================================================
# show_account_info
# ===========================================================================

class TestShowAccountInfo:
    """Tests for foundry/actions/account_info.py::show_account_info."""

    def test_basic_display_prints_panel(self, monkeypatch):
        """show_account_info prints a panel for a standard auth_info dict."""
        from foundry.actions import account_info as mod

        printed = []
        # console.print() called with 0 args for blank lines, 1 arg for content
        monkeypatch.setattr(mod.console, "print", lambda *a, **kw: printed.append(a[0] if a else ""))

        mod.show_account_info({"tier": "pro", "email": "dev@example.com", "status": "active"})
        assert printed  # At least the panel and surrounding lines

    def test_org_name_included_in_display(self, monkeypatch):
        """show_account_info includes org_name when present."""
        from foundry.actions import account_info as mod

        printed = []
        monkeypatch.setattr(mod.console, "print", lambda *a, **kw: printed.append(a[0] if a else ""))

        # Should not raise; org_name is appended to tier_display inside the table
        mod.show_account_info({
            "tier": "enterprise",
            "email": "corp@example.com",
            "status": "active",
            "org_name": "MegaCorp",
        })
        assert printed

    def test_inactive_status_uses_red_color(self, monkeypatch, capsys):
        """show_account_info uses red styling for inactive accounts."""
        from foundry.actions import account_info as mod

        printed = []
        monkeypatch.setattr(mod.console, "print", lambda *a, **kw: printed.append(a[0] if a else ""))

        mod.show_account_info({"tier": "free", "email": "old@example.com", "status": "inactive"})
        assert printed

    def test_missing_fields_use_defaults(self, monkeypatch):
        """show_account_info handles empty dict with default fallbacks."""
        from foundry.actions import account_info as mod

        printed = []
        monkeypatch.setattr(mod.console, "print", lambda *a, **kw: printed.append(a[0] if a else ""))

        mod.show_account_info({})  # All fields missing → defaults applied
        assert printed


# ===========================================================================
# account_info_menu
# ===========================================================================

class TestAccountInfoMenu:
    """Tests for foundry/actions/account_info.py::account_info_menu."""

    def _patch_show(self, monkeypatch):
        """Silence show_account_info to avoid rich rendering noise."""
        from foundry.actions import account_info as mod
        # console.print() is called with 0 or 1 args — accept *args
        monkeypatch.setattr(mod.console, "print", lambda *a, **kw: None)

    def test_back_to_main_menu_returns_true(self, monkeypatch):
        """Choosing '← Back to Main Menu' returns True."""
        from foundry.actions import account_info as mod

        self._patch_show(monkeypatch)
        monkeypatch.setattr(
            mod.questionary, "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: "← Back to Main Menu"),
        )

        result = mod.account_info_menu({"tier": "free"})
        assert result is True

    def test_refresh_then_back_returns_true(self, monkeypatch):
        """Refreshing account info and then going back returns True."""
        from foundry.actions import account_info as mod

        self._patch_show(monkeypatch)

        seq = iter(["refresh", "← Back to Main Menu"])
        monkeypatch.setattr(
            mod.questionary, "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)),
        )
        refresh_calls = {"n": 0}
        monkeypatch.setattr(
            mod, "get_current_license_info",
            lambda verify=True: (refresh_calls.__setitem__("n", refresh_calls["n"] + 1) or {"tier": "pro"}),
        )

        result = mod.account_info_menu({"tier": "free"})
        assert result is True
        assert refresh_calls["n"] == 1

    def test_refresh_failure_prints_error_and_continues(self, monkeypatch):
        """Exception during refresh prints error but doesn't crash the loop."""
        from foundry.actions import account_info as mod

        msgs = []
        monkeypatch.setattr(mod.console, "print", lambda *a, **kw: msgs.append(a[0] if a else ""))

        seq = iter(["refresh", "← Back to Main Menu"])
        monkeypatch.setattr(
            mod.questionary, "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)),
        )
        monkeypatch.setattr(
            mod, "get_current_license_info",
            lambda verify=True: (_ for _ in ()).throw(RuntimeError("server down")),
        )

        result = mod.account_info_menu({"tier": "free"})
        assert result is True
        assert any("Failed to refresh" in str(m) for m in msgs)

    def test_logout_confirmed_calls_logout_and_returns_false(self, monkeypatch):
        """Confirming logout calls the logout function and returns False."""
        from foundry.actions import account_info as mod

        self._patch_show(monkeypatch)

        monkeypatch.setattr(
            mod.questionary, "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: "logout"),
        )
        monkeypatch.setattr(
            mod.questionary, "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: True),
        )
        logout_calls = {"n": 0}
        monkeypatch.setattr(mod, "logout", lambda: logout_calls.__setitem__("n", logout_calls["n"] + 1))

        result = mod.account_info_menu({"tier": "pro"})
        assert result is False
        assert logout_calls["n"] == 1

    def test_logout_cancelled_restarts_loop(self, monkeypatch):
        """Cancelling logout confirmation keeps the user in the loop."""
        from foundry.actions import account_info as mod

        self._patch_show(monkeypatch)

        # First: logout choice → cancel, then back to main
        seq = iter(["logout", "← Back to Main Menu"])
        monkeypatch.setattr(
            mod.questionary, "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)),
        )
        monkeypatch.setattr(
            mod.questionary, "confirm",
            lambda *a, **k: SimpleNamespace(ask=lambda: False),
        )
        logout_calls = {"n": 0}
        monkeypatch.setattr(mod, "logout", lambda: logout_calls.__setitem__("n", logout_calls["n"] + 1))

        result = mod.account_info_menu({"tier": "free"})
        assert result is True
        assert logout_calls["n"] == 0  # Logout was cancelled — never called

    def test_menu_uses_questionary_style(self, monkeypatch):
        """account_info_menu passes QUESTIONARY_STYLE to questionary.select."""
        from foundry.actions import account_info as mod

        self._patch_show(monkeypatch)

        style_used = {"style": None}

        def fake_select(*args, **kwargs):
            style_used["style"] = kwargs.get("style")
            return SimpleNamespace(ask=lambda: "← Back to Main Menu")

        monkeypatch.setattr(mod.questionary, "select", fake_select)

        mod.account_info_menu({"tier": "alpha"})
        assert style_used["style"] is not None

    def test_questionary_returns_none_for_select(self, monkeypatch):
        """If questionary.select().ask() returns None (Ctrl-C), nothing explodes."""
        from foundry.actions import account_info as mod

        printed = []
        monkeypatch.setattr(mod.console, "print", lambda *a, **kw: printed.append(a[0] if a else ""))

        seq = iter([None, "← Back to Main Menu"])
        monkeypatch.setattr(
            mod.questionary, "select",
            lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)),
        )

        # None choice falls through all if/elif branches → loops again → back
        result = mod.account_info_menu({"tier": "free"})
        assert result is True
