"""
Security tests for injection-safety fixes across all codemod files.

Covers:
  C-1  Ruby InjectRouteCodemod — input validation via _safe_ruby_str
  C-16 Ruby newline rejection in InjectCallCodemod / InjectConstantCodemod
  C-2  Python _check_safe_call_statement dangerous-builtin denylist
  M-5  JS _find_closing_brace — correct depth-tracking (not rfind)
  M-6  TOML RemovePythonDependencyCM — exact name match, not substring
  M-3  CodemodPipeline dry_run never writes the real file
  M-4  BaseCodemod.validate() rejects syntax errors in Python output
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Helpers / shared imports
# ---------------------------------------------------------------------------


def _ruby_route(**kwargs):
    """Factory: build InjectRouteCodemod with safe defaults overridden by kwargs."""
    from foundry.codemods.ruby_codemods import InjectRouteCodemod

    defaults = {
        "http_method": "get",
        "path": "api/v1/users",
        "controller_action": "users#index",
    }
    defaults.update(kwargs)
    return InjectRouteCodemod(**defaults)


# ===========================================================================
# C-1  Ruby InjectRouteCodemod — injection prevention via _safe_ruby_str
# ===========================================================================


class TestRubyInjectRouteC1:
    """C-1: Inputs with shell-injection characters must be rejected at construction."""

    def test_injection_in_http_method_raises(self):
        """http_method with shell metacharacters raises ValueError."""
        with pytest.raises(ValueError, match="Unsafe Ruby codemod input"):
            _ruby_route(http_method="GET'; system('id') #")

    def test_semicolon_in_path_raises(self):
        """path containing ';' (injection char) raises ValueError."""
        with pytest.raises(ValueError):
            _ruby_route(path="valid/path'; DROP TABLE users; --")

    def test_path_traversal_raises(self):
        """path traversal pattern ('..') raises ValueError."""
        with pytest.raises(ValueError):
            _ruby_route(path="../../etc/passwd")

    def test_injection_in_controller_action_raises(self):
        """controller_action with shell chars raises ValueError."""
        with pytest.raises(ValueError):
            _ruby_route(controller_action="users#index\nrm -rf /")

    def test_clean_inputs_succeed(self):
        """Legitimate values must not raise."""
        route = _ruby_route(
            http_method="get",
            path="api/v1/users",
            controller_action="users#index",
        )
        assert route.http_method == "get"
        assert route.path == "api/v1/users"
        assert route.controller_action == "users#index"

    def test_clean_inputs_with_namespace_succeed(self):
        """Namespace variant with clean inputs must not raise."""
        route = _ruby_route(
            http_method="post",
            path="webhooks/shopify",
            controller_action="webhooks/shopify#handle",
            namespace="admin",
        )
        assert route.namespace == "admin"


# ===========================================================================
# C-16 Ruby newline rejection
# ===========================================================================


class TestRubyNewlineRejectionC16:
    """C-16: Newlines in Ruby codemod string fields must be rejected."""

    def test_call_statement_with_newline_raises(self):
        """InjectCallCodemod rejects call_statement containing \\n."""
        from foundry.codemods.ruby_codemods import InjectCallCodemod

        with pytest.raises(ValueError):
            InjectCallCodemod(call_statement="do_something\nrm -rf /")

    def test_call_statement_with_carriage_return_raises(self):
        """InjectCallCodemod rejects call_statement containing \\r."""
        from foundry.codemods.ruby_codemods import InjectCallCodemod

        with pytest.raises(ValueError):
            InjectCallCodemod(call_statement="do_something\rmalicious")

    def test_constant_value_with_newline_raises(self):
        """InjectConstantCodemod rejects value containing \\n."""
        from foundry.codemods.ruby_codemods import InjectConstantCodemod

        with pytest.raises(ValueError):
            InjectConstantCodemod(name="API_KEY", value="foo\nbar")

    def test_constant_value_with_carriage_return_raises(self):
        """InjectConstantCodemod rejects value containing \\r."""
        from foundry.codemods.ruby_codemods import InjectConstantCodemod

        with pytest.raises(ValueError):
            InjectConstantCodemod(name="TOKEN", value="foo\rbar")

    def test_clean_call_statement_succeeds(self):
        """Clean call statement must be accepted without error."""
        from foundry.codemods.ruby_codemods import InjectCallCodemod

        codemod = InjectCallCodemod(call_statement="config.middleware.use Rack::Cors")
        assert "Rack::Cors" in codemod.call_statement

    def test_clean_constant_value_succeeds(self):
        """Clean constant value must be accepted without error."""
        from foundry.codemods.ruby_codemods import InjectConstantCodemod

        codemod = InjectConstantCodemod(name="MAX_SIZE", value="100")
        assert codemod.name == "MAX_SIZE"


# ===========================================================================
# C-2  Python _check_safe_call_statement — dangerous-builtin denylist
# ===========================================================================


class TestPythonDangerousBuiltinC2:
    """C-2: _check_safe_call_statement must reject dangerous builtins."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from foundry.codemods.python_codemods import _check_safe_call_statement

        self.check = _check_safe_call_statement

    def test_import_via_dunder_raises(self):
        """__import__('os').system('id') is rejected."""
        with pytest.raises(ValueError, match="dangerous pattern"):
            self.check("__import__('os').system('id')")

    def test_eval_raises(self):
        """eval('malicious') is rejected."""
        with pytest.raises(ValueError, match="dangerous pattern"):
            self.check("eval('malicious')")

    def test_exec_raises(self):
        """exec('code') is rejected."""
        with pytest.raises(ValueError, match="dangerous pattern"):
            self.check("exec('code')")

    def test_compile_raises(self):
        """compile(...) is rejected."""
        with pytest.raises(ValueError):
            self.check("compile('code', '<string>', 'exec')")

    def test_os_system_raises(self):
        """os.system(...) is rejected."""
        with pytest.raises(ValueError):
            self.check("os.system('id')")

    def test_subprocess_run_raises(self):
        """subprocess.run(...) is rejected."""
        with pytest.raises(ValueError):
            self.check("subprocess.run(['ls', '-la'])")

    def test_safe_call_passes(self):
        """Legitimate call statement must not raise."""
        self.check("my_module.my_function(arg1, arg2)")

    def test_safe_register_blueprint_passes(self):
        """Flask register_blueprint is safe."""
        self.check("app.register_blueprint(auth_blueprint)")

    def test_safe_db_session_passes(self):
        """DB session add/commit are safe."""
        self.check("db.session.add(user)")


# ===========================================================================
# M-5  JS _find_closing_brace — correct brace matching
# ===========================================================================


class TestJsFindClosingBraceM5:
    """M-5: _find_closing_brace must use depth counting, not rfind."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from foundry.codemods.js_codemods import _find_closing_brace

        self.find = _find_closing_brace

    # ------------------------------------------------------------------
    # basic depth-counting
    # ------------------------------------------------------------------

    def test_simple_function_outer_closing_brace(self):
        """Outer } of nested functions is found at the very end."""
        content = "function outer() { function inner() { return 1; } return 2; }"
        open_pos = content.index("{")
        result = self.find(content, open_pos)
        # The matching } for the outermost { is the last character
        assert result == len(content) - 1

    def test_simple_no_nesting(self):
        """Simple non-nested block: { return 1; }."""
        content = "function f() { return 1; }"
        open_pos = content.index("{")
        result = self.find(content, open_pos)
        assert result == len(content) - 1

    def test_depth_not_rfind(self):
        """For deeply nested content the result must NOT be the last } in the string."""
        # outer { } followed by MORE text containing }
        content = "const a = { x: 1 }; const extra = { y: 2 };"
        open_pos = content.index("{")
        result = self.find(content, open_pos)
        # The first } closes the first {; it must NOT return the last }
        first_close = content.index("}")
        assert result == first_close

    def test_nested_braces_in_string_literal(self):
        """Matching } for outermost { is found correctly even when a string contains }."""
        # Structure: const a = { key: { nested: '}' } }; const b = 42;
        # The } inside the JS string literal must not confuse depth counting.
        content = "const a = { key: { nested: '}' } }; const b = 42;"
        open_pos = content.index("{")  # outer {
        result = self.find(content, open_pos)
        # The correct closing } for the outer { is the } just before ';'
        # i.e., the } at index 33 in the string above.
        expected = content.index("};")  # first "};" → the outer close
        assert result == expected, (
            f"Expected closing brace at {expected} "
            f"(content[{expected}]={content[expected]!r}), "
            f"got {result} (content[{result}]={content[result]!r})"
        )

    def test_unbalanced_returns_minus_one(self):
        """Unbalanced braces return -1."""
        content = "{ unclosed"
        result = self.find(content, 0)
        assert result == -1

    # ------------------------------------------------------------------
    # Integration: InjectCallCodemod inserts before the correct }
    # ------------------------------------------------------------------

    def test_inject_into_nested_function(self, tmp_path: Path):
        """InjectCallCodemod inserts the call before the correct closing brace."""
        from foundry.codemods.js_codemods import InjectCallCodemod

        src = textwrap.dedent("""\
            function main() {
              function inner() {
                doSomething();
              }
              setup();
            }
        """)
        js_file = tmp_path / "app.js"
        js_file.write_text(src, encoding="utf-8")

        codemod = InjectCallCodemod(
            call_statement="app.listen(3000)",
            target_function="main",
        )
        result = codemod.apply(js_file)

        new_content = js_file.read_text(encoding="utf-8")
        # The injected call must appear BEFORE the last line of the file
        # and after inner() block (i.e., it is inside main, not after it).
        assert "app.listen(3000)" in new_content
        listen_idx = new_content.index("app.listen(3000)")
        # The closing } of main() must come AFTER the injected call
        last_brace_idx = new_content.rfind("}")
        assert listen_idx < last_brace_idx


# ===========================================================================
# M-6  TOML RemovePythonDependencyCM — exact match, not substring
# ===========================================================================


class TestTomlExactMatchM6:
    """M-6: Removing a package by name must not accidentally remove longer names."""

    def _make_pyproject(self, deps: list[str], tmp_path: Path) -> Path:
        """Write a minimal pyproject.toml with [project.dependencies]."""
        lines = [
            "[project]",
            'name = "test-project"',
            'version = "0.1.0"',
            "dependencies = [",
        ]
        for dep in deps:
            lines.append(f'  "{dep}",')
        lines.append("]")
        p = tmp_path / "pyproject.toml"
        p.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return p

    def test_removing_requests_does_not_remove_requests_extra(self, tmp_path: Path):
        """Removing 'requests' must leave 'requests-extra' untouched."""
        from foundry.codemods.toml_codemods import RemovePythonDependencyCM

        p = self._make_pyproject(["requests>=2.28", "requests-extra>=1.0"], tmp_path)
        codemod = RemovePythonDependencyCM(dependencies=["requests"])
        result = codemod.apply(p)

        assert result.success
        new_text = p.read_text(encoding="utf-8")
        assert "requests-extra" in new_text, "requests-extra must survive removal of requests"
        assert "requests>=" not in new_text or "requests-extra" in new_text

    def test_removing_flask_does_not_remove_flask_login(self, tmp_path: Path):
        """Removing 'Flask' must leave 'Flask-Login' untouched."""
        from foundry.codemods.toml_codemods import RemovePythonDependencyCM

        p = self._make_pyproject(["Flask>=2.0", "Flask-Login>=0.6"], tmp_path)
        codemod = RemovePythonDependencyCM(dependencies=["Flask"])
        result = codemod.apply(p)

        assert result.success
        new_text = p.read_text(encoding="utf-8")
        assert "Flask-Login" in new_text, "Flask-Login must survive removal of Flask"

    def test_removing_flask_case_insensitive(self, tmp_path: Path):
        """Removal is case-insensitive: 'flask' removes 'Flask>=2.0'."""
        from foundry.codemods.toml_codemods import RemovePythonDependencyCM

        p = self._make_pyproject(["Flask>=2.0", "Flask-Login>=0.6"], tmp_path)
        codemod = RemovePythonDependencyCM(dependencies=["flask"])
        result = codemod.apply(p)

        assert result.success
        new_text = p.read_text(encoding="utf-8")
        # Flask>=2.0 must be gone; Flask-Login must remain
        assert "Flask-Login" in new_text
        # Flask>=2.0 (the bare Flask line) should be removed
        import tomlkit

        doc = tomlkit.parse(new_text)
        deps = [str(d) for d in doc["project"]["dependencies"]]
        from foundry.codemods.toml_codemods import extract_package_name

        dep_names_lower = [extract_package_name(d).lower() for d in deps]
        assert "flask" not in dep_names_lower
        assert "flask-login" in dep_names_lower

    def test_removing_exact_package_removes_it(self, tmp_path: Path):
        """Basic sanity: removing 'pytest' actually removes 'pytest'."""
        from foundry.codemods.toml_codemods import RemovePythonDependencyCM

        p = self._make_pyproject(["pytest>=7.0", "pytest-cov>=4.0"], tmp_path)
        codemod = RemovePythonDependencyCM(dependencies=["pytest"])
        result = codemod.apply(p)

        assert result.success
        new_text = p.read_text(encoding="utf-8")
        assert "pytest-cov" in new_text
        import tomlkit

        doc = tomlkit.parse(new_text)
        deps = [str(d) for d in doc["project"]["dependencies"]]
        from foundry.codemods.toml_codemods import extract_package_name

        dep_names_lower = [extract_package_name(d).lower() for d in deps]
        assert "pytest" not in dep_names_lower
        assert "pytest-cov" in dep_names_lower


# ===========================================================================
# M-3  CodemodPipeline dry_run — never writes the real file
# ===========================================================================


class TestPipelineDryRunM3:
    """M-3: dry_run must leave the original file untouched."""

    def test_dry_run_does_not_modify_file(self, tmp_path: Path):
        """After a dry_run the on-disk content is identical to what was written."""
        from foundry.codemods.base import CodemodPipeline
        from foundry.codemods.toml_codemods import AddPythonDependencyCM

        pyproject = tmp_path / "pyproject.toml"
        original = textwrap.dedent("""\
            [project]
            name = "myapp"
            version = "0.1.0"
            dependencies = []
        """)
        pyproject.write_text(original, encoding="utf-8")

        pipeline = CodemodPipeline()
        pipeline.add(AddPythonDependencyCM(dependencies=["httpx"], version=">=0.24"))

        success = pipeline.execute(pyproject, dry_run=True)

        assert success, "Pipeline should report success even in dry_run"
        on_disk = pyproject.read_text(encoding="utf-8")
        assert on_disk == original, (
            "dry_run must not alter the real file.\n"
            f"Expected:\n{original}\nGot:\n{on_disk}"
        )

    def test_dry_run_still_records_results(self, tmp_path: Path):
        """Pipeline.results is populated even when dry_run=True."""
        from foundry.codemods.base import CodemodPipeline
        from foundry.codemods.toml_codemods import AddPythonDependencyCM

        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            "[project]\nname = \"a\"\nversion = \"0.0.1\"\ndependencies = []\n",
            encoding="utf-8",
        )

        pipeline = CodemodPipeline()
        pipeline.add(AddPythonDependencyCM(dependencies=["rich"]))
        pipeline.execute(pyproject, dry_run=True)

        assert len(pipeline.results) > 0, "results must be recorded in dry_run mode"
        # Each result must carry the real path (not the temp path)
        for r in pipeline.results:
            if r.modified_path is not None:
                assert r.modified_path == pyproject

    def test_wet_run_does_modify_file(self, tmp_path: Path):
        """Sanity: a normal (wet) run DOES modify the file."""
        from foundry.codemods.base import CodemodPipeline
        from foundry.codemods.toml_codemods import AddPythonDependencyCM

        pyproject = tmp_path / "pyproject.toml"
        original = "[project]\nname = \"a\"\nversion = \"0.0.1\"\ndependencies = []\n"
        pyproject.write_text(original, encoding="utf-8")

        pipeline = CodemodPipeline()
        pipeline.add(AddPythonDependencyCM(dependencies=["httpx"], version=">=0.24"))
        pipeline.execute(pyproject, dry_run=False)

        new_content = pyproject.read_text(encoding="utf-8")
        assert new_content != original, "Wet run must modify the file"
        assert "httpx" in new_content


# ===========================================================================
# M-4  BaseCodemod.validate() — rejects Python syntax errors
# ===========================================================================


class TestValidateSyntaxM4:
    """M-4: validate() must return False when 'after' introduces a syntax error."""

    @pytest.fixture
    def codemod(self):
        """Return a concrete BaseCodemod instance (use AddPythonDependencyCM as vehicle)."""
        from foundry.codemods.toml_codemods import AddPythonDependencyCM

        return AddPythonDependencyCM(dependencies=["dummy"])

    VALID_PYTHON = textwrap.dedent("""\
        def foo():
            return 42
    """)

    BROKEN_PYTHON = "def foo( # broken"

    # requires-python uses a hyphen → Python sees subtraction on the LHS,
    # which is a SyntaxError, so ast.parse() will raise and validate() returns True.
    TOML_CONTENT = textwrap.dedent("""\
        [project]
        name = "test"
        requires-python = ">=3.11"
    """)

    # Ruby syntax is definitively invalid Python
    # (bare `def hello` without parens/colon is a SyntaxError).
    RUBY_CONTENT = textwrap.dedent("""\
        def hello
          puts 'world'
        end
    """)

    def test_valid_before_broken_after_returns_false(self, codemod):
        """before=valid Python, after=broken Python → False."""
        result = codemod.validate(self.VALID_PYTHON, self.BROKEN_PYTHON)
        assert result is False

    def test_valid_before_valid_after_returns_true(self, codemod):
        """before=valid Python, after=valid Python → True."""
        after = textwrap.dedent("""\
            def foo():
                return 42

            def bar():
                return "hello"
        """)
        result = codemod.validate(self.VALID_PYTHON, after)
        assert result is True

    def test_toml_before_returns_true(self, codemod):
        """before=TOML (not valid Python) → True (non-Python pass-through)."""
        result = codemod.validate(self.TOML_CONTENT, self.TOML_CONTENT)
        assert result is True

    def test_toml_before_broken_python_after_returns_true(self, codemod):
        """Non-Python 'before' must not trigger Python syntax checking of 'after'."""
        result = codemod.validate(self.TOML_CONTENT, self.BROKEN_PYTHON)
        # before has requires-python (SyntaxError in Python) → skip AST check → True
        assert result is True

    def test_ruby_before_returns_true(self, codemod):
        """Ruby content as 'before' is not valid Python → validate returns True."""
        result = codemod.validate(self.RUBY_CONTENT, self.BROKEN_PYTHON)
        # Ruby 'def hello' (no parens) is a Python SyntaxError → skip check → True
        assert result is True
