import hashlib
import io
import sys
import tarfile
from types import SimpleNamespace

import pytest
import typer


def test_require_git_status_check_force(monkeypatch):
    from foundry.safety import integration as integ

    called = {"ok": False}

    @integ.require_git_status_check()
    def wrapped(force=False):
        called["ok"] = True
        return "done"

    assert wrapped(force=True) == "done"
    assert called["ok"] is True


def test_verify_git_status_failure(monkeypatch):
    from foundry.safety import integration as integ

    class FakeGuard:
        def __init__(self, config=None):
            pass
        def require_clean_status(self):
            raise integ.GitStatusError("dirty")

    monkeypatch.setattr(integ, "GitGuard", FakeGuard)
    with pytest.raises(typer.Exit):
        integ.verify_git_status(force=False)


def test_codemod_safety_context_force():
    from foundry.safety import integration as integ

    with integ.CodemodSafetyContext(force=True) as ctx:
        assert ctx.is_safe is True


def test_get_git_status_display(monkeypatch):
    from foundry.safety import integration as integ

    class FakeGuard:
        def get_status_summary(self):
            return {
                "is_git_repo": True,
                "staged_files": ["a"],
                "unstaged_files": [],
                "untracked_files": ["b"],
                "merge_conflicts": [],
            }

    monkeypatch.setattr(integ, "GitGuard", FakeGuard)
    assert integ.get_git_status_display() == "staged:1,untracked:1"


def test_development_tools_menu(monkeypatch):
    from foundry import development_experience as dev_exp

    seq = iter(["Check Build Version", "Back to Main"])
    monkeypatch.setattr(
        dev_exp.questionary,
        "select",
        lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)),
    )
    called = {"check": 0, "pause": 0}
    monkeypatch.setattr(dev_exp, "check_build_version", lambda: called.__setitem__("check", called["check"] + 1))
    monkeypatch.setattr(dev_exp, "pause", lambda: called.__setitem__("pause", called["pause"] + 1))

    dev_exp.development_tools_menu()
    assert called["check"] == 1


def test_run_development_animated_experience(monkeypatch):
    from foundry import development_experience as dev_exp

    class FakeEngine:
        def __init__(self, fps=60, console=None):
            pass
        def play(self, anim):
            return None

    monkeypatch.setattr(dev_exp, "InteractiveAnimationEngine", FakeEngine)
    monkeypatch.setattr(dev_exp, "AnimationSequence", lambda seq: "intro")
    monkeypatch.setattr(dev_exp, "LogoRevealAnimation", lambda duration=1.0: "reveal")
    monkeypatch.setattr(dev_exp, "LogoStaticAnimation", lambda duration=1.0: "static")
    monkeypatch.setattr(dev_exp, "LogoDisperseAnimation", lambda duration=1.0: "disperse")
    called = {"menu": 0}
    monkeypatch.setattr(dev_exp, "development_tools_menu", lambda: called.__setitem__("menu", called["menu"] + 1))

    dev_exp.run_development_animated_experience()
    assert called["menu"] == 1


def test_codemod_examples_commands(monkeypatch):
    from foundry.actions.examples import codemod_examples as examples

    monkeypatch.setattr(examples, "verify_git_status", lambda force=False: None)
    monkeypatch.setattr(examples.console, "print", lambda *a, **k: None)

    class FakeContext:
        def __init__(self, force=False, allow_untracked=False):
            self.is_safe = True
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc_val, exc_tb):
            return False

    monkeypatch.setattr(examples, "CodemodSafetyContext", FakeContext)

    examples.upgrade_codemod(name="proj", target_version=None, force=True)
    examples.inject_feature(name="proj", feature="auth", force=True)
    examples.migrate_codemod(name="proj", from_version="1", to_version="2", force=True)
    examples.refactor_codemod(name="proj", pattern="x", force=True, dry_run=True)
    examples.validate_codemods(name="proj")
    examples.batch_codemods(name="proj", force=True)


def test_manage_module_imports():
    import foundry.manage as manage_mod
    assert manage_mod.app is not None


def test_examples_module_import():
    from foundry.actions.examples import codemod_app
    assert codemod_app is not None


def test_development_helpers(monkeypatch, tmp_path):
    from foundry.actions import development as dev_mod

    venv = tmp_path / "venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "python").write_text("")
    monkeypatch.setenv("VIRTUAL_ENV", str(venv))
    assert dev_mod.get_venv_path() == venv

    root = tmp_path / "root"
    root.mkdir()
    (root / "pyproject.toml").write_text('name = "sscli"\nversion = "1.2.3"\n')
    monkeypatch.setattr(dev_mod, "FOUNDRY_ROOT", root)
    assert dev_mod.get_stack_cli_root() == root
    assert dev_mod.get_local_version() == "1.2.3"


def test_development_run_build_no_root(monkeypatch):
    from foundry.actions import development as dev_mod

    monkeypatch.setattr(dev_mod, "get_stack_cli_root", lambda: None)
    assert dev_mod.run_build(clean=False) is False


def test_development_run_swap_no_venv(monkeypatch):
    from foundry.actions import development as dev_mod

    monkeypatch.setattr(dev_mod, "get_venv_path", lambda: None)
    assert dev_mod.run_swap(target="local") is False


def test_development_mount_feature_not_internal(monkeypatch, tmp_path):
    from foundry.actions import development as dev_mod

    monkeypatch.setattr(dev_mod, "is_internal_dev", lambda: False)
    assert dev_mod.mount_feature("commerce", "python-saas", str(tmp_path)) is False


def test_interactive_config_feature_selection(monkeypatch):
    from foundry.actions import interactive_config as config_mod

    monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
    monkeypatch.setattr(config_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: "my-app"))

    seq = iter(["features", "generate"])
    monkeypatch.setattr(config_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(
        config_mod.questionary,
        "checkbox",
        lambda *a, **k: SimpleNamespace(ask=lambda: ["commerce", "auth"]),
    )

    result = config_mod.get_interactive_config(template_name="python-saas")
    assert result["with_commerce"] is True
    assert "with_auth" in result
    assert result["with_auth"] is True


def test_interactive_config_quality_secrets(monkeypatch):
    from foundry.actions import interactive_config as config_mod

    monkeypatch.setattr(config_mod, "get_current_license_info", lambda: {"tier": "pro"})
    monkeypatch.setattr(config_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: "my-app"))
    monkeypatch.setattr(config_mod.shutil, "which", lambda cmd: None)

    seq = iter(["quality", "secrets", "dotenv", "github", "generate"])
    monkeypatch.setattr(config_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(config_mod.questionary, "confirm", lambda *a, **k: SimpleNamespace(ask=lambda: True))

    result = config_mod.get_interactive_config(template_name="python-saas")
    assert result["use_linters"] is True
    assert result["use_ast_injection"] is True


def test_observability_interactive_view_metadata(tmp_path, monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    meta = tmp_path / ".sscli-metadata.json"
    meta.write_text("{\"features_injected\": []}")

    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: str(tmp_path)))
    monkeypatch.setattr(obs_mod.console, "print", lambda *a, **k: None)

    obs_mod.interactive_view_metadata()


def test_verify_git_status_success(monkeypatch):
    from foundry.safety import integration as integ

    class FakeGuard:
        def __init__(self, config=None):
            pass
        def require_clean_status(self):
            return None

    monkeypatch.setattr(integ, "GitGuard", FakeGuard)
    integ.verify_git_status(force=False)


def test_codemod_safety_context_failure(monkeypatch):
    from foundry.safety import integration as integ
    import pytest

    class FakeGuard:
        def __init__(self, config=None):
            pass
        def require_clean_status(self):
            raise integ.GitStatusError("dirty")

    monkeypatch.setattr(integ, "GitGuard", FakeGuard)
    with pytest.raises(integ.GitStatusError):
        with integ.CodemodSafetyContext(force=False) as ctx:
            pass


def test_observability_interactive_workspace_list(monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: "."))
    monkeypatch.setattr(obs_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr(obs_mod, "list_workspaces", lambda search_path=None: [{"feature_name": "commerce", "template_name": "python-saas"}])

    obs_mod.interactive_workspace_list()


def test_observability_interactive_workspace_create(monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    seq = iter(["python-saas", "commerce", "./out"])
    monkeypatch.setattr(obs_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(obs_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr("foundry.utils.get_templates", lambda: [SimpleNamespace(name="python-saas")])
    monkeypatch.setitem(
        sys.modules,
        "foundry.features",
        SimpleNamespace(AVAILABLE_EXTENSIONS={"commerce": {"templates": ["python-saas"]}}),
    )
    monkeypatch.setattr(obs_mod, "create_feature_workspace", lambda **k: "./out")

    obs_mod.interactive_workspace_create()


def test_repo_utils_download_template_clone_success(tmp_path, monkeypatch):
    from foundry.actions import repo_utils as repo_mod

    target = tmp_path / "target"
    monkeypatch.setattr(repo_mod, "is_internal_dev", lambda: False)
    monkeypatch.setattr(repo_mod, "get_current_license_info", lambda verify=True: {"tier": "pro", "authorized": True})
    monkeypatch.setattr(repo_mod, "get_access_token", lambda: "token")
    monkeypatch.setattr(repo_mod.console, "print", lambda *a, **k: None)

    archive_bytes = io.BytesIO()
    with tarfile.open(fileobj=archive_bytes, mode="w:gz") as tar:
        content = b"ok"
        info = tarfile.TarInfo(name="README.md")
        info.size = len(content)
        tar.addfile(info, io.BytesIO(content))

    checksum = hashlib.sha256(archive_bytes.getvalue()).hexdigest()

    class FakeResponse:
        status_code = 200
        content = archive_bytes.getvalue()
        text = ""
        headers = {"X-Template-Sha256": checksum, "X-Foundry-User-Id": "1"}

    monkeypatch.setattr(repo_mod.requests, "get", lambda *a, **k: FakeResponse())

    assert repo_mod.download_template("python-saas", {"repo": "https://example.com"}, target) is True


def test_development_run_swap_local_success(tmp_path, monkeypatch):
    from foundry.actions import development as dev_mod

    dist_dir = tmp_path / "dist"
    dist_dir.mkdir()
    (dist_dir / "sscli-1.0.0.whl").write_text("x")
    venv = tmp_path / "venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "python").write_text("")

    monkeypatch.setattr(dev_mod, "get_stack_cli_root", lambda: tmp_path)
    monkeypatch.setattr(dev_mod, "get_venv_path", lambda: venv)
    monkeypatch.setattr(dev_mod, "get_pip_version", lambda: "1.0.0")
    monkeypatch.setattr(dev_mod, "is_using_local", lambda: False)
    monkeypatch.setattr(dev_mod.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=0, stderr=""))
    monkeypatch.setattr(dev_mod.console, "print", lambda *a, **k: None)

    assert dev_mod.run_swap(target="local") is True


def test_development_run_swap_pip_success(tmp_path, monkeypatch):
    from foundry.actions import development as dev_mod

    venv = tmp_path / "venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "python").write_text("")

    monkeypatch.setattr(dev_mod, "get_stack_cli_root", lambda: tmp_path)
    monkeypatch.setattr(dev_mod, "get_venv_path", lambda: venv)
    monkeypatch.setattr(dev_mod, "get_pip_version", lambda: "1.0.0")
    monkeypatch.setattr(dev_mod, "is_using_local", lambda: True)
    monkeypatch.setattr(dev_mod.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=0, stderr=""))
    monkeypatch.setattr(dev_mod.console, "print", lambda *a, **k: None)

    assert dev_mod.run_swap(target="pip") is True


def test_development_mount_feature_unknown(monkeypatch, tmp_path):
    from foundry.actions import development as dev_mod

    monkeypatch.setattr(dev_mod, "is_internal_dev", lambda: True)
    monkeypatch.setattr("foundry.constants.AVAILABLE_EXTENSIONS", {"auth": {}}, raising=False)
    monkeypatch.setattr("foundry.constants.FOUNDRY_ROOT", tmp_path, raising=False)

    assert dev_mod.mount_feature("commerce", "python-saas", str(tmp_path)) is False


def test_development_mount_feature_missing_source(monkeypatch, tmp_path):
    from foundry.actions import development as dev_mod

    monkeypatch.setattr(dev_mod, "is_internal_dev", lambda: True)
    monkeypatch.setattr("foundry.constants.AVAILABLE_EXTENSIONS", {"commerce": {}}, raising=False)
    monkeypatch.setattr("foundry.constants.FOUNDRY_ROOT", tmp_path, raising=False)

    assert dev_mod.mount_feature("commerce", "python-saas", str(tmp_path)) is False


def test_development_mount_feature_success(monkeypatch, tmp_path):
    from foundry.actions import development as dev_mod

    feature_src = tmp_path / "features" / "commerce"
    feature_src.mkdir(parents=True)
    (feature_src / "file.txt").write_text("x")

    target = tmp_path / "project"
    target.mkdir()

    monkeypatch.setattr(dev_mod, "is_internal_dev", lambda: True)
    monkeypatch.setattr("foundry.constants.AVAILABLE_EXTENSIONS", {"commerce": {}}, raising=False)
    monkeypatch.setattr("foundry.constants.FOUNDRY_ROOT", tmp_path, raising=False)
    monkeypatch.setattr(dev_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr(dev_mod.os, "symlink", lambda src, dst: None)

    assert dev_mod.mount_feature("commerce", "python-saas", str(target)) is True


def test_observability_interactive_workspace_list(monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: "."))
    monkeypatch.setattr(obs_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr(obs_mod, "list_workspaces", lambda search_path=None: [{"feature_name": "commerce", "template_name": "python-saas"}])

    obs_mod.interactive_workspace_list()


def test_observability_interactive_workspace_create(monkeypatch):
    from foundry.actions import observability_interactive as obs_mod

    seq = iter(["python-saas", "commerce", "./out"])
    monkeypatch.setattr(obs_mod.questionary, "select", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(obs_mod.questionary, "text", lambda *a, **k: SimpleNamespace(ask=lambda: next(seq)))
    monkeypatch.setattr(obs_mod.console, "print", lambda *a, **k: None)
    monkeypatch.setattr("foundry.utils.get_templates", lambda: [SimpleNamespace(name="python-saas")])
    monkeypatch.setitem(
        sys.modules,
        "foundry.features",
        SimpleNamespace(AVAILABLE_EXTENSIONS={"commerce": {"templates": ["python-saas"]}}),
    )
    monkeypatch.setattr(obs_mod, "create_feature_workspace", lambda **k: "./out")

    obs_mod.interactive_workspace_create()


def test_repo_utils_initialize_github_repo_not_authed(tmp_path, monkeypatch):
    from foundry.actions import repo_utils as repo_mod

    class FakeResult:
        def __init__(self, returncode=1, stderr="err"):
            self.returncode = returncode
            self.stderr = stderr
            self.stdout = ""

    def fake_run(*args, **kwargs):
        return FakeResult(returncode=1)

    monkeypatch.setattr(repo_mod.subprocess, "run", fake_run)
    monkeypatch.setattr(repo_mod.console, "print", lambda *a, **k: None)

    assert repo_mod.initialize_github_repo(tmp_path, {"name": "repo"}) is False


def test_repo_utils_download_template_missing_repo(tmp_path, monkeypatch):
    from foundry.actions import repo_utils as repo_mod

    monkeypatch.setattr(repo_mod, "is_internal_dev", lambda: False)
    monkeypatch.setattr(repo_mod, "get_current_license_info", lambda verify=True: {"tier": "pro", "authorized": True})
    monkeypatch.setattr(repo_mod, "get_access_token", lambda: "token")

    class FakeResponse:
        status_code = 404
        content = b""
        text = "not found"
        headers = {}

    monkeypatch.setattr(repo_mod.requests, "get", lambda *a, **k: FakeResponse())

    assert repo_mod.download_template("python-saas", {"repo": None}, tmp_path / "t") is False


def test_repo_utils_download_template_missing_token(tmp_path, monkeypatch):
    from foundry.actions import repo_utils as repo_mod

    monkeypatch.setattr(repo_mod, "is_internal_dev", lambda: False)
    monkeypatch.setattr(repo_mod, "get_current_license_info", lambda verify=True: {"tier": "pro", "authorized": True})
    monkeypatch.setattr(repo_mod, "get_access_token", lambda: None)

    assert repo_mod.download_template("python-saas", {"repo": "https://example.com"}, tmp_path / "t") is False


def test_setup_blocks_pro_templates(tmp_path, monkeypatch):
    from foundry.actions import setup as setup_mod

    tmpl = tmp_path / "python-saas"
    tmpl.mkdir()

    monkeypatch.setattr(setup_mod, "TEMPLATES_DIR", tmp_path)
    monkeypatch.setattr(setup_mod, "get_current_license_info", lambda: {"tier": "free"})
    monkeypatch.setattr(setup_mod, "TEMPLATE_REGISTRY", {"python-saas": {"tier": "pro"}})
    monkeypatch.setattr(setup_mod.console, "print", lambda *a, **k: None)

    setup_mod.run_setup()


def test_development_run_build_success(tmp_path, monkeypatch):
    from foundry.actions import development as dev_mod

    (tmp_path / "dist").mkdir()
    (tmp_path / "dist" / "sscli-1.0.0.whl").write_text("x")

    monkeypatch.setattr(dev_mod, "get_stack_cli_root", lambda: tmp_path)
    monkeypatch.setattr(dev_mod.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=0, stderr=""))
    monkeypatch.setattr(dev_mod.console, "print", lambda *a, **k: None)

    assert dev_mod.run_build(clean=False) is True


def test_development_show_status_verbose(tmp_path, monkeypatch):
    from foundry.actions import development as dev_mod

    (tmp_path / "requirements.txt").write_text("x\n")
    monkeypatch.setattr(dev_mod, "get_stack_cli_root", lambda: tmp_path)
    monkeypatch.setattr(dev_mod, "get_venv_path", lambda: tmp_path)
    monkeypatch.setattr(dev_mod, "get_local_version", lambda: "1.0.0")
    monkeypatch.setattr(dev_mod, "get_pip_version", lambda: "")
    monkeypatch.setattr(dev_mod, "is_using_local", lambda: True)
    monkeypatch.setattr(dev_mod.console, "print", lambda *a, **k: None)

    assert dev_mod.show_status(verbose=True) is True
