"""
Comprehensive tests for Ruby and JS codemods to increase coverage.

Targets:
- foundry/codemods/ruby_codemods.py (from 56% to ~90%)
- foundry/codemods/js_codemods.py (from 74% to ~90%)

Focuses on:
- All codemod types (inject tests for each variant)
- Fallback chain testing (Synvert → ast-grep → string)
- Error handling and edge cases
- Utility functions
"""

import subprocess
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch

import pytest

from foundry.codemods.base import ModificationResult
from foundry.codemods.ruby_codemods import (
    RubyCodemod,
    InjectRouteCodemod as RubyRouteCodemod,
    InjectCallCodemod as RubyCallCodemod,
    InjectConstantCodemod as RubyConstantCodemod,
)
from foundry.codemods.js_codemods import (
    JsCodemod,
    InjectImportCodemod,
    InjectRouteCodemod,
    InjectCallCodemod,
    InjectConstantCodemod,
)


@pytest.fixture(autouse=True)
def _mock_ast_grep_path(monkeypatch):
    """Ensure _resolve_ast_grep_path returns a fake binary so tests reach subprocess.run."""
    monkeypatch.setattr(
        "foundry.codemods.ruby_codemods._resolve_ast_grep_path",
        lambda: "/usr/bin/ast-grep",
    )
    monkeypatch.setattr(
        "foundry.codemods.js_codemods._resolve_ast_grep_path",
        lambda: "/usr/bin/ast-grep",
    )


# ============================================================
# Ruby Codemods - Synvert Integration Tests
# ============================================================

def test_ruby_synvert_success():
    """Test Ruby codemod with successful Synvert transformation."""
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    
    # Mock SynvertAdapter
    mock_adapter = Mock()
    mock_adapter.inline_rewrite.return_value = {
        "success": True,
        "changed_files": ["routes.rb"]
    }
    
    mock_module = MagicMock()
    mock_module.SynvertAdapter = Mock(return_value=mock_adapter)
    
    path = Path("/fake/routes.rb")
    
    with patch.dict('sys.modules', {'foundry.tools.synvert_adapter': mock_module}):
        result = codemod._apply_synvert(path)
    
    assert result.success is True
    assert result.changes_made == 1


def test_ruby_synvert_no_changes():
    """Test Ruby codemod when Synvert runs but makes no changes."""
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    
    mock_adapter = Mock()
    mock_adapter.inline_rewrite.return_value = {
        "success": True,
        "changed_files": None
    }
    
    mock_module = MagicMock()
    mock_module.SynvertAdapter = Mock(return_value=mock_adapter)
    
    path = Path("/fake/routes.rb")
    
    with patch.dict('sys.modules', {'foundry.tools.synvert_adapter': mock_module}):
        result = codemod._apply_synvert(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_ruby_synvert_failure():
    """Test Ruby codemod when Synvert reports failure."""
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    
    mock_adapter = Mock()
    mock_adapter.inline_rewrite.return_value = {
        "success": False,
        "error_message": "Syntax error in rule"
    }
    
    mock_module = MagicMock()
    mock_module.SynvertAdapter = Mock(return_value=mock_adapter)
    
    path = Path("/fake/routes.rb")
    
    with patch.dict('sys.modules', {'foundry.tools.synvert_adapter': mock_module}):
        result = codemod._apply_synvert(path)
    
    assert result.success is False
    assert "Syntax error" in result.error


def test_ruby_synvert_rule_simple_route():
    """Test Synvert rule generation for simple route."""
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    rule = codemod.get_synvert_rule()
    
    assert rule is not None
    assert "get" in rule
    assert "/users" in rule
    assert "users#index" in rule


def test_ruby_synvert_rule_namespaced_route():
    """Test Synvert rule generation for namespaced route."""
    codemod = RubyRouteCodemod(
        http_method="post",
        path="/webhooks",
        controller_action="webhooks#handle",
        namespace="admin"
    )
    rule = codemod.get_synvert_rule()
    
    assert rule is not None
    assert "post" in rule
    assert "admin" in rule
    assert "namespace" in rule


# ============================================================
# Ruby Codemods - ast-grep Path Tests
# ============================================================

def test_ruby_ast_grep_success(tmp_path, monkeypatch):
    """Test Ruby codemod with successful ast-grep transformation."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    
    def mock_run(*args, **kwargs):
        # Simulate ast-grep making changes
        path.write_text("Rails.application.routes.draw do\n  get '/users', to: 'users#index'\nend\n")
        return subprocess.CompletedProcess(args[0], 0)
    
    monkeypatch.setattr(subprocess, "run", mock_run)
    
    result = codemod._apply_ast_grep(path)
    
    assert result.success is True
    assert result.changes_made == 1


def test_ruby_ast_grep_no_changes(tmp_path, monkeypatch):
    """Test Ruby codemod when ast-grep runs but makes no changes."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    
    def mock_run(*args, **kwargs):
        return subprocess.CompletedProcess(args[0], 0)
    
    monkeypatch.setattr(subprocess, "run", mock_run)
    
    result = codemod._apply_ast_grep(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_ruby_ast_grep_timeout(tmp_path, monkeypatch):
    """Test Ruby codemod when ast-grep times out."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    
    def mock_run(*args, **kwargs):
        raise subprocess.TimeoutExpired(cmd=args[0], timeout=10)
    
    monkeypatch.setattr(subprocess, "run", mock_run)
    
    result = codemod._apply_ast_grep(path)
    
    assert result.success is False


def test_ruby_ast_grep_rule():
    """Test ast-grep rule generation for Ruby."""
    codemod = RubyRouteCodemod(http_method="post", path="/api/users", controller_action="api/users#create")
    rule = codemod.get_ast_grep_rule()
    
    assert rule is not None
    assert "pattern" in rule
    assert "replace" in rule
    assert "post" in rule["pattern"]


# ============================================================
# Ruby Codemods - Full Apply Chain Tests
# ============================================================

def test_ruby_apply_fallback_chain(tmp_path, monkeypatch):
    """Test Ruby codemod fallback chain: Synvert → ast-grep → string."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\n  get '/home', to: 'home#index'\nend\n")
    
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    
    # Disable ast-grep
    monkeypatch.setattr('foundry.codemods.ruby_codemods.is_ast_grep_available', lambda: False)
    
    result = codemod.apply(path)
    
    # Should fall back to string-based and succeed
    assert result.success is True
    assert "users#index" in path.read_text()


# ============================================================
# Ruby Codemods - String-based Edge Cases
# ============================================================

def test_ruby_route_duplicate_detection(tmp_path):
    """Test Ruby route duplicate detection."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\n  get '/users', to: 'users#index'\nend\n")
    
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_ruby_route_no_insertion_point(tmp_path):
    """Test Ruby route when no insertion point found."""
    path = tmp_path / "routes.rb"
    path.write_text("# Empty routes file\n")
    
    codemod = RubyRouteCodemod(http_method="get", path="/users", controller_action="users#index")
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "insertion point" in result.error


def test_ruby_route_namespaced_insertion(tmp_path):
    """Test Ruby route namespace insertion."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\n  namespace :admin do\n    get '/dashboard'\n  end\nend\n")
    
    codemod = RubyRouteCodemod(
        http_method="post",
        path="/webhooks",
        controller_action="webhooks#handle",
        namespace="admin"
    )
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "webhooks#handle" in path.read_text()


def test_ruby_route_namespace_not_found(tmp_path):
    """Test Ruby route when specified namespace doesn't exist."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\n  namespace :other do\n  end\nend\n")
    
    codemod = RubyRouteCodemod(
        http_method="get",
        path="/users",
        controller_action="users#index",
        namespace="admin"
    )
    result = codemod._apply_string_based(path)
    
    assert result.success is False


def test_ruby_call_duplicate_detection(tmp_path):
    """Test Ruby call duplicate detection."""
    path = tmp_path / "application.rb"
    path.write_text("module App\n  config.middleware.use Rack::Cors\nend\n")
    
    codemod = RubyCallCodemod(call_statement="config.middleware.use Rack::Cors")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_ruby_call_no_insertion_point(tmp_path):
    """Test Ruby call when no insertion point found."""
    path = tmp_path / "application.rb"
    path.write_text("# No end keyword\n")
    
    codemod = RubyCallCodemod(call_statement="config.middleware.use Rack::Cors")
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "insertion point" in result.error


def test_ruby_constant_duplicate_detection(tmp_path):
    """Test Ruby constant duplicate detection."""
    path = tmp_path / "application.rb"
    path.write_text("API_KEY = ENV['API_KEY']\nmodule App\nend\n")
    
    codemod = RubyConstantCodemod(name="API_KEY", value="ENV['API_KEY']")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_ruby_constant_insertion(tmp_path):
    """Test Ruby constant insertion after require statements."""
    path = tmp_path / "application.rb"
    path.write_text("require 'rails'\nrequire 'rack'\n\nmodule App\nend\n")
    
    codemod = RubyConstantCodemod(name="MAX_SIZE", value="100.megabytes")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "MAX_SIZE = 100.megabytes" in path.read_text()


# ============================================================
# JS Codemods - ast-grep Path Tests
# ============================================================

def test_js_ast_grep_success(tmp_path, monkeypatch):
    """Test JS codemod with successful ast-grep transformation."""
    path = tmp_path / "app.js"
    path.write_text("const x = 1;\n")
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    def mock_run(*args, **kwargs):
        path.write_text("import { useState } from 'react';\nconst x = 1;\n")
        return subprocess.CompletedProcess(args[0], 0)
    
    monkeypatch.setattr(subprocess, "run", mock_run)
    
    rule = codemod.get_rule()
    result = codemod._apply_ast_grep(path, rule)
    
    assert result.success is True
    assert result.changes_made == 1


def test_js_ast_grep_no_changes(tmp_path, monkeypatch):
    """Test JS codemod when ast-grep runs but makes no changes."""
    path = tmp_path / "app.js"
    path.write_text("import { useState } from 'react';\n")
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    def mock_run(*args, **kwargs):
        return subprocess.CompletedProcess(args[0], 0)
    
    monkeypatch.setattr(subprocess, "run", mock_run)
    
    rule = codemod.get_rule()
    result = codemod._apply_ast_grep(path, rule)
    
    assert result.success is True
    assert result.changes_made == 0


def test_js_ast_grep_timeout(tmp_path, monkeypatch):
    """Test JS codemod when ast-grep times out."""
    path = tmp_path / "app.js"
    path.write_text("const x = 1;\n")
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    def mock_run(*args, **kwargs):
        raise subprocess.TimeoutExpired(cmd=args[0], timeout=10)
    
    monkeypatch.setattr(subprocess, "run", mock_run)
    
    rule = codemod.get_rule()
    result = codemod._apply_ast_grep(path, rule)
    
    assert result.success is False
    assert "timeout" in result.error


def test_js_ast_grep_not_found(tmp_path, monkeypatch):
    """Test JS codemod when ast-grep binary not found."""
    path = tmp_path / "app.js"
    path.write_text("const x = 1;\n")
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    def mock_run(*args, **kwargs):
        raise FileNotFoundError("ast-grep not found")
    
    monkeypatch.setattr(subprocess, "run", mock_run)
    
    rule = codemod.get_rule()
    result = codemod._apply_ast_grep(path, rule)
    
    assert result.success is False
    assert "not found" in result.error


# ============================================================
# JS Codemods - Full Apply Chain Tests
# ============================================================

def test_js_apply_file_not_found():
    """Test JS codemod with non-existent file."""
    codemod = InjectImportCodemod(module="react", names=["useState"])
    missing_path = Path("/nonexistent/path/app.js")
    
    result = codemod.apply(missing_path)
    
    assert result.success is False
    assert "File not found" in result.error


def test_js_apply_fallback_to_string(tmp_path, monkeypatch):
    """Test JS codemod falls back to string-based when ast-grep unavailable."""
    path = tmp_path / "app.js"
    path.write_text("const x = 1;\n")
    
    codemod = InjectImportCodemod(module="react", names=["useState"])
    
    monkeypatch.setattr('foundry.codemods.js_codemods.is_ast_grep_available', lambda: False)
    
    result = codemod.apply(path)
    
    assert result.success is True
    assert "useState" in path.read_text()


# ============================================================
# JS Codemods - Import Variations
# ============================================================

def test_js_import_esm_multiple(tmp_path):
    """Test JS import with multiple named imports."""
    path = tmp_path / "app.js"
    path.write_text("import React from 'react';\n")
    
    codemod = InjectImportCodemod(module="react", names=["useState", "useEffect"], import_type="esm")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    content = path.read_text()
    assert "useState" in content
    assert "useEffect" in content


def test_js_import_esm_default():
    """Test JS import ESM default export."""
    codemod = InjectImportCodemod(module="react", names=[], import_type="esm")
    rule = codemod.get_rule()
    
    assert rule is not None
    assert "import * from 'react'" in rule["rule"]


def test_js_import_cjs():
    """Test JS import CommonJS format."""
    codemod = InjectImportCodemod(module="express", names=["express"], import_type="cjs")
    rule = codemod.get_rule()
    
    assert rule is not None
    assert "require(" in rule["rule"]
    assert "express" in rule["rule"]


def test_js_import_duplicate(tmp_path):
    """Test JS import duplicate detection."""
    path = tmp_path / "app.js"
    path.write_text("import { useState } from 'react';\n")
    
    codemod = InjectImportCodemod(module="react", names=["useState"], import_type="esm")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


# ============================================================
# JS Codemods - Route Variations
# ============================================================

def test_js_route_react(tmp_path):
    """Test JS React route injection."""
    path = tmp_path / "App.jsx"
    path.write_text("<Routes>\n  <Route path=\"/\" element={<Home />} />\n</Routes>\n")
    
    codemod = InjectRouteCodemod(path_pattern="/dashboard", component="Dashboard", framework="react")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "Dashboard" in path.read_text()


def test_js_route_react_duplicate(tmp_path):
    """Test JS React route duplicate detection."""
    path = tmp_path / "App.jsx"
    path.write_text("<Routes>\n  <Route path=\"/dashboard\" element={<Dashboard />} />\n</Routes>\n")
    
    codemod = InjectRouteCodemod(path_pattern="/dashboard", component="Dashboard", framework="react")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_js_route_react_no_routes(tmp_path):
    """Test JS React route when <Routes> not found."""
    path = tmp_path / "App.jsx"
    path.write_text("const App = () => <div>Hello</div>;\n")
    
    codemod = InjectRouteCodemod(path_pattern="/dashboard", component="Dashboard", framework="react")
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "insertion point" in result.error


def test_js_route_astro(tmp_path):
    """Test JS Astro route injection."""
    path = tmp_path / "routes.js"
    path.write_text("export const routes = [\n  { path: '/', component: Home }\n]\n")
    
    codemod = InjectRouteCodemod(path_pattern="/about", component="About", framework="astro")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "path: '/about'" in path.read_text()


def test_js_route_astro_duplicate(tmp_path):
    """Test JS Astro route duplicate detection."""
    path = tmp_path / "routes.js"
    path.write_text("export const routes = [\n  { path: '/about', component: About }\n]\n")
    
    codemod = InjectRouteCodemod(path_pattern="/about", component="About", framework="astro")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_js_route_astro_no_array(tmp_path):
    """Test JS Astro route when routes array not found."""
    path = tmp_path / "routes.js"
    path.write_text("const x = 1;\n")
    
    codemod = InjectRouteCodemod(path_pattern="/about", component="About", framework="astro")
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "insertion point" in result.error


def test_js_route_get_rule_react():
    """Test JS route get_rule for React."""
    codemod = InjectRouteCodemod(path_pattern="/dashboard", component="Dashboard", framework="react")
    rule = codemod.get_rule()
    
    assert rule is not None
    assert "/dashboard" in rule["rule"]
    assert "Dashboard" in rule["rule"]


def test_js_route_get_rule_astro():
    """Test JS route get_rule for Astro."""
    codemod = InjectRouteCodemod(path_pattern="/about", component="About", framework="astro")
    rule = codemod.get_rule()
    
    assert rule is not None
    assert "/about" in rule["rule"]


# ============================================================
# JS Codemods - Call Variations
# ============================================================

def test_js_call_with_target(tmp_path):
    """Test JS call injection with target function."""
    path = tmp_path / "main.js"
    path.write_text("function main() {\n  return true;\n}\n")
    
    codemod = InjectCallCodemod(call_statement="init()", target_function="main")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "init()" in path.read_text()


def test_js_call_duplicate(tmp_path):
    """Test JS call duplicate detection."""
    path = tmp_path / "main.js"
    path.write_text("function main() {\n  init();\n}\n")
    
    codemod = InjectCallCodemod(call_statement="init()", target_function="main")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_js_call_no_target(tmp_path):
    """Test JS call injection without target function."""
    path = tmp_path / "main.js"
    path.write_text("const x = 1;\n")
    
    codemod = InjectCallCodemod(call_statement="initialize()")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "initialize()" in path.read_text()


def test_js_call_get_rule():
    """Test JS call get_rule."""
    codemod = InjectCallCodemod(call_statement="app.use(cors())")
    rule = codemod.get_rule()
    
    assert rule is not None
    assert "app.use(cors())" in rule["rule"]


# ============================================================
# JS Codemods - Constant Variations
# ============================================================

def test_js_constant_insertion(tmp_path):
    """Test JS constant insertion."""
    path = tmp_path / "config.js"
    path.write_text("import React from 'react';\n\nexport default {};\n")
    
    codemod = InjectConstantCodemod(name="API_URL", value="'https://api.example.com'")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "const API_URL" in path.read_text()


def test_js_constant_duplicate_const(tmp_path):
    """Test JS constant duplicate detection with const."""
    path = tmp_path / "config.js"
    path.write_text("const API_URL = 'https://api.example.com';\n")
    
    codemod = InjectConstantCodemod(name="API_URL", value="'https://api.example.com'")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_js_constant_duplicate_assignment(tmp_path):
    """Test JS constant duplicate detection with assignment."""
    path = tmp_path / "config.js"
    path.write_text("API_URL = 'https://api.example.com';\n")
    
    codemod = InjectConstantCodemod(name="API_URL", value="'https://api.example.com'")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 0


def test_js_constant_get_rule():
    """Test JS constant get_rule."""
    codemod = InjectConstantCodemod(name="API_KEY", value="process.env.API_KEY")
    rule = codemod.get_rule()
    
    assert rule is not None
    assert "API_KEY" in rule["rule"]
    assert "process.env.API_KEY" in rule["rule"]


# ============================================================
# Utility Function Tests
# ============================================================

def test_ruby_is_ast_grep_available_sg(monkeypatch):
    """Test Ruby is_ast_grep_available with sg binary."""
    import foundry.codemods.ruby_codemods as ruby_mod
    
    monkeypatch.setattr('shutil.which', lambda name: "/usr/bin/sg" if name == "sg" else None)
    ruby_mod.is_ast_grep_available.cache_clear()
    
    assert ruby_mod.is_ast_grep_available() is True


def test_ruby_is_ast_grep_available_ast_grep(monkeypatch):
    """Test Ruby is_ast_grep_available with ast-grep binary."""
    import foundry.codemods.ruby_codemods as ruby_mod
    
    monkeypatch.setattr('shutil.which', lambda name: "/usr/bin/ast-grep" if name == "ast-grep" else None)
    ruby_mod.is_ast_grep_available.cache_clear()
    
    assert ruby_mod.is_ast_grep_available() is True


def test_ruby_is_ast_grep_available_none(monkeypatch):
    """Test Ruby is_ast_grep_available when not available."""
    import foundry.codemods.ruby_codemods as ruby_mod

    # Override the autouse fixture so _resolve_ast_grep_path returns None
    monkeypatch.setattr("foundry.codemods.ruby_codemods._resolve_ast_grep_path", lambda: None)
    ruby_mod.is_ast_grep_available.cache_clear()

    assert ruby_mod.is_ast_grep_available() is False


def test_js_is_ast_grep_available_sg(monkeypatch):
    """Test JS is_ast_grep_available with sg binary."""
    import foundry.codemods.js_codemods as js_mod
    
    monkeypatch.setattr('shutil.which', lambda name: "/usr/bin/sg" if name == "sg" else None)
    js_mod.is_ast_grep_available.cache_clear()
    
    assert js_mod.is_ast_grep_available() is True


def test_js_is_ast_grep_available_ast_grep(monkeypatch):
    """Test JS is_ast_grep_available with ast-grep binary."""
    import foundry.codemods.js_codemods as js_mod
    
    monkeypatch.setattr('shutil.which', lambda name: "/usr/bin/ast-grep" if name == "ast-grep" else None)
    js_mod.is_ast_grep_available.cache_clear()
    
    assert js_mod.is_ast_grep_available() is True


def test_js_is_ast_grep_available_none(monkeypatch):
    """Test JS is_ast_grep_available when not available."""
    import foundry.codemods.js_codemods as js_mod

    # Override the autouse fixture so _resolve_ast_grep_path returns None
    monkeypatch.setattr("foundry.codemods.js_codemods._resolve_ast_grep_path", lambda: None)
    js_mod.is_ast_grep_available.cache_clear()

    assert js_mod.is_ast_grep_available() is False


# ============================================================
# Helper Function Tests
# ============================================================

def test_js_write_yaml_rule():
    """Test JS _write_yaml_rule helper."""
    import tempfile
    from foundry.codemods.js_codemods import JsCodemod
    
    rule = {
        "rule": "const x = 1",
        "replace": "const y = 2"
    }
    
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        JsCodemod._write_yaml_rule(f, rule)
        temp_path = f.name
    
    try:
        content = Path(temp_path).read_text()
        assert "pattern: const x = 1" in content
        assert "replace: const y = 2" in content
    finally:
        Path(temp_path).unlink(missing_ok=True)


def test_js_write_yaml_rule_no_replace():
    """Test JS _write_yaml_rule without replace field."""
    import tempfile
    from foundry.codemods.js_codemods import JsCodemod
    
    rule = {
        "rule": "const x = 1"
    }
    
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        JsCodemod._write_yaml_rule(f, rule)
        temp_path = f.name
    
    try:
        content = Path(temp_path).read_text()
        assert "pattern: const x = 1" in content
        assert "replace:" not in content
    finally:
        Path(temp_path).unlink(missing_ok=True)


def test_ruby_apply_ast_grep_no_rule(tmp_path):
    """Test Ruby _apply_ast_grep when get_ast_grep_rule returns None."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    class NoRuleRubyCodemod(RubyCodemod):
        def get_ast_grep_rule(self):
            return None
    
    codemod = NoRuleRubyCodemod()
    result = codemod._apply_ast_grep(path)
    
    assert result.success is False
    assert "No rule defined" in result.error
