"""
Comprehensive edge case tests for Ruby codemods to boost coverage from 79% to 95%+.

Targets uncovered lines:
- Lines 44-46, 50-55, 60-61: Exception handling in apply() method
- Lines 87-90, 137-138: Synvert and ast-grep fallback paths
- Line 150, 157, 164: Base class method returns
- Lines 287-288, 307-308: Route injection exception handling
- Lines 356-357, 360-362, 373-374: Call injection exception handling  
- Lines 433-434: Constant injection exception handling
"""

import subprocess
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch

import pytest

from foundry.codemods.base import ModificationResult
from foundry.codemods.ruby_codemods import (
    RubyCodemod,
    InjectRouteCodemod,
    InjectCallCodemod,
    InjectConstantCodemod,
    is_ast_grep_available,
)


# ============================================================
# Base RubyCodemod - Exception Handling Tests
# ============================================================

def test_ruby_codemod_synvert_import_error(tmp_path):
    """Test exception handling when Synvert import fails (lines 44-46, 87-90)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock Synvert to raise ImportError
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.side_effect = ImportError("synvert not installed")
        
        # Should catch exception and continue to next method
        result = codemod.apply(path)
        
        # Should fall back to string-based
        assert result.success is True


def test_ruby_codemod_synvert_runtime_error(tmp_path):
    """Test exception handling when Synvert raises RuntimeError (lines 44-46)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.side_effect = RuntimeError("synvert execution failed")
        
        result = codemod.apply(path)
        assert result.success is True


def test_ruby_codemod_synvert_attribute_error(tmp_path):
    """Test exception handling when Synvert raises AttributeError (lines 44-46)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.side_effect = AttributeError("synvert module missing attribute")
        
        result = codemod.apply(path)
        assert result.success is True


def test_ruby_codemod_ast_grep_subprocess_error(tmp_path, monkeypatch):
    """Test exception handling when ast-grep raises SubprocessError (lines 50-55, 137-138)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Enable ast-grep
    monkeypatch.setattr('foundry.codemods.ruby_codemods.is_ast_grep_available', lambda: True)
    
    # Mock Synvert to fail
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.return_value = ModificationResult(success=False, error="synvert failed")
        
        # Mock ast-grep to raise SubprocessError
        with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_ast_grep') as mock_ast:
            mock_ast.side_effect = subprocess.SubprocessError("ast-grep crashed")
            
            result = codemod.apply(path)
            # Should fall back to string-based
            assert result.success is True


def test_ruby_codemod_ast_grep_file_not_found_error(tmp_path, monkeypatch):
    """Test exception handling when ast-grep raises FileNotFoundError (lines 50-55)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    monkeypatch.setattr('foundry.codemods.ruby_codemods.is_ast_grep_available', lambda: True)
    
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.return_value = ModificationResult(success=False, error="synvert failed")
        
        with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_ast_grep') as mock_ast:
            mock_ast.side_effect = FileNotFoundError("ast-grep binary not found")
            
            result = codemod.apply(path)
            assert result.success is True


def test_ruby_codemod_top_level_exception(tmp_path):
    """Test top-level exception handling in apply() method (lines 60-61)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock all methods to raise unexpected exception
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.side_effect = ValueError("unexpected error")
        
        # Mock ast-grep availability check
        with patch('foundry.codemods.ruby_codemods.is_ast_grep_available', return_value=False):
            
            # Mock string-based to also fail
            with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_string_based') as mock_string:
                mock_string.side_effect = ValueError("string-based also failed")
                
                result = codemod.apply(path)
                assert result.success is False
                assert "InjectRouteCodemod" in result.error
                assert "unexpected error" in result.error or "string-based also failed" in result.error


def test_ruby_codemod_synvert_not_available_path(tmp_path):
    """Test Synvert not available path (lines 87-90)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Call _apply_synvert directly when Synvert unavailable
    with patch.dict('sys.modules', {'foundry.tools.synvert_adapter': None}):
        result = codemod._apply_synvert(path)
        
        assert result.success is False
        assert "Synvert not available" in result.error


def test_ruby_codemod_ast_grep_exception_handler(tmp_path):
    """Test ast-grep exception handler catches general exceptions (line 137-138)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock subprocess.run to raise a generic exception during ast-grep
    with patch('subprocess.run') as mock_run:
        mock_run.side_effect = Exception("unexpected ast-grep error")
        
        result = codemod._apply_ast_grep(path)
        
        assert result.success is False
        assert "ast-grep not available" in result.error


def test_ruby_codemod_base_class_methods():
    """Test base class default method returns (lines 150, 157, 164)."""
    codemod = RubyCodemod()
    path = Path("/fake/path.rb")
    
    # Test get_synvert_rule returns None (line 150)
    assert codemod.get_synvert_rule() is None
    
    # Test get_ast_grep_rule returns None (line 157)
    assert codemod.get_ast_grep_rule() is None
    
    # Test _apply_string_based returns error (line 164)
    result = codemod._apply_string_based(path)
    assert result.success is False
    assert "No transformation approach available" in result.error


def test_ruby_codemod_ast_grep_timeout(tmp_path, monkeypatch):
    """Test ast-grep timeout exception handling (line 137)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock subprocess.run to raise TimeoutExpired
    def mock_run(*args, **kwargs):
        raise subprocess.TimeoutExpired(cmd=args[0], timeout=10)
    
    with patch('subprocess.run', side_effect=mock_run):
        result = codemod._apply_ast_grep(path)
        
        assert result.success is False
        assert "ast-grep not available" in result.error


# ============================================================
# InjectRouteCodemod - Exception Handling Tests
# ============================================================

def test_route_injection_file_read_error(tmp_path):
    """Test route injection when file read fails (lines 287-288)."""
    path = tmp_path / "routes.rb"
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock path.read_text to raise exception
    with patch.object(Path, 'read_text', side_effect=PermissionError("permission denied")):
        result = codemod._apply_string_based(path)
        
        assert result.success is False
        assert "String-based route injection failed" in result.error
        assert "permission denied" in result.error.lower()


def test_route_injection_file_write_error(tmp_path):
    """Test route injection when file write fails (lines 307-308)."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\n  get '/home'\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock path.write_text to raise exception
    with patch.object(Path, 'write_text', side_effect=IOError("disk full")):
        result = codemod._apply_string_based(path)
        
        assert result.success is False
        assert "String-based route injection failed" in result.error


def test_route_injection_unexpected_content_structure(tmp_path):
    """Test route injection with malformed content that causes string ops to fail."""
    path = tmp_path / "routes.rb"
    # Create content that might cause split/join operations to fail
    path.write_bytes(b'\x80\x81\x82')  # Invalid UTF-8
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "String-based route injection failed" in result.error


# ============================================================
# InjectCallCodemod - Exception Handling Tests
# ============================================================

def test_call_injection_file_read_error(tmp_path):
    """Test call injection when file read fails (lines 356-357)."""
    path = tmp_path / "application.rb"
    
    codemod = InjectCallCodemod("config.middleware.use Rack::Cors")
    
    with patch.object(Path, 'read_text', side_effect=FileNotFoundError("file not found")):
        result = codemod._apply_string_based(path)
        
        assert result.success is False
        assert "String-based call injection failed" in result.error


def test_call_injection_file_write_error(tmp_path):
    """Test call injection when file write fails (lines 360-362, 373-374)."""
    path = tmp_path / "application.rb"
    path.write_text("module App\n  class Application\n  end\nend\n")
    
    codemod = InjectCallCodemod("config.middleware.use Rack::Cors")
    
    with patch.object(Path, 'write_text', side_effect=IOError("read-only filesystem")):
        result = codemod._apply_string_based(path)
        
        assert result.success is False
        assert "String-based call injection failed" in result.error
        assert "read-only filesystem" in result.error.lower()


def test_call_injection_encoding_error(tmp_path):
    """Test call injection with encoding issues."""
    path = tmp_path / "application.rb"
    path.write_bytes(b'\xff\xfe')  # Invalid UTF-8
    
    codemod = InjectCallCodemod("config.middleware.use Rack::Cors")
    
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "String-based call injection failed" in result.error


def test_call_injection_empty_file(tmp_path):
    """Test call injection with empty file (no 'end' keyword)."""
    path = tmp_path / "application.rb"
    path.write_text("")
    
    codemod = InjectCallCodemod("config.middleware.use Rack::Cors")
    
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "insertion point" in result.error


# ============================================================
# InjectConstantCodemod - Exception Handling Tests
# ============================================================

def test_constant_injection_file_read_error(tmp_path):
    """Test constant injection when file read fails (lines 433-434)."""
    path = tmp_path / "application.rb"
    
    codemod = InjectConstantCodemod("API_KEY", "ENV['API_KEY']")
    
    with patch.object(Path, 'read_text', side_effect=OSError("io error")):
        result = codemod._apply_string_based(path)
        
        assert result.success is False
        assert "String-based constant injection failed" in result.error
        assert "io error" in result.error.lower()


def test_constant_injection_file_write_error(tmp_path):
    """Test constant injection when file write fails (lines 433-434)."""
    path = tmp_path / "application.rb"
    path.write_text("require 'rails'\n\nmodule App\nend\n")
    
    codemod = InjectConstantCodemod("MAX_SIZE", "100.megabytes")
    
    with patch.object(Path, 'write_text', side_effect=PermissionError("access denied")):
        result = codemod._apply_string_based(path)
        
        assert result.success is False
        assert "String-based constant injection failed" in result.error


def test_constant_injection_unicode_error(tmp_path):
    """Test constant injection with unicode decoding issues."""
    path = tmp_path / "application.rb"
    # Write invalid UTF-8 bytes
    path.write_bytes(b'\x80\x90\xa0')
    
    codemod = InjectConstantCodemod("API_KEY", "ENV['API_KEY']")
    
    result = codemod._apply_string_based(path)
    
    assert result.success is False
    assert "String-based constant injection failed" in result.error


# ============================================================
# Edge Case Tests - Complex Scenarios
# ============================================================

def test_route_injection_namespace_depth_edge_case(tmp_path):
    """Test namespaced route with nested 'end' keywords."""
    path = tmp_path / "routes.rb"
    path.write_text("""Rails.application.routes.draw do
  namespace :admin do
    namespace :internal do
      get '/dashboard'
    end
  end
end
""")
    
    codemod = InjectRouteCodemod("post", "/webhooks", "webhooks#handle", namespace="admin")
    result = codemod._apply_string_based(path)
    
    # Should find first 'end' after namespace
    assert result.success is True
    assert "webhooks#handle" in path.read_text()


def test_call_injection_multiple_end_keywords(tmp_path):
    """Test call injection finds correct 'end' keyword."""
    path = tmp_path / "application.rb"
    path.write_text("""module App
  class Application
    if true
    end
  end
end
""")
    
    codemod = InjectCallCodemod("config.time_zone = 'UTC'")
    result = codemod._apply_string_based(path)
    
    # Should insert before the last 'end'
    assert result.success is True


def test_constant_injection_mixed_content(tmp_path):
    """Test constant insertion in file with mixed content."""
    path = tmp_path / "application.rb"
    path.write_text("""# frozen_string_literal: true

require 'rails'
require 'rack'

Rails.application.initialize!

module App
end
""")
    
    codemod = InjectConstantCodemod("VERSION", "'1.0.0'")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    content = path.read_text()
    assert "VERSION = '1.0.0'" in content


def test_synvert_adapter_not_installed():
    """Test behavior when synvert_adapter module doesn't exist."""
    path = Path("/fake/routes.rb")
    codemod = InjectRouteCodemod("get", "/test", "test#index")
    
    # Ensure synvert_adapter is not importable
    with patch.dict('sys.modules', {'foundry.tools.synvert_adapter': None}):
        result = codemod._apply_synvert(path)
        
        assert result.success is False
        assert "Synvert not available" in result.error


def test_ast_grep_general_exception_handling(tmp_path):
    """Test ast-grep handles unexpected exceptions gracefully."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock subprocess.run to raise unexpected exception
    with patch('subprocess.run', side_effect=RuntimeError("unexpected subprocess error")):
        result = codemod._apply_ast_grep(path)
        
        assert result.success is False
        assert "ast-grep not available" in result.error


def test_route_injection_with_special_characters(tmp_path):
    """Test route injection handles special characters in path."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\n  get '/home'\nend\n")
    
    # Use single quotes which might cause issues with naive string handling
    codemod = InjectRouteCodemod("post", "/api/v1/users", "api/v1/users#create")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert "api/v1/users#create" in path.read_text()


def test_call_injection_preserves_indentation(tmp_path):
    """Test that call injection maintains proper indentation."""
    path = tmp_path / "application.rb"
    path.write_text("module App\n  class Application\n    # config\n  end\nend\n")
    
    codemod = InjectCallCodemod("config.time_zone = 'UTC'")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    content = path.read_text()
    # Should have 4 spaces indentation
    assert "    config.time_zone = 'UTC'" in content


# ============================================================
# Integration Tests - Multiple Fallback Paths
# ============================================================

def test_full_fallback_chain_all_errors(tmp_path, monkeypatch):
    """Test complete fallback chain when all methods fail."""
    path = tmp_path / "routes.rb"
    path.write_text("")  # Empty file with no insertion point
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Disable ast-grep
    monkeypatch.setattr('foundry.codemods.ruby_codemods.is_ast_grep_available', lambda: False)
    
    # Mock Synvert to fail
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.return_value = ModificationResult(success=False, error="synvert failed")
        
        result = codemod.apply(path)
        
        # String-based should also fail (no insertion point)
        assert result.success is False


def test_synvert_success_short_circuits_chain(tmp_path):
    """Test that Synvert success prevents fallback to other methods."""
    path = tmp_path / "routes.rb"
    path.write_text("Rails.application.routes.draw do\nend\n")
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Mock Synvert to succeed
    mock_adapter = Mock()
    mock_adapter.inline_rewrite.return_value = {"success": True, "changed_files": ["routes.rb"]}
    
    mock_module = MagicMock()
    mock_module.SynvertAdapter = Mock(return_value=mock_adapter)
    
    with patch.dict('sys.modules', {'foundry.tools.synvert_adapter': mock_module}):
        # Mock ast-grep and string methods to verify they aren't called
        with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_ast_grep') as mock_ast:
            with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_string_based') as mock_string:
                result = codemod.apply(path)
                
                assert result.success is True
                # Verify fallback methods were not called
                mock_ast.assert_not_called()
                mock_string.assert_not_called()


def test_ast_grep_success_with_changes_short_circuits(tmp_path, monkeypatch):
    """Test ast-grep success with changes prevents string fallback (lines 52-53)."""
    path = tmp_path / "routes.rb"
    original_content = "Rails.application.routes.draw do\n  get '/home'\nend\n"
    path.write_text(original_content)
    
    codemod = InjectRouteCodemod("get", "/users", "users#index")
    
    # Enable ast-grep
    monkeypatch.setattr('foundry.codemods.ruby_codemods.is_ast_grep_available', lambda: True)
    
    # Mock Synvert to fail
    with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_synvert') as mock_synvert:
        mock_synvert.return_value = ModificationResult(success=False, error="synvert failed")
        
        # Mock subprocess.run to succeed and modify file
        def mock_run(*args, **kwargs):
            # Simulate ast-grep making changes
            modified_content = original_content + "  get '/users', to: 'users#index'\n"
            path.write_text(modified_content)
            return subprocess.CompletedProcess(args[0], 0)
        
        with patch('subprocess.run', side_effect=mock_run):
            # Mock string-based to verify it's not called
            with patch('foundry.codemods.ruby_codemods.RubyCodemod._apply_string_based') as mock_string:
                result = codemod.apply(path)
                
                # Should succeed via ast-grep and not call string-based
                assert result.success is True
                assert result.changes_made == 1
                mock_string.assert_not_called()


def test_route_injection_after_existing_route(tmp_path):
    """Test route insertion after existing route definition (lines 287-288)."""
    path = tmp_path / "routes.rb"
    path.write_text("""Rails.application.routes.draw do
  get '/home', to: 'home#index'
  post '/contact', to: 'contact#create'
end
""")
    
    codemod = InjectRouteCodemod("get", "/about", "about#show")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 1
    
    content = path.read_text()
    # Should be inserted after the last route (post '/contact')
    lines = content.split('\n')
    about_line_idx = next(i for i, line in enumerate(lines) if '/about' in line)
    contact_line_idx = next(i for i, line in enumerate(lines) if '/contact' in line)
    # About should come after contact
    assert about_line_idx > contact_line_idx


def test_route_injection_insert_after_last_route_method(tmp_path):
    """Test specific code path inserting after route statement (lines 287-288)."""
    path = tmp_path / "routes.rb"
    # Routes file with an HTTP method route followed by other content
    path.write_text("""Rails.application.routes.draw do
  get '/api/health', to: 'health#check'
end
""")
    
    codemod = InjectRouteCodemod("post", "/api/data", "data#create")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 1
    
    content = path.read_text()
    
    # Verify the new route was added
    assert "data#create" in content
    assert content.count("to: ") == 2  # Both routes present


def test_route_injection_multiple_http_verbs(tmp_path):
    """Test route insertion works with all HTTP verb types (lines 287-288)."""
    path = tmp_path / "routes.rb"
    path.write_text("""Rails.application.routes.draw do
  get '/users'
  post '/users'
  patch '/users/:id'
  delete '/users/:id'
  put '/users/:id'
end
""")
    
    # Add a new route - should go after the last one (put)
    codemod = InjectRouteCodemod("get", "/accounts", "accounts#index")
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    content = path.read_text()
    
    lines = content.split('\n')
    put_idx = next(i for i, line in enumerate(lines) if "put '/users/:id'" in line)
    accounts_idx = next(i for i, line in enumerate(lines) if '/accounts' in line)
    
    # Should be inserted after the last route
    assert accounts_idx > put_idx


def test_route_injection_non_namespaced_various_verbs(tmp_path):
    """Test route insertion for non-namespaced routes with different verbs (lines 287-288)."""
    # Test each HTTP verb to ensure the startswith() check works
    for verb in ['get', 'post', 'patch', 'delete', 'put']:
        path = tmp_path / f"routes_{verb}.rb"
        path.write_text(f"""Rails.application.routes.draw do
  {verb} '/existing', to: 'existing#action'
  # trailing comment
end
""")
        
        codemod = InjectRouteCodemod("post", "/newroute", "newroute#create")
        result = codemod._apply_string_based(path)
        
        assert result.success is True
        content = path.read_text()
        assert "newroute#create" in content


def test_route_injection_finds_last_route_not_end(tmp_path):
    """
    Test that route injection finds last route line (not 'end') - hits lines 287-288.
    
    The backward search should find the route line first (before 'end'),
    set insert_idx = i + 1, and break.
    """
    path = tmp_path / "routes.rb"
    # Create a routes file where the last meaningful line is a route (not 'end')
    # Put the closing 'end' BEFORE the last route to force hitting the route branch
    path.write_text("""Rails.application.routes.draw do
  get '/home'
end
get '/standalone_route'
""")
    
    codemod = InjectRouteCodemod("post", "/api", "api#create")
    
    # Call string-based directly to ensure we're testing the right path
    result = codemod._apply_string_based(path)
    
    assert result.success is True
    assert result.changes_made == 1
    
    content = path.read_text()
    
    # The new route should be inserted right after the standalone route
    # When searching backwards, it finds '/standalone_route' first (before 'end')
    # This goes through insert_idx = i + 1 (line 287) and break (line 288)
    assert "api#create" in content
    lines = content.split('\n')
    standalone_idx = next(i for i, line in enumerate(lines) if 'standalone_route' in line)
    api_idx = next(i for i, line in enumerate(lines) if 'api#create' in line)
    assert api_idx == standalone_idx + 1
