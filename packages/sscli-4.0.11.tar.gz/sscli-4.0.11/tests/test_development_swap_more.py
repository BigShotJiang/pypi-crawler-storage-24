from pathlib import Path

from foundry.actions import development


def test_run_swap_no_venv(monkeypatch, tmp_path):
    monkeypatch.setattr(development, "get_stack_cli_root", lambda: tmp_path)
    monkeypatch.setattr(development, "get_venv_path", lambda: None)

    assert development.run_swap(target="local") is False


def test_run_swap_local_no_wheel(monkeypatch, tmp_path):
    stack_root = tmp_path / "stack-cli"
    dist_dir = stack_root / "dist"
    dist_dir.mkdir(parents=True)

    venv_path = tmp_path / "venv"
    (venv_path / "bin").mkdir(parents=True)
    (venv_path / "bin" / "python").write_text("", encoding="utf-8")

    monkeypatch.setattr(development, "get_stack_cli_root", lambda: stack_root)
    monkeypatch.setattr(development, "get_venv_path", lambda: venv_path)
    monkeypatch.setattr(development, "get_pip_version", lambda: "1.0.0")
    monkeypatch.setattr(development, "is_using_local", lambda: False)
    monkeypatch.setattr(development.console, "print", lambda *args, **_k: None)

    assert development.run_swap(target="local") is False


def test_run_swap_pip_no_version(monkeypatch, tmp_path):
    stack_root = tmp_path / "stack-cli"
    stack_root.mkdir(parents=True)

    venv_path = tmp_path / "venv"
    (venv_path / "bin").mkdir(parents=True)
    (venv_path / "bin" / "python").write_text("", encoding="utf-8")

    monkeypatch.setattr(development, "get_stack_cli_root", lambda: stack_root)
    monkeypatch.setattr(development, "get_venv_path", lambda: venv_path)
    monkeypatch.setattr(development, "get_pip_version", lambda: "")
    monkeypatch.setattr(development, "is_using_local", lambda: True)
    monkeypatch.setattr(development.console, "print", lambda *args, **_k: None)

    assert development.run_swap(target="pip") is False
