"""
Comprehensive tests for foundry.actions.health module.

Tests:
- Health check for various templates
- Docker file validation
- Git ignore validation
- Runbook validation
- Setup scripts validation
- Special cases (mobile, terraform)
"""

from pathlib import Path
import pytest


def test_run_health_check_all_files_present(monkeypatch, tmp_path):
    """Test health check with all required files present."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create python-saas with all files
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    (python_saas / "Dockerfile").write_text("FROM python:3.11")
    (python_saas / ".gitignore").write_text("*.pyc")
    (python_saas / "RUNBOOK.md").write_text("# Runbook")
    (python_saas / ".env.example").write_text("SECRET=")
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    (bin_dir / "setup.py").write_text("# setup")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    # Should have printed something
    assert len(printed) > 0


def test_run_health_check_missing_dockerfile(monkeypatch, tmp_path):
    """Test health check with missing Dockerfile."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    rails_api = templates_dir / "rails-api"
    rails_api.mkdir()
    (rails_api / ".gitignore").write_text("*.log")
    (rails_api / "RUNBOOK.md").write_text("# Runbook")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_missing_gitignore(monkeypatch, tmp_path):
    """Test health check with missing .gitignore."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    rails_ui_kit = templates_dir / "rails-ui-kit"
    rails_ui_kit.mkdir()
    (rails_ui_kit / "Dockerfile").write_text("FROM ruby:3.2")
    (rails_ui_kit / "RUNBOOK.md").write_text("# Runbook")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_missing_runbook(monkeypatch, tmp_path):
    """Test health check with missing RUNBOOK.md."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    react_client = templates_dir / "react-client"
    react_client.mkdir()
    (react_client / "Dockerfile").write_text("FROM node:20")
    (react_client / ".gitignore").write_text("node_modules")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_missing_setup_scripts(monkeypatch, tmp_path):
    """Test health check with missing setup scripts."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    (python_saas / "Dockerfile").write_text("FROM python:3.11")
    (python_saas / ".gitignore").write_text("*.pyc")
    (python_saas / "RUNBOOK.md").write_text("# Runbook")
    # No bin/ directory
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_mobile_template(monkeypatch, tmp_path):
    """Test health check for mobile templates (special case)."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    mobile_android = templates_dir / "mobile-android"
    mobile_android.mkdir()
    (mobile_android / "Dockerfile").write_text("FROM gradle")
    (mobile_android / ".gitignore").write_text("build/")
    (mobile_android / "RUNBOOK.md").write_text("# Android")
    # Mobile templates don't need bin/setup scripts
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_mobile_ios(monkeypatch, tmp_path):
    """Test health check for iOS mobile template."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    mobile_ios = templates_dir / "mobile-ios"
    mobile_ios.mkdir()
    (mobile_ios / "Dockerfile").write_text("FROM swift")
    (mobile_ios / ".gitignore").write_text("Pods/")
    (mobile_ios / "RUNBOOK.md").write_text("# iOS")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_terraform_special_case(monkeypatch, tmp_path):
    """Test health check for terraform-infra (special case)."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    terraform_infra = templates_dir / "terraform-infra"
    terraform_infra.mkdir()
    (terraform_infra / "main.tf").write_text("terraform {}")
    (terraform_infra / "variables.tf").write_text("variable 'x' {}")
    (terraform_infra / "RUNBOOK.md").write_text("# Terraform")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_missing_env_example(monkeypatch, tmp_path):
    """Test health check with missing .env.example."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    (python_saas / "Dockerfile").write_text("FROM python:3.11")
    (python_saas / ".gitignore").write_text("*.pyc")
    (python_saas / "RUNBOOK.md").write_text("# Runbook")
    # Missing .env.example
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_data_pipeline_no_env(monkeypatch, tmp_path):
    """Test health check for data-pipeline (doesn't need .env.example)."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    data_pipeline = templates_dir / "data-pipeline"
    data_pipeline.mkdir()
    (data_pipeline / "Dockerfile").write_text("FROM python:3.11")
    (data_pipeline / ".gitignore").write_text("*.pyc")
    (data_pipeline / "RUNBOOK.md").write_text("# Data Pipeline")
    # data-pipeline doesn't need .env.example
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_empty_templates_dir(monkeypatch, tmp_path):
    """Test health check with no templates."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    # Should still print something (empty tree)
    assert len(printed) > 0


def test_run_health_check_multiple_templates(monkeypatch, tmp_path):
    """Test health check with multiple templates."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create multiple templates with varying completeness
    for name in ["python-saas", "rails-api", "react-client"]:
        tmpl_dir = templates_dir / name
        tmpl_dir.mkdir()
        (tmpl_dir / "Dockerfile").write_text("FROM base")
        (tmpl_dir / ".gitignore").write_text("*")
        (tmpl_dir / "RUNBOOK.md").write_text("# Runbook")
        (tmpl_dir / ".env.example").write_text("SECRET=")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_with_setup_scripts(monkeypatch, tmp_path):
    """Test health check detects setup scripts correctly."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    python_saas = templates_dir / "python-saas"
    python_saas.mkdir()
    (python_saas / "Dockerfile").write_text("FROM python:3.11")
    (python_saas / ".gitignore").write_text("*.pyc")
    (python_saas / "RUNBOOK.md").write_text("# Runbook")
    (python_saas / ".env.example").write_text("SECRET=")
    
    bin_dir = python_saas / "bin"
    bin_dir.mkdir()
    (bin_dir / "setup.py").write_text("# setup")
    (bin_dir / "setup.sh").write_text("#!/bin/bash")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_terraform_missing_files(monkeypatch, tmp_path):
    """Test health check for terraform with missing files."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    terraform_infra = templates_dir / "terraform-infra"
    terraform_infra.mkdir()
    # Only main.tf, missing variables.tf and RUNBOOK.md
    (terraform_infra / "main.tf").write_text("terraform {}")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    assert len(printed) > 0


def test_run_health_check_nonexistent_template(monkeypatch, tmp_path):
    """Test health check skips templates that don't exist."""
    from foundry.actions import health as health_mod
    
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    
    # Create only one template, others won't exist
    react_client = templates_dir / "react-client"
    react_client.mkdir()
    (react_client / "Dockerfile").write_text("FROM node:20")
    
    monkeypatch.setattr(health_mod, "TEMPLATES_DIR", templates_dir)
    
    printed = []
    monkeypatch.setattr(health_mod.console, "print", lambda msg: printed.append(msg))
    
    health_mod.run_health_check()
    
    # Should still complete successfully
    assert len(printed) > 0
