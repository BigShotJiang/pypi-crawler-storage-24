"""Tests for sscli doctor and sscli setup."""
import json
import os
from unittest import mock

import pytest
from typer.testing import CliRunner

from foundry.commands.doctor import app as doctor_app, _check_python, _check_git, _check_token
from foundry.commands.wizard import app as wizard_app

runner = CliRunner()


class TestDoctorChecks:
    def test_check_python_pass(self):
        """Python 3.11+ should pass."""
        import sys
        if sys.version_info >= (3, 11):
            status, msg = _check_python()
            assert "PASS" in status
        else:
            status, msg = _check_python()
            assert "FAIL" in status

    def test_check_token_with_env(self):
        with mock.patch.dict(os.environ, {"SSCLI_TOKEN": "test-token-abc123"}):
            status, msg = _check_token()
            assert "PASS" in status

    def test_check_token_missing(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            env = {k: v for k, v in os.environ.items() if k != "SSCLI_TOKEN"}
            with mock.patch.dict(os.environ, env, clear=True):
                status, msg = _check_token()
                if "SSCLI_TOKEN" not in os.environ:
                    assert "FAIL" in status

    def test_check_git(self):
        status, msg = _check_git()
        # Should either PASS or FAIL, not raise
        assert "PASS" in status or "FAIL" in status

    def test_doctor_json_output(self):
        result = runner.invoke(doctor_app, ["--json"])
        # May exit 0 or 1 depending on environment, but output should be JSON
        try:
            data = json.loads(result.output)
            assert isinstance(data, list)
            assert all("check" in item for item in data)
        except json.JSONDecodeError:
            pass  # might have warnings before JSON

    def test_doctor_runs_without_crash(self):
        result = runner.invoke(doctor_app, [])
        # Should not crash with exception
        assert result.exception is None or isinstance(result.exception, SystemExit)

    def test_doctor_fix_flag(self):
        result = runner.invoke(doctor_app, ["--fix"])
        # Should run without crash
        assert result.exception is None or isinstance(result.exception, SystemExit)


class TestSetupWizard:
    def test_setup_no_token_exits_gracefully(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            result = runner.invoke(wizard_app, [], input="1\nmy-app\nY\n")
            # Should fail gracefully when no token
            assert result.exit_code != 0 or "token" in result.output.lower()
