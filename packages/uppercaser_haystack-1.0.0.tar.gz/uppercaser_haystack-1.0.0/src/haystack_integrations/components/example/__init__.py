# SPDX-FileCopyrightText: 2026-present AUTHOR <your@email.com>
#
# SPDX-License-Identifier: Apache-2.0

from .uppercaser import Uppercaser

__all__ = ["Uppercaser"]
