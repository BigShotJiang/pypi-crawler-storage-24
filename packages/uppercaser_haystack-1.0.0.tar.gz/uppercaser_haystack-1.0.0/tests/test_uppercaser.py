# SPDX-FileCopyrightText: 2026-present AUTHOR <your@email.com>
#
# SPDX-License-Identifier: Apache-2.0

from haystack.core.serialization import component_from_dict, component_to_dict

from haystack_integrations.components.example import Uppercaser


class TestUppercaser:
    def test_init_default(self):
        component = Uppercaser()
        assert component.param == "default"

    def test_init_custom_param(self):
        component = Uppercaser(param="custom")
        assert component.param == "custom"

    def test_run(self):
        component = Uppercaser()
        result = component.run(input_text="Hello, world!")
        assert result == {"output": "HELLO, WORLD!"}

    def test_to_dict(self):
        component = Uppercaser(param="custom")
        data = component_to_dict(component, "Uppercaser")
        assert data == {
            "type": "haystack_integrations.components.example.uppercaser.Uppercaser",
            "init_parameters": {"param": "custom"},
        }

    def test_from_dict(self):
        data = {
            "type": "haystack_integrations.components.example.uppercaser.Uppercaser",
            "init_parameters": {"param": "custom"},
        }
        deserialized = component_from_dict(Uppercaser, data, "Uppercaser")
        assert deserialized.param == "custom"
