"""Tests for the main Duffel client setup and transport."""

import httpx

from duffelbag import Duffel


def test_client_context_manager(mock_transport):
    http_client = httpx.Client(transport=mock_transport)
    with Duffel(token="duffel_test_abc", http_client=http_client) as client:
        assert client.offer_requests is not None
    # Should not raise after close


def test_default_headers(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={"meta": {"limit": 50, "after": None}, "data": []})
    )
    # Trigger a request
    list(client.airlines.list())

    req = mock_transport.last_request
    assert req.headers["authorization"] == "Bearer duffel_test_123"
    assert req.headers["duffel-version"] == "v2"
    assert req.headers["accept"] == "application/json"


def test_resource_properties_are_cached(client):
    assert client.offer_requests is client.offer_requests
    assert client.offers is client.offers
    assert client.orders is client.orders
    assert client.stays_bookings is client.stays_bookings
