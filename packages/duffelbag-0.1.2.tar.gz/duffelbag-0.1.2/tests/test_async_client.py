"""Tests for the async Duffel client."""

import httpx
import pytest

from duffelbag import AsyncDuffel
from duffelbag.resources.offer_requests import AsyncOfferRequests
from duffelbag.resources.orders import AsyncOrders


async def test_async_client_context_manager(async_mock_transport):
    http_client = httpx.AsyncClient(transport=async_mock_transport)
    async with AsyncDuffel(token="duffel_test_123", http_client=http_client) as client:
        assert client.offer_requests is not None


async def test_async_resource_properties_are_cached(async_client):
    assert async_client.offer_requests is async_client.offer_requests
    assert async_client.orders is async_client.orders
    assert isinstance(async_client.offer_requests, AsyncOfferRequests)
    assert isinstance(async_client.orders, AsyncOrders)


async def test_async_default_headers(async_client, async_mock_transport):
    await async_client.offer_requests.get("orq_001")
    req = async_mock_transport.last_request
    assert req.headers["authorization"] == "Bearer duffel_test_123"
    assert req.headers["duffel-version"] == "v2"
    assert req.headers["accept"] == "application/json"
