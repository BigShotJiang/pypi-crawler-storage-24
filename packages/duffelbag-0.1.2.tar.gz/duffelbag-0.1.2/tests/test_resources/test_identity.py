"""Tests for Identity resources."""

import httpx

from duffelbag.models import CustomerUser, CustomerUserGroup


def test_create_customer_user(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "icu_001",
                "email": "user@example.com",
                "given_name": "Jane",
                "family_name": "Doe",
                "live_mode": False,
                "created_at": "2026-01-01T00:00:00Z",
            }
        })
    )

    user = client.customer_users.create(
        email="user@example.com",
        given_name="Jane",
        family_name="Doe",
    )

    assert isinstance(user, CustomerUser)
    assert user.given_name == "Jane"
    assert "/identity/customer/users" in str(mock_transport.last_request.url)


def test_update_customer_user_uses_put(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={"data": {"id": "icu_001", "email": "new@example.com"}})
    )

    client.customer_users.update(
        "icu_001",
        email="new@example.com",
        given_name="Jane",
        family_name="Doe",
    )

    assert mock_transport.last_request.method == "PUT"


def test_create_component_client_key(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {"component_client_key": "eyJhbGciOi..."}
        })
    )

    key = client.component_client_keys.create(user_id="icu_001")
    assert key == "eyJhbGciOi..."


def test_create_customer_user_group(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {"id": "usg_001", "name": "Test Group", "user_ids": ["icu_001"]}
        })
    )

    group = client.customer_user_groups.create(name="Test Group", user_ids=["icu_001"])
    assert isinstance(group, CustomerUserGroup)
    assert group.user_ids == ["icu_001"]
