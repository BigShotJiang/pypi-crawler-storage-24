"""Tests for Webhook resources."""

import httpx

from duffelbag.models import Webhook


def test_create_webhook(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "end_001",
                "url": "https://example.com/webhook",
                "events": ["order.created"],
                "active": True,
                "live_mode": False,
                "secret": "wh_secret_abc123",
                "created_at": "2026-01-01T00:00:00Z",
                "updated_at": "2026-01-01T00:00:00Z",
            }
        })
    )

    webhook = client.webhooks.create(
        url="https://example.com/webhook",
        events=["order.created"],
    )

    assert isinstance(webhook, Webhook)
    assert webhook.secret == "wh_secret_abc123"
    assert webhook.active is True


def test_update_webhook(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": {"id": "end_001", "active": False}
        })
    )

    webhook = client.webhooks.update("end_001", active=False)
    assert webhook.active is False

    req = mock_transport.last_request
    assert req.method == "PATCH"


def test_delete_webhook(client, mock_transport):
    mock_transport.queue_response(httpx.Response(204))
    client.webhooks.delete("end_001")
    assert mock_transport.last_request.method == "DELETE"


def test_ping_webhook(client, mock_transport):
    mock_transport.queue_response(httpx.Response(204))
    client.webhooks.ping("end_001")
    assert "/air/webhooks/end_001/actions/ping" in str(mock_transport.last_request.url)
