"""Tests for the Orders resource."""

import httpx

from duffelbag.models import Order, Service


def test_create_order(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "ord_001",
                "booking_reference": "ABC123",
                "type": "instant",
                "total_amount": "350.00",
                "total_currency": "GBP",
                "passengers": [{
                    "id": "pas_001",
                    "given_name": "Jane",
                    "family_name": "Doe",
                    "type": "adult",
                }],
            }
        })
    )

    order = client.orders.create(
        selected_offers=["off_001"],
        passengers=[{
            "id": "pas_001",
            "given_name": "Jane",
            "family_name": "Doe",
            "born_on": "1990-01-01",
            "gender": "f",
            "title": "Ms",
            "email": "jane@example.com",
            "phone_number": "+441234567890",
        }],
        payments=[{"type": "balance", "amount": "350.00", "currency": "GBP"}],
    )

    assert isinstance(order, Order)
    assert order.id == "ord_001"
    assert order.booking_reference == "ABC123"

    body = mock_transport.last_request_json()
    assert body["data"]["selected_offers"] == ["off_001"]
    assert body["data"]["payments"][0]["type"] == "balance"


def test_list_orders_with_filters(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "meta": {"limit": 10, "after": None},
            "data": [{"id": "ord_001", "booking_reference": "XYZ"}],
        })
    )

    orders = list(client.orders.list(booking_reference="XYZ", limit=10))
    assert len(orders) == 1

    url = str(mock_transport.last_request.url)
    assert "booking_reference=XYZ" in url


def test_update_order_metadata(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={"data": {"id": "ord_001", "metadata": {"key": "val"}}})
    )

    order = client.orders.update("ord_001", metadata={"key": "val"})
    assert order.metadata == {"key": "val"}

    req = mock_transport.last_request
    assert req.method == "PATCH"
    body = mock_transport.last_request_json()
    assert body["data"]["metadata"]["key"] == "val"


def test_available_services(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": [
                {"id": "srv_001", "type": "baggage", "total_amount": "25.00", "total_currency": "GBP"},
            ]
        })
    )

    services = client.orders.available_services("ord_001")
    assert len(services) == 1
    assert isinstance(services[0], Service)
    assert services[0].type.value == "baggage"


def test_add_service(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={"data": {"id": "ord_001"}})
    )

    client.orders.add_service("ord_001", service_id="srv_001", quantity=1)

    req = mock_transport.last_request
    assert req.method == "POST"
    assert "/air/orders/ord_001/services" in str(req.url)
    body = mock_transport.last_request_json()
    assert body["data"]["id"] == "srv_001"
