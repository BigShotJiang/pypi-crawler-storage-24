"""Tests for order change resources."""

import httpx

from duffelbag.models import OrderChange, OrderChangeOffer, OrderChangeRequest


def test_create_order_change_request(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "ocr_001",
                "order_id": "ord_001",
                "order_change_offers": [
                    {"id": "oco_001", "change_total_amount": "50.00", "change_total_currency": "GBP"},
                ],
            }
        })
    )

    result = client.order_change_requests.create(
        order_id="ord_001",
        slices={
            "remove": [{"slice_id": "sli_001"}],
            "add": [{"origin": "LHR", "destination": "JFK", "departure_date": "2026-07-01"}],
        },
    )

    assert isinstance(result, OrderChangeRequest)
    assert result.order_change_offers[0].change_total_amount == "50.00"


def test_create_and_confirm_order_change(client, mock_transport):
    # Create
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {"id": "oce_001", "order_id": "ord_001"}
        })
    )

    change = client.order_changes.create(selected_order_change_offer="oco_001")
    assert isinstance(change, OrderChange)

    body = mock_transport.last_request_json()
    assert body["data"]["selected_order_change_offer"] == "oco_001"

    # Confirm
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": {"id": "oce_001", "confirmed_at": "2026-01-15T12:00:00Z"}
        })
    )

    confirmed = client.order_changes.confirm("oce_001")
    assert confirmed.confirmed_at is not None
    assert "/air/order_changes/oce_001/actions/confirm" in str(mock_transport.last_request.url)


def test_list_order_change_offers(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "meta": {"limit": 50, "after": None},
            "data": [
                {"id": "oco_001", "change_total_amount": "50.00"},
                {"id": "oco_002", "change_total_amount": "75.00"},
            ],
        })
    )

    offers = list(client.order_change_offers.list("ocr_001"))
    assert len(offers) == 2
    assert all(isinstance(o, OrderChangeOffer) for o in offers)
