"""Tests for Payments and Cards resources."""

import httpx

from duffelbag._base import CARDS_BASE_URL
from duffelbag.models import Card, Payment, ThreeDSecureSession


def test_create_payment(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "pay_001",
                "order_id": "ord_001",
                "amount": "350.00",
                "currency": "GBP",
                "type": "balance",
                "status": "succeeded",
            }
        })
    )

    payment = client.payments.create(
        order_id="ord_001",
        type="balance",
        amount="350.00",
        currency="GBP",
    )

    assert isinstance(payment, Payment)
    assert payment.status.value == "succeeded"

    body = mock_transport.last_request_json()
    assert body["data"]["order_id"] == "ord_001"
    assert body["data"]["payment"]["amount"] == "350.00"


def test_create_card_uses_cards_host(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "tcd_001",
                "brand": "visa",
                "last_4_digits": "4242",
                "name": "Jane Doe",
                "multi_use": False,
                "live_mode": False,
            }
        })
    )

    card = client.cards.create(
        number="4242424242424242",
        name="Jane Doe",
        cvc="123",
        expiry_month="12",
        expiry_year="28",
        address_line_1="1 Main St",
        address_city="London",
        address_region="Greater London",
        address_postal_code="W1A 1AA",
        address_country_code="GB",
    )

    assert isinstance(card, Card)
    assert card.brand.value == "visa"

    # Should have been sent to the cards host
    req = mock_transport.last_request
    assert str(req.url).startswith(CARDS_BASE_URL)


def test_delete_card(client, mock_transport):
    mock_transport.queue_response(httpx.Response(204))

    client.cards.delete("tcd_001")

    req = mock_transport.last_request
    assert req.method == "DELETE"
    assert str(req.url).startswith(CARDS_BASE_URL)


def test_create_3ds_session(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "3ds_001",
                "card_id": "tcd_001",
                "resource_id": "off_001",
                "status": "ready_for_payment",
                "live_mode": False,
            }
        })
    )

    session = client.three_d_secure_sessions.create(
        card_id="tcd_001",
        resource_id="off_001",
    )

    assert isinstance(session, ThreeDSecureSession)
    assert session.status.value == "ready_for_payment"
