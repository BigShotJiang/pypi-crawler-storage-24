"""Tests for Stays resources."""

import httpx

from duffelbag.models import StaysBooking, StaysQuote, StaysSearchResult


def test_search_stays(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": {
                "created_at": "2026-01-01T00:00:00Z",
                "results": [
                    {
                        "id": "srr_001",
                        "check_in_date": "2026-06-01",
                        "check_out_date": "2026-06-03",
                        "cheapest_rate_total_amount": "200.00",
                        "cheapest_rate_currency": "GBP",
                        "rooms": 1,
                        "accommodation": {"id": "acc_001", "name": "Test Hotel"},
                    }
                ],
            }
        })
    )

    results = client.stays_search.create(
        check_in_date="2026-06-01",
        check_out_date="2026-06-03",
        guests=[{"type": "adult"}],
        rooms=1,
        location={
            "geographic_coordinates": {"latitude": 51.5074, "longitude": -0.1278},
            "radius": 10,
        },
    )

    assert len(results) == 1
    assert isinstance(results[0], StaysSearchResult)
    assert results[0].accommodation.name == "Test Hotel"

    body = mock_transport.last_request_json()
    assert body["data"]["rooms"] == 1
    assert body["data"]["location"]["radius"] == 10


def test_create_quote(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "quo_001",
                "total_amount": "200.00",
                "total_currency": "GBP",
                "check_in_date": "2026-06-01",
                "check_out_date": "2026-06-03",
            }
        })
    )

    quote = client.stays_quotes.create(rate_id="rat_001")
    assert isinstance(quote, StaysQuote)
    assert quote.total_amount == "200.00"

    body = mock_transport.last_request_json()
    assert body["data"]["rate_id"] == "rat_001"


def test_create_booking(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(201, json={
            "data": {
                "id": "bok_001",
                "status": "confirmed",
                "reference": "H12345",
                "check_in_date": "2026-06-01",
                "check_out_date": "2026-06-03",
                "confirmed_at": "2026-01-15T10:00:00Z",
            }
        })
    )

    booking = client.stays_bookings.create(
        quote_id="quo_001",
        email="guest@example.com",
        phone_number="+441234567890",
        guests=[{"given_name": "Jane", "family_name": "Doe"}],
    )

    assert isinstance(booking, StaysBooking)
    assert booking.status.value == "confirmed"
    assert booking.reference == "H12345"


def test_cancel_booking(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": {
                "id": "bok_001",
                "status": "cancelled",
                "cancelled_at": "2026-01-16T10:00:00Z",
            }
        })
    )

    booking = client.stays_bookings.cancel("bok_001")
    assert booking.status.value == "cancelled"

    req = mock_transport.last_request
    assert req.method == "POST"
    assert "/stays/bookings/bok_001/actions/cancel" in str(req.url)
