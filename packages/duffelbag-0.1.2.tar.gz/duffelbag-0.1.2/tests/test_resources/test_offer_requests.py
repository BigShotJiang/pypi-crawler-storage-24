"""Tests for the OfferRequests resource."""

import httpx

from duffelbag.models import OfferRequest


def test_create_offer_request(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": {
                "id": "orq_001",
                "live_mode": False,
                "created_at": "2026-01-01T00:00:00Z",
                "cabin_class": "economy",
                "slices": [{
                    "origin_type": "airport",
                    "origin": {"id": "arp_lhr", "name": "Heathrow", "iata_code": "LHR"},
                    "destination_type": "airport",
                    "destination": {"id": "arp_jfk", "name": "JFK", "iata_code": "JFK"},
                    "departure_date": "2026-06-01",
                }],
                "offers": [{"id": "off_001", "total_amount": "350.00", "total_currency": "GBP"}],
                "passengers": [{"type": "adult"}],
                "client_key": "ck_001",
            }
        })
    )

    result = client.offer_requests.create(
        slices=[{"origin": "LHR", "destination": "JFK", "departure_date": "2026-06-01"}],
        passengers=[{"type": "adult"}],
        cabin_class="economy",
    )

    assert isinstance(result, OfferRequest)
    assert result.id == "orq_001"
    assert result.cabin_class.value == "economy"
    assert len(result.offers) == 1
    assert result.offers[0].total_amount == "350.00"

    req = mock_transport.last_request
    assert req.method == "POST"
    assert "/air/offer_requests" in str(req.url)
    assert "return_offers=true" in str(req.url)

    body = mock_transport.last_request_json()
    assert body["data"]["slices"][0]["origin"] == "LHR"
    assert body["data"]["cabin_class"] == "economy"


def test_create_with_supplier_timeout(client, mock_transport):
    mock_transport.queue_response(httpx.Response(200, json={"data": {"id": "orq_002"}}))

    client.offer_requests.create(
        slices=[{"origin": "LHR", "destination": "JFK", "departure_date": "2026-06-01"}],
        passengers=[{"type": "adult"}],
        supplier_timeout=30000,
        return_offers=False,
    )

    url = str(mock_transport.last_request.url)
    assert "supplier_timeout=30000" in url
    assert "return_offers=false" in url


def test_get_offer_request(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={"data": {"id": "orq_001", "cabin_class": "business"}})
    )

    result = client.offer_requests.get("orq_001")
    assert result.id == "orq_001"
    assert "/air/offer_requests/orq_001" in str(mock_transport.last_request.url)


def test_list_offer_requests(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "meta": {"limit": 50, "after": None},
            "data": [{"id": "orq_001"}, {"id": "orq_002"}],
        })
    )

    results = list(client.offer_requests.list())
    assert len(results) == 2
    assert all(isinstance(r, OfferRequest) for r in results)
