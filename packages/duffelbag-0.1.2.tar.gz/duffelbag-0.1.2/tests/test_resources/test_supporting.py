"""Tests for supporting resources (airlines, airports, places, etc.)."""

import httpx

from duffelbag.models import Airport, Place


def test_get_airport(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": {
                "id": "arp_lhr_gb",
                "name": "Heathrow",
                "iata_code": "LHR",
                "iata_country_code": "GB",
                "latitude": 51.4700,
                "longitude": -0.4543,
                "time_zone": "Europe/London",
            }
        })
    )

    airport = client.airports.get("arp_lhr_gb")
    assert isinstance(airport, Airport)
    assert airport.iata_code == "LHR"
    assert airport.latitude == 51.47


def test_list_airports_with_country_filter(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "meta": {"limit": 50, "after": None},
            "data": [{"id": "arp_lhr_gb", "iata_code": "LHR", "iata_country_code": "GB"}],
        })
    )

    airports = list(client.airports.list(iata_country_code="GB"))
    assert len(airports) == 1
    assert "iata_country_code=GB" in str(mock_transport.last_request.url)


def test_suggest_places(client, mock_transport):
    mock_transport.queue_response(
        httpx.Response(200, json={
            "data": [
                {"type": "airport", "id": "arp_lhr", "name": "Heathrow", "iata_code": "LHR",
                 "iata_country_code": "GB"},
                {"type": "city", "id": "cit_lon", "name": "London", "iata_code": "LON",
                 "iata_country_code": "GB"},
            ]
        })
    )

    places = client.places.suggest("heath")
    assert len(places) == 2
    assert isinstance(places[0], Place)
    assert places[0].type.value == "airport"
    assert places[1].type.value == "city"
    assert "query=heath" in str(mock_transport.last_request.url)
