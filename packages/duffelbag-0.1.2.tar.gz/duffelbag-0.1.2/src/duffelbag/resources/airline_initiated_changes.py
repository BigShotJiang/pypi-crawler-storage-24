from .._base import AsyncBaseResource, BaseResource, unwrap_response
from ..models import AirlineInitiatedChange


class AirlineInitiatedChanges(BaseResource):
    _path = "/air/airline_initiated_changes"

    def list(self, *, order_id: str | None = None) -> list[AirlineInitiatedChange]:
        resp = self._transport.request("GET", self._path, params={"order_id": order_id})
        body = unwrap_response(resp)
        return [AirlineInitiatedChange.model_validate(item) for item in body.get("data", [])]

    def update(self, id: str, *, action_taken: str) -> AirlineInitiatedChange:
        return self._update(id, AirlineInitiatedChange, {"action_taken": action_taken})

    def accept(self, id: str) -> AirlineInitiatedChange:
        return self._action(id, "accept", AirlineInitiatedChange)


class AsyncAirlineInitiatedChanges(AsyncBaseResource):
    _path = "/air/airline_initiated_changes"

    async def list(self, *, order_id: str | None = None) -> list[AirlineInitiatedChange]:
        resp = await self._transport.request("GET", self._path, params={"order_id": order_id})
        body = unwrap_response(resp)
        return [AirlineInitiatedChange.model_validate(item) for item in body.get("data", [])]

    async def update(self, id: str, *, action_taken: str) -> AirlineInitiatedChange:
        return await self._update(id, AirlineInitiatedChange, {"action_taken": action_taken})

    async def accept(self, id: str) -> AirlineInitiatedChange:
        return await self._action(id, "accept", AirlineInitiatedChange)
