from typing import Any

from .._base import CARDS_BASE_URL, AsyncBaseResource, BaseResource, unwrap_data, unwrap_response
from ..models import Card


class Cards(BaseResource):
    _path = "/payments/cards"

    def create(
        self,
        *,
        number: str,
        name: str,
        expiry_month: str,
        expiry_year: str,
        address_line_1: str,
        address_city: str,
        address_region: str,
        address_postal_code: str,
        address_country_code: str,
        cvc: str | None = None,
        multi_use: bool | None = None,
        card_id: str | None = None,
        address_line_2: str | None = None,
    ) -> Card:
        data: dict[str, Any] = {
            "number": number,
            "name": name,
            "expiry_month": expiry_month,
            "expiry_year": expiry_year,
            "address_line_1": address_line_1,
            "address_city": address_city,
            "address_region": address_region,
            "address_postal_code": address_postal_code,
            "address_country_code": address_country_code,
        }
        if cvc is not None:
            data["cvc"] = cvc
        if multi_use is not None:
            data["multi_use"] = multi_use
        if card_id is not None:
            data["card_id"] = card_id
        if address_line_2 is not None:
            data["address_line_2"] = address_line_2

        resp = self._transport.request(
            "POST", self._path, json_body={"data": data}, base_url=CARDS_BASE_URL,
        )
        return unwrap_data(resp, Card)

    def delete(self, id: str) -> None:
        resp = self._transport.request(
            "DELETE", f"{self._path}/{id}", base_url=CARDS_BASE_URL,
        )
        unwrap_response(resp)


class AsyncCards(AsyncBaseResource):
    _path = "/payments/cards"

    async def create(
        self,
        *,
        number: str,
        name: str,
        expiry_month: str,
        expiry_year: str,
        address_line_1: str,
        address_city: str,
        address_region: str,
        address_postal_code: str,
        address_country_code: str,
        cvc: str | None = None,
        multi_use: bool | None = None,
        card_id: str | None = None,
        address_line_2: str | None = None,
    ) -> Card:
        data: dict[str, Any] = {
            "number": number,
            "name": name,
            "expiry_month": expiry_month,
            "expiry_year": expiry_year,
            "address_line_1": address_line_1,
            "address_city": address_city,
            "address_region": address_region,
            "address_postal_code": address_postal_code,
            "address_country_code": address_country_code,
        }
        if cvc is not None:
            data["cvc"] = cvc
        if multi_use is not None:
            data["multi_use"] = multi_use
        if card_id is not None:
            data["card_id"] = card_id
        if address_line_2 is not None:
            data["address_line_2"] = address_line_2

        resp = await self._transport.request(
            "POST", self._path, json_body={"data": data}, base_url=CARDS_BASE_URL,
        )
        return unwrap_data(resp, Card)

    async def delete(self, id: str) -> None:
        resp = await self._transport.request(
            "DELETE", f"{self._path}/{id}", base_url=CARDS_BASE_URL,
        )
        unwrap_response(resp)
