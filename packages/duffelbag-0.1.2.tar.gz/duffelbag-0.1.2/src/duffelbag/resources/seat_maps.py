from .._base import AsyncBaseResource, BaseResource, unwrap_response
from ..models import SeatMap


class SeatMaps(BaseResource):
    _path = "/air/seat_maps"

    def list(self, offer_id: str) -> list[SeatMap]:
        resp = self._transport.request("GET", self._path, params={"offer_id": offer_id})
        body = unwrap_response(resp)
        return [SeatMap.model_validate(item) for item in body.get("data", [])]


class AsyncSeatMaps(AsyncBaseResource):
    _path = "/air/seat_maps"

    async def list(self, offer_id: str) -> list[SeatMap]:
        resp = await self._transport.request("GET", self._path, params={"offer_id": offer_id})
        body = unwrap_response(resp)
        return [SeatMap.model_validate(item) for item in body.get("data", [])]
