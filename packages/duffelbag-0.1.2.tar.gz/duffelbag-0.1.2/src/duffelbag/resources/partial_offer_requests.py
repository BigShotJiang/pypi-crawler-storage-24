from typing import Any

from .._base import AsyncBaseResource, BaseResource
from ..models import PartialOfferRequest


class PartialOfferRequests(BaseResource):
    _path = "/air/partial_offer_requests"

    def create(
        self,
        *,
        slices: list[dict[str, Any]],
        passengers: list[dict[str, Any]],
        cabin_class: str | None = None,
        max_connections: int | None = None,
        supplier_timeout: int | None = None,
        airline_credit_ids: list[str] | None = None,
        private_fares: dict[str, Any] | None = None,
    ) -> PartialOfferRequest:
        data: dict[str, Any] = {"slices": slices, "passengers": passengers}
        if cabin_class is not None:
            data["cabin_class"] = cabin_class
        if max_connections is not None:
            data["max_connections"] = max_connections
        if airline_credit_ids is not None:
            data["airline_credit_ids"] = airline_credit_ids
        if private_fares is not None:
            data["private_fares"] = private_fares

        params: dict[str, Any] = {}
        if supplier_timeout is not None:
            params["supplier_timeout"] = supplier_timeout

        return self._create(PartialOfferRequest, data, params=params or None)

    def get(self, id: str, *, selected_partial_offers: list[str] | None = None) -> PartialOfferRequest:
        params: dict[str, Any] = {}
        if selected_partial_offers:
            params["selected_partial_offer[]"] = selected_partial_offers
        return self._get(id, PartialOfferRequest, params=params or None)


class AsyncPartialOfferRequests(AsyncBaseResource):
    _path = "/air/partial_offer_requests"

    async def create(
        self,
        *,
        slices: list[dict[str, Any]],
        passengers: list[dict[str, Any]],
        cabin_class: str | None = None,
        max_connections: int | None = None,
        supplier_timeout: int | None = None,
        airline_credit_ids: list[str] | None = None,
        private_fares: dict[str, Any] | None = None,
    ) -> PartialOfferRequest:
        data: dict[str, Any] = {"slices": slices, "passengers": passengers}
        if cabin_class is not None:
            data["cabin_class"] = cabin_class
        if max_connections is not None:
            data["max_connections"] = max_connections
        if airline_credit_ids is not None:
            data["airline_credit_ids"] = airline_credit_ids
        if private_fares is not None:
            data["private_fares"] = private_fares

        params: dict[str, Any] = {}
        if supplier_timeout is not None:
            params["supplier_timeout"] = supplier_timeout

        return await self._create(PartialOfferRequest, data, params=params or None)

    async def get(self, id: str, *, selected_partial_offers: list[str] | None = None) -> PartialOfferRequest:
        params: dict[str, Any] = {}
        if selected_partial_offers:
            params["selected_partial_offer[]"] = selected_partial_offers
        return await self._get(id, PartialOfferRequest, params=params or None)
