from typing import Any

from .._base import AsyncBaseResource, AsyncPageIterator, BaseResource, PageIterator
from ..models import OfferRequest


class OfferRequests(BaseResource):
    _path = "/air/offer_requests"

    def list(self, *, limit: int | None = None) -> PageIterator[OfferRequest]:
        return self._list(OfferRequest, params={"limit": limit})

    def get(self, id: str) -> OfferRequest:
        return self._get(id, OfferRequest)

    def create(
        self,
        *,
        slices: "list[dict[str, Any]]",
        passengers: "list[dict[str, Any]]",
        cabin_class: str | None = None,
        max_connections: int | None = None,
        return_offers: bool = True,
        supplier_timeout: int | None = None,
        airline_credit_ids: "list[str] | None" = None,
        private_fares: dict[str, Any] | None = None,
    ) -> OfferRequest:
        data: dict[str, Any] = {"slices": slices, "passengers": passengers}
        if cabin_class is not None:
            data["cabin_class"] = cabin_class
        if max_connections is not None:
            data["max_connections"] = max_connections
        if airline_credit_ids is not None:
            data["airline_credit_ids"] = airline_credit_ids
        if private_fares is not None:
            data["private_fares"] = private_fares

        params: dict[str, Any] = {"return_offers": str(return_offers).lower()}
        if supplier_timeout is not None:
            params["supplier_timeout"] = supplier_timeout

        return self._create(OfferRequest, data, params=params)


class AsyncOfferRequests(AsyncBaseResource):
    _path = "/air/offer_requests"

    def list(self, *, limit: int | None = None) -> AsyncPageIterator[OfferRequest]:
        return self._list(OfferRequest, params={"limit": limit})

    async def get(self, id: str) -> OfferRequest:
        return await self._get(id, OfferRequest)

    async def create(
        self,
        *,
        slices: "list[dict[str, Any]]",
        passengers: "list[dict[str, Any]]",
        cabin_class: str | None = None,
        max_connections: int | None = None,
        return_offers: bool = True,
        supplier_timeout: int | None = None,
        airline_credit_ids: "list[str] | None" = None,
        private_fares: dict[str, Any] | None = None,
    ) -> OfferRequest:
        data: dict[str, Any] = {"slices": slices, "passengers": passengers}
        if cabin_class is not None:
            data["cabin_class"] = cabin_class
        if max_connections is not None:
            data["max_connections"] = max_connections
        if airline_credit_ids is not None:
            data["airline_credit_ids"] = airline_credit_ids
        if private_fares is not None:
            data["private_fares"] = private_fares

        params: dict[str, Any] = {"return_offers": str(return_offers).lower()}
        if supplier_timeout is not None:
            params["supplier_timeout"] = supplier_timeout

        return await self._create(OfferRequest, data, params=params)
