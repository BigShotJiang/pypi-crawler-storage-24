from typing import Any

from .._base import AsyncBaseResource, BaseResource
from ..models import BatchOfferRequest


class BatchOfferRequests(BaseResource):
    _path = "/air/batch_offer_requests"

    def create(
        self,
        *,
        slices: list[dict[str, Any]],
        passengers: list[dict[str, Any]],
        cabin_class: str | None = None,
        max_connections: int | None = None,
        supplier_timeout: int | None = None,
        airline_credit_ids: list[str] | None = None,
        private_fares: dict[str, Any] | None = None,
    ) -> BatchOfferRequest:
        data: dict[str, Any] = {"slices": slices, "passengers": passengers}
        if cabin_class is not None:
            data["cabin_class"] = cabin_class
        if max_connections is not None:
            data["max_connections"] = max_connections
        if airline_credit_ids is not None:
            data["airline_credit_ids"] = airline_credit_ids
        if private_fares is not None:
            data["private_fares"] = private_fares

        params: dict[str, Any] = {}
        if supplier_timeout is not None:
            params["supplier_timeout"] = supplier_timeout

        return self._create(BatchOfferRequest, data, params=params or None)

    def get(self, id: str) -> BatchOfferRequest:
        return self._get(id, BatchOfferRequest)


class AsyncBatchOfferRequests(AsyncBaseResource):
    _path = "/air/batch_offer_requests"

    async def create(
        self,
        *,
        slices: list[dict[str, Any]],
        passengers: list[dict[str, Any]],
        cabin_class: str | None = None,
        max_connections: int | None = None,
        supplier_timeout: int | None = None,
        airline_credit_ids: list[str] | None = None,
        private_fares: dict[str, Any] | None = None,
    ) -> BatchOfferRequest:
        data: dict[str, Any] = {"slices": slices, "passengers": passengers}
        if cabin_class is not None:
            data["cabin_class"] = cabin_class
        if max_connections is not None:
            data["max_connections"] = max_connections
        if airline_credit_ids is not None:
            data["airline_credit_ids"] = airline_credit_ids
        if private_fares is not None:
            data["private_fares"] = private_fares

        params: dict[str, Any] = {}
        if supplier_timeout is not None:
            params["supplier_timeout"] = supplier_timeout

        return await self._create(BatchOfferRequest, data, params=params or None)

    async def get(self, id: str) -> BatchOfferRequest:
        return await self._get(id, BatchOfferRequest)
