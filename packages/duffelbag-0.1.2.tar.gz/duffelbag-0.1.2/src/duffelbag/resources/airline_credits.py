from typing import Any

from .._base import AsyncBaseResource, AsyncPageIterator, BaseResource, PageIterator
from ..models import AirlineCredit


class AirlineCredits(BaseResource):
    _path = "/air/airline_credits"

    def list(self, *, user_id: str | None = None, limit: int | None = None) -> PageIterator[AirlineCredit]:
        return self._list(AirlineCredit, params={"user_id": user_id, "limit": limit})

    def get(self, id: str) -> AirlineCredit:
        return self._get(id, AirlineCredit)

    def create(
        self,
        *,
        airline_iata_code: str,
        amount: str,
        amount_currency: str,
        code: str,
        expires_at: str,
        issued_on: str,
        type: str,
        user_id: str | None = None,
        given_name: str | None = None,
        family_name: str | None = None,
    ) -> AirlineCredit:
        data: dict[str, Any] = {
            "airline_iata_code": airline_iata_code,
            "amount": amount,
            "amount_currency": amount_currency,
            "code": code,
            "expires_at": expires_at,
            "issued_on": issued_on,
            "type": type,
        }
        if user_id is not None:
            data["user_id"] = user_id
        if given_name is not None:
            data["given_name"] = given_name
        if family_name is not None:
            data["family_name"] = family_name
        return self._create(AirlineCredit, data)


class AsyncAirlineCredits(AsyncBaseResource):
    _path = "/air/airline_credits"

    def list(self, *, user_id: str | None = None, limit: int | None = None) -> AsyncPageIterator[AirlineCredit]:
        return self._list(AirlineCredit, params={"user_id": user_id, "limit": limit})

    async def get(self, id: str) -> AirlineCredit:
        return await self._get(id, AirlineCredit)

    async def create(
        self,
        *,
        airline_iata_code: str,
        amount: str,
        amount_currency: str,
        code: str,
        expires_at: str,
        issued_on: str,
        type: str,
        user_id: str | None = None,
        given_name: str | None = None,
        family_name: str | None = None,
    ) -> AirlineCredit:
        data: dict[str, Any] = {
            "airline_iata_code": airline_iata_code,
            "amount": amount,
            "amount_currency": amount_currency,
            "code": code,
            "expires_at": expires_at,
            "issued_on": issued_on,
            "type": type,
        }
        if user_id is not None:
            data["user_id"] = user_id
        if given_name is not None:
            data["given_name"] = given_name
        if family_name is not None:
            data["family_name"] = family_name
        return await self._create(AirlineCredit, data)
