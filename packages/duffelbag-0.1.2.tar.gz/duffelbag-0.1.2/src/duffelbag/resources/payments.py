from typing import Any

from .._base import AsyncBaseResource, AsyncPageIterator, BaseResource, PageIterator
from ..models import Payment


class Payments(BaseResource):
    _path = "/air/payments"

    def list(self, order_id: str, *, limit: int | None = None) -> PageIterator[Payment]:
        return self._list(Payment, params={"order_id": order_id, "limit": limit})

    def get(self, id: str) -> Payment:
        return self._get(id, Payment)

    def create(
        self,
        *,
        order_id: str,
        type: str,
        amount: str,
        currency: str,
        three_d_secure_session_id: str | None = None,
    ) -> Payment:
        payment: dict[str, Any] = {"type": type, "amount": amount, "currency": currency}
        if three_d_secure_session_id is not None:
            payment["three_d_secure_session_id"] = three_d_secure_session_id
        return self._create(Payment, {"order_id": order_id, "payment": payment})


class AsyncPayments(AsyncBaseResource):
    _path = "/air/payments"

    def list(self, order_id: str, *, limit: int | None = None) -> AsyncPageIterator[Payment]:
        return self._list(Payment, params={"order_id": order_id, "limit": limit})

    async def get(self, id: str) -> Payment:
        return await self._get(id, Payment)

    async def create(
        self,
        *,
        order_id: str,
        type: str,
        amount: str,
        currency: str,
        three_d_secure_session_id: str | None = None,
    ) -> Payment:
        payment: dict[str, Any] = {"type": type, "amount": amount, "currency": currency}
        if three_d_secure_session_id is not None:
            payment["three_d_secure_session_id"] = three_d_secure_session_id
        return await self._create(Payment, {"order_id": order_id, "payment": payment})
