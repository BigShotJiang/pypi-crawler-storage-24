from typing import Any

from .._base import AsyncBaseResource, BaseResource
from ..models import ThreeDSecureSession


class ThreeDSecureSessions(BaseResource):
    _path = "/payments/three_d_secure_sessions"

    def create(
        self,
        *,
        card_id: str,
        resource_id: str,
        services: list[dict[str, Any]] | None = None,
        exception: str | None = None,
    ) -> ThreeDSecureSession:
        data: dict[str, Any] = {"card_id": card_id, "resource_id": resource_id}
        if services is not None:
            data["services"] = services
        if exception is not None:
            data["exception"] = exception
        return self._create(ThreeDSecureSession, data)


class AsyncThreeDSecureSessions(AsyncBaseResource):
    _path = "/payments/three_d_secure_sessions"

    async def create(
        self,
        *,
        card_id: str,
        resource_id: str,
        services: list[dict[str, Any]] | None = None,
        exception: str | None = None,
    ) -> ThreeDSecureSession:
        data: dict[str, Any] = {"card_id": card_id, "resource_id": resource_id}
        if services is not None:
            data["services"] = services
        if exception is not None:
            data["exception"] = exception
        return await self._create(ThreeDSecureSession, data)
