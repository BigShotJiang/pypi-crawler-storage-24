from .._base import AsyncBaseResource, AsyncPageIterator, BaseResource, PageIterator
from ..models import OrderCancellation


class OrderCancellations(BaseResource):
    _path = "/air/order_cancellations"

    def list(self, *, order_id: str | None = None, limit: int | None = None) -> PageIterator[OrderCancellation]:
        return self._list(OrderCancellation, params={"order_id": order_id, "limit": limit})

    def get(self, id: str) -> OrderCancellation:
        return self._get(id, OrderCancellation)

    def create(self, *, order_id: str) -> OrderCancellation:
        return self._create(OrderCancellation, {"order_id": order_id})

    def confirm(self, id: str) -> OrderCancellation:
        return self._action(id, "confirm", OrderCancellation)


class AsyncOrderCancellations(AsyncBaseResource):
    _path = "/air/order_cancellations"

    def list(self, *, order_id: str | None = None, limit: int | None = None) -> AsyncPageIterator[OrderCancellation]:
        return self._list(OrderCancellation, params={"order_id": order_id, "limit": limit})

    async def get(self, id: str) -> OrderCancellation:
        return await self._get(id, OrderCancellation)

    async def create(self, *, order_id: str) -> OrderCancellation:
        return await self._create(OrderCancellation, {"order_id": order_id})

    async def confirm(self, id: str) -> OrderCancellation:
        return await self._action(id, "confirm", OrderCancellation)
