"""Resource modules for the Duffel API."""
