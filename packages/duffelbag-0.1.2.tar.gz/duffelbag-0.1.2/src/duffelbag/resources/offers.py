from typing import Any

from .._base import AsyncBaseResource, AsyncPageIterator, BaseResource, PageIterator, unwrap_data, unwrap_response
from ..models import Offer


class Offers(BaseResource):
    _path = "/air/offers"

    def list(
        self,
        offer_request_id: str,
        *,
        limit: int | None = None,
        sort: str | None = None,
        max_connections: int | None = None,
    ) -> PageIterator[Offer]:
        return self._list(
            Offer,
            params={
                "offer_request_id": offer_request_id,
                "limit": limit,
                "sort": sort,
                "max_connections": max_connections,
            },
        )

    def get(self, id: str, *, return_available_services: bool = False) -> Offer:
        return self._get(id, Offer, params={"return_available_services": return_available_services})

    def price(
        self,
        id: str,
        *,
        intended_payment_methods: "list[dict[str, Any]]",
        intended_services: "list[dict[str, Any]] | None" = None,
    ) -> Offer:
        data: dict[str, Any] = {
            "intended_payment_methods": intended_payment_methods,
            "intended_services": intended_services or [],
        }
        return self._action(id, "price", Offer, data=data)

    def update_passenger(
        self,
        offer_id: str,
        passenger_id: str,
        *,
        given_name: str,
        family_name: str,
        loyalty_programme_accounts: "list[dict[str, Any]] | None" = None,
    ) -> dict:
        data: dict[str, Any] = {"given_name": given_name, "family_name": family_name}
        if loyalty_programme_accounts is not None:
            data["loyalty_programme_accounts"] = loyalty_programme_accounts
        resp = self._transport.request(
            "PATCH",
            f"{self._path}/{offer_id}/passengers/{passenger_id}",
            json_body={"data": data},
        )
        return unwrap_response(resp).get("data", {})


class AsyncOffers(AsyncBaseResource):
    _path = "/air/offers"

    def list(
        self,
        offer_request_id: str,
        *,
        limit: int | None = None,
        sort: str | None = None,
        max_connections: int | None = None,
    ) -> AsyncPageIterator[Offer]:
        return self._list(
            Offer,
            params={
                "offer_request_id": offer_request_id,
                "limit": limit,
                "sort": sort,
                "max_connections": max_connections,
            },
        )

    async def get(self, id: str, *, return_available_services: bool = False) -> Offer:
        return await self._get(id, Offer, params={"return_available_services": return_available_services})

    async def price(
        self,
        id: str,
        *,
        intended_payment_methods: "list[dict[str, Any]]",
        intended_services: "list[dict[str, Any]] | None" = None,
    ) -> Offer:
        data: dict[str, Any] = {
            "intended_payment_methods": intended_payment_methods,
            "intended_services": intended_services or [],
        }
        return await self._action(id, "price", Offer, data=data)

    async def update_passenger(
        self,
        offer_id: str,
        passenger_id: str,
        *,
        given_name: str,
        family_name: str,
        loyalty_programme_accounts: "list[dict[str, Any]] | None" = None,
    ) -> dict:
        data: dict[str, Any] = {"given_name": given_name, "family_name": family_name}
        if loyalty_programme_accounts is not None:
            data["loyalty_programme_accounts"] = loyalty_programme_accounts
        resp = await self._transport.request(
            "PATCH",
            f"{self._path}/{offer_id}/passengers/{passenger_id}",
            json_body={"data": data},
        )
        return unwrap_response(resp).get("data", {})
