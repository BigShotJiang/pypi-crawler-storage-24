"""Explore Duffel's reference data: airlines, airports, aircraft, and places.

Usage:
    python examples/explore_reference_data.py

Requires DUFFEL_TOKEN environment variable or a test_api_key file in the project root.
"""

import os
from pathlib import Path

from duffelbag import Duffel

TOKEN = os.environ.get("DUFFEL_TOKEN") or Path("test_api_key").read_text().strip()

client = Duffel(token=TOKEN)

# --- Airlines (one page of 10) ---

print("Airlines (first 10):")
for airline in client.airlines.list(limit=10).page():
    print(f"  [{airline.iata_code or '  ':2s}] {airline.name}")

# --- Airports in a country ---

print("\nAirports in Germany (first 10):")
for airport in client.airports.list(limit=10, iata_country_code="DE").page():
    city_name = airport.city_name or "Unknown city"
    print(f"  {airport.iata_code}  {airport.name} ({city_name})")

# --- Aircraft types ---

print("\nAircraft types (first 10):")
for aircraft in client.aircraft.list(limit=10).page():
    print(f"  [{aircraft.iata_code or '  ':3s}] {aircraft.name}")

# --- Place search ---

print("\nPlace suggestions for 'Paris':")
places = client.places.suggest("Paris")
for place in places[:5]:
    print(f"  {place.type:10s}  {place.iata_code or '---':3s}  {place.name}")

# --- Loyalty programmes ---

print("\nLoyalty programmes (first 5):")
for prog in client.loyalty_programmes.list(limit=5).page():
    print(f"  {prog.name} (alliance: {prog.alliance or 'none'})")

client.close()
