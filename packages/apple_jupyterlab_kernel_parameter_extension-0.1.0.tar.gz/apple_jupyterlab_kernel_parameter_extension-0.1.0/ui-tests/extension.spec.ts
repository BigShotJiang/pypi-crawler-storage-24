import { test, expect } from '@playwright/test';
import { galata } from '@jupyterlab/galata';

/**
 * Don't load JupyterLab webpage before running the tests.
 */
test.use({ autoGoto: false });

test.describe(' Extension UI Tests', () => {
  test.beforeEach(async ({ page, baseURL }) => {
    await galata.resetUI(page, baseURL!);
    await galata.waitForApplication(page);
  });

  test('should load the extension', async ({ page }) => {
    // Check that JupyterLab loaded successfully
    await expect(page.locator('#jupyterlab-splash')).toBeHidden();
    
    // Verify the extension is loaded by checking for the menu item
    const helpMenu = page.locator('[data-menu="Help"]');
    await expect(helpMenu).toBeVisible();
    
    // Open Help menu
    await helpMenu.click();
    
    // Check for About menu item (customize this for your extension)
    const aboutMenuItem = page.locator('text="About "');
    await expect(aboutMenuItem).toBeVisible();
  });

  test('should open About dialog from Help menu', async ({ page }) => {
    // Open Help menu
    const helpMenu = page.locator('[data-menu="Help"]');
    await helpMenu.click();
    
    // Click on About item
    const aboutMenuItem = page.locator('text="About "');
    await aboutMenuItem.click();
    
    // Verify the About dialog opens
    const aboutDialog = page.locator('.jp-Dialog');
    await expect(aboutDialog).toBeVisible();
    
    // Check dialog title
    const dialogHeader = page.locator('.jp-Dialog-header');
    await expect(dialogHeader).toContainText('About ');
  });

  test('should close About dialog with Close button', async ({ page }) => {
    await openAboutDialog(page);
    
    const aboutDialog = page.locator('.jp-Dialog');
    await expect(aboutDialog).toBeVisible();
    
    // Click Close button
    const closeButton = page.locator('.jp-Dialog-button.jp-mod-accept');
    await closeButton.click();
    
    // Verify dialog is closed
    await expect(aboutDialog).toBeHidden();
  });

  test('should have proper accessibility attributes', async ({ page }) => {
    await openAboutDialog(page);
    
    const aboutDialog = page.locator('.jp-Dialog');
    
    // Check for proper ARIA attributes
    await expect(aboutDialog).toHaveAttribute('role', 'dialog');
    
    // Check for proper focus management
    const focusedElement = page.locator(':focus');
    await expect(focusedElement).toBeVisible();
  });
});

/**
 * Helper function to open the About dialog
 */
async function openAboutDialog(page: any): Promise<void> {
  const helpMenu = page.locator('[data-menu="Help"]');
  await helpMenu.click();
  
  const aboutMenuItem = page.locator('text="About "');
  await aboutMenuItem.click();
  
  const aboutDialog = page.locator('.jp-Dialog');
  await expect(aboutDialog).toBeVisible();
}
