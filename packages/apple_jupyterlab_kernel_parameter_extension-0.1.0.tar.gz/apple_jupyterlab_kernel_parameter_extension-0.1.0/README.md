# JupyterLab Kernel Parameter Extension

A JupyterLab 4.x extension that enables dynamic kernel parameter configuration through interactive dialogs. When launching kernels that define configuration schemas in their metadata, users are presented with a form to specify runtime parameters before kernel startup.

The extension automatically detects kernels with configuration schemas defined in `metadata.kernel_provisioner.config` within the kernel.json file. For example, a kernel with this configuration:

```json
{
  "metadata": {
    "kernel_provisioner": {
      "config": {
        "properties": {
          "memory": {
            "title": "Memory (GB)",
            "type": "string",
            "default": "8"
          }
        }
      }
    }
  }
}
```

Will automatically trigger a configuration dialog when selected. The forms are generated using [JSONForms](https://jsonforms.io/), a declarative framework for building forms from JSON Schema.

![Kernel Parameter Configuration Dialog](etc/resources/kernel-parameter.png)


## Features

- **Dynamic Configuration Dialogs** - Automatically generates forms from kernel metadata schemas
- **Multiple Input Types** - Supports text, textarea, dropdowns, editable dropdowns, and checkboxes
- **Field Validation** - JSON Schema validation plus custom rules (required, pattern, range, etc.)
- **Field Cascading** - Dropdown selections can show/hide or update other fields
- **Configuration Persistence** - Saves to both notebook metadata and browser localStorage
- **Keyboard Accessible** - Full keyboard navigation with Escape to cancel, Enter to submit
- **Universal Interception** - Captures kernel selection from menu, toolbar, and launcher tiles

## Installation

Install from Apple's internal PyPI:

```bash
pip install apple_jupyterlab_kernel_parameter_extension --index-url https://pypi.apple.com/simple
```

## Development

1. Clone the repository:
   ```bash
   git clone git@github.pie.apple.com:seven-of-nine/apple-jupyterlab-kernel-parameter-extension.git
   cd apple-jupyterlab-kernel-parameter-extension
   ```

2. Install dependencies:
   ```bash
   pip install -e .
   jlpm install
   ```

3. Build the extension:
   ```bash
   jlpm build
   ```

4. Link the extension to JupyterLab:
   ```bash
   jupyter labextension develop . --overwrite
   ```

5. Refresh JupyterLab in your browser after code changes (Cmd+Shift+R / Ctrl+Shift+R)

### Watch Mode

For active development, use watch mode to automatically rebuild on changes:

```bash
jlpm watch
```

This runs both TypeScript and labextension watchers in parallel. Keep this running and refresh your browser to see changes.

## Kernel Configuration Schema

To enable parameter configuration for a kernel, add a `config` schema to the kernel spec's `metadata.kernel_provisioner` section:

```json
{
  "display_name": "Python 3 with Parameters",
  "language": "python",
  "metadata": {
    "kernel_provisioner": {
      "provisioner_name": "local-provisioner",
      "config": {
        "title": "Kernel Parameters",
        "type": "object",
        "properties": {
          "queue_name": {
            "title": "Queue Name",
            "type": "string",
            "default": "default-queue",
            "description": "Compute queue for job submission",
            "enum": ["default-queue", "gpu-queue", "high-memory"],
            "validation": {
              "required": true
            }
          },
          "memory": {
            "title": "Memory (GB)",
            "type": "string",
            "default": "8",
            "description": "Memory allocation in gigabytes",
            "validation": {
              "required": true,
              "range": {
                "min": 1,
                "max": 256
              }
            }
          },
          "spark_config": {
            "title": "Spark Configuration",
            "type": "string",
            "rows": 10,
            "default": "spark.executor.memory=4g\nspark.driver.memory=2g",
            "description": "Additional Spark configuration (one per line)"
          }
        }
      }
    }
  }
}
```

### Supported Field Types

- **Text Input** - `type: "string"` with single-line input
- **Textarea** - `type: "string"` with `rows` property or `format: "textarea"`
- **Dropdown** - `type: "string"` with `enum` array
- **Editable Dropdown** - Dropdown with `editable: true` allows custom values
- **Checkbox** - `type: "boolean"`

### Validation Options

```json
{
  "validation": {
    "required": true,
    "range": { "min": 1, "max": 100 },
    "startsWith": "https://",
    "pattern": {
      "value": "^[a-z0-9-]+$",
      "errorMessage": "Only lowercase letters, numbers, and hyphens allowed"
    }
  }
}
```

### Field Cascading

Control field visibility and defaults based on dropdown selections:

```json
{
  "queue_name": {
    "enum": ["standard", "gpu"],
    "enumInteractionOverrides": [
      {
        "enumValue": "gpu",
        "fieldsToModify": [
          {
            "field": "gpu_type",
            "visible": true,
            "setDefaultTo": "nvidia-v100"
          },
          {
            "field": "gpu_count",
            "visible": true
          }
        ]
      }
    ]
  }
}
```

## Publishing

Version management and publishing are handled automatically by the Rio CI/CD pipeline. To create a release:

1. Go to the Rio console
2. Navigate to the Release pipeline
3. Click "Build with Parameters"
4. Select version bump type (major, minor, patch)
5. Click "Build"

The pipeline will automatically bump versions, build packages, run tests, and publish to Apple's registries.

## Architecture

See [CLAUDE.md](./CLAUDE.md) for detailed architecture documentation, including:
- Triple interception strategy for capturing kernel selection
- JSONForms renderer system
- Configuration persistence mechanism
- Type system and validation architecture

## License

BSD-3-Clause

