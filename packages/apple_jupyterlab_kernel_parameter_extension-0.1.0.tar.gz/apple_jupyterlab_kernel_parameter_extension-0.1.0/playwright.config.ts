import { PlaywrightTestConfig, devices } from '@playwright/test';

/**
 * See https://playwright.dev/docs/test-configuration.
 */
const config: PlaywrightTestConfig = {
  testDir: './ui-tests',
  timeout: 60000, // Reduced from 120s
  expect: {
    timeout: 10000, // Reduced from 20s
  },
  fullyParallel: false, // Disable parallel execution for stability
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0, // Reduced retries
  workers: 8, // Use single worker for stability
  reporter: process.env.CI ? 'github' : 'list',

  use: {
    baseURL: process.env.TARGET_URL ?? 'http://localhost:28888',
    trace: 'retain-on-failure',
    video: 'off', // Disable video recording to avoid ffmpeg dependency
    screenshot: 'only-on-failure',
    // Add navigation timeout
    navigationTimeout: 30000,
    // Add action timeout
    actionTimeout: 10000,
  },

  projects: [
    {
      name: 'galata',
      testMatch: 'ui-tests/**/*.spec.ts',
      use: {
        ...devices['Desktop Chrome'],
        // Use Galata's viewport
        channel: "chrome",
        viewport: { width: 1024, height: 768 },
        // Disable web security for local testing
        launchOptions: {
          args: ['--disable-web-security', '--disable-features=VizDisplayCompositor'],
        },
      },
    },
  ],

  webServer: {
    command: 'jupyter lab --no-browser --port=28888 --ip=0.0.0.0 --ServerApp.token="" --ServerApp.password="" --ServerApp.disable_check_xsrf=True --ServerApp.allow_origin="*" --ServerApp.allow_remote_access=True --allow-root',
    port: 28888,
    timeout: 60000, // Reduced timeout
    reuseExistingServer: !process.env.CI,
    stdout: 'pipe',
    stderr: 'pipe',
  },
};

export default config;
