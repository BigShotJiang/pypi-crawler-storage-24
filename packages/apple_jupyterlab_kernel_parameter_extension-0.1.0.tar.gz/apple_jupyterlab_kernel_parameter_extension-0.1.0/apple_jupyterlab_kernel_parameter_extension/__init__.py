"""

"""

try:
    from ._version import __version__
except ImportError:
    # Fallback when using the package in dev mode without installing
    # in editable mode with pip. It is highly recommended to install
    # the package from a stable release or in editable mode: https://pip.pypa.io/en/stable/topics/local-project-installs/#editable-installs
    import warnings
    warnings.warn("Importing 'apple_kernel_parameter_extension' outside a proper installation.")
    __version__ = "dev"


def _jupyter_labextension_paths():
    """Returns a list of labextension paths."""
    return [{
        "src": "labextension",
        "dest": "@apple/jupyterlab-kernel-parameter-extension"
    }]


__all__ = ["__version__", "_jupyter_labextension_paths"]
