# Changelog

All notable changes to JupyterLab Kernel Parameter Extension will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Complete kernel parameter configuration system with JSONForms integration
- Custom renderers for Select, EditableSelect, String, TextArea, and Checkbox inputs
- Triple interception strategy covering menu, toolbar, and launcher tile kernel selection
- Field cascading support via `enumInteractionOverrides` for dynamic form behavior
- Dual-tier validation system (JSON Schema + custom validation rules)
- Configuration persistence to both notebook metadata and browser localStorage
- Server disconnect monitoring with cross-tab synchronization
- Kernel error event listener with user-friendly error dialogs
- Enhanced dialog with validation blocking, auto-focus, and keyboard navigation
- Escape key support for canceling dialogs
- Enter key validation (blocks submission with errors, allows in textarea)
- Auto-focus on first input field when dialog opens
- "Restore Defaults" button for resetting fields to saved defaults
- Global `window.debugKernelSelector()` debug function
- Comprehensive debug logging with prefixed console messages
- CLAUDE.md architecture documentation
- Complete README with usage examples and kernel configuration guide

### Changed
- **BREAKING**: Renamed package from `@apple/kernel-parameter-extension` to `@apple/jupyterlab-kernel-parameter-extension`
- **BREAKING**: Renamed Python package from `apple_kernel_parameter_extension` to `apple_jupyterlab_kernel_parameter_extension`
- Updated plugin IDs to `@apple/jupyterlab-kernel-parameter-extension:plugin` and `:raiseErrors`
- Migrated from old extension format to modern JupyterLab 4.x architecture
- Changed ExtendedJsonSchema from interface to type intersection to avoid JupyterLab type conflicts
- Made IDocumentManager optional instead of required for better compatibility
- Converted TypeScript files with JSX to .tsx extension
- Enhanced TextArea tester to support `rows` property, `options.multi`, and `format: "textarea"`
- Improved dialog height to 80vh with scrollable content
- Standardized all form control widths and alignment for consistent visual appearance
- Updated all input fields to use `width: calc(100% - 4px)` to prevent overflow
- Enhanced focus states with blue border and subtle shadow
- Improved textarea with monospace font and `resize: vertical`

### Fixed
- TypeScript compilation errors from incorrect include pattern (changed to recursive `src/**/*`)
- JSX syntax errors by renaming .ts files to .tsx where needed
- Interface type conflicts with JupyterLab's JSON Schema types
- Property access errors on KernelConfigurationWidget methods
- Null handling in stringifyConfigObject for ConfigMap values
- Plugin loading issues when IDocumentManager not available
- Escape key not working until field is focused (added auto-focus)
- Textarea overflow beyond dialog boundaries
- Inconsistent padding causing layout issues
- TextArea not activating for fields with `rows` property in schema

### Technical Details
- Uses JSONForms 3.3 for declarative form generation
- Implements custom renderers with rank-based selection system
- Wraps `sessionContextDialogs.selectKernel` for menu-based selection
- Wraps `sessionContext.changeKernel` for each notebook via INotebookTracker
- Intercepts `app.commands.execute` for launcher tile commands
- Stores configuration in notebook metadata as `kernel_params`
- Uses localStorage for pre-filling forms on subsequent kernel selections

## [0.1.0] - 2025-01-01

### Added
- Initial release of Kernel Parameter
- Basic JupyterLab extension functionality
- Python package structure
- Build and publish automation
- Rio CI/CD pipeline for automated publishing
- npm package support with Lerna monorepo
- Python package with hatch build system
- Version bumping automation
- Dual publishing support (PyPI + npm)