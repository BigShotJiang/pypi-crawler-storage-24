# Release Process

This document outlines the release process for Kernel Parameter.

## Automated Release via Rio

The easiest way to create a release is through the Rio pipeline:

1. **Trigger Release Pipeline**
   - Go to the Rio console
   - Navigate to your project's Release pipeline
   - Click "Build with Parameters"
   - Select version bump type (major, minor, patch)
   - Click "Build"

2. **What the Pipeline Does**
   - Bumps version in all relevant files
   - Builds Python and npm packages
   - Runs tests and validation
   - Commits version changes
   - Creates git tag
   - Publishes to Apple registries
   - Creates GitHub release

## Manual Release

For local testing or troubleshooting, you can build packages manually:

### 1. Build

```bash
# Build TypeScript packages
jlpm build
# Build Python package
python -m build

# Validate builds
ls dist/
```

### 2. Publish

Publishing should be done through the Rio pipeline. For manual publishing:

```bash
# Publish npm packages
npm publish --registry https://npm.apple.com
# Publish Python package
twine upload dist/*
```

### 3. Git Operations

```bash
# Get version from package.json
VERSION=$(python -c "import json; print(json.load(open('package.json'))['version'])")
# Commit version changes
git commit -am "Bump to version ${VERSION}"

# Create tag
git tag "v${VERSION}"

# Push changes and tag
git push origin main
git push origin "v${VERSION}"
```

## Release Checklist

Before releasing:

- [ ] All tests pass
- [ ] Documentation is updated
- [ ] CHANGELOG.md is updated
- [ ] Version bump is appropriate (follows semver)
- [ ] No uncommitted changes

After releasing:

- [ ] Verify packages are available in registries
- [ ] Test installation from published packages
- [ ] Update downstream dependencies if needed
- [ ] Announce release to relevant stakeholders

## Troubleshooting

### Build Failures

1. Check dependencies: `jlpm install`
2. Clean and rebuild: `jlpm clean && jlpm build`
3. Check TypeScript compilation: `jlpm build`

### Publish Failures

1. Check credentials and registry access
2. Verify package names don't conflict
3. Check for network issues
4. Review Rio pipeline logs

### Version Issues

1. Ensure all package.json files have consistent versions
2. Check _version.py matches package.json
3. Verify git tags don't conflict

## Registry Information

- **Python**: Published to https://pypi.apple.com/simple/
- **npm**: Published to https://npm.apple.com/ (if npm packages enabled)

For access issues, contact your DevOps team.