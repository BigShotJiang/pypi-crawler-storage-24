/**
 * JupyterLab Kernel Parameter Extension
 *
 * Enables kernel configuration dialogs based on kernel metadata,
 * allowing users to set kernel parameters before launching.
 */

import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';
import { ISessionContextDialogs, Dialog } from '@jupyterlab/apputils';
import { ITranslator, nullTranslator } from '@jupyterlab/translation';
import { DocumentManager, IDocumentManager } from '@jupyterlab/docmanager';
import { INotebookTracker } from '@jupyterlab/notebook';
import { Event, KernelSpec } from '@jupyterlab/services';
import { showErrorMessage } from '@jupyterlab/apputils';
import { customSelectKernelWrapper } from './services/customKernelSelector';
import { EventListener } from './services/eventListener';
import { serverDisconnectMonitor } from './services/serverDisconnectMonitor';
import { extractErrorMessage } from './utils/errorParser';
import { KernelEvent } from './types';
import { KernelConfigurationWidget } from './components/KernelConfiguration';
import { customFormDialog, restoreDefaultsButton } from './components/dialogs';
import { saveConfig } from './utils/schemaHelpers';

/**
 * Main kernel parameter extension plugin
 *
 * Overrides the kernel selector to add configuration support
 * and monitors for server shutdowns.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: '@apple/jupyterlab-kernel-parameter-extension:plugin',
  description: 'Kernel parameter configuration extension',
  autoStart: true,
  requires: [ISessionContextDialogs, ITranslator, INotebookTracker],
  optional: [IDocumentManager],
  activate: (
    app: JupyterFrontEnd,
    sessionContextDialogs: ISessionContextDialogs,
    translator: ITranslator,
    notebookTracker: INotebookTracker,
    docManager: IDocumentManager | null
  ) => {
    console.log(
      'JupyterLab extension @apple/jupyterlab-kernel-parameter-extension:plugin is activated!'
    );

    console.log('[Plugin] sessionContextDialogs:', sessionContextDialogs);
    console.log('[Plugin] Original selectKernel:', sessionContextDialogs.selectKernel);

    if (!docManager) {
      console.error('IDocumentManager not available, kernel parameter extension cannot function');
      return;
    }

    console.log('[Plugin] IDocumentManager available:', docManager);

    // Override the kernel selector with our custom implementation
    const originalSelectKernel = sessionContextDialogs.selectKernel;
    const customSelector = customSelectKernelWrapper(
      app,
      docManager as DocumentManager,
      translator
    );

    sessionContextDialogs.selectKernel = customSelector;

    console.log('[Plugin] selectKernel has been overridden!');
    console.log('[Plugin] New selectKernel:', sessionContextDialogs.selectKernel);
    console.log('[Plugin] Are they different?', originalSelectKernel !== sessionContextDialogs.selectKernel);

    // Check if override persists after delay
    setTimeout(() => {
      console.log('[Plugin] Checking override after 5s...');
      console.log('[Plugin] Current selectKernel:', sessionContextDialogs.selectKernel);
      console.log('[Plugin] Is still our function?', sessionContextDialogs.selectKernel === customSelector);
      if (sessionContextDialogs.selectKernel !== customSelector) {
        console.error('[Plugin] WARNING: selectKernel was overridden by something else!');
      }
    }, 5000);

    // Also make it accessible globally for debugging
    (window as any).debugKernelSelector = () => {
      console.log('[Debug] Current selectKernel:', sessionContextDialogs.selectKernel);
      console.log('[Debug] Is our function?', sessionContextDialogs.selectKernel === customSelector);
      console.log('[Debug] sessionContextDialogs:', sessionContextDialogs);
    };

    console.log('[Plugin] Run window.debugKernelSelector() to check override status');

    // Start server disconnect monitoring
    serverDisconnectMonitor();

    // Also intercept toolbar kernel selections by wrapping changeKernel for each notebook
    console.log('[Plugin] Setting up notebook tracking to intercept toolbar kernel selections');

    /**
     * Wrap a notebook's sessionContext.changeKernel to show config dialog
     */
    const wrapChangeKernel = (notebookPanel: any): void => {
      const sessionContext = notebookPanel.sessionContext;
      if (!sessionContext || sessionContext._changeKernelWrapped) {
        return; // Already wrapped or no session context
      }

      console.log('[Plugin] Wrapping changeKernel for notebook:', notebookPanel.id);

      const originalChangeKernel = sessionContext.changeKernel.bind(sessionContext);
      sessionContext._changeKernelWrapped = true;

      sessionContext.changeKernel = async (options: any) => {
        console.log('[Toolbar] changeKernel intercepted, options:', options);

        // If no model/name specified, call original (like shutdown)
        if (!options || (!options.name && !options.id)) {
          console.log('[Toolbar] No kernel specified, calling original');
          return originalChangeKernel(options);
        }

        const kernelName = options.name || options.id;
        console.log('[Toolbar] Kernel name:', kernelName);

        // Get kernel spec
        const serviceManager = app.serviceManager;
        await serviceManager.ready;

        const kernelspec = serviceManager.kernelspecs?.specs?.kernelspecs[kernelName];
        console.log('[Toolbar] Kernel spec:', kernelspec);

        const hasConfig = !!(kernelspec?.metadata?.kernel_provisioner as any)?.config;
        console.log('[Toolbar] Has config:', hasConfig);

        if (!hasConfig) {
          console.log('[Toolbar] No config, calling original changeKernel');
          // Clear params for non-config kernels
          if (notebookPanel.context?.model) {
            notebookPanel.context.model.setMetadata('kernel_params', {});
            await notebookPanel.context.save();
          }
          return originalChangeKernel(options);
        }

        // Show configuration dialog
        console.log('[Toolbar] Showing configuration dialog');
        const trans = (translator || nullTranslator).load('jupyterlab');

        const kernelConfigurationDialogWidget = new KernelConfigurationWidget();
        kernelConfigurationDialogWidget.setSchema(kernelspec);

        const kernelConfigDialog = {
          title: kernelConfigurationDialogWidget.dialogTitle,
          body: kernelConfigurationDialogWidget,
          buttons: [
            restoreDefaultsButton,
            Dialog.cancelButton(),
            Dialog.okButton({ label: 'Accept' })
          ],
          defaultButton: 2
        };

        const configResult = await customFormDialog(kernelConfigDialog);
        console.log('[Toolbar] Config dialog result:', configResult);

        if (!configResult.button.accept) {
          console.log('[Toolbar] Config dialog cancelled');
          return; // User cancelled
        }

        // Save configuration to notebook metadata
        const configData = kernelConfigurationDialogWidget.getSchema();
        console.log('[Toolbar] Saving config data:', configData);

        if (notebookPanel.context?.model) {
          notebookPanel.context.model.setMetadata('kernel_params', configData);
          await notebookPanel.context.save();
        }

        // Save to localStorage for next time
        if (kernelConfigurationDialogWidget.dialogTitle) {
          saveConfig(
            kernelConfigurationDialogWidget.dialogTitle,
            configData
          );
        }

        // Now call original changeKernel
        console.log('[Toolbar] Calling original changeKernel with config');
        return originalChangeKernel(options);
      };
    };

    // Wrap existing notebooks
    notebookTracker.forEach(notebookPanel => {
      console.log('[Plugin] Wrapping existing notebook:', notebookPanel.id);
      wrapChangeKernel(notebookPanel);
    });

    // Wrap new notebooks as they're created
    notebookTracker.widgetAdded.connect((sender, notebookPanel) => {
      console.log('[Plugin] New notebook added:', notebookPanel.id);
      wrapChangeKernel(notebookPanel);
    });

    console.log('[Plugin] Notebook tracking setup complete');

    // Intercept launcher tile commands for notebook and console creation
    console.log('[Plugin] Setting up launcher tile interception');

    // Save the original execute method once
    const originalCommandExecute = app.commands.execute.bind(app.commands);

    // Track which commands we want to intercept
    const interceptedCommands = new Set(['notebook:create-new', 'console:create']);

    // Override the global execute method
    app.commands.execute = async (id: string, args?: any) => {
      // Only intercept specific commands
      if (!interceptedCommands.has(id)) {
        return originalCommandExecute(id, args);
      }

      console.log(`[Launcher] Command ${id} intercepted with args:`, args);

      // Check if a kernel name is specified
      const kernelName = args?.kernelName || args?.['kernelPreference']?.name;

      if (!kernelName) {
        console.log('[Launcher] No kernel name specified, calling original');
        return originalCommandExecute(id, args);
      }

      console.log('[Launcher] Kernel name:', kernelName);

      // Get kernel spec
      const serviceManager = app.serviceManager;
      await serviceManager.ready;

      const kernelspec = serviceManager.kernelspecs?.specs?.kernelspecs[kernelName];
      console.log('[Launcher] Kernel spec:', kernelspec);

      const hasConfig = !!(kernelspec?.metadata?.kernel_provisioner as any)?.config;
      console.log('[Launcher] Has config:', hasConfig);

      if (!hasConfig) {
        console.log('[Launcher] No config, calling original command');
        return originalCommandExecute(id, args);
      }

      // Show configuration dialog
      console.log('[Launcher] Showing configuration dialog');

      const kernelConfigurationDialogWidget = new KernelConfigurationWidget();
      kernelConfigurationDialogWidget.setSchema(kernelspec);

      const kernelConfigDialog = {
        title: kernelConfigurationDialogWidget.dialogTitle,
        body: kernelConfigurationDialogWidget,
        buttons: [
          restoreDefaultsButton,
          Dialog.cancelButton(),
          Dialog.okButton({ label: 'Accept' })
        ],
        defaultButton: 2
      };

      const configResult = await customFormDialog(kernelConfigDialog);
      console.log('[Launcher] Config dialog result:', configResult);

      if (!configResult.button.accept) {
        console.log('[Launcher] Config dialog cancelled');
        return; // User cancelled - don't create document
      }

      // Get configuration data
      const configData = kernelConfigurationDialogWidget.getSchema();
      console.log('[Launcher] Config data:', configData);

      // Save to localStorage for this kernel
      if (kernelConfigurationDialogWidget.dialogTitle) {
        saveConfig(kernelConfigurationDialogWidget.dialogTitle, configData);
      }

      // Create the notebook/console with original command
      console.log('[Launcher] Creating document with original command');
      const result = await originalCommandExecute(id, args);

      // After document is created, save config to its metadata
      // Wait a bit for the document to be ready
      setTimeout(async () => {
        console.log('[Launcher] Saving config to document metadata');

        // Find the newly created document
        if (id.startsWith('notebook:')) {
          const currentWidget = notebookTracker.currentWidget;
          if (currentWidget?.context?.model) {
            currentWidget.context.model.setMetadata('kernel_params', configData);
            await currentWidget.context.save();
            console.log('[Launcher] Config saved to notebook metadata');
          }
        }
      }, 500);

      return result;
    };

    console.log('[Plugin] Launcher tile interception setup complete');
    console.log('[Plugin] Intercepting commands:', Array.from(interceptedCommands));
  }
};

/**
 * Error handling plugin
 *
 * Listens for kernel action events and displays error dialogs
 * when kernel operations fail.
 */
const raiseErrors: JupyterFrontEndPlugin<void> = {
  id: '@apple/jupyterlab-kernel-parameter-extension:raiseErrors',
  description: 'Kernel error monitoring',
  autoStart: true,
  activate: async (app: JupyterFrontEnd) => {
    console.log(
      'JupyterLab extension @apple/jupyterlab-kernel-parameter-extension:raiseErrors activated!'
    );

    await app.serviceManager.ready;

    const eventListener = new EventListener(app.serviceManager.events);

    // Listen for kernel action events
    eventListener.addListener(
      'https://events.jupyter.org/jupyter_server/kernel_actions/v1',
      async (
        manager: Event.IManager,
        schemaId: string,
        event: Event.Emission
      ) => {
        const data = event as unknown as KernelEvent;

        // Display error dialog if kernel operation failed
        if (data.status && data.status === 'error') {
          console.error('Kernel Launch Error:', data);

          let title = '';
          if (data.status_code) {
            title += data.status_code.toString() + ': ';
          }
          title += 'Kernel ' + data.action.toString() + ' failed.';

          const extractedError = extractErrorMessage(data.msg);
          showErrorMessage(title, extractedError);
        }
      }
    );
  }
};

export default [plugin, raiseErrors];
