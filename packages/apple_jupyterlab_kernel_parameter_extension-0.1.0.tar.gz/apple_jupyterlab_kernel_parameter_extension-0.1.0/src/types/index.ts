/**
 * Type definitions for kernel parameter extension
 */

export * from './schema';
export * from './kernel-config';
