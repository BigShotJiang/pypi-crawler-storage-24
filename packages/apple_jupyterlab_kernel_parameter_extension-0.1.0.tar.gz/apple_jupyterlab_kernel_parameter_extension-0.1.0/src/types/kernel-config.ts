/**
 * Types for kernel configuration and management
 */

import { UISchemaElement } from '@jsonforms/core';
import { ErrorObject } from 'ajv';
import { KernelSpec } from '@jupyterlab/services';
import { ExtendedJsonSchema, ConfigMap } from './schema';

/**
 * Kernel custom configuration from kernel spec metadata
 */
export interface KernelCustomConfiguration {
  /**
   * JSON Schema defining the configuration form
   */
  config: ExtendedJsonSchema;

  /**
   * Optional UI Schema for form layout control
   */
  uischema?: UISchemaElement;

  /**
   * Default values for the configuration
   */
  defaultValues: Record<string, unknown>;

  /**
   * Optional error update callback
   */
  errorUpdateFn?: (errors: ErrorObject[]) => void;
}

/**
 * Kernel configuration object with data and validation errors
 */
export interface IKernelConfigObject {
  /**
   * Configuration data as key-value pairs
   */
  data: ConfigMap;

  /**
   * Validation errors from schema validation
   */
  errors: ErrorObject[];
}

/**
 * Kernel spec model with extended metadata
 */
export interface IKernelSpec extends KernelSpec.ISpecModel {
  metadata?: any;
}

/**
 * Kernel event from Jupyter Server
 */
export interface KernelEvent {
  schema_id: string;
  action: string;
  msg: string;
  kernel_id?: string;
  kernel_name?: string;
  status?: string;
  status_code?: number;
}

/**
 * Custom dropdown selection change event
 */
export interface DropdownChangeEventDetail {
  oldValue: string;
  newValue: string;
  path: string;
}

/**
 * Custom event type for dropdown changes
 */
export interface DropdownChangeEvent extends CustomEvent<DropdownChangeEventDetail> {}

/**
 * Props for components that need kernel configuration
 */
export interface WithKernelConfigProps {
  setKernelConfig: (config: IKernelConfigObject) => void;
  customConfig: KernelCustomConfiguration;
}
