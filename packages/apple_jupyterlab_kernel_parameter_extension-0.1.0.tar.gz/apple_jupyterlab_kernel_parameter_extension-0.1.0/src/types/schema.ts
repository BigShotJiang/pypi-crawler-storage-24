/**
 * Extended JSON Schema types for kernel configuration
 *
 * These types extend the standard JSONForms schema with custom properties
 * needed for kernel parameter configuration.
 */

import { JsonSchema } from '@jsonforms/core';

/**
 * Extended JSON Schema with custom properties for kernel configuration
 */
export type ExtendedJsonSchema = JsonSchema & {
  /**
   * Custom ID for the schema property, used for element identification
   */
  id?: string;

  /**
   * Whether this field allows custom/editable values (for selects)
   */
  editable?: string | boolean;

  /**
   * Number of rows for textarea inputs
   */
  rows?: number;

  /**
   * Size mappings for responsive layouts
   */
  sizeMappings?: Record<string, unknown>;

  /**
   * Configuration mappings for enum values
   * Maps enum values to configuration objects that should be applied
   */
  enumConfigs?: Record<string, ConfigMap>;

  /**
   * Defines how enum selection changes should cascade to other fields
   */
  enumInteractionOverrides?: EnumInteractionOverride[];

  /**
   * Custom validation rules for this field
   */
  validation?: ValidationRules;

  /**
   * Nested properties with extended schema support
   */
  properties?: {
    [property: string]: ExtendedJsonSchema;
  };

  /**
   * JSON Schema standard properties
   */
  enum?: Array<string | number>;
  type?: string | string[];
  default?: unknown;
  title?: string;
  description?: string;
};

/**
 * Configuration map for kernel parameters
 */
export type ConfigMap = Record<string, string | null>;

/**
 * Defines how selecting an enum value affects other fields
 */
export interface EnumInteractionOverride {
  /**
   * The field path that should be updated when the source field changes
   */
  pathToUpdate: string;

  /**
   * The source field in the enum config
   * Use "ALL" to merge all config values into a multiline field
   */
  sourceField: string;
}

/**
 * Custom validation rules for form fields
 */
export interface ValidationRules {
  /**
   * Field is required (must have a value)
   */
  required?: boolean;

  /**
   * String must start with specified prefix
   */
  startsWith?: string;

  /**
   * Number must be within specified range
   */
  range?: {
    min: number;
    max: number;
  };
}

/**
 * Result of a validation check
 */
export interface ValidationResult {
  success: boolean;
  errorMessage: string;
}

/**
 * Validation rule types
 */
export enum ValidationRule {
  Required = 'required',
  StartsWith = 'startsWith',
  Range = 'range'
}
