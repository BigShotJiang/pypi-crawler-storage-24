/**
 * Custom Kernel Selector
 *
 * Overrides JupyterLab's kernel selection to intercept the process
 * and show a configuration dialog for kernels that support parameters.
 */

import { JupyterFrontEnd } from '@jupyterlab/application';
import { ISessionContext, Dialog } from '@jupyterlab/apputils';
import { DocumentManager } from '@jupyterlab/docmanager';
import { DocumentRegistry } from '@jupyterlab/docregistry';
import { INotebookModel } from '@jupyterlab/notebook';
import { ITranslator, nullTranslator } from '@jupyterlab/translation';
import { KernelSelector } from './kernelSelector';
import { KernelConfigurationWidget } from '../components/KernelConfiguration';
import {
  customFormDialog,
  restoreDefaultsButton
} from '../components/dialogs';
import { saveConfig } from '../utils/schemaHelpers';

/**
 * Create a custom kernel selector function
 *
 * This function wraps the standard kernel selection process to add
 * configuration dialogs for kernels with custom parameters.
 *
 * @param app - JupyterLab application instance
 * @param docManager - Document manager for accessing notebook context
 * @param translator - Translation service
 * @returns Custom kernel selector function
 */
export function customSelectKernelWrapper(
  app: JupyterFrontEnd,
  docManager: DocumentManager,
  translator: ITranslator
) {
  return async function customSelectKernel(
    sessionContext: ISessionContext
  ): Promise<void> {
    console.log('[KernelSelector] customSelectKernel called');

    if (sessionContext.isDisposed) {
      console.log('[KernelSelector] sessionContext is disposed, returning');
      return Promise.resolve();
    }

    const serviceManager = app.serviceManager;
    translator = translator || nullTranslator;
    const trans = translator.load('jupyterlab');

    // Determine label for cancel/no-kernel button
    let label = trans.__('Cancel');
    if (sessionContext.hasNoKernel) {
      label = sessionContext.kernelDisplayName;
    }

    const buttons = [
      Dialog.cancelButton({ label }),
      Dialog.okButton({ label: trans.__('Select') })
    ];

    // Show kernel selector dialog
    console.log('[KernelSelector] Showing kernel selector dialog');
    const dialog = new Dialog({
      title: trans.__('Select Kernel'),
      body: new KernelSelector(sessionContext, translator),
      buttons
    });

    const result = await dialog.launch();
    console.log('[KernelSelector] Dialog result:', result);

    if (sessionContext.isDisposed || !result.button.accept) {
      console.log('[KernelSelector] Dialog cancelled or disposed');
      return;
    }

    const model = result.value;
    console.log('[KernelSelector] Selected kernel model:', model);

    // Handle "No Kernel" selection
    if (model === null && !sessionContext.hasNoKernel) {
      console.log('[KernelSelector] No kernel selected, shutting down');
      return sessionContext.shutdown();
    }

    if (model) {
      const kernelspec =
        serviceManager.kernelspecs.specs?.kernelspecs[model.name];

      console.log('[KernelSelector] Kernel spec for', model.name, ':', kernelspec);
      console.log('[KernelSelector] Kernel metadata:', kernelspec?.metadata);
      console.log('[KernelSelector] Kernel provisioner:', (kernelspec?.metadata as any)?.kernel_provisioner);

      // Get notebook context
      const notebookContext =
        app.shell.currentWidget &&
        (docManager.contextForWidget(
          app.shell.currentWidget
        ) as DocumentRegistry.IContext<INotebookModel>);

      console.log('[KernelSelector] Notebook context:', notebookContext);

      // Check if kernel has custom configuration
      const hasConfig = !!(kernelspec?.metadata?.kernel_provisioner as any)
        ?.config;

      console.log('[KernelSelector] Has config:', hasConfig);

      if (!hasConfig) {
        console.log('[KernelSelector] No config needed, changing kernel directly');
        // No configuration needed - clear params and change kernel
        notebookContext?.model.setMetadata('kernel_params', {});
        await notebookContext?.save();
        await sessionContext.changeKernel(model);
      } else {
        console.log('[KernelSelector] Kernel has config, showing configuration dialog');
        // Kernel has configuration - show config dialog
        const kernelConfigurationDialogWidget =
          new KernelConfigurationWidget();
        kernelConfigurationDialogWidget.setSchema(kernelspec);

        console.log('[KernelSelector] Widget dialog title:', kernelConfigurationDialogWidget.dialogTitle);
        console.log('[KernelSelector] Widget has config:', kernelConfigurationDialogWidget.hasCustomConfig());

        const kernelConfigDialog = {
          title: kernelConfigurationDialogWidget.dialogTitle,
          body: kernelConfigurationDialogWidget,
          buttons: [
            restoreDefaultsButton,
            Dialog.cancelButton(),
            Dialog.okButton({ label: 'Accept' })
          ],
          defaultButton: 2
        };

        console.log('[KernelSelector] Launching custom form dialog');
        const configResult = await customFormDialog(kernelConfigDialog);
        console.log('[KernelSelector] Config dialog result:', configResult);

        if (!configResult.button.accept) {
          console.log('[KernelSelector] Config dialog cancelled');
          return;
        }

        // Save configuration to notebook metadata
        const configData = kernelConfigurationDialogWidget.getSchema();
        console.log('[KernelSelector] Saving config data:', configData);
        notebookContext?.model.setMetadata('kernel_params', configData);

        // Save to localStorage for next time
        if (kernelConfigurationDialogWidget.dialogTitle) {
          saveConfig(
            kernelConfigurationDialogWidget.dialogTitle,
            configData
          );
        }

        await notebookContext?.save();
        await sessionContext.changeKernel(model);
        console.log('[KernelSelector] Kernel changed successfully');
      }
    }
  };
}
