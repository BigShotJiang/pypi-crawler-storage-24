/**
 * Server Disconnect Monitor
 *
 * Monitors for server shutdowns and displays a warning dialog
 * when the Jupyter server is restarted from another tab/window.
 */

import React from 'react';
import { Dialog, ReactWidget, showDialog } from '@jupyterlab/apputils';

/**
 * Widget displayed when server shutdown is detected
 */
class ServerShutdownWidget extends ReactWidget {
  protected render(): JSX.Element {
    return (
      <>
        Your Jupyter server was shutdown and/or restarted from a different
        tab/window. This notebook tab is no longer valid.
        <br />
        If you restarted the Jupyter Server, then there is another tab in your
        browser which is the active tab for your Notebook environment.
        <br />
        Please close this notebook tab.
      </>
    );
  }
}

/**
 * Set up server disconnect monitoring
 *
 * Uses BroadcastChannel to detect when the server shuts down
 * in another browser tab and displays a warning dialog.
 */
export function serverDisconnectMonitor(): void {
  const channel = new BroadcastChannel(window.location.host);

  channel.onmessage = (event): void => {
    if (event.data === 'shutdown') {
      const buttonList: ReadonlyArray<Dialog.IButton> = [];

      showDialog({
        title: 'Server Shutdown',
        body: new ServerShutdownWidget(),
        buttons: buttonList
      });
    }
  };
}
