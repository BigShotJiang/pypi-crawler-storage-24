/**
 * Kernel Selector Widget
 *
 * Provides a UI for selecting kernels, based on JupyterLab's private implementation.
 * This is needed because JupyterLab doesn't export its kernel selector publicly.
 */

import { Widget } from '@lumino/widgets';
import { each } from '@lumino/algorithm';
import {
  ISessionContext,
  SessionContext
} from '@jupyterlab/apputils';
import { PathExt } from '@jupyterlab/coreutils';
import { Kernel, Session } from '@jupyterlab/services';
import { ITranslator, nullTranslator } from '@jupyterlab/translation';

/**
 * Kernel Selector Widget
 *
 * Displays a dropdown selector for choosing a kernel
 */
export class KernelSelector extends Widget {
  /**
   * Create a new kernel selector widget
   */
  constructor(sessionContext: ISessionContext, translator?: ITranslator) {
    super({ node: createSelectorNode(sessionContext, translator) });
  }

  /**
   * Get the selected kernel model
   */
  getValue(): Kernel.IModel | null {
    const selector = this.node.querySelector('select') as HTMLSelectElement;
    return JSON.parse(selector.value) as Kernel.IModel | null;
  }
}

/**
 * Create the DOM node for the kernel selector
 */
function createSelectorNode(
  sessionContext: ISessionContext,
  translator?: ITranslator
): HTMLElement {
  translator = translator || nullTranslator;
  const trans = translator.load('jupyterlab');

  const body = document.createElement('div');
  const text = document.createElement('label');
  text.textContent = `${trans.__('Select kernel for:')} "${
    sessionContext.name
  }"`;
  body.appendChild(text);

  const options = getKernelSearch(sessionContext);
  const selector = document.createElement('select');
  populateKernelSelect(
    selector,
    options,
    translator,
    !sessionContext.hasNoKernel ? sessionContext.kernelDisplayName : null
  );
  body.appendChild(selector);

  return body;
}

/**
 * Get kernel search options for the session context
 */
function getKernelSearch(
  sessionContext: ISessionContext
): SessionContext.IKernelSearch {
  return {
    specs: sessionContext.specsManager.specs,
    sessions: sessionContext.sessionManager.running(),
    preference: sessionContext.kernelPreference
  };
}

/**
 * Populate the kernel select dropdown
 */
export function populateKernelSelect(
  node: HTMLSelectElement,
  options: SessionContext.IKernelSearch,
  translator?: ITranslator,
  currentKernelDisplayName: string | null = null
): void {
  // Clear existing options
  while (node.firstChild) {
    node.removeChild(node.firstChild);
  }

  const { preference, sessions, specs } = options;
  const { name, id, language, canStart, shouldStart } = preference;

  translator = translator || nullTranslator;
  const trans = translator.load('jupyterlab');

  if (!specs || canStart === false) {
    node.appendChild(optionForNone(translator));
    node.value = 'null';
    node.disabled = true;
    return;
  }

  node.disabled = false;

  // Create mappings of display names and languages
  const displayNames: Record<string, string> = Object.create(null);
  const languages: Record<string, string> = Object.create(null);

  for (const kernelName in specs.kernelspecs) {
    const spec = specs.kernelspecs[kernelName]!;
    displayNames[kernelName] = spec.display_name;
    languages[kernelName] = spec.language;
  }

  // Determine preferred kernels
  const names: string[] = [];

  if (name && name in specs.kernelspecs) {
    names.push(name);
  }

  // Add kernels matching the language
  if (name && names.length > 0 && language) {
    for (const specName in specs.kernelspecs) {
      if (name !== specName && languages[specName] === language) {
        names.push(specName);
      }
    }
  }

  // Use default kernel if none found
  if (!names.length) {
    names.push(specs.default);
  }

  // Add preferred kernels
  const preferred = document.createElement('optgroup');
  preferred.label = trans.__('Start Preferred Kernel');

  names.sort((a, b) => displayNames[a].localeCompare(displayNames[b]));
  for (const kernelName of names) {
    preferred.appendChild(optionForName(kernelName, displayNames[kernelName]));
  }

  if (preferred.firstChild) {
    node.appendChild(preferred);
  }

  // Add "No Kernel" option
  node.appendChild(optionForNone(translator));

  // Add other available kernels
  const other = document.createElement('optgroup');
  other.label = trans.__('Start Other Kernel');

  const otherNames: string[] = [];
  for (const specName in specs.kernelspecs) {
    if (names.indexOf(specName) === -1) {
      otherNames.push(specName);
    }
  }

  otherNames.sort((a, b) => displayNames[a].localeCompare(displayNames[b]));
  for (const otherName of otherNames) {
    other.appendChild(optionForName(otherName, displayNames[otherName]));
  }

  if (otherNames.length) {
    node.appendChild(other);
  }

  // Set default selection
  if (shouldStart === false) {
    node.value = 'null';
  } else {
    let selectedIndex = 0;
    if (currentKernelDisplayName) {
      selectedIndex = Array.from(node.options).findIndex(
        option => option.text === currentKernelDisplayName
      );
      selectedIndex = Math.max(selectedIndex, 0);
    }
    node.selectedIndex = selectedIndex;
  }

  // Add running sessions
  if (!sessions) {
    return;
  }

  const matchingSessions: Session.IModel[] = [];
  const otherSessions: Session.IModel[] = [];

  each(sessions, session => {
    if (
      language &&
      session.kernel &&
      languages[session.kernel.name] === language &&
      session.kernel.id !== id
    ) {
      matchingSessions.push(session);
    } else if (session.kernel?.id !== id) {
      otherSessions.push(session);
    }
  });

  const matching = document.createElement('optgroup');
  matching.label = trans.__('Use Kernel from Preferred Session');
  node.appendChild(matching);

  if (matchingSessions.length) {
    matchingSessions.sort((a, b) => a.path.localeCompare(b.path));

    each(matchingSessions, session => {
      const sessionName = session.kernel
        ? displayNames[session.kernel.name]
        : '';
      matching.appendChild(optionForSession(session, sessionName, translator));
    });
  }

  const otherSessionsNode = document.createElement('optgroup');
  otherSessionsNode.label = trans.__('Use Kernel from Other Session');
  node.appendChild(otherSessionsNode);

  if (otherSessions.length) {
    otherSessions.sort((a, b) => a.path.localeCompare(b.path));

    each(otherSessions, session => {
      const sessionName = session.kernel
        ? displayNames[session.kernel.name] || session.kernel.name
        : '';
      otherSessionsNode.appendChild(
        optionForSession(session, sessionName, translator)
      );
    });
  }
}

/**
 * Create an option element for a kernel name
 */
function optionForName(name: string, displayName: string): HTMLOptionElement {
  const option = document.createElement('option');
  option.text = displayName;
  option.value = JSON.stringify({ name });
  return option;
}

/**
 * Create an option for no kernel
 */
function optionForNone(translator?: ITranslator): HTMLOptGroupElement {
  translator = translator || nullTranslator;
  const trans = translator.load('jupyterlab');

  const group = document.createElement('optgroup');
  group.label = trans.__('Use No Kernel');
  const option = document.createElement('option');
  option.text = trans.__('No Kernel');
  option.value = 'null';
  group.appendChild(option);

  return group;
}

/**
 * Create an option element for a session
 */
function optionForSession(
  session: Session.IModel,
  displayName: string,
  translator?: ITranslator
): HTMLOptionElement {
  translator = translator || nullTranslator;
  const trans = translator.load('jupyterlab');

  const option = document.createElement('option');
  const sessionName = session.name || PathExt.basename(session.path);
  option.text = sessionName;
  option.value = JSON.stringify({ id: session.kernel?.id });
  option.title =
    `${trans.__('Path:')} ${session.path}\n` +
    `${trans.__('Name:')} ${sessionName}\n` +
    `${trans.__('Kernel Name:')} ${displayName}\n` +
    `${trans.__('Kernel Id:')} ${session.kernel?.id}`;

  return option;
}
