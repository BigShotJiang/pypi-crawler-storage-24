/**
 * Event Listener for Jupyter Server Events
 *
 * Provides a mechanism to register callbacks for specific Jupyter events
 * identified by schema IDs.
 */

import { Event } from '@jupyterlab/services';

/**
 * Listener callback function type
 */
export interface IListener {
  (
    eventManager: Event.IManager,
    schemaId: string,
    data: Event.Emission
  ): Promise<void>;
}

/**
 * Event Listener Interface
 */
export interface IEventListener {
  addListener(schemaId: string, listener: IListener): void;
  removeListener(schemaId: string, listener: IListener): void;
}

/**
 * Event Listener Implementation
 *
 * Connects to Jupyter's event stream and dispatches events to registered
 * listeners based on schema ID.
 */
export class EventListener implements IEventListener {
  private _listeners: Record<string, Set<IListener>> = {};
  private _eventManager: Event.IManager;

  /**
   * Create a new EventListener
   *
   * @param eventManager - Jupyter event manager
   */
  constructor(eventManager: Event.IManager) {
    this._eventManager = eventManager;

    // Connect to event stream
    this._eventManager.stream.connect(
      async (
        manager: Event.IManager,
        event: Event.Emission
      ): Promise<void> => {
        // Ignore events with no listeners
        if (!(event.schema_id in this._listeners)) {
          return;
        }

        const listeners = this._listeners[event.schema_id];
        for (const listener of listeners) {
          await listener(manager, event.schema_id, event);
        }
      }
    );
  }

  /**
   * Add a listener for a specific event schema
   *
   * @param schemaId - Event schema ID to listen for
   * @param listener - Callback function to register
   */
  addListener(schemaId: string, listener: IListener): void {
    if (schemaId in this._listeners) {
      this._listeners[schemaId].add(listener);
      return;
    }

    // Create new listener set for this schema
    this._listeners[schemaId] = new Set([listener]);
  }

  /**
   * Remove a listener for a specific event schema
   *
   * @param schemaId - Event schema ID
   * @param listener - Callback function to remove
   */
  removeListener(schemaId: string, listener: IListener): void {
    if (schemaId in this._listeners) {
      this._listeners[schemaId].delete(listener);
    }
  }
}
