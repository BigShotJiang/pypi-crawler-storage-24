/**
 * Error message parsing utilities
 *
 * Extracts and formats error messages from various sources
 * to provide better user-facing error text.
 */

/**
 * Extract clean error message from raw server error strings
 *
 * Attempts to parse Jakarta/Java WebApplicationException messages
 * and extract the actual error text.
 *
 * @param errorMsg - Raw error message from server
 * @returns Cleaned error message
 */
export function extractErrorMessage(errorMsg: string): string {
  const regex = /jakarta\.ws\.rs\.WebApplicationException: (.+)"}$/m;

  const match = errorMsg.match(regex);
  if (match && match[1]) {
    return match[1];
  }

  return errorMsg;
}
