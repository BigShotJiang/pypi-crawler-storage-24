/**
 * Schema helper utilities for kernel configuration
 *
 * Provides utilities for working with JSON schemas, including:
 * - Parsing and stringifying config strings
 * - Merging configurations
 * - Fitting values to schema types
 * - Generating defaults from schemas
 */

import { jsonDefault } from 'json-schema-default';
import { ExtendedJsonSchema, ConfigMap } from '../types';

/**
 * Parse a multiline config string into a key-value map
 *
 * Supports formats like:
 * - key=value
 * - key1=value1,key2=value2
 * - "quoted,value"
 *
 * @param configString - The config string to parse
 * @returns Record of key-value pairs
 */
export function parseConfigString(configString: string): Record<string, string> {
  const result: Record<string, string> = {};
  const lines: string[] = configString.split('\n');

  for (const line of lines) {
    // Handle quoted lines as single entities
    if (/^".*"$/.test(line)) {
      processKeyValue(line, result);
    } else {
      const parts: string[] = line.split(',');
      for (const part of parts) {
        processKeyValue(part, result);
      }
    }
  }

  return result;
}

/**
 * Process a single key=value entry
 */
function processKeyValue(entry: string, result: Record<string, string>): void {
  const keyValue = entry.split('=');
  if (keyValue.length === 2) {
    const [key, value] = keyValue;
    result[key.trim()] = value.trim();
  }
}

/**
 * Stringify a config object into a multiline string
 *
 * @param configObject - The config object to stringify
 * @returns Multiline string with key=value pairs
 */
export function stringifyConfigObject(
  configObject: Record<string, string | null>
): string {
  return Object.entries(configObject)
    .filter(([, value]) => value !== null)
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');
}

/**
 * Merge two configuration objects
 *
 * null values in configToApply indicate the key should be removed
 *
 * @param configToApply - New configuration to apply
 * @param currentConfig - Existing configuration
 * @returns Merged configuration
 */
export function mergeConfigs(
  configToApply: ConfigMap,
  currentConfig: ConfigMap
): ConfigMap {
  // Merge configs, then filter out keys with null values
  return Object.fromEntries(
    Object.entries({ ...currentConfig, ...configToApply }).filter(
      ([key, value]) =>
        !(key in configToApply && configToApply[key] === null)
    )
  );
}

/**
 * Fit values to match their schema type definitions
 *
 * - Converts strings to integers for integer schema types
 * - Converts strings to booleans for boolean schema types
 * - Validates enum values and uses first enum option if invalid
 * - Respects editable flag for enums
 *
 * @param values - Raw values to fit
 * @param schema - Schema to fit values to
 * @returns Typed values matching schema requirements
 */
export function fitValuesToSchema(
  values: Record<string, string>,
  schema: ExtendedJsonSchema
): Record<string, unknown> {
  const properties = schema.properties || {};
  const schemaValues: Record<string, unknown> = {};
  const keys = Object.keys(values);

  for (const key of keys) {
    const propertySchema = properties[key];
    const value = values[key];

    if (!propertySchema) {
      continue;
    }

    // Check if value is valid for enum fields (unless editable)
    const editable =
      propertySchema.editable == null
        ? false
        : String(propertySchema.editable).toLowerCase() === 'true';

    if (
      propertySchema.enum &&
      (!propertySchema.enum.includes(value) ||
        propertySchema.enum.length === 1) &&
      !editable
    ) {
      // Use first enum value as default
      schemaValues[key] = propertySchema.enum[0];
      continue;
    }

    // Type conversion based on schema type
    if (propertySchema.type === 'integer') {
      schemaValues[key] = parseInt(value ?? '-1', 10);
    } else if (propertySchema.type === 'boolean') {
      schemaValues[key] = value.toLowerCase() === 'true';
    } else {
      schemaValues[key] = value;
    }
  }

  return schemaValues;
}

/**
 * Stringify all values in an object to strings
 *
 * @param values - Values to stringify
 * @returns Object with all values converted to strings
 */
export function stringifyValues(
  values: Record<string, unknown>
): Record<string, string> {
  const result: Record<string, string> = {};

  for (const key in values) {
    if (Object.prototype.hasOwnProperty.call(values, key)) {
      result[key] = String(values[key]);
    }
  }

  return result;
}

/**
 * Generate default values from a JSON schema
 *
 * Uses json-schema-default library and ensures all properties
 * have an ID field for element identification
 *
 * @param schema - The schema to generate defaults from
 * @returns Default values object
 */
export function generateDefaults(
  schema: ExtendedJsonSchema
): Record<string, unknown> {
  // Ensure all properties have IDs and default values
  if (schema.properties) {
    Object.entries(schema.properties).forEach(([key, propertySchema]) => {
      // Set default from first enum value if no default exists
      if (
        propertySchema.enum &&
        propertySchema.enum.length > 0 &&
        !propertySchema.default
      ) {
        propertySchema.default = propertySchema.enum[0];
      }

      // Generate ID from title if not present
      if (!('id' in propertySchema) && 'title' in propertySchema) {
        propertySchema.id = String(propertySchema.title).replace(
          /[^a-zA-Z]/g,
          '-'
        );
      }
    });
  }

  return jsonDefault(schema as any) as Record<string, unknown>;
}

/**
 * Save configuration to localStorage
 *
 * @param dialogTitle - Title used as key prefix
 * @param config - Configuration to save
 */
export function saveConfig(
  dialogTitle: string,
  config: Record<string, unknown>
): void {
  const key = `${dialogTitle}-kernel-config`;
  localStorage.setItem(key, JSON.stringify(config));
}

/**
 * Load configuration from localStorage
 *
 * @param dialogTitle - Title used as key prefix
 * @returns Saved configuration or empty object
 */
export function loadConfig(dialogTitle: string): Record<string, string> {
  const key = `${dialogTitle}-kernel-config`;
  const saved = localStorage.getItem(key);
  return saved ? JSON.parse(saved) : {};
}

/**
 * Save schema defaults to localStorage (once per schema)
 *
 * @param dialogTitle - Title used as key
 * @param schema - Schema to save defaults for
 */
export function saveSchemaDefaults(
  dialogTitle: string,
  schema: ExtendedJsonSchema
): void {
  const key = `${dialogTitle}-kernel-config-default`;
  const formData = JSON.stringify(schema.properties);
  localStorage.setItem(key, formData);
}

/**
 * Check if schema defaults have been saved
 *
 * @param dialogTitle - Title used as key
 * @returns true if defaults exist in localStorage
 */
export function hasSchemaDefaults(dialogTitle: string): boolean {
  const key = `${dialogTitle}-kernel-config-default`;
  return localStorage.getItem(key) !== null;
}
