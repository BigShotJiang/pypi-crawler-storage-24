/**
 * Validation utilities for kernel configuration forms
 *
 * Provides custom validation rules beyond what JSON Schema offers,
 * including required fields, string prefixes, and numeric ranges.
 */

import {
  ValidationRule,
  ValidationResult,
  ValidationRules
} from '../types';

/**
 * Priority order for evaluating validation rules
 * Rules are checked in this order, stopping at the first failure
 */
const RULE_PRIORITY: string[] = [
  ValidationRule.Required,
  ValidationRule.StartsWith,
  ValidationRule.Range
];

/**
 * Sort validation rules by priority order
 * Warns if unknown rules are encountered
 */
function sortRulesByPriority(rules: ValidationRules): Array<{
  [key: string]: unknown;
}> {
  const sortedRules: Array<{ [key: string]: unknown }> = [];

  // Add rules in priority order
  RULE_PRIORITY.forEach((ruleName: string) => {
    if (Object.prototype.hasOwnProperty.call(rules, ruleName)) {
      const sortedRule: { [key: string]: unknown } = {};
      sortedRule[ruleName] = (rules as any)[ruleName];
      sortedRules.push(sortedRule);
    }
  });

  // Warn about unknown rules
  const ruleNames = Object.keys(rules);
  ruleNames.forEach((ruleName: string) => {
    if (!RULE_PRIORITY.includes(ruleName)) {
      console.warn(
        `Unknown validation rule '${ruleName}' found in validation schema`
      );
    }
  });

  return sortedRules;
}

/**
 * Validate that a field has a value (is not empty)
 */
function validateRequired(data: unknown, fieldName: string): ValidationResult {
  if (typeof data === 'string' && data !== '') {
    return {
      success: true,
      errorMessage: ''
    };
  }

  return {
    success: false,
    errorMessage: `${fieldName} is required`
  };
}

/**
 * Validate that a string starts with a specific prefix
 */
function validateStartsWith(
  data: unknown,
  fieldName: string,
  prefix: string
): ValidationResult {
  if (typeof data === 'string') {
    if (data.length === 0 || data.startsWith(prefix)) {
      return {
        success: true,
        errorMessage: ''
      };
    } else {
      return {
        success: false,
        errorMessage: `${fieldName} must start with '${prefix}'`
      };
    }
  }

  return {
    success: false,
    errorMessage: `${fieldName} must be a string, got ${typeof data}`
  };
}

/**
 * Validate that a number is within a specified range
 */
function validateRange(
  data: unknown,
  fieldName: string,
  rangeObj: { min: number; max: number }
): ValidationResult {
  const { min, max } = rangeObj;
  let value = data;

  // Convert string to number if it's numeric
  if (typeof data === 'string') {
    const numericPattern = /^[0-9]+$/;
    if (!numericPattern.test(data)) {
      return {
        success: false,
        errorMessage: `${fieldName} must be an integer`
      };
    }
    value = Number(data);
  }

  if (typeof value !== 'number') {
    return {
      success: false,
      errorMessage: `${fieldName} must be a number or numeric string`
    };
  }

  if (value < min || value > max) {
    return {
      success: false,
      errorMessage: `${fieldName} must be between ${min} and ${max}`
    };
  }

  return {
    success: true,
    errorMessage: ''
  };
}

/**
 * Validate a single rule against data
 */
function validateRule(
  data: unknown,
  fieldName: string,
  ruleName: string,
  params: unknown
): ValidationResult {
  switch (ruleName) {
    case ValidationRule.Required:
      return validateRequired(data, fieldName);
    case ValidationRule.StartsWith:
      return validateStartsWith(data, fieldName, params as string);
    case ValidationRule.Range:
      return validateRange(data, fieldName, params as {
        min: number;
        max: number;
      });
    default:
      return {
        success: false,
        errorMessage: `Invalid validation rule '${ruleName}' for field ${fieldName}`
      };
  }
}

/**
 * Validate data against a set of validation rules
 *
 * Rules are evaluated in priority order, stopping at the first failure.
 * Returns success: true if all rules pass, or success: false with an error message.
 *
 * @param data - The value to validate
 * @param fieldName - Display name for the field (used in error messages)
 * @param rules - Object containing validation rules to apply
 * @returns ValidationResult with success flag and error message
 */
export function validateRules(
  data: unknown,
  fieldName: string,
  rules: ValidationRules
): ValidationResult {
  const sortedRules = sortRulesByPriority(rules);

  for (const ruleObj of sortedRules) {
    const ruleName = Object.keys(ruleObj)[0];
    const validationResult = validateRule(
      data,
      fieldName,
      ruleName,
      ruleObj[ruleName]
    );

    if (!validationResult.success) {
      return validationResult;
    }
  }

  return {
    success: true,
    errorMessage: ''
  };
}
