/**
 * Tester for Checkbox renderer
 *
 * Determines when to use the Checkbox control for a schema property
 */

import { isBooleanControl, rankWith } from '@jsonforms/core';

/**
 * Use Checkbox control for boolean properties
 * Rank 3 means it takes precedence over default renderers
 */
export default rankWith(3, isBooleanControl);
