/**
 * Checkbox control for JSONForms integration
 *
 * Wraps the Checkbox component to work with JSONForms,
 * providing label, tooltip, and error display.
 */

import React, { useState, useCallback } from 'react';
import { withJsonFormsControlProps } from '@jsonforms/react';
import { ControlProps } from '@jsonforms/core';
import { Tooltip } from '@jupyter/react-components';
import { Checkbox } from './Checkbox';
import { TooltipIcon } from '../../shared';
import { useGlobalEventListener } from '../../../hooks';
import { ExtendedJsonSchema } from '../../../types';

export interface CheckboxControlProps extends ControlProps {
  schema: ExtendedJsonSchema;
}

/**
 * Checkbox control component with label, tooltip, and validation
 */
const CheckboxControl: React.FC<CheckboxControlProps> = ({
  data,
  handleChange,
  path,
  schema,
  label,
  required,
  errors
}) => {
  const [tooltipAnchor, setTooltipAnchor] = useState<HTMLElement | null>(null);

  // Set up tooltip anchor ref
  const tooltipRef = useCallback((node: HTMLDivElement | null) => {
    if (node) {
      setTooltipAnchor(node);
    }
  }, []);

  // Listen for global events
  useGlobalEventListener(handleChange, path, schema.id);

  // Handle value change
  const handleValueChange = useCallback(
    (newValue: boolean): void => {
      handleChange(path, newValue);
    },
    [handleChange, path]
  );

  return (
    <div className="CheckboxControl">
      <div className="CheckboxControl__Label">
        {label}{' '}
        {required && <span className="CheckboxControl__Required">*</span>}
        <span ref={tooltipRef}>
          <TooltipIcon />
        </span>
        <Tooltip
          anchorElement={tooltipAnchor}
          delay={100}
          position="top"
          className="tooltip-description"
        >
          {schema.description}
        </Tooltip>
        <span>
          <Checkbox
            id={schema.id}
            label={label}
            value={data}
            updateValue={handleValueChange}
          />
        </span>
      </div>
      {errors && <div className="CheckboxControl__Error">{errors}</div>}
    </div>
  );
};

export default withJsonFormsControlProps(CheckboxControl);
