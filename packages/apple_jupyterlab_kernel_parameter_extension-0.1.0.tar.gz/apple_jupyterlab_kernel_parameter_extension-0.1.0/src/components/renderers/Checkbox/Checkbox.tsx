/**
 * Checkbox input component
 *
 * A simple checkbox for boolean values
 */

import React from 'react';

export interface CheckboxProps {
  /**
   * Current checked state
   */
  value: boolean;

  /**
   * Callback when checked state changes
   */
  updateValue: (newValue: boolean) => void;

  /**
   * Label for accessibility
   */
  label: string;

  /**
   * Optional HTML ID
   */
  id?: string;
}

/**
 * Checkbox component
 */
export const Checkbox: React.FC<CheckboxProps> = ({
  value,
  updateValue,
  label,
  id
}) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
    updateValue(event.target.checked);
  };

  return (
    <input
      type="checkbox"
      id={id}
      checked={value || false}
      className="Checkbox"
      onChange={handleChange}
      aria-label={label}
    />
  );
};
