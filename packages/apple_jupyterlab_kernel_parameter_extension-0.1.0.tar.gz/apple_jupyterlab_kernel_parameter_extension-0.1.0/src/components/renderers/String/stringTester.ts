/**
 * Tester for String renderer
 *
 * Determines when to use the String control for a schema property
 */

import { isStringControl, rankWith } from '@jsonforms/core';

/**
 * Use String control for string properties
 * Rank 3 means it takes precedence over default renderers
 */
export default rankWith(3, isStringControl);
