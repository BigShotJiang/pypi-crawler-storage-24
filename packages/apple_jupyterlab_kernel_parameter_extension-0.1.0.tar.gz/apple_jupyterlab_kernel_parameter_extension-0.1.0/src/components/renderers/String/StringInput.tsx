/**
 * String input component
 *
 * A simple text input field that supports both string and integer values
 */

import React from 'react';

export interface StringInputProps {
  /**
   * Current value
   */
  value: string | number;

  /**
   * Callback when value changes
   */
  updateValue: (newValue: string | number) => void;

  /**
   * Whether to parse the value as an integer
   */
  parseAsInt: boolean;

  /**
   * Optional HTML ID
   */
  id?: string;
}

/**
 * String input component
 */
export const StringInput: React.FC<StringInputProps> = ({
  value,
  updateValue,
  parseAsInt,
  id
}) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const newValue = parseAsInt
      ? parseInt(event.target.value, 10)
      : event.target.value;
    updateValue(newValue);
  };

  return (
    <input
      id={id}
      className="String"
      type="text"
      value={value || ''}
      onChange={handleChange}
    />
  );
};
