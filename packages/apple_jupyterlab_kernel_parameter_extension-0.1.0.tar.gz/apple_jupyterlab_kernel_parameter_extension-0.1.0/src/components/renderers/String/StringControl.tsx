/**
 * String control for JSONForms integration
 *
 * Wraps the StringInput component to work with JSONForms,
 * providing label, tooltip, and error display.
 */

import React, { useState, useCallback } from 'react';
import { withJsonFormsControlProps } from '@jsonforms/react';
import { ControlProps } from '@jsonforms/core';
import { Tooltip } from '@jupyter/react-components';
import { StringInput } from './StringInput';
import { TooltipIcon } from '../../shared';
import { useGlobalEventListener } from '../../../hooks';
import { ExtendedJsonSchema } from '../../../types';

export interface StringControlProps extends ControlProps {
  schema: ExtendedJsonSchema;
}

/**
 * String control component with label, tooltip, and validation
 */
const StringControl: React.FC<StringControlProps> = ({
  data,
  handleChange,
  path,
  schema,
  label,
  required,
  errors
}) => {
  const [tooltipAnchor, setTooltipAnchor] = useState<HTMLElement | null>(null);

  // Set up tooltip anchor ref
  const tooltipRef = useCallback((node: HTMLDivElement | null) => {
    if (node) {
      setTooltipAnchor(node);
    }
  }, []);

  // Listen for global events
  useGlobalEventListener(handleChange, path, schema.id);

  // Handle value change
  const handleValueChange = useCallback(
    (newValue: number | string): void => {
      handleChange(path, newValue);
    },
    [handleChange, path]
  );

  return (
    <div className="StringControl">
      <div className="StringControl__Label">
        {label}{' '}
        {required && <span className="StringControl__Required">*</span>}
        <span ref={tooltipRef}>
          <TooltipIcon />
        </span>
        <Tooltip
          anchorElement={tooltipAnchor}
          delay={100}
          position="top"
          className="tooltip-description"
        >
          {schema.description}
        </Tooltip>
      </div>
      <StringInput
        id={schema.id}
        value={data || ''}
        parseAsInt={schema.type === 'integer'}
        updateValue={handleValueChange}
      />
      {errors && <div className="StringControl__Error">{errors}</div>}
    </div>
  );
};

export default withJsonFormsControlProps(StringControl);
