/**
 * TextArea input component
 *
 * A multiline text input with configurable number of rows
 */

import React, { useRef } from 'react';

export interface TextAreaProps {
  /**
   * Current value
   */
  value: string;

  /**
   * Callback when value changes
   */
  updateValue: (newValue: string) => void;

  /**
   * Number of visible text rows
   */
  rows: number;

  /**
   * Optional HTML ID
   */
  id?: string;
}

/**
 * TextArea component
 *
 * Handles Cmd+X (cut) events properly by using a timeout to ensure
 * the onChange event fires after the clipboard operation completes
 */
export const TextArea: React.FC<TextAreaProps> = ({
  value,
  updateValue,
  rows,
  id
}) => {
  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  // Handle cut events (Cmd+X / Ctrl+X)
  // Need to use setTimeout because onChange doesn't fire immediately on cut
  const handleCut = (): void => {
    setTimeout(() => {
      if (textAreaRef.current) {
        updateValue(textAreaRef.current.value);
      }
    }, 0);
  };

  const handleChange = (
    event: React.ChangeEvent<HTMLTextAreaElement>
  ): void => {
    updateValue(event.target.value);
  };

  return (
    <textarea
      id={id}
      className="TextArea"
      rows={rows}
      value={value}
      ref={textAreaRef}
      onCut={handleCut}
      onChange={handleChange}
    />
  );
};
