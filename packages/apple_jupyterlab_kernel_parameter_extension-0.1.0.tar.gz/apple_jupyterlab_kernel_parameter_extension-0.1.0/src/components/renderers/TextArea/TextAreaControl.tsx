/**
 * TextArea control for JSONForms integration
 *
 * Wraps the TextArea component to work with JSONForms,
 * providing label, tooltip, and error display.
 */

import React, { useState, useCallback } from 'react';
import { withJsonFormsControlProps } from '@jsonforms/react';
import { ControlProps } from '@jsonforms/core';
import { Tooltip } from '@jupyter/react-components';
import { TextArea } from './TextArea';
import { TooltipIcon } from '../../shared';
import { useGlobalEventListener } from '../../../hooks';
import { ExtendedJsonSchema } from '../../../types';

export interface TextAreaControlProps extends ControlProps {
  schema: ExtendedJsonSchema;
}

/**
 * TextArea control component with label, tooltip, and validation
 */
const TextAreaControl: React.FC<TextAreaControlProps> = ({
  data,
  handleChange,
  path,
  schema,
  label,
  required,
  errors
}) => {
  const [tooltipAnchor, setTooltipAnchor] = useState<HTMLElement | null>(null);

  // Set up tooltip anchor ref
  const tooltipRef = useCallback((node: HTMLDivElement | null) => {
    if (node) {
      setTooltipAnchor(node);
    }
  }, []);

  // Listen for global events
  useGlobalEventListener(handleChange, path, schema.id);

  // Handle value change
  const handleValueChange = useCallback(
    (newValue: string): void => {
      handleChange(path, newValue);
    },
    [handleChange, path]
  );

  return (
    <div className="TextAreaControl">
      <div className="TextAreaControl__Label">
        {label}{' '}
        {required && <span className="TextAreaControl__Required">*</span>}
        <span ref={tooltipRef}>
          <TooltipIcon />
        </span>
        <Tooltip
          anchorElement={tooltipAnchor}
          delay={100}
          position="top"
          className="tooltip-description"
        >
          {schema.description}
        </Tooltip>
      </div>
      <TextArea
        value={data || ''}
        id={schema.id}
        rows={schema.rows || 5}
        updateValue={handleValueChange}
      />
      {errors && <div className="TextAreaControl__Error">{errors}</div>}
    </div>
  );
};

export default withJsonFormsControlProps(TextAreaControl);
