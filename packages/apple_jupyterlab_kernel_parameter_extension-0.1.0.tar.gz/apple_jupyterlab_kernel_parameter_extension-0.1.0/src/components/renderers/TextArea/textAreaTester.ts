/**
 * Tester for TextArea renderer
 *
 * Determines when to use the TextArea control for a schema property
 */

import { rankWith, Tester } from '@jsonforms/core';

/**
 * Check if the schema represents a multiline control
 *
 * Triggers textarea for:
 * - uischema.options.multi is true (UI schema setting)
 * - schema.rows property is set (number > 1)
 * - schema.format is "textarea"
 */
const isMultiLineControl: Tester = (uischema, schema): boolean => {
  if (!schema) {
    return false;
  }

  // Check uischema.options.multi (from UI schema)
  const uiOptions = (uischema as any)?.options;
  if (uiOptions?.multi === 'true' || uiOptions?.multi === true) {
    console.log('[TextAreaTester] Activated via uischema.options.multi');
    return true;
  }

  // Check schema.rows property (standard way to indicate textarea)
  const rows = (schema as any)?.rows;
  if (typeof rows === 'number' && rows > 1) {
    console.log('[TextAreaTester] Activated via schema.rows:', rows);
    return true;
  }

  // Check schema.format property
  const format = (schema as any)?.format;
  if (format === 'textarea') {
    console.log('[TextAreaTester] Activated via schema.format');
    return true;
  }

  return false;
};

/**
 * Use TextArea control for string properties marked as multiline
 * Rank 4 means it takes precedence over regular String control (rank 3)
 */
export default rankWith(4, isMultiLineControl);
