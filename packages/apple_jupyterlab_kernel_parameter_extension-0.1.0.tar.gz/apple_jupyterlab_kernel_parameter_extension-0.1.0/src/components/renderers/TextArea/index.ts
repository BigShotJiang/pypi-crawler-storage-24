/**
 * TextArea renderer exports
 */

export { TextArea } from './TextArea';
export { default as TextAreaControl } from './TextAreaControl';
export { default as textAreaTester } from './textAreaTester';
