/**
 * Select control for JSONForms integration
 *
 * Wraps the Select component to work with JSONForms,
 * providing label, tooltip, and error display.
 */

import React, { useState, useCallback } from 'react';
import { withJsonFormsControlProps } from '@jsonforms/react';
import { ControlProps } from '@jsonforms/core';
import { Tooltip } from '@jupyter/react-components';
import { Select } from './Select';
import { TooltipIcon } from '../../shared';
import { useGlobalEventListener } from '../../../hooks';
import { ExtendedJsonSchema } from '../../../types';

export interface SelectControlProps extends ControlProps {
  schema: ExtendedJsonSchema;
}

/**
 * Select control component with label, tooltip, and validation
 */
const SelectControl: React.FC<SelectControlProps> = ({
  data,
  handleChange,
  path,
  schema,
  label,
  required,
  errors
}) => {
  const [tooltipAnchor, setTooltipAnchor] = useState<HTMLElement | null>(null);
  const previousValue = React.useRef(data);

  // Set up tooltip anchor ref
  const tooltipRef = useCallback((node: HTMLDivElement | null) => {
    if (node) {
      setTooltipAnchor(node);
    }
  }, []);

  // Listen for global events
  useGlobalEventListener(handleChange, path, schema.id);

  // Handle selection change and fire global event
  const handleSelectChange = useCallback(
    (newValue: number | string): void => {
      const oldValue = previousValue.current;
      previousValue.current = newValue;
      handleChange(path, newValue);

      // Dispatch global event for dropdown changes
      const event = new CustomEvent('dropdownSelectionChange', {
        detail: {
          path,
          oldValue,
          newValue
        }
      });
      window.dispatchEvent(event);
    },
    [handleChange, path]
  );

  return (
    <div className="SelectControl">
      <div className="SelectControl__Label">
        {label}{' '}
        {required && <span className="SelectControl__Required">*</span>}
        <span ref={tooltipRef}>
          <TooltipIcon />
        </span>
        <Tooltip
          anchorElement={tooltipAnchor}
          delay={100}
          position="top"
          className="tooltip-description"
        >
          {schema.description}
        </Tooltip>
      </div>
      <Select
        label={label}
        options={schema.enum}
        id={schema.id}
        value={data}
        parseAsInt={schema.type === 'integer'}
        updateValue={handleSelectChange}
      />
      {errors && <div className="SelectControl__Error">{errors}</div>}
    </div>
  );
};

export default withJsonFormsControlProps(SelectControl);
