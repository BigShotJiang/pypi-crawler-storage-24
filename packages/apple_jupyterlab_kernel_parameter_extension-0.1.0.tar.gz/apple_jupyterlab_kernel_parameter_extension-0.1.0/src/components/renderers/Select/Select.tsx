/**
 * Select component for dropdown lists
 *
 * A simple select dropdown that supports both string and integer values
 */

import React from 'react';

export interface SelectProps {
  /**
   * Current selected value
   */
  value: string | number;

  /**
   * Callback when value changes
   */
  updateValue: (newValue: string | number) => void;

  /**
   * Available options to select from
   */
  options?: Array<string | number>;

  /**
   * Whether to parse the value as an integer
   */
  parseAsInt: boolean;

  /**
   * Label for accessibility
   */
  label: string;

  /**
   * Optional HTML ID
   */
  id?: string;
}

/**
 * Select dropdown component
 */
export const Select: React.FC<SelectProps> = ({
  value,
  updateValue,
  options = [],
  parseAsInt,
  label,
  id
}) => {
  const handleChange = (event: React.ChangeEvent<HTMLSelectElement>): void => {
    const newValue = parseAsInt
      ? parseInt(event.target.value, 10)
      : event.target.value;
    updateValue(newValue);
  };

  return (
    <select
      className="Select"
      value={value}
      onChange={handleChange}
      id={id}
      aria-label={label}
    >
      {options.map(option => (
        <option key={`kernel-manager-${label}-${option}`} value={option}>
          {option}
        </option>
      ))}
    </select>
  );
};
