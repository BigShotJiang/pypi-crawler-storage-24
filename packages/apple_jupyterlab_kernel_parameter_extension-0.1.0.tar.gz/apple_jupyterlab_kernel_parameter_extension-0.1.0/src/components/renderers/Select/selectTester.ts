/**
 * Tester for Select renderer
 *
 * Determines when to use the Select control for a schema property
 */

import { isEnumControl, rankWith } from '@jsonforms/core';

/**
 * Use Select control for enum properties
 * Rank 3 means it takes precedence over default renderers
 */
export default rankWith(3, isEnumControl);
