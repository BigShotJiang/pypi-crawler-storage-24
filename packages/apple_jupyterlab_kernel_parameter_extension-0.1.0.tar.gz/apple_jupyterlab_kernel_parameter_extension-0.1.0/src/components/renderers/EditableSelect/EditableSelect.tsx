/**
 * Editable Select component
 *
 * A hybrid select/input component that allows users to either:
 * - Select from predefined options via dropdown
 * - Type a custom value in the input field
 */

import React, { useState, useEffect, useRef } from 'react';

export interface EditableSelectProps {
  /**
   * Current value
   */
  value: string | number;

  /**
   * Callback when value changes
   */
  updateValue: (newValue: string | number) => void;

  /**
   * Available options to select from
   */
  options?: Array<string | number>;

  /**
   * Whether to parse the value as an integer
   */
  parseAsInt: boolean;

  /**
   * Label for accessibility
   */
  label: string;

  /**
   * Optional HTML ID
   */
  id?: string;
}

/**
 * EditableSelect component
 *
 * Combines a dropdown and text input, allowing selection from
 * predefined options or custom text entry.
 */
export const EditableSelect: React.FC<EditableSelectProps> = ({
  value,
  updateValue,
  options = [],
  parseAsInt,
  label,
  id
}) => {
  const [selectedValue, setSelectedValue] = useState(value);
  const [customValue, setCustomValue] = useState(value);
  const [persistentOptions, setPersistentOptions] = useState<
    Array<string | number>
  >([]);

  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize options, ensuring current value is included
  useEffect(() => {
    setPersistentOptions(prevOptions => {
      const newOptions = new Set(options);

      // Include current value if it's not in the options
      if (!newOptions.has(value)) {
        newOptions.add(value);
      }

      // Add all provided options
      options.forEach(op => newOptions.add(op));

      return Array.from(newOptions);
    });
  }, [value, options]);

  // Handle clicking the input to select all text
  const handleInputClick = (): void => {
    if (inputRef.current) {
      inputRef.current.select();
    }
  };

  // Handle dropdown selection change
  const handleSelectChange = (
    event: React.ChangeEvent<HTMLSelectElement>
  ): void => {
    const newValue = event.target.value;
    setSelectedValue(newValue);
    setCustomValue(newValue);
    updateValue(parseAsInt ? parseInt(newValue, 10) : newValue);
  };

  // Handle manual input change
  const handleInputChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ): void => {
    const newValue = event.target.value;
    setCustomValue(newValue);
    setSelectedValue(''); // Clear selection when typing custom value
    updateValue(parseAsInt ? parseInt(newValue, 10) : newValue);
  };

  return (
    <div className="select-editable">
      <select
        className="EditableSelect__Dropdown"
        value={selectedValue}
        onChange={handleSelectChange}
        aria-label={`${label} dropdown`}
      >
        {persistentOptions.map(option => (
          <option key={`kernel-manager-${label}-${option}`} value={option}>
            {option}
          </option>
        ))}
      </select>
      <input
        id={id}
        ref={inputRef}
        type="text"
        className="EditableSelect__Input"
        onClick={handleInputClick}
        value={customValue}
        onChange={handleInputChange}
        aria-label={`${label} custom input`}
      />
    </div>
  );
};
