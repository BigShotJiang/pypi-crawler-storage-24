/**
 * EditableSelect control for JSONForms integration
 *
 * Wraps the EditableSelect component to work with JSONForms,
 * providing label, tooltip, and error display.
 */

import React, { useState, useCallback } from 'react';
import { withJsonFormsControlProps } from '@jsonforms/react';
import { ControlProps } from '@jsonforms/core';
import { Tooltip } from '@jupyter/react-components';
import { EditableSelect } from './EditableSelect';
import { TooltipIcon } from '../../shared';
import { useGlobalEventListener } from '../../../hooks';
import { ExtendedJsonSchema } from '../../../types';

export interface EditableSelectControlProps extends ControlProps {
  schema: ExtendedJsonSchema;
}

/**
 * EditableSelect control component with label, tooltip, and validation
 */
const EditableSelectControl: React.FC<EditableSelectControlProps> = ({
  data,
  handleChange,
  path,
  schema,
  label,
  required,
  errors
}) => {
  const [tooltipAnchor, setTooltipAnchor] = useState<HTMLElement | null>(null);

  // Set up tooltip anchor ref
  const tooltipRef = useCallback((node: HTMLDivElement | null) => {
    if (node) {
      setTooltipAnchor(node);
    }
  }, []);

  // Listen for global events
  useGlobalEventListener(handleChange, path, schema.id);

  // Handle value change
  const handleValueChange = useCallback(
    (newValue: number | string): void => {
      handleChange(path, newValue);
    },
    [handleChange, path]
  );

  return (
    <div className="EditableSelectControl">
      <div className="EditableSelectControl__Label">
        {label}{' '}
        {required && (
          <span className="EditableSelectControl__Required">*</span>
        )}
        <span ref={tooltipRef}>
          <TooltipIcon />
        </span>
        <Tooltip
          anchorElement={tooltipAnchor}
          delay={100}
          position="top"
          className="tooltip-description"
        >
          {schema.description}
        </Tooltip>
      </div>
      <EditableSelect
        label={label}
        options={schema.enum}
        id={schema.id}
        value={data}
        parseAsInt={schema.type === 'integer'}
        updateValue={handleValueChange}
      />
      {errors && <div className="EditableSelectControl__Error">{errors}</div>}
    </div>
  );
};

export default withJsonFormsControlProps(EditableSelectControl);
