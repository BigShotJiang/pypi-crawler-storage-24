/**
 * Tester for EditableSelect renderer
 *
 * Determines when to use the EditableSelect control for a schema property
 */

import { isEnumControl, rankWith, and, Tester } from '@jsonforms/core';

/**
 * Check if the schema allows custom values
 */
const isCustomEnumControl: Tester = (uischema, schema): boolean => {
  if (!schema) {
    return false;
  }

  // Check for editable.allow_custom or options.allow_custom flags
  const editable = (schema as any)?.editable;
  const options = (schema as any)?.options;

  return (
    editable?.allow_custom === 'true' ||
    editable?.allow_custom === true ||
    options?.allow_custom === true
  );
};

/**
 * Use EditableSelect control for enum properties that allow custom values
 * Rank 4 means it takes precedence over regular Select (rank 3)
 */
export default rankWith(4, and(isEnumControl, isCustomEnumControl));
