/**
 * Kernel Configuration Component
 *
 * Main form component for configuring kernel parameters using JSONForms.
 * Handles field interactions, validation, and configuration persistence.
 */

import React, { useState, useEffect, useCallback } from 'react';
import { JsonForms } from '@jsonforms/react';
import {
  vanillaCells,
  vanillaRenderers,
  JsonFormsStyleContext,
  vanillaStyles
} from '@jsonforms/vanilla-renderers';
import { ErrorObject } from 'ajv';
import {
  ExtendedJsonSchema,
  KernelCustomConfiguration,
  IKernelConfigObject,
  ConfigMap,
  DropdownChangeEvent
} from '../../types';
import { validateRules } from '../../utils/validation';
import {
  parseConfigString,
  stringifyConfigObject,
  mergeConfigs
} from '../../utils/schemaHelpers';
import {
  selectTester,
  SelectControl,
  editableSelectTester,
  EditableSelectControl,
  stringTester,
  StringControl,
  textAreaTester,
  TextAreaControl,
  checkboxTester,
  CheckboxControl
} from '../renderers';

/**
 * Style context for JSONForms with custom control classes
 */
const styleContextValue = {
  styles: [
    ...vanillaStyles,
    {
      name: 'control.select',
      classNames: ['Select']
    },
    {
      name: 'control.string',
      classNames: ['String']
    },
    {
      name: 'control.textarea',
      classNames: ['TextArea']
    },
    {
      name: 'control.checkbox',
      classNames: ['Checkbox']
    }
  ]
};

export interface KernelConfigurationProps {
  setKernelConfig: (config: IKernelConfigObject) => void;
  customConfig: KernelCustomConfiguration;
}

/**
 * Kernel Configuration Form Component
 *
 * Renders a dynamic form based on kernel metadata schema,
 * with support for field cascading, validation, and persistence.
 */
export const KernelConfigurationComponent: React.FC<
  KernelConfigurationProps
> = ({ setKernelConfig, customConfig }) => {
  const errorUpdateFunc = customConfig.errorUpdateFn;
  const [data, setData] = useState<ConfigMap>(
    customConfig.defaultValues as ConfigMap
  );
  const configProperties = customConfig.config?.properties;
  const [additionalErrors, setAdditionalErrors] = useState<ErrorObject[]>([]);
  const [errors, setErrors] = useState<ErrorObject[]>([]);

  // Update parent component with current config and errors
  useEffect(() => {
    setKernelConfig({ data, errors });
  }, [data, errors, setKernelConfig]);

  // Enable/disable dialog accept button based on errors
  useEffect(() => {
    const defaultButton = document.querySelector(
      '.jp-Dialog-button.jp-mod-accept'
    );

    if (defaultButton) {
      if (additionalErrors.length) {
        defaultButton.setAttribute('disabled', 'disabled');
      } else {
        defaultButton.removeAttribute('disabled');
      }
    }
  }, [additionalErrors]);

  /**
   * Construct an error object for validation failures
   */
  const constructAdditionalError = useCallback(
    (schemaName: string, errorMessage: string): ErrorObject => {
      return {
        message: errorMessage,
        instancePath: `/${schemaName}`,
        schemaPath: '',
        keyword: '',
        params: {}
      } as ErrorObject;
    },
    []
  );

  /**
   * Handle dropdown selection changes and apply field cascading
   */
  useEffect(() => {
    const handleDropdownChange = (event: Event): void => {
      const customEvent = event as DropdownChangeEvent;

      setData(prevData => {
        const updatedData = {
          ...prevData,
          [customEvent.detail.path]: customEvent.detail.newValue
        };

        // Check if this field has enumConfigs and enumInteractionOverrides
        if (
          configProperties &&
          customEvent.detail.path in configProperties &&
          'enumConfigs' in configProperties[customEvent.detail.path] &&
          'enumInteractionOverrides' in
            configProperties[customEvent.detail.path]
        ) {
          const fieldProperties = configProperties[
            customEvent.detail.path
          ] as any;
          const enumConfigs = fieldProperties.enumConfigs as Record<
            string,
            ConfigMap
          >;
          const enumInteractionsOverride = fieldProperties.enumInteractionOverrides as Array<{
            pathToUpdate: string;
            sourceField: string;
          }>;

          // Get configuration to apply for selected enum value
          const configToApply: ConfigMap = {
            ...enumConfigs[customEvent.detail.newValue]
          };

          // Apply interaction overrides
          enumInteractionsOverride.forEach(mapping => {
            if (
              'pathToUpdate' in mapping &&
              'sourceField' in mapping &&
              mapping.pathToUpdate in updatedData &&
              (mapping.sourceField in configToApply ||
                mapping.sourceField === 'ALL')
            ) {
              const sourceField = mapping.sourceField;
              const pathField = mapping.pathToUpdate;

              if (sourceField !== 'ALL') {
                // Direct field update
                updatedData[pathField] = configToApply[sourceField] || '';
                delete configToApply[sourceField];
              } else {
                // Merge all config values into multiline field
                const multiConfigToUpdate = updatedData[pathField]
                  ? parseConfigString(updatedData[pathField] || '')
                  : {};
                updatedData[pathField] = stringifyConfigObject(
                  mergeConfigs(configToApply, multiConfigToUpdate)
                );
              }
            } else {
              console.warn(
                'Missing configuration parameters, could not apply:',
                mapping,
                updatedData,
                configToApply
              );
            }
          });
        }

        return updatedData;
      });
    };

    window.addEventListener(
      'dropdownSelectionChange',
      handleDropdownChange as EventListener
    );

    return (): void => {
      window.removeEventListener(
        'dropdownSelectionChange',
        handleDropdownChange as EventListener
      );
    };
  }, [configProperties]);

  /**
   * Validate data and update error states
   */
  const updateErrors = useCallback(
    (data: ConfigMap): void => {
      const config = customConfig.config;
      const processedErrors: ErrorObject[] = [];

      for (const configField of Object.keys(data)) {
        const value = data[configField];
        const validationRules = (config.properties as any)?.[configField]
          ?.validation;

        if (validationRules) {
          const validationResult = validateRules(
            value,
            (config.properties as any)[configField].title,
            validationRules
          );

          if (!validationResult.success) {
            const newError = constructAdditionalError(
              configField,
              validationResult.errorMessage
            );
            processedErrors.push(newError);
          }
        }
      }

      setAdditionalErrors(processedErrors);
      setErrors(processedErrors);

      if (errorUpdateFunc) {
        errorUpdateFunc(processedErrors);
      }
    },
    [customConfig.config, constructAdditionalError, errorUpdateFunc]
  );

  // Show message if kernel doesn't support configuration
  if (Object.keys(customConfig.config).length === 0) {
    return (
      <div className="KernelConfiguration">
        The current selected kernel does not support custom configuration.
      </div>
    );
  }

  return (
    <div className="KernelConfiguration">
      <JsonFormsStyleContext.Provider value={styleContextValue}>
        <JsonForms
          schema={customConfig.config}
          data={data}
          cells={vanillaCells}
          uischema={customConfig.uischema}
          renderers={[
            ...vanillaRenderers,
            { tester: editableSelectTester, renderer: EditableSelectControl },
            { tester: selectTester, renderer: SelectControl },
            { tester: textAreaTester, renderer: TextAreaControl },
            { tester: stringTester, renderer: StringControl },
            { tester: checkboxTester, renderer: CheckboxControl }
          ]}
          additionalErrors={additionalErrors as ErrorObject[]}
          validationMode="NoValidation"
          onChange={({ data }): void => {
            setData(data);
            updateErrors(data);
          }}
        />
      </JsonFormsStyleContext.Provider>
    </div>
  );
};
