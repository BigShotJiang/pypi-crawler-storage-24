/**
 * Kernel Configuration Widget
 *
 * ReactWidget wrapper for the kernel configuration component.
 * Manages schema setup, default values, and configuration persistence.
 */

import { ReactWidget } from '@jupyterlab/apputils';
import { KernelSpec } from '@jupyterlab/services';
import { UISchemaElement } from '@jsonforms/core';
import React from 'react';
import {
  ExtendedJsonSchema,
  KernelCustomConfiguration,
  IKernelConfigObject
} from '../../types';
import {
  generateDefaults,
  fitValuesToSchema,
  stringifyValues,
  loadConfig,
  hasSchemaDefaults,
  saveSchemaDefaults
} from '../../utils/schemaHelpers';
import { KernelConfigurationComponent } from './KernelConfigurationComponent';

/**
 * Kernel Configuration Widget
 *
 * Provides a JupyterLab widget for configuring kernel parameters
 * using JSONForms with persistence and validation.
 */
export class KernelConfigurationWidget extends ReactWidget {
  public config: ExtendedJsonSchema = {};
  public uischema: UISchemaElement | undefined = undefined;
  public defaultValues: Record<string, unknown> = {};
  public conflictingKeys = '';
  public infoText = '';
  public dialogTitle = '';
  private customConfig: IKernelConfigObject = { data: {}, errors: [] };

  /**
   * Render the React component
   */
  protected render(): JSX.Element {
    return (
      <>
        {this.conflictingKeys && (
          <div>
            The configuration set for key(s) <b>{this.conflictingKeys}</b> are
            not valid. Please select a new configuration.
          </div>
        )}
        {this.infoText && (
          <div>
            <b>{this.infoText}</b>
          </div>
        )}
        <KernelConfigurationComponent
          setKernelConfig={this.setKernelConfig}
          customConfig={{
            config: this.config,
            uischema: this.uischema,
            defaultValues: this.defaultValues,
            errorUpdateFn: this.updateSchemaErrors
          }}
        />
      </>
    );
  }

  /**
   * Set informational text to display above the form
   */
  public setInfoText(text: string): void {
    this.infoText = text;
  }

  /**
   * Set conflicting keys warning message
   */
  public setConflictingKeys(conflictingKeys: string): void {
    this.conflictingKeys = conflictingKeys;
  }

  /**
   * Set up the schema from a kernel spec
   *
   * Loads configuration schema, UI schema, and defaults from kernel metadata.
   * Also restores previous user configurations from localStorage.
   */
  public setSchema(spec: KernelSpec.ISpecModel | undefined): void {
    const custom = spec?.metadata?.kernel_provisioner as unknown as
      | KernelCustomConfiguration
      | undefined;

    if (custom?.config) {
      this.config = custom.config;
    }

    if (custom?.config && custom?.uischema) {
      this.uischema = custom.uischema;
    }

    if (custom?.config && custom?.config.title) {
      this.dialogTitle = custom.config.title;
    }

    if (this.config.properties) {
      let previousConfig: Record<string, string> = {};

      // Load previous configuration from localStorage
      if (this.dialogTitle) {
        previousConfig = loadConfig(this.dialogTitle);
      }

      // Save schema defaults on first use
      if (this.dialogTitle && !hasSchemaDefaults(this.dialogTitle)) {
        saveSchemaDefaults(this.dialogTitle, this.config);
      }

      // Process schema properties
      Object.entries(this.config.properties).forEach(([key, obj]) => {
        // Set default from first enum value if no default exists
        if (obj.enum && obj.enum.length > 0 && !obj.default) {
          obj.default = obj.enum[0];
        }

        // Generate ID from title if not present
        if (!('id' in obj) && 'title' in obj) {
          obj.id = String(obj.title).replace(/[^a-zA-Z]/g, '-');
        }

        // Apply previous configuration as default
        if (key in previousConfig) {
          obj.default = previousConfig[key];
        }
      });
    }

    // Generate default values from schema
    const myDefaultInstance = generateDefaults(this.config);
    this.defaultValues = fitValuesToSchema(
      myDefaultInstance as Record<string, string>,
      this.config
    );
  }

  /**
   * Callback to update kernel configuration
   */
  public setKernelConfig = (config: IKernelConfigObject): void => {
    this.customConfig = { ...config };
  };

  /**
   * Set default values, merging with existing defaults
   */
  public setDefaultValues = (def: Record<string, unknown>): void => {
    const values = { ...this.defaultValues, ...def };
    this.defaultValues = fitValuesToSchema(
      values as Record<string, string>,
      this.config
    );
  };

  /**
   * Get current configuration as stringified values
   */
  public getSchema(): Record<string, string> {
    return stringifyValues(this.customConfig.data);
  }

  /**
   * Update schema validation errors
   */
  public updateSchemaErrors = (errors: any): void => {
    this.customConfig.errors = errors;
  };

  /**
   * Get current validation errors
   */
  public getSchemaErrors(): any[] {
    return this.customConfig.errors;
  }

  /**
   * Check if kernel has custom configuration
   */
  public hasCustomConfig = (): boolean => {
    return Object.keys(this.config).length !== 0;
  };
}
