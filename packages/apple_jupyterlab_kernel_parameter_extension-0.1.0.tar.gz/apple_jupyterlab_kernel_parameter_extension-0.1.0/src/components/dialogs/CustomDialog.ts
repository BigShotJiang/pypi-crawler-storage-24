/**
 * Custom dialog utilities for kernel configuration
 *
 * Provides enhanced Dialog functionality with validation,
 * default restoration, and configuration persistence.
 */

import { Dialog } from '@jupyterlab/apputils';
import { KernelConfigurationWidget } from '../KernelConfiguration';

const RESTORE_BUTTON_CLASS = 'restore-defaults';

/**
 * "Restore Defaults" button for dialog
 */
export const restoreDefaultsButton = Dialog.createButton({
  label: 'Restore Defaults',
  accept: false,
  displayType: 'warn',
  className: RESTORE_BUTTON_CLASS
});

/**
 * Custom form dialog that:
 * - Prevents submission when validation errors exist
 * - Saves configuration to localStorage on accept
 * - Provides "Restore Defaults" functionality
 * - Blocks Enter key when errors are present
 * - Allows Escape key to cancel the dialog
 * - Auto-focuses the first input field for immediate keyboard interaction
 *
 * @param options - Dialog options with KernelConfigurationWidget as body
 * @returns Promise resolving to dialog result
 */
export const customFormDialog = async (
  options: Partial<Dialog.IOptions<any>>
): Promise<Dialog.IResult<any>> => {
  const dialogBody = options.body;
  const dialog = new Dialog(options);

  if (dialogBody instanceof KernelConfigurationWidget) {
    const defaultButtonIndex =
      options.defaultButton || (options.buttons?.length ?? 0) - 1;

    // Set up accept button to save configuration
    const defaultButton = dialog.node
      .querySelector('.jp-Dialog-footer')
      ?.getElementsByTagName('button')[defaultButtonIndex];

    if (defaultButton) {
      defaultButton.onclick = (): void => {
        const formData = JSON.stringify(dialogBody.getSchema());
        localStorage.setItem(
          `${dialogBody.config.title}-kernel-config`,
          formData
        );
      };
    }

    // Override Dialog.handleEvent to add custom validation behavior
    const dialogHandleEvent = dialog.handleEvent.bind(dialog);

    dialog.handleEvent = (event: Event): void => {
      const dialogErrors = dialogBody.getSchemaErrors();

      // Handle keyboard events
      if (event instanceof KeyboardEvent && event.type === 'keydown') {
        // Handle Escape key - always allow it to pass through for cancellation
        if (event.keyCode === 27 || event.key === 'Escape') {
          console.log('[Dialog] Escape key pressed, allowing cancel');
          // Don't prevent default - let JupyterLab's dialog handle it
          dialogHandleEvent(event);
          return;
        }

        // Handle Enter key - block if errors exist
        if (event.keyCode === 13 || event.key === 'Enter') {
          // Allow Enter in textarea, block everywhere else if errors exist
          if (!(event.target instanceof HTMLTextAreaElement)) {
            if (dialogErrors.length > 0) {
              console.log('[Dialog] Enter key blocked due to validation errors');
              event.stopPropagation();
              event.preventDefault();
              return;
            } else {
              // No errors - let JupyterLab handle the submit
              console.log('[Dialog] Enter key pressed, allowing submit');
              dialogHandleEvent(event);
              return;
            }
          }
        }

        // For all other keyboard events, pass through
        dialogHandleEvent(event);
        return;
      }
      // Handle mouse events (button clicks)
      else if (event instanceof MouseEvent && event.type === 'click') {
        const target = event.target as HTMLElement;

        // Handle "Restore Defaults" button
        if (target.closest(`.${RESTORE_BUTTON_CLASS}`)) {
          event.stopPropagation();
          event.preventDefault();

          const savedSchemaDefault =
            localStorage.getItem(
              `${dialogBody.config.title}-kernel-config-default`
            ) || '{}';
          const schemaDefault = JSON.parse(savedSchemaDefault);

          Object.entries(schemaDefault).forEach(([key, obj]: [string, any]) => {
            let id = '';
            if ('id' in obj) {
              id = obj.id;
            } else if ('title' in obj) {
              id = obj.title.replace(/[^a-zA-Z]/g, '-');
            }

            const formElement = dialog.node
              .querySelector('.jp-Dialog-body')
              ?.querySelector(`#${id}`) as HTMLFormElement;

            if (formElement) {
              const detail: {
                id: string;
                path: string;
                value: any;
                checked: boolean | undefined;
              } = {
                id: id,
                path: key,
                value: obj.default,
                checked: undefined
              };

              if (formElement.classList.contains('Checkbox')) {
                detail.checked = obj.default === true;
              }

              const customEvent = new CustomEvent('updateCustomControl', {
                detail
              });
              window.dispatchEvent(customEvent);
            }
          });
        }
        // Prevent clicks on accept button when errors exist
        // Allow cancel button to work
        else if (
          dialogErrors.length > 0 &&
          !target.closest('.jp-mod-reject')
        ) {
          event.stopPropagation();
          event.preventDefault();
        } else {
          dialogHandleEvent(event);
        }
      } else {
        dialogHandleEvent(event);
      }
    };
  } else {
    console.warn('Dialog body is not a KernelConfigurationWidget');
  }

  // Launch the dialog
  const resultPromise = dialog.launch();

  // Set focus on first input field after dialog is rendered
  setTimeout(() => {
    // Find the first input element (input, select, or textarea)
    const firstInput = dialog.node.querySelector(
      '.jp-Dialog-body input, .jp-Dialog-body select, .jp-Dialog-body textarea'
    ) as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;

    if (firstInput) {
      console.log('[Dialog] Auto-focusing first field:', firstInput.id || firstInput.name);
      firstInput.focus();
    } else {
      console.log('[Dialog] No input field found for auto-focus');
    }
  }, 100);

  return resultPromise;
};
