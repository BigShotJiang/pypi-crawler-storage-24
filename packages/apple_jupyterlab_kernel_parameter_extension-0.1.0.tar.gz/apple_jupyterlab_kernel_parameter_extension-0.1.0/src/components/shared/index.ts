/**
 * Shared components for kernel parameter extension
 */

export * from './TooltipIcon';
