/**
 * Tooltip icon component
 *
 * Displays a small info icon used as an anchor for tooltips
 */

import React from 'react';
import TooltipIconSvg from '../../../style/icons/tooltip.svg';

/**
 * SVG tooltip icon component
 */
export function TooltipIcon(): JSX.Element {
  return (
    <img
      className="tooltip-icon"
      src={`data:image/svg+xml;utf8,${encodeURIComponent(TooltipIconSvg)}`}
      alt="Info"
    />
  );
}
