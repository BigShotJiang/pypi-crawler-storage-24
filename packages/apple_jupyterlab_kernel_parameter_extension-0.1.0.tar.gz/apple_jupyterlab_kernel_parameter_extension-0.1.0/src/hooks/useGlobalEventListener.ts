/**
 * Custom hook for listening to global control update events
 *
 * This hook allows form controls to respond to external updates
 * triggered via custom window events.
 */

import { useEffect } from 'react';

/**
 * Event detail structure for custom control updates
 */
interface ControlUpdateDetail {
  path: string;
  id?: string;
  value?: string | number;
  checked?: boolean;
}

/**
 * Hook to listen for global control update events
 *
 * @param handleChange - Callback to update the control value
 * @param path - JSONForms path for this control
 * @param id - Optional ID for more specific matching
 */
export function useGlobalEventListener(
  handleChange: (path: string, value: string | number | boolean) => void,
  path: string,
  id?: string
): void {
  useEffect(() => {
    const handleExternalChange = (event: Event): void => {
      const customEvent = event as CustomEvent<ControlUpdateDetail>;

      if (!customEvent.detail || customEvent.detail.path !== path) {
        return;
      }

      // If ID is specified, it must match
      if (id && customEvent.detail.id !== id) {
        return;
      }

      // Handle checkbox (checked) or regular (value) updates
      if (typeof customEvent.detail.checked !== 'undefined') {
        handleChange(path, customEvent.detail.checked);
      } else if (typeof customEvent.detail.value !== 'undefined') {
        handleChange(path, customEvent.detail.value);
      }
    };

    window.addEventListener('updateCustomControl', handleExternalChange);

    return (): void => {
      window.removeEventListener('updateCustomControl', handleExternalChange);
    };
  }, [handleChange, path, id]);
}
