# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a JupyterLab 4.x extension that enables **kernel parameter configuration dialogs** before kernel startup. It intercepts kernel selection flows and shows JSONForms-based configuration UIs when kernels define `metadata.kernel_provisioner.config` in their kernel.json spec.

**Package names:**
- NPM: `@apple/jupyterlab-kernel-parameter-extension`
- Python: `apple_jupyterlab_kernel_parameter_extension`
- Plugin IDs: `@apple/jupyterlab-kernel-parameter-extension:plugin` and `:raiseErrors`

## Build & Development Commands

### Initial Setup
```bash
pip install -e .
jlpm install
```

### Development Build
```bash
jlpm build                    # Build TypeScript and create labextension (dev mode)
jlpm build:lib                # Just compile TypeScript with sourcemaps
jlpm build:labextension:dev   # Just build JupyterLab extension (dev mode)
```

### Production Build
```bash
jlpm build:prod               # Full production build (clean + compile + package)
```

### Watch Mode
```bash
jlpm watch                    # Run both TypeScript and labextension watchers in parallel
jlpm watch:src                # Watch TypeScript files only
jlpm watch:labextension       # Watch for labextension changes only
```

### Clean
```bash
jlpm clean                    # Remove lib/ and TypeScript build artifacts
jlpm clean:labextension       # Remove Python package labextension output
jlpm clean:all                # Clean everything
```

### Install to JupyterLab
```bash
jlpm install:full             # pip install + jlpm install + build + develop link
jupyter labextension develop . --overwrite   # Link extension to JupyterLab
```

**After code changes:** Run `jlpm build` then refresh JupyterLab in browser (Cmd+Shift+R / Ctrl+Shift+R)

## Architecture

### Triple Interception Strategy

The extension intercepts kernel selection at **three entry points** to ensure the config dialog appears regardless of how the user selects a kernel:

1. **Menu-based selection** (`Kernel → Change Kernel...`)
   - Overrides `ISessionContextDialogs.selectKernel`
   - Implementation: `src/services/customKernelSelector.ts`
   - Console logs: `[KernelSelector]` prefix

2. **Toolbar dropdown** (kernel selector in notebook toolbar)
   - Wraps `sessionContext.changeKernel()` for each notebook via `INotebookTracker`
   - Set up in `src/index.ts` plugin activation
   - Console logs: `[Toolbar]` prefix

3. **Launcher tiles** (clicking "Python 3 Notebook" on launcher page)
   - Intercepts `app.commands.execute` for `notebook:create-new` and `console:create`
   - Set up in `src/index.ts` plugin activation
   - Console logs: `[Launcher]` prefix

All three paths check for `kernelspec?.metadata?.kernel_provisioner?.config`. If present, they show the configuration dialog. If absent, they proceed with normal kernel startup.

### JSONForms Integration

Uses JSONForms 3.3 with custom React renderers for form fields:

**Custom Renderers** (`src/components/renderers/`):
- `Select/` - Standard dropdown (uses `enum` from schema)
- `EditableSelect/` - Hybrid dropdown + text input (for `editable: true` fields)
- `String/` - Text input
- `TextArea/` - Multiline text (activated by `rows > 1`, `options.multi: true`, or `format: "textarea"`)
- `Checkbox/` - Boolean input

**Renderer Selection:**
Each renderer has a tester function that returns a rank. Higher rank = higher priority. Example: TextAreaTester checks for multiline indicators and returns rank 4, while StringTester returns rank 3, so TextArea takes precedence for multiline strings.

**Field Cascading:**
The `KernelConfigurationComponent` handles `enumInteractionOverrides` - when a dropdown changes, it can:
- Show/hide other fields via `fieldToModify.visible`
- Change other field values via `fieldToModify.setDefaultTo`
- Apply `enumConfigs` to set multiple defaults at once

### Configuration Persistence

**Two storage locations:**
1. **Notebook metadata** - Saved as `kernel_params` in `.ipynb` file, accessible to kernel provisioner
2. **localStorage** - Browser storage keyed by kernel title for pre-filling next time

**Flow:**
- User fills form → Clicks Accept → Config saved to both locations → Kernel starts with params
- Next time same kernel selected → localStorage values pre-fill form

### Dialog Features

The `CustomDialog` (`src/components/dialogs/CustomDialog.ts`) enhances JupyterLab's standard Dialog with:
- **Validation blocking** - Prevents submission when `getSchemaErrors()` returns errors
- **Restore Defaults** - Loads from localStorage `{kernelTitle}-kernel-config-default`
- **Escape key** - Always allows cancel (passes through to JupyterLab's dialog handler)
- **Enter key** - Submits only if no validation errors (blocked otherwise)
- **Auto-focus** - First input field receives focus on dialog open for immediate keyboard interaction

### Type System

**Extended JSON Schema** (`src/types/schema.ts`):
```typescript
export type ExtendedJsonSchema = JsonSchema & {
  id?: string;
  editable?: string | boolean;     // Makes dropdown editable
  rows?: number;                    // Triggers textarea
  enumConfigs?: Record<string, ConfigMap>;
  enumInteractionOverrides?: EnumInteractionOverride[];
  validation?: ValidationRules;
  // ... standard JSON Schema properties
};
```

Uses **type intersection** (`type X = Y & Z`) instead of interface extension to avoid conflicts with JupyterLab's type system.

### Validation System

**Two-tier validation:**

1. **JSON Schema validation** - Standard JSONForms/AJV validation from schema
2. **Custom validation** (`src/utils/validation.ts`) - Additional rules via `validation` property:
   - `required: true` - Field must have value
   - `startsWith: "https://"` - String prefix check
   - `range: {min, max}` - Numeric range validation
   - `pattern: {value, errorMessage}` - Regex with custom error

## Important Implementation Details

### When Adding New Renderers

1. Create directory in `src/components/renderers/{RendererName}/`
2. Implement `{RendererName}.tsx` (presentational component)
3. Implement `{RendererName}Control.tsx` (JSONForms control with `withJsonFormsControlProps`)
4. Implement `{rendererName}Tester.ts` (returns rank based on schema properties)
5. Export from `index.ts`
6. Register in `src/components/renderers/index.ts`

**Tester ranking:** Higher rank = higher priority. Use rank 4+ for specialized renderers that should override generic ones (rank 3).

### When Modifying Kernel Interception

All three interception points must be updated consistently. Check:
- Does kernel have config? `!!(kernelspec?.metadata?.kernel_provisioner as any)?.config`
- Show dialog before kernel starts (not after)
- Save to notebook metadata: `notebookPanel.context.model.setMetadata('kernel_params', configData)`
- Save to localStorage: `saveConfig(kernelTitle, configData)`

### CSS Styling

Uses JupyterLab CSS variables for theming:
- `--jp-input-background` - Input backgrounds
- `--jp-input-border-color` - Input borders
- `--jp-brand-color1` - Focus states
- `--jp-error-color1` - Error messages
- `--jp-ui-font-color0/1` - Text colors

All inputs use `width: calc(100% - 4px)` to prevent overflow from dialog body padding.

### Debugging

**Console log prefixes:**
- `[Plugin]` - Main plugin activation
- `[KernelSelector]` - Menu-based kernel selection
- `[Toolbar]` - Toolbar dropdown selection
- `[Launcher]` - Launcher tile selection
- `[Dialog]` - Dialog keyboard interactions
- `[TextAreaTester]` - Renderer tester activation

**Global debug function:**
```javascript
window.debugKernelSelector()  // Check if menu override is still active
```

### Kernel Spec Format

Expected kernel.json structure:
```json
{
  "display_name": "Python 3 with Parameters",
  "metadata": {
    "kernel_provisioner": {
      "config": {
        "title": "Kernel Parameters",
        "type": "object",
        "properties": {
          "field_name": {
            "title": "Field Label",
            "type": "string",
            "default": "value",
            "description": "Help text",
            "rows": 5,              // Makes it a textarea
            "validation": {
              "required": true
            }
          }
        }
      }
    }
  }
}
```

## Publishing

Automated via Rio CI/CD pipeline - do not publish manually. Version bumps are handled by the pipeline.
