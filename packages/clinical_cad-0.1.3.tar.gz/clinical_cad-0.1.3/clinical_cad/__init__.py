"""
Clinical Association Displacement (CAD) analysis with statistical normalization.
"""
from clinical_cad.cad import (
    main,
    parse_args,
    run_pipeline,
)

__all__ = ["main", "parse_args", "run_pipeline"]
