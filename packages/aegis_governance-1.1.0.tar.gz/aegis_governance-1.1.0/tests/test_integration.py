"""
Tests for src/integration/ module.

Tests cover:
- AFA Bridge
- pcw_decide interface
"""

import json

import pytest

from integration.afa_bridge import (
    AFABridge,
    DecisionOutcome,
    DecisionRequest,
    DecisionResponse,
    DecisionType,
)
from integration.pcw_decide import (
    PCWContext,
    PCWDecision,
    PCWPhase,
    PCWStatus,
    pcw_decide,
    quick_risk_check,
    require_human_approval,
)


class TestAFABridgeDatetimeTimezone:
    """Tests for timezone-aware datetime in AFA Bridge."""

    def test_requested_at_is_timezone_aware(self):
        """Test DecisionRequest.requested_at is timezone-aware (UTC)."""
        request = DecisionRequest(
            request_id="req-tz-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-1",
            context={"risk_delta": 0.5},
        )

        # Should have timezone info (not naive)
        assert request.requested_at.tzinfo is not None
        # Should be in UTC
        assert request.requested_at.utcoffset().total_seconds() == 0

    def test_responded_at_is_timezone_aware(self):
        """Test DecisionResponse.responded_at is timezone-aware (UTC)."""
        response = DecisionResponse(
            request_id="req-tz-2",
            outcome=DecisionOutcome.APPROVED,
            confidence=0.95,
            gates_evaluated=["risk"],
            gates_passed=["risk"],
            gates_failed=[],
            rationale="Test rationale",
            next_steps=["Continue"],
        )

        # Should have timezone info (not naive)
        assert response.responded_at.tzinfo is not None
        # Should be in UTC
        assert response.responded_at.utcoffset().total_seconds() == 0


class TestAFABridge:
    """Tests for AFABridge."""

    def test_init_basic(self):
        """Test basic initialization."""
        bridge = AFABridge()

        assert bridge.default_timeout_hours == 24
        assert len(bridge.pending_requests) == 0
        assert len(bridge.decision_history) == 0

    def test_request_decision_proposal(self, sample_proposal_data):
        """Test proposal decision request."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-1",
            context=sample_proposal_data,
        )

        response = bridge.request_decision(request)

        assert isinstance(response, DecisionResponse)
        assert response.request_id == "req-1"
        assert len(response.gates_evaluated) > 0
        assert response.decision_hash is not None

    def test_request_decision_proposal_delta_formats(self):
        """Risk/profit deltas should be applied to baselines."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-delta-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-1",
            context={
                "risk_baseline": 1.0,
                "risk_delta": 4.0,
                "profit_baseline": 1.0,
                "profit_delta": 4.0,
                "novelty_score": 0.9,
                "complexity_score": 0.6,
                "quality_score": 0.9,
                "quality_subscores": [0.9, 0.9, 0.9],
                "utility_lcb": 0.1,
            },
        )

        response = bridge.request_decision(request)

        assert response.outcome == DecisionOutcome.ESCALATED
        assert "risk" in response.gates_failed
        assert "profit" in response.gates_failed

    def test_request_decision_risk_check(self):
        """Test quick risk check request.

        Uses proper baseline/proposed format for Bayesian gate evaluation.
        With baseline=1.0 and proposed=1.5, delta_norm = 0.5, well below
        the 2.0 trigger threshold, so gate passes.
        """
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-2",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-1",
            context={"risk_baseline": 1.0, "risk_proposed": 1.5},
        )

        response = bridge.request_decision(request)

        assert response.outcome == DecisionOutcome.APPROVED
        assert "risk" in response.gates_evaluated

    def test_request_decision_authorization(self):
        """Test authorization request."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-3",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="agent-1",
            context={
                "required_authorizations": ["risk_lead", "security_lead"],
                "provided_authorizations": ["risk_lead", "security_lead"],
            },
        )

        response = bridge.request_decision(request)

        assert response.outcome == DecisionOutcome.APPROVED

    def test_request_decision_authorization_missing(self):
        """Test authorization request with missing auth."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-4",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="agent-1",
            context={
                "required_authorizations": ["risk_lead", "security_lead"],
                "provided_authorizations": ["risk_lead"],  # Missing security_lead
            },
        )

        response = bridge.request_decision(request)

        assert response.outcome == DecisionOutcome.PENDING
        assert "security_lead" in response.rationale

    def test_request_decision_execution(self):
        """Test execution permission request."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-5",
            decision_type=DecisionType.EXECUTION,
            agent_id="agent-1",
            context={
                "proposal_approved": True,
                "has_execution_plan": True,
            },
        )

        response = bridge.request_decision(request)

        assert response.outcome == DecisionOutcome.APPROVED

    def test_verify_decision(self):
        """Test decision verification."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-6",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-1",
            context={"risk_delta": 0.5},
        )

        response = bridge.request_decision(request)

        # Should verify with correct request
        assert bridge.verify_decision(response, request) is True

    def test_decision_history(self):
        """Test decision history tracking."""
        bridge = AFABridge()

        for i in range(3):
            request = DecisionRequest(
                request_id=f"req-{i}",
                decision_type=DecisionType.RISK_CHECK,
                agent_id="agent-1",
                context={"risk_delta": 0.5},
            )
            bridge.request_decision(request)

        history = bridge.get_decision_history(limit=2)
        assert len(history) == 2

    def test_decision_history_bounded_by_maxlen(self):
        """Test that decision_history is bounded to prevent memory leaks.

        The deque has maxlen=10000. When more decisions are made, old ones
        are automatically discarded.
        """
        from collections import deque

        bridge = AFABridge()

        # Verify it's a deque with maxlen
        assert isinstance(bridge.decision_history, deque)
        assert bridge.decision_history.maxlen == 10000

    def test_pending_requests_cleaned_on_success(self):
        """Test pending_requests is cleared after successful decision."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-cleanup-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-1",
            context={"risk_delta": 0.5},
        )

        # Before: no pending requests
        assert len(bridge.pending_requests) == 0

        # Make request
        bridge.request_decision(request)

        # After: still no pending requests (cleaned up)
        assert len(bridge.pending_requests) == 0


class TestPCWDecide:
    """Tests for pcw_decide interface."""

    def test_pcw_decide_all_pass(self):
        """Test pcw_decide with all gates passing.

        Note: confidence is the minimum across all gates. The quality gate
        returns confidence = quality_score when passed, so we use quality_score=0.95
        to ensure min_confidence >= 0.9.

        Since v3.11.0, utility_result must be provided or the utility gate fails
        (fail-closed behavior). We provide a valid utility_result.
        """
        from engine.utility import UtilityComponents, UtilityResult

        utility_result = UtilityResult(
            raw=1000.0,
            variance=100.0,
            lcb=500.0,  # Positive LCB passes utility gate
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="investment",
        )

        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Add caching",
            estimated_impact="medium",
            risk_baseline=1.0,
            risk_proposed=1.1,
            profit_baseline=1.0,
            profit_proposed=1.1,
            novelty_score=0.95,  # High novelty ensures G(N) >= 0.9
            complexity_score=0.6,
            quality_score=0.95,  # High quality ensures quality confidence >= 0.9
            quality_subscores=[0.95, 0.95, 0.95],
            utility_result=utility_result,  # Required for utility gate to pass
        )

        decision = pcw_decide(context)

        assert isinstance(decision, PCWDecision)
        assert decision.status == PCWStatus.PROCEED
        assert decision.gates_failed == 0
        assert decision.confidence >= 0.9  # min_confidence across all gates

    def test_pcw_decide_requires_human_approval(self):
        """Test explicit human approval flag pauses even when gates pass."""
        from engine.utility import UtilityComponents, UtilityResult

        utility_result = UtilityResult(
            raw=1000.0,
            variance=100.0,
            lcb=500.0,
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="investment",
        )

        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Add caching",
            estimated_impact="medium",
            risk_baseline=1.0,
            risk_proposed=1.1,
            profit_baseline=1.0,
            profit_proposed=1.1,
            novelty_score=0.95,
            complexity_score=0.6,
            quality_score=0.95,
            quality_subscores=[0.95, 0.95, 0.95],
            utility_result=utility_result,
            requires_human_approval=True,
        )

        decision = pcw_decide(context)

        assert decision.status == PCWStatus.PAUSE

    def test_pcw_decide_human_approval_pause_has_next_steps(self):
        """Test PAUSE for human approval includes actionable next_steps."""
        from engine.utility import UtilityComponents, UtilityResult

        utility_result = UtilityResult(
            raw=1000.0,
            variance=100.0,
            lcb=500.0,
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="investment",
        )

        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Needs approval",
            estimated_impact="medium",
            risk_baseline=1.0,
            risk_proposed=1.1,
            profit_baseline=1.0,
            profit_proposed=1.1,
            novelty_score=0.95,
            complexity_score=0.6,
            quality_score=0.95,
            quality_subscores=[0.95, 0.95, 0.95],
            utility_result=utility_result,
            requires_human_approval=True,
        )

        decision = pcw_decide(context)

        assert decision.status == PCWStatus.PAUSE
        assert len(decision.next_steps) > 0
        assert any(
            "human" in s.lower() or "approval" in s.lower() for s in decision.next_steps
        )

    def test_pcw_decide_complexity_fail(self):
        """Test pcw_decide with complexity floor failure."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            complexity_score=0.3,  # Below 0.5 floor
        )

        decision = pcw_decide(context)

        assert decision.status == PCWStatus.HALT
        assert "complexity" in decision.failing_gates
        assert decision.override_eligible is False

    def test_pcw_decide_risk_fail(self):
        """Test pcw_decide with risk gate failure."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Risky change",
            estimated_impact="high",
            risk_baseline=1.0,
            risk_proposed=5.0,  # 4x increase > 2x threshold
            complexity_score=0.6,
        )

        decision = pcw_decide(context)

        assert decision.status == PCWStatus.ESCALATE
        assert "risk" in decision.failing_gates
        assert decision.override_eligible is True
        assert "risk_lead" in decision.override_requires

    def test_pcw_decide_next_steps(self):
        """Test next steps generation."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            novelty_score=0.5,  # Below 0.8
            complexity_score=0.6,
            quality_score=0.6,  # Below 0.7
        )

        decision = pcw_decide(context)

        assert len(decision.next_steps) > 0
        assert any(
            "novelty" in step.lower() or "quality" in step.lower()
            for step in decision.next_steps
        )

    def test_pcw_decide_constraints(self):
        """Test constraints for complexity failure."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            complexity_score=0.4,  # Fails
        )

        decision = pcw_decide(context)

        assert len(decision.constraints) > 0
        assert "cannot be overridden" in decision.constraints[0]


class TestQuickRiskCheck:
    """Tests for quick_risk_check."""

    def test_quick_risk_check_safe(self):
        """Test quick check returns safe."""
        result = quick_risk_check(
            agent_id="agent-1",
            action_description="Minor update",
            risk_score=0.2,
            threshold=0.5,
        )

        assert result is True

    def test_quick_risk_check_unsafe(self):
        """Test quick check returns unsafe."""
        result = quick_risk_check(
            agent_id="agent-1",
            action_description="Major change",
            risk_score=0.7,
            threshold=0.5,
        )

        assert result is False


class TestRequireHumanApproval:
    """Tests for require_human_approval."""

    def test_high_impact_requires_approval(self):
        """Test high impact requires approval."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="high",
        )

        assert require_human_approval(context) is True

    def test_critical_impact_requires_approval(self):
        """Test critical impact requires approval."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="critical",
        )

        assert require_human_approval(context) is True

    def test_irreversible_requires_approval(self):
        """Test irreversible actions require approval."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            reversible=False,
        )

        assert require_human_approval(context) is True

    def test_explicit_flag_requires_approval(self):
        """Test explicit flag requires approval."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            requires_human_approval=True,
        )

        assert require_human_approval(context) is True

    def test_high_risk_delta_requires_approval(self):
        """Test high risk delta requires approval.

        Bayesian risk gate: With baseline=1.0 and proposed=4.0, delta_norm=3.0.
        The posterior probability P(Δ≥2|data) ≈ 0.81 >= 0.5, triggering
        human approval requirement.
        """
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            risk_baseline=1.0,
            risk_proposed=4.0,  # delta_norm=3.0, posterior ≈ 0.81 >= 0.5
        )

        assert require_human_approval(context) is True

    def test_low_impact_no_approval(self):
        """Test low impact doesn't require approval."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            reversible=True,
            requires_human_approval=False,
            risk_baseline=1.0,
            risk_proposed=1.1,
        )

        assert require_human_approval(context) is False


class TestAFABridgeAdvanced:
    """Advanced tests for AFABridge."""

    def test_decision_history_empty(self):
        """Test empty decision history."""
        bridge = AFABridge()

        history = bridge.get_decision_history(limit=10)
        assert len(history) == 0

    def test_multiple_decision_types(self):
        """Test multiple decision types in sequence."""
        bridge = AFABridge()

        # Risk check
        request1 = DecisionRequest(
            request_id="req-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-1",
            context={"risk_delta": 0.5},
        )
        bridge.request_decision(request1)

        # Authorization
        request2 = DecisionRequest(
            request_id="req-2",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="agent-1",
            context={
                "required_authorizations": ["risk_lead"],
                "provided_authorizations": ["risk_lead"],
            },
        )
        bridge.request_decision(request2)

        history = bridge.get_decision_history(limit=10)
        assert len(history) == 2


class TestPCWDecideAdvanced:
    """Advanced tests for pcw_decide."""

    def test_pcw_decide_multiple_failures(self):
        """Test pcw_decide with multiple gate failures."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Risky test",
            estimated_impact="high",
            risk_baseline=1.0,
            risk_proposed=5.0,  # Fails risk
            complexity_score=0.3,  # Fails complexity
            quality_score=0.5,  # Fails quality
        )

        decision = pcw_decide(context)

        assert decision.status == PCWStatus.HALT
        assert decision.gates_failed >= 2

    def test_missing_utility_fails_gate(self):
        """Test that missing utility_result fails utility gate (fail-closed).

        When utility_result is not provided, the default uses lcb=float('-inf')
        which should fail the utility gate. This is fail-closed behavior to
        prevent unexpected approvals when utility computation is missing.
        See multi-model-coherence-review.md (I1).
        """
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test without utility",
            estimated_impact="low",
            risk_baseline=1.0,
            risk_proposed=1.1,  # Would pass risk
            complexity_score=0.6,  # Would pass complexity
            quality_score=0.8,  # Would pass quality
            novelty_score=0.9,  # Would pass novelty
            utility_result=None,  # Missing utility
        )

        decision = pcw_decide(context)

        # Utility gate should fail due to lcb=-inf
        assert "utility" in decision.failing_gates
        assert decision.status != PCWStatus.PROCEED

    def test_provided_utility_can_pass(self):
        """Test that provided utility_result can pass utility gate."""
        from engine.utility import UtilityComponents, UtilityResult

        utility_result = UtilityResult(
            raw=1000.0,
            variance=100.0,
            lcb=500.0,  # Positive LCB should pass
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="investment",
        )

        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test with utility",
            estimated_impact="low",
            risk_baseline=1.0,
            risk_proposed=1.1,
            complexity_score=0.6,
            quality_score=0.8,
            novelty_score=0.9,
            quality_subscores=[0.8, 0.9, 0.85],
            utility_result=utility_result,
        )

        decision = pcw_decide(context)

        # Utility gate should pass with positive LCB
        assert "utility" not in decision.failing_gates

    def test_pcw_decide_malformed_context_returns_halt(self):
        """Test pcw_decide handles malformed context gracefully (M-ENG-005 fix).

        When a context object has missing or malformed attributes, pcw_decide
        should catch AttributeError and return HALT status instead of crashing.
        """

        # Create a mock malformed context that's missing some attributes
        class MalformedContext:
            agent_id = "agent-1"
            session_id = "session-1"
            phase = PCWPhase.PLAN
            proposal_summary = "Test"
            estimated_impact = "low"
            # Missing risk_baseline, risk_proposed, etc.

        malformed = MalformedContext()

        decision = pcw_decide(malformed)  # type: ignore[arg-type]

        # Should return HALT with evaluation_error
        assert decision.status == PCWStatus.HALT
        assert "evaluation_error" in decision.failing_gates
        assert "failed" in decision.rationale.lower()


class TestDecisionTrace:
    """Tests for DecisionTrace dataclass and _build_decision_trace function."""

    def test_decision_trace_attached(self):
        """Test that DecisionTrace is attached to PCWDecision."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Add caching",
            estimated_impact="medium",
        )

        decision = pcw_decide(context)

        assert decision.decision_trace is not None
        assert decision.decision_trace.decision_id == decision.decision_id
        assert decision.decision_trace.timestamp == decision.timestamp

    def test_decision_trace_context_snapshot(self):
        """Test context_snapshot contains expected fields."""
        context = PCWContext(
            agent_id="agent-123",
            session_id="session-456",
            phase=PCWPhase.COMMIT,
            proposal_summary="Deploy new feature",
            estimated_impact="high",
            requires_human_approval=True,
            time_sensitive=True,
            reversible=False,
            metadata={"source": "test", "priority": "urgent"},
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        ctx = trace.context_snapshot
        assert ctx["agent_id"] == "agent-123"
        assert ctx["session_id"] == "session-456"
        assert ctx["phase"] == "commit"
        assert ctx["estimated_impact"] == "high"
        assert ctx["requires_human_approval"] is True
        assert ctx["time_sensitive"] is True
        assert ctx["reversible"] is False
        assert set(ctx["metadata_keys"]) == {"source", "priority"}
        # Proposal summary should be hashed, not stored raw
        assert "proposal_summary_sha256" in ctx
        assert len(ctx["proposal_summary_sha256"]) == 64  # SHA-256 hex length
        assert ctx["proposal_summary_length"] == len("Deploy new feature")

    def test_decision_trace_metric_snapshot(self):
        """Test metric_snapshot contains all input metrics."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            risk_baseline=1.0,
            risk_proposed=1.5,
            profit_baseline=100.0,
            profit_proposed=150.0,
            novelty_score=0.75,
            complexity_score=0.6,
            quality_score=0.85,
            quality_subscores=[0.8, 0.9, 0.85],
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        metrics = trace.metric_snapshot
        assert metrics["risk_baseline"] == 1.0
        assert metrics["risk_proposed"] == 1.5
        assert metrics["profit_baseline"] == 100.0
        assert metrics["profit_proposed"] == 150.0
        assert metrics["novelty_score"] == 0.75
        assert metrics["complexity_score"] == 0.6
        assert metrics["quality_score"] == 0.85
        assert metrics["quality_subscores"] == [0.8, 0.9, 0.85]

    def test_decision_trace_gate_summaries(self):
        """Test gate_summaries contains all 6 gates."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        # Should have 6 gates: risk, profit, novelty, complexity, quality, utility
        assert len(trace.gate_summaries) == 6

        gate_names = {g["gate"] for g in trace.gate_summaries}
        expected_gates = {
            "risk",
            "profit",
            "novelty",
            "complexity",
            "quality",
            "utility",
        }
        assert gate_names == expected_gates

        # Each gate summary should have required fields
        for gate in trace.gate_summaries:
            assert "gate" in gate
            assert "passed" in gate
            assert "value" in gate
            assert "threshold" in gate
            assert "margin" in gate
            assert "confidence" in gate
            assert "posterior_probability" in gate
            assert "message" in gate

    def test_decision_trace_decision_summary(self):
        """Test decision_summary contains aggregate information."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            complexity_score=0.6,  # Pass complexity
            quality_score=0.8,  # Pass quality
            novelty_score=0.9,  # Pass novelty
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        summary = trace.decision_summary
        assert "all_passed" in summary
        assert "override_eligible" in summary
        assert "min_confidence" in summary
        assert "gates_passed" in summary
        assert "gates_failed" in summary

        # Should match PCWDecision values
        assert summary["gates_passed"] == decision.gates_passed
        assert summary["gates_failed"] == decision.gates_failed

    def test_decision_trace_with_utility_result(self):
        """Test metric_snapshot includes utility_result when provided."""
        from engine.utility import UtilityComponents, UtilityResult

        utility_result = UtilityResult(
            raw=1500.0,
            variance=100.0,
            lcb=1200.0,
            components=UtilityComponents(
                profit_high_conf=2000.0,
                value_low_conf=500.0,
                risk_adjustment=-300.0,
                complexity_tax=-200.0,
                opex_delta=-500.0,
            ),
            decision_path="investment",
        )

        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            utility_result=utility_result,
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        util_snapshot = trace.metric_snapshot["utility_result"]
        assert util_snapshot is not None
        assert util_snapshot["raw"] == 1500.0
        assert util_snapshot["variance"] == 100.0
        assert util_snapshot["lcb"] == 1200.0
        assert util_snapshot["decision_path"] == "investment"

        components = util_snapshot["components"]
        assert components["profit_high_conf"] == 2000.0
        assert components["value_low_conf"] == 500.0
        assert components["risk_adjustment"] == -300.0
        assert components["complexity_tax"] == -200.0
        assert components["opex_delta"] == -500.0

    def test_decision_trace_without_utility_result(self):
        """Test metric_snapshot captures defaulted utility_result used for evaluation."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            utility_result=None,  # Explicitly None
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        util_snapshot = trace.metric_snapshot["utility_result"]
        assert util_snapshot is not None
        assert util_snapshot["raw"] == 0.0
        assert util_snapshot["variance"] == 0.01
        assert util_snapshot["decision_path"] == "INVESTMENT"
        assert util_snapshot["lcb"] == float("-inf")

    def test_decision_trace_hash_determinism(self):
        """Test that proposal summary hash is deterministic."""
        from integration.pcw_decide import _hash_summary

        summary = "This is a test proposal summary"

        hash1 = _hash_summary(summary)
        hash2 = _hash_summary(summary)

        assert hash1 == hash2
        assert len(hash1) == 64  # SHA-256 produces 64 hex chars

        # Different summaries produce different hashes
        hash3 = _hash_summary("Different summary")
        assert hash1 != hash3

    def test_decision_trace_hash_unicode(self):
        """Test hash handles unicode characters."""
        from integration.pcw_decide import _hash_summary

        unicode_summary = "Proposal with unicode: café, naïve, 日本語"
        hash_result = _hash_summary(unicode_summary)

        assert len(hash_result) == 64
        # Same input produces same output
        assert hash_result == _hash_summary(unicode_summary)

    def test_decision_trace_empty_metadata(self):
        """Test context_snapshot handles empty metadata."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            metadata={},  # Empty dict
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        assert trace.context_snapshot["metadata_keys"] == []

    def test_decision_trace_non_mapping_metadata_does_not_crash(self):
        """Malformed metadata should not crash decision trace generation."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test",
            estimated_impact="low",
            metadata=["not", "a", "mapping"],  # type: ignore[arg-type]
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None
        assert trace.context_snapshot["metadata_keys"] == []

    def test_decision_trace_non_string_summary_does_not_crash(self):
        """Non-string proposal_summary should be normalized for hashing/length."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary=None,  # type: ignore[arg-type]
            estimated_impact="low",
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None
        assert trace.context_snapshot["proposal_summary_length"] == 0
        assert len(trace.context_snapshot["proposal_summary_sha256"]) == 64

    def test_decision_trace_extreme_values(self):
        """Test trace handles extreme metric values."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Extreme test",
            estimated_impact="low",
            risk_baseline=0.0,
            risk_proposed=1000000.0,  # Extreme risk
            profit_baseline=0.0,
            profit_proposed=0.0,
            novelty_score=0.0,  # Minimum novelty
            complexity_score=1.0,  # Maximum complexity
            quality_score=0.0,  # Minimum quality
            quality_subscores=[0.0, 0.0, 0.0],
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        # Values should be captured even when extreme
        assert trace.metric_snapshot["risk_proposed"] == 1000000.0
        assert trace.metric_snapshot["novelty_score"] == 0.0
        assert trace.metric_snapshot["complexity_score"] == 1.0

    def test_decision_trace_all_gates_pass(self):
        """Test trace correctly captures all gates passing.

        Since v3.11.0, utility_result must be provided or the utility gate fails
        (fail-closed behavior). We provide a valid utility_result.
        """
        from engine.utility import UtilityComponents, UtilityResult

        utility_result = UtilityResult(
            raw=1000.0,
            variance=100.0,
            lcb=500.0,  # Positive LCB passes utility gate
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="investment",
        )

        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Good proposal",
            estimated_impact="low",
            risk_baseline=1.0,
            risk_proposed=1.1,  # Minimal risk increase
            profit_baseline=100.0,
            profit_proposed=150.0,  # 50% increase (< 2x)
            novelty_score=0.95,  # High novelty
            complexity_score=0.6,  # Above 0.5 floor
            quality_score=0.9,  # Above 0.7 threshold
            quality_subscores=[0.9, 0.9, 0.9],
            utility_result=utility_result,  # Required for utility gate to pass
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        assert trace.decision_summary["all_passed"] is True
        all_passed = all(g["passed"] for g in trace.gate_summaries)
        assert all_passed is True

    def test_decision_trace_margin_calculation(self):
        """Test that gate margins are correctly captured."""
        context = PCWContext(
            agent_id="agent-1",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Test margins",
            estimated_impact="low",
            complexity_score=0.7,  # 0.2 margin above 0.5 threshold
        )

        decision = pcw_decide(context)
        trace = decision.decision_trace
        assert trace is not None

        # Find complexity gate in summaries
        complexity_gate = next(
            g for g in trace.gate_summaries if g["gate"] == "complexity"
        )
        assert complexity_gate["passed"] is True
        assert complexity_gate["value"] == 0.7
        assert complexity_gate["threshold"] == 0.5
        # Margin should be value - threshold = 0.2
        assert abs(complexity_gate["margin"] - 0.2) < 0.01


class TestAFABridgeAgentIdFilter:
    """Tests for get_decision_history agent_id filter (M3 fix)."""

    def test_get_decision_history_filters_by_agent(self):
        """Test that get_decision_history correctly filters by agent_id.

        M3 fix: agent_id filter was ignored (pass statement).
        Now properly filters by DecisionResponse.agent_id field.
        """
        bridge = AFABridge()

        # Create decisions from different agents
        for i, agent in enumerate(["agent-A", "agent-B", "agent-A", "agent-C"]):
            request = DecisionRequest(
                request_id=f"req-filter-{i}",
                decision_type=DecisionType.RISK_CHECK,
                agent_id=agent,
                context={"risk_delta": 0.5},
            )
            bridge.request_decision(request)

        # Filter by agent-A (should return 2 decisions)
        history_a = bridge.get_decision_history(agent_id="agent-A")
        assert len(history_a) == 2
        assert all(r.agent_id == "agent-A" for r in history_a)

        # Filter by agent-B (should return 1 decision)
        history_b = bridge.get_decision_history(agent_id="agent-B")
        assert len(history_b) == 1
        assert history_b[0].agent_id == "agent-B"

        # No filter (should return all 4)
        history_all = bridge.get_decision_history()
        assert len(history_all) == 4

    def test_get_decision_history_nonexistent_agent(self):
        """Test that filtering by nonexistent agent returns empty list."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-real",
            context={"risk_delta": 0.5},
        )
        bridge.request_decision(request)

        history = bridge.get_decision_history(agent_id="agent-nonexistent")
        assert len(history) == 0

    def test_decision_response_has_agent_id(self):
        """Test that DecisionResponse captures agent_id from request."""
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-agent-id",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="test-agent-123",
            context={"risk_delta": 0.5},
        )
        response = bridge.request_decision(request)

        # Response should have agent_id populated
        assert response.agent_id == "test-agent-123"

    def test_get_decision_history_limit_validation(self):
        """Test that get_decision_history rejects non-positive limit (L53 fix)."""
        bridge = AFABridge()

        with pytest.raises(ValueError, match=r"limit must be positive"):
            bridge.get_decision_history(limit=0)

        with pytest.raises(ValueError, match=r"limit must be positive"):
            bridge.get_decision_history(limit=-5)


class TestBH27HistoryLimitBoolGuard:
    """BH27-L5: get_decision_history must reject bool limit (bool-is-int)."""

    def test_limit_true_raises_type_error(self):
        """limit=True must raise TypeError, not silently act as limit=1."""
        bridge = AFABridge()
        with pytest.raises(TypeError, match="limit must be an integer"):
            bridge.get_decision_history(limit=True)  # type: ignore[arg-type]

    def test_limit_false_raises_type_error(self):
        """limit=False must raise TypeError, not ValueError."""
        bridge = AFABridge()
        with pytest.raises(TypeError, match="limit must be an integer"):
            bridge.get_decision_history(limit=False)  # type: ignore[arg-type]

    def test_limit_float_raises_type_error(self):
        """limit=1.5 must raise TypeError instead of crashing during slicing."""
        bridge = AFABridge()
        with pytest.raises(TypeError, match="limit must be an integer"):
            bridge.get_decision_history(limit=1.5)  # type: ignore[arg-type]


class TestAFABridgeFailClosed:
    """Tests for AFABridge fail-closed behavior (bug-hunt regression tests)."""

    def test_afa_bridge_missing_utility_fails_closed(self):
        """Test AFABridge fails utility gate when utility is missing.

        BUG FIX: Previously afa_bridge.py defaulted utility_lcb to 0.1 which
        would PASS the utility gate. This was inconsistent with pcw_decide.py
        which correctly uses float('-inf') for fail-closed behavior.

        Now both use float('-inf') to ensure proposals are rejected when
        utility computation is missing.
        """
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-failclosed-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.1,  # Would pass risk
                "novelty_score": 0.9,  # Would pass novelty
                "complexity_score": 0.6,  # Would pass complexity
                "quality_score": 0.8,  # Would pass quality
                "quality_subscores": [0.8, 0.8, 0.8],
                # utility_result intentionally omitted
            },
        )

        response = bridge.request_decision(request)

        # Utility gate should fail due to default lcb=float('-inf')
        assert "utility" in response.gates_failed
        assert response.outcome != DecisionOutcome.APPROVED

    def test_afa_bridge_explicit_utility_passes(self):
        """Test AFABridge passes utility gate when utility is provided."""
        from engine.utility import UtilityComponents, UtilityResult

        bridge = AFABridge()

        utility_result = UtilityResult(
            raw=1000.0,
            variance=100.0,
            lcb=500.0,  # Positive LCB should pass
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="investment",
        )

        request = DecisionRequest(
            request_id="req-utility-2",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.1,
                "novelty_score": 0.9,
                "complexity_score": 0.6,
                "quality_score": 0.8,
                "quality_subscores": [0.8, 0.8, 0.8],
                "utility_result": utility_result,
            },
        )

        response = bridge.request_decision(request)

        # Utility gate should pass with positive LCB
        assert "utility" not in response.gates_failed

    def test_afa_bridge_uses_public_risk_gate_api(self):
        """Test AFABridge uses public evaluate_risk_gate() API.

        BUG FIX: Previously _evaluate_risk_check used private method
        gate_evaluator._evaluate_risk_gate(). Now uses public
        gate_evaluator.evaluate_risk_gate() for proper API abstraction.
        """
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-api-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.5,  # Should pass with low delta
            },
        )

        # Should work correctly using public API
        response = bridge.request_decision(request)

        assert response.outcome == DecisionOutcome.APPROVED
        assert "risk" in response.gates_passed


class TestAFABridgeConfidenceFallback:
    """Regression tests for confidence fallback using 'or' vs 'is not None'."""

    def test_zero_confidence_preserved(self):
        """Test that confidence=0.0 is preserved, not replaced by fallback.

        BUG FIX: Previously used `risk_gate.confidence or (1.0 - posterior)`
        which treated 0.0 as falsy. Now uses explicit None check.
        """
        bridge = AFABridge()

        # Use a risk scenario that will pass (low delta)
        request = DecisionRequest(
            request_id="req-conf-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-conf",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.01,
            },
        )

        response = bridge.request_decision(request)
        # The key assertion: confidence should be a real value, not 0.0 treated as None
        assert response.outcome == DecisionOutcome.APPROVED
        assert response.confidence is not None


class TestAFABridgeTimeoutValidation:
    """Regression tests for AFABridge default_timeout_hours validation."""

    def test_bool_timeout_raises(self):
        """Bool timeout must be rejected (bool is not a valid numeric timeout)."""
        with pytest.raises(TypeError, match=r"default_timeout_hours must be numeric"):
            AFABridge(default_timeout_hours=True)

    def test_negative_timeout_raises(self):
        """Test that negative default_timeout_hours raises ValueError."""
        with pytest.raises(ValueError, match="must be positive"):
            AFABridge(default_timeout_hours=-1)

    def test_zero_timeout_raises(self):
        """Test that zero default_timeout_hours raises ValueError."""
        with pytest.raises(ValueError, match="must be positive"):
            AFABridge(default_timeout_hours=0)

    def test_positive_timeout_accepted(self):
        """Test that positive timeout is accepted."""
        bridge = AFABridge(default_timeout_hours=48)
        assert bridge.default_timeout_hours == 48

    def test_nan_timeout_raises(self):
        """BH12-L2 regression: NaN default_timeout_hours must raise ValueError."""
        with pytest.raises(ValueError, match="must be a finite number"):
            AFABridge(default_timeout_hours=float("nan"))

    def test_inf_timeout_raises(self):
        """BH12-L2 regression: Inf default_timeout_hours must raise ValueError."""
        with pytest.raises(ValueError, match="must be a finite number"):
            AFABridge(default_timeout_hours=float("inf"))

    def test_neg_inf_timeout_raises(self):
        """BH12-L2 regression: -Inf default_timeout_hours must raise ValueError."""
        with pytest.raises(ValueError, match="must be a finite number"):
            AFABridge(default_timeout_hours=float("-inf"))


class TestDecisionReprMethods:
    """Regression tests for DecisionRequest and DecisionResponse __repr__."""

    def test_decision_request_repr(self):
        """Test DecisionRequest repr shows key fields."""
        req = DecisionRequest(
            request_id="req-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-alpha",
            context={},
        )
        r = repr(req)
        assert "req-1" in r
        assert "proposal" in r
        assert "agent-alpha" in r

    def test_decision_response_repr(self):
        """Test DecisionResponse repr shows key fields."""
        resp = DecisionResponse(
            request_id="req-1",
            outcome=DecisionOutcome.APPROVED,
            confidence=0.95,
            gates_evaluated=["risk"],
            gates_passed=["risk"],
            gates_failed=[],
            rationale="All passed",
            next_steps=["Proceed"],
        )
        r = repr(resp)
        assert "req-1" in r
        assert "approved" in r
        assert "0.950" in r


class TestDecisionHashConfidence:
    """Tests for B2-12: confidence field in decision hash."""

    def test_decision_hash_includes_confidence(self):
        """Test that decision hash includes confidence field.

        B2-12: Previously hash only included request_id, agent_id, outcome,
        gates_passed, gates_failed, and timestamp. Now includes confidence
        for tamper detection.
        """
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-hash-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-test",
            context={"risk_baseline": 1.0, "risk_proposed": 1.2},
        )

        response = bridge.request_decision(request)

        # Hash should be computed
        assert response.decision_hash is not None
        assert len(response.decision_hash) == 64  # SHA-256 hex length

        # Verify hash includes confidence by checking that changing
        # confidence would change the hash
        original_hash = response.decision_hash
        original_confidence = response.confidence

        # Create a modified response with different confidence
        modified_response = DecisionResponse(
            request_id=response.request_id,
            outcome=response.outcome,
            confidence=original_confidence + 0.1,  # Different confidence
            gates_evaluated=response.gates_evaluated,
            gates_passed=response.gates_passed,
            gates_failed=response.gates_failed,
            rationale=response.rationale,
            next_steps=response.next_steps,
            responded_at=response.responded_at,  # Same timestamp
        )

        # Compute hash for modified response
        modified_hash = bridge._compute_decision_hash(request, modified_response)

        # Hashes should differ because confidence differs
        assert modified_hash != original_hash

    def test_verify_decision_fails_when_confidence_tampered(self):
        """Test that tampering with confidence fails verification.

        B2-12: The verify_decision method should detect confidence tampering.
        """
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-tamper-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-test",
            context={"risk_baseline": 1.0, "risk_proposed": 1.2},
        )

        response = bridge.request_decision(request)

        # Verify original passes
        assert bridge.verify_decision(response, request) is True

        # Tamper with confidence
        tampered_response = DecisionResponse(
            request_id=response.request_id,
            outcome=response.outcome,
            confidence=response.confidence + 0.5,  # Tampered confidence
            gates_evaluated=response.gates_evaluated,
            gates_passed=response.gates_passed,
            gates_failed=response.gates_failed,
            rationale=response.rationale,
            next_steps=response.next_steps,
            decision_hash=response.decision_hash,  # Original hash
            responded_at=response.responded_at,
        )

        # Verification should fail because hash doesn't match tampered confidence
        assert bridge.verify_decision(tampered_response, request) is False

    def test_decision_hash_confidence_precision(self):
        """Test that confidence floating-point precision is handled correctly.

        Ensures hash is deterministic for same confidence value.
        """
        bridge = AFABridge()

        request = DecisionRequest(
            request_id="req-precision-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-test",
            context={"risk_baseline": 1.0, "risk_proposed": 1.2},
        )

        # Make same request twice
        response1 = bridge.request_decision(request)

        # Create second request with same parameters
        request2 = DecisionRequest(
            request_id="req-precision-1",  # Same request_id
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-test",
            context={"risk_baseline": 1.0, "risk_proposed": 1.2},
        )
        response2 = bridge.request_decision(request2)

        # If timestamps happen to match (unlikely), hashes should be identical
        # More importantly, same confidence value should serialize consistently
        # This tests that JSON serialization of floats is deterministic
        assert isinstance(response1.confidence, float)
        assert isinstance(response2.confidence, float)


class TestGateRemediationCompleteness:
    """Regression: _GATE_REMEDIATION must cover all gate types."""

    def test_all_gate_types_have_remediation(self):
        """Every gate type evaluated by pcw_decide must have a remediation entry."""
        from integration.pcw_decide import _GATE_REMEDIATION

        expected_gates = {
            "risk",
            "profit",
            "novelty",
            "complexity",
            "quality",
            "utility",
        }
        assert set(_GATE_REMEDIATION.keys()) == expected_gates


class TestAFABridgeExceptionGuard:
    """Regression U-1: AFABridge must return ERROR on invalid context data."""

    def test_evaluate_proposal_invalid_novelty_returns_error(self):
        """Invalid novelty_score (out of range) should return ERROR, not raise."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-err-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-bad",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": "not_a_number",  # TypeError
                "complexity_score": 0.7,
                "quality_score": 0.8,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR
        assert response.confidence == 0.0
        assert "evaluation_error" in response.gates_failed
        assert "failed" in response.rationale.lower()

    def test_evaluate_proposal_none_quality_returns_error(self):
        """None quality_score triggering TypeError should return ERROR."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-err-2",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-bad",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.7,
                "quality_score": None,  # Null-coalesced to 0.7 (BH16 fix)
            },
        )
        response = bridge.request_decision(request)
        # After BH16 fix: None values are null-coalesced to defaults,
        # so the request succeeds instead of crashing with TypeError
        assert response.outcome != DecisionOutcome.ERROR

    def test_evaluate_risk_check_invalid_baseline_returns_error(self):
        """Non-numeric risk baseline should return ERROR, not raise."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-err-3",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-bad",
            context={
                "risk_baseline": "invalid",  # TypeError
                "risk_proposed": 1.5,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR
        assert response.confidence == 0.0
        assert "evaluation_error" in response.gates_failed
        assert "failed" in response.rationale.lower()

    def test_risk_check_null_baseline_uses_default(self):
        """BH17-M1: explicit None baseline must use default 0.0, not crash."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-bh17-1",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-null",
            context={
                "risk_baseline": None,
                "risk_proposed": 0.5,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome != DecisionOutcome.ERROR

    def test_risk_check_nan_baseline_returns_error(self):
        """BH17-M1: NaN baseline must be rejected via _coalesce_float."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-bh17-2",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-nan",
            context={
                "risk_baseline": float("nan"),
                "risk_proposed": 0.5,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_risk_check_inf_delta_returns_error(self):
        """BH17-M1: Inf risk_delta must be rejected via _coalesce_float."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-bh17-3",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-inf",
            context={
                "risk_baseline": 0.1,
                "risk_delta": float("inf"),
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_risk_check_null_delta_uses_default(self):
        """BH17-M1: explicit None risk_delta must use default 0.0."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-bh17-4",
            decision_type=DecisionType.RISK_CHECK,
            agent_id="agent-null-delta",
            context={
                "risk_baseline": 0.1,
                "risk_delta": None,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome != DecisionOutcome.ERROR

    def test_evaluate_proposal_valid_still_works(self):
        """Sanity: valid proposal context still returns non-ERROR outcome."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="req-ok-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-good",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.1,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.9,
                "complexity_score": 0.7,
                "quality_score": 0.85,
                "quality_subscores": [0.9, 0.8],
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome != DecisionOutcome.ERROR


# ============================================================================
# Ultrathink Bug-Hunt #5 Regression Tests
# ============================================================================


class TestPCWDecidePosteriorProbabilityCheck:
    """Regression: pcw_decide.py truthy check on posterior_probability."""

    def test_zero_posterior_not_skipped(self):
        """posterior_probability=0.0 should not be skipped by truthy check."""
        from engine.gates import GateResult, GateType

        # A gate result with posterior_probability = 0.0 (falsy but valid)
        result = GateResult(
            gate_type=GateType.RISK,
            passed=True,
            value=0.0,
            threshold=0.95,
            confidence=0.9,
            message="Test",
            posterior_probability=0.0,
        )
        # 0.0 is not >= 0.5, so this should not trigger override
        assert result.posterior_probability is not None
        assert result.posterior_probability == 0.0
        assert not (result.posterior_probability >= 0.5)


class TestAfaBridgeAuthorizationExceptionGuard:
    """Regression: afa_bridge.py _evaluate_authorization exception guard."""

    def test_authorization_with_invalid_context(self):
        """Authorization eval should return ERROR on bad context types."""
        from integration.afa_bridge import AFABridge, DecisionRequest, DecisionType

        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-auth-error",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="test-agent",
            context={
                "required_authorizations": "not_a_list",  # should be list
                "provided_authorizations": [],
            },
        )
        response = bridge.request_decision(request)
        # Should not crash — either handles gracefully or outer try catches it
        assert response is not None


class TestBH16AFABridgeNullContext:
    """BH16-M3: AFABridge must handle None context values without crashing."""

    def test_evaluate_proposal_null_risk_baseline(self):
        """risk_baseline=None must default to 0.0, not crash."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-null-risk",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test-agent",
            context={
                "risk_baseline": None,
                "proposal_summary": "test null values",
                "estimated_impact": "low",
            },
        )
        response = bridge.request_decision(request)
        assert response is not None
        assert response.outcome != DecisionOutcome.ERROR

    def test_evaluate_proposal_null_profit_baseline(self):
        """profit_baseline=None must default to 0.0, not crash."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-null-profit",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test-agent",
            context={
                "profit_baseline": None,
                "proposal_summary": "test null profit",
                "estimated_impact": "low",
            },
        )
        response = bridge.request_decision(request)
        assert response is not None
        assert response.outcome != DecisionOutcome.ERROR

    def test_evaluate_proposal_null_risk_delta(self):
        """risk_delta=None must default to 0.0, not crash."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-null-delta",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test-agent",
            context={
                "risk_delta": None,
                "proposal_summary": "test null delta",
                "estimated_impact": "low",
            },
        )
        response = bridge.request_decision(request)
        assert response is not None
        assert response.outcome != DecisionOutcome.ERROR

    def test_evaluate_proposal_all_null_metrics(self):
        """All-null context metrics must use defaults, not crash."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-all-null",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test-agent",
            context={
                "risk_baseline": None,
                "risk_proposed": None,
                "profit_baseline": None,
                "profit_proposed": None,
                "novelty_score": None,
                "complexity_score": None,
                "quality_score": None,
                "quality_subscores": None,
                "proposal_summary": "test all null",
                "estimated_impact": "low",
            },
        )
        response = bridge.request_decision(request)
        assert response is not None
        assert response.outcome != DecisionOutcome.ERROR


class TestBH16AFABridgeAuthOrdering:
    """BH16-L3: Authorization missing set must have deterministic ordering."""

    def test_authorization_missing_rationale_is_sorted(self):
        """Missing authorizations in rationale must be sorted."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-auth-order",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="test-agent",
            context={
                "required_authorizations": ["zulu", "alpha", "mike"],
                "provided_authorizations": [],
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.PENDING
        # Rationale must list authorizations in sorted order
        assert "alpha, mike, zulu" in response.rationale

    def test_authorization_missing_next_steps_sorted(self):
        """Missing authorizations in next_steps must be sorted."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-auth-steps",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="test-agent",
            context={
                "required_authorizations": ["charlie", "alpha"],
                "provided_authorizations": [],
            },
        )
        response = bridge.request_decision(request)
        assert response.next_steps[0] == "Obtain alpha authorization"
        assert response.next_steps[1] == "Obtain charlie authorization"


class TestQG62CoalesceFloatIsfinite:
    """QG62: _coalesce_float must reject NaN/Inf (transport parity)."""

    def test_coalesce_nan_string_raises(self):
        """'NaN' string should raise ValueError, not silently become NaN."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="qg62-nan",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={"risk_baseline": "NaN"},
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_coalesce_inf_raises(self):
        """float('inf') should raise ValueError."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="qg62-inf",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={"risk_baseline": float("inf")},
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_coalesce_negative_inf_raises(self):
        """float('-inf') should raise ValueError."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="qg62-neginf",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={"profit_baseline": float("-inf")},
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_nan_risk_proposed_raises_error(self):
        """NaN risk_proposed should return ERROR (isfinite guard)."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="qg62-nan-proposed",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={"risk_proposed": float("nan")},
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_inf_profit_proposed_raises_error(self):
        """Inf profit_proposed should return ERROR (isfinite guard)."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="qg62-inf-proposed",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={"profit_proposed": float("inf")},
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_risk_proposed_string_converted(self):
        """String risk_proposed should be converted to float."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="qg62-str",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": "1.5",
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.9,
                "complexity_score": 0.7,
                "quality_score": 0.85,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome != DecisionOutcome.ERROR


class TestBH19CoalesceFloatBoolGuard:
    """BH19-L1: _coalesce_float must reject boolean values (bool-is-int)."""

    def test_coalesce_bool_true_raises(self):
        """True should not silently become 1.0."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-bool-true",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={"risk_baseline": True},
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_coalesce_bool_false_raises(self):
        """False should not silently become 0.0."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-bool-false",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test",
            context={"profit_proposed": False},
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR


class TestBH19ExecutionBoolValidation:
    """BH19-M2: _evaluate_execution must reject non-boolean context values."""

    def test_string_false_is_truthy(self):
        """String 'false' is truthy in Python — must be rejected."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-exec-str-false",
            decision_type=DecisionType.EXECUTION,
            agent_id="test",
            context={
                "proposal_approved": "false",
                "has_execution_plan": True,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR
        assert "boolean" in response.rationale.lower()

    def test_int_one_is_truthy(self):
        """Integer 1 should not be treated as True."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-exec-int",
            decision_type=DecisionType.EXECUTION,
            agent_id="test",
            context={
                "proposal_approved": 1,
                "has_execution_plan": True,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_valid_booleans_still_work(self):
        """Actual booleans should still be processed correctly."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-exec-valid",
            decision_type=DecisionType.EXECUTION,
            agent_id="test",
            context={
                "proposal_approved": True,
                "has_execution_plan": True,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.APPROVED

    def test_false_booleans_reject(self):
        """False booleans should be processed, not error."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-exec-false",
            decision_type=DecisionType.EXECUTION,
            agent_id="test",
            context={
                "proposal_approved": False,
                "has_execution_plan": True,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome != DecisionOutcome.ERROR
        assert response.outcome != DecisionOutcome.APPROVED


class TestBH19AuthorizationNullGuard:
    """BH19-L2: _evaluate_authorization must handle None values from JSON null."""

    def test_null_required_authorizations(self):
        """None required_authorizations should not crash with set(None)."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-auth-null-req",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="test",
            context={
                "required_authorizations": None,
                "provided_authorizations": ["admin"],
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.APPROVED

    def test_null_provided_authorizations(self):
        """None provided_authorizations should not crash."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-auth-null-prov",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="test",
            context={
                "required_authorizations": ["admin"],
                "provided_authorizations": None,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.PENDING

    def test_both_null_authorizations(self):
        """Both None should result in APPROVED (no requirements)."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh19-auth-both-null",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="test",
            context={
                "required_authorizations": None,
                "provided_authorizations": None,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.APPROVED


class TestBH42AuthorizationFalsyFailOpen:
    """BH42-M1: falsy non-list auth fields must not silently pass as []."""

    def test_required_authorizations_zero_returns_error(self):
        """required_authorizations=0 must fail closed, not auto-approve."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh42-auth-zero",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="test",
            context={
                "required_authorizations": 0,
                "provided_authorizations": [],
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR
        assert "evaluation_error" in response.gates_failed


class TestBH20TransportBoolGuardParity:
    """BH20-L2: Lambda/MCP/CLI float helpers must reject bool inputs."""

    def test_lambda_float_rejects_bool_risk_baseline(self):
        """Lambda _float helper must reject bool for numeric fields."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "body": json.dumps(
                {
                    "proposal_summary": "test",
                    "estimated_impact": "low",
                    "risk_baseline": True,
                }
            ),
        }
        response = handler(event, None)
        assert response["statusCode"] == 400
        body = json.loads(response["body"])
        assert "bool" in body["error"].lower() or "numeric" in body["error"].lower()

    def test_lambda_risk_check_rejects_bool_risk_score(self):
        """Lambda _handle_risk_check must reject bool risk_score."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/risk-check",
            "body": json.dumps({"risk_score": True}),
        }
        response = handler(event, None)
        assert response["statusCode"] == 400
        body = json.loads(response["body"])
        assert "bool" in body["error"].lower() or "numeric" in body["error"].lower()

    def test_mcp_float_arg_rejects_bool(self):
        """MCP validate_float must reject bool inputs."""
        from aegis_governance.middleware import validate_float

        with pytest.raises(TypeError, match="bool"):
            validate_float({"risk_baseline": True}, "risk_baseline", 0.0)

    def test_mcp_float_arg_accepts_zero(self):
        """MCP validate_float must still accept 0 (falsy but valid)."""
        from aegis_governance.middleware import validate_float

        assert validate_float({"val": 0}, "val", 1.0) == 0.0

    def test_cli_parse_proposal_rejects_bool_metric(self):
        """CLI _parse_proposal must reject bool for numeric metric fields."""
        from cli import _parse_proposal

        with pytest.raises(TypeError, match="bool"):
            _parse_proposal({"risk_baseline": True})


class TestQG65UltrathinkFindings:
    """QG65: Ultrathink findings — CLI risk_score alias, quality_subscores bool guards."""

    def test_cli_risk_score_alias_rejects_bool(self):
        """CLI risk_score alias must reject bool (Finding 2.1)."""
        from cli import _parse_proposal

        with pytest.raises(TypeError, match="bool"):
            _parse_proposal({"risk_score": True})

    def test_cli_quality_subscores_reject_bool(self):
        """CLI quality_subscores elements must reject bool (Finding 2.2)."""
        from cli import _parse_proposal

        with pytest.raises(TypeError, match="bool"):
            _parse_proposal({"quality_subscores": [True, 0.5, 0.8]})

    def test_cli_quality_subscores_accept_numeric(self):
        """CLI quality_subscores must still accept valid numeric values."""
        from cli import _parse_proposal

        result = _parse_proposal({"quality_subscores": [0.9, 0.7, 0.8]})
        assert result["quality_subscores"] == [0.9, 0.7, 0.8]

    def test_lambda_base64_body_strict(self):
        """Lambda _parse_body must use strict base64 decode (Finding 5.2)."""
        # Valid base64 body should work
        import base64

        from lambda_handler import handler

        valid_body = base64.b64encode(b'{"proposal_summary": "test"}').decode()
        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "body": valid_body,
            "isBase64Encoded": True,
        }
        response = handler(event, None)
        # Should process (may be 200 or 400 depending on missing fields, but not 500)
        assert response["statusCode"] in (200, 400)


# ---------------------------------------------------------------------------
# Regression: BH24-L1 — quality_subscores type validation
# ---------------------------------------------------------------------------


class TestBH24QualitySubscoresTypeValidation:
    """BH24-L1: _extract_metrics must reject non-list quality_subscores."""

    def test_quality_subscores_float_rejected(self):
        """Passing a float instead of list must raise TypeError."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh24-l1-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.5,
                "quality_score": 0.7,
                "quality_subscores": 0.7,  # float instead of list
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_quality_subscores_dict_rejected(self):
        """Passing a dict instead of list must raise TypeError."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh24-l1-2",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.5,
                "quality_score": 0.7,
                "quality_subscores": {"a": 0.7},  # dict instead of list
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_quality_subscores_string_rejected(self):
        """Passing a string instead of list must raise TypeError."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh24-l1-3",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.5,
                "quality_score": 0.7,
                "quality_subscores": "high",  # string instead of list
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_quality_subscores_valid_list_accepted(self):
        """Valid list should pass normally."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh24-l1-4",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.5,
                "quality_score": 0.7,
                "quality_subscores": [0.8, 0.9, 0.7],
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome != DecisionOutcome.ERROR


# ---------------------------------------------------------------------------
# Regression: BH24-L2 — utility_result type validation
# ---------------------------------------------------------------------------


class TestBH24UtilityResultTypeValidation:
    """BH24-L2: _extract_metrics must reject non-UtilityResult utility_result."""

    def test_utility_result_dict_rejected(self):
        """Passing a dict instead of UtilityResult must raise TypeError."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh24-l2-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.5,
                "quality_score": 0.7,
                "utility_result": {"raw": 1.0, "variance": 0.01},
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_utility_result_string_rejected(self):
        """Passing a string instead of UtilityResult must raise TypeError."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh24-l2-2",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.5,
                "quality_score": 0.7,
                "utility_result": "high",
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.ERROR

    def test_utility_result_none_uses_default(self):
        """None utility_result should use default construction, not crash."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh24-l2-3",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-test",
            context={
                "risk_baseline": 1.0,
                "risk_proposed": 1.2,
                "profit_baseline": 100.0,
                "profit_proposed": 110.0,
                "novelty_score": 0.5,
                "complexity_score": 0.5,
                "quality_score": 0.7,
                "utility_result": None,
            },
        )
        response = bridge.request_decision(request)
        assert response.outcome != DecisionOutcome.ERROR


class TestBH29EstimatedImpactCaseNormalization:
    """Regression: estimated_impact must be case-insensitive (BH29-M1)."""

    def test_uppercase_critical_triggers_human_required(self):
        """'CRITICAL' (uppercase) must trigger human_required = True."""
        from engine.gates import GateEvaluator
        from integration.pcw_decide import PCWContext, PCWPhase, pcw_decide

        ctx = PCWContext(
            agent_id="test",
            session_id="test",
            phase=PCWPhase.PLAN,
            proposal_summary="test",
            estimated_impact="CRITICAL",
            risk_baseline=100.0,
            risk_proposed=50.0,
            profit_baseline=100.0,
            profit_proposed=110.0,
            novelty_score=0.5,
            complexity_score=0.5,
            quality_score=0.8,
            quality_subscores=[0.8, 0.8, 0.8],
        )
        evaluator = GateEvaluator()
        decision = pcw_decide(ctx, gate_evaluator=evaluator)
        assert decision.status.value in ("escalate", "pause")

    def test_mixed_case_high_triggers_human_required(self):
        """'High' (mixed case) must trigger human_required = True."""
        from engine.gates import GateEvaluator
        from integration.pcw_decide import PCWContext, PCWPhase, pcw_decide

        ctx = PCWContext(
            agent_id="test",
            session_id="test",
            phase=PCWPhase.PLAN,
            proposal_summary="test",
            estimated_impact="High",
            risk_baseline=100.0,
            risk_proposed=50.0,
            profit_baseline=100.0,
            profit_proposed=110.0,
            novelty_score=0.5,
            complexity_score=0.5,
            quality_score=0.8,
            quality_subscores=[0.8, 0.8, 0.8],
        )
        evaluator = GateEvaluator()
        decision = pcw_decide(ctx, gate_evaluator=evaluator)
        assert decision.status.value in ("escalate", "pause")

    def test_require_human_approval_uppercase(self):
        """require_human_approval() must accept case-insensitive impact."""
        from integration.pcw_decide import PCWContext, PCWPhase, require_human_approval

        ctx = PCWContext(
            agent_id="test",
            session_id="test",
            phase=PCWPhase.PLAN,
            proposal_summary="test",
            estimated_impact="CRITICAL",
        )
        assert require_human_approval(ctx) is True

    def test_require_human_approval_mixed_case(self):
        """require_human_approval() with 'Critical' must return True."""
        from integration.pcw_decide import PCWContext, PCWPhase, require_human_approval

        ctx = PCWContext(
            agent_id="test",
            session_id="test",
            phase=PCWPhase.PLAN,
            proposal_summary="test",
            estimated_impact="Critical",
        )
        assert require_human_approval(ctx) is True
