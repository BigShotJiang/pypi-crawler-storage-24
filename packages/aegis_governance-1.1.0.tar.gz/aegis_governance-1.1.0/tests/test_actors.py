"""
Tests for src/actors/ module.

Tests cover:
- Actor base class
- Proposer
- Analyst
- Approver
- Executor
"""

import pytest

from actors.analyst import AnalysisRequest, Analyst
from actors.approver import ApprovalVote, Approver
from actors.base import ActorCapabilities, ActorRole
from actors.executor import ExecutionPlan, ExecutionStatus, Executor
from actors.proposer import ProposalDraft, Proposer


class TestActorCapabilities:
    """Tests for ActorCapabilities."""

    def test_for_role_proposer(self):
        """Test capabilities for proposer role."""
        caps = ActorCapabilities.for_role(ActorRole.PROPOSER)

        assert caps.can_create_proposals is True
        assert caps.can_execute is False
        assert caps.can_override is False

    def test_for_role_analyst(self):
        """Test capabilities for analyst role."""
        caps = ActorCapabilities.for_role(ActorRole.ANALYST)

        assert caps.can_evaluate_gates is True
        assert caps.can_vote is True
        assert caps.can_create_proposals is False

    def test_for_role_admin(self):
        """Test admin has all capabilities."""
        caps = ActorCapabilities.for_role(ActorRole.ADMIN)

        assert caps.can_create_proposals is True
        assert caps.can_evaluate_gates is True
        assert caps.can_vote is True
        assert caps.can_approve is True
        assert caps.can_execute is True
        assert caps.can_override is True
        assert caps.can_rollback is True
        assert caps.can_configure is True


class TestProposer:
    """Tests for Proposer actor."""

    def test_init_basic(self):
        """Test basic initialization."""
        proposer = Proposer("p1", "Alice")

        assert proposer.actor_id == "p1"
        assert proposer.name == "Alice"
        assert ActorRole.PROPOSER in proposer.roles
        assert proposer.capabilities.can_create_proposals is True

    def test_init_with_additional_roles(self):
        """Test initialization with additional roles."""
        proposer = Proposer("p1", "Alice", additional_roles={ActorRole.ANALYST})

        assert ActorRole.PROPOSER in proposer.roles
        assert ActorRole.ANALYST in proposer.roles

    def test_get_primary_role(self):
        """Test primary role is PROPOSER."""
        proposer = Proposer("p1", "Alice")
        assert proposer.get_primary_role() == ActorRole.PROPOSER

    def test_get_allowed_actions(self):
        """Test allowed actions list."""
        proposer = Proposer("p1", "Alice")
        actions = proposer.get_allowed_actions()

        assert "create_draft" in actions
        assert "submit_proposal" in actions
        assert "withdraw_proposal" in actions

    def test_create_draft_valid(self):
        """Test creating valid draft."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="New Feature",
            description="Add caching layer",
            estimated_profit={"best": 10000, "likely": 8000, "worst": 5000},
            estimated_risk={"best": -0.2, "likely": -0.1, "worst": 0.1},
            complexity_assessment={"static": 0.3, "dynamic": 0.2},
            tags=["performance"],
            attachments=[],
        )

        result = proposer.create_draft(draft)

        assert result.success is True
        assert "proposal_id" in result.result_data

    def test_create_draft_invalid_missing_title(self):
        """Test draft rejection for missing title."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="",  # Empty title
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)

        assert result.success is False
        assert "Title" in result.error or "required" in result.error

    def test_create_draft_invalid_profit_estimate(self):
        """Test draft rejection for invalid profit estimate."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100},  # Missing likely and worst
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)

        assert result.success is False
        assert "profit" in result.error.lower()

    def test_submit_proposal_not_found(self):
        """Test submitting non-existent proposal."""
        proposer = Proposer("p1", "Alice")

        result = proposer.submit_proposal("nonexistent-id")

        assert result.success is False
        assert "not found" in result.error

    def test_submit_proposal(self):
        """Test submitting a draft."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        create_result = proposer.create_draft(draft)
        proposal_id = create_result.result_data["proposal_id"]

        submit_result = proposer.submit_proposal(proposal_id)

        assert submit_result.success is True
        assert proposal_id in proposer.submitted_proposals
        assert proposal_id not in proposer.active_proposals

    def test_withdraw_proposal(self):
        """Test withdrawing a proposal."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        create_result = proposer.create_draft(draft)
        proposal_id = create_result.result_data["proposal_id"]

        withdraw_result = proposer.withdraw_proposal(proposal_id, "Changed mind")

        assert withdraw_result.success is True

    def test_withdraw_submitted_proposal(self):
        """Test withdrawing a submitted proposal."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        create_result = proposer.create_draft(draft)
        proposal_id = create_result.result_data["proposal_id"]
        proposer.submit_proposal(proposal_id)

        withdraw_result = proposer.withdraw_proposal(proposal_id, "Changed mind")

        assert withdraw_result.success is True
        assert withdraw_result.result_data["status"] == "submitted_withdrawn"

    def test_withdraw_nonexistent_proposal(self):
        """Test withdrawing a non-existent proposal."""
        proposer = Proposer("p1", "Alice")

        result = proposer.withdraw_proposal("nonexistent", "Reason")

        assert result.success is False
        assert "not found" in result.error

    def test_get_proposal_status(self):
        """Test getting proposal status."""
        proposer = Proposer("p1", "Alice")

        # Test unknown status
        status = proposer.get_proposal_status("nonexistent")
        assert status["status"] == "unknown"

        # Create and check draft status
        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )
        result = proposer.create_draft(draft)
        proposal_id = result.result_data["proposal_id"]

        status = proposer.get_proposal_status(proposal_id)
        assert status["status"] == "draft"

        # Submit and check status
        proposer.submit_proposal(proposal_id)
        status = proposer.get_proposal_status(proposal_id)
        assert status["status"] == "submitted"


class TestAnalyst:
    """Tests for Analyst actor."""

    def test_init_basic(self):
        """Test basic initialization."""
        analyst = Analyst("a1", "Bob")

        assert analyst.actor_id == "a1"
        assert ActorRole.ANALYST in analyst.roles
        assert analyst.capabilities.can_evaluate_gates is True

    def test_init_with_specializations(self):
        """Test initialization with specializations."""
        analyst = Analyst("a1", "Bob", specializations=["risk", "security"])

        assert "risk" in analyst.specializations
        assert "security" in analyst.specializations

    def test_analyze_proposal_full(self, sample_proposal_data):
        """Test full proposal analysis."""
        analyst = Analyst("a1", "Bob")

        request = AnalysisRequest(
            proposal_id="p1",
            analysis_type="full",
            include_recommendations=True,
        )

        result = analyst.analyze_proposal(request, sample_proposal_data)

        assert result.success is True
        assert result.result_data["gate_count"] > 0

    def test_analyze_proposal_full_handles_null_quality_subscores(
        self, sample_proposal_data
    ):
        """Null quality_subscores should be treated like omitted subscores."""
        analyst = Analyst("a1", "Bob")

        request = AnalysisRequest(
            proposal_id="p1",
            analysis_type="full",
            include_recommendations=True,
        )

        proposal_data = dict(sample_proposal_data)
        proposal_data["quality_subscores"] = None

        result = analyst.analyze_proposal(request, proposal_data)

        assert result.success is True
        assert result.result_data["gate_count"] > 0

    def test_analyze_proposal_full_invalid_quality_subscores_type_fails_gracefully(
        self, sample_proposal_data
    ):
        """Non-list quality_subscores should return ActionResult failure, not crash."""
        analyst = Analyst("a1", "Bob")

        request = AnalysisRequest(
            proposal_id="p1",
            analysis_type="full",
            include_recommendations=True,
        )

        proposal_data = dict(sample_proposal_data)
        proposal_data["quality_subscores"] = "0.8,0.9,0.7"

        result = analyst.analyze_proposal(request, proposal_data)

        assert result.success is False
        assert result.error is not None
        assert "quality_subscores must be a list" in result.error

    def test_analyze_proposal_risk_only(self):
        """Test risk-only analysis."""
        analyst = Analyst("a1", "Bob")

        request = AnalysisRequest(
            proposal_id="p1",
            analysis_type="risk_only",
        )

        result = analyst.analyze_proposal(request, {"risk_delta": 0.5})

        assert result.success is True

    def test_analyze_proposal_quick_uses_risk_gate(self):
        """Test quick analysis runs the risk gate."""
        analyst = Analyst("a1", "Bob")

        request = AnalysisRequest(
            proposal_id="p1",
            analysis_type="quick",
        )

        result = analyst.analyze_proposal(
            request,
            {"risk_baseline": 1.0, "risk_delta": 4.0},
        )

        assert result.success is True
        assert result.result_data["gate_count"] == 1
        assert result.result_data["overall_passed"] is False

    def test_risk_gate_uses_delta_with_baseline(self):
        """Risk delta should be applied to baseline when computing proposed."""
        analyst = Analyst("a1", "Bob")

        gate = analyst._evaluate_risk_gate(
            {"risk_baseline": 1.0, "risk_delta": 4.0},
        )

        assert gate.passed is False

    def test_profit_gate_uses_delta_with_baseline(self):
        """Profit delta should be applied to baseline when computing proposed."""
        analyst = Analyst("a1", "Bob")

        gate = analyst._evaluate_profit_gate(
            {"profit_baseline": 1.0, "profit_delta": 4.0},
        )

        assert gate.passed is False

    def test_allowed_actions(self):
        """Test allowed actions list."""
        analyst = Analyst("a1", "Bob")
        actions = analyst.get_allowed_actions()

        assert "analyze_proposal" in actions
        assert "evaluate_gate" in actions
        assert "vote" in actions


class TestApprover:
    """Tests for Approver actor."""

    def test_init_basic(self):
        """Test basic initialization."""
        approver = Approver("ap1", "Carol")

        assert approver.actor_id == "ap1"
        assert ActorRole.APPROVER in approver.roles
        assert approver.capabilities.can_vote is True
        assert approver.capabilities.can_approve is True

    def test_init_risk_lead(self):
        """Test Risk Lead initialization."""
        approver = Approver("ap1", "Carol", is_risk_lead=True)

        assert ActorRole.RISK_LEAD in approver.roles
        assert approver.capabilities.can_override is True
        assert approver.get_primary_role() == ActorRole.RISK_LEAD

    def test_init_security_lead(self):
        """Test Security Lead initialization."""
        approver = Approver("ap1", "Carol", is_security_lead=True)

        assert ActorRole.SECURITY_LEAD in approver.roles
        assert approver.capabilities.can_override is True
        assert approver.get_primary_role() == ActorRole.SECURITY_LEAD

    def test_init_with_additional_roles(self):
        """Test initialization with additional roles."""
        approver = Approver("ap1", "Carol", additional_roles={ActorRole.ANALYST})

        assert ActorRole.APPROVER in approver.roles
        assert ActorRole.ANALYST in approver.roles

    def test_cast_vote(self):
        """Test vote casting."""
        approver = Approver("ap1", "Carol")

        vote = ApprovalVote(
            proposal_id="p1",
            vote="approve",
            rationale="Looks good",
        )

        result = approver.cast_vote(vote)

        assert result.success is True
        assert "p1" in approver.votes_cast

    def test_cast_vote_invalid(self):
        """Test invalid vote rejection at construction time."""
        with pytest.raises(ValueError, match="Invalid vote"):
            ApprovalVote(
                proposal_id="p1",
                vote="invalid_vote",  # Invalid
                rationale="Test",
            )

    def test_authorize_override_risk_lead(self):
        """Test override authorization by Risk Lead."""
        approver = Approver("ap1", "Carol", is_risk_lead=True)

        result = approver.authorize_override(
            proposal_id="p1",
            failed_gates=["risk"],
            justification="Critical business need",
            signature="valid-sig",
        )

        assert result.success is True
        assert result.result_data["role"] == "risk_lead"

    def test_authorize_override_blocked_complexity(self):
        """Test override blocked for complexity gate."""
        approver = Approver("ap1", "Carol", is_risk_lead=True)

        result = approver.authorize_override(
            proposal_id="p1",
            failed_gates=["complexity"],  # Cannot override
            justification="Test",
            signature="sig",
        )

        assert result.success is False
        assert "cannot be overridden" in result.error

    def test_approve_proposal(self):
        """Test direct proposal approval."""
        approver = Approver("ap1", "Carol")

        result = approver.approve_proposal("p1", conditions=["Must add tests"])

        assert result.success is True
        assert result.result_data["conditions"] == ["Must add tests"]

    def test_reject_proposal(self):
        """Test proposal rejection."""
        approver = Approver("ap1", "Carol")

        result = approver.reject_proposal("p1", "Does not meet quality bar")

        assert result.success is True
        assert result.result_data["allow_resubmission"] is True

    def test_get_primary_role_basic(self):
        """Test primary role for basic approver."""
        approver = Approver("ap1", "Carol")
        assert approver.get_primary_role() == ActorRole.APPROVER

    def test_get_allowed_actions(self):
        """Test allowed actions list."""
        approver = Approver("ap1", "Carol")
        actions = approver.get_allowed_actions()

        assert "vote" in actions
        assert "approve" in actions
        assert "reject" in actions

    def test_authorize_override_no_capability(self):
        """Test override blocked for non-lead approver."""
        approver = Approver("ap1", "Carol")  # Not a lead

        result = approver.authorize_override(
            proposal_id="p1",
            failed_gates=["risk"],
            justification="Test",
            signature="sig",
        )

        assert result.success is False
        assert (
            "override" in result.error.lower() or "capability" in result.error.lower()
        )

    def test_authorize_override_security_lead(self):
        """Test override authorization by Security Lead."""
        approver = Approver("ap1", "Carol", is_security_lead=True)

        result = approver.authorize_override(
            proposal_id="p1",
            failed_gates=["profit"],
            justification="Critical business need",
            signature="valid-sig",
        )

        assert result.success is True
        assert result.result_data["role"] == "security_lead"
        assert "p1" in approver.overrides_authorized

    def test_authorize_override_missing_signature(self):
        """Test override blocked when signature missing."""
        approver = Approver("ap1", "Carol", is_risk_lead=True)

        result = approver.authorize_override(
            proposal_id="p1",
            failed_gates=["risk"],
            justification="Test",
            signature="",  # Empty signature
        )

        assert result.success is False
        assert "signature" in result.error.lower()

    def test_get_allowed_actions_with_override(self):
        """Test allowed actions includes override for leads."""
        approver = Approver("ap1", "Carol", is_risk_lead=True)
        actions = approver.get_allowed_actions()

        assert "authorize_override" in actions
        assert "sign_override" in actions

    def test_get_override_status(self):
        """Test get_override_status returns correct info."""
        approver = Approver("ap1", "Carol", is_risk_lead=True)

        # Authorize one override
        approver.authorize_override(
            proposal_id="p1",
            failed_gates=["risk"],
            justification="Test",
            signature="sig",
        )

        status = approver.get_override_status()

        assert status["actor_id"] == "ap1"
        assert status["is_risk_lead"] is True
        assert status["is_security_lead"] is False
        assert status["can_sign_override"] is True
        assert status["overrides_authorized"] == 1

    def test_cast_vote_with_conditions(self):
        """Test casting vote with conditions."""
        approver = Approver("ap1", "Carol")

        vote = ApprovalVote(
            proposal_id="p1",
            vote="approve",
            rationale="Looks good",
            conditions=["Add unit tests", "Update documentation"],
        )

        result = approver.cast_vote(vote)

        assert result.success is True
        assert result.result_data["has_conditions"] is True

    def test_cast_vote_defer(self):
        """Test casting defer vote."""
        approver = Approver("ap1", "Carol")

        vote = ApprovalVote(
            proposal_id="p1",
            vote="defer",
            rationale="Need more information",
        )

        result = approver.cast_vote(vote)

        assert result.success is True
        assert result.result_data["vote"] == "defer"

    def test_cast_vote_abstain(self):
        """Test casting abstain vote."""
        approver = Approver("ap1", "Carol")

        vote = ApprovalVote(
            proposal_id="p1",
            vote="abstain",
            rationale="Conflict of interest",
        )

        result = approver.cast_vote(vote)

        assert result.success is True
        assert result.result_data["vote"] == "abstain"


class TestExecutor:
    """Tests for Executor actor."""

    def test_init_basic(self):
        """Test basic initialization."""
        executor = Executor("e1", "Dave")

        assert executor.actor_id == "e1"
        assert ActorRole.EXECUTOR in executor.roles
        assert executor.capabilities.can_execute is True
        assert executor.capabilities.can_rollback is True

    def test_start_execution(self):
        """Test starting execution."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "deploy"}, {"action": "verify"}],
            rollback_steps=[{"action": "revert"}],
            timeout_seconds=300,
        )

        result = executor.start_execution(plan)

        assert result.success is True
        assert "p1" in executor.active_executions

    def test_start_execution_with_no_steps_completes(self):
        """Test starting an empty execution plan completes immediately."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p-empty",
            steps=[],
            rollback_steps=[],
            timeout_seconds=300,
        )

        result = executor.start_execution(plan)

        assert result.success is True
        assert "p-empty" not in executor.active_executions
        assert "p-empty" in executor.completed_executions
        assert result.result_data["status"] == "completed"

    def test_start_execution_duplicate(self):
        """Test duplicate execution blocked."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "deploy"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        result = executor.start_execution(plan)

        assert result.success is False
        assert "already in progress" in result.error

    def test_advance_step(self):
        """Test advancing execution step."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}, {"action": "b"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        result = executor.advance_step("p1", {"status": "success"})

        assert result.success is True
        assert result.result_data["current_step"] == 1

    def test_execution_completion(self):
        """Test execution completion."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        result = executor.advance_step("p1", {"status": "success"})

        assert result.result_data["completed"] is True
        assert "p1" in executor.completed_executions

    def test_rollback(self):
        """Test execution rollback."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}],
            rollback_steps=[{"action": "revert"}],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        result = executor.rollback("p1", "Deployment failed")

        assert result.success is True
        assert result.result_data["status"] == "rolled_back"

    def test_rollback_tracks_in_completed_executions(self):
        """Regression: rolled-back executions must appear in completed_executions."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}],
            rollback_steps=[{"action": "revert"}],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        executor.rollback("p1", "Deployment failed")

        # Bug fix: rollback must add to completed_executions (audit trail)
        assert "p1" in executor.completed_executions
        assert "p1" not in executor.active_executions

    def test_start_execution_rejects_previously_completed(self):
        """Regression: cannot re-execute a previously completed proposal."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        executor.advance_step("p1", {"result": "ok"})

        # Verify it completed
        assert "p1" in executor.completed_executions

        # Attempt to re-execute should fail
        result = executor.start_execution(plan)
        assert result is not None
        assert result.success is False
        assert "already executed" in result.error

    def test_pause_resume(self):
        """Test pause and resume."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}, {"action": "b"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)

        pause_result = executor.pause_execution("p1", "Manual review")
        assert pause_result.success is True

        status = executor.get_execution_status("p1")
        assert status.status == ExecutionStatus.PAUSED

        resume_result = executor.resume_execution("p1")
        assert resume_result.success is True

        status = executor.get_execution_status("p1")
        assert status.status == ExecutionStatus.IN_PROGRESS

    def test_get_active_count(self):
        """Test active execution count."""
        executor = Executor("e1", "Dave")

        assert executor.get_active_count() == 0

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}],
            rollback_steps=[],
            timeout_seconds=300,
        )
        executor.start_execution(plan)

        assert executor.get_active_count() == 1

    def test_get_primary_role(self):
        """Test primary role is EXECUTOR."""
        executor = Executor("e1", "Dave")
        assert executor.get_primary_role() == ActorRole.EXECUTOR

    def test_get_allowed_actions(self):
        """Test allowed actions list."""
        executor = Executor("e1", "Dave")
        actions = executor.get_allowed_actions()

        assert "start_execution" in actions
        assert "rollback" in actions

    def test_get_execution_status_not_found(self):
        """Test status for non-existent execution."""
        executor = Executor("e1", "Dave")
        status = executor.get_execution_status("nonexistent")

        assert status is None or (hasattr(status, "status") and status.status is None)

    def test_get_execution_status_returns_defensive_copy(self):
        """Test that get_execution_status returns a copy, not the original.

        This prevents external mutation from bypassing the thread-safety lock.
        """
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}, {"action": "b"}],
            rollback_steps=[],
            timeout_seconds=300,
        )
        executor.start_execution(plan)

        # Get status
        status1 = executor.get_execution_status("p1")
        assert status1 is not None
        original_step = status1.current_step

        # Mutate the returned status
        status1.current_step = 999

        # Get status again - should be unchanged
        status2 = executor.get_execution_status("p1")
        assert status2 is not None
        assert status2.current_step == original_step  # Not 999

    def test_init_with_additional_roles(self):
        """Test executor with additional roles."""
        executor = Executor("e1", "Dave", additional_roles={ActorRole.ANALYST})

        assert ActorRole.EXECUTOR in executor.roles
        assert ActorRole.ANALYST in executor.roles

    def test_advance_step_not_active(self):
        """Test advance_step with no active execution."""
        executor = Executor("e1", "Dave")

        result = executor.advance_step("nonexistent", {"status": "success"})

        assert result.success is False
        assert "No active execution" in result.error

    def test_advance_step_not_in_progress(self):
        """Test advance_step when execution is paused."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}, {"action": "b"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        executor.pause_execution("p1", "Need review")

        result = executor.advance_step("p1", {"status": "success"})

        assert result.success is False
        assert "not in progress" in result.error

    def test_rollback_not_active(self):
        """Test rollback with no active execution."""
        executor = Executor("e1", "Dave")

        result = executor.rollback("nonexistent", "Test reason")

        assert result.success is False
        assert "No active execution" in result.error

    def test_pause_execution_not_active(self):
        """Test pause_execution with no active execution."""
        executor = Executor("e1", "Dave")

        result = executor.pause_execution("nonexistent", "Test reason")

        assert result.success is False
        assert "No active execution" in result.error

    def test_pause_execution_not_in_progress(self):
        """Test pause_execution when already paused."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)
        executor.pause_execution("p1", "First pause")

        result = executor.pause_execution("p1", "Second pause")

        assert result.success is False
        assert "in-progress" in result.error

    def test_resume_execution_not_active(self):
        """Test resume_execution with no active execution."""
        executor = Executor("e1", "Dave")

        result = executor.resume_execution("nonexistent")

        assert result.success is False
        assert "No active execution" in result.error

    def test_resume_execution_not_paused(self):
        """Test resume_execution when not paused."""
        executor = Executor("e1", "Dave")

        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"action": "a"}],
            rollback_steps=[],
            timeout_seconds=300,
        )

        executor.start_execution(plan)

        result = executor.resume_execution("p1")

        assert result.success is False
        assert "paused" in result.error


# =============================================================================
# Codex Bug Hunt v3.21.0 Regression Tests
# =============================================================================


class TestAnalysisTypeValidation:
    """Regression tests for analysis_type validation (Codex HIGH bug).

    Codex Bug: analyst.py:150 - Invalid analysis_type values could result
    in no gates being evaluated, and `all([])` returns True, causing
    false approvals.
    """

    def test_invalid_analysis_type_raises_valueerror(self):
        """Test that invalid analysis_type raises ValueError at construction."""
        import pytest

        with pytest.raises(ValueError, match="Invalid analysis_type"):
            AnalysisRequest(
                proposal_id="p1",
                analysis_type="invalid_type",
            )

    def test_valid_analysis_types_accepted(self):
        """Test that valid analysis_type values are accepted."""
        from actors.analyst import VALID_ANALYSIS_TYPES

        for analysis_type in VALID_ANALYSIS_TYPES:
            request = AnalysisRequest(
                proposal_id="p1",
                analysis_type=analysis_type,
            )
            assert request.analysis_type == analysis_type

    def test_empty_gates_returns_failure(self):
        """Test that if somehow no gates are evaluated, analyze_proposal fails."""
        # This is a defense-in-depth test - even if analysis_type validation
        # were bypassed, the analyze_proposal method should fail safely.
        analyst = Analyst("a1", "Alice")

        # Create a valid request with "quick" type which evaluates at least risk gate
        request = AnalysisRequest(proposal_id="p1", analysis_type="quick")

        # With minimal proposal data, gates should evaluate
        result = analyst.analyze_proposal(
            request,
            {"risk_baseline": 1.0, "risk_proposed": 1.1},
        )

        # Should succeed because at least one gate was evaluated
        assert result.success is True
        assert result.result_data["gate_count"] >= 1


class TestExecutionPlanValidation:
    """Regression tests for ExecutionPlan input validation."""

    def test_timeout_seconds_zero_raises(self):
        """Test that zero timeout_seconds raises ValueError."""
        with pytest.raises(ValueError, match="timeout_seconds must be positive"):
            ExecutionPlan(
                proposal_id="p1",
                steps=[],
                rollback_steps=[],
                timeout_seconds=0,
            )

    def test_timeout_seconds_negative_raises(self):
        """Test that negative timeout_seconds raises ValueError."""
        with pytest.raises(ValueError, match="timeout_seconds must be positive"):
            ExecutionPlan(
                proposal_id="p1",
                steps=[],
                rollback_steps=[],
                timeout_seconds=-100,
            )

    def test_timeout_seconds_positive_accepted(self):
        """Test that positive timeout_seconds is accepted."""
        plan = ExecutionPlan(
            proposal_id="p1",
            steps=[{"name": "step1"}],
            rollback_steps=[],
            timeout_seconds=3600,
        )
        assert plan.timeout_seconds == 3600


class TestActorCapabilitiesRepr:
    """Regression tests for ActorCapabilities __repr__."""

    def test_repr_shows_enabled_capabilities(self):
        """Test repr shows only enabled capabilities."""
        from actors.base import ActorCapabilities

        caps = ActorCapabilities(can_vote=True, can_approve=True)
        r = repr(caps)
        assert "can_vote" in r
        assert "can_approve" in r
        assert "can_execute" not in r

    def test_repr_no_capabilities(self):
        """Test repr shows 'none' when no capabilities enabled."""
        from actors.base import ActorCapabilities

        caps = ActorCapabilities()
        r = repr(caps)
        assert "none" in r


# =============================================================================
# L44 Regression Tests - Type Coercion Validation in _evaluate_utility_gate
# =============================================================================


class TestUtilityGateTypeCoercion:
    """Regression tests for L44: type coercion validation in _evaluate_utility_gate.

    Issue: analyst.py:345 - _evaluate_utility_gate was missing type coercion
    validation, which could cause confusing errors when numeric fields
    contained non-numeric types (e.g., from JSON deserialization).
    """

    def test_string_numeric_values_coerced(self):
        """Test that string numeric values are properly coerced to float."""
        analyst = Analyst("a1", "Alice")

        # Pass utility values as strings (common from JSON deserialization)
        data = {
            "utility_lcb": "100.5",
            "raw_utility": "150.0",
            "utility_variance": "25.0",
            "profit_high_conf": "50.0",
            "value_low_conf": "10.0",
            "risk_adjustment": "5.0",
            "complexity_tax": "15.0",
            "opex_delta": "0.0",
        }

        # Should succeed - strings are coerced to floats
        gate = analyst._evaluate_utility_gate(data)
        assert gate.gate_name == "utility"
        # Gate passes if LCB > 0 (100.5 > 0)
        assert gate.passed is True

    def test_integer_values_coerced(self):
        """Test that integer values are properly coerced to float."""
        analyst = Analyst("a1", "Alice")

        # Pass utility values as integers
        data = {
            "utility_lcb": 100,
            "raw_utility": 150,
            "utility_variance": 25,
            "profit_high_conf": 50,
            "value_low_conf": 10,
            "risk_adjustment": 5,
            "complexity_tax": 15,
            "opex_delta": 0,
        }

        # Should succeed - integers are coerced to floats
        gate = analyst._evaluate_utility_gate(data)
        assert gate.gate_name == "utility"
        assert gate.passed is True

    def test_invalid_string_raises_typeerror(self):
        """Test that non-numeric strings raise TypeError."""
        analyst = Analyst("a1", "Alice")

        data = {
            "utility_lcb": "not_a_number",  # Invalid string
        }

        with pytest.raises(TypeError, match="Cannot convert utility_lcb"):
            analyst._evaluate_utility_gate(data)

    def test_list_value_raises_typeerror(self):
        """Test that list values raise TypeError."""
        analyst = Analyst("a1", "Alice")

        data = {
            "utility_lcb": [100.0],  # List instead of float
        }

        with pytest.raises(TypeError, match=r"Cannot convert utility_lcb.*list"):
            analyst._evaluate_utility_gate(data)

    def test_dict_value_raises_typeerror(self):
        """Test that dict values raise TypeError."""
        analyst = Analyst("a1", "Alice")

        data = {
            "profit_high_conf": {"value": 50.0},  # Dict instead of float
        }

        with pytest.raises(TypeError, match=r"Cannot convert profit_high_conf.*dict"):
            analyst._evaluate_utility_gate(data)

    def test_bool_value_raises_typeerror(self):
        """Test that boolean values raise TypeError (bool is subclass of int)."""
        analyst = Analyst("a1", "Alice")

        data = {
            "utility_lcb": True,  # Bool instead of float
        }

        with pytest.raises(TypeError, match=r"Cannot convert utility_lcb.*bool"):
            analyst._evaluate_utility_gate(data)

    def test_none_value_coalesced_to_default(self):
        """QG68: None utility_lcb is null-coalesced to 0.0 (transport parity)."""
        analyst = Analyst("a1", "Alice")

        data = {
            "utility_lcb": None,  # Null-coalesced to 0.0
        }

        result = analyst._evaluate_utility_gate(data)
        assert result is not None

    def test_mixed_valid_types_coerced(self):
        """Test that mixed but valid types (int, float, str) are all coerced."""
        analyst = Analyst("a1", "Alice")

        data = {
            "utility_lcb": 100,  # int
            "raw_utility": 150.5,  # float
            "utility_variance": "25.0",  # str
            "profit_high_conf": 50,  # int
            "value_low_conf": "10.5",  # str
            "risk_adjustment": 5.0,  # float
            "complexity_tax": "15",  # str (integer as string)
            "opex_delta": 0,  # int
        }

        # All values should be coerced successfully
        gate = analyst._evaluate_utility_gate(data)
        assert gate.gate_name == "utility"
        assert gate.passed is True

    def test_utility_result_object_bypasses_coercion(self):
        """Test that providing UtilityResult directly bypasses coercion."""
        from engine.utility import UtilityComponents, UtilityResult

        analyst = Analyst("a1", "Alice")

        # Provide pre-constructed UtilityResult
        utility_result = UtilityResult(
            raw=150.0,
            variance=25.0,
            lcb=100.0,
            components=UtilityComponents(
                profit_high_conf=50.0,
                value_low_conf=10.0,
                risk_adjustment=5.0,
                complexity_tax=15.0,
                opex_delta=0.0,
            ),
            decision_path="INVESTMENT",
        )

        data = {"utility_result": utility_result}

        # Should use the provided UtilityResult directly
        gate = analyst._evaluate_utility_gate(data)
        assert gate.gate_name == "utility"
        assert gate.passed is True


# =============================================================================
# B1 Regression Tests - Proposer Bug Fixes (v3.32.0)
# =============================================================================


class TestProposerPertTypeValidation:
    """Regression tests for B1-1: PERT estimate type validation.

    Issue: proposer.py:122 - _validate_pert_estimates was only checking key
    presence, not numeric types. Non-numeric values would pass validation
    and cause errors downstream.
    """

    def test_string_values_raise_typeerror(self):
        """Test that string values in PERT estimates return ActionResult failure.

        BH44-M2: create_draft now catches TypeError and returns ActionResult
        instead of propagating the exception.
        """
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": "100", "likely": "80", "worst": "50"},  # Strings
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is False
        assert "must be numeric" in result.error

    def test_none_values_raise_typeerror(self):
        """Test that None values in PERT estimates return ActionResult failure.

        BH44-M2: create_draft now catches TypeError and returns ActionResult.
        """
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": None, "likely": 80, "worst": 50},  # None value
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is False
        assert "must be numeric" in result.error
        assert "NoneType" in result.error

    def test_bool_values_raise_typeerror(self):
        """Test that boolean values in PERT estimates return ActionResult failure.

        Note: bool is a subclass of int in Python, so this needs explicit handling.
        BH44-M2: create_draft now catches TypeError and returns ActionResult.
        """
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": True, "likely": 80, "worst": 50},  # Bool value
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is False
        assert "must be numeric" in result.error
        assert "bool" in result.error

    def test_list_values_raise_typeerror(self):
        """Test that list values in PERT estimates return ActionResult failure.

        BH44-M2: create_draft now catches TypeError and returns ActionResult.
        """
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": [100], "likely": 80, "worst": 50},  # List value
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is False
        assert "must be numeric" in result.error
        assert "list" in result.error

    def test_dict_values_raise_typeerror(self):
        """Test that dict values in PERT estimates return ActionResult failure.

        BH44-M2: create_draft now catches TypeError and returns ActionResult.
        """
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": {"value": -0.1}, "likely": 0, "worst": 0.1},  # Dict
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is False
        assert "must be numeric" in result.error
        assert "dict" in result.error

    def test_int_values_accepted(self):
        """Test that integer values are accepted in PERT estimates."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},  # Integers
            estimated_risk={"best": 0, "likely": 0, "worst": 0},  # Integers
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is True

    def test_float_values_accepted(self):
        """Test that float values are accepted in PERT estimates."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100.5, "likely": 80.3, "worst": 50.1},  # Floats
            estimated_risk={"best": -0.1, "likely": 0.0, "worst": 0.1},  # Floats
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is True

    def test_mixed_int_float_accepted(self):
        """Test that mixed int/float values are accepted in PERT estimates."""
        proposer = Proposer("p1", "Alice")

        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80.5, "worst": 50},  # Mixed
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},  # Mixed
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )

        result = proposer.create_draft(draft)
        assert result.success is True


class TestProposerTOCTOURaceFixes:
    """Regression tests for B1-2 and B1-3: TOCTOU race condition fixes.

    Issues:
    - B1-2: submit_proposal() used `if x in deque: deque.remove(x)` pattern
    - B1-3: withdraw_proposal() used same pattern

    Both are now fixed to use try/except ValueError pattern.
    """

    def test_submit_proposal_concurrent_removal_safe(self):
        """Test that submit_proposal handles concurrent removal gracefully.

        The try/except pattern ensures that even if the proposal is removed
        between the check and removal, the method handles it gracefully.
        """
        proposer = Proposer("p1", "Alice")

        # Create a draft
        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )
        create_result = proposer.create_draft(draft)
        proposal_id = create_result.result_data["proposal_id"]

        # Submit the proposal
        submit_result = proposer.submit_proposal(proposal_id)
        assert submit_result.success is True

        # Try to submit again - should fail gracefully (already submitted)
        submit_result2 = proposer.submit_proposal(proposal_id)
        assert submit_result2.success is False
        assert "already been submitted" in submit_result2.error

    def test_submit_proposal_not_found_graceful(self):
        """Test that submit_proposal handles not-found gracefully."""
        proposer = Proposer("p1", "Alice")

        result = proposer.submit_proposal("nonexistent-id")
        assert result.success is False
        assert "not found" in result.error

    def test_withdraw_proposal_concurrent_removal_safe(self):
        """Test that withdraw_proposal handles concurrent removal gracefully.

        The try/except pattern ensures that even if the proposal is removed
        between the check and removal, the method handles it gracefully.
        """
        proposer = Proposer("p1", "Alice")

        # Create a draft
        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )
        create_result = proposer.create_draft(draft)
        proposal_id = create_result.result_data["proposal_id"]

        # Withdraw the draft
        withdraw_result = proposer.withdraw_proposal(proposal_id, "Changed mind")
        assert withdraw_result.success is True
        assert withdraw_result.result_data["status"] == "draft_withdrawn"

        # Try to withdraw again - should fail gracefully (not found)
        withdraw_result2 = proposer.withdraw_proposal(proposal_id, "Changed mind again")
        assert withdraw_result2.success is False
        assert "not found" in withdraw_result2.error

    def test_withdraw_submitted_proposal_safe(self):
        """Test that withdrawing submitted proposals works correctly."""
        proposer = Proposer("p1", "Alice")

        # Create and submit a draft
        draft = ProposalDraft(
            title="Test",
            description="Test",
            estimated_profit={"best": 100, "likely": 80, "worst": 50},
            estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
            complexity_assessment={"static": 0.1, "dynamic": 0.1},
            tags=[],
            attachments=[],
        )
        create_result = proposer.create_draft(draft)
        proposal_id = create_result.result_data["proposal_id"]
        proposer.submit_proposal(proposal_id)

        # Withdraw the submitted proposal
        withdraw_result = proposer.withdraw_proposal(proposal_id, "No longer needed")
        assert withdraw_result.success is True
        assert withdraw_result.result_data["status"] == "submitted_withdrawn"

        # Verify it's removed from submitted_proposals
        assert proposal_id not in proposer.submitted_proposals

    def test_withdraw_nonexistent_proposal_graceful(self):
        """Test that withdraw_proposal handles nonexistent proposals gracefully."""
        proposer = Proposer("p1", "Alice")

        result = proposer.withdraw_proposal("nonexistent-id", "Reason")
        assert result.success is False
        assert "not found" in result.error

    def test_submit_and_withdraw_sequence(self):
        """Test the full sequence of create -> submit -> withdraw works correctly."""
        proposer = Proposer("p1", "Alice")

        # Create multiple drafts
        proposal_ids = []
        for i in range(3):
            draft = ProposalDraft(
                title=f"Test {i}",
                description=f"Description {i}",
                estimated_profit={"best": 100, "likely": 80, "worst": 50},
                estimated_risk={"best": -0.1, "likely": 0, "worst": 0.1},
                complexity_assessment={"static": 0.1, "dynamic": 0.1},
                tags=[],
                attachments=[],
            )
            result = proposer.create_draft(draft)
            proposal_ids.append(result.result_data["proposal_id"])

        # Submit first two
        proposer.submit_proposal(proposal_ids[0])
        proposer.submit_proposal(proposal_ids[1])

        # Verify states
        assert proposal_ids[0] in proposer.submitted_proposals
        assert proposal_ids[1] in proposer.submitted_proposals
        assert proposal_ids[2] in proposer.active_proposals

        # Withdraw from each category
        result1 = proposer.withdraw_proposal(proposal_ids[0], "Withdraw submitted")
        result2 = proposer.withdraw_proposal(proposal_ids[2], "Withdraw draft")

        assert result1.success is True
        assert result1.result_data["status"] == "submitted_withdrawn"
        assert result2.success is True
        assert result2.result_data["status"] == "draft_withdrawn"

        # Verify final states
        assert proposal_ids[0] not in proposer.submitted_proposals
        assert proposal_ids[1] in proposer.submitted_proposals
        assert proposal_ids[2] not in proposer.active_proposals


class TestW8CompletedStatusQueryable:
    """Regression test for W-8: completed executions queryable via get_execution_status."""

    def test_empty_plan_execution_queryable(self):
        """W-8 regression: empty-plan execution still queryable after completion."""
        from actors.executor import ExecutionPlan, ExecutionStatus, Executor

        executor = Executor(actor_id="exec-1", name="Test Executor")
        plan = ExecutionPlan(
            proposal_id="prop-w8",
            steps=[],
            rollback_steps=[],
            timeout_seconds=60,
        )

        result = executor.start_execution(plan)
        assert result.success

        # After completion, status should still be queryable (W-8 fix)
        status = executor.get_execution_status("prop-w8")
        assert status is not None
        assert status.status == ExecutionStatus.COMPLETED
        assert status.proposal_id == "prop-w8"

    def test_completed_multi_step_execution_queryable(self):
        """W-8 regression: completed multi-step execution queryable."""
        from actors.executor import ExecutionPlan, ExecutionStatus, Executor

        executor = Executor(actor_id="exec-2", name="Test Executor")
        plan = ExecutionPlan(
            proposal_id="prop-w8b",
            steps=[{"action": "a"}, {"action": "b"}],
            rollback_steps=[],
            timeout_seconds=60,
        )

        executor.start_execution(plan)
        executor.advance_step("prop-w8b", {"ok": True})
        executor.advance_step("prop-w8b", {"ok": True})

        # Execution is completed — should be queryable
        status = executor.get_execution_status("prop-w8b")
        assert status is not None
        assert status.status == ExecutionStatus.COMPLETED


class TestExecutorRollbackRetry:
    """Regression T10-1: rolled-back proposals must be retryable."""

    def test_start_execution_after_rollback(self):
        """A ROLLED_BACK proposal should be retryable by the same Executor."""
        executor = Executor(
            actor_id="exec-retry",
            name="retry-exec",
        )
        plan = ExecutionPlan(
            proposal_id="retry-prop",
            steps=[{"action": "deploy"}],
            rollback_steps=[{"action": "undeploy"}],
            timeout_seconds=60,
        )

        # First execution
        result1 = executor.start_execution(plan)
        assert result1.success

        # Rollback
        rollback = executor.rollback("retry-prop", "test rollback")
        assert rollback.success

        # Retry should succeed (not blocked by re-execution guard)
        plan2 = ExecutionPlan(
            proposal_id="retry-prop",
            steps=[{"action": "deploy-v2"}],
            rollback_steps=[],
            timeout_seconds=60,
        )
        result2 = executor.start_execution(plan2)
        assert result2.success, f"Expected retry to succeed, got: {result2.error}"

    def test_start_execution_after_completion_still_blocked(self):
        """A COMPLETED proposal should still be blocked from re-execution."""
        executor = Executor(
            actor_id="exec-block",
            name="block-exec",
        )
        plan = ExecutionPlan(
            proposal_id="block-prop",
            steps=[{"action": "deploy"}],
            rollback_steps=[],
            timeout_seconds=60,
        )

        executor.start_execution(plan)
        executor.advance_step("block-prop", {"ok": True})

        # Re-execution should fail
        result = executor.start_execution(plan)
        assert not result.success
        assert "already executed" in result.error


class TestQG59AnalystNaN:
    """QG59: Analyst NaN/Inf input rejection."""

    def test_coerce_to_float_rejects_nan_numeric(self):
        """QG59-P2-2: _coerce_to_float must reject NaN numeric values."""
        analyst = Analyst(actor_id="a-1", name="Test Analyst")
        with pytest.raises(TypeError, match="not a finite number"):
            analyst._coerce_to_float(float("nan"), "test_field")

    def test_coerce_to_float_rejects_inf_numeric(self):
        """QG59-P2-2: _coerce_to_float must reject Inf numeric values."""
        analyst = Analyst(actor_id="a-1", name="Test Analyst")
        with pytest.raises(TypeError, match="not a finite number"):
            analyst._coerce_to_float(float("inf"), "test_field")

    def test_coerce_to_float_rejects_nan_string(self):
        """QG59-P2-2: _coerce_to_float must reject 'nan' string."""
        analyst = Analyst(actor_id="a-1", name="Test Analyst")
        with pytest.raises(TypeError, match="NaN/Inf"):
            analyst._coerce_to_float("nan", "test_field")

    def test_coerce_to_float_rejects_inf_string(self):
        """QG59-P2-2: _coerce_to_float must reject 'inf' string."""
        analyst = Analyst(actor_id="a-1", name="Test Analyst")
        with pytest.raises(TypeError, match="NaN/Inf"):
            analyst._coerce_to_float("inf", "test_field")

    def test_calculate_confidence_filters_nan(self):
        """QG59-P2-L1: NaN confidence values must be filtered before averaging."""
        from actors.analyst import GateAnalysis

        analyst = Analyst(actor_id="a-1", name="Test Analyst")
        analyses = [
            GateAnalysis(
                gate_name="risk", passed=True, value=0.5, threshold=0.95, confidence=0.8
            ),
            GateAnalysis(
                gate_name="profit",
                passed=True,
                value=0.5,
                threshold=0.95,
                confidence=float("nan"),
            ),
            GateAnalysis(
                gate_name="novelty",
                passed=True,
                value=0.9,
                threshold=0.8,
                confidence=0.6,
            ),
        ]
        result = analyst._calculate_confidence(analyses)
        # Should average only finite values: (0.8 + 0.6) / 2 = 0.7
        assert abs(result - 0.7) < 1e-9


class TestQG59ProposerPertNaN:
    """QG59: Proposer PERT estimate NaN/Inf rejection."""

    def test_pert_nan_profit_rejected(self):
        """QG59-P2-3: NaN in PERT profit estimates must be rejected.

        BH44-M2: create_draft now returns ActionResult instead of raising.
        """
        proposer = Proposer(actor_id="p-1", name="Test Proposer")
        draft = ProposalDraft(
            title="Test",
            description="Test desc",
            estimated_profit={"best": float("nan"), "likely": 100.0, "worst": 50.0},
            estimated_risk={"best": 0.1, "likely": 0.2, "worst": 0.3},
            complexity_assessment={"static": 0.5, "dynamic": 0.5},
            tags=[],
            attachments=[],
        )
        result = proposer.create_draft(draft)
        assert result.success is False
        assert "finite" in result.error

    def test_execution_plan_nan_timeout_rejected(self):
        """BH12: NaN timeout_seconds must be rejected (IEEE 754 bypass prevention)."""
        with pytest.raises((ValueError, TypeError)):
            ExecutionPlan(
                proposal_id="test",
                steps=[{"step": 1}],
                rollback_steps=[],
                timeout_seconds=float("nan"),
            )

    def test_execution_plan_inf_timeout_rejected(self):
        """BH12: Inf timeout_seconds must be rejected."""
        with pytest.raises((ValueError, TypeError)):
            ExecutionPlan(
                proposal_id="test",
                steps=[{"step": 1}],
                rollback_steps=[],
                timeout_seconds=float("inf"),
            )

    def test_calibration_proposal_nan_data_window_rejected(self):
        """BH12: NaN data_window must be rejected (type enforcement)."""
        from actors.calibrator import CalibrationProposal

        with pytest.raises((TypeError, ValueError)):
            CalibrationProposal(
                proposal_id="test",
                parameter_name="tau_warning",
                current_value=0.3,
                proposed_value=0.4,
                justification="test",
                data_window=float("nan"),
                statistical_method="percentile_p90",
            )

    def test_calibration_proposal_negative_data_window_rejected(self):
        """BH12: Negative data_window must be rejected."""
        from actors.calibrator import CalibrationProposal

        with pytest.raises(ValueError, match="data_window"):
            CalibrationProposal(
                proposal_id="test",
                parameter_name="tau_warning",
                current_value=0.3,
                proposed_value=0.4,
                justification="test",
                data_window=-1,
                statistical_method="percentile_p90",
            )

    def test_pert_inf_risk_rejected(self):
        """QG59-P2-3: Inf in PERT risk estimates must be rejected.

        BH44-M2: create_draft now returns ActionResult instead of raising.
        """
        proposer = Proposer(actor_id="p-1", name="Test Proposer")
        draft = ProposalDraft(
            title="Test",
            description="Test desc",
            estimated_profit={"best": 50.0, "likely": 100.0, "worst": 150.0},
            estimated_risk={"best": 0.1, "likely": float("inf"), "worst": 0.3},
            complexity_assessment={"static": 0.5, "dynamic": 0.5},
            tags=[],
            attachments=[],
        )
        result = proposer.create_draft(draft)
        assert result.success is False
        assert "finite" in result.error


# ---------------------------------------------------------------------------
# Regression: BH24 — Analyst null guard for dict.get() explicit None
# ---------------------------------------------------------------------------


class TestBH24AnalystNullGuards:
    """BH24: Analyst gate methods must handle explicit None from dict.get()."""

    def _make_request(self) -> AnalysisRequest:
        return AnalysisRequest(
            proposal_id="bh24-null",
            analysis_type="full",
            include_recommendations=True,
        )

    def test_quality_score_null_uses_default(self):
        """BH24-M3: quality_score=None must use default 0.7, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_delta": 0.5,
            "profit_delta": 0.3,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": None,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_risk_baseline_null_uses_default(self):
        """BH24-M4: risk_baseline=None must use default 0.0, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_baseline": None,
            "risk_proposed": 1.5,
            "profit_delta": 0.3,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_risk_delta_null_uses_default(self):
        """BH25: risk_delta=None must use default 0.0, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_baseline": 1.0,
            "risk_delta": None,
            "profit_delta": 0.3,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_novelty_score_null_uses_default(self):
        """BH24-L4: novelty_score=None must use default 0.5, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_delta": 0.5,
            "profit_delta": 0.3,
            "novelty_score": None,
            "complexity_score": 0.6,
            "quality_score": 0.8,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_complexity_score_null_uses_default(self):
        """BH24-L5: complexity_score=None must use default 0.5, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_delta": 0.5,
            "profit_delta": 0.3,
            "novelty_score": 0.85,
            "complexity_score": None,
            "quality_score": 0.8,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_utility_lcb_null_uses_default(self):
        """QG68-UT1: utility_lcb=None must use default 0.0, not raise TypeError."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_delta": 0.5,
            "profit_delta": 0.3,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
            "utility_lcb": None,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_utility_variance_null_uses_default(self):
        """QG68-UT1: utility_variance=None must use default 0.0, not raise TypeError."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_delta": 0.5,
            "profit_delta": 0.3,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
            "utility_variance": None,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_profit_baseline_null_uses_default(self):
        """BH24-L6: profit_baseline=None must use default 0.0, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_delta": 0.5,
            "profit_baseline": None,
            "profit_proposed": 110.0,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_profit_delta_null_uses_default(self):
        """BH25: profit_delta=None must use default 0.0, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_delta": 0.5,
            "profit_baseline": 100.0,
            "profit_delta": None,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True


class TestBH25UtilityComponentsNullGuard:
    """BH25-M1: UtilityComponents fields with explicit None must not crash."""

    @staticmethod
    def _make_request():
        return AnalysisRequest(proposal_id="P-UC1", analysis_type="full")

    def test_utility_components_all_null(self):
        """All UtilityComponents sub-fields as None must default to 0.0."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_baseline": 1.0,
            "risk_proposed": 1.2,
            "profit_baseline": 100.0,
            "profit_proposed": 110.0,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
            "quality_subscores": [0.8, 0.8, 0.8],
            "utility_lcb": 0.5,
            "net_utility": 1.0,
            "utility_variance": 0.1,
            "profit_high_conf": None,
            "value_low_conf": None,
            "risk_adjustment": None,
            "complexity_tax": None,
            "opex_delta": None,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True

    def test_utility_lcb_null(self):
        """utility_lcb=None must default to 0.0, not crash."""
        analyst = Analyst("a1", "Bob")
        data = {
            "risk_baseline": 1.0,
            "risk_proposed": 1.2,
            "profit_baseline": 100.0,
            "profit_proposed": 110.0,
            "novelty_score": 0.85,
            "complexity_score": 0.6,
            "quality_score": 0.8,
            "quality_subscores": [0.8, 0.8, 0.8],
            "utility_lcb": None,
            "net_utility": None,
            "utility_variance": None,
        }
        result = analyst.analyze_proposal(self._make_request(), data)
        assert result.success is True


class TestBH29ExecutorStartLockSnapshot:
    """Regression: start_execution must snapshot status inside lock (BH29-M2)."""

    def test_start_execution_returns_in_progress_status(self):
        from actors.executor import ExecutionPlan, Executor

        executor = Executor("exec-1", "Test Executor")
        plan = ExecutionPlan(
            proposal_id="prop-1",
            steps=[{"action": "deploy", "description": "Deploy service"}],
            rollback_steps=[],
            timeout_seconds=60,
        )
        result = executor.start_execution(plan)
        assert result.success is True
        assert result.result_data["status"] == "in_progress"

    def test_start_execution_snapshots_inside_lock(self):
        """Verify the return value reflects the status at lock-release time."""
        from actors.executor import ExecutionPlan, Executor

        executor = Executor("exec-1", "Test Executor")
        plan = ExecutionPlan(
            proposal_id="prop-snap",
            steps=[{"action": "step1", "description": "Only step"}],
            rollback_steps=[],
            timeout_seconds=60,
        )
        result = executor.start_execution(plan)
        assert result.result_data["status"] == "in_progress"


class TestBH29CalibratorNoveltyKZero:
    """Regression: _validate_gate_param must reject novelty_k=0 (BH29-M3)."""

    def test_novelty_k_zero_raises(self):
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="positive"):
            _validate_gate_param("novelty_k", 0.0)

    def test_novelty_k_nonzero_passes(self):
        from actors.calibrator import _validate_gate_param

        _validate_gate_param("novelty_k", 1.5)  # Should not raise
