"""TD-6: Strengthen isinstance-only test assertions.

Adds value assertions alongside isinstance checks to verify that factory
methods and constructors produce correctly configured instances, not just
the right type.
"""

from config import AegisConfig


class TestConfigFactoryValueAssertions:
    """TD-6: Factory methods must produce correctly configured instances."""

    def test_create_gate_evaluator_inherits_config(self):
        """GateEvaluator created from config should inherit epsilon_R."""
        config = AegisConfig(epsilon_R=0.05, novelty_threshold=0.9)
        evaluator = config.create_gate_evaluator()

        from engine.gates import GateEvaluator

        assert isinstance(evaluator, GateEvaluator)
        assert evaluator.epsilon_R == 0.05
        assert evaluator.novelty_threshold == 0.9

    def test_create_gate_evaluator_default_values(self):
        """Default config produces evaluator with default parameters."""
        config = AegisConfig.default()
        evaluator = config.create_gate_evaluator()

        from engine.gates import GateEvaluator

        assert isinstance(evaluator, GateEvaluator)
        assert evaluator.epsilon_R == config.epsilon_R
        assert evaluator.risk_trigger_factor == config.risk_trigger_factor

    def test_create_utility_calculator_has_gamma(self):
        """UtilityCalculator should inherit gamma from config."""
        config = AegisConfig(gamma=0.5)
        calculator = config.create_utility_calculator()

        from engine.utility import UtilityCalculator

        assert isinstance(calculator, UtilityCalculator)
        assert calculator.gamma == 0.5

    def test_create_drift_monitor_inherits_thresholds(self):
        """DriftMonitor should inherit KL thresholds from config."""
        from config import KLDriftConfig

        kl = KLDriftConfig(tau_warning=0.2, tau_critical=0.4)
        config = AegisConfig(kl_drift=kl)
        dm = config.create_drift_monitor()

        from engine.drift import DriftMonitor

        assert isinstance(dm, DriftMonitor)
        assert dm.tau_warning == 0.2
        assert dm.tau_critical == 0.4

    def test_default_config_values_are_correct_types(self):
        """Default config fields should be correct types AND have expected ranges."""
        config = AegisConfig.default()
        assert isinstance(config.epsilon_R, float)
        assert 0.0 < config.epsilon_R < 1.0
        assert isinstance(config.epsilon_P, float)
        assert 0.0 < config.epsilon_P < 1.0
        assert isinstance(config.gamma, float)
        assert 0.0 < config.gamma < 1.0


class TestIntegrationResultValueAssertions:
    """TD-6: Integration results must have meaningful values, not just correct types."""

    def test_pcw_decision_has_valid_confidence(self):
        """PCWDecision confidence should be in [0, 1] range."""
        from integration.pcw_decide import PCWContext, PCWPhase, pcw_decide

        context = PCWContext(
            agent_id="test-agent",
            session_id="test-session",
            phase=PCWPhase.COMMIT,
            proposal_summary="Test proposal",
            estimated_impact="low",
            risk_baseline=1.0,
            risk_proposed=1.1,
            profit_baseline=1.0,
            profit_proposed=1.1,
        )
        decision = pcw_decide(context)
        assert isinstance(decision.confidence, float)
        assert 0.0 <= decision.confidence <= 1.0
        assert len(decision.decision_id) > 0
        assert decision.gates_passed + decision.gates_failed > 0


class TestTelemetryValueAssertions:
    """TD-6: Telemetry objects must have meaningful values."""

    def test_pipeline_stats_values_after_ingest(self):
        """Pipeline stats should reflect actual event counts."""
        from telemetry.pipeline import PipelineStats, TelemetryPipeline

        pipeline = TelemetryPipeline()
        pipeline.ingest(
            {
                "event_id": "1",
                "event_type": "test",
                "timestamp": "2026-01-01T00:00:00Z",
                "source": "test",
            }
        )
        stats = pipeline.get_stats()
        assert isinstance(stats, PipelineStats)
        assert stats.events_received == 1
        assert stats.buffer_size == 1
        assert stats.events_dropped == 0
