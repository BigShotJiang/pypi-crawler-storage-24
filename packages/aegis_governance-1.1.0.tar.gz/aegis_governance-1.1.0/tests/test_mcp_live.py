"""Live MCP server integration tests via FastMCP + MCP SDK client.

Spawns the AEGIS MCP server as a subprocess, connects via stdio,
and exercises all 5 tools through the real MCP protocol.

Requires: pip install aegis-governance[mcp]
"""

from __future__ import annotations

import json
import sys
from typing import Any

import pytest

mcp_mod = pytest.importorskip(
    "mcp", reason="MCP SDK not installed (optional [mcp] dep)"
)

from mcp import ClientSession  # noqa: E402
from mcp.client.stdio import StdioServerParameters, stdio_client  # noqa: E402
from mcp.types import TextContent  # noqa: E402

# ── Fixtures ────────────────────────────────────────────────────────


@pytest.fixture
async def mcp_session():
    """Spawn MCP server and return connected ClientSession."""
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "aegis_governance.mcp_server"],
    )
    # anyio task groups raise RuntimeError on teardown when the cancel scope
    # is exited in a different task than it was entered in (known issue with
    # MCP client + pytest-asyncio).  pytest isolates test exceptions from
    # fixture yields, so this only catches setup/teardown errors — never
    # RuntimeErrors raised during test execution.
    try:
        async with (
            stdio_client(params) as (read, write),
            ClientSession(read, write) as session,
        ):
            await session.initialize()
            yield session
    except RuntimeError as exc:
        if "cancel scope" not in str(exc):
            raise


async def call_tool(
    session: ClientSession, tool_name: str, args: dict[str, Any]
) -> dict[str, Any]:
    """Call an MCP tool and parse the JSON response."""
    result = await session.call_tool(tool_name, arguments=args)
    content = result.content[0]
    if isinstance(content, TextContent):
        return json.loads(content.text)
    raise ValueError(f"Unexpected content type: {type(content)}")


# ── Tier 1: Smoke Tests ────────────────────────────────────────────


class TestMCPSmoke:
    """Tier 1: Basic connectivity and tool availability."""

    async def test_s1_health_check(self, mcp_session):
        """S1: aegis_check_thresholds returns 6 gates + config."""
        r = await call_tool(mcp_session, "aegis_check_thresholds", {})
        assert isinstance(r.get("gates"), list)
        assert len(r["gates"]) == 6
        assert isinstance(r.get("config"), dict)
        gate_names = [g["name"] for g in r["gates"]]
        assert "risk" in gate_names
        assert "complexity" in gate_names

    async def test_s2_crypto_status(self, mcp_session):
        """S2: aegis_crypto_status returns signatures + default_provider."""
        r = await call_tool(mcp_session, "aegis_crypto_status", {})
        assert "signatures" in r
        assert "default_provider" in r

    async def test_s3_scoring_guide_generic(self, mcp_session):
        """S3: aegis_get_scoring_guide returns valid structure."""
        r = await call_tool(mcp_session, "aegis_get_scoring_guide", {})
        assert isinstance(r, dict)


# ── Tier 2: Functional Tests ───────────────────────────────────────


class TestMCPFunctional:
    """Tier 2: Gate behavior verification."""

    async def test_f1_simple_proceed(self, mcp_session):
        """F1: Low risk, high quality → PROCEED."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "F1: Minor CSS fix",
                "estimated_impact": "low",
                "risk_baseline": 0.1,
                "risk_proposed": 0.1,
                "novelty_score": 0.9,
                "complexity_score": 0.9,
                "quality_score": 0.9,
            },
        )
        assert r["status"] == "proceed"

    async def test_f2_risk_triggered_pause(self, mcp_session):
        """F2: 10x risk increase → risk gate fails."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "F2: Risky deploy",
                "estimated_impact": "medium",
                "risk_baseline": 0.05,
                "risk_proposed": 0.5,
                "novelty_score": 0.9,
                "complexity_score": 0.8,
                "quality_score": 0.8,
            },
        )
        assert r["status"] in ("pause", "escalate")
        assert "risk" in r["failing_gates"]

    async def test_f3_complexity_halt(self, mcp_session):
        """F3: Complexity below 0.5 floor → non-overridable HALT."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "F3: Overly complex proposal",
                "estimated_impact": "medium",
                "complexity_score": 0.3,
                "novelty_score": 0.9,
                "quality_score": 0.9,
            },
        )
        assert r["status"] == "halt"
        assert r["override_eligible"] is False

    async def test_f4_novelty_failure(self, mcp_session):
        """F4: Novelty below 0.84 threshold → novelty gate fails."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "F4: Novel approach",
                "estimated_impact": "medium",
                "novelty_score": 0.5,
                "complexity_score": 0.8,
                "quality_score": 0.8,
            },
        )
        assert "novelty" in r["failing_gates"]

    async def test_f5_quality_zero_subscore(self, mcp_session):
        """F5: Zero quality subscore → quality gate fails."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "F5: Quality zero subscore",
                "estimated_impact": "medium",
                "quality_score": 0.8,
                "quality_subscores": [0.9, 0.0, 0.8],
                "complexity_score": 0.8,
                "novelty_score": 0.9,
            },
        )
        assert "quality" in r["failing_gates"]

    async def test_f6_critical_impact_escalation(self, mcp_session):
        """F6: Critical impact → escalate."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "F6: Critical system change",
                "estimated_impact": "critical",
                "risk_baseline": 0.1,
                "risk_proposed": 0.1,
                "novelty_score": 0.9,
                "complexity_score": 0.9,
                "quality_score": 0.9,
            },
        )
        assert r["status"] == "escalate"

    async def test_f7_human_approval_override(self, mcp_session):
        """F7: requires_human_approval → pause or escalate."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "F7: Needs human approval",
                "estimated_impact": "medium",
                "requires_human_approval": True,
                "novelty_score": 0.9,
                "complexity_score": 0.9,
                "quality_score": 0.9,
            },
        )
        assert r["status"] in ("pause", "escalate")

    async def test_f8_quick_risk_safe(self, mcp_session):
        """F8: Low risk score → safe=true."""
        r = await call_tool(
            mcp_session,
            "aegis_quick_risk_check",
            {
                "action_description": "F8: Low risk action",
                "risk_score": 0.3,
                "threshold": 0.5,
            },
        )
        assert r["safe"] is True

    async def test_f9_quick_risk_unsafe(self, mcp_session):
        """F9: High risk score → safe=false."""
        r = await call_tool(
            mcp_session,
            "aegis_quick_risk_check",
            {
                "action_description": "F9: High risk action",
                "risk_score": 0.8,
                "threshold": 0.5,
            },
        )
        assert r["safe"] is False

    async def test_f10_scoring_guide_trading(self, mcp_session):
        """F10: Trading domain scoring guide returns valid dict."""
        r = await call_tool(
            mcp_session, "aegis_get_scoring_guide", {"domain": "trading"}
        )
        assert isinstance(r, dict)
        assert "error" not in r

    @pytest.mark.parametrize("domain", ["cicd", "moderation", "agents"])
    async def test_f11_scoring_guide_domains(self, mcp_session, domain):
        """F11: All scoring guide domains return valid structure."""
        r = await call_tool(mcp_session, "aegis_get_scoring_guide", {"domain": domain})
        assert isinstance(r, dict)
        assert "error" not in r


# ── Tier 3: Domain Stress Tests ────────────────────────────────────


class TestMCPDomainStress:
    """Tier 3: Real-world domain scenarios."""

    async def test_d1_trading_mean_reversion(self, mcp_session):
        """D1: Mean-reversion strategy — novelty should fail at 0.65."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "D1: Deploy mean-reversion strategy, Sharpe 1.8, 2yr backtest",
                "estimated_impact": "high",
                "risk_baseline": 0.15,
                "risk_proposed": 0.22,
                "profit_baseline": 1.2,
                "profit_proposed": 1.8,
                "novelty_score": 0.65,
                "complexity_score": 0.6,
                "quality_score": 0.85,
            },
        )
        assert "novelty" in r["failing_gates"]

    async def test_d2_schema_migration(self, mcp_session):
        """D2: Schema migration — high impact + risk → not proceed."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "D2: Schema migration, 5M rows, 3 services, 10-min window",
                "estimated_impact": "high",
                "risk_baseline": 0.05,
                "risk_proposed": 0.35,
                "novelty_score": 0.9,
                "complexity_score": 0.55,
                "quality_score": 0.85,
            },
        )
        assert r["status"] in ("escalate", "pause", "halt")

    async def test_d3_ai_misinformation_detection(self, mcp_session):
        """D3: AI misinformation detection — critical impact → escalate."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "D3: AI misinformation detection, 15 new rules",
                "estimated_impact": "critical",
                "risk_baseline": 0.1,
                "risk_proposed": 0.15,
                "novelty_score": 0.9,
                "complexity_score": 0.7,
                "quality_score": 0.9,
            },
        )
        assert r["status"] == "escalate"

    async def test_d4_safe_low_risk_deploy(self, mcp_session):
        """D4: Safe low-risk deployment → proceed."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "D4: Bump logging library version",
                "estimated_impact": "low",
                "risk_baseline": 0.05,
                "risk_proposed": 0.05,
                "novelty_score": 0.95,
                "complexity_score": 0.95,
                "quality_score": 0.95,
            },
        )
        assert r["status"] == "proceed"

    async def test_d5_everything_terrible(self, mcp_session):
        """D5: Everything terrible → halt."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "D5: Everything terrible",
                "estimated_impact": "high",
                "risk_baseline": 0.1,
                "risk_proposed": 0.9,
                "novelty_score": 0.1,
                "complexity_score": 0.2,
                "quality_score": 0.3,
            },
        )
        assert r["status"] == "halt"

    async def test_d6_everything_perfect(self, mcp_session):
        """D6: Everything perfect → proceed."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "D6: Everything perfect",
                "estimated_impact": "low",
                "risk_baseline": 0.05,
                "risk_proposed": 0.05,
                "novelty_score": 0.99,
                "complexity_score": 0.99,
                "quality_score": 0.99,
            },
        )
        assert r["status"] == "proceed"


# ── Tier 4: Edge Cases & Error Handling ────────────────────────────


class TestMCPEdgeCases:
    """Tier 4: Error handling and edge cases."""

    async def test_e1_boolean_risk_input(self, mcp_session):
        """E1: Boolean risk input — error or coerce (Pydantic may coerce bool→float)."""
        try:
            r = await call_tool(
                mcp_session,
                "aegis_evaluate_proposal",
                {
                    "proposal_summary": "E1: Bool risk",
                    "estimated_impact": "low",
                    "risk_baseline": True,
                },
            )
            # Either an error dict or a valid decision (Pydantic coercion)
            assert isinstance(r, dict)
        except Exception:  # noqa: S110
            pass  # MCP-level error is also acceptable

    async def test_e3_empty_proposal_summary(self, mcp_session):
        """E3: Empty proposal summary — handles gracefully."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "",
                "estimated_impact": "low",
                "novelty_score": 0.9,
                "complexity_score": 0.9,
                "quality_score": 0.9,
            },
        )
        assert isinstance(r, dict)

    async def test_e5_out_of_range_score(self, mcp_session):
        """E5: Out-of-range risk score — handles without crash."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "E5: Out of range",
                "estimated_impact": "low",
                "risk_proposed": 1.5,
                "novelty_score": 0.9,
                "complexity_score": 0.9,
                "quality_score": 0.9,
            },
        )
        assert isinstance(r, dict)

    async def test_e6_negative_values(self, mcp_session):
        """E6: Negative risk value — handles gracefully."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "E6: Negative risk",
                "estimated_impact": "low",
                "risk_baseline": -0.1,
                "novelty_score": 0.9,
                "complexity_score": 0.9,
                "quality_score": 0.9,
            },
        )
        assert isinstance(r, dict)

    async def test_e7_shadow_mode(self, mcp_session):
        """E7: Shadow mode returns shadow_result."""
        r = await call_tool(
            mcp_session,
            "aegis_evaluate_proposal",
            {
                "proposal_summary": "E7: Shadow mode test",
                "estimated_impact": "high",
                "risk_baseline": 0.1,
                "risk_proposed": 0.9,
                "complexity_score": 0.2,
                "novelty_score": 0.1,
                "quality_score": 0.3,
                "shadow_mode": True,
            },
        )
        assert "shadow_result" in r

    @pytest.mark.parametrize(
        "domain", ["trading", "cicd", "moderation", "agents", "generic"]
    )
    async def test_e8_all_scoring_guide_domains(self, mcp_session, domain):
        """E8: All scoring guide domains return without crash."""
        r = await call_tool(mcp_session, "aegis_get_scoring_guide", {"domain": domain})
        assert isinstance(r, dict)
        assert "error" not in r
