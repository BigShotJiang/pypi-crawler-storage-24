"""Tests for AEGIS Unkey Client (v2 API).

Tests cover:
- UnkeyClient initialization and error handling
- Key verification (mocked HTTP)
- Key creation (mocked HTTP)
- Key revocation (mocked HTTP)
- Key listing (mocked HTTP)
- VerifyResult and KeyInfo parsing (v2 format)
- Graceful degradation on network errors
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# VerifyResult / KeyInfo parsing tests (no httpx needed)
# ---------------------------------------------------------------------------


class TestVerifyResult:
    """Test VerifyResult parsing from API responses."""

    def test_valid_response_v2(self) -> None:
        from aegis_governance.unkey import VerifyResult

        data = {
            "valid": True,
            "identity": {"externalId": "cust_abc123", "id": "id_xxx"},
            "meta": {"tier": "professional"},
            "ratelimits": [{"remaining": 9500, "limit": 10000}],
            "code": "VALID",
        }
        r = VerifyResult.from_response(data)
        assert r.valid is True
        assert r.owner_id == "cust_abc123"
        assert r.meta["tier"] == "professional"
        assert r.remaining == 9500

    def test_valid_response_v1_compat(self) -> None:
        """v1-style flat fields still parse correctly."""
        from aegis_governance.unkey import VerifyResult

        data = {
            "valid": True,
            "ownerId": "cust_abc123",
            "meta": {"tier": "professional"},
            "remaining": 9500,
        }
        r = VerifyResult.from_response(data)
        assert r.valid is True
        assert r.owner_id == "cust_abc123"
        assert r.remaining == 9500

    def test_invalid_response(self) -> None:
        from aegis_governance.unkey import VerifyResult

        data = {
            "valid": False,
            "code": "KEY_NOT_FOUND",
        }
        r = VerifyResult.from_response(data)
        assert r.valid is False
        assert r.code == "KEY_NOT_FOUND"

    def test_error_response(self) -> None:
        from aegis_governance.unkey import VerifyResult

        data = {
            "valid": False,
            "error": {"message": "Rate limited"},
        }
        r = VerifyResult.from_response(data)
        assert r.valid is False
        assert r.error == "Rate limited"

    def test_empty_response(self) -> None:
        from aegis_governance.unkey import VerifyResult

        r = VerifyResult.from_response({})
        assert r.valid is False
        assert r.owner_id == ""

    def test_no_ratelimits_remaining_is_none(self) -> None:
        from aegis_governance.unkey import VerifyResult

        data = {"valid": True, "code": "VALID"}
        r = VerifyResult.from_response(data)
        assert r.remaining is None

    def test_empty_ratelimits_list(self) -> None:
        from aegis_governance.unkey import VerifyResult

        data = {"valid": True, "ratelimits": []}
        r = VerifyResult.from_response(data)
        assert r.remaining is None


class TestKeyInfo:
    """Test KeyInfo parsing from API responses."""

    def test_full_response_v2(self) -> None:
        from aegis_governance.unkey import KeyInfo

        data = {
            "keyId": "key_123",
            "apiId": "api_456",
            "name": "production-key",
            "identity": {"externalId": "cust_abc"},
            "meta": {"tier": "enterprise"},
            "createdAt": 1709683200000,
            "enabled": True,
        }
        k = KeyInfo.from_response(data)
        assert k.key_id == "key_123"
        assert k.api_id == "api_456"
        assert k.name == "production-key"
        assert k.owner_id == "cust_abc"
        assert k.enabled is True

    def test_full_response_v1_compat(self) -> None:
        """v1-style ownerId still parses correctly."""
        from aegis_governance.unkey import KeyInfo

        data = {
            "keyId": "key_123",
            "apiId": "api_456",
            "name": "production-key",
            "ownerId": "cust_abc",
            "meta": {"tier": "enterprise"},
            "createdAt": 1709683200000,
            "enabled": True,
        }
        k = KeyInfo.from_response(data)
        assert k.owner_id == "cust_abc"

    def test_minimal_response(self) -> None:
        from aegis_governance.unkey import KeyInfo

        k = KeyInfo.from_response({"id": "key_min"})
        assert k.key_id == "key_min"
        assert k.name == ""


# ---------------------------------------------------------------------------
# UnkeyClient initialization tests
# ---------------------------------------------------------------------------


class TestUnkeyClientInit:
    """Test UnkeyClient constructor validation."""

    def test_missing_httpx_raises(self) -> None:
        with patch("aegis_governance.unkey._HAS_HTTPX", False):
            from aegis_governance.unkey import UnkeyClient

            with pytest.raises(RuntimeError, match="httpx is required"):
                UnkeyClient(root_key="test_key")

    def test_empty_root_key_raises(self) -> None:
        from aegis_governance.unkey import UnkeyClient

        with pytest.raises(ValueError, match="root_key is required"):
            UnkeyClient(root_key="")


# ---------------------------------------------------------------------------
# UnkeyClient method tests (mocked HTTP)
# ---------------------------------------------------------------------------


class TestUnkeyClientMethods:
    """Test UnkeyClient methods with mocked httpx."""

    @pytest.fixture
    def mock_client(self) -> Any:
        from aegis_governance.unkey import UnkeyClient

        client = UnkeyClient(root_key="unkey_test_root", api_id="api_test")
        # Replace the internal httpx client with a mock
        client._client = MagicMock()
        return client

    def test_verify_key_success(self, mock_client: Any) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "data": {
                "valid": True,
                "identity": {"externalId": "cust_123"},
                "meta": {"tier": "professional"},
                "ratelimits": [{"remaining": 100, "limit": 1000}],
                "code": "VALID",
            },
        }
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        result = mock_client.verify_key("uk_live_abc")

        assert result.valid is True
        assert result.owner_id == "cust_123"
        assert result.remaining == 100
        mock_client._client.post.assert_called_once()

    def test_verify_key_invalid(self, mock_client: Any) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "data": {
                "valid": False,
                "code": "KEY_NOT_FOUND",
            },
        }
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        result = mock_client.verify_key("uk_live_invalid")
        assert result.valid is False

    def test_verify_key_network_error(self, mock_client: Any) -> None:
        mock_client._client.post.side_effect = ConnectionError("Network down")

        result = mock_client.verify_key("uk_live_abc")
        assert result.valid is False
        assert "Network down" in result.error

    def test_verify_key_no_api_id_in_body(self, mock_client: Any) -> None:
        """v2 verify does not include apiId in the request body."""
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": {"valid": True, "code": "VALID"}}
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        mock_client.verify_key("uk_live_abc")

        call_kwargs = mock_client._client.post.call_args
        body = call_kwargs[1]["json"]
        assert "apiId" not in body
        assert body["key"] == "uk_live_abc"

    def test_create_key(self, mock_client: Any) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "data": {
                "keyId": "key_new_123",
                "key": "uk_live_newkey",
            },
        }
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        info = mock_client.create_key(
            owner_id="cust_abc",
            name="test-key",
            meta={"tier": "professional"},
        )
        assert info.key_id == "key_new_123"
        assert info.owner_id == "cust_abc"

    def test_create_key_uses_external_id(self, mock_client: Any) -> None:
        """v2 uses externalId instead of ownerId."""
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": {"keyId": "key_ext"}}
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        mock_client.create_key(owner_id="cust_xyz")

        call_kwargs = mock_client._client.post.call_args
        body = call_kwargs[1]["json"]
        assert body["externalId"] == "cust_xyz"
        assert "ownerId" not in body

    def test_create_key_with_ratelimit(self, mock_client: Any) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": {"keyId": "key_rl"}}
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        info = mock_client.create_key(
            owner_id="cust_abc",
            ratelimit={"type": "fast", "limit": 100, "duration": 60000},
        )
        assert info.key_id == "key_rl"

        # Verify ratelimits array format (v2) with autoApply
        call_kwargs = mock_client._client.post.call_args
        body = call_kwargs[1]["json"]
        assert "ratelimits" in body
        assert isinstance(body["ratelimits"], list)
        assert body["ratelimits"][0]["limit"] == 100
        assert body["ratelimits"][0]["autoApply"] is True

    def test_revoke_key_success(self, mock_client: Any) -> None:
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        assert mock_client.revoke_key("key_123") is True

    def test_revoke_key_failure(self, mock_client: Any) -> None:
        mock_client._client.post.side_effect = RuntimeError("API error")

        assert mock_client.revoke_key("key_123") is False

    def test_list_keys(self, mock_client: Any) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "data": {
                "keys": [
                    {
                        "keyId": "k1",
                        "apiId": "api_test",
                        "identity": {"externalId": "cust_abc"},
                    },
                    {
                        "keyId": "k2",
                        "apiId": "api_test",
                        "identity": {"externalId": "cust_abc"},
                    },
                ],
            },
        }
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        keys = mock_client.list_keys(owner_id="cust_abc")
        assert len(keys) == 2
        assert keys[0].key_id == "k1"

    def test_list_keys_uses_post(self, mock_client: Any) -> None:
        """v2 list_keys uses POST, not GET."""
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": {"keys": []}}
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        mock_client.list_keys(owner_id="cust_abc")
        mock_client._client.post.assert_called_once()

    def test_list_keys_empty(self, mock_client: Any) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": {"keys": []}}
        mock_resp.raise_for_status = MagicMock()
        mock_client._client.post.return_value = mock_resp

        assert mock_client.list_keys() == []

    def test_list_keys_network_error(self, mock_client: Any) -> None:
        mock_client._client.post.side_effect = ConnectionError("Timeout")

        assert mock_client.list_keys() == []

    def test_context_manager(self) -> None:
        from aegis_governance.unkey import UnkeyClient

        client = UnkeyClient(root_key="test", api_id="test")
        client._client = MagicMock()

        with client as c:
            assert c is client

        client._client.close.assert_called_once()
