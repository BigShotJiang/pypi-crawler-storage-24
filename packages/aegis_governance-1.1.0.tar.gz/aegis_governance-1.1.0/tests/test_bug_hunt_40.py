"""Regression tests for Bug Hunt #40.

BH40-M1: AFABridge quality_subscores empty-list bypass (pre-existing, kept)
BH40-M2: BatchHTTPSink.stop() reads self._thread outside lock — lock-before-join race
BH40-M3: validate_normalized missing bool guard — bool-is-int bypass for normalized scores
BH40-M4: _parse_mcp_rate_limit checks isinstance(value, float) on original value — string
         fractional inputs like "3.5" silently truncated to 3
BH40-L1: GateEvaluator.__init__ accepts negative threshold values — trivially disables gates
BH40-L2: _parse_kl_drift_dict checks isinstance(v, float) on original value — same string
         fractional truncation as BH40-M4
BH40-L3: mcp_server.run_server() stdio size guard uses len(line) char count, not byte count
BH40-L4: AFABridge.get_decision_history() uses truthy check for agent_id — empty string ""
         silently bypasses filter and returns all history
BH40-L5: DEKRotator.get_decryptor() and list_versions() read self._deks without lock
"""

import threading
import time
from typing import Optional
from unittest.mock import MagicMock, patch

import pytest

from engine.utility import UtilityResult
from integration.afa_bridge import (
    AFABridge,
    DecisionOutcome,
    DecisionRequest,
    DecisionType,
)

# Shared utility result for gate evaluation tests
_PASSING_UTILITY = UtilityResult(
    raw=1.0,
    variance=0.01,
    lcb=1.0,
    components=None,
    decision_path="INVESTMENT",
)


# ---------------------------------------------------------------------------
# BH40-M1: AFABridge quality_subscores empty-list bypass (pre-existing)
# ---------------------------------------------------------------------------


class TestBH40AFABridgeQualitySubscoresEmpty:
    """Regression: explicit empty quality_subscores must fail closed."""

    def test_proposal_with_empty_quality_subscores_fails_quality_gate(self) -> None:
        """quality_subscores=[] must not be replaced with default passing subscores."""
        bridge = AFABridge()
        request = DecisionRequest(
            request_id="bh40-empty-subscores",
            decision_type=DecisionType.PROPOSAL,
            agent_id="agent-1",
            context={
                "risk_baseline": 0.10,
                "risk_proposed": 0.10,
                "profit_baseline": 0.10,
                "profit_proposed": 0.10,
                "novelty_score": 1.0,
                "complexity_score": 0.90,
                "quality_score": 0.95,
                "quality_subscores": [],
                "utility_result": UtilityResult(
                    raw=1.0,
                    variance=0.01,
                    lcb=1.0,
                    components=None,
                    decision_path="INVESTMENT",
                ),
            },
        )

        response = bridge.request_decision(request)

        assert response.outcome == DecisionOutcome.ESCALATED
        assert "quality" in response.gates_failed
        assert "quality" not in response.gates_passed


# ---------------------------------------------------------------------------
# BH40-M2: BatchHTTPSink.stop() lock-before-join race
# ---------------------------------------------------------------------------


class TestBH40M2BatchHTTPSinkStopRace:
    """BatchHTTPSink.stop() must extract self._thread under lock before joining."""

    def test_stop_clears_thread_ref_under_lock(self) -> None:
        """stop() must set _thread=None under lock, before join."""
        try:
            from telemetry.emitter import BatchHTTPSink
        except ImportError:
            pytest.skip("telemetry.emitter not available")

        sink = BatchHTTPSink(
            "http://localhost:9999/events", batch_size=10, allow_insecure=True
        )
        assert sink._thread is None
        sink.start()
        assert sink._thread is not None

        sink.stop()
        assert sink._thread is None

    def test_stop_is_idempotent_without_start(self) -> None:
        """stop() on a never-started sink must not crash."""
        try:
            from telemetry.emitter import BatchHTTPSink
        except ImportError:
            pytest.skip("telemetry.emitter not available")

        sink = BatchHTTPSink(
            "http://localhost:9999/events", batch_size=10, allow_insecure=True
        )
        sink.stop()  # must not raise
        assert sink._thread is None

    def test_thread_cleared_before_join(self) -> None:
        """_thread must be None when join() is called (cleared under lock, not after)."""
        try:
            from telemetry.emitter import BatchHTTPSink
        except ImportError:
            pytest.skip("telemetry.emitter not available")

        thread_ref_at_join: list[Optional[threading.Thread]] = []
        original_join = threading.Thread.join

        def patched_join(
            self_thread: threading.Thread, timeout: Optional[float] = None
        ) -> None:
            thread_ref_at_join.append(sink._thread)
            original_join(self_thread, timeout=timeout)

        sink = BatchHTTPSink(
            "http://localhost:9999/events", batch_size=10, allow_insecure=True
        )
        sink.start()

        with patch.object(threading.Thread, "join", patched_join):
            sink.stop()

        assert thread_ref_at_join, "join should have been called once"
        assert (
            thread_ref_at_join[0] is None
        ), "self._thread must be None when join() is called — must be cleared under lock"


# ---------------------------------------------------------------------------
# BH40-M3: validate_normalized missing bool guard
# ---------------------------------------------------------------------------


class TestBH40M3ValidateNormalizedBoolGuard:
    """validate_normalized must reject bool inputs like all other validators."""

    def test_true_raises_type_error(self) -> None:
        from engine.validation import validate_normalized

        with pytest.raises(TypeError, match="bool"):
            validate_normalized("score", True)

    def test_false_raises_type_error(self) -> None:
        from engine.validation import validate_normalized

        with pytest.raises(TypeError, match="bool"):
            validate_normalized("score", False)

    def test_float_zero_accepted(self) -> None:
        from engine.validation import validate_normalized

        validate_normalized("score", 0.0)  # no exception

    def test_float_one_accepted(self) -> None:
        from engine.validation import validate_normalized

        validate_normalized("score", 1.0)  # no exception

    def test_out_of_range_raises_value_error(self) -> None:
        from engine.validation import validate_normalized

        with pytest.raises(ValueError):
            validate_normalized("score", 1.5)

    def test_gate_evaluator_rejects_bool_novelty_score(self) -> None:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator()
        with pytest.raises(TypeError, match="bool"):
            evaluator.evaluate_all(
                risk_baseline=1.0,
                risk_proposed=0.8,
                profit_baseline=1.0,
                profit_proposed=1.2,
                novelty_score=True,  # bool — must raise TypeError
                complexity_score=0.8,
                quality_score=0.9,
                quality_subscores=[0.9],
                utility_result=_PASSING_UTILITY,
            )

    def test_gate_evaluator_rejects_bool_complexity_score(self) -> None:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator()
        with pytest.raises(TypeError, match="bool"):
            evaluator.evaluate_all(
                risk_baseline=1.0,
                risk_proposed=0.8,
                profit_baseline=1.0,
                profit_proposed=1.2,
                novelty_score=0.9,
                complexity_score=False,  # bool — must raise TypeError
                quality_score=0.9,
                quality_subscores=[0.9],
                utility_result=_PASSING_UTILITY,
            )

    def test_gate_evaluator_rejects_bool_quality_score(self) -> None:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator()
        with pytest.raises(TypeError, match="bool"):
            evaluator.evaluate_all(
                risk_baseline=1.0,
                risk_proposed=0.8,
                profit_baseline=1.0,
                profit_proposed=1.2,
                novelty_score=0.9,
                complexity_score=0.8,
                quality_score=True,  # bool — must raise TypeError
                quality_subscores=[0.9],
                utility_result=_PASSING_UTILITY,
            )

    def test_gate_evaluator_rejects_bool_in_subscores_list(self) -> None:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator()
        with pytest.raises(TypeError, match="bool"):
            evaluator.evaluate_all(
                risk_baseline=1.0,
                risk_proposed=0.8,
                profit_baseline=1.0,
                profit_proposed=1.2,
                novelty_score=0.9,
                complexity_score=0.8,
                quality_score=0.9,
                quality_subscores=[0.9, False],  # bool element — must raise TypeError
                utility_result=_PASSING_UTILITY,
            )


# ---------------------------------------------------------------------------
# BH40-M4: _parse_mcp_rate_limit string fractional truncation
# ---------------------------------------------------------------------------


class TestBH40M4McpRateLimitStringFractional:
    """_parse_mcp_rate_limit must reject fractional string inputs like "3.5"."""

    def test_string_fractional_raises_type_error(self) -> None:
        from config import AegisConfig

        with pytest.raises(TypeError, match="integer"):
            AegisConfig._parse_mcp_rate_limit("3.5")

    def test_string_integer_accepted(self) -> None:
        from config import AegisConfig

        result = AegisConfig._parse_mcp_rate_limit("60")
        assert result == 60

    def test_float_fractional_raises_type_error(self) -> None:
        from config import AegisConfig

        with pytest.raises(TypeError, match="integer"):
            AegisConfig._parse_mcp_rate_limit(3.5)

    def test_from_dict_string_fractional_raises(self) -> None:
        from config import AegisConfig

        with pytest.raises(TypeError, match="integer"):
            AegisConfig.from_dict({"mcp_rate_limit": "3.5"})

    def test_from_dict_string_integer_accepted(self) -> None:
        from config import AegisConfig

        cfg = AegisConfig.from_dict({"mcp_rate_limit": "30"})
        assert cfg.mcp_rate_limit == 30


# ---------------------------------------------------------------------------
# BH40-L1: GateEvaluator negative threshold values disable governance gates
# ---------------------------------------------------------------------------


class TestBH40L1GateEvaluatorNegativeThresholds:
    """GateEvaluator must reject negative values for governance-critical thresholds."""

    def test_negative_complexity_floor_raises(self) -> None:
        from engine.gates import GateEvaluator

        with pytest.raises(ValueError, match="non-negative"):
            GateEvaluator(complexity_floor=-1.0)

    def test_negative_novelty_threshold_raises(self) -> None:
        from engine.gates import GateEvaluator

        with pytest.raises(ValueError, match="non-negative"):
            GateEvaluator(novelty_threshold=-0.5)

    def test_negative_quality_min_score_raises(self) -> None:
        from engine.gates import GateEvaluator

        with pytest.raises(ValueError, match="non-negative"):
            GateEvaluator(quality_min_score=-0.1)

    def test_negative_novelty_n0_raises(self) -> None:
        from engine.gates import GateEvaluator

        with pytest.raises(ValueError, match="non-negative"):
            GateEvaluator(novelty_N0=-0.1)

    def test_zero_complexity_floor_accepted(self) -> None:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator(complexity_floor=0.0)
        assert evaluator.complexity_floor == 0.0

    def test_zero_novelty_threshold_accepted(self) -> None:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator(novelty_threshold=0.0)
        assert evaluator.novelty_threshold == 0.0

    def test_negative_utility_threshold_still_accepted(self) -> None:
        """utility_threshold may legitimately be negative for negative-utility proposals."""
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator(utility_threshold=-1.0)
        assert evaluator.utility_threshold == -1.0


# ---------------------------------------------------------------------------
# BH40-L2: _parse_kl_drift_dict string fractional truncation for window_days
# ---------------------------------------------------------------------------


class TestBH40L2KlDriftDictStringFractional:
    """_parse_kl_drift_dict must reject fractional string inputs for window_days."""

    def test_string_fractional_window_days_raises(self) -> None:
        from config import AegisConfig

        with pytest.raises(TypeError, match="integer"):
            AegisConfig._parse_kl_drift_dict({"window_days": "30.7"})

    def test_string_integer_window_days_accepted(self) -> None:
        from config import AegisConfig

        result = AegisConfig._parse_kl_drift_dict({"window_days": "30"})
        assert result["window_days"] == 30

    def test_float_fractional_window_days_raises(self) -> None:
        from config import AegisConfig

        with pytest.raises(TypeError, match="integer"):
            AegisConfig._parse_kl_drift_dict({"window_days": 30.7})

    def test_from_dict_string_fractional_window_days_raises(self) -> None:
        from config import AegisConfig

        with pytest.raises(TypeError, match="integer"):
            AegisConfig.from_dict({"kl_drift": {"window_days": "30.7"}})

    def test_non_finite_window_days_float_raises_value_error(self) -> None:
        """Non-finite float (nan, inf) must raise ValueError (not TypeError)."""
        from config import AegisConfig

        with pytest.raises(ValueError):
            AegisConfig._parse_kl_drift_dict({"window_days": float("nan")})

        with pytest.raises((ValueError, OverflowError)):
            AegisConfig._parse_kl_drift_dict({"window_days": float("inf")})


# ---------------------------------------------------------------------------
# BH40-L3: mcp_server.run_server() stdio size guard uses char count, not byte count
# ---------------------------------------------------------------------------


class TestBH40L3McpServerSizeGuardByteCount:
    """run_server() size guard — OBSOLETE after MCP consolidation.

    The custom JSON-RPC stdio loop (run_server) was removed in favour of
    FastMCP's built-in transport, which handles request size limits
    internally.  These tests are retained as placeholders so the BH40-L3
    bug-hunt ID remains discoverable.
    """

    def test_placeholder(self) -> None:
        """Placeholder: FastMCP handles transport size limits internally."""


# ---------------------------------------------------------------------------
# BH40-L4: AFABridge.get_decision_history() truthy check bypasses empty-string filter
# ---------------------------------------------------------------------------


class TestBH40L4AFABridgeDecisionHistoryEmptyString:
    """get_decision_history(agent_id="") must return [] not full history."""

    def test_empty_string_agent_id_returns_empty(self) -> None:
        bridge = AFABridge()
        fake_decision = MagicMock()
        fake_decision.agent_id = "agent-1"
        bridge.decision_history.append(fake_decision)

        result = bridge.get_decision_history(agent_id="")
        assert result == [], (
            f"get_decision_history(agent_id='') returned {result!r}; "
            "empty string must filter to no matches, not bypass the filter"
        )

    def test_none_agent_id_returns_all_history(self) -> None:
        bridge = AFABridge()
        fake_decision = MagicMock()
        fake_decision.agent_id = "agent-1"
        bridge.decision_history.append(fake_decision)

        result = bridge.get_decision_history(agent_id=None)
        assert len(result) == 1

    def test_matching_agent_id_filters_correctly(self) -> None:
        bridge = AFABridge()
        d1 = MagicMock()
        d1.agent_id = "agent-1"
        d2 = MagicMock()
        d2.agent_id = "agent-2"
        bridge.decision_history.extend([d1, d2])

        result = bridge.get_decision_history(agent_id="agent-1")
        assert len(result) == 1
        assert result[0].agent_id == "agent-1"


# ---------------------------------------------------------------------------
# BH40-L5: DEKRotator.get_decryptor() and list_versions() without lock
# ---------------------------------------------------------------------------


class TestBH40L5DEKRotatorReadersLocked:
    """DEKRotator.get_decryptor() and list_versions() must acquire self._lock."""

    def test_get_decryptor_source_uses_lock(self) -> None:
        """get_decryptor() source must contain 'with self._lock:' before the _deks.get call."""
        import inspect

        try:
            from telemetry.encryption import DEKRotator
        except ImportError:
            pytest.skip("telemetry.encryption not available")

        source = inspect.getsource(DEKRotator.get_decryptor)
        assert (
            "with self._lock:" in source
        ), "get_decryptor() must acquire self._lock before reading self._deks"

    def test_list_versions_source_uses_lock(self) -> None:
        """list_versions() source must contain 'with self._lock:' before the _deks.keys call."""
        import inspect

        try:
            from telemetry.encryption import DEKRotator
        except ImportError:
            pytest.skip("telemetry.encryption not available")

        source = inspect.getsource(DEKRotator.list_versions)
        assert (
            "with self._lock:" in source
        ), "list_versions() must acquire self._lock before reading self._deks"

    def test_get_decryptor_returns_none_for_missing_version(self) -> None:
        """get_decryptor() must return None for an unknown version (no crash)."""
        try:
            from telemetry.encryption import DEKRotator
        except ImportError:
            pytest.skip("telemetry.encryption not available")

        try:
            rotator = DEKRotator()
        except RuntimeError as e:
            pytest.skip(str(e))  # liboqs-python not installed
        result = rotator.get_decryptor("nonexistent-version")
        assert result is None

    def test_list_versions_returns_list(self) -> None:
        """list_versions() must return a plain list."""
        try:
            from telemetry.encryption import DEKRotator
        except ImportError:
            pytest.skip("telemetry.encryption not available")

        try:
            rotator = DEKRotator()
        except RuntimeError as e:
            pytest.skip(str(e))  # liboqs-python not installed
        result = rotator.list_versions()
        assert isinstance(result, list)

    def test_list_versions_concurrent_safe(self) -> None:
        """Concurrent list_versions() and generate_dek() calls must not raise."""
        try:
            from telemetry.encryption import DEKRotator
        except ImportError:
            pytest.skip("telemetry.encryption not available")
        try:
            from cryptography.hazmat.primitives.asymmetric.x25519 import (
                X25519PrivateKey,  # noqa: F401
            )
        except ImportError:
            pytest.skip("cryptography not available")

        import uuid

        try:
            rotator = DEKRotator()
        except RuntimeError as e:
            pytest.skip(str(e))  # liboqs-python not installed
        errors: list[Exception] = []

        def writer() -> None:
            for _ in range(10):
                try:
                    # Use unique version to avoid same-day collision ValueError
                    rotator.generate_dek(version=f"dek-test-{uuid.uuid4().hex[:8]}")
                except Exception as e:
                    errors.append(e)
                time.sleep(0.001)

        def reader() -> None:
            for _ in range(30):
                try:
                    versions = rotator.list_versions()
                    assert isinstance(versions, list)
                except Exception as e:
                    errors.append(e)
                time.sleep(0.001)

        threads = [
            threading.Thread(target=writer),
            threading.Thread(target=reader),
            threading.Thread(target=reader),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert not errors, f"Thread-safety errors: {errors}"
