"""Tests for aegis_governance.middleware module.

Comprehensive tests covering:
- validate_float: NaN/Inf rejection, bool guarding, None/absent defaults
- validate_bool: strict bool validation, non-bool rejection
- validate_quality_subscores: list validation, mixed types, edge cases
- validate_drift_baseline: list validation, None/empty handling
- validate_str: string extraction, non-string fallback
- build_pcw_context: full PCWContext construction from raw dicts
- RateLimiter: token bucket behavior, thread safety
- AuditMiddleware: delegation to pcw_decide, audit event production
- AuditEvent: dataclass construction and serialization
- safe_round: finite and non-finite value handling
- _hash_context: deterministic hashing
- Facade re-exports: all middleware symbols accessible via aegis_governance
"""

import importlib
import sys
import threading
import time
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from aegis_governance.middleware import (
    AuditEvent,
    AuditMiddleware,
    RateLimiter,
    _hash_context,
    build_pcw_context,
    safe_round,
    validate_bool,
    validate_drift_baseline,
    validate_float,
    validate_quality_subscores,
    validate_str,
)

# Force the module object into sys.modules (not the __init__.py re-export).
# integration.__init__ re-exports pcw_decide as a function, which shadows
# the module in attribute lookups.  Using sys.modules gives us the actual
# module so @patch.object can replace its pcw_decide attribute.
importlib.import_module("integration.pcw_decide")
_pcw_module = sys.modules["integration.pcw_decide"]
from integration.pcw_decide import PCWContext, PCWPhase, PCWStatus  # noqa: E402

# ---------------------------------------------------------------------------
# validate_float
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestValidateFloat:
    """Tests for validate_float() — NaN/Inf rejection and bool guarding."""

    def test_validate_float_returns_value_when_present(self):
        assert validate_float({"x": 1.5}, "x", 0.0) == 1.5

    def test_validate_float_returns_default_when_absent(self):
        assert validate_float({}, "x", 3.14) == 3.14

    def test_validate_float_returns_default_when_none(self):
        assert validate_float({"x": None}, "x", 2.0) == 2.0

    def test_validate_float_preserves_zero(self):
        """Zero is a legitimate falsy value and must not be replaced by default."""
        assert validate_float({"x": 0}, "x", 99.9) == 0.0

    def test_validate_float_preserves_zero_float(self):
        assert validate_float({"x": 0.0}, "x", 99.9) == 0.0

    def test_validate_float_converts_int(self):
        assert validate_float({"x": 5}, "x", 0.0) == 5.0

    def test_validate_float_converts_string_numeric(self):
        assert validate_float({"x": "3.14"}, "x", 0.0) == 3.14

    def test_validate_float_rejects_nan(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_float({"x": float("nan")}, "x", 0.0)

    def test_validate_float_rejects_inf(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_float({"x": float("inf")}, "x", 0.0)

    def test_validate_float_rejects_neg_inf(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_float({"x": float("-inf")}, "x", 0.0)

    def test_validate_float_rejects_bool_true(self):
        with pytest.raises(TypeError, match="got bool"):
            validate_float({"x": True}, "x", 0.0)

    def test_validate_float_rejects_bool_false(self):
        with pytest.raises(TypeError, match="got bool"):
            validate_float({"x": False}, "x", 0.0)

    def test_validate_float_rejects_non_numeric_string(self):
        with pytest.raises(ValueError):
            validate_float({"x": "hello"}, "x", 0.0)

    def test_validate_float_negative_value(self):
        assert validate_float({"x": -1.5}, "x", 0.0) == -1.5

    def test_validate_float_very_large_value(self):
        assert validate_float({"x": 1e300}, "x", 0.0) == 1e300

    def test_validate_float_very_small_value(self):
        assert validate_float({"x": 1e-300}, "x", 0.0) == 1e-300

    def test_validate_float_error_includes_key_name(self):
        """Error messages should include the argument name for debugging."""
        with pytest.raises(TypeError, match="risk_proposed"):
            validate_float({"risk_proposed": True}, "risk_proposed", 0.0)

    def test_validate_float_nan_string(self):
        """String 'nan' converts to float NaN, which should be rejected."""
        with pytest.raises(ValueError, match="must be finite"):
            validate_float({"x": "nan"}, "x", 0.0)

    def test_validate_float_inf_string(self):
        """String 'inf' converts to float inf, which should be rejected."""
        with pytest.raises(ValueError, match="must be finite"):
            validate_float({"x": "inf"}, "x", 0.0)


# ---------------------------------------------------------------------------
# validate_bool
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestValidateBool:
    """Tests for validate_bool() — strict bool validation."""

    def test_validate_bool_returns_true(self):
        assert validate_bool({"x": True}, "x", False) is True

    def test_validate_bool_returns_false(self):
        assert validate_bool({"x": False}, "x", True) is False

    def test_validate_bool_returns_default_when_absent(self):
        assert validate_bool({}, "x", True) is True

    def test_validate_bool_returns_default_when_none(self):
        assert validate_bool({"x": None}, "x", True) is True

    def test_validate_bool_rejects_int_1(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            validate_bool({"x": 1}, "x", False)

    def test_validate_bool_rejects_int_0(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            validate_bool({"x": 0}, "x", False)

    def test_validate_bool_rejects_string_true(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            validate_bool({"x": "true"}, "x", False)

    def test_validate_bool_rejects_string_false(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            validate_bool({"x": "false"}, "x", False)

    def test_validate_bool_rejects_float(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            validate_bool({"x": 1.0}, "x", False)

    def test_validate_bool_rejects_list(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            validate_bool({"x": []}, "x", False)

    def test_validate_bool_error_includes_key_name(self):
        with pytest.raises(TypeError, match="requires_human_approval"):
            validate_bool(
                {"requires_human_approval": "yes"}, "requires_human_approval", False
            )

    def test_validate_bool_error_includes_type_name(self):
        with pytest.raises(TypeError, match="str"):
            validate_bool({"x": "yes"}, "x", False)


# ---------------------------------------------------------------------------
# validate_quality_subscores
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestValidateQualitySubscores:
    """Tests for validate_quality_subscores() — subscore list validation."""

    def test_valid_subscores(self):
        result = validate_quality_subscores({"quality_subscores": [0.8, 0.9, 0.7]})
        assert result == [0.8, 0.9, 0.7]

    def test_default_when_absent(self):
        result = validate_quality_subscores({})
        assert result == [0.7, 0.7, 0.7]

    def test_default_when_not_list(self):
        result = validate_quality_subscores({"quality_subscores": "not-a-list"})
        assert result == [0.7, 0.7, 0.7]

    def test_default_when_none(self):
        result = validate_quality_subscores({"quality_subscores": None})
        assert result == [0.7, 0.7, 0.7]

    def test_default_when_dict(self):
        result = validate_quality_subscores({"quality_subscores": {"a": 1}})
        assert result == [0.7, 0.7, 0.7]

    def test_empty_list_returns_default(self):
        """Empty list is falsy, so not-a-list check kicks in and returns default."""
        result = validate_quality_subscores({"quality_subscores": []})
        # Empty list: isinstance([], list) is True, loop produces nothing,
        # validated is empty, raw=[] is falsy so `raw and not saw_non_null`
        # is False, so we reach `return []`
        assert result == []

    def test_all_none_list_returns_default(self):
        """All-null list should return default subscores."""
        result = validate_quality_subscores({"quality_subscores": [None, None, None]})
        assert result == [0.7, 0.7, 0.7]

    def test_mixed_none_and_values(self):
        """None values are skipped, valid values kept."""
        result = validate_quality_subscores(
            {"quality_subscores": [None, 0.8, None, 0.6]}
        )
        assert result == [0.8, 0.6]

    def test_single_subscore(self):
        result = validate_quality_subscores({"quality_subscores": [0.9]})
        assert result == [0.9]

    def test_rejects_bool_in_subscores(self):
        with pytest.raises(TypeError, match="got bool"):
            validate_quality_subscores({"quality_subscores": [0.7, True, 0.8]})

    def test_rejects_nan_in_subscores(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_quality_subscores({"quality_subscores": [0.7, float("nan")]})

    def test_rejects_inf_in_subscores(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_quality_subscores({"quality_subscores": [float("inf")]})

    def test_rejects_neg_inf_in_subscores(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_quality_subscores({"quality_subscores": [float("-inf")]})

    def test_rejects_non_numeric_string(self):
        with pytest.raises(ValueError, match="must be numeric"):
            validate_quality_subscores({"quality_subscores": ["hello"]})

    def test_accepts_numeric_strings(self):
        result = validate_quality_subscores({"quality_subscores": ["0.7", "0.8"]})
        assert result == [0.7, 0.8]

    def test_accepts_integers(self):
        result = validate_quality_subscores({"quality_subscores": [1, 0]})
        assert result == [1.0, 0.0]

    def test_negative_subscores_accepted(self):
        """Negative values are not rejected by the validator (range is domain concern)."""
        result = validate_quality_subscores({"quality_subscores": [-0.5, 0.5]})
        assert result == [-0.5, 0.5]


# ---------------------------------------------------------------------------
# validate_drift_baseline
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestValidateDriftBaseline:
    """Tests for validate_drift_baseline() — drift baseline data validation."""

    def test_valid_baseline(self):
        result = validate_drift_baseline({"drift_baseline_data": [0.1, 0.2, 0.3]})
        assert result == [0.1, 0.2, 0.3]

    def test_returns_none_when_absent(self):
        assert validate_drift_baseline({}) is None

    def test_returns_none_when_none(self):
        assert validate_drift_baseline({"drift_baseline_data": None}) is None

    def test_returns_none_when_not_list(self):
        assert validate_drift_baseline({"drift_baseline_data": "not-a-list"}) is None

    def test_returns_none_when_empty_list(self):
        assert validate_drift_baseline({"drift_baseline_data": []}) is None

    def test_filters_none_values(self):
        result = validate_drift_baseline({"drift_baseline_data": [0.1, None, 0.3]})
        assert result == [0.1, 0.3]

    def test_all_none_returns_none(self):
        result = validate_drift_baseline({"drift_baseline_data": [None, None]})
        assert result is None

    def test_rejects_bool_in_baseline(self):
        with pytest.raises(TypeError, match="got bool"):
            validate_drift_baseline({"drift_baseline_data": [0.1, True]})

    def test_rejects_nan_in_baseline(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_drift_baseline({"drift_baseline_data": [float("nan")]})

    def test_rejects_inf_in_baseline(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_drift_baseline({"drift_baseline_data": [float("inf")]})

    def test_rejects_neg_inf_in_baseline(self):
        with pytest.raises(ValueError, match="must be finite"):
            validate_drift_baseline({"drift_baseline_data": [float("-inf")]})

    def test_single_value(self):
        result = validate_drift_baseline({"drift_baseline_data": [0.5]})
        assert result == [0.5]

    def test_negative_values_accepted(self):
        result = validate_drift_baseline({"drift_baseline_data": [-0.1, -0.2]})
        assert result == [-0.1, -0.2]

    def test_zero_values_accepted(self):
        result = validate_drift_baseline({"drift_baseline_data": [0.0, 0.0]})
        assert result == [0.0, 0.0]


# ---------------------------------------------------------------------------
# validate_str
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestValidateStr:
    """Tests for validate_str() — string extraction with defaults."""

    def test_returns_value_when_present(self):
        assert validate_str({"x": "hello"}, "x", "default") == "hello"

    def test_returns_default_when_absent(self):
        assert validate_str({}, "x", "default") == "default"

    def test_returns_default_when_none(self):
        assert validate_str({"x": None}, "x", "default") == "default"

    def test_returns_default_when_empty_string(self):
        assert validate_str({"x": ""}, "x", "default") == "default"

    def test_returns_default_when_not_string(self):
        assert validate_str({"x": 42}, "x", "default") == "default"

    def test_returns_default_when_bool(self):
        assert validate_str({"x": True}, "x", "default") == "default"

    def test_returns_default_when_list(self):
        assert validate_str({"x": [1, 2]}, "x", "default") == "default"

    def test_whitespace_string_is_valid(self):
        """Non-empty whitespace string is still a valid string."""
        assert validate_str({"x": "  "}, "x", "default") == "  "


# ---------------------------------------------------------------------------
# build_pcw_context
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestBuildPcwContext:
    """Tests for build_pcw_context() — PCWContext construction from raw dicts."""

    def test_minimal_args_produce_valid_context(self):
        ctx = build_pcw_context({})
        assert isinstance(ctx, PCWContext)
        assert ctx.agent_id == "sdk-caller"
        assert ctx.phase == PCWPhase.PLAN
        assert ctx.risk_baseline == 0.0
        assert ctx.risk_proposed == 0.0
        assert ctx.profit_baseline == 0.0
        assert ctx.profit_proposed == 0.0
        assert ctx.novelty_score == 0.5
        assert ctx.complexity_score == 0.5
        assert ctx.quality_score == 0.7
        assert ctx.quality_subscores == [0.7, 0.7, 0.7]
        assert ctx.requires_human_approval is False
        assert ctx.time_sensitive is False
        assert ctx.reversible is True
        assert ctx.metadata == {}
        assert ctx.proposal_summary == ""
        assert ctx.estimated_impact == "medium"

    def test_full_args(self):
        args = {
            "phase": "commit",
            "agent_id": "test-agent",
            "session_id": "sess-001",
            "proposal_summary": "Add caching layer",
            "estimated_impact": "high",
            "risk_baseline": 0.1,
            "risk_proposed": 0.3,
            "profit_baseline": 1000.0,
            "profit_proposed": 1500.0,
            "novelty_score": 0.8,
            "complexity_score": 0.6,
            "quality_score": 0.9,
            "quality_subscores": [0.9, 0.85, 0.95],
            "requires_human_approval": True,
            "time_sensitive": True,
            "reversible": False,
            "metadata": {"source": "test"},
        }
        ctx = build_pcw_context(args)
        assert ctx.phase == PCWPhase.COMMIT
        assert ctx.agent_id == "test-agent"
        assert ctx.session_id == "sess-001"
        assert ctx.proposal_summary == "Add caching layer"
        assert ctx.estimated_impact == "high"
        assert ctx.risk_baseline == 0.1
        assert ctx.risk_proposed == 0.3
        assert ctx.profit_baseline == 1000.0
        assert ctx.profit_proposed == 1500.0
        assert ctx.novelty_score == 0.8
        assert ctx.complexity_score == 0.6
        assert ctx.quality_score == 0.9
        assert ctx.quality_subscores == [0.9, 0.85, 0.95]
        assert ctx.requires_human_approval is True
        assert ctx.time_sensitive is True
        assert ctx.reversible is False
        assert ctx.metadata == {"source": "test"}

    def test_phase_plan(self):
        ctx = build_pcw_context({"phase": "plan"})
        assert ctx.phase == PCWPhase.PLAN

    def test_phase_work(self):
        ctx = build_pcw_context({"phase": "work"})
        assert ctx.phase == PCWPhase.WORK

    def test_phase_commit(self):
        ctx = build_pcw_context({"phase": "commit"})
        assert ctx.phase == PCWPhase.COMMIT

    def test_phase_case_insensitive(self):
        ctx = build_pcw_context({"phase": "PLAN"})
        assert ctx.phase == PCWPhase.PLAN

    def test_phase_unknown_defaults_to_plan(self):
        ctx = build_pcw_context({"phase": "unknown"})
        # Defaults to the first value in the phase map (PLAN)
        assert ctx.phase == PCWPhase.PLAN

    def test_phase_non_string_defaults(self):
        ctx = build_pcw_context({"phase": 42})
        assert ctx.phase == PCWPhase.PLAN

    def test_risk_score_alias(self):
        """risk_score should be used as fallback for risk_proposed."""
        ctx = build_pcw_context({"risk_score": 0.5})
        assert ctx.risk_proposed == 0.5

    def test_risk_proposed_takes_priority_over_risk_score(self):
        """risk_proposed should take priority over risk_score alias."""
        ctx = build_pcw_context({"risk_proposed": 0.3, "risk_score": 0.9})
        assert ctx.risk_proposed == 0.3

    def test_proposal_summary_null_becomes_empty_string(self):
        ctx = build_pcw_context({"proposal_summary": None})
        assert ctx.proposal_summary == ""

    def test_estimated_impact_null_becomes_medium(self):
        ctx = build_pcw_context({"estimated_impact": None})
        assert ctx.estimated_impact == "medium"

    def test_metadata_null_becomes_empty_dict(self):
        ctx = build_pcw_context({"metadata": None})
        assert ctx.metadata == {}

    def test_metadata_non_dict_raises_typeerror(self):
        with pytest.raises(TypeError, match="metadata must be a JSON object"):
            build_pcw_context({"metadata": "not-a-dict"})

    def test_metadata_list_raises_typeerror(self):
        with pytest.raises(TypeError, match="metadata must be a JSON object"):
            build_pcw_context({"metadata": [1, 2, 3]})

    def test_nan_risk_proposed_raises(self):
        with pytest.raises(ValueError, match="must be finite"):
            build_pcw_context({"risk_proposed": float("nan")})

    def test_inf_profit_proposed_raises(self):
        with pytest.raises(ValueError, match="must be finite"):
            build_pcw_context({"profit_proposed": float("inf")})

    def test_bool_risk_baseline_raises(self):
        with pytest.raises(TypeError, match="got bool"):
            build_pcw_context({"risk_baseline": True})

    def test_bool_requires_human_approval_string_raises(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            build_pcw_context({"requires_human_approval": "yes"})

    def test_session_id_auto_generated_when_absent(self):
        """session_id should be a UUID when not provided."""
        ctx = build_pcw_context({})
        assert len(ctx.session_id) > 0
        # UUID format: 8-4-4-4-12 hex digits
        parts = ctx.session_id.split("-")
        assert len(parts) == 5

    def test_session_id_preserved_when_provided(self):
        ctx = build_pcw_context({"session_id": "my-session"})
        assert ctx.session_id == "my-session"

    def test_agent_id_default(self):
        ctx = build_pcw_context({})
        assert ctx.agent_id == "sdk-caller"

    def test_agent_id_custom(self):
        ctx = build_pcw_context({"agent_id": "my-agent"})
        assert ctx.agent_id == "my-agent"


# ---------------------------------------------------------------------------
# RateLimiter
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestRateLimiter:
    """Tests for RateLimiter — token bucket rate limiting."""

    def test_allow_within_capacity(self):
        limiter = RateLimiter(capacity=5, rate=1.0)
        for _ in range(5):
            assert limiter.allow() is True

    def test_deny_after_capacity_exhausted(self):
        limiter = RateLimiter(capacity=2, rate=0.0)
        assert limiter.allow() is True
        assert limiter.allow() is True
        assert limiter.allow() is False

    def test_single_token_capacity(self):
        limiter = RateLimiter(capacity=1, rate=0.0)
        assert limiter.allow() is True
        assert limiter.allow() is False

    def test_tokens_refill_over_time(self):
        limiter = RateLimiter(capacity=1, rate=1000.0)  # Very fast refill
        assert limiter.allow() is True
        # With rate=1000 tokens/sec, even a tiny sleep should refill
        time.sleep(0.01)
        assert limiter.allow() is True

    def test_refill_does_not_exceed_capacity(self):
        limiter = RateLimiter(capacity=2, rate=1000.0)
        # Exhaust all tokens
        limiter.allow()
        limiter.allow()
        # Wait for refill
        time.sleep(0.1)
        # Should get at most capacity tokens back
        assert limiter.allow() is True
        assert limiter.allow() is True
        # Immediately after, should be denied (no time to refill)
        assert limiter.allow() is False

    def test_zero_rate_no_refill(self):
        limiter = RateLimiter(capacity=1, rate=0.0)
        assert limiter.allow() is True
        time.sleep(0.01)
        assert limiter.allow() is False

    def test_thread_safety(self):
        """Concurrent access should not corrupt internal state."""
        limiter = RateLimiter(capacity=100, rate=0.0)
        results = []
        barrier = threading.Barrier(10)

        def consume():
            barrier.wait()
            for _ in range(20):
                results.append(limiter.allow())

        threads = [threading.Thread(target=consume) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Exactly 100 should be True (capacity=100, rate=0 so no refill)
        assert sum(results) == 100
        assert len(results) == 200


# ---------------------------------------------------------------------------
# AuditEvent
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestAuditEvent:
    """Tests for AuditEvent dataclass."""

    def _make_event(self, **overrides):
        defaults = {
            "decision_id": "dec-001",
            "timestamp_utc": "2026-01-01T00:00:00+00:00",
            "source": "test-source",
            "agent_id": "test-agent",
            "status": "proceed",
            "gates_passed": 5,
            "gates_failed": 0,
            "failing_gates": [],
            "params_hash": "abcdef1234567890",
            "latency_ms": 12.345,
            "shadow_mode": False,
        }
        defaults.update(overrides)
        return AuditEvent(**defaults)

    def test_construction(self):
        event = self._make_event()
        assert event.decision_id == "dec-001"
        assert event.source == "test-source"
        assert event.agent_id == "test-agent"
        assert event.status == "proceed"
        assert event.gates_passed == 5
        assert event.gates_failed == 0
        assert event.failing_gates == []
        assert event.shadow_mode is False

    def test_to_dict_serialization(self):
        event = self._make_event()
        d = event.to_dict()
        assert isinstance(d, dict)
        assert d["decision_id"] == "dec-001"
        assert d["source"] == "test-source"
        assert d["agent_id"] == "test-agent"
        assert d["status"] == "proceed"
        assert d["gates_passed"] == 5
        assert d["gates_failed"] == 0
        assert d["failing_gates"] == []
        assert d["shadow_mode"] is False
        assert d["params_hash"] == "abcdef1234567890"

    def test_to_dict_latency_rounded(self):
        event = self._make_event(latency_ms=12.345678)
        d = event.to_dict()
        assert d["latency_ms"] == 12.35

    def test_to_dict_metadata_default_empty(self):
        event = self._make_event()
        assert event.to_dict()["metadata"] == {}

    def test_to_dict_metadata_preserved(self):
        event = self._make_event(metadata={"key": "value"})
        assert event.to_dict()["metadata"] == {"key": "value"}

    def test_to_dict_with_failing_gates(self):
        event = self._make_event(
            gates_passed=3,
            gates_failed=2,
            failing_gates=["risk_gate", "novelty_gate"],
        )
        d = event.to_dict()
        assert d["gates_failed"] == 2
        assert d["failing_gates"] == ["risk_gate", "novelty_gate"]

    def test_to_dict_shadow_mode_true(self):
        event = self._make_event(shadow_mode=True)
        assert event.to_dict()["shadow_mode"] is True

    def test_to_dict_all_keys_present(self):
        """Verify that to_dict contains exactly the expected keys."""
        event = self._make_event()
        d = event.to_dict()
        expected_keys = {
            "decision_id",
            "timestamp_utc",
            "source",
            "agent_id",
            "status",
            "gates_passed",
            "gates_failed",
            "failing_gates",
            "params_hash",
            "latency_ms",
            "shadow_mode",
            "metadata",
        }
        assert set(d.keys()) == expected_keys


# ---------------------------------------------------------------------------
# safe_round
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestSafeRound:
    """Tests for safe_round() — NaN/Inf-safe rounding."""

    def test_finite_value_rounded(self):
        assert safe_round(3.14159, 2) == 3.14

    def test_finite_value_default_ndigits(self):
        assert safe_round(3.14159265358979) == 3.141593

    def test_zero(self):
        assert safe_round(0.0) == 0.0

    def test_negative_value(self):
        assert safe_round(-1.23456, 3) == -1.235

    def test_integer_value(self):
        assert safe_round(5.0, 2) == 5.0

    def test_nan_returns_none(self):
        assert safe_round(float("nan")) is None

    def test_inf_returns_none(self):
        assert safe_round(float("inf")) is None

    def test_neg_inf_returns_none(self):
        assert safe_round(float("-inf")) is None

    def test_very_small_value(self):
        result = safe_round(1e-10, 6)
        assert result == 0.0

    def test_large_value(self):
        result = safe_round(1e15, 2)
        assert result == 1e15

    def test_ndigits_zero(self):
        result = safe_round(3.7, 0)
        assert result == 4.0


# ---------------------------------------------------------------------------
# _hash_context
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestHashContext:
    """Tests for _hash_context() — deterministic context hashing."""

    def _make_context(self, **overrides):
        defaults = {
            "agent_id": "test-agent",
            "session_id": "sess-001",
            "phase": PCWPhase.PLAN,
            "proposal_summary": "test proposal",
            "estimated_impact": "medium",
            "risk_baseline": 0.0,
            "risk_proposed": 0.3,
            "profit_baseline": 0.0,
            "profit_proposed": 0.0,
            "novelty_score": 0.5,
            "complexity_score": 0.5,
            "quality_score": 0.7,
        }
        defaults.update(overrides)
        return PCWContext(**defaults)

    def test_returns_hex_string(self):
        ctx = self._make_context()
        h = _hash_context(ctx)
        assert isinstance(h, str)
        # All hex characters
        assert all(c in "0123456789abcdef" for c in h)

    def test_hash_length_is_16(self):
        """Truncated SHA-256 should be 16 hex chars."""
        ctx = self._make_context()
        h = _hash_context(ctx)
        assert len(h) == 16

    def test_deterministic(self):
        """Same context must always produce the same hash."""
        ctx = self._make_context()
        h1 = _hash_context(ctx)
        h2 = _hash_context(ctx)
        assert h1 == h2

    def test_different_contexts_different_hashes(self):
        ctx1 = self._make_context(risk_proposed=0.3)
        ctx2 = self._make_context(risk_proposed=0.9)
        assert _hash_context(ctx1) != _hash_context(ctx2)

    def test_different_agents_different_hashes(self):
        ctx1 = self._make_context(agent_id="agent-a")
        ctx2 = self._make_context(agent_id="agent-b")
        assert _hash_context(ctx1) != _hash_context(ctx2)

    def test_different_phases_different_hashes(self):
        ctx1 = self._make_context(phase=PCWPhase.PLAN)
        ctx2 = self._make_context(phase=PCWPhase.COMMIT)
        assert _hash_context(ctx1) != _hash_context(ctx2)


# ---------------------------------------------------------------------------
# AuditMiddleware
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestAuditMiddleware:
    """Tests for AuditMiddleware — wraps pcw_decide() with audit trail."""

    def _make_context(self):
        return PCWContext(
            agent_id="test-agent",
            session_id="sess-001",
            phase=PCWPhase.PLAN,
            proposal_summary="test proposal",
            estimated_impact="medium",
        )

    def _make_mock_decision(self):
        decision = MagicMock()
        decision.decision_id = "dec-mock-001"
        decision.timestamp = datetime(2026, 1, 1, tzinfo=timezone.utc)
        decision.status = PCWStatus.PROCEED
        decision.gates_passed = 5
        decision.gates_failed = 0
        decision.failing_gates = []
        return decision

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_delegates_to_pcw_decide(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")
        ctx = self._make_context()

        middleware.decide(ctx)

        mock_pcw_decide.assert_called_once()
        # Verify context was passed through
        call_args = mock_pcw_decide.call_args
        assert call_args[0][0] is ctx

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_returns_pcw_decision(self, mock_pcw_decide):
        mock_decision = self._make_mock_decision()
        mock_pcw_decide.return_value = mock_decision
        middleware = AuditMiddleware(source="test")

        result = middleware.decide(self._make_context())
        assert result is mock_decision

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_passes_gate_evaluator(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")
        mock_evaluator = MagicMock()

        middleware.decide(self._make_context(), gate_evaluator=mock_evaluator)

        call_kwargs = mock_pcw_decide.call_args
        assert call_kwargs.kwargs.get("gate_evaluator") is mock_evaluator

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_passes_shadow_mode(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")

        middleware.decide(self._make_context(), shadow_mode=True)

        call_kwargs = mock_pcw_decide.call_args
        assert call_kwargs.kwargs.get("shadow_mode") is True

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_passes_rbac_enforcer(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")
        mock_rbac = MagicMock()

        middleware.decide(self._make_context(), rbac_enforcer=mock_rbac)

        call_kwargs = mock_pcw_decide.call_args
        assert call_kwargs.kwargs.get("rbac_enforcer") is mock_rbac

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_passes_drift_monitor(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")
        mock_drift = MagicMock()

        middleware.decide(self._make_context(), drift_monitor=mock_drift)

        call_kwargs = mock_pcw_decide.call_args
        assert call_kwargs.kwargs.get("drift_monitor") is mock_drift

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_passes_telemetry_emitter(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        mock_emitter = MagicMock()
        middleware = AuditMiddleware(source="test", telemetry_emitter=mock_emitter)

        middleware.decide(self._make_context())

        call_kwargs = mock_pcw_decide.call_args
        assert call_kwargs.kwargs.get("telemetry_emitter") is mock_emitter

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_passes_prometheus_exporter(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        mock_prometheus = MagicMock()
        middleware = AuditMiddleware(source="test", prometheus_exporter=mock_prometheus)

        middleware.decide(self._make_context())

        call_kwargs = mock_pcw_decide.call_args
        assert call_kwargs.kwargs.get("prometheus_exporter") is mock_prometheus

    def test_rate_limiter_blocks_when_exceeded(self):
        limiter = RateLimiter(capacity=0, rate=0.0)
        middleware = AuditMiddleware(source="test", rate_limiter=limiter)

        with pytest.raises(RuntimeError, match="Rate limit exceeded"):
            middleware.decide(self._make_context())

    @patch.object(_pcw_module, "pcw_decide")
    def test_rate_limiter_allows_within_capacity(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        limiter = RateLimiter(capacity=10, rate=0.0)
        middleware = AuditMiddleware(source="test", rate_limiter=limiter)

        # Should not raise
        middleware.decide(self._make_context())

    @patch.object(_pcw_module, "pcw_decide")
    def test_no_rate_limiter_always_allows(self, mock_pcw_decide):
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")

        # Should not raise even without rate limiter
        middleware.decide(self._make_context())

    @patch.object(_pcw_module, "pcw_decide")
    def test_audit_telemetry_emission(self, mock_pcw_decide):
        """When telemetry_emitter is provided, _emit_audit should call emit()."""
        mock_pcw_decide.return_value = self._make_mock_decision()
        mock_emitter = MagicMock()
        middleware = AuditMiddleware(source="test", telemetry_emitter=mock_emitter)

        middleware.decide(self._make_context())

        # The emitter should have been called at least once for the audit event
        assert mock_emitter.emit.called

    @patch.object(_pcw_module, "pcw_decide")
    def test_audit_telemetry_emission_failure_does_not_crash(self, mock_pcw_decide):
        """Telemetry emission failure must not crash the caller."""
        mock_pcw_decide.return_value = self._make_mock_decision()
        mock_emitter = MagicMock()
        mock_emitter.emit.side_effect = Exception("telemetry down")
        middleware = AuditMiddleware(source="test", telemetry_emitter=mock_emitter)

        # Must not raise despite telemetry failure
        decision = middleware.decide(self._make_context())
        assert decision is not None

    @patch.object(_pcw_module, "pcw_decide")
    def test_no_telemetry_emitter_skips_emission(self, mock_pcw_decide):
        """No telemetry emitter means no audit emission, but no crash."""
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")

        # Must not raise
        decision = middleware.decide(self._make_context())
        assert decision is not None

    def test_source_default(self):
        middleware = AuditMiddleware()
        assert middleware.source == "aegis-sdk"

    def test_source_custom(self):
        middleware = AuditMiddleware(source="agoraiv-bridge")
        assert middleware.source == "agoraiv-bridge"

    @patch.object(_pcw_module, "pcw_decide")
    def test_decide_logs_audit_event(self, mock_pcw_decide):
        """The decide method should log audit information at INFO level."""
        mock_pcw_decide.return_value = self._make_mock_decision()
        middleware = AuditMiddleware(source="test")

        with patch("aegis_governance.middleware.logger") as mock_logger:
            middleware.decide(self._make_context())
            mock_logger.info.assert_called_once()
            log_msg = mock_logger.info.call_args[0][0]
            assert "AEGIS_AUDIT" in log_msg


# ---------------------------------------------------------------------------
# AuditMiddleware._emit_audit (internal, but important contract)
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestAuditMiddlewareEmitAudit:
    """Tests for AuditMiddleware._emit_audit internal method."""

    def _make_event(self):
        return AuditEvent(
            decision_id="dec-001",
            timestamp_utc="2026-01-01T00:00:00+00:00",
            source="test",
            agent_id="test-agent",
            status="proceed",
            gates_passed=5,
            gates_failed=0,
            failing_gates=[],
            params_hash="abcdef1234567890",
            latency_ms=10.0,
            shadow_mode=False,
        )

    def test_emit_audit_with_no_emitter_is_noop(self):
        middleware = AuditMiddleware(source="test")
        # Should not raise
        middleware._emit_audit(self._make_event())

    def test_emit_audit_calls_emitter(self):
        mock_emitter = MagicMock()
        middleware = AuditMiddleware(source="test", telemetry_emitter=mock_emitter)

        event = self._make_event()
        middleware._emit_audit(event)

        mock_emitter.emit.assert_called_once()
        call_kwargs = mock_emitter.emit.call_args
        assert call_kwargs.kwargs.get("correlation_id") == "dec-001"

    def test_emit_audit_swallows_exceptions(self):
        mock_emitter = MagicMock()
        mock_emitter.emit.side_effect = RuntimeError("emitter broken")
        middleware = AuditMiddleware(source="test", telemetry_emitter=mock_emitter)

        # Must not raise
        middleware._emit_audit(self._make_event())


# ---------------------------------------------------------------------------
# Integration: build_pcw_context edge cases
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestBuildPcwContextEdgeCases:
    """Edge cases and error conditions for build_pcw_context."""

    def test_risk_score_zero_not_replaced_by_default(self):
        """risk_score=0 should produce risk_proposed=0, not the default."""
        ctx = build_pcw_context({"risk_score": 0})
        assert ctx.risk_proposed == 0.0

    def test_risk_proposed_zero_not_replaced_by_default(self):
        ctx = build_pcw_context({"risk_proposed": 0})
        assert ctx.risk_proposed == 0.0

    def test_novelty_score_zero_accepted(self):
        ctx = build_pcw_context({"novelty_score": 0})
        assert ctx.novelty_score == 0.0

    def test_quality_score_zero_accepted(self):
        ctx = build_pcw_context({"quality_score": 0})
        assert ctx.quality_score == 0.0

    def test_nan_novelty_score_raises(self):
        with pytest.raises(ValueError, match="must be finite"):
            build_pcw_context({"novelty_score": float("nan")})

    def test_inf_complexity_score_raises(self):
        with pytest.raises(ValueError, match="must be finite"):
            build_pcw_context({"complexity_score": float("inf")})

    def test_bool_profit_baseline_raises(self):
        with pytest.raises(TypeError, match="got bool"):
            build_pcw_context({"profit_baseline": True})

    def test_bool_novelty_score_raises(self):
        with pytest.raises(TypeError, match="got bool"):
            build_pcw_context({"novelty_score": False})

    def test_bool_quality_score_raises(self):
        with pytest.raises(TypeError, match="got bool"):
            build_pcw_context({"quality_score": True})

    def test_bool_time_sensitive_string_raises(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            build_pcw_context({"time_sensitive": "true"})

    def test_bool_reversible_int_raises(self):
        with pytest.raises(TypeError, match="must be a boolean"):
            build_pcw_context({"reversible": 1})

    def test_invalid_quality_subscores_propagate(self):
        with pytest.raises(TypeError, match="got bool"):
            build_pcw_context({"quality_subscores": [True]})

    def test_quality_subscores_nan_propagates(self):
        with pytest.raises(ValueError, match="must be finite"):
            build_pcw_context({"quality_subscores": [float("nan")]})

    def test_proposal_summary_non_string_converted(self):
        """Non-string proposal_summary should be converted via str()."""
        ctx = build_pcw_context({"proposal_summary": 42})
        assert ctx.proposal_summary == "42"

    def test_estimated_impact_non_string_converted(self):
        """Non-string estimated_impact should be converted via str()."""
        ctx = build_pcw_context({"estimated_impact": 42})
        assert ctx.estimated_impact == "42"

    def test_empty_string_proposal_summary(self):
        ctx = build_pcw_context({"proposal_summary": ""})
        assert ctx.proposal_summary == ""

    def test_metadata_with_nested_dicts(self):
        ctx = build_pcw_context({"metadata": {"a": {"b": {"c": 1}}, "list": [1, 2]}})
        assert ctx.metadata["a"]["b"]["c"] == 1

    def test_risk_proposed_none_falls_through_to_risk_score(self):
        """When risk_proposed is explicitly None, fall through to risk_score."""
        ctx = build_pcw_context({"risk_proposed": None, "risk_score": 0.4})
        assert ctx.risk_proposed == 0.4

    def test_both_risk_keys_none_returns_default(self):
        ctx = build_pcw_context({"risk_proposed": None, "risk_score": None})
        assert ctx.risk_proposed == 0.0


# ---------------------------------------------------------------------------
# Phase map caching
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestPhaseMapCaching:
    """Tests for the lazy phase map cache behavior."""

    def test_build_pcw_context_populates_phase_map(self):
        """After building a context, the phase map cache should be populated."""
        # Just ensure this doesn't raise and produces valid phases
        for phase_str in ("plan", "work", "commit"):
            ctx = build_pcw_context({"phase": phase_str})
            assert ctx.phase.value == phase_str

    def test_mixed_case_phases(self):
        """Phase strings should be case-insensitive."""
        for phase_str in ("Plan", "WORK", "Commit", "PLAN", "work"):
            ctx = build_pcw_context({"phase": phase_str})
            assert ctx.phase.value == phase_str.lower()


# ---------------------------------------------------------------------------
# RateLimiter edge cases
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestRateLimiterEdgeCases:
    """Additional edge cases for RateLimiter."""

    def test_large_capacity(self):
        limiter = RateLimiter(capacity=10000, rate=0.0)
        allowed = sum(limiter.allow() for _ in range(10000))
        assert allowed == 10000
        assert limiter.allow() is False

    def test_fractional_rate(self):
        """Fractional rates should work correctly."""
        limiter = RateLimiter(capacity=10, rate=0.5)
        # Exhaust all tokens
        for _ in range(10):
            limiter.allow()
        # With rate 0.5 tokens/sec, need ~2 seconds for 1 token
        # After a short wait, should still be denied
        assert limiter.allow() is False

    def test_rate_limiter_initial_state(self):
        """A freshly created limiter should start at full capacity."""
        limiter = RateLimiter(capacity=3, rate=0.0)
        assert limiter.allow() is True
        assert limiter.allow() is True
        assert limiter.allow() is True
        assert limiter.allow() is False


# ---------------------------------------------------------------------------
# Middleware facade re-exports (GAP-2: aegis_governance.middleware → SDK)
# ---------------------------------------------------------------------------


@pytest.mark.unit
class TestMiddlewareFacadeImports:
    """Verify middleware symbols are re-exported from the SDK facade."""

    @pytest.mark.parametrize(
        "name",
        [
            "AuditMiddleware",
            "AuditEvent",
            "RateLimiter",
            "build_pcw_context",
            "validate_float",
            "validate_bool",
            "validate_quality_subscores",
            "validate_drift_baseline",
            "validate_str",
            "safe_round",
        ],
    )
    def test_facade_export(self, name: str) -> None:
        mod = importlib.import_module("aegis_governance")
        assert hasattr(mod, name), f"{name} not exported from aegis_governance"

    @pytest.mark.parametrize(
        "name",
        [
            "AuditMiddleware",
            "AuditEvent",
            "RateLimiter",
            "build_pcw_context",
            "validate_float",
            "validate_bool",
            "validate_quality_subscores",
            "validate_drift_baseline",
            "validate_str",
            "safe_round",
        ],
    )
    def test_facade_export_in_all(self, name: str) -> None:
        mod = importlib.import_module("aegis_governance")
        assert name in mod.__all__, f"{name} not in aegis_governance.__all__"
