"""Regression tests for Bug Hunt #39.

BH39-M1: TelemetryPipeline.stop() held _start_lock during thread.join()
          — blocked concurrent start() for up to 5 seconds (same anti-pattern
          fixed in MetricsServer.stop() by BH38-M4; now mirrored here).

BH39-M2: DEKRotator.generate_dek() had no lock around the check-then-write
          to self._deks — TOCTOU race when two threads called generate_dek()
          concurrently with the same version string (day-granularity auto-
          generated versions make this likely in production).

BH39-M3: KeyStoreRepository.get_private_key() held _audit_lock for the full
          duration of kek.decrypt() (expensive ML-KEM-768 decapsulation),
          blocking all other audit operations that need the lock.

BH39-L1: ConsensusWorkflow.from_dict() called cls(...) which runs __init__,
          setting created_at/deadline to datetime.now() before overwriting
          them from serialized data — intermediate inconsistent state window.
          Fixed by switching to cls.__new__(cls) (mirrors OverrideWorkflow).
"""

import threading
import time
from unittest.mock import patch

import pytest

from telemetry.pipeline import TelemetryPipeline
from workflows.consensus import (
    ConsensusConfig,
    ConsensusState,
    ConsensusWorkflow,
    VoteOutcome,
)

# =============================================================================
# BH39-M1: TelemetryPipeline.stop() join-under-lock
# =============================================================================


class TestBH39M1PipelineStopJoinUnderLock:
    """TelemetryPipeline.stop() must release _start_lock before thread.join()."""

    def test_stop_releases_lock_before_join(self):
        """stop() must not hold _start_lock during join — previously blocked
        a concurrent start() for up to 5 seconds."""
        pipeline = TelemetryPipeline()
        pipeline.start()
        time.sleep(0.05)

        lock_held_during_join = []

        original_join = threading.Thread.join

        def patched_join(self_thread, timeout=None):
            # Try to acquire the lock non-blocking — it must NOT be held here.
            acquired = pipeline._start_lock.acquire(blocking=False)
            lock_held_during_join.append(not acquired)
            if acquired:
                pipeline._start_lock.release()
            return original_join(self_thread, timeout=timeout)

        with patch.object(threading.Thread, "join", patched_join):
            pipeline.stop()

        # Lock must have been free during join — list is non-empty because
        # patched_join was called, and every entry must be False (not held).
        assert (
            lock_held_during_join
        ), "join() was never called — fix may have removed join"
        assert not any(lock_held_during_join), (
            "BH39-M1 regression: _start_lock was held during thread.join(); "
            "a concurrent start() would have been blocked for up to 5 seconds"
        )

    def test_start_during_stop_not_deadlocked(self):
        """Concurrent start() immediately after stop() must complete quickly.

        With the bug, start() would block for up to 5 s waiting for the lock
        held by stop()'s join.  After the fix, start() acquires the lock
        immediately because stop() releases it before joining.
        """
        pipeline = TelemetryPipeline()
        pipeline.start()
        time.sleep(0.05)

        start_complete = threading.Event()
        start_elapsed: list[float] = []

        def start_soon():
            """Called from background thread shortly after stop() is initiated."""
            time.sleep(0.01)  # small delay so stop() begins first
            t0 = time.monotonic()
            pipeline.start()
            start_elapsed.append(time.monotonic() - t0)
            start_complete.set()

        start_thread = threading.Thread(target=start_soon, daemon=True)
        start_thread.start()

        pipeline.stop()

        # start() must complete within 1 second — old bug would block for ~5 s
        assert start_complete.wait(timeout=2.0), (
            "BH39-M1 regression: start() after stop() did not complete within 2 s; "
            "suggests _start_lock was held during join()"
        )
        if start_elapsed:
            assert start_elapsed[0] < 2.0, (
                f"BH39-M1 regression: start() took {start_elapsed[0]:.2f}s — "
                "lock contention from join-under-lock detected"
            )

        # Clean up
        pipeline.stop()

    def test_stop_sets_worker_thread_none_before_join(self):
        """After fix, worker_thread is set to None before join — any code that
        checks pipeline.worker_thread after stop() must see None immediately."""
        pipeline = TelemetryPipeline()
        pipeline.start()
        time.sleep(0.05)
        pipeline.stop()
        # worker_thread must be None after stop completes
        assert pipeline.worker_thread is None

    def test_stop_idempotent_when_not_running(self):
        """stop() on a never-started pipeline must be a no-op."""
        pipeline = TelemetryPipeline()
        # Should not raise
        pipeline.stop()
        assert pipeline.worker_thread is None
        assert not pipeline.running

    def test_stop_running_flag_cleared_under_lock(self):
        """running flag is set to False inside the lock — worker loop exits."""
        pipeline = TelemetryPipeline()
        pipeline.start()
        time.sleep(0.05)
        assert pipeline.running is True
        pipeline.stop()
        assert pipeline.running is False


# =============================================================================
# BH39-M2: DEKRotator TOCTOU race
# =============================================================================


class TestBH39M2DEKRotatorThreadSafety:
    """DEKRotator.generate_dek() must be safe under concurrent calls."""

    @pytest.fixture(autouse=True)
    def skip_if_no_pqc(self):
        """Skip if liboqs-python is not installed."""
        pytest.importorskip("oqs", reason="liboqs-python required for DEKRotator tests")
        from crypto import HYBRID_KEM_AVAILABLE

        if not HYBRID_KEM_AVAILABLE:
            pytest.skip("HybridKEM not available — install liboqs-python>=0.10.0")

    def test_dek_rotator_has_lock(self):
        """DEKRotator.__init__ must create a threading.Lock (BH39-M2 fix)."""
        from telemetry.encryption import DEKRotator

        rotator = DEKRotator()
        assert hasattr(rotator, "_lock"), (
            "BH39-M2 regression: DEKRotator has no _lock attribute; "
            "concurrent generate_dek() calls are not serialized"
        )
        assert isinstance(
            rotator._lock, type(threading.Lock())
        ), "BH39-M2: _lock must be a threading.Lock instance"

    def test_generate_dek_explicit_version_duplicate_raises(self):
        """Explicit duplicate version must raise ValueError (pre-existing behavior)."""
        from telemetry.encryption import DEKRotator

        rotator = DEKRotator()
        rotator.generate_dek(version="v-dup-test")
        with pytest.raises(ValueError, match="already exists"):
            rotator.generate_dek(version="v-dup-test")

    def test_concurrent_generate_dek_different_versions(self):
        """Two threads with different explicit versions must both succeed."""
        from telemetry.encryption import DEKRotator

        rotator = DEKRotator()
        results: list[str] = []
        errors: list[Exception] = []

        def worker(ver: str) -> None:
            try:
                dek_ver, _, _ = rotator.generate_dek(version=ver)
                results.append(dek_ver)
            except Exception as exc:
                errors.append(exc)

        t1 = threading.Thread(target=worker, args=("concurrent-v1",))
        t2 = threading.Thread(target=worker, args=("concurrent-v2",))
        t1.start()
        t2.start()
        t1.join(timeout=30)
        t2.join(timeout=30)

        assert not errors, f"Unexpected errors in concurrent generate_dek: {errors}"
        assert sorted(results) == ["concurrent-v1", "concurrent-v2"]

    def test_concurrent_generate_dek_same_version_one_succeeds(self):
        """Two threads racing on the same version: exactly one must succeed and
        the other must raise ValueError (not silently overwrite)."""
        from telemetry.encryption import DEKRotator

        rotator = DEKRotator()
        successes: list[str] = []
        failures: list[Exception] = []
        start_event = threading.Event()

        def worker() -> None:
            start_event.wait()
            try:
                ver, _, _ = rotator.generate_dek(version="race-version")
                successes.append(ver)
            except ValueError as exc:
                failures.append(exc)

        threads = [threading.Thread(target=worker) for _ in range(4)]
        for t in threads:
            t.start()
        start_event.set()
        for t in threads:
            t.join(timeout=60)

        # Exactly one thread wins; the rest get ValueError (not silent overwrite)
        assert len(successes) == 1, (
            f"BH39-M2 regression: expected exactly 1 success, got {len(successes)}; "
            "TOCTOU race may have allowed multiple writes or silent overwrites"
        )
        assert (
            len(failures) == 3
        ), f"Expected 3 failures (duplicate version), got {len(failures)}"

    def test_generate_dek_result_stored_correctly(self):
        """Generated DEK must appear in _deks after the call returns."""
        from telemetry.encryption import DEKRotator

        rotator = DEKRotator()
        ver, _, _ = rotator.generate_dek(version="check-stored")
        assert ver in rotator._deks, "DEK was not stored after generate_dek()"


# =============================================================================
# BH39-M3: KeyStoreRepository lock-during-decrypt
# =============================================================================


def _run_async(coro):
    """Run an async coroutine in a fresh event loop without disturbing the
    default event loop.  asyncio.run() closes the loop after use which breaks
    tests that later call asyncio.get_event_loop().run_until_complete() — the
    pattern used in several existing test_workflows.py tests (TestW10, TestW11).
    Using a dedicated loop and restoring the original afterwards is safe.
    """
    import asyncio

    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


class TestBH39M3KeyStoreLockDuringDecrypt:
    """KeyStoreRepository.get_private_key() must release _audit_lock before
    calling kek.decrypt() (expensive ML-KEM-768 decapsulation)."""

    @pytest.fixture(autouse=True)
    def skip_if_no_persistence(self):
        pytest.importorskip(
            "sqlalchemy", reason="SQLAlchemy required for key store tests"
        )
        pytest.importorskip(
            "oqs", reason="liboqs-python required for key store decrypt tests"
        )
        from crypto import HYBRID_KEM_AVAILABLE

        if not HYBRID_KEM_AVAILABLE:
            pytest.skip("HybridKEM not available — install liboqs-python>=0.10.0")

    def test_get_private_key_releases_lock_before_decrypt(self):
        """kek.decrypt() must be called outside the _audit_lock.

        Strategy: mock kek.decrypt() to check whether _audit_lock is held
        while the decrypt call is in progress.
        """
        from crypto.kek_provider import InMemoryKEKProvider
        from workflows.persistence.engine import DatabaseConfig
        from workflows.persistence.key_store import KeyStoreRepository

        config = DatabaseConfig.for_testing()
        kek = InMemoryKEKProvider()
        repo = KeyStoreRepository(config=config, kek_provider=kek)

        lock_held_during_decrypt: list[bool] = []
        original_decrypt = kek.decrypt

        def patched_decrypt(data, version=None):
            # asyncio.Lock.locked() is synchronous and safe to call from sync code.
            lock_held_during_decrypt.append(repo._audit_lock.locked())
            return original_decrypt(data, version=version)

        async def run():
            await repo.initialize()

            from crypto import get_default_provider

            try:
                provider = get_default_provider()
                private_key, public_key = provider.generate_keypair()
                await repo.store_key(
                    role="test_role",
                    algorithm=provider.algorithm_name,
                    private_key=private_key,
                    public_key=public_key,
                    created_by="test",
                )
            except Exception:
                pytest.skip("Default crypto provider unavailable")
                return

            kek.decrypt = patched_decrypt  # type: ignore[method-assign]
            try:
                await repo.get_private_key("test_role", provider.algorithm_name)
            finally:
                kek.decrypt = original_decrypt  # type: ignore[method-assign]
                await repo.close()

        _run_async(run())

        assert (
            lock_held_during_decrypt
        ), "kek.decrypt() was never called — check test setup"
        assert not any(lock_held_during_decrypt), (
            "BH39-M3 regression: _audit_lock was held during kek.decrypt(); "
            "concurrent record_usage / rotate_key calls would have been blocked "
            "for the full ML-KEM-768 decapsulation duration"
        )

    def test_get_private_key_returns_none_for_missing_key(self):
        """get_private_key() must return None when no key is stored (no KEK needed)."""
        from crypto.kek_provider import InMemoryKEKProvider
        from workflows.persistence.engine import DatabaseConfig
        from workflows.persistence.key_store import KeyStoreRepository

        config = DatabaseConfig.for_testing()
        repo = KeyStoreRepository(config=config, kek_provider=InMemoryKEKProvider())

        async def run():
            await repo.initialize()
            result = await repo.get_private_key("nonexistent_role", "bip322")
            await repo.close()
            return result

        result = _run_async(run())
        assert result is None

    def test_get_private_key_lock_not_held_after_call(self):
        """After get_private_key() returns, _audit_lock must be free."""
        from crypto.kek_provider import InMemoryKEKProvider
        from workflows.persistence.engine import DatabaseConfig
        from workflows.persistence.key_store import KeyStoreRepository

        config = DatabaseConfig.for_testing()
        repo = KeyStoreRepository(config=config, kek_provider=InMemoryKEKProvider())

        async def run():
            await repo.initialize()
            await repo.get_private_key("any_role", "bip322")
            is_locked = repo._audit_lock.locked()
            await repo.close()
            return is_locked

        is_locked = _run_async(run())
        assert not is_locked, (
            "BH39-M3 regression: _audit_lock is still held after get_private_key() returned; "
            "suggests lock was not properly released"
        )


# =============================================================================
# BH39-L1: ConsensusWorkflow.from_dict() intermediate inconsistent state
# =============================================================================


class TestBH39L1ConsensusFromDictUsesNew:
    """ConsensusWorkflow.from_dict() must use cls.__new__(cls), not cls(...)."""

    def _make_serialized(
        self,
        proposal_id: str = "test-prop",
        voters=None,
        config=None,
    ) -> dict:
        """Helper: create a workflow, vote to finalize it, serialize."""
        if voters is None:
            voters = {"alice", "bob"}
        if config is None:
            config = ConsensusConfig(quorum_percentage=0.5, approval_threshold=0.5)
        wf = ConsensusWorkflow(proposal_id, voters, config)
        wf.cast_vote("alice", VoteOutcome.APPROVE)
        wf.cast_vote("bob", VoteOutcome.APPROVE)
        return wf.to_dict()

    def test_from_dict_does_not_call_init(self):
        """from_dict() must use __new__ — __init__ must NOT be called.

        Verified by patching __init__ with a sentinel and confirming it is
        NOT invoked during from_dict().
        """
        data = self._make_serialized()
        init_call_count: list[int] = [0]
        original_init = ConsensusWorkflow.__init__

        def counting_init(self_wf, *args, **kwargs):
            init_call_count[0] += 1
            return original_init(self_wf, *args, **kwargs)

        with patch.object(ConsensusWorkflow, "__init__", counting_init):
            ConsensusWorkflow.from_dict(data)

        assert init_call_count[0] == 0, (
            f"BH39-L1 regression: ConsensusWorkflow.__init__ was called "
            f"{init_call_count[0]} time(s) during from_dict(); "
            "expected 0 — from_dict() must use cls.__new__(cls)"
        )

    def test_from_dict_created_at_matches_original(self):
        """Restored created_at must equal the original serialized value exactly."""
        wf = ConsensusWorkflow(
            "prop-ts-check",
            {"alice", "bob"},
            ConsensusConfig(quorum_percentage=0.5, approval_threshold=0.5),
        )
        original_created_at = wf.created_at
        data = wf.to_dict()

        restored = ConsensusWorkflow.from_dict(data)
        assert restored.created_at == original_created_at, (
            "BH39-L1 regression: restored created_at does not match original; "
            "from_dict() may have re-run __init__ which sets created_at=datetime.now()"
        )

    def test_from_dict_deadline_matches_original(self):
        """Restored deadline must equal the original serialized value exactly."""
        config = ConsensusConfig(
            quorum_percentage=0.5, approval_threshold=0.5, timeout_hours=24
        )
        wf = ConsensusWorkflow("prop-dl-check", {"alice"}, config)
        original_deadline = wf.deadline
        data = wf.to_dict()

        restored = ConsensusWorkflow.from_dict(data)
        assert restored.deadline == original_deadline, (
            "BH39-L1 regression: restored deadline does not match original; "
            "from_dict() may have re-run __init__ which recomputes deadline"
        )

    def test_from_dict_full_round_trip(self):
        """Complete round-trip: serialize approved workflow, restore, verify all fields."""
        voters = {"alice", "bob", "carol"}
        config = ConsensusConfig(
            quorum_percentage=0.5,
            approval_threshold=0.5,
            timeout_hours=72,
            required_roles={"risk_lead"},
            allow_abstain=True,
        )
        original = ConsensusWorkflow("prop-roundtrip", voters, config)
        original.cast_vote("alice", VoteOutcome.APPROVE, rationale="looks good")
        original.cast_vote("bob", VoteOutcome.APPROVE)

        data = original.to_dict()
        restored = ConsensusWorkflow.from_dict(data)

        assert restored.proposal_id == original.proposal_id
        assert restored.eligible_voters == original.eligible_voters
        assert restored.state == original.state
        assert restored.created_at == original.created_at
        assert restored.deadline == original.deadline
        assert set(restored.votes.keys()) == set(original.votes.keys())
        assert restored.config.quorum_percentage == original.config.quorum_percentage
        assert restored.config.approval_threshold == original.config.approval_threshold
        assert restored.config.timeout_hours == original.config.timeout_hours
        assert restored.config.required_roles == original.config.required_roles

    def test_from_dict_no_clock_drift_between_calls(self):
        """Two calls to from_dict() on the same data must yield identical timestamps.

        With the __init__ bug, each call would produce a slightly different
        created_at because datetime.now() is called fresh each time.
        """
        data = self._make_serialized()

        restored_1 = ConsensusWorkflow.from_dict(data)
        time.sleep(0.01)  # Ensure clock advances between calls
        restored_2 = ConsensusWorkflow.from_dict(data)

        assert restored_1.created_at == restored_2.created_at, (
            "BH39-L1 regression: two from_dict() calls on identical data produced "
            "different created_at values — __init__ is being called (sets datetime.now())"
        )
        assert (
            restored_1.deadline == restored_2.deadline
        ), "BH39-L1 regression: two from_dict() calls produced different deadline values"

    def test_from_dict_with_finalized_at(self):
        """Finalized workflows must have _finalized_at restored correctly."""
        voters = {"alice", "bob"}
        config = ConsensusConfig(quorum_percentage=0.5, approval_threshold=0.5)
        wf = ConsensusWorkflow("prop-finalized", voters, config)
        wf.cast_vote("alice", VoteOutcome.APPROVE)
        wf.cast_vote("bob", VoteOutcome.APPROVE)
        assert wf._finalized_at is not None

        original_finalized = wf._finalized_at
        data = wf.to_dict()

        restored = ConsensusWorkflow.from_dict(data)
        assert (
            restored._finalized_at == original_finalized
        ), "from_dict() did not restore _finalized_at correctly"

    def test_from_dict_pending_workflow_has_no_finalized_at(self):
        """Pending (not yet voted) workflows must have _finalized_at=None after restore."""
        wf = ConsensusWorkflow(
            "prop-pending",
            {"alice", "bob"},
            ConsensusConfig(quorum_percentage=0.5, approval_threshold=0.5),
        )
        data = wf.to_dict()
        restored = ConsensusWorkflow.from_dict(data)
        assert restored._finalized_at is None

    def test_from_dict_restored_workflow_can_still_vote(self):
        """A partially-voted workflow restored from dict must still accept new votes."""
        voters = {"alice", "bob", "carol"}
        config = ConsensusConfig(quorum_percentage=0.5, approval_threshold=0.5)
        wf = ConsensusWorkflow("prop-partial", voters, config)
        wf.cast_vote("alice", VoteOutcome.APPROVE)
        data = wf.to_dict()

        restored = ConsensusWorkflow.from_dict(data)
        # Should be able to vote from remaining voters
        result = restored.cast_vote("bob", VoteOutcome.APPROVE)
        # With 2/3 voters approving (>=50% quorum, >=50% threshold) → APPROVED
        assert restored.state in (
            ConsensusState.APPROVED,
            ConsensusState.QUORUM_MET,
            ConsensusState.PENDING,
        )
        assert result is True or restored.state == ConsensusState.APPROVED
