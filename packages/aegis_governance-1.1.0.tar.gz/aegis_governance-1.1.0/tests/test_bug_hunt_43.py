"""Regression tests for Bug Hunt #43.

BH43-Codex-M1: Analyst missing try/except around gate evaluations
BH43-Codex-M2: Analyst missing else TypeError for non-list quality_subscores
BH43-M1: CLI quality_subscores null raises TypeError (transport parity)
BH43-L1: CLI metric defaults ignores simplified name when canonical key is null
BH43-M2: ComplexityBreakdown accepts bool fields without validation
BH43-M3: UtilityCalculator.calculate() value_variance negative silently floored to 0
BH43-L2: UtilityCalculator.calculate() value_low_conf/opex_delta not validated
BH43-L3: UtilityCalculator.calculate() covariance terms not validated
BH43-M4+M5: TelemetryPipeline ingest() no defensive copy (aliasing)
BH43-L4: ProposalWorkflow.from_dict() uses cls() instead of cls.__new__()
"""

import math
from datetime import datetime, timezone

import pytest


# ---------------------------------------------------------------------------
# BH43-Codex-M1: Analyst try/except around gate evaluations
# ---------------------------------------------------------------------------
class TestBH43CodexM1AnalystTryExcept:
    """Analyst.analyze_proposal() must return ActionResult failure on gate exception."""

    def test_invalid_quality_subscores_returns_failure_not_crash(self):
        """Non-list quality_subscores should return ActionResult(success=False)."""
        from actors.analyst import AnalysisRequest, Analyst

        analyst = Analyst("a1", "Tester")
        request = AnalysisRequest(
            proposal_id="p1",
            analysis_type="full",
            include_recommendations=False,
        )
        # String is not a valid subscores type
        data = {
            "risk_delta": 0.5,
            "quality_score": 0.8,
            "quality_subscores": "not-a-list",
        }
        result = analyst.analyze_proposal(request, data)
        assert result.success is False
        assert result.error is not None
        assert "quality_subscores" in result.error


# ---------------------------------------------------------------------------
# BH43-M1: CLI quality_subscores null → TypeError (transport parity)
# ---------------------------------------------------------------------------
class TestBH43M1CLIQualitySubscoresNull:
    """CLI must treat quality_subscores=null same as omitted (default to [0.7, 0.7, 0.7])."""

    def test_null_quality_subscores_defaults(self):
        """Explicit null quality_subscores should default, not raise TypeError."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "quality_subscores": None,
        }
        result = _parse_proposal(data)
        assert result["quality_subscores"] == [0.7, 0.7, 0.7]

    def test_missing_quality_subscores_no_key(self):
        """Omitted quality_subscores should not set the key (default from pcw_decide)."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
        }
        result = _parse_proposal(data)
        # When key is absent, _extract_risk_alias_and_subscores doesn't set it
        assert "quality_subscores" not in result

    def test_explicit_empty_list_preserved(self):
        """Explicit empty list [] should be preserved (fail-closed)."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "quality_subscores": [],
        }
        result = _parse_proposal(data)
        assert result["quality_subscores"] == []


# ---------------------------------------------------------------------------
# BH43-L1: CLI metric defaults ignores alias when canonical key is null
# ---------------------------------------------------------------------------
class TestBH43L1CLIMetricAliasNull:
    """CLI must fall through to simplified alias when canonical key is explicitly null."""

    def test_null_canonical_falls_through_to_alias(self):
        """risk_proposed=null + risk=0.3 should use risk=0.3, not default 0.0."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "risk_proposed": None,
            "risk": 0.3,
        }
        result = _parse_proposal(data)
        assert result["risk_proposed"] == pytest.approx(0.3)

    def test_null_canonical_null_alias_uses_default(self):
        """risk_proposed=null + risk=null should use default 0.0."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "risk_proposed": None,
            "risk": None,
        }
        result = _parse_proposal(data)
        assert result["risk_proposed"] == pytest.approx(0.0)

    def test_both_absent_uses_default(self):
        """No risk_proposed or risk key should use default 0.0."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
        }
        result = _parse_proposal(data)
        assert result["risk_proposed"] == pytest.approx(0.0)

    def test_profit_alias_null_fallthrough(self):
        """profit_proposed=null + profit=1000.0 should use 1000.0."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "profit_proposed": None,
            "profit": 1000.0,
        }
        result = _parse_proposal(data)
        assert result["profit_proposed"] == pytest.approx(1000.0)


# ---------------------------------------------------------------------------
# BH43-M2: ComplexityBreakdown accepts bool fields
# ---------------------------------------------------------------------------
class TestBH43M2ComplexityBreakdownBool:
    """ComplexityBreakdown must reject bool values (bool-is-int coercion)."""

    def test_static_bool_raises_type_error(self):
        from engine.utility import ComplexityBreakdown

        with pytest.raises(TypeError, match="bool"):
            ComplexityBreakdown(static=True, dynamic=0.5)

    def test_dynamic_bool_raises_type_error(self):
        from engine.utility import ComplexityBreakdown

        with pytest.raises(TypeError, match="bool"):
            ComplexityBreakdown(static=0.5, dynamic=False)

    def test_static_nan_raises_value_error(self):
        from engine.utility import ComplexityBreakdown

        with pytest.raises(ValueError, match="finite"):
            ComplexityBreakdown(static=float("nan"), dynamic=0.5)

    def test_dynamic_inf_raises_value_error(self):
        from engine.utility import ComplexityBreakdown

        with pytest.raises(ValueError, match="finite"):
            ComplexityBreakdown(static=0.5, dynamic=float("inf"))

    def test_valid_values_accepted(self):
        from engine.utility import ComplexityBreakdown

        cb = ComplexityBreakdown(static=0.3, dynamic=0.7)
        assert cb.total == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# BH43-M3: value_variance negative silently floored to 0
# ---------------------------------------------------------------------------
class TestBH43M3ValueVarianceNegative:
    """UtilityCalculator.calculate() must reject negative value_variance."""

    def _make_calculator(self):
        from engine.utility import UtilityCalculator

        return UtilityCalculator()

    def _make_estimates(self):
        from engine.utility import ComplexityBreakdown, ThreePointEstimate

        return (
            ThreePointEstimate(best=100, likely=200, worst=300),
            ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1),
            ComplexityBreakdown(static=0.5, dynamic=0.5),
        )

    def test_negative_value_variance_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(ValueError, match="non-negative"):
            calc.calculate(p, r, c, value_variance=-100.0)

    def test_zero_value_variance_accepted(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        result = calc.calculate(p, r, c, value_variance=0.0)
        assert result.variance >= 0.0

    def test_value_variance_bool_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(TypeError, match="bool"):
            calc.calculate(p, r, c, value_variance=True)

    def test_value_variance_nan_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(ValueError, match="finite"):
            calc.calculate(p, r, c, value_variance=float("nan"))

    def test_value_variance_inf_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(ValueError, match="finite"):
            calc.calculate(p, r, c, value_variance=float("inf"))


# ---------------------------------------------------------------------------
# BH43-L2: value_low_conf / opex_delta not validated
# ---------------------------------------------------------------------------
class TestBH43L2ValueLowConfOpexDelta:
    """UtilityCalculator.calculate() must validate value_low_conf and opex_delta."""

    def _make_calculator(self):
        from engine.utility import UtilityCalculator

        return UtilityCalculator()

    def _make_estimates(self):
        from engine.utility import ComplexityBreakdown, ThreePointEstimate

        return (
            ThreePointEstimate(best=100, likely=200, worst=300),
            ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1),
            ComplexityBreakdown(static=0.5, dynamic=0.5),
        )

    def test_value_low_conf_nan_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(ValueError, match="finite"):
            calc.calculate(p, r, c, value_low_conf=float("nan"))

    def test_opex_delta_inf_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(ValueError, match="finite"):
            calc.calculate(p, r, c, opex_delta=float("inf"))

    def test_opex_delta_bool_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(TypeError, match="bool"):
            calc.calculate(p, r, c, opex_delta=True)


# ---------------------------------------------------------------------------
# BH43-L3: Covariance terms not validated
# ---------------------------------------------------------------------------
class TestBH43L3CovarianceValidation:
    """UtilityCalculator.calculate() must validate covariance terms."""

    def _make_calculator(self):
        from engine.utility import UtilityCalculator

        return UtilityCalculator()

    def _make_estimates(self):
        from engine.utility import ComplexityBreakdown, ThreePointEstimate

        return (
            ThreePointEstimate(best=100, likely=200, worst=300),
            ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1),
            ComplexityBreakdown(static=0.5, dynamic=0.5),
        )

    def test_cov_pv_nan_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(ValueError, match="finite"):
            calc.calculate(p, r, c, cov_pv=float("nan"))

    def test_cov_pr_inf_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(ValueError, match="finite"):
            calc.calculate(p, r, c, cov_pr=float("inf"))

    def test_cov_vr_bool_raises(self):
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        with pytest.raises(TypeError, match="bool"):
            calc.calculate(p, r, c, cov_vr=True)

    def test_none_covariance_accepted(self):
        """None covariance (independence assumption) should work fine."""
        calc = self._make_calculator()
        p, r, c = self._make_estimates()
        result = calc.calculate(p, r, c, cov_pv=None, cov_pr=None, cov_vr=None)
        assert math.isfinite(result.raw)


# ---------------------------------------------------------------------------
# BH43-M4+M5: TelemetryPipeline ingest aliasing
# ---------------------------------------------------------------------------
class TestBH43M4M5PipelineAliasing:
    """TelemetryPipeline.ingest() must deep-copy events to prevent aliasing."""

    def test_caller_mutation_after_ingest_does_not_corrupt_buffer(self):
        """Mutating an event dict after ingest() must not change buffered copy."""
        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        config = PipelineConfig(
            buffer_size=100,
            flush_threshold=100,
            strict_validation=False,
        )
        pipeline = TelemetryPipeline(config=config)

        event = {"event_id": "1", "metadata": {"key": "original"}}
        pipeline.ingest(event)

        # Mutate the caller's dict after ingest
        event["metadata"]["key"] = "mutated"
        event["event_id"] = "changed"

        # Buffer should be unaffected
        buffered = list(pipeline.buffer)
        assert len(buffered) == 1
        assert buffered[0]["event_id"] == "1"
        assert buffered[0]["metadata"]["key"] == "original"

    def test_nested_dict_isolation(self):
        """Nested dicts must be deeply copied, not shared."""
        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        config = PipelineConfig(
            buffer_size=100,
            flush_threshold=100,
            strict_validation=False,
        )
        pipeline = TelemetryPipeline(config=config)

        nested = {"inner": [1, 2, 3]}
        event = {"event_id": "1", "nested": nested}
        pipeline.ingest(event)

        # Mutate the nested structure
        nested["inner"].append(4)

        buffered = list(pipeline.buffer)
        assert buffered[0]["nested"]["inner"] == [1, 2, 3]


# ---------------------------------------------------------------------------
# BH43-L4: ProposalWorkflow.from_dict() uses cls() instead of cls.__new__()
# ---------------------------------------------------------------------------
class TestBH43L4ProposalFromDictNew:
    """ProposalWorkflow.from_dict() must use cls.__new__() to avoid __init__ side effects."""

    def test_from_dict_does_not_call_init(self):
        """from_dict() should not generate a spurious created_at timestamp."""
        from workflows.proposal import (
            ProposalMetadata,
            ProposalState,
            ProposalWorkflow,
        )

        original = ProposalWorkflow(
            metadata=ProposalMetadata(
                title="Test",
                description="Test description",
                author_id="author1",
            ),
        )
        original.submit("admin")
        original_data = original.to_dict()

        # Store original created_at
        original_created_at = original_data["created_at"]

        # Restore from dict — should preserve the exact timestamps
        restored = ProposalWorkflow.from_dict(original_data)
        assert restored.created_at.isoformat() == original_created_at
        assert restored.state == ProposalState.SUBMITTED
        assert restored.proposal_id == original.proposal_id

    def test_round_trip_preserves_state(self):
        """to_dict → from_dict should preserve all state exactly."""
        from workflows.proposal import (
            EvaluationResult,
            ProposalMetadata,
            ProposalState,
            ProposalWorkflow,
        )

        wf = ProposalWorkflow(
            metadata=ProposalMetadata(
                title="RT Test",
                description="Round trip",
                author_id="author",
            ),
        )
        wf.submit("admin")
        wf.start_evaluation("evaluator")
        wf.complete_evaluation(
            "evaluator",
            EvaluationResult(
                gate_results={"risk": True},
                all_passed=True,
                override_eligible=False,
                evaluated_at=datetime.now(timezone.utc),
                evaluator_id="evaluator",
            ),
        )

        data = wf.to_dict()
        restored = ProposalWorkflow.from_dict(data)

        assert restored.state == ProposalState.GATE_PASSED
        assert len(restored.transitions) == 3
        assert restored.evaluation_result is not None
        assert restored.evaluation_result.all_passed is True

    def test_from_dict_without_evaluation_result(self):
        """from_dict() on workflow without evaluation must not crash on to_dict()."""
        from workflows.proposal import (
            ProposalMetadata,
            ProposalState,
            ProposalWorkflow,
        )

        wf = ProposalWorkflow(
            metadata=ProposalMetadata(
                title="No Eval",
                description="Test without evaluation",
                author_id="author",
            ),
        )
        wf.submit("admin")
        data = wf.to_dict()

        restored = ProposalWorkflow.from_dict(data)
        assert restored.evaluation_result is None
        assert restored.state == ProposalState.SUBMITTED

        # Round-trip must not crash (the critical path)
        re_serialized = restored.to_dict()
        assert re_serialized["evaluation_result"] is None
