"""Tests for AEGIS Stripe Webhook Handler.

Tests cover:
- Stripe signature verification
- Subscription lifecycle events (created, updated, deleted)
- Invoice events (paid, payment_failed)
- Customer ID resolution from metadata
- Tier resolution from subscription items
- Error handling and edge cases
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any
from unittest.mock import MagicMock, patch

_TEST_WEBHOOK_SECRET = "whsec_test_secret"  # noqa: S105


def _make_stripe_event(
    event_type: str,
    data_object: dict[str, Any],
    webhook_secret: str = _TEST_WEBHOOK_SECRET,
) -> dict[str, Any]:
    """Build a mock API Gateway event for a Stripe webhook."""
    payload = json.dumps(
        {
            "id": "evt_test_123",
            "type": event_type,
            "data": {"object": data_object},
        }
    )

    # Generate valid Stripe signature
    timestamp = str(int(time.time()))
    signed_payload = f"{timestamp}.{payload}"
    sig = hmac.new(
        webhook_secret.encode("utf-8"),
        signed_payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    return {
        "httpMethod": "POST",
        "path": "/webhooks/stripe",
        "headers": {
            "Stripe-Signature": f"t={timestamp},v1={sig}",
        },
        "body": payload,
    }


def _make_subscription_object(
    customer_id: str = "cust_test1",
    tier: str = "professional",
    status: str = "active",
) -> dict[str, Any]:
    """Build a mock Stripe subscription object."""
    return {
        "id": "sub_test_123",
        "customer": "cus_stripe_123",
        "status": status,
        "metadata": {"aegis_customer_id": customer_id, "aegis_tier": tier},
        "items": {
            "data": [
                {
                    "price": {
                        "metadata": {"aegis_tier": tier},
                    },
                }
            ]
        },
        "current_period_start": int(time.time()),
        "current_period_end": int(time.time()) + 2592000,  # +30 days
        "cancel_at_period_end": False,
    }


# ---------------------------------------------------------------------------
# Signature verification tests
# ---------------------------------------------------------------------------


class TestStripeSignatureVerification:
    """Test Stripe webhook signature verification."""

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    @patch("aegis_governance.stripe_webhook._get_customer_manager")
    def test_valid_signature_accepted(
        self, mock_mgr: MagicMock, mock_secret: MagicMock
    ) -> None:
        from aegis_governance.stripe_webhook import handler

        mock_mgr.return_value.upsert_subscription.return_value = None
        mock_mgr.return_value.update_customer.return_value = None

        event = _make_stripe_event(
            "customer.subscription.created",
            _make_subscription_object(),
        )
        result = handler(event, None)
        assert result["statusCode"] == 200

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    def test_invalid_signature_rejected(self, mock_secret: MagicMock) -> None:
        from aegis_governance.stripe_webhook import handler

        event = _make_stripe_event(
            "customer.subscription.created",
            _make_subscription_object(),
        )
        # Tamper with the signature
        event["headers"]["Stripe-Signature"] = "t=123,v1=invalid_signature"
        result = handler(event, None)
        assert result["statusCode"] == 401

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    def test_missing_signature_rejected(self, mock_secret: MagicMock) -> None:
        from aegis_governance.stripe_webhook import handler

        event = _make_stripe_event(
            "customer.subscription.created",
            _make_subscription_object(),
        )
        event["headers"] = {}
        result = handler(event, None)
        assert result["statusCode"] == 401

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    def test_expired_timestamp_rejected(self, mock_secret: MagicMock) -> None:
        from aegis_governance.stripe_webhook import handler

        payload = json.dumps(
            {
                "id": "evt_test",
                "type": "customer.subscription.created",
                "data": {"object": _make_subscription_object()},
            }
        )
        # Use an old timestamp (>5 min)
        old_ts = str(int(time.time()) - 600)
        sig = hmac.new(
            b"whsec_test_secret",
            f"{old_ts}.{payload}".encode(),
            hashlib.sha256,
        ).hexdigest()

        event = {
            "httpMethod": "POST",
            "path": "/webhooks/stripe",
            "headers": {"Stripe-Signature": f"t={old_ts},v1={sig}"},
            "body": payload,
        }
        result = handler(event, None)
        assert result["statusCode"] == 401


# ---------------------------------------------------------------------------
# Subscription lifecycle tests
# ---------------------------------------------------------------------------


class TestSubscriptionCreated:
    """Test customer.subscription.created handler."""

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    @patch("aegis_governance.stripe_webhook._get_customer_manager")
    def test_creates_subscription_record(
        self, mock_mgr: MagicMock, mock_secret: MagicMock
    ) -> None:
        from aegis_governance.stripe_webhook import handler

        mock_mgr.return_value.upsert_subscription.return_value = None
        mock_mgr.return_value.update_customer.return_value = None

        event = _make_stripe_event(
            "customer.subscription.created",
            _make_subscription_object(customer_id="cust_abc", tier="enterprise"),
        )
        result = handler(event, None)
        assert result["statusCode"] == 200

        # Verify subscription was upserted
        mock_mgr.return_value.upsert_subscription.assert_called_once()
        sub_arg = mock_mgr.return_value.upsert_subscription.call_args[0][0]
        assert sub_arg.customer_id == "cust_abc"
        assert sub_arg.tier == "enterprise"

        # Verify customer tier was updated
        mock_mgr.return_value.update_customer.assert_called_once_with(
            "cust_abc", tier="enterprise"
        )

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    @patch("aegis_governance.stripe_webhook._get_customer_manager")
    def test_missing_customer_id_handled_gracefully(
        self, mock_mgr: MagicMock, mock_secret: MagicMock
    ) -> None:
        from aegis_governance.stripe_webhook import handler

        sub = _make_subscription_object()
        sub["metadata"] = {}  # No aegis_customer_id

        event = _make_stripe_event("customer.subscription.created", sub)
        result = handler(event, None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert "warning" in body


class TestSubscriptionUpdated:
    """Test customer.subscription.updated handler."""

    @patch("aegis_governance.stripe_webhook._update_unkey_key_metadata")
    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    @patch("aegis_governance.stripe_webhook._get_customer_manager")
    def test_updates_tier_and_subscription(
        self,
        mock_mgr: MagicMock,
        mock_secret: MagicMock,
        mock_unkey_update: MagicMock,
    ) -> None:
        from aegis_governance.stripe_webhook import handler

        mock_mgr.return_value.upsert_subscription.return_value = None
        mock_mgr.return_value.update_customer.return_value = None

        event = _make_stripe_event(
            "customer.subscription.updated",
            _make_subscription_object(tier="enterprise"),
        )
        result = handler(event, None)
        assert result["statusCode"] == 200
        mock_mgr.return_value.update_customer.assert_called_once_with(
            "cust_test1", tier="enterprise"
        )
        mock_unkey_update.assert_called_once_with("cust_test1", "enterprise")


class TestSubscriptionDeleted:
    """Test customer.subscription.deleted handler."""

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    @patch("aegis_governance.stripe_webhook._get_customer_manager")
    def test_downgrades_to_community(
        self, mock_mgr: MagicMock, mock_secret: MagicMock
    ) -> None:
        from aegis_governance.stripe_webhook import handler

        mock_mgr.return_value.upsert_subscription.return_value = None
        mock_mgr.return_value.update_customer.return_value = None

        event = _make_stripe_event(
            "customer.subscription.deleted",
            _make_subscription_object(tier="professional"),
        )
        result = handler(event, None)
        assert result["statusCode"] == 200

        sub_arg = mock_mgr.return_value.upsert_subscription.call_args[0][0]
        assert sub_arg.tier == "community"
        assert sub_arg.status == "canceled"

        mock_mgr.return_value.update_customer.assert_called_once_with(
            "cust_test1", tier="community"
        )


# ---------------------------------------------------------------------------
# Invoice tests
# ---------------------------------------------------------------------------


class TestInvoicePaid:
    """Test invoice.paid handler."""

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    @patch("aegis_governance.stripe_webhook._get_customer_manager")
    def test_invoice_paid_logged(
        self, mock_mgr: MagicMock, mock_secret: MagicMock
    ) -> None:
        from aegis_governance.stripe_webhook import handler

        invoice = {
            "id": "inv_test_123",
            "amount_paid": 350000,
            "currency": "usd",
            "subscription_details": {
                "metadata": {"aegis_customer_id": "cust_test1"},
            },
        }
        event = _make_stripe_event("invoice.paid", invoice)
        result = handler(event, None)
        assert result["statusCode"] == 200


class TestInvoicePaymentFailed:
    """Test invoice.payment_failed handler."""

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    @patch("aegis_governance.stripe_webhook._get_customer_manager")
    def test_marks_past_due(self, mock_mgr: MagicMock, mock_secret: MagicMock) -> None:
        from aegis_governance.customer import Subscription
        from aegis_governance.stripe_webhook import handler

        existing_sub = Subscription(
            customer_id="cust_test1",
            stripe_subscription_id="sub_123",
            status="active",
        )
        mock_mgr.return_value.get_subscription.return_value = existing_sub
        mock_mgr.return_value.upsert_subscription.return_value = None

        invoice = {
            "id": "inv_fail_123",
            "subscription_details": {
                "metadata": {"aegis_customer_id": "cust_test1"},
            },
        }
        event = _make_stripe_event("invoice.payment_failed", invoice)
        result = handler(event, None)
        assert result["statusCode"] == 200

        # Verify subscription was marked past_due
        mock_mgr.return_value.upsert_subscription.assert_called_once()
        updated_sub = mock_mgr.return_value.upsert_subscription.call_args[0][0]
        assert updated_sub.status == "past_due"


# ---------------------------------------------------------------------------
# Unhandled event tests
# ---------------------------------------------------------------------------


class TestUnhandledEvents:
    """Test that unknown event types are acknowledged without error."""

    @patch(
        "aegis_governance.stripe_webhook._get_webhook_secret",
        return_value="whsec_test_secret",
    )
    def test_unknown_event_type_returns_200(self, mock_secret: MagicMock) -> None:
        from aegis_governance.stripe_webhook import handler

        event = _make_stripe_event("charge.succeeded", {"id": "ch_123"})
        result = handler(event, None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["received"] is True


# ---------------------------------------------------------------------------
# Routing tests
# ---------------------------------------------------------------------------


class TestWebhookRouting:
    """Test route matching."""

    def test_wrong_path_returns_404(self) -> None:
        from aegis_governance.stripe_webhook import handler

        event = {"httpMethod": "POST", "path": "/webhooks/other", "headers": {}}
        result = handler(event, None)
        assert result["statusCode"] == 404

    def test_wrong_method_returns_404(self) -> None:
        from aegis_governance.stripe_webhook import handler

        event = {"httpMethod": "GET", "path": "/webhooks/stripe", "headers": {}}
        result = handler(event, None)
        assert result["statusCode"] == 404


# ---------------------------------------------------------------------------
# Tier resolution tests
# ---------------------------------------------------------------------------


class TestTierResolution:
    """Test tier resolution from Stripe subscription data."""

    def test_resolve_from_price_metadata(self) -> None:
        from aegis_governance.stripe_webhook import _resolve_tier_from_subscription

        sub = _make_subscription_object(tier="enterprise")
        assert _resolve_tier_from_subscription(sub) == "enterprise"

    def test_resolve_from_subscription_metadata(self) -> None:
        from aegis_governance.stripe_webhook import _resolve_tier_from_subscription

        sub = {
            "items": {"data": []},
            "metadata": {"aegis_tier": "financial_services"},
        }
        assert _resolve_tier_from_subscription(sub) == "financial_services"

    def test_missing_metadata_returns_none(self) -> None:
        from aegis_governance.stripe_webhook import _resolve_tier_from_subscription

        sub = {"items": {"data": []}, "metadata": {}}
        assert _resolve_tier_from_subscription(sub) is None
