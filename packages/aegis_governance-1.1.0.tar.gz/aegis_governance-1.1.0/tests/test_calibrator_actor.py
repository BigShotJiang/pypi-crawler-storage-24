"""
Tests for src/actors/calibrator.py — Calibrator actor.

Tests cover:
- Initialization, roles, and capabilities
- CalibrationProposal and CalibrationStatus dataclasses
- Drift threshold calibration proposals
- Bayesian prior update proposals
- Gate parameter threshold proposals
- Approval workflow (approve, reject, apply lifecycle)
- Thread safety
"""

import threading
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest

from actors.base import ActorCapabilities, ActorRole
from actors.calibrator import (
    CalibrationProposal,
    CalibrationStatus,
    Calibrator,
)
from engine.bayesian import BayesianPosterior
from engine.drift import DriftMonitor
from engine.gates import GateEvaluator

# ---------------------------------------------------------------------------
# TestCalibratorInit
# ---------------------------------------------------------------------------


class TestCalibratorInit:
    """Tests for Calibrator actor initialization."""

    def test_basic_init(self):
        """Test basic initialization sets correct attributes."""
        cal = Calibrator("cal-1", "Threshold Tuner")

        assert cal.actor_id == "cal-1"
        assert cal.name == "Threshold Tuner"
        assert ActorRole.CALIBRATOR in cal.roles
        assert cal.proposals == {}
        assert len(cal.proposal_history) == 0

    def test_with_additional_roles(self):
        """Test additional roles are merged."""
        cal = Calibrator(
            "cal-1",
            "Tuner",
            additional_roles={ActorRole.ANALYST},
        )
        assert ActorRole.CALIBRATOR in cal.roles
        assert ActorRole.ANALYST in cal.roles

    def test_capabilities(self):
        """Test calibrator has correct default capabilities."""
        cal = Calibrator("cal-1", "Tuner")
        assert cal.capabilities.can_evaluate_gates is True
        assert cal.capabilities.can_vote is True
        assert cal.capabilities.can_configure is True
        # Must NOT have override or approve
        assert cal.capabilities.can_override is False
        assert cal.capabilities.can_approve is False

    def test_primary_role(self):
        """Test primary role is CALIBRATOR."""
        cal = Calibrator("cal-1", "Tuner")
        assert cal.get_primary_role() == ActorRole.CALIBRATOR

    def test_allowed_actions(self):
        """Test allowed actions list."""
        cal = Calibrator("cal-1", "Tuner")
        actions = cal.get_allowed_actions()
        assert "propose_drift_calibration" in actions
        assert "propose_prior_update" in actions
        assert "propose_gate_threshold" in actions
        assert "approve_calibration" in actions
        assert "reject_calibration" in actions
        assert "apply_calibration" in actions
        assert "get_proposal_status" in actions
        assert "list_proposals" in actions

    def test_repr(self):
        """Test __repr__ output."""
        cal = Calibrator("cal-1", "Tuner")
        r = repr(cal)
        assert "cal-1" in r
        assert "Tuner" in r
        assert "proposals=0" in r

    def test_history_limit(self):
        """Test custom history limit."""
        cal = Calibrator("cal-1", "Tuner", history_limit=5)
        assert cal.proposal_history.maxlen == 5


# ---------------------------------------------------------------------------
# TestCalibrationDataclasses
# ---------------------------------------------------------------------------


class TestCalibrationDataclasses:
    """Tests for CalibrationStatus and CalibrationProposal."""

    def test_status_values(self):
        """Test CalibrationStatus enum values."""
        assert CalibrationStatus.PROPOSED.value == "proposed"
        assert CalibrationStatus.APPROVED.value == "approved"
        assert CalibrationStatus.REJECTED.value == "rejected"
        assert CalibrationStatus.APPLIED.value == "applied"

    def test_proposal_defaults(self):
        """Test CalibrationProposal default values."""
        p = CalibrationProposal(
            proposal_id="p-1",
            parameter_name="tau_warning",
            current_value=0.1,
            proposed_value=0.15,
            justification="Recalibration",
            data_window=100,
            statistical_method="percentile_p90",
        )
        assert p.status == CalibrationStatus.PROPOSED
        assert isinstance(p.created_at, datetime)
        assert p.created_at.tzinfo == timezone.utc
        assert p.reviewed_by is None
        assert p.review_reason is None

    def test_proposal_repr(self):
        """Test CalibrationProposal __repr__."""
        p = CalibrationProposal(
            proposal_id="p-1",
            parameter_name="tau_warning",
            current_value=0.1,
            proposed_value=0.15,
            justification="test",
            data_window=50,
            statistical_method="percentile_p90",
        )
        r = repr(p)
        assert "p-1" in r
        assert "tau_warning" in r
        assert "proposed" in r


# ---------------------------------------------------------------------------
# TestDriftCalibration
# ---------------------------------------------------------------------------


class TestDriftCalibration:
    """Tests for propose_drift_calibration."""

    def _make_detector(self, tau_warning=0.1, tau_critical=0.5):
        return DriftMonitor(tau_warning=tau_warning, tau_critical=tau_critical)

    def test_success_creates_proposals(self):
        """Test successful calibration creates proposals for changed thresholds."""
        cal = Calibrator("cal-1", "Tuner")
        det = self._make_detector(tau_warning=0.1, tau_critical=0.5)
        # Historical values that will produce different P90/P99
        kl_values = [0.01 * i for i in range(1, 101)]  # 0.01 to 1.0

        result = cal.propose_drift_calibration(
            "batch-1", det, kl_values, justification="Monthly recal"
        )
        assert result.success is True
        assert result.result_data is not None
        assert result.result_data["batch_id"] == "batch-1"
        # Should have created sub-proposals
        assert len(result.result_data["proposals"]) > 0

    def test_no_capability_fails(self):
        """Test without configure capability fails."""
        cal = Calibrator("cal-1", "Tuner")
        cal.capabilities = ActorCapabilities()  # No capabilities
        det = self._make_detector()

        result = cal.propose_drift_calibration("batch-1", det, [0.1, 0.2, 0.3])
        assert result.success is False
        assert "configure" in result.error

    def test_duplicate_proposal_id_fails(self):
        """Test duplicate proposal ID is rejected."""
        cal = Calibrator("cal-1", "Tuner")
        det = self._make_detector()
        kl_values = [0.01 * i for i in range(1, 101)]

        cal.propose_drift_calibration("batch-1", det, kl_values)
        # Second call with same ID uses a sub-proposal ID format,
        # so use propose_gate_threshold to occupy the exact ID
        cal.proposals["batch-2"] = CalibrationProposal(
            proposal_id="batch-2",
            parameter_name="tau_warning",
            current_value=0.1,
            proposed_value=0.15,
            justification="x",
            data_window=1,
            statistical_method="test",
        )
        result = cal.propose_drift_calibration("batch-2", det, kl_values)
        assert result.success is False
        assert "already exists" in result.error

    def test_empty_data_returns_unchanged(self):
        """Test empty historical data produces no proposals."""
        cal = Calibrator("cal-1", "Tuner")
        det = self._make_detector(tau_warning=0.1, tau_critical=0.5)

        result = cal.propose_drift_calibration("batch-1", det, [])
        assert result.success is True
        # calibrate_thresholds returns originals for empty data
        assert result.result_data["proposals"] == []

    def test_nan_inf_filtered(self):
        """Test NaN and inf values are handled gracefully."""
        cal = Calibrator("cal-1", "Tuner")
        det = self._make_detector()

        result = cal.propose_drift_calibration(
            "batch-1", det, [float("nan"), float("inf"), float("-inf")]
        )
        # calibrate_thresholds filters non-finite, returns originals
        assert result.success is True

    def test_emits_telemetry(self):
        """Test telemetry emission when emitter provided."""
        cal = Calibrator("cal-1", "Tuner")
        det = self._make_detector(tau_warning=0.1, tau_critical=0.5)
        kl_values = [0.01 * i for i in range(1, 101)]

        emitter = MagicMock()
        cal.propose_drift_calibration(
            "batch-1", det, kl_values, telemetry_emitter=emitter
        )
        emitter.emit.assert_called_once()
        call_kwargs = emitter.emit.call_args
        assert call_kwargs[1]["payload"]["method"] == "drift_calibration"


# ---------------------------------------------------------------------------
# TestPriorUpdate
# ---------------------------------------------------------------------------


class TestPriorUpdate:
    """Tests for propose_prior_update."""

    def _make_bayesian(self, prior_mean=0.0, prior_std=1.0):
        return BayesianPosterior(
            prior_mean=prior_mean,
            prior_std=prior_std,
            likelihood_std=0.5,
        )

    def test_success_creates_proposals(self):
        """Test successful prior update creates proposals."""
        cal = Calibrator("cal-1", "Tuner")
        bay = self._make_bayesian(prior_mean=0.0, prior_std=1.0)
        # Observations that shift the mean
        observations = [2.0, 2.5, 3.0, 2.8, 2.2, 2.6, 2.4, 2.7]

        result = cal.propose_prior_update(
            "prior-1", bay, observations, justification="Empirical update"
        )
        assert result.success is True
        assert result.result_data is not None
        assert len(result.result_data["proposals"]) > 0

    def test_no_capability_fails(self):
        """Test without evaluate_gates capability fails."""
        cal = Calibrator("cal-1", "Tuner")
        cal.capabilities = ActorCapabilities()  # No capabilities
        bay = self._make_bayesian()

        result = cal.propose_prior_update("prior-1", bay, [1.0, 2.0])
        assert result.success is False
        assert "configure capability" in result.error

    def test_prior_update_requires_can_configure_not_can_evaluate_gates(self):
        """Regression: propose_prior_update must check can_configure, not can_evaluate_gates (BH11-M3)."""
        cal = Calibrator("cal-1", "Tuner")
        # Grant can_evaluate_gates but NOT can_configure
        cal.capabilities.can_evaluate_gates = True
        cal.capabilities.can_configure = False
        bay = self._make_bayesian()

        result = cal.propose_prior_update("prior-1", bay, [1.0, 2.0])
        assert result.success is False
        assert "configure capability" in result.error

    def test_duplicate_proposal_id_fails(self):
        """Test duplicate proposal ID is rejected."""
        cal = Calibrator("cal-1", "Tuner")
        bay = self._make_bayesian()
        # Pre-occupy the proposal ID
        cal.proposals["prior-1"] = CalibrationProposal(
            proposal_id="prior-1",
            parameter_name="prior_mean",
            current_value=0.0,
            proposed_value=1.0,
            justification="x",
            data_window=1,
            statistical_method="test",
        )

        result = cal.propose_prior_update("prior-1", bay, [1.0, 2.0])
        assert result.success is False
        assert "already exists" in result.error

    def test_empty_observations_no_change(self):
        """Test empty observations produces no proposals."""
        cal = Calibrator("cal-1", "Tuner")
        bay = self._make_bayesian()

        result = cal.propose_prior_update("prior-1", bay, [])
        assert result.success is True
        assert result.result_data["proposals"] == []

    def test_emits_telemetry(self):
        """Test telemetry emission when emitter provided."""
        cal = Calibrator("cal-1", "Tuner")
        bay = self._make_bayesian(prior_mean=0.0, prior_std=1.0)
        observations = [5.0] * 30  # Strong shift

        emitter = MagicMock()
        cal.propose_prior_update(
            "prior-1", bay, observations, telemetry_emitter=emitter
        )
        emitter.emit.assert_called_once()
        call_kwargs = emitter.emit.call_args
        assert call_kwargs[1]["payload"]["method"] == "prior_update"


# ---------------------------------------------------------------------------
# TestGateThreshold
# ---------------------------------------------------------------------------


class TestGateThreshold:
    """Tests for propose_gate_threshold."""

    def test_success(self):
        """Test successful gate threshold proposal."""
        cal = Calibrator("cal-1", "Tuner")

        result = cal.propose_gate_threshold(
            proposal_id="gt-1",
            parameter_name="epsilon_R",
            current_value=0.01,
            proposed_value=0.02,
            justification="Increased to reduce noise",
            data_window=200,
            statistical_method="z_test",
        )
        assert result.success is True
        assert result.result_data["parameter"] == "epsilon_R"
        assert "gt-1" in cal.proposals

    def test_unrecognized_parameter_fails(self):
        """Test unrecognized parameter is rejected."""
        cal = Calibrator("cal-1", "Tuner")

        result = cal.propose_gate_threshold(
            proposal_id="gt-1",
            parameter_name="not_a_real_param",
            current_value=0.0,
            proposed_value=1.0,
            justification="test",
            data_window=10,
            statistical_method="bootstrap",
        )
        assert result.success is False
        assert "Unrecognized parameter" in result.error

    def test_duplicate_proposal_id_fails(self):
        """Test duplicate proposal ID is rejected."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "gt-1", "epsilon_R", 0.01, 0.02, "test", 10, "z_test"
        )

        result = cal.propose_gate_threshold(
            "gt-1", "epsilon_P", 0.01, 0.03, "test2", 20, "z_test"
        )
        assert result.success is False
        assert "already exists" in result.error

    @pytest.mark.parametrize(
        "param",
        [
            "epsilon_R",
            "epsilon_P",
            "risk_trigger_factor",
            "tau_warning",
            "tau_critical",
            "prior_mean",
            "likelihood_std",
            "novelty_N0",
            "complexity_floor",
            "quality_min_score",
            "utility_threshold",
        ],
    )
    def test_recognized_parameters_accepted(self, param):
        """Test all recognized parameters are accepted."""
        cal = Calibrator("cal-1", "Tuner")
        result = cal.propose_gate_threshold(
            proposal_id=f"gt-{param}",
            parameter_name=param,
            current_value=0.1,
            proposed_value=0.2,
            justification="parametrize test",
            data_window=50,
            statistical_method="bootstrap",
        )
        assert result.success is True

    def test_no_capability_fails(self):
        """Test without configure capability fails."""
        cal = Calibrator("cal-1", "Tuner")
        cal.capabilities = ActorCapabilities()

        result = cal.propose_gate_threshold(
            "gt-1", "epsilon_R", 0.01, 0.02, "test", 10, "z_test"
        )
        assert result.success is False
        assert "configure" in result.error


# ---------------------------------------------------------------------------
# TestApprovalWorkflow
# ---------------------------------------------------------------------------


class TestApprovalWorkflow:
    """Tests for approve/reject/apply calibration lifecycle."""

    def _make_cal_with_proposal(self, proposal_id="p-1", param="epsilon_R"):
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            proposal_id=proposal_id,
            parameter_name=param,
            current_value=0.01,
            proposed_value=0.02,
            justification="test",
            data_window=50,
            statistical_method="z_test",
        )
        return cal

    def test_approve(self):
        """Test approving a proposed calibration."""
        cal = self._make_cal_with_proposal()

        result = cal.approve_calibration("p-1", "reviewer-1", "Looks good")
        assert result.success is True
        assert cal.proposals["p-1"].status == CalibrationStatus.APPROVED
        assert cal.proposals["p-1"].reviewed_by == "reviewer-1"

    def test_reject(self):
        """Test rejecting a proposed calibration."""
        cal = self._make_cal_with_proposal()

        result = cal.reject_calibration("p-1", "reviewer-1", "Insufficient evidence")
        assert result.success is True
        assert cal.proposals["p-1"].status == CalibrationStatus.REJECTED

    def test_approve_unknown_id_fails(self):
        """Test approving nonexistent proposal fails."""
        cal = Calibrator("cal-1", "Tuner")

        result = cal.approve_calibration("missing", "reviewer-1")
        assert result.success is False
        assert "not found" in result.error

    def test_reject_unknown_id_fails(self):
        """Test rejecting nonexistent proposal fails."""
        cal = Calibrator("cal-1", "Tuner")

        result = cal.reject_calibration("missing", "reviewer-1", "nope")
        assert result.success is False
        assert "not found" in result.error

    def test_approve_non_proposed_fails(self):
        """Test approving an already-approved proposal fails."""
        cal = self._make_cal_with_proposal()
        cal.approve_calibration("p-1", "reviewer-1")

        result = cal.approve_calibration("p-1", "reviewer-2")
        assert result.success is False
        assert "approved" in result.error

    def test_reject_non_proposed_fails(self):
        """Test rejecting an already-rejected proposal fails."""
        cal = self._make_cal_with_proposal()
        cal.reject_calibration("p-1", "reviewer-1", "no")

        result = cal.reject_calibration("p-1", "reviewer-2", "also no")
        assert result.success is False
        assert "rejected" in result.error

    def test_apply_gate_threshold(self):
        """Test applying an approved gate threshold change."""
        cal = self._make_cal_with_proposal()
        cal.approve_calibration("p-1", "reviewer-1")

        ge = GateEvaluator(epsilon_R=0.01)
        result = cal.apply_calibration("p-1", gate_evaluator=ge)
        assert result.success is True
        assert ge.epsilon_R == 0.02
        assert cal.proposals["p-1"].status == CalibrationStatus.APPLIED

    def test_apply_drift_threshold(self):
        """Test applying an approved drift threshold change."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "d-1", "tau_warning", 0.1, 0.15, "test", 50, "percentile_p90"
        )
        cal.approve_calibration("d-1", "reviewer-1")

        det = DriftMonitor(tau_warning=0.1, tau_critical=0.5)
        result = cal.apply_calibration("d-1", drift_detector=det)
        assert result.success is True
        assert det.tau_warning == 0.15

    def test_apply_without_approval_fails(self):
        """Test applying a non-approved proposal fails."""
        cal = self._make_cal_with_proposal()

        ge = GateEvaluator()
        result = cal.apply_calibration("p-1", gate_evaluator=ge)
        assert result.success is False
        assert "approved" in result.error

    def test_apply_unknown_id_fails(self):
        """Test applying nonexistent proposal fails."""
        cal = Calibrator("cal-1", "Tuner")

        result = cal.apply_calibration("missing")
        assert result.success is False
        assert "not found" in result.error

    def test_apply_no_capability_fails(self):
        """Test applying without configure capability fails."""
        cal = self._make_cal_with_proposal()
        cal.approve_calibration("p-1", "reviewer-1")
        cal.capabilities = ActorCapabilities()

        result = cal.apply_calibration("p-1", gate_evaluator=GateEvaluator())
        assert result.success is False
        assert "configure" in result.error

    def test_apply_drift_without_detector_fails(self):
        """Test applying drift threshold without detector fails."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "d-1", "tau_warning", 0.1, 0.15, "test", 50, "percentile_p90"
        )
        cal.approve_calibration("d-1", "reviewer-1")

        result = cal.apply_calibration("d-1")  # No drift_detector
        assert result.success is False
        assert "drift_detector required" in result.error

    def test_apply_gate_without_evaluator_fails(self):
        """Test applying gate threshold without evaluator fails."""
        cal = self._make_cal_with_proposal()
        cal.approve_calibration("p-1", "reviewer-1")

        result = cal.apply_calibration("p-1")  # No gate_evaluator
        assert result.success is False
        assert "gate_evaluator required" in result.error

    def test_apply_prior_returns_advisory(self):
        """Test applying prior_mean returns advisory (BayesianPosterior is immutable)."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "pr-1", "prior_mean", 0.0, 1.5, "test", 50, "bayesian_update"
        )
        cal.approve_calibration("pr-1", "reviewer-1")

        result = cal.apply_calibration("pr-1")
        assert result.success is True
        assert result.result_data["target"] == "bayesian_prior"
        assert "immutable" in result.result_data["note"]
        assert cal.proposals["pr-1"].status == CalibrationStatus.APPLIED

    def test_apply_emits_telemetry(self):
        """Test apply emits THRESHOLD_UPDATED telemetry."""
        cal = self._make_cal_with_proposal()
        cal.approve_calibration("p-1", "reviewer-1")

        emitter = MagicMock()
        ge = GateEvaluator(epsilon_R=0.01)
        cal.apply_calibration("p-1", gate_evaluator=ge, telemetry_emitter=emitter)
        emitter.emit.assert_called_once()

    def test_full_lifecycle(self):
        """Test full propose -> approve -> apply lifecycle."""
        cal = Calibrator("cal-1", "Tuner")
        ge = GateEvaluator(novelty_threshold=0.8)

        # Propose
        propose_result = cal.propose_gate_threshold(
            "lc-1",
            "novelty_threshold",
            0.8,
            0.85,
            "Increased novelty sensitivity",
            300,
            "bootstrap_ci",
        )
        assert propose_result.success is True
        assert cal.proposals["lc-1"].status == CalibrationStatus.PROPOSED

        # Approve
        approve_result = cal.approve_calibration(
            "lc-1", "risk-lead-1", "Evidence sufficient"
        )
        assert approve_result.success is True
        assert cal.proposals["lc-1"].status == CalibrationStatus.APPROVED

        # Apply
        apply_result = cal.apply_calibration("lc-1", gate_evaluator=ge)
        assert apply_result.success is True
        assert ge.novelty_threshold == 0.85
        assert cal.proposals["lc-1"].status == CalibrationStatus.APPLIED


# ---------------------------------------------------------------------------
# TestQueryMethods
# ---------------------------------------------------------------------------


class TestQueryMethods:
    """Tests for get_proposal_status and list_proposals."""

    def test_get_proposal_status(self):
        """Test getting status of an existing proposal."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold("q-1", "epsilon_R", 0.01, 0.02, "test", 10, "z_test")

        result = cal.get_proposal_status("q-1")
        assert result.success is True
        assert result.result_data["parameter"] == "epsilon_R"
        assert result.result_data["status"] == "proposed"

    def test_get_proposal_status_not_found(self):
        """Test getting status of nonexistent proposal."""
        cal = Calibrator("cal-1", "Tuner")

        result = cal.get_proposal_status("missing")
        assert result.success is False
        assert "not found" in result.error

    def test_list_proposals_all(self):
        """Test listing all proposals."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "q-1", "epsilon_R", 0.01, 0.02, "test1", 10, "z_test"
        )
        cal.propose_gate_threshold(
            "q-2", "epsilon_P", 0.01, 0.03, "test2", 20, "z_test"
        )

        result = cal.list_proposals()
        assert result.success is True
        assert result.result_data["count"] == 2

    def test_list_proposals_filtered(self):
        """Test listing proposals with status filter."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "q-1", "epsilon_R", 0.01, 0.02, "test1", 10, "z_test"
        )
        cal.propose_gate_threshold(
            "q-2", "epsilon_P", 0.01, 0.03, "test2", 20, "z_test"
        )
        cal.approve_calibration("q-1", "reviewer-1")

        result = cal.list_proposals(status_filter=CalibrationStatus.APPROVED)
        assert result.success is True
        assert result.result_data["count"] == 1
        assert result.result_data["proposals"][0]["proposal_id"] == "q-1"


# ---------------------------------------------------------------------------
# TestThreadSafety
# ---------------------------------------------------------------------------


class TestThreadSafety:
    """Tests for thread safety."""

    def test_lock_exists(self):
        """Test calibrator has a threading lock."""
        cal = Calibrator("cal-1", "Tuner")
        assert isinstance(cal._lock, type(threading.Lock()))

    def test_concurrent_proposals(self):
        """Test concurrent proposal creation doesn't corrupt state."""
        cal = Calibrator("cal-1", "Tuner")
        errors: list[str] = []

        def make_proposal(i: int) -> None:
            try:
                result = cal.propose_gate_threshold(
                    proposal_id=f"concurrent-{i}",
                    parameter_name="epsilon_R",
                    current_value=0.01,
                    proposed_value=0.01 + i * 0.001,
                    justification=f"Thread {i}",
                    data_window=10,
                    statistical_method="z_test",
                )
                if not result.success:
                    errors.append(f"Thread {i} failed: {result.error}")
            except Exception as exc:
                errors.append(f"Thread {i} exception: {exc}")

        threads = [threading.Thread(target=make_proposal, args=(i,)) for i in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Errors: {errors}"
        assert len(cal.proposals) == 20


# ---------------------------------------------------------------------------
# TestUltrathinkRegression — regression tests for ultrathink findings
# ---------------------------------------------------------------------------


class TestUltrathinkRegression:
    """Regression tests for ultrathink findings U-1 through U-5."""

    def test_u1_invalid_drift_thresholds_returns_action_result(self):
        """U-1: update_thresholds ValueError returns ActionResult, not exception.

        DriftMonitor.update_thresholds() raises ValueError if
        tau_warning >= tau_critical. The Calibrator must catch this
        and return a failed ActionResult with status reverted to APPROVED.
        """
        cal = Calibrator("cal-1", "Tuner")
        # Propose tau_warning higher than existing tau_critical (0.5)
        cal.propose_gate_threshold(
            "u1-1", "tau_warning", 0.1, 0.9, "test", 50, "percentile_p90"
        )
        cal.approve_calibration("u1-1", "reviewer-1")

        det = DriftMonitor(tau_warning=0.1, tau_critical=0.5)
        # This would raise ValueError("tau_warning must be < tau_critical")
        # without the U-1 fix; should now return failed ActionResult
        result = cal.apply_calibration("u1-1", drift_detector=det)
        assert result.success is False
        assert "Apply failed" in result.error
        # Status must revert to APPROVED for retry
        assert cal.proposals["u1-1"].status == CalibrationStatus.APPROVED

    def test_u2_negative_epsilon_rejected(self):
        """U-2: Negative epsilon_R/epsilon_P rejected by _validate_gate_param.

        GateEvaluator uses epsilon as a denominator; zero or negative
        would cause division by zero. The validator must catch this
        before setattr.
        """
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "u2-1", "epsilon_R", 0.01, -0.01, "test", 50, "z_test"
        )
        cal.approve_calibration("u2-1", "reviewer-1")

        ge = GateEvaluator(epsilon_R=0.01)
        result = cal.apply_calibration("u2-1", gate_evaluator=ge)
        assert result.success is False
        assert "must be positive" in result.error
        # Original value preserved
        assert ge.epsilon_R == 0.01
        # Status reverted for retry
        assert cal.proposals["u2-1"].status == CalibrationStatus.APPROVED

    def test_u2_zero_epsilon_rejected(self):
        """U-2: Zero epsilon_P is also rejected (must be > 0, not >= 0)."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold("u2-2", "epsilon_P", 0.01, 0.0, "test", 50, "z_test")
        cal.approve_calibration("u2-2", "reviewer-1")

        ge = GateEvaluator(epsilon_P=0.01)
        result = cal.apply_calibration("u2-2", gate_evaluator=ge)
        assert result.success is False
        assert "must be positive" in result.error

    def test_u2_zero_trigger_factor_rejected(self):
        """U-2: Zero risk_trigger_factor rejected by validator."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "u2-3", "risk_trigger_factor", 2.0, 0.0, "test", 50, "z_test"
        )
        cal.approve_calibration("u2-3", "reviewer-1")

        ge = GateEvaluator(risk_trigger_factor=2.0)
        result = cal.apply_calibration("u2-3", gate_evaluator=ge)
        assert result.success is False
        assert "must be non-zero" in result.error
        assert ge.risk_trigger_factor == 2.0

    def test_u2_trigger_confidence_prob_out_of_range_rejected(self):
        """U-2: trigger_confidence_prob must stay in (0, 1]."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "u2-4", "trigger_confidence_prob", 0.95, 1.5, "test", 50, "z_test"
        )
        cal.approve_calibration("u2-4", "reviewer-1")

        ge = GateEvaluator(trigger_confidence_prob=0.95)
        result = cal.apply_calibration("u2-4", gate_evaluator=ge)
        assert result.success is False
        assert "must be in (0, 1]" in result.error
        assert ge.trigger_confidence_prob == 0.95
        assert cal.proposals["u2-4"].status == CalibrationStatus.APPROVED

    def test_u3_double_apply_prevented(self):
        """U-3: Concurrent double-apply of same proposal prevented.

        The status transitions to APPLIED under lock. A second apply
        attempt must see APPLIED (not APPROVED) and fail.
        """
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "u3-1", "novelty_threshold", 0.8, 0.85, "test", 50, "bootstrap"
        )
        cal.approve_calibration("u3-1", "reviewer-1")

        ge = GateEvaluator(novelty_threshold=0.8)

        # First apply succeeds
        result1 = cal.apply_calibration("u3-1", gate_evaluator=ge)
        assert result1.success is True
        assert cal.proposals["u3-1"].status == CalibrationStatus.APPLIED

        # Second apply fails because status is now APPLIED
        result2 = cal.apply_calibration("u3-1", gate_evaluator=ge)
        assert result2.success is False
        assert "applied" in result2.error

    def test_u4_derived_id_collision_drift(self):
        """U-4: Derived sub-proposal ID collision detected in drift calibration.

        If a proposal with ID "batch_tau_warning" already exists,
        propose_drift_calibration("batch", ...) must detect the collision.
        """
        cal = Calibrator("cal-1", "Tuner")
        # Pre-occupy a derived ID
        cal.propose_gate_threshold(
            "batch_tau_warning", "epsilon_R", 0.01, 0.02, "occupy", 10, "z_test"
        )

        det = DriftMonitor(tau_warning=0.1, tau_critical=0.5)
        kl_values = [0.01 * i for i in range(1, 101)]

        result = cal.propose_drift_calibration("batch", det, kl_values)
        assert result.success is False
        assert "already exists" in result.error

    def test_u4_derived_id_collision_prior(self):
        """U-4: Derived sub-proposal ID collision detected in prior update.

        If a proposal with ID "prior_prior_mean" already exists,
        propose_prior_update("prior", ...) must detect the collision.
        """
        cal = Calibrator("cal-1", "Tuner")
        # Pre-occupy a derived ID
        cal.propose_gate_threshold(
            "prior_prior_mean", "epsilon_R", 0.01, 0.02, "occupy", 10, "z_test"
        )

        bay = BayesianPosterior(prior_mean=0.0, prior_std=1.0, likelihood_std=0.5)
        observations = [5.0] * 30  # Strong shift to create proposals

        result = cal.propose_prior_update("prior", bay, observations)
        assert result.success is False
        assert "already exists" in result.error

    def test_apply_drift_tau_critical(self):
        """Regression: Apply tau_critical (not just tau_warning)."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "tc-1", "tau_critical", 0.5, 0.6, "test", 50, "percentile_p99"
        )
        cal.approve_calibration("tc-1", "reviewer-1")

        det = DriftMonitor(tau_warning=0.1, tau_critical=0.5)
        result = cal.apply_calibration("tc-1", drift_detector=det)
        assert result.success is True
        assert det.tau_critical == 0.6
        assert result.result_data["target"] == "drift_detector"

    def test_apply_drift_missing_detector_reverts_status(self):
        """Regression: Missing drift_detector reverts status to APPROVED."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "rev-1", "tau_critical", 0.5, 0.6, "test", 50, "percentile_p99"
        )
        cal.approve_calibration("rev-1", "reviewer-1")

        result = cal.apply_calibration("rev-1")  # No detector
        assert result.success is False
        # Status must be reverted so proposal can be retried
        assert cal.proposals["rev-1"].status == CalibrationStatus.APPROVED

    def test_apply_gate_missing_evaluator_reverts_status(self):
        """Regression: Missing gate_evaluator reverts status to APPROVED."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "rev-2", "epsilon_R", 0.01, 0.02, "test", 50, "z_test"
        )
        cal.approve_calibration("rev-2", "reviewer-1")

        result = cal.apply_calibration("rev-2")  # No evaluator
        assert result.success is False
        assert cal.proposals["rev-2"].status == CalibrationStatus.APPROVED

    def test_list_proposals_filter_applied(self):
        """Regression: Filter by APPLIED status works correctly."""
        cal = Calibrator("cal-1", "Tuner")
        cal.propose_gate_threshold(
            "f-1", "novelty_threshold", 0.8, 0.85, "test", 50, "bootstrap"
        )
        cal.propose_gate_threshold(
            "f-2", "complexity_floor", 0.5, 0.6, "test", 50, "bootstrap"
        )
        cal.approve_calibration("f-1", "reviewer-1")
        ge = GateEvaluator(novelty_threshold=0.8)
        cal.apply_calibration("f-1", gate_evaluator=ge)

        result = cal.list_proposals(status_filter=CalibrationStatus.APPLIED)
        assert result.result_data["count"] == 1
        assert result.result_data["proposals"][0]["proposal_id"] == "f-1"


class TestQG58CalibratorRegressions:
    """QG58 ultrathink calibrator regression tests."""

    def test_validate_gate_param_rejects_nan(self):
        """QG58-P2-1: NaN must be rejected by _validate_gate_param."""
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="finite number"):
            _validate_gate_param("epsilon_R", float("nan"))

    def test_validate_gate_param_rejects_inf(self):
        """QG58-P2-1: Inf must be rejected by _validate_gate_param."""
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="finite number"):
            _validate_gate_param("risk_trigger_factor", float("inf"))

    def test_validate_gate_param_rejects_neg_inf(self):
        """QG58-P2-1: -Inf must be rejected by _validate_gate_param."""
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="finite number"):
            _validate_gate_param("profit_trigger_factor", float("-inf"))


class TestQG59CalibrationProposalValidation:
    """QG59: CalibrationProposal NaN/Inf field validation."""

    def test_nan_current_value_rejected(self):
        """QG59-P2-1: CalibrationProposal must reject NaN current_value."""
        with pytest.raises(ValueError, match="current_value must be finite"):
            CalibrationProposal(
                proposal_id="cp-nan-1",
                parameter_name="risk_trigger_factor",
                current_value=float("nan"),
                proposed_value=2.5,
                justification="test",
                data_window=30,
                statistical_method="bayesian",
            )

    def test_inf_proposed_value_rejected(self):
        """QG59-P2-1: CalibrationProposal must reject Inf proposed_value."""
        with pytest.raises(ValueError, match="proposed_value must be finite"):
            CalibrationProposal(
                proposal_id="cp-inf-1",
                parameter_name="risk_trigger_factor",
                current_value=2.0,
                proposed_value=float("inf"),
                justification="test",
                data_window=30,
                statistical_method="bayesian",
            )

    def test_neg_inf_current_value_rejected(self):
        """QG59-P2-1: CalibrationProposal must reject -Inf current_value."""
        with pytest.raises(ValueError, match="current_value must be finite"):
            CalibrationProposal(
                proposal_id="cp-ninf-1",
                parameter_name="risk_trigger_factor",
                current_value=float("-inf"),
                proposed_value=2.5,
                justification="test",
                data_window=30,
                statistical_method="bayesian",
            )
