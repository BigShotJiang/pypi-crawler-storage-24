"""Tests for AEGIS CLI entry point."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from cli import (
    _get_version,
    _load_config,
    _load_drift_monitor,
    _parse_proposal,
    build_parser,
    cmd_evaluate,
    cmd_health,
    cmd_metrics,
    cmd_validate_config,
    cmd_version,
    main,
)


class TestCLIParser:
    """Test argument parsing."""

    def test_build_parser(self):
        parser = build_parser()
        assert parser.prog == "aegis"

    def test_evaluate_command(self):
        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", "test.json"])
        assert args.command == "evaluate"
        assert args.input == "test.json"

    def test_evaluate_with_config(self):
        parser = build_parser()
        args = parser.parse_args(
            ["evaluate", "--input", "test.json", "--config", "config.yaml"]
        )
        assert args.config == "config.yaml"

    def test_validate_config_command(self):
        parser = build_parser()
        args = parser.parse_args(["validate-config", "config.yaml"])
        assert args.command == "validate-config"
        assert args.config_file == "config.yaml"

    def test_version_command(self):
        parser = build_parser()
        args = parser.parse_args(["version"])
        assert args.command == "version"

    def test_no_command_returns_zero(self):
        """No command should print help and return 0."""
        with patch("cli.sys.argv", ["aegis"]):
            assert main() == 0


class TestCmdVersion:
    """Test version command."""

    def test_version_outputs_json(self, capsys):
        parser = build_parser()
        args = parser.parse_args(["version"])
        result = cmd_version(args)
        assert result == 0

        captured = capsys.readouterr()
        info = json.loads(captured.out)
        assert "aegis_governance" in info
        assert "python" in info


class TestCmdEvaluate:
    """Test evaluate command."""

    def test_evaluate_minimal_proposal(self, capsys, tmp_path):
        """Evaluate with minimal fields."""
        proposal = {
            "proposal_summary": "Test proposal",
            "estimated_impact": "low",
            "complexity_score": 0.8,
            "quality_score": 0.9,
        }
        path = tmp_path / "minimal.json"
        path.write_text(json.dumps(proposal))

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(path)])
        cmd_evaluate(args)

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "status" in output
        assert "confidence" in output
        assert "gates" in output

    def test_evaluate_high_risk_proposal(self, tmp_path):
        """High risk should result in non-proceed status."""
        proposal = {
            "proposal_summary": "Risky change",
            "estimated_impact": "critical",
            "risk_proposed": 0.9,
            "complexity_score": 0.8,
            "quality_score": 0.9,
        }
        path = tmp_path / "high_risk.json"
        path.write_text(json.dumps(proposal))

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(path)])
        # High impact critical = escalate
        assert cmd_evaluate(args) != 0

    def test_evaluate_nonexistent_file(self):
        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", "/nonexistent.json"])
        result = cmd_evaluate(args)
        assert result == 1

    def test_evaluate_invalid_json(self, tmp_path):
        bad_file = tmp_path / "bad.json"
        bad_file.write_text("not json{{{")

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(bad_file)])
        assert cmd_evaluate(args) == 1

    def test_evaluate_no_input_tty(self):
        """No input and stdin is TTY should error."""
        parser = build_parser()
        args = parser.parse_args(["evaluate"])
        with patch("cli.sys.stdin") as mock_stdin:
            mock_stdin.isatty.return_value = True
            result = cmd_evaluate(args)
        assert result == 1

    def test_evaluate_with_risk_score_shorthand(self, capsys, tmp_path):
        """risk_score should map to risk_proposed."""
        proposal = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "risk_score": 0.1,
            "complexity_score": 0.8,
            "quality_score": 0.9,
        }
        path = tmp_path / "risk_shorthand.json"
        path.write_text(json.dumps(proposal))

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(path)])
        cmd_evaluate(args)

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "status" in output

    def test_evaluate_output_has_gate_details(self, capsys, tmp_path):
        """Output should include per-gate results."""
        proposal = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "complexity_score": 0.8,
            "quality_score": 0.9,
        }
        path = tmp_path / "gate_details.json"
        path.write_text(json.dumps(proposal))

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(path)])
        cmd_evaluate(args)

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "gates" in output
        assert "risk" in output["gates"]
        assert "complexity" in output["gates"]
        assert "quality" in output["gates"]


class TestCmdValidateConfig:
    """Test validate-config command."""

    def test_validate_interface_contract(self, capsys):
        """Validate the actual interface-contract.yaml."""
        pytest.importorskip("yaml")
        contract_path = (
            Path(__file__).parent.parent / "schema" / "interface-contract.yaml"
        )
        if not contract_path.exists():
            pytest.skip("interface-contract.yaml not found")

        parser = build_parser()
        args = parser.parse_args(["validate-config", str(contract_path)])
        result = cmd_validate_config(args)
        assert result == 0

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert output["valid"] is True
        assert "parameters" in output

    def test_validate_nonexistent_file(self):
        pytest.importorskip("yaml")
        parser = build_parser()
        args = parser.parse_args(["validate-config", "/nonexistent.yaml"])
        result = cmd_validate_config(args)
        assert result == 1

    def test_validate_invalid_yaml(self, tmp_path):
        """Validate-config with non-dict YAML content should return 1."""
        pytest.importorskip("yaml")
        bad_yaml = tmp_path / "bad.yaml"
        bad_yaml.write_text("- just a list\n- not a dict\n")
        parser = build_parser()
        args = parser.parse_args(["validate-config", str(bad_yaml)])
        result = cmd_validate_config(args)
        assert result == 1


class TestGetVersion:
    """Test _get_version helper."""

    def test_version_returns_string(self):
        version = _get_version()
        assert isinstance(version, str)
        assert len(version) > 0

    def test_version_fallback_on_error(self):
        """Should return '1.1.0' when importlib.metadata fails."""
        import importlib.metadata

        with patch.object(importlib.metadata, "version", side_effect=Exception("nope")):
            version = _get_version()
            assert version == "1.1.0"


class TestLoadConfig:
    """Test _load_config helper."""

    def test_load_config_default(self):
        """No path should return default config."""
        config = _load_config(None)
        assert config.epsilon_R == 0.01

    def test_load_config_from_yaml(self, tmp_path):
        """Config path should load from YAML."""
        pytest.importorskip("yaml")
        import yaml

        config_yaml = tmp_path / "config.yaml"
        config_yaml.write_text(
            yaml.dump(
                {
                    "parameters": {
                        "epsilon_R": 0.02,
                        "risk_trigger_factor": 2.5,
                        "profit_trigger_factor": 0.8,
                        "complexity_floor": 0.4,
                        "quality_min_score": 0.65,
                        "quality_no_zero_subscore": True,
                        "trigger_confidence_prob": 0.96,
                    }
                }
            )
        )
        config = _load_config(str(config_yaml))
        assert config.epsilon_R == 0.02


class TestParseProposal:
    """Test _parse_proposal helper."""

    def test_parse_minimal(self):
        data = {"proposal_summary": "Test", "estimated_impact": "low"}
        kwargs = _parse_proposal(data)
        assert kwargs["proposal_summary"] == "Test"
        assert kwargs["estimated_impact"] == "low"
        assert kwargs["agent_id"] == "aegis-cli"

    def test_parse_with_quality_subscores(self):
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "quality_subscores": [0.8, 0.9, 0.7],
        }
        kwargs = _parse_proposal(data)
        assert kwargs["quality_subscores"] == [0.8, 0.9, 0.7]

    def test_parse_phase_mapping(self):
        for phase_str, expected_name in [
            ("plan", "PLAN"),
            ("commit", "COMMIT"),
            ("work", "WORK"),
        ]:
            data = {
                "proposal_summary": "Test",
                "estimated_impact": "low",
                "phase": phase_str,
            }
            kwargs = _parse_proposal(data)
            assert kwargs["phase"].name == expected_name

    def test_parse_unknown_phase_defaults_plan(self):
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "phase": "unknown",
        }
        kwargs = _parse_proposal(data)
        assert kwargs["phase"].name == "PLAN"

    def test_parse_simplified_names_for_scores(self):
        """Regression: simplified names for novelty/complexity/quality should work."""
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "novelty": 0.9,
            "complexity": 0.8,
            "quality": 0.85,
        }
        kwargs = _parse_proposal(data)
        assert kwargs["novelty_score"] == 0.9
        assert kwargs["complexity_score"] == 0.8
        assert kwargs["quality_score"] == 0.85

    def test_parse_full_names_still_work(self):
        """Full field names should still take precedence."""
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "novelty_score": 0.7,
            "novelty": 0.9,  # Should be ignored since full name is present
        }
        kwargs = _parse_proposal(data)
        assert kwargs["novelty_score"] == 0.7

    def test_parse_non_string_phase_defaults_plan(self):
        """Non-string phase values should fall back to 'plan', not crash (BH11-M2)."""
        for bad_phase in [1, None, True, 3.14, ["plan"]]:
            data = {
                "proposal_summary": "Test",
                "estimated_impact": "low",
                "phase": bad_phase,
            }
            kwargs = _parse_proposal(data)
            assert kwargs["phase"].name == "PLAN"

    def test_parse_quality_subscores_with_nulls(self):
        """Null elements in quality_subscores should be filtered, not crash (BH11-M1)."""
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "quality_subscores": [0.7, None, 0.8],
        }
        kwargs = _parse_proposal(data)
        assert kwargs["quality_subscores"] == [0.7, 0.8]

    def test_parse_quality_subscores_all_nulls_uses_default(self):
        """All-null quality_subscores should fall back to default list (BH11-M1)."""
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "quality_subscores": [None, None, None],
        }
        kwargs = _parse_proposal(data)
        assert kwargs["quality_subscores"] == [0.7, 0.7, 0.7]

    def test_parse_null_metric_uses_default(self):
        """Explicit JSON null values should fall back to defaults, not crash (BH10-M4)."""
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "risk_baseline": None,
            "novelty_score": None,
        }
        kwargs = _parse_proposal(data)
        assert kwargs["risk_baseline"] == 0.0
        assert kwargs["novelty_score"] == 0.5


class TestBH18CLIBoolControlFlags:
    """BH18: CLI must reject non-boolean control flags (transport parity with Lambda)."""

    @pytest.mark.parametrize(
        ("field", "invalid_value"),
        [
            ("requires_human_approval", "true"),
            ("time_sensitive", 1),
            ("reversible", "false"),
        ],
    )
    def test_parse_proposal_non_bool_control_flag_rejected(self, field, invalid_value):
        """Non-bool control flags must raise TypeError."""
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            field: invalid_value,
        }
        with pytest.raises(TypeError, match=f"'{field}' must be a boolean"):
            _parse_proposal(data)

    def test_parse_proposal_bool_flags_accepted(self):
        """Actual bool values must be accepted."""
        data = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "requires_human_approval": True,
            "time_sensitive": False,
            "reversible": False,
        }
        kwargs = _parse_proposal(data)
        assert kwargs["requires_human_approval"] is True
        assert kwargs["time_sensitive"] is False
        assert kwargs["reversible"] is False


class TestCmdEvaluateEdgeCases:
    """Additional evaluate command edge cases."""

    def test_evaluate_config_load_error(self):
        """Config load failure should return 1."""
        parser = build_parser()
        args = parser.parse_args(
            [
                "evaluate",
                "--input",
                "dummy.json",
                "--config",
                "/nonexistent/config.yaml",
            ]
        )
        result = cmd_evaluate(args)
        assert result == 1

    def test_evaluate_stdin_input(self, capsys):
        """Evaluate should read from stdin when no --input and stdin is not a TTY."""
        import io

        proposal = {
            "proposal_summary": "Stdin test",
            "estimated_impact": "low",
            "complexity_score": 0.8,
            "quality_score": 0.9,
        }
        mock_stdin = io.StringIO(json.dumps(proposal))
        mock_stdin.isatty = lambda: False

        parser = build_parser()
        args = parser.parse_args(["evaluate"])
        with patch("cli.sys.stdin", mock_stdin):
            cmd_evaluate(args)

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "status" in output

    def test_evaluate_halt_returns_one(self, tmp_path):
        """Halt status should return exit code 1."""
        proposal = {
            "proposal_summary": "Bad change",
            "estimated_impact": "critical",
            "risk_proposed": 0.99,
            "complexity_score": 0.1,
            "quality_score": 0.1,
        }
        path = tmp_path / "halt.json"
        path.write_text(json.dumps(proposal))

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(path)])
        result = cmd_evaluate(args)
        # Halt or escalate — exit code should be non-zero
        assert result != 0

    def test_evaluate_value_error_returns_one(self, tmp_path):
        """ValueError during evaluation should return 1."""
        # Provide invalid numeric value that will fail conversion
        proposal = {
            "proposal_summary": "Test",
            "estimated_impact": "low",
            "risk_proposed": "not-a-number",
        }
        path = tmp_path / "invalid.json"
        path.write_text(json.dumps(proposal))

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(path)])
        result = cmd_evaluate(args)
        assert result == 1

    def test_validate_config_import_error(self):
        """Validate-config when yaml not importable should return 1."""
        from config import AegisConfig

        parser = build_parser()
        args = parser.parse_args(["validate-config", "dummy.yaml"])
        with patch.object(AegisConfig, "from_yaml", side_effect=ImportError("no yaml")):
            result = cmd_validate_config(args)
            assert result == 1


class TestMainEntryPoint:
    """Test main() dispatching."""

    def test_main_dispatches_to_evaluate(self, tmp_path):
        proposal_file = tmp_path / "eval.json"
        proposal_file.write_text(
            json.dumps(
                {
                    "proposal_summary": "Test",
                    "estimated_impact": "low",
                    "complexity_score": 0.8,
                    "quality_score": 0.9,
                }
            )
        )

        with patch(
            "cli.sys.argv", ["aegis", "evaluate", "--input", str(proposal_file)]
        ):
            result = main()
            assert isinstance(result, int)

    def test_main_dispatches_to_version(self):
        with patch("cli.sys.argv", ["aegis", "version"]):
            result = main()
            assert result == 0


class TestCmdHealth:
    """Test health command."""

    def test_health_outputs_json(self, capsys):
        parser = build_parser()
        args = parser.parse_args(["health"])
        result = cmd_health(args)
        assert result == 0

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "healthy" in output
        assert "checks" in output
        assert output["checks"]["config"]["ok"] is True

    def test_health_checks_gates(self, capsys):
        parser = build_parser()
        args = parser.parse_args(["health"])
        cmd_health(args)

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert output["checks"]["gates"]["ok"] is True

    def test_health_checks_persistence(self, capsys):
        parser = build_parser()
        args = parser.parse_args(["health"])
        cmd_health(args)

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "persistence" in output["checks"]

    def test_health_command_parser(self):
        parser = build_parser()
        args = parser.parse_args(["health"])
        assert args.command == "health"


class TestCmdMetrics:
    """Test metrics command."""

    def test_metrics_outputs_prometheus_format(self, capsys):
        parser = build_parser()
        args = parser.parse_args(["metrics"])
        result = cmd_metrics(args)
        assert result == 0

        captured = capsys.readouterr()
        # Prometheus format contains # HELP or # TYPE lines
        assert len(captured.out) > 0

    def test_metrics_command_parser(self):
        parser = build_parser()
        args = parser.parse_args(["metrics"])
        assert args.command == "metrics"

    def test_main_dispatches_to_health(self):
        with patch("cli.sys.argv", ["aegis", "health"]):
            result = main()
            assert result == 0

    def test_main_dispatches_to_metrics(self):
        with patch("cli.sys.argv", ["aegis", "metrics"]):
            result = main()
            assert result == 0


class TestSafeRoundJsonCompliance:
    """Regression: CLI JSON output must be RFC 7159 compliant.

    The utility gate's fail-closed default produces lcb=float('-inf').
    round(float('-inf'), 6) → float('-inf'), and json.dumps emits
    '-Infinity' which is NOT valid JSON.  _safe_round replaces
    non-finite values with None (JSON null).
    """

    def test_safe_round_finite_values(self):
        from cli import _safe_round

        assert _safe_round(3.14159265) == round(3.14159265, 6)
        assert _safe_round(0.0) == 0.0
        assert _safe_round(-42.123456789) == round(-42.123456789, 6)

    def test_safe_round_negative_infinity(self):
        from cli import _safe_round

        assert _safe_round(float("-inf")) is None

    def test_safe_round_positive_infinity(self):
        from cli import _safe_round

        assert _safe_round(float("inf")) is None

    def test_safe_round_nan(self):
        from cli import _safe_round

        assert _safe_round(float("nan")) is None

    def test_evaluate_output_is_valid_json(self, capsys, tmp_path):
        """End-to-end: CLI evaluate output MUST be parseable by json.loads.

        Without _safe_round, the utility gate's fail-closed default
        (lcb=-inf) causes json.dumps to emit '-Infinity', which
        json.loads(strict=True) rejects as non-standard JSON.
        """
        proposal = {
            "proposal_summary": "Test JSON compliance",
            "estimated_impact": "low",
            "complexity_score": 0.8,
            "quality_score": 0.9,
        }
        path = tmp_path / "json_compliance.json"
        path.write_text(json.dumps(proposal))

        parser = build_parser()
        args = parser.parse_args(["evaluate", "--input", str(path)])
        cmd_evaluate(args)

        captured = capsys.readouterr()
        # This would raise ValueError if output contains -Infinity/NaN
        output = json.loads(captured.out)
        assert "gates" in output
        # Verify non-finite gate values are null, not -Infinity
        for gate_name, gate_data in output["gates"].items():
            val = gate_data["value"]
            assert val is None or isinstance(
                val, (int, float)
            ), f"Gate {gate_name} value must be null or finite, got {val!r}"


class TestDriftBaselineCLI:
    """Tests for --drift-baseline flag on evaluate command."""

    def test_evaluate_with_drift_baseline(self, capsys, tmp_path):
        """Passing baseline file includes drift in output."""
        proposal = tmp_path / "proposal.json"
        proposal.write_text(
            json.dumps(
                {
                    "proposal_summary": "Drift CLI test",
                    "estimated_impact": "medium",
                    "risk_baseline": 0.1,
                    "risk_proposed": 0.15,
                    "profit_baseline": 0.5,
                    "profit_proposed": 0.6,
                    "complexity_score": 0.7,
                    "quality_score": 0.8,
                }
            )
        )
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps([0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4]))

        parser = build_parser()
        args = parser.parse_args(
            ["evaluate", "--input", str(proposal), "--drift-baseline", str(baseline)]
        )
        cmd_evaluate(args)

        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "status" in output

    def test_evaluate_drift_baseline_not_found(self, capsys, tmp_path):
        """Missing baseline file returns error."""
        proposal = tmp_path / "proposal.json"
        proposal.write_text(
            json.dumps(
                {
                    "proposal_summary": "Test",
                    "estimated_impact": "low",
                }
            )
        )

        parser = build_parser()
        args = parser.parse_args(
            [
                "evaluate",
                "--input",
                str(proposal),
                "--drift-baseline",
                "/nonexistent/baseline.json",
            ]
        )
        result = cmd_evaluate(args)
        assert result == 1

    def test_evaluate_drift_baseline_invalid(self, capsys, tmp_path):
        """Non-array JSON returns error."""
        proposal = tmp_path / "proposal.json"
        proposal.write_text(
            json.dumps(
                {
                    "proposal_summary": "Test",
                    "estimated_impact": "low",
                }
            )
        )
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps({"not": "an array"}))

        parser = build_parser()
        args = parser.parse_args(
            ["evaluate", "--input", str(proposal), "--drift-baseline", str(baseline)]
        )
        result = cmd_evaluate(args)
        assert result == 1

    def test_evaluate_drift_critical_exit_code(self, tmp_path):
        """Critical drift returns exit code 1 (halt)."""
        proposal = tmp_path / "proposal.json"
        proposal.write_text(
            json.dumps(
                {
                    "proposal_summary": "Drift critical test",
                    "estimated_impact": "medium",
                    "risk_baseline": 0.1,
                    "risk_proposed": 0.15,
                    "profit_baseline": 0.5,
                    "profit_proposed": 0.6,
                    "complexity_score": 0.7,
                    "quality_score": 0.8,
                }
            )
        )
        # Baseline far from expected observations -> high KL divergence
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps([5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0]))

        parser = build_parser()
        # Use very low thresholds to ensure critical drift
        # Create a config with low thresholds
        config_data = {
            "parameters": {
                "kl_drift": {
                    "tau_warning": 0.0001,
                    "tau_critical": 0.001,
                    "window_days": 30,
                }
            }
        }
        config_path = tmp_path / "config.yaml"
        try:
            import yaml

            config_path.write_text(yaml.dump(config_data))
        except ImportError:
            pytest.skip("PyYAML not available")

        args = parser.parse_args(
            [
                "evaluate",
                "--input",
                str(proposal),
                "--drift-baseline",
                str(baseline),
                "--config",
                str(config_path),
            ]
        )
        result = cmd_evaluate(args)
        assert result == 1  # HALT -> exit code 1

    def test_evaluate_drift_baseline_null_values_filtered(self, tmp_path):
        """T-6 regression: null values in baseline are filtered, not crash."""
        proposal = tmp_path / "proposal.json"
        proposal.write_text(
            json.dumps(
                {
                    "proposal_summary": "Null baseline test",
                    "estimated_impact": "medium",
                    "complexity_score": 0.7,
                    "quality_score": 0.8,
                }
            )
        )
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps([1.0, None, 2.0, None, 3.0, 4.0, 5.0, 6.0]))

        parser = build_parser()
        args = parser.parse_args(
            ["evaluate", "--input", str(proposal), "--drift-baseline", str(baseline)]
        )
        # Nulls filtered out, remaining values used — should not crash
        result = cmd_evaluate(args)
        assert result in (0, 1, 2)

    def test_evaluate_drift_baseline_all_null(self, tmp_path):
        """All-null baseline returns error (no valid values)."""
        proposal = tmp_path / "proposal.json"
        proposal.write_text(
            json.dumps(
                {
                    "proposal_summary": "All-null baseline test",
                    "estimated_impact": "low",
                }
            )
        )
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps([None, None, None]))

        parser = build_parser()
        args = parser.parse_args(
            ["evaluate", "--input", str(proposal), "--drift-baseline", str(baseline)]
        )
        # All nulls → ValueError → error exit
        result = cmd_evaluate(args)
        assert result == 1


class TestQG69CLIDriftBaselineIsfinite:
    """QG69-M1: CLI drift baseline must reject NaN/Inf (transport parity with Lambda)."""

    def test_drift_baseline_nan_raises(self, tmp_path):
        """NaN in baseline file must raise ValueError."""
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps([1.0, float("nan"), 2.0]))

        from types import SimpleNamespace

        from config import AegisConfig

        args = SimpleNamespace(drift_baseline=str(baseline))
        with pytest.raises(ValueError, match="must be finite"):
            _load_drift_monitor(args, AegisConfig.default())

    def test_drift_baseline_inf_raises(self, tmp_path):
        """Inf in baseline file must raise ValueError."""
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps([1.0, float("inf"), 2.0]))

        from types import SimpleNamespace

        from config import AegisConfig

        args = SimpleNamespace(drift_baseline=str(baseline))
        with pytest.raises(ValueError, match="must be finite"):
            _load_drift_monitor(args, AegisConfig.default())

    def test_drift_baseline_neg_inf_raises(self, tmp_path):
        """-Inf in baseline file must raise ValueError."""
        baseline = tmp_path / "baseline.json"
        baseline.write_text(json.dumps([1.0, float("-inf"), 2.0]))

        from types import SimpleNamespace

        from config import AegisConfig

        args = SimpleNamespace(drift_baseline=str(baseline))
        with pytest.raises(ValueError, match="must be finite"):
            _load_drift_monitor(args, AegisConfig.default())


class TestBH13CLIIsfiniteGuard:
    """BH13-M3: CLI _parse_proposal must reject NaN/Inf values."""

    def test_parse_proposal_nan_risk(self):
        """NaN risk_proposed must raise ValueError."""
        with pytest.raises(ValueError, match="must be finite"):
            _parse_proposal({"risk_proposed": "NaN"})

    def test_parse_proposal_inf_risk(self):
        """Inf risk_baseline must raise ValueError."""
        with pytest.raises(ValueError, match="must be finite"):
            _parse_proposal({"risk_baseline": "Infinity"})

    def test_parse_proposal_neg_inf_profit(self):
        """-Inf profit_proposed must raise ValueError."""
        with pytest.raises(ValueError, match="must be finite"):
            _parse_proposal({"profit_proposed": "-Infinity"})

    def test_parse_proposal_nan_risk_score_fallback(self):
        """NaN in risk_score (fallback path) must raise ValueError."""
        with pytest.raises(ValueError, match="must be finite"):
            _parse_proposal({"risk_score": "NaN"})

    def test_parse_proposal_nan_quality_subscore(self):
        """NaN in quality_subscores must raise ValueError."""
        with pytest.raises(ValueError, match="must be finite"):
            _parse_proposal({"quality_subscores": [0.8, "NaN", 0.7]})

    def test_parse_proposal_inf_quality_subscore(self):
        """Inf in quality_subscores must raise ValueError."""
        with pytest.raises(ValueError, match="must be finite"):
            _parse_proposal({"quality_subscores": ["Infinity", 0.7, 0.7]})


class TestBH25CLIRiskScoreTransportParity:
    """BH25-M2: CLI risk_score alias must check value presence, not just key."""

    def test_risk_score_fallback_when_risk_proposed_null(self):
        """risk_score should be used when risk_proposed is explicitly None."""
        result = _parse_proposal({"risk_score": 1.5, "risk_proposed": None})
        assert result["risk_proposed"] == 1.5

    def test_risk_proposed_takes_precedence_over_risk_score(self):
        """Explicit non-null risk_proposed must take precedence over risk_score."""
        result = _parse_proposal({"risk_score": 1.5, "risk_proposed": 2.0})
        assert result["risk_proposed"] == 2.0

    def test_risk_score_used_when_risk_proposed_absent(self):
        """risk_score used when risk_proposed key is absent entirely."""
        result = _parse_proposal({"risk_score": 3.0})
        assert result["risk_proposed"] == 3.0


class TestBH30CLIRiskScoreNullGuard:
    """BH30-M3: CLI risk_score null must not crash with float(None) TypeError."""

    def test_null_risk_score_does_not_crash(self):
        """risk_score: null must not crash with float(None) TypeError."""
        result = _parse_proposal({"risk_score": None})
        # Should use default 0.0 from _METRIC_DEFAULTS, not crash
        assert result["risk_proposed"] == 0.0

    def test_null_risk_score_falls_through_to_default(self):
        """risk_score: null should fall through to default, not override."""
        result = _parse_proposal({"risk_score": None, "profit_baseline": 1.0})
        assert result["risk_proposed"] == 0.0
        assert result["profit_baseline"] == 1.0


class TestQG72CLINullStringFields:
    """QG72: CLI dict.get() null gotcha for proposal_summary and estimated_impact."""

    def test_null_proposal_summary_uses_default(self):
        """proposal_summary: null must use 'CLI evaluation' default."""
        result = _parse_proposal({"proposal_summary": None})
        assert result["proposal_summary"] == "CLI evaluation"

    def test_null_estimated_impact_uses_default(self):
        """estimated_impact: null must use 'medium' default."""
        result = _parse_proposal({"estimated_impact": None})
        assert result["estimated_impact"] == "medium"


# --- Transport Parity Regression Tests ---


class TestCLITransportParityMetadata:
    """Regression: CLI metadata extraction and validation."""

    def test_metadata_dict_accepted(self):
        """Valid dict metadata is extracted."""
        result = _parse_proposal({"metadata": {"env": "prod"}})
        assert result["metadata"] == {"env": "prod"}

    def test_metadata_null_uses_empty(self):
        """null metadata defaults to {}."""
        result = _parse_proposal({"metadata": None})
        assert result["metadata"] == {}

    def test_metadata_non_dict_rejected(self):
        """Non-dict metadata raises TypeError."""
        with pytest.raises(TypeError, match="metadata"):
            _parse_proposal({"metadata": "not-a-dict"})


class TestCLITransportParitySessionId:
    """Regression: CLI session_id defaults to UUID."""

    def test_session_id_default_is_uuid(self):
        """When session_id is omitted, a UUID is generated."""
        import re

        result = _parse_proposal({})
        # UUID4 format: 8-4-4-4-12 hex chars
        uuid_pattern = re.compile(
            r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
        )
        assert uuid_pattern.match(
            result["session_id"]
        ), f"session_id should be UUID4, got {result['session_id']}"

    def test_explicit_session_id_preserved(self):
        """Explicit session_id is preserved, not overwritten."""
        result = _parse_proposal({"session_id": "my-session-42"})
        assert result["session_id"] == "my-session-42"

    def test_empty_session_id_generates_uuid(self):
        """Empty string session_id generates UUID."""
        result = _parse_proposal({"session_id": ""})
        assert result["session_id"] != ""
        assert len(result["session_id"]) == 36  # UUID format


class TestCLITransportParitySSRF:
    """Regression: CLI telemetry URL SSRF validation."""

    def test_private_ip_telemetry_url_rejected(self, capsys):
        """Private IP telemetry URLs should be rejected with warning."""
        from cli import _build_telemetry_emitter

        class FakeArgs:
            telemetry_url = "https://192.168.1.1/events"

        class FakeConfig:
            telemetry_url = None

        result = _build_telemetry_emitter(FakeArgs(), FakeConfig())
        assert result is None
        captured = capsys.readouterr()
        assert "SSRF" in captured.err or "rejected" in captured.err.lower()
