"""Bug Hunt #32 regression tests.

BH32-M1: DriftMonitor constructor accepts negative/Inf thresholds
         (update_thresholds validates, constructor doesn't — parity gap)
BH32-M2: Calibrator _validate_gate_param allows negative threshold params
         (complexity_floor, quality_min_score, novelty_threshold, utility_threshold)
BH32-L1: KLDriftConfig __post_init__ missing window_days validation
"""

import pytest

from engine.drift import DriftMonitor

# ---------------------------------------------------------------------------
# BH32-M1: DriftMonitor constructor — negative and Inf thresholds
# ---------------------------------------------------------------------------


class TestDriftMonitorConstructorValidation:
    """Constructor must reject invalid thresholds the same way update_thresholds does."""

    def test_negative_tau_warning_rejected(self) -> None:
        with pytest.raises(ValueError, match="tau_warning must be non-negative"):
            DriftMonitor(tau_warning=-0.1, tau_critical=0.5)

    def test_negative_tau_critical_rejected(self) -> None:
        with pytest.raises(ValueError, match="tau_critical must be non-negative"):
            DriftMonitor(tau_warning=0.3, tau_critical=-0.5)

    def test_inf_tau_warning_rejected(self) -> None:
        with pytest.raises(ValueError, match="tau_warning must be finite"):
            DriftMonitor(tau_warning=float("inf"), tau_critical=0.5)

    def test_inf_tau_critical_rejected(self) -> None:
        with pytest.raises(ValueError, match="tau_critical must be finite"):
            DriftMonitor(tau_warning=0.3, tau_critical=float("inf"))

    def test_neg_inf_tau_warning_rejected(self) -> None:
        with pytest.raises(ValueError, match="tau_warning must be finite"):
            DriftMonitor(tau_warning=float("-inf"), tau_critical=0.5)

    def test_nan_tau_warning_rejected(self) -> None:
        with pytest.raises(ValueError):
            DriftMonitor(tau_warning=float("nan"), tau_critical=0.5)

    def test_nan_tau_critical_rejected(self) -> None:
        with pytest.raises(ValueError):
            DriftMonitor(tau_warning=0.3, tau_critical=float("nan"))

    def test_zero_tau_warning_valid(self) -> None:
        """Zero is non-negative and valid (tau_warning=0 < tau_critical=0.5)."""
        dm = DriftMonitor(tau_warning=0.0, tau_critical=0.5)
        assert dm.tau_warning == 0.0

    def test_valid_thresholds_still_work(self) -> None:
        dm = DriftMonitor(tau_warning=0.2, tau_critical=0.8)
        assert dm.tau_warning == 0.2
        assert dm.tau_critical == 0.8


# ---------------------------------------------------------------------------
# BH32-M2: Calibrator _validate_gate_param — negative threshold values
# ---------------------------------------------------------------------------


class TestCalibratorNegativeThresholdValidation:
    """Threshold params must reject negative values (governance bypass risk)."""

    def test_negative_complexity_floor_rejected(self) -> None:
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="non-negative"):
            _validate_gate_param("complexity_floor", -0.1)

    def test_negative_quality_min_score_rejected(self) -> None:
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="non-negative"):
            _validate_gate_param("quality_min_score", -0.5)

    def test_negative_novelty_threshold_rejected(self) -> None:
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="non-negative"):
            _validate_gate_param("novelty_threshold", -1.0)

    def test_negative_utility_threshold_accepted(self) -> None:
        """BH44-M1: utility_threshold may be negative (GateEvaluator allows it)."""
        from actors.calibrator import _validate_gate_param

        # Should NOT raise — negative utility_threshold is valid
        _validate_gate_param("utility_threshold", -0.01)

    def test_zero_threshold_accepted(self) -> None:
        """Zero is valid for thresholds (e.g. utility_threshold=0.0 is default)."""
        from actors.calibrator import _validate_gate_param

        _validate_gate_param("complexity_floor", 0.0)
        _validate_gate_param("quality_min_score", 0.0)
        _validate_gate_param("novelty_threshold", 0.0)
        _validate_gate_param("utility_threshold", 0.0)

    def test_positive_threshold_accepted(self) -> None:
        from actors.calibrator import _validate_gate_param

        _validate_gate_param("complexity_floor", 0.5)
        _validate_gate_param("quality_min_score", 0.7)
        _validate_gate_param("novelty_threshold", 0.8)
        _validate_gate_param("utility_threshold", 0.1)


# ---------------------------------------------------------------------------
# BH32-L1: KLDriftConfig window_days validation
# ---------------------------------------------------------------------------


class TestKLDriftConfigWindowDaysValidation:
    """window_days must be a positive integer >= 1."""

    def test_zero_window_days_rejected(self) -> None:
        from config import KLDriftConfig

        with pytest.raises(ValueError, match="window_days must be >= 1"):
            KLDriftConfig(window_days=0)

    def test_negative_window_days_rejected(self) -> None:
        from config import KLDriftConfig

        with pytest.raises(ValueError, match="window_days must be >= 1"):
            KLDriftConfig(window_days=-5)

    def test_bool_window_days_rejected(self) -> None:
        from config import KLDriftConfig

        with pytest.raises(TypeError, match="window_days must be an integer"):
            KLDriftConfig(window_days=True)  # type: ignore[arg-type]

    def test_valid_window_days_accepted(self) -> None:
        from config import KLDriftConfig

        cfg = KLDriftConfig(window_days=1)
        assert cfg.window_days == 1

        cfg2 = KLDriftConfig(window_days=90)
        assert cfg2.window_days == 90

    def test_default_window_days_valid(self) -> None:
        from config import KLDriftConfig

        cfg = KLDriftConfig()
        assert cfg.window_days == 30
