"""Tests for shared validation and serialization utilities.

Covers:
  - engine.validation: validate_positive, validate_range,
    validate_normalized, validate_threshold_ordering
  - workflows.serialization: ensure_utc
"""

from datetime import datetime, timedelta, timezone

import pytest

from engine.validation import (
    validate_normalized,
    validate_positive,
    validate_range,
    validate_threshold_ordering,
)
from workflows.serialization import ensure_utc

# =========================================================================
# ensure_utc
# =========================================================================


class TestEnsureUtc:
    """Tests for ensure_utc()."""

    def test_naive_datetime_gets_utc(self):
        """Naive datetime should have UTC attached."""
        naive = datetime(2026, 1, 1, 12, 0, 0)
        result = ensure_utc(naive)
        assert result.tzinfo is timezone.utc
        assert result.year == 2026
        assert result.hour == 12

    def test_utc_datetime_unchanged(self):
        """Already-UTC datetime should be returned unchanged."""
        aware = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        result = ensure_utc(aware)
        assert result is aware

    def test_non_utc_timezone_converted_to_utc(self):
        """BH17-L4: Non-UTC timezone should be converted to UTC."""
        eastern = timezone(timedelta(hours=-5))
        aware = datetime(2026, 1, 1, 12, 0, 0, tzinfo=eastern)
        result = ensure_utc(aware)
        assert result.tzinfo is timezone.utc
        # 12:00 EST = 17:00 UTC
        assert result.hour == 17

    def test_non_utc_positive_offset_converted(self):
        """BH17-L4: Positive UTC offset datetimes should be normalized to UTC."""
        plus5 = timezone(timedelta(hours=5))
        aware = datetime(2026, 1, 1, 10, 0, 0, tzinfo=plus5)
        result = ensure_utc(aware)
        assert result.tzinfo is timezone.utc
        # 10:00+05:00 = 05:00 UTC
        assert result.hour == 5


# =========================================================================
# validate_positive
# =========================================================================


class TestValidatePositive:
    """Tests for validate_positive()."""

    def test_positive_value_passes(self):
        """Positive values should not raise."""
        validate_positive("x", 1.0)
        validate_positive("x", 0.001)

    def test_zero_raises(self):
        """Zero should raise ValueError."""
        with pytest.raises(ValueError, match="x must be positive, got 0"):
            validate_positive("x", 0)

    def test_negative_raises(self):
        """Negative values should raise ValueError."""
        with pytest.raises(ValueError, match="x must be positive, got -1"):
            validate_positive("x", -1)

    def test_error_message_format(self):
        """Error message should include parameter name and value."""
        with pytest.raises(ValueError, match=r"prior_std must be positive, got -0\.5"):
            validate_positive("prior_std", -0.5)

    def test_context_appended(self):
        """Optional context should appear after the base message."""
        with pytest.raises(
            ValueError,
            match=r"epsilon_R must be positive, got 0\. Extra info",
        ):
            validate_positive("epsilon_R", 0, context="Extra info")

    def test_nan_raises(self):
        """NaN should raise — NaN <= 0 is False in IEEE 754, so NaN would slip through without explicit check."""
        with pytest.raises(ValueError, match="x must be positive, got nan"):
            validate_positive("x", float("nan"))

    def test_inf_raises(self):
        """QG60-1: Inf must raise — Inf > 0 is True in IEEE 754, so Inf would slip through without isfinite check."""
        with pytest.raises(ValueError, match="x must be positive, got inf"):
            validate_positive("x", float("inf"))

    def test_neg_inf_raises(self):
        """QG60-1: -Inf must raise."""
        with pytest.raises(ValueError, match="x must be positive, got -inf"):
            validate_positive("x", float("-inf"))


# =========================================================================
# validate_range
# =========================================================================


class TestValidateRange:
    """Tests for validate_range()."""

    def test_in_range_passes(self):
        """Value inside range should not raise."""
        validate_range("x", 0.5, 0.0, 1.0)

    def test_below_lower_raises(self):
        """Value below lower bound should raise."""
        with pytest.raises(ValueError, match=r"x must be in \[0.0, 1.0\], got -0.1"):
            validate_range("x", -0.1, 0.0, 1.0)

    def test_above_upper_raises(self):
        """Value above upper bound should raise."""
        with pytest.raises(ValueError, match=r"x must be in \[0.0, 1.0\], got 1.5"):
            validate_range("x", 1.5, 0.0, 1.0)

    def test_at_lower_inclusive_passes(self):
        """Value at inclusive lower bound should pass."""
        validate_range("x", 0.0, 0.0, 1.0, inclusive_lower=True)

    def test_at_lower_exclusive_raises(self):
        """Value at exclusive lower bound should raise."""
        with pytest.raises(ValueError, match=r"x must be in \(0.0, 1.0\], got 0.0"):
            validate_range("x", 0.0, 0.0, 1.0, inclusive_lower=False)

    def test_at_upper_inclusive_passes(self):
        """Value at inclusive upper bound should pass."""
        validate_range("x", 1.0, 0.0, 1.0, inclusive_upper=True)

    def test_at_upper_exclusive_raises(self):
        """Value at exclusive upper bound should raise."""
        with pytest.raises(ValueError, match=r"x must be in \[0.0, 1.0\), got 1.0"):
            validate_range("x", 1.0, 0.0, 1.0, inclusive_upper=False)

    def test_both_exclusive(self):
        """Both bounds exclusive: (0, 1)."""
        with pytest.raises(ValueError, match=r"x must be in \(0, 1\), got 0"):
            validate_range("x", 0, 0, 1, inclusive_lower=False, inclusive_upper=False)

    def test_nan_without_check_passes(self):
        """NaN should pass when check_nan is False (default)."""
        # NaN comparisons are all False, so it won't trigger below/above
        # but this documents the behavior
        validate_range("x", float("nan"), 0.0, 1.0, check_nan=False)

    def test_nan_with_check_raises(self):
        """NaN should raise when check_nan is True."""
        with pytest.raises(ValueError, match="x must be in"):
            validate_range("x", float("nan"), 0.0, 1.0, check_nan=True)


# =========================================================================
# validate_normalized
# =========================================================================


class TestValidateNormalized:
    """Tests for validate_normalized()."""

    def test_zero_passes(self):
        """0.0 should pass."""
        validate_normalized("score", 0.0)

    def test_one_passes(self):
        """1.0 should pass."""
        validate_normalized("score", 1.0)

    def test_midpoint_passes(self):
        """0.5 should pass."""
        validate_normalized("score", 0.5)

    def test_below_zero_raises(self):
        """Negative value should raise."""
        with pytest.raises(ValueError, match=r"score must be in \[0, 1\], got -0.1"):
            validate_normalized("score", -0.1)

    def test_above_one_raises(self):
        """Value > 1.0 should raise."""
        with pytest.raises(ValueError, match=r"score must be in \[0, 1\], got 1.1"):
            validate_normalized("score", 1.1)

    def test_nan_raises(self):
        """NaN should raise (0.0 <= NaN is False in Python)."""
        with pytest.raises(ValueError, match=r"score must be in \[0, 1\]"):
            validate_normalized("score", float("nan"))


# =========================================================================
# validate_threshold_ordering
# =========================================================================


class TestValidateThresholdOrdering:
    """Tests for validate_threshold_ordering()."""

    def test_valid_ordering_passes(self):
        """lower < upper should not raise."""
        validate_threshold_ordering("low", 0.3, "high", 0.5)

    def test_equal_raises(self):
        """Equal values should raise."""
        with pytest.raises(
            ValueError, match=r"low \(0.5\) must be less than high \(0.5\)"
        ):
            validate_threshold_ordering("low", 0.5, "high", 0.5)

    def test_reversed_raises(self):
        """Reversed ordering should raise."""
        with pytest.raises(
            ValueError,
            match=r"tau_warning \(0.8\) must be less than tau_critical \(0.3\)",
        ):
            validate_threshold_ordering("tau_warning", 0.8, "tau_critical", 0.3)

    def test_nan_lower_raises(self):
        """NaN as lower value should raise — NaN >= x is False in IEEE 754."""
        with pytest.raises(ValueError, match="must be less than"):
            validate_threshold_ordering("low", float("nan"), "high", 0.5)

    def test_nan_upper_raises(self):
        """NaN as upper value should raise."""
        with pytest.raises(ValueError, match="must be less than"):
            validate_threshold_ordering("low", 0.3, "high", float("nan"))
