"""Regression tests for Bug Hunt #33.

BH33-M1: config._parse_flat_numeric silently accepts non-numeric types (list, dict)
BH33-M2: config._from_raw_dict silently accepts non-numeric types for DIRECT params
BH33-M3: DriftMonitor.evaluate() passes unfiltered current_window to _to_histogram()
BH33-M4: OverrideWorkflow.__init__ doesn't defensive-copy failed_gates list
BH33-M5: mark_completed() doesn't sync state_data with final_state (Codex finding)
"""

from __future__ import annotations

import pytest

# ---------------------------------------------------------------------------
# BH33-M1: _parse_flat_numeric rejects non-numeric types
# ---------------------------------------------------------------------------


class TestConfigParseFlat:
    """BH33-M1: config._parse_flat_numeric must reject non-numeric types."""

    def test_from_dict_list_value_rejected(self):
        """A list value for a numeric param must raise TypeError."""
        from config import AegisConfig

        with pytest.raises(TypeError, match="Expected numeric value"):
            AegisConfig.from_dict({"epsilon_R": [0.01]})

    def test_from_dict_dict_value_rejected(self):
        """A dict value for a numeric param must raise TypeError."""
        from config import AegisConfig

        with pytest.raises(TypeError, match="Expected numeric value"):
            AegisConfig.from_dict({"epsilon_R": {"value": 0.01}})

    def test_from_dict_tuple_value_rejected(self):
        """A tuple value for a numeric param must raise TypeError."""
        from config import AegisConfig

        with pytest.raises(TypeError, match="Expected numeric value"):
            AegisConfig.from_dict({"profit_trigger_factor": (1.0, 2.0)})

    def test_from_dict_none_value_accepted(self):
        """None values should be silently skipped (use default)."""
        from config import AegisConfig

        cfg = AegisConfig.from_dict({"epsilon_R": None})
        assert cfg.epsilon_R == 0.01  # default

    def test_from_dict_valid_numeric_still_works(self):
        """Valid int/float values must still be accepted."""
        from config import AegisConfig

        cfg = AegisConfig.from_dict({"epsilon_R": 0.05, "risk_trigger_factor": 2})
        assert cfg.epsilon_R == 0.05
        assert cfg.risk_trigger_factor == 2


# ---------------------------------------------------------------------------
# BH33-M2: _from_raw_dict rejects non-numeric types
# ---------------------------------------------------------------------------


class TestConfigFromRawDict:
    """BH33-M2: _from_raw_dict DIRECT params must reject non-numeric types."""

    def test_from_yaml_list_value_rejected(self):
        """A YAML list for a numeric param must raise TypeError."""
        pytest.importorskip("yaml")
        import pathlib
        import tempfile

        from config import AegisConfig

        with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
            f.write("parameters:\n  epsilon_R:\n    - 0.01\n    - 0.02\n")
            f.flush()
            with pytest.raises(TypeError, match="Expected numeric value"):
                AegisConfig.from_yaml(pathlib.Path(f.name))

    def test_from_yaml_nested_dict_value_rejected(self):
        """A YAML dict for a numeric param must raise TypeError."""
        pytest.importorskip("yaml")
        import pathlib
        import tempfile

        from config import AegisConfig

        with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
            f.write("parameters:\n  epsilon_R:\n    value: 0.01\n")
            f.flush()
            with pytest.raises(TypeError, match="Expected numeric value"):
                AegisConfig.from_yaml(pathlib.Path(f.name))

    def test_from_yaml_valid_string_numeric_coerced(self):
        """Quoted numeric strings in YAML must be coerced to float."""
        pytest.importorskip("yaml")
        import pathlib
        import tempfile

        from config import AegisConfig

        with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
            f.write('parameters:\n  epsilon_R: "0.05"\n')
            f.flush()
            cfg = AegisConfig.from_yaml(pathlib.Path(f.name))
            assert cfg.epsilon_R == 0.05


# ---------------------------------------------------------------------------
# BH33-M3: DriftMonitor.evaluate() histogram asymmetry with Inf values
# ---------------------------------------------------------------------------


class TestDriftMonitorEvaluateInfFiltering:
    """BH33-M3: evaluate() must exclude Inf from histogram like set_baseline()."""

    def test_evaluate_with_inf_excluded_from_histogram(self):
        """Inf values in current_window must not inflate histogram bins."""
        from engine.drift import DriftMonitor

        monitor = DriftMonitor(num_bins=10)
        # Baseline: uniform-ish finite data
        baseline = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        monitor.set_baseline(baseline)

        # Current window: same data plus Inf
        current_no_inf = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        result_no_inf = monitor.evaluate(current_no_inf)

        # With Inf added — should give the same KL divergence since Inf
        # is filtered before histogram construction (after fix)
        current_with_inf = [*current_no_inf, float("inf")]
        result_with_inf = monitor.evaluate(current_with_inf)

        # KL divergence should be identical (Inf is excluded from histogram)
        assert result_no_inf.kl_divergence == result_with_inf.kl_divergence

    def test_evaluate_with_neg_inf_excluded(self):
        """Negative Inf should also be filtered from histogram."""
        from engine.drift import DriftMonitor

        monitor = DriftMonitor(num_bins=10)
        baseline = [0.1, 0.2, 0.3, 0.4, 0.5]
        monitor.set_baseline(baseline)

        current = [0.1, 0.2, 0.3, 0.4, 0.5]
        result_clean = monitor.evaluate(current)

        current_neg_inf = [*current, float("-inf")]
        result_neg_inf = monitor.evaluate(current_neg_inf)

        assert result_clean.kl_divergence == result_neg_inf.kl_divergence

    def test_evaluate_window_size_reflects_finite_only(self):
        """window_size in result should count only finite values."""
        from engine.drift import DriftMonitor

        monitor = DriftMonitor(num_bins=5)
        monitor.set_baseline([1.0, 2.0, 3.0, 4.0, 5.0])

        result = monitor.evaluate([1.0, 2.0, float("inf"), 3.0])
        assert result.window_size == 3  # only finite values


# ---------------------------------------------------------------------------
# BH33-M4: OverrideWorkflow.__init__ defensive copy of failed_gates
# ---------------------------------------------------------------------------


class TestOverrideWorkflowDefensiveCopy:
    """BH33-M4: __init__ must defensive-copy failed_gates."""

    def test_failed_gates_not_aliased(self):
        """Mutating the original list must not affect the workflow."""
        from workflows.override import OverrideWorkflow

        gates = ["risk", "quality"]
        workflow = OverrideWorkflow(
            proposal_id="test-copy",
            justification="test",
            failed_gates=gates,
            requested_by="user-1",
        )

        # Mutate the original list
        gates.append("novelty")
        gates.clear()

        # Workflow should still have the original values
        assert workflow.request.failed_gates == ["risk", "quality"]

    def test_failed_gates_is_independent_list(self):
        """The stored list should be a different object from the input."""
        from workflows.override import OverrideWorkflow

        gates = ["risk"]
        workflow = OverrideWorkflow(
            proposal_id="test-identity",
            justification="test",
            failed_gates=gates,
            requested_by="user-1",
        )

        assert workflow.request.failed_gates is not gates
        assert workflow.request.failed_gates == gates


# ---------------------------------------------------------------------------
# BH33-M5: mark_completed() state_data sync (Codex finding)
# ---------------------------------------------------------------------------


class TestMarkCompletedStateDataSync:
    """BH33-M5: mark_completed() must sync state_data with final_state."""

    @pytest.mark.asyncio
    async def test_mark_completed_syncs_state_data(self):
        """After mark_completed, load_checkpoint should reflect final state."""
        try:
            from workflows.persistence.engine import DatabaseConfig
            from workflows.persistence.repository import WorkflowPersistence
            from workflows.proposal import ProposalMetadata, ProposalWorkflow
        except ImportError:
            pytest.skip("persistence deps not available")

        config = DatabaseConfig.for_testing()
        persistence = WorkflowPersistence(config)
        await persistence.initialize()

        metadata = ProposalMetadata(
            title="BH33 test",
            description="test proposal",
            author_id="user-1",
        )
        workflow = ProposalWorkflow(
            proposal_id="prop-bh33-m5a",
            metadata=metadata,
        )

        await persistence.save_checkpoint(
            workflow=workflow,
            actor_id="user-1",
        )

        result = await persistence.mark_completed(
            workflow_id=workflow.proposal_id,
            actor_id="admin",
            final_state="approved",
        )
        assert result is True

        state_data = await persistence.load_checkpoint(workflow.proposal_id)
        assert state_data is not None
        assert state_data.get("state") == "approved"

        await persistence.close()

    @pytest.mark.asyncio
    async def test_mark_completed_syncs_current_state_key(self):
        """state_data with 'current_state' key should also be updated."""
        try:
            from workflows.persistence.engine import DatabaseConfig
            from workflows.persistence.repository import WorkflowPersistence
            from workflows.proposal import ProposalMetadata, ProposalWorkflow
        except ImportError:
            pytest.skip("persistence deps not available")

        config = DatabaseConfig.for_testing()
        persistence = WorkflowPersistence(config)
        await persistence.initialize()

        metadata = ProposalMetadata(
            title="BH33 test2",
            description="test proposal 2",
            author_id="user-2",
        )
        workflow = ProposalWorkflow(
            proposal_id="prop-bh33-m5b",
            metadata=metadata,
        )

        await persistence.save_checkpoint(
            workflow=workflow,
            actor_id="user-2",
        )

        await persistence.mark_completed(
            workflow_id=workflow.proposal_id,
            actor_id="admin",
            final_state="rejected",
        )

        state_data = await persistence.load_checkpoint(workflow.proposal_id)
        assert state_data is not None
        # The key may be 'state' or 'current_state' depending on workflow type
        if "current_state" in state_data:
            assert state_data["current_state"] == "rejected"

        await persistence.close()
