"""Tests for AEGIS Customer Management (Phase 1).

Tests cover:
- Customer dataclass validation and serialization
- UsageRecord and UsageSummary serialization
- CustomerManager CRUD operations (with DynamoDB mock)
- Usage metering (atomic counters)
- API key → customer mapping and caching
- Lambda handler customer context injection
- Admin CLI commands
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from aegis_governance.customer import (
    Customer,
    CustomerManager,
    UsageRecord,
    UsageSummary,
    generate_customer_id,
)

# ---------------------------------------------------------------------------
# Customer dataclass tests
# ---------------------------------------------------------------------------


class TestCustomer:
    """Test Customer dataclass validation and serialization."""

    def test_create_valid_customer(self) -> None:
        c = Customer(
            customer_id="cust_abc123",
            name="Acme Corp",
            email="admin@acme.com",
        )
        assert c.customer_id == "cust_abc123"
        assert c.name == "Acme Corp"
        assert c.email == "admin@acme.com"
        assert c.tier == "community"  # default tier normalizes from "community"
        assert c.status == "active"
        assert c.created_at  # auto-populated

    def test_customer_missing_id_raises(self) -> None:
        with pytest.raises(ValueError, match="customer_id is required"):
            Customer(customer_id="", name="Acme", email="a@b.com")

    def test_customer_missing_name_raises(self) -> None:
        with pytest.raises(ValueError, match="name is required"):
            Customer(customer_id="cust_1", name="", email="a@b.com")

    def test_customer_missing_email_raises(self) -> None:
        with pytest.raises(ValueError, match="email is required"):
            Customer(customer_id="cust_1", name="Acme", email="")

    def test_customer_invalid_tier_raises(self) -> None:
        with pytest.raises(ValueError, match="tier must be"):
            Customer(
                customer_id="cust_1",
                name="Acme",
                email="a@b.com",
                tier="gold",
            )

    def test_customer_invalid_status_raises(self) -> None:
        with pytest.raises(ValueError, match="status must be"):
            Customer(
                customer_id="cust_1",
                name="Acme",
                email="a@b.com",
                status="banned",
            )

    def test_customer_valid_tiers(self) -> None:
        # Canonical names
        for tier in ("community", "professional", "enterprise", "financial_services"):
            c = Customer(
                customer_id="cust_1",
                name="Acme",
                email="a@b.com",
                tier=tier,
            )
            assert c.tier == tier
        # Aliases normalize
        c_free = Customer(customer_id="cust_1", name="A", email="a@b.com", tier="free")
        assert c_free.tier == "community"
        c_pro = Customer(customer_id="cust_1", name="A", email="a@b.com", tier="pro")
        assert c_pro.tier == "professional"

    def test_customer_to_item_roundtrip(self) -> None:
        c = Customer(
            customer_id="cust_xyz",
            name="Test Corp",
            email="test@corp.com",
            company="Corp Inc",
            tier="professional",
            api_key_id="ak_123",
            metadata={"plan": "annual"},
        )
        item = c.to_item()
        assert item["pk"] == "CUSTOMER#cust_xyz"
        assert item["sk"] == "PROFILE"
        assert item["entity_type"] == "CUSTOMER"

        restored = Customer.from_item(item)
        assert restored.customer_id == c.customer_id
        assert restored.name == c.name
        assert restored.email == c.email
        assert restored.company == c.company
        assert restored.tier == c.tier
        assert restored.api_key_id == c.api_key_id
        assert restored.metadata == c.metadata

    def test_customer_to_dict(self) -> None:
        c = Customer(
            customer_id="cust_1",
            name="Acme",
            email="a@b.com",
        )
        d = c.to_dict()
        assert d["customer_id"] == "cust_1"
        assert d["name"] == "Acme"
        assert d["email"] == "a@b.com"
        # Must be JSON-serializable
        json.dumps(d)

    def test_customer_preserves_existing_timestamps(self) -> None:
        ts = "2026-01-01T00:00:00+00:00"
        c = Customer(
            customer_id="cust_1",
            name="Acme",
            email="a@b.com",
            created_at=ts,
            updated_at=ts,
        )
        assert c.created_at == ts
        assert c.updated_at == ts


# ---------------------------------------------------------------------------
# UsageRecord tests
# ---------------------------------------------------------------------------


class TestUsageRecord:
    """Test UsageRecord serialization."""

    def test_usage_record_to_item(self) -> None:
        r = UsageRecord(
            customer_id="cust_1",
            month="2026-03",
            day="08",
            evaluate_count=42,
            risk_check_count=5,
            total_calls=47,
        )
        item = r.to_item()
        assert item["pk"] == "USAGE#cust_1#2026-03"
        assert item["sk"] == "DAY#08"
        assert item["entity_type"] == "USAGE"

    def test_usage_record_roundtrip(self) -> None:
        r = UsageRecord(
            customer_id="cust_1",
            month="2026-03",
            day="08",
            evaluate_count=10,
            risk_check_count=3,
            total_calls=13,
            channels={"api": 10, "mcp": 3},
        )
        item = r.to_item()
        restored = UsageRecord.from_item(item)
        assert restored.evaluate_count == 10
        assert restored.risk_check_count == 3
        assert restored.total_calls == 13


class TestUsageSummary:
    """Test UsageSummary aggregation."""

    def test_usage_summary_to_dict(self) -> None:
        s = UsageSummary(
            customer_id="cust_1",
            month="2026-03",
            total_evaluations=100,
            total_risk_checks=20,
            total_calls=120,
            channels={"api": 100, "mcp": 20},
            daily_breakdown=[
                UsageRecord(
                    customer_id="cust_1",
                    month="2026-03",
                    day="08",
                    evaluate_count=50,
                    risk_check_count=10,
                    total_calls=60,
                ),
            ],
        )
        d = s.to_dict()
        assert d["total_evaluations"] == 100
        assert len(d["daily_breakdown"]) == 1
        # Must be JSON-serializable
        json.dumps(d)


# ---------------------------------------------------------------------------
# generate_customer_id tests
# ---------------------------------------------------------------------------


class TestGenerateCustomerId:
    """Test customer ID generation."""

    def test_prefix(self) -> None:
        cid = generate_customer_id()
        assert cid.startswith("cust_")

    def test_uniqueness(self) -> None:
        ids = {generate_customer_id() for _ in range(100)}
        assert len(ids) == 100  # All unique

    def test_length(self) -> None:
        cid = generate_customer_id()
        # cust_ + 12 hex chars = 17
        assert len(cid) == 17


# ---------------------------------------------------------------------------
# CustomerManager tests (mocked DynamoDB)
# ---------------------------------------------------------------------------


class FakeDynamoTable:
    """In-memory DynamoDB table mock for testing."""

    def __init__(self) -> None:
        self.items: dict[tuple[str, str], dict[str, Any]] = {}

    def put_item(self, Item: dict[str, Any]) -> None:
        key = (Item["pk"], Item["sk"])
        self.items[key] = Item

    def get_item(self, Key: dict[str, str]) -> dict[str, Any]:
        key = (Key["pk"], Key["sk"])
        item = self.items.get(key)
        if item:
            return {"Item": item}
        return {}

    def scan(self, **kwargs: Any) -> dict[str, Any]:
        filter_expr = kwargs.get("FilterExpression", "")
        values = kwargs.get("ExpressionAttributeValues", {})
        results = []
        for item in self.items.values():
            if "entity_type = :et" in filter_expr and item.get(
                "entity_type"
            ) == values.get(":et"):
                results.append(item)
        return {"Items": results}

    def query(self, **kwargs: Any) -> dict[str, Any]:
        values = kwargs.get("ExpressionAttributeValues", {})
        pk_val = values.get(":pk", "")
        prefix = values.get(":prefix", "")
        results = []
        for (pk, sk), item in self.items.items():
            if pk == pk_val and sk.startswith(prefix):
                results.append(item)
        return {"Items": results}

    def update_item(self, Key: dict[str, str], **kwargs: Any) -> None:
        pk, sk = Key["pk"], Key["sk"]
        values = kwargs.get("ExpressionAttributeValues", {})
        key = (pk, sk)
        if key not in self.items:
            self.items[key] = {
                "pk": pk,
                "sk": sk,
                "evaluate_count": 0,
                "risk_check_count": 0,
                "total_calls": 0,
            }
        item = self.items[key]
        # Apply SET values: map :placeholder → value from ExpressionAttributeValues
        # The real DynamoDB UpdateExpression maps attribute names to :placeholders.
        # We simulate by matching known placeholders to item keys.
        placeholder_to_key = {
            ":cid": "customer_id",
            ":month": "month",
            ":day": "day",
            ":et": "entity_type",
        }
        for placeholder, item_key in placeholder_to_key.items():
            if placeholder in values:
                item[item_key] = values[placeholder]
        # Apply ADD expressions (simulate atomic increment)
        update_expr = kwargs.get("UpdateExpression", "")
        if "evaluate_count :one" in update_expr:
            item["evaluate_count"] = item.get("evaluate_count", 0) + 1
        if "risk_check_count :one" in update_expr:
            item["risk_check_count"] = item.get("risk_check_count", 0) + 1
        if "total_calls :one" in update_expr:
            item["total_calls"] = item.get("total_calls", 0) + 1


class FakeDynamoResource:
    """Fake boto3 DynamoDB resource."""

    def __init__(self, table: FakeDynamoTable) -> None:
        self._table = table

    def Table(self, name: str) -> FakeDynamoTable:
        return self._table


@pytest.fixture
def fake_table() -> FakeDynamoTable:
    return FakeDynamoTable()


@pytest.fixture
def customer_mgr(fake_table: FakeDynamoTable) -> CustomerManager:
    resource = FakeDynamoResource(fake_table)
    return CustomerManager(
        table_name="test-table",
        dynamodb_resource=resource,
    )


class TestCustomerManager:
    """Test CustomerManager CRUD operations."""

    def test_create_customer(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(
            name="Acme Corp",
            email="admin@acme.com",
            company="Acme",
        )
        assert c.customer_id.startswith("cust_")
        assert c.name == "Acme Corp"
        assert c.tier == "community"

    def test_create_customer_with_api_key(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(
            name="Acme Corp",
            email="admin@acme.com",
            api_key_id="ak_test_123",
        )
        # API key mapping should be written
        found = customer_mgr.get_customer_by_api_key("ak_test_123")
        assert found is not None
        assert found.customer_id == c.customer_id

    def test_get_customer(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(name="Test", email="t@t.com")
        found = customer_mgr.get_customer(c.customer_id)
        assert found is not None
        assert found.name == "Test"

    def test_get_customer_not_found(self, customer_mgr: CustomerManager) -> None:
        assert customer_mgr.get_customer("nonexistent") is None

    def test_get_customer_by_api_key_not_found(
        self, customer_mgr: CustomerManager
    ) -> None:
        assert customer_mgr.get_customer_by_api_key("unknown_key") is None

    def test_api_key_lookup_caching(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(
            name="Cached", email="c@c.com", api_key_id="ak_cached"
        )
        # First call populates cache
        found1 = customer_mgr.get_customer_by_api_key("ak_cached")
        assert found1 is not None

        # Second call should hit cache (we can verify by checking cache dict)
        assert "ak_cached" in customer_mgr._customer_cache
        found2 = customer_mgr.get_customer_by_api_key("ak_cached")
        assert found2 is not None
        assert found2.customer_id == c.customer_id

    def test_list_customers(self, customer_mgr: CustomerManager) -> None:
        customer_mgr.create_customer(name="A", email="a@a.com")
        customer_mgr.create_customer(name="B", email="b@b.com")
        customers = customer_mgr.list_customers()
        assert len(customers) == 2

    def test_list_customers_empty(self, customer_mgr: CustomerManager) -> None:
        assert customer_mgr.list_customers() == []

    def test_update_customer(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(name="Original", email="o@o.com")
        updated = customer_mgr.update_customer(
            c.customer_id, name="Updated", tier="pro"
        )
        assert updated is not None
        assert updated.name == "Updated"
        assert updated.tier == "professional"  # "pro" alias normalizes

    def test_update_customer_not_found(self, customer_mgr: CustomerManager) -> None:
        assert customer_mgr.update_customer("nonexistent", name="X") is None

    def test_update_customer_ignores_disallowed_fields(
        self, customer_mgr: CustomerManager
    ) -> None:
        c = customer_mgr.create_customer(name="Acme", email="a@a.com")
        original_id = c.customer_id
        # Try to update a disallowed field via **kwargs
        updated = customer_mgr.update_customer(original_id, **{"name": "Updated"})
        assert updated is not None
        assert updated.customer_id == original_id  # Not changed

    def test_update_customer_rejects_invalid_tier(
        self, customer_mgr: CustomerManager
    ) -> None:
        c = customer_mgr.create_customer(name="Acme", email="a@a.com")
        with pytest.raises(ValueError, match="tier must be"):
            customer_mgr.update_customer(c.customer_id, tier="gold")

    def test_update_customer_rejects_invalid_status(
        self, customer_mgr: CustomerManager
    ) -> None:
        c = customer_mgr.create_customer(name="Acme", email="a@a.com")
        with pytest.raises(ValueError, match="status must be"):
            customer_mgr.update_customer(c.customer_id, status="banned")

    def test_update_customer_rejects_empty_name(
        self, customer_mgr: CustomerManager
    ) -> None:
        c = customer_mgr.create_customer(name="Acme", email="a@a.com")
        with pytest.raises(ValueError, match="name is required"):
            customer_mgr.update_customer(c.customer_id, name="")

    def test_update_customer_rejects_empty_email(
        self, customer_mgr: CustomerManager
    ) -> None:
        c = customer_mgr.create_customer(name="Acme", email="a@a.com")
        with pytest.raises(ValueError, match="email is required"):
            customer_mgr.update_customer(c.customer_id, email="")


class TestUsageMetering:
    """Test usage recording and querying."""

    def test_record_usage_evaluate(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(name="User", email="u@u.com")
        customer_mgr.record_usage(c.customer_id, route="/evaluate")
        customer_mgr.record_usage(c.customer_id, route="/evaluate")

        summary = customer_mgr.get_usage(c.customer_id)
        assert summary.total_evaluations == 2
        assert summary.total_calls == 2

    def test_record_usage_risk_check(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(name="User", email="u@u.com")
        customer_mgr.record_usage(c.customer_id, route="/risk-check")

        summary = customer_mgr.get_usage(c.customer_id)
        assert summary.total_risk_checks == 1
        assert summary.total_calls == 1

    def test_record_usage_mixed(self, customer_mgr: CustomerManager) -> None:
        c = customer_mgr.create_customer(name="User", email="u@u.com")
        customer_mgr.record_usage(c.customer_id, route="/evaluate")
        customer_mgr.record_usage(c.customer_id, route="/risk-check")
        customer_mgr.record_usage(c.customer_id, route="/evaluate")

        summary = customer_mgr.get_usage(c.customer_id)
        assert summary.total_evaluations == 2
        assert summary.total_risk_checks == 1
        assert summary.total_calls == 3

    def test_get_usage_empty(self, customer_mgr: CustomerManager) -> None:
        summary = customer_mgr.get_usage("nonexistent")
        assert summary.total_calls == 0
        assert summary.daily_breakdown == []

    def test_get_usage_specific_month(self, customer_mgr: CustomerManager) -> None:
        summary = customer_mgr.get_usage("cust_1", month="2025-01")
        assert summary.month == "2025-01"
        assert summary.total_calls == 0

    def test_record_usage_failure_does_not_raise(
        self, customer_mgr: CustomerManager
    ) -> None:
        """Usage metering failure should never bubble up."""
        # Force table to raise
        customer_mgr._table = MagicMock()
        customer_mgr._table.update_item.side_effect = RuntimeError("DDB error")
        # Should not raise
        customer_mgr.record_usage("cust_1", route="/evaluate")


# ---------------------------------------------------------------------------
# Lambda handler customer integration tests
# ---------------------------------------------------------------------------


class TestLambdaCustomerIntegration:
    """Test customer context injection in Lambda handler."""

    def test_inject_customer_context_adds_headers(self) -> None:
        from lambda_handler import _inject_customer_context

        customer = Customer(
            customer_id="cust_abc",
            name="Test",
            email="t@t.com",
            tier="professional",
        )
        resp = {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"status": "proceed"}),
        }
        result = _inject_customer_context(resp, customer)
        assert result["headers"]["X-AEGIS-Customer"] == "cust_abc"
        assert result["headers"]["X-AEGIS-Tier"] == "professional"

        body = json.loads(result["body"])
        assert body["_customer_id"] == "cust_abc"
        assert body["_tier"] == "professional"

    def test_inject_customer_context_none_customer(self) -> None:
        from lambda_handler import _inject_customer_context

        resp = {
            "statusCode": 200,
            "headers": {},
            "body": json.dumps({"status": "proceed"}),
        }
        result = _inject_customer_context(resp, None)
        assert "X-AEGIS-Customer" not in result["headers"]

    def test_track_usage_none_manager(self) -> None:
        from lambda_handler import _track_usage

        # Should not raise when manager is None
        _track_usage(None, None, route="/evaluate")

    def test_track_usage_none_customer(self) -> None:
        from lambda_handler import _track_usage

        mgr = MagicMock()
        _track_usage(mgr, None, route="/evaluate")
        mgr.record_usage.assert_not_called()

    def test_track_usage_calls_record(self) -> None:
        from lambda_handler import _track_usage

        mgr = MagicMock()
        customer = Customer(customer_id="cust_1", name="T", email="t@t.com")
        _track_usage(mgr, customer, route="/evaluate")
        mgr.record_usage.assert_called_once_with(
            "cust_1", channel="api", route="/evaluate"
        )

    def test_track_usage_exception_suppressed(self) -> None:
        from lambda_handler import _track_usage

        mgr = MagicMock()
        mgr.record_usage.side_effect = RuntimeError("boom")
        customer = Customer(customer_id="cust_1", name="T", email="t@t.com")
        # Should not raise
        _track_usage(mgr, customer, route="/evaluate")


# ---------------------------------------------------------------------------
# CLI admin command tests
# ---------------------------------------------------------------------------


class TestAdminCLI:
    """Test admin CLI commands with mocked DynamoDB."""

    def test_create_customer_cli(self, capsys: pytest.CaptureFixture[str]) -> None:
        from cli import cmd_admin_create_customer

        fake = FakeDynamoTable()
        resource = FakeDynamoResource(fake)
        mgr = CustomerManager(table_name="test", dynamodb_resource=resource)

        args = MagicMock()
        args.name = "CLI Corp"
        args.email = "cli@corp.com"
        args.company = "Corp"
        args.tier = "community"
        args.api_key_id = ""
        args.table = None
        args.region = None

        with patch(
            "aegis_governance.customer.CustomerManager",
            return_value=mgr,
        ):
            result = cmd_admin_create_customer(args)

        assert result == 0
        output = json.loads(capsys.readouterr().out)
        assert output["name"] == "CLI Corp"
        assert output["customer_id"].startswith("cust_")

    def test_usage_cli(self, capsys: pytest.CaptureFixture[str]) -> None:
        from cli import cmd_admin_usage

        fake = FakeDynamoTable()
        resource = FakeDynamoResource(fake)
        mgr = CustomerManager(table_name="test", dynamodb_resource=resource)

        args = MagicMock()
        args.customer_id = "cust_test"
        args.month = "2026-03"
        args.table = None
        args.region = None

        with patch(
            "aegis_governance.customer.CustomerManager",
            return_value=mgr,
        ):
            result = cmd_admin_usage(args)

        assert result == 0
        output = json.loads(capsys.readouterr().out)
        assert output["month"] == "2026-03"
        assert output["total_calls"] == 0

    def test_build_parser_has_admin(self) -> None:
        from cli import build_parser

        parser = build_parser()
        # Should parse admin create-customer without error
        args = parser.parse_args(
            [
                "admin",
                "create-customer",
                "--name",
                "Test",
                "--email",
                "t@t.com",
            ]
        )
        assert args.command == "admin"
        assert args.admin_command == "create-customer"
        assert args.name == "Test"

    def test_build_parser_admin_usage(self) -> None:
        from cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["admin", "usage", "cust_123", "--month", "2026-03"])
        assert args.admin_command == "usage"
        assert args.customer_id == "cust_123"
        assert args.month == "2026-03"
