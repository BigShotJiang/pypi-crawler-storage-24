"""Regression tests for optional dependency graceful degradation.

Verifies that production modules import successfully when optional
dependencies (scipy, prometheus_client) are absent, and raise clear
ImportError messages at point of use.
"""

import importlib
import sys
from unittest.mock import patch

import pytest


class TestScipyGracefulDegradation:
    """Tests for engine.utility graceful degradation without scipy."""

    def test_utility_module_imports_without_scipy(self):
        """Module-level import succeeds even when scipy is absent."""
        # Remove scipy and the utility module from sys.modules so we can
        # re-import with scipy blocked.
        saved_modules = {}
        modules_to_remove = [
            k for k in sys.modules if k == "scipy" or k.startswith("scipy.")
        ]
        modules_to_remove.append("engine.utility")
        for mod in modules_to_remove:
            if mod in sys.modules:
                saved_modules[mod] = sys.modules.pop(mod)

        try:
            with patch.dict(sys.modules, {"scipy": None, "scipy.stats": None}):
                module = importlib.import_module("engine.utility")
                assert hasattr(module, "_HAS_SCIPY")
                assert module._HAS_SCIPY is False
        finally:
            # Restore original modules
            for mod, ref in saved_modules.items():
                sys.modules[mod] = ref

    def test_get_z_score_raises_importerror_without_scipy_unlisted(self):
        """_get_z_score raises ImportError for unlisted confidence when scipy absent."""
        saved_modules = {}
        modules_to_remove = [
            k for k in sys.modules if k == "scipy" or k.startswith("scipy.")
        ]
        modules_to_remove.append("engine.utility")
        for mod in modules_to_remove:
            if mod in sys.modules:
                saved_modules[mod] = sys.modules.pop(mod)

        try:
            with patch.dict(sys.modules, {"scipy": None, "scipy.stats": None}):
                module = importlib.import_module("engine.utility")
                calc = object.__new__(module.UtilityCalculator)
                with pytest.raises(
                    ImportError, match="pip install aegis-governance\\[engine\\]"
                ):
                    calc._get_z_score(0.9123)
        finally:
            for mod, ref in saved_modules.items():
                sys.modules[mod] = ref

    def test_get_z_score_fallback_succeeds_for_common_confidence(self):
        """_get_z_score returns correct value from fallback table when scipy absent."""
        saved_modules = {}
        modules_to_remove = [
            k for k in sys.modules if k == "scipy" or k.startswith("scipy.")
        ]
        modules_to_remove.append("engine.utility")
        for mod in modules_to_remove:
            if mod in sys.modules:
                saved_modules[mod] = sys.modules.pop(mod)

        try:
            with patch.dict(sys.modules, {"scipy": None, "scipy.stats": None}):
                module = importlib.import_module("engine.utility")
                calc = object.__new__(module.UtilityCalculator)
                z = calc._get_z_score(0.95)
                assert abs(z - 1.6448536269514720) < 1e-10
        finally:
            for mod, ref in saved_modules.items():
                sys.modules[mod] = ref


class TestPrometheusGracefulDegradation:
    """Tests for prometheus_exporter graceful degradation without prometheus_client."""

    def test_prometheus_module_imports_without_client(self):
        """Module-level import succeeds even when prometheus_client is absent."""
        saved_modules = {}
        modules_to_remove = [
            k
            for k in sys.modules
            if k == "prometheus_client" or k.startswith("prometheus_client.")
        ]
        modules_to_remove.append("telemetry.prometheus_exporter")
        for mod in modules_to_remove:
            if mod in sys.modules:
                saved_modules[mod] = sys.modules.pop(mod)

        try:
            with patch.dict(sys.modules, {"prometheus_client": None}):
                module = importlib.import_module("telemetry.prometheus_exporter")
                assert hasattr(module, "PROMETHEUS_AVAILABLE")
                assert module.PROMETHEUS_AVAILABLE is False
        finally:
            for mod, ref in saved_modules.items():
                sys.modules[mod] = ref

    def test_prometheus_exporter_init_raises_without_client(self):
        """PrometheusExporter constructor raises ImportError with install instructions."""
        saved_modules = {}
        modules_to_remove = [
            k
            for k in sys.modules
            if k == "prometheus_client" or k.startswith("prometheus_client.")
        ]
        modules_to_remove.append("telemetry.prometheus_exporter")
        for mod in modules_to_remove:
            if mod in sys.modules:
                saved_modules[mod] = sys.modules.pop(mod)

        try:
            with patch.dict(sys.modules, {"prometheus_client": None}):
                module = importlib.import_module("telemetry.prometheus_exporter")
                with pytest.raises(
                    ImportError, match="pip install aegis-governance\\[telemetry\\]"
                ):
                    module.PrometheusExporter()
        finally:
            for mod, ref in saved_modules.items():
                sys.modules[mod] = ref
