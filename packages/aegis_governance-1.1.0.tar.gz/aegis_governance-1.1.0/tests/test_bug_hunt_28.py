"""Bug Hunt #28 Regression Tests

BH28-M1: ConsensusWorkflow QUORUM_MET state never reverts when quorum lost
BH28-M2: Governance initiate_override blocked by expired stale override
BH28-M3: CLI risk_score alias overwrites risk simplified name
BH28-L1: DriftMonitor.evaluate() window_size includes non-finite values
BH28-L2: Config quality_no_zero_subscore string coercion
"""

from datetime import datetime, timedelta, timezone

import pytest

# ---------------------------------------------------------------------------
# BH28-M1: ConsensusWorkflow QUORUM_MET revert on quorum loss
# ---------------------------------------------------------------------------


class TestConsensusQuorumRevert:
    """QUORUM_MET state must revert to PENDING when quorum is lost."""

    def test_quorum_met_reverts_to_pending_on_vote_overwrite_to_defer(self):
        """Overwriting a decisive vote with DEFER drops participation below quorum."""
        from workflows.consensus import (
            ConsensusConfig,
            ConsensusState,
            ConsensusWorkflow,
            VoteOutcome,
        )

        # Use 5 voters. Quorum at 40%, approval at 80%.
        # 1 APPROVE + 1 REJECT = 2/5 participation = 40% >= 40% quorum.
        # Approval rate = 1/2 = 50% < 80% threshold, so no finalization.
        config = ConsensusConfig(quorum_percentage=0.39, approval_threshold=0.80)
        wf = ConsensusWorkflow("prop-1", {"a", "b", "c", "d", "e"}, config=config)

        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.REJECT)
        assert wf.state == ConsensusState.QUORUM_MET

        # Voter "b" overwrites to DEFER: participation 1/5 = 0.20 < 0.39
        wf.cast_vote("b", VoteOutcome.DEFER)
        assert wf.state == ConsensusState.PENDING
        assert not wf.quorum_met

    def test_quorum_met_reverts_result_consistent(self):
        """get_result().state and get_result().quorum_met must be consistent."""
        from workflows.consensus import (
            ConsensusConfig,
            ConsensusState,
            ConsensusWorkflow,
            VoteOutcome,
        )

        config = ConsensusConfig(quorum_percentage=0.39, approval_threshold=0.80)
        wf = ConsensusWorkflow("prop-2", {"a", "b", "c", "d", "e"}, config=config)

        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.REJECT)  # quorum met, not finalized
        wf.cast_vote("b", VoteOutcome.DEFER)  # quorum lost

        result = wf.get_result()
        # State and quorum_met must not contradict
        if result.state == ConsensusState.QUORUM_MET:
            assert result.quorum_met is True
        if not result.quorum_met:
            assert result.state != ConsensusState.QUORUM_MET

    def test_quorum_revert_then_regain_still_works(self):
        """After quorum is lost and regained, consensus can still finalize."""
        from workflows.consensus import (
            ConsensusConfig,
            ConsensusState,
            ConsensusWorkflow,
            VoteOutcome,
        )

        config = ConsensusConfig(quorum_percentage=0.39, approval_threshold=0.80)
        wf = ConsensusWorkflow("prop-3", {"a", "b", "c", "d", "e"}, config=config)

        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.REJECT)  # quorum met, not finalized
        assert wf.state == ConsensusState.QUORUM_MET

        # Lose quorum
        wf.cast_vote("b", VoteOutcome.DEFER)
        assert wf.state == ConsensusState.PENDING

        # Regain quorum with enough approvals to finalize (4/4 decisive = 100% > 80%)
        wf.cast_vote("b", VoteOutcome.APPROVE)
        wf.cast_vote("c", VoteOutcome.APPROVE)
        wf.cast_vote("d", VoteOutcome.APPROVE)
        wf.cast_vote("e", VoteOutcome.APPROVE)
        assert wf.state == ConsensusState.APPROVED

    def test_serialization_roundtrip_after_quorum_revert(self):
        """to_dict/from_dict preserves reverted PENDING state correctly."""
        from workflows.consensus import (
            ConsensusConfig,
            ConsensusState,
            ConsensusWorkflow,
            VoteOutcome,
        )

        config = ConsensusConfig(quorum_percentage=0.39, approval_threshold=0.80)
        wf = ConsensusWorkflow("prop-4", {"a", "b", "c", "d", "e"}, config=config)

        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote(
            "b", VoteOutcome.REJECT
        )  # 2/5=40% >= 39% quorum, 50% < 80% approval
        assert wf.state == ConsensusState.QUORUM_MET
        wf.cast_vote("b", VoteOutcome.DEFER)  # 1/5=20% < 39% quorum → revert
        assert wf.state == ConsensusState.PENDING

        restored = ConsensusWorkflow.from_dict(wf.to_dict())
        assert restored.state == ConsensusState.PENDING


# ---------------------------------------------------------------------------
# BH28-M2: Governance initiate_override blocked by expired stale override
# ---------------------------------------------------------------------------


class TestGovernanceStaleOverrideEviction:
    """initiate_override must evict expired overrides for the same proposal."""

    def test_expired_override_evicted_on_new_request(self):
        """New override succeeds after previous one expired."""
        from actors.governance import Governance

        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="first",
            failed_gates=["risk"],
            requested_by="dev-1",
        )
        # Force expiration
        stale = gov.active_overrides["prop-1"]
        stale.expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="second",
            failed_gates=["risk"],
            requested_by="dev-2",
        )
        assert result.success is True
        assert gov.active_overrides["prop-1"] is not stale
        assert gov.active_overrides["prop-1"].request.requested_by == "dev-2"

    def test_non_expired_override_still_blocks(self):
        """Active (non-expired) override still blocks new requests."""
        from actors.governance import Governance

        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="first",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="second",
            failed_gates=["risk"],
            requested_by="dev-2",
        )
        assert result.success is False
        assert "already active" in result.error


# ---------------------------------------------------------------------------
# BH28-M3: CLI risk_score alias vs risk simplified name
# ---------------------------------------------------------------------------


class TestCLIRiskAliasOverwrite:
    """risk_score should NOT overwrite when 'risk' simplified name is present."""

    def test_risk_simplified_name_takes_priority_over_risk_score(self):
        """When both 'risk' and 'risk_score' are provided, 'risk' wins."""
        from cli import _parse_proposal

        data = {"risk": 0.3, "risk_score": 0.5}
        result = _parse_proposal(data)
        assert result["risk_proposed"] == 0.3

    def test_risk_score_used_when_no_risk_or_risk_proposed(self):
        """risk_score applies when neither canonical nor simplified name is present."""
        from cli import _parse_proposal

        data = {"risk_score": 0.4}
        result = _parse_proposal(data)
        assert result["risk_proposed"] == 0.4

    def test_risk_proposed_canonical_takes_priority(self):
        """Canonical risk_proposed takes priority over risk_score."""
        from cli import _parse_proposal

        data = {"risk_proposed": 0.2, "risk_score": 0.6}
        result = _parse_proposal(data)
        assert result["risk_proposed"] == 0.2


# ---------------------------------------------------------------------------
# BH28-L1: DriftMonitor.evaluate() window_size accuracy
# ---------------------------------------------------------------------------


class TestDriftWindowSizeAccuracy:
    """window_size should count only finite values that contributed to KL."""

    def test_window_size_excludes_nan(self):
        """NaN values should not be counted in window_size."""
        from engine.drift import DriftMonitor

        dm = DriftMonitor(num_bins=5, tau_warning=0.5, tau_critical=1.0)
        dm.set_baseline([0.1, 0.2, 0.3, 0.4, 0.5])

        result = dm.evaluate([0.1, float("nan"), 0.3, float("nan"), 0.5])
        assert result.window_size == 3  # Only 3 finite values

    def test_window_size_excludes_inf(self):
        """Inf values should not be counted in window_size."""
        from engine.drift import DriftMonitor

        dm = DriftMonitor(num_bins=5, tau_warning=0.5, tau_critical=1.0)
        dm.set_baseline([0.1, 0.2, 0.3, 0.4, 0.5])

        result = dm.evaluate([0.1, float("inf"), 0.3, float("-inf"), 0.5])
        assert result.window_size == 3  # Only 3 finite values

    def test_window_size_all_finite(self):
        """When all values are finite, window_size equals input length."""
        from engine.drift import DriftMonitor

        dm = DriftMonitor(num_bins=5, tau_warning=0.5, tau_critical=1.0)
        dm.set_baseline([0.1, 0.2, 0.3, 0.4, 0.5])

        result = dm.evaluate([0.1, 0.2, 0.3, 0.4, 0.5])
        assert result.window_size == 5


# ---------------------------------------------------------------------------
# BH28-L2: Config quality_no_zero_subscore string coercion
# ---------------------------------------------------------------------------


class TestConfigBoolFieldCoercion:
    """Bool-allowed config fields must be properly coerced to actual bools."""

    def test_string_false_coerced_to_bool_false(self):
        """String 'false' must become bool False, not truthy string."""
        from config import AegisConfig

        cfg = AegisConfig.from_dict({"quality_no_zero_subscore": "false"})
        assert cfg.quality_no_zero_subscore is False

    def test_string_true_coerced_to_bool_true(self):
        """String 'true' must become bool True."""
        from config import AegisConfig

        cfg = AegisConfig.from_dict({"quality_no_zero_subscore": "true"})
        assert cfg.quality_no_zero_subscore is True

    def test_int_zero_coerced_to_bool_false(self):
        """Integer 0 must become bool False."""
        from config import AegisConfig

        cfg = AegisConfig.from_dict({"quality_no_zero_subscore": 0})
        assert cfg.quality_no_zero_subscore is False

    def test_bool_value_passes_through(self):
        """Actual bool value passes through unchanged."""
        from config import AegisConfig

        cfg = AegisConfig.from_dict({"quality_no_zero_subscore": True})
        assert cfg.quality_no_zero_subscore is True

    def test_invalid_string_raises_error(self):
        """Non-boolean string raises ValueError."""
        from config import AegisConfig

        with pytest.raises(ValueError, match="Cannot convert"):
            AegisConfig.from_dict({"quality_no_zero_subscore": "maybe"})

    def test_nan_float_raises_error(self):
        """NaN float must not silently coerce to True."""
        from config import AegisConfig

        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"quality_no_zero_subscore": float("nan")})

    def test_inf_float_raises_error(self):
        """Inf float must not silently coerce to True."""
        from config import AegisConfig

        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"quality_no_zero_subscore": float("inf")})


# ---------------------------------------------------------------------------
# QG70-L1: _from_raw_dict YAML bool coercion parity
# ---------------------------------------------------------------------------


class TestFromRawDictBoolCoercion:
    """_from_raw_dict must coerce bool-allowed fields via _coerce_bool."""

    def test_yaml_string_false_coerced(self):
        """YAML quoted 'false' string must become bool False in from_yaml path."""
        from config import AegisConfig

        cfg = AegisConfig._from_raw_dict(
            {"parameters": {"quality_no_zero_subscore": "false"}}
        )
        assert cfg.quality_no_zero_subscore is False

    def test_yaml_string_true_coerced(self):
        """YAML quoted 'true' string must become bool True in from_yaml path."""
        from config import AegisConfig

        cfg = AegisConfig._from_raw_dict(
            {"parameters": {"quality_no_zero_subscore": "true"}}
        )
        assert cfg.quality_no_zero_subscore is True


# ---------------------------------------------------------------------------
# QG70-L3: set_baseline passes only finite data to histogram
# ---------------------------------------------------------------------------


class TestSetBaselineFiniteOnly:
    """set_baseline must not pass Inf values to histogram."""

    def test_baseline_inf_excluded_from_histogram(self):
        """Inf values in baseline data should not skew the distribution."""
        from engine.drift import DriftMonitor

        dm = DriftMonitor(num_bins=5, tau_warning=0.5, tau_critical=1.0)
        # Baseline with Inf — Inf should be excluded from histogram
        baseline_hash = dm.set_baseline([0.1, 0.2, 0.3, 0.4, float("inf")])
        assert baseline_hash  # hash computed successfully

        # Histogram should sum to 1.0 (valid probability distribution)
        assert abs(sum(dm.baseline_distribution) - 1.0) < 1e-9

        # All 4 finite values should be in the histogram, Inf excluded
        total_count = sum(
            h * 4 for h in dm.baseline_distribution
        )  # unnormalize by count
        assert abs(total_count - 4.0) < 1e-9  # 4 finite values, not 5
