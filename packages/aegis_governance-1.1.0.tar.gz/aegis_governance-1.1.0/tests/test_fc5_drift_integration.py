"""FC-5: Drift detection integration tests.

Verifies end-to-end drift detection → policy enforcement → decision output.
"""

from engine.drift import DriftAction, DriftMonitor, DriftResult, DriftStatus
from integration.pcw_decide import PCWPhase, PCWStatus, _apply_drift_overrides


class TestDriftWarningIntegration:
    """FC-5: WARNING drift adds advisory guidance without blocking."""

    def test_warning_drift_appends_recalibration_step(self):
        """WARNING drift adds a review-baseline step to next_steps."""
        drift = DriftResult(
            status=DriftStatus.WARNING,
            kl_divergence=0.35,
            action=DriftAction.ALERT_AND_CONTINUE,
            baseline_hash="abc",
            window_size=100,
        )
        original_steps = ["Submit for review"]
        _, _, _, returned_steps = _apply_drift_overrides(
            drift_result=drift,
            status=PCWStatus.PAUSE,
            override_eligible=True,
            override_requires=["risk_lead"],
            rationale="Gates failed: risk",
            phase=PCWPhase.COMMIT,
            failing_gates=["risk"],
            next_steps=original_steps,
        )
        assert any("drift warning" in s.lower() for s in returned_steps)
        # Steps are recomputed but drift step is appended
        assert len(returned_steps) >= 2

    def test_warning_drift_updates_rationale(self):
        """WARNING drift appends drift info to rationale."""
        drift = DriftResult(
            status=DriftStatus.WARNING,
            kl_divergence=0.42,
            action=DriftAction.ALERT_AND_CONTINUE,
            baseline_hash="abc",
            window_size=100,
        )
        _, _, rationale, _ = _apply_drift_overrides(
            drift_result=drift,
            status=PCWStatus.PROCEED,
            override_eligible=True,
            override_requires=[],
            rationale="All gates passed",
            phase=PCWPhase.COMMIT,
            failing_gates=[],
            next_steps=["Proceed"],
        )
        assert "drift warning" in rationale.lower()
        assert "0.4200" in rationale

    def test_warning_drift_preserves_override_eligibility(self):
        """WARNING drift does NOT disable overrides (advisory only)."""
        drift = DriftResult(
            status=DriftStatus.WARNING,
            kl_divergence=0.35,
            action=DriftAction.ALERT_AND_CONTINUE,
            baseline_hash="abc",
            window_size=100,
        )
        eligible, requires, _, _ = _apply_drift_overrides(
            drift_result=drift,
            status=PCWStatus.PAUSE,
            override_eligible=True,
            override_requires=["risk_lead"],
            rationale="Gates failed",
            phase=PCWPhase.COMMIT,
            failing_gates=["risk"],
            next_steps=["Fix"],
        )
        assert eligible is True
        assert requires == ["risk_lead"]

    def test_normal_drift_no_changes(self):
        """NORMAL drift leaves rationale unchanged, no drift step appended."""
        drift = DriftResult(
            status=DriftStatus.NORMAL,
            kl_divergence=0.05,
            action=DriftAction.CONTINUE,
            baseline_hash="abc",
            window_size=100,
        )
        _, _, rationale, returned_steps = _apply_drift_overrides(
            drift_result=drift,
            status=PCWStatus.PROCEED,
            override_eligible=True,
            override_requires=[],
            rationale="All gates passed",
            phase=PCWPhase.COMMIT,
            failing_gates=[],
            next_steps=["Proceed to execution"],
        )
        assert "drift" not in rationale.lower()
        # NORMAL drift should not append a drift-related step
        assert not any("drift" in s.lower() for s in returned_steps)


class TestDriftEndToEnd:
    """End-to-end: DriftMonitor.evaluate → _evaluate_drift_policy → decision."""

    def test_critical_drift_halts_and_disables_override(self):
        """Full flow: critical KL → HALT status + override disabled."""
        drift = DriftResult(
            status=DriftStatus.CRITICAL,
            kl_divergence=2.5,
            action=DriftAction.HALT_AND_RECALIBRATE,
            baseline_hash="abc",
            window_size=100,
        )
        eligible, requires, rationale, steps = _apply_drift_overrides(
            drift_result=drift,
            status=PCWStatus.HALT,
            override_eligible=True,
            override_requires=["risk_lead"],
            rationale="test",
            phase=PCWPhase.COMMIT,
            failing_gates=[],
            next_steps=["should_be_replaced"],
        )
        assert eligible is False
        assert requires == []
        assert "critical" in rationale.lower()
        assert any("recalibrate" in s.lower() for s in steps)

    def test_drift_monitor_evaluate_produces_valid_result(self):
        """DriftMonitor.evaluate returns a DriftResult with expected fields."""
        monitor = DriftMonitor(tau_warning=0.3, tau_critical=0.5)
        baseline = [0.1, 0.2, 0.3, 0.4, 0.5] * 20
        monitor.set_baseline(baseline)

        # Similar data → NORMAL
        result = monitor.evaluate([0.1, 0.2, 0.3, 0.4, 0.5] * 10)
        assert result.status == DriftStatus.NORMAL
        assert result.action == DriftAction.CONTINUE
        assert result.kl_divergence >= 0

        # Very different data → CRITICAL
        result = monitor.evaluate([5.0, 6.0, 7.0, 8.0, 9.0] * 10)
        assert result.status == DriftStatus.CRITICAL
        assert result.action == DriftAction.HALT_AND_RECALIBRATE
