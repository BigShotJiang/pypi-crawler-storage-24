"""Tests for AEGIS Customer API (Phase 2c).

Tests cover:
- Profile retrieval and update
- Usage retrieval with quota context
- Key creation, listing, revocation
- Upgrade request submission
- Authentication enforcement
- Error handling
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

from aegis_governance.customer import Customer


def _make_event(
    method: str = "GET",
    path: str = "/customer/profile",
    body: dict[str, Any] | None = None,
    customer_id: str = "cust_test1",
) -> dict[str, Any]:
    """Build a mock API Gateway event with authorizer context."""
    event: dict[str, Any] = {
        "httpMethod": method,
        "path": path,
        "requestContext": {
            "authorizer": {"customer_id": customer_id},
        },
    }
    if body is not None:
        event["body"] = json.dumps(body)
    return event


# ---------------------------------------------------------------------------
# Authentication tests
# ---------------------------------------------------------------------------


class TestCustomerApiAuth:
    """Test authentication enforcement."""

    def test_no_customer_id_returns_401(self) -> None:
        from aegis_governance.customer_api import handler

        event = _make_event(customer_id="")
        result = handler(event, None)
        assert result["statusCode"] == 401

    def test_missing_authorizer_returns_401(self) -> None:
        from aegis_governance.customer_api import handler

        event = {"httpMethod": "GET", "path": "/customer/profile", "requestContext": {}}
        result = handler(event, None)
        assert result["statusCode"] == 401


# ---------------------------------------------------------------------------
# Profile tests
# ---------------------------------------------------------------------------


class TestGetProfile:
    """Test GET /customer/profile."""

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_get_profile_success(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer_api import handler

        customer = Customer(
            customer_id="cust_test1",
            name="Test Corp",
            email="test@corp.com",
            tier="professional",
        )
        mock_mgr.return_value.get_customer.return_value = customer
        mock_mgr.return_value.get_subscription.return_value = None

        result = handler(_make_event(), None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["customer"]["name"] == "Test Corp"
        assert body["tier_details"]["name"] == "professional"

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_get_profile_not_found(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer_api import handler

        mock_mgr.return_value.get_customer.return_value = None

        result = handler(_make_event(), None)
        assert result["statusCode"] == 404


class TestUpdateProfile:
    """Test PATCH /customer/profile."""

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_update_name(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer_api import handler

        updated = Customer(
            customer_id="cust_test1",
            name="New Name",
            email="t@t.com",
        )
        mock_mgr.return_value.update_customer.return_value = updated

        result = handler(
            _make_event("PATCH", "/customer/profile", {"name": "New Name"}),
            None,
        )
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["customer"]["name"] == "New Name"

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_update_disallowed_field_rejected(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer_api import handler

        result = handler(
            _make_event("PATCH", "/customer/profile", {"tier": "enterprise"}),
            None,
        )
        assert result["statusCode"] == 400
        body = json.loads(result["body"])
        assert "No valid fields" in body["error"]

    def test_update_invalid_body(self) -> None:
        from aegis_governance.customer_api import handler

        event = _make_event("PATCH", "/customer/profile")
        event["body"] = "not json {"
        result = handler(event, None)
        assert result["statusCode"] == 400


# ---------------------------------------------------------------------------
# Usage tests
# ---------------------------------------------------------------------------


class TestGetUsage:
    """Test GET /customer/usage."""

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_get_current_usage(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer import UsageSummary
        from aegis_governance.customer_api import handler

        summary = UsageSummary(
            customer_id="cust_test1",
            month="2026-03",
            total_evaluations=500,
            total_calls=600,
        )
        customer = Customer(
            customer_id="cust_test1",
            name="Test",
            email="t@t.com",
            tier="professional",
        )
        mock_mgr.return_value.get_usage.return_value = summary
        mock_mgr.return_value.get_customer.return_value = customer

        result = handler(_make_event("GET", "/customer/usage"), None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["total_evaluations"] == 500
        assert body["quota"] == 10_000
        assert body["quota_remaining"] == 9500

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_get_historical_usage(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer import UsageSummary
        from aegis_governance.customer_api import handler

        summary = UsageSummary(
            customer_id="cust_test1",
            month="2026-02",
            total_evaluations=0,
        )
        customer = Customer(
            customer_id="cust_test1",
            name="Test",
            email="t@t.com",
        )
        mock_mgr.return_value.get_usage.return_value = summary
        mock_mgr.return_value.get_customer.return_value = customer

        result = handler(
            _make_event("GET", "/customer/usage/2026-02"),
            None,
        )
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["month"] == "2026-02"


# ---------------------------------------------------------------------------
# Key management tests
# ---------------------------------------------------------------------------


class TestKeyManagement:
    """Test key CRUD endpoints."""

    @patch("aegis_governance.customer_api._get_unkey_client")
    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_create_key(self, mock_mgr: MagicMock, mock_unkey: MagicMock) -> None:
        from aegis_governance.customer_api import handler
        from aegis_governance.unkey import KeyInfo

        customer = Customer(
            customer_id="cust_test1",
            name="Test",
            email="t@t.com",
            tier="professional",
        )
        mock_mgr.return_value.get_customer.return_value = customer

        mock_unkey_client = MagicMock()
        mock_unkey_client.list_keys.return_value = []
        mock_unkey_client.create_key.return_value = KeyInfo(
            key_id="key_new1",
            api_id="api_test",
            name="my-key",
            owner_id="cust_test1",
        )
        mock_unkey.return_value = mock_unkey_client

        result = handler(
            _make_event("POST", "/customer/keys", {"name": "my-key"}),
            None,
        )
        assert result["statusCode"] == 201
        body = json.loads(result["body"])
        assert body["key_id"] == "key_new1"

    @patch("aegis_governance.customer_api._get_unkey_client")
    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_key_limit_enforced(
        self, mock_mgr: MagicMock, mock_unkey: MagicMock
    ) -> None:
        from aegis_governance.customer_api import handler
        from aegis_governance.unkey import KeyInfo

        customer = Customer(
            customer_id="cust_test1",
            name="Test",
            email="t@t.com",
            tier="community",
        )
        mock_mgr.return_value.get_customer.return_value = customer

        mock_unkey_client = MagicMock()
        # Community tier allows 1 key — already have 1
        mock_unkey_client.list_keys.return_value = [
            KeyInfo(key_id="existing", api_id="test")
        ]
        mock_unkey.return_value = mock_unkey_client

        result = handler(
            _make_event("POST", "/customer/keys", {"name": "second-key"}),
            None,
        )
        assert result["statusCode"] == 429
        body = json.loads(result["body"])
        assert "Key limit" in body["error"]

    @patch("aegis_governance.customer_api._get_unkey_client")
    def test_list_keys(self, mock_unkey: MagicMock) -> None:
        from aegis_governance.customer_api import handler
        from aegis_governance.unkey import KeyInfo

        mock_unkey_client = MagicMock()
        mock_unkey_client.list_keys.return_value = [
            KeyInfo(key_id="k1", api_id="test", name="prod-key"),
            KeyInfo(key_id="k2", api_id="test", name="dev-key"),
        ]
        mock_unkey.return_value = mock_unkey_client

        result = handler(_make_event("GET", "/customer/keys"), None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["count"] == 2

    @patch("aegis_governance.customer_api._get_unkey_client")
    def test_revoke_key_success(self, mock_unkey: MagicMock) -> None:
        from aegis_governance.customer_api import handler
        from aegis_governance.unkey import KeyInfo

        mock_unkey_client = MagicMock()
        mock_unkey_client.list_keys.return_value = [
            KeyInfo(key_id="key_to_revoke", api_id="test", owner_id="cust_test1"),
        ]
        mock_unkey_client.revoke_key.return_value = True
        mock_unkey.return_value = mock_unkey_client

        result = handler(
            _make_event("DELETE", "/customer/keys/key_to_revoke"),
            None,
        )
        assert result["statusCode"] == 200

    @patch("aegis_governance.customer_api._get_unkey_client")
    def test_revoke_key_not_owned(self, mock_unkey: MagicMock) -> None:
        from aegis_governance.customer_api import handler

        mock_unkey_client = MagicMock()
        mock_unkey_client.list_keys.return_value = []  # No keys owned
        mock_unkey.return_value = mock_unkey_client

        result = handler(
            _make_event("DELETE", "/customer/keys/other_key"),
            None,
        )
        assert result["statusCode"] == 404

    @patch("aegis_governance.customer_api._get_unkey_client")
    def test_no_unkey_returns_503(self, mock_unkey: MagicMock) -> None:
        from aegis_governance.customer_api import handler

        mock_unkey.return_value = None

        result = handler(
            _make_event("POST", "/customer/keys", {"name": "test"}),
            None,
        )
        assert result["statusCode"] == 503


# ---------------------------------------------------------------------------
# Upgrade request tests
# ---------------------------------------------------------------------------


class TestUpgradeRequest:
    """Test POST /customer/upgrade-request."""

    def test_upgrade_request_success(self) -> None:
        from aegis_governance.customer_api import handler

        result = handler(
            _make_event(
                "POST",
                "/customer/upgrade-request",
                {"tier": "enterprise", "reason": "Growing team"},
            ),
            None,
        )
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["status"] == "pending_review"
        assert body["requested_tier"] == "enterprise"

    def test_upgrade_request_missing_tier(self) -> None:
        from aegis_governance.customer_api import handler

        result = handler(
            _make_event("POST", "/customer/upgrade-request", {"reason": "Need more"}),
            None,
        )
        assert result["statusCode"] == 400

    def test_upgrade_request_invalid_tier(self) -> None:
        from aegis_governance.customer_api import handler

        result = handler(
            _make_event("POST", "/customer/upgrade-request", {"tier": "platinum"}),
            None,
        )
        assert result["statusCode"] == 400


# ---------------------------------------------------------------------------
# Routing tests
# ---------------------------------------------------------------------------


class TestRouting:
    """Test route matching and 404 handling."""

    def test_unknown_path_returns_404(self) -> None:
        from aegis_governance.customer_api import handler

        result = handler(_make_event("GET", "/customer/unknown"), None)
        assert result["statusCode"] == 404

    def test_wrong_method_returns_404(self) -> None:
        from aegis_governance.customer_api import handler

        result = handler(_make_event("DELETE", "/customer/profile"), None)
        assert result["statusCode"] == 404

    def test_invalid_month_format_returns_400(self) -> None:
        from aegis_governance.customer_api import handler

        result = handler(_make_event("GET", "/customer/usage/bad-month"), None)
        assert result["statusCode"] == 400
        body = json.loads(result["body"])
        assert "YYYY-MM" in body["error"]

    def test_month_traversal_attempt_returns_400(self) -> None:
        from aegis_governance.customer_api import handler

        result = handler(_make_event("GET", "/customer/usage/../../secrets"), None)
        assert result["statusCode"] == 400

    def test_empty_key_id_returns_400(self) -> None:
        from aegis_governance.customer_api import handler

        # Trailing slash results in empty key_id
        result = handler(_make_event("DELETE", "/customer/keys/"), None)
        assert result["statusCode"] == 400


# ---------------------------------------------------------------------------
# Provision tests
# ---------------------------------------------------------------------------


def _make_provision_event(
    body: dict[str, Any] | None = None,
    service_key: str = "test-service-key",
) -> dict[str, Any]:
    """Build a mock provisioning event (no authorizer context)."""
    event: dict[str, Any] = {
        "httpMethod": "POST",
        "path": "/customer/provision",
        "headers": {"X-Service-Key": service_key},
        "requestContext": {},
    }
    if body is not None:
        event["body"] = json.dumps(body)
    return event


class TestProvision:
    """Test POST /customer/provision."""

    @patch(
        "aegis_governance.customer_api._get_service_key",
        return_value="test-service-key",
    )
    @patch("aegis_governance.customer_api._get_unkey_client")
    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_provision_new_customer(
        self,
        mock_mgr: MagicMock,
        mock_unkey: MagicMock,
        mock_svc_key: MagicMock,
    ) -> None:
        from aegis_governance.customer_api import handler
        from aegis_governance.unkey import KeyInfo

        # No existing customer
        mock_mgr.return_value.get_customer_by_email.return_value = None

        new_customer = Customer(
            customer_id="cust_new1",
            name="New User",
            email="new@example.com",
        )
        mock_mgr.return_value.create_customer.return_value = new_customer
        mock_mgr.return_value.update_customer.return_value = new_customer

        mock_unkey_client = MagicMock()
        mock_unkey_client.create_key.return_value = KeyInfo(
            key_id="key_prov1",
            api_id="api_test",
            name="auto-clerk_user1",
            owner_id="cust_new1",
            key="uk_live_new_key_value",
        )
        mock_unkey.return_value = mock_unkey_client

        result = handler(
            _make_provision_event(
                {
                    "clerk_user_id": "clerk_user1",
                    "email": "new@example.com",
                    "name": "New User",
                }
            ),
            None,
        )
        assert result["statusCode"] == 201
        body = json.loads(result["body"])
        assert body["customer_id"] == "cust_new1"
        assert body["api_key"] == "uk_live_new_key_value"
        assert body["api_key_id"] == "key_prov1"

    @patch(
        "aegis_governance.customer_api._get_service_key",
        return_value="test-service-key",
    )
    @patch("aegis_governance.customer_api._get_unkey_client")
    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_provision_existing_customer(
        self,
        mock_mgr: MagicMock,
        mock_unkey: MagicMock,
        mock_svc_key: MagicMock,
    ) -> None:
        from aegis_governance.customer_api import handler
        from aegis_governance.unkey import KeyInfo

        existing = Customer(
            customer_id="cust_exist1",
            name="Existing User",
            email="exist@example.com",
            tier="professional",
        )
        mock_mgr.return_value.get_customer_by_email.return_value = existing
        mock_mgr.return_value.update_customer.return_value = existing

        mock_unkey_client = MagicMock()
        mock_unkey_client.create_key.return_value = KeyInfo(
            key_id="key_prov2",
            api_id="api_test",
            name="auto-clerk_user2",
            owner_id="cust_exist1",
            key="uk_live_existing_key",
        )
        mock_unkey.return_value = mock_unkey_client

        result = handler(
            _make_provision_event(
                {
                    "clerk_user_id": "clerk_user2",
                    "email": "exist@example.com",
                    "name": "Existing User",
                }
            ),
            None,
        )
        assert result["statusCode"] == 201
        body = json.loads(result["body"])
        assert body["customer_id"] == "cust_exist1"
        # Should NOT create a new customer
        mock_mgr.return_value.create_customer.assert_not_called()

    def test_provision_invalid_service_key(self) -> None:
        from aegis_governance.customer_api import handler

        with patch(
            "aegis_governance.customer_api._get_service_key",
            return_value="correct-key",
        ):
            result = handler(
                _make_provision_event(
                    {"clerk_user_id": "u1", "email": "e@x.com", "name": "N"},
                    service_key="wrong-key",
                ),
                None,
            )
            assert result["statusCode"] == 401

    def test_provision_missing_fields(self) -> None:
        from aegis_governance.customer_api import handler

        with patch(
            "aegis_governance.customer_api._get_service_key",
            return_value="test-service-key",
        ):
            # Missing email
            result = handler(
                _make_provision_event({"clerk_user_id": "u1", "name": "N"}),
                None,
            )
            assert result["statusCode"] == 400
            body = json.loads(result["body"])
            assert "email" in body["error"]

    @patch(
        "aegis_governance.customer_api._get_service_key",
        return_value="test-service-key",
    )
    @patch("aegis_governance.customer_api._get_unkey_client")
    def test_provision_unkey_unavailable(
        self, mock_unkey: MagicMock, mock_svc_key: MagicMock
    ) -> None:
        from aegis_governance.customer_api import handler

        mock_unkey.return_value = None

        result = handler(
            _make_provision_event(
                {
                    "clerk_user_id": "u1",
                    "email": "e@x.com",
                    "name": "N",
                }
            ),
            None,
        )
        assert result["statusCode"] == 503


# ---------------------------------------------------------------------------
# Profile with subscription test
# ---------------------------------------------------------------------------


class TestProfileWithSubscription:
    """Test GET /customer/profile includes subscription info."""

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_profile_includes_subscription(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer import Subscription
        from aegis_governance.customer_api import handler

        customer = Customer(
            customer_id="cust_test1",
            name="Test Corp",
            email="test@corp.com",
            tier="professional",
        )
        subscription = Subscription(
            customer_id="cust_test1",
            stripe_subscription_id="sub_123",
            tier="professional",
            status="active",
            current_period_end="2026-04-11T00:00:00Z",
        )
        mock_mgr.return_value.get_customer.return_value = customer
        mock_mgr.return_value.get_subscription.return_value = subscription

        result = handler(_make_event(), None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert "subscription" in body
        assert body["subscription"]["status"] == "active"
        assert body["subscription"]["tier"] == "professional"

    @patch("aegis_governance.customer_api._get_customer_manager")
    def test_profile_without_subscription(self, mock_mgr: MagicMock) -> None:
        from aegis_governance.customer_api import handler

        customer = Customer(
            customer_id="cust_test1",
            name="Test Corp",
            email="test@corp.com",
        )
        mock_mgr.return_value.get_customer.return_value = customer
        mock_mgr.return_value.get_subscription.return_value = None

        result = handler(_make_event(), None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert "subscription" not in body
