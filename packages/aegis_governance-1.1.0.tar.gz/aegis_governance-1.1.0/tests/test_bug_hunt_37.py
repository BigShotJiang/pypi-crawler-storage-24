"""Regression tests for Bug Hunt #37.

BH37-M1: BayesianPosterior.compute_posterior/compute_full NaN/Inf validation
BH37-M2: emergency_halt() audit trail completeness for terminal overrides
BH37-M3: Calibrator _validate_gate_param novelty_N0 range constraint
BH37-L1: PipelineConfig accepts float for integer sizing fields (Codex)
BH37-L2: ThreePointEstimate accepts bool values
BH37-L3: DriftMonitor window_days missing integer type check
"""

import math
from datetime import datetime, timedelta, timezone

import pytest

# ---------------------------------------------------------------------------
# BH37-M1: BayesianPosterior NaN/Inf validation for observed_delta and
#           trigger_threshold
# ---------------------------------------------------------------------------


class TestBH37BayesianNaNInfValidation:
    """compute_posterior and compute_full must reject NaN/Inf inputs."""

    def test_compute_posterior_nan_observed_delta(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        with pytest.raises(ValueError, match="observed_delta must be finite"):
            bp.compute_posterior(float("nan"), 2.0)

    def test_compute_posterior_inf_observed_delta(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        with pytest.raises(ValueError, match="observed_delta must be finite"):
            bp.compute_posterior(float("inf"), 2.0)

    def test_compute_posterior_neg_inf_observed_delta(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        with pytest.raises(ValueError, match="observed_delta must be finite"):
            bp.compute_posterior(float("-inf"), 2.0)

    def test_compute_posterior_nan_trigger_threshold(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        with pytest.raises(ValueError, match="trigger_threshold must be finite"):
            bp.compute_posterior(1.0, float("nan"))

    def test_compute_posterior_inf_trigger_threshold(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        with pytest.raises(ValueError, match="trigger_threshold must be finite"):
            bp.compute_posterior(1.0, float("inf"))

    def test_compute_full_nan_observed_delta(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        with pytest.raises(ValueError, match="observed_delta must be finite"):
            bp.compute_full(float("nan"), 2.0)

    def test_compute_full_inf_trigger_threshold(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        with pytest.raises(ValueError, match="trigger_threshold must be finite"):
            bp.compute_full(1.0, float("inf"))

    def test_compute_posterior_valid_inputs_still_work(self):
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior()
        result = bp.compute_posterior(1.5, 2.0)
        assert math.isfinite(result)
        assert 0.0 <= result <= 1.0


# ---------------------------------------------------------------------------
# BH37-M2: emergency_halt() audit trail completeness
# ---------------------------------------------------------------------------


class TestBH37EmergencyHaltAuditTrail:
    """emergency_halt must report already-terminal overrides in audit trail."""

    def test_emergency_halt_tracks_already_terminal_overrides(self):
        from actors.governance import Governance
        from workflows.override import OverrideWorkflow

        actor = Governance(actor_id="gov-1", name="Gov Actor")

        # Create an override and manually expire it
        wf = OverrideWorkflow(
            proposal_id="test-override",
            requested_by="lead-1",
            failed_gates=["risk"],
            justification="Testing halt",
        )
        # Force expiration by setting expires_at in the past
        wf.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        with actor._lock:
            actor.active_overrides["test-override"] = wf

        result = actor.emergency_halt("Critical issue")

        assert result.success is True
        data = result.result_data
        # The expired override should appear in already_terminal_overrides
        assert "already_terminal_overrides" in data
        all_ids = data["cancelled_overrides"] + data["already_terminal_overrides"]
        assert "test-override" in all_ids

    def test_emergency_halt_cancelled_overrides_still_tracked(self):
        from actors.governance import Governance
        from workflows.override import OverrideWorkflow

        actor = Governance(actor_id="gov-1", name="Gov Actor")

        # Create an override that is still PENDING (not expired)
        wf = OverrideWorkflow(
            proposal_id="active-override",
            requested_by="lead-1",
            failed_gates=["risk"],
            justification="Testing halt",
        )

        with actor._lock:
            actor.active_overrides["active-override"] = wf

        result = actor.emergency_halt("Critical issue")

        assert result.success is True
        assert "active-override" in result.result_data["cancelled_overrides"]


# ---------------------------------------------------------------------------
# BH37-M3: Calibrator _validate_gate_param novelty_N0 range constraint
# ---------------------------------------------------------------------------


class TestBH37CalibratorNoveltyN0Validation:
    """novelty_N0 must be non-negative to prevent gate bypass."""

    def test_novelty_N0_negative_rejected(self):
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="must be non-negative"):
            _validate_gate_param("novelty_N0", -1.0)

    def test_novelty_N0_zero_allowed(self):
        from actors.calibrator import _validate_gate_param

        # Zero is a valid inflection point (non-negative)
        _validate_gate_param("novelty_N0", 0.0)  # should not raise

    def test_novelty_N0_positive_allowed(self):
        from actors.calibrator import _validate_gate_param

        _validate_gate_param("novelty_N0", 0.5)  # should not raise

    def test_novelty_N0_nan_rejected(self):
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="must be a finite number"):
            _validate_gate_param("novelty_N0", float("nan"))

    def test_novelty_N0_inf_rejected(self):
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="must be a finite number"):
            _validate_gate_param("novelty_N0", float("inf"))


# ---------------------------------------------------------------------------
# BH37-L2: ThreePointEstimate bool guard
# ---------------------------------------------------------------------------


class TestBH37ThreePointEstimateBoolGuard:
    """ThreePointEstimate must reject bool values for best/likely/worst."""

    def test_best_bool_rejected(self):
        from engine.utility import ThreePointEstimate

        with pytest.raises(TypeError, match="PERT best must be numeric, got bool"):
            ThreePointEstimate(best=False, likely=0.5, worst=1.0)

    def test_likely_bool_rejected(self):
        from engine.utility import ThreePointEstimate

        with pytest.raises(TypeError, match="PERT likely must be numeric, got bool"):
            ThreePointEstimate(best=0.0, likely=True, worst=1.0)

    def test_worst_bool_rejected(self):
        from engine.utility import ThreePointEstimate

        with pytest.raises(TypeError, match="PERT worst must be numeric, got bool"):
            ThreePointEstimate(best=0.0, likely=0.5, worst=True)

    def test_valid_floats_still_work(self):
        from engine.utility import ThreePointEstimate

        est = ThreePointEstimate(best=0.0, likely=0.5, worst=1.0)
        assert math.isfinite(est.expected)


# ---------------------------------------------------------------------------
# BH37-L3: DriftMonitor window_days integer type check
# ---------------------------------------------------------------------------


class TestBH37DriftMonitorWindowDaysTypeCheck:
    """DriftMonitor.window_days must reject non-integer types."""

    def test_float_window_days_rejected(self):
        from engine.drift import DriftMonitor

        with pytest.raises(TypeError, match="window_days must be an integer"):
            DriftMonitor(window_days=3.5)

    def test_string_window_days_rejected(self):
        from engine.drift import DriftMonitor

        with pytest.raises(TypeError, match="window_days must be an integer"):
            DriftMonitor(window_days="30")

    def test_bool_window_days_rejected(self):
        from engine.drift import DriftMonitor

        with pytest.raises(TypeError, match="window_days must be an integer"):
            DriftMonitor(window_days=True)

    def test_valid_int_window_days_accepted(self):
        from engine.drift import DriftMonitor

        dm = DriftMonitor(window_days=30)
        assert dm.window_days == 30
