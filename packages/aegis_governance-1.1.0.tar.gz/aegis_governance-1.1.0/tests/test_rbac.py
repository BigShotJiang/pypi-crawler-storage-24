"""Tests for RBAC Enforcement Layer.

Validates:
1. Permission and RBACConstraint enums match schema/rbac-definitions.yaml
2. YAMLRoleResolver stores and resolves actor-role assignments
3. RBACEnforcer resolves permissions with inheritance
4. Constraint checking dispatches to correct logic
5. Override authorization enforces four-eyes and role verification
6. YAML loading integrates with the actual schema file
7. Edge cases: empty definitions, unknown permissions, circular inheritance
"""

from pathlib import Path

import pytest

from rbac import (
    Permission,
    RBACConstraint,
    RBACEnforcer,
    YAMLRoleResolver,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

# Minimal RBAC definitions dict matching schema/rbac-definitions.yaml structure
_MINIMAL_RBAC: dict = {
    "roles": {
        "viewer": {
            "inherits": [],
            "permissions": ["read_proposals", "read_telemetry"],
        },
        "analyst": {
            "inherits": ["viewer"],
            "permissions": ["run_queries", "export_reports", "view_statistics"],
        },
        "developer": {
            "inherits": ["analyst"],
            "permissions": [
                "submit_proposals",
                "view_own_decisions",
                "cancel_own_proposals",
            ],
        },
        "reviewer": {
            "inherits": ["developer"],
            "permissions": [
                "approve_proposals",
                "reject_proposals",
                "request_override",
                "add_review_comments",
            ],
        },
        "risk_lead": {
            "inherits": ["reviewer"],
            "permissions": [
                "first_key_override",
                "propose_threshold_changes",
                "view_risk_analytics",
                "trigger_recalibration",
            ],
            "constraints": [
                "cannot_approve_own_proposals",
                "requires_second_key_for_override",
            ],
        },
        "security_lead": {
            "inherits": ["reviewer"],
            "permissions": [
                "second_key_override",
                "view_security_audit",
                "manage_security_gates",
            ],
            "constraints": [
                "cannot_bypass_security_invariants",
                "requires_first_key_for_override",
            ],
        },
        "calibrator": {
            "inherits": ["analyst"],
            "permissions": [
                "propose_recalibration",
                "view_calibration_history",
                "run_statistical_analysis",
            ],
            "constraints": ["requires_approval_for_deploy"],
        },
        "admin": {
            "inherits": ["risk_lead", "security_lead", "calibrator"],
            "permissions": [
                "manage_roles",
                "audit_all",
                "system_config",
                "manage_integrations",
                "emergency_shutdown",
            ],
            "constraints": [
                "no_unilateral_override",
                "four_eyes_principle",
                "all_actions_logged",
            ],
        },
    },
    "constraints": {
        "cannot_approve_own_proposals": {
            "enforcement": "hard_block",
        },
        "requires_second_key_for_override": {
            "enforcement": "hard_block",
        },
        "cannot_bypass_security_invariants": {
            "enforcement": "hard_block",
        },
        "no_unilateral_override": {
            "enforcement": "hard_block",
        },
        "four_eyes_principle": {
            "enforcement": "hard_block",
        },
        "all_actions_logged": {
            "enforcement": "hard_block",
        },
    },
}


def _make_enforcer(
    rbac_defs: dict = _MINIMAL_RBAC,
) -> tuple[RBACEnforcer, YAMLRoleResolver]:
    """Create an enforcer with a YAMLRoleResolver for testing."""
    resolver = YAMLRoleResolver()
    enforcer = RBACEnforcer(role_resolver=resolver, rbac_definitions=rbac_defs)
    return enforcer, resolver


# ---------------------------------------------------------------------------
# TestPermission
# ---------------------------------------------------------------------------


class TestPermission:
    """Permission enum matches schema/rbac-definitions.yaml entries."""

    def test_read_proposals_value(self):
        assert Permission.READ_PROPOSALS.value == "read_proposals"

    def test_first_key_override_value(self):
        assert Permission.FIRST_KEY_OVERRIDE.value == "first_key_override"

    def test_emergency_shutdown_value(self):
        assert Permission.EMERGENCY_SHUTDOWN.value == "emergency_shutdown"

    def test_all_permissions_are_strings(self):
        for perm in Permission:
            assert isinstance(perm.value, str)

    def test_permission_membership(self):
        assert "read_proposals" in [p.value for p in Permission]
        assert "submit_proposals" in [p.value for p in Permission]
        assert "nonexistent_perm" not in [p.value for p in Permission]

    def test_permission_count(self):
        # 4 viewer + 3 developer + 4 reviewer + 2 override + 3 risk
        # + 2 security + 3 calibrator + 5 admin + 3 analyst = 29
        assert len(Permission) == 29


# ---------------------------------------------------------------------------
# TestRBACConstraint
# ---------------------------------------------------------------------------


class TestRBACConstraint:
    """RBACConstraint enum covers all constraints in the schema."""

    def test_cannot_approve_own_value(self):
        assert (
            RBACConstraint.CANNOT_APPROVE_OWN_PROPOSALS.value
            == "cannot_approve_own_proposals"
        )

    def test_four_eyes_value(self):
        assert RBACConstraint.FOUR_EYES_PRINCIPLE.value == "four_eyes_principle"

    def test_requires_approval_for_deploy_value(self):
        assert (
            RBACConstraint.REQUIRES_APPROVAL_FOR_DEPLOY.value
            == "requires_approval_for_deploy"
        )

    def test_all_constraints_are_strings(self):
        for c in RBACConstraint:
            assert isinstance(c.value, str)

    def test_constraint_count(self):
        # 6 in top-level constraints + 2 role-only constraints = 8
        assert len(RBACConstraint) == 8


# ---------------------------------------------------------------------------
# TestYAMLRoleResolver
# ---------------------------------------------------------------------------


class TestYAMLRoleResolver:
    """YAMLRoleResolver manages in-memory actor-role assignments."""

    def test_unknown_actor_returns_empty(self):
        resolver = YAMLRoleResolver()
        assert resolver.resolve_roles("unknown") == set()

    def test_assign_single_role(self):
        resolver = YAMLRoleResolver()
        resolver.assign_role("alice", "developer")
        assert resolver.resolve_roles("alice") == {"developer"}

    def test_assign_multiple_roles(self):
        resolver = YAMLRoleResolver()
        resolver.assign_role("bob", "risk_lead")
        resolver.assign_role("bob", "security_lead")
        assert resolver.resolve_roles("bob") == {"risk_lead", "security_lead"}

    def test_assign_duplicate_role_is_idempotent(self):
        resolver = YAMLRoleResolver()
        resolver.assign_role("carol", "viewer")
        resolver.assign_role("carol", "viewer")
        assert resolver.resolve_roles("carol") == {"viewer"}

    def test_resolve_returns_copy(self):
        resolver = YAMLRoleResolver()
        resolver.assign_role("dave", "analyst")
        roles = resolver.resolve_roles("dave")
        roles.add("admin")  # mutate the returned set
        assert resolver.resolve_roles("dave") == {"analyst"}

    def test_repr(self):
        resolver = YAMLRoleResolver()
        resolver.assign_role("x", "viewer")
        assert "YAMLRoleResolver" in repr(resolver)

    def test_conforms_to_protocol(self):
        from rbac import RoleResolver

        resolver = YAMLRoleResolver()
        assert isinstance(resolver, RoleResolver)


# ---------------------------------------------------------------------------
# TestRBACEnforcer
# ---------------------------------------------------------------------------


class TestRBACEnforcer:
    """Core enforcement: permission resolution, constraints, overrides."""

    # -- Permission resolution with inheritance --

    def test_viewer_has_read_proposals(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("v", "viewer")
        assert enforcer.has_permission("v", "read_proposals")

    def test_viewer_cannot_submit(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("v", "viewer")
        assert not enforcer.has_permission("v", "submit_proposals")

    def test_developer_inherits_viewer_permissions(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("d", "developer")
        # Direct
        assert enforcer.has_permission("d", "submit_proposals")
        # Inherited from analyst (inherits from viewer)
        assert enforcer.has_permission("d", "read_proposals")
        assert enforcer.has_permission("d", "run_queries")

    def test_risk_lead_inherits_full_chain(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("r", "risk_lead")
        # Direct
        assert enforcer.has_permission("r", "first_key_override")
        # Inherited: reviewer -> developer -> analyst -> viewer
        assert enforcer.has_permission("r", "approve_proposals")
        assert enforcer.has_permission("r", "submit_proposals")
        assert enforcer.has_permission("r", "run_queries")
        assert enforcer.has_permission("r", "read_proposals")

    def test_admin_inherits_from_all_parents(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("a", "admin")
        # Admin-specific
        assert enforcer.has_permission("a", "manage_roles")
        assert enforcer.has_permission("a", "emergency_shutdown")
        # From risk_lead
        assert enforcer.has_permission("a", "first_key_override")
        # From security_lead
        assert enforcer.has_permission("a", "second_key_override")
        # From calibrator
        assert enforcer.has_permission("a", "propose_recalibration")
        # From viewer (deep inheritance)
        assert enforcer.has_permission("a", "read_telemetry")

    def test_unknown_actor_has_no_permissions(self):
        enforcer, _ = _make_enforcer()
        assert not enforcer.has_permission("ghost", "read_proposals")

    def test_unknown_permission_returns_false(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("u", "admin")
        assert not enforcer.has_permission("u", "nonexistent_permission")

    # -- Constraint checking --

    def test_cannot_approve_own_same_actor(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "cannot_approve_own_proposals",
            proposer_id="alice",
            approver_id="alice",
        )
        assert not passed
        assert reason is not None and "Self-approval" in reason

    def test_cannot_approve_own_different_actors(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "cannot_approve_own_proposals",
            proposer_id="alice",
            approver_id="bob",
        )
        assert passed
        assert reason is None

    def test_four_eyes_same_actor(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "four_eyes_principle",
            actor1_id="charlie",
            actor2_id="charlie",
        )
        assert not passed
        assert reason is not None and "Four-eyes" in reason

    def test_four_eyes_different_actors(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "four_eyes_principle",
            actor1_id="charlie",
            actor2_id="diana",
        )
        assert passed
        assert reason is None

    def test_requires_second_key_missing(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "requires_second_key_for_override",
            has_second_key=False,
        )
        assert not passed
        assert reason is not None

    def test_requires_second_key_present(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "requires_second_key_for_override",
            has_second_key=True,
        )
        assert passed

    def test_no_unilateral_override_single_signer(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override",
            signer_count=1,
        )
        assert not passed

    def test_no_unilateral_override_two_signers(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override",
            signer_count=2,
        )
        assert passed

    def test_unknown_constraint_fails(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint("totally_unknown")
        assert not passed
        assert reason is not None and "Unknown" in reason

    # -- Override authorization --

    def test_authorize_override_risk_lead(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("risk_alice", "risk_lead")
        ok, reason = enforcer.authorize_override(
            "risk_alice", "risk_lead", "bob_requester"
        )
        assert ok
        assert reason is None

    def test_authorize_override_security_lead(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("sec_bob", "security_lead")
        ok, reason = enforcer.authorize_override(
            "sec_bob", "security_lead", "alice_requester"
        )
        assert ok
        assert reason is None

    def test_authorize_override_unknown_role(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("eve", "viewer")
        ok, reason = enforcer.authorize_override("eve", "risk_lead", "frank")
        assert not ok
        assert reason is not None and "does not have role" in reason

    def test_authorize_override_four_eyes_violation(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("same", "risk_lead")
        ok, reason = enforcer.authorize_override("same", "risk_lead", "same")
        assert not ok
        assert reason is not None and "Four-eyes" in reason

    def test_authorize_override_no_override_permission(self):
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("dev", "developer")
        ok, reason = enforcer.authorize_override("dev", "developer", "other")
        assert not ok
        assert reason is not None and "override permission" in reason

    # -- repr --

    def test_repr(self):
        enforcer, _ = _make_enforcer()
        r = repr(enforcer)
        assert "RBACEnforcer" in r
        assert "roles=" in r


# ---------------------------------------------------------------------------
# TestRBACEnforcerFromYAML
# ---------------------------------------------------------------------------


class TestRBACEnforcerFromYAML:
    """Integration tests loading from the actual schema YAML file."""

    @pytest.fixture()
    def yaml_enforcer(self):
        yaml = pytest.importorskip("yaml", reason="pyyaml not installed")  # noqa: F841
        schema_path = (
            Path(__file__).resolve().parent.parent / "schema" / "rbac-definitions.yaml"
        )
        if not schema_path.exists():
            pytest.skip("schema/rbac-definitions.yaml not found")
        resolver = YAMLRoleResolver()
        enforcer = RBACEnforcer.from_yaml(str(schema_path), role_resolver=resolver)
        return enforcer, resolver

    def test_loads_roles(self, yaml_enforcer):
        enforcer, _ = yaml_enforcer
        assert len(enforcer._roles) >= 7  # viewer..admin + calibrator

    def test_admin_inherits_all_permissions(self, yaml_enforcer):
        enforcer, resolver = yaml_enforcer
        resolver.assign_role("super", "admin")
        # Admin should have permissions from all branches
        assert enforcer.has_permission("super", "manage_roles")
        assert enforcer.has_permission("super", "first_key_override")
        assert enforcer.has_permission("super", "second_key_override")
        assert enforcer.has_permission("super", "read_proposals")
        assert enforcer.has_permission("super", "propose_recalibration")

    def test_constraint_count_matches_yaml(self, yaml_enforcer):
        enforcer, _ = yaml_enforcer
        # schema/rbac-definitions.yaml defines 8 top-level constraints
        assert len(enforcer._constraints) == 8

    def test_viewer_permissions_from_yaml(self, yaml_enforcer):
        enforcer, resolver = yaml_enforcer
        resolver.assign_role("v", "viewer")
        assert enforcer.has_permission("v", "read_proposals")
        assert enforcer.has_permission("v", "read_telemetry")
        assert not enforcer.has_permission("v", "submit_proposals")


# ---------------------------------------------------------------------------
# TestRBACEnforcerEdgeCases
# ---------------------------------------------------------------------------


class TestRBACEnforcerEdgeCases:
    """Edge cases and defensive behavior."""

    def test_empty_role_definitions(self):
        enforcer, resolver = _make_enforcer(rbac_defs={"roles": {}, "constraints": {}})
        resolver.assign_role("x", "viewer")
        assert not enforcer.has_permission("x", "read_proposals")

    def test_role_with_no_inherits(self):
        defs = {
            "roles": {
                "standalone": {
                    "permissions": ["read_proposals"],
                },
            },
            "constraints": {},
        }
        enforcer, resolver = _make_enforcer(rbac_defs=defs)
        resolver.assign_role("s", "standalone")
        assert enforcer.has_permission("s", "read_proposals")
        assert not enforcer.has_permission("s", "submit_proposals")

    def test_circular_inheritance_protection(self):
        defs = {
            "roles": {
                "a": {
                    "inherits": ["b"],
                    "permissions": ["read_proposals"],
                },
                "b": {
                    "inherits": ["a"],
                    "permissions": ["submit_proposals"],
                },
            },
            "constraints": {},
        }
        enforcer, resolver = _make_enforcer(rbac_defs=defs)
        resolver.assign_role("user", "a")
        # Should not infinite-loop; both permissions should be resolved
        assert enforcer.has_permission("user", "read_proposals")
        assert enforcer.has_permission("user", "submit_proposals")

    def test_get_role_constraints(self):
        enforcer, _ = _make_enforcer()
        constraints = enforcer.get_role_constraints("risk_lead")
        assert "cannot_approve_own_proposals" in constraints
        assert "requires_second_key_for_override" in constraints

    def test_get_role_constraints_unknown_role(self):
        enforcer, _ = _make_enforcer()
        assert enforcer.get_role_constraints("nonexistent") == []

    def test_get_all_constraints(self):
        enforcer, _ = _make_enforcer()
        all_c = enforcer.get_all_constraints()
        assert "four_eyes_principle" in all_c

    def test_from_yaml_missing_file(self):
        yaml = pytest.importorskip("yaml", reason="pyyaml not installed")  # noqa: F841
        with pytest.raises(FileNotFoundError):
            RBACEnforcer.from_yaml("/nonexistent/path/rbac.yaml")

    def test_constraint_all_actions_logged_not_logged(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "all_actions_logged", is_logged=False
        )
        assert not passed

    def test_constraint_all_actions_logged_is_logged(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint("all_actions_logged", is_logged=True)
        assert passed

    def test_constraint_cannot_bypass_security(self):
        enforcer, _ = _make_enforcer()
        passed, _ = enforcer.check_constraint(
            "cannot_bypass_security_invariants", bypassing=True
        )
        assert not passed
        passed, _ = enforcer.check_constraint(
            "cannot_bypass_security_invariants", bypassing=False
        )
        assert passed

    def test_constraint_cannot_bypass_security_missing_context(self):
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint("cannot_bypass_security_invariants")
        assert not passed
        assert "Missing required context" in reason

    def test_constraint_requires_approval_for_deploy(self):
        enforcer, _ = _make_enforcer()
        passed, _ = enforcer.check_constraint(
            "requires_approval_for_deploy", has_approval=False
        )
        assert not passed
        passed, _ = enforcer.check_constraint(
            "requires_approval_for_deploy", has_approval=True
        )
        assert passed

    def test_constraint_requires_first_key(self):
        enforcer, _ = _make_enforcer()
        passed, _ = enforcer.check_constraint(
            "requires_first_key_for_override", has_first_key=False
        )
        assert not passed
        passed, _ = enforcer.check_constraint(
            "requires_first_key_for_override", has_first_key=True
        )
        assert passed

    def test_identity_constraint_fails_closed_missing_both_ids(self):
        """Identity constraints fail when both actor IDs are missing."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint("cannot_approve_own_proposals")
        assert not passed
        assert "Missing required context" in reason

    def test_identity_constraint_fails_closed_missing_one_id(self):
        """Identity constraints fail when one actor ID is missing."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "cannot_approve_own_proposals", proposer_id="alice"
        )
        assert not passed
        assert "Missing required context" in reason

    def test_four_eyes_fails_closed_missing_ids(self):
        """Four-eyes constraint fails when actor IDs are missing."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint("four_eyes_principle")
        assert not passed
        assert "Missing required context" in reason

    def test_permission_cache_is_used(self):
        """Second call uses cache, produces same result."""
        enforcer, resolver = _make_enforcer()
        resolver.assign_role("c", "admin")
        result1 = enforcer.has_permission("c", "manage_roles")
        result2 = enforcer.has_permission("c", "manage_roles")
        assert result1 == result2 is True
        # Verify cache was populated
        assert "admin" in enforcer._permission_cache


# ---------------------------------------------------------------------------
# Regression: BH24-M2 — NO_UNILATERAL_OVERRIDE null signer_count
# ---------------------------------------------------------------------------


class TestBH24NoUnilateralOverrideNullSignerCount:
    """BH24-M2: signer_count=None from JSON null must fail-closed, not crash."""

    def test_signer_count_null_fails_closed(self):
        """ctx.get('signer_count', 0) returns None when key exists with null."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=None
        )
        assert not passed
        assert "Unilateral override prohibited" in reason

    def test_signer_count_bool_true_fails_closed(self):
        """bool is subclass of int — True would pass '< 2' but is not valid."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=True
        )
        assert not passed

    def test_signer_count_bool_false_fails_closed(self):
        """False == 0 in Python — must be rejected as non-numeric."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=False
        )
        assert not passed

    def test_signer_count_string_fails_closed(self):
        """Non-numeric types must fail-closed."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count="2"
        )
        assert not passed

    def test_signer_count_2_passes(self):
        """Valid integer signer_count=2 should pass."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=2
        )
        assert passed

    def test_signer_count_float_2_passes(self):
        """Float 2.0 should pass (valid numeric >= 2)."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=2.0
        )
        assert passed


class TestBH26RBACBoolConstraintNoneFailClosed:
    """BH26-M3: Bool constraint must fail-closed when flag_value is None."""

    def test_bypassing_none_fails_closed(self):
        """bypassing=None must FAIL (not pass) the cannot_bypass_security_invariants check."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "cannot_bypass_security_invariants", bypassing=None
        )
        assert not passed, "bypassing=None should fail-closed, not pass"
        assert "Expected bool" in reason

    def test_has_approval_none_fails_closed(self):
        """has_approval=None must FAIL the requires_approval_for_deploy check."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "requires_approval_for_deploy", has_approval=None
        )
        assert not passed, "has_approval=None should fail-closed"
        assert "Expected bool" in reason

    def test_is_logged_none_fails_closed(self):
        """is_logged=None must FAIL the all_actions_logged check."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint("all_actions_logged", is_logged=None)
        assert not passed
        assert "Expected bool" in reason

    def test_has_second_key_none_fails_closed(self):
        """has_second_key=None must FAIL the requires_second_key_for_override check."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "requires_second_key_for_override", has_second_key=None
        )
        assert not passed
        assert "Expected bool" in reason

    def test_string_value_fails_closed(self):
        """Non-boolean truthy value must fail-closed."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "cannot_bypass_security_invariants", bypassing="false"
        )
        assert not passed
        assert "Expected bool" in reason

    def test_int_value_fails_closed(self):
        """Integer 0 (falsy but not bool) must fail-closed."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "cannot_bypass_security_invariants", bypassing=0
        )
        assert not passed
        assert "Expected bool" in reason

    def test_true_bool_still_works(self):
        """Actual bool True must still pass/fail correctly."""
        enforcer, _ = _make_enforcer()
        # bypassing=True should FAIL (pass_when_true=False)
        passed, _ = enforcer.check_constraint(
            "cannot_bypass_security_invariants", bypassing=True
        )
        assert not passed

    def test_false_bool_still_works(self):
        """Actual bool False must still pass correctly."""
        enforcer, _ = _make_enforcer()
        # bypassing=False should PASS (pass_when_true=False)
        passed, _ = enforcer.check_constraint(
            "cannot_bypass_security_invariants", bypassing=False
        )
        assert passed


# ---------------------------------------------------------------------------
# Regression: BH35-M1 — NO_UNILATERAL_OVERRIDE NaN signer_count bypass
# ---------------------------------------------------------------------------


class TestBH35NoUnilateralOverrideNaNSignerCount:
    """BH35-M1: NaN signer_count must fail-closed due to IEEE 754 comparison."""

    def test_signer_count_nan_fails_closed(self):
        """NaN < 2 is False in IEEE 754, so NaN would bypass the constraint."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=float("nan")
        )
        assert not passed
        assert "Unilateral override prohibited" in reason

    def test_signer_count_inf_fails_closed(self):
        """Inf >= 2 is True, but Inf is not a valid signer count."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=float("inf")
        )
        assert not passed
        assert "Unilateral override prohibited" in reason

    def test_signer_count_negative_inf_fails_closed(self):
        """-Inf < 2 is True but -Inf is not a valid signer count."""
        enforcer, _ = _make_enforcer()
        passed, reason = enforcer.check_constraint(
            "no_unilateral_override", signer_count=float("-inf")
        )
        assert not passed
        assert "Unilateral override prohibited" in reason
