"""
Persistence Layer Tests

Comprehensive test suite for GAP-M3 Workflow Persistence implementation.
Uses SQLite in-memory database for fast, isolated testing.

Test Coverage:
- ORM models (WorkflowInstance, WorkflowTransition, WorkflowCheckpoint)
- Database engine configuration
- WorkflowPersistence repository
- DurableWorkflowEngine
- Workflow serialization (to_dict/from_dict)
- Audit trail integrity verification
"""

from datetime import datetime, timedelta, timezone

import pytest

pytest.importorskip("sqlalchemy")

from workflows.consensus import (
    ConsensusConfig,
    ConsensusWorkflow,
    VoteOutcome,
)
from workflows.override import (
    OverrideRequest,
    OverrideState,
    OverrideWorkflow,
    SignatureRecord,
)
from workflows.persistence import (
    DatabaseConfig,
    DurableWorkflowEngine,
    WorkflowCheckpoint,
    WorkflowInstance,
    WorkflowPersistence,
    WorkflowTransition,
    create_database_engine,
)
from workflows.proposal import (
    EvaluationResult,
    ProposalMetadata,
    ProposalPriority,
    ProposalState,
    ProposalWorkflow,
    StateTransition,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def database_config():
    """SQLite in-memory database configuration."""
    return DatabaseConfig.for_testing()


@pytest.fixture
async def persistence(database_config):
    """Initialized WorkflowPersistence instance."""
    p = WorkflowPersistence(database_config)
    await p.initialize()
    yield p
    await p.close()


@pytest.fixture
async def engine(persistence):
    """DurableWorkflowEngine instance."""
    return DurableWorkflowEngine(persistence)


@pytest.fixture
def sample_metadata():
    """Sample ProposalMetadata for testing."""
    return ProposalMetadata(
        title="Test Proposal",
        description="A test proposal for persistence testing",
        author_id="user-123",
        priority=ProposalPriority.HIGH,
        tags=["test", "persistence"],
        related_proposals=[],
    )


@pytest.fixture
def sample_proposal(sample_metadata):
    """Sample ProposalWorkflow for testing."""
    return ProposalWorkflow(
        proposal_id="prop-test-001",
        metadata=sample_metadata,
    )


@pytest.fixture
def sample_consensus():
    """Sample ConsensusWorkflow for testing."""
    return ConsensusWorkflow(
        proposal_id="cons-test-001",
        eligible_voters={"voter-1", "voter-2", "voter-3"},
        config=ConsensusConfig(
            quorum_percentage=0.51,
            approval_threshold=0.67,
            timeout_hours=24,
            required_roles={"risk_lead"},
            allow_abstain=True,
        ),
    )


@pytest.fixture
def sample_override():
    """Sample OverrideWorkflow for testing."""
    request = OverrideRequest(
        proposal_id="prop-override-001",
        justification="Critical production fix required",
        failed_gates=["risk", "novelty"],
        requested_by="admin-user",
        requested_at=datetime.now(timezone.utc),
    )
    # Create workflow without validator for testing
    workflow = OverrideWorkflow.__new__(OverrideWorkflow)
    workflow.validator = None
    workflow.request = request
    workflow.message_hash = "abc123def456"
    workflow.expires_at = datetime.now(timezone.utc) + timedelta(hours=24)
    workflow.risk_lead_signature = None
    workflow.security_lead_signature = None
    return workflow


# =============================================================================
# Database Configuration Tests
# =============================================================================


class TestDatabaseConfig:
    """Tests for DatabaseConfig class."""

    def test_for_testing_in_memory(self):
        """Test in-memory SQLite configuration."""
        config = DatabaseConfig.for_testing()
        assert config.is_sqlite
        assert config.is_memory
        assert "memory" in config.url

    def test_for_testing_with_path(self, tmp_path):
        """Test file-based SQLite configuration."""
        db_path = tmp_path / "test.db"
        config = DatabaseConfig.for_testing(str(db_path))
        assert config.is_sqlite
        assert not config.is_memory
        assert str(db_path) in config.url

    def test_for_postgresql(self):
        """Test PostgreSQL configuration."""
        config = DatabaseConfig.for_postgresql(
            host="localhost",
            port=5432,
            database="aegis_test",
            user="test_user",
            password="test_pass",
        )
        assert not config.is_sqlite
        assert "postgresql+asyncpg" in config.url
        assert "aegis_test" in config.url

    def test_for_postgresql_url_encodes_special_chars(self):
        """Test PostgreSQL URL-encodes user and password with special chars.

        Bug fix: passwords containing @, :, /, ?, #, or % would produce
        malformed connection URLs, potentially connecting to wrong host.
        """
        config = DatabaseConfig.for_postgresql(
            host="db.example.com",
            port=5432,
            database="aegis",
            user="admin@org",
            password="p@ss:w0rd/test",
        )
        # Special chars must be percent-encoded so URL parses correctly
        assert "admin%40org" in config.url
        assert "p%40ss%3Aw0rd%2Ftest" in config.url
        assert "@db.example.com:5432" in config.url


class TestDatabaseEngine:
    """Tests for database engine creation."""

    def test_create_engine_sqlite_memory(self, database_config):
        """Test SQLite in-memory engine creation."""
        engine = create_database_engine(database_config)
        assert engine is not None
        # StaticPool should be used for in-memory
        assert engine.pool is not None

    def test_create_engine_with_echo(self):
        """Test engine with SQL echo enabled."""
        config = DatabaseConfig.for_testing()
        config.echo = True
        engine = create_database_engine(config)
        assert engine.echo is True


# =============================================================================
# ORM Model Tests
# =============================================================================


class TestWorkflowInstance:
    """Tests for WorkflowInstance ORM model."""

    def test_create_instance(self):
        """Test creating a WorkflowInstance."""
        instance = WorkflowInstance(
            workflow_type="proposal",
            workflow_id="prop-123",
            current_state="draft",
            state_data={"test": "data"},
        )
        assert instance.workflow_type == "proposal"
        assert instance.workflow_id == "prop-123"
        assert instance.current_state == "draft"
        assert instance.state_data == {"test": "data"}

    def test_instance_repr(self):
        """Test string representation."""
        instance = WorkflowInstance(
            workflow_type="proposal",
            workflow_id="prop-123",
            current_state="draft",
        )
        repr_str = repr(instance)
        assert "WorkflowInstance" in repr_str
        assert "proposal" in repr_str


class TestWorkflowTransition:
    """Tests for WorkflowTransition ORM model."""

    def test_compute_hash(self):
        """Test transition hash computation."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0)
        hash1 = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp,
        )
        assert len(hash1) == 64  # SHA-256 hex

        # Same inputs should produce same hash
        hash2 = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp,
        )
        assert hash1 == hash2

    def test_hash_chain(self):
        """Test hash chaining for audit trail."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0)
        hash1 = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp,
        )

        hash2 = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp + timedelta(hours=1),
            previous_hash=hash1,
        )

        # Different previous hash should change result
        assert hash1 != hash2


class TestWorkflowTransitionVerifyHash:
    """Regression tests for WorkflowTransition.verify_hash (L12 fix)."""

    def test_verify_hash_valid_transition(self):
        """Test verify_hash returns True for valid transition.

        L12 fix: Added verify_hash() method for consistency with KeyUsageAudit.
        """
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        # Create transition with valid hash
        transition = WorkflowTransition(
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            reason="Initial submission",
            extra_data={"key": "value"},
            created_at=timestamp,
        )
        transition.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp,
            previous_hash=None,
            reason="Initial submission",
            extra_data={"key": "value"},
        )

        assert transition.verify_hash(previous_hash=None) is True

    def test_verify_hash_tampered_transition(self):
        """Test verify_hash returns False for tampered transition."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        transition = WorkflowTransition(
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            reason="Initial submission",
            extra_data={},
            created_at=timestamp,
            transition_hash="tampered_hash",  # Invalid hash
        )

        assert transition.verify_hash(previous_hash=None) is False

    def test_verify_hash_with_chain(self):
        """Test verify_hash works with hash chaining."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        # Create first transition
        hash1 = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp,
        )

        # Create second transition with previous_hash
        timestamp2 = timestamp + timedelta(hours=1)
        transition2 = WorkflowTransition(
            workflow_instance_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            created_at=timestamp2,
        )
        transition2.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp2,
            previous_hash=hash1,
        )

        # Should verify with correct previous_hash
        assert transition2.verify_hash(previous_hash=hash1) is True

        # Should fail with wrong previous_hash
        assert transition2.verify_hash(previous_hash="wrong_hash") is False

    def test_verify_hash_uses_stored_previous_hash(self):
        """BH16-L5 regression: verify_hash uses stored previous_hash when no arg given.

        Non-first transitions must verify standalone (no argument) by falling
        back to the stored previous_hash column.
        """
        timestamp1 = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        timestamp2 = timestamp1 + timedelta(hours=1)

        # First transition hash
        hash1 = WorkflowTransition.compute_hash(
            workflow_id="wf-chain",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp1,
            previous_hash=None,
        )

        # Second transition computed with hash1 as previous
        hash2 = WorkflowTransition.compute_hash(
            workflow_id="wf-chain",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp2,
            previous_hash=hash1,
        )

        # Create second transition WITH stored previous_hash
        transition2 = WorkflowTransition(
            workflow_instance_id="wf-chain",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            created_at=timestamp2,
            transition_hash=hash2,
            previous_hash=hash1,  # Stored
        )

        # Standalone verification (no argument) should succeed
        assert transition2.verify_hash() is True

    def test_verify_hash_explicit_param_overrides_stored(self):
        """BH16-L5: explicit previous_hash parameter takes precedence over stored value."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        stored_prev = "stored_hash_value"
        explicit_prev = "explicit_hash_value"

        # Compute hash using explicit_prev
        h = WorkflowTransition.compute_hash(
            workflow_id="wf-override",
            from_state="a",
            to_state="b",
            actor_id="actor",
            timestamp=timestamp,
            previous_hash=explicit_prev,
        )

        transition = WorkflowTransition(
            workflow_instance_id="wf-override",
            from_state="a",
            to_state="b",
            actor_id="actor",
            created_at=timestamp,
            transition_hash=h,
            previous_hash=stored_prev,  # Different from what was used
        )

        # Stored value should fail (hash was computed with explicit_prev)
        assert transition.verify_hash() is False

        # Explicit parameter should succeed
        assert transition.verify_hash(previous_hash=explicit_prev) is True

    def test_verify_hash_first_transition_null_stored(self):
        """BH16-L5: first transition (NULL stored previous_hash) passes without argument."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        h = WorkflowTransition.compute_hash(
            workflow_id="wf-first",
            from_state="init",
            to_state="ready",
            actor_id="actor",
            timestamp=timestamp,
            previous_hash=None,
        )

        transition = WorkflowTransition(
            workflow_instance_id="wf-first",
            from_state="init",
            to_state="ready",
            actor_id="actor",
            created_at=timestamp,
            transition_hash=h,
            previous_hash=None,  # First transition — no previous
        )

        # Standalone verification should succeed
        assert transition.verify_hash() is True

    def test_verify_hash_chain_of_three_standalone(self):
        """BH16-L5: 3-transition chain, each verifies standalone with stored previous_hash."""
        base_ts = datetime(2025, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        wf_id = "wf-triple"

        # Transition 1: init → draft (no previous)
        h1 = WorkflowTransition.compute_hash(
            workflow_id=wf_id,
            from_state="init",
            to_state="draft",
            actor_id="a1",
            timestamp=base_ts,
            previous_hash=None,
        )
        t1 = WorkflowTransition(
            workflow_instance_id=wf_id,
            from_state="init",
            to_state="draft",
            actor_id="a1",
            created_at=base_ts,
            transition_hash=h1,
            previous_hash=None,
        )

        # Transition 2: draft → review (previous = h1)
        ts2 = base_ts + timedelta(hours=1)
        h2 = WorkflowTransition.compute_hash(
            workflow_id=wf_id,
            from_state="draft",
            to_state="review",
            actor_id="a2",
            timestamp=ts2,
            previous_hash=h1,
        )
        t2 = WorkflowTransition(
            workflow_instance_id=wf_id,
            from_state="draft",
            to_state="review",
            actor_id="a2",
            created_at=ts2,
            transition_hash=h2,
            previous_hash=h1,
        )

        # Transition 3: review → approved (previous = h2)
        ts3 = base_ts + timedelta(hours=2)
        h3 = WorkflowTransition.compute_hash(
            workflow_id=wf_id,
            from_state="review",
            to_state="approved",
            actor_id="a3",
            timestamp=ts3,
            previous_hash=h2,
        )
        t3 = WorkflowTransition(
            workflow_instance_id=wf_id,
            from_state="review",
            to_state="approved",
            actor_id="a3",
            created_at=ts3,
            transition_hash=h3,
            previous_hash=h2,
        )

        # All three should verify standalone
        assert t1.verify_hash() is True
        assert t2.verify_hash() is True
        assert t3.verify_hash() is True

    def test_verify_hash_tampered_stored_previous_hash(self):
        """BH16-L5: tampered stored previous_hash is detected on standalone verify."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        real_prev = "real_previous_hash"

        h = WorkflowTransition.compute_hash(
            workflow_id="wf-tamper",
            from_state="a",
            to_state="b",
            actor_id="actor",
            timestamp=timestamp,
            previous_hash=real_prev,
        )

        transition = WorkflowTransition(
            workflow_instance_id="wf-tamper",
            from_state="a",
            to_state="b",
            actor_id="actor",
            created_at=timestamp,
            transition_hash=h,
            previous_hash="tampered_value",  # Tampered!
        )

        # Standalone verification should fail
        assert transition.verify_hash() is False

        # Providing the real value should succeed
        assert transition.verify_hash(previous_hash=real_prev) is True

    def test_bh16_l5_regression_standalone_verification(self):
        """BH16-L5 regression: standalone verify_hash for non-first transitions.

        This is the exact scenario that was broken: a second transition's
        verify_hash() was called without arguments, producing a false negative
        because previous_hash defaulted to None instead of the stored value.
        """
        ts1 = datetime(2025, 3, 15, 10, 0, 0, tzinfo=timezone.utc)
        ts2 = ts1 + timedelta(minutes=30)
        wf_id = "wf-regression"

        # Build first transition
        h1 = WorkflowTransition.compute_hash(
            workflow_id=wf_id,
            from_state="draft",
            to_state="submitted",
            actor_id="proposer",
            timestamp=ts1,
            previous_hash=None,
        )

        # Build second transition (chained)
        h2 = WorkflowTransition.compute_hash(
            workflow_id=wf_id,
            from_state="submitted",
            to_state="evaluating",
            actor_id="evaluator",
            timestamp=ts2,
            previous_hash=h1,
        )

        t2 = WorkflowTransition(
            workflow_instance_id=wf_id,
            from_state="submitted",
            to_state="evaluating",
            actor_id="evaluator",
            created_at=ts2,
            transition_hash=h2,
            previous_hash=h1,  # Stored at creation
        )

        # THE BUG: before fix, verify_hash() with no args would use None
        # instead of the stored h1, causing a false negative
        assert (
            t2.verify_hash() is True
        ), "BH16-L5: standalone verify_hash() should use stored previous_hash"


class TestWorkflowCheckpoint:
    """Tests for WorkflowCheckpoint ORM model."""

    def test_compute_hash(self):
        """Test checkpoint hash computation."""
        state = {"workflow_id": "wf-123", "state": "draft"}
        hash1 = WorkflowCheckpoint.compute_hash(state)
        assert len(hash1) == 64

        # Same state should produce same hash
        hash2 = WorkflowCheckpoint.compute_hash(state)
        assert hash1 == hash2

    def test_verify_integrity(self):
        """Test checkpoint integrity verification."""
        state = {"workflow_id": "wf-123", "state": "draft"}
        checkpoint = WorkflowCheckpoint(
            workflow_instance_id="inst-123",
            checkpoint_number=1,
            state_snapshot=state,
            checkpoint_hash=WorkflowCheckpoint.compute_hash(state),
        )
        assert checkpoint.verify_integrity() is True

    def test_verify_integrity_tampered(self):
        """Test detection of tampered checkpoint."""
        state = {"workflow_id": "wf-123", "state": "draft"}
        checkpoint = WorkflowCheckpoint(
            workflow_instance_id="inst-123",
            checkpoint_number=1,
            state_snapshot=state,
            checkpoint_hash="invalid_hash",
        )
        assert checkpoint.verify_integrity() is False


# =============================================================================
# WorkflowPersistence Repository Tests
# =============================================================================


class TestWorkflowPersistence:
    """Tests for WorkflowPersistence repository."""

    @pytest.mark.asyncio
    async def test_initialization(self, database_config):
        """Test persistence initialization."""
        p = WorkflowPersistence(database_config)
        await p.initialize()
        assert p._initialized is True
        await p.close()

    @pytest.mark.asyncio
    async def test_context_manager(self, database_config):
        """Test async context manager usage."""
        async with WorkflowPersistence(database_config) as p:
            assert p._initialized is True

    @pytest.mark.asyncio
    async def test_save_and_load_checkpoint(self, persistence, sample_proposal):
        """Test saving and loading workflow checkpoint."""
        # Save checkpoint
        checkpoint_id = await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="test-user",
        )
        assert checkpoint_id is not None

        # Load checkpoint
        state_data = await persistence.load_checkpoint(sample_proposal.proposal_id)
        assert state_data is not None
        assert state_data["proposal_id"] == sample_proposal.proposal_id

    @pytest.mark.asyncio
    async def test_load_nonexistent_checkpoint(self, persistence):
        """Test loading non-existent workflow."""
        state_data = await persistence.load_checkpoint("nonexistent-id")
        assert state_data is None

    @pytest.mark.asyncio
    async def test_multiple_checkpoints(self, persistence, sample_proposal):
        """Test multiple checkpoints for same workflow."""
        # Save first checkpoint
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        # Modify workflow
        sample_proposal.state = ProposalState.SUBMITTED
        sample_proposal.transitions.append(
            StateTransition(
                from_state=ProposalState.DRAFT,
                to_state=ProposalState.SUBMITTED,
                timestamp=datetime.now(timezone.utc),
                actor_id="user-1",
            )
        )

        # Save second checkpoint
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        # Load should return latest state
        state_data = await persistence.load_checkpoint(sample_proposal.proposal_id)
        assert state_data["state"] == "submitted"

    @pytest.mark.asyncio
    async def test_load_checkpoint_by_number(self, persistence, sample_proposal):
        """Test loading specific checkpoint by number."""
        # Save initial checkpoint
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )
        original_state = sample_proposal.state.value

        # Modify and save again
        sample_proposal.state = ProposalState.SUBMITTED
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        # Load first checkpoint
        state_1 = await persistence.load_checkpoint_by_number(
            sample_proposal.proposal_id, 1
        )
        assert state_1["state"] == original_state

        # Load second checkpoint
        state_2 = await persistence.load_checkpoint_by_number(
            sample_proposal.proposal_id, 2
        )
        assert state_2["state"] == "submitted"

    @pytest.mark.asyncio
    async def test_save_checkpoint_retries_on_checkpoint_number_collision(
        self,
        persistence,
        sample_proposal,
        monkeypatch,
    ):
        """Duplicate checkpoint_number collisions should retry instead of failing."""
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        original_get_next = persistence._get_next_checkpoint_number
        call_count = {"n": 0}

        async def collision_then_real(session, instance_id):
            call_count["n"] += 1
            # Simulate stale/contended allocation: two attempts pick checkpoint #2.
            if call_count["n"] <= 2:
                return 2
            return await original_get_next(session, instance_id)

        monkeypatch.setattr(
            persistence,
            "_get_next_checkpoint_number",
            collision_then_real,
        )

        # First call gets #2. Second call first attempts #2 (collision), then retries.
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-2",
        )

        state_2 = await persistence.load_checkpoint_by_number(
            sample_proposal.proposal_id, 2
        )
        state_3 = await persistence.load_checkpoint_by_number(
            sample_proposal.proposal_id, 3
        )
        assert state_2 is not None
        assert state_3 is not None
        assert call_count["n"] >= 3

    @pytest.mark.asyncio
    async def test_list_pending_workflows(self, persistence, sample_proposal):
        """Test listing pending workflows."""
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        pending = await persistence.list_pending_workflows("proposal")
        assert len(pending) == 1
        assert pending[0]["proposal_id"] == sample_proposal.proposal_id

    @pytest.mark.asyncio
    async def test_list_workflows_with_filters(self, persistence, sample_proposal):
        """Test listing workflows with various filters."""
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        # Filter by type
        workflows = await persistence.list_workflows(workflow_type="proposal")
        assert len(workflows) == 1

        # Filter by state
        workflows = await persistence.list_workflows(state="draft")
        assert len(workflows) == 1

        # Filter by non-matching state
        workflows = await persistence.list_workflows(state="approved")
        assert len(workflows) == 0

    @pytest.mark.asyncio
    async def test_get_workflow_summary_uses_async_safe_counts(
        self, persistence, sample_proposal
    ):
        """Regression: get_workflow_summary should not lazy-load relationships.

        Accessing instance.transitions/checkpoints directly under AsyncSession can
        trigger sqlalchemy.exc.MissingGreenlet. Summary counts must be obtained
        via explicit async queries.
        """
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        summary = await persistence.get_workflow_summary(sample_proposal.proposal_id)
        assert summary is not None
        assert summary["checkpoint_count"] == 1
        assert summary["transition_count"] == 0

        sample_proposal.state = ProposalState.SUBMITTED
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        summary = await persistence.get_workflow_summary(sample_proposal.proposal_id)
        assert summary is not None
        assert summary["checkpoint_count"] == 2
        assert summary["transition_count"] == 1

    @pytest.mark.asyncio
    async def test_workflow_exists(self, persistence, sample_proposal):
        """Test checking workflow existence."""
        assert await persistence.workflow_exists(sample_proposal.proposal_id) is False

        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        assert await persistence.workflow_exists(sample_proposal.proposal_id) is True

    @pytest.mark.asyncio
    async def test_delete_workflow(self, persistence, sample_proposal):
        """Test deleting workflow."""
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        assert await persistence.workflow_exists(sample_proposal.proposal_id) is True

        result = await persistence.delete_workflow(sample_proposal.proposal_id)
        assert result is True

        assert await persistence.workflow_exists(sample_proposal.proposal_id) is False

    @pytest.mark.asyncio
    async def test_mark_completed(self, persistence, sample_proposal):
        """Test marking workflow as completed."""
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        result = await persistence.mark_completed(
            workflow_id=sample_proposal.proposal_id,
            actor_id="admin",
            final_state="approved",
        )
        assert result is True

        # Should not appear in pending
        pending = await persistence.list_pending_workflows("proposal")
        assert len(pending) == 0

    @pytest.mark.asyncio
    async def test_get_audit_trail(self, persistence, sample_proposal):
        """Test retrieving audit trail."""
        # Save initial state
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        # Transition state
        sample_proposal.state = ProposalState.SUBMITTED
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
            transition_reason="Submitted for review",
        )

        # Get audit trail
        trail = await persistence.get_audit_trail(sample_proposal.proposal_id)
        assert len(trail) == 1  # One transition recorded
        assert trail[0]["from_state"] == "draft"
        assert trail[0]["to_state"] == "submitted"
        assert trail[0]["actor_id"] == "user-1"

    @pytest.mark.asyncio
    async def test_verify_audit_chain(self, persistence, sample_proposal):
        """Test audit chain integrity verification."""
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        sample_proposal.state = ProposalState.SUBMITTED
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        sample_proposal.state = ProposalState.EVALUATING
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="evaluator",
        )

        is_valid, error = await persistence.verify_audit_chain(
            sample_proposal.proposal_id
        )
        assert is_valid is True
        assert error is None

    @pytest.mark.asyncio
    async def test_verify_audit_chain_missing_workflow(self, persistence):
        """W-6 regression: verify_audit_chain returns False for missing workflow."""
        is_valid, error = await persistence.verify_audit_chain(
            "nonexistent-workflow-id"
        )
        assert is_valid is False
        assert "Workflow not found" in (error or "")

    @pytest.mark.asyncio
    async def test_record_transition_stores_previous_hash(
        self, persistence, sample_proposal
    ):
        """BH16-L5 regression: _record_transition populates previous_hash column."""
        # Save initial state
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        # Trigger two state transitions
        sample_proposal.state = ProposalState.SUBMITTED
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
            transition_reason="Submit",
        )

        sample_proposal.state = ProposalState.EVALUATING
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="evaluator",
            transition_reason="Begin evaluation",
        )

        # Fetch transitions directly from the DB
        async with persistence.session_factory() as session:
            from sqlalchemy import select

            inst_result = await session.execute(
                select(WorkflowInstance).where(
                    WorkflowInstance.workflow_id == sample_proposal.proposal_id
                )
            )
            instance = inst_result.scalar_one()

            result = await session.execute(
                select(WorkflowTransition)
                .where(WorkflowTransition.workflow_instance_id == instance.id)
                .order_by(WorkflowTransition.created_at)
            )
            transitions = result.scalars().all()

        assert len(transitions) == 2

        # First transition: previous_hash should be None
        assert transitions[0].previous_hash is None

        # Second transition: previous_hash should be first's transition_hash
        assert transitions[1].previous_hash == transitions[0].transition_hash

        # Both should verify standalone (no argument)
        assert transitions[0].verify_hash() is True
        assert transitions[1].verify_hash() is True

    @pytest.mark.asyncio
    async def test_verify_audit_chain_with_stored_hashes(
        self, persistence, sample_proposal
    ):
        """BH16-L5 regression: full chain round-trip with stored previous_hash."""
        # Create 3-transition chain through normal API
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        sample_proposal.state = ProposalState.SUBMITTED
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="user-1",
        )

        sample_proposal.state = ProposalState.EVALUATING
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="evaluator",
        )

        sample_proposal.state = ProposalState.GATE_PASSED
        await persistence.save_checkpoint(
            workflow=sample_proposal,
            actor_id="evaluator",
        )

        # Verify chain integrity through existing API
        is_valid, error = await persistence.verify_audit_chain(
            sample_proposal.proposal_id
        )
        assert is_valid is True, f"Chain verification failed: {error}"

        # Also verify each transition standalone
        async with persistence.session_factory() as session:
            from sqlalchemy import select

            inst_result = await session.execute(
                select(WorkflowInstance).where(
                    WorkflowInstance.workflow_id == sample_proposal.proposal_id
                )
            )
            instance = inst_result.scalar_one()

            result = await session.execute(
                select(WorkflowTransition)
                .where(WorkflowTransition.workflow_instance_id == instance.id)
                .order_by(WorkflowTransition.created_at)
            )
            transitions = result.scalars().all()

        assert len(transitions) == 3
        for t in transitions:
            assert (
                t.verify_hash() is True
            ), f"Standalone verify_hash failed for {t.from_state} -> {t.to_state}"


# =============================================================================
# DurableWorkflowEngine Tests
# =============================================================================


class TestDurableWorkflowEngine:
    """Tests for DurableWorkflowEngine."""

    @pytest.mark.asyncio
    async def test_create_workflow(self, engine, sample_metadata):
        """Test creating a durable workflow."""
        workflow = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="new-prop-001",
            metadata=sample_metadata,
        )

        assert workflow.proposal_id == "new-prop-001"
        assert workflow.state == ProposalState.DRAFT

        # Should be persisted
        exists = await engine.persistence.workflow_exists("new-prop-001")
        assert exists is True

    @pytest.mark.asyncio
    async def test_resume_workflow(self, engine, sample_metadata):
        """Test resuming a workflow."""
        # Create and persist
        original = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="resume-test-001",
            metadata=sample_metadata,
        )

        # Resume
        resumed = await engine.resume(ProposalWorkflow, "resume-test-001")

        assert resumed is not None
        assert resumed.proposal_id == original.proposal_id
        assert resumed.state == original.state

    @pytest.mark.asyncio
    async def test_resume_nonexistent(self, engine):
        """Test resuming non-existent workflow."""
        resumed = await engine.resume(ProposalWorkflow, "nonexistent")
        assert resumed is None

    @pytest.mark.asyncio
    async def test_resume_or_create(self, engine, sample_metadata):
        """Test resume_or_create functionality."""
        # First call should create
        workflow1, is_new1 = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id="roc-test-001",
            actor_id="user-1",
            proposal_id="roc-test-001",
            metadata=sample_metadata,
        )
        assert is_new1 is True

        # Second call should resume
        workflow2, is_new2 = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id="roc-test-001",
            actor_id="user-1",
            proposal_id="roc-test-001",
            metadata=sample_metadata,
        )
        assert is_new2 is False
        assert workflow2.proposal_id == workflow1.proposal_id

    @pytest.mark.asyncio
    async def test_checkpoint(self, engine, sample_metadata):
        """Test manual checkpointing."""
        workflow = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="checkpoint-test",
            metadata=sample_metadata,
        )

        # Modify workflow
        workflow.state = ProposalState.SUBMITTED

        # Create manual checkpoint
        checkpoint_id = await engine.checkpoint(
            workflow,
            actor_id="user-1",
            reason="Manual checkpoint",
        )
        assert checkpoint_id is not None

    @pytest.mark.asyncio
    async def test_complete_workflow(self, engine, sample_metadata):
        """Test completing a workflow."""
        workflow = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="complete-test",
            metadata=sample_metadata,
        )

        result = await engine.complete(
            workflow,
            actor_id="admin",
            final_state="approved",
        )
        assert result is True

        # Should not appear in pending
        pending = await engine.list_pending("proposal")
        assert len(pending) == 0

    @pytest.mark.asyncio
    async def test_abort_workflow(self, engine, sample_metadata):
        """Test aborting a workflow."""
        workflow = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="abort-test",
            metadata=sample_metadata,
        )

        result = await engine.abort(
            workflow,
            actor_id="admin",
            reason="Testing abort",
        )
        assert result is True

    @pytest.mark.asyncio
    async def test_get_checkpoint_history(self, engine, sample_metadata):
        """Test getting checkpoint at specific point."""
        workflow = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="history-test",
            metadata=sample_metadata,
        )
        original_state = workflow.state.value

        # Modify and checkpoint
        workflow.state = ProposalState.SUBMITTED
        await engine.checkpoint(workflow, actor_id="user-1")

        # Get first checkpoint
        old_workflow = await engine.get_checkpoint(
            ProposalWorkflow,
            "history-test",
            1,
        )
        assert old_workflow.state.value == original_state

    @pytest.mark.asyncio
    async def test_verify_integrity(self, engine, sample_metadata):
        """Test audit trail integrity verification."""
        workflow = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="integrity-test",
            metadata=sample_metadata,
        )

        workflow.state = ProposalState.SUBMITTED
        await engine.checkpoint(workflow, actor_id="user-1")

        is_valid, error = await engine.verify_integrity("integrity-test")
        assert is_valid is True


# =============================================================================
# Workflow Serialization Tests
# =============================================================================


class TestProposalWorkflowSerialization:
    """Tests for ProposalWorkflow serialization."""

    def test_workflow_properties(self, sample_proposal):
        """Test workflow_id, workflow_type, current_state properties."""
        assert sample_proposal.workflow_id == sample_proposal.proposal_id
        assert sample_proposal.workflow_type == "proposal"
        assert sample_proposal.current_state == "draft"

    def test_to_dict(self, sample_proposal):
        """Test serialization to dictionary."""
        data = sample_proposal.to_dict()

        assert data["proposal_id"] == sample_proposal.proposal_id
        assert data["state"] == "draft"
        assert "metadata" in data
        assert data["metadata"]["title"] == "Test Proposal"
        assert data["metadata"]["priority"] == "high"
        assert "created_at" in data
        assert "transitions" in data

    def test_from_dict(self, sample_proposal):
        """Test deserialization from dictionary."""
        data = sample_proposal.to_dict()
        restored = ProposalWorkflow.from_dict(data)

        assert restored.proposal_id == sample_proposal.proposal_id
        assert restored.state == sample_proposal.state
        assert restored.metadata.title == sample_proposal.metadata.title
        assert restored.metadata.priority == sample_proposal.metadata.priority

    def test_round_trip(self, sample_proposal):
        """Test full serialization round-trip."""
        # Add some state changes
        sample_proposal.state = ProposalState.SUBMITTED
        sample_proposal.transitions.append(
            StateTransition(
                from_state=ProposalState.DRAFT,
                to_state=ProposalState.SUBMITTED,
                timestamp=datetime.now(timezone.utc),
                actor_id="user-1",
                reason="Ready for review",
            )
        )
        sample_proposal.evaluation_result = EvaluationResult(
            gate_results={"risk": True, "profit": True},
            all_passed=True,
            override_eligible=False,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="evaluator-1",
        )

        # Round trip
        data = sample_proposal.to_dict()
        restored = ProposalWorkflow.from_dict(data)

        assert restored.state == ProposalState.SUBMITTED
        assert len(restored.transitions) == 1
        assert restored.evaluation_result is not None
        assert restored.evaluation_result.all_passed is True


class TestConsensusWorkflowSerialization:
    """Tests for ConsensusWorkflow serialization."""

    def test_workflow_properties(self, sample_consensus):
        """Test workflow_id, workflow_type, current_state properties."""
        assert (
            sample_consensus.workflow_id == f"consensus:{sample_consensus.proposal_id}"
        )
        assert sample_consensus.workflow_type == "consensus"
        assert sample_consensus.current_state == "pending"

    def test_to_dict(self, sample_consensus):
        """Test serialization to dictionary."""
        data = sample_consensus.to_dict()

        assert data["proposal_id"] == sample_consensus.proposal_id
        assert data["state"] == "pending"
        assert sorted(data["eligible_voters"]) == sorted(
            sample_consensus.eligible_voters
        )
        assert "config" in data
        assert data["config"]["quorum_percentage"] == 0.51

    def test_to_dict_with_votes(self, sample_consensus):
        """Test serialization with votes."""
        sample_consensus.cast_vote("voter-1", VoteOutcome.APPROVE, "Looks good")
        sample_consensus.cast_vote("voter-2", VoteOutcome.REJECT, "Needs work")

        data = sample_consensus.to_dict()

        assert len(data["votes"]) == 2
        assert data["votes"]["voter-1"]["outcome"] == "approve"
        assert data["votes"]["voter-2"]["outcome"] == "reject"

    def test_from_dict(self, sample_consensus):
        """Test deserialization from dictionary."""
        data = sample_consensus.to_dict()
        restored = ConsensusWorkflow.from_dict(data)

        assert restored.proposal_id == sample_consensus.proposal_id
        assert restored.state == sample_consensus.state
        assert restored.eligible_voters == sample_consensus.eligible_voters
        assert (
            restored.config.quorum_percentage
            == sample_consensus.config.quorum_percentage
        )

    def test_round_trip_with_votes(self, sample_consensus):
        """Test round-trip with votes."""
        sample_consensus.cast_vote("voter-1", VoteOutcome.APPROVE)
        sample_consensus.cast_vote("voter-2", VoteOutcome.APPROVE)

        data = sample_consensus.to_dict()
        restored = ConsensusWorkflow.from_dict(data)

        assert len(restored.votes) == 2
        assert "voter-1" in restored.votes
        assert restored.votes["voter-1"].outcome == VoteOutcome.APPROVE


class TestOverrideWorkflowSerialization:
    """Tests for OverrideWorkflow serialization."""

    def test_workflow_properties(self, sample_override):
        """Test workflow_id, workflow_type, current_state properties."""
        assert sample_override.workflow_type == "override"
        assert sample_override.current_state == "pending"

    def test_to_dict(self, sample_override):
        """Test serialization to dictionary."""
        data = sample_override.to_dict()

        assert "request" in data
        assert data["request"]["proposal_id"] == "prop-override-001"
        assert data["message_hash"] == "abc123def456"
        assert "expires_at" in data
        assert data["risk_lead_signature"] is None
        assert data["security_lead_signature"] is None

    def test_to_dict_with_signatures(self, sample_override):
        """Test serialization with signatures."""
        sample_override.risk_lead_signature = SignatureRecord(
            signer_id="risk-lead",
            role="risk_lead",
            signature="base64signature==",
            message_hash=sample_override.message_hash,
            timestamp=datetime.now(timezone.utc),
            public_key="pubkey123",
        )
        # Update state to match (normally add_signature does this)
        sample_override.request.state = OverrideState.PARTIAL

        data = sample_override.to_dict()

        assert data["risk_lead_signature"] is not None
        assert data["risk_lead_signature"]["signer_id"] == "risk-lead"
        assert data["current_state"] == "partial"

    def test_from_dict(self, sample_override):
        """Test deserialization from dictionary."""
        data = sample_override.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        assert restored.request.proposal_id == sample_override.request.proposal_id
        assert restored.message_hash == sample_override.message_hash
        assert restored.validator is None  # Validator cannot be serialized

    def test_round_trip_with_signatures(self, sample_override):
        """Test round-trip with signatures."""
        sample_override.risk_lead_signature = SignatureRecord(
            signer_id="risk-lead",
            role="risk_lead",
            signature="risksig==",
            message_hash=sample_override.message_hash,
            timestamp=datetime.now(timezone.utc),
            public_key="pubkey1",
        )
        sample_override.security_lead_signature = SignatureRecord(
            signer_id="security-lead",
            role="security_lead",
            signature="secsig==",
            message_hash=sample_override.message_hash,
            timestamp=datetime.now(timezone.utc),
            public_key="pubkey2",
        )
        # Update state to match (normally add_signature does this)
        sample_override.request.state = OverrideState.APPROVED

        data = sample_override.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        assert restored.risk_lead_signature is not None
        assert restored.security_lead_signature is not None
        assert restored.current_state == "approved"


# =============================================================================
# Integration Tests
# =============================================================================


class TestPersistenceIntegration:
    """Integration tests for persistence layer."""

    @pytest.mark.asyncio
    async def test_consensus_workflow_persistence(self, engine):
        """Test persisting and resuming ConsensusWorkflow."""
        # Create consensus workflow
        workflow = await engine.create(
            ConsensusWorkflow,
            actor_id="system",
            proposal_id="consensus-persist-001",
            eligible_voters={"voter-a", "voter-b", "voter-c"},
        )

        # Cast some votes
        workflow.cast_vote("voter-a", VoteOutcome.APPROVE, "Approved")

        # Checkpoint
        await engine.checkpoint(workflow, actor_id="voter-a")

        # Resume
        restored = await engine.resume(ConsensusWorkflow, workflow.workflow_id)

        assert restored is not None
        assert len(restored.votes) == 1
        assert "voter-a" in restored.votes

    @pytest.mark.asyncio
    async def test_multiple_workflow_types(self, engine, sample_metadata):
        """Test managing different workflow types together."""
        # Create proposal (result not used, testing creation itself)
        _proposal = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id="multi-type-prop",
            metadata=sample_metadata,
        )

        # Create consensus (result not used, testing creation itself)
        _consensus = await engine.create(
            ConsensusWorkflow,
            actor_id="system",
            proposal_id="multi-type-cons",
            eligible_voters={"a", "b"},
        )

        # List by type
        proposals = await engine.list_pending("proposal")
        consensuses = await engine.list_pending("consensus")

        assert len(proposals) == 1
        assert len(consensuses) == 1

    @pytest.mark.asyncio
    async def test_consensus_workflow_id_namespace(self, engine, sample_metadata):
        """Test consensus workflow_id avoids collisions with proposal workflow_id."""
        proposal_id = "shared-prop-001"

        proposal = await engine.create(
            ProposalWorkflow,
            actor_id="user-1",
            proposal_id=proposal_id,
            metadata=sample_metadata,
        )

        consensus = await engine.create(
            ConsensusWorkflow,
            actor_id="system",
            proposal_id=proposal_id,
            eligible_voters={"a", "b"},
        )

        assert proposal.workflow_id != consensus.workflow_id

        restored_proposal = await engine.resume(ProposalWorkflow, proposal.workflow_id)
        restored_consensus = await engine.resume(
            ConsensusWorkflow,
            consensus.workflow_id,
        )

        assert restored_proposal is not None
        assert restored_consensus is not None
        assert restored_proposal.proposal_id == proposal_id
        assert restored_consensus.proposal_id == proposal_id

    @pytest.mark.asyncio
    async def test_workflow_lifecycle(self, engine, sample_metadata):
        """Test complete workflow lifecycle."""
        # Create
        workflow = await engine.create(
            ProposalWorkflow,
            actor_id="author",
            proposal_id="lifecycle-test",
            metadata=sample_metadata,
        )

        # Transition through states
        workflow.state = ProposalState.SUBMITTED
        await engine.checkpoint(workflow, actor_id="author")

        workflow.state = ProposalState.EVALUATING
        await engine.checkpoint(workflow, actor_id="evaluator")

        workflow.state = ProposalState.APPROVED
        await engine.checkpoint(workflow, actor_id="approver")

        # Complete
        await engine.complete(workflow, actor_id="approver")

        # Verify audit trail
        trail = await engine.get_audit_trail("lifecycle-test")
        assert len(trail) == 3  # 3 state transitions

        # Verify integrity
        is_valid, _ = await engine.verify_integrity("lifecycle-test")
        assert is_valid is True


# =============================================================================
# Codex Bug Hunt v3.21.0 Regression Tests
# =============================================================================


class TestTransitionHashIntegrity:
    """Regression tests for WorkflowTransition hash including reason/extra_data.

    Codex Bug: models.py:243 - Transition hash was missing reason and extra_data,
    meaning two transitions with different reasons/metadata would have the same
    hash (integrity vulnerability).
    """

    def test_transition_hash_includes_reason(self):
        """Test that different reasons produce different hashes."""
        from datetime import datetime, timezone

        from workflows.persistence.models import WorkflowTransition

        timestamp = datetime.now(timezone.utc)

        hash1 = WorkflowTransition.compute_hash(
            workflow_id="w1",
            from_state="draft",
            to_state="submitted",
            actor_id="actor1",
            timestamp=timestamp,
            reason="Reason A",
            extra_data={},
        )

        hash2 = WorkflowTransition.compute_hash(
            workflow_id="w1",
            from_state="draft",
            to_state="submitted",
            actor_id="actor1",
            timestamp=timestamp,
            reason="Reason B",  # Different reason
            extra_data={},
        )

        # Hashes should be different
        assert hash1 != hash2

    def test_transition_hash_includes_extra_data(self):
        """Test that different extra_data produces different hashes."""
        from datetime import datetime, timezone

        from workflows.persistence.models import WorkflowTransition

        timestamp = datetime.now(timezone.utc)

        hash1 = WorkflowTransition.compute_hash(
            workflow_id="w1",
            from_state="draft",
            to_state="submitted",
            actor_id="actor1",
            timestamp=timestamp,
            reason="Same reason",
            extra_data={"key": "value1"},
        )

        hash2 = WorkflowTransition.compute_hash(
            workflow_id="w1",
            from_state="draft",
            to_state="submitted",
            actor_id="actor1",
            timestamp=timestamp,
            reason="Same reason",
            extra_data={"key": "value2"},  # Different extra_data
        )

        # Hashes should be different
        assert hash1 != hash2


class TestAuditHashIntegrity:
    """Regression tests for KeyUsageAudit hash including context.

    Codex Bug: models.py:588 - Audit hash was missing context (proposal_id, etc.),
    meaning two audits with different contexts would have the same hash.
    """

    def test_audit_hash_includes_context(self):
        """Test that different contexts produce different hashes."""
        from datetime import datetime, timezone

        from workflows.persistence.models import KeyUsageAudit

        timestamp = datetime.now(timezone.utc)

        hash1 = KeyUsageAudit.compute_hash(
            key_id="k1",
            operation="sign",
            actor_id="actor1",
            timestamp=timestamp,
            context={"proposal_id": "p1"},
        )

        hash2 = KeyUsageAudit.compute_hash(
            key_id="k1",
            operation="sign",
            actor_id="actor1",
            timestamp=timestamp,
            context={"proposal_id": "p2"},  # Different proposal
        )

        # Hashes should be different
        assert hash1 != hash2

    def test_audit_verify_hash_includes_context(self):
        """Test that verify_hash uses context for verification."""
        from datetime import datetime, timezone

        from workflows.persistence.models import KeyUsageAudit

        timestamp = datetime.now(timezone.utc)
        context = {"proposal_id": "p1", "workflow": "test"}

        # Compute hash with context
        operation_hash = KeyUsageAudit.compute_hash(
            key_id="k1",
            operation="sign",
            actor_id="actor1",
            timestamp=timestamp,
            context=context,
        )

        # Create audit record
        audit = KeyUsageAudit(
            id="a1",
            key_id="k1",
            operation="sign",
            actor_id="actor1",
            context=context,
            operation_hash=operation_hash,
            previous_hash=None,
            created_at=timestamp,
        )

        # Hash should verify correctly
        assert audit.verify_hash() is True

        # Modify context (tamper with it)
        audit.context = {"proposal_id": "p999"}

        # Hash should no longer verify
        assert audit.verify_hash() is False


# =============================================================================
# B3-5 Regression Tests: resume_or_create ID mismatch handling
# =============================================================================


class TestResumeOrCreateStrictId:
    """Regression tests for B3-5: resume_or_create ID mismatch handling."""

    @pytest.mark.asyncio
    async def test_resume_or_create_matching_id_works(self, engine, sample_metadata):
        """Test resume_or_create works when IDs match (normal case)."""
        workflow_id = "matching-id-test"

        # Create workflow
        workflow, is_new = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id=workflow_id,
            actor_id="user-1",
            proposal_id=workflow_id,
            metadata=sample_metadata,
        )
        assert is_new is True
        assert workflow.workflow_id == workflow_id

        # Resume - should work fine
        workflow2, is_new2 = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id=workflow_id,
            actor_id="user-1",
            proposal_id=workflow_id,
            metadata=sample_metadata,
        )
        assert is_new2 is False
        assert workflow2.workflow_id == workflow_id

    @pytest.mark.asyncio
    async def test_resume_or_create_applies_workflow_id_on_create_when_missing(
        self, engine, sample_metadata
    ):
        """Regression: creation path must apply workflow_id when constructor ID is omitted."""
        workflow_id = "implicit-create-id-test"

        # Create without passing proposal_id explicitly.
        workflow1, is_new1 = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id=workflow_id,
            actor_id="user-1",
            metadata=sample_metadata,
        )
        assert is_new1 is True
        assert workflow1.workflow_id == workflow_id

        # A second call should resume the same workflow, not create another one.
        workflow2, is_new2 = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id=workflow_id,
            actor_id="user-1",
            metadata=sample_metadata,
        )
        assert is_new2 is False
        assert workflow2.workflow_id == workflow_id

    @pytest.mark.asyncio
    async def test_resume_or_create_strict_id_default_true(
        self, engine, sample_metadata
    ):
        """Test that strict_id defaults to True (B3-5 fix).

        When a workflow's ID differs from the requested ID, it should raise
        ValueError by default to alert callers to a potential bug.
        """
        # This test verifies the parameter exists and defaults to True
        # We need to mock a scenario where IDs mismatch

        # Create a workflow with a known ID
        workflow, is_new = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id="original-id",
            actor_id="user-1",
            proposal_id="original-id",
            metadata=sample_metadata,
        )
        assert is_new is True

        # For ProposalWorkflow, workflow_id == proposal_id, so this should work
        workflow2, is_new2 = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id="original-id",
            actor_id="user-1",
            proposal_id="original-id",
            metadata=sample_metadata,
        )
        assert is_new2 is False

    @pytest.mark.asyncio
    async def test_resume_or_create_strict_id_false_allows_mismatch(
        self, engine, sample_metadata, caplog
    ):
        """Test that strict_id=False logs warning instead of raising (B3-5 fix)."""
        import logging

        # Create workflow
        workflow, is_new = await engine.resume_or_create(
            ProposalWorkflow,
            workflow_id="test-strict-false",
            actor_id="user-1",
            strict_id=False,
            proposal_id="test-strict-false",
            metadata=sample_metadata,
        )
        assert is_new is True

        # Resume with same ID - should work normally (no mismatch)
        with caplog.at_level(logging.WARNING):
            workflow2, is_new2 = await engine.resume_or_create(
                ProposalWorkflow,
                workflow_id="test-strict-false",
                actor_id="user-1",
                strict_id=False,
                proposal_id="test-strict-false",
                metadata=sample_metadata,
            )

        assert is_new2 is False
        # No warning because IDs match
        assert "Workflow ID mismatch" not in caplog.text


# =============================================================================
# B3-7 Regression Tests: verify_chain_link method
# =============================================================================


class TestVerifyChainLink:
    """Regression tests for B3-7: WorkflowTransition.verify_chain_link method."""

    def test_verify_chain_link_first_transition(self):
        """Test verify_chain_link for first transition (no previous)."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        transition = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp,
        )
        transition.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp,
            previous_hash=None,
        )

        # First transition with no previous should verify
        is_valid, error = transition.verify_chain_link(None)
        assert is_valid is True
        assert error is None

    def test_verify_chain_link_first_transition_rejects_non_empty_previous_hash(self):
        """First transition must not carry a previous_hash value."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        transition = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp,
            previous_hash="forged-prev-hash",
        )
        # Hash is internally consistent, but chain root is invalid because
        # a first transition must not reference a predecessor.
        transition.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp,
            previous_hash="forged-prev-hash",
        )

        is_valid, error = transition.verify_chain_link(None)
        assert is_valid is False
        assert error is not None
        assert "Invalid chain root" in error

    def test_verify_chain_link_valid_chain(self):
        """Test verify_chain_link for valid chain of two transitions."""
        timestamp1 = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        timestamp2 = datetime(2025, 1, 1, 13, 0, 0, tzinfo=timezone.utc)

        # First transition
        t1 = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp1,
        )
        t1.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp1,
            previous_hash=None,
        )

        # Second transition linked to first
        t2 = WorkflowTransition(
            id="t2",
            workflow_instance_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            created_at=timestamp2,
        )
        t2.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp2,
            previous_hash=t1.transition_hash,
        )

        # Chain verification should pass
        is_valid, error = t2.verify_chain_link(t1)
        assert is_valid is True
        assert error is None

    def test_verify_chain_link_tampered_hash(self):
        """Test verify_chain_link detects tampered hash."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        t1 = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp,
            transition_hash="tampered_hash_value",  # Invalid hash
        )

        is_valid, error = t1.verify_chain_link(None)
        assert is_valid is False
        assert "Hash verification failed" in error
        assert "tampered" in error

    def test_verify_chain_link_state_discontinuity(self):
        """Test verify_chain_link detects state discontinuity (B3-7 fix)."""
        timestamp1 = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        timestamp2 = datetime(2025, 1, 1, 13, 0, 0, tzinfo=timezone.utc)

        # First transition
        t1 = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp1,
        )
        t1.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp1,
        )

        # Second transition with state discontinuity (from_state != t1.to_state)
        t2 = WorkflowTransition(
            id="t2",
            workflow_instance_id="wf-123",
            from_state="draft",  # Should be "submitted"!
            to_state="approved",
            actor_id="user-2",
            created_at=timestamp2,
        )
        t2.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp2,
            previous_hash=t1.transition_hash,
        )

        is_valid, error = t2.verify_chain_link(t1)
        assert is_valid is False
        assert "State discontinuity" in error
        assert "submitted" in error  # Expected from_state
        assert "draft" in error  # Actual from_state

    def test_verify_chain_link_workflow_mismatch(self):
        """Test verify_chain_link detects workflow ID mismatch (B3-7 fix)."""
        timestamp1 = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        timestamp2 = datetime(2025, 1, 1, 13, 0, 0, tzinfo=timezone.utc)

        # First transition for workflow A
        t1 = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-A",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp1,
        )
        t1.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-A",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp1,
        )

        # Second transition for workflow B (different workflow!)
        t2 = WorkflowTransition(
            id="t2",
            workflow_instance_id="wf-B",  # Different workflow
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            created_at=timestamp2,
        )
        t2.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-B",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp2,
            previous_hash=t1.transition_hash,
        )

        is_valid, error = t2.verify_chain_link(t1)
        assert is_valid is False
        assert "Workflow ID mismatch" in error

    def test_verify_chain_link_temporal_violation(self):
        """Test verify_chain_link detects temporal ordering violation (B3-7 fix)."""
        timestamp1 = datetime(2025, 1, 1, 14, 0, 0, tzinfo=timezone.utc)  # Later!
        timestamp2 = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)  # Earlier

        # First transition
        t1 = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp1,  # 2 PM
        )
        t1.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp1,
        )

        # Second transition with earlier timestamp (violation)
        t2 = WorkflowTransition(
            id="t2",
            workflow_instance_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            created_at=timestamp2,  # 12 PM - before t1!
        )
        t2.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp2,
            previous_hash=t1.transition_hash,
        )

        is_valid, error = t2.verify_chain_link(t1)
        assert is_valid is False
        assert "Temporal ordering violation" in error

    def test_verify_chain_link_naive_timestamps(self):
        """Test verify_chain_link handles naive timestamps correctly."""
        # Some databases (SQLite) may strip timezone info
        timestamp1 = datetime(2025, 1, 1, 12, 0, 0)  # Naive (no timezone)
        timestamp2 = datetime(2025, 1, 1, 13, 0, 0)  # Naive

        t1 = WorkflowTransition(
            id="t1",
            workflow_instance_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            created_at=timestamp1,
        )
        t1.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="draft",
            to_state="submitted",
            actor_id="user-1",
            timestamp=timestamp1.replace(tzinfo=timezone.utc),
        )

        t2 = WorkflowTransition(
            id="t2",
            workflow_instance_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            created_at=timestamp2,
        )
        t2.transition_hash = WorkflowTransition.compute_hash(
            workflow_id="wf-123",
            from_state="submitted",
            to_state="approved",
            actor_id="user-2",
            timestamp=timestamp2.replace(tzinfo=timezone.utc),
            previous_hash=t1.transition_hash,
        )

        # Should handle naive timestamps by treating as UTC
        is_valid, error = t2.verify_chain_link(t1)
        assert is_valid is True
        assert error is None
