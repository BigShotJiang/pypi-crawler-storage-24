"""
Tests for src/engine/ module.

Tests cover:
- Utility calculation (Rubric v2.1)
- Gate evaluation (all 6 gates)
- Bayesian posterior probability
- Complexity decomposition
- KL divergence drift detection
"""

import math

import pytest

from engine.bayesian import (
    BayesianPosterior,
    PosteriorResult,
)
from engine.complexity import (
    ComplexityAnalysis,
    ComplexityDecomposer,
    ComplexityMetric,
)
from engine.drift import (
    DriftAction,
    DriftMonitor,
    DriftResult,
    DriftStatus,
)
from engine.gates import (
    GateEvaluator,
    GateResult,
    GateType,
)
from engine.utility import (
    ComplexityBreakdown,
    ThreePointEstimate,
    UtilityCalculator,
    UtilityResult,
)


class TestUtilityCalculator:
    """Tests for UtilityCalculator."""

    def test_init_defaults(self):
        """Test default initialization."""
        calc = UtilityCalculator()
        assert calc.gamma == 0.3
        assert calc.kappa == 1.0
        # Fixed per GAP-C1: phi_S=100, phi_D=2000 (spec-aligned values)
        assert calc.phi_S == 100.0
        assert calc.phi_D == 2000.0
        assert calc.lcb_alpha == 0.05

    def test_init_custom(self):
        """Test custom initialization."""
        calc = UtilityCalculator(gamma=0.5, kappa=2.0)
        assert calc.gamma == 0.5
        assert calc.kappa == 2.0

    def test_calculate_basic(self):
        """Test basic utility calculation.

        Note: PERT requires best <= likely <= worst numerically.
        """
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=5000, likely=8000, worst=10000)
        risk = ThreePointEstimate(best=-0.3, likely=-0.2, worst=-0.1)
        complexity = ComplexityBreakdown(static=0.1, dynamic=0.05)

        result = calc.calculate(profit, risk, complexity)

        assert isinstance(result, UtilityResult)
        assert result.decision_path == "INVESTMENT"  # positive complexity
        assert result.variance > 0
        assert result.lcb < result.raw  # LCB should be lower

    def test_calculate_refactoring_path(self):
        """Test refactoring path detection (negative complexity).

        Note: PERT requires best <= likely <= worst numerically.
        """
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=1000, likely=3000, worst=5000)
        risk = ThreePointEstimate(best=-0.1, likely=-0.05, worst=0.0)
        complexity = ComplexityBreakdown(
            static=-0.2, dynamic=-0.1
        )  # Negative = reducing

        result = calc.calculate(profit, risk, complexity)

        assert result.decision_path == "REFACTORING"

    def test_pert_expected_value(self):
        """Test PERT expected value: E[X] = (a + 4m + b) / 6."""
        estimate = ThreePointEstimate(best=100, likely=150, worst=200)
        expected = (100 + 4 * 150 + 200) / 6
        assert estimate.expected == expected

    def test_pert_variance(self):
        """Test PERT variance: Var[X] = ((b - a) / 6)^2."""
        estimate = ThreePointEstimate(best=100, likely=150, worst=200)
        expected_var = ((200 - 100) / 6) ** 2
        assert estimate.variance == expected_var

    def test_pert_constraint_validation(self):
        """Test PERT constraint: best <= likely <= worst."""
        import pytest

        # Valid PERT estimates
        ThreePointEstimate(best=100, likely=150, worst=200)  # Should not raise
        ThreePointEstimate(best=100, likely=100, worst=200)  # likely == best is ok
        ThreePointEstimate(best=100, likely=200, worst=200)  # likely == worst is ok

        # Invalid PERT estimates should raise ValueError
        with pytest.raises(ValueError, match="PERT requires best <= likely <= worst"):
            ThreePointEstimate(best=200, likely=150, worst=100)  # Inverted

        with pytest.raises(ValueError, match="PERT requires best <= likely <= worst"):
            ThreePointEstimate(best=100, likely=50, worst=200)  # likely < best

        with pytest.raises(ValueError, match="PERT requires best <= likely <= worst"):
            ThreePointEstimate(best=100, likely=300, worst=200)  # likely > worst

    def test_check_refactoring_path_eligible(self):
        """Test refactoring path eligibility."""
        calc = UtilityCalculator(migration_budget=5000)

        result = UtilityResult(
            raw=-3000,  # Negative but within budget
            variance=100,
            lcb=-3100,
            components=None,
            decision_path="REFACTORING",
        )

        assert calc.check_refactoring_path(result) is True

    def test_check_refactoring_path_not_eligible(self):
        """Test refactoring path ineligibility (exceeds budget)."""
        calc = UtilityCalculator(migration_budget=5000)

        result = UtilityResult(
            raw=-10000,  # Exceeds budget
            variance=100,
            lcb=-10100,
            components=None,
            decision_path="REFACTORING",
        )

        assert calc.check_refactoring_path(result) is False


class TestGateEvaluator:
    """Tests for GateEvaluator."""

    def test_init_defaults(self):
        """Test default initialization."""
        evaluator = GateEvaluator()
        assert evaluator.epsilon_R == 0.01
        assert evaluator.epsilon_P == 0.01
        assert evaluator.risk_trigger_factor == 2.0
        assert evaluator.trigger_confidence_prob == 0.95

    def test_evaluate_all_pass(self, sample_proposal_data):
        """Test evaluation when all gates pass."""
        evaluator = GateEvaluator()

        # Mock utility result
        from engine.utility import UtilityComponents, UtilityResult

        utility = UtilityResult(
            raw=1000,
            variance=100,
            lcb=500,
            components=UtilityComponents(
                profit_high_conf=1000,
                value_low_conf=100,
                risk_adjustment=50,
                complexity_tax=100,
                opex_delta=50,
            ),
            decision_path="INVESTMENT",
        )

        result = evaluator.evaluate_all(
            risk_baseline=1.0,
            risk_proposed=1.2,  # Low delta
            profit_baseline=1.0,
            profit_proposed=1.1,  # Low delta
            novelty_score=0.9,  # Above 0.8
            complexity_score=0.6,  # Above 0.5
            quality_score=0.8,  # Above 0.7
            quality_subscores=[0.7, 0.8, 0.9],  # No zeros
            utility_result=utility,
        )

        assert result.all_passed is True
        assert len(result.get_failures()) == 0

    def test_evaluate_risk_gate_fail(self):
        """Test risk gate failure."""
        evaluator = GateEvaluator()

        # Use public method (evaluate_risk_gate wraps _evaluate_risk_gate)
        result = evaluator.evaluate_risk_gate(
            baseline=1.0,
            proposed=5.0,  # 4x increase
        )

        assert result.gate_type == GateType.RISK
        assert result.passed is False

    def test_evaluate_risk_gate_public_method(self):
        """Test public evaluate_risk_gate method matches internal behavior."""
        evaluator = GateEvaluator()

        # Public method should give same result as internal method
        public_result = evaluator.evaluate_risk_gate(baseline=1.0, proposed=1.5)
        internal_result = evaluator._evaluate_risk_gate(baseline=1.0, proposed=1.5)

        assert public_result.passed == internal_result.passed
        assert public_result.value == internal_result.value
        assert (
            public_result.posterior_probability == internal_result.posterior_probability
        )

    def test_evaluate_complexity_gate_hard_floor(self):
        """Test complexity floor is a hard requirement."""
        evaluator = GateEvaluator()

        result = evaluator._evaluate_complexity_gate(0.4)  # Below 0.5

        assert result.gate_type == GateType.COMPLEXITY
        assert result.passed is False
        assert result.confidence == 0.0  # Hard requirement

    def test_evaluate_novelty_gate_logistic(self):
        """Test novelty gate uses logistic function."""
        evaluator = GateEvaluator(novelty_N0=0.7, novelty_k=10)

        # At N0, G(N) should be ~0.5
        result = evaluator._evaluate_novelty_gate(0.7)
        assert abs(result.value - 0.5) < 0.01

        # High novelty should pass
        result = evaluator._evaluate_novelty_gate(0.9)
        assert result.passed is True

    def test_evaluate_novelty_gate_overflow_protection(self):
        """Test novelty gate handles extreme values without overflow."""
        evaluator = GateEvaluator(novelty_N0=0.7, novelty_k=10)

        # Extreme negative novelty should not cause OverflowError
        # Previously would cause math.exp(1007) overflow
        result = evaluator._evaluate_novelty_gate(-100.0)
        assert result.passed is False
        assert result.value >= 0.0
        assert result.value <= 1.0

        # Extreme positive novelty should also be safe
        result = evaluator._evaluate_novelty_gate(100.0)
        assert result.passed is True
        assert result.value >= 0.0
        assert result.value <= 1.0

    def test_evaluate_utility_gate_overflow_protection(self):
        """Test utility gate sigmoid confidence handles extreme values without overflow."""
        from engine.utility import UtilityComponents, UtilityResult

        evaluator = GateEvaluator()

        # Extreme negative LCB would previously cause math.exp(1000) overflow
        utility = UtilityResult(
            raw=-1.0,
            variance=1.0,
            lcb=-1000.0,
            components=UtilityComponents(0.0, 0.0, 0.0, 0.0, 0.0),
            decision_path="INVESTMENT",
        )

        result = evaluator._evaluate_utility_gate(utility)
        assert result.passed is False
        assert result.confidence is not None
        assert 0.0 <= result.confidence <= 1.0

    def test_profit_gate_negative_baseline_normalization(self):
        """Test profit gate normalization uses baseline magnitude for negative baselines."""
        evaluator = GateEvaluator()

        result = evaluator._evaluate_profit_gate(baseline=-100.0, proposed=-50.0)

        # (P_prop - P_base) / max(|P_base|, eps) = 50 / 100 = 0.5
        assert abs(result.value - 0.5) < 1e-12
        assert result.passed is True

    def test_profit_gate_large_negative_change_fails(self):
        """Test profit gate fails on large negative change."""
        evaluator = GateEvaluator()

        result = evaluator._evaluate_profit_gate(baseline=100.0, proposed=-300.0)

        # Delta_norm = (-300 - 100) / 100 = -4 -> |Δ| >= 2 should fail.
        assert result.passed is False
        assert result.posterior_probability is not None
        assert result.posterior_probability >= evaluator.trigger_confidence_prob

    def test_evaluate_quality_gate_zero_subscore(self):
        """Test quality gate fails on zero subscore."""
        evaluator = GateEvaluator()

        from engine.utility import UtilityComponents, UtilityResult

        utility = UtilityResult(
            raw=1000,
            variance=100,
            lcb=500,
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="INVESTMENT",
        )

        result = evaluator.evaluate_all(
            risk_baseline=1.0,
            risk_proposed=1.1,
            profit_baseline=1.0,
            profit_proposed=1.1,
            novelty_score=0.9,
            complexity_score=0.6,
            quality_score=0.8,  # High score
            quality_subscores=[0.9, 0.0, 0.8],  # But has zero!
            utility_result=utility,
        )

        quality_gate = result.gates[GateType.QUALITY]
        assert quality_gate.passed is False

    def test_quality_gate_allows_zero_when_configured(self):
        """Regression: quality_no_zero_subscore=False should allow zero subscores."""
        evaluator = GateEvaluator(quality_no_zero_subscore=False)

        from engine.utility import UtilityComponents, UtilityResult

        utility = UtilityResult(
            raw=1000,
            variance=100,
            lcb=500,
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="INVESTMENT",
        )

        result = evaluator.evaluate_all(
            risk_baseline=1.0,
            risk_proposed=1.1,
            profit_baseline=1.0,
            profit_proposed=1.1,
            novelty_score=0.9,
            complexity_score=0.6,
            quality_score=0.8,  # Above threshold
            quality_subscores=[0.9, 0.0, 0.8],  # Has zero, but flag is off
            utility_result=utility,
        )

        quality_gate = result.gates[GateType.QUALITY]
        assert quality_gate.passed is True  # Should pass with flag off

    def test_override_eligibility(self):
        """Test override eligibility (complexity passed, others failed)."""
        evaluator = GateEvaluator()

        from engine.utility import UtilityComponents, UtilityResult

        utility = UtilityResult(
            raw=-100,
            variance=100,
            lcb=-200,  # Negative utility
            components=UtilityComponents(100, 10, 5, 10, 5),
            decision_path="INVESTMENT",
        )

        result = evaluator.evaluate_all(
            risk_baseline=1.0,
            risk_proposed=5.0,  # Fails
            profit_baseline=1.0,
            profit_proposed=1.1,
            novelty_score=0.9,
            complexity_score=0.6,  # Passes
            quality_score=0.8,
            quality_subscores=[0.8, 0.9],
            utility_result=utility,
        )

        assert result.all_passed is False
        assert result.override_eligible is True


class TestBayesianPosterior:
    """Tests for BayesianPosterior."""

    def test_init_defaults(self):
        """Test default initialization."""
        bayes = BayesianPosterior()
        assert bayes.prior_mean == 0.0
        assert bayes.prior_std == 1.0
        assert bayes.likelihood_std == 0.5

    def test_compute_posterior_low_delta(self):
        """Test posterior with low observed delta."""
        bayes = BayesianPosterior()

        prob = bayes.compute_posterior(
            observed_delta=0.5,
            trigger_threshold=2.0,
        )

        # Low delta should have low probability of exceeding threshold
        assert prob < 0.5

    def test_compute_posterior_high_delta(self):
        """Test posterior with high observed delta."""
        bayes = BayesianPosterior()

        prob = bayes.compute_posterior(
            observed_delta=3.0,
            trigger_threshold=2.0,
        )

        # High delta should have high probability of exceeding threshold
        assert prob > 0.5

    def test_compute_full_result(self):
        """Test compute_full returns PosteriorResult."""
        bayes = BayesianPosterior()

        result = bayes.compute_full(
            observed_delta=1.5,
            trigger_threshold=2.0,
        )

        assert isinstance(result, PosteriorResult)
        assert 0 <= result.probability <= 1
        assert result.confidence == 1.0 - result.probability

    def test_update_prior(self):
        """Test prior update from observations."""
        bayes = BayesianPosterior()

        observations = [0.5, 0.6, 0.4, 0.55, 0.45]
        new_mean, new_std = bayes.update_prior(observations)

        # Should move toward empirical mean (0.5)
        empirical_mean = sum(observations) / len(observations)
        # With 5 observations, weight = 5/30 ≈ 0.167
        # new_mean = 0.833 * 0 + 0.167 * 0.5 ≈ 0.083
        assert 0 < new_mean < empirical_mean  # Between prior (0) and empirical (0.5)

    def test_update_prior_empty_observations_respects_overrides(self):
        """Test empty observations uses provided overrides (including zero)."""
        bayes = BayesianPosterior(prior_mean=2.0, prior_std=1.0)

        new_mean, new_std = bayes.update_prior(
            [],
            current_mean=0.0,
            current_std=0.5,
        )

        assert new_mean == 0.0
        assert new_std == 0.5

    def test_update_prior_ddof_sample_variance(self):
        """Test ddof parameter for sample vs population variance."""
        bayes = BayesianPosterior()

        observations = [1.0, 2.0, 3.0, 4.0, 5.0]

        # Population variance (ddof=0, default)
        _, std_pop = bayes.update_prior(observations, ddof=0)

        # Sample variance (ddof=1, Bessel's correction)
        _, std_sample = bayes.update_prior(observations, ddof=1)

        # Sample std should be larger (n/(n-1) factor)
        # For n=5: sample_var = pop_var * (5/4) = pop_var * 1.25
        assert std_sample > std_pop

        # Verify the ratio is correct (weighted combination with prior)
        # The raw empirical ratio would be sqrt(5/4) ≈ 1.118
        # But due to weighted combination with prior, actual ratio varies
        assert std_sample / std_pop > 1.0

    def test_update_prior_ddof_single_observation(self):
        """Test ddof=1 with single observation doesn't divide by zero."""
        bayes = BayesianPosterior()

        # Single observation - ddof=1 would divide by 0 without protection
        observations = [1.0]
        _, std = bayes.update_prior(observations, ddof=1)

        # Should not raise and should return reasonable value
        assert std > 0

    def test_update_prior_ddof_negative_raises(self):
        """Test negative ddof raises ValueError."""
        bayes = BayesianPosterior()

        observations = [1.0, 2.0, 3.0]
        with pytest.raises(ValueError, match="ddof must be non-negative"):
            bayes.update_prior(observations, ddof=-1)

    def test_update_prior_ddof_bool_rejected(self):
        """Bool ddof must be rejected (bool is int subtype)."""
        bayes = BayesianPosterior()

        with pytest.raises(TypeError, match=r"ddof must be an integer.*bool"):
            bayes.update_prior([1.0, 2.0, 3.0], ddof=True)

    def test_update_prior_nan_observations_filtered(self):
        """Regression: NaN observations must not propagate into returned mean.

        Previously, NaN values in observations caused sum() to return NaN,
        which silently propagated into new_mean. Using the result as
        prior_mean for subsequent computations produced NaN gate results.
        """
        bayes = BayesianPosterior()

        # Mix of valid and NaN observations
        mean, std = bayes.update_prior([1.0, float("nan"), 3.0, float("nan")])
        assert math.isfinite(mean), f"mean must be finite, got {mean}"
        assert math.isfinite(std), f"std must be finite, got {std}"
        # Empirical mean of [1.0, 3.0] is 2.0, but weight=2/30 so prior (0.0)
        # dominates: new_mean ≈ 0.93*0 + 0.07*2 ≈ 0.13
        assert mean > 0.0  # Moved toward empirical mean

    def test_update_prior_all_nan_returns_prior(self):
        """All-NaN observations should return current prior unchanged."""
        bayes = BayesianPosterior(prior_mean=5.0, prior_std=2.0)

        mean, std = bayes.update_prior([float("nan"), float("nan")])
        assert mean == 5.0
        assert std == 2.0


class TestComplexityDecomposer:
    """Tests for ComplexityDecomposer."""

    def test_init_defaults(self):
        """Test default initialization."""
        decomposer = ComplexityDecomposer()
        assert decomposer.complexity_floor == 0.5
        assert decomposer.normalization_max == 100.0

    def test_analyze_basic(self):
        """Test basic complexity analysis."""
        decomposer = ComplexityDecomposer()

        metrics = {
            ComplexityMetric.CYCLOMATIC: 15,
            ComplexityMetric.COGNITIVE: 20,
            ComplexityMetric.COUPLING: 10,
        }

        result = decomposer.analyze(metrics)

        assert isinstance(result, ComplexityAnalysis)
        assert result.static_total >= 0
        assert result.dynamic_total >= 0
        assert 0 <= result.normalized <= 1

    def test_analyze_meets_floor(self):
        """Test meets_floor property."""
        decomposer = ComplexityDecomposer(complexity_floor=0.5)

        # High complexity should meet floor
        metrics = {
            ComplexityMetric.CYCLOMATIC: 60,
            ComplexityMetric.COGNITIVE: 70,
            ComplexityMetric.COUPLING: 50,
        }

        result = decomposer.analyze(metrics)
        assert result.meets_floor is True

    def test_compute_delta(self):
        """Test complexity delta computation."""
        decomposer = ComplexityDecomposer()

        baseline = ComplexityAnalysis(
            static_total=0.5,
            dynamic_total=0.3,
            combined_total=0.8,
            normalized=0.4,
            scores={},
            meets_floor=True,
        )

        proposed = ComplexityAnalysis(
            static_total=0.4,
            dynamic_total=0.2,
            combined_total=0.6,
            normalized=0.3,
            scores={},
            meets_floor=True,
        )

        delta = decomposer.compute_delta(baseline, proposed)

        # Use approximate comparison for floating point
        assert abs(delta["static_delta"] - (-0.1)) < 0.001
        assert abs(delta["dynamic_delta"] - (-0.1)) < 0.001
        assert abs(delta["total_delta"] - (-0.2)) < 0.001

    def test_compute_complexity_tax(self):
        """Test complexity tax calculation."""
        decomposer = ComplexityDecomposer()

        delta = {
            "static_delta": 0.1,
            "dynamic_delta": 0.05,
        }

        tax = decomposer.compute_complexity_tax(delta, phi_S=500, phi_D=10000)

        expected = 500 * 0.1 + 10000 * 0.05
        assert tax == expected

    def test_compute_complexity_tax_missing_static_key(self):
        """Test compute_complexity_tax raises KeyError for missing static_delta."""
        decomposer = ComplexityDecomposer()
        delta = {"dynamic_delta": 0.05}  # Missing static_delta

        with pytest.raises(KeyError, match=r"static_delta"):
            decomposer.compute_complexity_tax(delta)

    def test_compute_complexity_tax_missing_dynamic_key(self):
        """Test compute_complexity_tax raises KeyError for missing dynamic_delta."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1}  # Missing dynamic_delta

        with pytest.raises(KeyError, match=r"dynamic_delta"):
            decomposer.compute_complexity_tax(delta)

    def test_compute_complexity_tax_empty_dict(self):
        """Test compute_complexity_tax raises KeyError for empty dict."""
        decomposer = ComplexityDecomposer()

        with pytest.raises(KeyError, match=r"missing required keys"):
            decomposer.compute_complexity_tax({})

    def test_is_refactoring_eligible(self):
        """Test refactoring eligibility (negative delta)."""
        decomposer = ComplexityDecomposer()

        positive_delta = {"total_delta": 0.1}
        negative_delta = {"total_delta": -0.1}

        assert decomposer.is_refactoring_eligible(positive_delta) is False
        assert decomposer.is_refactoring_eligible(negative_delta) is True


class TestDriftMonitor:
    """Tests for DriftMonitor."""

    def test_init_defaults(self):
        """Test default initialization."""
        monitor = DriftMonitor()
        assert monitor.tau_warning == 0.3
        assert monitor.tau_critical == 0.5
        assert monitor.window_days == 30
        assert monitor.num_bins == 50

    def test_init_invalid_threshold_ordering_raises(self):
        """Test DriftMonitor raises ValueError when tau_warning >= tau_critical."""
        with pytest.raises(ValueError, match=r"tau_warning.*must be less than"):
            DriftMonitor(tau_warning=0.5, tau_critical=0.3)

        with pytest.raises(ValueError, match=r"tau_warning.*must be less than"):
            DriftMonitor(tau_warning=0.5, tau_critical=0.5)  # Equal values

    def test_init_num_bins_zero_raises(self):
        """Test DriftMonitor raises ValueError when num_bins <= 0 (M19 fix)."""
        with pytest.raises(ValueError, match=r"num_bins must be positive"):
            DriftMonitor(num_bins=0)

        with pytest.raises(ValueError, match=r"num_bins must be positive"):
            DriftMonitor(num_bins=-5)

    def test_init_epsilon_zero_raises(self):
        """Test DriftMonitor raises ValueError when epsilon <= 0 (M19 fix)."""
        with pytest.raises(ValueError, match=r"epsilon must be positive"):
            DriftMonitor(epsilon=0)

        with pytest.raises(ValueError, match=r"epsilon must be positive"):
            DriftMonitor(epsilon=-1e-10)

    def test_update_thresholds_invalid_ordering_raises(self):
        """Test update_thresholds validates tau_warning < tau_critical."""
        monitor = DriftMonitor()

        # Valid update should work
        monitor.update_thresholds(tau_warning=0.2, tau_critical=0.4)
        assert monitor.tau_warning == 0.2
        assert monitor.tau_critical == 0.4

        # Invalid update should raise
        with pytest.raises(ValueError, match=r"tau_warning.*must be less than"):
            monitor.update_thresholds(tau_warning=0.5, tau_critical=0.3)

        with pytest.raises(ValueError, match=r"tau_warning.*must be less than"):
            monitor.update_thresholds(tau_warning=0.4, tau_critical=0.4)

    def test_set_baseline(self):
        """Test baseline setting."""
        monitor = DriftMonitor()

        data = [0.1, 0.2, 0.3, 0.4, 0.5]
        hash_value = monitor.set_baseline(data)

        assert monitor.baseline_distribution is not None
        assert len(monitor.baseline_distribution) == monitor.num_bins
        assert monitor.baseline_hash == hash_value
        assert len(hash_value) == 64  # SHA-256 hex

    def test_set_baseline_empty_raises_valueerror(self):
        """Test set_baseline raises ValueError for empty data."""
        monitor = DriftMonitor()

        with pytest.raises(ValueError, match="Cannot set baseline with empty data"):
            monitor.set_baseline([])

    def test_set_baseline_inf_values_filtered(self):
        """Test set_baseline filters inf values from min/max computation."""
        monitor = DriftMonitor()
        hash_value = monitor.set_baseline([1.0, 2.0, float("inf")])
        assert monitor._baseline_min == 1.0
        assert monitor._baseline_max == 2.0
        assert hash_value is not None
        # Subsequent evaluate should not crash
        result = monitor.evaluate([1.5])
        assert result is not None

    def test_set_baseline_neg_inf_values_filtered(self):
        """Test set_baseline filters -inf values from min/max computation."""
        monitor = DriftMonitor()
        monitor.set_baseline([float("-inf"), 3.0, 5.0])
        assert monitor._baseline_min == 3.0
        assert monitor._baseline_max == 5.0

    def test_set_baseline_all_inf_raises_valueerror(self):
        """Test set_baseline raises ValueError when all values are non-finite."""
        monitor = DriftMonitor()
        with pytest.raises(ValueError, match="no finite values"):
            monitor.set_baseline([float("inf"), float("-inf")])

    def test_set_baseline_single_value_works(self):
        """Test set_baseline works with a single value."""
        monitor = DriftMonitor()

        hash_value = monitor.set_baseline([0.5])

        assert monitor.baseline_distribution is not None
        assert len(monitor.baseline_distribution) == monitor.num_bins
        assert monitor.baseline_hash == hash_value
        assert monitor._baseline_min == 0.5
        assert monitor._baseline_max == 0.5

    def test_evaluate_with_empty_current_window(self):
        """Test evaluate raises ValueError for empty current window (L4 fix)."""
        monitor = DriftMonitor()

        # Set up baseline
        monitor.set_baseline([0.1, 0.2, 0.3, 0.4, 0.5])

        # Empty current window should raise ValueError (L4 fix)
        with pytest.raises(
            ValueError, match=r"Cannot evaluate drift with empty current_window"
        ):
            monitor.evaluate([])

    def test_evaluate_no_baseline_raises(self):
        """Test evaluate raises without baseline."""
        monitor = DriftMonitor()

        with pytest.raises(ValueError, match="Baseline not set"):
            monitor.evaluate([0.1, 0.2, 0.3])

    def test_evaluate_normal(self):
        """Test evaluate returns NORMAL for similar distributions."""
        monitor = DriftMonitor()

        baseline = [0.1 + i * 0.01 for i in range(100)]
        current = [0.1 + i * 0.01 + 0.001 for i in range(100)]  # Slight shift

        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)

        assert isinstance(result, DriftResult)
        assert result.status == DriftStatus.NORMAL
        assert result.action == DriftAction.CONTINUE

    def test_evaluate_critical(self):
        """Test evaluate returns CRITICAL for very different distributions."""
        monitor = DriftMonitor(tau_warning=0.1, tau_critical=0.2)

        # Baseline: uniform distribution (spread across range)
        baseline = [i / 100 for i in range(100)]  # 0.00 to 0.99 uniform
        # Current: bimodal distribution (concentrated at extremes)
        current = [0.1] * 50 + [0.9] * 50  # Very different shape

        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)

        # With such different distribution shapes, KL divergence should exceed thresholds
        assert result.kl_divergence > monitor.tau_critical
        assert result.status == DriftStatus.CRITICAL
        assert result.action == DriftAction.HALT_AND_RECALIBRATE

    def test_evaluate_detects_range_shift(self):
        """Test drift detects large range shift even with similar shape."""
        monitor = DriftMonitor(tau_warning=0.1, tau_critical=0.2)

        # Baseline: uniform-ish across a small range near 0
        baseline = [i / 100 for i in range(100)]
        # Current: same shape, shifted far outside baseline range
        current = [100 + (i / 100) for i in range(100)]

        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)

        assert result.kl_divergence > monitor.tau_critical
        assert result.status == DriftStatus.CRITICAL

    def test_calibrate_thresholds(self, sample_kl_values):
        """Test threshold calibration from historical values."""
        monitor = DriftMonitor()

        tau_warning, tau_critical = monitor.calibrate_thresholds(
            sample_kl_values,
            warning_percentile=90,
            critical_percentile=99,
        )

        # Should be within range of input values
        assert tau_warning >= min(sample_kl_values)
        assert tau_critical >= tau_warning

    def test_calibrate_thresholds_uses_nearest_rank(self):
        """Test percentile index uses nearest-rank (not inclusive upper bound)."""
        monitor = DriftMonitor()

        historical = list(range(10))  # 0..9
        tau_warning, tau_critical = monitor.calibrate_thresholds(
            historical,
            warning_percentile=90,
            critical_percentile=99,
        )

        assert tau_warning == 8
        assert tau_critical == 9

    def test_calibrate_thresholds_all_nan_returns_original(self):
        """Regression: all-NaN calibration data must not produce NaN thresholds."""
        monitor = DriftMonitor(tau_warning=0.3, tau_critical=0.5)

        tau_warning, tau_critical = monitor.calibrate_thresholds(
            [float("nan"), float("nan")]
        )

        assert tau_warning == 0.3
        assert tau_critical == 0.5
        assert math.isfinite(tau_warning)
        assert math.isfinite(tau_critical)

    def test_update_thresholds(self):
        """Test threshold update."""
        monitor = DriftMonitor()

        monitor.update_thresholds(tau_warning=0.25, tau_critical=0.45)

        assert monitor.tau_warning == 0.25
        assert monitor.tau_critical == 0.45

    def test_histogram_normalization(self):
        """Test histogram sums to 1."""
        monitor = DriftMonitor()

        data = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
        hist = monitor._to_histogram(data)

        total = sum(hist)
        assert abs(total - 1.0) < 0.001

    def test_kl_divergence_self(self):
        """Test KL divergence of distribution with itself is ~0."""
        monitor = DriftMonitor()

        p = [0.25, 0.25, 0.25, 0.25]
        kl = monitor._compute_kl_divergence(p, p)

        assert kl < 0.001  # Should be very close to 0

    def test_evaluate_warning(self):
        """Test evaluate returns WARNING for moderately different distributions."""
        monitor = DriftMonitor(tau_warning=0.1, tau_critical=0.5)

        # Baseline: uniform distribution
        baseline = [i / 100 for i in range(100)]
        # Current: slightly skewed distribution
        current = [0.3] * 40 + [0.7] * 60  # Slightly different

        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)

        # Should detect some drift
        assert result.kl_divergence > 0


class TestUtilityAdvanced:
    """Additional utility calculator tests."""

    def test_three_point_estimate_properties(self):
        """Test ThreePointEstimate properties."""
        estimate = ThreePointEstimate(best=0, likely=50, worst=100)

        # Expected value should be around 50
        assert 40 < estimate.expected < 60
        # Variance should be positive
        assert estimate.variance > 0

    def test_three_point_estimate_std_dev(self):
        """Test ThreePointEstimate std_dev property."""
        import math

        estimate = ThreePointEstimate(best=100, likely=150, worst=200)

        expected_var = ((200 - 100) / 6) ** 2
        expected_std = math.sqrt(expected_var)

        assert abs(estimate.std_dev - expected_std) < 0.001

    def test_calculate_with_high_complexity(self):
        """Test utility with high complexity."""
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=1000, likely=3000, worst=5000)
        risk = ThreePointEstimate(best=-0.1, likely=0, worst=0.1)
        complexity = ComplexityBreakdown(static=0.8, dynamic=0.7)  # High

        result = calc.calculate(profit, risk, complexity)

        assert isinstance(result, UtilityResult)
        # High complexity should reduce utility
        assert result.raw < profit.expected

    def test_utility_lcb_calculation(self):
        """Test LCB is lower than raw utility."""
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=3000, likely=7000, worst=10000)
        risk = ThreePointEstimate(best=-0.2, likely=-0.1, worst=0)
        complexity = ComplexityBreakdown(static=0.2, dynamic=0.1)

        result = calc.calculate(profit, risk, complexity)

        # LCB should always be lower than raw
        assert result.lcb <= result.raw


class TestUtilityComponents:
    """Tests for UtilityComponents properties."""

    def test_gross_value(self):
        """Test gross_value property."""
        from engine.utility import UtilityComponents

        components = UtilityComponents(
            profit_high_conf=1000,
            value_low_conf=200,
            risk_adjustment=50,
            complexity_tax=100,
            opex_delta=30,
        )

        assert components.gross_value == 1250  # 1000 + 200 + 50

    def test_total_cost(self):
        """Test total_cost property."""
        from engine.utility import UtilityComponents

        components = UtilityComponents(
            profit_high_conf=1000,
            value_low_conf=200,
            risk_adjustment=50,
            complexity_tax=100,
            opex_delta=30,
        )

        assert components.total_cost == 130  # 100 + 30


class TestUtilityResultProperties:
    """Tests for UtilityResult properties."""

    def test_std_dev(self):
        """Test UtilityResult std_dev property."""
        from engine.utility import UtilityComponents

        result = UtilityResult(
            raw=1000,
            variance=400,  # 20^2
            lcb=900,
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="INVESTMENT",
        )

        assert result.std_dev == 20.0  # sqrt(400)


class TestZScoreCalculation:
    """Tests for z-score calculation using continuous scipy.stats.norm.ppf.

    L3 fix: Now uses continuous z-score computation instead of discrete thresholds.
    Values are verified against scipy.stats.norm.ppf() with approximate comparison.
    """

    def test_z_score_95_confidence(self):
        """Test z-score for 95% confidence (norm.ppf(0.95) ≈ 1.6449)."""
        calc = UtilityCalculator(lcb_alpha=0.05)  # 95% confidence
        assert abs(calc.z_alpha - 1.6449) < 0.001

    def test_z_score_90_confidence(self):
        """Test z-score for 90% confidence (norm.ppf(0.90) ≈ 1.2816)."""
        calc = UtilityCalculator(lcb_alpha=0.10)  # 90% confidence
        assert abs(calc.z_alpha - 1.2816) < 0.001

    def test_z_score_80_confidence(self):
        """Test z-score for 80% confidence (norm.ppf(0.80) ≈ 0.8416)."""
        calc = UtilityCalculator(lcb_alpha=0.20)  # 80% confidence
        assert abs(calc.z_alpha - 0.8416) < 0.001

    def test_z_score_low_confidence(self):
        """Test z-score for 70% confidence (norm.ppf(0.70) ≈ 0.5244)."""
        calc = UtilityCalculator(lcb_alpha=0.30)  # 70% confidence
        assert abs(calc.z_alpha - 0.5244) < 0.001

    def test_z_score_invalid_zero_confidence(self):
        """Test that lcb_alpha=1.0 raises ValueError (validated at construction)."""
        with pytest.raises(ValueError, match=r"lcb_alpha must be in \(0\.0, 1\.0\)"):
            UtilityCalculator(lcb_alpha=1.0)  # Invalid: boundary value

    def test_z_score_invalid_one_confidence(self):
        """Test that lcb_alpha=0.0 raises ValueError (validated at construction)."""
        with pytest.raises(ValueError, match=r"lcb_alpha must be in \(0\.0, 1\.0\)"):
            UtilityCalculator(lcb_alpha=0.0)  # Invalid: boundary value

    def test_lcb_alpha_nan_rejected(self):
        """NaN lcb_alpha must be rejected at construction, not silently propagate (BH11-L1)."""
        with pytest.raises(ValueError, match=r"lcb_alpha must be in \(0\.0, 1\.0\)"):
            UtilityCalculator(lcb_alpha=float("nan"))


class TestRefactoringPath:
    """Additional tests for refactoring path."""

    def test_check_refactoring_path_not_refactoring(self):
        """Test check_refactoring_path returns False for investment path."""
        from engine.utility import UtilityComponents

        calc = UtilityCalculator()

        result = UtilityResult(
            raw=1000,
            variance=100,
            lcb=900,
            components=UtilityComponents(1000, 100, 50, 100, 50),
            decision_path="INVESTMENT",  # Not refactoring
        )

        assert calc.check_refactoring_path(result) is False


class TestComplexityBreakdown:
    """Tests for ComplexityBreakdown."""

    def test_total_property(self):
        """Test ComplexityBreakdown total property."""
        breakdown = ComplexityBreakdown(static=0.3, dynamic=0.2)
        assert breakdown.total == 0.5

    def test_negative_complexity_refactoring(self):
        """Test negative complexity triggers refactoring path."""
        breakdown = ComplexityBreakdown(static=-0.2, dynamic=-0.1)
        assert abs(breakdown.total - (-0.3)) < 0.001  # Use approx comparison


class TestKappaEffective:
    """Tests for kappa effective calculation (risk coefficient)."""

    def test_kappa_effective_positive_risk(self):
        """Test kappa is 0 when risk increases."""
        calc = UtilityCalculator(kappa=1.0)

        profit = ThreePointEstimate(best=500, likely=800, worst=1000)
        risk = ThreePointEstimate(
            best=0.1, likely=0.2, worst=0.3
        )  # Positive = increase
        complexity = ComplexityBreakdown(static=0.1, dynamic=0.05)

        result = calc.calculate(profit, risk, complexity)

        # Risk term should be 0 (kappa_effective = 0 for positive risk)
        assert result.components is not None
        assert result.components.risk_adjustment == 0.0

    def test_kappa_effective_negative_risk(self):
        """Test kappa applies when risk decreases."""
        calc = UtilityCalculator(kappa=1.0)

        profit = ThreePointEstimate(best=500, likely=800, worst=1000)
        risk = ThreePointEstimate(
            best=-0.3, likely=-0.2, worst=-0.1
        )  # Negative = decrease
        complexity = ComplexityBreakdown(static=0.1, dynamic=0.05)

        result = calc.calculate(profit, risk, complexity)

        # Risk term should be negative (reward for reducing risk)
        assert result.components is not None
        assert result.components.risk_adjustment < 0


class TestPosteriorPredictive:
    """Tests for posterior predictive distribution (ADR-006)."""

    def test_compute_posterior_predictive_exists(self):
        """Test compute_posterior_predictive method exists and works."""
        bayes = BayesianPosterior()

        prob = bayes.compute_posterior_predictive(
            observed_delta=1.5,
            trigger_threshold=2.0,
        )

        assert 0 <= prob <= 1

    def test_posterior_vs_predictive_difference(self):
        """Test predictive is more conservative (lower probability).

        With observed_delta > threshold, posterior probability P(θ ≥ t) > 0.5.
        The posterior predictive has larger std, so the z-score is smaller,
        meaning the CDF is closer to 0.5, resulting in lower tail probability.
        """
        bayes = BayesianPosterior()

        # Use a delta clearly above threshold so probability > 0.5
        # and predictive (larger std) gives lower probability
        p_post = bayes.compute_posterior(
            observed_delta=3.0,  # Well above threshold
            trigger_threshold=2.0,
            use_predictive=False,
        )

        p_pred = bayes.compute_posterior(
            observed_delta=3.0,
            trigger_threshold=2.0,
            use_predictive=True,
        )

        # Both should be > 0.5 since observed > threshold
        assert p_post > 0.5
        assert p_pred > 0.5
        # Predictive should be lower (more conservative) because
        # larger σ_pred brings probability closer to 0.5
        assert p_pred < p_post

    def test_predictive_std_larger_than_posterior_std(self):
        """Test posterior predictive std is always larger than posterior std."""
        bayes = BayesianPosterior()

        result = bayes.compute_full(
            observed_delta=1.5,
            trigger_threshold=2.0,
        )

        assert result.predictive_std is not None
        assert result.predictive_std > result.posterior_std

    def test_predictive_std_formula(self):
        """Test σ_pred = √(σ_post² + σ_L²)."""
        import math

        bayes = BayesianPosterior(likelihood_std=0.5)

        result = bayes.compute_full(
            observed_delta=1.5,
            trigger_threshold=2.0,
        )

        assert result.predictive_std is not None
        expected_pred_std = math.sqrt(result.posterior_std**2 + 0.5**2)
        assert abs(result.predictive_std - expected_pred_std) < 0.0001

    def test_compute_full_with_predictive_mode(self):
        """Test compute_full uses predictive std when use_predictive=True."""
        bayes = BayesianPosterior()

        # Use a delta well above threshold so probability > 0.5
        result_post = bayes.compute_full(
            observed_delta=3.0,
            trigger_threshold=2.0,
            use_predictive=False,
        )

        result_pred = bayes.compute_full(
            observed_delta=3.0,
            trigger_threshold=2.0,
            use_predictive=True,
        )

        # Same mean and stds
        assert result_post.posterior_mean == result_pred.posterior_mean
        assert result_post.posterior_std == result_pred.posterior_std
        assert result_post.predictive_std == result_pred.predictive_std

        # Both should be > 0.5 since observed > threshold
        assert result_post.probability > 0.5
        assert result_pred.probability > 0.5

        # Different probability (predictive is more conservative)
        assert result_pred.probability < result_post.probability

    def test_backward_compatibility(self):
        """Test default behavior unchanged (use_predictive=False)."""
        bayes = BayesianPosterior()

        # These should be identical
        p1 = bayes.compute_posterior(1.5, 2.0)
        p2 = bayes.compute_posterior(1.5, 2.0, use_predictive=False)

        assert p1 == p2


class TestBayesianInputValidation:
    """Tests for input validation in BayesianPosterior."""

    def test_zero_prior_std_raises_error(self):
        """Test zero prior_std raises ValueError."""
        with pytest.raises(ValueError, match="prior_std must be positive"):
            BayesianPosterior(prior_std=0.0)

    def test_negative_prior_std_raises_error(self):
        """Test negative prior_std raises ValueError."""
        with pytest.raises(ValueError, match="prior_std must be positive"):
            BayesianPosterior(prior_std=-1.0)

    def test_zero_likelihood_std_raises_error(self):
        """Test zero likelihood_std raises ValueError."""
        with pytest.raises(ValueError, match="likelihood_std must be positive"):
            BayesianPosterior(likelihood_std=0.0)

    def test_negative_likelihood_std_raises_error(self):
        """Test negative likelihood_std raises ValueError."""
        with pytest.raises(ValueError, match="likelihood_std must be positive"):
            BayesianPosterior(likelihood_std=-0.5)

    def test_compute_posterior_zero_override_std_raises(self):
        """Test compute_posterior with zero override std raises ValueError."""
        bayes = BayesianPosterior()

        with pytest.raises(ValueError, match="prior_std must be positive"):
            bayes.compute_posterior(1.0, 2.0, prior_std=0.0)

        with pytest.raises(ValueError, match="likelihood_std must be positive"):
            bayes.compute_posterior(1.0, 2.0, likelihood_std=0.0)

    def test_compute_full_zero_override_std_raises(self):
        """Test compute_full with zero override std raises ValueError."""
        bayes = BayesianPosterior()

        with pytest.raises(ValueError, match="prior_std must be positive"):
            bayes.compute_full(1.0, 2.0, prior_std=0.0)

        with pytest.raises(ValueError, match="likelihood_std must be positive"):
            bayes.compute_full(1.0, 2.0, likelihood_std=0.0)

    def test_very_small_valid_std(self):
        """Test very small but valid std values work correctly."""
        # Very small but valid std
        bayes = BayesianPosterior(prior_std=1e-6, likelihood_std=1e-6)
        result = bayes.compute_posterior(1.0, 2.0)

        # Should return a valid probability
        assert 0.0 <= result <= 1.0


class TestCovarianceSupport:
    """Tests for covariance matrix support in utility calculation (U1+)."""

    def test_covariance_positive_increases_variance(self):
        """Test positive covariance increases variance."""
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=5000, likely=8000, worst=10000)
        risk = ThreePointEstimate(best=-0.3, likely=-0.2, worst=-0.1)
        complexity = ComplexityBreakdown(static=0.1, dynamic=0.05)

        # Without covariance
        result_no_cov = calc.calculate(
            profit, risk, complexity, value_low_conf=1000, value_variance=100
        )

        # With positive covariance between profit and value
        result_with_cov = calc.calculate(
            profit,
            risk,
            complexity,
            value_low_conf=1000,
            value_variance=100,
            cov_pv=50.0,  # Positive covariance
        )

        # Positive covariance should increase variance
        assert result_with_cov.variance > result_no_cov.variance

    def test_covariance_negative_decreases_variance(self):
        """Test negative covariance decreases variance."""
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=5000, likely=8000, worst=10000)
        risk = ThreePointEstimate(best=-0.3, likely=-0.2, worst=-0.1)
        complexity = ComplexityBreakdown(static=0.1, dynamic=0.05)

        # Without covariance
        result_no_cov = calc.calculate(
            profit, risk, complexity, value_low_conf=1000, value_variance=100
        )

        # With negative covariance
        result_with_cov = calc.calculate(
            profit,
            risk,
            complexity,
            value_low_conf=1000,
            value_variance=100,
            cov_pv=-10.0,  # Small negative covariance
        )

        # Negative covariance should decrease variance
        assert result_with_cov.variance < result_no_cov.variance

    def test_covariance_backward_compatible(self):
        """Test None covariances give same result as before."""
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=5000, likely=8000, worst=10000)
        risk = ThreePointEstimate(best=-0.3, likely=-0.2, worst=-0.1)
        complexity = ComplexityBreakdown(static=0.1, dynamic=0.05)

        # Explicit None (default)
        result1 = calc.calculate(
            profit,
            risk,
            complexity,
            value_low_conf=1000,
            value_variance=100,
            cov_pv=None,
            cov_pr=None,
            cov_vr=None,
        )

        # Implicit None (not provided)
        result2 = calc.calculate(
            profit, risk, complexity, value_low_conf=1000, value_variance=100
        )

        assert result1.variance == result2.variance
        assert result1.raw == result2.raw
        assert result1.lcb == result2.lcb

    def test_covariance_factor_of_2(self):
        """Test covariance term has factor of 2 per variance formula."""
        calc = UtilityCalculator(gamma=1.0)  # gamma=1 simplifies calculation

        profit = ThreePointEstimate(best=100, likely=100, worst=100)  # Zero variance
        risk = ThreePointEstimate(best=0.0, likely=0.0, worst=0.0)  # Zero variance
        complexity = ComplexityBreakdown(static=0, dynamic=0)

        # With value_variance=100 and cov_pv=10
        # Variance should be: 0 + 1²*100 + 0 + 2*1*10 = 100 + 20 = 120
        result = calc.calculate(
            profit,
            risk,
            complexity,
            value_low_conf=100,
            value_variance=100,
            cov_pv=10.0,
        )

        # Factor of 2 means cov_pv=10 adds 20 to variance
        expected_variance = 100 + 2 * 10
        assert abs(result.variance - expected_variance) < 0.001

    def test_variance_floor_at_zero(self):
        """Test variance cannot go negative from large negative covariance."""
        calc = UtilityCalculator()

        profit = ThreePointEstimate(best=100, likely=100, worst=100)
        risk = ThreePointEstimate(best=0.0, likely=0.0, worst=0.0)
        complexity = ComplexityBreakdown(static=0, dynamic=0)

        # Very large negative covariance that would make variance negative
        result = calc.calculate(
            profit,
            risk,
            complexity,
            value_low_conf=100,
            value_variance=10,
            cov_pv=-1000.0,  # Would make variance negative
        )

        # Variance should be floored at 0
        assert result.variance >= 0.0


# =============================================================================
# Codex Bug Hunt v3.21.0 Regression Tests
# =============================================================================


class TestBayesianEffectiveStdClamping:
    """Regression tests for Bayesian effective_std clamping (Codex HIGH bug)."""

    def test_effective_std_clamped_with_near_zero_std(self):
        """Test that effective_std is clamped to prevent ZeroDivisionError.

        Codex Bug: bayesian.py:174 - effective_std could be very small
        due to numerical precision, causing ZeroDivisionError.
        """
        # Use very small std values that could cause numerical issues
        bayes = BayesianPosterior(
            prior_mean=0.0,
            prior_std=1e-12,  # Very small but valid
            likelihood_std=1e-12,  # Very small but valid
        )

        # This should not raise ZeroDivisionError
        prob = bayes.compute_posterior(
            observed_delta=0.0,
            trigger_threshold=0.0,
        )

        # Result should be a valid probability
        assert 0.0 <= prob <= 1.0

    def test_effective_std_clamped_in_compute_full(self):
        """Test effective_std clamping also works in compute_full."""
        bayes = BayesianPosterior(
            prior_mean=0.0,
            prior_std=1e-12,
            likelihood_std=1e-12,
        )

        # This should not raise ZeroDivisionError
        result = bayes.compute_full(
            observed_delta=0.0,
            trigger_threshold=0.0,
        )

        assert isinstance(result, PosteriorResult)
        assert 0.0 <= result.probability <= 1.0


# =============================================================================
# Minor Bug Fixes v3.23.0 Regression Tests
# =============================================================================


class TestBayesianPriorWeightThreshold:
    """Regression tests for _PRIOR_WEIGHT_THRESHOLD constant (L3 fix)."""

    def test_prior_weight_threshold_constant_exists(self):
        """Test that _PRIOR_WEIGHT_THRESHOLD constant is defined."""
        assert hasattr(BayesianPosterior, "_PRIOR_WEIGHT_THRESHOLD")
        assert BayesianPosterior._PRIOR_WEIGHT_THRESHOLD == 30

    def test_update_prior_uses_threshold_constant(self):
        """Test that update_prior uses the threshold constant correctly.

        At n=30 observations, weight should be 1.0 (full empirical weight).
        At n=15 observations, weight should be 0.5.
        """
        bayes = BayesianPosterior(prior_mean=0.0, prior_std=1.0)

        # With 30 observations, full weight to empirical
        observations = [1.0] * 30
        new_mean, _ = bayes.update_prior(observations)
        # Should be close to empirical mean (1.0)
        assert abs(new_mean - 1.0) < 0.01

        # With 15 observations (half threshold), half weight
        observations = [2.0] * 15
        new_mean, _ = bayes.update_prior(observations)
        # Should be blend of prior (0.0) and empirical (2.0)
        # weight = 15/30 = 0.5, so new_mean = 0.5 * 0.0 + 0.5 * 2.0 = 1.0
        assert abs(new_mean - 1.0) < 0.01


class TestComplexityRefactoringEligibleValidation:
    """Regression tests for is_refactoring_eligible validation (L4 fix)."""

    def test_is_refactoring_eligible_missing_key_raises(self):
        """Test that missing 'total_delta' key raises KeyError.

        L4 fix: Added validation for required dict key.
        """
        decomposer = ComplexityDecomposer()

        with pytest.raises(KeyError, match="total_delta"):
            decomposer.is_refactoring_eligible({})

    def test_is_refactoring_eligible_partial_dict_raises(self):
        """Test that partial dict without total_delta raises KeyError."""
        decomposer = ComplexityDecomposer()

        with pytest.raises(KeyError, match="total_delta"):
            decomposer.is_refactoring_eligible({"static_delta": -0.1})

    def test_is_refactoring_eligible_valid_dict_works(self):
        """Test that valid delta dict works correctly."""
        decomposer = ComplexityDecomposer()

        # Negative total_delta = refactoring eligible
        delta = {"static_delta": -0.1, "dynamic_delta": -0.05, "total_delta": -0.15}
        assert decomposer.is_refactoring_eligible(delta) is True

        # Positive total_delta = not eligible
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05, "total_delta": 0.15}
        assert decomposer.is_refactoring_eligible(delta) is False


class TestDriftCalibrateThresholdsValidation:
    """Regression tests for calibrate_thresholds validation (L5 fix)."""

    def test_calibrate_thresholds_invalid_returns_original(self):
        """Test that invalid thresholds (warning >= critical) returns originals.

        L5 fix: Added validation to prevent invalid threshold ordering.
        """
        monitor = DriftMonitor(tau_warning=0.3, tau_critical=0.5)

        # With very few identical values, percentiles may produce invalid ordering
        # (both P90 and P99 would be the same value)
        historical_kl = [0.2, 0.2, 0.2]  # All same value

        tau_warning, tau_critical = monitor.calibrate_thresholds(historical_kl)

        # Should return original thresholds, not invalid computed ones
        assert tau_warning == 0.3
        assert tau_critical == 0.5

    def test_calibrate_thresholds_valid_returns_computed(self):
        """Test that valid computed thresholds are returned."""
        monitor = DriftMonitor(tau_warning=0.3, tau_critical=0.5)

        # Properly spread values should produce valid ordering
        historical_kl = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.6]

        tau_warning, tau_critical = monitor.calibrate_thresholds(historical_kl)

        # Should return computed thresholds
        assert tau_warning < tau_critical


class TestComplexityDecomposerValidation:
    """Regression tests for ComplexityDecomposer input validation."""

    @pytest.mark.parametrize("bad_floor", [True, False])
    def test_complexity_floor_bool_rejected(self, bad_floor):
        """Bool complexity_floor must be rejected (bool is int in Python)."""
        with pytest.raises(
            TypeError, match="complexity_floor must be numeric, got bool"
        ):
            ComplexityDecomposer(complexity_floor=bad_floor)

    def test_complexity_floor_negative_raises(self):
        """Test that negative complexity_floor raises ValueError."""
        with pytest.raises(ValueError, match="complexity_floor must be in"):
            ComplexityDecomposer(complexity_floor=-0.1)

    def test_complexity_floor_above_one_raises(self):
        """Test that complexity_floor > 1.0 raises ValueError."""
        with pytest.raises(ValueError, match="complexity_floor must be in"):
            ComplexityDecomposer(complexity_floor=1.5)

    def test_normalization_max_negative_raises(self):
        """Test that negative normalization_max raises ValueError."""
        with pytest.raises(ValueError, match="normalization_max must be positive"):
            ComplexityDecomposer(normalization_max=-1.0)

    def test_normalization_max_zero_raises(self):
        """Test that zero normalization_max raises ValueError."""
        with pytest.raises(ValueError, match="normalization_max must be positive"):
            ComplexityDecomposer(normalization_max=0.0)

    def test_valid_parameters_accepted(self):
        """Test that valid parameters are accepted."""
        decomposer = ComplexityDecomposer(complexity_floor=0.3, normalization_max=200.0)
        assert decomposer.complexity_floor == 0.3
        assert decomposer.normalization_max == 200.0

    def test_complexity_floor_nan_rejected(self):
        """BH12: NaN complexity_floor must be rejected (check_nan=True)."""
        with pytest.raises(ValueError, match="complexity_floor"):
            ComplexityDecomposer(complexity_floor=float("nan"))

    def test_analyze_nan_metric_rejected(self):
        """BH12: NaN metric values must be rejected, not silently treated as 1.0."""
        decomposer = ComplexityDecomposer()
        with pytest.raises(ValueError, match="non-finite"):
            decomposer.analyze({ComplexityMetric.CYCLOMATIC: float("nan")})

    def test_analyze_inf_metric_rejected(self):
        """BH12: Inf metric values must be rejected."""
        decomposer = ComplexityDecomposer()
        with pytest.raises(ValueError, match="non-finite"):
            decomposer.analyze({ComplexityMetric.CYCLOMATIC: float("inf")})


class TestDriftResultRepr:
    """Regression tests for DriftResult __repr__."""

    def test_drift_result_repr(self):
        """Test DriftResult repr shows key fields."""
        result = DriftResult(
            status=DriftStatus.WARNING,
            kl_divergence=0.35,
            action=DriftAction.ALERT_AND_CONTINUE,
            baseline_hash="abc123",
            window_size=30,
        )
        r = repr(result)
        assert "warning" in r
        assert "0.3500" in r
        assert "alert_and_continue" in r


class TestComplexityAnalysisRepr:
    """Regression tests for ComplexityAnalysis __repr__."""

    def test_complexity_analysis_repr_meets_floor(self):
        """Test ComplexityAnalysis repr when meeting floor."""
        analysis = ComplexityAnalysis(
            static_total=0.5,
            dynamic_total=0.5,
            combined_total=1.0,
            normalized=0.5,
            scores={},
            meets_floor=True,
        )
        r = repr(analysis)
        assert "MEETS_FLOOR" in r
        assert "0.500" in r

    def test_complexity_analysis_repr_below_floor(self):
        """Test ComplexityAnalysis repr when below floor."""
        analysis = ComplexityAnalysis(
            static_total=0.2,
            dynamic_total=0.1,
            combined_total=0.3,
            normalized=0.15,
            scores={},
            meets_floor=False,
        )
        r = repr(analysis)
        assert "BELOW_FLOOR" in r


class TestGateResultRepr:
    """Regression tests for GateResult and GateEvaluationResult __repr__."""

    def test_gate_result_repr_pass(self):
        """Test GateResult repr for passing gate."""
        result = GateResult(
            gate_type=GateType.RISK,
            passed=True,
            value=0.5,
            threshold=0.95,
        )
        r = repr(result)
        assert "risk" in r
        assert "PASS" in r

    def test_gate_result_repr_fail(self):
        """Test GateResult repr for failing gate."""
        result = GateResult(
            gate_type=GateType.QUALITY,
            passed=False,
            value=0.4,
            threshold=0.7,
        )
        r = repr(result)
        assert "quality" in r
        assert "FAIL" in r


# =============================================================================
# B2-4, B2-10, L47 Validation Bug Fixes (v3.32.0)
# =============================================================================


class TestTriggerFactorValidation:
    """Regression tests for trigger_factor validation in GateEvaluator (B2-4 fix)."""

    def test_trigger_factor_normal_range_no_warning(self, caplog):
        """Test trigger_factor in normal range [-10, 10] produces no warning."""
        import logging

        with caplog.at_level(logging.WARNING):
            evaluator = GateEvaluator(
                risk_trigger_factor=2.0,
                profit_trigger_factor=-2.0,  # Negative is allowed (inverts logic)
            )

        # No warnings should be logged
        assert len(caplog.records) == 0
        assert evaluator.risk_trigger_factor == 2.0
        assert evaluator.profit_trigger_factor == -2.0

    def test_trigger_factor_extreme_positive_warns(self, caplog):
        """Test trigger_factor > 10 logs a warning."""
        import logging

        with caplog.at_level(logging.WARNING):
            evaluator = GateEvaluator(
                risk_trigger_factor=15.0,  # Outside [-10, 10]
            )

        assert len(caplog.records) == 1
        assert "risk_trigger_factor=15.0" in caplog.text
        assert "outside recommended range" in caplog.text
        assert evaluator.risk_trigger_factor == 15.0  # Still set

    def test_trigger_factor_extreme_negative_warns(self, caplog):
        """Test trigger_factor < -10 logs a warning."""
        import logging

        with caplog.at_level(logging.WARNING):
            GateEvaluator(
                profit_trigger_factor=-20.0,  # Outside [-10, 10]
            )

        assert len(caplog.records) == 1
        assert "profit_trigger_factor=-20.0" in caplog.text
        assert "outside recommended range" in caplog.text

    def test_trigger_factor_boundary_values_no_warning(self, caplog):
        """Test trigger_factor at boundaries [-10, 10] produces no warning."""
        import logging

        with caplog.at_level(logging.WARNING):
            GateEvaluator(
                risk_trigger_factor=-10.0,  # Exactly at boundary
                profit_trigger_factor=10.0,  # Exactly at boundary
            )

        assert len(caplog.records) == 0

    def test_negative_trigger_factor_inverts_gate_logic(self):
        """Test negative trigger_factor can be used to invert gate logic.

        With positive trigger_factor=2.0, the gate triggers on risk increases >= 2x.
        With negative trigger_factor=-2.0, the gate should trigger on risk decreases.
        """
        # Positive trigger: fails on 4x increase
        pos_evaluator = GateEvaluator(risk_trigger_factor=2.0)
        result_pos = pos_evaluator.evaluate_risk_gate(baseline=1.0, proposed=5.0)
        assert result_pos.passed is False  # Large increase triggers failure

        # Negative trigger: different behavior for same data
        # This test confirms the evaluator accepts negative values
        neg_evaluator = GateEvaluator(risk_trigger_factor=-2.0)
        neg_evaluator.evaluate_risk_gate(baseline=1.0, proposed=5.0)


class TestUtilityComplexityValidation:
    """Regression tests for complexity validation in UtilityCalculator.calculate() (B2-10 fix)."""

    def test_complexity_normal_range_no_warning(self, caplog):
        """Test complexity in normal range [-1, 1] produces no warning."""
        import logging

        calc = UtilityCalculator()
        profit = ThreePointEstimate(best=1000, likely=2000, worst=3000)
        risk = ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1)
        complexity = ComplexityBreakdown(static=0.5, dynamic=0.3)  # Normal range

        with caplog.at_level(logging.WARNING):
            result = calc.calculate(profit, risk, complexity)

        assert len(caplog.records) == 0
        assert result.raw is not None

    def test_complexity_extreme_static_warns(self, caplog):
        """Test complexity.static outside [-2, 2] logs a warning."""
        import logging

        calc = UtilityCalculator()
        profit = ThreePointEstimate(best=1000, likely=2000, worst=3000)
        risk = ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1)
        complexity = ComplexityBreakdown(static=5.0, dynamic=0.3)  # static > 2

        with caplog.at_level(logging.WARNING):
            result = calc.calculate(profit, risk, complexity)

        assert len(caplog.records) == 1
        assert "complexity.static=5.0" in caplog.text
        assert "outside expected range" in caplog.text
        assert result.raw is not None  # Calculation still proceeds

    def test_complexity_extreme_dynamic_warns(self, caplog):
        """Test complexity.dynamic outside [-2, 2] logs a warning."""
        import logging

        calc = UtilityCalculator()
        profit = ThreePointEstimate(best=1000, likely=2000, worst=3000)
        risk = ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1)
        complexity = ComplexityBreakdown(static=0.3, dynamic=-3.0)  # dynamic < -2

        with caplog.at_level(logging.WARNING):
            calc.calculate(profit, risk, complexity)

        assert len(caplog.records) == 1
        assert "complexity.dynamic=-3.0" in caplog.text
        assert "outside expected range" in caplog.text

    def test_complexity_both_extreme_warns_twice(self, caplog):
        """Test both complexity values outside range logs two warnings."""
        import logging

        calc = UtilityCalculator()
        profit = ThreePointEstimate(best=1000, likely=2000, worst=3000)
        risk = ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1)
        complexity = ComplexityBreakdown(static=10.0, dynamic=-10.0)  # Both extreme

        with caplog.at_level(logging.WARNING):
            calc.calculate(profit, risk, complexity)

        assert len(caplog.records) == 2

    def test_complexity_boundary_values_no_warning(self, caplog):
        """Test complexity at boundaries [-2, 2] produces no warning."""
        import logging

        calc = UtilityCalculator()
        profit = ThreePointEstimate(best=1000, likely=2000, worst=3000)
        risk = ThreePointEstimate(best=-0.1, likely=0.0, worst=0.1)
        complexity = ComplexityBreakdown(static=2.0, dynamic=-2.0)  # At boundaries

        with caplog.at_level(logging.WARNING):
            calc.calculate(profit, risk, complexity)

        assert len(caplog.records) == 0


class TestPhiUpperBoundValidation:
    """Regression tests for phi_S/phi_D upper bound validation (L47 fix)."""

    def test_phi_s_normal_range_accepted(self):
        """Test phi_S in normal range [0, 10000] is accepted."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}

        # Normal value
        tax = decomposer.compute_complexity_tax(delta, phi_S=500, phi_D=5000)
        assert tax == 500 * 0.1 + 5000 * 0.05

    def test_phi_s_at_upper_bound_accepted(self):
        """Test phi_S at upper bound (10000) is accepted."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}

        tax = decomposer.compute_complexity_tax(delta, phi_S=10000, phi_D=5000)
        assert tax == 10000 * 0.1 + 5000 * 0.05

    def test_phi_s_above_upper_bound_raises(self):
        """Test phi_S > 10000 raises ValueError."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}

        with pytest.raises(ValueError, match=r"phi_S=15000.*exceeds upper bound"):
            decomposer.compute_complexity_tax(delta, phi_S=15000, phi_D=5000)

    def test_phi_d_at_upper_bound_accepted(self):
        """Test phi_D at upper bound (100000) is accepted."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}

        tax = decomposer.compute_complexity_tax(delta, phi_S=500, phi_D=100000)
        assert tax == 500 * 0.1 + 100000 * 0.05

    def test_phi_d_above_upper_bound_raises(self):
        """Test phi_D > 100000 raises ValueError."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}

        with pytest.raises(ValueError, match=r"phi_D=200000.*exceeds upper bound"):
            decomposer.compute_complexity_tax(delta, phi_S=500, phi_D=200000)

    def test_phi_upper_bound_constants_defined(self):
        """Test upper bound constants are defined on the class."""
        assert hasattr(ComplexityDecomposer, "PHI_S_UPPER_BOUND")
        assert hasattr(ComplexityDecomposer, "PHI_D_UPPER_BOUND")
        assert ComplexityDecomposer.PHI_S_UPPER_BOUND == 10000.0
        assert ComplexityDecomposer.PHI_D_UPPER_BOUND == 100000.0

    def test_phi_both_at_boundaries_accepted(self):
        """Test both phi values at their respective upper bounds are accepted."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}

        tax = decomposer.compute_complexity_tax(delta, phi_S=10000, phi_D=100000)
        expected = 10000 * 0.1 + 100000 * 0.05
        assert tax == expected

    def test_phi_negative_still_rejected(self):
        """Test negative phi values are still rejected (existing M10 fix)."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}

        with pytest.raises(ValueError, match=r"phi_S must be non-negative"):
            decomposer.compute_complexity_tax(delta, phi_S=-100, phi_D=5000)

        with pytest.raises(ValueError, match=r"phi_D must be non-negative"):
            decomposer.compute_complexity_tax(delta, phi_S=500, phi_D=-5000)

    def test_phi_s_nan_rejected_in_complexity_tax(self):
        """T-1 regression: NaN phi_S must be caught (NaN bypasses < and > checks)."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}
        with pytest.raises(ValueError, match=r"phi_S must be non-negative"):
            decomposer.compute_complexity_tax(delta, phi_S=float("nan"), phi_D=5000)

    def test_phi_d_nan_rejected_in_complexity_tax(self):
        """T-1 regression: NaN phi_D must be caught (NaN bypasses < and > checks)."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 0.1, "dynamic_delta": 0.05}
        with pytest.raises(ValueError, match=r"phi_D must be non-negative"):
            decomposer.compute_complexity_tax(delta, phi_S=500, phi_D=float("nan"))


# =============================================================================
# L47: UtilityCalculator phi_S/phi_D Validation
# =============================================================================


class TestUtilityCalculatorPhiValidation:
    """L47 regression: phi_S/phi_D must be validated in UtilityCalculator.__init__."""

    def test_default_phi_values_accepted(self):
        """Default phi_S=100, phi_D=2000 must be accepted."""
        calc = UtilityCalculator(phi_S=100.0, phi_D=2000.0)
        assert calc.phi_S == 100.0
        assert calc.phi_D == 2000.0

    def test_phi_s_upper_bound_accepted(self):
        """phi_S at upper bound (10000) must be accepted."""
        calc = UtilityCalculator(phi_S=10000.0)
        assert calc.phi_S == 10000.0

    def test_phi_d_upper_bound_accepted(self):
        """phi_D at upper bound (100000) must be accepted."""
        calc = UtilityCalculator(phi_D=100000.0)
        assert calc.phi_D == 100000.0

    def test_phi_s_above_bound_rejected(self):
        """phi_S above upper bound must raise ValueError."""
        with pytest.raises(ValueError, match=r"phi_S must be in \[0"):
            UtilityCalculator(phi_S=15000.0)

    def test_phi_d_above_bound_rejected(self):
        """phi_D above upper bound must raise ValueError."""
        with pytest.raises(ValueError, match=r"phi_D must be in \[0"):
            UtilityCalculator(phi_D=200000.0)

    def test_phi_s_negative_rejected(self):
        """Negative phi_S must raise ValueError."""
        with pytest.raises(ValueError, match=r"phi_S must be in \[0"):
            UtilityCalculator(phi_S=-1.0)

    def test_phi_d_negative_rejected(self):
        """Negative phi_D must raise ValueError."""
        with pytest.raises(ValueError, match=r"phi_D must be in \[0"):
            UtilityCalculator(phi_D=-1.0)

    def test_phi_s_infinity_rejected(self):
        """phi_S=inf must raise ValueError (NaN propagation risk)."""
        with pytest.raises(ValueError, match=r"phi_S must be in \[0"):
            UtilityCalculator(phi_S=float("inf"))

    def test_phi_d_infinity_rejected(self):
        """phi_D=inf must raise ValueError (NaN propagation risk)."""
        with pytest.raises(ValueError, match=r"phi_D must be in \[0"):
            UtilityCalculator(phi_D=float("inf"))

    def test_phi_s_nan_rejected(self):
        """phi_S=NaN must raise ValueError (NaN bypasses comparison operators)."""
        with pytest.raises(ValueError, match=r"phi_S must be in \[0"):
            UtilityCalculator(phi_S=float("nan"))

    def test_phi_d_nan_rejected(self):
        """phi_D=NaN must raise ValueError (NaN bypasses comparison operators)."""
        with pytest.raises(ValueError, match=r"phi_D must be in \[0"):
            UtilityCalculator(phi_D=float("nan"))

    def test_phi_s_zero_accepted(self):
        """phi_S=0 is a valid boundary (no static complexity cost)."""
        calc = UtilityCalculator(phi_S=0.0)
        assert calc.phi_S == 0.0

    def test_phi_d_zero_accepted(self):
        """phi_D=0 is a valid boundary (no dynamic complexity cost)."""
        calc = UtilityCalculator(phi_D=0.0)
        assert calc.phi_D == 0.0


# =============================================================================
# Bug-Hunt v3.35.0 Regression Tests
# =============================================================================


class TestEpsilonValidation:
    """Bug 1 regression tests: epsilon_R/epsilon_P validation."""

    def test_epsilon_r_zero_raises_valueerror(self):
        """Test epsilon_R=0 raises ValueError to prevent division by zero."""
        with pytest.raises(ValueError, match=r"epsilon_R must be positive"):
            GateEvaluator(epsilon_R=0.0)

    def test_epsilon_p_zero_raises_valueerror(self):
        """Test epsilon_P=0 raises ValueError to prevent division by zero."""
        with pytest.raises(ValueError, match=r"epsilon_P must be positive"):
            GateEvaluator(epsilon_P=0.0)

    def test_epsilon_negative_raises_valueerror(self):
        """Test negative epsilon values raise ValueError."""
        with pytest.raises(ValueError, match=r"epsilon_R must be positive"):
            GateEvaluator(epsilon_R=-0.01)

        with pytest.raises(ValueError, match=r"epsilon_P must be positive"):
            GateEvaluator(epsilon_P=-0.001)

    def test_epsilon_small_positive_accepted(self):
        """Test small positive epsilon values are accepted."""
        evaluator = GateEvaluator(epsilon_R=1e-10, epsilon_P=1e-10)
        assert evaluator.epsilon_R == 1e-10
        assert evaluator.epsilon_P == 1e-10


class TestNegativeTriggerFactor:
    """Bug 2 regression tests: negative trigger_factor behavior."""

    def test_risk_gate_negative_factor_triggers_on_decrease(self):
        """Test risk gate with negative factor triggers on large decreases.

        With risk_trigger_factor=-2.0, the gate should fail when there's
        a high probability of a large risk DECREASE (good thing being flagged).
        """
        evaluator = GateEvaluator(risk_trigger_factor=-2.0)

        # Large decrease: baseline=1.0, proposed=0.1 -> delta=-0.9 (relative -90%)
        result = evaluator.evaluate_risk_gate(baseline=1.0, proposed=0.1)

        # Should fail because P(Δ <= -2.0) is significant for large decrease
        # The gate triggers when large decreases are detected
        assert result.message is not None
        assert "P(Δ≤" in result.message  # Verify left-tail probability in message

    def test_risk_gate_negative_factor_passes_on_increase(self):
        """Test risk gate with negative factor passes on increases.

        With risk_trigger_factor=-2.0, increases should not trigger the gate.
        """
        evaluator = GateEvaluator(risk_trigger_factor=-2.0)

        # Large increase: baseline=1.0, proposed=5.0 -> delta=4.0 (relative +400%)
        result = evaluator.evaluate_risk_gate(baseline=1.0, proposed=5.0)

        # Should pass because P(Δ <= -2.0) is low for positive delta
        assert result.passed is True

    def test_profit_gate_uses_absolute_trigger_factor(self):
        """Test profit gate uses |trigger_factor| for symmetric check.

        The profit gate checks for large changes in either direction,
        so negative trigger factors should behave like positive ones.
        """
        evaluator_positive = GateEvaluator(profit_trigger_factor=2.0)
        evaluator_negative = GateEvaluator(profit_trigger_factor=-2.0)

        # Same delta should produce same result
        result_pos = evaluator_positive.evaluate_profit_gate(
            baseline=100.0, proposed=150.0
        )
        result_neg = evaluator_negative.evaluate_profit_gate(
            baseline=100.0, proposed=150.0
        )

        # Both should have same pass/fail status
        assert result_pos.passed == result_neg.passed
        # Posteriors should be approximately equal (using abs)
        assert result_pos.posterior_probability is not None
        assert result_neg.posterior_probability is not None
        assert (
            abs(result_pos.posterior_probability - result_neg.posterior_probability)
            < 0.01
        )


class TestUtilityConfidenceCalculation:
    """Bug 3 regression tests: utility confidence relative to threshold."""

    def test_utility_confidence_below_threshold_is_low(self):
        """Test confidence < 0.5 when LCB < threshold."""
        evaluator = GateEvaluator(utility_threshold=10.0)

        utility = UtilityResult(
            raw=8.0,
            variance=1.0,
            lcb=9.0,  # Below threshold of 10.0
            components=None,
            decision_path="INVESTMENT",
        )

        result = evaluator.evaluate_utility_gate(utility)

        assert result.passed is False
        assert result.confidence is not None
        assert result.confidence < 0.5  # Bug 3 fix: confidence reflects pass/fail

    def test_utility_confidence_above_threshold_is_high(self):
        """Test confidence > 0.5 when LCB > threshold."""
        evaluator = GateEvaluator(utility_threshold=10.0)

        utility = UtilityResult(
            raw=12.0,
            variance=1.0,
            lcb=11.0,  # Above threshold of 10.0
            components=None,
            decision_path="INVESTMENT",
        )

        result = evaluator.evaluate_utility_gate(utility)

        assert result.passed is True
        assert result.confidence is not None
        assert result.confidence > 0.5  # Bug 3 fix: confidence reflects pass/fail

    def test_utility_confidence_at_threshold_is_near_half(self):
        """Test confidence ≈ 0.5 when LCB ≈ threshold."""
        evaluator = GateEvaluator(utility_threshold=10.0)

        utility = UtilityResult(
            raw=10.0,
            variance=1.0,
            lcb=10.0,  # At threshold
            components=None,
            decision_path="INVESTMENT",
        )

        result = evaluator.evaluate_utility_gate(utility)

        # At threshold: margin = 0, confidence = sigmoid(0) = 0.5
        assert result.confidence is not None
        assert 0.45 < result.confidence < 0.55

    def test_utility_confidence_with_zero_threshold(self):
        """Test confidence works correctly with default threshold=0."""
        evaluator = GateEvaluator()  # utility_threshold=0.0 default

        # Positive LCB should have high confidence
        utility_positive = UtilityResult(
            raw=5.0, variance=1.0, lcb=3.0, components=None, decision_path="INVESTMENT"
        )
        result_pos = evaluator.evaluate_utility_gate(utility_positive)
        assert result_pos.passed is True
        assert result_pos.confidence is not None
        assert result_pos.confidence > 0.5

        # Negative LCB should have low confidence
        utility_negative = UtilityResult(
            raw=-5.0,
            variance=1.0,
            lcb=-3.0,
            components=None,
            decision_path="INVESTMENT",
        )
        result_neg = evaluator.evaluate_utility_gate(utility_negative)
        assert result_neg.passed is False
        assert result_neg.confidence is not None
        assert result_neg.confidence < 0.5


# ============================================================================
# Ultrathink Bug-Hunt #5 Regression Tests
# ============================================================================


class TestKLDivergenceRenormalization:
    """Regression: drift.py KL divergence must re-normalize after epsilon clamping."""

    def test_kl_divergence_renormalized_distributions(self):
        """Verify epsilon-smoothed distributions still sum to 1.0."""
        from engine.drift import DriftMonitor

        detector = DriftMonitor(epsilon=0.01)
        # Sparse distributions with zeros
        p = [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        q = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]
        # Should not raise, and result should be finite
        kl = detector._compute_kl_divergence(p, q)
        assert isinstance(kl, float)
        assert kl >= 0.0
        assert not math.isnan(kl)

    def test_kl_divergence_identical_distributions(self):
        """KL divergence of identical distributions should be ~0."""
        from engine.drift import DriftMonitor

        detector = DriftMonitor(epsilon=1e-10)
        p = [0.25, 0.25, 0.25, 0.25]
        kl = detector._compute_kl_divergence(p, p.copy())
        assert abs(kl) < 1e-6


class TestHistogramInfHandling:
    """Regression: drift.py int(float('inf')) OverflowError."""

    def test_histogram_with_inf_values(self):
        """Histogram should handle inf values without OverflowError."""
        from engine.drift import DriftMonitor

        detector = DriftMonitor()
        data = [1.0, 2.0, 3.0, float("inf"), float("-inf"), 4.0]
        hist = detector._to_histogram(data)
        assert isinstance(hist, list)
        assert len(hist) == detector.num_bins
        assert abs(sum(hist) - 1.0) < 1e-6

    def test_histogram_with_nan_values(self):
        """Histogram should handle NaN values without crash."""
        from engine.drift import DriftMonitor

        detector = DriftMonitor()
        data = [1.0, 2.0, float("nan"), 3.0]
        hist = detector._to_histogram(data)
        assert isinstance(hist, list)

    def test_histogram_all_nonfinite_with_provided_range(self):
        """Regression: _to_histogram must use provided min_val/max_val even when
        all data values are non-finite.

        Previously, if all data values were inf/-inf/NaN, _to_histogram returned
        a uniform distribution regardless of provided min_val/max_val. This caused
        incorrect KL divergence when comparing a baseline (with proper range) to
        current data that was entirely non-finite — the non-finite values should
        be placed in boundary bins using the provided range, not uniformly spread.
        """
        from engine.drift import DriftMonitor

        detector = DriftMonitor()

        # All-inf data with explicit baseline range
        data = [float("inf"), float("inf"), float("inf")]
        hist = detector._to_histogram(data, min_val=0.0, max_val=10.0)

        assert isinstance(hist, list)
        assert len(hist) == detector.num_bins
        # All inf values should go to the last bin, not be uniform
        assert hist[-1] == 1.0
        assert sum(hist) == pytest.approx(1.0)

    def test_histogram_all_neginf_with_provided_range(self):
        """All -inf values with provided range should go to first bin."""
        from engine.drift import DriftMonitor

        detector = DriftMonitor()
        data = [float("-inf"), float("-inf")]
        hist = detector._to_histogram(data, min_val=0.0, max_val=10.0)

        assert hist[0] == 1.0
        assert sum(hist) == pytest.approx(1.0)


class TestNaNConfidencePropagation:
    """Regression tests for NaN confidence propagation (ultrathink finding)."""

    def test_evaluate_all_nan_risk_baseline_no_nan_confidence(self):
        """NaN risk_baseline must not propagate NaN into min_confidence."""
        from engine.gates import GateEvaluator
        from engine.utility import UtilityResult

        evaluator = GateEvaluator()
        utility_result = UtilityResult(
            raw=100.0,
            variance=1.0,
            lcb=50.0,
            components=None,
            decision_path="INVESTMENT",
        )
        result = evaluator.evaluate_all(
            risk_baseline=float("nan"),
            risk_proposed=0.3,
            profit_baseline=100.0,
            profit_proposed=200.0,
            novelty_score=0.9,
            complexity_score=0.8,
            quality_score=0.9,
            quality_subscores=[0.8, 0.8, 0.8],
            utility_result=utility_result,
        )
        assert not math.isnan(result.min_confidence), "min_confidence must not be NaN"

    def test_evaluate_all_nan_bayesian_inputs_gives_zero_confidence(self):
        """NaN in Bayesian gate inputs should give 0.0 min_confidence."""
        from engine.gates import GateEvaluator
        from engine.utility import UtilityResult

        evaluator = GateEvaluator()
        utility_result = UtilityResult(
            raw=100.0,
            variance=1.0,
            lcb=50.0,
            components=None,
            decision_path="INVESTMENT",
        )
        # NaN on both risk and profit baselines; valid scores for other gates
        result = evaluator.evaluate_all(
            risk_baseline=float("nan"),
            risk_proposed=float("nan"),
            profit_baseline=float("nan"),
            profit_proposed=float("nan"),
            novelty_score=0.9,
            complexity_score=0.8,
            quality_score=0.9,
            quality_subscores=[0.8, 0.8, 0.8],
            utility_result=utility_result,
        )
        assert not math.isnan(result.min_confidence)
        # Risk and profit gates produce NaN confidence, which is filtered;
        # min_confidence comes from remaining gates with finite confidence
        assert result.min_confidence >= 0.0


class TestCLIRiskScorePriority:
    """Regression test for CLI risk_score vs risk_proposed priority."""

    def test_risk_proposed_takes_precedence_over_risk_score(self):
        """Explicit risk_proposed must not be overridden by risk_score."""
        from cli import _parse_proposal

        data = {"risk_proposed": 0.8, "risk_score": 0.3}
        kwargs = _parse_proposal(data)
        assert (
            kwargs["risk_proposed"] == 0.8
        ), "risk_proposed should take precedence over risk_score"

    def test_risk_score_used_when_risk_proposed_absent(self):
        """risk_score should map to risk_proposed when canonical name absent."""
        from cli import _parse_proposal

        data = {"risk_score": 0.6}
        kwargs = _parse_proposal(data)
        assert kwargs["risk_proposed"] == 0.6


class TestDecisionPathCase:
    """Regression test for decision_path case consistency."""

    def test_pcw_decide_default_decision_path_uppercase(self):
        """Default decision_path from pcw_decide should be uppercase INVESTMENT."""
        from integration.pcw_decide import PCWContext, PCWPhase, pcw_decide

        context = PCWContext(
            agent_id="test",
            session_id="test-session",
            phase=PCWPhase.PLAN,
            estimated_impact="low",
            proposal_summary="Test proposal",
        )
        decision = pcw_decide(context)
        if decision.decision_trace is not None:
            util_snapshot = decision.decision_trace.metric_snapshot.get(
                "utility_result"
            )
            if util_snapshot is not None:
                assert util_snapshot["decision_path"] == "INVESTMENT"


class TestBug8PercentileRangeValidation:
    """Regression: calibrate_thresholds must validate percentile ranges."""

    def test_warning_percentile_negative_raises(self):
        """Bug 8: Negative warning_percentile should raise ValueError."""
        monitor = DriftMonitor()
        with pytest.raises(ValueError, match="warning_percentile must be between"):
            monitor.calibrate_thresholds([0.1, 0.2, 0.3], warning_percentile=-10)

    def test_critical_percentile_over_100_raises(self):
        """Bug 8: critical_percentile > 100 should raise ValueError."""
        monitor = DriftMonitor()
        with pytest.raises(ValueError, match="critical_percentile must be between"):
            monitor.calibrate_thresholds([0.1, 0.2, 0.3], critical_percentile=150)

    def test_warning_ge_critical_raises(self):
        """Bug 8: warning_percentile >= critical_percentile should raise ValueError."""
        monitor = DriftMonitor()
        with pytest.raises(ValueError, match=r"warning_percentile.*must be less than"):
            monitor.calibrate_thresholds(
                [0.1, 0.2, 0.3], warning_percentile=95, critical_percentile=90
            )

    def test_valid_percentiles_accepted(self):
        """Bug 8: Valid percentile range should work normally."""
        monitor = DriftMonitor()
        tau_w, tau_c = monitor.calibrate_thresholds(
            [0.1, 0.2, 0.3, 0.4, 0.5], warning_percentile=80, critical_percentile=95
        )
        assert tau_w < tau_c


class TestBug9NaNHistogramHandling:
    """Regression: _to_histogram should handle NaN input without crashing."""

    def test_histogram_all_nan_no_range_returns_uniform(self):
        """Bug 9: All-NaN data with no external range returns uniform."""
        monitor = DriftMonitor(num_bins=5)
        hist = monitor._to_histogram([float("nan"), float("nan")])
        assert len(hist) == 5
        assert abs(sum(hist) - 1.0) < 1e-9

    def test_histogram_mixed_nan_with_range(self):
        """Bug 9: NaN values with valid range are skipped (not binned)."""
        monitor = DriftMonitor(num_bins=10)
        hist = monitor._to_histogram([0.5, float("nan"), 0.3], min_val=0.0, max_val=1.0)
        assert len(hist) == 10
        assert abs(sum(hist) - 1.0) < 1e-9
        # NaN is skipped, so only 2 values contributed to the histogram

    def test_histogram_nan_not_in_last_bin(self):
        """Bug Hunt #9: NaN should not inflate the last histogram bin."""
        monitor = DriftMonitor(num_bins=5)
        # All values in first bin range, plus NaN
        hist = monitor._to_histogram([0.1, 0.1, float("nan")], min_val=0.0, max_val=1.0)
        # Last bin should be empty since NaN is skipped (not routed there)
        assert hist[-1] == 0.0


class TestBugHunt9RegressionFixes:
    """Bug Hunt #9 regression tests for gate and utility fixes."""

    def test_gate_evaluator_rejects_zero_risk_trigger_factor(self):
        """Bug Hunt #9: zero trigger_factor causes degenerate gate behavior."""
        with pytest.raises(ValueError, match="must be non-zero"):
            GateEvaluator(risk_trigger_factor=0.0)

    def test_gate_evaluator_rejects_zero_profit_trigger_factor(self):
        """Bug Hunt #9: zero trigger_factor causes degenerate gate behavior."""
        with pytest.raises(ValueError, match="must be non-zero"):
            GateEvaluator(profit_trigger_factor=0.0)

    def test_utility_result_std_dev_negative_variance(self):
        """Bug Hunt #9 updated by BH39: negative variance is now rejected at
        construction (UtilityResult.__post_init__) rather than clamped silently
        in std_dev.  The std_dev clamping code is retained as a defensive guard
        for future subclasses, but should never be reached via the public API."""
        with pytest.raises(
            ValueError, match="variance must be finite and non-negative"
        ):
            UtilityResult(
                raw=1.0,
                variance=-0.1,
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_update_prior_variance_space_interpolation(self):
        """Regression QG-Defer-2: update_prior must combine in variance space.

        Linear interpolation of standard deviations systematically
        underestimates uncertainty (Jensen's inequality). The fix combines
        in variance space: new_std = sqrt((1-w)*σ₀² + w*σ_emp²).
        """
        bp = BayesianPosterior(prior_mean=0.0, prior_std=1.0)
        # prior_std=1.0, empirical_std≈0.1, weight=0.5 →
        # linear gives 0.55, variance-space gives sqrt(0.505)≈0.71
        observations = [0.0, 0.1, -0.1, 0.05, -0.05]  # tight cluster → low std
        _new_mean, new_std = bp.update_prior(observations)

        # Compute what linear interpolation would give
        n = len(observations)
        weight = min(n / bp._PRIOR_WEIGHT_THRESHOLD, 1.0)
        emp_mean = sum(observations) / n
        emp_var = sum((x - emp_mean) ** 2 for x in observations) / (n - 1)
        emp_std = math.sqrt(emp_var)
        linear_std = (1 - weight) * 1.0 + weight * emp_std

        # Variance-space result must be >= linear interpolation
        assert new_std >= linear_std, (
            f"Variance-space std ({new_std:.6f}) should be >= "
            f"linear std ({linear_std:.6f})"
        )

    def test_update_prior_extreme_std_no_overflow(self):
        """Ultrathink B10-1/B10-2: extreme prior_std must not crash update_prior."""
        bp = BayesianPosterior(prior_mean=0.0, prior_std=1e200)
        observations = [1.0, 2.0, 3.0]
        _, new_std = bp.update_prior(observations)
        # Should not raise OverflowError; result must be finite
        assert math.isfinite(new_std)
        assert new_std > 0


class TestQG58Regressions:
    """QG58 ultrathink regression tests."""

    def test_update_prior_extreme_observations_no_overflow(self):
        """QG58-P1-1: observations with magnitude >1e154 must not crash."""
        bp = BayesianPosterior(prior_mean=0.0, prior_std=1.0)
        observations = [1e308, -1e308]
        mean, std = bp.update_prior(observations)
        # Should return fallback (prior values), not raise OverflowError
        assert math.isfinite(mean)
        assert math.isfinite(std)

    def test_drift_evaluate_all_nan_window_raises(self):
        """QG58-P1-2: all-NaN current_window must raise ValueError."""
        monitor = DriftMonitor()
        monitor.set_baseline([1.0, 2.0, 3.0, 4.0, 5.0])
        with pytest.raises(ValueError, match="no finite values"):
            monitor.evaluate([float("nan"), float("nan")])

    def test_drift_histogram_empty_data_returns_uniform(self):
        """QG58-P1-3: _to_histogram returns normalized dist when all data skipped."""
        monitor = DriftMonitor(num_bins=10)
        monitor.set_baseline([1.0, 2.0, 3.0])
        # All NaN values will be skipped in _to_histogram
        hist = monitor._to_histogram([float("nan")], min_val=0.0, max_val=5.0)
        total = sum(hist)
        assert abs(total - 1.0) < 1e-10, f"Histogram must sum to 1.0, got {total}"


class TestQG59GateValidation:
    """QG59: GateEvaluator constructor validation."""

    def test_nan_trigger_factor_rejected(self):
        """QG59-P1-1: NaN trigger_factor must be rejected."""
        with pytest.raises(ValueError, match="NaN"):
            GateEvaluator(risk_trigger_factor=float("nan"))

    def test_nan_profit_trigger_factor_rejected(self):
        """QG59-P1-1: NaN profit_trigger_factor must be rejected."""
        with pytest.raises(ValueError, match="NaN"):
            GateEvaluator(profit_trigger_factor=float("nan"))

    def test_trigger_confidence_prob_above_one_rejected(self):
        """QG59-P2-2: trigger_confidence_prob > 1.0 must be rejected (fail-OPEN prevention)."""
        with pytest.raises(ValueError):
            GateEvaluator(trigger_confidence_prob=2.0)

    def test_trigger_confidence_prob_nan_rejected(self):
        """QG59-P2-2: NaN trigger_confidence_prob must be rejected."""
        with pytest.raises(ValueError):
            GateEvaluator(trigger_confidence_prob=float("nan"))

    def test_trigger_confidence_prob_zero_rejected(self):
        """QG59-P2-2: trigger_confidence_prob=0.0 must be rejected (exclusive lower)."""
        with pytest.raises(ValueError):
            GateEvaluator(trigger_confidence_prob=0.0)

    @pytest.mark.parametrize(
        "param,value",
        [
            ("complexity_floor", float("nan")),
            ("complexity_floor", float("inf")),
            ("novelty_N0", float("nan")),
            ("novelty_k", float("-inf")),
            ("novelty_threshold", float("nan")),
            ("quality_min_score", float("inf")),
            ("utility_threshold", float("nan")),
        ],
    )
    def test_gate_evaluator_rejects_nonfinite_thresholds(self, param, value):
        """BH12: NaN/Inf in threshold params must be rejected (governance lockout prevention)."""
        with pytest.raises(ValueError, match="must be a finite number"):
            GateEvaluator(**{param: value})


class TestQG60Regressions:
    """QG60: Inf passthrough in validation, UtilityCalculator, and ThreePointEstimate."""

    def test_validate_positive_rejects_inf(self):
        """QG60-1: Inf must be rejected by validate_positive (disables risk/profit gates)."""
        from engine.validation import validate_positive

        with pytest.raises(ValueError, match="must be positive"):
            validate_positive("epsilon_R", float("inf"))

    def test_validate_positive_rejects_neg_inf(self):
        """QG60-1: -Inf must be rejected by validate_positive."""
        from engine.validation import validate_positive

        with pytest.raises(ValueError, match="must be positive"):
            validate_positive("epsilon_R", float("-inf"))

    @pytest.mark.parametrize("param", ["gamma", "kappa", "migration_budget"])
    def test_utility_calculator_rejects_inf_params(self, param):
        """QG60-2: UtilityCalculator must reject Inf for gamma/kappa/migration_budget."""
        with pytest.raises(ValueError, match="must be a finite number"):
            UtilityCalculator(**{param: float("inf")})

    @pytest.mark.parametrize("param", ["gamma", "kappa", "migration_budget"])
    def test_utility_calculator_rejects_nan_params(self, param):
        """QG60-2: UtilityCalculator must reject NaN for gamma/kappa/migration_budget."""
        with pytest.raises(ValueError, match="must be a finite number"):
            UtilityCalculator(**{param: float("nan")})

    @pytest.mark.parametrize("param", ["best", "likely", "worst"])
    def test_three_point_estimate_rejects_inf(self, param):
        """QG60-5: ThreePointEstimate must reject Inf values."""
        defaults = {"best": 0.0, "likely": 5.0, "worst": 10.0}
        defaults[param] = float("inf")
        with pytest.raises(ValueError, match="must be finite"):
            ThreePointEstimate(**defaults)

    @pytest.mark.parametrize("param", ["best", "likely", "worst"])
    def test_three_point_estimate_rejects_nan(self, param):
        """QG60-5: ThreePointEstimate must reject NaN values."""
        defaults = {"best": 0.0, "likely": 5.0, "worst": 10.0}
        defaults[param] = float("nan")
        with pytest.raises(ValueError, match="must be finite"):
            ThreePointEstimate(**defaults)


class TestBH16ComplexityNegativeClamp:
    """BH16-L4: ComplexityDecomposer must clamp negative normalized values to 0."""

    def test_negative_metric_value_clamps_to_zero(self):
        """Negative metric values must produce normalized=0.0, not negative."""
        decomposer = ComplexityDecomposer()
        result = decomposer.analyze({ComplexityMetric.LOC: -50.0})
        score = result.scores[ComplexityMetric.LOC]
        assert (
            score.normalized >= 0.0
        ), f"Negative value produced normalized={score.normalized}, expected >= 0"

    def test_negative_metric_overall_normalized_non_negative(self):
        """Overall normalized score must be >= 0 even with negative inputs."""
        decomposer = ComplexityDecomposer()
        result = decomposer.analyze({ComplexityMetric.LOC: -100.0})
        assert result.normalized >= 0.0


class TestBH25DriftConstantLargeMagnitude:
    """BH25-M3: Constant data with large magnitude must not cause ZeroDivisionError."""

    def test_constant_large_magnitude_baseline(self):
        """Constant values at 1e16 must not cause ZeroDivisionError in histogram."""
        monitor = DriftMonitor()
        large_val = 1e16
        data = [large_val] * 20
        baseline_hash = monitor.set_baseline(data)
        assert baseline_hash  # successfully set

    def test_constant_large_magnitude_evaluate(self):
        """Evaluate drift with large-magnitude constant data must not crash."""
        monitor = DriftMonitor()
        large_val = 1e16
        monitor.set_baseline([large_val] * 20)
        result = monitor.evaluate([large_val] * 10)
        assert result.status == DriftStatus.NORMAL

    def test_constant_huge_magnitude(self):
        """Values at 1e100 (well beyond 2^53) must still work."""
        monitor = DriftMonitor()
        huge_val = 1e100
        monitor.set_baseline([huge_val] * 10)
        result = monitor.evaluate([huge_val] * 5)
        assert result.status == DriftStatus.NORMAL


class TestBH25BayesianOverflow:
    """BH25-L2: update_prior must handle sum() overflow to inf gracefully."""

    def test_update_prior_extreme_values_no_inf(self):
        """Extreme values that cause sum() to overflow must return finite result."""
        calc = BayesianPosterior()
        extreme_values = [1e308, 1e308, 1e308]
        new_mean, new_std = calc.update_prior(extreme_values)
        # Must return finite values (fallback to prior), not (inf, inf)
        assert math.isfinite(new_mean), f"new_mean is {new_mean}, expected finite"
        assert math.isfinite(new_std), f"new_std is {new_std}, expected finite"

    def test_update_prior_mixed_extreme_values(self):
        """Mix of extreme values where sum overflows must return finite."""
        calc = BayesianPosterior(prior_mean=0.5, prior_std=1.0)
        extreme_values = [1e308, -1e308, 1e308]
        new_mean, new_std = calc.update_prior(extreme_values)
        assert math.isfinite(new_mean)
        assert math.isfinite(new_std)


class TestBH26ValidationBoolGuard:
    """BH26-M1: validate_positive() must reject boolean values."""

    def test_validate_positive_rejects_true(self):
        """True coerces to 1 which is a valid positive — but booleans are not numeric."""
        from engine.validation import validate_positive

        with pytest.raises(TypeError, match="got bool"):
            validate_positive("epsilon_R", True)

    def test_validate_positive_rejects_false(self):
        """False coerces to 0 which would fail positivity — but should fail as bool first."""
        from engine.validation import validate_positive

        with pytest.raises(TypeError, match="got bool"):
            validate_positive("epsilon_R", False)

    def test_gate_evaluator_rejects_bool_epsilon(self):
        """GateEvaluator(epsilon_R=True) must not silently coerce."""
        with pytest.raises(TypeError):
            GateEvaluator(epsilon_R=True)

    def test_validate_positive_context_in_bool_msg(self):
        """Context string should be appended to bool rejection message."""
        from engine.validation import validate_positive

        with pytest.raises(TypeError, match="extra info"):
            validate_positive("x", True, context="extra info")


class TestBH26BayesianVarOverflow:
    """BH26-M2: empirical_var overflow to inf must return fallback, not (mean, inf)."""

    def test_empirical_var_overflow_returns_fallback(self):
        """When (x - mean)^2 overflows but mean is finite, must fallback."""
        calc = BayesianPosterior(prior_mean=0.0, prior_std=1.0)
        # Values where mean=0 (finite) but sum of squares overflows to inf
        values = [1e154, -1e154]
        new_mean, new_std = calc.update_prior(values)
        assert math.isfinite(new_mean), f"Expected finite mean, got {new_mean}"
        assert math.isfinite(new_std), f"Expected finite std, got {new_std}"

    def test_empirical_var_overflow_returns_prior(self):
        """Fallback should return prior parameters when var overflows."""
        calc = BayesianPosterior(prior_mean=5.0, prior_std=2.0)
        values = [1e200, -1e200, 1e200]
        new_mean, new_std = calc.update_prior(values)
        # Should fallback to prior
        assert math.isfinite(new_mean)
        assert math.isfinite(new_std)


class TestBH26ComplexityDeltaFiniteness:
    """BH26-L1: compute_complexity_tax must reject NaN/Inf delta values."""

    def test_nan_static_delta_rejected(self):
        """NaN in static_delta must raise ValueError."""
        decomposer = ComplexityDecomposer()
        with pytest.raises(ValueError, match=r"static_delta.*must be finite"):
            decomposer.compute_complexity_tax(
                {"static_delta": float("nan"), "dynamic_delta": 0.5}
            )

    def test_inf_dynamic_delta_rejected(self):
        """Inf in dynamic_delta must raise ValueError."""
        decomposer = ComplexityDecomposer()
        with pytest.raises(ValueError, match=r"dynamic_delta.*must be finite"):
            decomposer.compute_complexity_tax(
                {"static_delta": 0.5, "dynamic_delta": float("inf")}
            )

    def test_neg_inf_static_delta_rejected(self):
        """-Inf in static_delta must raise ValueError."""
        decomposer = ComplexityDecomposer()
        with pytest.raises(ValueError, match=r"static_delta.*must be finite"):
            decomposer.compute_complexity_tax(
                {"static_delta": float("-inf"), "dynamic_delta": 0.5}
            )

    def test_valid_deltas_still_work(self):
        """Normal finite values must still compute correctly."""
        decomposer = ComplexityDecomposer()
        result = decomposer.compute_complexity_tax(
            {"static_delta": 0.1, "dynamic_delta": 0.2}
        )
        assert math.isfinite(result)
