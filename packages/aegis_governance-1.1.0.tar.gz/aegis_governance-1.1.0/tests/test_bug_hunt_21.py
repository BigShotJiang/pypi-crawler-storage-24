"""Regression tests for Bug Hunt #21 findings.

BH21-M1: KLDriftConfig missing __post_init__ threshold ordering validation
BH21-M2: Lambda _validate_subscores missing bool guard
BH21-M3: AFABridge _extract_metrics missing quality_subscores validation
BH21-L1: DriftMonitor window_days accepts zero/negative
BH21-L2: Calibrator proposals dict grows unbounded
BH21-L3: emit_shadow_evaluation payload key collision
BH21-L4: set_drift_status unbounded Prometheus label cardinality
BH21-L5: MCP HTTP 405 missing Allow header
"""

import pytest

# ---------------------------------------------------------------------------
# BH21-M1: KLDriftConfig __post_init__ validates threshold ordering
# ---------------------------------------------------------------------------


class TestBH21M1KLDriftConfigValidation:
    """KLDriftConfig must reject tau_warning >= tau_critical at construction."""

    def test_invalid_ordering_rejected(self):
        """tau_warning >= tau_critical raises ValueError."""
        from config import KLDriftConfig

        with pytest.raises(ValueError, match="tau_warning"):
            KLDriftConfig(tau_warning=0.5, tau_critical=0.3)

    def test_equal_thresholds_rejected(self):
        """tau_warning == tau_critical raises ValueError."""
        from config import KLDriftConfig

        with pytest.raises(ValueError, match="tau_warning"):
            KLDriftConfig(tau_warning=0.5, tau_critical=0.5)

    def test_valid_ordering_accepted(self):
        """tau_warning < tau_critical is accepted."""
        from config import KLDriftConfig

        cfg = KLDriftConfig(tau_warning=0.2, tau_critical=0.4)
        assert cfg.tau_warning == 0.2
        assert cfg.tau_critical == 0.4


# ---------------------------------------------------------------------------
# BH21-M2: Lambda _validate_subscores bool guard (transport parity)
# ---------------------------------------------------------------------------


class TestBH21M2LambdaSubscoreBoolGuard:
    """Lambda _validate_subscores must reject bool values."""

    def test_bool_subscore_rejected(self):
        """Boolean element in quality_subscores raises TypeError."""
        import json

        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "body": json.dumps(
                {
                    "quality_subscores": [True, 0.7, 0.8],
                }
            ),
        }
        resp = handler(event, None)
        assert resp["statusCode"] == 400
        body = json.loads(resp["body"])
        assert "bool" in body["error"].lower()

    def test_numeric_subscores_accepted(self):
        """Numeric subscores are accepted through Lambda."""
        import json

        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "body": json.dumps(
                {
                    "quality_subscores": [0.7, 0.8, 0.9],
                }
            ),
        }
        resp = handler(event, None)
        # Should NOT be a 400 for subscores
        assert resp["statusCode"] != 400 or "subscore" not in json.loads(
            resp["body"]
        ).get("error", "")


# ---------------------------------------------------------------------------
# BH21-M3: AFABridge _extract_metrics quality_subscores validation
# ---------------------------------------------------------------------------


class TestBH21M3AFABridgeSubscoreValidation:
    """AFABridge must validate quality_subscores elements."""

    def _make_request(self, subscores):
        from integration.afa_bridge import AFABridge, DecisionRequest, DecisionType

        bridge = AFABridge()
        req = DecisionRequest(
            request_id="test-1",
            decision_type=DecisionType.PROPOSAL,
            agent_id="test-agent",
            context={
                "proposal_summary": "test",
                "risk_baseline": 0.1,
                "risk_proposed": 0.15,
                "quality_subscores": subscores,
            },
        )
        return bridge.request_decision(req)

    def test_bool_subscore_rejected(self):
        """Boolean element in quality_subscores produces ERROR outcome."""
        from integration.afa_bridge import DecisionOutcome

        resp = self._make_request([True, 0.7])
        assert resp.outcome == DecisionOutcome.ERROR
        assert "bool" in resp.rationale.lower()

    def test_nan_subscore_rejected(self):
        """NaN element in quality_subscores produces ERROR outcome."""
        from integration.afa_bridge import DecisionOutcome

        resp = self._make_request([float("nan"), 0.7])
        assert resp.outcome == DecisionOutcome.ERROR
        assert "finite" in resp.rationale.lower()

    def test_inf_subscore_rejected(self):
        """Inf element in quality_subscores produces ERROR outcome."""
        from integration.afa_bridge import DecisionOutcome

        resp = self._make_request([float("inf"), 0.7])
        assert resp.outcome == DecisionOutcome.ERROR
        assert "finite" in resp.rationale.lower()


# ---------------------------------------------------------------------------
# BH21-L1: DriftMonitor window_days must reject zero/negative
# ---------------------------------------------------------------------------


class TestBH21L1DriftMonitorWindowDays:
    """DriftMonitor must reject non-positive window_days."""

    def test_zero_window_days_rejected(self):
        """window_days=0 raises ValueError."""
        from engine.drift import DriftMonitor

        with pytest.raises(ValueError):
            DriftMonitor(window_days=0)

    def test_negative_window_days_rejected(self):
        """window_days=-1 raises ValueError."""
        from engine.drift import DriftMonitor

        with pytest.raises(ValueError):
            DriftMonitor(window_days=-1)

    def test_positive_window_days_accepted(self):
        """window_days=1 is accepted."""
        from engine.drift import DriftMonitor

        dm = DriftMonitor(window_days=1)
        assert dm.window_days == 1


# ---------------------------------------------------------------------------
# BH21-L2: Calibrator proposals dict bounded via eviction
# ---------------------------------------------------------------------------


class TestBH21L2CalibratorProposalEviction:
    """Calibrator must evict old proposals to prevent unbounded growth."""

    def test_proposals_bounded(self):
        """After exceeding history_limit, old proposals are evicted."""
        from actors.calibrator import Calibrator
        from engine.drift import DriftMonitor

        cal = Calibrator(
            actor_id="test-cal",
            name="Test Calibrator",
            history_limit=5,
        )
        dm = DriftMonitor(tau_warning=0.3, tau_critical=0.5)
        dm.set_baseline([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8])

        # Create more proposals than history_limit
        kl_values = [0.1, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]
        for i in range(10):
            cal.propose_drift_calibration(
                proposal_id=f"drift-{i}",
                drift_detector=dm,
                historical_kl_values=kl_values,
                justification=f"test {i}",
            )

        # proposals dict should be bounded by history_limit
        assert len(cal.proposals) <= 5 + 1  # allow small margin for timing


# ---------------------------------------------------------------------------
# BH21-L3: emit_shadow_evaluation drift key collision prevention
# ---------------------------------------------------------------------------


class TestBH21L3ShadowEvaluationKeyCollision:
    """emit_shadow_evaluation must namespace drift to prevent status key collision."""

    def test_drift_result_namespaced(self):
        """drift_result is stored under 'drift' key, not flattened."""
        from telemetry.emitter import TelemetryEmitter

        emitter = TelemetryEmitter(source="test")
        event = emitter.emit_shadow_evaluation(
            decision_id="d-1",
            status="APPROVED",
            gates_passed=3,
            gates_total=5,
            drift_result={"status": "warning", "kl_divergence": 0.35},
        )
        # The top-level "status" should be preserved as "APPROVED"
        assert event.payload["status"] == "APPROVED"
        # Drift result should be nested under "drift" key
        assert event.payload["drift"]["status"] == "warning"
        assert event.payload["drift"]["kl_divergence"] == 0.35


# ---------------------------------------------------------------------------
# BH21-L4: set_drift_status rejects unknown status values
# ---------------------------------------------------------------------------


class TestBH21L4DriftStatusLabelCardinality:
    """set_drift_status must reject unknown status strings."""

    def test_unknown_status_rejected(self):
        """Arbitrary string status raises ValueError."""
        pytest.importorskip("prometheus_client")
        from telemetry.prometheus_exporter import PrometheusExporter

        exporter = PrometheusExporter()
        with pytest.raises(ValueError, match="Unknown drift status"):
            exporter.set_drift_status("bogus_status")

    def test_known_statuses_accepted(self):
        """normal, warning, critical are accepted."""
        pytest.importorskip("prometheus_client")
        from telemetry.prometheus_exporter import PrometheusExporter

        exporter = PrometheusExporter()
        for status in ["normal", "warning", "critical"]:
            exporter.set_drift_status(status)  # Should not raise


# ---------------------------------------------------------------------------
# BH21-L5: MCP HTTP 405 includes Allow header per RFC 9110
# ---------------------------------------------------------------------------


class TestBH21L5MCP405AllowHeader:
    """MCP HTTP server 405 response — HTTP transport removed in MCP consolidation.

    The _MCPHTTPHandler was deleted when the custom JSON-RPC server was replaced
    by FastMCP. FastMCP handles HTTP protocol details internally.
    """

    def test_placeholder(self):
        """Placeholder — HTTP handler tests removed with server consolidation."""
        pass
