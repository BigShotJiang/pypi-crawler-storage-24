"""Schema ↔ Code Consistency Tests

Verifies that schema YAML documents and Python code stay in sync.
Catches naming drift between:
- telemetry-schema.yaml override fields ↔ OverrideInfo.to_schema_dict()
- telemetry-schema.yaml override fields ↔ TelemetryEmitter override payloads
- workflow-definitions.yaml ↔ OverrideState enum / OverrideWorkflow params
- Prometheus rule files parse without error
"""

import inspect
from pathlib import Path

import yaml

from telemetry.emitter import TelemetryEmitter, memory_sink
from telemetry.schema import OverrideInfo, ProposalTelemetry, TelemetryRecord
from workflows.override import OverrideState, OverrideWorkflow

_SCHEMA_DIR = Path(__file__).resolve().parent.parent / "schema"
_MONITORING_DIR = Path(__file__).resolve().parent.parent / "monitoring" / "prometheus"


def _load_yaml(path: Path) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def _get_schema_override_fields() -> set[str]:
    """Return all override_* field names from telemetry-schema.yaml."""
    schema = _load_yaml(_SCHEMA_DIR / "telemetry-schema.yaml")
    return {k for k in schema["required_fields"] if k.startswith("override_")}


# =========================================================================
# Item 1: telemetry-schema.yaml ↔ OverrideInfo
# =========================================================================


class TestOverrideInfoSchemaConsistency:
    """OverrideInfo.to_schema_dict() keys must cover the schema."""

    def test_to_schema_dict_keys_are_subset_of_schema(self):
        """Every key in to_schema_dict() must exist in the schema YAML."""
        schema_fields = _get_schema_override_fields()
        code_keys = set(OverrideInfo().to_schema_dict().keys())
        extra = code_keys - schema_fields
        assert not extra, f"Keys in to_schema_dict() missing from schema: {extra}"

    def test_schema_override_fields_covered_by_to_schema_dict(self):
        """Every override_* field in the schema must appear in to_schema_dict().

        Fields only emitted by emitter methods (override_rejected_by,
        override_rejection_reason) are excluded — they belong to the
        rejection event, not the OverrideInfo dataclass.
        """
        schema_fields = _get_schema_override_fields()
        code_keys = set(OverrideInfo().to_schema_dict().keys())

        # Fields not part of OverrideInfo:
        # - override_rejected_by/override_rejection_reason: emitter-only (rejection event)
        # - override_rationale: audit-section field (pre-existing, separate from OverrideInfo)
        emitter_only_fields = {
            "override_rejected_by",
            "override_rejection_reason",
            "override_rationale",
        }

        missing = schema_fields - code_keys - emitter_only_fields
        assert not missing, f"Schema fields not in to_schema_dict(): {missing}"

    def test_to_schema_dict_keys_use_override_prefix(self):
        """All keys from to_schema_dict() must use the override_ prefix."""
        for key in OverrideInfo().to_schema_dict():
            assert key.startswith("override_"), f"Key {key!r} lacks override_ prefix"


# =========================================================================
# Item 1: telemetry-schema.yaml ↔ Emitter payload keys
# =========================================================================


class TestEmitterSchemaConsistency:
    """Emitter override payload keys must exist in the schema."""

    def _make_emitter(self):
        events: list = []
        emitter = TelemetryEmitter(source="schema-test")
        emitter.add_sink(memory_sink(events))
        return emitter, events

    def test_override_requested_keys_in_schema(self):
        schema_fields = _get_schema_override_fields()
        emitter, events = self._make_emitter()
        emitter.emit_override_requested(
            proposal_id="P-1",
            requester_id="actor-1",
            failed_gates=["risk"],
            justification="test",
        )
        payload_keys = {k for k in events[0].payload if k.startswith("override_")}
        missing = payload_keys - schema_fields
        assert not missing, f"Emitter keys missing from schema: {missing}"

    def test_override_approved_keys_in_schema(self):
        schema_fields = _get_schema_override_fields()
        emitter, events = self._make_emitter()
        emitter.emit_override_approved(
            proposal_id="P-1",
            risk_lead_id="rl-1",
            security_lead_id="sl-1",
        )
        payload_keys = {k for k in events[0].payload if k.startswith("override_")}
        missing = payload_keys - schema_fields
        assert not missing, f"Emitter keys missing from schema: {missing}"

    def test_override_rejected_keys_in_schema(self):
        schema_fields = _get_schema_override_fields()
        emitter, events = self._make_emitter()
        emitter.emit_override_rejected(
            proposal_id="P-1",
            rejected_by="rl-1",
            reason="denied",
        )
        payload_keys = {k for k in events[0].payload if k.startswith("override_")}
        missing = payload_keys - schema_fields
        assert not missing, f"Emitter keys missing from schema: {missing}"


# =========================================================================
# Item 1: ProposalTelemetry.to_dict() override flattening
# =========================================================================


class TestProposalTelemetryOverrideFlattening:
    """ProposalTelemetry serialization must flatten override at top level."""

    def test_to_dict_flattens_override_with_schema_keys(self):
        """Override fields appear at top level, not nested under 'override'."""
        from datetime import datetime, timezone

        record = TelemetryRecord(
            record_id="r-1",
            record_type="proposal",
            timestamp=datetime.now(timezone.utc),
            source="test",
            payload=ProposalTelemetry(
                override=OverrideInfo(
                    requested=True,
                    requester_id="actor-1",
                    justification="test justification",
                ),
            ),
        )
        d = record.to_dict()
        payload = d["payload"]
        assert "override" not in payload, "Override should be flattened, not nested"
        assert payload["override_requested"] is True
        assert payload["override_requester_id"] == "actor-1"
        assert payload["override_justification"] == "test justification"

    def test_to_dict_without_override_has_no_override_keys(self):
        """When override is None, no override keys (prefixed or bare) should appear."""
        from datetime import datetime, timezone

        record = TelemetryRecord(
            record_id="r-2",
            record_type="proposal",
            timestamp=datetime.now(timezone.utc),
            source="test",
            payload=ProposalTelemetry(),
        )
        d = record.to_dict()
        payload = d["payload"]
        # No override_ prefixed keys
        override_keys = [k for k in payload if k.startswith("override_")]
        assert not override_keys, f"Unexpected override keys: {override_keys}"
        # No bare "override" key either (asdict serializes None fields)
        assert "override" not in payload, "Stale 'override' key found in payload"


# =========================================================================
# Item 2: workflow-definitions.yaml ↔ OverrideState / OverrideWorkflow
# =========================================================================


class TestWorkflowDefinitionsConsistency:
    """workflow-definitions.yaml must stay in sync with Python code."""

    def _load_override_workflow_def(self) -> dict:
        defs = _load_yaml(_SCHEMA_DIR / "workflow-definitions.yaml")
        for wf in defs["workflows"]:
            if wf["id"] == "aegis_two_key_override":
                return wf
        raise AssertionError(
            "aegis_two_key_override not found in workflow-definitions.yaml"
        )

    def test_terminal_states_match_override_state_enum(self):
        """Every YAML terminal state maps to an OverrideState enum value.

        The YAML uses ``override_`` prefixed names for disambiguation
        across multiple workflow registries; the Python enum uses bare
        values. Both conventions are correct — this test verifies the
        mapping is complete.
        """
        wf = self._load_override_workflow_def()
        yaml_states = set(wf["terminal_states"])

        # Build expected mapping: override_<value> for each terminal state
        python_terminal = {
            OverrideState.APPROVED,
            OverrideState.REJECTED,
            OverrideState.EXPIRED,
        }
        expected_yaml = {f"override_{s.value}" for s in python_terminal}

        assert (
            yaml_states == expected_yaml
        ), f"YAML terminal_states {yaml_states} != expected {expected_yaml}"

    def test_integration_keys_map_to_init_params(self):
        """YAML integration block keys must correspond to OverrideWorkflow.__init__ params.

        The mapping is: rbac→rbac_enforcer, telemetry→telemetry_emitter,
        alerts→alert_sink, prometheus→prometheus_exporter.
        """
        wf = self._load_override_workflow_def()
        yaml_integration_keys = set(wf.get("integration", {}).keys())

        # Known mapping from YAML shorthand → Python parameter name
        yaml_to_param = {
            "rbac": "rbac_enforcer",
            "telemetry": "telemetry_emitter",
            "alerts": "alert_sink",
            "prometheus": "prometheus_exporter",
        }

        init_params = set(
            inspect.signature(OverrideWorkflow.__init__).parameters.keys()
        )

        for yaml_key, param_name in yaml_to_param.items():
            assert (
                yaml_key in yaml_integration_keys
            ), f"YAML integration missing key {yaml_key!r}"
            assert (
                param_name in init_params
            ), f"OverrideWorkflow.__init__ missing param {param_name!r}"

        # No unknown YAML integration keys
        extra = yaml_integration_keys - yaml_to_param.keys()
        assert not extra, f"Unknown YAML integration keys: {extra}"


# =========================================================================
# Item 3: Prometheus YAML files parse without error
# =========================================================================


class TestPrometheusConfigParseable:
    """Prometheus rule files must be valid YAML."""

    def test_alerting_rules_parse(self):
        data = _load_yaml(_MONITORING_DIR / "alerting-rules.yaml")
        assert "groups" in data
        for group in data["groups"]:
            assert "rules" in group
            for rule in group["rules"]:
                assert "alert" in rule
                assert "expr" in rule

    def test_recording_rules_parse(self):
        data = _load_yaml(_MONITORING_DIR / "recording-rules.yaml")
        assert "groups" in data
        for group in data["groups"]:
            assert "rules" in group
            for rule in group["rules"]:
                assert "record" in rule
                assert "expr" in rule

    def test_alerting_rules_have_required_annotations(self):
        """Every alert rule must have severity label and summary annotation."""
        data = _load_yaml(_MONITORING_DIR / "alerting-rules.yaml")
        for group in data["groups"]:
            for rule in group["rules"]:
                assert "labels" in rule, f"Alert {rule['alert']} missing labels"
                assert (
                    "severity" in rule["labels"]
                ), f"Alert {rule['alert']} missing severity label"
                assert (
                    "annotations" in rule
                ), f"Alert {rule['alert']} missing annotations"
                assert (
                    "summary" in rule["annotations"]
                ), f"Alert {rule['alert']} missing summary annotation"
