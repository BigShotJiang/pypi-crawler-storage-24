"""Regression tests for Bug Hunt #34.

BH34-M1: DriftMonitor(num_bins=float) accepted, crashes later (Codex finding)
BH34-M2: CLI cmd_evaluate missing TypeError in config catch
BH34-M3: DualSignatureValidator.expiration_hours missing upper bound
BH34-M4: TelemetryPipeline._worker_loop inconsistent state on raise error
BH34-L1: AegisConfig.from_dict() telemetry_url type coercion gap
"""

import argparse

import pytest

from config import AegisConfig
from engine.drift import DriftMonitor
from workflows.override import DualSignatureValidator

# ---------------------------------------------------------------------------
# BH34-M1: DriftMonitor rejects non-integer num_bins at construction
# ---------------------------------------------------------------------------


class TestBH34M1DriftMonitorNumBins:
    """DriftMonitor must reject float num_bins eagerly."""

    def test_float_num_bins_rejected(self):
        with pytest.raises(TypeError, match="num_bins must be an integer"):
            DriftMonitor(num_bins=2.5)

    def test_bool_num_bins_rejected(self):
        with pytest.raises(TypeError, match="num_bins must be an integer"):
            DriftMonitor(num_bins=True)

    def test_string_num_bins_rejected(self):
        with pytest.raises(TypeError, match="num_bins must be an integer"):
            DriftMonitor(num_bins="10")  # type: ignore[arg-type]

    def test_valid_int_num_bins_accepted(self):
        dm = DriftMonitor(num_bins=10)
        assert dm.num_bins == 10


# ---------------------------------------------------------------------------
# BH34-M2: CLI cmd_evaluate catches TypeError from config loading
# ---------------------------------------------------------------------------


class TestBH34M2CLITypeError:
    """cmd_evaluate must catch TypeError from AegisConfig.from_yaml."""

    def test_cmd_evaluate_catches_type_error(self, tmp_path):
        """TypeError in config loading produces clean JSON error, not traceback."""
        from cli import cmd_evaluate

        config_file = tmp_path / "bad.yaml"
        config_file.write_text("epsilon_R: true\n")

        args = argparse.Namespace(
            config=str(config_file),
            input=None,
            risk_baseline=0.5,
            risk_proposed=0.6,
            profit_baseline=1.0,
            profit_proposed=1.1,
            novelty=0.5,
            complexity=0.5,
            quality=0.8,
            quality_subscores=None,
            drift_baseline=None,
            shadow=False,
        )

        result = cmd_evaluate(args)
        assert result == 1


# ---------------------------------------------------------------------------
# BH34-M3: DualSignatureValidator rejects excessively large expiration_hours
# ---------------------------------------------------------------------------


class TestBH34M3ExpirationUpperBound:
    """DualSignatureValidator must reject huge expiration_hours."""

    def test_huge_expiration_hours_rejected(self):
        with pytest.raises(ValueError, match="exceeds maximum allowed"):
            DualSignatureValidator(expiration_hours=100_000_000)

    def test_max_boundary_accepted(self):
        v = DualSignatureValidator(
            expiration_hours=DualSignatureValidator.MAX_EXPIRATION_HOURS
        )
        assert v.expiration_hours == DualSignatureValidator.MAX_EXPIRATION_HOURS

    def test_one_over_max_rejected(self):
        with pytest.raises(ValueError, match="exceeds maximum allowed"):
            DualSignatureValidator(
                expiration_hours=DualSignatureValidator.MAX_EXPIRATION_HOURS + 1
            )


# ---------------------------------------------------------------------------
# BH34-M4: Pipeline._worker_loop resets running on exception
# ---------------------------------------------------------------------------


@pytest.mark.filterwarnings("ignore::pytest.PytestUnhandledThreadExceptionWarning")
class TestBH34M4PipelineWorkerLoop:
    """_worker_loop must reset self.running on unhandled exception."""

    def test_worker_loop_resets_running_on_exception(self):
        """When _worker_loop dies from storage raise, running becomes False."""
        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        config = PipelineConfig(
            flush_interval_seconds=1,
            flush_threshold=1,
            storage_on_error="raise",
        )
        pipeline = TelemetryPipeline(config=config)

        def bad_handler(_events):
            raise RuntimeError("storage failure")

        pipeline.add_storage_handler(bad_handler)
        pipeline.start()

        # Put event in queue; worker picks it up via get(), calls ingest(),
        # buffer hits flush_threshold=1, flush() triggers storage handler
        # which raises RuntimeError, killing the worker thread.
        pipeline.queue.put({"proposal_id": "test-bh34", "event": "test"})

        if pipeline.worker_thread is not None:
            pipeline.worker_thread.join(timeout=5.0)

        assert pipeline.running is False

    def test_pipeline_restartable_after_worker_crash(self):
        """After worker crash, start() should work again."""
        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        config = PipelineConfig(
            flush_interval_seconds=1,
            flush_threshold=1,
            storage_on_error="raise",
        )
        pipeline = TelemetryPipeline(config=config)

        call_count = 0

        def flaky_handler(_events):
            nonlocal call_count
            call_count += 1
            if call_count <= 1:
                raise RuntimeError("first call fails")

        pipeline.add_storage_handler(flaky_handler)
        pipeline.start()

        pipeline.queue.put({"proposal_id": "test-restart", "event": "test"})

        if pipeline.worker_thread is not None:
            pipeline.worker_thread.join(timeout=5.0)

        assert pipeline.running is False

        # Should be restartable now
        pipeline.start()
        assert pipeline.running is True
        pipeline.stop()


# ---------------------------------------------------------------------------
# BH34-L1: AegisConfig.from_dict coerces telemetry_url to string
# ---------------------------------------------------------------------------


class TestBH34L1TelemetryUrlCoercion:
    """from_dict must coerce telemetry_url to str like _from_raw_dict does."""

    def test_int_telemetry_url_coerced_to_string(self):
        config = AegisConfig.from_dict({"telemetry_url": 12345})
        assert config.telemetry_url == "12345"
        assert isinstance(config.telemetry_url, str)

    def test_none_telemetry_url_stays_none(self):
        config = AegisConfig.from_dict({"telemetry_url": None})
        assert config.telemetry_url is None

    def test_string_telemetry_url_unchanged(self):
        config = AegisConfig.from_dict({"telemetry_url": "https://example.com"})
        assert config.telemetry_url == "https://example.com"

    def test_missing_telemetry_url_stays_default(self):
        config = AegisConfig.from_dict({})
        assert config.telemetry_url is None
