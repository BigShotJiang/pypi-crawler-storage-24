"""TD-3: Negative and edge-case test coverage.

Covers error paths, invalid inputs, and boundary conditions for:
- GateEvaluator (gates.py)
- UtilityCalculator / ThreePointEstimate / UtilityResult (utility.py)
- ConsensusWorkflow (consensus.py)
"""

from __future__ import annotations

import pytest

from engine.gates import GateEvaluator
from engine.utility import (
    ComplexityBreakdown,
    ThreePointEstimate,
    UtilityCalculator,
    UtilityResult,
)
from workflows.consensus import (
    ConsensusConfig,
    ConsensusState,
    ConsensusWorkflow,
    VoteOutcome,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_utility_result(
    raw: float = 1.0,
    variance: float = 0.1,
    lcb: float = 0.5,
    decision_path: str = "INVESTMENT",
) -> UtilityResult:
    """Build a valid UtilityResult for gate evaluation tests."""
    return UtilityResult(
        raw=raw,
        variance=variance,
        lcb=lcb,
        components=None,
        decision_path=decision_path,
    )


# ===================================================================
# Gate Evaluator -- invalid inputs
# ===================================================================


class TestGateEvaluatorInvalidInputs:
    """Negative tests for GateEvaluator construction and evaluate_all."""

    # -- Constructor validation ------------------------------------------

    def test_nan_epsilon_r_rejected(self) -> None:
        """NaN epsilon_R must be rejected at construction time."""
        with pytest.raises(ValueError, match="epsilon_R"):
            GateEvaluator(epsilon_R=float("nan"))

    def test_inf_epsilon_p_rejected(self) -> None:
        """Inf epsilon_P must be rejected at construction time."""
        with pytest.raises(ValueError, match="epsilon_P"):
            GateEvaluator(epsilon_P=float("inf"))

    def test_negative_epsilon_r_rejected(self) -> None:
        """Negative epsilon_R must be rejected (must be positive)."""
        with pytest.raises(ValueError, match="epsilon_R"):
            GateEvaluator(epsilon_R=-0.01)

    def test_zero_risk_trigger_factor_rejected(self) -> None:
        """Zero risk_trigger_factor must be rejected (causes gate to always fail)."""
        with pytest.raises(ValueError, match="risk_trigger_factor"):
            GateEvaluator(risk_trigger_factor=0.0)

    def test_nan_risk_trigger_factor_rejected(self) -> None:
        """NaN risk_trigger_factor must be rejected."""
        with pytest.raises(ValueError, match="risk_trigger_factor"):
            GateEvaluator(risk_trigger_factor=float("nan"))

    def test_inf_profit_trigger_factor_rejected(self) -> None:
        """Inf profit_trigger_factor must be rejected."""
        with pytest.raises(ValueError, match="profit_trigger_factor"):
            GateEvaluator(profit_trigger_factor=float("inf"))

    def test_bool_risk_trigger_factor_rejected(self) -> None:
        """Bool risk_trigger_factor must raise TypeError (bool is subclass of int)."""
        with pytest.raises(TypeError, match="risk_trigger_factor"):
            GateEvaluator(risk_trigger_factor=True)

    def test_bool_novelty_k_rejected(self) -> None:
        """Bool novelty_k must raise TypeError."""
        with pytest.raises(TypeError, match="novelty_k"):
            GateEvaluator(novelty_k=True)

    # -- evaluate_all: bool inputs for baseline/proposed ------------------

    def test_evaluate_all_bool_risk_baseline_rejected(self) -> None:
        """Bool risk_baseline must raise TypeError in evaluate_all."""
        ge = GateEvaluator()
        with pytest.raises(TypeError, match="risk_baseline"):
            ge.evaluate_all(
                risk_baseline=True,
                risk_proposed=0.2,
                profit_baseline=100.0,
                profit_proposed=110.0,
                novelty_score=0.8,
                complexity_score=0.6,
                quality_score=0.8,
                quality_subscores=[0.8, 0.7],
                utility_result=_make_utility_result(),
            )

    def test_evaluate_all_bool_profit_proposed_rejected(self) -> None:
        """Bool profit_proposed must raise TypeError in evaluate_all."""
        ge = GateEvaluator()
        with pytest.raises(TypeError, match="profit_proposed"):
            ge.evaluate_all(
                risk_baseline=0.1,
                risk_proposed=0.2,
                profit_baseline=100.0,
                profit_proposed=False,
                novelty_score=0.8,
                complexity_score=0.6,
                quality_score=0.8,
                quality_subscores=[0.8, 0.7],
                utility_result=_make_utility_result(),
            )

    # -- evaluate_all: NaN propagation in risk/profit ---------------------

    def test_risk_gate_nan_baseline_fails_closed(self) -> None:
        """NaN risk baseline must produce a fail-closed risk gate."""
        ge = GateEvaluator()
        result = ge.evaluate_risk_gate(baseline=float("nan"), proposed=0.2)
        assert result.passed is False
        assert result.confidence == 0.0

    def test_profit_gate_nan_proposed_fails_closed(self) -> None:
        """NaN profit proposed must produce a fail-closed profit gate."""
        ge = GateEvaluator()
        result = ge.evaluate_profit_gate(baseline=100.0, proposed=float("nan"))
        assert result.passed is False
        assert result.confidence == 0.0

    def test_risk_gate_inf_proposed_fails_closed(self) -> None:
        """Inf risk proposed must produce a fail-closed risk gate."""
        ge = GateEvaluator()
        result = ge.evaluate_risk_gate(baseline=0.1, proposed=float("inf"))
        assert result.passed is False
        assert result.confidence == 0.0

    # -- evaluate_all: normalized score out of range ----------------------

    def test_novelty_score_above_one_rejected(self) -> None:
        """novelty_score > 1.0 must raise ValueError in evaluate_all."""
        ge = GateEvaluator()
        with pytest.raises(ValueError, match="novelty_score"):
            ge.evaluate_all(
                risk_baseline=0.1,
                risk_proposed=0.2,
                profit_baseline=100.0,
                profit_proposed=110.0,
                novelty_score=1.5,
                complexity_score=0.6,
                quality_score=0.8,
                quality_subscores=[0.8],
                utility_result=_make_utility_result(),
            )

    def test_complexity_score_negative_rejected(self) -> None:
        """complexity_score < 0 must raise ValueError in evaluate_all."""
        ge = GateEvaluator()
        with pytest.raises(ValueError, match="complexity_score"):
            ge.evaluate_all(
                risk_baseline=0.1,
                risk_proposed=0.2,
                profit_baseline=100.0,
                profit_proposed=110.0,
                novelty_score=0.8,
                complexity_score=-0.1,
                quality_score=0.8,
                quality_subscores=[0.8],
                utility_result=_make_utility_result(),
            )

    # -- Novelty gate: non-finite input -----------------------------------

    def test_novelty_gate_nan_fails_closed(self) -> None:
        """NaN novelty_score must fail-closed with confidence=0."""
        ge = GateEvaluator()
        result = ge.evaluate_novelty_gate(float("nan"))
        assert result.passed is False
        assert result.confidence == 0.0

    def test_novelty_gate_inf_fails_closed(self) -> None:
        """Inf novelty_score must fail-closed with confidence=0."""
        ge = GateEvaluator()
        result = ge.evaluate_novelty_gate(float("inf"))
        assert result.passed is False
        assert result.confidence == 0.0

    # -- Quality gate: NaN subscores --------------------------------------

    def test_quality_gate_nan_subscore_treated_as_zero(self) -> None:
        """NaN in quality_subscores must be treated as zero (fail-safe)."""
        ge = GateEvaluator()
        result = ge.evaluate_quality_gate(
            quality_score=0.9,
            subscores=[0.8, float("nan"), 0.7],
        )
        # NaN subscore -> treated as 0.0 -> has_zero triggers -> fail
        assert result.passed is False
        assert "Zero sub-score" in (result.message or "")

    def test_quality_gate_empty_subscores_fails(self) -> None:
        """Empty subscores list must fail (min_subscore defaults to 0.0)."""
        ge = GateEvaluator()
        result = ge.evaluate_quality_gate(quality_score=0.9, subscores=[])
        assert result.passed is False


# ===================================================================
# Utility Calculator -- edge cases
# ===================================================================


class TestUtilityEdgeCases:
    """Negative tests for UtilityCalculator and related dataclasses."""

    def test_utility_result_nan_raw_rejected(self) -> None:
        """NaN raw utility must be rejected at construction."""
        with pytest.raises(ValueError, match="raw"):
            UtilityResult(
                raw=float("nan"),
                variance=0.1,
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_utility_result_nan_variance_rejected(self) -> None:
        """NaN variance must be rejected at construction."""
        with pytest.raises(ValueError, match="variance"):
            UtilityResult(
                raw=1.0,
                variance=float("nan"),
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_utility_result_negative_variance_rejected(self) -> None:
        """Negative variance must be rejected at construction."""
        with pytest.raises(ValueError, match="variance"):
            UtilityResult(
                raw=1.0,
                variance=-0.5,
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_utility_result_inf_variance_rejected(self) -> None:
        """Infinite variance must be rejected at construction."""
        with pytest.raises(ValueError, match="variance"):
            UtilityResult(
                raw=1.0,
                variance=float("inf"),
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_utility_result_bool_raw_rejected(self) -> None:
        """Bool raw must be rejected (bool is subclass of int)."""
        with pytest.raises(ValueError, match="raw"):
            UtilityResult(
                raw=True,
                variance=0.1,
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_three_point_estimate_violates_ordering(self) -> None:
        """best > likely must raise ValueError."""
        with pytest.raises(ValueError, match="PERT requires"):
            ThreePointEstimate(best=5.0, likely=3.0, worst=10.0)

    def test_three_point_estimate_nan_field(self) -> None:
        """NaN in any PERT field must raise ValueError."""
        with pytest.raises(ValueError, match="finite"):
            ThreePointEstimate(best=1.0, likely=float("nan"), worst=10.0)

    def test_three_point_estimate_inf_field(self) -> None:
        """Inf in any PERT field must raise ValueError."""
        with pytest.raises(ValueError, match="finite"):
            ThreePointEstimate(best=1.0, likely=5.0, worst=float("inf"))

    def test_three_point_estimate_bool_rejected(self) -> None:
        """Bool field in PERT must raise TypeError."""
        with pytest.raises(TypeError, match="bool"):
            ThreePointEstimate(best=True, likely=5.0, worst=10.0)

    def test_complexity_breakdown_nan_rejected(self) -> None:
        """NaN in ComplexityBreakdown must raise ValueError."""
        with pytest.raises(ValueError, match="finite"):
            ComplexityBreakdown(static=float("nan"), dynamic=0.5)

    def test_complexity_breakdown_bool_rejected(self) -> None:
        """Bool in ComplexityBreakdown must raise TypeError."""
        with pytest.raises(TypeError, match="bool"):
            ComplexityBreakdown(static=True, dynamic=0.5)

    def test_calculate_nan_value_low_conf_rejected(self) -> None:
        """NaN value_low_conf in calculate must raise ValueError."""
        calc = UtilityCalculator()
        with pytest.raises(ValueError, match="value_low_conf"):
            calc.calculate(
                profit_estimate=ThreePointEstimate(best=100, likely=200, worst=300),
                risk_estimate=ThreePointEstimate(best=-10, likely=-5, worst=0),
                complexity=ComplexityBreakdown(static=0.3, dynamic=0.2),
                value_low_conf=float("nan"),
            )

    def test_calculate_inf_opex_delta_rejected(self) -> None:
        """Inf opex_delta in calculate must raise ValueError."""
        calc = UtilityCalculator()
        with pytest.raises(ValueError, match="opex_delta"):
            calc.calculate(
                profit_estimate=ThreePointEstimate(best=100, likely=200, worst=300),
                risk_estimate=ThreePointEstimate(best=-10, likely=-5, worst=0),
                complexity=ComplexityBreakdown(static=0.3, dynamic=0.2),
                opex_delta=float("inf"),
            )

    def test_calculate_negative_value_variance_rejected(self) -> None:
        """Negative value_variance in calculate must raise ValueError."""
        calc = UtilityCalculator()
        with pytest.raises(ValueError, match="value_variance"):
            calc.calculate(
                profit_estimate=ThreePointEstimate(best=100, likely=200, worst=300),
                risk_estimate=ThreePointEstimate(best=-10, likely=-5, worst=0),
                complexity=ComplexityBreakdown(static=0.3, dynamic=0.2),
                value_variance=-1.0,
            )


# ===================================================================
# Consensus Workflow -- error paths
# ===================================================================


class TestConsensusWorkflowErrorPaths:
    """Negative tests for consensus workflow state transitions."""

    def _make_workflow(
        self,
        voters: set[str] | None = None,
        config: ConsensusConfig | None = None,
    ) -> ConsensusWorkflow:
        """Build a ConsensusWorkflow with sensible defaults."""
        if voters is None:
            voters = {"voter_a", "voter_b", "voter_c"}
        return ConsensusWorkflow(
            proposal_id="prop-neg-001",
            eligible_voters=voters,
            config=config or ConsensusConfig(),
        )

    def test_vote_from_ineligible_voter_rejected(self) -> None:
        """A voter not in the eligible set must be rejected."""
        wf = self._make_workflow()
        accepted = wf.cast_vote("intruder", VoteOutcome.APPROVE)
        assert accepted is False
        assert "intruder" not in wf.votes

    def test_vote_after_approval_finalization_rejected(self) -> None:
        """Votes after consensus is finalized (APPROVED) must be rejected."""
        voters = {"a", "b", "c"}
        config = ConsensusConfig(
            quorum_percentage=0.51,
            approval_threshold=0.5,
        )
        wf = ConsensusWorkflow(
            proposal_id="prop-fin",
            eligible_voters=voters,
            config=config,
        )
        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.APPROVE)
        # Should be finalized as APPROVED now
        assert wf.state == ConsensusState.APPROVED

        # Subsequent vote must be rejected
        accepted = wf.cast_vote("c", VoteOutcome.REJECT)
        assert accepted is False

    def test_vote_after_rejection_finalization_rejected(self) -> None:
        """Votes after consensus is finalized (REJECTED) must be rejected."""
        voters = {"a", "b", "c"}
        config = ConsensusConfig(
            quorum_percentage=0.51,
            approval_threshold=0.5,
        )
        wf = ConsensusWorkflow(
            proposal_id="prop-rej",
            eligible_voters=voters,
            config=config,
        )
        wf.cast_vote("a", VoteOutcome.REJECT)
        wf.cast_vote("b", VoteOutcome.REJECT)
        assert wf.state == ConsensusState.REJECTED

        accepted = wf.cast_vote("c", VoteOutcome.APPROVE)
        assert accepted is False

    def test_duplicate_vote_overwrites_with_warning(self) -> None:
        """Duplicate vote from same voter must overwrite (logged warning)."""
        wf = self._make_workflow()
        wf.cast_vote("voter_a", VoteOutcome.APPROVE)
        wf.cast_vote("voter_a", VoteOutcome.REJECT)
        assert wf.votes["voter_a"].outcome == VoteOutcome.REJECT

    def test_abstain_rejected_when_not_allowed(self) -> None:
        """ABSTAIN vote must be rejected when allow_abstain is False."""
        config = ConsensusConfig(allow_abstain=False)
        wf = self._make_workflow(config=config)
        accepted = wf.cast_vote("voter_a", VoteOutcome.ABSTAIN)
        assert accepted is False

    def test_empty_eligible_voters_with_positive_quorum_rejected(self) -> None:
        """Empty eligible_voters with positive quorum must raise ValueError."""
        with pytest.raises(ValueError, match="empty eligible_voters"):
            ConsensusWorkflow(
                proposal_id="prop-empty",
                eligible_voters=set(),
                config=ConsensusConfig(quorum_percentage=0.51),
            )

    def test_empty_eligible_voters_with_zero_quorum_rejected(self) -> None:
        """Empty eligible_voters with zero quorum must raise ValueError."""
        with pytest.raises(ValueError, match="trivially pass"):
            ConsensusWorkflow(
                proposal_id="prop-empty-zero",
                eligible_voters=set(),
                config=ConsensusConfig(quorum_percentage=0.0),
            )

    # -- Boundary conditions ---------------------------------------------

    def test_quorum_at_exact_51_percent(self) -> None:
        """Quorum must be met when participation is exactly at 51% threshold."""
        # 100 voters, need 51 votes
        voters = {f"v{i}" for i in range(100)}
        config = ConsensusConfig(quorum_percentage=0.51)
        wf = ConsensusWorkflow(
            proposal_id="prop-quorum-boundary",
            eligible_voters=voters,
            config=config,
        )
        # Cast exactly 51 votes
        for i in range(51):
            wf.cast_vote(f"v{i}", VoteOutcome.APPROVE)

        assert wf.quorum_met is True
        assert wf.participation_rate == pytest.approx(0.51)

    def test_quorum_not_met_at_50_percent(self) -> None:
        """Quorum must NOT be met when participation is below 51% threshold."""
        voters = {f"v{i}" for i in range(100)}
        config = ConsensusConfig(quorum_percentage=0.51)
        wf = ConsensusWorkflow(
            proposal_id="prop-quorum-below",
            eligible_voters=voters,
            config=config,
        )
        for i in range(50):
            wf.cast_vote(f"v{i}", VoteOutcome.APPROVE)

        assert wf.quorum_met is False
        assert wf.state == ConsensusState.PENDING

    def test_approval_at_exact_two_thirds_threshold(self) -> None:
        """Approval must succeed at exactly 2/3 approval ratio."""
        voters = {"a", "b", "c"}
        config = ConsensusConfig(
            quorum_percentage=0.51,
            approval_threshold=2 / 3,
        )
        wf = ConsensusWorkflow(
            proposal_id="prop-2thirds",
            eligible_voters=voters,
            config=config,
        )
        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.APPROVE)
        wf.cast_vote("c", VoteOutcome.REJECT)
        # 2/3 approvals = 0.6667 >= 0.6667 threshold
        assert wf.state == ConsensusState.APPROVED

    def test_consensus_config_bool_quorum_rejected(self) -> None:
        """Bool quorum_percentage must raise TypeError."""
        with pytest.raises(TypeError, match="quorum_percentage"):
            ConsensusConfig(quorum_percentage=True)

    def test_consensus_config_negative_timeout_rejected(self) -> None:
        """Negative timeout_hours must raise ValueError."""
        with pytest.raises(ValueError, match="timeout_hours"):
            ConsensusConfig(timeout_hours=-1)

    def test_consensus_config_zero_timeout_rejected(self) -> None:
        """Zero timeout_hours must raise ValueError."""
        with pytest.raises(ValueError, match="timeout_hours"):
            ConsensusConfig(timeout_hours=0)

    def test_consensus_config_bool_timeout_rejected(self) -> None:
        """Bool timeout_hours must raise TypeError."""
        with pytest.raises(TypeError, match="timeout_hours"):
            ConsensusConfig(timeout_hours=True)

    def test_consensus_config_quorum_above_one_rejected(self) -> None:
        """quorum_percentage > 1.0 must raise ValueError."""
        with pytest.raises(ValueError, match="quorum_percentage"):
            ConsensusConfig(quorum_percentage=1.5)

    def test_consensus_config_approval_threshold_negative_rejected(self) -> None:
        """Negative approval_threshold must raise ValueError."""
        with pytest.raises(ValueError, match="approval_threshold"):
            ConsensusConfig(approval_threshold=-0.1)
