"""Bug Hunt #22 regression tests.

BH22-M1: override.py reject() missing wall-clock expiration check (Codex — test in test_override_coverage.py)
BH22-M2: MCP quality_subscores missing extraction (transport parity)
BH22-M3: DriftMonitor.update_thresholds missing finiteness + non-negativity
BH22-M4: persistence mark_completed re-completion guard
BH22-L1: drift_baseline_data bool guard (Lambda + MCP)
BH22-L2: Governance active_overrides eviction of expired
BH22-L3: AFABridge _evaluate_authorization string-as-iterable
"""

import json
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

import pytest

from engine.drift import DriftMonitor

# --- BH22-M2: MCP quality_subscores extraction ---


class TestMCPQualitySubscores:
    """BH22-M2: MCP must extract quality_subscores from arguments."""

    def test_mcp_evaluate_passes_quality_subscores(self):
        """Regression: build_pcw_context should extract quality_subscores."""
        from aegis_governance.middleware import build_pcw_context

        ctx = build_pcw_context(
            {
                "proposal_summary": "Test proposal",
                "risk_baseline": 0.1,
                "risk_proposed": 0.15,
                "quality_subscores": [0.8, 0.9, 0.7],
            }
        )
        assert ctx.quality_subscores == [0.8, 0.9, 0.7]

    def test_mcp_evaluate_rejects_bool_subscore(self):
        """Regression: build_pcw_context must reject boolean quality_subscores."""
        from aegis_governance.middleware import build_pcw_context

        with pytest.raises(TypeError, match="bool"):
            build_pcw_context(
                {
                    "proposal_summary": "Test",
                    "quality_subscores": [True, 0.9, 0.7],
                }
            )

    def test_mcp_evaluate_empty_subscores_returns_empty(self):
        """UT-1: Empty quality_subscores must return [] (parity with Lambda)."""
        from aegis_governance.middleware import build_pcw_context

        ctx = build_pcw_context(
            {
                "proposal_summary": "Empty subscores test",
                "quality_score": 0.95,
                "quality_subscores": [],
            }
        )
        assert ctx.quality_subscores == []

    def test_mcp_evaluate_rejects_non_numeric_subscore(self):
        """UT-2: build_pcw_context must reject non-numeric string subscores."""
        from aegis_governance.middleware import build_pcw_context

        with pytest.raises(ValueError, match="numeric"):
            build_pcw_context(
                {
                    "proposal_summary": "Test",
                    "quality_subscores": ["abc", 0.9, 0.7],
                }
            )


# --- BH22-M3: DriftMonitor.update_thresholds validation ---


class TestUpdateThresholdsValidation:
    """BH22-M3: update_thresholds must reject Inf and negative values."""

    def test_update_thresholds_rejects_positive_infinity(self):
        """Regression: Inf tau_warning must be rejected."""
        dm = DriftMonitor()
        with pytest.raises(ValueError, match="finite"):
            dm.update_thresholds(float("inf"), 0.5)

    def test_update_thresholds_rejects_negative_infinity(self):
        """Regression: -Inf tau_critical must be rejected."""
        dm = DriftMonitor()
        with pytest.raises(ValueError, match="finite"):
            dm.update_thresholds(0.3, float("-inf"))

    def test_update_thresholds_rejects_nan(self):
        """Regression: NaN must be rejected."""
        dm = DriftMonitor()
        with pytest.raises(ValueError, match="finite"):
            dm.update_thresholds(float("nan"), 0.5)

    def test_update_thresholds_rejects_negative_warning(self):
        """Regression: negative tau_warning must be rejected."""
        dm = DriftMonitor()
        with pytest.raises(ValueError, match="non-negative"):
            dm.update_thresholds(-0.1, 0.5)

    def test_update_thresholds_rejects_negative_critical(self):
        """Regression: negative tau_critical must be rejected."""
        dm = DriftMonitor()
        with pytest.raises(ValueError, match="non-negative"):
            dm.update_thresholds(0.3, -0.1)

    def test_update_thresholds_accepts_valid_values(self):
        """Positive test: valid thresholds should be accepted."""
        dm = DriftMonitor()
        dm.update_thresholds(0.2, 0.4)
        assert dm.tau_warning == 0.2
        assert dm.tau_critical == 0.4


# --- BH22-M4: mark_completed re-completion guard ---


class TestMarkCompletedGuard:
    """BH22-M4: mark_completed must reject re-completion."""

    @pytest.mark.asyncio
    async def test_mark_completed_rejects_already_completed(self, tmp_path):
        """Regression: re-completing a workflow must return False."""
        try:
            from workflows.persistence.engine import DatabaseConfig
            from workflows.persistence.repository import WorkflowPersistence
        except ImportError:
            pytest.skip("persistence deps not available")

        db_path = tmp_path / "test.db"
        config = DatabaseConfig(
            url=f"sqlite+aiosqlite:///{db_path}",
        )
        repo = WorkflowPersistence(config)
        await repo.initialize()

        # Create a workflow via save_checkpoint with a mock
        mock_wf = MagicMock()
        mock_wf.workflow_id = "bh22-m4-test"
        mock_wf.workflow_type = "proposal"
        mock_wf.current_state = "draft"
        mock_wf.to_dict.return_value = {"id": "bh22-m4-test"}

        await repo.save_checkpoint(mock_wf, actor_id="test-actor")

        # First completion should succeed
        result1 = await repo.mark_completed("bh22-m4-test", "test-actor", "completed")
        assert result1 is True

        # Second completion must be rejected
        result2 = await repo.mark_completed("bh22-m4-test", "test-actor", "completed")
        assert result2 is False


# --- BH22-L1: drift_baseline_data bool guard ---


class TestDriftBaselineDataBoolGuard:
    """BH22-L1: drift_baseline_data must reject bool elements."""

    def test_lambda_drift_baseline_rejects_bool(self):
        """Regression: Lambda must reject bool in drift_baseline_data."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "body": json.dumps(
                {
                    "proposal_summary": "Test",
                    "drift_baseline_data": [True, 0.5, 0.6],
                }
            ),
        }

        result = handler(event, None)
        assert result["statusCode"] == 400
        body = json.loads(result["body"])
        assert "error" in body
        assert "numeric" in body["error"].lower() or "bool" in body["error"].lower()

    def test_mcp_drift_baseline_rejects_bool(self):
        """Regression: validate_drift_baseline must reject bool elements."""
        from aegis_governance.middleware import validate_drift_baseline

        with pytest.raises(TypeError, match="bool"):
            validate_drift_baseline({"drift_baseline_data": [True, 0.5, 0.6]})

    def test_lambda_drift_baseline_accepts_valid(self):
        """Positive test: valid numeric baseline data should be accepted."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "body": json.dumps(
                {
                    "proposal_summary": "Test",
                    "drift_baseline_data": [0.1, 0.2, 0.3, 0.4, 0.5],
                }
            ),
        }

        result = handler(event, None)
        assert result["statusCode"] == 200


# --- BH22-L2: Governance active_overrides eviction ---


class TestGovernanceEviction:
    """BH22-L2: Governance must evict expired overrides."""

    def test_get_active_overrides_evicts_expired(self):
        """Regression: get_active_overrides must evict expired workflows."""
        from actors.governance import Governance

        gov = Governance(actor_id="gov-1", name="Test Governance")

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )
        assert result.success

        # Forcibly expire the override
        with gov._lock:
            wf = gov.active_overrides["prop-1"]
            wf.expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)

        summary = gov.get_active_overrides()
        assert "prop-1" not in summary
        assert len(gov.active_overrides) == 0

    def test_evict_expired_preserves_active(self):
        """Positive test: non-expired overrides must survive eviction."""
        from actors.governance import Governance

        gov = Governance(actor_id="gov-1", name="Test Governance")

        gov.initiate_override("prop-1", "test", ["risk"], "alice")
        gov.initiate_override("prop-2", "test", ["risk"], "bob")

        # Expire only one
        with gov._lock:
            wf1 = gov.active_overrides["prop-1"]
            wf1.expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)

        summary = gov.get_active_overrides()
        assert "prop-1" not in summary
        assert "prop-2" in summary


# --- BH22-L3: AFABridge authorization string-as-iterable ---


class TestAuthorizationStringGuard:
    """BH22-L3: _evaluate_authorization must handle string inputs safely."""

    def test_authorization_string_required_treated_as_single_item(self):
        """Regression: string 'admin' must not be iterated as characters."""
        from integration.afa_bridge import (
            AFABridge,
            DecisionOutcome,
            DecisionRequest,
            DecisionType,
        )

        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-1",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="agent-1",
            context={
                "required_authorizations": "admin",
                "provided_authorizations": "admin",
            },
        )

        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.APPROVED

    def test_authorization_string_required_missing_provided(self):
        """Regression: string 'admin' required but not provided."""
        from integration.afa_bridge import (
            AFABridge,
            DecisionOutcome,
            DecisionRequest,
            DecisionType,
        )

        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-2",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="agent-1",
            context={
                "required_authorizations": "admin",
                "provided_authorizations": [],
            },
        )

        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.PENDING
        assert "admin" in response.rationale

    def test_authorization_list_still_works(self):
        """Positive test: list inputs must continue working correctly."""
        from integration.afa_bridge import (
            AFABridge,
            DecisionOutcome,
            DecisionRequest,
            DecisionType,
        )

        bridge = AFABridge()
        request = DecisionRequest(
            request_id="test-3",
            decision_type=DecisionType.AUTHORIZATION,
            agent_id="agent-1",
            context={
                "required_authorizations": ["admin", "deploy"],
                "provided_authorizations": ["admin"],
            },
        )

        response = bridge.request_decision(request)
        assert response.outcome == DecisionOutcome.PENDING
        assert "deploy" in response.rationale
