"""Tests for AEGIS Cross-Channel Identity (Phase 2a).

Tests cover:
- Customer tier normalization (aliases → canonical)
- customer.py record_usage() writes channel counters
- Lambda _extract_tenant_id reads authorizer context (Unkey path)
- Lambda _inject_customer_context forwards rate/quota headers
- MCP server reads AEGIS_CUSTOMER_ID env var
- AuditMiddleware includes customer_id in metadata
- CLI --customer-id flag parsing
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from aegis_governance.customer import Customer, CustomerManager

# ---------------------------------------------------------------------------
# Customer tier normalization
# ---------------------------------------------------------------------------


class TestCustomerTierNormalization:
    """Verify tier aliases are normalized at construction time."""

    def test_free_alias_normalizes_to_community(self) -> None:
        c = Customer(
            customer_id="cust_test1",
            name="Test",
            email="t@t.com",
            tier="free",
        )
        assert c.tier == "community"

    def test_pro_alias_normalizes_to_professional(self) -> None:
        c = Customer(
            customer_id="cust_test2",
            name="Test",
            email="t@t.com",
            tier="pro",
        )
        assert c.tier == "professional"

    def test_canonical_tier_unchanged(self) -> None:
        for tier in ("community", "professional", "enterprise", "financial_services"):
            c = Customer(
                customer_id="cust_test3",
                name="Test",
                email="t@t.com",
                tier=tier,
            )
            assert c.tier == tier

    def test_invalid_tier_raises(self) -> None:
        with pytest.raises(ValueError, match="tier must be"):
            Customer(
                customer_id="cust_test4",
                name="Test",
                email="t@t.com",
                tier="platinum",
            )

    def test_financial_services_tier(self) -> None:
        c = Customer(
            customer_id="cust_fs1",
            name="BigBank",
            email="admin@bigbank.com",
            tier="financial_services",
        )
        assert c.tier == "financial_services"


# ---------------------------------------------------------------------------
# record_usage channel counter
# ---------------------------------------------------------------------------


class TestRecordUsageChannel:
    """Verify record_usage writes channel counters to DynamoDB."""

    def test_record_usage_includes_channel_in_expression(self) -> None:
        mock_table = MagicMock()
        mock_resource = MagicMock()
        mock_resource.Table.return_value = mock_table

        mgr = CustomerManager(
            table_name="test-table",
            dynamodb_resource=mock_resource,
        )
        mgr.record_usage("cust_abc", channel="mcp", route="/evaluate")

        mock_table.update_item.assert_called_once()
        call_kwargs = mock_table.update_item.call_args[1]

        # Verify channel is in the expression attribute names
        assert "#ch" in call_kwargs["ExpressionAttributeNames"]
        assert call_kwargs["ExpressionAttributeNames"]["#ch"] == "mcp"

        # Verify the update expression includes channel counter
        expr = call_kwargs["UpdateExpression"]
        assert "channels.#ch" in expr

    def test_record_usage_different_channels(self) -> None:
        for channel in ("api", "mcp", "sdk", "cli", "github-action"):
            mock_table = MagicMock()
            mock_resource = MagicMock()
            mock_resource.Table.return_value = mock_table

            mgr = CustomerManager(
                table_name="test-table",
                dynamodb_resource=mock_resource,
            )
            mgr.record_usage("cust_x", channel=channel, route="/evaluate")

            call_kwargs = mock_table.update_item.call_args[1]
            assert call_kwargs["ExpressionAttributeNames"]["#ch"] == channel


# ---------------------------------------------------------------------------
# Lambda _extract_tenant_id (Unkey authorizer path)
# ---------------------------------------------------------------------------


class TestLambdaExtractTenantId:
    """Test _extract_tenant_id reads authorizer context before legacy path."""

    def test_authorizer_customer_id_takes_precedence(self) -> None:
        from lambda_handler import _extract_tenant_id

        event: dict[str, Any] = {
            "requestContext": {
                "authorizer": {"customer_id": "cust_unkey123"},
                "identity": {"apiKeyId": "legacy-key-id"},
            }
        }
        assert _extract_tenant_id(event) == "cust_unkey123"

    def test_falls_back_to_api_key_id(self) -> None:
        from lambda_handler import _extract_tenant_id

        event: dict[str, Any] = {
            "requestContext": {
                "identity": {"apiKeyId": "apigw-key-456"},
            }
        }
        assert _extract_tenant_id(event) == "apigw-key-456"

    def test_empty_authorizer_falls_back(self) -> None:
        from lambda_handler import _extract_tenant_id

        event: dict[str, Any] = {
            "requestContext": {
                "authorizer": {},
                "identity": {"apiKeyId": "fallback-key"},
            }
        }
        assert _extract_tenant_id(event) == "fallback-key"

    def test_no_context_returns_anonymous(self) -> None:
        from lambda_handler import _extract_tenant_id

        assert _extract_tenant_id({}) == "anonymous"


# ---------------------------------------------------------------------------
# Lambda _inject_customer_context (rate/quota headers)
# ---------------------------------------------------------------------------


class TestLambdaInjectCustomerContext:
    """Test response headers include rate/quota from authorizer."""

    def _make_response(self) -> dict[str, Any]:
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"status": "proceed"}),
        }

    def _make_customer(self) -> Any:
        return Customer(
            customer_id="cust_rq1",
            name="Test",
            email="t@t.com",
            tier="professional",
        )

    def test_rate_headers_from_authorizer(self) -> None:
        from lambda_handler import _inject_customer_context

        event: dict[str, Any] = {
            "requestContext": {
                "authorizer": {
                    "rate_remaining": 95,
                }
            }
        }
        resp = _inject_customer_context(
            self._make_response(), self._make_customer(), event
        )
        assert resp["headers"]["X-AEGIS-Rate-Remaining"] == "95"
        # quota_remaining is computed by Customer API, not authorizer
        assert "X-AEGIS-Quota-Remaining" not in resp["headers"]

    def test_no_authorizer_no_rate_headers(self) -> None:
        from lambda_handler import _inject_customer_context

        resp = _inject_customer_context(
            self._make_response(), self._make_customer(), {}
        )
        assert "X-AEGIS-Rate-Remaining" not in resp["headers"]

    def test_no_event_no_rate_headers(self) -> None:
        from lambda_handler import _inject_customer_context

        resp = _inject_customer_context(self._make_response(), self._make_customer())
        assert "X-AEGIS-Rate-Remaining" not in resp["headers"]

    def test_none_customer_returns_unchanged(self) -> None:
        from lambda_handler import _inject_customer_context

        original = self._make_response()
        resp = _inject_customer_context(original, None, {})
        assert resp is original


# ---------------------------------------------------------------------------
# MCP server AEGIS_CUSTOMER_ID env var
# ---------------------------------------------------------------------------


class TestMCPCustomerId:
    """Test MCP server reads AEGIS_CUSTOMER_ID env var."""

    def test_audit_middleware_receives_customer_id(self) -> None:
        """When AEGIS_CUSTOMER_ID is set, AuditMiddleware gets it."""
        from aegis_governance import mcp_server

        # Clear cached state so _get_audit() re-initializes
        mcp_server._STATE.clear()

        with patch.dict("os.environ", {"AEGIS_CUSTOMER_ID": "cust_mcp_test"}):
            audit = mcp_server._get_audit()
            assert audit.customer_id == "cust_mcp_test"

        # Cleanup
        mcp_server._STATE.clear()

    def test_no_env_var_means_none(self) -> None:
        from aegis_governance import mcp_server

        mcp_server._STATE.clear()

        with patch.dict("os.environ", {}, clear=True):
            # Ensure AEGIS_CUSTOMER_ID is not set
            import os

            os.environ.pop("AEGIS_CUSTOMER_ID", None)
            audit = mcp_server._get_audit()
            assert audit.customer_id is None

        mcp_server._STATE.clear()


# ---------------------------------------------------------------------------
# AuditMiddleware customer_id in metadata
# ---------------------------------------------------------------------------


class TestAuditMiddlewareCustomerId:
    """Test AuditMiddleware includes customer_id in audit events."""

    def test_customer_id_in_audit_metadata(self) -> None:
        from aegis_governance.middleware import AuditMiddleware

        audit = AuditMiddleware(source="test", customer_id="cust_audit1")
        assert audit.customer_id == "cust_audit1"

    def test_no_customer_id_default(self) -> None:
        from aegis_governance.middleware import AuditMiddleware

        audit = AuditMiddleware(source="test")
        assert audit.customer_id is None


# ---------------------------------------------------------------------------
# CLI --customer-id flag
# ---------------------------------------------------------------------------


class TestCLICustomerIdFlag:
    """Test CLI --customer-id global flag parsing."""

    def test_customer_id_parsed(self) -> None:
        from cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["--customer-id", "cust_cli1", "version"])
        assert args.customer_id == "cust_cli1"

    def test_customer_id_from_env(self) -> None:
        from cli import build_parser

        with patch.dict("os.environ", {"AEGIS_CUSTOMER_ID": "cust_env1"}):
            parser = build_parser()
            args = parser.parse_args(["version"])
            assert args.customer_id == "cust_env1"

    def test_customer_id_default_none(self) -> None:
        from cli import build_parser

        with patch.dict("os.environ", {}, clear=True):
            import os

            os.environ.pop("AEGIS_CUSTOMER_ID", None)
            parser = build_parser()
            args = parser.parse_args(["version"])
            assert args.customer_id is None


# ---------------------------------------------------------------------------
# CustomerManager update_customer tier normalization
# ---------------------------------------------------------------------------


class TestCustomerManagerTierUpdate:
    """Verify tier aliases are normalized on update_customer."""

    def test_update_tier_free_normalizes(self) -> None:
        mock_table = MagicMock()
        mock_resource = MagicMock()
        mock_resource.Table.return_value = mock_table

        # Simulate existing customer in DynamoDB
        mock_table.get_item.return_value = {
            "Item": {
                "pk": "CUSTOMER#cust_up1",
                "sk": "PROFILE",
                "customer_id": "cust_up1",
                "name": "Test",
                "email": "t@t.com",
                "company": "",
                "tier": "community",
                "status": "active",
                "api_key_id": "",
                "created_at": "2026-01-01T00:00:00+00:00",
                "updated_at": "2026-01-01T00:00:00+00:00",
                "metadata": {},
            }
        }

        mgr = CustomerManager(
            table_name="test-table",
            dynamodb_resource=mock_resource,
        )
        updated = mgr.update_customer("cust_up1", tier="free")
        assert updated is not None
        assert updated.tier == "community"

    def test_update_tier_invalid_raises(self) -> None:
        mock_table = MagicMock()
        mock_resource = MagicMock()
        mock_resource.Table.return_value = mock_table

        mock_table.get_item.return_value = {
            "Item": {
                "pk": "CUSTOMER#cust_up2",
                "sk": "PROFILE",
                "customer_id": "cust_up2",
                "name": "Test",
                "email": "t@t.com",
                "tier": "community",
                "status": "active",
            }
        }

        mgr = CustomerManager(
            table_name="test-table",
            dynamodb_resource=mock_resource,
        )
        with pytest.raises(ValueError, match="tier must be"):
            mgr.update_customer("cust_up2", tier="gold")
