"""Bug Hunt #45 regression tests.

BH45-Codex-M1: ProposalWorkflow.transition_to() metadata mutable reference
BH45-M1: MCP risk_score eager evaluation (transport parity with Lambda BH13-M1)
BH45-M2: BayesianPosterior.update_prior missing current_mean/current_std validation
BH45-L1: PipelineConfig missing retention_days/drift_window_size validation
BH45-L2: PipelineConfig pii_encryption_on_error/storage_on_error accept arbitrary strings
"""

import math

import pytest

# --- BH45-Codex-M1: ProposalWorkflow transition metadata deep copy ---


class TestBH45CodexM1TransitionMetadataDeepCopy:
    """Codex finding: transition_to() stored metadata by reference."""

    def test_nested_metadata_mutation_does_not_corrupt_audit(self):
        """Mutating nested metadata after transition must not alter stored data."""
        from workflows.proposal import ProposalMetadata, ProposalState, ProposalWorkflow

        metadata = ProposalMetadata(title="T", description="D", author_id="alice")
        wf = ProposalWorkflow(metadata)

        transition_meta = {"nested": {"key": "original"}}
        wf.transition_to(
            ProposalState.SUBMITTED, actor_id="a", metadata=transition_meta
        )

        # Mutate the original dict
        transition_meta["nested"]["key"] = "mutated"
        transition_meta["injected"] = True

        stored = wf.transitions[-1].metadata
        assert stored == {"nested": {"key": "original"}}
        assert "injected" not in stored

    def test_none_metadata_becomes_empty_dict(self):
        """None metadata should become {} (not None)."""
        from workflows.proposal import ProposalMetadata, ProposalState, ProposalWorkflow

        metadata = ProposalMetadata(title="T", description="D", author_id="alice")
        wf = ProposalWorkflow(metadata)
        wf.transition_to(ProposalState.SUBMITTED, actor_id="a", metadata=None)

        assert wf.transitions[-1].metadata == {}

    def test_empty_dict_metadata_not_falsy_skipped(self):
        """Empty dict {} should be stored as {} (not replaced by default)."""
        from workflows.proposal import ProposalMetadata, ProposalState, ProposalWorkflow

        metadata = ProposalMetadata(title="T", description="D", author_id="alice")
        wf = ProposalWorkflow(metadata)
        wf.transition_to(ProposalState.SUBMITTED, actor_id="a", metadata={})

        assert wf.transitions[-1].metadata == {}


# --- BH45-M1: MCP risk_score eager evaluation ---


class TestBH45M1MCPRiskScoreEagerEval:
    """MCP eager evaluation of risk_score fallback when risk_proposed is present."""

    def test_risk_proposed_present_ignores_invalid_risk_score(self):
        """When risk_proposed is valid, invalid risk_score should be ignored."""
        from aegis_governance.middleware import validate_float

        # Simulate arguments where risk_proposed is valid but risk_score is bool
        arguments = {"risk_proposed": 0.3, "risk_score": True}

        # The new code should use risk_proposed and never touch risk_score
        result = (
            validate_float(arguments, "risk_proposed", 0.0)
            if arguments.get("risk_proposed") is not None
            else validate_float(arguments, "risk_score", 0.0)
        )
        assert result == pytest.approx(0.3)

    def test_risk_proposed_none_falls_back_to_risk_score(self):
        """When risk_proposed is null/missing, should fall back to risk_score."""
        from aegis_governance.middleware import validate_float

        arguments = {"risk_score": 0.5}

        result = (
            validate_float(arguments, "risk_proposed", 0.0)
            if arguments.get("risk_proposed") is not None
            else validate_float(arguments, "risk_score", 0.0)
        )
        assert result == pytest.approx(0.5)

    def test_risk_proposed_zero_not_treated_as_missing(self):
        """risk_proposed=0.0 is a valid value, not a signal to fall back."""
        from aegis_governance.middleware import validate_float

        arguments = {"risk_proposed": 0.0, "risk_score": 0.9}

        result = (
            validate_float(arguments, "risk_proposed", 0.0)
            if arguments.get("risk_proposed") is not None
            else validate_float(arguments, "risk_score", 0.0)
        )
        assert result == pytest.approx(0.0)


# --- BH45-M2: BayesianPosterior.update_prior validation ---


class TestBH45M2BayesianUpdatePriorValidation:
    """update_prior must validate current_mean and current_std parameters."""

    def _make_calculator(self):
        from engine.bayesian import BayesianPosterior

        return BayesianPosterior(prior_mean=0.0, prior_std=1.0, likelihood_std=0.5)

    def test_current_mean_bool_true_raises(self):
        calc = self._make_calculator()
        with pytest.raises(TypeError, match="current_mean must be a number, got bool"):
            calc.update_prior([0.5, 0.6], current_mean=True)

    def test_current_mean_bool_false_raises(self):
        calc = self._make_calculator()
        with pytest.raises(TypeError, match="current_mean must be a number, got bool"):
            calc.update_prior([0.5, 0.6], current_mean=False)

    def test_current_mean_nan_raises(self):
        calc = self._make_calculator()
        with pytest.raises(ValueError, match="current_mean must be finite"):
            calc.update_prior([0.5, 0.6], current_mean=float("nan"))

    def test_current_mean_inf_raises(self):
        calc = self._make_calculator()
        with pytest.raises(ValueError, match="current_mean must be finite"):
            calc.update_prior([0.5, 0.6], current_mean=float("inf"))

    def test_current_mean_neg_inf_raises(self):
        calc = self._make_calculator()
        with pytest.raises(ValueError, match="current_mean must be finite"):
            calc.update_prior([0.5, 0.6], current_mean=float("-inf"))

    def test_current_std_zero_raises(self):
        calc = self._make_calculator()
        with pytest.raises(ValueError):
            calc.update_prior([0.5, 0.6], current_std=0.0)

    def test_current_std_negative_raises(self):
        calc = self._make_calculator()
        with pytest.raises(ValueError):
            calc.update_prior([0.5, 0.6], current_std=-1.0)

    def test_current_std_nan_raises(self):
        calc = self._make_calculator()
        with pytest.raises(ValueError):
            calc.update_prior([0.5, 0.6], current_std=float("nan"))

    def test_current_std_inf_raises(self):
        calc = self._make_calculator()
        with pytest.raises(ValueError):
            calc.update_prior([0.5, 0.6], current_std=float("inf"))

    def test_valid_current_mean_and_std_accepted(self):
        calc = self._make_calculator()
        mean, std = calc.update_prior([0.5, 0.6], current_mean=0.5, current_std=0.3)
        assert math.isfinite(mean)
        assert math.isfinite(std)
        assert std > 0

    def test_none_current_mean_uses_prior(self):
        """None values should fall back to prior (existing behavior)."""
        calc = self._make_calculator()
        mean, std = calc.update_prior([0.5, 0.6], current_mean=None, current_std=None)
        assert math.isfinite(mean)
        assert math.isfinite(std)


# --- BH45-L1: PipelineConfig retention_days/drift_window_size validation ---


class TestBH45L1PipelineConfigIntValidation:
    """PipelineConfig must validate retention_days and drift_window_size."""

    def test_retention_days_zero_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="retention_days must be >= 1"):
            PipelineConfig(retention_days=0)

    def test_retention_days_negative_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="retention_days must be >= 1"):
            PipelineConfig(retention_days=-5)

    def test_retention_days_bool_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(TypeError, match="retention_days must be an integer"):
            PipelineConfig(retention_days=True)

    def test_drift_window_size_zero_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="drift_window_size must be >= 1"):
            PipelineConfig(drift_window_size=0)

    def test_drift_window_size_negative_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="drift_window_size must be >= 1"):
            PipelineConfig(drift_window_size=-1)

    def test_drift_window_size_bool_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(TypeError, match="drift_window_size must be an integer"):
            PipelineConfig(drift_window_size=True)

    def test_valid_values_accepted(self):
        from telemetry.pipeline import PipelineConfig

        cfg = PipelineConfig(retention_days=30, drift_window_size=500)
        assert cfg.retention_days == 30
        assert cfg.drift_window_size == 500


# --- BH45-L2: PipelineConfig enum string validation ---


class TestBH45L2PipelineConfigEnumValidation:
    """PipelineConfig must reject invalid enum string values."""

    def test_pii_encryption_on_error_typo_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="pii_encryption_on_error"):
            PipelineConfig(pii_encryption_on_error="wanr")

    def test_pii_encryption_on_error_ignore_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="pii_encryption_on_error"):
            PipelineConfig(pii_encryption_on_error="ignore")

    def test_storage_on_error_typo_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="storage_on_error"):
            PipelineConfig(storage_on_error="ignore")

    def test_storage_on_error_drop_invalid(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="storage_on_error"):
            PipelineConfig(storage_on_error="drop")

    def test_valid_pii_values_accepted(self):
        from telemetry.pipeline import PipelineConfig

        for val in ("warn", "drop", "raise"):
            cfg = PipelineConfig(pii_encryption_on_error=val)
            assert cfg.pii_encryption_on_error == val

    def test_valid_storage_values_accepted(self):
        from telemetry.pipeline import PipelineConfig

        for val in ("warn", "raise"):
            cfg = PipelineConfig(storage_on_error=val)
            assert cfg.storage_on_error == val


# --- BH45-D1: _apply_drift_overrides unconditionally recomputes next_steps ---


class TestBH45D1DriftOverridesPreservesNextSteps:
    """BH45-D1: When drift_result is None, caller's next_steps must be preserved."""

    def test_none_drift_preserves_caller_next_steps(self):
        """When drift_result is None, original next_steps are returned unchanged."""
        from integration.pcw_decide import PCWPhase, PCWStatus, _apply_drift_overrides

        caller_steps = ["custom_step_1", "custom_step_2"]
        _, _, _, returned_steps = _apply_drift_overrides(
            drift_result=None,
            status=PCWStatus.PROCEED,
            override_eligible=True,
            override_requires=["dual_sig"],
            rationale="test",
            phase=PCWPhase.COMMIT,
            failing_gates=[],
            next_steps=caller_steps,
        )
        assert returned_steps == caller_steps

    def test_none_drift_no_next_steps_recomputes(self):
        """When drift_result is None and next_steps is None, steps are recomputed."""
        from integration.pcw_decide import PCWPhase, PCWStatus, _apply_drift_overrides

        _, _, _, returned_steps = _apply_drift_overrides(
            drift_result=None,
            status=PCWStatus.PROCEED,
            override_eligible=True,
            override_requires=[],
            rationale="test",
            phase=PCWPhase.COMMIT,
            failing_gates=[],
            next_steps=None,
        )
        # Should get default steps for COMMIT/PROCEED, not None
        assert isinstance(returned_steps, list)

    def test_critical_drift_replaces_next_steps(self):
        """When drift_result is CRITICAL, steps are overridden regardless."""
        from engine.drift import DriftAction, DriftResult, DriftStatus
        from integration.pcw_decide import PCWPhase, PCWStatus, _apply_drift_overrides

        drift = DriftResult(
            status=DriftStatus.CRITICAL,
            kl_divergence=2.5,
            action=DriftAction.HALT_AND_RECALIBRATE,
            baseline_hash="abc123",
            window_size=100,
        )
        caller_steps = ["should_be_replaced"]
        _, _, _, returned_steps = _apply_drift_overrides(
            drift_result=drift,
            status=PCWStatus.PROCEED,
            override_eligible=True,
            override_requires=[],
            rationale="test",
            phase=PCWPhase.COMMIT,
            failing_gates=[],
            next_steps=caller_steps,
        )
        # CRITICAL drift produces override-specific steps
        assert returned_steps != caller_steps


# --- BH45-D2: sign_tools_list doesn't increment _schema_revisions ---


class TestBH45D2SchemaRevisionIncrement:
    """BH45-D2: schemaRevision must increment when tool schema changes."""

    def _make_signer(self):
        from crypto.schema_signer import ToolSchemaSigner

        return ToolSchemaSigner(issuer="test")

    def test_revision_increments_on_schema_change(self):
        """Sign, modify tool, re-sign: revision should be 2."""
        signer = self._make_signer()
        tools_v1 = [{"name": "foo", "description": "v1", "inputSchema": {}}]
        result1 = signer.sign_tools_list(tools_v1)
        rev1 = result1["toolProofs"][0]["statement"]["tool"]["schemaRevision"]
        assert rev1 == 1

        tools_v2 = [
            {"name": "foo", "description": "v2", "inputSchema": {"type": "object"}}
        ]
        result2 = signer.sign_tools_list(tools_v2)
        rev2 = result2["toolProofs"][0]["statement"]["tool"]["schemaRevision"]
        assert rev2 == 2

    def test_no_increment_same_schema(self):
        """Sign same tools twice: revision stays at 1."""
        signer = self._make_signer()
        tools = [{"name": "bar", "description": "same", "inputSchema": {}}]
        signer.sign_tools_list(tools)
        result2 = signer.sign_tools_list(tools)
        rev = result2["toolProofs"][0]["statement"]["tool"]["schemaRevision"]
        assert rev == 1

    def test_new_tool_starts_at_revision_1(self):
        """A brand new tool gets schemaRevision 1."""
        signer = self._make_signer()
        tools = [{"name": "new_tool", "description": "fresh", "inputSchema": {}}]
        result = signer.sign_tools_list(tools)
        rev = result["toolProofs"][0]["statement"]["tool"]["schemaRevision"]
        assert rev == 1


# --- BH45-D3: QUORUM_MET with zero decisive votes ---


class TestBH45D3QuorumAllAbstained:
    """BH45-D3: All-abstain quorum must flag all_abstained on ConsensusResult."""

    def test_quorum_met_all_abstain_flags_correctly(self):
        """All voters abstain → QUORUM_MET with all_abstained=True."""
        from workflows.consensus import (
            ConsensusConfig,
            ConsensusWorkflow,
            VoteOutcome,
        )

        config = ConsensusConfig(
            quorum_percentage=0.5,
            approval_threshold=0.67,
            timeout_hours=1,
        )
        wf = ConsensusWorkflow(
            proposal_id="p1",
            eligible_voters={"v1", "v2", "v3"},
            config=config,
        )

        wf.cast_vote("v1", VoteOutcome.ABSTAIN, "no opinion")
        wf.cast_vote("v2", VoteOutcome.ABSTAIN, "pass")

        result = wf.get_result()
        assert result is not None
        assert result.all_abstained is True
        assert result.abstention_count == 2
        assert result.decisive_votes == 0

    def test_quorum_met_mixed_votes_not_flagged(self):
        """Mix of approve+abstain → all_abstained=False."""
        from workflows.consensus import (
            ConsensusConfig,
            ConsensusWorkflow,
            VoteOutcome,
        )

        config = ConsensusConfig(
            quorum_percentage=0.5,
            approval_threshold=0.67,
            timeout_hours=1,
        )
        wf = ConsensusWorkflow(
            proposal_id="p2",
            eligible_voters={"v1", "v2", "v3"},
            config=config,
        )

        wf.cast_vote("v1", VoteOutcome.APPROVE, "yes")
        wf.cast_vote("v2", VoteOutcome.ABSTAIN, "pass")

        result = wf.get_result()
        assert result is not None
        assert result.all_abstained is False
        assert result.decisive_votes >= 1

    def test_decisive_votes_excludes_abstain_defer(self):
        """decisive_votes counts only APPROVE and REJECT, not ABSTAIN/DEFER."""
        from workflows.consensus import (
            ConsensusConfig,
            ConsensusWorkflow,
            VoteOutcome,
        )

        config = ConsensusConfig(
            quorum_percentage=0.5,
            approval_threshold=0.67,
            timeout_hours=1,
        )
        wf = ConsensusWorkflow(
            proposal_id="p3",
            eligible_voters={"v1", "v2", "v3", "v4", "v5"},
            config=config,
        )

        wf.cast_vote("v1", VoteOutcome.APPROVE, "yes")
        wf.cast_vote("v2", VoteOutcome.REJECT, "no")
        wf.cast_vote("v3", VoteOutcome.ABSTAIN, "pass")

        result = wf.get_result()
        assert result is not None
        assert result.decisive_votes == 2  # APPROVE + REJECT only
        assert result.abstention_count == 1
        assert result.all_abstained is False


# --- TD-1: file_sink path validation at construction ---


class TestTD1FileSinkPathValidation:
    """TD-1: file_sink must validate path at construction, not just at write time."""

    def test_empty_filepath_raises(self):
        from telemetry.emitter import file_sink

        with pytest.raises(ValueError, match="non-empty string"):
            file_sink("")

    def test_whitespace_filepath_raises(self):
        from telemetry.emitter import file_sink

        with pytest.raises(ValueError, match="non-empty string"):
            file_sink("   ")

    def test_nonexistent_parent_raises(self):
        from telemetry.emitter import file_sink

        with pytest.raises(ValueError, match="parent directory does not exist"):
            file_sink("/nonexistent/dir/that/will/never/exist/log.jsonl")

    def test_valid_filepath_accepted(self, tmp_path):
        from telemetry.emitter import file_sink

        logfile = str(tmp_path / "events.jsonl")
        sink = file_sink(logfile)
        assert callable(sink)


# --- TD-2: SerializableMixin applied to all workflow classes ---


class TestTD2SerializableMixin:
    """TD-2: All LIBERTAS workflow classes use SerializableMixin."""

    def test_consensus_workflow_is_serializable(self):
        from workflows.consensus import ConsensusWorkflow
        from workflows.serialization import SerializableMixin

        assert issubclass(ConsensusWorkflow, SerializableMixin)

    def test_override_workflow_is_serializable(self):
        from workflows.override import OverrideWorkflow
        from workflows.serialization import SerializableMixin

        assert issubclass(OverrideWorkflow, SerializableMixin)

    def test_proposal_workflow_is_serializable(self):
        from workflows.proposal import ProposalWorkflow
        from workflows.serialization import SerializableMixin

        assert issubclass(ProposalWorkflow, SerializableMixin)

    def test_mixin_defines_required_interface(self):
        """SerializableMixin defines the 5 required methods/properties."""
        from workflows.serialization import SerializableMixin

        assert hasattr(SerializableMixin, "workflow_id")
        assert hasattr(SerializableMixin, "workflow_type")
        assert hasattr(SerializableMixin, "current_state")
        assert hasattr(SerializableMixin, "to_dict")
        assert hasattr(SerializableMixin, "from_dict")
