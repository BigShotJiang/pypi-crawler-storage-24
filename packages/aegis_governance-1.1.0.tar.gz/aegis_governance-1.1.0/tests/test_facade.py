"""Tests for aegis_governance facade package.

Verifies that all public API symbols are importable through the
aegis_governance namespace.
"""


class TestFacadeImports:
    """All public API should be importable from aegis_governance."""

    def test_import_version(self):
        from aegis_governance import __version__

        assert isinstance(__version__, str)
        assert len(__version__) > 0

    def test_import_config(self):
        from aegis_governance import AegisConfig, KLDriftConfig

        config = AegisConfig.default()
        assert isinstance(config, AegisConfig)
        assert isinstance(config.kl_drift, KLDriftConfig)

    def test_import_pcw_decide(self):
        from aegis_governance import (
            pcw_decide,
        )

        assert callable(pcw_decide)

    def test_import_gate_evaluator(self):
        from aegis_governance import (
            GateEvaluator,
        )

        evaluator = GateEvaluator()
        assert isinstance(evaluator, GateEvaluator)

    def test_import_utility(self):
        from aegis_governance import UtilityCalculator

        assert UtilityCalculator is not None

    def test_import_engine(self):
        from aegis_governance import (
            BayesianPosterior,
        )

        assert BayesianPosterior is not None

    def test_import_integration(self):
        from aegis_governance import AFABridge

        assert AFABridge is not None

    def test_import_workflows(self):
        from aegis_governance import (
            ProposalWorkflow,
        )

        assert ProposalWorkflow is not None

    def test_import_actors(self):
        from aegis_governance import (
            ActorRole,
        )

        assert ActorRole.PROPOSER is not None

    def test_import_helpers(self):
        from aegis_governance import quick_risk_check

        assert callable(quick_risk_check)


class TestFacadeEndToEnd:
    """Test full SDK workflow through facade imports."""

    def test_config_to_evaluate(self):
        """Config → GateEvaluator → pcw_decide end-to-end."""
        from aegis_governance import (
            AegisConfig,
            PCWContext,
            PCWPhase,
            PCWStatus,
            pcw_decide,
        )

        config = AegisConfig.default()
        evaluator = config.create_gate_evaluator()

        context = PCWContext(
            agent_id="test-agent",
            session_id="test-session",
            phase=PCWPhase.PLAN,
            proposal_summary="Add caching layer",
            estimated_impact="low",
            risk_proposed=0.02,
            complexity_score=0.8,
            quality_score=0.9,
        )

        decision = pcw_decide(context, gate_evaluator=evaluator)
        assert decision.status in (
            PCWStatus.PROCEED,
            PCWStatus.PAUSE,
            PCWStatus.ESCALATE,
            PCWStatus.HALT,
        )
        assert decision.gates_passed >= 0
        assert decision.decision_id is not None

    def test_all_exports(self):
        """Verify __all__ is complete and consistent."""
        import aegis_governance

        for name in aegis_governance.__all__:
            assert hasattr(aegis_governance, name), f"Missing export: {name}"
