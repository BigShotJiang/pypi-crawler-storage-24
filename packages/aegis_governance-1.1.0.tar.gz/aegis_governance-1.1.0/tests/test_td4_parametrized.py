"""TD-4: Parametrized test coverage.

Replaces repetitive test patterns with pytest.mark.parametrize for:
- GateEvaluator threshold/status combos
- DriftMonitor threshold validation
- PipelineConfig validation
- ExecutionPlan validation
- ConsensusConfig validation
"""

from __future__ import annotations

import pytest

from actors.executor import ExecutionPlan
from engine.drift import DriftMonitor
from engine.gates import GateEvaluator, GateType
from engine.utility import (
    UtilityResult,
)
from telemetry.pipeline import PipelineConfig
from workflows.consensus import ConsensusConfig

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_utility_result(lcb: float = 0.5) -> UtilityResult:
    """Build a valid UtilityResult with specified LCB."""
    return UtilityResult(
        raw=lcb + 0.5,
        variance=0.1,
        lcb=lcb,
        components=None,
        decision_path="INVESTMENT",
    )


# ===================================================================
# Gate Evaluation -- threshold / status combinations
# ===================================================================


class TestGateRiskThresholdParametrized:
    """Parametrized tests for risk gate pass/fail across delta magnitudes."""

    @pytest.mark.parametrize(
        "baseline,proposed,expected_passed",
        [
            pytest.param(0.1, 0.1, True, id="no-change-passes"),
            pytest.param(0.1, 0.11, True, id="small-increase-passes"),
            pytest.param(0.1, 0.5, False, id="large-increase-fails"),
            pytest.param(0.1, 0.0, True, id="decrease-passes"),
            pytest.param(0.0, 0.0, True, id="both-zero-passes"),
        ],
    )
    def test_risk_gate_threshold(
        self,
        baseline: float,
        proposed: float,
        expected_passed: bool,
    ) -> None:
        """Risk gate pass/fail for various delta magnitudes."""
        ge = GateEvaluator()
        result = ge.evaluate_risk_gate(baseline=baseline, proposed=proposed)
        assert result.passed is expected_passed
        assert result.gate_type == GateType.RISK


class TestGateNoveltyThresholdParametrized:
    """Parametrized tests for novelty gate logistic function."""

    @pytest.mark.parametrize(
        "novelty_score,expected_passed",
        [
            pytest.param(0.0, False, id="zero-novelty-fails"),
            pytest.param(0.5, False, id="mid-novelty-fails"),
            pytest.param(0.7, False, id="at-midpoint-barely-fails"),
            pytest.param(0.85, True, id="high-novelty-passes"),
            pytest.param(1.0, True, id="max-novelty-passes"),
        ],
    )
    def test_novelty_gate_threshold(
        self,
        novelty_score: float,
        expected_passed: bool,
    ) -> None:
        """Novelty gate pass/fail across logistic curve."""
        ge = GateEvaluator()
        result = ge.evaluate_novelty_gate(novelty_score)
        assert result.passed is expected_passed
        assert result.gate_type == GateType.NOVELTY


class TestGateComplexityFloorParametrized:
    """Parametrized tests for complexity floor gate."""

    @pytest.mark.parametrize(
        "complexity_score,expected_passed",
        [
            pytest.param(0.0, False, id="zero-fails"),
            pytest.param(0.49, False, id="just-below-floor-fails"),
            pytest.param(0.5, True, id="at-floor-passes"),
            pytest.param(0.51, True, id="just-above-floor-passes"),
            pytest.param(1.0, True, id="max-passes"),
        ],
    )
    def test_complexity_floor_threshold(
        self,
        complexity_score: float,
        expected_passed: bool,
    ) -> None:
        """Complexity floor pass/fail at boundary values."""
        ge = GateEvaluator()
        result = ge.evaluate_complexity_gate(complexity_score)
        assert result.passed is expected_passed
        assert result.gate_type == GateType.COMPLEXITY


class TestGateQualityThresholdParametrized:
    """Parametrized tests for quality gate score + subscore combos."""

    @pytest.mark.parametrize(
        "quality_score,subscores,expected_passed",
        [
            pytest.param(0.8, [0.7, 0.8], True, id="good-score-good-subs"),
            pytest.param(0.6, [0.7, 0.8], False, id="low-score-good-subs"),
            pytest.param(0.8, [0.0, 0.8], False, id="good-score-zero-sub"),
            pytest.param(0.7, [0.5, 0.5], True, id="at-threshold-passes"),
            pytest.param(0.69, [0.5, 0.5], False, id="below-threshold-fails"),
            pytest.param(0.9, [], False, id="empty-subscores-fails"),
        ],
    )
    def test_quality_gate_combinations(
        self,
        quality_score: float,
        subscores: list[float],
        expected_passed: bool,
    ) -> None:
        """Quality gate pass/fail for score + subscore combinations."""
        ge = GateEvaluator()
        result = ge.evaluate_quality_gate(quality_score, subscores)
        assert result.passed is expected_passed
        assert result.gate_type == GateType.QUALITY


class TestGateUtilityThresholdParametrized:
    """Parametrized tests for utility LCB gate."""

    @pytest.mark.parametrize(
        "lcb,utility_threshold,expected_passed",
        [
            pytest.param(1.0, 0.0, True, id="positive-lcb-passes"),
            pytest.param(0.0, 0.0, False, id="zero-lcb-at-zero-threshold-fails"),
            pytest.param(-1.0, 0.0, False, id="negative-lcb-fails"),
            pytest.param(0.5, 0.5, False, id="at-threshold-fails"),
            pytest.param(0.51, 0.5, True, id="just-above-threshold-passes"),
        ],
    )
    def test_utility_gate_threshold(
        self,
        lcb: float,
        utility_threshold: float,
        expected_passed: bool,
    ) -> None:
        """Utility LCB gate pass/fail at various thresholds."""
        ge = GateEvaluator(utility_threshold=utility_threshold)
        result = ge.evaluate_utility_gate(_make_utility_result(lcb=lcb))
        assert result.passed is expected_passed
        assert result.gate_type == GateType.UTILITY


# ===================================================================
# DriftMonitor -- threshold validation
# ===================================================================


class TestDriftMonitorThresholdParametrized:
    """Parametrized tests for DriftMonitor threshold validation."""

    @pytest.mark.parametrize(
        "tau_w,tau_c,should_raise",
        [
            pytest.param(0.3, 0.5, False, id="valid-default"),
            pytest.param(0.0, 0.5, False, id="zero-warning-valid"),
            pytest.param(0.5, 0.3, True, id="warning-above-critical-invalid"),
            pytest.param(-0.1, 0.5, True, id="negative-warning-invalid"),
            pytest.param(0.3, -0.1, True, id="negative-critical-invalid"),
            pytest.param(0.5, 0.5, True, id="equal-thresholds-invalid"),
        ],
    )
    def test_threshold_validation(
        self,
        tau_w: float,
        tau_c: float,
        should_raise: bool,
    ) -> None:
        """DriftMonitor construction validates threshold ordering."""
        if should_raise:
            with pytest.raises(ValueError):
                DriftMonitor(tau_warning=tau_w, tau_critical=tau_c)
        else:
            dm = DriftMonitor(tau_warning=tau_w, tau_critical=tau_c)
            assert dm.tau_warning == tau_w
            assert dm.tau_critical == tau_c

    @pytest.mark.parametrize(
        "tau_w,tau_c,error_type",
        [
            pytest.param(float("nan"), 0.5, ValueError, id="nan-warning"),
            pytest.param(0.3, float("nan"), ValueError, id="nan-critical"),
            pytest.param(float("inf"), 0.5, ValueError, id="inf-warning"),
            pytest.param(0.3, float("inf"), ValueError, id="inf-critical"),
        ],
    )
    def test_non_finite_threshold_rejected(
        self,
        tau_w: float,
        tau_c: float,
        error_type: type,
    ) -> None:
        """Non-finite threshold values must be rejected."""
        with pytest.raises(error_type):
            DriftMonitor(tau_warning=tau_w, tau_critical=tau_c)

    @pytest.mark.parametrize(
        "num_bins,should_raise,error_type",
        [
            pytest.param(50, False, None, id="valid-bins"),
            pytest.param(1, False, None, id="single-bin-valid"),
            pytest.param(0, True, ValueError, id="zero-bins-invalid"),
            pytest.param(-1, True, ValueError, id="negative-bins-invalid"),
            pytest.param(True, True, TypeError, id="bool-bins-invalid"),
        ],
    )
    def test_num_bins_validation(
        self,
        num_bins: int,
        should_raise: bool,
        error_type: type | None,
    ) -> None:
        """DriftMonitor num_bins validation at construction."""
        if should_raise:
            assert error_type is not None
            with pytest.raises(error_type):
                DriftMonitor(num_bins=num_bins)
        else:
            dm = DriftMonitor(num_bins=num_bins)
            assert dm.num_bins == num_bins


# ===================================================================
# PipelineConfig -- validation
# ===================================================================


class TestPipelineConfigParametrized:
    """Parametrized tests for PipelineConfig validation."""

    @pytest.mark.parametrize(
        "field_name,value,error_type",
        [
            pytest.param("buffer_size", 0, ValueError, id="zero-buffer-size"),
            pytest.param("buffer_size", -1, ValueError, id="negative-buffer-size"),
            pytest.param("buffer_size", True, TypeError, id="bool-buffer-size"),
            pytest.param("flush_threshold", 0, ValueError, id="zero-flush-threshold"),
            pytest.param(
                "flush_threshold", -5, ValueError, id="negative-flush-threshold"
            ),
            pytest.param(
                "flush_threshold", False, TypeError, id="bool-flush-threshold"
            ),
            pytest.param(
                "flush_interval_seconds",
                0,
                ValueError,
                id="zero-flush-interval",
            ),
            pytest.param(
                "flush_interval_seconds",
                -1,
                ValueError,
                id="negative-flush-interval",
            ),
        ],
    )
    def test_invalid_pipeline_config(
        self,
        field_name: str,
        value: int,
        error_type: type,
    ) -> None:
        """PipelineConfig rejects invalid integer configuration values."""
        with pytest.raises(error_type):
            PipelineConfig(**{field_name: value})

    @pytest.mark.parametrize(
        "buffer_size,flush_threshold,flush_interval",
        [
            pytest.param(1, 1, 1, id="all-minimums"),
            pytest.param(100, 50, 30, id="moderate-values"),
            pytest.param(10000, 500, 300, id="large-values"),
        ],
    )
    def test_valid_pipeline_config(
        self,
        buffer_size: int,
        flush_threshold: int,
        flush_interval: int,
    ) -> None:
        """PipelineConfig accepts valid configuration values."""
        config = PipelineConfig(
            buffer_size=buffer_size,
            flush_threshold=flush_threshold,
            flush_interval_seconds=flush_interval,
        )
        assert config.buffer_size == buffer_size
        assert config.flush_threshold == flush_threshold
        assert config.flush_interval_seconds == flush_interval


# ===================================================================
# ExecutionPlan -- validation
# ===================================================================


class TestExecutionPlanParametrized:
    """Parametrized tests for ExecutionPlan validation."""

    @pytest.mark.parametrize(
        "timeout,error_type",
        [
            pytest.param(0, ValueError, id="zero-timeout"),
            pytest.param(-1, ValueError, id="negative-timeout"),
            pytest.param(-100, ValueError, id="large-negative-timeout"),
            pytest.param(True, TypeError, id="bool-timeout"),
            pytest.param(False, TypeError, id="false-bool-timeout"),
            pytest.param(float("inf"), ValueError, id="inf-timeout"),
            pytest.param(float("nan"), ValueError, id="nan-timeout"),
        ],
    )
    def test_invalid_timeout(
        self, timeout: int | float | bool, error_type: type
    ) -> None:
        """ExecutionPlan rejects invalid timeout_seconds values."""
        with pytest.raises(error_type):
            ExecutionPlan(
                proposal_id="prop-test",
                steps=[{"action": "deploy"}],
                rollback_steps=[{"action": "rollback"}],
                timeout_seconds=timeout,
            )

    @pytest.mark.parametrize(
        "timeout",
        [
            pytest.param(1, id="minimum-timeout"),
            pytest.param(60, id="one-minute"),
            pytest.param(3600, id="one-hour"),
            pytest.param(86400, id="one-day"),
        ],
    )
    def test_valid_timeout(self, timeout: int) -> None:
        """ExecutionPlan accepts valid timeout_seconds values."""
        plan = ExecutionPlan(
            proposal_id="prop-ok",
            steps=[{"action": "deploy"}],
            rollback_steps=[{"action": "rollback"}],
            timeout_seconds=timeout,
        )
        assert plan.timeout_seconds == timeout


# ===================================================================
# ConsensusConfig -- validation
# ===================================================================


class TestConsensusConfigParametrized:
    """Parametrized tests for ConsensusConfig validation."""

    @pytest.mark.parametrize(
        "quorum,threshold,should_raise",
        [
            pytest.param(0.0, 0.5, False, id="zero-quorum-valid"),
            pytest.param(0.51, 0.667, False, id="default-valid"),
            pytest.param(1.0, 1.0, False, id="max-values-valid"),
            pytest.param(-0.1, 0.5, True, id="negative-quorum-invalid"),
            pytest.param(1.1, 0.5, True, id="quorum-above-one-invalid"),
            pytest.param(0.5, -0.1, True, id="negative-threshold-invalid"),
            pytest.param(0.5, 1.1, True, id="threshold-above-one-invalid"),
        ],
    )
    def test_quorum_and_threshold_validation(
        self,
        quorum: float,
        threshold: float,
        should_raise: bool,
    ) -> None:
        """ConsensusConfig validates quorum_percentage and approval_threshold."""
        if should_raise:
            with pytest.raises(ValueError):
                ConsensusConfig(
                    quorum_percentage=quorum,
                    approval_threshold=threshold,
                )
        else:
            config = ConsensusConfig(
                quorum_percentage=quorum,
                approval_threshold=threshold,
            )
            assert config.quorum_percentage == quorum
            assert config.approval_threshold == threshold

    @pytest.mark.parametrize(
        "timeout,error_type",
        [
            pytest.param(0, ValueError, id="zero-timeout"),
            pytest.param(-1, ValueError, id="negative-timeout"),
            pytest.param(True, TypeError, id="bool-true-timeout"),
            pytest.param(False, TypeError, id="bool-false-timeout"),
        ],
    )
    def test_timeout_validation(self, timeout: int | bool, error_type: type) -> None:
        """ConsensusConfig rejects invalid timeout_hours values."""
        with pytest.raises(error_type):
            ConsensusConfig(timeout_hours=timeout)

    @pytest.mark.parametrize(
        "timeout",
        [
            pytest.param(1, id="minimum-timeout"),
            pytest.param(48, id="default-timeout"),
            pytest.param(168, id="one-week"),
            pytest.param(8760, id="one-year"),
        ],
    )
    def test_valid_timeout(self, timeout: int) -> None:
        """ConsensusConfig accepts valid timeout_hours values."""
        config = ConsensusConfig(timeout_hours=timeout)
        assert config.timeout_hours == timeout


# ===================================================================
# GateEvaluator constructor -- parametrized invalid thresholds
# ===================================================================


class TestGateEvaluatorConstructorParametrized:
    """Parametrized tests for GateEvaluator constructor validation."""

    @pytest.mark.parametrize(
        "param,value,error_type",
        [
            pytest.param("novelty_k", 0, ValueError, id="zero-novelty-k"),
            pytest.param("novelty_k", -1.0, ValueError, id="negative-novelty-k"),
            pytest.param("novelty_k", float("nan"), ValueError, id="nan-novelty-k"),
            pytest.param("novelty_k", float("inf"), ValueError, id="inf-novelty-k"),
            pytest.param("novelty_k", True, TypeError, id="bool-novelty-k"),
            pytest.param("novelty_N0", -0.1, ValueError, id="negative-novelty-N0"),
            pytest.param(
                "novelty_threshold", -0.1, ValueError, id="negative-novelty-threshold"
            ),
            pytest.param(
                "complexity_floor", -0.1, ValueError, id="negative-complexity-floor"
            ),
            pytest.param(
                "quality_min_score", -0.1, ValueError, id="negative-quality-min-score"
            ),
            pytest.param(
                "complexity_floor", float("nan"), ValueError, id="nan-complexity-floor"
            ),
            pytest.param(
                "complexity_floor", True, TypeError, id="bool-complexity-floor"
            ),
        ],
    )
    def test_invalid_threshold_param(
        self,
        param: str,
        value: float | bool,
        error_type: type,
    ) -> None:
        """GateEvaluator rejects invalid threshold parameters at construction."""
        with pytest.raises(error_type):
            GateEvaluator(**{param: value})

    @pytest.mark.parametrize(
        "trigger_confidence_prob",
        [
            pytest.param(0.0, id="zero-confidence-prob"),
            pytest.param(-0.1, id="negative-confidence-prob"),
            pytest.param(1.1, id="above-one-confidence-prob"),
            pytest.param(float("nan"), id="nan-confidence-prob"),
        ],
    )
    def test_invalid_trigger_confidence_prob(
        self,
        trigger_confidence_prob: float,
    ) -> None:
        """GateEvaluator rejects invalid trigger_confidence_prob values."""
        with pytest.raises(ValueError):
            GateEvaluator(trigger_confidence_prob=trigger_confidence_prob)
