"""Tests for AIPEA bridge adapter.

Validates that AIPEAGateAdapter correctly preprocesses claims
and degrades gracefully when AIPEA is not installed.
"""

from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest

from integration.aipea_bridge import AIPEAGateAdapter


class TestPassthroughBehavior:
    """Tests for graceful degradation when AIPEA is unavailable."""

    async def test_passthrough_when_aipea_missing(self):
        """Adapter returns passthrough result when aipea not installed."""
        adapter = AIPEAGateAdapter()
        with patch.dict("sys.modules", {"aipea": None}):
            adapter._aipea_available = None  # force re-check
            result = await adapter.preprocess_claim("test claim")
        assert result.enhanced_claim == "test claim"
        assert result.query_type == "unknown"
        assert result.processing_tier == "offline"

    def test_passthrough_fields_populated(self):
        """All passthrough fields have sensible defaults."""
        result = AIPEAGateAdapter._passthrough("abc123", "raw text")
        assert result.request_id == "abc123"
        assert result.enhanced_claim == "raw text"
        assert result.complexity == 0.5
        assert result.needs_current_info is False
        assert result.search_context is None
        assert result.security_flags == []
        assert result.enhancement_time_ms == 0.0
        assert isinstance(result.timestamp, datetime)

    def test_passthrough_is_frozen(self):
        """PreprocessedClaim is immutable (frozen dataclass)."""
        result = AIPEAGateAdapter._passthrough("abc", "text")
        with pytest.raises(AttributeError):
            result.enhanced_claim = "modified"  # type: ignore[misc]


class TestAdapterConfiguration:
    """Tests for adapter initialization and configuration."""

    def test_compliance_mode_stored(self):
        """Compliance mode string is stored for later use."""
        adapter = AIPEAGateAdapter(compliance_mode="hipaa")
        assert adapter._compliance_mode_str == "hipaa"

    def test_default_compliance_mode(self):
        """Default compliance mode is 'general'."""
        adapter = AIPEAGateAdapter()
        assert adapter._compliance_mode_str == "general"

    async def test_request_id_unique(self):
        """Each preprocess_claim call generates a unique request_id."""
        adapter = AIPEAGateAdapter()
        adapter._aipea_available = False  # skip import
        r1 = await adapter.preprocess_claim("claim 1")
        r2 = await adapter.preprocess_claim("claim 2")
        assert r1.request_id != r2.request_id


class TestResultMapping:
    """Tests for mapping AIPEA results to PreprocessedClaim."""

    def _make_mock_result(self, with_search=False):
        """Create a mock EnhancementResult."""
        mock = MagicMock()
        mock.enhanced_prompt = "enhanced text"
        mock.query_analysis.query_type.value = "technical"
        mock.query_analysis.complexity = 0.7
        mock.query_analysis.needs_current_info = True
        mock.processing_tier.value = "tactical"
        mock.enhancement_time_ms = 42.5
        if with_search:
            mock.search_context.source = "exa"
            mock.search_context.confidence = 0.85
            mock.search_context.results = [MagicMock(), MagicMock()]
        else:
            mock.search_context = None
        return mock

    def test_map_result_without_search(self):
        """Maps result fields correctly when no search context."""
        adapter = AIPEAGateAdapter()
        mock_result = self._make_mock_result(with_search=False)
        claim = adapter._map_result("req123", mock_result)
        assert claim.enhanced_claim == "enhanced text"
        assert claim.query_type == "technical"
        assert claim.complexity == 0.7
        assert claim.needs_current_info is True
        assert claim.search_context is None
        assert claim.processing_tier == "tactical"
        assert claim.enhancement_time_ms == 42.5

    def test_map_result_with_search(self):
        """Maps search context fields when present."""
        adapter = AIPEAGateAdapter()
        mock_result = self._make_mock_result(with_search=True)
        claim = adapter._map_result("req456", mock_result)
        assert claim.search_context is not None
        assert claim.search_context["source"] == "exa"
        assert claim.search_context["confidence"] == 0.85
        assert claim.search_context["result_count"] == 2

    async def test_preprocess_handles_exception(self):
        """Adapter returns passthrough on unexpected exceptions."""
        import builtins

        adapter = AIPEAGateAdapter()
        adapter._aipea_available = True

        _real_import = builtins.__import__

        def _selective_import(name, *args, **kwargs):
            if name == "aipea" or name.startswith("aipea."):
                return MagicMock()
            return _real_import(name, *args, **kwargs)

        with (
            patch(
                "integration.aipea_bridge.AIPEAGateAdapter._map_result",
                side_effect=RuntimeError("boom"),
            ),
            patch("builtins.__import__", side_effect=_selective_import),
        ):
            result = await adapter.preprocess_claim("fail claim")
        assert result.enhanced_claim == "fail claim"
        assert result.processing_tier == "offline"
