"""Bug Hunt #44 regression tests.

BH44-Codex-M1: schema_signer sign_tools_list() chain state committed before
    manifest signing — partial state corruption on failure (found by Codex +
    Claude Agent 3).

BH44-M1: calibrator _NONNEGATIVE_GATE_PARAMS incorrectly includes
    utility_threshold — rejects negative values that GateEvaluator accepts.

BH44-M2: proposer create_draft() does not catch TypeError from
    _validate_pert_estimates() — raw exception escapes instead of ActionResult.

BH44-L1: pcw_decide _evaluate_drift_policy returns aliased constraints list
    when drift_monitor is None — inconsistent with non-None path.
"""

from __future__ import annotations

import pytest

# ---------------------------------------------------------------------------
# BH44-Codex-M1: schema_signer chain state atomicity
# (Codex wrote the primary regression test in tests/crypto/test_schema_signer.py;
#  we add a complementary test here for the successful-path chain update.)
# ---------------------------------------------------------------------------


class TestBH44CodexM1SchemaSignerAtomicity:
    """Regression: sign_tools_list chain state update must be atomic."""

    def test_successful_signing_commits_chain_state(self) -> None:
        """After successful signing, _prev_digests and _manifest_revision advance."""
        try:
            from crypto.schema_signer import ToolSchemaSigner
        except ImportError:
            pytest.skip("crypto module not available")

        signer = ToolSchemaSigner()
        initial_revision = signer._manifest_revision
        assert signer._prev_digests == {}

        tool = {
            "name": "test_tool",
            "description": "Chain state regression",
            "inputSchema": {"type": "object", "properties": {}},
        }
        signer.sign_tools_list([tool])

        assert signer._manifest_revision == initial_revision + 1
        assert "test_tool" in signer._prev_digests

    def test_two_successive_signings_advance_revision(self) -> None:
        """Each successful signing increments _manifest_revision."""
        try:
            from crypto.schema_signer import ToolSchemaSigner
        except ImportError:
            pytest.skip("crypto module not available")

        signer = ToolSchemaSigner()
        initial_revision = signer._manifest_revision
        tool = {
            "name": "tool_a",
            "description": "Revision counter regression",
            "inputSchema": {"type": "object", "properties": {}},
        }
        signer.sign_tools_list([tool])
        assert signer._manifest_revision == initial_revision + 1

        signer.sign_tools_list([tool])
        assert signer._manifest_revision == initial_revision + 2


# ---------------------------------------------------------------------------
# BH44-M1: calibrator utility_threshold non-negative over-validation
# ---------------------------------------------------------------------------


class TestBH44M1CalibratorUtilityThreshold:
    """Regression: calibrator must accept negative utility_threshold (GateEvaluator does)."""

    def test_gate_evaluator_accepts_negative_utility_threshold(self) -> None:
        """GateEvaluator.__init__ accepts negative utility_threshold."""
        from engine.gates import GateEvaluator

        ge = GateEvaluator(utility_threshold=-0.5)
        assert ge.utility_threshold == -0.5

    def test_validate_gate_param_accepts_negative_utility_threshold(self) -> None:
        """_validate_gate_param must not reject negative utility_threshold."""
        from actors.calibrator import _validate_gate_param

        # Should not raise
        _validate_gate_param("utility_threshold", -0.5)

    def test_validate_gate_param_rejects_negative_complexity_floor(self) -> None:
        """complexity_floor is correctly non-negative — this must still fail."""
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="non-negative"):
            _validate_gate_param("complexity_floor", -0.1)

    def test_validate_gate_param_rejects_nan_utility_threshold(self) -> None:
        """utility_threshold must still be finite."""
        from actors.calibrator import _validate_gate_param

        with pytest.raises(ValueError, match="finite"):
            _validate_gate_param("utility_threshold", float("nan"))

    def test_validate_gate_param_accepts_zero_utility_threshold(self) -> None:
        """utility_threshold=0 is valid (break-even floor)."""
        from actors.calibrator import _validate_gate_param

        _validate_gate_param("utility_threshold", 0.0)


# ---------------------------------------------------------------------------
# BH44-M2: proposer create_draft TypeError escape
# ---------------------------------------------------------------------------


class TestBH44M2ProposerTypeErrorEscape:
    """Regression: create_draft must return ActionResult for invalid PERT types."""

    def _make_proposer(self):
        from actors.proposer import Proposer

        return Proposer(
            actor_id="test-proposer",
            name="Test Proposer",
        )

    def _make_draft(self, *, profit_best=0.5):
        from actors.proposer import ProposalDraft

        return ProposalDraft(
            title="Test Proposal",
            description="Testing type error handling",
            estimated_profit={"best": profit_best, "likely": 1.0, "worst": 2.0},
            estimated_risk={"best": 0.1, "likely": 0.2, "worst": 0.3},
            complexity_assessment={"static": 0.5, "dynamic": 0.5},
            tags=["test"],
            attachments=[],
        )

    def test_string_pert_value_returns_action_result(self) -> None:
        """String in PERT estimates should return ActionResult, not raise."""
        proposer = self._make_proposer()
        draft = self._make_draft(profit_best="not_a_number")
        result = proposer.create_draft(draft)
        assert not result.success
        assert result.error is not None
        assert (
            "numeric" in result.error.lower() or "int or float" in result.error.lower()
        )

    def test_bool_pert_value_returns_action_result(self) -> None:
        """Bool in PERT estimates should return ActionResult, not raise."""
        proposer = self._make_proposer()
        draft = self._make_draft(profit_best=True)
        result = proposer.create_draft(draft)
        assert not result.success
        assert result.error is not None
        assert "bool" in result.error.lower()

    def test_nan_pert_value_returns_action_result(self) -> None:
        """NaN in PERT estimates should return ActionResult, not raise."""
        proposer = self._make_proposer()
        draft = self._make_draft(profit_best=float("nan"))
        result = proposer.create_draft(draft)
        assert not result.success
        assert result.error is not None
        assert "finite" in result.error.lower()

    def test_inf_pert_value_returns_action_result(self) -> None:
        """Inf in PERT estimates should return ActionResult, not raise."""
        proposer = self._make_proposer()
        draft = self._make_draft(profit_best=float("inf"))
        result = proposer.create_draft(draft)
        assert not result.success
        assert result.error is not None

    def test_valid_pert_still_works(self) -> None:
        """Valid PERT values should still produce a successful result."""
        proposer = self._make_proposer()
        draft = self._make_draft(profit_best=0.5)
        result = proposer.create_draft(draft)
        assert result.success


# ---------------------------------------------------------------------------
# BH44-L1: pcw_decide drift policy constraints aliasing
# ---------------------------------------------------------------------------


class TestBH44L1DriftPolicyConstraintsAlias:
    """Regression: _evaluate_drift_policy must return defensive copy of constraints."""

    def test_no_drift_monitor_returns_copy(self) -> None:
        """When drift_monitor is None, returned constraints must be a new list."""
        from integration.pcw_decide import (
            PCWContext,
            PCWPhase,
            PCWStatus,
            _evaluate_drift_policy,
        )

        ctx = PCWContext(
            agent_id="test",
            session_id="s1",
            phase=PCWPhase.PLAN,
            proposal_summary="test",
            estimated_impact="low",
            risk_baseline=0.0,
            risk_proposed=0.1,
            profit_baseline=0.0,
            profit_proposed=1.0,
        )
        original = ["existing constraint"]
        status, result_constraints, drift = _evaluate_drift_policy(
            drift_monitor=None,
            context=ctx,
            current_status=PCWStatus.PROCEED,
            constraints=original,
            telemetry_emitter=None,
            decision_id="test-decision-1",
        )
        assert result_constraints == original
        assert result_constraints is not original  # must be a copy

    def test_mutation_does_not_affect_original(self) -> None:
        """Mutating returned constraints must not affect the original list."""
        from integration.pcw_decide import (
            PCWContext,
            PCWPhase,
            PCWStatus,
            _evaluate_drift_policy,
        )

        ctx = PCWContext(
            agent_id="test",
            session_id="s2",
            phase=PCWPhase.PLAN,
            proposal_summary="test",
            estimated_impact="low",
            risk_baseline=0.0,
            risk_proposed=0.1,
            profit_baseline=0.0,
            profit_proposed=1.0,
        )
        original = ["constraint A"]
        _, result_constraints, _ = _evaluate_drift_policy(
            drift_monitor=None,
            context=ctx,
            current_status=PCWStatus.PROCEED,
            constraints=original,
            telemetry_emitter=None,
            decision_id="test-decision-2",
        )
        result_constraints.append("constraint B")
        assert "constraint B" not in original
