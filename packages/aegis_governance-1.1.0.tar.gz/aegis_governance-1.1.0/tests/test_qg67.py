"""Regression tests for Quality-Gate #67 Ultrathink findings.

QG67-G1: quality gate NaN subscores treated as zero (fail-safe)
QG67-G2: novelty gate non-finite inputs fail-closed with zero confidence
QG67-G3: evaluate_all rejects bool for risk/profit baseline/proposed
QG67-C9: ToolSchemaSigner.sign_tools_list thread safety
QG67-C2: EnvironmentKEKProvider/InMemoryKEKProvider thread safety locks
QG67-T1: BatchHTTPSink re-enqueues events on flush failure
QG67-T10: PII encryption error messages sanitized (no plaintext PII)
"""

import threading
from unittest.mock import patch

import pytest


# ---------------------------------------------------------------------------
# G1: Quality gate NaN subscores
# ---------------------------------------------------------------------------
class TestQG67G1QualityGateNaN:
    """_evaluate_quality_gate must treat NaN subscores as zero (fail-safe)."""

    def test_nan_subscore_treated_as_zero(self):
        """NaN in subscores should trigger has_zero and fail the gate."""
        from engine.gates import GateEvaluator

        ge = GateEvaluator()
        result = ge._evaluate_quality_gate(0.9, [0.8, float("nan"), 0.7])
        assert result.passed is False, "NaN subscore should fail quality gate"
        assert "Zero sub-score" in result.message

    def test_nan_subscore_order_independent(self):
        """Result must not depend on NaN position in the list."""
        from engine.gates import GateEvaluator

        ge = GateEvaluator()
        r1 = ge._evaluate_quality_gate(0.9, [float("nan"), 0.8, 0.9])
        r2 = ge._evaluate_quality_gate(0.9, [0.8, 0.9, float("nan")])
        assert r1.passed == r2.passed
        assert r1.passed is False

    def test_all_finite_subscores_still_pass(self):
        """Normal subscores should pass as before."""
        from engine.gates import GateEvaluator

        ge = GateEvaluator()
        result = ge._evaluate_quality_gate(0.9, [0.8, 0.7, 0.9])
        assert result.passed is True


# ---------------------------------------------------------------------------
# G2: Novelty gate non-finite inputs
# ---------------------------------------------------------------------------
class TestQG67G2NoveltyGateNonFinite:
    """_evaluate_novelty_gate must fail-closed with confidence=0.0 for NaN/Inf."""

    def test_nan_novelty_fails_closed(self):
        from engine.gates import GateEvaluator

        ge = GateEvaluator()
        result = ge._evaluate_novelty_gate(float("nan"))
        assert result.passed is False
        assert result.confidence == 0.0
        assert "Non-finite" in result.message

    def test_inf_novelty_fails_closed(self):
        from engine.gates import GateEvaluator

        ge = GateEvaluator()
        result = ge._evaluate_novelty_gate(float("inf"))
        assert result.passed is False
        assert result.confidence == 0.0

    def test_neg_inf_novelty_fails_closed(self):
        from engine.gates import GateEvaluator

        ge = GateEvaluator()
        result = ge._evaluate_novelty_gate(float("-inf"))
        assert result.passed is False
        assert result.confidence == 0.0

    def test_finite_novelty_still_works(self):
        from engine.gates import GateEvaluator

        ge = GateEvaluator()
        result = ge._evaluate_novelty_gate(0.9)
        assert result.passed is True
        assert result.confidence > 0.0


# ---------------------------------------------------------------------------
# G3: Bool rejection in evaluate_all
# ---------------------------------------------------------------------------
class TestQG67G3EvaluateAllBoolGuard:
    """evaluate_all must reject bool for risk/profit baseline/proposed."""

    @pytest.mark.parametrize(
        "kwarg",
        ["risk_baseline", "risk_proposed", "profit_baseline", "profit_proposed"],
    )
    def test_bool_rejected(self, kwarg):
        from engine.gates import GateEvaluator
        from engine.utility import UtilityResult

        ge = GateEvaluator()
        base_kwargs = {
            "risk_baseline": 0.5,
            "risk_proposed": 0.3,
            "profit_baseline": 1.0,
            "profit_proposed": 1.2,
            "novelty_score": 0.9,
            "complexity_score": 0.7,
            "quality_score": 0.8,
            "quality_subscores": [0.8, 0.7],
            "utility_result": UtilityResult(
                raw=1.0,
                variance=0.01,
                lcb=0.8,
                components=None,
                decision_path="INVESTMENT",
            ),
        }
        base_kwargs[kwarg] = True
        with pytest.raises(TypeError, match="must be numeric, got bool"):
            ge.evaluate_all(**base_kwargs)


# ---------------------------------------------------------------------------
# C9: ToolSchemaSigner thread safety
# ---------------------------------------------------------------------------
class TestQG67C9SchemaSignerThreadSafety:
    """sign_tools_list must be serialized to protect AMTSS chain state."""

    def test_has_sign_lock(self):
        """ToolSchemaSigner must have a _sign_lock attribute."""
        from crypto.schema_signer import ToolSchemaSigner

        signer = ToolSchemaSigner()
        assert hasattr(signer, "_sign_lock")
        assert isinstance(signer._sign_lock, type(threading.Lock()))

    def test_concurrent_signing_produces_sequential_revisions(self):
        """Concurrent sign_tools_list calls must not skip revision numbers."""
        from crypto.schema_signer import ToolSchemaSigner

        signer = ToolSchemaSigner()
        tools = [{"name": "test_tool", "description": "Test", "inputSchema": {}}]

        results = []
        errors = []

        def sign_and_record():
            try:
                signer.sign_tools_list(tools)
                results.append(signer._manifest_revision)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=sign_and_record) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Unexpected errors: {errors}"
        # After 10 calls, revision should be 11 (started at 1, incremented 10 times)
        assert signer._manifest_revision == 11


# ---------------------------------------------------------------------------
# C2: KEK provider thread safety (structural check)
# ---------------------------------------------------------------------------
class TestQG67C2KEKProviderLocks:
    """EnvironmentKEKProvider and InMemoryKEKProvider must have _lock."""

    def test_environment_kek_has_lock(self):
        """EnvironmentKEKProvider should have _lock attribute."""
        # We can't construct without liboqs, so check the class source.
        # Verify the class defines _lock in __init__ by inspecting source
        import inspect

        from crypto.kek_provider import EnvironmentKEKProvider

        source = inspect.getsource(EnvironmentKEKProvider.__init__)
        assert "_lock" in source, "EnvironmentKEKProvider.__init__ must set _lock"
        assert "threading.Lock()" in source

    def test_inmemory_kek_has_lock(self):
        """InMemoryKEKProvider should have _lock attribute."""
        import inspect

        from crypto.kek_provider import InMemoryKEKProvider

        source = inspect.getsource(InMemoryKEKProvider.__init__)
        assert "_lock" in source, "InMemoryKEKProvider.__init__ must set _lock"
        assert "threading.Lock()" in source


# ---------------------------------------------------------------------------
# T1: BatchHTTPSink re-enqueue on failure
# ---------------------------------------------------------------------------
class TestQG67T1BatchHTTPSinkReenqueue:
    """BatchHTTPSink.flush must re-enqueue events on send failure."""

    def test_failed_flush_reenqueues_events(self):
        from telemetry.emitter import BatchHTTPSink

        sink = BatchHTTPSink(
            url="https://example.com/events",
            batch_size=5,
            max_retries=0,
        )

        # Manually add events to buffer
        sink._buffer.extend(["event1", "event2", "event3"])

        # Mock _send_with_retry to return 0 (failure)
        with patch.object(sink, "_send_with_retry", return_value=0):
            sent = sink.flush()

        assert sent == 0
        # Events should be re-enqueued
        assert len(sink._buffer) == 3
        assert list(sink._buffer) == ["event1", "event2", "event3"]

    def test_successful_flush_does_not_reenqueue(self):
        from telemetry.emitter import BatchHTTPSink

        sink = BatchHTTPSink(
            url="https://example.com/events",
            batch_size=5,
            max_retries=0,
        )

        sink._buffer.extend(["event1", "event2"])

        with patch.object(sink, "_send_with_retry", return_value=2):
            sent = sink.flush()

        assert sent == 2
        assert len(sink._buffer) == 0


# ---------------------------------------------------------------------------
# T10: PII encryption error sanitization
# ---------------------------------------------------------------------------
class TestQG67T10PIIErrorSanitization:
    """PII encryption errors must not leak plaintext in error messages."""

    def test_error_message_contains_type_not_value(self):
        """Error field should contain exception type, not the full str(e)."""
        pytest.importorskip("oqs", reason="liboqs not available")
        from crypto.hybrid_kem import HybridKEMProvider
        from telemetry.encryption import PIIEncryptionEnricher

        kem = HybridKEMProvider()
        kp = kem.generate_keypair()
        enricher = PIIEncryptionEnricher(
            public_key=kp.public,
            dek_version="test-v1",
        )

        # Mock _encrypt_dict to raise with a message containing "PII"
        fake_pii = "john.doe@secret-corp.com"
        with patch.object(
            enricher,
            "_encrypt_dict",
            side_effect=ValueError(f"Cannot serialize {fake_pii}"),
        ):
            result = enricher.enrich({"actor_id": fake_pii})

        error_msg = result["_pii_encryption_error"]
        # Must NOT contain the actual PII value
        assert fake_pii not in error_msg
        # Must contain the exception type name
        assert "ValueError" in error_msg

    def test_strict_mode_raises_sanitized(self):
        """In raise_on_error mode, RuntimeError message must be sanitized."""
        pytest.importorskip("oqs", reason="liboqs not available")
        from crypto.hybrid_kem import HybridKEMProvider
        from telemetry.encryption import PIIEncryptionEnricher

        kem = HybridKEMProvider()
        kp = kem.generate_keypair()
        enricher = PIIEncryptionEnricher(
            public_key=kp.public,
            dek_version="test-v1",
            raise_on_error=True,
        )

        fake_pii = "SSN-123-45-6789"
        with (
            patch.object(
                enricher,
                "_encrypt_dict",
                side_effect=ValueError(f"Bad field: {fake_pii}"),
            ),
            pytest.raises(RuntimeError) as exc_info,
        ):
            enricher.enrich({"actor_id": "test"})

        assert fake_pii not in str(exc_info.value)
        assert "ValueError" in str(exc_info.value)
