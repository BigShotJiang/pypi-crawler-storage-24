"""Tests for AegisConfig — schema-code linkage.

Validates that:
1. Default config matches schema/interface-contract.yaml frozen values
2. YAML loading parses interface-contract.yaml format correctly
3. Factory methods create properly configured components
4. Immutability (frozen dataclass) prevents runtime drift
"""

import tempfile
from pathlib import Path

import pytest

from config import AegisConfig, KLDriftConfig


class TestAegisConfigDefaults:
    """Verify defaults match frozen YAML values exactly."""

    def test_default_creates_instance(self):
        config = AegisConfig.default()
        assert isinstance(config, AegisConfig)

    def test_epsilon_R_default(self):
        config = AegisConfig.default()
        assert config.epsilon_R == 0.01

    def test_epsilon_P_default(self):
        config = AegisConfig.default()
        assert config.epsilon_P == 0.01

    def test_risk_trigger_factor_default(self):
        config = AegisConfig.default()
        assert config.risk_trigger_factor == 2.0

    def test_profit_trigger_factor_default(self):
        config = AegisConfig.default()
        assert config.profit_trigger_factor == 2.0

    def test_trigger_confidence_prob_default(self):
        config = AegisConfig.default()
        assert config.trigger_confidence_prob == 0.95

    def test_novelty_N0_default(self):
        config = AegisConfig.default()
        assert config.novelty_N0 == 0.7

    def test_novelty_k_default(self):
        config = AegisConfig.default()
        assert config.novelty_k == 10.0

    def test_novelty_threshold_default(self):
        config = AegisConfig.default()
        assert config.novelty_threshold == 0.8

    def test_complexity_floor_default(self):
        config = AegisConfig.default()
        assert config.complexity_floor == 0.5

    def test_quality_min_score_default(self):
        config = AegisConfig.default()
        assert config.quality_min_score == 0.7

    def test_gamma_default(self):
        config = AegisConfig.default()
        assert config.gamma == 0.3

    def test_kappa_default(self):
        config = AegisConfig.default()
        assert config.kappa == 1.0

    def test_phi_S_default(self):
        config = AegisConfig.default()
        assert config.phi_S == 100.0

    def test_phi_D_default(self):
        config = AegisConfig.default()
        assert config.phi_D == 2000.0

    def test_lcb_alpha_default(self):
        config = AegisConfig.default()
        assert config.lcb_alpha == 0.05

    def test_migration_budget_default(self):
        config = AegisConfig.default()
        assert config.migration_budget == 5000.0

    def test_kl_drift_defaults(self):
        config = AegisConfig.default()
        assert config.kl_drift.tau_warning == 0.3
        assert config.kl_drift.tau_critical == 0.5
        assert config.kl_drift.window_days == 30


class TestAegisConfigImmutability:
    """Frozen dataclass prevents accidental mutation."""

    def test_cannot_modify_epsilon(self):
        config = AegisConfig.default()
        with pytest.raises(AttributeError):
            config.epsilon_R = 0.5  # type: ignore[misc]

    def test_cannot_modify_trigger_factor(self):
        config = AegisConfig.default()
        with pytest.raises(AttributeError):
            config.risk_trigger_factor = 99.0  # type: ignore[misc]


class TestAegisConfigFromDict:
    """Test flat dict construction."""

    def test_from_dict_with_overrides(self):
        config = AegisConfig.from_dict({"epsilon_R": 0.05, "gamma": 0.5})
        assert config.epsilon_R == 0.05
        assert config.gamma == 0.5
        # Others remain default
        assert config.epsilon_P == 0.01

    def test_from_dict_empty_uses_defaults(self):
        config = AegisConfig.from_dict({})
        assert config.epsilon_R == 0.01

    def test_from_dict_with_kl_drift(self):
        config = AegisConfig.from_dict(
            {"kl_drift": {"tau_warning": 0.4, "tau_critical": 0.6, "window_days": 60}}
        )
        assert config.kl_drift.tau_warning == 0.4
        assert config.kl_drift.tau_critical == 0.6
        assert config.kl_drift.window_days == 60

    def test_from_dict_ignores_unknown_keys(self):
        config = AegisConfig.from_dict({"unknown_key": 999})
        assert config.epsilon_R == 0.01


class TestAegisConfigYAML:
    """Test YAML loading (requires pyyaml)."""

    @pytest.fixture
    def yaml_available(self):
        """Skip if pyyaml not installed."""
        pytest.importorskip("yaml")

    def test_from_yaml_interface_contract(self, yaml_available):
        """Load the actual interface-contract.yaml and verify parsing."""
        contract_path = (
            Path(__file__).parent.parent / "schema" / "interface-contract.yaml"
        )
        if not contract_path.exists():
            pytest.skip("interface-contract.yaml not found")

        config = AegisConfig.from_yaml(contract_path)

        # All values should match frozen defaults
        assert config.epsilon_R == 0.01
        assert config.epsilon_P == 0.01
        assert config.risk_trigger_factor == 2.0
        assert config.profit_trigger_factor == 2.0
        assert config.trigger_confidence_prob == 0.95
        assert config.novelty_N0 == 0.7
        assert config.novelty_k == 10.0
        assert config.novelty_threshold == 0.8
        assert config.complexity_floor == 0.5
        assert config.quality_min_score == 0.7
        assert config.gamma == 0.3
        assert config.kappa == 1.0
        assert config.phi_S == 100.0
        assert config.phi_D == 2000.0
        assert config.migration_budget == 5000.0
        assert config.lcb_alpha == 0.05

    def test_from_yaml_custom_file(self, yaml_available):
        """Load from a custom YAML config."""
        import yaml

        custom = {"parameters": {"epsilon_R": 0.05, "epsilon_P": 0.02}}

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(custom, f)
            f.flush()
            config = AegisConfig.from_yaml(f.name)

        assert config.epsilon_R == 0.05
        assert config.epsilon_P == 0.02

    def test_from_yaml_nonexistent_file(self, yaml_available):
        with pytest.raises(FileNotFoundError):
            AegisConfig.from_yaml("/nonexistent/path.yaml")

    def test_from_yaml_invalid_content(self, yaml_available):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write("just a string")
            f.flush()
            # A plain string is a valid YAML but not a dict
            with pytest.raises(ValueError, match="Expected YAML dict"):
                AegisConfig.from_yaml(f.name)

    def test_from_yaml_utility_threshold_not_dropped(self, yaml_available):
        """Regression: _from_raw_dict must include utility_threshold in _DIRECT.

        Previously utility_threshold was missing from the _DIRECT list,
        causing it to be silently dropped when loading from YAML. The
        GateEvaluator would then always use the default (0.0) regardless
        of what the YAML file specified.
        """
        import yaml

        custom = {"parameters": {"utility_threshold": 42.5}}
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(custom, f)
            f.flush()
            config = AegisConfig.from_yaml(f.name)

        assert config.utility_threshold == 42.5


class TestSchemaCodeSync:
    """Critical test: verify Python defaults match YAML frozen values.

    This test ensures schema/interface-contract.yaml and AegisConfig
    defaults never drift apart.
    """

    def test_defaults_match_interface_contract(self):
        """Schema-code sync test: Python defaults == YAML frozen values."""
        try:
            import yaml
        except ImportError:
            pytest.skip("pyyaml required for schema-code sync test")

        contract_path = (
            Path(__file__).parent.parent / "schema" / "interface-contract.yaml"
        )
        if not contract_path.exists():
            pytest.skip("interface-contract.yaml not found")

        with open(contract_path) as f:
            raw = yaml.safe_load(f)

        params = raw["parameters"]
        config = AegisConfig.default()

        # Direct params
        assert config.epsilon_R == params["epsilon_R"]
        assert config.epsilon_P == params["epsilon_P"]
        assert config.risk_trigger_factor == params["risk_trigger_factor"]
        assert config.profit_trigger_factor == params["profit_trigger_factor"]
        assert config.trigger_confidence_prob == params["trigger_confidence_prob"]
        assert config.complexity_floor == params["complexity_floor"]
        assert config.quality_min_score == params["quality_min_score"]

        # Nested params
        ng = params["novelty_gate"]
        assert config.novelty_N0 == ng["N0"]
        assert config.novelty_k == ng["k"]
        assert config.novelty_threshold == ng["output_threshold"]

        util = params["utility"]
        assert config.gamma == util["gamma"]
        assert config.kappa == util["kappa"]
        assert config.lcb_alpha == util["lcb_alpha"]
        assert config.utility_threshold == util["theta"]

        ct = params["complexity_tax"]
        assert config.phi_S == ct["phi_S"]
        assert config.phi_D == ct["phi_D"]

        rp = params["refactoring_path"]
        assert config.migration_budget == rp["migration_budget"]


class TestAegisConfigFactory:
    """Test factory methods for creating configured components."""

    def test_create_gate_evaluator(self):
        config = AegisConfig.default()
        evaluator = config.create_gate_evaluator()

        from engine.gates import GateEvaluator

        assert isinstance(evaluator, GateEvaluator)

    def test_create_gate_evaluator_with_custom_params(self):
        config = AegisConfig(epsilon_R=0.05, novelty_threshold=0.9)
        evaluator = config.create_gate_evaluator()

        from engine.gates import GateEvaluator

        assert isinstance(evaluator, GateEvaluator)

    def test_create_utility_calculator(self):
        config = AegisConfig.default()
        calculator = config.create_utility_calculator()

        from engine.utility import UtilityCalculator

        assert isinstance(calculator, UtilityCalculator)


class TestAegisConfigSerialization:
    """Test to_dict round-trip."""

    def test_to_dict(self):
        config = AegisConfig.default()
        d = config.to_dict()

        assert d["epsilon_R"] == 0.01
        assert d["gamma"] == 0.3
        assert d["kl_drift"]["tau_warning"] == 0.3

    def test_to_dict_from_dict_roundtrip(self):
        original = AegisConfig(epsilon_R=0.05, gamma=0.5)
        d = original.to_dict()
        restored = AegisConfig.from_dict(d)

        assert restored.epsilon_R == original.epsilon_R
        assert restored.gamma == original.gamma
        assert restored.kl_drift.tau_warning == original.kl_drift.tau_warning


class TestKLDriftConfig:
    """Test KL drift sub-config."""

    def test_defaults(self):
        kl = KLDriftConfig()
        assert kl.tau_warning == 0.3
        assert kl.tau_critical == 0.5
        assert kl.window_days == 30

    def test_custom_values(self):
        kl = KLDriftConfig(tau_warning=0.4, tau_critical=0.7, window_days=60)
        assert kl.tau_warning == 0.4
        assert kl.tau_critical == 0.7
        assert kl.window_days == 60

    def test_immutability(self):
        kl = KLDriftConfig()
        with pytest.raises(AttributeError):
            kl.tau_warning = 0.99  # type: ignore[misc]

    def test_nan_tau_warning_rejected(self):
        """BH24-L3: NaN tau_warning must be rejected at construction."""
        with pytest.raises(ValueError, match="tau_warning must be finite"):
            KLDriftConfig(tau_warning=float("nan"), tau_critical=0.5)

    def test_nan_tau_critical_rejected(self):
        """BH24-L3: NaN tau_critical must be rejected at construction."""
        with pytest.raises(ValueError, match="tau_critical must be finite"):
            KLDriftConfig(tau_warning=0.3, tau_critical=float("nan"))

    def test_inf_tau_warning_rejected(self):
        """BH24-L3: Inf tau_warning must be rejected at construction."""
        with pytest.raises(ValueError, match="tau_warning must be finite"):
            KLDriftConfig(tau_warning=float("inf"), tau_critical=0.5)

    def test_inf_tau_critical_rejected(self):
        """BH24-L3: Inf tau_critical must be rejected at construction."""
        with pytest.raises(ValueError, match="tau_critical must be finite"):
            KLDriftConfig(tau_warning=0.3, tau_critical=float("inf"))

    def test_neg_inf_tau_warning_rejected(self):
        """BH24-L3: -Inf tau_warning must be rejected at construction."""
        with pytest.raises(ValueError, match="tau_warning must be finite"):
            KLDriftConfig(tau_warning=float("-inf"), tau_critical=0.5)


class TestBug7KLDriftExtraKeys:
    """Regression: from_dict with extra keys in kl_drift should not crash."""

    def test_from_dict_kl_drift_extra_keys_ignored(self):
        """Bug 7: KLDriftConfig(**data) crashed on extra keys."""
        config = AegisConfig.from_dict(
            {
                "kl_drift": {
                    "tau_warning": 0.4,
                    "tau_critical": 0.6,
                    "window_days": 60,
                    "extra_key": "should_be_ignored",
                    "another_extra": 42,
                }
            }
        )
        assert config.kl_drift.tau_warning == 0.4
        assert config.kl_drift.tau_critical == 0.6
        assert config.kl_drift.window_days == 60

    def test_from_dict_kl_drift_only_extra_keys(self):
        """Only unrecognized keys should produce default KLDriftConfig."""
        config = AegisConfig.from_dict({"kl_drift": {"unknown_param": 999}})
        assert config.kl_drift.tau_warning == 0.3
        assert config.kl_drift.tau_critical == 0.5
        assert config.kl_drift.window_days == 30


class TestCreateDriftMonitor:
    """Tests for AegisConfig.create_drift_monitor() factory method."""

    def test_create_drift_monitor(self):
        """Factory produces DriftMonitor with correct params."""
        from engine.drift import DriftMonitor

        config = AegisConfig(
            kl_drift=KLDriftConfig(tau_warning=0.25, tau_critical=0.45, window_days=14)
        )
        dm = config.create_drift_monitor()
        assert isinstance(dm, DriftMonitor)
        assert dm.tau_warning == 0.25
        assert dm.tau_critical == 0.45
        assert dm.window_days == 14

    def test_create_drift_monitor_default_config(self):
        """Default config produces DriftMonitor with default thresholds."""
        from engine.drift import DriftMonitor

        config = AegisConfig.default()
        dm = config.create_drift_monitor()
        assert isinstance(dm, DriftMonitor)
        assert dm.tau_warning == 0.3
        assert dm.tau_critical == 0.5


class TestQG59ConfigNullHandling:
    """QG59: YAML null value handling in config parsing."""

    def test_yaml_null_nested_float_no_crash(self, tmp_path):
        """QG59-P1-4: Null values in nested YAML sections must not crash."""
        yaml_file = tmp_path / "config.yaml"
        yaml_file.write_text(
            "parameters:\n" "  novelty_gate:\n" "    k: null\n" "    N0: 0.5\n"
        )
        config = AegisConfig.from_yaml(str(yaml_file))
        # Null key should be skipped, non-null key should be parsed
        assert config.novelty_N0 == 0.5

    def test_yaml_null_kl_drift_values_use_defaults(self, tmp_path):
        """QG59-P1-4: Null KL drift values must fall back to defaults."""
        yaml_file = tmp_path / "config.yaml"
        yaml_file.write_text(
            "parameters:\n"
            "  kl_divergence:\n"
            "    tau_warning: null\n"
            "    tau_critical: null\n"
            "    window_days: null\n"
        )
        config = AegisConfig.from_yaml(str(yaml_file))
        assert config.kl_drift.tau_warning == 0.3
        assert config.kl_drift.tau_critical == 0.5
        assert config.kl_drift.window_days == 30

    def test_yaml_null_direct_params_use_defaults(self, tmp_path):
        """BH12: Null values in _DIRECT params must fall back to defaults."""
        yaml_file = tmp_path / "config.yaml"
        yaml_file.write_text(
            "parameters:\n"
            "  epsilon_R: null\n"
            "  complexity_floor: null\n"
            "  quality_min_score: null\n"
        )
        config = AegisConfig.from_yaml(str(yaml_file))
        assert config.epsilon_R == 0.01  # default
        assert config.complexity_floor == 0.5  # default
        assert config.quality_min_score == 0.7  # default

    def test_from_dict_null_novelty_params_use_defaults(self):
        """BH12: Null novelty params in from_dict must fall back to defaults."""
        config = AegisConfig.from_dict(
            {"novelty_N0": None, "novelty_k": None, "novelty_threshold": None}
        )
        assert config.novelty_N0 == 0.7  # default
        assert config.novelty_k == 10.0  # default
        assert config.novelty_threshold == 0.8  # default

    def test_from_dict_null_flat_keys_use_defaults(self):
        """BH12: Null values in _FLAT_KEYS must fall back to defaults."""
        config = AegisConfig.from_dict({"epsilon_R": None, "complexity_floor": None})
        assert config.epsilon_R == 0.01
        assert config.complexity_floor == 0.5

    def test_from_dict_kl_drift_null_values_filtered(self):
        """BH13-M2: Null kl_drift values must be filtered, not passed as None."""
        config = AegisConfig.from_dict(
            {"kl_drift": {"tau_warning": None, "tau_critical": None}}
        )
        # Should use defaults from KLDriftConfig, not None
        assert config.kl_drift.tau_warning == 0.3
        assert config.kl_drift.tau_critical == 0.5

    def test_from_dict_mcp_rate_limit_none(self):
        """BH13-L1: mcp_rate_limit=None must not crash with TypeError."""
        config = AegisConfig.from_dict({"mcp_rate_limit": None})
        # Should use default (60)
        assert config.mcp_rate_limit == 60

    def test_from_dict_kl_drift_partial_null(self):
        """BH13-M2: Partial null kl_drift — non-null values should be used."""
        config = AegisConfig.from_dict(
            {"kl_drift": {"tau_warning": 0.2, "tau_critical": None}}
        )
        assert config.kl_drift.tau_warning == 0.2
        assert config.kl_drift.tau_critical == 0.5  # default


class TestBH15Regressions:
    """BH15: Regression tests for Bug Hunt #15 findings."""

    def test_extract_nested_floats_rejects_bool_true(self, tmp_path):
        """BH15-M1: YAML boolean 'true' must not silently coerce to 1.0."""
        yaml_content = (
            "parameters:\n"
            "  utility:\n"
            "    gamma: true\n"  # YAML parses as Python True
        )
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_yaml(p)

    def test_extract_nested_floats_rejects_bool_false(self, tmp_path):
        """BH15-M1: YAML boolean 'false' must not silently coerce to 0.0."""
        yaml_content = (
            "parameters:\n"
            "  novelty_gate:\n"
            "    N0: false\n"  # YAML parses as Python False
        )
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_yaml(p)

    def test_extract_nested_floats_accepts_int(self, tmp_path):
        """BH15-M1: Integer values must still be accepted (valid float coercion)."""
        yaml_content = (
            "parameters:\n"
            "  utility:\n"
            "    gamma: 1\n"  # YAML int, valid coercion
        )
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        config = AegisConfig.from_yaml(p)
        assert config.gamma == 1.0


class TestQG61BoolGuardCoverage:
    """QG61: Ultrathink bool guard coverage for all config entry points."""

    # Finding 1: _from_raw_dict DIRECT params
    def test_from_raw_dict_direct_rejects_bool(self, tmp_path):
        """DIRECT params like epsilon_R must reject bool."""
        yaml_content = "parameters:\n  epsilon_R: true\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_yaml(p)

    def test_from_raw_dict_direct_allows_quality_bool(self, tmp_path):
        """quality_no_zero_subscore is explicitly allowed as bool."""
        yaml_content = "parameters:\n  quality_no_zero_subscore: false\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        config = AegisConfig.from_yaml(p)
        assert config.quality_no_zero_subscore is False

    # Finding 2: from_dict FLAT_KEYS + novelty
    def test_from_dict_flat_rejects_bool(self):
        """from_dict FLAT_KEYS must reject bool for numeric fields."""
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_dict({"epsilon_R": True})

    def test_from_dict_flat_allows_quality_bool(self):
        """from_dict allows bool for quality_no_zero_subscore."""
        config = AegisConfig.from_dict({"quality_no_zero_subscore": False})
        assert config.quality_no_zero_subscore is False

    def test_from_dict_novelty_rejects_bool(self):
        """from_dict novelty params must reject bool."""
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_dict({"novelty_N0": True})

    # Finding 3: KL drift bool guard
    def test_from_raw_dict_kl_drift_rejects_bool(self, tmp_path):
        """KL drift params must reject bool values."""
        yaml_content = "parameters:\n  kl_drift:\n    tau_warning: true\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_yaml(p)

    # BH16: from_dict KL drift bool guard
    def test_from_dict_kl_drift_rejects_bool_tau_warning(self):
        """from_dict must reject bool in kl_drift.tau_warning (BH16-M2)."""
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_dict({"kl_drift": {"tau_warning": True}})

    def test_from_dict_kl_drift_rejects_bool_tau_critical(self):
        """from_dict must reject bool in kl_drift.tau_critical (BH16-M2)."""
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_dict({"kl_drift": {"tau_critical": False}})

    def test_from_dict_kl_drift_rejects_bool_window_days(self):
        """from_dict must reject bool in kl_drift.window_days (BH16-M2)."""
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_dict({"kl_drift": {"window_days": True}})

    def test_from_dict_kl_drift_accepts_numeric(self):
        """from_dict must accept valid numeric kl_drift values."""
        config = AegisConfig.from_dict({"kl_drift": {"tau_warning": 0.4}})
        assert config.kl_drift.tau_warning == 0.4

    # BH16: mcp_rate_limit bool guard
    def test_from_dict_mcp_rate_limit_rejects_bool(self):
        """from_dict must reject bool for mcp_rate_limit (BH16-L2)."""
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_dict({"mcp_rate_limit": True})

    def test_from_raw_dict_mcp_rate_limit_rejects_bool(self, tmp_path):
        """_from_raw_dict must reject bool for mcp_rate_limit (BH16-L2)."""
        yaml_content = "mcp_rate_limit: true\nparameters: {}\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(TypeError, match="bool"):
            AegisConfig.from_yaml(p)

    def test_from_dict_mcp_rate_limit_accepts_int(self):
        """from_dict must accept valid integer mcp_rate_limit."""
        config = AegisConfig.from_dict({"mcp_rate_limit": 120})
        assert config.mcp_rate_limit == 120


class TestQG62KLDriftFromDictValidation:
    """QG62: from_dict must validate kl_drift NaN/Inf and coerce window_days."""

    def test_kl_drift_nan_tau_warning_raises(self):
        """NaN tau_warning should raise ValueError."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"kl_drift": {"tau_warning": float("nan")}})

    def test_kl_drift_inf_tau_critical_raises(self):
        """Inf tau_critical should raise ValueError."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"kl_drift": {"tau_critical": float("inf")}})

    def test_kl_drift_window_days_coerced_to_int(self):
        """window_days should be coerced to int."""
        config = AegisConfig.from_dict({"kl_drift": {"window_days": 15.0}})
        assert config.kl_drift.window_days == 15
        assert isinstance(config.kl_drift.window_days, int)

    def test_kl_drift_valid_float_accepted(self):
        """Valid float tau_warning should work (must be < tau_critical default 0.5)."""
        config = AegisConfig.from_dict({"kl_drift": {"tau_warning": 0.2}})
        assert config.kl_drift.tau_warning == 0.2


class TestBH17ConfigValidation:
    """BH17: NaN/Inf validation parity in YAML parsing paths."""

    def test_extract_nested_floats_rejects_nan(self, tmp_path):
        """BH17-L1: _extract_nested_floats must reject NaN values."""
        yaml_content = "parameters:\n  novelty_gate:\n    N0: .nan\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)

    def test_extract_nested_floats_rejects_inf(self, tmp_path):
        """BH17-L1: _extract_nested_floats must reject Inf values."""
        yaml_content = "parameters:\n  utility:\n    gamma: .inf\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)

    def test_extract_nested_floats_rejects_neg_inf(self, tmp_path):
        """BH17-L1: _extract_nested_floats must reject -Inf values."""
        yaml_content = "parameters:\n  complexity_tax:\n    phi_S: -.inf\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)

    def test_from_raw_dict_kl_drift_rejects_nan(self, tmp_path):
        """BH17-L2: _from_raw_dict kl_drift must reject NaN (parity with from_dict)."""
        yaml_content = "parameters:\n  kl_drift:\n    tau_warning: .nan\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)

    def test_from_raw_dict_kl_drift_rejects_inf(self, tmp_path):
        """BH17-L2: _from_raw_dict kl_drift tau_critical must reject Inf."""
        yaml_content = "parameters:\n  kl_drift:\n    tau_critical: .inf\n"
        p = tmp_path / "config.yaml"
        p.write_text(yaml_content)
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)


class TestBH18FlatKeyNaNInfValidation:
    """BH18: from_dict and _from_raw_dict flat keys must reject NaN/Inf."""

    @pytest.mark.parametrize(
        "key", ["epsilon_R", "gamma", "kappa", "phi_S", "lcb_alpha"]
    )
    def test_from_dict_flat_nan_rejected(self, key):
        """NaN in flat keys must raise ValueError (parity with nested sections)."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({key: float("nan")})

    @pytest.mark.parametrize(
        "key", ["epsilon_P", "risk_trigger_factor", "utility_threshold"]
    )
    def test_from_dict_flat_inf_rejected(self, key):
        """Inf in flat keys must raise ValueError (parity with nested sections)."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({key: float("inf")})

    def test_from_dict_novelty_nan_rejected(self):
        """NaN in novelty flat keys must raise ValueError."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"novelty_k": float("nan")})

    def test_from_dict_novelty_inf_rejected(self):
        """Inf in novelty flat keys must raise ValueError."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"novelty_N0": float("inf")})

    def test_from_raw_dict_flat_nan_rejected(self, tmp_path):
        """NaN in _from_raw_dict _DIRECT keys must raise ValueError."""
        pytest.importorskip("yaml")
        p = tmp_path / "config.yaml"
        p.write_text("parameters:\n  epsilon_R: .nan\n")
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)

    def test_from_raw_dict_flat_inf_rejected(self, tmp_path):
        """Inf in _from_raw_dict _DIRECT keys must raise ValueError."""
        pytest.importorskip("yaml")
        p = tmp_path / "config.yaml"
        p.write_text("parameters:\n  complexity_floor: .inf\n")
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)


class TestBH20WindowDaysValidation:
    """BH20-L1: kl_drift.window_days must reject non-finite and negative values."""

    def test_window_days_inf_raises_overflow(self):
        """window_days=Inf must raise a ValueError, not OverflowError."""
        with pytest.raises((ValueError, OverflowError)):
            AegisConfig.from_dict({"kl_drift": {"window_days": float("inf")}})

    def test_window_days_nan_raises(self):
        """window_days=NaN must raise ValueError."""
        with pytest.raises((ValueError, OverflowError)):
            AegisConfig.from_dict({"kl_drift": {"window_days": float("nan")}})

    def test_window_days_negative_raises(self):
        """window_days=-5 must raise ValueError."""
        with pytest.raises(ValueError, match="must be >= 1"):
            AegisConfig.from_dict({"kl_drift": {"window_days": -5}})

    def test_window_days_zero_raises(self):
        """window_days=0 must raise ValueError."""
        with pytest.raises(ValueError, match="must be >= 1"):
            AegisConfig.from_dict({"kl_drift": {"window_days": 0}})

    def test_window_days_positive_accepted(self):
        """window_days=7 must be accepted."""
        config = AegisConfig.from_dict({"kl_drift": {"window_days": 7}})
        assert config.kl_drift.window_days == 7


class TestBH25ConfigStringNaNValidation:
    """BH25-L3: from_dict must reject string 'nan'/'inf' values."""

    def test_from_dict_string_nan_rejected(self):
        """String 'nan' must raise ValueError, not silently pass."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"gamma": "nan"})

    def test_from_dict_string_inf_rejected(self):
        """String 'inf' must raise ValueError."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"gamma": "inf"})

    def test_from_dict_string_neg_inf_rejected(self):
        """String '-inf' must raise ValueError."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"gamma": "-inf"})

    def test_from_dict_string_infinity_rejected(self):
        """String 'Infinity' must raise ValueError."""
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"phi_S": "Infinity"})

    def test_from_dict_valid_string_numeric_accepted(self):
        """Valid numeric string like '0.5' must be accepted and converted."""
        config = AegisConfig.from_dict({"gamma": "0.5"})
        assert config.gamma == 0.5

    def test_from_dict_invalid_string_rejected(self):
        """Non-numeric string must raise ValueError."""
        with pytest.raises(ValueError, match="Cannot convert"):
            AegisConfig.from_dict({"gamma": "not_a_number"})


class TestBH27FromRawDictStringCoercion:
    """BH27-M2: _from_raw_dict must coerce string values to float for _DIRECT params."""

    def test_from_raw_dict_quoted_string_float_coerced(self, tmp_path):
        """YAML quoted numeric like '0.01' must be coerced to float, not passed as str."""
        pytest.importorskip("yaml")
        p = tmp_path / "config.yaml"
        p.write_text('parameters:\n  epsilon_R: "0.01"\n  epsilon_P: "0.05"\n')
        config = AegisConfig.from_yaml(p)
        assert config.epsilon_R == 0.01
        assert isinstance(config.epsilon_R, float)
        assert config.epsilon_P == 0.05
        assert isinstance(config.epsilon_P, float)

    def test_from_raw_dict_string_nan_rejected(self, tmp_path):
        """YAML quoted 'nan' in _DIRECT must raise ValueError via string coercion."""
        pytest.importorskip("yaml")
        p = tmp_path / "config.yaml"
        p.write_text('parameters:\n  epsilon_R: "nan"\n')
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)

    def test_from_raw_dict_string_inf_rejected(self, tmp_path):
        """YAML quoted 'inf' in _DIRECT must raise ValueError via string coercion."""
        pytest.importorskip("yaml")
        p = tmp_path / "config.yaml"
        p.write_text('parameters:\n  risk_trigger_factor: "inf"\n')
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_yaml(p)

    def test_from_raw_dict_string_non_numeric_rejected(self, tmp_path):
        """YAML quoted non-numeric string must raise ValueError."""
        pytest.importorskip("yaml")
        p = tmp_path / "config.yaml"
        p.write_text('parameters:\n  epsilon_R: "abc"\n')
        with pytest.raises(ValueError):
            AegisConfig.from_yaml(p)


class TestBH29McpRateLimitNonFinite:
    """Regression: mcp_rate_limit must reject NaN/Inf (BH29-L1)."""

    def test_from_dict_inf_rejected(self):
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"mcp_rate_limit": float("inf")})

    def test_from_dict_nan_rejected(self):
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"mcp_rate_limit": float("nan")})

    def test_from_dict_negative_inf_rejected(self):
        with pytest.raises(ValueError, match="Non-finite"):
            AegisConfig.from_dict({"mcp_rate_limit": float("-inf")})

    def test_from_raw_dict_inf_rejected(self):
        pytest.importorskip("yaml")
        import pathlib
        import tempfile

        with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False) as f:
            f.write("mcp_rate_limit: .inf\n")
            f.flush()
            with pytest.raises(ValueError, match="Non-finite"):
                AegisConfig.from_yaml(pathlib.Path(f.name))

    def test_from_dict_valid_int_accepted(self):
        cfg = AegisConfig.from_dict({"mcp_rate_limit": 120})
        assert cfg.mcp_rate_limit == 120
