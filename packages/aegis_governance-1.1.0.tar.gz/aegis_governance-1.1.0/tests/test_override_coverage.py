"""
Additional Override Workflow Tests for Coverage

Target: Cover missing lines in src/workflows/override.py
Focus on:
- Error handling paths
- Edge cases in signature validation
- OverrideWorkflow state transitions
- sign_with_stored_key() async method
- get_stored_key_info() async method
- Duplicate signature detection
- Serialization/deserialization edge cases
- RBAC + telemetry + alert wiring paths
"""

import base64
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from telemetry.alert import LogAlertSink
from workflows.override import (
    CRYPTO_AVAILABLE,
    PROVIDERS_AVAILABLE,
    DualSignatureValidator,
    OverrideState,
    OverrideWorkflow,
    SignatureRecord,
)

# =============================================================================
# TestDualSignatureValidatorEdgeCases
# =============================================================================


class TestDualSignatureValidatorEdgeCases:
    """Tests for DualSignatureValidator edge cases and error paths."""

    def test_algorithm_name_without_provider(self):
        """Test algorithm_name property returns 'ed25519-legacy' when no provider."""
        # Create validator with provider explicitly set to None
        validator = DualSignatureValidator()
        # Force provider to None to test legacy path
        validator._provider = None

        assert validator.algorithm_name == "ed25519-legacy"

    def test_algorithm_name_with_provider(self):
        """Test algorithm_name property returns provider's algorithm name."""
        if not PROVIDERS_AVAILABLE:
            pytest.skip("Signature providers not available")

        from src.crypto import get_default_provider

        provider = get_default_provider()
        validator = DualSignatureValidator(provider=provider)

        assert validator.algorithm_name == provider.algorithm_name

    def test_provider_property_returns_configured_provider(self):
        """Test provider property returns the configured provider."""
        validator = DualSignatureValidator()
        # Provider may be auto-selected or None
        _ = validator.provider  # Should not raise

    def test_create_message_hash_legacy_path(self):
        """Test create_message_hash uses legacy SHA-256 path when no provider."""
        validator = DualSignatureValidator()
        # Force no provider
        validator._provider = None

        msg_hash = validator.create_message_hash(
            proposal_id="test-prop",
            justification="test justification",
            failed_gates=["gate1", "gate2"],
        )

        # Should return 64-char hex SHA-256 hash
        assert len(msg_hash) == 64
        assert all(c in "0123456789abcdef" for c in msg_hash)

    def test_create_message_hash_legacy_gate_sorting(self):
        """Test that legacy path sorts gates for deterministic hash."""
        validator = DualSignatureValidator()
        validator._provider = None

        hash1 = validator.create_message_hash("p1", "test", ["b", "a", "c"])
        hash2 = validator.create_message_hash("p1", "test", ["a", "b", "c"])
        hash3 = validator.create_message_hash("p1", "test", ["c", "a", "b"])

        # All should be equal due to sorting
        assert hash1 == hash2 == hash3

    def test_validate_signature_exception_handling(self):
        """Test validate_signature handles decode exceptions."""
        if not PROVIDERS_AVAILABLE:
            pytest.skip("Signature providers not available")

        validator = DualSignatureValidator()

        # Invalid base64 should return False (not raise)
        result = validator.validate_signature(
            signature="not-valid-base64!!!",
            message_hash="a" * 64,
            public_key=base64.b64encode(b"x" * 32).decode(),
        )
        assert result is False

    def test_validate_signature_invalid_hex_message_hash(self):
        """Test validate_signature handles invalid hex message hash."""
        if not PROVIDERS_AVAILABLE:
            pytest.skip("Signature providers not available")

        validator = DualSignatureValidator()

        result = validator.validate_signature(
            signature=base64.b64encode(b"x" * 64).decode(),
            message_hash="gg" * 32,  # Invalid hex
            public_key=base64.b64encode(b"x" * 32).decode(),
        )
        assert result is False

    @pytest.mark.skipif(
        not (PROVIDERS_AVAILABLE or CRYPTO_AVAILABLE),
        reason="No signature backend available",
    )
    def test_validate_signature_rejects_trailing_base64_garbage(self):
        """Reject non-canonical base64 that appends trailing junk.

        Regression:
            base64.b64decode(..., validate=False) accepted malformed strings
            like "valid==!!!!", which decoded to the same bytes and could pass
            cryptographic verification.
        """
        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()
        msg_hash = validator.create_message_hash(
            proposal_id="prop-b64-strict",
            justification="strict decode check",
            failed_gates=["risk"],
        )
        signature = validator.sign_message(msg_hash, private_key)

        # Sanity check baseline valid signature.
        assert validator.validate_signature(signature, msg_hash, public_key) is True

        # Malformed base64 with trailing non-base64 data must be rejected.
        assert (
            validator.validate_signature(signature + "!!!!", msg_hash, public_key)
            is False
        )
        assert (
            validator.validate_signature(signature, msg_hash, public_key + "!!!!")
            is False
        )

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_validate_signature_legacy_invalid_signature_size(self):
        """Test legacy validate_signature rejects wrong signature size."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy path

        # Wrong size signature (32 bytes instead of 64)
        result = validator.validate_signature(
            signature=base64.b64encode(b"x" * 32).decode(),
            message_hash="a" * 64,
            public_key=base64.b64encode(b"y" * 32).decode(),
        )
        assert result is False

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_validate_signature_legacy_invalid_key_size(self):
        """Test legacy validate_signature rejects wrong key size."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy path

        # Wrong size public key (16 bytes instead of 32)
        result = validator.validate_signature(
            signature=base64.b64encode(b"x" * 64).decode(),
            message_hash="a" * 64,
            public_key=base64.b64encode(b"y" * 16).decode(),
        )
        assert result is False

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_validate_signature_legacy_crypto_failure(self):
        """Test legacy validate_signature returns False on crypto failure."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy path

        # Valid format but cryptographically invalid
        result = validator.validate_signature(
            signature=base64.b64encode(b"x" * 64).decode(),
            message_hash="a" * 64,
            public_key=base64.b64encode(b"y" * 32).decode(),
        )
        # Should return False (not raise)
        assert result is False

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_generate_keypair_legacy_path(self):
        """Test generate_keypair uses legacy Ed25519 when no provider."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy path

        private_key, public_key = validator.generate_keypair()

        # Should be base64-encoded 32-byte keys
        private_bytes = base64.b64decode(private_key)
        public_bytes = base64.b64decode(public_key)

        assert len(private_bytes) == 32
        assert len(public_bytes) == 32

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_sign_message_legacy_path(self):
        """Test sign_message uses legacy Ed25519 when no provider."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy path

        private_key, public_key = validator.generate_keypair()
        msg_hash = "a" * 64

        signature = validator.sign_message(msg_hash, private_key)

        # Should be base64-encoded 64-byte signature
        sig_bytes = base64.b64decode(signature)
        assert len(sig_bytes) == 64

        # Should verify in legacy mode
        assert validator.validate_signature(signature, msg_hash, public_key)

    def test_format_validation_invalid_base64_signature(self):
        """Test format validation rejects invalid base64."""
        validator = DualSignatureValidator()

        result = validator._validate_signature_format(
            signature="!!!invalid-base64!!!",
            message_hash="a" * 64,
            public_key=base64.b64encode(b"y" * 32).decode(),
        )
        assert result is False

    def test_format_validation_invalid_base64_public_key(self):
        """Test format validation rejects invalid base64 public key."""
        validator = DualSignatureValidator()

        result = validator._validate_signature_format(
            signature=base64.b64encode(b"x" * 64).decode(),
            message_hash="a" * 64,
            public_key="!!!invalid-base64!!!",
        )
        assert result is False


# =============================================================================
# TestOverrideWorkflowStateTransitions
# =============================================================================


class TestOverrideWorkflowStateTransitions:
    """Tests for OverrideWorkflow state transitions and edge cases."""

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_expired_override_request(self):
        """Test that expired requests are handled correctly."""
        validator = DualSignatureValidator()  # Use default; force expiry via expires_at
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        # Force expiration
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        private_key, public_key = validator.generate_keypair()
        signature = validator.sign_message(workflow.message_hash, private_key)

        success, msg = workflow.add_signature(
            signer_id="rl-1",
            role="risk_lead",
            signature=signature,
            public_key=public_key,
        )

        assert success is False
        assert "expired" in msg.lower()
        assert workflow.request.state == OverrideState.EXPIRED

    def test_validator_none_after_deserialization(self):
        """Test add_signature fails when validator is None (after deserialization)."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Simulate deserialization by setting validator to None
        workflow.validator = None

        success, msg = workflow.add_signature(
            signer_id="rl-1",
            role="risk_lead",
            signature=base64.b64encode(b"x" * 64).decode(),
            public_key=base64.b64encode(b"y" * 32).decode(),
        )

        assert success is False
        assert "validator" in msg.lower()

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_duplicate_risk_lead_signature_rejected(self):
        """Test that duplicate risk_lead signature is rejected."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        private_key, public_key = validator.generate_keypair()
        signature = validator.sign_message(workflow.message_hash, private_key)

        # First signature succeeds
        success1, _ = workflow.add_signature(
            signer_id="rl-1",
            role="risk_lead",
            signature=signature,
            public_key=public_key,
        )
        assert success1 is True

        # Second risk_lead signature should fail
        success2, msg = workflow.add_signature(
            signer_id="rl-2",
            role="risk_lead",
            signature=signature,
            public_key=public_key,
        )
        assert success2 is False
        assert "already provided" in msg

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_duplicate_security_lead_signature_rejected(self):
        """Test that duplicate security_lead signature is rejected."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        private_key, public_key = validator.generate_keypair()
        signature = validator.sign_message(workflow.message_hash, private_key)

        # First signature succeeds
        success1, _ = workflow.add_signature(
            signer_id="sl-1",
            role="security_lead",
            signature=signature,
            public_key=public_key,
        )
        assert success1 is True

        # Second security_lead signature should fail
        success2, msg = workflow.add_signature(
            signer_id="sl-2",
            role="security_lead",
            signature=signature,
            public_key=public_key,
        )
        assert success2 is False
        assert "already provided" in msg

    def test_same_signer_for_both_roles_rejected(self):
        """Test that the same signer cannot provide both role signatures."""

        class DummyValidator:
            expiration_hours = 24
            algorithm_name = "dummy"

            def create_message_hash(
                self, proposal_id: str, justification: str, failed_gates: list[str]
            ) -> str:
                return "a" * 64

            def validate_signature(
                self, signature: str, message_hash: str, public_key: str
            ) -> bool:
                return True

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=DummyValidator(),
        )

        success1, _ = workflow.add_signature(
            signer_id="same-signer",
            role="risk_lead",
            signature="sig",
            public_key="pub",
        )
        assert success1 is True

        success2, msg = workflow.add_signature(
            signer_id="same-signer",
            role="security_lead",
            signature="sig",
            public_key="pub",
        )
        assert success2 is False
        assert "four-eyes" in msg.lower()

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_reject_already_approved_fails(self):
        """Test that rejecting an already approved request fails."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        # Add both signatures to approve
        risk_priv, risk_pub = validator.generate_keypair()
        sec_priv, sec_pub = validator.generate_keypair()

        risk_sig = validator.sign_message(workflow.message_hash, risk_priv)
        sec_sig = validator.sign_message(workflow.message_hash, sec_priv)

        workflow.add_signature("rl-1", "risk_lead", risk_sig, risk_pub)
        workflow.add_signature("sl-1", "security_lead", sec_sig, sec_pub)

        assert workflow.request.state == OverrideState.APPROVED

        # Now try to reject - should fail
        result = workflow.reject("admin", "Too late!")
        assert result is False
        assert workflow.request.state == OverrideState.APPROVED

    def test_reject_already_expired_fails(self):
        """Test that rejecting an expired request fails."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Force expiration
        workflow.request.state = OverrideState.EXPIRED

        result = workflow.reject("admin", "Cannot reject expired")
        assert result is False

    def test_reject_time_expired_request_fails_and_marks_expired(self):
        """Regression: reject() must fail when request expired by wall clock."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)

        result = workflow.reject("admin", "Cannot reject expired")

        assert result is False
        assert workflow.request.state == OverrideState.EXPIRED
        assert workflow.request.rejected_by is None
        assert workflow.request.rejection_reason is None
        assert workflow.request.rejected_at is None

    def test_reject_already_rejected_fails(self):
        """Regression: re-rejecting a REJECTED override must be refused.

        Terminal states (APPROVED, REJECTED, EXPIRED) are immutable.
        Previously reject() only checked APPROVED and EXPIRED, allowing
        a REJECTED override's audit trail to be silently overwritten.
        """
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # First rejection succeeds
        result = workflow.reject("admin-1", "Policy violation")
        assert result is True
        assert workflow.request.state == OverrideState.REJECTED
        assert workflow.request.rejected_by == "admin-1"
        assert workflow.request.rejection_reason == "Policy violation"

        # Second rejection must be refused (terminal state)
        result = workflow.reject("admin-2", "Different reason")
        assert result is False
        # Original rejection metadata preserved
        assert workflow.request.rejected_by == "admin-1"
        assert workflow.request.rejection_reason == "Policy violation"

    def test_get_result_no_signatures(self):
        """Test get_result when no signatures collected."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        result = workflow.get_result()

        assert result.approved is False
        assert result.state == OverrideState.PENDING
        assert result.risk_lead_signature is None
        assert result.security_lead_signature is None
        assert result.combined_hash is None

    def test_get_result_validator_none_no_combined_hash(self):
        """Test get_result with validator=None doesn't compute combined hash."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Manually set signatures without validator
        workflow.risk_lead_signature = SignatureRecord(
            signer_id="rl-1",
            role="risk_lead",
            signature="sig1",
            message_hash="a" * 64,
            timestamp=datetime.now(timezone.utc),
        )
        workflow.security_lead_signature = SignatureRecord(
            signer_id="sl-1",
            role="security_lead",
            signature="sig2",
            message_hash="a" * 64,
            timestamp=datetime.now(timezone.utc),
        )
        workflow.validator = None

        result = workflow.get_result()
        # combined_hash should be None since validator is None
        assert result.combined_hash is None

    def test_get_pending_signatures_both_pending(self):
        """Test get_pending_signatures when both signatures are pending."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        pending = workflow.get_pending_signatures()
        assert set(pending) == {"risk_lead", "security_lead"}

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_get_pending_signatures_security_only(self):
        """Test get_pending_signatures when only security_lead is pending."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        private_key, public_key = validator.generate_keypair()
        signature = validator.sign_message(workflow.message_hash, private_key)
        workflow.add_signature("rl-1", "risk_lead", signature, public_key)

        pending = workflow.get_pending_signatures()
        assert pending == ["security_lead"]

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_get_pending_signatures_none_pending(self):
        """Test get_pending_signatures when all signatures collected."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        risk_priv, risk_pub = validator.generate_keypair()
        sec_priv, sec_pub = validator.generate_keypair()

        workflow.add_signature(
            "rl-1",
            "risk_lead",
            validator.sign_message(workflow.message_hash, risk_priv),
            risk_pub,
        )
        workflow.add_signature(
            "sl-1",
            "security_lead",
            validator.sign_message(workflow.message_hash, sec_priv),
            sec_pub,
        )

        pending = workflow.get_pending_signatures()
        assert pending == []


# =============================================================================
# TestOverrideWorkflowSerialization
# =============================================================================


class TestOverrideWorkflowSerialization:
    """Tests for OverrideWorkflow serialization/deserialization."""

    def test_workflow_id_format(self):
        """Test workflow_id property returns correct format."""
        workflow = OverrideWorkflow(
            proposal_id="test-prop-123",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        workflow_id = workflow.workflow_id
        assert workflow_id.startswith("test-prop-123:")
        assert len(workflow_id.split(":")[1]) == 16  # First 16 chars of hash

    def test_workflow_type_is_override(self):
        """Test workflow_type property returns 'override'."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        assert workflow.workflow_type == "override"

    def test_current_state_pending(self):
        """Test current_state property when no signatures."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        assert workflow.current_state == "pending"

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_current_state_partial(self):
        """Test current_state property when one signature collected."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        private_key, public_key = validator.generate_keypair()
        signature = validator.sign_message(workflow.message_hash, private_key)
        workflow.add_signature("rl-1", "risk_lead", signature, public_key)

        assert workflow.current_state == "partial"

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_current_state_approved(self):
        """Test current_state property when both signatures collected."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        risk_priv, risk_pub = validator.generate_keypair()
        sec_priv, sec_pub = validator.generate_keypair()

        workflow.add_signature(
            "rl-1",
            "risk_lead",
            validator.sign_message(workflow.message_hash, risk_priv),
            risk_pub,
        )
        workflow.add_signature(
            "sl-1",
            "security_lead",
            validator.sign_message(workflow.message_hash, sec_priv),
            sec_pub,
        )

        assert workflow.current_state == "approved"

    def test_current_state_rejected(self):
        """Test current_state reflects rejected state correctly."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )
        workflow.reject("admin", "Policy violation")
        assert workflow.current_state == "rejected"

    def test_current_state_expired(self):
        """Test current_state reflects expired state correctly."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )
        workflow.request.state = OverrideState.EXPIRED
        assert workflow.current_state == "expired"

    def test_to_dict_and_from_dict_roundtrip(self):
        """Test full serialization/deserialization roundtrip."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test justification",
            failed_gates=["risk", "profit"],
            requested_by="alice",
        )

        # Serialize
        data = workflow.to_dict()

        # Verify structure
        assert "workflow_id" in data
        assert "workflow_type" in data
        assert "current_state" in data
        assert "request" in data
        assert "message_hash" in data
        assert "expires_at" in data

        # Deserialize
        restored = OverrideWorkflow.from_dict(data)

        # Verify restoration
        assert restored.request.proposal_id == workflow.request.proposal_id
        assert restored.request.justification == workflow.request.justification
        assert restored.request.failed_gates == workflow.request.failed_gates
        assert restored.request.requested_by == workflow.request.requested_by
        assert restored.message_hash == workflow.message_hash
        assert restored.validator is None  # Validator not serialized

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_to_dict_with_signatures(self):
        """Test serialization includes signatures."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        private_key, public_key = validator.generate_keypair()
        signature = validator.sign_message(workflow.message_hash, private_key)
        workflow.add_signature("rl-1", "risk_lead", signature, public_key)

        data = workflow.to_dict()

        assert data["risk_lead_signature"] is not None
        assert data["risk_lead_signature"]["signer_id"] == "rl-1"
        assert data["risk_lead_signature"]["role"] == "risk_lead"
        assert data["security_lead_signature"] is None

    def test_set_validator_after_deserialization(self):
        """Test set_validator method restores validation capability."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Serialize and deserialize
        data = workflow.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        assert restored.validator is None

        # Set validator
        new_validator = DualSignatureValidator()
        restored.set_validator(new_validator)

        assert restored.validator is new_validator

    def test_set_key_store_after_deserialization(self):
        """Test set_key_store method restores key store."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Serialize and deserialize
        data = workflow.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        assert restored.key_store is None

        # Create mock key store
        mock_key_store = MagicMock()
        restored.set_key_store(mock_key_store)

        assert restored.key_store is mock_key_store

    def test_deserialize_signature_none(self):
        """Test _deserialize_signature handles None input."""
        result = OverrideWorkflow._deserialize_signature(None)
        assert result is None

    def test_serialize_signature_none(self):
        """Test _serialize_signature handles None input."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        result = workflow._serialize_signature(None)
        assert result is None


# =============================================================================
# TestSignWithStoredKey
# =============================================================================


class TestSignWithStoredKey:
    """Tests for sign_with_stored_key async method."""

    @pytest.mark.asyncio
    async def test_sign_with_stored_key_no_key_store(self):
        """Test sign_with_stored_key fails when key_store not configured."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=None,
        )

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "key store not configured" in msg.lower()

    @pytest.mark.asyncio
    async def test_sign_with_stored_key_no_validator(self):
        """Test sign_with_stored_key fails when validator not configured."""
        mock_key_store = MagicMock()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )
        workflow.validator = None

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "validator not configured" in msg.lower()

    @pytest.mark.asyncio
    async def test_sign_with_stored_key_invalid_role(self):
        """Test sign_with_stored_key fails with invalid role."""
        mock_key_store = MagicMock()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )

        success, msg = await workflow.sign_with_stored_key("invalid_role", "actor-1")

        assert success is False
        assert "invalid role" in msg.lower()

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_with_stored_key_duplicate_risk_lead(self):
        """Test sign_with_stored_key fails when risk_lead already signed."""
        mock_key_store = MagicMock()
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
            validator=validator,
        )

        # Manually set risk_lead signature
        workflow.risk_lead_signature = SignatureRecord(
            signer_id="rl-1",
            role="risk_lead",
            signature="existing",
            message_hash=workflow.message_hash,
            timestamp=datetime.now(timezone.utc),
        )

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "already provided" in msg

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_with_stored_key_duplicate_security_lead(self):
        """Test sign_with_stored_key fails when security_lead already signed."""
        mock_key_store = MagicMock()
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
            validator=validator,
        )

        # Manually set security_lead signature
        workflow.security_lead_signature = SignatureRecord(
            signer_id="sl-1",
            role="security_lead",
            signature="existing",
            message_hash=workflow.message_hash,
            timestamp=datetime.now(timezone.utc),
        )

        success, msg = await workflow.sign_with_stored_key("security_lead", "actor-1")

        assert success is False
        assert "already provided" in msg

    @pytest.mark.asyncio
    async def test_sign_with_stored_key_expired(self):
        """Test sign_with_stored_key fails when request expired."""
        mock_key_store = MagicMock()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )

        # Force expiration
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "expired" in msg.lower()
        assert workflow.request.state == OverrideState.EXPIRED

    @pytest.mark.asyncio
    async def test_sign_with_stored_key_terminal_state_no_key_decryption(self):
        """Test sign_with_stored_key rejects early on terminal state.

        BUG FIX: Previously sign_with_stored_key would decrypt the private
        key before checking terminal states, wasting work and unnecessarily
        exposing key material.
        """
        mock_key_store = MagicMock()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )

        # Force approved state
        workflow.request.state = OverrideState.APPROVED

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "already approved" in msg.lower()
        # Key store should NOT have been accessed
        mock_key_store.get_private_key.assert_not_called()

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_with_stored_key_no_private_key_found(self):
        """Test sign_with_stored_key fails when no key found in store."""
        mock_key_store = MagicMock()
        mock_key_store.get_private_key = AsyncMock(return_value=None)

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "no active key found" in msg.lower()

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_with_stored_key_no_public_key_found(self):
        """Test sign_with_stored_key fails when no public key found."""
        mock_key_store = MagicMock()
        mock_key_store.get_private_key = AsyncMock(return_value=b"x" * 32)
        mock_key_store.get_public_key = AsyncMock(return_value=None)

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "no public key found" in msg.lower()

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_with_stored_key_success(self):
        """Test sign_with_stored_key succeeds with valid key store."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy Ed25519

        # Generate real keypair for testing
        private_key, public_key = validator.generate_keypair()
        private_bytes = base64.b64decode(private_key)
        public_bytes = base64.b64decode(public_key)

        mock_key_store = MagicMock()
        mock_key_store.get_private_key = AsyncMock(return_value=private_bytes)
        mock_key_store.get_public_key = AsyncMock(return_value=public_bytes)
        mock_key_store.record_usage = AsyncMock()

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
            validator=validator,
        )

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is True
        assert workflow.risk_lead_signature is not None
        assert workflow.request.state == OverrideState.PARTIAL

        # Verify key_store.record_usage was called
        mock_key_store.record_usage.assert_called_once()

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_with_stored_key_pins_version_on_rotation(self):
        """Regression: pin key version to avoid private/public key mismatch.

        Simulates a key rotation window where active private/public lookups
        would otherwise return different versions.
        """
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy Ed25519

        # Version 1 keypair (used for signing)
        v1_private_b64, v1_public_b64 = validator.generate_keypair()
        v1_private_bytes = base64.b64decode(v1_private_b64)
        v1_public_bytes = base64.b64decode(v1_public_b64)

        # Version 2 public key (simulates post-rotation active key)
        _, v2_public_b64 = validator.generate_keypair()
        v2_public_bytes = base64.b64decode(v2_public_b64)

        async def get_private_key(role, algorithm, version=None):
            if version in (None, 1):
                return v1_private_bytes
            return None

        async def get_public_key(role, algorithm, version=None):
            if version is None:
                # Race window: active key changed between calls
                return v2_public_bytes
            if version == 1:
                return v1_public_bytes
            return None

        mock_key_store = MagicMock()
        mock_key_store.get_key_info = AsyncMock(return_value={"key_version": 1})
        mock_key_store.get_private_key = AsyncMock(side_effect=get_private_key)
        mock_key_store.get_public_key = AsyncMock(side_effect=get_public_key)
        mock_key_store.record_usage = AsyncMock()

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
            validator=validator,
        )

        success, _ = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is True
        assert workflow.risk_lead_signature is not None
        mock_key_store.get_key_info.assert_awaited_once_with(
            "risk_lead", "ed25519-legacy"
        )
        mock_key_store.get_private_key.assert_awaited_once_with(
            "risk_lead", "ed25519-legacy", version=1
        )
        mock_key_store.get_public_key.assert_awaited_once_with(
            "risk_lead", "ed25519-legacy", version=1
        )
        mock_key_store.record_usage.assert_awaited_once_with(
            role="risk_lead",
            algorithm="ed25519-legacy",
            operation="sign",
            actor_id="actor-1",
            context={
                "proposal_id": "prop-1",
                "message_hash": workflow.message_hash,
                "workflow_type": "override",
            },
            version=1,
        )

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_with_stored_key_exception_handling(self):
        """Test sign_with_stored_key handles exceptions gracefully."""
        mock_key_store = MagicMock()
        mock_key_store.get_private_key = AsyncMock(
            side_effect=RuntimeError("Database error")
        )

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )

        success, msg = await workflow.sign_with_stored_key("risk_lead", "actor-1")

        assert success is False
        assert "signing failed" in msg.lower()


# =============================================================================
# TestGetStoredKeyInfo
# =============================================================================


class TestGetStoredKeyInfo:
    """Tests for get_stored_key_info async method."""

    @pytest.mark.asyncio
    async def test_get_stored_key_info_no_key_store(self):
        """Test get_stored_key_info returns None when key_store not configured."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=None,
        )

        result = await workflow.get_stored_key_info("risk_lead")

        assert result is None

    @pytest.mark.asyncio
    async def test_get_stored_key_info_no_validator(self):
        """Test get_stored_key_info returns None when validator not configured."""
        mock_key_store = MagicMock()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )
        workflow.validator = None

        result = await workflow.get_stored_key_info("risk_lead")

        assert result is None

    @pytest.mark.asyncio
    async def test_get_stored_key_info_success(self):
        """Test get_stored_key_info returns key info from store."""
        mock_key_store = MagicMock()
        expected_info = {
            "id": "key-123",
            "role": "risk_lead",
            "algorithm": "bip322-simple",
            "key_version": 1,
        }
        mock_key_store.get_key_info = AsyncMock(return_value=expected_info)

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
        )

        result = await workflow.get_stored_key_info("risk_lead")

        assert result == expected_info
        mock_key_store.get_key_info.assert_called_once()


# =============================================================================
# TestProviderInitializationEdgeCases
# =============================================================================


class TestProviderInitializationEdgeCases:
    """Tests for provider initialization edge cases."""

    def test_validator_with_custom_expiration(self):
        """Test validator accepts custom expiration hours."""
        validator = DualSignatureValidator(expiration_hours=48)
        assert validator.expiration_hours == 48

    def test_validator_with_explicit_none_provider(self):
        """Test validator accepts explicit None provider."""
        validator = DualSignatureValidator(provider=None)
        # May auto-select a provider if available
        _ = validator.provider

    @pytest.mark.skipif(not PROVIDERS_AVAILABLE, reason="Providers not available")
    def test_validator_updates_sizes_from_provider(self):
        """Test validator updates signature/key sizes from provider."""
        from src.crypto import get_default_provider

        provider = get_default_provider()
        validator = DualSignatureValidator(provider=provider)

        # Sizes should match provider (W-1 fix: instance attributes, not class)
        assert provider.signature_size == validator._signature_size
        assert provider.public_key_size == validator._public_key_size


# =============================================================================
# TestOverrideWorkflowFromDictWithState
# =============================================================================


class TestOverrideWorkflowFromDictWithState:
    """Tests for from_dict with different states."""

    def test_from_dict_preserves_state(self):
        """Test that from_dict preserves the override state."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Set to PARTIAL state manually
        workflow.request.state = OverrideState.PARTIAL

        data = workflow.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        assert restored.request.state == OverrideState.PARTIAL

    def test_from_dict_handles_missing_state_gracefully(self):
        """Test that from_dict handles missing state field."""
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
        )

        data = workflow.to_dict()
        # Remove state field to simulate old data
        del data["request"]["state"]

        restored = OverrideWorkflow.from_dict(data)

        # Should default to PENDING
        assert restored.request.state == OverrideState.PENDING

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_from_dict_with_signatures_roundtrip(self):
        """Test from_dict deserializes signatures correctly."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        # Add both signatures
        risk_priv, risk_pub = validator.generate_keypair()
        sec_priv, sec_pub = validator.generate_keypair()

        workflow.add_signature(
            "rl-1",
            "risk_lead",
            validator.sign_message(workflow.message_hash, risk_priv),
            risk_pub,
        )
        workflow.add_signature(
            "sl-1",
            "security_lead",
            validator.sign_message(workflow.message_hash, sec_priv),
            sec_pub,
        )

        # Serialize and deserialize
        data = workflow.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        # Verify signatures are restored
        assert restored.risk_lead_signature is not None
        assert restored.security_lead_signature is not None
        assert restored.risk_lead_signature.signer_id == "rl-1"
        assert restored.security_lead_signature.signer_id == "sl-1"
        assert restored.risk_lead_signature.public_key is not None
        assert restored.security_lead_signature.public_key is not None


# =============================================================================
# TestLegacyValidatorExceptionPaths
# =============================================================================


class TestLegacyValidatorExceptionPaths:
    """Tests for legacy validator exception handling paths."""

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_legacy_validate_signature_value_error(self):
        """Test legacy validate_signature handles ValueError (e.g., invalid key format)."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy path

        # Create a signature with valid base64 but invalid Ed25519 key bytes
        # This should trigger ValueError when loading the public key
        result = validator.validate_signature(
            signature=base64.b64encode(b"\x00" * 64).decode(),
            message_hash="a" * 64,
            # A public key of all zeros is invalid for Ed25519
            public_key=base64.b64encode(b"\x00" * 32).decode(),
        )
        assert result is False

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_legacy_sign_and_verify_roundtrip(self):
        """Test legacy sign_message and validate_signature roundtrip works."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy path

        private_key, public_key = validator.generate_keypair()
        msg_hash = validator.create_message_hash("p1", "test", ["gate1"])

        signature = validator.sign_message(msg_hash, private_key)

        # Should verify successfully
        assert validator.validate_signature(signature, msg_hash, public_key) is True

        # Different hash should fail
        other_hash = validator.create_message_hash("p2", "other", ["gate2"])
        assert validator.validate_signature(signature, other_hash, public_key) is False

    def test_generate_keypair_no_provider_no_crypto_raises(self):
        """Test generate_keypair raises RuntimeError when no provider and no crypto."""
        validator = DualSignatureValidator()
        validator._provider = None  # No provider

        # Patch CRYPTO_AVAILABLE to False
        import workflows.override as override_module

        original = override_module.CRYPTO_AVAILABLE
        try:
            override_module.CRYPTO_AVAILABLE = False
            with pytest.raises(RuntimeError, match="No signature provider"):
                validator.generate_keypair()
        finally:
            override_module.CRYPTO_AVAILABLE = original

    def test_sign_message_no_provider_no_crypto_raises(self):
        """Test sign_message raises RuntimeError when no provider and no crypto."""
        validator = DualSignatureValidator()
        validator._provider = None  # No provider

        import workflows.override as override_module

        original = override_module.CRYPTO_AVAILABLE
        try:
            override_module.CRYPTO_AVAILABLE = False
            with pytest.raises(RuntimeError, match="No signature provider"):
                validator.sign_message("a" * 64, "dummy_key")
        finally:
            override_module.CRYPTO_AVAILABLE = original

    def test_validate_signature_no_provider_no_crypto_format_only(self):
        """Test validate_signature uses format validation when no crypto."""
        validator = DualSignatureValidator()
        validator._provider = None  # No provider

        import workflows.override as override_module

        original = override_module.CRYPTO_AVAILABLE
        try:
            override_module.CRYPTO_AVAILABLE = False
            # Should use format-only validation
            result = validator.validate_signature(
                signature=base64.b64encode(b"x" * 64).decode(),
                message_hash="a" * 64,
                public_key=base64.b64encode(b"y" * 32).decode(),
            )
            # Format is valid, so should return True (but not cryptographically verified)
            assert result is True
        finally:
            override_module.CRYPTO_AVAILABLE = original


# =============================================================================
# TestStateUpdateBranches
# =============================================================================


class TestStateUpdateBranches:
    """Tests for _update_override_state branch coverage."""

    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    def test_update_state_only_security_lead(self):
        """Test state update when only security_lead has signed."""
        validator = DualSignatureValidator()
        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        # Add only security_lead signature
        private_key, public_key = validator.generate_keypair()
        signature = validator.sign_message(workflow.message_hash, private_key)

        workflow.add_signature("sl-1", "security_lead", signature, public_key)

        assert workflow.request.state == OverrideState.PARTIAL
        assert workflow.risk_lead_signature is None
        assert workflow.security_lead_signature is not None


# =============================================================================
# TestSignWithStoredKeyIntegration
# =============================================================================


class TestSignWithStoredKeyIntegration:
    """Integration tests for sign_with_stored_key with full workflow."""

    @pytest.mark.asyncio
    @pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
    async def test_sign_both_roles_with_stored_keys(self):
        """Test signing both roles with stored keys completes the workflow."""
        validator = DualSignatureValidator()
        validator._provider = None  # Force legacy Ed25519

        # Generate keypairs for both roles
        risk_priv, risk_pub = validator.generate_keypair()
        sec_priv, sec_pub = validator.generate_keypair()

        risk_priv_bytes = base64.b64decode(risk_priv)
        risk_pub_bytes = base64.b64decode(risk_pub)
        sec_priv_bytes = base64.b64decode(sec_priv)
        sec_pub_bytes = base64.b64decode(sec_pub)

        mock_key_store = MagicMock()

        # Set up key store to return appropriate keys for each role
        async def get_private_key(role, algorithm):
            if role == "risk_lead":
                return risk_priv_bytes
            return sec_priv_bytes

        async def get_public_key(role, algorithm):
            if role == "risk_lead":
                return risk_pub_bytes
            return sec_pub_bytes

        mock_key_store.get_private_key = get_private_key
        mock_key_store.get_public_key = get_public_key
        mock_key_store.record_usage = AsyncMock()

        workflow = OverrideWorkflow(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="alice",
            key_store=mock_key_store,
            validator=validator,
        )

        # Sign with risk_lead
        success1, msg1 = await workflow.sign_with_stored_key(
            "risk_lead", "risk@aegis.io"
        )
        assert success1 is True
        assert workflow.request.state == OverrideState.PARTIAL

        # Sign with security_lead
        success2, msg2 = await workflow.sign_with_stored_key(
            "security_lead", "sec@aegis.io"
        )
        assert success2 is True
        assert workflow.request.state == OverrideState.APPROVED

        # Verify audit was recorded twice
        assert mock_key_store.record_usage.call_count == 2


# =============================================================================
# RBAC + Telemetry + Alert Wiring Integration Tests
# =============================================================================


@pytest.mark.skipif(not CRYPTO_AVAILABLE, reason="cryptography not available")
class TestOverrideWiringIntegration:
    """Tests for RBAC, telemetry, Prometheus, and alert wiring in OverrideWorkflow."""

    def _make_rbac_enforcer(self):
        """Create a mock RBACEnforcer."""
        mock = MagicMock()
        mock.authorize_override.return_value = (True, None)
        return mock

    def _make_denied_rbac_enforcer(self, reason="RBAC denied"):
        """Create a mock RBACEnforcer that denies."""
        mock = MagicMock()
        mock.authorize_override.return_value = (False, reason)
        return mock

    def _make_telemetry_emitter(self):
        """Create a mock TelemetryEmitter."""
        mock = MagicMock()
        mock.emit_override_requested.return_value = MagicMock()
        mock.emit_override_approved.return_value = MagicMock()
        mock.emit_override_rejected.return_value = MagicMock()
        return mock

    def _make_prometheus_exporter(self):
        """Create a mock PrometheusExporter."""
        mock = MagicMock()
        mock.record_override_request.return_value = None
        return mock

    def _make_alert_sink(self):
        """Create a mock AlertSink."""
        mock = MagicMock()
        mock.send_alert.return_value = None
        return mock

    def test_init_emits_telemetry_and_alert_on_creation(self):
        """OverrideWorkflow constructor fires telemetry and alert events."""
        emitter = self._make_telemetry_emitter()
        prometheus = self._make_prometheus_exporter()
        alert = self._make_alert_sink()

        OverrideWorkflow(
            proposal_id="wiring-001",
            justification="Test wiring",
            failed_gates=["risk"],
            requested_by="alice",
            telemetry_emitter=emitter,
            prometheus_exporter=prometheus,
            alert_sink=alert,
        )

        emitter.emit_override_requested.assert_called_once()
        prometheus.record_override_request.assert_called_once_with(outcome="requested")
        alert.send_alert.assert_called_once()
        call_args = alert.send_alert.call_args
        from telemetry.alert import AlertSeverity

        assert call_args[0][0] == AlertSeverity.INFO

    def test_rbac_denied_emits_telemetry_and_emergency_alert(self):
        """RBAC denial in add_signature fires telemetry and EMERGENCY alert."""
        rbac = self._make_denied_rbac_enforcer("Unauthorized role")
        emitter = self._make_telemetry_emitter()
        alert = self._make_alert_sink()

        workflow = OverrideWorkflow(
            proposal_id="wiring-002",
            justification="Test denial",
            failed_gates=["risk"],
            requested_by="alice",
            rbac_enforcer=rbac,
            telemetry_emitter=emitter,
            alert_sink=alert,
        )

        # Reset mocks from init calls
        emitter.reset_mock()
        alert.reset_mock()

        success, msg = workflow.add_signature(
            signer_id="eve",
            role="risk_lead",
            signature="ZmFrZQ==",
            public_key="ZmFrZQ==",
        )

        assert not success
        assert "Unauthorized role" in msg
        emitter.emit_override_rejected.assert_called_once()
        alert.send_alert.assert_called_once()
        call_args = alert.send_alert.call_args
        from telemetry.alert import AlertSeverity

        assert call_args[0][0] == AlertSeverity.EMERGENCY

    def test_rejection_emits_telemetry_prometheus_alert(self):
        """reject() fires telemetry, Prometheus counter, and WARNING alert."""
        emitter = self._make_telemetry_emitter()
        prometheus = self._make_prometheus_exporter()
        alert = self._make_alert_sink()

        workflow = OverrideWorkflow(
            proposal_id="wiring-003",
            justification="Test rejection",
            failed_gates=["risk"],
            requested_by="alice",
            telemetry_emitter=emitter,
            prometheus_exporter=prometheus,
            alert_sink=alert,
        )

        # Reset mocks from init calls
        emitter.reset_mock()
        prometheus.reset_mock()
        alert.reset_mock()

        workflow.reject("admin", "Not justified")

        emitter.emit_override_rejected.assert_called_once()
        prometheus.record_override_request.assert_called_once_with(outcome="rejected")
        alert.send_alert.assert_called_once()
        call_args = alert.send_alert.call_args
        from telemetry.alert import AlertSeverity

        assert call_args[0][0] == AlertSeverity.WARNING

    def test_log_alert_sink_wiring(self, caplog):
        """LogAlertSink actually logs when wired into OverrideWorkflow."""
        import logging

        alert = LogAlertSink(logger_name="test.alerts")
        with caplog.at_level(logging.INFO, logger="test.alerts"):
            OverrideWorkflow(
                proposal_id="wiring-004",
                justification="Test log sink",
                failed_gates=["risk"],
                requested_by="alice",
                alert_sink=alert,
            )
        assert any("Override requested" in rec.message for rec in caplog.records)


class TestBH13OverrideToDict:
    """BH13-L2: OverrideWorkflow.to_dict() must return defensive copies."""

    def test_to_dict_failed_gates_defensive_copy(self):
        """Mutating to_dict() result must not corrupt internal state."""
        wf = OverrideWorkflow(
            proposal_id="bh13-test",
            justification="Test defensive copy",
            failed_gates=["risk", "complexity"],
            requested_by="alice",
        )
        d = wf.to_dict()
        original_gates = list(wf.request.failed_gates)

        # Mutate the returned dict's failed_gates
        d["request"]["failed_gates"].append("injected")

        # Internal state must be unchanged
        assert wf.request.failed_gates == original_gates
        assert "injected" not in wf.request.failed_gates


class TestBH15GetResultDefensiveCopy:
    """BH15-M2: get_result() must return defensive copies of SignatureRecords."""

    def test_get_result_signature_mutation_does_not_affect_workflow(self):
        """Mutating returned SignatureRecord must not corrupt workflow state."""
        wf = OverrideWorkflow(
            proposal_id="bh15-test",
            justification="Test get_result copy",
            failed_gates=["risk"],
            requested_by="alice",
        )
        # Use real keypair for valid signature
        validator = DualSignatureValidator(expiration_hours=24)
        private_key, public_key = validator.generate_keypair()
        wf.validator = validator
        signature = validator.sign_message(wf.message_hash, private_key)

        # Add a risk lead signature with valid crypto
        success, _ = wf.add_signature(
            signer_id="risk-lead-1",
            role="risk_lead",
            signature=signature,
            public_key=public_key,
        )
        assert success
        original_signer = wf.risk_lead_signature.signer_id

        # Get result and mutate the returned signature
        result = wf.get_result()
        result.risk_lead_signature.signer_id = "attacker"

        # Internal state must be unchanged
        assert wf.risk_lead_signature.signer_id == original_signer
        assert wf.risk_lead_signature.signer_id != "attacker"

    def test_get_result_none_signatures_handled(self):
        """get_result() with no signatures must not crash."""
        wf = OverrideWorkflow(
            proposal_id="bh15-test-none",
            justification="Test none sigs",
            failed_gates=["risk"],
            requested_by="alice",
        )
        result = wf.get_result()
        assert result.risk_lead_signature is None
        assert result.security_lead_signature is None


class TestBH20OverrideFromDictMutableSharing:
    """BH20-M2: OverrideWorkflow.from_dict() must defensively copy failed_gates."""

    def test_from_dict_failed_gates_not_shared_with_input(self):
        """Mutation of input data must not corrupt restored workflow state."""
        wf = OverrideWorkflow(
            proposal_id="bh20-test",
            justification="test mutable sharing",
            failed_gates=["risk", "profit"],
            requested_by="alice",
        )
        data = wf.to_dict()

        restored = OverrideWorkflow.from_dict(data)

        # Mutate the input data after deserialization
        data["request"]["failed_gates"].append("novelty")

        # Restored workflow must NOT be affected
        assert restored.request.failed_gates == ["risk", "profit"]
        assert len(restored.request.failed_gates) == 2
