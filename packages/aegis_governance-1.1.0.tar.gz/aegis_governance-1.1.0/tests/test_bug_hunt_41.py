"""Regression tests for Bug Hunt #41 — Hybrid (gpt-5.3-codex + 3 Claude sweep agents).

BH41-Codex: ComplexityDecomposer bool guard for complexity_floor (in test_engine.py)
BH41-M1: Analyst._evaluate_quality_gate — None subscores crash GateEvaluator
BH41-M2: validate_range — NaN bypass with default check_nan=False → changed to True
BH41-M3: ToolSchemaSigner.create_tool_statement — _prev_digests mutated before signing
BH41-M4: ConsensusWorkflow.get_required_missing — DEFER voters satisfy required roles
BH41-L1: Calibrator.list_proposals — status read race after lock release
BH41-L2: TelemetryEmitter.emit_mcp_invocation — or-coercion of correlation_id
"""

from __future__ import annotations

import threading
import time

import pytest

# ---------------------------------------------------------------------------
# BH41-M1: Analyst._evaluate_quality_gate — None subscores
# ---------------------------------------------------------------------------


class TestBH41M1AnalystNoneSubscores:
    """BH41-M1: None elements in quality_subscores cause TypeError in GateEvaluator."""

    @pytest.fixture()
    def analyst(self):
        from actors.analyst import Analyst

        return Analyst(actor_id="test-analyst", name="Test Analyst")

    def test_none_subscores_do_not_crash(self, analyst):
        """[None, 0.8] in subscores must not raise TypeError."""
        from actors.analyst import AnalysisRequest

        request_data = {
            "quality_score": 0.8,
            "quality_subscores": [None, 0.8, None],
        }
        req = AnalysisRequest(proposal_id="test-p1", analysis_type="full")
        # Must not raise TypeError — saw_non_null filtering applies
        result = analyst.analyze_proposal(req, request_data)
        assert result.success or not result.success  # any outcome is fine; no crash

    def test_all_null_subscores_default(self, analyst):
        """[None, None] all-null list must fall back to defaults, not crash."""
        from actors.analyst import AnalysisRequest

        request_data = {
            "quality_score": 0.8,
            "quality_subscores": [None, None],
        }
        req = AnalysisRequest(proposal_id="test-p2", analysis_type="full")
        result = analyst.analyze_proposal(req, request_data)
        assert result.success or not result.success  # no crash

    def test_explicit_none_subscores_field_defaults(self, analyst):
        """quality_subscores=None (explicit null) must use defaults."""
        from actors.analyst import AnalysisRequest

        request_data = {
            "quality_score": 0.8,
            "quality_subscores": None,
        }
        req = AnalysisRequest(proposal_id="test-p3", analysis_type="full")
        result = analyst.analyze_proposal(req, request_data)
        assert result.success or not result.success  # no crash

    def test_valid_subscores_unaffected(self, analyst):
        """Non-null subscores must continue to work correctly."""
        from actors.analyst import AnalysisRequest

        request_data = {
            "quality_score": 0.9,
            "quality_subscores": [0.9, 0.85, 0.95],
        }
        req = AnalysisRequest(proposal_id="test-p4", analysis_type="full")
        result = analyst.analyze_proposal(req, request_data)
        assert result.success or not result.success  # no crash

    def test_mixed_none_and_valid_subscores_filters_correctly(self, analyst):
        """Mixed list [None, 0.9] must use only the non-null values."""
        from actors.analyst import AnalysisRequest

        request_data = {
            "quality_score": 0.9,
            "quality_subscores": [None, 0.9, None],
        }
        req = AnalysisRequest(proposal_id="test-p5", analysis_type="full")
        # Must not raise — the None values are filtered before gate evaluation
        result = analyst.analyze_proposal(req, request_data)
        assert result.success or not result.success  # no crash


# ---------------------------------------------------------------------------
# BH41-M2: validate_range — default check_nan=True
# ---------------------------------------------------------------------------


class TestBH41M2ValidateRangeNaNDefault:
    """BH41-M2: validate_range NaN bypass when check_nan=False (old default)."""

    def test_nan_rejected_by_default(self):
        """NaN must be rejected when check_nan is not specified (new default=True)."""
        from engine.validation import validate_range

        with pytest.raises(ValueError, match="must be in"):
            validate_range("param", float("nan"), 0.0, 1.0)

    def test_nan_still_rejected_when_explicit_true(self):
        """NaN must be rejected when check_nan=True is explicit."""
        from engine.validation import validate_range

        with pytest.raises(ValueError, match="must be in"):
            validate_range("param", float("nan"), 0.0, 1.0, check_nan=True)

    def test_nan_passes_when_caller_explicitly_opts_out(self):
        """Caller can still pass check_nan=False to opt out (backward compat)."""
        from engine.validation import validate_range

        # Should NOT raise — caller explicitly disabled NaN check
        validate_range("param", float("nan"), 0.0, 1.0, check_nan=False)

    def test_valid_value_unaffected(self):
        """Normal values within range still pass."""
        from engine.validation import validate_range

        validate_range("param", 0.5, 0.0, 1.0)  # no exception

    def test_out_of_range_still_rejected(self):
        """Out-of-range values still raise ValueError."""
        from engine.validation import validate_range

        with pytest.raises(ValueError):
            validate_range("param", 1.5, 0.0, 1.0)

    def test_neg_nan_rejected_by_default(self):
        """Negative NaN must also be rejected by default."""
        from engine.validation import validate_range

        # math.nan and -math.nan should both be caught
        with pytest.raises(ValueError):
            validate_range("param", -float("nan"), 0.0, 1.0)


# ---------------------------------------------------------------------------
# BH41-M3: ToolSchemaSigner — _prev_digests atomic after signing
# ---------------------------------------------------------------------------


class TestBH41M3SchemaSignerAtomicChainState:
    """BH41-M3: _prev_digests must not be mutated before sign_statement() succeeds."""

    @pytest.fixture()
    def valid_signer(self):
        from crypto.ed25519_provider import Ed25519Provider
        from crypto.schema_signer import SigningKeyPair, ToolSchemaSigner

        provider = Ed25519Provider()
        private_key, public_key = provider.generate_keypair()
        kp = SigningKeyPair(private_key=private_key, public_key=public_key)
        return ToolSchemaSigner(key_pair=kp, issuer="test-issuer")

    @pytest.fixture()
    def invalid_signer(self):
        """Signer with 8-byte (invalid) private key — sign_statement will raise."""
        from crypto.schema_signer import SigningKeyPair, ToolSchemaSigner

        kp = SigningKeyPair(private_key=b"tooshort", public_key=b"x" * 32)
        return ToolSchemaSigner(key_pair=kp, issuer="test-issuer")

    def test_valid_signer_chains_correctly(self, valid_signer):
        """Valid signing: prevDigest in second call references first tool's digest."""
        tool = {"name": "tool_a", "description": "Test", "inputSchema": {}}
        # First call — no prevDigest
        valid_signer.sign_tools_list([tool])
        # Second call — prevDigest must be set (chain advanced)
        result2 = valid_signer.sign_tools_list([tool])
        stmt2 = result2["toolProofs"][0]["statement"]
        assert "prevDigest" in stmt2["tool"], "Chain must advance on second call"

    def test_failed_signing_does_not_corrupt_chain(self, invalid_signer):
        """If sign_statement raises, _prev_digests must NOT be updated."""
        tool = {"name": "chain_tool", "description": "Test", "inputSchema": {}}
        # Record initial state (empty)
        initial_prev = dict(invalid_signer._prev_digests)

        with pytest.raises(ValueError):
            invalid_signer.sign_tools_list([tool])

        # _prev_digests must be unchanged after failure
        assert (
            invalid_signer._prev_digests == initial_prev
        ), "_prev_digests must not be mutated when sign_statement raises"

    def test_partial_failure_does_not_corrupt_chain(self, invalid_signer):
        """With multiple tools, failure on first must leave chain state clean."""
        tools = [
            {"name": "tool_x", "description": "X", "inputSchema": {}},
            {"name": "tool_y", "description": "Y", "inputSchema": {}},
        ]
        initial_prev = dict(invalid_signer._prev_digests)

        with pytest.raises(ValueError):
            invalid_signer.sign_tools_list(tools)

        # Neither tool must have been committed to the chain
        assert invalid_signer._prev_digests == initial_prev

    def test_successful_signing_does_advance_chain(self, valid_signer):
        """After successful signing, _prev_digests must be updated for each tool."""
        tool = {"name": "advance_tool", "description": "Test", "inputSchema": {}}
        assert "advance_tool" not in valid_signer._prev_digests

        valid_signer.sign_tools_list([tool])

        assert (
            "advance_tool" in valid_signer._prev_digests
        ), "Chain state must be advanced after successful signing"


# ---------------------------------------------------------------------------
# BH41-M4: ConsensusWorkflow.get_required_missing — DEFER voters
# ---------------------------------------------------------------------------


class TestBH41M4ConsensusGetRequiredMissingDefer:
    """BH41-M4: DEFER votes must not satisfy required-role obligations."""

    @pytest.fixture()
    def workflow(self):
        from workflows.consensus import ConsensusConfig, ConsensusWorkflow

        config = ConsensusConfig(
            quorum_percentage=0.5,
            approval_threshold=0.6,
            required_roles={"risk_lead"},
        )
        return ConsensusWorkflow(
            proposal_id="test-prop",
            eligible_voters={"risk_lead_actor", "other_actor"},
            config=config,
        )

    def test_defer_vote_does_not_satisfy_required_role(self, workflow):
        """An actor casting DEFER must NOT be counted as having fulfilled their role."""
        from workflows.consensus import VoteOutcome

        actor_roles = {"risk_lead_actor": {"risk_lead"}}
        workflow.cast_vote("risk_lead_actor", VoteOutcome.DEFER)

        missing = workflow.get_required_missing(actor_roles=actor_roles)
        assert (
            "risk_lead" in missing
        ), "risk_lead must still be missing after a DEFER vote"

    def test_approve_vote_satisfies_required_role(self, workflow):
        """An actor casting APPROVE must satisfy their required-role obligation."""
        from workflows.consensus import VoteOutcome

        actor_roles = {"risk_lead_actor": {"risk_lead"}}
        workflow.cast_vote("risk_lead_actor", VoteOutcome.APPROVE)

        missing = workflow.get_required_missing(actor_roles=actor_roles)
        assert (
            "risk_lead" not in missing
        ), "risk_lead must be satisfied after an APPROVE vote"

    def test_reject_vote_satisfies_required_role(self, workflow):
        """An actor casting REJECT must satisfy their required-role obligation."""
        from workflows.consensus import VoteOutcome

        actor_roles = {"risk_lead_actor": {"risk_lead"}}
        workflow.cast_vote("risk_lead_actor", VoteOutcome.REJECT)

        missing = workflow.get_required_missing(actor_roles=actor_roles)
        assert "risk_lead" not in missing

    def test_abstain_vote_satisfies_required_role(self, workflow):
        """An actor casting ABSTAIN must satisfy their required-role obligation."""
        from workflows.consensus import VoteOutcome

        actor_roles = {"risk_lead_actor": {"risk_lead"}}
        workflow.cast_vote("risk_lead_actor", VoteOutcome.ABSTAIN)

        missing = workflow.get_required_missing(actor_roles=actor_roles)
        assert "risk_lead" not in missing

    def test_no_votes_returns_all_required_roles(self, workflow):
        """With no votes, all required roles must be returned as missing."""
        actor_roles = {"risk_lead_actor": {"risk_lead"}}
        missing = workflow.get_required_missing(actor_roles=actor_roles)
        assert "risk_lead" in missing

    def test_defer_then_approve_satisfies_role(self, workflow):
        """Actor who deferred then approves must satisfy required role (vote overwrite)."""
        from workflows.consensus import VoteOutcome

        actor_roles = {"risk_lead_actor": {"risk_lead"}}

        workflow.cast_vote("risk_lead_actor", VoteOutcome.DEFER)
        assert "risk_lead" in workflow.get_required_missing(actor_roles=actor_roles)

        workflow.cast_vote("risk_lead_actor", VoteOutcome.APPROVE)
        assert "risk_lead" not in workflow.get_required_missing(actor_roles=actor_roles)


# ---------------------------------------------------------------------------
# BH41-L1: Calibrator.list_proposals — status snapshot under lock
# ---------------------------------------------------------------------------


class TestBH41L1CalibratorListProposalsDataRace:
    """BH41-L1: list_proposals must snapshot status values under the lock."""

    @pytest.fixture()
    def calibrator(self):
        from actors.calibrator import Calibrator

        return Calibrator("cal-bh41", "BH41 Calibrator")

    def _make_proposal(self, cal, proposal_id="bh41-p1"):
        """Create a simple gate threshold proposal and return its ID."""
        cal.propose_gate_threshold(
            proposal_id=proposal_id,
            parameter_name="epsilon_R",
            current_value=0.01,
            proposed_value=0.02,
            justification="BH41 test",
            data_window=50,
            statistical_method="z_test",
        )
        return proposal_id

    def test_list_proposals_returns_correct_status_after_approval(self, calibrator):
        """Status in returned summaries must reflect state at call time."""
        from actors.calibrator import CalibrationStatus

        pid = self._make_proposal(calibrator, "status-test")

        # List while PROPOSED
        listed = calibrator.list_proposals()
        assert listed.success
        # Should find proposal in PROPOSED state
        p_before = next(
            (p for p in listed.result_data["proposals"] if p["proposal_id"] == pid),
            None,
        )
        assert p_before is not None
        assert p_before["status"] == CalibrationStatus.PROPOSED.value

        # Approve
        calibrator.approve_calibration(pid, "reviewer-bh41")

        # List again — status must now reflect APPROVED
        listed_after = calibrator.list_proposals()
        assert listed_after.success
        p_after = next(
            (
                p
                for p in listed_after.result_data["proposals"]
                if p["proposal_id"] == pid
            ),
            None,
        )
        assert p_after is not None
        assert p_after["status"] == CalibrationStatus.APPROVED.value

    def test_list_proposals_concurrent_no_crash(self, calibrator):
        """list_proposals must not crash under concurrent approve calls."""
        pid = self._make_proposal(calibrator, "concurrent-bh41")
        errors: list[Exception] = []

        def approver() -> None:
            try:
                calibrator.approve_calibration(pid, "reviewer-concurrent")
            except Exception as e:
                errors.append(e)

        def lister() -> None:
            for _ in range(20):
                try:
                    calibrator.list_proposals()
                except Exception as e:
                    errors.append(e)
                time.sleep(0.001)

        t_approve = threading.Thread(target=approver)
        t_list = threading.Thread(target=lister)
        t_list.start()
        t_approve.start()
        t_approve.join(timeout=5)
        t_list.join(timeout=5)

        assert not errors, f"Errors during concurrent list/approve: {errors}"

    def test_list_proposals_status_filter_consistent(self, calibrator):
        """Status filter must return only proposals with the requested status."""
        from actors.calibrator import CalibrationStatus

        pid = self._make_proposal(calibrator, "filter-bh41")

        # Filter for PROPOSED — should return our proposal
        listed = calibrator.list_proposals(status_filter=CalibrationStatus.PROPOSED)
        assert listed.success
        ids = [p["proposal_id"] for p in listed.result_data["proposals"]]
        assert pid in ids
        # All returned proposals must have the requested status
        for p in listed.result_data["proposals"]:
            assert p["status"] == CalibrationStatus.PROPOSED.value

    def test_list_proposals_filter_excludes_other_status(self, calibrator):
        """After approval, proposal must NOT appear in PROPOSED filter."""
        from actors.calibrator import CalibrationStatus

        pid = self._make_proposal(calibrator, "exclude-bh41")
        calibrator.approve_calibration(pid, "reviewer-exclude")

        # Filter for PROPOSED — approved proposal must be excluded
        listed = calibrator.list_proposals(status_filter=CalibrationStatus.PROPOSED)
        assert listed.success
        ids = [p["proposal_id"] for p in listed.result_data["proposals"]]
        assert pid not in ids


# ---------------------------------------------------------------------------
# BH41-L2: TelemetryEmitter.emit_mcp_invocation — or-coercion of correlation_id
# ---------------------------------------------------------------------------


class TestBH41L2EmitMCPInvocationCorrelationId:
    """BH41-L2: emit_mcp_invocation must use explicit None-sentinel for correlation_id."""

    @pytest.fixture()
    def emitter(self):
        from telemetry.emitter import TelemetryEmitter

        return TelemetryEmitter(source="bh41-test")

    def test_no_correlation_id_defaults_to_none_without_active_chain(self, emitter):
        """Without an active correlation chain, correlation_id in event must be None."""
        event = emitter.emit_mcp_invocation(
            tool_name="test_tool",
            params_hash="abc123",
            decision="ALLOW",
            latency_ms=5.0,
        )
        assert event.correlation_id is None

    def test_active_chain_propagates_when_no_correlation_passed(self, emitter):
        """With an active correlation, event must carry the active ID."""
        chain_id = emitter.start_correlation()
        event = emitter.emit_mcp_invocation(
            tool_name="test_tool",
            params_hash="abc123",
            decision="ALLOW",
            latency_ms=5.0,
        )
        emitter.end_correlation()
        assert event.correlation_id == chain_id

    def test_explicit_correlation_id_overrides_active_chain(self, emitter):
        """Explicit correlation_id must override the active correlation chain."""
        emitter.start_correlation()
        explicit_id = "explicit-correlation-bh41"
        event = emitter.emit_mcp_invocation(
            tool_name="test_tool",
            params_hash="abc123",
            decision="ALLOW",
            latency_ms=5.0,
            correlation_id=explicit_id,
        )
        emitter.end_correlation()
        assert event.correlation_id == explicit_id

    def test_explicit_none_uses_active_chain(self, emitter):
        """Passing correlation_id=None explicitly falls back to active chain."""
        chain_id = emitter.start_correlation()
        event = emitter.emit_mcp_invocation(
            tool_name="test_tool",
            params_hash="abc123",
            decision="ALLOW",
            latency_ms=5.0,
            correlation_id=None,
        )
        emitter.end_correlation()
        assert event.correlation_id == chain_id

    def test_after_end_correlation_no_linkage(self, emitter):
        """After end_correlation(), events must have no correlation ID."""
        emitter.start_correlation()
        emitter.end_correlation()
        event = emitter.emit_mcp_invocation(
            tool_name="test_tool",
            params_hash="abc123",
            decision="ALLOW",
            latency_ms=5.0,
        )
        assert event.correlation_id is None

    def test_active_chain_does_not_bleed_into_default_invocation(self, emitter):
        """Previous correlation chain must not affect events after end_correlation."""
        emitter.start_correlation()
        emitter.end_correlation()
        # After ending, no correlation should be attached by default
        event = emitter.emit_mcp_invocation(
            tool_name="test_tool",
            params_hash="def456",
            decision="DENY",
            latency_ms=2.0,
        )
        assert event.correlation_id is None
