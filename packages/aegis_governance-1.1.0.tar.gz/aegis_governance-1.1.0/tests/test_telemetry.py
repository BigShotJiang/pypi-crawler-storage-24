"""
Tests for src/telemetry/ module.

Tests cover:
- Telemetry schema
- Event emitter
- Pipeline
"""

from datetime import datetime, timedelta, timezone

import pytest

from telemetry.emitter import (
    BatchHTTPSink,
    EventType,
    TelemetryEmitter,
    TelemetryEvent,
    memory_sink,
)
from telemetry.encryption import EncryptedField
from telemetry.pipeline import (
    PipelineConfig,
    PipelineStats,
    TelemetryPipeline,
    create_default_pipeline,
    enrich_with_environment,
    enrich_with_timestamp,
    validate_required_fields,
    validate_timestamp,
)
from telemetry.schema import (
    DecisionOutcome,
    GateResults,
    GateTelemetry,
    MetricValues,
    ProposalIdentification,
    ProposalTelemetry,
    TelemetryRecord,
    ThresholdValues,
)


class TestProposalTelemetry:
    """Tests for ProposalTelemetry schema."""

    def test_validate_complete(self):
        """Test validation of complete telemetry."""
        telemetry = ProposalTelemetry(
            identification=ProposalIdentification(
                proposal_id="p1",
                proposal_version=1,
                baseline_snapshot_hash="abc123",
                submission_timestamp=datetime.now(timezone.utc).isoformat(),
            ),
            metrics=MetricValues(
                risk_baseline=1.0,
                risk_proposed=1.2,
                delta_risk_norm=0.2,
                profit_baseline=1000,
                profit_proposed=1100,
                delta_profit_norm=0.1,
                novelty_score=0.9,
                novelty_gate_output=0.95,
                complexity_static=0.3,
                complexity_dynamic=0.2,
                complexity_total=0.5,
                complexity_normalized=0.5,
                quality_total=0.8,
                quality_subscores={"clarity": 0.9, "feasibility": 0.7},
                utility_raw=5000,
                utility_variance=100,
                utility_lcb=4500,
                decision_path="INVESTMENT",
            ),
            thresholds=ThresholdValues(
                epsilon_R=0.01,
                epsilon_P=0.01,
                risk_trigger_factor=2.0,
                profit_trigger_factor=2.0,
                trigger_confidence_prob=0.95,
                novelty_N0=0.7,
                novelty_k=10,
                novelty_threshold=0.8,
                complexity_floor=0.5,
                quality_minimum=0.7,
                gamma=0.3,
                kappa=1.0,
                phi_S=500,
                phi_D=10000,
            ),
            gates=GateResults(
                risk_passed=True,
                risk_posterior=0.1,
                profit_passed=True,
                profit_posterior=0.15,
                novelty_passed=True,
                complexity_passed=True,
                quality_passed=True,
                utility_passed=True,
                all_gates_passed=True,
                override_eligible=False,
            ),
            decision=DecisionOutcome(
                decision="approved",
                decision_timestamp=datetime.now(timezone.utc).isoformat(),
                decision_actor="system",
                decision_rationale="All gates passed",
            ),
        )

        errors = telemetry.validate()
        assert len(errors) == 0
        assert telemetry.is_valid() is True

    def test_validate_missing_fields(self):
        """Test validation catches missing fields."""
        telemetry = ProposalTelemetry()  # Empty

        errors = telemetry.validate()

        assert "identification" in str(errors)
        assert "metrics" in str(errors)
        assert "thresholds" in str(errors)
        assert "gates" in str(errors)
        assert "decision" in str(errors)
        assert telemetry.is_valid() is False

    def test_gate_telemetry(self):
        """Test individual gate telemetry."""
        gate = GateTelemetry(
            gate_name="risk",
            passed=True,
            value=0.5,
            threshold=2.0,
            posterior_probability=0.1,
            confidence=0.9,
            evaluated_at=datetime.now(timezone.utc).isoformat(),
        )

        assert gate.gate_name == "risk"
        assert gate.passed is True


class TestTelemetryRecord:
    """Tests for TelemetryRecord."""

    def test_to_dict(self):
        """Test serialization to dict."""
        record = TelemetryRecord(
            record_id="rec-1",
            record_type="proposal",
            timestamp=datetime.now(timezone.utc),
            source="test",
            payload=ProposalTelemetry(),
        )

        data = record.to_dict()

        assert data["record_id"] == "rec-1"
        assert data["record_type"] == "proposal"
        assert "payload" in data


class TestTelemetryEmitter:
    """Tests for TelemetryEmitter."""

    def test_init_basic(self):
        """Test basic initialization."""
        emitter = TelemetryEmitter(source="test")

        assert emitter.source == "test"
        assert emitter.event_count == 0

    def test_emit_event(self):
        """Test event emission."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit(
            EventType.PROPOSAL_SUBMITTED,
            payload={"proposal_id": "p1"},
        )

        assert isinstance(event, TelemetryEvent)
        assert event.event_type == EventType.PROPOSAL_SUBMITTED
        assert len(events) == 1
        assert emitter.event_count == 1

    def test_emit_proposal_submitted(self):
        """Test proposal submitted convenience method."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_proposal_submitted(
            proposal_id="p1",
            author_id="alice",
            summary="Test proposal",
        )

        assert event.payload["proposal_id"] == "p1"
        assert event.payload["author_id"] == "alice"

    def test_emit_gate_evaluated(self):
        """Test gate evaluated convenience method."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_gate_evaluated(
            proposal_id="p1",
            gate_name="risk",
            passed=True,
            value=0.5,
            threshold=2.0,
        )

        assert event.event_type == EventType.GATE_PASSED
        assert event.payload["gate_name"] == "risk"

    def test_emit_gate_failed(self):
        """Test gate failed event."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_gate_evaluated(
            proposal_id="p1",
            gate_name="risk",
            passed=False,
            value=3.0,
            threshold=2.0,
        )

        assert event.event_type == EventType.GATE_FAILED

    def test_emit_drift_event(self):
        """Test drift event emission."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_drift_event(
            drift_status="warning",
            kl_divergence=0.35,
            threshold=0.3,
            action="alert_and_continue",
        )

        assert event.event_type == EventType.DRIFT_WARNING

    def test_correlation_chain(self):
        """Test correlation chain management."""
        emitter = TelemetryEmitter(source="test")

        correlation_id = emitter.start_correlation()
        assert correlation_id is not None

        event1 = emitter.emit(EventType.PROPOSAL_SUBMITTED, {})
        event2 = emitter.emit(EventType.GATE_EVALUATED, {})

        assert event1.correlation_id == correlation_id
        assert event2.correlation_id == correlation_id
        assert event2.parent_event_id == event1.event_id

        emitter.end_correlation()
        assert emitter.default_correlation_id is None

    def test_multiple_sinks(self):
        """Test multiple sink handling."""
        emitter = TelemetryEmitter(source="test")
        events1 = []
        events2 = []
        emitter.add_sink(memory_sink(events1))
        emitter.add_sink(memory_sink(events2))

        emitter.emit(EventType.PROPOSAL_SUBMITTED, {})

        assert len(events1) == 1
        assert len(events2) == 1

    def test_remove_sink(self):
        """Test sink removal."""
        emitter = TelemetryEmitter(source="test")
        events = []
        sink = memory_sink(events)
        emitter.add_sink(sink)

        emitter.emit(EventType.PROPOSAL_SUBMITTED, {})
        assert len(events) == 1

        emitter.remove_sink(sink)
        emitter.emit(EventType.PROPOSAL_SUBMITTED, {})
        assert len(events) == 1  # No new events


class TestPipelineConfigValidation:
    """Tests for PipelineConfig validation."""

    def test_buffer_size_zero_raises(self):
        """Regression: buffer_size=0 caused infinite loop in ingest().

        With maxlen=0, deque always reports full, causing the while-True
        flush loop to spin forever. Now PipelineConfig rejects buffer_size < 1.
        """
        with pytest.raises(ValueError, match="buffer_size must be >= 1"):
            PipelineConfig(buffer_size=0)

    def test_buffer_size_negative_raises(self):
        """Negative buffer_size must be rejected."""
        with pytest.raises(ValueError, match="buffer_size must be >= 1"):
            PipelineConfig(buffer_size=-1)


class TestTelemetryPipeline:
    """Tests for TelemetryPipeline."""

    def test_init_defaults(self):
        """Test default initialization."""
        pipeline = TelemetryPipeline()

        assert pipeline.config.buffer_size == 1000
        assert pipeline.config.flush_interval_seconds == 60

    def test_init_custom_config(self):
        """Test custom configuration."""
        config = PipelineConfig(
            buffer_size=500,
            flush_threshold=50,
        )
        pipeline = TelemetryPipeline(config)

        assert pipeline.config.buffer_size == 500
        assert pipeline.config.flush_threshold == 50

    def test_ingest_event(self):
        """Test event ingestion."""
        pipeline = TelemetryPipeline()
        pipeline.add_validator(validate_required_fields)

        event = {
            "event_id": "e1",
            "event_type": "test",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "test",
        }

        result = pipeline.ingest(event)

        assert result is True
        stats = pipeline.get_stats()
        assert stats.events_received == 1
        assert stats.buffer_size == 1

    def test_ingest_invalid_event(self):
        """Test invalid event handling with strict mode."""
        config = PipelineConfig(strict_validation=True, drop_invalid=True)
        pipeline = TelemetryPipeline(config)
        pipeline.add_validator(validate_required_fields)

        event = {"incomplete": True}  # Missing required fields

        result = pipeline.ingest(event)

        assert result is False
        assert pipeline.stats.events_dropped == 1

    def test_flush(self):
        """Test buffer flush."""
        pipeline = TelemetryPipeline()
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        for i in range(5):
            pipeline.ingest(
                {
                    "event_id": f"e{i}",
                    "event_type": "test",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "test",
                }
            )

        count = pipeline.flush()

        assert count == 5
        assert len(stored) == 5
        assert pipeline.stats.events_processed == 5

    def test_auto_flush_on_threshold(self):
        """Test automatic flush on threshold."""
        config = PipelineConfig(flush_threshold=3)
        pipeline = TelemetryPipeline(config)
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        for i in range(3):
            pipeline.ingest(
                {
                    "event_id": f"e{i}",
                    "event_type": "test",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "test",
                }
            )

        # Should have auto-flushed
        assert len(stored) == 3

    def test_ingest_flushes_when_buffer_full(self):
        """Test ingest flushes when buffer is full to prevent drops."""
        config = PipelineConfig(buffer_size=2, flush_threshold=100)
        pipeline = TelemetryPipeline(config)
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        for i in range(3):
            pipeline.ingest(
                {
                    "event_id": f"e{i}",
                    "event_type": "test",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "test",
                }
            )

        pipeline.flush()

        event_ids = [event["event_id"] for event in stored]
        assert event_ids == ["e0", "e1", "e2"]

    def test_encrypt_warn_path_does_not_mutate_input(self):
        """Regression: _encrypt_pii_fields 'warn' path must not mutate input event."""
        config = PipelineConfig(
            pii_encryption_on_error="warn",
        )
        pipeline = TelemetryPipeline(config)
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        # Add a broken encryptor that always raises
        def bad_enricher(event):
            raise RuntimeError("encryption broken")

        pipeline.pii_enricher = bad_enricher

        original_event = {
            "event_id": "e1",
            "event_type": "test",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "test",
            "actor_id": "user@example.com",
        }
        original_keys = set(original_event.keys())

        pipeline.ingest(original_event)
        pipeline.flush()

        # Original event must NOT have _pii_encryption_failed key
        assert "_pii_encryption_failed" not in original_event
        assert set(original_event.keys()) == original_keys

    def test_enrichment(self):
        """Test event enrichment."""
        pipeline = TelemetryPipeline()
        pipeline.add_enricher(enrich_with_timestamp)
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )
        pipeline.flush()

        assert "processed_at" in stored[0]

    def test_aggregation_stage(self):
        """Test aggregation stage is executed during flush."""
        pipeline = TelemetryPipeline()
        aggregated = []

        def aggregator(events):
            aggregated.extend(events)

        pipeline.add_aggregator(aggregator)

        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )

        pipeline.flush()

        assert len(aggregated) == 1
        assert aggregated[0]["event_id"] == "e1"

    def test_get_stats(self):
        """Test stats retrieval."""
        pipeline = TelemetryPipeline()

        for i in range(3):
            pipeline.ingest(
                {
                    "event_id": f"e{i}",
                    "event_type": "test",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "test",
                }
            )

        stats = pipeline.get_stats()

        assert isinstance(stats, PipelineStats)
        assert stats.events_received == 3
        assert stats.buffer_size == 3

    def test_reset_stats(self):
        """Test stats reset."""
        pipeline = TelemetryPipeline()
        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )

        pipeline.reset_stats()
        stats = pipeline.get_stats()

        assert stats.events_received == 0


class TestValidators:
    """Tests for built-in validators."""

    def test_validate_required_fields_pass(self):
        """Test required fields validation pass."""
        event = {
            "event_id": "e1",
            "event_type": "test",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "test",
        }

        assert validate_required_fields(event) is True

    def test_validate_required_fields_fail(self):
        """Test required fields validation fail."""
        event = {"event_id": "e1"}  # Missing fields

        assert validate_required_fields(event) is False

    def test_validate_timestamp_valid(self):
        """Test timestamp validation with valid timestamp."""
        event = {"timestamp": datetime.now(timezone.utc).isoformat()}

        assert validate_timestamp(event) is True

    def test_validate_timestamp_future(self):
        """Test timestamp validation rejects far future."""

        future = datetime.now(timezone.utc) + timedelta(hours=1)
        event = {"timestamp": future.isoformat()}

        assert validate_timestamp(event) is False


class TestCreateDefaultPipeline:
    """Tests for create_default_pipeline factory."""

    def test_create_development_pipeline(self):
        """Test development pipeline creation."""
        pipeline = create_default_pipeline("development")

        assert len(pipeline.validators) == 2
        assert len(pipeline.enrichers) == 2
        assert len(pipeline.storage_handlers) == 1  # Console sink

    def test_create_production_pipeline(self):
        """Test production pipeline has no console sink."""
        pipeline = create_default_pipeline("production")

        assert len(pipeline.storage_handlers) == 0


class TestTelemetryEventSerialization:
    """Tests for TelemetryEvent serialization."""

    def test_to_json(self):
        """Test TelemetryEvent to_json method."""
        from telemetry.emitter import TelemetryEvent

        event = TelemetryEvent(
            event_id="e123",
            event_type=EventType.PROPOSAL_SUBMITTED,
            timestamp=datetime(2024, 1, 15, 12, 0, 0),
            source="test",
            payload={"proposal_id": "p1"},
            correlation_id="corr123",
            parent_event_id="parent456",
            metadata={"env": "test"},
        )

        json_str = event.to_json()

        import json

        data = json.loads(json_str)
        assert data["event_id"] == "e123"
        assert data["event_type"] == "proposal.submitted"
        assert data["source"] == "test"
        assert data["payload"]["proposal_id"] == "p1"
        assert data["correlation_id"] == "corr123"


class TestEmitterSinks:
    """Tests for emitter sinks."""

    def test_remove_sink_not_found(self):
        """Test remove_sink returns False when sink not found."""
        emitter = TelemetryEmitter(source="test")
        events = []
        sink = memory_sink(events)

        # Don't add the sink
        result = emitter.remove_sink(sink)
        assert result is False

    def test_sink_error_handling(self):
        """Test sink error is captured in metadata."""
        emitter = TelemetryEmitter(source="test")

        def failing_sink(event):
            raise ValueError("Sink failed!")

        emitter.add_sink(failing_sink)

        event = emitter.emit(EventType.PROPOSAL_SUBMITTED, {"test": True})

        assert "sink_errors" in event.metadata
        assert "Sink failed!" in event.metadata["sink_errors"][0]

    def test_console_sink(self, capsys):
        """Test console_sink prints events."""
        from telemetry.emitter import TelemetryEvent, console_sink

        event = TelemetryEvent(
            event_id="e1",
            event_type=EventType.PROPOSAL_SUBMITTED,
            timestamp=datetime.now(timezone.utc),
            source="test",
            payload={"proposal_id": "p1"},
        )

        console_sink(event)

        captured = capsys.readouterr()
        assert "proposal.submitted" in captured.out
        assert "proposal_id" in captured.out

    def test_file_sink(self, tmp_path):
        """Test file_sink writes events to file."""
        from telemetry.emitter import TelemetryEvent, file_sink

        filepath = tmp_path / "events.jsonl"
        sink = file_sink(str(filepath))

        event = TelemetryEvent(
            event_id="e1",
            event_type=EventType.PROPOSAL_SUBMITTED,
            timestamp=datetime.now(timezone.utc),
            source="test",
            payload={"proposal_id": "p1"},
        )

        sink(event)

        content = filepath.read_text()
        assert "proposal.submitted" in content
        assert "proposal_id" in content


class TestEmitterProposalDecision:
    """Tests for emit_proposal_decision."""

    def test_emit_proposal_rejected(self):
        """Test proposal rejected event emission."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_proposal_decision(
            proposal_id="p1",
            decision="rejected",
            rationale="Does not meet quality bar",
            actor_id="approver-1",
        )

        assert event.event_type == EventType.PROPOSAL_REJECTED
        assert event.payload["decision"] == "rejected"

    def test_emit_proposal_approved(self):
        """Test proposal approved via emit_proposal_decision."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_proposal_decision(
            proposal_id="p1",
            decision="approved",
            rationale="All gates passed",
            actor_id="approver-1",
        )

        assert event.event_type == EventType.PROPOSAL_APPROVED


class TestEmitterDriftEvents:
    """Tests for drift event emission."""

    def test_emit_drift_critical(self):
        """Test critical drift event."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_drift_event(
            drift_status="critical",
            kl_divergence=0.8,
            threshold=0.5,
            action="halt_and_recalibrate",
        )

        assert event.event_type == EventType.DRIFT_CRITICAL

    def test_emit_drift_detected(self):
        """Test detected drift event (normal)."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit_drift_event(
            drift_status="normal",
            kl_divergence=0.1,
            threshold=0.3,
            action="continue",
        )

        assert event.event_type == EventType.DRIFT_DETECTED


class TestTelemetryEmitterAdvanced:
    """Advanced tests for TelemetryEmitter."""

    def test_emit_proposal_approved(self):
        """Test proposal approved event emission."""
        emitter = TelemetryEmitter(source="test")
        events = []
        emitter.add_sink(memory_sink(events))

        event = emitter.emit(
            EventType.PROPOSAL_APPROVED,
            payload={"proposal_id": "p1"},
        )

        assert event.event_type == EventType.PROPOSAL_APPROVED
        assert len(events) == 1

    def test_get_event_count(self):
        """Test event count tracking."""
        emitter = TelemetryEmitter(source="test")

        emitter.emit(EventType.PROPOSAL_SUBMITTED, {})
        emitter.emit(EventType.GATE_PASSED, {})
        emitter.emit(EventType.PROPOSAL_APPROVED, {})

        assert emitter.event_count == 3


class TestPipelineStartStop:
    """Tests for pipeline start/stop threading functionality."""

    def test_start_stop_basic(self):
        """Test starting and stopping the pipeline."""
        import time

        pipeline = TelemetryPipeline()
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        pipeline.start()
        assert pipeline.running is True
        assert pipeline.worker_thread is not None

        # Give thread time to start
        time.sleep(0.1)

        pipeline.stop()
        assert pipeline.running is False

    def test_start_already_running(self):
        """Test start when already running is no-op."""

        pipeline = TelemetryPipeline()
        pipeline.start()

        thread1 = pipeline.worker_thread
        pipeline.start()  # Should be no-op
        thread2 = pipeline.worker_thread

        assert thread1 is thread2  # Same thread

        pipeline.stop()

    def test_stop_flushes_buffer(self):
        """Test stop flushes remaining buffer."""
        import time

        config = PipelineConfig(flush_threshold=100)  # High threshold
        pipeline = TelemetryPipeline(config)
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        pipeline.start()
        time.sleep(0.05)

        # Ingest without triggering auto-flush
        for i in range(5):
            pipeline.ingest(
                {
                    "event_id": f"e{i}",
                    "event_type": "test",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "test",
                }
            )

        assert len(stored) == 0  # Not flushed yet

        pipeline.stop()  # Should flush
        assert len(stored) == 5


class TestValidationBreakCase:
    """Tests for validation break case (invalid but not dropped)."""

    def test_invalid_not_dropped_continues(self):
        """Test invalid event is added but marked when not dropped."""
        config = PipelineConfig(strict_validation=True, drop_invalid=False)
        pipeline = TelemetryPipeline(config)
        pipeline.add_validator(validate_required_fields)

        event = {"incomplete": True}  # Missing required fields

        result = pipeline.ingest(event)

        assert result is True  # Still accepted
        stats = pipeline.get_stats()
        assert stats.events_invalid == 1
        assert stats.events_dropped == 0
        assert stats.buffer_size == 1


class TestPipelineHelperFunctions:
    """Tests for pipeline helper functions."""

    def test_memory_storage_handler(self):
        """Test memory_storage factory function."""
        from telemetry.pipeline import memory_storage

        storage = []
        handler = memory_storage(storage)

        events = [{"event_id": "1"}, {"event_id": "2"}]
        handler(events)

        assert len(storage) == 2
        assert storage[0]["event_id"] == "1"

    def test_console_storage(self, capsys):
        """Test console_storage prints events."""
        from telemetry.pipeline import console_storage

        events = [
            {"event_type": "test", "event_id": "e1"},
            {"event_type": "proposal", "event_id": "e2"},
        ]

        console_storage(events)

        captured = capsys.readouterr()
        assert "[STORED] test: e1" in captured.out
        assert "[STORED] proposal: e2" in captured.out

    def test_enrich_with_environment(self):
        """Test enrich_with_environment factory."""
        from telemetry.pipeline import enrich_with_environment

        enricher = enrich_with_environment("production")
        event = {"event_id": "e1"}

        enriched = enricher(event)

        assert enriched["environment"] == "production"


class TestTimestampValidation:
    """Additional timestamp validation tests."""

    def test_validate_timestamp_datetime_object(self):
        """Test timestamp validation with datetime object."""
        event = {"timestamp": datetime.now(timezone.utc)}
        assert validate_timestamp(event) is True

    def test_validate_timestamp_missing(self):
        """Test timestamp validation with missing timestamp."""
        event = {}
        assert validate_timestamp(event) is False

    def test_validate_timestamp_invalid_format(self):
        """Test timestamp validation with invalid format."""
        event = {"timestamp": "not-a-timestamp"}
        assert validate_timestamp(event) is False

    def test_validate_timestamp_iso_format(self):
        """Test timestamp validation with ISO format (no Z suffix)."""

        # Use a recent past timestamp - ISO format without timezone
        past = datetime.now(timezone.utc) - timedelta(hours=1)
        event = {"timestamp": past.isoformat()}
        assert validate_timestamp(event) is True


class TestTelemetryPipelineAdvanced:
    """Advanced tests for TelemetryPipeline."""

    def test_multiple_storage_handlers(self):
        """Test multiple storage handlers."""
        pipeline = TelemetryPipeline()
        storage1 = []
        storage2 = []
        pipeline.add_storage_handler(lambda events: storage1.extend(events))
        pipeline.add_storage_handler(lambda events: storage2.extend(events))

        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )
        pipeline.flush()

        assert len(storage1) == 1
        assert len(storage2) == 1

    def test_multiple_enrichers(self):
        """Test multiple enrichers."""
        pipeline = TelemetryPipeline()
        pipeline.add_enricher(enrich_with_timestamp)
        pipeline.add_enricher(lambda e: e.update({"custom_field": "value"}) or e)
        stored = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )
        pipeline.flush()

        assert "processed_at" in stored[0]

    def test_storage_handler_error(self):
        """Test storage handler error handling."""
        pipeline = TelemetryPipeline()

        def failing_handler(events):
            raise ValueError("Storage failed")

        pipeline.add_storage_handler(failing_handler)

        # Ingest and flush - should not crash
        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )
        pipeline.flush()

        # Check that error was recorded
        assert len(pipeline.stats.errors) > 0
        assert "Storage error" in pipeline.stats.errors[0]

    def test_analyzer_error_handling(self):
        """Test analyzer error handling."""
        pipeline = TelemetryPipeline()

        def failing_analyzer(events):
            raise RuntimeError("Analysis failed")

        pipeline.add_analyzer(failing_analyzer)

        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )
        pipeline.flush()

        # Check error was recorded
        assert any("Analysis error" in err for err in pipeline.stats.errors)


# =============================================================================
# Minor Bug Fixes v3.23.0 Regression Tests
# =============================================================================


class TestFileSinkErrorHandling:
    """Regression tests for file_sink error handling (M5 fix)."""

    def test_file_sink_handles_write_error(self, tmp_path):
        """Test that file_sink handles write errors gracefully.

        M5 fix: Added try/except + warning for file write failures.
        """
        # TD-1: file_sink now validates at construction. Create with valid
        # dir, then remove it to trigger write-time error.
        import shutil
        import tempfile
        import warnings

        from telemetry.emitter import TelemetryEvent, file_sink

        tmpdir = tempfile.mkdtemp()
        bad_path = f"{tmpdir}/events.log"
        sink = file_sink(bad_path)
        shutil.rmtree(tmpdir)

        event = TelemetryEvent(
            event_id="test-1",
            event_type=EventType.PROPOSAL_SUBMITTED,
            timestamp=datetime.now(timezone.utc),
            source="test",
            payload={"proposal_id": "p1"},
        )

        # Should warn instead of raising
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            sink(event)

            # Should have emitted a RuntimeWarning
            assert len(w) == 1
            assert issubclass(w[0].category, RuntimeWarning)
            assert "file_sink write failed" in str(w[0].message)


class TestTelemetryEmitterThreadSafety:
    """Tests documenting TelemetryEmitter's thread-safety limitations (L10 fix)."""

    def test_emitter_docstring_mentions_thread_safety(self):
        """Test that TelemetryEmitter class docstring mentions thread-safety."""
        assert "not thread-safe" in TelemetryEmitter.__doc__.lower()
        assert "event_count" in TelemetryEmitter.__doc__


class TestSchemaValidateReportsAllErrors:
    """Regression tests for validate() reporting all errors (L9 fix)."""

    def test_validate_reports_multiple_identification_errors(self):
        """Test that validate reports all identification sub-errors.

        L9 fix: Changed elif chain to collect all errors, not just first.
        """
        telemetry = ProposalTelemetry(
            identification=ProposalIdentification(
                proposal_id="",  # Empty - error
                proposal_version=1,
                baseline_snapshot_hash="",  # Empty - error
                submission_timestamp=datetime.now(timezone.utc).isoformat(),
            ),
            # Other required fields missing too
        )

        errors = telemetry.validate()

        # Should report BOTH identification sub-errors, not just the first
        id_errors = [e for e in errors if "identification." in e]
        assert len(id_errors) >= 2  # Both proposal_id and baseline_snapshot_hash

    def test_validate_reports_all_missing_sections(self):
        """Test that validate reports all missing required sections."""
        telemetry = ProposalTelemetry()  # Completely empty

        errors = telemetry.validate()

        # Should have errors for: identification, metrics, thresholds, gates, decision
        assert len(errors) == 5
        assert "identification" in errors[0]
        assert "metrics" in errors[1]
        assert "thresholds" in errors[2]
        assert "gates" in errors[3]
        assert "decision" in errors[4]


# =============================================================================
# Pipeline Thread Safety Regression Tests (H-WF-003 fix)
# =============================================================================


class TestPipelineThreadSafety:
    """Regression tests for pipeline thread safety fixes (H-WF-003)."""

    def test_concurrent_ingest_stats_consistency(self):
        """Test that concurrent ingests produce consistent stats.

        H-WF-003 fix: Stats counters now protected by _stats_lock to ensure
        atomic increments under concurrent access.
        """
        import threading

        pipeline = TelemetryPipeline(
            PipelineConfig(flush_threshold=10000)  # High threshold to avoid auto-flush
        )

        num_threads = 10
        events_per_thread = 100
        total_expected = num_threads * events_per_thread

        def ingest_events():
            for i in range(events_per_thread):
                pipeline.ingest(
                    {
                        "event_id": f"e-{threading.current_thread().name}-{i}",
                        "event_type": "test",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "source": "test",
                    }
                )

        threads = [
            threading.Thread(target=ingest_events, name=f"thread-{i}")
            for i in range(num_threads)
        ]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        stats = pipeline.get_stats()

        # All events should be counted exactly once
        assert stats.events_received == total_expected

    def test_reset_stats_during_concurrent_ingest(self):
        """Test that reset_stats is safe during concurrent ingests.

        H-WF-003 fix: reset_stats() now uses _stats_lock to prevent
        concurrent threads from losing reference during replacement.
        """
        import threading
        import time

        pipeline = TelemetryPipeline(PipelineConfig(flush_threshold=10000))
        stop_event = threading.Event()

        def ingest_continuously():
            i = 0
            while not stop_event.is_set():
                pipeline.ingest(
                    {
                        "event_id": f"e-{i}",
                        "event_type": "test",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "source": "test",
                    }
                )
                i += 1
                time.sleep(0.001)  # Small delay to avoid overwhelming

        # Start concurrent ingest
        ingest_thread = threading.Thread(target=ingest_continuously)
        ingest_thread.start()

        # Reset stats multiple times during concurrent ingest
        for _ in range(5):
            time.sleep(0.01)
            pipeline.reset_stats()

        # Stop and verify no crash occurred
        stop_event.set()
        ingest_thread.join(timeout=1.0)

        # Should complete without exception
        stats = pipeline.get_stats()
        assert isinstance(stats, PipelineStats)

    def test_get_stats_returns_snapshot(self):
        """Test that get_stats returns a snapshot, not a mutable reference.

        H-WF-003 fix: get_stats() now returns a defensive copy to prevent
        concurrent modification of stats after retrieval.
        """
        pipeline = TelemetryPipeline()

        pipeline.ingest(
            {
                "event_id": "e1",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )

        # Get snapshot
        stats1 = pipeline.get_stats()
        received1 = stats1.events_received

        # Ingest more events
        pipeline.ingest(
            {
                "event_id": "e2",
                "event_type": "test",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "test",
            }
        )

        # Original snapshot should be unchanged
        assert stats1.events_received == received1

        # New snapshot should reflect new state
        stats2 = pipeline.get_stats()
        assert stats2.events_received == received1 + 1

    def test_concurrent_flush_and_ingest(self):
        """Test that concurrent flush and ingest operations are safe.

        H-WF-003 fix: Both operations now properly acquire locks to prevent
        data races.
        """
        import threading

        stored = []
        pipeline = TelemetryPipeline(
            PipelineConfig(flush_threshold=10)  # Low threshold for frequent flushes
        )
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        stop_event = threading.Event()

        def ingest_continuously():
            i = 0
            while not stop_event.is_set() and i < 100:
                pipeline.ingest(
                    {
                        "event_id": f"e-{i}",
                        "event_type": "test",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "source": "test",
                    }
                )
                i += 1

        def flush_periodically():
            while not stop_event.is_set():
                pipeline.flush()

        ingest_thread = threading.Thread(target=ingest_continuously)
        flush_thread = threading.Thread(target=flush_periodically)

        ingest_thread.start()
        flush_thread.start()

        ingest_thread.join(timeout=2.0)
        stop_event.set()
        flush_thread.join(timeout=1.0)

        # Final flush to capture remaining events
        pipeline.flush()

        # All events should be stored exactly once
        stats = pipeline.get_stats()
        assert stats.events_received == len(stored)

    def test_worker_thread_stop_timeout_warning(self, caplog):
        """Test that stop() logs warning when worker thread doesn't stop in time.

        H-WF-003 fix: Added timeout warning logging to stop() method.
        """
        import logging
        import time

        # Configure logging capture
        caplog.set_level(logging.WARNING, logger="telemetry.pipeline")

        pipeline = TelemetryPipeline()

        # Create a mock that makes is_alive always return True
        # to simulate a stuck thread
        pipeline.start()

        # Immediately stop - the thread should stop normally
        # We can't easily test the timeout warning without mocking,
        # so we just verify normal stop works
        time.sleep(0.05)
        pipeline.stop()

        # Worker thread should be None after stop
        assert pipeline.worker_thread is None


class TestT2EnricherImmutability:
    """Regression tests for T-2: enrichers must not mutate input dict."""

    def test_enrich_with_timestamp_does_not_mutate(self):
        """T-2 regression: enrich_with_timestamp returns new dict."""
        original = {"event_id": "e1", "data": "value"}
        original_copy = dict(original)
        result = enrich_with_timestamp(original)
        assert original == original_copy, "Input dict was mutated"
        assert "processed_at" in result
        assert "processed_at" not in original

    def test_enrich_with_environment_does_not_mutate(self):
        """T-2 regression: enrich_with_environment returns new dict."""
        enricher = enrich_with_environment("staging")
        original = {"event_id": "e2", "data": "value"}
        original_copy = dict(original)
        result = enricher(original)
        assert original == original_copy, "Input dict was mutated"
        assert result["environment"] == "staging"
        assert "environment" not in original


class TestT5SetPiiEncryptorAtomicity:
    """Regression test for T-5: set_pii_encryptor sets both fields under lock."""

    def test_set_pii_encryptor_under_lock(self):
        """T-5 regression: both _pii_encryptor and enable_pii_encryption set atomically."""
        pipeline = TelemetryPipeline()
        assert pipeline._pii_encryptor is None
        assert pipeline.config.enable_pii_encryption is False

        # Use a sentinel object as mock encryptor
        mock_encryptor = object()
        pipeline.set_pii_encryptor(mock_encryptor)  # type: ignore[arg-type]

        assert pipeline._pii_encryptor is mock_encryptor
        assert pipeline.config.enable_pii_encryption is True


class TestEncryptPiiFieldsUsesPassedEncryptor:
    """Regression: _encrypt_pii_fields must use the captured encryptor, not re-read self (BH11-M7)."""

    def test_encrypt_uses_passed_encryptor(self):
        """flush() captures pii_encryptor under lock; _encrypt_pii_fields must use it."""
        pipeline = TelemetryPipeline()

        class MockEncryptor:
            def enrich(self, event):
                return {**event, "encrypted": True}

        # Set up encryptor
        pipeline.set_pii_encryptor(MockEncryptor())  # type: ignore[arg-type]

        # Call _encrypt_pii_fields with an explicit encryptor parameter
        events = [{"actor_id": "test-actor"}]
        result = pipeline._encrypt_pii_fields(events, encryptor=MockEncryptor())
        assert result[0]["encrypted"] is True

    def test_encrypt_falls_back_to_self_when_no_encryptor_passed(self):
        """When no encryptor param is passed, fall back to self._pii_encryptor."""
        pipeline = TelemetryPipeline()

        class MockEncryptor:
            def enrich(self, event):
                return {**event, "encrypted_fallback": True}

        pipeline.set_pii_encryptor(MockEncryptor())  # type: ignore[arg-type]

        events = [{"actor_id": "test-actor"}]
        result = pipeline._encrypt_pii_fields(events)
        assert result[0]["encrypted_fallback"] is True


class TestT6MemorySinkFifoEviction:
    """Regression test for T-6: memory_sink FIFO eviction uses del instead of pop."""

    def test_fifo_eviction_preserves_newest(self):
        """T-6 regression: bounded list evicts oldest, keeps newest."""
        events: list[TelemetryEvent] = []
        sink = memory_sink(events, maxlen=3)

        emitter = TelemetryEmitter(source="test")
        emitter.add_sink(sink)

        for i in range(5):
            emitter.emit(EventType.GATE_EVALUATED, {"idx": i})

        # Should have the 3 newest events (idx=2,3,4)
        assert len(events) == 3
        assert events[0].payload["idx"] == 2
        assert events[2].payload["idx"] == 4


class TestBH15EmitterURLValidation:
    """BH15-L5: _validate_sink_url must reject URLs with no hostname."""

    def test_validate_sink_url_rejects_empty_hostname(self):
        """BH15-L5: 'https://' with no hostname must raise ValueError."""
        from telemetry.emitter import HTTPEventSink

        with pytest.raises(ValueError, match="hostname"):
            HTTPEventSink(url="https://", allow_insecure=True)

    def test_validate_sink_url_rejects_http_empty_hostname(self):
        """BH15-L5: 'http://' with no hostname must raise ValueError."""
        from telemetry.emitter import HTTPEventSink

        with pytest.raises(ValueError, match="hostname"):
            HTTPEventSink(url="http://", allow_insecure=True)


class TestEncryptedFieldParsing:
    """Security validation tests for EncryptedField.from_dict()."""

    def test_from_dict_rejects_non_base64_ciphertext(self):
        """Malformed base64 should be rejected (no permissive decode)."""
        data = {
            "_encrypted": True,
            "_algorithm": "x25519+ml-kem-768+aes-256-gcm",
            "_dek_version": "dek-v1",
            "_ciphertext": "YWJj$",
            "_plaintext_hash": "deadbeef",
            "_encrypted_at": "2026-01-01T00:00:00Z",
        }

        with pytest.raises(ValueError, match="Invalid base64 ciphertext"):
            EncryptedField.from_dict(data)


class TestBH29PipelineStopDrainResilience:
    """Regression: stop() drain must survive storage errors (BH29-M4)."""

    def test_stop_drain_continues_on_storage_error(self):
        """stop() drain must catch RuntimeError and continue to final flush."""
        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        flush_count = {"n": 0}

        def failing_storage(events):
            flush_count["n"] += 1
            raise RuntimeError("storage down")

        # Use raise mode so ingest() propagates errors
        config = PipelineConfig(
            buffer_size=1, flush_threshold=1, storage_on_error="raise"
        )
        pipeline = TelemetryPipeline(config)
        pipeline.storage_handlers = [failing_storage]
        # Do NOT call start() — avoid worker thread complexity.
        # Manually put events in queue to simulate pending items at shutdown.
        for i in range(3):
            pipeline.queue.put(
                {"event_type": f"test_{i}", "timestamp": "2026-01-01T00:00:00Z"}
            )

        # stop() should NOT raise even with storage_on_error="raise"
        # because the drain loop catches RuntimeError per BH29-M4 fix.
        pipeline.stop()

        # Storage was called multiple times: once per drained event (ingest triggers
        # flush since buffer_size=1 and flush_threshold=1), plus the final flush().
        assert flush_count["n"] >= 2


class TestBH29PipelineFlushThresholdValidation:
    """Regression: flush_threshold must be >= 1 (BH29-L5)."""

    def test_zero_flush_threshold_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="flush_threshold must be >= 1"):
            PipelineConfig(flush_threshold=0)

    def test_negative_flush_threshold_raises(self):
        from telemetry.pipeline import PipelineConfig

        with pytest.raises(ValueError, match="flush_threshold must be >= 1"):
            PipelineConfig(flush_threshold=-1)

    def test_positive_flush_threshold_accepted(self):
        from telemetry.pipeline import PipelineConfig

        config = PipelineConfig(flush_threshold=5)
        assert config.flush_threshold == 5


class TestQG71PipelineDrainBroadException:
    """Regression: drain catches all exceptions, not just RuntimeError (QG71)."""

    def test_stop_drain_catches_non_runtime_exception(self):
        """Enricher KeyError should not crash drain loop."""
        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        config = PipelineConfig(buffer_size=10, flush_threshold=10)
        pipeline = TelemetryPipeline(config)
        # Enricher that raises KeyError (not RuntimeError)
        pipeline.enrichers = [lambda e: e["nonexistent_key"]]
        for i in range(3):
            pipeline.queue.put(
                {"event_type": f"test_{i}", "timestamp": "2026-01-01T00:00:00Z"}
            )
        # stop() must NOT raise — drain catches all exceptions
        pipeline.stop()

    def test_stop_drain_catches_type_error_from_enricher(self):
        """Enricher TypeError should not crash drain loop."""
        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        config = PipelineConfig(buffer_size=10, flush_threshold=10)
        pipeline = TelemetryPipeline(config)
        pipeline.enrichers = [lambda e: len(None)]  # TypeError
        pipeline.queue.put({"event_type": "test", "timestamp": "2026-01-01T00:00:00Z"})
        pipeline.stop()


class TestBH30PipelineConfigDefensiveCopy:
    """BH30-L2: TelemetryPipeline must not mutate caller's PipelineConfig."""

    def test_shared_config_not_mutated_by_pii_encryptor(self):
        """Passing pii_encryptor must not mutate the original config object."""
        from unittest.mock import MagicMock

        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        shared_config = PipelineConfig(buffer_size=100, flush_threshold=50)
        assert shared_config.enable_pii_encryption is False

        mock_encryptor = MagicMock()
        _pipeline = TelemetryPipeline(shared_config, pii_encryptor=mock_encryptor)

        # Original config must NOT have been mutated
        assert shared_config.enable_pii_encryption is False

    def test_set_pii_encryptor_does_not_mutate_original_config(self):
        """set_pii_encryptor must not mutate the original config object."""
        from unittest.mock import MagicMock

        from telemetry.pipeline import PipelineConfig, TelemetryPipeline

        shared_config = PipelineConfig(buffer_size=100, flush_threshold=50)
        pipeline = TelemetryPipeline(shared_config)
        assert shared_config.enable_pii_encryption is False

        pipeline.set_pii_encryptor(MagicMock())

        # Pipeline's internal copy should be mutated, original should not
        assert pipeline.config.enable_pii_encryption is True
        assert shared_config.enable_pii_encryption is False


# ---------------------------------------------------------------------------
# Regression: BH35-M2 — PipelineConfig.flush_interval_seconds no validation
# ---------------------------------------------------------------------------


class TestBH35PipelineConfigFlushInterval:
    """BH35-M2: flush_interval_seconds must be validated like buffer_size."""

    def test_flush_interval_zero_raises(self):
        with pytest.raises(ValueError, match="flush_interval_seconds must be >= 1"):
            PipelineConfig(flush_interval_seconds=0)

    def test_flush_interval_negative_raises(self):
        with pytest.raises(ValueError, match="flush_interval_seconds must be >= 1"):
            PipelineConfig(flush_interval_seconds=-10)

    def test_flush_interval_bool_true_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            PipelineConfig(flush_interval_seconds=True)

    def test_flush_interval_bool_false_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            PipelineConfig(flush_interval_seconds=False)

    def test_flush_interval_valid_accepted(self):
        config = PipelineConfig(flush_interval_seconds=30)
        assert config.flush_interval_seconds == 30


# ---------------------------------------------------------------------------
# Regression: BH35-L1 — PipelineConfig buffer_size/flush_threshold bool
# ---------------------------------------------------------------------------


class TestBH35PipelineConfigBoolGuards:
    """BH35-L1: buffer_size and flush_threshold must reject bool."""

    def test_buffer_size_bool_true_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            PipelineConfig(buffer_size=True)

    def test_buffer_size_bool_false_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            PipelineConfig(buffer_size=False)

    def test_flush_threshold_bool_true_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            PipelineConfig(flush_threshold=True)

    def test_flush_threshold_bool_false_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            PipelineConfig(flush_threshold=False)


# ---------------------------------------------------------------------------
# Regression: BH37-L1 — PipelineConfig accepts float sizes and crashes later
# ---------------------------------------------------------------------------


class TestBH37PipelineConfigIntegerGuards:
    """PipelineConfig must reject non-integer numeric values for sizing fields."""

    @pytest.mark.parametrize(
        "field_name",
        ["buffer_size", "flush_threshold", "flush_interval_seconds"],
    )
    def test_float_fields_raise_type_error(self, field_name):
        kwargs = {field_name: 1.5}
        with pytest.raises(TypeError, match="must be an integer, got float"):
            PipelineConfig(**kwargs)


# ---------------------------------------------------------------------------
# Regression: BH35-M3 — BatchHTTPSink.flush_interval_seconds no validation
# ---------------------------------------------------------------------------


class TestBH35BatchHTTPSinkFlushInterval:
    """BH35-M3: BatchHTTPSink flush_interval_seconds must be validated."""

    def test_flush_interval_zero_raises(self):
        with pytest.raises(ValueError, match="flush_interval_seconds must be >= 1"):
            BatchHTTPSink(
                url="https://example.com/events",
                flush_interval_seconds=0,
            )

    def test_flush_interval_negative_raises(self):
        with pytest.raises(ValueError, match="flush_interval_seconds must be >= 1"):
            BatchHTTPSink(
                url="https://example.com/events",
                flush_interval_seconds=-5,
            )

    def test_flush_interval_bool_true_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            BatchHTTPSink(
                url="https://example.com/events",
                flush_interval_seconds=True,
            )

    def test_flush_interval_bool_false_raises(self):
        with pytest.raises(TypeError, match="must be an integer, got bool"):
            BatchHTTPSink(
                url="https://example.com/events",
                flush_interval_seconds=False,
            )


# ---------------------------------------------------------------------------
# Regression: BH35-L2 — DEKCache.ttl_seconds no validation
# ---------------------------------------------------------------------------


class TestBH35DEKCacheTTLValidation:
    """BH35-L2: DEKCache.ttl_seconds must reject zero, negative, and bool."""

    def test_ttl_zero_raises(self):
        from telemetry.encryption import DEKCache

        with pytest.raises(ValueError, match="ttl_seconds must be >= 1"):
            DEKCache(ttl_seconds=0)

    def test_ttl_negative_raises(self):
        from telemetry.encryption import DEKCache

        with pytest.raises(ValueError, match="ttl_seconds must be >= 1"):
            DEKCache(ttl_seconds=-3600)

    def test_ttl_bool_true_raises(self):
        from telemetry.encryption import DEKCache

        with pytest.raises(TypeError, match="must be an integer, got bool"):
            DEKCache(ttl_seconds=True)

    def test_ttl_bool_false_raises(self):
        from telemetry.encryption import DEKCache

        with pytest.raises(TypeError, match="must be an integer, got bool"):
            DEKCache(ttl_seconds=False)

    def test_ttl_valid_accepted(self):
        from telemetry.encryption import DEKCache

        cache = DEKCache(ttl_seconds=7200)
        assert cache._ttl.total_seconds() == 7200


# ---------------------------------------------------------------------------
# Regression: QG-U1 — BatchHTTPSink missing bool guards for batch_size,
# max_retries, timeout; missing retry_delay_seconds validation
# ---------------------------------------------------------------------------


class TestQGU1BatchHTTPSinkIntParamBoolGuards:
    """QG-U1: BatchHTTPSink int params (batch_size, max_retries, timeout) must reject bool."""

    def test_batch_size_bool_true_raises(self):
        with pytest.raises(TypeError, match="batch_size must be an integer, got bool"):
            BatchHTTPSink(url="https://example.com/events", batch_size=True)

    def test_batch_size_bool_false_raises(self):
        with pytest.raises(TypeError, match="batch_size must be an integer, got bool"):
            BatchHTTPSink(url="https://example.com/events", batch_size=False)

    def test_max_retries_bool_true_raises(self):
        with pytest.raises(TypeError, match="max_retries must be an integer, got bool"):
            BatchHTTPSink(url="https://example.com/events", max_retries=True)

    def test_max_retries_bool_false_raises(self):
        with pytest.raises(TypeError, match="max_retries must be an integer, got bool"):
            BatchHTTPSink(url="https://example.com/events", max_retries=False)

    def test_timeout_bool_true_raises(self):
        with pytest.raises(TypeError, match="timeout must be an integer, got bool"):
            BatchHTTPSink(url="https://example.com/events", timeout=True)

    def test_timeout_bool_false_raises(self):
        with pytest.raises(TypeError, match="timeout must be an integer, got bool"):
            BatchHTTPSink(url="https://example.com/events", timeout=False)

    def test_timeout_zero_raises(self):
        with pytest.raises(ValueError, match="timeout must be >= 1"):
            BatchHTTPSink(url="https://example.com/events", timeout=0)

    def test_timeout_negative_raises(self):
        with pytest.raises(ValueError, match="timeout must be >= 1"):
            BatchHTTPSink(url="https://example.com/events", timeout=-5)


class TestQGU1BatchHTTPSinkRetryDelayValidation:
    """QG-U1: BatchHTTPSink retry_delay_seconds must reject bool, NaN, Inf, negative."""

    def test_retry_delay_bool_true_raises(self):
        with pytest.raises(
            TypeError, match="retry_delay_seconds must be a number, got bool"
        ):
            BatchHTTPSink(url="https://example.com/events", retry_delay_seconds=True)

    def test_retry_delay_bool_false_raises(self):
        with pytest.raises(
            TypeError, match="retry_delay_seconds must be a number, got bool"
        ):
            BatchHTTPSink(url="https://example.com/events", retry_delay_seconds=False)

    def test_retry_delay_nan_raises(self):
        with pytest.raises(ValueError, match="retry_delay_seconds must be finite"):
            BatchHTTPSink(
                url="https://example.com/events", retry_delay_seconds=float("nan")
            )

    def test_retry_delay_inf_raises(self):
        with pytest.raises(ValueError, match="retry_delay_seconds must be finite"):
            BatchHTTPSink(
                url="https://example.com/events", retry_delay_seconds=float("inf")
            )

    def test_retry_delay_negative_raises(self):
        with pytest.raises(ValueError, match="retry_delay_seconds must be >= 0"):
            BatchHTTPSink(url="https://example.com/events", retry_delay_seconds=-1.0)

    def test_retry_delay_zero_accepted(self):
        """Zero delay is valid — means no wait between retries."""
        sink = BatchHTTPSink(url="https://example.com/events", retry_delay_seconds=0.0)
        assert sink._retry_delay == 0.0


class TestQGU1HTTPEventSinkTimeoutValidation:
    """QG-U1: HTTPEventSink timeout must reject bool, zero, negative."""

    def test_timeout_bool_true_raises(self):
        from telemetry.emitter import HTTPEventSink

        with pytest.raises(TypeError, match="timeout must be an integer, got bool"):
            HTTPEventSink(url="https://example.com/events", timeout=True)

    def test_timeout_bool_false_raises(self):
        from telemetry.emitter import HTTPEventSink

        with pytest.raises(TypeError, match="timeout must be an integer, got bool"):
            HTTPEventSink(url="https://example.com/events", timeout=False)

    def test_timeout_zero_raises(self):
        from telemetry.emitter import HTTPEventSink

        with pytest.raises(ValueError, match="timeout must be >= 1"):
            HTTPEventSink(url="https://example.com/events", timeout=0)

    def test_timeout_negative_raises(self):
        from telemetry.emitter import HTTPEventSink

        with pytest.raises(ValueError, match="timeout must be >= 1"):
            HTTPEventSink(url="https://example.com/events", timeout=-5)

    def test_timeout_valid_accepted(self):
        from telemetry.emitter import HTTPEventSink

        sink = HTTPEventSink(url="https://example.com/events", timeout=30)
        assert sink._timeout == 30
