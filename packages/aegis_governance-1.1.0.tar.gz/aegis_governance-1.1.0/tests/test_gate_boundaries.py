"""Boundary Value Analysis (BVA) tests for all quantitative gates.

Verifies pass/fail behavior at exact threshold values for every gate,
catching off-by-one comparison operator bugs (< vs <=, > vs >=).

ROADMAP Item 5: Boundary tests for all gates.

Gate comparison operators (verified by these tests):
- Risk:       posterior < 0.95          (strict <)   at=0.95 -> FAIL
- Profit:     posterior < 0.95          (strict <)   at=0.95 -> FAIL
- Novelty:    G(N) >= 0.8              (inclusive >=) at=0.8  -> PASS
- Complexity: C >= 0.5                 (inclusive >=) at=0.5  -> PASS
- Quality:    Q >= 0.7 AND !zero       (inclusive >=) at=0.7  -> PASS
- Utility:    LCB > 0.0               (strict >)    at=0.0  -> FAIL
- Drift warn: KL >= 0.3               (inclusive >=) at=0.3  -> WARNING
- Drift crit: KL >= 0.5               (inclusive >=) at=0.5  -> CRITICAL
"""

import math
from typing import Optional

import pytest

from engine.drift import DriftMonitor, DriftStatus
from engine.gates import GateEvaluator, GateType
from engine.utility import UtilityResult

# ---------------------------------------------------------------------------
# Pre-computed boundary constants
# ---------------------------------------------------------------------------

# Bayesian defaults: prior_mean=0, prior_std=1.0, likelihood_std=0.5
# posterior_precision = 1 + 4 = 5, posterior_std = sqrt(0.2) ~ 0.4472
# Posterior mean equals 0.8 times observed_delta.
# P(delta >= 2.0) = 0.95 when observed_delta = _RISK_BOUNDARY_DELTA
_RISK_BOUNDARY_DELTA = 3.419501130725143

# Novelty: G(N) = 1/(1+exp(-10*(N-0.7))) = 0.8 when N = 0.7 + ln(4)/10
_NOVELTY_BOUNDARY_N = 0.7 + math.log(4) / 10  # ~0.8386

# Small epsilon for "just above/below" boundary tests.
# Large enough to avoid platform-dependent float artefacts.
_EPS = 1e-4


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_utility(lcb: float, raw: float = 0.0) -> UtilityResult:
    """Create a minimal UtilityResult with the given LCB."""
    return UtilityResult(
        raw=raw,
        variance=0.0,
        lcb=lcb,
        components=None,
        decision_path="INVESTMENT",
    )


def _risk_proposed_for_posterior(
    target_delta_norm: float,
    baseline: float = 1.0,
    epsilon_R: float = 0.01,
) -> float:
    """Compute proposed value that produces target_delta_norm.

    delta_norm = (proposed - baseline) / max(|baseline|, epsilon_R)
    => proposed = baseline + target_delta_norm * max(|baseline|, epsilon_R)
    """
    return baseline + target_delta_norm * max(abs(baseline), epsilon_R)


# ===================================================================
# 1. Risk Gate Boundary Tests
# ===================================================================


class TestRiskGateBoundary:
    """Risk gate: P(delta >= trigger) < 0.95 to pass (strict <)."""

    @pytest.mark.parametrize(
        "delta_offset, expected_pass",
        [
            pytest.param(0.0, False, id="at-boundary-posterior-eq-0.95-FAIL"),
            pytest.param(_EPS, False, id="epsilon-above-boundary-FAIL"),
            pytest.param(-_EPS, True, id="epsilon-below-boundary-PASS"),
            pytest.param(2.0, False, id="far-above-FAIL"),
            pytest.param(-2.0, True, id="far-below-PASS"),
        ],
    )
    def test_risk_posterior_boundary(
        self, delta_offset: float, expected_pass: bool
    ) -> None:
        """At boundary delta_norm, posterior == 0.95 -> FAIL (strict <)."""
        evaluator = GateEvaluator()
        delta_norm = _RISK_BOUNDARY_DELTA + delta_offset
        proposed = _risk_proposed_for_posterior(delta_norm, baseline=1.0)
        result = evaluator.evaluate_risk_gate(baseline=1.0, proposed=proposed)
        assert result.passed is expected_pass

    @pytest.mark.parametrize(
        "baseline, proposed, expected_pass",
        [
            pytest.param(
                0.0,
                _RISK_BOUNDARY_DELTA * 0.01,
                False,
                id="zero-baseline-uses-epsilon-at-boundary",
            ),
            pytest.param(0.0, 0.0, True, id="zero-baseline-zero-proposed-PASS"),
        ],
    )
    def test_risk_baseline_zero_uses_epsilon(
        self, baseline: float, proposed: float, expected_pass: bool
    ) -> None:
        """Zero baseline normalises by epsilon_R=0.01."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_risk_gate(baseline=baseline, proposed=proposed)
        assert result.passed is expected_pass

    @pytest.mark.parametrize(
        "delta_offset, expected_pass",
        [
            pytest.param(0.0, False, id="negative-trigger-at-boundary-FAIL"),
            pytest.param(_EPS, True, id="negative-trigger-above-boundary-PASS"),
        ],
    )
    def test_risk_negative_trigger_boundary(
        self, delta_offset: float, expected_pass: bool
    ) -> None:
        """Negative trigger_factor inverts to left-tail: P(delta <= -2)."""
        evaluator = GateEvaluator(risk_trigger_factor=-2.0)
        # Symmetric: large negative delta_norm triggers the left tail
        delta_norm = -_RISK_BOUNDARY_DELTA + delta_offset
        proposed = _risk_proposed_for_posterior(delta_norm, baseline=1.0)
        result = evaluator.evaluate_risk_gate(baseline=1.0, proposed=proposed)
        assert result.passed is expected_pass


# ===================================================================
# 2. Profit Gate Boundary Tests
# ===================================================================


class TestProfitGateBoundary:
    """Profit gate: P(|delta| >= trigger) < 0.95 to pass (strict <).

    Two-tailed: posterior = P(delta >= t) + P(delta <= -t).
    """

    @pytest.mark.parametrize(
        "delta_offset, expected_pass",
        [
            pytest.param(0.0, False, id="at-boundary-posterior-eq-0.95-FAIL"),
            pytest.param(_EPS, False, id="epsilon-above-boundary-FAIL"),
            pytest.param(-_EPS, True, id="epsilon-below-boundary-PASS"),
            pytest.param(2.0, False, id="far-above-FAIL"),
            pytest.param(-2.0, True, id="far-below-PASS"),
        ],
    )
    def test_profit_posterior_boundary(
        self, delta_offset: float, expected_pass: bool
    ) -> None:
        """At boundary delta_norm, upper-tail posterior ~ 0.95."""
        evaluator = GateEvaluator()
        delta_norm = _RISK_BOUNDARY_DELTA + delta_offset
        proposed = _risk_proposed_for_posterior(
            delta_norm, baseline=1.0, epsilon_R=0.01
        )
        result = evaluator.evaluate_profit_gate(baseline=1.0, proposed=proposed)
        assert result.passed is expected_pass

    def test_profit_symmetry(self) -> None:
        """Positive and negative deltas of equal magnitude produce similar posteriors."""
        evaluator = GateEvaluator()
        result_pos = evaluator.evaluate_profit_gate(baseline=1.0, proposed=3.0)
        result_neg = evaluator.evaluate_profit_gate(baseline=1.0, proposed=-1.0)
        assert result_pos.posterior_probability == pytest.approx(
            result_neg.posterior_probability, abs=0.01
        )

    def test_profit_zero_delta_passes(self) -> None:
        """Zero delta trivially passes (no change detected)."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_profit_gate(baseline=1.0, proposed=1.0)
        assert result.passed is True

    def test_profit_negative_direction_boundary(self) -> None:
        """Large decrease also triggers the two-tailed profit gate."""
        evaluator = GateEvaluator()
        delta_norm = _RISK_BOUNDARY_DELTA
        # Large negative delta
        proposed = _risk_proposed_for_posterior(-delta_norm, baseline=1.0)
        result = evaluator.evaluate_profit_gate(baseline=1.0, proposed=proposed)
        assert result.passed is False


# ===================================================================
# 3. Novelty Gate Boundary Tests
# ===================================================================


class TestNoveltyGateBoundary:
    """Novelty gate: G(N) >= 0.8 to pass (inclusive >=)."""

    @pytest.mark.parametrize(
        "n_offset, expected_pass",
        [
            pytest.param(0.0, True, id="at-boundary-G-eq-0.8-PASS"),
            pytest.param(_EPS, True, id="epsilon-above-PASS"),
            pytest.param(-_EPS, False, id="epsilon-below-FAIL"),
            pytest.param(0.1, True, id="far-above-PASS"),
            pytest.param(-0.1, False, id="far-below-FAIL"),
        ],
    )
    def test_novelty_threshold_boundary(
        self, n_offset: float, expected_pass: bool
    ) -> None:
        """At N=_NOVELTY_BOUNDARY_N, G(N)=0.8 exactly -> PASS (inclusive >=)."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_novelty_gate(_NOVELTY_BOUNDARY_N + n_offset)
        assert result.passed is expected_pass

    def test_novelty_at_midpoint(self) -> None:
        """At N=N0=0.7, G(N)=0.5 -> FAIL (well below 0.8)."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_novelty_gate(0.7)
        assert result.value == pytest.approx(0.5, abs=1e-9)
        assert result.passed is False

    def test_novelty_custom_threshold_boundary(self) -> None:
        """Custom threshold=0.5: at midpoint G=0.5 -> PASS (inclusive >=)."""
        evaluator = GateEvaluator(novelty_threshold=0.5)
        result = evaluator.evaluate_novelty_gate(0.7)  # G(0.7) = 0.5 exactly
        assert result.value == pytest.approx(0.5, abs=1e-9)
        assert result.passed is True


# ===================================================================
# 4. Complexity Gate Boundary Tests
# ===================================================================


class TestComplexityGateBoundary:
    """Complexity gate: C_norm >= 0.5 to pass (inclusive >=)."""

    @pytest.mark.parametrize(
        "score, expected_pass",
        [
            pytest.param(0.5, True, id="at-floor-PASS"),
            pytest.param(0.5 + _EPS, True, id="epsilon-above-PASS"),
            pytest.param(0.5 - _EPS, False, id="epsilon-below-FAIL"),
            pytest.param(1.0, True, id="far-above-PASS"),
            pytest.param(0.0, False, id="far-below-FAIL"),
        ],
    )
    def test_complexity_floor_boundary(self, score: float, expected_pass: bool) -> None:
        """At score=0.5, passes (inclusive >=)."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_complexity_gate(score)
        assert result.passed is expected_pass

    def test_complexity_confidence_binary(self) -> None:
        """Confidence is 1.0 on pass, 0.0 on fail."""
        evaluator = GateEvaluator()
        assert evaluator.evaluate_complexity_gate(0.5).confidence == 1.0
        assert evaluator.evaluate_complexity_gate(0.499).confidence == 0.0

    def test_complexity_custom_floor_boundary(self) -> None:
        """Custom floor=0.3: at 0.3 -> PASS, at 0.2999 -> FAIL."""
        evaluator = GateEvaluator(complexity_floor=0.3)
        assert evaluator.evaluate_complexity_gate(0.3).passed is True
        assert evaluator.evaluate_complexity_gate(0.3 - _EPS).passed is False


# ===================================================================
# 5. Quality Gate Boundary Tests
# ===================================================================


class TestQualityGateBoundary:
    """Quality gate: Q >= 0.7 AND no zero sub-scores (inclusive >=)."""

    @pytest.mark.parametrize(
        "score, expected_pass",
        [
            pytest.param(0.7, True, id="at-threshold-PASS"),
            pytest.param(0.7 + _EPS, True, id="epsilon-above-PASS"),
            pytest.param(0.7 - _EPS, False, id="epsilon-below-FAIL"),
            pytest.param(1.0, True, id="far-above-PASS"),
            pytest.param(0.0, False, id="far-below-FAIL"),
        ],
    )
    def test_quality_score_boundary(self, score: float, expected_pass: bool) -> None:
        """Score at/near 0.7 with valid subscores."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_quality_gate(score, [0.8, 0.9])
        assert result.passed is expected_pass

    @pytest.mark.parametrize(
        "subscore, expected_pass",
        [
            pytest.param(0.0, False, id="exactly-zero-FAIL"),
            pytest.param(_EPS, True, id="epsilon-above-zero-PASS"),
            pytest.param(-0.0, False, id="negative-zero-FAIL"),
            pytest.param(0.01, True, id="small-positive-PASS"),
        ],
    )
    def test_quality_zero_subscore_boundary(
        self, subscore: float, expected_pass: bool
    ) -> None:
        """Zero subscore boundary: min_subscore <= 0.0 -> has_zero=True.

        Note: -0.0 <= 0.0 is True in Python, so -0.0 triggers has_zero.
        The evaluate_all() validator rejects negative subscores, but the
        individual evaluate_quality_gate() does not hard-reject them.
        """
        evaluator = GateEvaluator()
        result = evaluator.evaluate_quality_gate(0.8, [0.8, subscore])
        assert result.passed is expected_pass

    def test_quality_empty_subscores(self) -> None:
        """Empty subscores -> min defaults to 0.0 -> FAIL (fail-safe)."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_quality_gate(0.9, [])
        assert result.passed is False

    def test_quality_combined_boundary(self) -> None:
        """Both score at threshold AND subscore at minimum -> PASS."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_quality_gate(0.7, [_EPS])
        assert result.passed is True

    def test_quality_combined_boundary_both_marginal_fail(self) -> None:
        """Score at threshold but zero subscore -> FAIL."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_quality_gate(0.7, [0.0])
        assert result.passed is False

    def test_quality_no_zero_flag_false(self) -> None:
        """With quality_no_zero_subscore=False, zero subscores are allowed."""
        evaluator = GateEvaluator(quality_no_zero_subscore=False)
        result = evaluator.evaluate_quality_gate(0.8, [0.0, 0.9])
        assert result.passed is True

    def test_quality_no_zero_flag_false_still_checks_score(self) -> None:
        """Flag=False still enforces quality_min_score."""
        evaluator = GateEvaluator(quality_no_zero_subscore=False)
        result = evaluator.evaluate_quality_gate(0.6, [0.0, 0.9])
        assert result.passed is False


# ===================================================================
# 6. Utility Gate Boundary Tests
# ===================================================================


class TestUtilityGateBoundary:
    """Utility gate: LCB > theta to pass (strict >)."""

    @pytest.mark.parametrize(
        "lcb, expected_pass",
        [
            pytest.param(0.0, False, id="at-threshold-LCB-eq-0-FAIL"),
            pytest.param(_EPS, True, id="epsilon-above-PASS"),
            pytest.param(-_EPS, False, id="epsilon-below-FAIL"),
            pytest.param(100.0, True, id="far-above-PASS"),
            pytest.param(-100.0, False, id="far-below-FAIL"),
        ],
    )
    def test_utility_lcb_boundary(self, lcb: float, expected_pass: bool) -> None:
        """At LCB=0.0, FAIL (strict >)."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_utility_gate(_make_utility(lcb))
        assert result.passed is expected_pass

    @pytest.mark.parametrize(
        "lcb, expected_pass",
        [
            pytest.param(5.0, False, id="at-custom-threshold-FAIL"),
            pytest.param(5.0 + _EPS, True, id="epsilon-above-custom-PASS"),
            pytest.param(5.0 - _EPS, False, id="epsilon-below-custom-FAIL"),
        ],
    )
    def test_utility_custom_threshold_boundary(
        self, lcb: float, expected_pass: bool
    ) -> None:
        """Custom utility_threshold=5.0."""
        evaluator = GateEvaluator(utility_threshold=5.0)
        result = evaluator.evaluate_utility_gate(_make_utility(lcb))
        assert result.passed is expected_pass

    def test_utility_confidence_at_boundary(self) -> None:
        """At LCB exactly at threshold, margin=0 -> confidence ~ 0.5."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_utility_gate(_make_utility(0.0))
        assert result.confidence == pytest.approx(0.5, abs=1e-6)


# ===================================================================
# 7. Drift Monitor Boundary Tests
# ===================================================================


class TestDriftMonitorBoundary:
    """Drift monitor: KL >= tau_critical -> CRITICAL (inclusive >=).
    KL >= tau_warning -> WARNING (inclusive >=).
    """

    def test_drift_critical_boundary_at(self) -> None:
        """KL exactly at tau_critical -> CRITICAL (inclusive >=)."""
        # Build distributions with known KL, then set tau to match
        baseline = [0.0] * 500 + [1.0] * 500
        current = [0.5] * 500 + [1.5] * 500  # shifted
        monitor = DriftMonitor(tau_warning=0.001, tau_critical=10.0)
        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)
        kl = result.kl_divergence

        # Now set tau_critical to exactly the computed KL
        monitor2 = DriftMonitor(tau_warning=kl / 2, tau_critical=kl)
        monitor2.set_baseline(baseline)
        result2 = monitor2.evaluate(current)
        assert result2.status == DriftStatus.CRITICAL

    def test_drift_critical_boundary_epsilon_above(self) -> None:
        """KL just below tau_critical -> WARNING (not CRITICAL)."""
        baseline = [0.0] * 500 + [1.0] * 500
        current = [0.5] * 500 + [1.5] * 500
        monitor = DriftMonitor(tau_warning=0.001, tau_critical=10.0)
        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)
        kl = result.kl_divergence

        # tau_critical slightly above KL -> should NOT be CRITICAL
        monitor2 = DriftMonitor(tau_warning=kl / 2, tau_critical=kl + _EPS)
        monitor2.set_baseline(baseline)
        result2 = monitor2.evaluate(current)
        assert result2.status == DriftStatus.WARNING

    def test_drift_critical_boundary_epsilon_below(self) -> None:
        """KL just above tau_critical -> CRITICAL."""
        baseline = [0.0] * 500 + [1.0] * 500
        current = [0.5] * 500 + [1.5] * 500
        monitor = DriftMonitor(tau_warning=0.001, tau_critical=10.0)
        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)
        kl = result.kl_divergence

        monitor2 = DriftMonitor(tau_warning=kl / 2, tau_critical=kl - _EPS)
        monitor2.set_baseline(baseline)
        result2 = monitor2.evaluate(current)
        assert result2.status == DriftStatus.CRITICAL

    def test_drift_warning_boundary_at(self) -> None:
        """KL exactly at tau_warning -> WARNING (inclusive >=)."""
        baseline = [0.0] * 500 + [1.0] * 500
        current = [0.1] * 500 + [1.1] * 500  # small shift
        monitor = DriftMonitor(tau_warning=0.001, tau_critical=10.0)
        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)
        kl = result.kl_divergence

        monitor2 = DriftMonitor(tau_warning=kl, tau_critical=kl + 1.0)
        monitor2.set_baseline(baseline)
        result2 = monitor2.evaluate(current)
        assert result2.status == DriftStatus.WARNING

    def test_drift_warning_boundary_epsilon_above(self) -> None:
        """KL just below tau_warning -> NORMAL."""
        baseline = [0.0] * 500 + [1.0] * 500
        current = [0.1] * 500 + [1.1] * 500
        monitor = DriftMonitor(tau_warning=0.001, tau_critical=10.0)
        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)
        kl = result.kl_divergence

        monitor2 = DriftMonitor(tau_warning=kl + _EPS, tau_critical=kl + 1.0)
        monitor2.set_baseline(baseline)
        result2 = monitor2.evaluate(current)
        assert result2.status == DriftStatus.NORMAL

    def test_drift_warning_boundary_epsilon_below(self) -> None:
        """KL just above tau_warning -> WARNING."""
        baseline = [0.0] * 500 + [1.0] * 500
        current = [0.1] * 500 + [1.1] * 500
        monitor = DriftMonitor(tau_warning=0.001, tau_critical=10.0)
        monitor.set_baseline(baseline)
        result = monitor.evaluate(current)
        kl = result.kl_divergence

        monitor2 = DriftMonitor(tau_warning=kl - _EPS, tau_critical=kl + 1.0)
        monitor2.set_baseline(baseline)
        result2 = monitor2.evaluate(current)
        assert result2.status == DriftStatus.WARNING

    def test_drift_identical_distributions(self) -> None:
        """Identical distributions -> KL ~= 0 -> NORMAL."""
        data = list(range(100))
        monitor = DriftMonitor()
        monitor.set_baseline(data)
        result = monitor.evaluate(data)
        assert result.status == DriftStatus.NORMAL
        assert result.kl_divergence == pytest.approx(0.0, abs=1e-6)

    def test_drift_threshold_ordering_boundary(self) -> None:
        """tau_warning == tau_critical -> ValueError."""
        with pytest.raises(ValueError, match="must be less than"):
            DriftMonitor(tau_warning=0.5, tau_critical=0.5)

    def test_drift_status_transitions(self) -> None:
        """Sweep from NORMAL -> WARNING -> CRITICAL as shift increases."""
        baseline = [float(x) for x in range(200)]
        monitor = DriftMonitor(tau_warning=0.01, tau_critical=0.1)
        monitor.set_baseline(baseline)

        # No shift -> NORMAL
        result0 = monitor.evaluate(baseline)
        assert result0.status == DriftStatus.NORMAL

        # Moderate shift -> at least WARNING
        shifted_moderate = [x + 20.0 for x in baseline]
        result1 = monitor.evaluate(shifted_moderate)
        assert result1.status in (DriftStatus.WARNING, DriftStatus.CRITICAL)

        # Large shift -> CRITICAL
        shifted_large = [x + 200.0 for x in baseline]
        result2 = monitor.evaluate(shifted_large)
        assert result2.status == DriftStatus.CRITICAL


# ===================================================================
# 8. Multi-Gate Boundary Integration Tests
# ===================================================================


class TestMultiGateBoundaryIntegration:
    """Integration tests: evaluate_all() at exact boundary combinations."""

    def _all_gates_inputs(
        self,
        risk_delta: float = 0.0,
        profit_delta: float = 0.0,
        novelty: float = 1.0,
        complexity: float = 0.8,
        quality: float = 0.9,
        subscores: Optional[list[float]] = None,
        lcb: float = 1.0,
    ) -> dict:
        """Build default evaluate_all kwargs with overridable values."""
        return {
            "risk_baseline": 1.0,
            "risk_proposed": 1.0 + risk_delta,
            "profit_baseline": 1.0,
            "profit_proposed": 1.0 + profit_delta,
            "novelty_score": novelty,
            "complexity_score": complexity,
            "quality_score": quality,
            "quality_subscores": subscores if subscores is not None else [0.8, 0.9],
            "utility_result": _make_utility(lcb),
        }

    def test_all_gates_at_boundary_all_pass(self) -> None:
        """Every gate at its inclusive/just-passing boundary -> all_passed=True."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_all(
            **self._all_gates_inputs(
                novelty=_NOVELTY_BOUNDARY_N,  # G(N) = 0.8 exactly -> PASS
                complexity=0.5,  # == floor -> PASS
                quality=0.7,  # == min_score -> PASS
                subscores=[_EPS],  # > 0 -> no zero -> PASS
                lcb=_EPS,  # > 0.0 -> PASS (strict >)
            )
        )
        assert result.all_passed is True

    def test_one_gate_fails_at_boundary(self) -> None:
        """Utility at exact threshold (0.0) -> FAIL, others pass."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_all(
            **self._all_gates_inputs(
                novelty=_NOVELTY_BOUNDARY_N,
                complexity=0.5,
                quality=0.7,
                subscores=[0.5],
                lcb=0.0,  # == threshold -> FAIL (strict >)
            )
        )
        assert result.all_passed is False
        assert result.gates[GateType.UTILITY].passed is False

    def test_override_eligible_complexity_at_floor(self) -> None:
        """Complexity == floor -> passes; other gates fail -> override_eligible=True."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_all(
            **self._all_gates_inputs(
                complexity=0.5,  # at floor -> PASS
                lcb=0.0,  # FAIL
            )
        )
        assert result.override_eligible is True
        assert result.gates[GateType.COMPLEXITY].passed is True

    def test_override_ineligible_complexity_below_floor(self) -> None:
        """Complexity just below floor -> fails -> override_eligible=False."""
        evaluator = GateEvaluator()
        result = evaluator.evaluate_all(
            **self._all_gates_inputs(
                complexity=0.5 - _EPS,  # below floor -> FAIL
                lcb=0.0,  # also FAIL
            )
        )
        assert result.override_eligible is False
        assert result.gates[GateType.COMPLEXITY].passed is False


# ===================================================================
# 9. Constructor Validation Boundary Tests
# ===================================================================


class TestConstructorValidationBoundary:
    """GateEvaluator constructor validation at parameter boundaries."""

    @pytest.mark.parametrize(
        "epsilon_R, should_raise",
        [
            pytest.param(1e-10, False, id="tiny-positive-accepted"),
            pytest.param(0.01, False, id="default-accepted"),
            pytest.param(0.0, True, id="zero-rejected"),
            pytest.param(-0.01, True, id="negative-rejected"),
            pytest.param(-1e-10, True, id="tiny-negative-rejected"),
        ],
    )
    def test_epsilon_boundary(self, epsilon_R: float, should_raise: bool) -> None:
        """Epsilon must be strictly positive (> 0)."""
        if should_raise:
            with pytest.raises(ValueError, match="epsilon_R must be positive"):
                GateEvaluator(epsilon_R=epsilon_R)
        else:
            evaluator = GateEvaluator(epsilon_R=epsilon_R)
            assert evaluator.epsilon_R == epsilon_R

    @pytest.mark.parametrize(
        "factor, should_raise, should_warn",
        [
            pytest.param(10.0, False, False, id="at-upper-bound-OK"),
            pytest.param(10.1, False, True, id="above-upper-warn"),
            pytest.param(-10.0, False, False, id="at-lower-bound-OK"),
            pytest.param(-10.1, False, True, id="below-lower-warn"),
            pytest.param(0.0, True, False, id="zero-rejected"),
        ],
    )
    def test_trigger_factor_boundary(
        self,
        factor: float,
        should_raise: bool,
        should_warn: bool,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        """Trigger factor: zero rejected, outside [-10,10] warns."""
        if should_raise:
            with pytest.raises(ValueError, match="must be non-zero"):
                GateEvaluator(risk_trigger_factor=factor)
        else:
            with caplog.at_level("WARNING"):
                evaluator = GateEvaluator(risk_trigger_factor=factor)
            assert evaluator.risk_trigger_factor == factor
            if should_warn:
                assert "outside recommended range" in caplog.text
