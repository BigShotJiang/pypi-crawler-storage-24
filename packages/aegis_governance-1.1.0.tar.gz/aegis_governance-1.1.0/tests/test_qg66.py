"""Regression tests for Quality-Gate #66 Ultrathink findings.

QG66-M1: pcw_decide _evaluate_drift_policy returns defensive copy on ValueError
QG66-L1: governance.emergency_halt captures timestamp inside lock
QG66-M2: drift.calibrate_thresholds rejects bool percentile args
QG66-M3: schema_signer.sign_tools_list rejects duplicate tool names
"""

import math
import threading
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest


class TestQG66M1DefensiveCopyDriftValueError:
    """_evaluate_drift_policy must return list(constraints) on ValueError path."""

    def test_valueerror_path_returns_copy(self):
        """When drift_monitor.evaluate raises ValueError, returned constraints
        must be a NEW list (defensive copy), not the same object."""
        from integration.pcw_decide import _evaluate_drift_policy

        drift_monitor = MagicMock()
        drift_monitor.evaluate.side_effect = ValueError("baseline not set")

        original_constraints = ["existing_constraint"]
        _status, returned_constraints, drift_result = _evaluate_drift_policy(
            drift_monitor=drift_monitor,
            context=MagicMock(
                risk_proposed=0.5,
                risk_baseline=0.4,
                profit_proposed=1.0,
                profit_baseline=0.9,
            ),
            current_status="PROCEED",
            constraints=original_constraints,
            telemetry_emitter=None,
            decision_id="test-decision-1",
        )

        # Must be equal in content
        assert returned_constraints == original_constraints
        # Must NOT be the same object (defensive copy)
        assert returned_constraints is not original_constraints
        assert drift_result is None

    def test_valueerror_path_mutation_isolation(self):
        """Mutating the returned constraints must not affect the original."""
        from integration.pcw_decide import _evaluate_drift_policy

        drift_monitor = MagicMock()
        drift_monitor.evaluate.side_effect = ValueError("baseline not set")

        original_constraints = ["c1", "c2"]
        _, returned_constraints, _ = _evaluate_drift_policy(
            drift_monitor=drift_monitor,
            context=MagicMock(
                risk_proposed=0.5,
                risk_baseline=0.4,
                profit_proposed=1.0,
                profit_baseline=0.9,
            ),
            current_status="PROCEED",
            constraints=original_constraints,
            telemetry_emitter=None,
            decision_id="test-decision-2",
        )

        returned_constraints.append("c3")
        assert len(original_constraints) == 2  # Original unchanged


class TestQG66L1GovernanceHaltTimestamp:
    """emergency_halt must capture timestamp inside the lock."""

    def test_halt_timestamp_is_before_return(self):
        """The halted_at timestamp must be captured during halt, not after."""
        from actors.governance import Governance

        actor = Governance(actor_id="gov-1", name="Gov Test")
        before = datetime.now(timezone.utc)
        result = actor.emergency_halt("test reason")
        after = datetime.now(timezone.utc)

        assert result.result_data is not None
        halted_at = datetime.fromisoformat(result.result_data["halted_at"])
        assert before <= halted_at <= after

    def test_halt_timestamp_under_contention(self):
        """Under contention, halted_at should still be temporally close to
        the actual state change, not delayed by lock wait."""
        from actors.governance import Governance

        actor = Governance(actor_id="gov-1", name="Gov Test")

        timestamps = []
        barrier = threading.Barrier(2)

        def halt_with_timing():
            barrier.wait()
            result = actor.emergency_halt("concurrent halt")
            if result.result_data is not None and "halted_at" in result.result_data:
                ts = datetime.fromisoformat(result.result_data["halted_at"])
                timestamps.append(ts)

        t1 = threading.Thread(target=halt_with_timing)
        t2 = threading.Thread(target=halt_with_timing)
        t1.start()
        t2.start()
        t1.join(timeout=5)
        t2.join(timeout=5)

        # Both should have timestamps (one succeeds, one fails due to
        # already halted — but our actor doesn't check that, so both succeed)
        assert len(timestamps) >= 1


class TestQG66M2CalibrateThresholdsBoolGuard:
    """calibrate_thresholds must reject bool percentile arguments."""

    def test_warning_percentile_true_rejected(self):
        from engine.drift import DriftMonitor

        dm = DriftMonitor()
        with pytest.raises(
            TypeError, match="warning_percentile must be numeric, got bool"
        ):
            dm.calibrate_thresholds(
                [0.1, 0.2, 0.3], warning_percentile=True, critical_percentile=95
            )

    def test_warning_percentile_false_rejected(self):
        from engine.drift import DriftMonitor

        dm = DriftMonitor()
        with pytest.raises(
            TypeError, match="warning_percentile must be numeric, got bool"
        ):
            dm.calibrate_thresholds(
                [0.1, 0.2, 0.3], warning_percentile=False, critical_percentile=95
            )

    def test_critical_percentile_true_rejected(self):
        from engine.drift import DriftMonitor

        dm = DriftMonitor()
        with pytest.raises(
            TypeError, match="critical_percentile must be numeric, got bool"
        ):
            dm.calibrate_thresholds(
                [0.1, 0.2, 0.3], warning_percentile=75, critical_percentile=True
            )

    def test_critical_percentile_false_rejected(self):
        from engine.drift import DriftMonitor

        dm = DriftMonitor()
        with pytest.raises(
            TypeError, match="critical_percentile must be numeric, got bool"
        ):
            dm.calibrate_thresholds(
                [0.1, 0.2, 0.3], warning_percentile=75, critical_percentile=False
            )

    def test_valid_numeric_percentiles_still_work(self):
        """Non-bool numeric percentiles must still be accepted."""
        from engine.drift import DriftMonitor

        dm = DriftMonitor()
        result = dm.calibrate_thresholds(
            [0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0],
            warning_percentile=75,
            critical_percentile=95,
        )
        assert len(result) == 2
        assert all(math.isfinite(v) for v in result)


class TestQG66M3SchemaSignerDuplicateToolNames:
    """sign_tools_list must reject duplicate tool names."""

    def test_duplicate_names_raises_valueerror(self):
        from crypto.schema_signer import ToolSchemaSigner

        signer = ToolSchemaSigner()
        tools = [
            {"name": "evaluate", "description": "First", "inputSchema": {}},
            {"name": "evaluate", "description": "Second", "inputSchema": {}},
        ]
        with pytest.raises(ValueError, match="Duplicate tool names detected"):
            signer.sign_tools_list(tools)

    def test_multiple_duplicates_all_reported(self):
        from crypto.schema_signer import ToolSchemaSigner

        signer = ToolSchemaSigner()
        tools = [
            {"name": "a", "description": "1", "inputSchema": {}},
            {"name": "b", "description": "2", "inputSchema": {}},
            {"name": "a", "description": "3", "inputSchema": {}},
            {"name": "b", "description": "4", "inputSchema": {}},
        ]
        with pytest.raises(
            ValueError, match="Duplicate tool names detected"
        ) as exc_info:
            signer.sign_tools_list(tools)
        # Both duplicated names should be mentioned
        assert "a" in str(exc_info.value)
        assert "b" in str(exc_info.value)

    def test_unique_names_accepted(self):
        """Non-duplicate tool names must still work."""
        from crypto.schema_signer import ToolSchemaSigner

        signer = ToolSchemaSigner()
        tools = [
            {
                "name": "evaluate",
                "description": "First",
                "inputSchema": {"type": "object"},
            },
            {
                "name": "risk_check",
                "description": "Second",
                "inputSchema": {"type": "object"},
            },
        ]
        result = signer.sign_tools_list(tools)
        assert "toolProofs" in result
        assert len(result["toolProofs"]) == 2

    def test_single_tool_accepted(self):
        """Single tool (no possibility of duplicates) must work."""
        from crypto.schema_signer import ToolSchemaSigner

        signer = ToolSchemaSigner()
        tools = [
            {"name": "evaluate", "description": "Only tool", "inputSchema": {}},
        ]
        result = signer.sign_tools_list(tools)
        assert len(result["toolProofs"]) == 1
