"""Tests for aegis_get_scoring_guide MCP tool and scoring_guide module."""

from __future__ import annotations

import json
from typing import Any

from aegis_governance.scoring_guide import (
    VALID_DOMAINS,
    get_scoring_guide,
)

# ── Unit tests for scoring_guide module ──────────────────────────────


class TestGetScoringGuide:
    """Test the get_scoring_guide() function directly."""

    def test_generic_returned_for_none_domain(self) -> None:
        result = get_scoring_guide(None)
        assert result["domain"] == "generic"

    def test_generic_returned_for_unknown_domain(self) -> None:
        result = get_scoring_guide("unknown_domain_xyz")
        assert result["domain"] == "generic"

    def test_all_valid_domains_return_guide(self) -> None:
        for domain in VALID_DOMAINS:
            result = get_scoring_guide(domain)
            assert result["domain"] == domain
            assert "parameters" in result
            assert "common_mistakes" in result
            assert "worked_example" in result

    def test_trading_guide_has_var_derivation(self) -> None:
        result = get_scoring_guide("trading")
        risk = result["parameters"]["risk_baseline"]
        assert "VaR" in risk["derivation"] or "Value-at-Risk" in risk["derivation"]

    def test_cicd_guide_has_error_rate_derivation(self) -> None:
        result = get_scoring_guide("cicd")
        risk = result["parameters"]["risk_baseline"]
        assert "error" in risk["derivation"].lower()

    def test_moderation_guide_has_fpr_derivation(self) -> None:
        result = get_scoring_guide("moderation")
        risk = result["parameters"]["risk_baseline"]
        assert "false positive" in risk["derivation"].lower()

    def test_agents_guide_has_failure_rate_derivation(self) -> None:
        result = get_scoring_guide("agents")
        risk = result["parameters"]["risk_baseline"]
        assert "failure" in risk["derivation"].lower()

    def test_all_guides_have_required_parameter_keys(self) -> None:
        required_params = {
            "risk_baseline",
            "risk_proposed",
            "profit_baseline",
            "profit_proposed",
            "novelty_score",
            "complexity_score",
            "quality_score",
            "quality_subscores",
            "estimated_impact",
        }
        for domain in VALID_DOMAINS:
            result = get_scoring_guide(domain)
            actual_params = set(result["parameters"].keys())
            assert required_params.issubset(
                actual_params
            ), f"Domain '{domain}' missing params: {required_params - actual_params}"

    def test_all_guides_have_worked_example_with_input(self) -> None:
        for domain in VALID_DOMAINS:
            result = get_scoring_guide(domain)
            example = result["worked_example"]
            assert (
                "input" in example
            ), f"Domain '{domain}' worked_example missing 'input'"
            assert "proposal_summary" in example["input"]

    def test_all_guides_have_common_mistakes(self) -> None:
        for domain in VALID_DOMAINS:
            result = get_scoring_guide(domain)
            assert isinstance(result["common_mistakes"], list)
            assert len(result["common_mistakes"]) > 0

    def test_complexity_inversion_warning_in_all_guides(self) -> None:
        """All domains should warn about complexity_score inversion."""
        for domain in VALID_DOMAINS:
            result = get_scoring_guide(domain)
            mistakes = " ".join(result["common_mistakes"]).lower()
            assert (
                "complexity" in mistakes
            ), f"Domain '{domain}' missing complexity warning in common_mistakes"

    def test_novelty_pass_direction_warning_in_all_guides(self) -> None:
        """All domains should warn about novelty gate pass direction."""
        for domain in VALID_DOMAINS:
            result = get_scoring_guide(domain)
            mistakes = " ".join(result["common_mistakes"]).lower()
            assert (
                "novelty" in mistakes
            ), f"Domain '{domain}' missing novelty warning in common_mistakes"

    def test_deep_copy_isolation(self) -> None:
        """Mutating returned guide must not affect subsequent calls."""
        result1 = get_scoring_guide("trading")
        result1["domain"] = "CORRUPTED"
        result1["parameters"]["risk_baseline"]["derivation"] = "CORRUPTED"
        # Second call should return fresh, uncorrupted data
        result2 = get_scoring_guide("trading")
        assert result2["domain"] == "trading"
        assert "CORRUPTED" not in result2["parameters"]["risk_baseline"]["derivation"]


# ── MCP tool function integration tests ─────────────────────────────


def _call_tool(domain: str | None = None) -> Any:
    """Helper to call the MCP tool function and parse the JSON result."""
    from aegis_governance.mcp_server import aegis_get_scoring_guide

    result_str = aegis_get_scoring_guide(domain)
    return json.loads(result_str)


class TestMCPScoringGuideTool:
    """Test the aegis_get_scoring_guide tool function."""

    def test_call_with_trading_domain(self) -> None:
        result = _call_tool("trading")
        assert result["domain"] == "trading"
        assert "parameters" in result
        assert "Value-at-Risk" in result["parameters"]["risk_baseline"]["derivation"]

    def test_call_with_cicd_domain(self) -> None:
        result = _call_tool("cicd")
        assert result["domain"] == "cicd"

    def test_call_with_moderation_domain(self) -> None:
        result = _call_tool("moderation")
        assert result["domain"] == "moderation"

    def test_call_with_agents_domain(self) -> None:
        result = _call_tool("agents")
        assert result["domain"] == "agents"

    def test_call_with_generic_domain(self) -> None:
        result = _call_tool("generic")
        assert result["domain"] == "generic"

    def test_call_with_no_domain(self) -> None:
        result = _call_tool(None)
        assert result["domain"] == "generic"

    def test_call_with_invalid_domain(self) -> None:
        result = _call_tool("invalid")
        assert result["domain"] == "generic"

    def test_result_is_json_serializable(self) -> None:
        """The result must survive JSON round-trip (no custom objects)."""
        for domain in VALID_DOMAINS:
            result = _call_tool(domain)
            roundtrip = json.loads(json.dumps(result))
            assert roundtrip["domain"] == domain
