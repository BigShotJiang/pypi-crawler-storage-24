"""Tests for aegis_governance.mapper — DomainMapper protocol and GateInputs.

Covers:
- GateInputs construction, validation, and defaults
- GateInputs.__post_init__ rejection of NaN, Inf, bool, wrong types
- GateInputs.to_pcw_context() round-trip with string and enum phases
- DomainMapper protocol structural subtyping (isinstance checks)
- PassthroughMapper pass-through behavior and defaults
- Edge cases: empty dicts, extra keys, boundary values
"""

import pytest

from aegis_governance.mapper import (
    _FINITE_FLOAT_FIELDS,
    DomainMapper,
    GateInputs,
    PassthroughMapper,
)

# -- GateInputs: construction and defaults --


class TestGateInputsDefaults:
    """GateInputs should have sensible defaults for all fields."""

    def test_default_construction(self):
        inputs = GateInputs()
        assert inputs.risk_baseline == 0.0
        assert inputs.risk_proposed == 0.0
        assert inputs.profit_baseline == 0.0
        assert inputs.profit_proposed == 0.0
        assert inputs.novelty_score == 0.5
        assert inputs.complexity_score == 0.5
        assert inputs.quality_score == 0.7
        assert inputs.quality_subscores == [0.7, 0.7, 0.7]
        assert inputs.proposal_summary == ""
        assert inputs.estimated_impact == "medium"

    def test_explicit_construction(self):
        inputs = GateInputs(
            risk_baseline=0.1,
            risk_proposed=0.3,
            profit_baseline=1.0,
            profit_proposed=1.5,
            novelty_score=0.8,
            complexity_score=0.9,
            quality_score=0.95,
            quality_subscores=[0.9, 0.95, 1.0],
            proposal_summary="Deploy new strategy",
            estimated_impact="high",
        )
        assert inputs.risk_baseline == 0.1
        assert inputs.risk_proposed == 0.3
        assert inputs.profit_baseline == 1.0
        assert inputs.profit_proposed == 1.5
        assert inputs.novelty_score == 0.8
        assert inputs.complexity_score == 0.9
        assert inputs.quality_score == 0.95
        assert inputs.quality_subscores == [0.9, 0.95, 1.0]
        assert inputs.proposal_summary == "Deploy new strategy"
        assert inputs.estimated_impact == "high"

    def test_integer_values_accepted(self):
        """Ints should be accepted for numeric fields."""
        inputs = GateInputs(risk_baseline=1, profit_proposed=2)
        assert inputs.risk_baseline == 1.0
        assert inputs.profit_proposed == 2.0

    def test_zero_values_accepted(self):
        """Zero is a valid finite float."""
        inputs = GateInputs(
            risk_baseline=0,
            risk_proposed=0,
            profit_baseline=0,
            profit_proposed=0,
            novelty_score=0,
            complexity_score=0,
            quality_score=0,
        )
        assert inputs.risk_baseline == 0.0

    def test_negative_values_accepted(self):
        """Negative floats are valid (some domains use them for profit delta)."""
        inputs = GateInputs(profit_proposed=-0.5)
        assert inputs.profit_proposed == -0.5


# -- GateInputs: validation (fail-closed) --


class TestGateInputsValidation:
    """__post_init__ should reject invalid inputs immediately."""

    @pytest.mark.parametrize("field_name", _FINITE_FLOAT_FIELDS)
    def test_nan_rejected(self, field_name):
        with pytest.raises(ValueError, match="must be finite"):
            GateInputs(**{field_name: float("nan")})

    @pytest.mark.parametrize("field_name", _FINITE_FLOAT_FIELDS)
    def test_positive_inf_rejected(self, field_name):
        with pytest.raises(ValueError, match="must be finite"):
            GateInputs(**{field_name: float("inf")})

    @pytest.mark.parametrize("field_name", _FINITE_FLOAT_FIELDS)
    def test_negative_inf_rejected(self, field_name):
        with pytest.raises(ValueError, match="must be finite"):
            GateInputs(**{field_name: float("-inf")})

    @pytest.mark.parametrize("field_name", _FINITE_FLOAT_FIELDS)
    def test_bool_rejected_for_numeric(self, field_name):
        with pytest.raises(TypeError, match="must be numeric, got bool"):
            GateInputs(**{field_name: True})

    @pytest.mark.parametrize("field_name", _FINITE_FLOAT_FIELDS)
    def test_string_rejected_for_numeric(self, field_name):
        with pytest.raises(TypeError, match="must be numeric"):
            GateInputs(**{field_name: "not_a_number"})

    def test_quality_subscores_nan_rejected(self):
        with pytest.raises(ValueError, match=r"quality_subscores.*must be finite"):
            GateInputs(quality_subscores=[0.7, float("nan"), 0.8])

    def test_quality_subscores_inf_rejected(self):
        with pytest.raises(ValueError, match=r"quality_subscores.*must be finite"):
            GateInputs(quality_subscores=[float("inf")])

    def test_quality_subscores_bool_rejected(self):
        with pytest.raises(
            TypeError, match=r"quality_subscores.*must be numeric, got bool"
        ):
            GateInputs(quality_subscores=[True, 0.7])

    def test_quality_subscores_string_rejected(self):
        with pytest.raises(TypeError, match=r"quality_subscores.*must be numeric"):
            GateInputs(quality_subscores=["bad"])

    def test_quality_subscores_not_list_rejected(self):
        with pytest.raises(TypeError, match="quality_subscores must be a list"):
            GateInputs(quality_subscores=(0.7, 0.8))  # type: ignore[arg-type]

    def test_estimated_impact_invalid_rejected(self):
        with pytest.raises(ValueError, match="estimated_impact must be one of"):
            GateInputs(estimated_impact="extreme")

    def test_estimated_impact_normalized_to_lowercase(self):
        inputs = GateInputs(estimated_impact="HIGH")
        assert inputs.estimated_impact == "high"

    def test_estimated_impact_mixed_case(self):
        inputs = GateInputs(estimated_impact="Critical")
        assert inputs.estimated_impact == "critical"

    def test_estimated_impact_non_string_rejected(self):
        with pytest.raises(TypeError, match="estimated_impact must be a string"):
            GateInputs(estimated_impact=42)  # type: ignore[arg-type]

    def test_proposal_summary_non_string_rejected(self):
        with pytest.raises(TypeError, match="proposal_summary must be a string"):
            GateInputs(proposal_summary=123)  # type: ignore[arg-type]

    def test_all_valid_impacts_accepted(self):
        for impact in ("low", "medium", "high", "critical"):
            inputs = GateInputs(estimated_impact=impact)
            assert inputs.estimated_impact == impact

    def test_empty_quality_subscores_accepted(self):
        inputs = GateInputs(quality_subscores=[])
        assert inputs.quality_subscores == []


# -- GateInputs: to_pcw_context --


class TestGateInputsToPcwContext:
    """to_pcw_context() should produce a valid PCWContext."""

    def test_basic_round_trip(self):
        inputs = GateInputs(
            risk_baseline=0.09,
            risk_proposed=0.156,
            profit_baseline=1.2,
            profit_proposed=1.8,
            novelty_score=0.65,
            complexity_score=0.9,
            quality_score=0.85,
            quality_subscores=[0.85, 0.9, 0.8],
            proposal_summary="Deploy mean-reversion strategy",
            estimated_impact="medium",
        )
        ctx = inputs.to_pcw_context(
            agent_id="quant-desk",
            session_id="session-1",
            phase="plan",
        )
        assert ctx.agent_id == "quant-desk"
        assert ctx.session_id == "session-1"
        assert ctx.risk_baseline == 0.09
        assert ctx.risk_proposed == 0.156
        assert ctx.profit_baseline == 1.2
        assert ctx.profit_proposed == 1.8
        assert ctx.novelty_score == 0.65
        assert ctx.complexity_score == 0.9
        assert ctx.quality_score == 0.85
        assert ctx.quality_subscores == [0.85, 0.9, 0.8]
        assert ctx.proposal_summary == "Deploy mean-reversion strategy"
        assert ctx.estimated_impact == "medium"

    def test_string_phase_plan(self):
        from integration.pcw_decide import PCWPhase

        ctx = GateInputs().to_pcw_context("a", "s", phase="plan")
        assert ctx.phase == PCWPhase.PLAN

    def test_string_phase_commit(self):
        from integration.pcw_decide import PCWPhase

        ctx = GateInputs().to_pcw_context("a", "s", phase="commit")
        assert ctx.phase == PCWPhase.COMMIT

    def test_string_phase_work(self):
        from integration.pcw_decide import PCWPhase

        ctx = GateInputs().to_pcw_context("a", "s", phase="work")
        assert ctx.phase == PCWPhase.WORK

    def test_string_phase_case_insensitive(self):
        from integration.pcw_decide import PCWPhase

        ctx = GateInputs().to_pcw_context("a", "s", phase="PLAN")
        assert ctx.phase == PCWPhase.PLAN

    def test_enum_phase_accepted(self):
        from integration.pcw_decide import PCWPhase

        ctx = GateInputs().to_pcw_context("a", "s", phase=PCWPhase.COMMIT)
        assert ctx.phase == PCWPhase.COMMIT

    def test_invalid_phase_rejected(self):
        with pytest.raises(ValueError, match="Unknown phase"):
            GateInputs().to_pcw_context("a", "s", phase="invalid")

    def test_optional_flags(self):
        ctx = GateInputs().to_pcw_context(
            "a",
            "s",
            requires_human_approval=True,
            time_sensitive=True,
            reversible=False,
        )
        assert ctx.requires_human_approval is True
        assert ctx.time_sensitive is True
        assert ctx.reversible is False

    def test_metadata_forwarded(self):
        meta = {"source": "test", "version": 3}
        ctx = GateInputs().to_pcw_context("a", "s", metadata=meta)
        assert ctx.metadata == {"source": "test", "version": 3}

    def test_metadata_default_empty(self):
        ctx = GateInputs().to_pcw_context("a", "s")
        assert ctx.metadata == {}

    def test_quality_subscores_defensive_copy(self):
        """to_pcw_context should not share the same list object."""
        inputs = GateInputs(quality_subscores=[0.8, 0.9])
        ctx = inputs.to_pcw_context("a", "s")
        ctx.quality_subscores.append(0.5)
        assert len(inputs.quality_subscores) == 2  # original unmodified


# ---------------------------------------------------------------------------
# DomainMapper: protocol / structural subtyping
# ---------------------------------------------------------------------------


class TestDomainMapperProtocol:
    """DomainMapper is a runtime-checkable Protocol."""

    def test_passthrough_is_domain_mapper(self):
        mapper = PassthroughMapper()
        assert isinstance(mapper, DomainMapper)

    def test_custom_class_satisfies_protocol(self):
        """A class with matching signatures satisfies the protocol."""

        class CustomMapper:
            @property
            def domain_name(self) -> str:
                return "custom"

            def map_to_gate_inputs(self, domain_data: dict) -> GateInputs:
                return GateInputs(risk_proposed=domain_data.get("risk", 0.0))

        mapper = CustomMapper()
        assert isinstance(mapper, DomainMapper)

    def test_incomplete_class_not_domain_mapper(self):
        """A class missing map_to_gate_inputs should not match."""

        class IncompleteMapper:
            @property
            def domain_name(self) -> str:
                return "incomplete"

        obj = IncompleteMapper()
        assert not isinstance(obj, DomainMapper)

    def test_missing_domain_name_not_domain_mapper(self):
        """A class missing the domain_name property should not match."""

        class NoDomainName:
            def map_to_gate_inputs(self, domain_data: dict) -> GateInputs:
                return GateInputs()

        obj = NoDomainName()
        assert not isinstance(obj, DomainMapper)


# ---------------------------------------------------------------------------
# PassthroughMapper
# ---------------------------------------------------------------------------


class TestPassthroughMapper:
    """PassthroughMapper passes raw AEGIS parameter names through."""

    def test_domain_name(self):
        mapper = PassthroughMapper()
        assert mapper.domain_name == "passthrough"

    def test_empty_dict_uses_defaults(self):
        mapper = PassthroughMapper()
        inputs = mapper.map_to_gate_inputs({})
        assert inputs.risk_baseline == 0.0
        assert inputs.risk_proposed == 0.0
        assert inputs.quality_score == 0.7
        assert inputs.estimated_impact == "medium"

    def test_full_passthrough(self):
        mapper = PassthroughMapper()
        data = {
            "risk_baseline": 0.1,
            "risk_proposed": 0.3,
            "profit_baseline": 1.0,
            "profit_proposed": 1.5,
            "novelty_score": 0.8,
            "complexity_score": 0.9,
            "quality_score": 0.95,
            "quality_subscores": [0.9, 0.95, 1.0],
            "proposal_summary": "Test proposal",
            "estimated_impact": "high",
        }
        inputs = mapper.map_to_gate_inputs(data)
        assert inputs.risk_baseline == 0.1
        assert inputs.risk_proposed == 0.3
        assert inputs.profit_baseline == 1.0
        assert inputs.profit_proposed == 1.5
        assert inputs.novelty_score == 0.8
        assert inputs.complexity_score == 0.9
        assert inputs.quality_score == 0.95
        assert inputs.quality_subscores == [0.9, 0.95, 1.0]
        assert inputs.proposal_summary == "Test proposal"
        assert inputs.estimated_impact == "high"

    def test_extra_keys_ignored(self):
        mapper = PassthroughMapper()
        inputs = mapper.map_to_gate_inputs(
            {
                "risk_baseline": 0.1,
                "unknown_field": "should be ignored",
                "another_unknown": 42,
            }
        )
        assert inputs.risk_baseline == 0.1
        assert inputs.risk_proposed == 0.0  # default

    def test_partial_keys(self):
        mapper = PassthroughMapper()
        inputs = mapper.map_to_gate_inputs(
            {
                "risk_proposed": 0.5,
                "estimated_impact": "critical",
            }
        )
        assert inputs.risk_proposed == 0.5
        assert inputs.estimated_impact == "critical"
        assert inputs.risk_baseline == 0.0  # default

    def test_invalid_value_raises(self):
        mapper = PassthroughMapper()
        with pytest.raises(ValueError, match="must be finite"):
            mapper.map_to_gate_inputs({"risk_baseline": float("nan")})

    def test_quality_subscores_defensive_copy(self):
        """PassthroughMapper should copy the list, not alias it."""
        mapper = PassthroughMapper()
        original = [0.8, 0.9]
        inputs = mapper.map_to_gate_inputs({"quality_subscores": original})
        inputs.quality_subscores.append(0.5)
        assert len(original) == 2  # original unmodified


# ---------------------------------------------------------------------------
# Integration: GateInputs -> pcw_decide round-trip
# ---------------------------------------------------------------------------


class TestGateInputsPcwDecideIntegration:
    """GateInputs should integrate with pcw_decide end-to-end."""

    def test_gate_inputs_through_pcw_decide(self):
        """Full round-trip: GateInputs -> PCWContext -> pcw_decide."""
        from integration.pcw_decide import pcw_decide

        inputs = GateInputs(
            risk_baseline=0.09,
            risk_proposed=0.156,
            profit_baseline=1.2,
            profit_proposed=1.8,
            novelty_score=0.65,
            complexity_score=0.9,
            quality_score=0.85,
            quality_subscores=[0.85, 0.9, 0.8],
            proposal_summary="Deploy mean-reversion strategy on ES futures",
            estimated_impact="medium",
        )
        ctx = inputs.to_pcw_context(
            agent_id="test-agent",
            session_id="test-session",
            phase="plan",
        )
        decision = pcw_decide(ctx)
        # The decision should have a valid status (any PCWStatus value)
        assert decision.status is not None
        assert decision.decision_id is not None
        assert decision.gates_passed + decision.gates_failed > 0

    def test_passthrough_mapper_through_pcw_decide(self):
        """PassthroughMapper -> GateInputs -> PCWContext -> pcw_decide."""
        from integration.pcw_decide import pcw_decide

        mapper = PassthroughMapper()
        inputs = mapper.map_to_gate_inputs(
            {
                "risk_baseline": 0.02,
                "risk_proposed": 0.08,
                "profit_baseline": 0.24,
                "profit_proposed": 0.28,
                "novelty_score": 0.6,
                "complexity_score": 0.85,
                "quality_score": 0.96,
                "quality_subscores": [0.98, 1.0, 0.9],
                "proposal_summary": "Schema migration",
                "estimated_impact": "high",
            }
        )
        ctx = inputs.to_pcw_context(
            agent_id="deploy-bot",
            session_id="deploy-session",
            phase="plan",
        )
        decision = pcw_decide(ctx)
        assert decision.status is not None


# ---------------------------------------------------------------------------
# Facade imports
# ---------------------------------------------------------------------------


class TestFacadeImports:
    """Verify mapper symbols are importable from aegis_governance."""

    def test_import_domain_mapper(self):
        from aegis_governance import DomainMapper

        assert DomainMapper is not None

    def test_import_gate_inputs(self):
        from aegis_governance import GateInputs

        assert GateInputs is not None

    def test_import_passthrough_mapper(self):
        from aegis_governance import PassthroughMapper

        assert PassthroughMapper is not None

    def test_passthrough_satisfies_protocol_via_facade(self):
        from aegis_governance import DomainMapper, PassthroughMapper

        mapper = PassthroughMapper()
        assert isinstance(mapper, DomainMapper)
