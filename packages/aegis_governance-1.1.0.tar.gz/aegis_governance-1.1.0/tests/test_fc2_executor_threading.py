"""FC-2: Executor threading hardening tests.

Verifies that Executor's threading.Lock guards correctly protect
shared state under concurrent access. Each test uses ThreadPoolExecutor
and synchronization primitives (Barrier, Event) to maximise thread
interleaving and expose race conditions.
"""

import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from src.actors.base import ActionResult
from src.actors.executor import (
    ExecutionPlan,
    ExecutionStatus,
    Executor,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_plan(proposal_id: str, steps: int = 3) -> ExecutionPlan:
    """Create a minimal ExecutionPlan with *steps* dummy steps."""
    return ExecutionPlan(
        proposal_id=proposal_id,
        steps=[{"action": f"step-{i}"} for i in range(steps)],
        rollback_steps=[{"action": "undo"}],
        timeout_seconds=60,
        requires_confirmation=False,
    )


def _make_executor(name: str = "test-exec") -> Executor:
    """Create an Executor with default capabilities."""
    return Executor(actor_id=name, name=name)


# ---------------------------------------------------------------------------
# Test class
# ---------------------------------------------------------------------------


class TestExecutorConcurrentAccess:
    """Test Executor under concurrent ThreadPoolExecutor access."""

    # -- 1. Concurrent starts of DIFFERENT proposals ----------------------

    def test_concurrent_start_execution_different_proposals(self) -> None:
        """Multiple threads starting different proposals concurrently.

        All should succeed with no data corruption.
        """
        executor = _make_executor()
        num_proposals = 20
        plans = [_make_plan(f"prop-{i}") for i in range(num_proposals)]

        barrier = threading.Barrier(num_proposals)

        def _start(plan: ExecutionPlan) -> ActionResult:
            barrier.wait()  # synchronise thread starts
            return executor.start_execution(plan)

        results = []
        with ThreadPoolExecutor(max_workers=num_proposals) as pool:
            futures = [pool.submit(_start, p) for p in plans]
            for f in as_completed(futures):
                results.append(f.result())

        # Every start should succeed
        assert all(r.success for r in results), [
            r.error for r in results if not r.success
        ]

        # active_executions should contain exactly all proposals
        assert executor.get_active_count() == num_proposals

        # Each proposal should be individually queryable and IN_PROGRESS
        for i in range(num_proposals):
            status = executor.get_execution_status(f"prop-{i}")
            assert status is not None
            assert status.status == ExecutionStatus.IN_PROGRESS
            assert status.total_steps == 3

    # -- 2. Concurrent starts of the SAME proposal -----------------------

    def test_concurrent_start_same_proposal_only_one_succeeds(self) -> None:
        """Race condition: N threads try to start the same proposal.

        Exactly one should succeed; the rest should fail with a duplicate
        error.
        """
        executor = _make_executor()
        plan = _make_plan("contested-prop", steps=5)
        num_threads = 10

        barrier = threading.Barrier(num_threads)

        def _start():
            barrier.wait()
            return executor.start_execution(plan)

        results = []
        with ThreadPoolExecutor(max_workers=num_threads) as pool:
            futures = [pool.submit(_start) for _ in range(num_threads)]
            for f in as_completed(futures):
                results.append(f.result())

        successes = [r for r in results if r.success]
        failures = [r for r in results if not r.success]

        assert len(successes) == 1, f"Expected exactly 1 success, got {len(successes)}"
        assert len(failures) == num_threads - 1

        # The single active execution should be present
        assert executor.get_active_count() == 1
        status = executor.get_execution_status("contested-prop")
        assert status is not None
        assert status.status == ExecutionStatus.IN_PROGRESS

    # -- 3. Concurrent advance_step on DIFFERENT executions ---------------

    def test_concurrent_advance_step(self) -> None:
        """Multiple threads advancing different executions in parallel.

        Each execution has 3 steps. After 3 concurrent advance rounds
        every execution should be COMPLETED.
        """
        executor = _make_executor()
        num_executions = 10
        steps_per = 3

        # Start all executions sequentially (setup)
        for i in range(num_executions):
            result = executor.start_execution(_make_plan(f"adv-{i}", steps=steps_per))
            assert result.success

        barrier = threading.Barrier(num_executions)
        errors: list[str] = []

        def _advance_all_steps(proposal_id: str) -> None:
            barrier.wait()
            for step_idx in range(steps_per):
                r = executor.advance_step(proposal_id, {"step": step_idx})
                if not r.success:
                    errors.append(f"{proposal_id} step {step_idx}: {r.error}")

        with ThreadPoolExecutor(max_workers=num_executions) as pool:
            futures = [
                pool.submit(_advance_all_steps, f"adv-{i}")
                for i in range(num_executions)
            ]
            for f in as_completed(futures):
                f.result()  # propagate unexpected exceptions

        assert errors == [], f"Unexpected advance errors: {errors}"

        # All executions should now be completed, none active
        assert executor.get_active_count() == 0

        for i in range(num_executions):
            status = executor.get_execution_status(f"adv-{i}")
            assert status is not None
            assert status.status == ExecutionStatus.COMPLETED
            assert status.current_step == steps_per

    # -- 4. Concurrent advance_step on the SAME execution ----------------

    def test_concurrent_advance_same_execution_no_overshoot(self) -> None:
        """Multiple threads try to advance the same execution concurrently.

        The lock must serialize step increments so that:
        - current_step never exceeds total_steps
        - Exactly total_steps successful advances occur
        """
        executor = _make_executor()
        total_steps = 5
        plan = _make_plan("same-adv", steps=total_steps)
        assert executor.start_execution(plan).success

        num_threads = 20
        barrier = threading.Barrier(num_threads)
        success_count = 0
        count_lock = threading.Lock()

        def _try_advance():
            nonlocal success_count
            barrier.wait()
            r = executor.advance_step("same-adv", {"concurrent": True})
            if r.success:
                with count_lock:
                    success_count += 1

        with ThreadPoolExecutor(max_workers=num_threads) as pool:
            futures = [pool.submit(_try_advance) for _ in range(num_threads)]
            for f in as_completed(futures):
                f.result()

        # Exactly total_steps advances should succeed (the rest fail because
        # execution is completed or not in progress)
        assert success_count == total_steps

        status = executor.get_execution_status("same-adv")
        assert status is not None
        assert status.status == ExecutionStatus.COMPLETED
        assert status.current_step == total_steps

    # -- 5. Concurrent start + rollback ----------------------------------

    def test_concurrent_start_and_rollback(self) -> None:
        """One thread starts, another rolls back from a different thread.

        The execution should end in a clean rolled-back state.
        """
        executor = _make_executor()
        plan = _make_plan("rollback-race", steps=5)

        # Start first so rollback has something to work with
        assert executor.start_execution(plan).success

        start_event = threading.Event()

        def _rollback():
            start_event.wait()
            return executor.rollback("rollback-race", "concurrent rollback")

        def _advance():
            start_event.wait()
            return executor.advance_step("rollback-race", {"step": 0})

        with ThreadPoolExecutor(max_workers=2) as pool:
            f_rollback = pool.submit(_rollback)
            f_advance = pool.submit(_advance)
            start_event.set()

            r_rollback = f_rollback.result()
            r_advance = f_advance.result()

        # Exactly one of the two should succeed on the active execution;
        # the other should fail (no active execution after the winner finishes).
        # If rollback wins, advance fails; if advance wins first, rollback still
        # succeeds because execution remains active.
        # The key invariant: no exceptions, and the final state is consistent.
        assert (
            r_rollback.success or r_advance.success
        ), "At least one operation should succeed"

        # After rollback succeeds, the execution should not be active
        if r_rollback.success:
            assert executor.get_active_count() == 0
            status = executor.get_execution_status("rollback-race")
            assert status is not None
            assert status.status == ExecutionStatus.ROLLED_BACK

    # -- 6. Concurrent status reads during mutations ----------------------

    def test_concurrent_status_reads(self) -> None:
        """Multiple threads reading status while execution is mutated.

        Defensive copies must prevent data races; no thread should see a
        partially-mutated object.
        """
        executor = _make_executor()
        plan = _make_plan("status-reads", steps=10)
        assert executor.start_execution(plan).success

        read_results: list[ExecutionStatus] = []
        results_lock = threading.Lock()
        stop_event = threading.Event()

        def _reader():
            while not stop_event.is_set():
                status = executor.get_execution_status("status-reads")
                if status is not None:
                    # Verify internal consistency of the snapshot
                    assert status.current_step <= status.total_steps
                    assert status.status in ExecutionStatus
                    with results_lock:
                        read_results.append(status.status)

        # Start 10 reader threads
        readers = []
        for _ in range(10):
            t = threading.Thread(target=_reader, daemon=True)
            t.start()
            readers.append(t)

        # Advance steps from main thread
        for step in range(10):
            executor.advance_step("status-reads", {"step": step})

        stop_event.set()
        for t in readers:
            t.join(timeout=5.0)

        # We should have collected some reads
        assert len(read_results) > 0, "Readers should have captured status snapshots"

        # All statuses must be valid ExecutionStatus values (no corrupt data)
        valid_statuses = {ExecutionStatus.IN_PROGRESS, ExecutionStatus.COMPLETED}
        for s in read_results:
            assert s in valid_statuses, f"Unexpected status: {s}"

    # -- 7. Concurrent pause and resume -----------------------------------

    def test_concurrent_pause_resume(self) -> None:
        """Concurrent pause and resume on the same execution.

        Verifies no deadlock and final state is consistent (either paused
        or in_progress, never corrupt).
        """
        executor = _make_executor()
        plan = _make_plan("pause-resume", steps=5)
        assert executor.start_execution(plan).success

        num_iterations = 50
        barrier = threading.Barrier(2)
        errors: list[str] = []

        def _pauser():
            for _ in range(num_iterations):
                barrier.wait()
                executor.pause_execution("pause-resume", "test pause")

        def _resumer():
            for _ in range(num_iterations):
                barrier.wait()
                executor.resume_execution("pause-resume")

        with ThreadPoolExecutor(max_workers=2) as pool:
            f_pause = pool.submit(_pauser)
            f_resume = pool.submit(_resumer)

            # Collect any exceptions
            for f in as_completed([f_pause, f_resume]):
                try:
                    f.result()
                except Exception as exc:
                    errors.append(str(exc))

        assert errors == [], f"Concurrent pause/resume raised: {errors}"

        # Final state must be a valid status, not corrupted
        status = executor.get_execution_status("pause-resume")
        assert status is not None
        assert status.status in {ExecutionStatus.IN_PROGRESS, ExecutionStatus.PAUSED}

    # -- 8. Concurrent rollback of DIFFERENT executions --------------------

    def test_concurrent_rollback_different_executions(self) -> None:
        """Roll back multiple distinct executions in parallel."""
        executor = _make_executor()
        num = 10

        for i in range(num):
            assert executor.start_execution(_make_plan(f"rb-{i}")).success

        barrier = threading.Barrier(num)

        def _rollback(pid: str) -> ActionResult:
            barrier.wait()
            return executor.rollback(pid, "parallel rollback")

        results = []
        with ThreadPoolExecutor(max_workers=num) as pool:
            futures = [pool.submit(_rollback, f"rb-{i}") for i in range(num)]
            for f in as_completed(futures):
                results.append(f.result())

        assert all(r.success for r in results), [
            r.error for r in results if not r.success
        ]
        assert executor.get_active_count() == 0

        for i in range(num):
            status = executor.get_execution_status(f"rb-{i}")
            assert status is not None
            assert status.status == ExecutionStatus.ROLLED_BACK

    # -- 9. Concurrent get_active_count during mutations -------------------

    def test_concurrent_get_active_count_consistency(self) -> None:
        """get_active_count never returns negative or impossibly high values
        even during concurrent start/complete mutations.
        """
        executor = _make_executor()
        total = 20
        stop_event = threading.Event()
        bad_counts: list[int] = []
        counts_lock = threading.Lock()

        def _counter():
            while not stop_event.is_set():
                count = executor.get_active_count()
                if count < 0 or count > total:
                    with counts_lock:
                        bad_counts.append(count)

        # Start counter thread
        counter = threading.Thread(target=_counter, daemon=True)
        counter.start()

        # Start and complete proposals
        for i in range(total):
            plan = _make_plan(f"cnt-{i}", steps=1)
            executor.start_execution(plan)
            executor.advance_step(f"cnt-{i}", {"done": True})

        stop_event.set()
        counter.join(timeout=5.0)

        assert bad_counts == [], f"Invalid active counts observed: {bad_counts}"

    # -- 10. Defensive copy prevents cross-thread mutation -----------------

    def test_get_execution_status_returns_independent_copies(self) -> None:
        """Two threads that get status snapshots should hold independent
        copies. Mutating one snapshot must not affect the other or the
        internal state.
        """
        executor = _make_executor()
        plan = _make_plan("copy-test", steps=5)
        assert executor.start_execution(plan).success

        snapshots: list = []
        snapshots_lock = threading.Lock()
        barrier = threading.Barrier(2)

        def _read():
            barrier.wait()
            s = executor.get_execution_status("copy-test")
            with snapshots_lock:
                snapshots.append(s)

        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(_read) for _ in range(2)]
            for f in as_completed(futures):
                f.result()

        assert len(snapshots) == 2
        s1, s2 = snapshots

        # Mutate one snapshot
        s1.current_step = 999

        # The other snapshot and internal state should be unaffected
        assert s2.current_step != 999
        internal = executor.get_execution_status("copy-test")
        assert internal is not None
        assert internal.current_step == 0

    # -- 11. High contention start + advance + rollback mix ---------------

    def test_high_contention_mixed_operations(self) -> None:
        """Mix of start, advance, rollback across threads.

        Ensures no deadlock and all operations complete within timeout.
        """
        executor = _make_executor()
        num_proposals = 10
        barrier = threading.Barrier(num_proposals * 3)
        errors: list[str] = []
        errors_lock = threading.Lock()

        def _worker(idx: int, op: str) -> None:
            pid = f"mix-{idx}"
            try:
                barrier.wait(timeout=5.0)
                if op == "start":
                    executor.start_execution(_make_plan(pid, steps=3))
                elif op == "advance":
                    executor.advance_step(pid, {"step": 0})
                elif op == "rollback":
                    executor.rollback(pid, "mixed test")
            except threading.BrokenBarrierError:
                pass  # acceptable if barrier times out
            except Exception as exc:
                with errors_lock:
                    errors.append(f"{op}({pid}): {exc}")

        with ThreadPoolExecutor(max_workers=num_proposals * 3) as pool:
            futures = []
            for i in range(num_proposals):
                futures.append(pool.submit(_worker, i, "start"))
                futures.append(pool.submit(_worker, i, "advance"))
                futures.append(pool.submit(_worker, i, "rollback"))
            for f in as_completed(futures):
                f.result()

        assert errors == [], f"Unexpected exceptions: {errors}"

        # No assertion on final state -- the interleaving is nondeterministic.
        # The key property is that no exception was raised and the executor
        # is in a consistent state (active_count >= 0).
        assert executor.get_active_count() >= 0

    # -- 12. Completed-status dict is not corrupted by concurrent completions

    def test_concurrent_completions_populate_completed_status(self) -> None:
        """Complete many executions concurrently and verify _completed_status
        dict is consistent.
        """
        executor = _make_executor()
        num = 15

        for i in range(num):
            plan = _make_plan(f"comp-{i}", steps=1)
            assert executor.start_execution(plan).success

        barrier = threading.Barrier(num)

        def _complete(pid: str) -> ActionResult:
            barrier.wait()
            return executor.advance_step(pid, {"final": True})

        results = []
        with ThreadPoolExecutor(max_workers=num) as pool:
            futures = [pool.submit(_complete, f"comp-{i}") for i in range(num)]
            for f in as_completed(futures):
                results.append(f.result())

        assert all(r.success for r in results)
        assert executor.get_active_count() == 0

        # All should appear in completed status
        for i in range(num):
            status = executor.get_execution_status(f"comp-{i}")
            assert status is not None, f"comp-{i} missing from completed status"
            assert status.status == ExecutionStatus.COMPLETED
