"""Tests for src/telemetry/audit_chain.py — hash-chained audit trail.

Covers:
- Chain creation and genesis hash
- Event appending and enrichment
- Chain verification (valid, tampered, missing metadata)
- Tamper detection scanning
- Thread safety under concurrent appends
- Pipeline enricher integration
- Edge cases (empty events, single event, custom genesis)
"""

import threading
from datetime import datetime, timezone

import pytest

from telemetry.audit_chain import (
    _GENESIS_HASH,
    AuditChain,
    AuditChainEnricher,
    canonical_json,
    compute_hash,
)

# ---------------------------------------------------------------------------
# Helper fixtures
# ---------------------------------------------------------------------------


def _make_event(event_id: str = "evt-1", event_type: str = "test") -> dict:
    return {
        "event_id": event_id,
        "event_type": event_type,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": "test",
        "data": {"key": "value"},
    }


# ---------------------------------------------------------------------------
# canonical_json
# ---------------------------------------------------------------------------


class TestCanonicalJson:
    def test_deterministic_output(self):
        """Same dict always produces same bytes."""
        d = {"b": 2, "a": 1, "c": 3}
        assert canonical_json(d) == canonical_json(d)

    def test_key_order_independent(self):
        """Key insertion order does not affect output."""
        d1 = {"b": 2, "a": 1}
        d2 = {"a": 1, "b": 2}
        assert canonical_json(d1) == canonical_json(d2)

    def test_strips_chain_fields(self):
        """Chain metadata fields are excluded from digest."""
        base = {"event_id": "1", "data": "x"}
        with_chain = {
            **base,
            "_chain_hash": "abc",
            "_chain_previous_hash": "def",
            "_chain_seq": 1,
        }
        assert canonical_json(base) == canonical_json(with_chain)

    def test_non_serializable_uses_str(self):
        """Non-JSON-serializable values fall back to str()."""
        d = {"ts": datetime(2026, 1, 1, tzinfo=timezone.utc)}
        result = canonical_json(d)
        assert b"2026" in result


# ---------------------------------------------------------------------------
# compute_hash
# ---------------------------------------------------------------------------


class TestComputeHash:
    def test_deterministic(self):
        """Same inputs produce same hash."""
        data = b'{"a":1}'
        prev = "abc123"
        assert compute_hash(data, prev) == compute_hash(data, prev)

    def test_different_previous_hash_changes_result(self):
        """Changing previous hash changes output."""
        data = b'{"a":1}'
        h1 = compute_hash(data, "aaa")
        h2 = compute_hash(data, "bbb")
        assert h1 != h2

    def test_sha256_length(self):
        """Output is a 64-char hex string (SHA-256)."""
        h = compute_hash(b"test", "prev")
        assert len(h) == 64
        assert all(c in "0123456789abcdef" for c in h)


# ---------------------------------------------------------------------------
# AuditChain
# ---------------------------------------------------------------------------


class TestAuditChain:
    def test_genesis_hash_default(self):
        chain = AuditChain()
        assert chain.genesis_hash == _GENESIS_HASH
        assert chain.head_hash == _GENESIS_HASH
        assert chain.sequence == 0

    def test_custom_genesis(self):
        chain = AuditChain(genesis_hash="custom_genesis")
        assert chain.genesis_hash == "custom_genesis"
        assert chain.head_hash == "custom_genesis"

    def test_append_single_event(self):
        chain = AuditChain()
        event = _make_event()
        enriched = chain.append(event)

        assert enriched["_chain_previous_hash"] == _GENESIS_HASH
        assert enriched["_chain_hash"] is not None
        assert enriched["_chain_seq"] == 1
        assert chain.sequence == 1
        assert chain.head_hash == enriched["_chain_hash"]

    def test_append_does_not_mutate_original(self):
        chain = AuditChain()
        event = _make_event()
        original_keys = set(event.keys())
        chain.append(event)
        assert set(event.keys()) == original_keys

    def test_chain_links(self):
        """Each event's previous_hash equals the prior event's hash."""
        chain = AuditChain()
        e1 = chain.append(_make_event("e1"))
        e2 = chain.append(_make_event("e2"))
        e3 = chain.append(_make_event("e3"))

        assert e1["_chain_previous_hash"] == _GENESIS_HASH
        assert e2["_chain_previous_hash"] == e1["_chain_hash"]
        assert e3["_chain_previous_hash"] == e2["_chain_hash"]

    def test_sequence_increments(self):
        chain = AuditChain()
        for i in range(5):
            enriched = chain.append(_make_event(f"e{i}"))
            assert enriched["_chain_seq"] == i + 1
        assert chain.sequence == 5

    def test_append_empty_event_raises(self):
        chain = AuditChain()
        with pytest.raises(ValueError, match="empty event"):
            chain.append({})

    def test_reset(self):
        chain = AuditChain()
        chain.append(_make_event())
        chain.append(_make_event())
        assert chain.sequence == 2

        chain.reset()
        assert chain.sequence == 0
        assert chain.head_hash == _GENESIS_HASH

    def test_repr(self):
        chain = AuditChain()
        r = repr(chain)
        assert "AuditChain" in r
        assert "sequence=0" in r


# ---------------------------------------------------------------------------
# AuditChain.verify_chain
# ---------------------------------------------------------------------------


class TestVerifyChain:
    def test_empty_chain_valid(self):
        ok, err = AuditChain.verify_chain([])
        assert ok is True
        assert err is None

    def test_single_event_valid(self):
        chain = AuditChain()
        events = [chain.append(_make_event())]
        ok, err = AuditChain.verify_chain(events)
        assert ok is True
        assert err is None

    def test_multi_event_valid(self):
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(10)]
        ok, err = AuditChain.verify_chain(events)
        assert ok is True
        assert err is None

    def test_tampered_data_detected(self):
        """Modifying event data breaks the chain."""
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(5)]
        events[2]["data"] = {"tampered": True}
        ok, err = AuditChain.verify_chain(events)
        assert ok is False
        assert "Event 2" in err
        assert "hash mismatch" in err

    def test_tampered_hash_detected(self):
        """Replacing a stored hash breaks verification."""
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(3)]
        events[1]["_chain_hash"] = "0" * 64
        ok, err = AuditChain.verify_chain(events)
        assert ok is False

    def test_missing_chain_metadata(self):
        chain = AuditChain()
        events = [chain.append(_make_event())]
        del events[0]["_chain_hash"]
        ok, err = AuditChain.verify_chain(events)
        assert ok is False
        assert "missing chain metadata" in err

    def test_swapped_events_detected(self):
        """Swapping event order breaks the chain."""
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(3)]
        events[0], events[1] = events[1], events[0]
        ok, err = AuditChain.verify_chain(events)
        assert ok is False
        assert "previous_hash mismatch" in err

    def test_custom_genesis_verification(self):
        custom = "my_genesis"
        chain = AuditChain(genesis_hash=custom)
        events = [chain.append(_make_event(f"e{i}")) for i in range(3)]
        # Verify with matching genesis
        ok, err = AuditChain.verify_chain(events, genesis_hash=custom)
        assert ok is True
        # Verify with wrong genesis fails
        ok, err = AuditChain.verify_chain(events, genesis_hash="wrong")
        assert ok is False

    def test_removed_event_detected(self):
        """Removing an event from the middle breaks the chain."""
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(5)]
        del events[2]
        ok, err = AuditChain.verify_chain(events)
        assert ok is False

    def test_inserted_event_detected(self):
        """Inserting a foreign event breaks the chain."""
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(3)]
        fake = {
            "event_id": "fake",
            "_chain_hash": "x" * 64,
            "_chain_previous_hash": events[0]["_chain_hash"],
        }
        events.insert(1, fake)
        ok, err = AuditChain.verify_chain(events)
        assert ok is False


# ---------------------------------------------------------------------------
# AuditChain.detect_tampered_events
# ---------------------------------------------------------------------------


class TestDetectTamperedEvents:
    def test_clean_chain_returns_empty(self):
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(5)]
        assert AuditChain.detect_tampered_events(events) == []

    def test_single_tamper_detected(self):
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(5)]
        events[3]["data"] = {"tampered": True}
        tampered = AuditChain.detect_tampered_events(events)
        assert 3 in tampered

    def test_multiple_tampers_detected(self):
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(5)]
        events[1]["data"] = "x"
        events[3]["data"] = "y"
        tampered = AuditChain.detect_tampered_events(events)
        assert 1 in tampered
        assert 3 in tampered

    def test_empty_chain_returns_empty(self):
        assert AuditChain.detect_tampered_events([]) == []

    def test_missing_metadata_flagged(self):
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(3)]
        del events[1]["_chain_hash"]
        tampered = AuditChain.detect_tampered_events(events)
        assert 1 in tampered


# ---------------------------------------------------------------------------
# Thread safety
# ---------------------------------------------------------------------------


class TestAuditChainThreadSafety:
    def test_concurrent_appends(self):
        """Multiple threads appending concurrently produce a valid chain."""
        chain = AuditChain()
        results: list[dict] = []
        lock = threading.Lock()
        n_threads = 8
        events_per_thread = 50

        def worker(thread_id: int) -> None:
            local_results = []
            for j in range(events_per_thread):
                event = _make_event(f"t{thread_id}-e{j}")
                enriched = chain.append(event)
                local_results.append(enriched)
            with lock:
                results.extend(local_results)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        total = n_threads * events_per_thread
        assert chain.sequence == total
        assert len(results) == total

        # All sequence numbers should be unique
        seqs = [r["_chain_seq"] for r in results]
        assert len(set(seqs)) == total

        # All hashes should be unique
        hashes = [r["_chain_hash"] for r in results]
        assert len(set(hashes)) == total

        # If we sort by sequence, the chain should verify
        sorted_events = sorted(results, key=lambda e: e["_chain_seq"])
        ok, err = AuditChain.verify_chain(sorted_events)
        assert ok is True, f"Chain verification failed: {err}"


# ---------------------------------------------------------------------------
# AuditChainEnricher (pipeline integration)
# ---------------------------------------------------------------------------


class TestAuditChainEnricher:
    def test_enricher_callable(self):
        """Enricher can be used as a pipeline enricher function."""
        enricher = AuditChainEnricher()
        event = _make_event()
        result = enricher(event)
        assert "_chain_hash" in result
        assert "_chain_previous_hash" in result
        assert "_chain_seq" in result

    def test_enricher_chains_correctly(self):
        enricher = AuditChainEnricher()
        events = [enricher(_make_event(f"e{i}")) for i in range(5)]
        ok, err = AuditChain.verify_chain(events)
        assert ok is True

    def test_enricher_repr(self):
        enricher = AuditChainEnricher()
        r = repr(enricher)
        assert "AuditChainEnricher" in r

    def test_enricher_custom_genesis(self):
        enricher = AuditChainEnricher(genesis_hash="test_genesis")
        event = enricher(_make_event())
        assert event["_chain_previous_hash"] == "test_genesis"

    def test_pipeline_integration(self):
        """Enricher works within a TelemetryPipeline."""
        from telemetry.pipeline import TelemetryPipeline

        pipeline = TelemetryPipeline()
        chain_enricher = AuditChainEnricher()
        pipeline.add_enricher(chain_enricher)

        stored: list[dict] = []
        pipeline.add_storage_handler(lambda events: stored.extend(events))

        for i in range(3):
            pipeline.ingest(
                {
                    "event_id": f"e{i}",
                    "event_type": "test",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "test",
                }
            )

        pipeline.flush()

        assert len(stored) >= 1
        # All stored events should have chain metadata
        for event in stored:
            assert "_chain_hash" in event
            assert "_chain_previous_hash" in event

        # Chain should verify
        ok, err = AuditChain.verify_chain(stored)
        assert ok is True, f"Pipeline chain verification failed: {err}"


# ---------------------------------------------------------------------------
# Chain recovery / partial verification
# ---------------------------------------------------------------------------


class TestChainEdgeCases:
    def test_large_chain(self):
        """Chain of 1000 events verifies correctly."""
        chain = AuditChain()
        events = [chain.append(_make_event(f"e{i}")) for i in range(1000)]
        ok, err = AuditChain.verify_chain(events)
        assert ok is True

    def test_event_with_nested_data(self):
        """Events with nested structures are handled correctly."""
        chain = AuditChain()
        event = {
            "event_id": "complex",
            "nested": {"deep": {"list": [1, 2, 3], "dict": {"a": "b"}}},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        enriched = chain.append(event)
        ok, err = AuditChain.verify_chain([enriched])
        assert ok is True

    def test_unicode_data(self):
        """Events with unicode content chain correctly."""
        chain = AuditChain()
        event = {"event_id": "unicode", "data": "hello \u00e9\u00e8\u00ea \u4e16\u754c"}
        enriched = chain.append(event)
        ok, err = AuditChain.verify_chain([enriched])
        assert ok is True

    def test_float_and_bool_data(self):
        """Events with floats and booleans are deterministic."""
        chain = AuditChain()
        event = {
            "event_id": "types",
            "float_val": 3.14,
            "bool_val": True,
            "null_val": None,
        }
        e1 = chain.append(event)

        chain2 = AuditChain()
        e2 = chain2.append(event)
        assert e1["_chain_hash"] == e2["_chain_hash"]
