"""Tests for shared SSRF-safe URL validation module."""

from telemetry.url_validation import is_forbidden_ip, validate_telemetry_url


class TestIsForbiddenIp:
    """Test is_forbidden_ip helper."""

    def test_public_ip_allowed(self):
        import ipaddress

        assert is_forbidden_ip(ipaddress.ip_address("8.8.8.8")) is False

    def test_loopback_forbidden(self):
        import ipaddress

        assert is_forbidden_ip(ipaddress.ip_address("127.0.0.1")) is True

    def test_private_forbidden(self):
        import ipaddress

        assert is_forbidden_ip(ipaddress.ip_address("192.168.1.1")) is True

    def test_link_local_forbidden(self):
        import ipaddress

        assert is_forbidden_ip(ipaddress.ip_address("169.254.1.1")) is True


class TestValidateTelemetryUrl:
    """Test validate_telemetry_url SSRF checks."""

    def test_https_public_accepted(self):
        assert validate_telemetry_url("https://example.com/events") is True

    def test_http_rejected(self):
        assert validate_telemetry_url("http://example.com/events") is False

    def test_private_ip_rejected(self):
        assert validate_telemetry_url("https://192.168.1.1/events") is False

    def test_loopback_rejected(self):
        assert validate_telemetry_url("https://127.0.0.1/events") is False

    def test_empty_rejected(self):
        assert validate_telemetry_url("") is False

    def test_file_scheme_rejected(self):
        assert validate_telemetry_url("file:///etc/passwd") is False

    def test_no_hostname_rejected(self):
        assert validate_telemetry_url("https://") is False
