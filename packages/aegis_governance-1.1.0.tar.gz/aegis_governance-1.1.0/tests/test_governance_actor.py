"""
Tests for src/actors/governance.py — Governance actor.

Tests cover:
- Initialization and capabilities
- Override lifecycle (initiate, sign, approve, reject, expire)
- Compliance checking
- Emergency halt
- Active overrides tracking
"""

import base64
from datetime import datetime, timedelta, timezone

from actors.base import ActorCapabilities, ActorRole
from actors.governance import Governance
from engine.gates import GateType
from workflows.override import DualSignatureValidator

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_fake_signature() -> str:
    """Return a base64-encoded 64-byte fake signature."""
    return base64.b64encode(b"\x00" * 64).decode("ascii")


def _make_fake_public_key() -> str:
    """Return a base64-encoded 32-byte fake public key."""
    return base64.b64encode(b"\x01" * 32).decode("ascii")


# ---------------------------------------------------------------------------
# TestGovernanceInit
# ---------------------------------------------------------------------------


class TestGovernanceInit:
    """Tests for Governance actor initialization."""

    def test_basic_init(self):
        """Test basic initialization sets correct attributes."""
        gov = Governance("gov-1", "Governance Lead")

        assert gov.actor_id == "gov-1"
        assert gov.name == "Governance Lead"
        assert ActorRole.GOVERNANCE in gov.roles
        assert gov.active_overrides == {}
        assert len(gov.override_history) == 0
        assert len(gov.compliance_checks) == 0
        assert gov._halted is False
        assert gov._halt_reason is None

    def test_with_additional_roles(self):
        """Test additional roles are merged."""
        gov = Governance(
            "gov-1",
            "Gov Lead",
            additional_roles={ActorRole.ADMIN},
        )

        assert ActorRole.GOVERNANCE in gov.roles
        assert ActorRole.ADMIN in gov.roles

    def test_primary_role(self):
        """Test primary role is GOVERNANCE."""
        gov = Governance("gov-1", "Gov Lead")
        assert gov.get_primary_role() == ActorRole.GOVERNANCE

    def test_allowed_actions(self):
        """Test allowed actions list."""
        gov = Governance("gov-1", "Gov Lead")
        actions = gov.get_allowed_actions()

        assert "initiate_override" in actions
        assert "add_override_signature" in actions
        assert "reject_override" in actions
        assert "check_override_status" in actions
        assert "check_compliance" in actions
        assert "emergency_halt" in actions

    def test_capabilities(self):
        """Test GOVERNANCE capabilities match RBAC schema."""
        gov = Governance("gov-1", "Gov Lead")

        assert gov.capabilities.can_override is True
        assert gov.capabilities.can_vote is True
        assert gov.capabilities.can_configure is True
        assert gov.capabilities.can_evaluate_gates is True
        # Should NOT have these
        assert gov.capabilities.can_create_proposals is False
        assert gov.capabilities.can_execute is False
        assert gov.capabilities.can_approve is False
        assert gov.capabilities.can_rollback is False


class TestGovernanceCapabilities:
    """Tests for GOVERNANCE capabilities via ActorCapabilities."""

    def test_for_role_governance(self):
        """Test ActorCapabilities.for_role returns correct caps."""
        caps = ActorCapabilities.for_role(ActorRole.GOVERNANCE)

        assert caps.can_evaluate_gates is True
        assert caps.can_vote is True
        assert caps.can_override is True
        assert caps.can_configure is True
        assert caps.can_create_proposals is False
        assert caps.can_execute is False

    def test_has_capability_checks(self):
        """Test has_capability on Governance actor."""
        gov = Governance("gov-1", "Gov Lead")

        assert gov.has_capability("can_override") is True
        assert gov.has_capability("can_vote") is True
        assert gov.has_capability("can_configure") is True
        assert gov.has_capability("can_evaluate_gates") is True
        assert gov.has_capability("can_execute") is False

    def test_merge_with_additional_roles(self):
        """Test capability merge with additional roles."""
        gov = Governance(
            "gov-1",
            "Gov Lead",
            additional_roles={ActorRole.EXECUTOR},
        )

        # Gets GOVERNANCE caps + EXECUTOR caps
        assert gov.capabilities.can_override is True
        assert gov.capabilities.can_execute is True
        assert gov.capabilities.can_rollback is True


# ---------------------------------------------------------------------------
# TestGovernanceOverride
# ---------------------------------------------------------------------------


class TestGovernanceOverride:
    """Tests for override lifecycle management."""

    def test_initiate_override_success(self):
        """Test successful override initiation."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="Emergency fix needed",
            failed_gates=["risk", "quality"],
            requested_by="dev-1",
        )

        assert result.success is True
        assert result.result_data["proposal_id"] == "prop-1"
        assert result.result_data["state"] == "pending"
        assert "prop-1" in gov.active_overrides
        assert "prop-1" in gov.override_history

    def test_initiate_override_complexity_blocked(self):
        """Test complexity gate override is blocked."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=[GateType.COMPLEXITY.value],
            requested_by="dev-1",
        )

        assert result.success is False
        assert "Complexity gate" in result.error
        assert "prop-1" not in gov.active_overrides

    def test_initiate_override_duplicate(self):
        """Test duplicate override is rejected."""
        gov = Governance("gov-1", "Gov Lead")

        gov.initiate_override(
            proposal_id="prop-1",
            justification="first",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="second",
            failed_gates=["risk"],
            requested_by="dev-2",
        )

        assert result.success is False
        assert "already active" in result.error

    def test_initiate_override_without_capability(self):
        """Test override initiation without capability fails."""
        gov = Governance(
            "gov-1",
            "Gov Lead",
            # Force no capabilities
        )
        gov.capabilities.can_override = False

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        assert result.success is False
        assert "override capability" in result.error

    def test_add_signature_success(self):
        """Test adding a signature to an active override."""
        validator = DualSignatureValidator()
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
            validator=validator,
        )

        # Generate real keypair and sign the message hash
        priv, pub = validator.generate_keypair()
        workflow = gov.active_overrides["prop-1"]
        sig = validator.sign_message(workflow.message_hash, priv)

        result = gov.add_override_signature(
            proposal_id="prop-1",
            signer_id="risk-lead-1",
            role="risk_lead",
            signature=sig,
            public_key=pub,
        )

        assert result.success is True
        assert result.result_data["state"] == "partial"
        assert result.result_data["signer_id"] == "risk-lead-1"

    def test_add_signature_unknown_proposal(self):
        """Test adding signature to unknown proposal fails."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.add_override_signature(
            proposal_id="nonexistent",
            signer_id="risk-lead-1",
            role="risk_lead",
            signature=_make_fake_signature(),
            public_key=_make_fake_public_key(),
        )

        assert result.success is False
        assert "No active override" in result.error

    def test_full_approval_lifecycle(self):
        """Test full lifecycle: initiate -> sign (risk) -> sign (security) -> approved."""
        validator = DualSignatureValidator()
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
            validator=validator,
        )

        workflow = gov.active_overrides["prop-1"]
        msg_hash = workflow.message_hash

        # Risk lead keypair and signature
        risk_priv, risk_pub = validator.generate_keypair()
        risk_sig = validator.sign_message(msg_hash, risk_priv)

        r1 = gov.add_override_signature(
            proposal_id="prop-1",
            signer_id="risk-lead-1",
            role="risk_lead",
            signature=risk_sig,
            public_key=risk_pub,
        )
        assert r1.success is True
        assert r1.result_data["state"] == "partial"

        # Security lead keypair and signature (different signer)
        sec_priv, sec_pub = validator.generate_keypair()
        sec_sig = validator.sign_message(msg_hash, sec_priv)

        r2 = gov.add_override_signature(
            proposal_id="prop-1",
            signer_id="sec-lead-1",
            role="security_lead",
            signature=sec_sig,
            public_key=sec_pub,
        )
        assert r2.success is True
        assert r2.result_data["state"] == "approved"
        assert r2.result_data["approved"] is True

        # Should be removed from active overrides
        assert "prop-1" not in gov.active_overrides

    def test_reject_override_success(self):
        """Test successful override rejection."""
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        result = gov.reject_override("prop-1", "Not justified")

        assert result.success is True
        assert result.result_data["state"] == "rejected"
        assert result.result_data["reason"] == "Not justified"
        assert "prop-1" not in gov.active_overrides

    def test_reject_override_unknown_proposal(self):
        """Test rejecting unknown proposal fails."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.reject_override("nonexistent", "reason")

        assert result.success is False
        assert "No active override" in result.error

    def test_check_override_status_success(self):
        """Test checking status of active override."""
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        result = gov.check_override_status("prop-1")

        assert result.success is True
        assert result.result_data["state"] == "pending"
        assert result.result_data["approved"] is False
        assert "risk_lead" in result.result_data["pending_signatures"]
        assert "security_lead" in result.result_data["pending_signatures"]

    def test_check_override_status_unknown(self):
        """Test checking status of unknown proposal."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.check_override_status("nonexistent")

        assert result.success is False
        assert "No active override" in result.error

    def test_check_override_status_detects_expiry(self):
        """Test that status check detects expiration."""
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        # Force expiration
        workflow = gov.active_overrides["prop-1"]
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        result = gov.check_override_status("prop-1")

        assert result.success is True
        assert result.result_data["state"] == "expired"
        # Should be removed from active overrides
        assert "prop-1" not in gov.active_overrides


# ---------------------------------------------------------------------------
# TestGovernanceCompliance
# ---------------------------------------------------------------------------


class TestGovernanceCompliance:
    """Tests for compliance checking."""

    def test_all_gates_pass(self):
        """Test compliance check when all gates pass."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.check_compliance(
            proposal_id="prop-1",
            gate_results={
                "risk": True,
                "profit": True,
                "complexity": True,
                "quality": True,
            },
        )

        assert result.success is True
        assert result.result_data["compliant"] is True
        assert result.result_data["violations"] == []

    def test_complexity_gate_failed(self):
        """Test complexity gate failure produces violation."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.check_compliance(
            proposal_id="prop-1",
            gate_results={
                "risk": True,
                "complexity": False,
                "quality": True,
            },
        )

        assert result.success is True
        assert result.result_data["compliant"] is False
        assert len(result.result_data["violations"]) == 1
        assert "Complexity" in result.result_data["violations"][0]

    def test_compliance_recorded_in_deque(self):
        """Test compliance checks are recorded."""
        gov = Governance("gov-1", "Gov Lead")

        gov.check_compliance("prop-1", {"complexity": True})
        gov.check_compliance("prop-2", {"complexity": False})

        assert len(gov.compliance_checks) == 2
        assert gov.compliance_checks[0].proposal_id == "prop-1"
        assert gov.compliance_checks[0].compliant is True
        assert gov.compliance_checks[1].proposal_id == "prop-2"
        assert gov.compliance_checks[1].compliant is False

    def test_compliance_without_capability(self):
        """Test compliance check without capability fails."""
        gov = Governance("gov-1", "Gov Lead")
        gov.capabilities.can_evaluate_gates = False

        result = gov.check_compliance("prop-1", {"complexity": True})

        assert result.success is False
        assert "gate evaluation capability" in result.error

    def test_other_gates_failing_is_compliant(self):
        """Test that non-complexity gate failures don't produce violations."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.check_compliance(
            proposal_id="prop-1",
            gate_results={
                "risk": False,
                "profit": False,
                "complexity": True,
            },
        )

        assert result.result_data["compliant"] is True
        assert result.result_data["violations"] == []


# ---------------------------------------------------------------------------
# TestGovernanceEmergencyHalt
# ---------------------------------------------------------------------------


class TestGovernanceEmergencyHalt:
    """Tests for emergency halt."""

    def test_emergency_halt_success(self):
        """Test successful emergency halt."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.emergency_halt("Critical security incident")

        assert result.success is True
        assert result.result_data["halted"] is True
        assert result.result_data["reason"] == "Critical security incident"
        assert gov.is_halted() is True
        assert gov._halt_reason == "Critical security incident"

    def test_emergency_halt_without_capability(self):
        """Test emergency halt without capability fails."""
        gov = Governance("gov-1", "Gov Lead")
        gov.capabilities.can_configure = False

        result = gov.emergency_halt("reason")

        assert result.success is False
        assert "configure capability" in result.error
        assert gov.is_halted() is False

    def test_emergency_halt_is_atomic(self):
        """emergency_halt must update _halted and _halt_reason under lock (BH10-L5)."""
        import threading

        gov = Governance("gov-1", "Gov Lead")
        observed_states: list[tuple[bool, str | None]] = []

        def reader():
            for _ in range(200):
                with gov._lock:
                    observed_states.append((gov._halted, gov._halt_reason))

        t = threading.Thread(target=reader)
        t.start()
        gov.emergency_halt("race test")
        t.join()

        for halted, reason in observed_states:
            if halted:
                assert (
                    reason == "race test"
                ), f"Observed halted=True but reason={reason!r} — non-atomic write"

    def test_emergency_halt_cancels_active_overrides(self):
        """emergency_halt must reject all active overrides (BH11-M4)."""
        gov = Governance("gov-1", "Gov Lead")

        # Initiate an override to populate active_overrides
        result = gov.initiate_override(
            proposal_id="P-001",
            justification="Testing halt cleanup",
            failed_gates=["risk"],
            requested_by="analyst-1",
        )
        assert result.success is True
        assert len(gov.get_active_overrides()) == 1

        # Halt — should cancel and clear active overrides
        halt_result = gov.emergency_halt("Critical incident")
        assert halt_result.success is True
        assert halt_result.result_data["cancelled_overrides"] == ["P-001"]
        assert len(gov.get_active_overrides()) == 0

    def test_emergency_halt_excludes_already_rejected(self):
        """BH17-L6: Already-terminal overrides must not appear in cancelled list."""
        gov = Governance("gov-1", "Gov Lead")

        # Initiate two overrides
        gov.initiate_override(
            proposal_id="P-pending",
            justification="Will be halted",
            failed_gates=["risk"],
            requested_by="analyst-1",
        )
        gov.initiate_override(
            proposal_id="P-rejected",
            justification="Already rejected",
            failed_gates=["quality"],
            requested_by="analyst-2",
        )
        assert len(gov.get_active_overrides()) == 2

        # Manually reject P-rejected so it's in a terminal state
        # but still in active_overrides (simulates race condition)
        workflow = gov.active_overrides["P-rejected"]
        workflow.reject("external-actor", "Pre-rejected")

        # Halt — only P-pending should appear in cancelled_overrides
        halt_result = gov.emergency_halt("Test halt with mixed states")
        assert halt_result.success is True
        assert "P-pending" in halt_result.result_data["cancelled_overrides"]
        assert "P-rejected" not in halt_result.result_data["cancelled_overrides"]


# ---------------------------------------------------------------------------
# TestGovernanceActiveOverrides
# ---------------------------------------------------------------------------


class TestGovernanceActiveOverrides:
    """Tests for active overrides tracking."""

    def test_get_active_overrides_empty(self):
        """Test empty active overrides."""
        gov = Governance("gov-1", "Gov Lead")
        assert gov.get_active_overrides() == {}

    def test_get_active_overrides_with_entries(self):
        """Test active overrides with entries."""
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test1",
            failed_gates=["risk"],
            requested_by="dev-1",
        )
        gov.initiate_override(
            proposal_id="prop-2",
            justification="test2",
            failed_gates=["quality"],
            requested_by="dev-2",
        )

        overrides = gov.get_active_overrides()

        assert "prop-1" in overrides
        assert "prop-2" in overrides
        assert overrides["prop-1"]["state"] == "pending"
        assert "risk_lead" in overrides["prop-1"]["pending_signatures"]
        assert "security_lead" in overrides["prop-1"]["pending_signatures"]

    def test_history_deque_bounded(self):
        """Test that override history is bounded by history_limit."""
        gov = Governance("gov-1", "Gov Lead", history_limit=3)

        for i in range(5):
            gov.initiate_override(
                proposal_id=f"prop-{i}",
                justification="test",
                failed_gates=["risk"],
                requested_by="dev-1",
            )

        assert len(gov.override_history) == 3
        # Should contain most recent 3
        assert "prop-2" in gov.override_history
        assert "prop-3" in gov.override_history
        assert "prop-4" in gov.override_history

    def test_is_halted_default(self):
        """Test default halt state is False."""
        gov = Governance("gov-1", "Gov Lead")
        assert gov.is_halted() is False

    def test_is_halted_after_halt(self):
        """Test halt state after emergency_halt."""
        gov = Governance("gov-1", "Gov Lead")
        gov.emergency_halt("test")
        assert gov.is_halted() is True


# ---------------------------------------------------------------------------
# TestGovernanceUltrathinkRegressions
# ---------------------------------------------------------------------------


class TestGovernanceUltrathinkRegressions:
    """Regression tests for ultrathink findings U-1 through U-7."""

    def test_u1_halt_blocks_initiate_override(self):
        """U-1: initiate_override must fail when system is halted."""
        gov = Governance("gov-1", "Gov Lead")
        gov.emergency_halt("security incident")

        result = gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        assert result.success is False
        assert "halted" in result.error.lower()
        assert "prop-1" not in gov.active_overrides

    def test_u2_halt_blocks_add_signature(self):
        """U-2: add_override_signature must fail when system is halted."""
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
        )
        # Halt AFTER initiation
        gov.emergency_halt("security incident")

        result = gov.add_override_signature(
            proposal_id="prop-1",
            signer_id="risk-lead-1",
            role="risk_lead",
            signature=_make_fake_signature(),
            public_key=_make_fake_public_key(),
        )

        assert result.success is False
        assert "halted" in result.error.lower()

    def test_u3_missing_complexity_gate_is_noncompliant(self):
        """U-3: Missing complexity gate result must be a violation (fail-closed)."""
        gov = Governance("gov-1", "Gov Lead")

        # Empty gate results — no complexity key
        result = gov.check_compliance("prop-1", {})

        assert result.success is True
        assert result.result_data["compliant"] is False
        assert any("missing" in v.lower() for v in result.result_data["violations"])

    def test_u3_missing_complexity_with_other_gates(self):
        """U-3: Other gates present but complexity missing is still non-compliant."""
        gov = Governance("gov-1", "Gov Lead")

        result = gov.check_compliance(
            "prop-1",
            {"risk": True, "profit": True, "quality": True},
        )

        assert result.result_data["compliant"] is False
        assert len(result.result_data["violations"]) == 1

    def test_u4_terminal_workflow_cleaned_on_failed_reject(self):
        """U-4: Terminal workflows are cleaned from active_overrides even if reject() fails."""
        gov = Governance("gov-1", "Gov Lead")
        gov.initiate_override(
            proposal_id="prop-1",
            justification="test",
            failed_gates=["risk"],
            requested_by="dev-1",
        )

        # First reject succeeds
        gov.reject_override("prop-1", "reason")
        assert "prop-1" not in gov.active_overrides

    def test_u7_thread_safety_lock_exists(self):
        """U-7: Governance actor must have a threading lock."""
        gov = Governance("gov-1", "Gov Lead")
        import threading

        assert hasattr(gov, "_lock")
        assert isinstance(gov._lock, type(threading.Lock()))


class TestGovernanceImport:
    """Tests for governance actor importability."""

    def test_import_from_actors_package(self):
        """Test Governance is importable from actors package."""
        from actors import Governance as G

        assert G is Governance

    def test_actorrole_governance_exists(self):
        """Test ActorRole.GOVERNANCE is available."""
        assert ActorRole.GOVERNANCE.value == "governance"

    def test_in_actors_all(self):
        """Test Governance is in actors.__all__."""
        import actors

        assert "Governance" in actors.__all__


class TestQG58GovernanceRegressions:
    """QG58 ultrathink governance regression tests."""

    def test_expired_override_cleaned_from_active(self):
        """QG58-P2-3: expired overrides must be removed from active_overrides."""
        from datetime import datetime, timedelta, timezone

        gov = Governance("gov-1", "Gov Lead")
        # Initiate override with required params
        gov.initiate_override(
            proposal_id="prop-expire",
            justification="test expiration cleanup",
            failed_gates=["risk"],
            requested_by="req-1",
        )
        assert "prop-expire" in gov.active_overrides

        # Force the override to expire by setting expires_at in the past
        workflow = gov.active_overrides["prop-expire"]
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(seconds=1)

        # Try to add signature — should fail (expired) AND clean up
        result = gov.add_override_signature(
            proposal_id="prop-expire",
            signer_id="signer-1",
            role="risk_lead",
            signature="sig",
            public_key="pk",
        )
        assert not result.success
        # The expired workflow should have been cleaned up
        assert "prop-expire" not in gov.active_overrides
