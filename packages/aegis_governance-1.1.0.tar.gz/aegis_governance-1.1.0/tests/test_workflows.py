"""
Tests for src/workflows/ module.

Tests cover:
- Consensus workflow
- Proposal lifecycle
- Two-key override
"""

from datetime import datetime, timezone
from typing import Optional

import pytest

from workflows.consensus import (
    ConsensusConfig,
    ConsensusResult,
    ConsensusState,
    ConsensusWorkflow,
    Vote,
    VoteOutcome,
)
from workflows.override import (
    DualSignatureValidator,
    OverrideState,
    OverrideWorkflow,
    SignatureRecord,
)
from workflows.proposal import (
    EvaluationResult,
    ProposalMetadata,
    ProposalState,
    ProposalWorkflow,
)


class TestConsensusWorkflow:
    """Tests for ConsensusWorkflow."""

    def test_init_basic(self):
        """Test basic initialization."""
        voters = {"alice", "bob", "carol"}
        workflow = ConsensusWorkflow("proposal-1", voters)

        assert workflow.proposal_id == "proposal-1"
        assert workflow.eligible_voters == voters
        assert workflow.state == ConsensusState.PENDING
        assert workflow.total_eligible == 3

    def test_init_defensively_copies_eligible_voters(self):
        """External voter-set mutation must not alter workflow authorization."""
        voters = {"alice"}
        workflow = ConsensusWorkflow("proposal-1", voters)

        # Mutating caller-owned set should not grant new voter access.
        voters.add("bob")

        assert workflow.total_eligible == 1
        assert workflow.cast_vote("bob", VoteOutcome.APPROVE) is False

    def test_init_custom_config(self):
        """Test initialization with custom config."""
        config = ConsensusConfig(
            quorum_percentage=0.67,
            approval_threshold=0.75,
            timeout_hours=24,
        )
        workflow = ConsensusWorkflow("proposal-1", {"a", "b"}, config)

        assert workflow.config.quorum_percentage == 0.67

    def test_config_threshold_validation(self):
        """Test ConsensusConfig validates threshold ranges (M4)."""
        import pytest

        # Valid configs
        ConsensusConfig(quorum_percentage=0.0, approval_threshold=0.0)
        ConsensusConfig(quorum_percentage=1.0, approval_threshold=1.0)
        ConsensusConfig(quorum_percentage=0.51, approval_threshold=0.67)

        # Invalid quorum_percentage
        with pytest.raises(ValueError, match="quorum_percentage must be between"):
            ConsensusConfig(quorum_percentage=-0.1)

        with pytest.raises(ValueError, match="quorum_percentage must be between"):
            ConsensusConfig(quorum_percentage=1.1)

        # Invalid approval_threshold
        with pytest.raises(ValueError, match="approval_threshold must be between"):
            ConsensusConfig(approval_threshold=-0.1)

        with pytest.raises(ValueError, match="approval_threshold must be between"):
            ConsensusConfig(approval_threshold=1.5)

    def test_empty_voters_raises_regardless_of_quorum(self):
        """Test that empty voters raises ValueError regardless of quorum setting.

        B3-1: Both cases are now rejected at construction time:
        - quorum=0 with empty voters would trivially pass (problematic)
        - quorum>0 with empty voters can never be met (confusing runtime behavior)
        """
        import pytest

        # Empty voters with positive quorum now raises (B3-1 fix)
        with pytest.raises(ValueError, match="empty eligible_voters"):
            ConsensusWorkflow("p1", set(), ConsensusConfig(quorum_percentage=0.5))

        # Empty voters with zero quorum also raises (existing behavior)
        with pytest.raises(ValueError, match="empty eligible_voters"):
            ConsensusWorkflow("p2", set(), ConsensusConfig(quorum_percentage=0.0))

    def test_cast_vote_valid(self):
        """Test valid vote casting."""
        workflow = ConsensusWorkflow("proposal-1", {"alice", "bob"})

        result = workflow.cast_vote(
            actor_id="alice",
            outcome=VoteOutcome.APPROVE,
            rationale="LGTM",
        )

        assert result is True
        assert "alice" in workflow.votes
        assert workflow.votes["alice"].outcome == VoteOutcome.APPROVE

    def test_cast_vote_disallow_abstain(self):
        """Test abstain vote rejection when abstain is disabled."""
        config = ConsensusConfig(allow_abstain=False)
        workflow = ConsensusWorkflow("proposal-1", {"alice", "bob"}, config)

        result = workflow.cast_vote("alice", VoteOutcome.ABSTAIN)

        assert result is False
        assert "alice" not in workflow.votes

    def test_cast_vote_invalid_voter(self):
        """Test vote rejection for non-eligible voter."""
        workflow = ConsensusWorkflow("proposal-1", {"alice", "bob"})

        result = workflow.cast_vote("eve", VoteOutcome.APPROVE)

        assert result is False
        assert "eve" not in workflow.votes

    def test_quorum_calculation(self):
        """Test quorum met calculation."""
        workflow = ConsensusWorkflow("proposal-1", {"a", "b", "c", "d"})

        assert workflow.quorum_met is False

        workflow.cast_vote("a", VoteOutcome.APPROVE)
        workflow.cast_vote("b", VoteOutcome.APPROVE)
        # 2/4 = 50% < 51% quorum

        assert workflow.quorum_met is False

        workflow.cast_vote("c", VoteOutcome.APPROVE)
        # 3/4 = 75% > 51% quorum

        assert workflow.quorum_met is True

    def test_consensus_approved(self):
        """Test consensus reaching approved state."""
        workflow = ConsensusWorkflow("proposal-1", {"a", "b", "c"})

        workflow.cast_vote("a", VoteOutcome.APPROVE)
        workflow.cast_vote("b", VoteOutcome.APPROVE)
        workflow.cast_vote("c", VoteOutcome.APPROVE)

        assert workflow.state == ConsensusState.APPROVED

    def test_consensus_rejected(self):
        """Test consensus reaching rejected state."""
        config = ConsensusConfig(approval_threshold=0.5)
        workflow = ConsensusWorkflow("proposal-1", {"a", "b", "c"}, config)

        workflow.cast_vote("a", VoteOutcome.REJECT)
        workflow.cast_vote("b", VoteOutcome.REJECT)
        workflow.cast_vote("c", VoteOutcome.REJECT)

        assert workflow.state == ConsensusState.REJECTED

    def test_get_result(self):
        """Test getting consensus result."""
        workflow = ConsensusWorkflow("proposal-1", {"a", "b"})
        workflow.cast_vote("a", VoteOutcome.APPROVE)

        result = workflow.get_result()

        assert isinstance(result, ConsensusResult)
        assert result.approval_count == 1
        assert result.rejection_count == 0
        assert len(result.consensus_hash) == 64

    def test_get_missing_voters(self):
        """Test getting missing voters."""
        workflow = ConsensusWorkflow("proposal-1", {"a", "b", "c"})
        workflow.cast_vote("a", VoteOutcome.APPROVE)

        missing = workflow.get_missing_voters()

        assert missing == {"b", "c"}

    def test_all_abstain_rejects(self):
        """Test that all voters abstaining results in REJECTED state (L54 fix).

        Previously, if all voters abstained, the workflow would be stuck in
        QUORUM_MET state forever because decisive_votes == 0 caused early return.
        Now it correctly rejects when everyone has voted but all abstained.
        """
        workflow = ConsensusWorkflow("proposal-1", {"a", "b"})

        # Both voters abstain
        workflow.cast_vote("a", VoteOutcome.ABSTAIN)
        workflow.cast_vote("b", VoteOutcome.ABSTAIN)

        # Should be REJECTED, not stuck in QUORUM_MET
        assert workflow.state == ConsensusState.REJECTED

    def test_partial_quorum_all_abstain_waits_for_remaining_voters(self):
        """Test partial quorum with all abstentions waits for remaining voters.

        When quorum is met but not all voters have voted, and all votes cast
        are abstentions, the workflow should NOT reject prematurely. Remaining
        voters could still cast decisive APPROVE/REJECT votes. The timeout
        mechanism handles the case where remaining voters never vote.

        Regression: Previously (H-WF-001), this rejected immediately, which
        locked out remaining voters from changing the outcome.
        """
        # 10 voters, 51% quorum = need 6 votes for quorum
        voters = {f"voter-{i}" for i in range(10)}
        config = ConsensusConfig(quorum_percentage=0.51)
        workflow = ConsensusWorkflow("proposal-partial", voters, config)

        # 6 voters abstain (meets quorum, but no decisive votes)
        for i in range(6):
            workflow.cast_vote(f"voter-{i}", VoteOutcome.ABSTAIN)

        # Should stay in QUORUM_MET — remaining 4 voters can still vote
        assert workflow.state == ConsensusState.QUORUM_MET
        assert len(workflow.votes) == 6

        # A remaining voter can still cast a decisive vote
        workflow.cast_vote("voter-6", VoteOutcome.APPROVE)
        # Now decisive_votes=1, approval_rate=1.0 >= 0.67 → APPROVED
        assert workflow.state == ConsensusState.APPROVED

    def test_partial_quorum_mixed_with_abstain_approves(self):
        """Test partial quorum with mixed votes including abstentions.

        When quorum is met with a mix of approvals and abstentions, the
        approval rate should be calculated excluding abstentions.
        """
        # 10 voters, 51% quorum, 67% approval threshold
        voters = {f"voter-{i}" for i in range(10)}
        config = ConsensusConfig(quorum_percentage=0.51, approval_threshold=0.67)
        workflow = ConsensusWorkflow("proposal-mixed", voters, config)

        # 3 approve, 3 abstain = 6 votes (meets quorum)
        # Approval rate = 3/3 = 100% (abstains excluded from decisive count)
        workflow.cast_vote("voter-0", VoteOutcome.APPROVE)
        workflow.cast_vote("voter-1", VoteOutcome.APPROVE)
        workflow.cast_vote("voter-2", VoteOutcome.APPROVE)
        workflow.cast_vote("voter-3", VoteOutcome.ABSTAIN)
        workflow.cast_vote("voter-4", VoteOutcome.ABSTAIN)
        workflow.cast_vote("voter-5", VoteOutcome.ABSTAIN)

        # Should be APPROVED (100% approval rate among decisive votes)
        assert workflow.state == ConsensusState.APPROVED

    def test_partial_quorum_insufficient_approval_continues(self):
        """Test partial quorum with insufficient approval rate stays in QUORUM_MET.

        When quorum is met but neither approval nor rejection threshold is met,
        the workflow should stay in QUORUM_MET waiting for more votes.
        """
        # 10 voters, 51% quorum, 67% approval threshold
        voters = {f"voter-{i}" for i in range(10)}
        config = ConsensusConfig(quorum_percentage=0.51, approval_threshold=0.67)
        workflow = ConsensusWorkflow("proposal-partial", voters, config)

        # 3 approve, 2 reject, 1 abstain = 6 votes (meets quorum)
        # Approval rate = 3/5 = 60% (below 67% threshold)
        # Rejection rate = 2/5 = 40% (below 67% threshold)
        workflow.cast_vote("voter-0", VoteOutcome.APPROVE)
        workflow.cast_vote("voter-1", VoteOutcome.APPROVE)
        workflow.cast_vote("voter-2", VoteOutcome.APPROVE)
        workflow.cast_vote("voter-3", VoteOutcome.REJECT)
        workflow.cast_vote("voter-4", VoteOutcome.REJECT)
        workflow.cast_vote("voter-5", VoteOutcome.ABSTAIN)

        # Should stay in QUORUM_MET (neither threshold met)
        assert workflow.state == ConsensusState.QUORUM_MET

    def test_all_abstain_at_exact_quorum_boundary_waits(self):
        """Test all abstain at exact quorum boundary waits for remaining voters.

        With exactly 51% of voters abstaining (the exact quorum threshold),
        remaining 49% could still cast decisive votes.

        Regression: Previously rejected immediately, disenfranchising remaining voters.
        """
        # 100 voters, 51% quorum = need exactly 51 votes
        voters = {f"voter-{i}" for i in range(100)}
        config = ConsensusConfig(quorum_percentage=0.51)
        workflow = ConsensusWorkflow("proposal-boundary", voters, config)

        # Exactly 51 voters abstain (exactly at quorum boundary)
        for i in range(51):
            workflow.cast_vote(f"voter-{i}", VoteOutcome.ABSTAIN)

        # Should stay in QUORUM_MET — 49 remaining voters can still vote
        assert workflow.state == ConsensusState.QUORUM_MET


class TestProposalWorkflow:
    """Tests for ProposalWorkflow."""

    def test_init_basic(self):
        """Test basic initialization."""
        metadata = ProposalMetadata(
            title="Test Proposal",
            description="A test proposal",
            author_id="alice",
        )
        workflow = ProposalWorkflow(metadata)

        assert workflow.state == ProposalState.DRAFT
        assert workflow.metadata.title == "Test Proposal"
        assert len(workflow.proposal_id) > 0

    def test_state_transitions(self):
        """Test valid state transitions."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        # DRAFT -> SUBMITTED
        assert workflow.can_transition_to(ProposalState.SUBMITTED)
        assert workflow.submit("alice")
        assert workflow.state == ProposalState.SUBMITTED

        # SUBMITTED -> EVALUATING
        assert workflow.start_evaluation("system")
        assert workflow.state == ProposalState.EVALUATING

    def test_invalid_transition(self):
        """Test invalid state transitions are blocked."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        # DRAFT -> APPROVED is invalid
        assert workflow.can_transition_to(ProposalState.APPROVED) is False
        result = workflow.transition_to(ProposalState.APPROVED, "alice")
        assert result is False
        assert workflow.state == ProposalState.DRAFT
        assert workflow.consensus_id is None
        assert workflow.execution_id is None

    def test_start_consensus_invalid_state_does_not_set_id(self):
        """Test consensus_id isn't set when transition fails."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        result = workflow.start_consensus(actor_id="system", consensus_id="cons-1")

        assert result is False
        assert workflow.state == ProposalState.DRAFT
        assert workflow.consensus_id is None

    def test_start_execution_invalid_state_does_not_set_id(self):
        """Test execution_id isn't set when transition fails."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        result = workflow.start_execution(actor_id="system", execution_id="exec-1")

        assert result is False
        assert workflow.state == ProposalState.DRAFT
        assert workflow.execution_id is None

    def test_complete_evaluation_passed(self):
        """Test evaluation completion with pass."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        from workflows.proposal import EvaluationResult

        workflow.submit("alice")
        workflow.start_evaluation("system")

        eval_result = EvaluationResult(
            gate_results={"risk": True, "profit": True},
            all_passed=True,
            override_eligible=False,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="system",
        )

        workflow.complete_evaluation("system", eval_result)

        assert workflow.state == ProposalState.GATE_PASSED
        assert workflow.evaluation_result is not None

    def test_complete_evaluation_failed(self):
        """Test evaluation completion with failure."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        from workflows.proposal import EvaluationResult

        workflow.submit("alice")
        workflow.start_evaluation("system")

        eval_result = EvaluationResult(
            gate_results={"risk": False},
            all_passed=False,
            override_eligible=True,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="system",
        )

        workflow.complete_evaluation("system", eval_result)

        assert workflow.state == ProposalState.GATE_FAILED

    def test_request_override(self):
        """Test override request."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        from workflows.proposal import EvaluationResult

        workflow.submit("alice")
        workflow.start_evaluation("system")

        eval_result = EvaluationResult(
            gate_results={"risk": False},
            all_passed=False,
            override_eligible=True,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="system",
        )

        workflow.complete_evaluation("system", eval_result)
        result = workflow.request_override("alice", "Critical business need")

        assert result is True
        assert workflow.state == ProposalState.OVERRIDE_REQUESTED

    def test_audit_trail(self):
        """Test audit trail recording."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        workflow.submit("alice")
        workflow.start_evaluation("system")

        trail = workflow.get_audit_trail()

        assert len(trail) == 2
        assert trail[0]["to_state"] == "submitted"
        assert trail[1]["to_state"] == "evaluating"

    def test_transition_to_defensively_copies_metadata(self):
        """Mutating caller-owned transition metadata must not alter audit state."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        transition_metadata = {"nested": {"version": 1}}
        assert workflow.transition_to(
            ProposalState.SUBMITTED,
            actor_id="alice",
            metadata=transition_metadata,
        )

        transition_metadata["nested"]["version"] = 2
        transition_metadata["injected"] = "mutated"

        assert workflow.transitions[-1].metadata == {"nested": {"version": 1}}

    def test_to_dict_returns_detached_snapshot(self):
        """Regression: mutating serialized data must not mutate workflow state."""
        metadata = ProposalMetadata(
            title="Test",
            description="Test",
            author_id="alice",
            tags=["core"],
            related_proposals=["proposal-0"],
        )
        workflow = ProposalWorkflow(metadata)

        workflow.submit("alice")
        workflow.start_evaluation("system")
        eval_result = EvaluationResult(
            gate_results={"risk": {"passed": False}},
            all_passed=False,
            override_eligible=True,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="system",
        )
        workflow.complete_evaluation("system", eval_result)

        data = workflow.to_dict()

        data["metadata"]["tags"].append("mutated")
        data["metadata"]["related_proposals"].append("proposal-x")
        data["evaluation_result"]["gate_results"]["risk"]["passed"] = True
        data["transitions"][-1]["metadata"]["gate_results"]["risk"]["passed"] = True

        assert workflow.metadata.tags == ["core"]
        assert workflow.metadata.related_proposals == ["proposal-0"]
        assert workflow.evaluation_result is not None
        assert workflow.evaluation_result.gate_results["risk"]["passed"] is False
        assert (
            workflow.transitions[-1].metadata["gate_results"]["risk"]["passed"] is False
        )

    def test_from_dict_detaches_mutable_input(self):
        """Regression: mutating input data after from_dict must not affect workflow."""
        data = {
            "proposal_id": "prop-from-dict-copy",
            "state": "evaluating",
            "created_at": "2025-01-15T10:00:00+00:00",
            "updated_at": "2025-01-15T10:05:00+00:00",
            "metadata": {
                "title": "Test Proposal",
                "description": "Test description",
                "author_id": "author-1",
                "priority": "medium",
                "tags": ["core"],
                "related_proposals": ["prop-0"],
            },
            "transitions": [
                {
                    "from_state": "submitted",
                    "to_state": "evaluating",
                    "timestamp": "2025-01-15T10:03:00+00:00",
                    "actor_id": "system",
                    "reason": "Starting evaluation",
                    "metadata": {"gate_results": {"risk": {"passed": False}}},
                },
            ],
            "evaluation_result": {
                "gate_results": {"risk": {"passed": False}},
                "all_passed": False,
                "override_eligible": True,
                "evaluated_at": "2025-01-15T10:04:00+00:00",
                "evaluator_id": "system",
            },
        }

        restored = ProposalWorkflow.from_dict(data)

        data["metadata"]["tags"].append("mutated")
        data["metadata"]["related_proposals"].append("prop-x")
        data["transitions"][0]["metadata"]["gate_results"]["risk"]["passed"] = True
        data["evaluation_result"]["gate_results"]["risk"]["passed"] = True

        assert restored.metadata.tags == ["core"]
        assert restored.metadata.related_proposals == ["prop-0"]
        assert (
            restored.transitions[0].metadata["gate_results"]["risk"]["passed"] is False
        )
        assert restored.evaluation_result is not None
        assert restored.evaluation_result.gate_results["risk"]["passed"] is False

    def test_terminal_states(self):
        """Test terminal state detection."""
        metadata = ProposalMetadata(title="Test", description="Test", author_id="alice")
        workflow = ProposalWorkflow(metadata)

        assert workflow.is_terminal is False

        workflow.submit("alice")
        workflow.start_evaluation("system")

        from workflows.proposal import EvaluationResult

        eval_result = EvaluationResult(
            gate_results={},
            all_passed=False,
            override_eligible=False,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="system",
        )
        workflow.complete_evaluation("system", eval_result)
        workflow.reject("admin", "Does not meet requirements")

        assert workflow.is_terminal is True


class TestOverrideWorkflow:
    """Tests for OverrideWorkflow."""

    def test_init_basic(self):
        """Test basic initialization."""
        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical business need",
            failed_gates=["risk"],
            requested_by="alice",
        )

        assert workflow.request.proposal_id == "proposal-1"
        assert workflow.request.state == OverrideState.PENDING
        assert len(workflow.message_hash) == 64

    def test_add_signature_valid(self):
        """Test adding valid Ed25519 signature."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Sign the workflow's message hash
        signature = validator.sign_message(workflow.message_hash, private_key)

        success, msg = workflow.add_signature(
            signer_id="risk-lead-1",
            role="risk_lead",
            signature=signature,
            public_key=public_key,
        )

        assert success is True
        assert workflow.risk_lead_signature is not None
        assert workflow.request.state == OverrideState.PARTIAL

    def test_add_signature_invalid_role(self):
        """Test rejecting invalid role."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        signature = validator.sign_message(workflow.message_hash, private_key)

        success, msg = workflow.add_signature(
            signer_id="user-1",
            role="developer",  # Invalid role
            signature=signature,
            public_key=public_key,
        )

        assert success is False
        assert "Invalid role" in msg

    def test_add_signature_invalid_signature(self):
        """Test rejecting cryptographically invalid signature."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key1, public_key1 = validator.generate_keypair()
        private_key2, public_key2 = validator.generate_keypair()

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Sign with key1 but verify with key2 (should fail)
        signature = validator.sign_message(workflow.message_hash, private_key1)

        success, msg = workflow.add_signature(
            signer_id="risk-lead-1",
            role="risk_lead",
            signature=signature,
            public_key=public_key2,  # Wrong key!
        )

        assert success is False
        assert "Signature validation failed" in msg

    def test_dual_signature_approval(self):
        """Test approval with both valid Ed25519 signatures."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        risk_private, risk_public = validator.generate_keypair()
        sec_private, sec_public = validator.generate_keypair()

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        risk_sig = validator.sign_message(workflow.message_hash, risk_private)
        sec_sig = validator.sign_message(workflow.message_hash, sec_private)

        workflow.add_signature("rl-1", "risk_lead", risk_sig, risk_public)
        workflow.add_signature("sl-1", "security_lead", sec_sig, sec_public)

        assert workflow.request.state == OverrideState.APPROVED

        result = workflow.get_result()
        assert result.approved is True
        assert result.combined_hash is not None

    def test_reject_override(self):
        """Test explicit override rejection."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        signature = validator.sign_message(workflow.message_hash, private_key)
        workflow.add_signature("rl-1", "risk_lead", signature, public_key)
        result = workflow.reject("admin", "Not justified")

        assert result is True
        assert workflow.request.state == OverrideState.REJECTED

    def test_get_pending_signatures(self):
        """Test getting pending signature roles."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        pending = workflow.get_pending_signatures()
        assert set(pending) == {"risk_lead", "security_lead"}

        signature = validator.sign_message(workflow.message_hash, private_key)
        workflow.add_signature("rl-1", "risk_lead", signature, public_key)

        pending = workflow.get_pending_signatures()
        assert pending == ["security_lead"]

    def test_from_dict_with_validator_factory(self):
        """Test from_dict_with_validator factory method."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        # Create original workflow with signature
        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()

        original = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
            validator=validator,
        )

        signature = validator.sign_message(original.message_hash, private_key)
        original.add_signature("rl-1", "risk_lead", signature, public_key)

        # Serialize and restore with factory method
        data = original.to_dict()
        restored = OverrideWorkflow.from_dict_with_validator(data, validator=validator)

        # Validator should be set
        assert restored.validator is not None
        assert restored.request.state == OverrideState.PARTIAL
        assert restored.risk_lead_signature is not None

        # Should be able to add another signature immediately
        sec_private, sec_public = validator.generate_keypair()
        sec_sig = validator.sign_message(restored.message_hash, sec_private)
        success, _ = restored.add_signature(
            "sl-1", "security_lead", sec_sig, sec_public
        )
        assert success is True
        assert restored.request.state == OverrideState.APPROVED

    def test_from_dict_without_validator_needs_set(self):
        """Test from_dict without validator requires set_validator before use."""
        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        data = workflow.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        # Validator is None
        assert restored.validator is None

        # Attempting to add signature should fail gracefully
        success, msg = restored.add_signature("rl-1", "risk_lead", "sig", "key")
        assert success is False
        assert "Validator not set" in msg


class TestDualSignatureValidator:
    """Tests for DualSignatureValidator."""

    def test_create_message_hash(self):
        """Test message hash creation is deterministic."""
        validator = DualSignatureValidator()

        hash1 = validator.create_message_hash(
            proposal_id="p1",
            justification="test",
            failed_gates=["risk", "profit"],
        )

        hash2 = validator.create_message_hash(
            proposal_id="p1",
            justification="test",
            failed_gates=["profit", "risk"],  # Different order
        )

        # Should be same due to sorting
        assert hash1 == hash2
        assert len(hash1) == 64

    def test_validate_signature_ed25519(self):
        """Test Ed25519 signature validation."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()
        msg_hash = validator.create_message_hash("p1", "test", ["risk"])
        signature = validator.sign_message(msg_hash, private_key)

        # Valid signature should pass
        assert validator.validate_signature(signature, msg_hash, public_key) is True

        # Different message hash should fail
        other_hash = validator.create_message_hash("p2", "other", ["profit"])
        assert validator.validate_signature(signature, other_hash, public_key) is False

        # Different public key should fail
        _, other_public = validator.generate_keypair()
        assert validator.validate_signature(signature, msg_hash, other_public) is False

    def test_validate_signature_format_validation(self):
        """Test format validation rejects malformed inputs."""
        import base64

        validator = DualSignatureValidator()

        # Valid format (for fallback validation)
        valid_sig = base64.b64encode(b"x" * 64).decode()
        valid_key = base64.b64encode(b"y" * 32).decode()
        valid_hash = "a" * 64

        # Wrong signature size should fail
        short_sig = base64.b64encode(b"x" * 32).decode()
        assert (
            validator._validate_signature_format(short_sig, valid_hash, valid_key)
            is False
        )

        # Wrong public key size should fail
        short_key = base64.b64encode(b"y" * 16).decode()
        assert (
            validator._validate_signature_format(valid_sig, valid_hash, short_key)
            is False
        )

        # Wrong hash length should fail
        assert (
            validator._validate_signature_format(valid_sig, "abc", valid_key) is False
        )

        # Invalid hex should fail
        assert (
            validator._validate_signature_format(valid_sig, "z" * 64, valid_key)
            is False
        )

    def test_generate_keypair(self):
        """Test Ed25519 keypair generation."""
        import base64

        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()

        # Keys should be base64 encoded
        private_bytes = base64.b64decode(private_key)
        public_bytes = base64.b64decode(public_key)

        # Ed25519 private key is 32 bytes, public key is 32 bytes
        assert len(private_bytes) == 32
        assert len(public_bytes) == 32

        # Two keypairs should be different
        private2, public2 = validator.generate_keypair()
        assert private_key != private2
        assert public_key != public2

    def test_sign_message(self):
        """Test BIP-322/Schnorr message signing."""
        import base64

        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()
        private_key, public_key = validator.generate_keypair()
        msg_hash = "a" * 64  # Valid 64-char hex

        signature = validator.sign_message(msg_hash, private_key)

        # Signature should be base64 encoded 64 bytes
        sig_bytes = base64.b64decode(signature)
        assert len(sig_bytes) == 64

        # BIP-340 Schnorr uses auxiliary randomness, so signatures are NOT
        # deterministic (unlike Ed25519). Each signing produces different signature.
        # The important test is that both signatures verify correctly.
        signature2 = validator.sign_message(msg_hash, private_key)
        assert validator.validate_signature(signature, msg_hash, public_key)
        assert validator.validate_signature(signature2, msg_hash, public_key)

        # Different message should produce different signature (still true)
        other_hash = "b" * 64
        signature3 = validator.sign_message(other_hash, private_key)
        assert signature != signature3

    def test_combine_signatures(self):
        """Test signature combination."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        validator = DualSignatureValidator()

        from workflows.override import SignatureRecord

        private1, public1 = validator.generate_keypair()
        private2, public2 = validator.generate_keypair()
        msg_hash = validator.create_message_hash("p1", "test", ["risk"])

        sig1 = SignatureRecord(
            signer_id="s1",
            role="risk_lead",
            signature=validator.sign_message(msg_hash, private1),
            message_hash=msg_hash,
            timestamp=datetime.now(timezone.utc),
            public_key=public1,
        )

        sig2 = SignatureRecord(
            signer_id="s2",
            role="security_lead",
            signature=validator.sign_message(msg_hash, private2),
            message_hash=msg_hash,
            timestamp=datetime.now(timezone.utc),
            public_key=public2,
        )

        combined = validator.combine_signatures(sig1, sig2)

        # Combined hash should be a 64-char hex SHA-256
        assert len(combined) == 64

        # Should be deterministic
        combined2 = validator.combine_signatures(sig1, sig2)
        assert combined == combined2

    def test_crypto_unavailable_fallback(self):
        """Test that format validation works when crypto is unavailable."""
        import base64

        validator = DualSignatureValidator()

        # Create properly formatted inputs
        sig = base64.b64encode(b"x" * 64).decode()
        key = base64.b64encode(b"y" * 32).decode()
        msg_hash = "a" * 64

        # Format validation should accept properly formatted inputs
        result = validator._validate_signature_format(sig, msg_hash, key)
        assert result is True

    def test_constants(self):
        """Test validator constants match Ed25519 specifications."""
        validator = DualSignatureValidator()
        assert validator._signature_size == 64
        assert validator._public_key_size == 32
        assert DualSignatureValidator.PRIVATE_KEY_SIZE == 32
        assert DualSignatureValidator.SHA256_HEX_LENGTH == 64


class TestHybridSignatureIntegration:
    """Integration tests for hybrid post-quantum signatures (GAP-Q1)."""

    def test_override_with_hybrid_signatures(self):
        """Test override workflow with hybrid Ed25519 + ML-DSA signatures."""
        import pytest

        from src.crypto import HYBRID_AVAILABLE

        if not HYBRID_AVAILABLE:
            pytest.skip("liboqs-python not available for hybrid signatures")

        from src.crypto.hybrid_provider import HybridSignatureProvider

        provider = HybridSignatureProvider()

        # Generate hybrid keypairs for risk_lead and security_lead
        risk_private, risk_public = provider.generate_keypair()
        sec_private, sec_public = provider.generate_keypair()

        _workflow = OverrideWorkflow(
            proposal_id="proposal-hybrid-1",
            justification="Critical business need with PQ security",
            failed_gates=["risk", "profit"],
            requested_by="alice",
        )

        # Create message hash using hybrid provider
        msg_hash_bytes = provider.create_message_hash(
            proposal_id="proposal-hybrid-1",
            justification="Critical business need with PQ security",
            failed_gates=["risk", "profit"],
        )

        # Sign with hybrid signatures
        risk_sig = provider.sign(msg_hash_bytes, risk_private)
        sec_sig = provider.sign(msg_hash_bytes, sec_private)

        # Verify signatures work with hybrid provider
        assert provider.verify(risk_sig, msg_hash_bytes, risk_public)
        assert provider.verify(sec_sig, msg_hash_bytes, sec_public)

        # Verify signature sizes are correct (2,484 bytes)
        assert len(risk_sig) == provider.SIGNATURE_SIZE
        assert len(sec_sig) == provider.SIGNATURE_SIZE

        # Verify public key sizes are correct (1,344 bytes)
        assert len(risk_public) == provider.PUBLIC_KEY_SIZE
        assert len(sec_public) == provider.PUBLIC_KEY_SIZE

    def test_hybrid_provider_injection(self):
        """Test that DualSignatureValidator can use injected hybrid provider."""
        import pytest

        from src.crypto import HYBRID_AVAILABLE

        if not HYBRID_AVAILABLE:
            pytest.skip("liboqs-python not available for hybrid signatures")

        from src.crypto.hybrid_provider import HybridSignatureProvider

        # Create validator with hybrid provider injected
        hybrid_provider = HybridSignatureProvider()
        validator = DualSignatureValidator(provider=hybrid_provider)

        # Generate hybrid keypair
        private_key, public_key = hybrid_provider.generate_keypair()

        # Create message hash
        msg_hash_bytes = hybrid_provider.create_message_hash(
            proposal_id="test-injection",
            justification="Testing provider injection",
            failed_gates=["gate1"],
        )

        # Sign with hybrid provider
        signature = hybrid_provider.sign(msg_hash_bytes, private_key)

        # Verify signature roundtrip works
        assert hybrid_provider.verify(signature, msg_hash_bytes, public_key)

        # Algorithm name should be hybrid
        assert validator.provider.algorithm_name == "ed25519+ml-dsa-44"

    def test_signature_record_algorithm_field(self):
        """Test SignatureRecord includes algorithm field."""
        from workflows.override import SignatureRecord

        record = SignatureRecord(
            signer_id="test-signer",
            role="risk_lead",
            signature="test-signature",
            message_hash="a" * 64,
            timestamp=datetime.now(timezone.utc),
            public_key="test-key",
            algorithm="ed25519+ml-dsa-44",
        )

        assert record.algorithm == "ed25519+ml-dsa-44"

    def test_signature_record_default_algorithm(self):
        """Test SignatureRecord defaults to bip322-simple."""
        from workflows.override import SignatureRecord

        record = SignatureRecord(
            signer_id="test-signer",
            role="risk_lead",
            signature="test-signature",
            message_hash="a" * 64,
            timestamp=datetime.now(timezone.utc),
        )

        assert record.algorithm == "bip322-simple"

    def test_backward_compat_bip322_signatures(self):
        """Test backward compatibility with existing BIP-322 signatures."""
        import pytest

        from src.crypto import BIP322_AVAILABLE
        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        if not BIP322_AVAILABLE:
            pytest.skip("btclib not available for BIP-322 signatures")

        # Default validator should use BIP-322
        validator = DualSignatureValidator()
        assert validator.provider.algorithm_name == "bip322-simple"

        # Generate BIP-322 keypair
        private_key, public_key = validator.generate_keypair()
        msg_hash = validator.create_message_hash("p1", "test", ["risk"])

        # Sign and verify with BIP-322
        signature = validator.sign_message(msg_hash, private_key)
        assert validator.validate_signature(signature, msg_hash, public_key)

        # Verify size constraints for BIP-322
        import base64

        sig_bytes = base64.b64decode(signature)
        pub_bytes = base64.b64decode(public_key)
        assert len(sig_bytes) == 64  # BIP-322 signature size
        assert len(pub_bytes) == 32  # BIP-322 public key size


class TestConsensusFinalizedAtTimestamp:
    """Tests for consensus finalized_at timestamp fix (bug-hunt regression tests)."""

    def test_finalized_at_is_captured_at_finalization(self):
        """Test finalized_at is captured at actual finalization time.

        BUG FIX: Previously get_result() computed finalized_at dynamically
        using datetime.now() on each call, which returned different timestamps.
        Now _finalize() stores the timestamp once at actual finalization time.
        """
        import time

        voters = {"alice", "bob", "carol"}
        workflow = ConsensusWorkflow("proposal-1", voters)

        # Cast votes to reach consensus
        workflow.cast_vote("alice", VoteOutcome.APPROVE)
        workflow.cast_vote("bob", VoteOutcome.APPROVE)
        workflow.cast_vote("carol", VoteOutcome.APPROVE)

        # After finalization, get_result() multiple times should return
        # the SAME finalized_at timestamp
        result1 = workflow.get_result()
        time.sleep(0.05)  # Small delay
        result2 = workflow.get_result()

        # Both calls should return the exact same finalized_at timestamp
        assert result1.finalized_at is not None
        assert result2.finalized_at is not None
        assert result1.finalized_at == result2.finalized_at

    def test_finalized_at_none_when_pending(self):
        """Test finalized_at is None when workflow is still pending."""
        voters = {"alice", "bob", "carol"}
        workflow = ConsensusWorkflow("proposal-2", voters)

        # Only one vote - not finalized yet
        workflow.cast_vote("alice", VoteOutcome.APPROVE)

        result = workflow.get_result()

        # Should still be pending with no finalized_at
        assert workflow.state in (ConsensusState.PENDING, ConsensusState.QUORUM_MET)
        assert result.finalized_at is None

    def test_finalized_at_persisted_in_to_dict(self):
        """Test finalized_at is included in serialization."""
        voters = {"alice", "bob"}
        config = ConsensusConfig(quorum_percentage=0.5, approval_threshold=0.5)
        workflow = ConsensusWorkflow("proposal-3", voters, config)

        # Finalize
        workflow.cast_vote("alice", VoteOutcome.APPROVE)
        workflow.cast_vote("bob", VoteOutcome.APPROVE)

        data = workflow.to_dict()

        assert "finalized_at" in data
        assert data["finalized_at"] is not None

    def test_finalized_at_restored_from_dict(self):
        """Test finalized_at is properly restored from serialization."""
        voters = {"alice", "bob"}
        config = ConsensusConfig(quorum_percentage=0.5, approval_threshold=0.5)
        workflow = ConsensusWorkflow("proposal-4", voters, config)

        # Finalize
        workflow.cast_vote("alice", VoteOutcome.APPROVE)
        workflow.cast_vote("bob", VoteOutcome.APPROVE)

        original_finalized_at = workflow._finalized_at

        # Serialize and restore
        data = workflow.to_dict()
        restored = ConsensusWorkflow.from_dict(data)

        # finalized_at should be restored correctly
        assert restored._finalized_at is not None
        assert restored._finalized_at == original_finalized_at

    def test_from_dict_with_naive_timestamps(self):
        """Test from_dict normalizes naive timestamps to UTC (L7 fix).

        Verifies that naive datetime strings (without timezone info) are
        correctly converted to timezone-aware UTC datetimes, preventing
        comparison errors between naive and aware datetimes.
        """
        # Create workflow data with naive ISO timestamps (no timezone suffix)
        naive_created = "2025-01-15T10:00:00"  # No +00:00 or Z suffix
        naive_deadline = "2025-01-20T10:00:00"
        naive_finalized = "2025-01-16T14:30:00"
        naive_vote_timestamp = "2025-01-15T12:00:00"

        data = {
            "proposal_id": "prop-naive-tz",
            "eligible_voters": ["alice"],
            "config": {
                "quorum_percentage": 1.0,
                "approval_threshold": 0.5,
                "timeout_hours": 72,
                "required_roles": [],
                "allow_abstain": True,
            },
            "created_at": naive_created,
            "deadline": naive_deadline,
            "state": "approved",
            "votes": {
                "alice": {
                    "actor_id": "alice",
                    "outcome": "approve",
                    "timestamp": naive_vote_timestamp,
                    "rationale": "Test",
                    "signature": None,
                }
            },
            "finalized_at": naive_finalized,
        }

        restored = ConsensusWorkflow.from_dict(data)

        # All timestamps should be timezone-aware after restoration
        assert restored.created_at.tzinfo is not None
        assert restored.created_at.tzinfo == timezone.utc
        assert restored.deadline.tzinfo is not None
        assert restored.deadline.tzinfo == timezone.utc
        assert restored._finalized_at is not None
        assert restored._finalized_at.tzinfo is not None
        assert restored._finalized_at.tzinfo == timezone.utc

        # Vote timestamps should also be timezone-aware
        vote = restored.votes["alice"]
        assert vote.timestamp.tzinfo is not None
        assert vote.timestamp.tzinfo == timezone.utc

    def test_from_dict_preserves_aware_timestamps(self):
        """Test from_dict preserves timezone-aware timestamps without modification.

        Verifies that timestamps already containing timezone info are not
        altered by the _ensure_utc() helper.
        """
        # Create workflow data with explicit UTC timezone
        aware_created = "2025-01-15T10:00:00+00:00"
        aware_deadline = "2025-01-20T10:00:00+00:00"

        data = {
            "proposal_id": "prop-aware-tz",
            "eligible_voters": ["alice"],
            "config": {
                "quorum_percentage": 1.0,
                "approval_threshold": 0.5,
                "timeout_hours": 72,
                "required_roles": [],
                "allow_abstain": True,
            },
            "created_at": aware_created,
            "deadline": aware_deadline,
            "state": "pending",
            "votes": {},
        }

        restored = ConsensusWorkflow.from_dict(data)

        # Timestamps should remain timezone-aware
        assert restored.created_at.tzinfo is not None
        assert restored.deadline.tzinfo is not None
        # Should match the original values
        expected_created = datetime.fromisoformat(aware_created)
        assert restored.created_at == expected_created


class TestProposalWorkflowTimezone:
    """Regression tests for ProposalWorkflow timezone handling (v3.21.0 fix)."""

    def test_from_dict_normalizes_naive_timestamps(self):
        """Test from_dict normalizes naive timestamps to UTC.

        Regression test for timezone bug found in v3.21.0 bug-hunt.
        ProposalWorkflow.from_dict() must normalize naive datetime
        strings to timezone-aware UTC datetimes.
        """
        # Create workflow data with naive ISO timestamps (no timezone)
        naive_created = "2025-01-15T10:00:00"
        naive_updated = "2025-01-16T11:00:00"
        naive_transition = "2025-01-15T10:30:00"
        naive_evaluated = "2025-01-16T10:00:00"

        data = {
            "proposal_id": "prop-naive-tz",
            "state": "gate_passed",
            "created_at": naive_created,
            "updated_at": naive_updated,
            "metadata": {
                "title": "Test Proposal",
                "description": "Test description",
                "author_id": "author-1",
                "priority": "medium",
            },
            "transitions": [
                {
                    "from_state": "submitted",
                    "to_state": "evaluating",
                    "timestamp": naive_transition,
                    "actor_id": "system",
                    "reason": "Starting evaluation",
                    "metadata": {},
                },
            ],
            "evaluation_result": {
                "gate_results": {"risk": True, "profit": True},
                "all_passed": True,
                "override_eligible": False,
                "evaluated_at": naive_evaluated,
                "evaluator_id": "system",
            },
        }

        restored = ProposalWorkflow.from_dict(data)

        # All timestamps should be timezone-aware after restoration
        assert restored.created_at.tzinfo is not None
        assert restored.created_at.tzinfo == timezone.utc
        assert restored.updated_at.tzinfo is not None
        assert restored.updated_at.tzinfo == timezone.utc

        # Transition timestamps should also be timezone-aware
        assert len(restored.transitions) == 1
        assert restored.transitions[0].timestamp.tzinfo is not None
        assert restored.transitions[0].timestamp.tzinfo == timezone.utc

        # Evaluation result timestamp should be timezone-aware
        assert restored.evaluation_result is not None
        assert restored.evaluation_result.evaluated_at.tzinfo is not None
        assert restored.evaluation_result.evaluated_at.tzinfo == timezone.utc

    def test_from_dict_preserves_aware_timestamps(self):
        """Test from_dict preserves timezone-aware timestamps without modification."""
        # Create workflow data with explicit UTC timezone
        aware_created = "2025-01-15T10:00:00+00:00"
        aware_updated = "2025-01-16T11:00:00+00:00"

        data = {
            "proposal_id": "prop-aware-tz",
            "state": "draft",
            "created_at": aware_created,
            "updated_at": aware_updated,
            "metadata": {
                "title": "Test Proposal",
                "description": "Test description",
                "author_id": "author-1",
                "priority": "medium",
            },
            "transitions": [],
        }

        restored = ProposalWorkflow.from_dict(data)

        # Timestamps should remain timezone-aware
        assert restored.created_at.tzinfo is not None
        assert restored.updated_at.tzinfo is not None
        # Should match the original values
        expected_created = datetime.fromisoformat(aware_created)
        assert restored.created_at == expected_created


class TestProposalWorkflowPrometheusExporter:
    """Regression tests for ProposalWorkflow prometheus_exporter restoration (B3-4 fix)."""

    def test_from_dict_does_not_restore_exporter(self):
        """Test from_dict does not restore prometheus_exporter (expected behavior).

        The prometheus_exporter cannot be serialized, so from_dict() correctly
        leaves it as None. Callers must use set_prometheus_exporter() or
        from_dict_with_exporter() to enable metrics after restoration.
        """
        metadata = ProposalMetadata(
            title="Test Proposal",
            description="Test description",
            author_id="alice",
        )
        original = ProposalWorkflow(metadata)
        original.submit("alice")

        # Serialize and restore
        data = original.to_dict()
        restored = ProposalWorkflow.from_dict(data)

        # prometheus_exporter should be None after from_dict()
        assert restored._prometheus_exporter is None

    def test_set_prometheus_exporter_after_restoration(self):
        """Test set_prometheus_exporter enables metrics after restoration.

        Regression test for bug B3-4: After deserialization, state transitions
        should be able to record metrics once set_prometheus_exporter() is called.
        """
        from unittest.mock import MagicMock

        metadata = ProposalMetadata(
            title="Test Proposal",
            description="Test description",
            author_id="alice",
        )
        original = ProposalWorkflow(metadata)
        original.submit("alice")
        original.start_evaluation("system")

        # Serialize and restore
        data = original.to_dict()
        restored = ProposalWorkflow.from_dict(data)

        # Create mock exporter
        mock_exporter = MagicMock()

        # Set exporter after restoration
        restored.set_prometheus_exporter(mock_exporter)

        # Verify exporter is set
        assert restored._prometheus_exporter is mock_exporter

        # Perform a state transition
        from workflows.proposal import EvaluationResult

        eval_result = EvaluationResult(
            gate_results={"risk": True, "profit": True},
            all_passed=True,
            override_eligible=False,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="system",
        )
        restored.complete_evaluation("system", eval_result)

        # Verify metrics were recorded
        mock_exporter.record_proposal_transition.assert_called()
        mock_exporter.record_proposal_state.assert_called()

    def test_from_dict_with_exporter_factory(self):
        """Test from_dict_with_exporter factory method sets exporter.

        This is the recommended pattern for restoring workflows that need
        immediate metrics recording capability.
        """
        from unittest.mock import MagicMock

        metadata = ProposalMetadata(
            title="Test Proposal",
            description="Test description",
            author_id="alice",
        )
        original = ProposalWorkflow(metadata)
        original.submit("alice")

        # Serialize
        data = original.to_dict()

        # Restore with exporter using factory method
        mock_exporter = MagicMock()
        restored = ProposalWorkflow.from_dict_with_exporter(
            data, prometheus_exporter=mock_exporter
        )

        # Verify exporter is set
        assert restored._prometheus_exporter is mock_exporter

        # Verify state was correctly restored
        assert restored.state == ProposalState.SUBMITTED
        assert restored.metadata.title == "Test Proposal"

    def test_from_dict_with_exporter_none_exporter(self):
        """Test from_dict_with_exporter works with None exporter.

        Should behave like regular from_dict() when no exporter is provided.
        """
        metadata = ProposalMetadata(
            title="Test Proposal",
            description="Test description",
            author_id="alice",
        )
        original = ProposalWorkflow(metadata)

        data = original.to_dict()
        restored = ProposalWorkflow.from_dict_with_exporter(
            data, prometheus_exporter=None
        )

        # prometheus_exporter should be None
        assert restored._prometheus_exporter is None

        # Should still be able to transition (silently skipping metrics)
        assert restored.submit("alice") is True
        assert restored.state == ProposalState.SUBMITTED

    def test_transition_without_exporter_succeeds_silently(self):
        """Test state transitions work without exporter (no errors).

        When prometheus_exporter is None, transitions should succeed without
        raising errors - they just skip metrics recording.
        """
        metadata = ProposalMetadata(
            title="Test Proposal",
            description="Test description",
            author_id="alice",
        )
        original = ProposalWorkflow(metadata)
        original.submit("alice")

        # Serialize and restore (no exporter)
        data = original.to_dict()
        restored = ProposalWorkflow.from_dict(data)

        # Verify no exporter
        assert restored._prometheus_exporter is None

        # Transitions should succeed without errors
        assert restored.start_evaluation("system") is True
        assert restored.state == ProposalState.EVALUATING


class TestOverrideWorkflowTimezone:
    """Regression tests for OverrideWorkflow timezone handling (v3.21.0 fix)."""

    def test_from_dict_normalizes_naive_timestamps(self):
        """Test from_dict normalizes naive timestamps to UTC.

        Regression test for timezone bug found in v3.21.0 bug-hunt.
        OverrideWorkflow.from_dict() must normalize naive datetime
        strings to timezone-aware UTC datetimes.
        """
        # Create workflow data with naive ISO timestamps (no timezone)
        naive_requested = "2025-01-15T10:00:00"
        naive_expires = "2025-01-15T22:00:00"
        naive_signature = "2025-01-15T11:00:00"

        data = {
            "workflow_id": "override-naive-tz",
            "workflow_type": "override",
            "current_state": "partial",
            "request": {
                "proposal_id": "prop-1",
                "justification": "Critical business need",
                "failed_gates": ["risk"],
                "requested_by": "alice",
                "requested_at": naive_requested,
                "state": "partial",
            },
            "message_hash": "a" * 64,
            "expires_at": naive_expires,
            "risk_lead_signature": {
                "signer_id": "risk-lead-1",
                "role": "risk_lead",
                "signature": "sig123",
                "message_hash": "a" * 64,
                "timestamp": naive_signature,
                "public_key": "key123",
                "algorithm": "ed25519-legacy",
            },
            "security_lead_signature": None,
        }

        restored = OverrideWorkflow.from_dict(data)

        # All timestamps should be timezone-aware after restoration
        assert restored.request.requested_at.tzinfo is not None
        assert restored.request.requested_at.tzinfo == timezone.utc
        assert restored.expires_at.tzinfo is not None
        assert restored.expires_at.tzinfo == timezone.utc

        # Signature timestamp should also be timezone-aware
        assert restored.risk_lead_signature is not None
        assert restored.risk_lead_signature.timestamp.tzinfo is not None
        assert restored.risk_lead_signature.timestamp.tzinfo == timezone.utc

    def test_is_expired_works_with_restored_workflow(self):
        """Test is_expired property works correctly after from_dict restoration.

        This tests that the fix prevents TypeError when comparing
        expires_at (restored from string) with datetime.now(timezone.utc).
        """
        # Create workflow that should NOT be expired (24 hours in the future)
        from datetime import timedelta

        future_expires = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat()

        data = {
            "workflow_id": "override-expiry-test",
            "workflow_type": "override",
            "current_state": "pending",
            "request": {
                "proposal_id": "prop-1",
                "justification": "Test",
                "failed_gates": ["risk"],
                "requested_by": "alice",
                "requested_at": datetime.now(timezone.utc).isoformat(),
                "state": "pending",
            },
            "message_hash": "a" * 64,
            "expires_at": future_expires,
            "risk_lead_signature": None,
            "security_lead_signature": None,
        }

        restored = OverrideWorkflow.from_dict(data)

        # This should NOT raise TypeError due to timezone mismatch
        assert restored.is_expired is False

        # Create workflow that SHOULD be expired (24 hours in the past)
        past_expires = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        data["expires_at"] = past_expires

        restored_expired = OverrideWorkflow.from_dict(data)
        assert restored_expired.is_expired is True


class TestConsensusConfigTimeoutValidation:
    """Regression tests for ConsensusConfig timeout_hours validation."""

    def test_timeout_hours_zero_raises(self):
        """Test that zero timeout_hours raises ValueError."""
        with pytest.raises(ValueError, match="timeout_hours must be positive"):
            ConsensusConfig(timeout_hours=0)

    def test_timeout_hours_negative_raises(self):
        """Test that negative timeout_hours raises ValueError."""
        with pytest.raises(ValueError, match="timeout_hours must be positive"):
            ConsensusConfig(timeout_hours=-24)

    def test_timeout_hours_positive_accepted(self):
        """Test that positive timeout_hours is accepted."""
        config = ConsensusConfig(timeout_hours=72)
        assert config.timeout_hours == 72

    def test_timeout_hours_bool_raises(self):
        """Bool timeout_hours must be rejected (bool is subclass of int, BH14-M1)."""
        with pytest.raises(TypeError, match=r"timeout_hours must be numeric.*bool"):
            ConsensusConfig(timeout_hours=True)

    def test_timeout_hours_false_raises(self):
        """False (== 0) must be rejected as bool, not as zero (BH14-M1)."""
        with pytest.raises(TypeError, match=r"timeout_hours must be numeric.*bool"):
            ConsensusConfig(timeout_hours=False)

    def test_timeout_hours_nan_raises(self):
        """NaN timeout_hours must be rejected, not pass through IEEE 754 (BH11-M5)."""
        with pytest.raises(ValueError, match="finite number"):
            ConsensusConfig(timeout_hours=float("nan"))

    def test_timeout_hours_inf_raises(self):
        """Inf timeout_hours must be rejected (BH11-M5)."""
        with pytest.raises(ValueError, match="finite number"):
            ConsensusConfig(timeout_hours=float("inf"))

    def test_timeout_hours_excessive_raises(self):
        """Excessive timeout_hours must fail fast instead of overflowing timedelta."""
        with pytest.raises(ValueError, match="exceeds maximum allowed"):
            ConsensusConfig(timeout_hours=10**20)


class TestConsensusConfigBoolGuards:
    """Regression: quorum_percentage and approval_threshold must reject bool (BH18)."""

    def test_quorum_percentage_true_raises(self):
        """True (==1) must be rejected as bool, not accepted as valid percentage."""
        with pytest.raises(TypeError, match=r"quorum_percentage must be numeric.*bool"):
            ConsensusConfig(quorum_percentage=True)

    def test_quorum_percentage_false_raises(self):
        """False (==0) must be rejected as bool, not accepted as 0% quorum."""
        with pytest.raises(TypeError, match=r"quorum_percentage must be numeric.*bool"):
            ConsensusConfig(quorum_percentage=False)

    def test_approval_threshold_true_raises(self):
        """True (==1) must be rejected as bool, not accepted as threshold."""
        with pytest.raises(
            TypeError, match=r"approval_threshold must be numeric.*bool"
        ):
            ConsensusConfig(approval_threshold=True)

    def test_approval_threshold_false_raises(self):
        """False (==0) must be rejected as bool, not accepted as 0% threshold."""
        with pytest.raises(
            TypeError, match=r"approval_threshold must be numeric.*bool"
        ):
            ConsensusConfig(approval_threshold=False)

    def test_allow_abstain_non_bool_raises(self):
        """String allow_abstain must not silently bypass abstain policy checks."""
        with pytest.raises(TypeError, match=r"allow_abstain must be bool"):
            ConsensusConfig(allow_abstain="false")


class TestConsensusReprMethods:
    """Regression tests for Vote and ConsensusResult __repr__."""

    def test_vote_repr(self):
        """Test Vote repr shows actor and outcome."""
        vote = Vote(
            actor_id="alice",
            outcome=VoteOutcome.APPROVE,
            timestamp=datetime.now(timezone.utc),
        )
        r = repr(vote)
        assert "alice" in r
        assert "approve" in r

    def test_consensus_result_repr(self):
        """Test ConsensusResult repr shows state and counts."""
        result = ConsensusResult(
            state=ConsensusState.APPROVED,
            votes={},
            approval_count=3,
            rejection_count=1,
            quorum_met=True,
            consensus_hash="abc",
        )
        r = repr(result)
        assert "approved" in r
        assert "3" in r


class TestOverrideRejectionMetadata:
    """Tests for B3-3: Override rejection metadata recording."""

    def test_reject_records_metadata(self):
        """Test that reject() records actor_id, reason, and timestamp (B3-3 fix)."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical fix needed",
            failed_gates=["risk_gate"],
            requested_by="alice",
        )

        # Perform rejection
        before_reject = datetime.now(timezone.utc)
        result = workflow.reject("security_admin", "Insufficient justification")
        after_reject = datetime.now(timezone.utc)

        # Verify rejection succeeded
        assert result is True
        assert workflow.request.state == OverrideState.REJECTED

        # Verify rejection metadata is recorded (B3-3 fix)
        assert workflow.request.rejected_by == "security_admin"
        assert workflow.request.rejection_reason == "Insufficient justification"
        assert workflow.request.rejected_at is not None
        assert before_reject <= workflow.request.rejected_at <= after_reject

    def test_rejection_metadata_persisted_in_to_dict(self):
        """Test that rejection metadata is serialized in to_dict()."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        workflow = OverrideWorkflow(
            proposal_id="proposal-2",
            justification="Emergency override",
            failed_gates=["quality_gate"],
            requested_by="bob",
        )

        workflow.reject("risk_lead_admin", "Does not meet quality standards")
        data = workflow.to_dict()

        # Verify rejection metadata in serialized output
        assert data["request"]["rejected_by"] == "risk_lead_admin"
        assert data["request"]["rejection_reason"] == "Does not meet quality standards"
        assert "rejected_at" in data["request"]
        assert data["request"]["state"] == "rejected"

    def test_rejection_metadata_restored_from_dict(self):
        """Test that rejection metadata is deserialized in from_dict()."""
        import pytest

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        workflow = OverrideWorkflow(
            proposal_id="proposal-3",
            justification="Critical security patch",
            failed_gates=["complexity_gate"],
            requested_by="carol",
        )

        workflow.reject("compliance_officer", "Requires additional review")
        original_rejected_at = workflow.request.rejected_at

        # Serialize and deserialize
        data = workflow.to_dict()
        restored = OverrideWorkflow.from_dict(data)

        # Verify metadata is restored
        assert restored.request.rejected_by == "compliance_officer"
        assert restored.request.rejection_reason == "Requires additional review"
        assert restored.request.rejected_at is not None
        # Timestamps should match (within ISO format precision)
        assert (
            restored.request.rejected_at.isoformat() == original_rejected_at.isoformat()
        )


class TestOverrideTerminalStateGuard:
    """Regression tests for O-2: add_signature must reject on terminal states."""

    def test_add_signature_after_rejection_fails(self):
        """Signatures cannot be added after explicit rejection."""
        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        workflow = OverrideWorkflow(
            proposal_id="terminal-001",
            justification="Test terminal guard",
            failed_gates=["risk_gate"],
            requested_by="alice",
        )
        workflow.reject("admin", "Denied")
        assert workflow.request.state == OverrideState.REJECTED

        success, msg = workflow.add_signature(
            signer_id="bob",
            role="risk_lead",
            signature="ZmFrZQ==",
            public_key="ZmFrZQ==",
        )
        assert not success
        assert "already rejected" in msg.lower()

    def test_add_signature_after_expiry_fails(self):
        """Signatures cannot be added after expiration."""
        from datetime import timedelta

        from workflows.override import CRYPTO_AVAILABLE

        if not CRYPTO_AVAILABLE:
            pytest.skip("cryptography library not available")

        workflow = OverrideWorkflow(
            proposal_id="terminal-002",
            justification="Test expiry guard",
            failed_gates=["risk_gate"],
            requested_by="alice",
        )
        # Force expiration
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        success, msg = workflow.add_signature(
            signer_id="bob",
            role="risk_lead",
            signature="ZmFrZQ==",
            public_key="ZmFrZQ==",
        )
        assert not success
        assert "expired" in msg.lower()


class TestConsensusEmptyVotersValidation:
    """Regression tests for B3-1: ConsensusWorkflow empty voters validation."""

    def test_empty_voters_positive_quorum_raises(self):
        """Test that empty voters with positive quorum raises ValueError (B3-1 fix).

        Empty eligible_voters with positive quorum_percentage creates a workflow
        where quorum can never be met, leading to confusing runtime behavior.
        This should be rejected at construction time.
        """
        with pytest.raises(ValueError, match="empty eligible_voters"):
            ConsensusWorkflow(
                "proposal-1",
                set(),  # Empty voters
                ConsensusConfig(quorum_percentage=0.5),  # Positive quorum
            )

    def test_empty_voters_zero_quorum_still_raises(self):
        """Test that empty voters with zero quorum raises (existing behavior)."""
        with pytest.raises(ValueError, match="empty eligible_voters"):
            ConsensusWorkflow(
                "proposal-1",
                set(),
                ConsensusConfig(quorum_percentage=0.0),
            )

    def test_non_empty_voters_works(self):
        """Test that non-empty voters with positive quorum works normally."""
        workflow = ConsensusWorkflow(
            "proposal-1",
            {"alice", "bob"},
            ConsensusConfig(quorum_percentage=0.5),
        )
        assert workflow.total_eligible == 2


class TestConsensusActorRolesValidation:
    """Regression tests for B3-1: actor_roles empty dict warning."""

    def test_empty_actor_roles_logs_warning(self, caplog):
        """Test that empty actor_roles dict logs a warning (B3-1 fix).

        When get_required_missing() is called with an empty actor_roles dict
        but required_roles are configured, this indicates a possible caller
        configuration issue. A warning should be logged.
        """
        import logging

        workflow = ConsensusWorkflow(
            "proposal-1",
            {"alice", "bob"},
            ConsensusConfig(required_roles={"risk_lead", "security_lead"}),
        )

        # Cast some votes
        workflow.cast_vote("alice", VoteOutcome.APPROVE)

        # Call with empty actor_roles dict
        with caplog.at_level(logging.WARNING):
            missing = workflow.get_required_missing(actor_roles={})

        # Should return all required roles (conservative)
        assert missing == {"risk_lead", "security_lead"}

        # Should have logged a warning
        assert "empty actor_roles dict" in caplog.text

    def test_none_actor_roles_no_warning(self, caplog):
        """Test that None actor_roles does not log warning (expected usage)."""
        import logging

        workflow = ConsensusWorkflow(
            "proposal-1",
            {"alice"},
            ConsensusConfig(required_roles={"risk_lead"}),
        )

        with caplog.at_level(logging.WARNING):
            missing = workflow.get_required_missing(actor_roles=None)

        # Should return all required roles
        assert missing == {"risk_lead"}

        # Should NOT log warning (None is expected - means "no role info")
        assert "empty actor_roles dict" not in caplog.text

    def test_empty_actor_roles_no_required_roles_no_warning(self, caplog):
        """Test that empty actor_roles with no required_roles is fine."""
        import logging

        workflow = ConsensusWorkflow(
            "proposal-1",
            {"alice"},
            ConsensusConfig(required_roles=set()),  # No required roles
        )

        with caplog.at_level(logging.WARNING):
            missing = workflow.get_required_missing(actor_roles={})

        # Should return empty set (no required roles)
        assert missing == set()

        # Should NOT log warning (empty required_roles means no issue)
        assert "empty actor_roles dict" not in caplog.text


class TestOverrideIsExpiredDocumentation:
    """Regression tests for B3-2: is_expired TOCTOU documentation and check_and_mark_expired."""

    def test_is_expired_returns_correct_value(self):
        """Test is_expired returns correct boolean based on expires_at."""
        from datetime import timedelta

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Should not be expired immediately (24 hour default)
        assert workflow.is_expired is False

        # Manually set expires_at to past
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)
        assert workflow.is_expired is True

    def test_check_and_mark_expired_marks_state(self):
        """Test check_and_mark_expired atomically marks state (B3-2 fix)."""
        from datetime import timedelta

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Set expires_at to past
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        # State should still be PENDING before check
        assert workflow.request.state == OverrideState.PENDING

        # Call check_and_mark_expired
        result = workflow.check_and_mark_expired()

        # Should return True and mark state as EXPIRED
        assert result is True
        assert workflow.request.state == OverrideState.EXPIRED

    def test_check_and_mark_expired_already_expired(self):
        """Test check_and_mark_expired returns True if already EXPIRED."""

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Manually set to EXPIRED
        workflow.request.state = OverrideState.EXPIRED

        # Should return True immediately without checking time
        result = workflow.check_and_mark_expired()
        assert result is True

    def test_check_and_mark_expired_keeps_approved_terminal_state(self):
        """Approved overrides must not be downgraded to EXPIRED."""
        from datetime import timedelta

        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )
        workflow.request.state = OverrideState.APPROVED
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        result = workflow.check_and_mark_expired()

        assert result is False
        assert workflow.request.state == OverrideState.APPROVED

    def test_check_and_mark_expired_not_expired(self):
        """Test check_and_mark_expired returns False if still valid."""
        workflow = OverrideWorkflow(
            proposal_id="proposal-1",
            justification="Critical",
            failed_gates=["risk"],
            requested_by="alice",
        )

        # Should have 24 hours remaining
        result = workflow.check_and_mark_expired()

        # Should return False and leave state unchanged
        assert result is False
        assert workflow.request.state == OverrideState.PENDING

    def test_check_and_mark_expired_logs_on_expiry(self, caplog):
        """Test check_and_mark_expired logs when marking expired."""
        import logging
        from datetime import timedelta

        workflow = OverrideWorkflow(
            proposal_id="proposal-expiry-log",
            justification="Test",
            failed_gates=["risk"],
            requested_by="alice",
        )
        workflow.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        with caplog.at_level(logging.INFO):
            workflow.check_and_mark_expired()

        assert "Override request expired" in caplog.text
        assert "proposal-expiry-log" in caplog.text


class TestDualSignatureValidatorExpirationHours:
    """Regression tests for BH14-M2: expiration_hours validation."""

    def test_zero_expiration_hours_raises(self):
        """Zero expiration_hours silently creates instantly-expired overrides (BH14-M2)."""
        with pytest.raises(ValueError, match="expiration_hours must be positive"):
            DualSignatureValidator(expiration_hours=0)

    def test_negative_expiration_hours_raises(self):
        """Negative expiration_hours creates overrides expired in the past (BH14-M2)."""
        with pytest.raises(ValueError, match="expiration_hours must be positive"):
            DualSignatureValidator(expiration_hours=-1)

    def test_nan_expiration_hours_raises(self):
        """NaN expiration_hours must be rejected (BH14-M2)."""
        with pytest.raises(ValueError, match="expiration_hours must be a finite"):
            DualSignatureValidator(expiration_hours=float("nan"))

    def test_inf_expiration_hours_raises(self):
        """Inf expiration_hours must be rejected (BH14-M2)."""
        with pytest.raises(ValueError, match="expiration_hours must be a finite"):
            DualSignatureValidator(expiration_hours=float("inf"))

    def test_bool_expiration_hours_raises(self):
        """Bool expiration_hours must be rejected (bool is subclass of int, BH14-M2)."""
        with pytest.raises(TypeError, match=r"expiration_hours must be numeric.*bool"):
            DualSignatureValidator(expiration_hours=True)

    def test_valid_expiration_hours_accepted(self):
        """Valid positive integer is accepted."""
        v = DualSignatureValidator(expiration_hours=48)
        assert v.expiration_hours == 48


class TestW1InstanceSizes:
    """Regression tests for W-1: signature sizes are instance, not class attributes."""

    def test_sizes_are_instance_level(self):
        """W-1 regression: different providers don't pollute class state."""
        v1 = DualSignatureValidator()
        v2 = DualSignatureValidator()
        # Both have default sizes
        assert v1._signature_size == 64
        assert v2._signature_size == 64
        # Mutating one doesn't affect the other
        v1._signature_size = 128
        assert v2._signature_size == 64
        # No class-level SIGNATURE_SIZE attribute
        assert not hasattr(DualSignatureValidator, "SIGNATURE_SIZE")


class TestW2CombineSignaturesOrder:
    """Regression tests for W-2: combine_signatures is order-independent."""

    def test_combine_signatures_order_independent(self):
        """W-2 regression: combine_signatures(a,b) == combine_signatures(b,a)."""
        validator = DualSignatureValidator()
        sig_risk = SignatureRecord(
            signer_id="risk-user",
            role="risk_lead",
            signature="sig_r",
            message_hash="abc123",
            timestamp=datetime.now(timezone.utc),
        )
        sig_sec = SignatureRecord(
            signer_id="sec-user",
            role="security_lead",
            signature="sig_s",
            message_hash="abc123",
            timestamp=datetime.now(timezone.utc),
        )
        hash1 = validator.combine_signatures(sig_risk, sig_sec)
        hash2 = validator.combine_signatures(sig_sec, sig_risk)
        assert hash1 == hash2


class TestW10FourEyesPreCheck:
    """Regression tests for W-10: four-eyes check before key fetch."""

    async def test_sign_with_stored_key_rejects_same_signer(self):
        """W-10 regression: sign_with_stored_key rejects duplicate signer before key fetch."""
        workflow = OverrideWorkflow(
            proposal_id="prop-w10",
            justification="test",
            failed_gates=["gate"],
            requested_by="dev",
        )
        # Manually set a security_lead signature
        workflow.security_lead_signature = SignatureRecord(
            signer_id="same-user",
            role="security_lead",
            signature="sig",
            message_hash=workflow.message_hash,
            timestamp=datetime.now(timezone.utc),
        )
        workflow.request.state = OverrideState.PARTIAL

        # Mock key_store
        class MockKeyStore:
            pass

        workflow.key_store = MockKeyStore()  # type: ignore[assignment]

        # Try to sign as risk_lead with same signer_id — should fail BEFORE key fetch
        success, msg = await workflow.sign_with_stored_key("risk_lead", "same-user")
        assert not success
        assert "Four-eyes violation" in msg


class TestW11StoredKeyAuditVersionPinning:
    """Regression tests for W-11: audit usage tracks pinned key version."""

    async def test_sign_with_stored_key_records_usage_for_pinned_version(self):
        """W-11 regression: record_usage must use the same pinned version used for signing."""

        class DummyValidator:
            expiration_hours = 24
            algorithm_name = "dummy-algo"

            def create_message_hash(
                self, proposal_id: str, justification: str, failed_gates: list[str]
            ) -> str:
                return "a" * 64

            def sign_message(self, message_hash: str, private_key_b64: str) -> str:
                return "sig"

            def validate_signature(
                self, signature: str, message_hash: str, public_key: str
            ) -> bool:
                return True

        class MockKeyStore:
            def __init__(self) -> None:
                self.private_version = None
                self.public_version = None
                self.usage_version = None

            async def get_key_info(self, role: str, algorithm: str):
                return {"key_version": 7}

            async def get_private_key(
                self, role: str, algorithm: str, version: Optional[int] = None
            ):
                self.private_version = version
                return b"private-key"

            async def get_public_key(
                self, role: str, algorithm: str, version: Optional[int] = None
            ):
                self.public_version = version
                return b"public-key"

            async def record_usage(
                self,
                role: str,
                algorithm: str,
                operation: str,
                actor_id: str,
                context: dict[str, str],
                version: Optional[int] = None,
            ) -> None:
                self.usage_version = version

        key_store = MockKeyStore()
        workflow = OverrideWorkflow(
            proposal_id="prop-w11",
            justification="test",
            failed_gates=["gate"],
            requested_by="dev",
            validator=DummyValidator(),
            key_store=key_store,  # type: ignore[arg-type]
        )

        success, msg = await workflow.sign_with_stored_key("risk_lead", "risk-user")

        assert success, msg
        assert key_store.private_version == 7
        assert key_store.public_version == 7
        assert key_store.usage_version == 7


class TestW3VoteOverwriteWarning:
    """Regression test for W-3: vote overwrite logs warning."""

    def test_vote_overwrite_logs_warning(self, caplog):
        """W-3 regression: overwriting a vote emits a warning log."""
        import logging

        voters = {"alice", "bob", "carol"}
        workflow = ConsensusWorkflow("prop-w3", voters)

        # First vote
        workflow.cast_vote("alice", VoteOutcome.APPROVE)

        # Overwrite vote
        with caplog.at_level(logging.WARNING, logger="workflows.consensus"):
            workflow.cast_vote("alice", VoteOutcome.REJECT)

        assert "Vote overwrite" in caplog.text
        assert "alice" in caplog.text


class TestW5EvaluationResultAfterTransition:
    """Regression test for W-5: evaluation_result set only on successful transition."""

    def test_failed_transition_does_not_set_evaluation_result(self):
        """W-5 regression: failed transition leaves evaluation_result unchanged."""
        metadata = ProposalMetadata(
            title="Test",
            description="Test proposal",
            author_id="author-1",
        )
        workflow = ProposalWorkflow(metadata, proposal_id="prop-w5")
        assert workflow.evaluation_result is None

        result = EvaluationResult(
            gate_results={"risk": True},
            all_passed=True,
            override_eligible=False,
            evaluated_at=datetime.now(timezone.utc),
            evaluator_id="evaluator-1",
        )

        # Proposal is in DRAFT state — complete_evaluation requires EVALUATING
        success = workflow.complete_evaluation("evaluator-1", result)
        assert not success
        assert workflow.evaluation_result is None


# ============================================================================
# Ultrathink Bug-Hunt #5 Regression Tests
# ============================================================================


class TestProposalAuditTrailDefensiveCopy:
    """Regression: proposal.py audit trail metadata exposed by reference."""

    def test_audit_trail_metadata_is_defensive_copy(self):
        """Mutating returned metadata should not affect internal state."""
        from workflows.proposal import ProposalMetadata, ProposalWorkflow

        wf = ProposalWorkflow(
            metadata=ProposalMetadata(
                title="Test",
                description="Test proposal",
                author_id="proposer-1",
            ),
        )
        # Trigger a transition to generate audit trail
        wf.submit(actor_id="proposer-1")
        trail = wf.get_audit_trail()
        if trail and trail[0].get("metadata"):
            # Mutate the returned dict
            trail[0]["metadata"]["injected"] = "malicious"
            # Verify internal state is unaffected
            trail2 = wf.get_audit_trail()
            assert "injected" not in trail2[0].get("metadata", {})


class TestConsensusVotesDefensiveCopy:
    """Regression: consensus.py shallow copy exposes mutable Vote objects."""

    def test_result_votes_are_independent_copies(self):
        """Modifying Vote in ConsensusResult should not affect internal state."""
        from workflows.consensus import ConsensusWorkflow, VoteOutcome

        wf = ConsensusWorkflow(
            proposal_id="test-prop",
            eligible_voters={"voter1", "voter2"},
        )
        wf.cast_vote("voter1", VoteOutcome.APPROVE, "Looks good")
        wf.cast_vote("voter2", VoteOutcome.APPROVE, "Agreed")
        result = wf.get_result()

        # Mutate vote in result
        vote = result.votes["voter1"]
        original_rationale = vote.rationale
        vote.rationale = "MUTATED"

        # Internal state should be unaffected
        result2 = wf.get_result()
        assert result2.votes["voter1"].rationale == original_rationale


class TestConsensusTwoThirdsMajority:
    """Regression QG-Defer-5: 2/3 majority must produce APPROVED, not stuck in QUORUM_MET."""

    def test_two_of_three_approvals_is_approved(self):
        """With default threshold (2/3), 2 approvals out of 3 decisive votes → APPROVED.

        Old default 0.67 caused 2/3 (0.6667) < 0.67 → incorrectly stuck.
        Vote order: REJECT first so quorum is met with mixed votes,
        then second APPROVE triggers the 2/3 threshold check.
        """
        wf = ConsensusWorkflow(
            proposal_id="two-thirds-test",
            eligible_voters={"a", "b", "c"},
            config=ConsensusConfig(quorum_percentage=0.51),
            # approval_threshold defaults to 2/3
        )
        wf.cast_vote("a", VoteOutcome.REJECT)
        wf.cast_vote("b", VoteOutcome.APPROVE)
        # At this point: 1 approve, 1 reject → 50% approval, no decision yet
        assert wf.state == ConsensusState.QUORUM_MET

        wf.cast_vote("c", VoteOutcome.APPROVE)
        # Now: 2 approve, 1 reject → 2/3 = 0.6667 >= 2/3 threshold

        result = wf.get_result()
        assert (
            result.state == ConsensusState.APPROVED
        ), f"2/3 approval should yield APPROVED, got {result.state.value}"
        assert result.approval_count == 2
        assert result.rejection_count == 1

    def test_one_of_three_approvals_is_rejected(self):
        """1 approval out of 3 → rejection rate 2/3 >= threshold → REJECTED."""
        wf = ConsensusWorkflow(
            proposal_id="rejection-test",
            eligible_voters={"a", "b", "c"},
            config=ConsensusConfig(quorum_percentage=0.51),
        )
        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.REJECT)
        wf.cast_vote("c", VoteOutcome.REJECT)

        result = wf.get_result()
        assert result.state == ConsensusState.REJECTED


class TestSchemaValidationNoneVsFalsy:
    """Regression: schema.py 'if not section' should be 'if section is None'."""

    def test_falsy_section_not_treated_as_missing(self):
        """A section that evaluates as falsy but is not None should not error."""
        from telemetry.schema import ProposalTelemetry

        # Create a valid telemetry record
        telemetry = ProposalTelemetry()
        # Sections are None by default — that's correctly missing
        errors = telemetry.validate()
        # Should report "Missing required" for None sections
        assert any("Missing required" in e for e in errors)


class TestBug10DeferVoteSemantics:
    """Regression: DEFER votes should NOT count toward quorum participation."""

    def test_defer_does_not_count_toward_quorum(self):
        """Bug 10: DEFER votes should not count as participation."""
        wf = ConsensusWorkflow(
            proposal_id="defer-test",
            eligible_voters={"a", "b", "c", "d"},
            config=ConsensusConfig(quorum_percentage=0.51),
        )
        # One DEFER vote should not count toward participation
        wf.cast_vote("a", VoteOutcome.DEFER)
        assert wf.votes_cast == 0  # DEFER doesn't count
        assert wf.participation_rate == 0.0
        assert not wf.quorum_met

    def test_defer_recorded_but_abstain_counts(self):
        """ABSTAIN counts as participation, DEFER does not."""
        wf = ConsensusWorkflow(
            proposal_id="semantics-test",
            eligible_voters={"a", "b", "c", "d"},
            config=ConsensusConfig(quorum_percentage=0.51),
        )
        wf.cast_vote("a", VoteOutcome.ABSTAIN)
        wf.cast_vote("b", VoteOutcome.DEFER)
        # Only ABSTAIN counts
        assert wf.votes_cast == 1
        assert len(wf.votes) == 2  # Both are recorded

    def test_defer_plus_approvals_reach_quorum(self):
        """DEFER alone can't meet quorum, but APPROVE votes can."""
        wf = ConsensusWorkflow(
            proposal_id="mixed-test",
            eligible_voters={"a", "b", "c", "d"},
            config=ConsensusConfig(quorum_percentage=0.51, approval_threshold=0.67),
        )
        wf.cast_vote("a", VoteOutcome.DEFER)
        wf.cast_vote("b", VoteOutcome.APPROVE)
        wf.cast_vote("c", VoteOutcome.APPROVE)
        # 2 out of 4 = 50% participation (DEFER excluded), quorum not met
        assert wf.votes_cast == 2
        assert not wf.quorum_met
        # One more approval meets quorum
        wf.cast_vote("d", VoteOutcome.APPROVE)
        assert wf.votes_cast == 3
        assert wf.quorum_met


class TestBH16ConsensusDeadlock:
    """BH16-M4: Consensus must finalize as REJECTED when all voters have voted
    but neither approval nor rejection threshold is met."""

    def test_deadlock_4_voters_split_vote_rejects(self):
        """4 voters, 2 approve / 2 reject, threshold=0.67 → deadlock → REJECTED.

        Uses quorum_percentage=1.0 to force all voters to participate before
        consensus evaluation starts.
        """
        wf = ConsensusWorkflow(
            proposal_id="test-deadlock",
            eligible_voters={"a", "b", "c", "d"},
            config=ConsensusConfig(quorum_percentage=1.0, approval_threshold=2 / 3),
        )
        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.REJECT)
        wf.cast_vote("c", VoteOutcome.APPROVE)
        # Not yet deadlocked — 1 voter remaining
        assert wf.state != ConsensusState.REJECTED
        wf.cast_vote("d", VoteOutcome.REJECT)
        # All 4 voted, 2/4 approve = 0.5 < 0.67, 2/4 reject = 0.5 < 0.67
        assert wf.state == ConsensusState.REJECTED

    def test_deadlock_5_voters_3_2_split_rejects(self):
        """5 voters, 3 approve / 2 reject, threshold=0.80 → deadlock → REJECTED."""
        wf = ConsensusWorkflow(
            proposal_id="test-deadlock-5",
            eligible_voters={"a", "b", "c", "d", "e"},
            config=ConsensusConfig(quorum_percentage=1.0, approval_threshold=0.80),
        )
        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.REJECT)
        wf.cast_vote("c", VoteOutcome.APPROVE)
        wf.cast_vote("d", VoteOutcome.REJECT)
        wf.cast_vote("e", VoteOutcome.APPROVE)
        # 3/5 = 0.6, which is < 0.80, so no approval; 2/5 = 0.4, no rejection
        assert wf.state == ConsensusState.REJECTED

    def test_non_deadlock_still_approves(self):
        """Normal case: sufficient votes for approval still works."""
        wf = ConsensusWorkflow(
            proposal_id="test-no-deadlock",
            eligible_voters={"a", "b", "c"},
            config=ConsensusConfig(quorum_percentage=0.5, approval_threshold=2 / 3),
        )
        wf.cast_vote("a", VoteOutcome.APPROVE)
        wf.cast_vote("b", VoteOutcome.APPROVE)
        wf.cast_vote("c", VoteOutcome.REJECT)
        # 2/3 ≈ 0.667 >= 0.667 threshold → APPROVED
        assert wf.state == ConsensusState.APPROVED
