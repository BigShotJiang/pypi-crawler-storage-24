"""Regression tests for Bug Hunt #39 Lane B findings.

BH39-M4: GateEvaluator accepts float('inf') for trigger factors — silently
         disables Bayesian risk/profit gate (gates.py).
BH39-M5: UtilityResult accepts NaN for variance/raw/lcb — NaN propagates
         to silent gate failure (utility.py).
BH39-M6: config._parse_kl_drift_dict silently truncates float window_days
         before KLDriftConfig can reject it (config.py).
BH39-L2: GateEvaluator novelty_k=0.0 makes logistic gate score-insensitive (gates.py).
BH39-L3: JSON-RPC notification with non-string method receives error response,
         violating JSON-RPC 2.0 §4.1 (mcp_server.py).
BH39-L4: bip322_provider.encode_simple() crashes with cryptic error for
         signatures >=256 bytes (bip322_provider.py).
BH39-L5: config._parse_mcp_rate_limit silently truncates float mcp_rate_limit
         (config.py).
"""

import math

import pytest

from config import AegisConfig
from engine.gates import GateEvaluator
from engine.utility import UtilityResult

try:
    from crypto.bip322_provider import BIP322Provider

    _HAS_BTCLIB = True
except ImportError:
    _HAS_BTCLIB = False

# =============================================================================
# BH39-M4: GateEvaluator float('inf') trigger factor disables Bayesian gate
# =============================================================================


class TestBH39M4TriggerFactorInf:
    """GateEvaluator must reject float('inf') for trigger factors."""

    def test_risk_trigger_factor_inf_raises(self):
        """float('inf') risk_trigger_factor must raise ValueError, not silently disable gate."""
        with pytest.raises(ValueError, match="finite"):
            GateEvaluator(risk_trigger_factor=float("inf"))

    def test_profit_trigger_factor_inf_raises(self):
        """float('inf') profit_trigger_factor must raise ValueError."""
        with pytest.raises(ValueError, match="finite"):
            GateEvaluator(profit_trigger_factor=float("inf"))

    def test_risk_trigger_factor_neg_inf_raises(self):
        """-inf risk_trigger_factor must raise ValueError."""
        with pytest.raises(ValueError, match="finite"):
            GateEvaluator(risk_trigger_factor=float("-inf"))

    def test_profit_trigger_factor_neg_inf_raises(self):
        """-inf profit_trigger_factor must raise ValueError."""
        with pytest.raises(ValueError, match="finite"):
            GateEvaluator(profit_trigger_factor=float("-inf"))

    def test_finite_trigger_factor_accepted(self):
        """Finite trigger factors in normal range must still be accepted."""
        gate = GateEvaluator(risk_trigger_factor=2.0, profit_trigger_factor=2.0)
        assert gate.risk_trigger_factor == 2.0


# =============================================================================
# BH39-M5: UtilityResult NaN variance/raw/lcb causes silent gate failure
# =============================================================================


class TestBH39M5UtilityResultNaN:
    """UtilityResult must reject NaN for variance, raw, and lcb."""

    def test_nan_variance_raises(self):
        """NaN variance must raise ValueError at construction time."""
        with pytest.raises(ValueError, match="NaN"):
            UtilityResult(
                raw=1.0,
                variance=float("nan"),
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_nan_raw_raises(self):
        """NaN raw must raise ValueError at construction time."""
        with pytest.raises(ValueError, match="NaN"):
            UtilityResult(
                raw=float("nan"),
                variance=0.01,
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_nan_lcb_raises(self):
        """NaN lcb must raise ValueError at construction time."""
        with pytest.raises(ValueError, match="NaN"):
            UtilityResult(
                raw=1.0,
                variance=0.01,
                lcb=float("nan"),
                components=None,
                decision_path="INVESTMENT",
            )

    def test_inf_variance_raises(self):
        """Infinite variance must raise ValueError (not physically meaningful)."""
        with pytest.raises(ValueError, match="variance"):
            UtilityResult(
                raw=1.0,
                variance=float("inf"),
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_negative_variance_raises(self):
        """Negative variance must raise ValueError."""
        with pytest.raises(ValueError, match="variance"):
            UtilityResult(
                raw=1.0,
                variance=-0.01,
                lcb=0.5,
                components=None,
                decision_path="INVESTMENT",
            )

    def test_neg_inf_raw_allowed(self):
        """-inf raw IS allowed — it signals extremely low utility."""
        result = UtilityResult(
            raw=float("-inf"),
            variance=0.0,
            lcb=float("-inf"),
            components=None,
            decision_path="INVESTMENT",
        )
        assert math.isinf(result.raw)

    def test_valid_utility_result_accepted(self):
        """Valid UtilityResult must still be accepted."""
        result = UtilityResult(
            raw=1.5,
            variance=0.04,
            lcb=1.1,
            components=None,
            decision_path="INVESTMENT",
        )
        assert result.raw == 1.5
        assert math.isclose(result.std_dev, 0.2)


# =============================================================================
# BH39-M6: config silently truncates float window_days
# =============================================================================


class TestBH39M6WindowDaysFloatTruncation:
    """_parse_kl_drift_dict must reject fractional float window_days."""

    def test_fractional_window_days_raises_type_error(self):
        """30.7 window_days must raise TypeError, not silently become 30."""
        with pytest.raises(TypeError, match="integer"):
            AegisConfig.from_dict({"kl_drift": {"window_days": 30.7}})

    def test_fractional_small_window_days_raises(self):
        """1.5 window_days must raise TypeError."""
        with pytest.raises(TypeError, match="integer"):
            AegisConfig.from_dict({"kl_drift": {"window_days": 1.5}})

    def test_integer_float_window_days_accepted(self):
        """30.0 (float but whole number) must be accepted as 30."""
        config = AegisConfig.from_dict({"kl_drift": {"window_days": 30.0}})
        assert config.kl_drift.window_days == 30

    def test_integer_window_days_accepted(self):
        """Plain int window_days must still work."""
        config = AegisConfig.from_dict({"kl_drift": {"window_days": 7}})
        assert config.kl_drift.window_days == 7


# =============================================================================
# BH39-L2: GateEvaluator novelty_k=0.0 makes gate score-insensitive
# =============================================================================


class TestBH39L2NoveltyKZero:
    """novelty_k must be strictly positive."""

    def test_novelty_k_zero_raises(self):
        """novelty_k=0.0 must raise ValueError."""
        with pytest.raises(ValueError, match="novelty_k"):
            GateEvaluator(novelty_k=0.0)

    def test_novelty_k_negative_raises(self):
        """Negative novelty_k must raise ValueError."""
        with pytest.raises(ValueError, match="novelty_k"):
            GateEvaluator(novelty_k=-1.0)

    def test_novelty_k_positive_accepted(self):
        """Positive novelty_k must still be accepted."""
        gate = GateEvaluator(novelty_k=10.0)
        assert gate.novelty_k == 10.0

    def test_novelty_k_small_positive_accepted(self):
        """Small positive novelty_k must be accepted."""
        gate = GateEvaluator(novelty_k=0.001)
        assert gate.novelty_k == 0.001


# =============================================================================
# BH39-L3: JSON-RPC notification with non-string method gets error response
# =============================================================================


class TestBH39L3JsonRpcNotificationNonStringMethod:
    """JSON-RPC notification tests — custom JSON-RPC server removed.

    FastMCP handles JSON-RPC 2.0 protocol details internally.
    These tests verified custom JSON-RPC dispatch which is now handled by the SDK.
    """

    def test_placeholder(self):
        """Placeholder — JSON-RPC dispatch tests removed with server consolidation."""
        pass


# =============================================================================
# BH39-L4: bip322_provider.encode_simple() crashes for signatures >=256 bytes
# =============================================================================


@pytest.mark.skipif(not _HAS_BTCLIB, reason="btclib not installed")
class TestBH39L4EncodeSimpleOversizedSignature:
    """encode_simple must raise a clear ValueError for wrong-size signatures."""

    def test_oversized_signature_raises_value_error(self):
        """2484-byte hybrid signature must raise ValueError with clear message."""
        provider = BIP322Provider()
        big_sig = b"\x00" * 256  # >= 256 bytes — would crash bytes([256])
        with pytest.raises(ValueError, match="64 bytes"):
            provider.encode_simple(big_sig)

    def test_undersized_signature_raises_value_error(self):
        """32-byte signature must raise ValueError with clear message."""
        provider = BIP322Provider()
        small_sig = b"\x00" * 32
        with pytest.raises(ValueError, match="64 bytes"):
            provider.encode_simple(small_sig)

    def test_correct_size_signature_accepted(self):
        """64-byte signature must be accepted without error."""
        provider = BIP322Provider()
        sig = b"\x00" * 64
        encoded = provider.encode_simple(sig)
        assert isinstance(encoded, str)

    def test_empty_signature_raises_value_error(self):
        """Empty signature must raise ValueError."""
        provider = BIP322Provider()
        with pytest.raises(ValueError, match="64 bytes"):
            provider.encode_simple(b"")


# =============================================================================
# BH39-L5: config._parse_mcp_rate_limit silently truncates floats
# =============================================================================


class TestBH39L5McpRateLimitFloatTruncation:
    """_parse_mcp_rate_limit must reject fractional float values."""

    def test_fractional_rate_limit_raises(self):
        """60.9 mcp_rate_limit must raise TypeError, not silently become 60."""
        with pytest.raises(TypeError, match="integer"):
            AegisConfig.from_dict({"mcp_rate_limit": 60.9})

    def test_fractional_small_raises(self):
        """30.5 mcp_rate_limit must raise TypeError."""
        with pytest.raises(TypeError, match="integer"):
            AegisConfig.from_dict({"mcp_rate_limit": 30.5})

    def test_integer_float_accepted(self):
        """60.0 mcp_rate_limit (float but whole number) must be accepted."""
        config = AegisConfig.from_dict({"mcp_rate_limit": 60.0})
        assert config.mcp_rate_limit == 60

    def test_integer_accepted(self):
        """Plain int mcp_rate_limit must still work."""
        config = AegisConfig.from_dict({"mcp_rate_limit": 120})
        assert config.mcp_rate_limit == 120
