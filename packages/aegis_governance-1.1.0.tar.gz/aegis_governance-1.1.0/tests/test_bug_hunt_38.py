"""Regression tests for Bug Hunt #38.

BH38-H1: key_store.py uses Python 3.10+ parenthesized async-with syntax
          (SyntaxError on Python 3.9, the declared minimum supported version)
BH38-M1: UtilityCalculator accepts bool for phi_S, phi_D, gamma, kappa,
          and migration_budget (bool-is-int bypass)
BH38-M2: GateEvaluator accepts bool for risk_trigger_factor,
          profit_trigger_factor, and threshold parameters (bool-is-int bypass)
BH38-M3: CalibrationProposal accepts bool for current_value/proposed_value;
          _validate_gate_param accepts bool without rejection
BH38-M4: MetricsServer.stop() holds _lock during thread.join() — blocks
          concurrent start() for up to 5 seconds
BH38-L1: BatchHTTPSink accepts float/non-int for integer params (Codex fix)
"""

import ast
import threading
import time
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# BH38-H1: Python 3.9 syntax — parenthesized async-with
# ---------------------------------------------------------------------------


class TestBH38H1KeyStoreSyntax:
    """key_store.py must be parseable on Python 3.9 (no parenthesized async-with)."""

    def test_key_store_no_parenthesized_async_with(self):
        """Verify no 'async with (' pattern exists in key_store.py."""
        key_store_path = (
            Path(__file__).parent.parent
            / "src"
            / "workflows"
            / "persistence"
            / "key_store.py"
        )
        source = key_store_path.read_text()
        # Parenthesized async with: 'async with (' followed by newline or space
        import re

        matches = re.findall(r"async\s+with\s*\(", source)
        assert matches == [], (
            f"Found {len(matches)} parenthesized async-with block(s) in key_store.py. "
            "This syntax is Python 3.10+ only and causes SyntaxError on Python 3.9."
        )

    def test_key_store_parses_as_valid_python_39_ast(self):
        """key_store.py AST must parse without errors (catches syntax issues)."""
        key_store_path = (
            Path(__file__).parent.parent
            / "src"
            / "workflows"
            / "persistence"
            / "key_store.py"
        )
        source = key_store_path.read_text()
        # ast.parse validates syntax; will raise SyntaxError for 3.10-only syntax
        tree = ast.parse(source)
        assert tree is not None


# ---------------------------------------------------------------------------
# BH38-M1: UtilityCalculator bool guards
# ---------------------------------------------------------------------------


class TestBH38M1UtilityCalculatorBoolGuards:
    """UtilityCalculator must reject bool for all numeric constructor params."""

    def test_phi_s_bool_true_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(TypeError, match="phi_S must be numeric, got bool"):
            UtilityCalculator(phi_S=True)

    def test_phi_s_bool_false_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(TypeError, match="phi_S must be numeric, got bool"):
            UtilityCalculator(phi_S=False)

    def test_phi_d_bool_true_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(TypeError, match="phi_D must be numeric, got bool"):
            UtilityCalculator(phi_D=True)

    def test_phi_d_bool_false_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(TypeError, match="phi_D must be numeric, got bool"):
            UtilityCalculator(phi_D=False)

    def test_gamma_bool_true_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(TypeError, match="gamma must be numeric, got bool"):
            UtilityCalculator(gamma=True)

    def test_gamma_bool_false_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(TypeError, match="gamma must be numeric, got bool"):
            UtilityCalculator(gamma=False)

    def test_kappa_bool_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(TypeError, match="kappa must be numeric, got bool"):
            UtilityCalculator(kappa=True)

    def test_migration_budget_bool_rejected(self):
        from engine.utility import UtilityCalculator

        with pytest.raises(
            TypeError, match="migration_budget must be numeric, got bool"
        ):
            UtilityCalculator(migration_budget=True)

    def test_valid_float_still_accepted(self):
        """Regression guard: valid float params must still construct successfully."""
        from engine.utility import UtilityCalculator

        calc = UtilityCalculator(gamma=0.5, kappa=1.0, phi_S=200.0, phi_D=3000.0)
        assert calc.gamma == 0.5
        assert calc.phi_S == 200.0


# ---------------------------------------------------------------------------
# BH38-M2: GateEvaluator bool guards
# ---------------------------------------------------------------------------


class TestBH38M2GateEvaluatorBoolGuards:
    """GateEvaluator must reject bool for trigger factors and threshold params."""

    def test_risk_trigger_factor_bool_true_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(
            TypeError, match="risk_trigger_factor must be numeric, got bool"
        ):
            GateEvaluator(risk_trigger_factor=True)

    def test_profit_trigger_factor_bool_false_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(
            TypeError, match="profit_trigger_factor must be numeric, got bool"
        ):
            GateEvaluator(profit_trigger_factor=False)

    def test_novelty_N0_bool_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(TypeError, match="novelty_N0 must be numeric, got bool"):
            GateEvaluator(novelty_N0=True)

    def test_novelty_k_bool_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(TypeError, match="novelty_k must be numeric, got bool"):
            GateEvaluator(novelty_k=False)

    def test_complexity_floor_bool_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(
            TypeError, match="complexity_floor must be numeric, got bool"
        ):
            GateEvaluator(complexity_floor=False)

    def test_novelty_threshold_bool_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(
            TypeError, match="novelty_threshold must be numeric, got bool"
        ):
            GateEvaluator(novelty_threshold=True)

    def test_quality_min_score_bool_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(
            TypeError, match="quality_min_score must be numeric, got bool"
        ):
            GateEvaluator(quality_min_score=False)

    def test_utility_threshold_bool_rejected(self):
        from engine.gates import GateEvaluator

        with pytest.raises(
            TypeError, match="utility_threshold must be numeric, got bool"
        ):
            GateEvaluator(utility_threshold=True)

    def test_trigger_confidence_prob_bool_true_rejected(self):
        """QG-UT1: trigger_confidence_prob=True must be rejected (bool-is-int bypass).

        True == 1.0 which is the inclusive upper bound of validate_range,
        so without an explicit bool guard it silently passed before this fix.
        """
        from engine.gates import GateEvaluator

        with pytest.raises(
            TypeError, match="trigger_confidence_prob must be numeric, got bool"
        ):
            GateEvaluator(trigger_confidence_prob=True)

    def test_valid_gate_evaluator_still_constructs(self):
        """Regression guard: valid numeric params must still construct successfully."""
        from engine.gates import GateEvaluator

        ge = GateEvaluator(risk_trigger_factor=2.0, complexity_floor=0.5)
        assert ge.risk_trigger_factor == 2.0
        assert ge.complexity_floor == 0.5


# ---------------------------------------------------------------------------
# BH38-M3: CalibrationProposal and _validate_gate_param bool guards
# ---------------------------------------------------------------------------


class TestBH38M3CalibrationBoolGuards:
    """CalibrationProposal and _validate_gate_param must reject bool values."""

    def _make_proposal(self, **kwargs):
        from actors.calibrator import CalibrationProposal

        defaults = {
            "proposal_id": "test-prop-001",
            "parameter_name": "epsilon_R",
            "current_value": 0.5,
            "proposed_value": 0.6,
            "justification": "test justification",
            "data_window": 30,
            "statistical_method": "mean",
        }
        defaults.update(kwargs)
        return CalibrationProposal(**defaults)

    def test_proposed_value_bool_true_rejected(self):
        with pytest.raises(TypeError, match="proposed_value must be numeric, got bool"):
            self._make_proposal(proposed_value=True)

    def test_proposed_value_bool_false_rejected(self):
        with pytest.raises(TypeError, match="proposed_value must be numeric, got bool"):
            self._make_proposal(proposed_value=False)

    def test_current_value_bool_true_rejected(self):
        with pytest.raises(TypeError, match="current_value must be numeric, got bool"):
            self._make_proposal(current_value=True)

    def test_current_value_bool_false_rejected(self):
        with pytest.raises(TypeError, match="current_value must be numeric, got bool"):
            self._make_proposal(current_value=False)

    def test_validate_gate_param_bool_rejected(self):
        from actors.calibrator import _validate_gate_param

        with pytest.raises(TypeError, match="epsilon_R must be numeric, got bool"):
            _validate_gate_param("epsilon_R", True)

    def test_validate_gate_param_bool_false_rejected(self):
        from actors.calibrator import _validate_gate_param

        with pytest.raises(
            TypeError, match="complexity_floor must be numeric, got bool"
        ):
            _validate_gate_param("complexity_floor", False)

    def test_valid_calibration_proposal_still_constructs(self):
        """Regression guard: valid float values must still construct successfully."""
        proposal = self._make_proposal(current_value=0.5, proposed_value=0.6)
        assert proposal.proposed_value == 0.6

    def test_validate_gate_param_valid_float_accepted(self):
        from actors.calibrator import _validate_gate_param

        # Should not raise — valid positive float for epsilon_R
        _validate_gate_param("epsilon_R", 0.5)


# ---------------------------------------------------------------------------
# BH38-M4: MetricsServer.stop() lock-held-during-join
# ---------------------------------------------------------------------------


class TestBH38M4MetricsServerLockDuringJoin:
    """MetricsServer.stop() must release lock before join() to avoid deadlock."""

    def test_stop_does_not_hold_lock_during_join(self):
        """Verify stop() releases _lock before calling thread.join().

        Regression: previously stop() held _lock for the entire duration,
        blocking concurrent start() calls for up to 5 seconds.
        """
        from telemetry.metrics_server import MetricsServer

        server = MetricsServer()
        server.start()
        time.sleep(0.05)  # let the server thread settle

        lock_acquired_during_join = []

        original_join = threading.Thread.join

        def patched_join(self_thread, timeout=None):
            # Try to acquire the server lock while join() is in progress
            acquired = server._lock.acquire(blocking=False)
            lock_acquired_during_join.append(acquired)
            if acquired:
                server._lock.release()
            original_join(self_thread, timeout=timeout)

        threading.Thread.join = patched_join  # type: ignore[method-assign]
        try:
            server.stop()
        finally:
            threading.Thread.join = original_join  # type: ignore[method-assign]

        # The lock must have been available (not held) when join() was called
        assert any(lock_acquired_during_join), (
            "MetricsServer._lock was still held during thread.join() — "
            "stop() must release the lock before joining the thread."
        )

    def test_stop_is_idempotent(self):
        """Repeated stop() calls must not raise."""
        from telemetry.metrics_server import MetricsServer

        server = MetricsServer()
        server.start()
        time.sleep(0.05)
        server.stop()
        server.stop()  # second stop must not raise

    def test_stop_without_start_is_safe(self):
        """stop() on a never-started server must not raise."""
        from telemetry.metrics_server import MetricsServer

        server = MetricsServer()
        server.stop()  # must be a no-op


# ---------------------------------------------------------------------------
# BH38-L1: BatchHTTPSink non-integer params (Codex fix — already in emitter.py)
# ---------------------------------------------------------------------------


class TestBH38L1BatchHTTPSinkNonIntegerParams:
    """BatchHTTPSink must reject float/non-int for all integer-typed params."""

    def test_max_retries_float_rejected_at_construction(self):
        """Non-integer max_retries must be caught at init, not at flush() time."""
        from telemetry.emitter import BatchHTTPSink

        with pytest.raises(TypeError, match="max_retries must be an integer"):
            BatchHTTPSink(url="https://example.com/events", max_retries=1.5)

    def test_batch_size_float_rejected(self):
        from telemetry.emitter import BatchHTTPSink

        with pytest.raises(TypeError, match="batch_size must be an integer"):
            BatchHTTPSink(url="https://example.com/events", batch_size=3.0)

    def test_timeout_float_rejected(self):
        from telemetry.emitter import BatchHTTPSink

        with pytest.raises(TypeError, match="timeout must be an integer"):
            BatchHTTPSink(url="https://example.com/events", timeout=10.5)
