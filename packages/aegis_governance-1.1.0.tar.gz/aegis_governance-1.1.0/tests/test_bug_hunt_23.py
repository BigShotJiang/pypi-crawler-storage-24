"""Bug Hunt #23 regression tests.

BH23-M1: cli.py _load_drift_monitor missing bool guard (transport parity)
BH23-M2: cli.py quality_subscores empty list [] treated as default (transport parity)
BH23-M3: calibrator.py _evict_old_proposals called outside lock (race condition)
BH23-L1: cli.py quality_subscores missing isinstance(list) type check
BH23-L2: bayesian.py BayesianPosterior prior_mean accepts NaN/Inf
BH23-L3: consensus.py check_timeout returns True for finalized workflows past deadline
BH23-L4: key_store.py get_private_key missing _audit_lock (TOCTOU with revoke_key)
"""

import json
from types import SimpleNamespace

import pytest

# --- BH23-M1: CLI drift baseline missing bool guard ---


class TestCLIDriftBaselineBoolGuard:
    """BH23-M1: CLI _load_drift_monitor must reject boolean values."""

    def test_drift_baseline_rejects_bool_true(self, tmp_path):
        """Regression: drift baseline with True must raise TypeError."""
        from cli import _load_drift_monitor
        from config import AegisConfig

        baseline_file = tmp_path / "baseline.json"
        baseline_file.write_text(json.dumps([1.0, True, 0.5]))

        args = SimpleNamespace(drift_baseline=str(baseline_file))
        config = AegisConfig()
        with pytest.raises(TypeError, match="got bool"):
            _load_drift_monitor(args, config)

    def test_drift_baseline_rejects_bool_false(self, tmp_path):
        """Regression: drift baseline with False must raise TypeError."""
        from cli import _load_drift_monitor
        from config import AegisConfig

        baseline_file = tmp_path / "baseline.json"
        baseline_file.write_text(json.dumps([1.0, False, 0.5]))

        args = SimpleNamespace(drift_baseline=str(baseline_file))
        config = AegisConfig()
        with pytest.raises(TypeError, match="got bool"):
            _load_drift_monitor(args, config)

    def test_drift_baseline_accepts_numeric(self, tmp_path):
        """Valid numeric values must still be accepted."""
        from cli import _load_drift_monitor
        from config import AegisConfig

        baseline_file = tmp_path / "baseline.json"
        baseline_file.write_text(json.dumps([1.0, 2.0, 0.5]))

        args = SimpleNamespace(drift_baseline=str(baseline_file))
        config = AegisConfig()
        monitor = _load_drift_monitor(args, config)
        assert monitor is not None

    def test_drift_baseline_accepts_null_elements(self, tmp_path):
        """Null elements should be filtered out (not rejected)."""
        from cli import _load_drift_monitor
        from config import AegisConfig

        baseline_file = tmp_path / "baseline.json"
        baseline_file.write_text(json.dumps([1.0, None, 0.5]))

        args = SimpleNamespace(drift_baseline=str(baseline_file))
        config = AegisConfig()
        monitor = _load_drift_monitor(args, config)
        assert monitor is not None


# --- BH23-M2: CLI quality_subscores empty list transport parity ---


class TestCLIQualitySubscoresEmptyList:
    """BH23-M2: CLI must treat explicit [] same as Lambda/MCP (return [])."""

    def test_explicit_empty_list_returns_empty(self):
        """Regression: quality_subscores: [] must produce [] not defaults."""
        from cli import _extract_risk_alias_and_subscores

        data = {"quality_subscores": []}
        kwargs: dict = {}
        _extract_risk_alias_and_subscores(data, kwargs)
        assert kwargs["quality_subscores"] == []

    def test_all_null_list_returns_defaults(self):
        """All-null list must still return default [0.7, 0.7, 0.7]."""
        from cli import _extract_risk_alias_and_subscores

        data = {"quality_subscores": [None, None]}
        kwargs: dict = {}
        _extract_risk_alias_and_subscores(data, kwargs)
        assert kwargs["quality_subscores"] == [0.7, 0.7, 0.7]

    def test_valid_subscores_returned_as_is(self):
        """Valid numeric subscores must be returned unchanged."""
        from cli import _extract_risk_alias_and_subscores

        data = {"quality_subscores": [0.8, 0.9]}
        kwargs: dict = {}
        _extract_risk_alias_and_subscores(data, kwargs)
        assert kwargs["quality_subscores"] == [0.8, 0.9]

    def test_mixed_null_and_valid_returns_valid_only(self):
        """Mixed null and valid subscores should return only valid ones."""
        from cli import _extract_risk_alias_and_subscores

        data = {"quality_subscores": [0.8, None, 0.9]}
        kwargs: dict = {}
        _extract_risk_alias_and_subscores(data, kwargs)
        assert kwargs["quality_subscores"] == [0.8, 0.9]


# --- BH23-L1: CLI quality_subscores missing isinstance(list) type check ---


class TestCLIQualitySubscoresTypeCheck:
    """BH23-L1: CLI must reject non-list quality_subscores with clear error."""

    def test_rejects_string_subscores(self):
        """Regression: string quality_subscores must raise TypeError."""
        from cli import _extract_risk_alias_and_subscores

        data = {"quality_subscores": "0.8,0.9"}
        kwargs: dict = {}
        with pytest.raises(TypeError, match="must be a list"):
            _extract_risk_alias_and_subscores(data, kwargs)

    def test_rejects_numeric_subscores(self):
        """Regression: numeric quality_subscores must raise TypeError."""
        from cli import _extract_risk_alias_and_subscores

        data = {"quality_subscores": 42}
        kwargs: dict = {}
        with pytest.raises(TypeError, match="must be a list"):
            _extract_risk_alias_and_subscores(data, kwargs)

    def test_rejects_dict_subscores(self):
        """Regression: dict quality_subscores must raise TypeError."""
        from cli import _extract_risk_alias_and_subscores

        data = {"quality_subscores": {"a": 0.8}}
        kwargs: dict = {}
        with pytest.raises(TypeError, match="must be a list"):
            _extract_risk_alias_and_subscores(data, kwargs)


# --- BH23-L2: BayesianPosterior prior_mean NaN/Inf validation ---


class TestBayesianPriorMeanValidation:
    """BH23-L2: BayesianPosterior must reject NaN/Inf prior_mean."""

    def test_constructor_rejects_nan_prior_mean(self):
        """Regression: NaN prior_mean must raise ValueError."""
        from engine.bayesian import BayesianPosterior

        with pytest.raises(ValueError, match="prior_mean must be finite"):
            BayesianPosterior(prior_mean=float("nan"))

    def test_constructor_rejects_inf_prior_mean(self):
        """Regression: Inf prior_mean must raise ValueError."""
        from engine.bayesian import BayesianPosterior

        with pytest.raises(ValueError, match="prior_mean must be finite"):
            BayesianPosterior(prior_mean=float("inf"))

    def test_constructor_rejects_neg_inf_prior_mean(self):
        """Regression: -Inf prior_mean must raise ValueError."""
        from engine.bayesian import BayesianPosterior

        with pytest.raises(ValueError, match="prior_mean must be finite"):
            BayesianPosterior(prior_mean=float("-inf"))

    def test_constructor_accepts_zero_prior_mean(self):
        """Zero is a valid prior_mean."""
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior(prior_mean=0.0)
        assert bp.prior_mean == 0.0

    def test_constructor_accepts_negative_prior_mean(self):
        """Negative values are valid prior_mean."""
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior(prior_mean=-1.5)
        assert bp.prior_mean == -1.5

    def test_compute_posterior_rejects_nan_override(self):
        """Regression: NaN prior_mean override must raise ValueError."""
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior(prior_mean=0.0)
        with pytest.raises(ValueError, match="prior_mean must be finite"):
            bp.compute_posterior(
                observed_delta=1.0,
                trigger_threshold=2.0,
                prior_mean=float("nan"),
            )

    def test_compute_posterior_rejects_inf_override(self):
        """Regression: Inf prior_mean override must raise ValueError."""
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior(prior_mean=0.0)
        with pytest.raises(ValueError, match="prior_mean must be finite"):
            bp.compute_posterior(
                observed_delta=1.0,
                trigger_threshold=2.0,
                prior_mean=float("inf"),
            )

    def test_compute_full_rejects_nan_override(self):
        """Regression: compute_full with NaN prior_mean override must raise."""
        from engine.bayesian import BayesianPosterior

        bp = BayesianPosterior(prior_mean=0.0)
        with pytest.raises(ValueError, match="prior_mean must be finite"):
            bp.compute_full(
                observed_delta=1.0,
                trigger_threshold=2.0,
                prior_mean=float("nan"),
            )


# --- BH23-M3: Calibrator _evict_old_proposals called inside lock ---


class TestCalibratorEvictionUnderLock:
    """BH23-M3: _evict_old_proposals must run inside self._lock."""

    def test_eviction_runs_under_lock_gate_threshold(self):
        """Regression: propose_gate_threshold evicts inside lock."""
        from actors.calibrator import Calibrator

        cal = Calibrator(actor_id="cal-1", name="Test", history_limit=2)
        # Fill beyond history_limit to trigger eviction
        for i in range(3):
            cal.propose_gate_threshold(
                proposal_id=f"p{i}",
                parameter_name="epsilon_risk",
                current_value=0.1,
                proposed_value=0.2,
                justification="test",
                data_window=100,
                statistical_method="percentile_p90",
            )

        # Verify eviction happened (only 2 remain due to history_limit=2)
        assert len(cal.proposals) <= 2

    def test_eviction_runs_under_lock_drift_calibration(self):
        """Regression: propose_drift_calibration evicts inside lock."""
        from actors.calibrator import Calibrator
        from engine.drift import DriftMonitor

        cal = Calibrator(actor_id="cal-2", name="Test", history_limit=2)
        dm = DriftMonitor()
        dm.set_baseline([1.0, 2.0, 3.0])

        for i in range(3):
            cal.propose_drift_calibration(
                proposal_id=f"d{i}",
                drift_detector=dm,
                historical_kl_values=[0.1, 0.2, 0.3, 0.4, 0.5],
            )

        assert len(cal.proposals) <= 4  # 2 proposals * 2 sub-IDs max

    def test_concurrent_propose_no_crash(self):
        """Regression: concurrent proposals must not crash from race."""
        import threading

        from actors.calibrator import Calibrator

        cal = Calibrator(actor_id="cal-3", name="Test", history_limit=5)
        errors: list[str] = []

        def propose(tid: int) -> None:
            try:
                for j in range(10):
                    cal.propose_gate_threshold(
                        proposal_id=f"t{tid}_p{j}",
                        parameter_name="epsilon_risk",
                        current_value=0.1,
                        proposed_value=0.2,
                        justification="concurrent test",
                        data_window=100,
                        statistical_method="percentile_p90",
                    )
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=propose, args=(i,)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent errors: {errors}"


# --- BH23-L3: ConsensusWorkflow.check_timeout misleading return ---


class TestConsensusCheckTimeoutReturn:
    """BH23-L3: check_timeout must return False for finalized non-timeout workflows."""

    def _make_expired_workflow(self, proposal_id: str):
        """Create a ConsensusWorkflow with deadline already in the past."""
        from datetime import datetime, timedelta, timezone

        from workflows.consensus import ConsensusConfig, ConsensusWorkflow

        config = ConsensusConfig(
            approval_threshold=0.5,
            timeout_hours=1,
        )
        wf = ConsensusWorkflow(
            proposal_id=proposal_id,
            eligible_voters={"v1", "v2"},
            config=config,
        )
        # Force deadline into the past
        wf.deadline = datetime.now(timezone.utc) - timedelta(hours=1)
        return wf

    def test_approved_workflow_past_deadline_returns_false(self):
        """Regression: approved workflow past deadline must NOT report timeout."""
        from datetime import datetime, timezone

        from workflows.consensus import ConsensusState

        wf = self._make_expired_workflow("test-1")
        wf.state = ConsensusState.APPROVED
        wf._finalized_at = datetime.now(timezone.utc)

        result = wf.check_timeout()
        assert result is False, "Approved workflow should not report timeout"

    def test_rejected_workflow_past_deadline_returns_false(self):
        """Regression: rejected workflow past deadline must NOT report timeout."""
        from datetime import datetime, timezone

        from workflows.consensus import ConsensusState

        wf = self._make_expired_workflow("test-2")
        wf.state = ConsensusState.REJECTED
        wf._finalized_at = datetime.now(timezone.utc)

        result = wf.check_timeout()
        assert result is False, "Rejected workflow should not report timeout"

    def test_timeout_workflow_past_deadline_returns_true(self):
        """Already-timed-out workflow past deadline must still return True."""
        from workflows.consensus import ConsensusState

        wf = self._make_expired_workflow("test-3")
        wf.state = ConsensusState.TIMEOUT

        result = wf.check_timeout()
        assert result is True

    def test_pending_workflow_past_deadline_transitions_and_returns_true(self):
        """Pending workflow past deadline must transition to TIMEOUT and return True."""
        from workflows.consensus import ConsensusState

        wf = self._make_expired_workflow("test-4")

        result = wf.check_timeout()
        assert result is True
        assert wf.state == ConsensusState.TIMEOUT


# --- BH23-L4: KeyStoreRepository get_private_key missing _audit_lock ---


class TestKeyStoreAuditLockOnRead:
    """BH23-L4: get_private_key/get_public_key must acquire _audit_lock."""

    @pytest.mark.asyncio
    async def test_get_private_key_acquires_audit_lock(self):
        """Regression: get_private_key must hold _audit_lock during execution."""
        try:
            from workflows.persistence.key_store import KeyStoreRepository
        except ImportError:
            pytest.skip("persistence deps not available")
        from unittest.mock import AsyncMock, MagicMock, patch

        repo = KeyStoreRepository.__new__(KeyStoreRepository)
        repo._audit_lock = __import__("asyncio").Lock()
        repo._kek_provider = MagicMock()
        repo._kek_provider.decrypt.return_value = b"private-key-bytes"

        mock_key = MagicMock()
        mock_key.encrypted_private_key = b"encrypted"
        mock_key.master_kek_version = 1
        mock_key.revoked_at = None

        mock_session = AsyncMock()

        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def mock_session_factory():
            yield mock_session

        repo._session_factory = mock_session_factory

        with patch.object(repo, "_get_active_key", return_value=mock_key):
            # Verify it works (doesn't deadlock or error)
            result = await repo.get_private_key("risk_lead", "bip322-simple")
            assert result == b"private-key-bytes"

    @pytest.mark.asyncio
    async def test_get_private_key_returns_none_for_revoked_active(self):
        """Regression: get_private_key (version=None) must return None for revoked keys."""
        try:
            from workflows.persistence.key_store import KeyStoreRepository
        except ImportError:
            pytest.skip("persistence deps not available")
        from unittest.mock import AsyncMock, MagicMock, patch

        repo = KeyStoreRepository.__new__(KeyStoreRepository)
        repo._audit_lock = __import__("asyncio").Lock()
        repo._kek_provider = MagicMock()

        mock_key = MagicMock()
        mock_key.revoked_at = __import__("datetime").datetime.now(
            __import__("datetime").timezone.utc
        )

        mock_session = AsyncMock()

        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def mock_session_factory():
            yield mock_session

        repo._session_factory = mock_session_factory

        with patch.object(repo, "_get_active_key", return_value=mock_key):
            # version=None triggers the TOCTOU guard
            result = await repo.get_private_key("risk_lead", "bip322-simple")
            assert result is None, "Revoked active key must return None"

    @pytest.mark.asyncio
    async def test_get_public_key_returns_none_for_revoked_active(self):
        """Regression: get_public_key (version=None) must return None for revoked keys."""
        try:
            from workflows.persistence.key_store import KeyStoreRepository
        except ImportError:
            pytest.skip("persistence deps not available")
        from unittest.mock import AsyncMock, MagicMock, patch

        repo = KeyStoreRepository.__new__(KeyStoreRepository)
        repo._audit_lock = __import__("asyncio").Lock()

        mock_key = MagicMock()
        mock_key.revoked_at = __import__("datetime").datetime.now(
            __import__("datetime").timezone.utc
        )
        mock_key.public_key = b"pub-key"

        mock_session = AsyncMock()

        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def mock_session_factory():
            yield mock_session

        repo._session_factory = mock_session_factory

        with patch.object(repo, "_get_active_key", return_value=mock_key):
            # version=None triggers the TOCTOU guard
            result = await repo.get_public_key("risk_lead", "bip322-simple")
            assert result is None, "Revoked active key must return None"
