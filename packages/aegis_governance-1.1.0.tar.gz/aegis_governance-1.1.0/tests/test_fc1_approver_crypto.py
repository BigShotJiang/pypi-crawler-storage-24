"""
FC-1: BIP-322 Signature Validation in Approver Actor

Regression tests for wiring BIP-322 cryptographic signature verification
into the Approver.authorize_override() flow. Covers:

- Valid BIP-322 signature: sign, verify, authorize succeeds
- Invalid signature: bad sig bytes, authorize fails
- No verifier fallback: no verifier configured, legacy non-empty check
- No public key with verifier: verifier present but no pubkey, falls back
- Malformed base64: decode failure returns clear error

Tests are skipped if btclib is not installed (optional crypto dependency).
"""

import pytest

# Skip entire module if btclib is not available
btclib = pytest.importorskip("btclib")

from actors.approver import Approver  # noqa: E402
from crypto.bip322_provider import BIP322Provider  # noqa: E402


@pytest.fixture
def provider() -> BIP322Provider:
    """Create a BIP322Provider instance."""
    return BIP322Provider()


@pytest.fixture
def keypair(provider: BIP322Provider) -> tuple[bytes, bytes]:
    """Generate a secp256k1 keypair (private_key, public_key)."""
    return provider.generate_keypair()


class TestFC1ApproverCryptoVerification:
    """FC-1: BIP-322 signature validation wired into Approver.authorize_override()."""

    def test_authorize_override_valid_bip322_signature(
        self,
        provider: BIP322Provider,
        keypair: tuple[bytes, bytes],
    ) -> None:
        """A correctly signed override with valid BIP-322 signature should succeed."""
        private_key, public_key = keypair

        approver = Approver(
            "ap-crypto-1",
            "Carol (Risk Lead)",
            is_risk_lead=True,
            signature_verifier=provider,
        )

        proposal_id = "prop-fc1-valid"
        justification = "Critical production hotfix"
        failed_gates = ["risk", "profit"]

        # Sign the canonical message
        message_hash = provider.create_message_hash(
            proposal_id, justification, failed_gates
        )
        raw_signature = provider.sign(message_hash, private_key)
        encoded_signature = provider.encode_simple(raw_signature)

        result = approver.authorize_override(
            proposal_id=proposal_id,
            failed_gates=failed_gates,
            justification=justification,
            signature=encoded_signature,
            public_key=public_key,
        )

        assert result.success is True
        assert result.result_data["proposal_id"] == proposal_id
        assert result.result_data["role"] == "risk_lead"
        assert result.result_data["crypto_verified"] is True
        assert proposal_id in approver.overrides_authorized

    def test_authorize_override_invalid_signature_rejected(
        self,
        provider: BIP322Provider,
        keypair: tuple[bytes, bytes],
    ) -> None:
        """An override with a cryptographically invalid signature must be rejected."""
        _private_key, public_key = keypair

        approver = Approver(
            "ap-crypto-2",
            "Dave (Security Lead)",
            is_security_lead=True,
            signature_verifier=provider,
        )

        proposal_id = "prop-fc1-bad-sig"
        justification = "Attempted bypass"
        failed_gates = ["risk"]

        # Create a valid-looking but wrong signature (64 zero bytes, encoded)
        bad_signature_bytes = b"\x00" * 64
        bad_encoded = provider.encode_simple(bad_signature_bytes)

        result = approver.authorize_override(
            proposal_id=proposal_id,
            failed_gates=failed_gates,
            justification=justification,
            signature=bad_encoded,
            public_key=public_key,
        )

        assert result.success is False
        assert "verification failed" in result.error.lower()
        assert proposal_id not in approver.overrides_authorized

    def test_authorize_override_no_verifier_fallback(self) -> None:
        """Without a verifier, authorize_override falls back to non-empty string check."""
        approver = Approver(
            "ap-legacy-1",
            "Eve (Risk Lead)",
            is_risk_lead=True,
            # No signature_verifier -- legacy mode
        )

        # Non-empty string should pass legacy check
        result_pass = approver.authorize_override(
            proposal_id="prop-fc1-legacy-pass",
            failed_gates=["risk"],
            justification="Legacy path test",
            signature="some-non-empty-signature",
        )
        assert result_pass.success is True
        assert result_pass.result_data["crypto_verified"] is False

        # Empty string should fail legacy check
        result_fail = approver.authorize_override(
            proposal_id="prop-fc1-legacy-fail",
            failed_gates=["risk"],
            justification="Legacy path test",
            signature="",
        )
        assert result_fail.success is False
        assert "signature" in result_fail.error.lower()

    def test_authorize_override_no_public_key_with_verifier(
        self,
        provider: BIP322Provider,
    ) -> None:
        """Verifier present but no public_key falls back to legacy non-empty check."""
        approver = Approver(
            "ap-nopub-1",
            "Frank (Risk Lead)",
            is_risk_lead=True,
            signature_verifier=provider,
        )

        # With verifier but without public_key, should use legacy path
        result_pass = approver.authorize_override(
            proposal_id="prop-fc1-nopub",
            failed_gates=["profit"],
            justification="No pubkey provided",
            signature="legacy-string-sig",
            # public_key omitted (defaults to None)
        )
        assert result_pass.success is True
        assert result_pass.result_data["crypto_verified"] is False

        # Empty string should still fail in legacy path
        result_fail = approver.authorize_override(
            proposal_id="prop-fc1-nopub-fail",
            failed_gates=["profit"],
            justification="No pubkey, empty sig",
            signature="",
        )
        assert result_fail.success is False
        assert "signature" in result_fail.error.lower()

    def test_authorize_override_malformed_base64_rejected(
        self,
        provider: BIP322Provider,
        keypair: tuple[bytes, bytes],
    ) -> None:
        """Malformed base64 signature should fail with a decode error."""
        _private_key, public_key = keypair

        approver = Approver(
            "ap-crypto-3",
            "Grace (Risk Lead)",
            is_risk_lead=True,
            signature_verifier=provider,
        )

        result = approver.authorize_override(
            proposal_id="prop-fc1-malformed",
            failed_gates=["risk"],
            justification="Malformed sig test",
            signature="not-valid-base64!!!",
            public_key=public_key,
        )

        assert result.success is False
        assert "decode failed" in result.error.lower()
        assert "prop-fc1-malformed" not in approver.overrides_authorized

    def test_authorize_override_wrong_key_rejected(
        self,
        provider: BIP322Provider,
        keypair: tuple[bytes, bytes],
    ) -> None:
        """Signature signed by one key must fail verification against a different key."""
        private_key, _public_key = keypair
        # Generate a second keypair -- verify against the wrong public key
        _private_key2, public_key2 = provider.generate_keypair()

        approver = Approver(
            "ap-crypto-4",
            "Hank (Security Lead)",
            is_security_lead=True,
            signature_verifier=provider,
        )

        proposal_id = "prop-fc1-wrong-key"
        justification = "Wrong key test"
        failed_gates = ["risk"]

        message_hash = provider.create_message_hash(
            proposal_id, justification, failed_gates
        )
        raw_signature = provider.sign(message_hash, private_key)
        encoded_signature = provider.encode_simple(raw_signature)

        # Verify against public_key2 (not the one that signed)
        result = approver.authorize_override(
            proposal_id=proposal_id,
            failed_gates=failed_gates,
            justification=justification,
            signature=encoded_signature,
            public_key=public_key2,
        )

        assert result.success is False
        assert "verification failed" in result.error.lower()

    def test_authorize_override_security_lead_valid_signature(
        self,
        provider: BIP322Provider,
        keypair: tuple[bytes, bytes],
    ) -> None:
        """Security Lead (not just Risk Lead) can also use crypto verification."""
        private_key, public_key = keypair

        approver = Approver(
            "ap-crypto-5",
            "Iris (Security Lead)",
            is_security_lead=True,
            signature_verifier=provider,
        )

        proposal_id = "prop-fc1-sec-lead"
        justification = "Security lead override"
        failed_gates = ["profit"]

        message_hash = provider.create_message_hash(
            proposal_id, justification, failed_gates
        )
        raw_signature = provider.sign(message_hash, private_key)
        encoded_signature = provider.encode_simple(raw_signature)

        result = approver.authorize_override(
            proposal_id=proposal_id,
            failed_gates=failed_gates,
            justification=justification,
            signature=encoded_signature,
            public_key=public_key,
        )

        assert result.success is True
        assert result.result_data["role"] == "security_lead"
        assert result.result_data["crypto_verified"] is True
