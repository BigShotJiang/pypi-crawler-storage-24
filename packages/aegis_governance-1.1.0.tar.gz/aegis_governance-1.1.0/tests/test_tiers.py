"""Tests for AEGIS Tier Definitions (Phase 2a).

Tests cover:
- TierDefinition dataclass immutability and serialization
- Tier registry completeness and feature hierarchy
- Alias resolution (free → community, pro → professional)
- Invalid tier rejection
- Tier lookup via get_tier()
"""

from __future__ import annotations

import pytest

from aegis_governance.tiers import (
    COMMUNITY,
    ENTERPRISE,
    FINANCIAL_SERVICES,
    PROFESSIONAL,
    TIERS,
    VALID_TIER_NAMES,
    get_tier,
    resolve_tier_name,
)

# ---------------------------------------------------------------------------
# TierDefinition tests
# ---------------------------------------------------------------------------


class TestTierDefinition:
    """Test TierDefinition dataclass."""

    def test_frozen_immutability(self) -> None:
        with pytest.raises(AttributeError):
            COMMUNITY.name = "hacked"  # type: ignore[misc]

    def test_to_dict_includes_all_fields(self) -> None:
        d = COMMUNITY.to_dict()
        assert d["name"] == "community"
        assert d["display_name"] == "Community"
        assert d["monthly_evaluations"] == 100
        assert d["rate_per_minute"] == 10
        assert d["max_keys"] == 1
        assert d["overage_per_eval"] == 0.0
        assert d["monthly_price_usd"] == 0
        assert isinstance(d["features"], list)
        assert "gates" in d["features"]

    def test_features_are_sorted_in_dict(self) -> None:
        d = PROFESSIONAL.to_dict()
        assert d["features"] == sorted(d["features"])


# ---------------------------------------------------------------------------
# Tier registry tests
# ---------------------------------------------------------------------------


class TestTierRegistry:
    """Test tier registry completeness and hierarchy."""

    def test_four_canonical_tiers(self) -> None:
        assert set(TIERS.keys()) == {
            "community",
            "professional",
            "enterprise",
            "financial_services",
        }

    def test_tier_ordering_by_price(self) -> None:
        prices = [t.monthly_price_usd for t in TIERS.values()]
        assert prices == sorted(prices)

    def test_tier_ordering_by_evaluations(self) -> None:
        evals = [t.monthly_evaluations for t in TIERS.values()]
        assert evals == sorted(evals)

    def test_tier_ordering_by_rate(self) -> None:
        rates = [t.rate_per_minute for t in TIERS.values()]
        assert rates == sorted(rates)

    def test_tier_ordering_by_keys(self) -> None:
        keys = [t.max_keys for t in TIERS.values()]
        assert keys == sorted(keys)

    def test_feature_hierarchy_superset(self) -> None:
        """Higher tiers must be supersets of lower tiers."""
        assert COMMUNITY.features <= PROFESSIONAL.features
        assert PROFESSIONAL.features <= ENTERPRISE.features
        assert ENTERPRISE.features <= FINANCIAL_SERVICES.features

    def test_community_is_free(self) -> None:
        assert COMMUNITY.monthly_price_usd == 0
        assert COMMUNITY.overage_per_eval == 0.0

    def test_professional_pricing(self) -> None:
        assert PROFESSIONAL.monthly_price_usd == 3_500
        assert PROFESSIONAL.monthly_evaluations == 10_000
        assert PROFESSIONAL.overage_per_eval == 0.25

    def test_enterprise_pricing(self) -> None:
        assert ENTERPRISE.monthly_price_usd == 18_000
        assert ENTERPRISE.monthly_evaluations == 100_000

    def test_financial_services_pricing(self) -> None:
        assert FINANCIAL_SERVICES.monthly_price_usd == 50_000
        assert FINANCIAL_SERVICES.monthly_evaluations == 250_000

    def test_valid_tier_names_include_aliases(self) -> None:
        assert "free" in VALID_TIER_NAMES
        assert "pro" in VALID_TIER_NAMES
        assert "community" in VALID_TIER_NAMES
        assert "professional" in VALID_TIER_NAMES


# ---------------------------------------------------------------------------
# Alias resolution tests
# ---------------------------------------------------------------------------


class TestTierAliases:
    """Test backward-compatible tier name aliases."""

    def test_free_resolves_to_community(self) -> None:
        assert resolve_tier_name("free") == "community"

    def test_pro_resolves_to_professional(self) -> None:
        assert resolve_tier_name("pro") == "professional"

    def test_canonical_names_pass_through(self) -> None:
        assert resolve_tier_name("community") == "community"
        assert resolve_tier_name("professional") == "professional"
        assert resolve_tier_name("enterprise") == "enterprise"
        assert resolve_tier_name("financial_services") == "financial_services"

    def test_invalid_tier_raises_value_error(self) -> None:
        with pytest.raises(ValueError, match="Invalid tier"):
            resolve_tier_name("platinum")

    def test_empty_tier_raises_value_error(self) -> None:
        with pytest.raises(ValueError, match="Invalid tier"):
            resolve_tier_name("")


# ---------------------------------------------------------------------------
# get_tier() tests
# ---------------------------------------------------------------------------


class TestGetTier:
    """Test get_tier() lookup function."""

    def test_get_by_canonical_name(self) -> None:
        assert get_tier("enterprise") is ENTERPRISE

    def test_get_by_alias(self) -> None:
        assert get_tier("free") is COMMUNITY
        assert get_tier("pro") is PROFESSIONAL

    def test_get_invalid_raises(self) -> None:
        with pytest.raises(ValueError):
            get_tier("gold")

    def test_get_tier_returns_same_instance(self) -> None:
        """Frozen instances should be reused, not copied."""
        assert get_tier("community") is get_tier("free")
