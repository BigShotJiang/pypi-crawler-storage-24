"""Regression tests for Bug Hunt #36.

BH36-M1 (Codex): Lambda `or` pattern for estimated_impact/phase bypasses
    type check for falsy non-string values (False, 0).
BH36-M2: mark_completed(final_state="aborted") injects non-enum state into
    serialized request.state, breaking from_dict() deserialization.
BH36-M3: CLI `or` pattern for estimated_impact — same class as M1.
BH36-M4: MCP `or` pattern for estimated_impact — same class as M1.
BH36-L1: compute_complexity_tax missing bool guard for phi_S/phi_D.
BH36-L2: Lambda/CLI proposal_summary `or` pattern accepts falsy non-strings.
"""

import json

import pytest

from engine.complexity import ComplexityDecomposer

# ---------------------------------------------------------------------------
# BH36-M1 (Codex): Lambda estimated_impact/phase falsy bypass
# ---------------------------------------------------------------------------
# Codex already added test_falsy_boolean_estimated_impact_rejected in
# tests/infra/test_lambda_handler.py. Additional Lambda tests here.


class TestBH36M1LambdaPhaseOr:
    """Lambda phase=False must be rejected, not defaulted via `or`."""

    def test_false_phase_rejected(self):
        """phase=False (bool) must not be silently coerced to 'plan'."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "headers": {},
            "queryStringParameters": None,
            "pathParameters": None,
            "body": json.dumps({"proposal_summary": "test", "phase": False}),
            "isBase64Encoded": False,
        }

        class Ctx:
            pass

        response = handler(event, Ctx())
        assert (
            response["statusCode"] == 400
        ), "phase=False must be rejected as non-string"

    def test_zero_phase_rejected(self):
        """phase=0 (int) must not be silently coerced to 'plan'."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "headers": {},
            "queryStringParameters": None,
            "pathParameters": None,
            "body": json.dumps({"proposal_summary": "test", "phase": 0}),
            "isBase64Encoded": False,
        }

        class Ctx:
            pass

        response = handler(event, Ctx())
        assert response["statusCode"] == 400


# ---------------------------------------------------------------------------
# BH36-M2: mark_completed non-enum final_state
# ---------------------------------------------------------------------------


class TestBH36M2MarkCompletedNonEnumState:
    """mark_completed must not inject non-enum final_state into request.state."""

    @pytest.mark.asyncio
    async def test_aborted_preserves_request_state(self, tmp_path):
        """Aborting a workflow must NOT write 'aborted' into request.state."""
        try:
            from workflows.persistence.engine import DatabaseConfig
            from workflows.persistence.repository import WorkflowPersistence
        except ImportError:
            pytest.skip("persistence deps not available")

        db_path = tmp_path / "test.db"
        config = DatabaseConfig(
            url=f"sqlite+aiosqlite:///{db_path}",
            pool_size=1,
        )

        # Use a simple object satisfying SerializableWorkflow protocol
        class _FakeWorkflow:
            def __init__(self, wid, state, state_data):
                self._wid = wid
                self._state = state
                self._state_data = state_data

            @property
            def workflow_id(self):
                return self._wid

            @property
            def workflow_type(self):
                return "override"

            @property
            def current_state(self):
                return self._state

            def to_dict(self):
                return dict(self._state_data)

        workflow_id = "test-abort-enum"
        state_data = {
            "state": "pending",
            "current_state": "pending",
            "request": {"state": "pending", "proposal_id": workflow_id},
        }

        async with WorkflowPersistence(config) as persistence:
            wf = _FakeWorkflow(workflow_id, "pending", state_data)
            await persistence.save_checkpoint(wf, actor_id="test")

            # Abort it
            await persistence.mark_completed(
                workflow_id=workflow_id,
                actor_id="test",
                final_state="aborted",
            )

            # Load and verify request.state was NOT overwritten to "aborted"
            loaded = await persistence.load_checkpoint(workflow_id)
            assert loaded is not None
            assert loaded["current_state"] == "aborted"  # top-level is fine
            # request.state must remain the last valid enum value
            assert (
                loaded["request"]["state"] == "pending"
            ), "request.state must NOT be overwritten with non-enum 'aborted'"

    @pytest.mark.asyncio
    async def test_valid_enum_state_still_updates_request(self, tmp_path):
        """Valid enum final_state should still update request.state."""
        try:
            from workflows.persistence.engine import DatabaseConfig
            from workflows.persistence.repository import WorkflowPersistence
        except ImportError:
            pytest.skip("persistence deps not available")

        db_path = tmp_path / "test.db"
        config = DatabaseConfig(
            url=f"sqlite+aiosqlite:///{db_path}",
            pool_size=1,
        )

        class _FakeWorkflow:
            def __init__(self, wid, state, state_data):
                self._wid = wid
                self._state = state
                self._state_data = state_data

            @property
            def workflow_id(self):
                return self._wid

            @property
            def workflow_type(self):
                return "override"

            @property
            def current_state(self):
                return self._state

            def to_dict(self):
                return dict(self._state_data)

        workflow_id = "test-valid-enum"
        state_data = {
            "state": "pending",
            "current_state": "pending",
            "request": {"state": "pending", "proposal_id": workflow_id},
        }

        async with WorkflowPersistence(config) as persistence:
            wf = _FakeWorkflow(workflow_id, "pending", state_data)
            await persistence.save_checkpoint(wf, actor_id="test")

            # Complete with a valid OverrideState
            await persistence.mark_completed(
                workflow_id=workflow_id,
                actor_id="test",
                final_state="approved",
            )

            loaded = await persistence.load_checkpoint(workflow_id)
            assert loaded is not None
            assert loaded["request"]["state"] == "approved"


# ---------------------------------------------------------------------------
# BH36-M3: CLI estimated_impact `or` bypass
# ---------------------------------------------------------------------------


class TestBH36M3CLIEstimatedImpactOr:
    """CLI must reject falsy non-string estimated_impact."""

    def test_false_estimated_impact_rejected(self):
        """estimated_impact=False must raise TypeError, not default to 'medium'."""
        from cli import _parse_proposal

        with pytest.raises(TypeError, match="estimated_impact must be a string"):
            _parse_proposal({"estimated_impact": False})

    def test_zero_estimated_impact_rejected(self):
        """estimated_impact=0 must raise TypeError."""
        from cli import _parse_proposal

        with pytest.raises(TypeError, match="estimated_impact must be a string"):
            _parse_proposal({"estimated_impact": 0})

    def test_null_estimated_impact_defaults(self):
        """estimated_impact=None must default to 'medium'."""
        from cli import _parse_proposal

        result = _parse_proposal({"estimated_impact": None})
        assert result["estimated_impact"] == "medium"


# ---------------------------------------------------------------------------
# BH36-M4: MCP estimated_impact `or` bypass
# ---------------------------------------------------------------------------


class TestBH36M4MCPEstimatedImpactOr:
    """MCP must not coerce falsy non-strings via `or` for estimated_impact."""

    def test_false_estimated_impact_defaults_to_medium(self):
        """MCP estimated_impact=False should get 'medium' default, not 'False' string."""
        # The MCP wraps with str(), so False would become "False" with old code.
        # With the fix, it should default to "medium".
        # Simulate the fixed logic from mcp_server.py
        arguments = {"estimated_impact": False}
        raw = arguments.get("estimated_impact")
        is_valid = isinstance(raw, str) and raw
        result = str(raw) if is_valid else "medium"
        assert result == "medium", "False should not pass isinstance(str) check"

    def test_none_estimated_impact_defaults(self):
        """MCP estimated_impact=None should default to 'medium'."""
        arguments = {"estimated_impact": None}
        raw = arguments.get("estimated_impact")
        is_valid = isinstance(raw, str) and raw
        result = str(raw) if is_valid else "medium"
        assert result == "medium"


# ---------------------------------------------------------------------------
# BH36-L1: compute_complexity_tax bool guard
# ---------------------------------------------------------------------------


class TestBH36L1ComplexityTaxBoolGuard:
    """compute_complexity_tax must reject bool for phi_S and phi_D."""

    def test_phi_s_bool_rejected(self):
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 10, "dynamic_delta": 5}
        with pytest.raises(TypeError, match="phi_S must be numeric, got bool"):
            decomposer.compute_complexity_tax(delta, phi_S=True)

    def test_phi_d_bool_rejected(self):
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 10, "dynamic_delta": 5}
        with pytest.raises(TypeError, match="phi_D must be numeric, got bool"):
            decomposer.compute_complexity_tax(delta, phi_D=True)

    def test_phi_s_false_rejected(self):
        """False (0.0) must not silently disable complexity costing."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 10, "dynamic_delta": 5}
        with pytest.raises(TypeError, match="phi_S must be numeric, got bool"):
            decomposer.compute_complexity_tax(delta, phi_S=False)

    def test_phi_d_false_rejected(self):
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 10, "dynamic_delta": 5}
        with pytest.raises(TypeError, match="phi_D must be numeric, got bool"):
            decomposer.compute_complexity_tax(delta, phi_D=False)

    def test_valid_float_still_works(self):
        """Normal float values must still work."""
        decomposer = ComplexityDecomposer()
        delta = {"static_delta": 10.0, "dynamic_delta": 5.0}
        result = decomposer.compute_complexity_tax(delta, phi_S=100.0, phi_D=2000.0)
        assert isinstance(result, (int, float))  # returns total cost as number


# ---------------------------------------------------------------------------
# BH36-L2: Lambda/CLI proposal_summary `or` pattern
# ---------------------------------------------------------------------------


class TestBH36L2ProposalSummaryOr:
    """proposal_summary=False must use default, not coerce to 'False'."""

    def test_lambda_false_proposal_summary_uses_default(self):
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/evaluate",
            "headers": {},
            "queryStringParameters": None,
            "pathParameters": None,
            "body": json.dumps({"proposal_summary": False}),
            "isBase64Encoded": False,
        }

        class Ctx:
            pass

        response = handler(event, Ctx())
        # Should succeed with default summary, not crash or use "False"
        assert response["statusCode"] == 200
        body = json.loads(response["body"])
        # The summary should be the default, not the string "False"
        assert body.get("decision_trace", {}).get("proposal_summary") != "False"

    def test_cli_false_proposal_summary_uses_default(self):
        from cli import _parse_proposal

        result = _parse_proposal({"proposal_summary": False})
        assert result["proposal_summary"] == "CLI evaluation"

    def test_cli_zero_proposal_summary_uses_default(self):
        from cli import _parse_proposal

        result = _parse_proposal({"proposal_summary": 0})
        assert result["proposal_summary"] == "CLI evaluation"

    def test_cli_valid_string_preserved(self):
        from cli import _parse_proposal

        result = _parse_proposal({"proposal_summary": "my proposal"})
        assert result["proposal_summary"] == "my proposal"
