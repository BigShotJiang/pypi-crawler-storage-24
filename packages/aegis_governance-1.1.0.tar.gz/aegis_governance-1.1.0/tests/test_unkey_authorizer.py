"""Tests for AEGIS Lambda Authorizer (Phase 2b).

Tests cover:
- Bearer token extraction
- Policy document generation (Allow/Deny)
- Unkey verification integration (mocked)
- Customer context injection in policy
- Graceful denial on errors
- ARN wildcard handling
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

# Test ARN for API Gateway method
_TEST_METHOD_ARN = "arn:aws:execute-api:us-west-2:123456789:abc123/dev/POST/evaluate"


# ---------------------------------------------------------------------------
# Policy builder tests
# ---------------------------------------------------------------------------


class TestBuildPolicy:
    """Test _build_policy helper."""

    def test_allow_policy(self) -> None:
        from aegis_governance.unkey_authorizer import _build_policy

        policy = _build_policy("cust_abc", "Allow", _TEST_METHOD_ARN)
        assert policy["principalId"] == "cust_abc"
        stmt = policy["policyDocument"]["Statement"][0]
        assert stmt["Effect"] == "Allow"
        assert stmt["Action"] == "execute-api:Invoke"

    def test_deny_policy(self) -> None:
        from aegis_governance.unkey_authorizer import _build_policy

        policy = _build_policy("anonymous", "Deny", _TEST_METHOD_ARN)
        assert policy["principalId"] == "anonymous"
        stmt = policy["policyDocument"]["Statement"][0]
        assert stmt["Effect"] == "Deny"

    def test_arn_wildcard(self) -> None:
        from aegis_governance.unkey_authorizer import _build_policy

        policy = _build_policy("test", "Allow", _TEST_METHOD_ARN)
        stmt = policy["policyDocument"]["Statement"][0]
        # Should wildcard the resource path
        assert stmt["Resource"].endswith("/*")
        assert "abc123/dev/*" in stmt["Resource"]

    def test_malformed_arn_fallback(self) -> None:
        from aegis_governance.unkey_authorizer import _build_policy

        policy = _build_policy("test", "Allow", "not-an-arn")
        stmt = policy["policyDocument"]["Statement"][0]
        # Should fall back to the raw ARN
        assert stmt["Resource"] == "not-an-arn"


# ---------------------------------------------------------------------------
# Handler tests (mocked Unkey client)
# ---------------------------------------------------------------------------


class TestAuthorizerHandler:
    """Test the Lambda authorizer handler."""

    def _make_event(self, token: str = "") -> dict[str, Any]:
        return {
            "authorizationToken": token,
            "methodArn": _TEST_METHOD_ARN,
            "type": "TOKEN",
        }

    @patch("aegis_governance.unkey_authorizer._get_unkey_client")
    def test_valid_bearer_token(self, mock_get_client: MagicMock) -> None:
        from aegis_governance.unkey import VerifyResult
        from aegis_governance.unkey_authorizer import handler

        mock_client = MagicMock()
        mock_client.verify_key.return_value = VerifyResult(
            valid=True,
            owner_id="cust_verified",
            meta={"tier": "enterprise"},
            remaining=9500,
        )
        mock_get_client.return_value = mock_client

        result = handler(self._make_event("Bearer uk_live_abc123"), None)

        assert result["principalId"] == "cust_verified"
        stmt = result["policyDocument"]["Statement"][0]
        assert stmt["Effect"] == "Allow"
        assert result["context"]["customer_id"] == "cust_verified"
        assert result["context"]["tier"] == "enterprise"
        assert result["context"]["rate_remaining"] == 9500

    @patch("aegis_governance.unkey_authorizer._get_unkey_client")
    def test_invalid_key_denied(self, mock_get_client: MagicMock) -> None:
        from aegis_governance.unkey import VerifyResult
        from aegis_governance.unkey_authorizer import handler

        mock_client = MagicMock()
        mock_client.verify_key.return_value = VerifyResult(
            valid=False, code="KEY_NOT_FOUND"
        )
        mock_get_client.return_value = mock_client

        result = handler(self._make_event("Bearer uk_live_invalid"), None)

        assert result["principalId"] == "anonymous"
        stmt = result["policyDocument"]["Statement"][0]
        assert stmt["Effect"] == "Deny"

    def test_empty_token_denied(self) -> None:
        from aegis_governance.unkey_authorizer import handler

        result = handler(self._make_event(""), None)

        assert result["principalId"] == "anonymous"
        stmt = result["policyDocument"]["Statement"][0]
        assert stmt["Effect"] == "Deny"

    @patch("aegis_governance.unkey_authorizer._get_unkey_client")
    def test_network_error_denied(self, mock_get_client: MagicMock) -> None:
        from aegis_governance.unkey_authorizer import handler

        mock_get_client.side_effect = ConnectionError("Network down")

        result = handler(self._make_event("Bearer uk_live_abc"), None)

        assert result["principalId"] == "anonymous"
        stmt = result["policyDocument"]["Statement"][0]
        assert stmt["Effect"] == "Deny"

    @patch("aegis_governance.unkey_authorizer._get_unkey_client")
    def test_token_without_bearer_prefix(self, mock_get_client: MagicMock) -> None:
        from aegis_governance.unkey import VerifyResult
        from aegis_governance.unkey_authorizer import handler

        mock_client = MagicMock()
        mock_client.verify_key.return_value = VerifyResult(
            valid=True,
            owner_id="cust_raw",
            meta={"tier": "community"},
        )
        mock_get_client.return_value = mock_client

        result = handler(self._make_event("uk_live_raw_token"), None)

        assert result["principalId"] == "cust_raw"
        stmt = result["policyDocument"]["Statement"][0]
        assert stmt["Effect"] == "Allow"

    @patch("aegis_governance.unkey_authorizer._get_unkey_client")
    def test_meta_customer_id_fallback(self, mock_get_client: MagicMock) -> None:
        """When ownerId is empty, fall back to meta.customer_id."""
        from aegis_governance.unkey import VerifyResult
        from aegis_governance.unkey_authorizer import handler

        mock_client = MagicMock()
        mock_client.verify_key.return_value = VerifyResult(
            valid=True,
            owner_id="",
            meta={"customer_id": "cust_meta_fallback", "tier": "professional"},
        )
        mock_get_client.return_value = mock_client

        result = handler(self._make_event("Bearer uk_live_fallback"), None)

        assert result["context"]["customer_id"] == "cust_meta_fallback"
        assert result["context"]["tier"] == "professional"

    @patch("aegis_governance.unkey_authorizer._get_unkey_client")
    def test_no_remaining_uses_minus_one(self, mock_get_client: MagicMock) -> None:
        """When remaining is None, context should show -1 (unlimited)."""
        from aegis_governance.unkey import VerifyResult
        from aegis_governance.unkey_authorizer import handler

        mock_client = MagicMock()
        mock_client.verify_key.return_value = VerifyResult(
            valid=True,
            owner_id="cust_unlimited",
            remaining=None,
        )
        mock_get_client.return_value = mock_client

        result = handler(self._make_event("Bearer uk_live_unlimited"), None)
        assert result["context"]["rate_remaining"] == -1
        assert "quota_remaining" not in result["context"]
