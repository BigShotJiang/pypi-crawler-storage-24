"""Bug Hunt #31 regression tests.

BH31-M1: MCP audit caller_id accepts non-string agent_id without isinstance guard
BH31-L1: Lambda _handle_risk_check threshold dict.get null gotcha
BH31-L2: ConsensusConfig.timeout_hours accepts impractical fractional values
BH31-L3: DualSignatureValidator.expiration_hours accepts impractical fractional values

QG73 Ultrathink findings:
QG73-L1: CLI agent_id/session_id lack isinstance guard (transport parity)
QG73-M1: AFABridge default_timeout_hours lacks fractional minimum guard
"""

from __future__ import annotations

import json

import pytest

# ── BH31-M1: MCP audit caller_id non-string guard ──────────────────────


class TestMCPAuditCallerIdGuard:
    """BH31-M1: agent_id type guard in middleware validate_str."""

    def test_null_agent_id_uses_default(self):
        """agent_id: null should use default, not None."""
        from aegis_governance.middleware import validate_str

        result = validate_str({"agent_id": None}, "agent_id", "sdk-caller")
        assert result == "sdk-caller"

    def test_int_agent_id_uses_default(self):
        """agent_id: 42 should use default, not int."""
        from aegis_governance.middleware import validate_str

        result = validate_str({"agent_id": 42}, "agent_id", "sdk-caller")
        assert result == "sdk-caller"

    def test_list_agent_id_uses_default(self):
        """agent_id: [] should use default, not list."""
        from aegis_governance.middleware import validate_str

        result = validate_str({"agent_id": ["injected"]}, "agent_id", "sdk-caller")
        assert result == "sdk-caller"


# ── BH31-L1: Lambda _handle_risk_check threshold null gotcha ────────────


class TestLambdaRiskCheckThresholdNull:
    """BH31-L1: threshold: null should use default 0.5, not crash."""

    def test_null_threshold_uses_default(self):
        """JSON null threshold should fall back to 0.5 default."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/risk-check",
            "body": json.dumps(
                {
                    "risk_score": 0.3,
                    "threshold": None,  # JSON null
                }
            ),
        }

        result = handler(event, None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        # Should use default threshold of 0.5
        assert body["threshold"] == 0.5

    def test_explicit_threshold_still_works(self):
        """Explicit threshold value should be used normally."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/risk-check",
            "body": json.dumps(
                {
                    "risk_score": 0.3,
                    "threshold": 0.8,
                }
            ),
        }

        result = handler(event, None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["threshold"] == 0.8

    def test_missing_threshold_uses_default(self):
        """Missing threshold key should also use default 0.5."""
        from lambda_handler import handler

        event = {
            "httpMethod": "POST",
            "path": "/risk-check",
            "body": json.dumps(
                {
                    "risk_score": 0.3,
                    # no threshold key at all
                }
            ),
        }

        result = handler(event, None)
        assert result["statusCode"] == 200
        body = json.loads(result["body"])
        assert body["threshold"] == 0.5


# ── BH31-L2: ConsensusConfig.timeout_hours fractional minimum ───────────


class TestConsensusTimeoutMinimum:
    """BH31-L2: timeout_hours must be >= 1 when float to prevent instant timeout."""

    def test_fractional_below_one_rejected(self):
        """timeout_hours=0.001 creates 3.6s deadline -- must be rejected."""
        from workflows.consensus import ConsensusConfig

        with pytest.raises(ValueError, match="must be >= 1"):
            ConsensusConfig(timeout_hours=0.001)

    def test_fractional_half_hour_rejected(self):
        """timeout_hours=0.5 creates 30-minute deadline -- must be rejected."""
        from workflows.consensus import ConsensusConfig

        with pytest.raises(ValueError, match="must be >= 1"):
            ConsensusConfig(timeout_hours=0.5)

    def test_float_one_accepted(self):
        """timeout_hours=1.0 (1 hour) should be accepted."""
        from workflows.consensus import ConsensusConfig

        config = ConsensusConfig(timeout_hours=1.0)
        assert config.timeout_hours == 1.0

    def test_float_two_accepted(self):
        """timeout_hours=2.5 should be accepted (above minimum)."""
        from workflows.consensus import ConsensusConfig

        config = ConsensusConfig(timeout_hours=2.5)
        assert config.timeout_hours == 2.5

    def test_int_one_accepted(self):
        """timeout_hours=1 (int) should still be accepted."""
        from workflows.consensus import ConsensusConfig

        config = ConsensusConfig(timeout_hours=1)
        assert config.timeout_hours == 1


# ── BH31-L3: DualSignatureValidator.expiration_hours fractional minimum ──


class TestOverrideExpirationMinimum:
    """BH31-L3: expiration_hours must be >= 1 when float."""

    def test_fractional_below_one_rejected(self):
        """expiration_hours=0.001 creates 3.6s expiration -- must be rejected."""
        from workflows.override import DualSignatureValidator

        with pytest.raises(ValueError, match="must be >= 1"):
            DualSignatureValidator(expiration_hours=0.001)

    def test_fractional_half_hour_rejected(self):
        """expiration_hours=0.5 creates 30-minute expiration -- must be rejected."""
        from workflows.override import DualSignatureValidator

        with pytest.raises(ValueError, match="must be >= 1"):
            DualSignatureValidator(expiration_hours=0.5)

    def test_float_one_accepted(self):
        """expiration_hours=1.0 should be accepted."""
        from workflows.override import DualSignatureValidator

        validator = DualSignatureValidator(expiration_hours=1.0)
        assert validator.expiration_hours == 1.0

    def test_int_one_accepted(self):
        """expiration_hours=1 (int) should still be accepted."""
        from workflows.override import DualSignatureValidator

        validator = DualSignatureValidator(expiration_hours=1)
        assert validator.expiration_hours == 1


# ── QG73-L1: CLI agent_id/session_id isinstance guard ────────────────────


class TestCLIAgentIdGuard:
    """QG73-L1: CLI must guard agent_id/session_id type like MCP/Lambda."""

    def test_int_agent_id_uses_default(self):
        """Non-string agent_id from JSON input should use 'aegis-cli'."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "agent_id": 42,
        }
        kwargs = _parse_proposal(data)
        assert kwargs["agent_id"] == "aegis-cli"

    def test_null_agent_id_uses_default(self):
        """None agent_id should use 'aegis-cli'."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "agent_id": None,
        }
        kwargs = _parse_proposal(data)
        assert kwargs["agent_id"] == "aegis-cli"

    def test_int_session_id_uses_default(self):
        """Non-string session_id from JSON input should generate UUID."""
        from cli import _parse_proposal

        data = {
            "proposal_summary": "test",
            "estimated_impact": "low",
            "session_id": 99,
        }
        kwargs = _parse_proposal(data)
        # Non-string session_id should be replaced with a UUID
        assert kwargs["session_id"] != "cli-session"
        assert len(kwargs["session_id"]) == 36  # UUID format


# ── QG73-M1: AFABridge default_timeout_hours fractional minimum ──────────


class TestAFABridgeTimeoutMinimum:
    """QG73-M1: default_timeout_hours must be >= 1 when float."""

    def test_fractional_below_one_rejected(self):
        """default_timeout_hours=0.001 must be rejected."""
        from integration.afa_bridge import AFABridge

        with pytest.raises(ValueError, match="must be >= 1"):
            AFABridge(default_timeout_hours=0.001)

    def test_fractional_half_hour_rejected(self):
        """default_timeout_hours=0.5 must be rejected."""
        from integration.afa_bridge import AFABridge

        with pytest.raises(ValueError, match="must be >= 1"):
            AFABridge(default_timeout_hours=0.5)

    def test_float_one_accepted(self):
        """default_timeout_hours=1.0 should be accepted."""
        from integration.afa_bridge import AFABridge

        bridge = AFABridge(default_timeout_hours=1.0)
        assert bridge.default_timeout_hours == 1.0

    def test_int_accepted(self):
        """default_timeout_hours=24 (int) should be accepted."""
        from integration.afa_bridge import AFABridge

        bridge = AFABridge(default_timeout_hours=24)
        assert bridge.default_timeout_hours == 24
