"""Workflow Persistence Module

Provides durable state persistence for AEGIS LIBERTAS workflows using
SQLAlchemy 2.0 async ORM with PostgreSQL (production) and SQLite (testing).

Architecture:
    - models.py: SQLAlchemy ORM models for workflow state
    - engine.py: Database engine and session factory configuration
    - repository.py: WorkflowPersistence repository with async methods

Usage:
    from workflows.persistence import (
        WorkflowPersistence,
        DatabaseConfig,
        create_database_engine,
    )

    # Initialize persistence layer
    config = DatabaseConfig(url="sqlite+aiosqlite:///workflows.db")
    persistence = WorkflowPersistence(config)

    # Save workflow checkpoint
    await persistence.save_checkpoint(workflow, actor_id="user-123")

    # Load workflow from checkpoint
    state_data = await persistence.load_checkpoint(workflow_id="prop-456")

References:
    - ADR-001: Workflow State Persistence Architecture
    - GAP-M3: Workflow Persistence Implementation Plan
    - LangGraph Checkpoint Pattern

"""

from workflows.persistence.durable import (
    DurableWorkflowContext,
    DurableWorkflowEngine,
    DurableWorkflowMixin,
)
from workflows.persistence.engine import DatabaseConfig, create_database_engine
from workflows.persistence.models import (
    Base,
    GovernanceKey,
    KeyUsageAudit,
    WorkflowCheckpoint,
    WorkflowInstance,
    WorkflowTransition,
)
from workflows.persistence.repository import SerializableWorkflow, WorkflowPersistence

__all__ = [
    "Base",
    "DatabaseConfig",
    "DurableWorkflowContext",
    "DurableWorkflowEngine",
    "DurableWorkflowMixin",
    "GovernanceKey",
    "KeyUsageAudit",
    "SerializableWorkflow",
    "WorkflowCheckpoint",
    "WorkflowInstance",
    "WorkflowPersistence",
    "WorkflowTransition",
    "create_database_engine",
]
