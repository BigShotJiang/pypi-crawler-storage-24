"""Workflow Persistence Repository

Provides the core persistence API for AEGIS LIBERTAS workflows.
Implements checkpoint-based state management with full audit trail.

Key Operations:
    - save_checkpoint: Persist workflow state with transition recording
    - load_checkpoint: Restore workflow from last checkpoint
    - list_workflows: Query workflows by type/state/date range
    - get_audit_trail: Retrieve complete transition history
    - resume_workflow: Load and restore workflow instance

Thread Safety:
    All methods are async and use separate sessions per operation.
    Safe for concurrent use from multiple coroutines.

Transaction Guarantees:
    Each operation runs in a transaction with automatic rollback on error.
    Checkpoints and transitions are atomically persisted together.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Optional, Protocol, TypeVar
from uuid import uuid4

from sqlalchemy import and_, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from workflows.persistence.engine import (
    DatabaseConfig,
    create_database_engine,
    create_session_factory,
    init_database,
)
from workflows.persistence.models import (
    WorkflowCheckpoint,
    WorkflowInstance,
    WorkflowTransition,
)

logger = logging.getLogger(__name__)


class SerializableWorkflow(Protocol):
    """Protocol for workflows that support persistence."""

    @property
    def workflow_id(self) -> str:
        """Unique workflow identifier."""
        ...

    @property
    def workflow_type(self) -> str:
        """Workflow type discriminator."""
        ...

    @property
    def current_state(self) -> str:
        """Current state value."""
        ...

    def to_dict(self) -> dict[str, Any]:
        """Serialize workflow to dictionary."""
        ...

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerializableWorkflow":
        """Deserialize workflow from dictionary."""
        ...


T = TypeVar("T", bound=SerializableWorkflow)


class WorkflowPersistence:
    """Async workflow state persistence layer.

    Provides durable storage for AEGIS LIBERTAS workflows with:
    - Checkpoint-based state snapshots
    - Cryptographically-verified audit trail
    - Crash recovery and resume capability
    - Query support for workflow management

    Example:
        # Initialize
        config = DatabaseConfig.for_testing()
        persistence = WorkflowPersistence(config)
        await persistence.initialize()

        # Save workflow
        await persistence.save_checkpoint(workflow, actor_id="user-123")

        # Load workflow
        state = await persistence.load_checkpoint("workflow-456")

        # List pending workflows
        pending = await persistence.list_pending_workflows("proposal")

    """

    _CHECKPOINT_NUMBER_RETRY_LIMIT = 3

    def __init__(
        self,
        config: Optional[DatabaseConfig] = None,
        engine: Optional[AsyncEngine] = None,
    ):
        """Initialize persistence layer.

        Provide either config or engine, not both.

        Args:
            config: Database configuration (creates new engine)
            engine: Pre-configured async engine (for sharing)

        """
        if config and engine:
            raise ValueError("Provide either config or engine, not both")

        if engine:
            self._engine = engine
            self._owns_engine = False
        elif config:
            self._engine = create_database_engine(config)
            self._owns_engine = True
        else:
            raise ValueError("Provide either config or engine")

        self._session_factory = create_session_factory(self._engine)
        self._initialized = False

    @property
    def engine(self) -> AsyncEngine:
        """Get the database engine."""
        return self._engine

    @property
    def session_factory(self) -> async_sessionmaker[AsyncSession]:
        """Get the session factory."""
        return self._session_factory

    async def initialize(self) -> None:
        """Initialize database schema.

        Creates tables if they don't exist. Safe to call multiple times.
        """
        await init_database(self._engine)
        self._initialized = True

    async def close(self) -> None:
        """Close database connections.

        Only closes the engine if it was created by this instance.
        """
        if self._owns_engine:
            await self._engine.dispose()

    async def __aenter__(self) -> "WorkflowPersistence":
        """Async context manager entry."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()

    # ========================================================================
    # Core Persistence Operations
    # ========================================================================

    async def save_checkpoint(
        self,
        workflow: SerializableWorkflow,
        actor_id: str,
        transition_reason: Optional[str] = None,
        transition_metadata: Optional[dict[str, Any]] = None,
    ) -> str:
        """Persist current workflow state as checkpoint.

        Atomically:
        1. Creates or updates workflow instance record
        2. Creates checkpoint with state snapshot
        3. Records state transition if state changed

        Args:
            workflow: Workflow to persist
            actor_id: ID of actor triggering the checkpoint
            transition_reason: Optional reason for state change
            transition_metadata: Optional metadata for transition

        Returns:
            Checkpoint ID

        Raises:
            RuntimeError: If not initialized

        """
        if not self._initialized:
            raise RuntimeError("Persistence not initialized. Call initialize() first.")

        for attempt in range(self._CHECKPOINT_NUMBER_RETRY_LIMIT + 1):
            state_data = workflow.to_dict()
            checkpoint_hash = WorkflowCheckpoint.compute_hash(state_data)

            try:
                async with self._session_factory() as session, session.begin():
                    # Get or create workflow instance
                    instance = await self._get_or_create_instance(
                        session,
                        workflow_id=workflow.workflow_id,
                        workflow_type=workflow.workflow_type,
                        current_state=workflow.current_state,
                        state_data=state_data,
                    )

                    # Check if state changed
                    previous_state = instance.current_state
                    state_changed = previous_state != workflow.current_state

                    # Update instance
                    instance.current_state = workflow.current_state
                    instance.state_data = state_data
                    instance.updated_at = datetime.now(timezone.utc)

                    # Get next checkpoint number
                    checkpoint_number = await self._get_next_checkpoint_number(
                        session,
                        instance.id,
                    )

                    # Create checkpoint
                    checkpoint = WorkflowCheckpoint(
                        id=str(uuid4()),
                        workflow_instance_id=instance.id,
                        checkpoint_number=checkpoint_number,
                        state_snapshot=state_data,
                        checkpoint_hash=checkpoint_hash,
                    )
                    session.add(checkpoint)

                    # Record transition if state changed
                    if state_changed:
                        await self._record_transition(
                            session,
                            instance_id=instance.id,
                            from_state=previous_state,
                            to_state=workflow.current_state,
                            actor_id=actor_id,
                            reason=transition_reason,
                            metadata=transition_metadata or {},
                        )

                    checkpoint_id: str = checkpoint.id
                    return checkpoint_id
            except IntegrityError as e:
                if (
                    attempt >= self._CHECKPOINT_NUMBER_RETRY_LIMIT
                    or not self._is_checkpoint_number_conflict(e)
                ):
                    raise
                logger.warning(
                    "save_checkpoint checkpoint_number collision for workflow_id=%s "
                    "(attempt %d/%d); retrying",
                    workflow.workflow_id,
                    attempt + 1,
                    self._CHECKPOINT_NUMBER_RETRY_LIMIT + 1,
                )

        # Defensive fallback: loop either returns on success or raises.
        raise RuntimeError("save_checkpoint failed after checkpoint collision retries")

    @staticmethod
    def _is_checkpoint_number_conflict(exc: IntegrityError) -> bool:
        """Return True if IntegrityError is a checkpoint-number uniqueness collision."""
        msg = str(getattr(exc, "orig", exc)).lower()
        if "uq_checkpoint_number" in msg:
            return True
        if "checkpoint_number" not in msg:
            return False
        return (
            "workflow_checkpoints.workflow_instance_id" in msg
            or "workflow_checkpoint.workflow_instance_id" in msg
            or "workflow_instance_id, checkpoint_number" in msg
        )

    async def load_checkpoint(
        self,
        workflow_id: str,
    ) -> Optional[dict[str, Any]]:
        """Load workflow state from last checkpoint.

        Args:
            workflow_id: Workflow identifier

        Returns:
            Serialized workflow state, or None if not found

        """
        async with self._session_factory() as session:
            result = await session.execute(
                select(WorkflowInstance).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            instance = result.scalar_one_or_none()

            if instance:
                state: Optional[dict[str, Any]] = instance.state_data
                return state
            return None

    async def load_checkpoint_by_number(
        self,
        workflow_id: str,
        checkpoint_number: int,
    ) -> Optional[dict[str, Any]]:
        """Load specific checkpoint by number.

        Useful for time-travel debugging or rollback.

        Args:
            workflow_id: Workflow identifier
            checkpoint_number: Checkpoint number to load

        Returns:
            Checkpoint state snapshot, or None if not found

        """
        async with self._session_factory() as session:
            # First get instance ID
            instance_result = await session.execute(
                select(WorkflowInstance.id).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            instance_id = instance_result.scalar_one_or_none()

            if not instance_id:
                return None

            # Get checkpoint
            checkpoint_result = await session.execute(
                select(WorkflowCheckpoint).where(
                    and_(
                        WorkflowCheckpoint.workflow_instance_id == instance_id,
                        WorkflowCheckpoint.checkpoint_number == checkpoint_number,
                    ),
                ),
            )
            checkpoint = checkpoint_result.scalar_one_or_none()

            if checkpoint:
                snapshot: Optional[dict[str, Any]] = checkpoint.state_snapshot
                return snapshot
            return None

    async def delete_workflow(
        self,
        workflow_id: str,
    ) -> bool:
        """Delete workflow and all associated data.

        Cascades to delete transitions and checkpoints.

        Args:
            workflow_id: Workflow identifier

        Returns:
            True if deleted, False if not found

        """
        async with self._session_factory() as session, session.begin():
            result = await session.execute(
                select(WorkflowInstance).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            instance = result.scalar_one_or_none()

            if instance:
                await session.delete(instance)
                return True
            return False

    # ========================================================================
    # Query Operations
    # ========================================================================

    async def list_pending_workflows(
        self,
        workflow_type: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List all non-completed workflows.

        Args:
            workflow_type: Optional type filter
            limit: Maximum results

        Returns:
            List of serialized workflow states

        """
        async with self._session_factory() as session:
            query = select(WorkflowInstance).where(
                WorkflowInstance.completed_at.is_(None),
            )

            if workflow_type:
                query = query.where(WorkflowInstance.workflow_type == workflow_type)

            query = query.order_by(WorkflowInstance.created_at.desc()).limit(limit)

            result = await session.execute(query)
            instances = result.scalars().all()

            return [inst.state_data for inst in instances]

    async def list_workflows(
        self,
        workflow_type: Optional[str] = None,
        state: Optional[str] = None,
        created_after: Optional[datetime] = None,
        created_before: Optional[datetime] = None,
        include_completed: bool = True,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List workflows with filtering options.

        Args:
            workflow_type: Filter by type
            state: Filter by current state
            created_after: Filter by creation date (>=)
            created_before: Filter by creation date (<=)
            include_completed: Include completed workflows
            limit: Maximum results
            offset: Results offset for pagination

        Returns:
            List of workflow summaries (not full state data)

        """
        async with self._session_factory() as session:
            query = select(WorkflowInstance)

            if workflow_type:
                query = query.where(WorkflowInstance.workflow_type == workflow_type)

            if state:
                query = query.where(WorkflowInstance.current_state == state)

            if created_after:
                query = query.where(WorkflowInstance.created_at >= created_after)

            if created_before:
                query = query.where(WorkflowInstance.created_at <= created_before)

            if not include_completed:
                query = query.where(WorkflowInstance.completed_at.is_(None))

            query = (
                query.order_by(WorkflowInstance.created_at.desc())
                .limit(limit)
                .offset(offset)
            )

            result = await session.execute(query)
            instances = result.scalars().all()

            return [
                {
                    "id": inst.id,
                    "workflow_id": inst.workflow_id,
                    "workflow_type": inst.workflow_type,
                    "current_state": inst.current_state,
                    "created_at": inst.created_at.isoformat(),
                    "updated_at": inst.updated_at.isoformat(),
                    "completed_at": (
                        inst.completed_at.isoformat() if inst.completed_at else None
                    ),
                }
                for inst in instances
            ]

    async def get_workflow_summary(
        self,
        workflow_id: str,
    ) -> Optional[dict[str, Any]]:
        """Get workflow summary without full state data.

        Args:
            workflow_id: Workflow identifier

        Returns:
            Workflow summary or None

        """
        async with self._session_factory() as session:
            result = await session.execute(
                select(WorkflowInstance).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            instance = result.scalar_one_or_none()

            if not instance:
                return None

            # Count transitions/checkpoints via explicit async queries.
            # Avoid lazy relationship loading in AsyncSession, which can
            # raise MissingGreenlet when relationship access triggers IO.
            transition_count_result = await session.execute(
                select(func.count())
                .select_from(WorkflowTransition)
                .where(WorkflowTransition.workflow_instance_id == instance.id)
            )
            transition_count = int(transition_count_result.scalar_one())

            checkpoint_count_result = await session.execute(
                select(func.count())
                .select_from(WorkflowCheckpoint)
                .where(WorkflowCheckpoint.workflow_instance_id == instance.id)
            )
            checkpoint_count = int(checkpoint_count_result.scalar_one())

            return {
                "id": instance.id,
                "workflow_id": instance.workflow_id,
                "workflow_type": instance.workflow_type,
                "current_state": instance.current_state,
                "created_at": instance.created_at.isoformat(),
                "updated_at": instance.updated_at.isoformat(),
                "completed_at": (
                    instance.completed_at.isoformat() if instance.completed_at else None
                ),
                "transition_count": transition_count,
                "checkpoint_count": checkpoint_count,
            }

    # ========================================================================
    # Audit Trail Operations
    # ========================================================================

    async def get_audit_trail(
        self,
        workflow_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get complete audit trail for workflow.

        Args:
            workflow_id: Workflow identifier
            limit: Maximum transitions to return

        Returns:
            List of transition records in chronological order

        """
        async with self._session_factory() as session:
            # Get instance ID
            instance_result = await session.execute(
                select(WorkflowInstance.id).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            instance_id = instance_result.scalar_one_or_none()

            if not instance_id:
                return []

            # Get transitions
            result = await session.execute(
                select(WorkflowTransition)
                .where(WorkflowTransition.workflow_instance_id == instance_id)
                .order_by(WorkflowTransition.created_at)
                .limit(limit),
            )
            transitions = result.scalars().all()

            return [
                {
                    "id": t.id,
                    "from_state": t.from_state,
                    "to_state": t.to_state,
                    "actor_id": t.actor_id,
                    "reason": t.reason,
                    "metadata": t.extra_data,
                    "transition_hash": t.transition_hash,
                    "created_at": t.created_at.isoformat(),
                }
                for t in transitions
            ]

    async def verify_audit_chain(
        self,
        workflow_id: str,
    ) -> tuple[bool, Optional[str]]:
        """Verify integrity of audit trail hash chain.

        Args:
            workflow_id: Workflow identifier

        Returns:
            Tuple of (is_valid, error_message)

        """
        async with self._session_factory() as session:
            # Get instance ID
            instance_result = await session.execute(
                select(WorkflowInstance.id).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            instance_id = instance_result.scalar_one_or_none()

            if not instance_id:
                logger.warning(
                    "verify_audit_chain: workflow not found: %s", workflow_id
                )
                return False, f"Workflow not found: {workflow_id}"

            # Get all transitions in order
            result = await session.execute(
                select(WorkflowTransition)
                .where(WorkflowTransition.workflow_instance_id == instance_id)
                .order_by(WorkflowTransition.created_at),
            )
            transitions = result.scalars().all()

            if not transitions:
                return True, None

            # Verify hash chain
            previous_hash: Optional[str] = None

            for t in transitions:
                # Ensure timestamp is timezone-aware (SQLite may strip timezone)
                ts = t.created_at
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                expected_hash = WorkflowTransition.compute_hash(
                    workflow_id=instance_id,
                    from_state=t.from_state,
                    to_state=t.to_state,
                    actor_id=t.actor_id,
                    timestamp=ts,
                    previous_hash=previous_hash,
                    reason=t.reason,
                    extra_data=t.extra_data,
                )

                if t.transition_hash != expected_hash:
                    return False, f"Hash mismatch at transition {t.id}"

                previous_hash = t.transition_hash

            return True, None

    # ========================================================================
    # Lifecycle Operations
    # ========================================================================

    async def mark_completed(
        self,
        workflow_id: str,
        actor_id: str,
        final_state: str,
    ) -> bool:
        """Mark workflow as completed.

        Args:
            workflow_id: Workflow identifier
            actor_id: Actor completing the workflow
            final_state: Final workflow state

        Returns:
            True if marked, False if not found

        """
        async with self._session_factory() as session, session.begin():
            result = await session.execute(
                select(WorkflowInstance).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            instance = result.scalar_one_or_none()

            if not instance:
                return False

            # Guard against re-completing already-completed workflows
            if instance.completed_at is not None:
                return False

            # Record final transition if state changed
            if instance.current_state != final_state:
                await self._record_transition(
                    session,
                    instance_id=instance.id,
                    from_state=instance.current_state,
                    to_state=final_state,
                    actor_id=actor_id,
                    reason="Workflow completed",
                )

            # Keep serialized checkpoint data consistent with current_state
            # so load_checkpoint()/resume return the finalized state.
            state_data = (
                dict(instance.state_data)
                if isinstance(instance.state_data, dict)
                else {}
            )
            if "state" in state_data:
                state_data["state"] = final_state
            if "current_state" in state_data:
                state_data["current_state"] = final_state
            # Only update request.state if the final_state is a valid enum
            # value for the workflow type.  Non-enum values like "aborted"
            # would break from_dict() deserialization (BH36-M2).
            request_data = state_data.get("request")
            if isinstance(request_data, dict) and "state" in request_data:
                updated_request = dict(request_data)
                # Preserve the last valid request state — the top-level
                # current_state and completed_at already record the abort.
                # Only overwrite request.state for valid workflow states.
                try:
                    from workflows.override import OverrideState

                    OverrideState(final_state)
                    updated_request["state"] = final_state
                    state_data["request"] = updated_request
                except ValueError:
                    try:
                        from workflows.proposal import ProposalState

                        ProposalState(final_state)
                        updated_request["state"] = final_state
                        state_data["request"] = updated_request
                    except ValueError:
                        pass  # Non-enum final_state: keep original request.state
            instance.state_data = state_data

            instance.current_state = final_state
            instance.completed_at = datetime.now(timezone.utc)
            instance.updated_at = datetime.now(timezone.utc)

            return True

    async def workflow_exists(self, workflow_id: str) -> bool:
        """Check if workflow exists.

        Args:
            workflow_id: Workflow identifier

        Returns:
            True if exists

        """
        async with self._session_factory() as session:
            result = await session.execute(
                select(WorkflowInstance.id).where(
                    WorkflowInstance.workflow_id == workflow_id,
                ),
            )
            return result.scalar_one_or_none() is not None

    # ========================================================================
    # Helper Methods
    # ========================================================================

    async def _get_or_create_instance(
        self,
        session: AsyncSession,
        workflow_id: str,
        workflow_type: str,
        current_state: str,
        state_data: dict[str, Any],
    ) -> WorkflowInstance:
        """Get existing instance or create new one."""
        result = await session.execute(
            select(WorkflowInstance).where(WorkflowInstance.workflow_id == workflow_id),
        )
        instance = result.scalar_one_or_none()

        if not instance:
            instance = WorkflowInstance(
                id=str(uuid4()),
                workflow_id=workflow_id,
                workflow_type=workflow_type,
                current_state=current_state,
                state_data=state_data,
            )
            session.add(instance)

        workflow_instance: WorkflowInstance = instance
        return workflow_instance

    async def _get_next_checkpoint_number(
        self,
        session: AsyncSession,
        instance_id: str,
    ) -> int:
        """Get next checkpoint number for instance."""
        result = await session.execute(
            select(WorkflowCheckpoint.checkpoint_number)
            .where(WorkflowCheckpoint.workflow_instance_id == instance_id)
            .order_by(WorkflowCheckpoint.checkpoint_number.desc())
            .limit(1),
        )
        last_number = result.scalar_one_or_none()
        return (last_number or 0) + 1

    async def _record_transition(
        self,
        session: AsyncSession,
        instance_id: str,
        from_state: str,
        to_state: str,
        actor_id: str,
        reason: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> WorkflowTransition:
        """Record state transition with hash chain."""
        # Get previous transition hash for chaining
        result = await session.execute(
            select(WorkflowTransition.transition_hash)
            .where(WorkflowTransition.workflow_instance_id == instance_id)
            .order_by(WorkflowTransition.created_at.desc())
            .limit(1),
        )
        previous_hash = result.scalar_one_or_none()

        now = datetime.now(timezone.utc)

        extra_data = metadata or {}
        transition_hash = WorkflowTransition.compute_hash(
            workflow_id=instance_id,
            from_state=from_state,
            to_state=to_state,
            actor_id=actor_id,
            timestamp=now,
            previous_hash=previous_hash,
            reason=reason,
            extra_data=extra_data,
        )

        transition = WorkflowTransition(
            id=str(uuid4()),
            workflow_instance_id=instance_id,
            from_state=from_state,
            to_state=to_state,
            actor_id=actor_id,
            reason=reason,
            extra_data=extra_data,
            transition_hash=transition_hash,
            previous_hash=previous_hash,
            created_at=now,
        )
        session.add(transition)

        return transition
