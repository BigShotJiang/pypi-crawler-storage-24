"""SQLAlchemy ORM Models for Workflow Persistence

Implements the database schema defined in ADR-001:
- WorkflowInstance: Core workflow state storage
- WorkflowTransition: Audit trail for state changes
- WorkflowCheckpoint: Snapshot storage for resume capability

Database Support:
- PostgreSQL (production): Uses JSONB, gen_random_uuid()
- SQLite (testing): Uses JSON, application-generated UUIDs

Schema Version: 1.0.0
"""

import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import JSON, TypeDecorator


def _utc_now() -> datetime:
    """Helper function for timezone-aware UTC timestamps (SQLAlchemy default)."""
    return datetime.now(timezone.utc)


class JSONType(TypeDecorator[dict[str, Any]]):
    """Platform-agnostic JSON type.

    Uses JSONB for PostgreSQL (faster queries, indexing support).
    Uses JSON for SQLite (testing compatibility).
    """

    impl = JSON
    cache_ok = True

    def load_dialect_impl(self, dialect: Any) -> Any:
        """Select appropriate JSON implementation based on dialect."""
        if dialect.name == "postgresql":
            return dialect.type_descriptor(JSONB())
        return dialect.type_descriptor(JSON())


class Base(DeclarativeBase):
    """Base class for all ORM models."""


class WorkflowInstance(Base):
    """Core workflow instance table.

    Stores the current state and serialized data for each workflow.
    Supports parent-child relationships for nested workflows.

    Attributes:
        id: UUID primary key (auto-generated)
        workflow_type: Type discriminator ('proposal', 'consensus', 'override')
        workflow_id: Business identifier (unique within type)
        current_state: Current FSM state value
        state_data: Full serialized workflow state (JSONB/JSON)
        created_at: Instance creation timestamp
        updated_at: Last state update timestamp
        completed_at: Workflow completion timestamp (None if active)
        parent_workflow_id: Reference to parent workflow (for nesting)

    """

    __tablename__ = "workflow_instances"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_type: Mapped[str] = mapped_column(String(50), nullable=False)
    workflow_id: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)
    current_state: Mapped[str] = mapped_column(String(50), nullable=False)
    state_data: Mapped[dict[str, Any]] = mapped_column(
        JSONType(),
        nullable=False,
        default=dict,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=_utc_now,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=_utc_now,
        onupdate=_utc_now,
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    parent_workflow_id: Mapped[Optional[str]] = mapped_column(
        String(36),
        ForeignKey("workflow_instances.id"),
        nullable=True,
    )

    # Relationships
    transitions: Mapped[list["WorkflowTransition"]] = relationship(
        "WorkflowTransition",
        back_populates="workflow_instance",
        cascade="all, delete-orphan",
        order_by="WorkflowTransition.created_at",
    )
    checkpoints: Mapped[list["WorkflowCheckpoint"]] = relationship(
        "WorkflowCheckpoint",
        back_populates="workflow_instance",
        cascade="all, delete-orphan",
        order_by="WorkflowCheckpoint.checkpoint_number.desc()",
    )
    parent: Mapped[Optional["WorkflowInstance"]] = relationship(
        "WorkflowInstance",
        remote_side=[id],
        backref="children",
    )

    # Indexes for common query patterns
    __table_args__ = (
        Index("idx_workflow_type", "workflow_type"),
        Index("idx_workflow_state", "current_state"),
        Index("idx_workflow_created", "created_at"),
        Index(
            "idx_workflow_active",
            "completed_at",
            postgresql_where="completed_at IS NULL",
        ),
    )

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"<WorkflowInstance(id={self.id!r}, type={self.workflow_type!r}, "
            f"state={self.current_state!r})>"
        )


class WorkflowTransition(Base):
    """State transition audit trail.

    Records every state change with actor, timestamp, and cryptographic hash
    for integrity verification. Essential for governance compliance.

    Attributes:
        id: UUID primary key
        workflow_instance_id: Reference to parent workflow
        from_state: Previous state value
        to_state: New state value
        actor_id: Identifier of actor who triggered transition
        reason: Optional human-readable reason
        metadata: Additional transition context (JSONB/JSON)
        transition_hash: SHA-256 hash for integrity verification
        previous_hash: Hash of previous transition (for standalone chain verification)
        created_at: Transition timestamp

    """

    __tablename__ = "workflow_transitions"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_instance_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("workflow_instances.id", ondelete="CASCADE"),
        nullable=False,
    )
    from_state: Mapped[str] = mapped_column(String(50), nullable=False)
    to_state: Mapped[str] = mapped_column(String(50), nullable=False)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    extra_data: Mapped[dict[str, Any]] = mapped_column(
        JSONType(),
        nullable=False,
        default=dict,
    )
    transition_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    previous_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=_utc_now,
    )

    # Relationships
    workflow_instance: Mapped["WorkflowInstance"] = relationship(
        "WorkflowInstance",
        back_populates="transitions",
    )

    # Indexes
    __table_args__ = (
        Index("idx_transition_workflow", "workflow_instance_id"),
        Index("idx_transition_actor", "actor_id"),
        Index("idx_transition_created", "created_at"),
    )

    @classmethod
    def compute_hash(
        cls,
        workflow_id: str,
        from_state: str,
        to_state: str,
        actor_id: str,
        timestamp: datetime,
        previous_hash: Optional[str] = None,
        reason: Optional[str] = None,
        extra_data: Optional[dict[str, Any]] = None,
    ) -> str:
        """Compute SHA-256 hash for transition integrity.

        Creates a cryptographic chain by including the previous transition hash.
        This enables detection of any tampering with the audit trail.

        Args:
            workflow_id: Workflow instance ID
            from_state: Previous state
            to_state: New state
            actor_id: Actor who triggered transition
            timestamp: Transition timestamp
            previous_hash: Hash of previous transition (for chaining)
            reason: Transition reason (included in hash for integrity)
            extra_data: Additional metadata (included in hash for integrity)

        Returns:
            64-character hexadecimal SHA-256 hash

        """
        data = json.dumps(
            {
                "workflow_id": workflow_id,
                "from_state": from_state,
                "to_state": to_state,
                "actor_id": actor_id,
                "timestamp": timestamp.isoformat(),
                "previous_hash": previous_hash or "",
                "reason": reason or "",
                "extra_data": extra_data or {},
            },
            sort_keys=True,
        )
        return hashlib.sha256(data.encode()).hexdigest()

    def verify_hash(self, previous_hash: Optional[str] = None) -> bool:
        """Verify this transition's hash for integrity.

        Recomputes the hash from stored fields and compares with transition_hash.
        Same pattern as KeyUsageAudit.verify_hash() for consistency.

        Args:
            previous_hash: Hash of the previous transition (for chain verification).
                If provided, overrides the stored previous_hash. If not provided,
                falls back to self.previous_hash (stored at creation time).

        Returns:
            True if hash is valid, False if tampered

        Note:
            For full chain verification, iterate transitions in order and pass
            each transition_hash as the previous_hash for the next transition.
            Or use verify_chain_link() for a more explicit chain validation.
            Standalone verification (no argument) works for all transitions
            because previous_hash is stored as a column.
        """
        # Ensure timestamp is timezone-aware (SQLite may strip timezone)
        ts = self.created_at
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)

        # Use explicit parameter if provided, otherwise fall back to stored value
        hash_to_use = previous_hash if previous_hash is not None else self.previous_hash

        expected = self.compute_hash(
            workflow_id=self.workflow_instance_id,
            from_state=self.from_state,
            to_state=self.to_state,
            actor_id=self.actor_id,
            timestamp=ts,
            previous_hash=hash_to_use,
            reason=self.reason,
            extra_data=self.extra_data,
        )
        result: bool = self.transition_hash == expected
        return result

    def verify_chain_link(
        self, previous_transition: Optional["WorkflowTransition"]
    ) -> tuple[bool, Optional[str]]:
        """Verify this transition's hash chain link to the previous transition.

        This method validates both the hash integrity and the chain linkage:
        1. Verifies this transition's hash is correct (using previous_hash)
        2. Verifies the workflow_instance_id matches (same workflow)
        3. Verifies state continuity (previous.to_state == this.from_state)
        4. Verifies temporal ordering (previous.created_at <= this.created_at)

        Args:
            previous_transition: The transition that should precede this one.
                If None, this is treated as the first transition in the chain
                (previous_hash should be empty/None).

        Returns:
            Tuple of (is_valid, error_message). If valid, error_message is None.

        Example:
            >>> transitions = get_transitions_in_order()
            >>> prev = None
            >>> for t in transitions:
            ...     valid, error = t.verify_chain_link(prev)
            ...     if not valid:
            ...         raise IntegrityError(f"Chain broken: {error}")
            ...     prev = t

        Note:
            Repository-level chain verification may be more efficient for
            batch validation. This method is useful for incremental validation
            or when verifying individual transitions.
        """
        # Determine expected previous_hash
        expected_previous_hash = (
            previous_transition.transition_hash if previous_transition else None
        )

        # 1. Verify hash integrity
        if not self.verify_hash(expected_previous_hash):
            return False, (
                f"Hash verification failed for transition {self.id}. "
                "Transition may have been tampered with."
            )

        # If no previous transition, this is the first in the chain.
        # previous_hash must be empty/None for a valid chain root.
        if previous_transition is None:
            if self.previous_hash not in (None, ""):
                return False, (
                    f"Invalid chain root: first transition has previous_hash={self.previous_hash!r}. "
                    "First transition must have no previous_hash."
                )
            return True, None

        # 2. Verify same workflow
        if self.workflow_instance_id != previous_transition.workflow_instance_id:
            return False, (
                f"Workflow ID mismatch: previous={previous_transition.workflow_instance_id}, "
                f"current={self.workflow_instance_id}"
            )

        # 3. Verify state continuity (previous.to_state == current.from_state)
        if self.from_state != previous_transition.to_state:
            return False, (
                f"State discontinuity: previous.to_state={previous_transition.to_state}, "
                f"current.from_state={self.from_state}"
            )

        # 4. Verify temporal ordering
        prev_ts = previous_transition.created_at
        curr_ts = self.created_at
        # Handle timezone-naive timestamps
        if prev_ts.tzinfo is None:
            prev_ts = prev_ts.replace(tzinfo=timezone.utc)
        if curr_ts.tzinfo is None:
            curr_ts = curr_ts.replace(tzinfo=timezone.utc)

        if curr_ts < prev_ts:
            return False, (
                f"Temporal ordering violation: previous.created_at={prev_ts.isoformat()}, "
                f"current.created_at={curr_ts.isoformat()}"
            )

        return True, None

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"<WorkflowTransition(id={self.id!r}, "
            f"{self.from_state!r} -> {self.to_state!r}, actor={self.actor_id!r})>"
        )


class WorkflowCheckpoint(Base):
    """Workflow state checkpoint for resume capability.

    Stores complete state snapshots at specific points for crash recovery.
    Checkpoints are numbered sequentially per workflow instance.

    Attributes:
        id: UUID primary key
        workflow_instance_id: Reference to parent workflow
        checkpoint_number: Sequential checkpoint number (1, 2, 3, ...)
        state_snapshot: Complete serialized state (JSONB/JSON)
        checkpoint_hash: SHA-256 hash of snapshot for integrity
        created_at: Checkpoint creation timestamp

    """

    __tablename__ = "workflow_checkpoints"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_instance_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("workflow_instances.id", ondelete="CASCADE"),
        nullable=False,
    )
    checkpoint_number: Mapped[int] = mapped_column(Integer, nullable=False)
    state_snapshot: Mapped[dict[str, Any]] = mapped_column(
        JSONType(),
        nullable=False,
    )
    checkpoint_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=_utc_now,
    )

    # Relationships
    workflow_instance: Mapped["WorkflowInstance"] = relationship(
        "WorkflowInstance",
        back_populates="checkpoints",
    )

    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint(
            "workflow_instance_id",
            "checkpoint_number",
            name="uq_checkpoint_number",
        ),
        Index("idx_checkpoint_workflow", "workflow_instance_id"),
        Index("idx_checkpoint_created", "created_at"),
    )

    @classmethod
    def compute_hash(cls, state_snapshot: dict[str, Any]) -> str:
        """Compute SHA-256 hash of checkpoint state.

        Args:
            state_snapshot: Serialized workflow state

        Returns:
            64-character hexadecimal SHA-256 hash

        """
        data = json.dumps(state_snapshot, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()

    def verify_integrity(self) -> bool:
        """Verify checkpoint integrity by recomputing hash.

        Returns:
            True if hash matches, False if tampered

        """
        expected_hash = self.compute_hash(self.state_snapshot)
        result: bool = self.checkpoint_hash == expected_hash
        return result

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"<WorkflowCheckpoint(id={self.id!r}, "
            f"workflow={self.workflow_instance_id!r}, "
            f"number={self.checkpoint_number})>"
        )


class GovernanceKey(Base):
    """Governance signing key storage with KEK-encrypted private keys.

    Stores governance keys (risk_lead, security_lead) with:
    - Private key encrypted using Master KEK (HybridKEM)
    - Public key stored in plaintext (for verification)
    - Version tracking for key rotation
    - Revocation support

    Key Lifecycle:
    - Created with initial version 1
    - Rotated: revoked_at set on old key, new key with version+1 created
    - Revoked: revoked_at set, key no longer usable for signing

    Attributes:
        id: UUID primary key
        role: Key role ('risk_lead', 'security_lead')
        algorithm: Signing algorithm ('bip322-simple', 'hybrid-mldsa44', etc.)
        encrypted_private_key: KEK-encrypted private key (HybridEncryptedBlob bytes)
        public_key: Raw public key bytes (plaintext for verification)
        key_version: Sequential version number (for rotation tracking)
        created_at: Key creation timestamp
        rotated_at: When this key was rotated out (None if active)
        revoked_at: When this key was revoked (None if active)
        master_kek_version: Version of KEK used for encryption
        encryption_algorithm: Algorithm used for key encryption
        created_by: Actor who created this key
        metadata: Additional key context (JSONB/JSON)

    GAP-Q2 Phase 2: Key Store Integration

    """

    __tablename__ = "governance_key_store"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    role: Mapped[str] = mapped_column(String(50), nullable=False)
    algorithm: Mapped[str] = mapped_column(String(50), nullable=False)

    # Key material - private encrypted, public plaintext
    encrypted_private_key: Mapped[bytes] = mapped_column(
        LargeBinary,
        nullable=False,
    )
    public_key: Mapped[bytes] = mapped_column(
        LargeBinary,
        nullable=False,
    )

    # Key lifecycle
    key_version: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=_utc_now,
    )
    rotated_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    revoked_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Encryption metadata
    master_kek_version: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )
    encryption_algorithm: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
    )

    # Audit
    created_by: Mapped[str] = mapped_column(String(100), nullable=False)
    key_metadata: Mapped[dict[str, Any]] = mapped_column(
        "metadata",  # Use 'metadata' as column name in database
        JSONType(),
        nullable=False,
        default=dict,
    )

    # Relationships
    usage_records: Mapped[list["KeyUsageAudit"]] = relationship(
        "KeyUsageAudit",
        back_populates="governance_key",
        cascade="all, delete-orphan",
        order_by="KeyUsageAudit.created_at",
    )

    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint(
            "role",
            "algorithm",
            "key_version",
            name="uq_role_algo_version",
        ),
        Index("idx_key_role", "role"),
        Index("idx_key_algorithm", "algorithm"),
        Index("idx_key_kek_version", "master_kek_version"),
        Index(
            "idx_key_active",
            "role",
            "algorithm",
            postgresql_where="revoked_at IS NULL",
        ),
    )

    @property
    def is_active(self) -> bool:
        """Check if key is active (not revoked)."""
        return self.revoked_at is None

    def __repr__(self) -> str:
        """String representation for debugging."""
        status = "active" if self.is_active else "revoked"
        return (
            f"<GovernanceKey(id={self.id!r}, role={self.role!r}, "
            f"algorithm={self.algorithm!r}, v{self.key_version}, {status})>"
        )


class KeyUsageAudit(Base):
    """Audit trail for key operations with hash chain integrity.

    Records every operation on governance keys:
    - 'create': Initial key generation
    - 'sign': Key used for signing
    - 'verify': Key used for verification
    - 'rotate': Key rotated to new version
    - 'revoke': Key revoked

    Hash Chain:
    - Each record includes hash of previous record
    - Enables detection of audit trail tampering
    - Same pattern as WorkflowTransition

    Attributes:
        id: UUID primary key
        key_id: Reference to governance key
        operation: Operation type
        actor_id: Actor who performed operation
        context: Additional context (proposal_id, etc.)
        operation_hash: SHA-256 hash for integrity
        previous_hash: Hash of previous audit record (for chaining)
        created_at: Operation timestamp

    GAP-Q2 Phase 2: Key Store Integration

    """

    __tablename__ = "key_usage_audit"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    key_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("governance_key_store.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Operation details
    operation: Mapped[str] = mapped_column(String(50), nullable=False)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    context: Mapped[dict[str, Any]] = mapped_column(
        JSONType(),
        nullable=False,
        default=dict,
    )

    # Hash chain for integrity
    operation_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    previous_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=_utc_now,
    )

    # Relationships
    governance_key: Mapped["GovernanceKey"] = relationship(
        "GovernanceKey",
        back_populates="usage_records",
    )

    # Indexes
    __table_args__ = (
        Index("idx_usage_key", "key_id"),
        Index("idx_usage_actor", "actor_id"),
        Index("idx_usage_operation", "operation"),
        Index("idx_usage_created", "created_at"),
    )

    @classmethod
    def compute_hash(
        cls,
        key_id: str,
        operation: str,
        actor_id: str,
        timestamp: datetime,
        previous_hash: Optional[str] = None,
        context: Optional[dict[str, Any]] = None,
    ) -> str:
        """Compute SHA-256 hash for audit integrity.

        Creates a cryptographic chain by including the previous audit hash.
        Same pattern as WorkflowTransition.compute_hash.

        Args:
            key_id: Governance key ID
            operation: Operation type
            actor_id: Actor who performed operation
            timestamp: Operation timestamp
            previous_hash: Hash of previous audit record (for chaining)
            context: Operation context (proposal_id, etc.) - included for integrity

        Returns:
            64-character hexadecimal SHA-256 hash

        """
        data = json.dumps(
            {
                "key_id": key_id,
                "operation": operation,
                "actor_id": actor_id,
                "timestamp": timestamp.isoformat(),
                "previous_hash": previous_hash or "",
                "context": context or {},
            },
            sort_keys=True,
        )
        return hashlib.sha256(data.encode()).hexdigest()

    def verify_hash(self) -> bool:
        """Verify this audit record's hash.

        Returns:
            True if hash is valid, False if tampered

        """
        # Ensure timestamp is timezone-aware (SQLite may strip timezone)
        ts = self.created_at
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        expected = self.compute_hash(
            key_id=self.key_id,
            operation=self.operation,
            actor_id=self.actor_id,
            timestamp=ts,
            previous_hash=self.previous_hash,
            context=self.context,
        )
        result: bool = self.operation_hash == expected
        return result

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"<KeyUsageAudit(id={self.id!r}, key={self.key_id!r}, "
            f"operation={self.operation!r}, actor={self.actor_id!r})>"
        )
