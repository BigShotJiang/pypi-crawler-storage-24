"""Key Store Repository - Secure Governance Key Storage.

Provides persistent storage for governance signing keys (risk_lead, security_lead)
with KEK-encrypted private keys and hash-chained audit trail.

Key Operations:
    - store_key: Encrypt and store new governance key
    - get_private_key: Decrypt and return private key for signing
    - get_public_key: Return public key for verification
    - rotate_key: Create new version, revoke old
    - revoke_key: Mark key as inactive
    - record_usage: Log operation in audit trail
    - get_audit_trail: Retrieve operation history

Security Properties:
    - Private keys encrypted at rest using HybridKEM
    - Master KEK never stored in database
    - Hash-chained audit trail for tamper detection
    - Key versioning for rotation support

Thread Safety:
    All methods are async and use separate sessions per operation.
    Safe for concurrent use from multiple coroutines.

GAP-Q2 Phase 2: Key Store Integration
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import uuid4

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from crypto.kek_provider import KEKProvider
from workflows.persistence.engine import (
    DatabaseConfig,
    create_database_engine,
    create_session_factory,
    init_database,
)
from workflows.persistence.models import (
    GovernanceKey,
    KeyUsageAudit,
)

logger = logging.getLogger(__name__)


class KeyStoreRepository:
    """Async key store with KEK encryption.

    Provides secure storage for governance signing keys with:
    - KEK-encrypted private keys (using HybridKEM)
    - Plaintext public keys (for verification)
    - Version tracking for key rotation
    - Hash-chained audit trail

    Example:
        # Initialize
        config = DatabaseConfig.for_testing()
        kek_provider = InMemoryKEKProvider()
        key_store = KeyStoreRepository(config=config, kek_provider=kek_provider)
        await key_store.initialize()

        # Store governance key
        from crypto import get_default_provider
        provider = get_default_provider()
        private_key, public_key = provider.generate_keypair()

        key_id = await key_store.store_key(
            role="risk_lead",
            algorithm=provider.algorithm_name,
            private_key=private_key,
            public_key=public_key,
            created_by="admin@aegis.io",
        )

        # Retrieve private key for signing
        private_key = await key_store.get_private_key("risk_lead", "bip322-simple")

        # Rotate key
        new_key_id = await key_store.rotate_key(
            role="risk_lead",
            algorithm="bip322-simple",
            new_private_key=new_private,
            new_public_key=new_public,
            actor_id="admin@aegis.io",
        )

    """

    def __init__(
        self,
        config: Optional[DatabaseConfig] = None,
        engine: Optional[AsyncEngine] = None,
        kek_provider: Optional[KEKProvider] = None,
    ):
        """Initialize key store repository.

        Args:
            config: Database configuration (creates new engine)
            engine: Pre-configured async engine (for sharing)
            kek_provider: KEK provider for key encryption/decryption

        """
        if config and engine:
            raise ValueError("Provide either config or engine, not both")

        if engine:
            self._engine = engine
            self._owns_engine = False
        elif config:
            self._engine = create_database_engine(config)
            self._owns_engine = True
        else:
            raise ValueError("Provide either config or engine")

        self._session_factory = create_session_factory(self._engine)
        self._kek_provider = kek_provider
        self._initialized = False
        self._audit_lock = asyncio.Lock()

    @property
    def engine(self) -> AsyncEngine:
        """Get the database engine."""
        return self._engine

    @property
    def session_factory(self) -> async_sessionmaker[AsyncSession]:
        """Get the session factory."""
        return self._session_factory

    async def initialize(self) -> None:
        """Initialize database schema.

        Creates tables if they don't exist. Safe to call multiple times.
        """
        await init_database(self._engine)
        self._initialized = True

    async def close(self) -> None:
        """Close database connections.

        Only disposes engine if we own it (created from config).
        """
        if self._owns_engine:
            await self._engine.dispose()

    def _ensure_kek_provider(self) -> KEKProvider:
        """Ensure KEK provider is configured."""
        if self._kek_provider is None:
            raise RuntimeError(
                "KEK provider not configured. "
                "Provide kek_provider to KeyStoreRepository constructor.",
            )
        return self._kek_provider

    # =========================================================================
    # Key Storage Operations
    # =========================================================================

    async def store_key(
        self,
        role: str,
        algorithm: str,
        private_key: bytes,
        public_key: bytes,
        created_by: str,
        metadata: Optional[dict[str, Any]] = None,
    ) -> str:
        """Encrypt and store a new governance key.

        Args:
            role: Key role ('risk_lead', 'security_lead')
            algorithm: Signing algorithm ('bip322-simple', 'hybrid-mldsa44')
            private_key: Raw private key bytes
            public_key: Raw public key bytes
            created_by: Actor ID creating the key
            metadata: Additional key metadata

        Returns:
            Key ID (UUID string)

        Raises:
            ValueError: If active key already exists for role/algorithm
            RuntimeError: If KEK provider not configured

        """
        kek = self._ensure_kek_provider()

        # fmt: off  # Python 3.9 compat: parenthesized async with is 3.10+ only
        async with self._audit_lock, self._session_factory() as session, session.begin():
            # fmt: on
            # Check for existing active key
            existing = await self._get_active_key(session, role, algorithm)
            if existing is not None:
                raise ValueError(
                    f"Active key already exists for {role}/{algorithm}. "
                    f"Use rotate_key() to create new version.",
                )

            # Encrypt private key with KEK
            encrypted_private = kek.encrypt(private_key)

            # Get next version number
            next_version = await self._get_next_version(session, role, algorithm)

            # Create key record
            key = GovernanceKey(
                id=str(uuid4()),
                role=role,
                algorithm=algorithm,
                encrypted_private_key=encrypted_private,
                public_key=public_key,
                key_version=next_version,
                master_kek_version=kek.current_version,
                encryption_algorithm=kek.algorithm_name,
                created_by=created_by,
                key_metadata=metadata or {},
            )
            session.add(key)

            # Record audit
            await self._record_audit(
                session,
                key_id=key.id,
                operation="create",
                actor_id=created_by,
                context={
                    "role": role,
                    "algorithm": algorithm,
                    "version": next_version,
                },
            )

            logger.info(
                f"Governance key stored: role={role}, algorithm={algorithm}, "
                f"version={next_version}, id={key.id}",
            )

            key_id: str = key.id
            return key_id

    async def get_private_key(
        self,
        role: str,
        algorithm: str,
        version: Optional[int] = None,
    ) -> Optional[bytes]:
        """Decrypt and return private key for signing.

        Args:
            role: Key role
            algorithm: Signing algorithm
            version: Specific version (None = current active)

        Returns:
            Decrypted private key bytes, or None if not found

        Raises:
            RuntimeError: If KEK provider not configured

        """
        kek = self._ensure_kek_provider()

        # BH39-M3: release _audit_lock before calling kek.decrypt() — the
        # ML-KEM-768 decapsulation is an expensive CPU-bound operation that
        # previously blocked all other audit operations (record_usage, store_key,
        # rotate_key, revoke_key) for its entire duration.  Instead, we fetch
        # the key data under the lock, then decrypt outside it.  The TOCTOU
        # revocation guard is still enforced under the lock; decrypting a key
        # that is revoked between the lock release and decrypt() is harmless
        # because the caller (sign_with_stored_key) re-validates via get_key_info.
        async with self._audit_lock, self._session_factory() as session:
            if version is None:
                key = await self._get_active_key(session, role, algorithm)
            else:
                key = await self._get_key_by_version(session, role, algorithm, version)

            if key is None:
                return None

            # TOCTOU guard: when fetching the "current active" key (version=None),
            # re-check revocation under lock to prevent race with concurrent
            # revoke_key().  Explicit version requests skip this check — the
            # caller deliberately asked for a historical key (e.g., for
            # verification of old signatures).
            if version is None and key.revoked_at is not None:
                return None

            # Capture encrypted bytes and metadata; lock is released after
            # this block, before the expensive kek.decrypt() call below.
            encrypted_private_key = key.encrypted_private_key
            master_kek_version = key.master_kek_version
            key_id = key.id

        # Decrypt outside the lock — ML-KEM-768 decapsulation is CPU-bound
        # and can block other coroutines for tens of milliseconds.
        try:
            private_key = kek.decrypt(
                encrypted_private_key,
                version=master_kek_version,
            )
            return private_key
        except ValueError as e:
            logger.error(f"Failed to decrypt key {key_id}: {e}")
            raise RuntimeError(f"Key decryption failed: {e}") from e

    async def get_public_key(
        self,
        role: str,
        algorithm: str,
        version: Optional[int] = None,
    ) -> Optional[bytes]:
        """Return public key for verification.

        Args:
            role: Key role
            algorithm: Signing algorithm
            version: Specific version (None = current active)

        Returns:
            Raw public key bytes, or None if not found

        """
        async with self._audit_lock, self._session_factory() as session:
            if version is None:
                key = await self._get_active_key(session, role, algorithm)
            else:
                key = await self._get_key_by_version(session, role, algorithm, version)

            if key is None:
                return None

            # Revocation check under lock — consistent with get_private_key.
            # Only for "current active" lookups; explicit version requests
            # are deliberate (e.g., verifying old signatures).
            if version is None and key.revoked_at is not None:
                return None

            public_key_bytes: Optional[bytes] = key.public_key
            return public_key_bytes

    async def key_exists(self, role: str, algorithm: str) -> bool:
        """Check if active key exists for role/algorithm.

        Args:
            role: Key role
            algorithm: Signing algorithm

        Returns:
            True if active key exists

        """
        async with self._session_factory() as session:
            key = await self._get_active_key(session, role, algorithm)
            return key is not None

    # =========================================================================
    # Key Rotation Operations
    # =========================================================================

    async def rotate_key(
        self,
        role: str,
        algorithm: str,
        new_private_key: bytes,
        new_public_key: bytes,
        actor_id: str,
        reason: Optional[str] = None,
    ) -> str:
        """Rotate key (new version, revoke old).

        Creates a new key version and revokes the old one.
        Old key remains in database for signature verification.

        Args:
            role: Key role
            algorithm: Signing algorithm
            new_private_key: New private key bytes
            new_public_key: New public key bytes
            actor_id: Actor performing rotation
            reason: Optional rotation reason

        Returns:
            New key ID

        Raises:
            ValueError: If no active key exists to rotate

        """
        kek = self._ensure_kek_provider()

        # fmt: off  # Python 3.9 compat: parenthesized async with is 3.10+ only
        async with self._audit_lock, self._session_factory() as session, session.begin():
            # fmt: on
            # Get current active key
            old_key = await self._get_active_key(session, role, algorithm)
            if old_key is None:
                raise ValueError(
                    f"No active key to rotate for {role}/{algorithm}. "
                    f"Use store_key() for initial key creation.",
                )

            now = datetime.now(timezone.utc)

            # Revoke old key
            old_key.revoked_at = now
            old_key.rotated_at = now

            # Create new key
            encrypted_private = kek.encrypt(new_private_key)
            new_version = old_key.key_version + 1

            new_key = GovernanceKey(
                id=str(uuid4()),
                role=role,
                algorithm=algorithm,
                encrypted_private_key=encrypted_private,
                public_key=new_public_key,
                key_version=new_version,
                master_kek_version=kek.current_version,
                encryption_algorithm=kek.algorithm_name,
                created_by=actor_id,
                key_metadata={
                    "rotated_from": old_key.id,
                    "rotation_reason": reason,
                },
            )
            session.add(new_key)

            # Audit old key revocation
            await self._record_audit(
                session,
                key_id=old_key.id,
                operation="revoke",
                actor_id=actor_id,
                context={
                    "reason": "rotation",
                    "new_key_id": new_key.id,
                    "new_version": new_version,
                },
            )

            # Audit new key creation
            await self._record_audit(
                session,
                key_id=new_key.id,
                operation="rotate",
                actor_id=actor_id,
                context={
                    "old_key_id": old_key.id,
                    "old_version": old_key.key_version,
                    "reason": reason,
                },
            )

            logger.info(
                f"Key rotated: {role}/{algorithm} v{old_key.key_version} -> "
                f"v{new_version}, old_id={old_key.id}, new_id={new_key.id}",
            )

            new_key_id: str = new_key.id
            return new_key_id

    async def revoke_key(
        self,
        role: str,
        algorithm: str,
        actor_id: str,
        reason: Optional[str] = None,
    ) -> bool:
        """Revoke active key (without creating new one).

        Use this for emergency revocation. After revocation, no active key
        exists for the role/algorithm until store_key() is called.

        Args:
            role: Key role
            algorithm: Signing algorithm
            actor_id: Actor performing revocation
            reason: Revocation reason

        Returns:
            True if key was revoked, False if no active key

        """
        # fmt: off  # Python 3.9 compat: parenthesized async with is 3.10+ only
        async with self._audit_lock, self._session_factory() as session, session.begin():
            # fmt: on
            key = await self._get_active_key(session, role, algorithm)
            if key is None:
                return False

            key.revoked_at = datetime.now(timezone.utc)

            await self._record_audit(
                session,
                key_id=key.id,
                operation="revoke",
                actor_id=actor_id,
                context={
                    "reason": reason or "manual_revocation",
                },
            )

            logger.info(
                f"Key revoked: {role}/{algorithm} v{key.key_version}, "
                f"id={key.id}, reason={reason}",
            )

            return True

    # =========================================================================
    # Audit Operations
    # =========================================================================

    async def record_usage(
        self,
        role: str,
        algorithm: str,
        operation: str,
        actor_id: str,
        context: Optional[dict[str, Any]] = None,
        version: Optional[int] = None,
    ) -> None:
        """Record key usage in audit trail.

        Args:
            role: Key role
            algorithm: Signing algorithm
            operation: Operation type ('sign', 'verify', etc.)
            actor_id: Actor performing operation
            context: Additional operation context
            version: Specific key version to attribute usage to
                (None = current active key)

        """
        # fmt: off  # Python 3.9 compat: parenthesized async with is 3.10+ only
        async with self._audit_lock, self._session_factory() as session, session.begin():
            # fmt: on
            if version is None:
                key = await self._get_active_key(session, role, algorithm)
            else:
                key = await self._get_key_by_version(
                    session,
                    role,
                    algorithm,
                    version,
                )
            if key is not None:
                await self._record_audit(
                    session,
                    key_id=key.id,
                    operation=operation,
                    actor_id=actor_id,
                    context=context or {},
                )
            else:
                logger.warning(
                    f"record_usage: No key found for role={role}, "
                    f"algorithm={algorithm}, version={version}. "
                    "Audit entry not created."
                )

    async def get_audit_trail(
        self,
        role: str,
        algorithm: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get audit trail for role/algorithm.

        Args:
            role: Key role
            algorithm: Signing algorithm
            limit: Maximum records to return

        Returns:
            List of audit records (newest first)

        """
        async with self._session_factory() as session:
            # Get all keys for role/algorithm
            result = await session.execute(
                select(GovernanceKey.id).where(
                    and_(
                        GovernanceKey.role == role,
                        GovernanceKey.algorithm == algorithm,
                    ),
                ),
            )
            key_ids = [row[0] for row in result.fetchall()]

            if not key_ids:
                return []

            # Get audit records for all versions
            result = await session.execute(
                select(KeyUsageAudit)
                .where(KeyUsageAudit.key_id.in_(key_ids))
                .order_by(KeyUsageAudit.created_at.desc())
                .limit(limit),
            )
            records = result.scalars().all()

            return [
                {
                    "id": r.id,
                    "key_id": r.key_id,
                    "operation": r.operation,
                    "actor_id": r.actor_id,
                    "context": r.context,
                    "created_at": r.created_at.isoformat(),
                    "operation_hash": r.operation_hash,
                    "previous_hash": r.previous_hash,
                }
                for r in records
            ]

    async def verify_audit_chain(
        self,
        role: str,
        algorithm: str,
    ) -> tuple[bool, Optional[str]]:
        """Verify integrity of audit trail hash chain.

        Args:
            role: Key role
            algorithm: Signing algorithm

        Returns:
            (is_valid, error_message) tuple

        """
        async with self._session_factory() as session:
            # Get all keys for role/algorithm
            result = await session.execute(
                select(GovernanceKey.id).where(
                    and_(
                        GovernanceKey.role == role,
                        GovernanceKey.algorithm == algorithm,
                    ),
                ),
            )
            key_ids = [row[0] for row in result.fetchall()]

            if not key_ids:
                return True, None  # Empty chain is valid

            # Verify each key's audit chain independently
            # (each key has its own hash chain, not shared across keys)
            for key_id in key_ids:
                result = await session.execute(
                    select(KeyUsageAudit)
                    .where(KeyUsageAudit.key_id == key_id)
                    .order_by(KeyUsageAudit.created_at.asc()),
                )
                records = list(result.scalars().all())

                if not records:
                    continue  # No audit records for this key is valid

                # Verify this key's hash chain
                expected_previous: Optional[str] = None
                for record in records:
                    # Verify this record's hash
                    if not record.verify_hash():
                        return False, f"Hash mismatch at record {record.id}"

                    # Verify chain linkage
                    if record.previous_hash != expected_previous:
                        return False, f"Chain broken at record {record.id}"

                    expected_previous = record.operation_hash

            return True, None

    # =========================================================================
    # Query Operations
    # =========================================================================

    async def list_keys(
        self,
        role: Optional[str] = None,
        algorithm: Optional[str] = None,
        include_revoked: bool = False,
    ) -> list[dict[str, Any]]:
        """List governance keys.

        Args:
            role: Filter by role (None = all)
            algorithm: Filter by algorithm (None = all)
            include_revoked: Include revoked keys

        Returns:
            List of key summaries

        """
        async with self._session_factory() as session:
            query = select(GovernanceKey)

            conditions = []
            if role:
                conditions.append(GovernanceKey.role == role)
            if algorithm:
                conditions.append(GovernanceKey.algorithm == algorithm)
            if not include_revoked:
                conditions.append(GovernanceKey.revoked_at.is_(None))

            if conditions:
                query = query.where(and_(*conditions))

            query = query.order_by(
                GovernanceKey.role,
                GovernanceKey.algorithm,
                GovernanceKey.key_version.desc(),
            )

            result = await session.execute(query)
            keys = result.scalars().all()

            return [
                {
                    "id": k.id,
                    "role": k.role,
                    "algorithm": k.algorithm,
                    "key_version": k.key_version,
                    "created_at": k.created_at.isoformat(),
                    "revoked_at": k.revoked_at.isoformat() if k.revoked_at else None,
                    "created_by": k.created_by,
                    "is_active": k.is_active,
                }
                for k in keys
            ]

    async def get_key_info(
        self,
        role: str,
        algorithm: str,
        version: Optional[int] = None,
    ) -> Optional[dict[str, Any]]:
        """Get detailed key information (without private key).

        Args:
            role: Key role
            algorithm: Signing algorithm
            version: Specific version (None = active)

        Returns:
            Key info dict or None

        """
        async with self._session_factory() as session:
            if version is None:
                key = await self._get_active_key(session, role, algorithm)
            else:
                key = await self._get_key_by_version(session, role, algorithm, version)

            if key is None:
                return None

            return {
                "id": key.id,
                "role": key.role,
                "algorithm": key.algorithm,
                "key_version": key.key_version,
                "public_key_size": len(key.public_key),
                "encrypted_private_key_size": len(key.encrypted_private_key),
                "created_at": key.created_at.isoformat(),
                "rotated_at": key.rotated_at.isoformat() if key.rotated_at else None,
                "revoked_at": key.revoked_at.isoformat() if key.revoked_at else None,
                "master_kek_version": key.master_kek_version,
                "encryption_algorithm": key.encryption_algorithm,
                "created_by": key.created_by,
                "metadata": key.key_metadata,
                "is_active": key.is_active,
            }

    # =========================================================================
    # Private Helper Methods
    # =========================================================================

    async def _get_active_key(
        self,
        session: AsyncSession,
        role: str,
        algorithm: str,
    ) -> Optional[GovernanceKey]:
        """Get active (non-revoked) key for role/algorithm."""
        result = await session.execute(
            select(GovernanceKey).where(
                and_(
                    GovernanceKey.role == role,
                    GovernanceKey.algorithm == algorithm,
                    GovernanceKey.revoked_at.is_(None),
                ),
            ),
        )
        key: Optional[GovernanceKey] = result.scalar_one_or_none()
        return key

    async def _get_key_by_version(
        self,
        session: AsyncSession,
        role: str,
        algorithm: str,
        version: int,
    ) -> Optional[GovernanceKey]:
        """Get specific key version."""
        result = await session.execute(
            select(GovernanceKey).where(
                and_(
                    GovernanceKey.role == role,
                    GovernanceKey.algorithm == algorithm,
                    GovernanceKey.key_version == version,
                ),
            ),
        )
        key: Optional[GovernanceKey] = result.scalar_one_or_none()
        return key

    async def _get_next_version(
        self,
        session: AsyncSession,
        role: str,
        algorithm: str,
    ) -> int:
        """Get next version number for role/algorithm."""
        from sqlalchemy import func

        result = await session.execute(
            select(func.coalesce(func.max(GovernanceKey.key_version), 0)).where(
                and_(
                    GovernanceKey.role == role,
                    GovernanceKey.algorithm == algorithm,
                ),
            ),
        )
        max_version = result.scalar_one()
        next_version: int = max_version + 1
        return next_version

    async def _record_audit(
        self,
        session: AsyncSession,
        key_id: str,
        operation: str,
        actor_id: str,
        context: dict[str, Any],
    ) -> None:
        """Record audit entry with hash chain."""
        # Get previous hash
        result = await session.execute(
            select(KeyUsageAudit.operation_hash)
            .where(KeyUsageAudit.key_id == key_id)
            .order_by(KeyUsageAudit.created_at.desc())
            .limit(1),
        )
        previous_hash = result.scalar_one_or_none()

        now = datetime.now(timezone.utc)
        operation_hash = KeyUsageAudit.compute_hash(
            key_id=key_id,
            operation=operation,
            actor_id=actor_id,
            timestamp=now,
            previous_hash=previous_hash,
            context=context,
        )

        audit = KeyUsageAudit(
            id=str(uuid4()),
            key_id=key_id,
            operation=operation,
            actor_id=actor_id,
            context=context,
            operation_hash=operation_hash,
            previous_hash=previous_hash,
            created_at=now,
        )
        session.add(audit)


__all__ = ["KeyStoreRepository"]
