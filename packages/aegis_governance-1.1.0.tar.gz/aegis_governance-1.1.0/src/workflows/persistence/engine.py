"""Database Engine Configuration

Provides async database engine and session factory for workflow persistence.
Supports PostgreSQL (production) and SQLite (testing) backends.

Configuration:
    - PostgreSQL: postgresql+asyncpg://user:pass@host/db
    - SQLite: sqlite+aiosqlite:///path/to/db.sqlite
    - SQLite in-memory: sqlite+aiosqlite:///:memory:

Usage:
    # Production PostgreSQL
    config = DatabaseConfig(
        url="postgresql+asyncpg://user:pass@localhost/aegis",
        pool_size=10,
        echo=False,
    )

    # Testing SQLite (in-memory)
    config = DatabaseConfig.for_testing()

    # Create engine and session factory
    engine = create_database_engine(config)
    session_factory = create_session_factory(engine)
"""

from dataclasses import dataclass, field
from typing import Any, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool, StaticPool

from workflows.persistence.models import Base


@dataclass
class DatabaseConfig:
    """Database connection configuration.

    Attributes:
        url: Database URL (SQLAlchemy async format)
        pool_size: Connection pool size (PostgreSQL only)
        max_overflow: Maximum overflow connections (PostgreSQL only)
        pool_timeout: Pool checkout timeout in seconds
        pool_recycle: Connection recycle time in seconds
        echo: Log SQL statements (for debugging)
        echo_pool: Log pool events (for debugging)
        connect_args: Additional driver-specific arguments

    """

    url: str
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    pool_recycle: int = 1800  # 30 minutes
    echo: bool = False
    echo_pool: bool = False
    connect_args: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def for_testing(cls, path: Optional[str] = None) -> "DatabaseConfig":
        """Create configuration for testing with SQLite.

        Args:
            path: Optional file path. If None, uses in-memory database.

        Returns:
            DatabaseConfig configured for SQLite testing

        """
        url = f"sqlite+aiosqlite:///{path}" if path else "sqlite+aiosqlite:///:memory:"

        return cls(
            url=url,
            echo=False,
            # SQLite requires check_same_thread=False for async
            connect_args={"check_same_thread": False},
        )

    @classmethod
    def for_postgresql(
        cls,
        host: str = "localhost",
        port: int = 5432,
        database: str = "aegis",
        user: str = "aegis",
        password: str = "",  # nosec B107
        **kwargs: Any,
    ) -> "DatabaseConfig":
        """Create configuration for PostgreSQL.

        Args:
            host: Database host
            port: Database port
            database: Database name
            user: Database user
            password: Database password
            **kwargs: Additional configuration options

        Returns:
            DatabaseConfig configured for PostgreSQL

        """
        from sqlalchemy.engine import URL

        url = URL.create(
            drivername="postgresql+asyncpg",
            username=user,
            password=password,
            host=host,
            port=port,
            database=database,
        )
        return cls(url=url.render_as_string(hide_password=False), **kwargs)

    @property
    def is_sqlite(self) -> bool:
        """Check if configuration is for SQLite."""
        return self.url.startswith("sqlite")

    @property
    def is_memory(self) -> bool:
        """Check if configuration is for in-memory SQLite."""
        return ":memory:" in self.url


def create_database_engine(config: DatabaseConfig) -> AsyncEngine:
    """Create async database engine from configuration.

    Configures appropriate pooling strategy based on database type:
    - PostgreSQL: Connection pooling with configurable size
    - SQLite file: NullPool (no persistent connections)
    - SQLite memory: StaticPool (single shared connection)

    Args:
        config: Database configuration

    Returns:
        Configured AsyncEngine instance

    """
    engine_kwargs: dict[str, Any] = {
        "echo": config.echo,
        "echo_pool": config.echo_pool,
    }

    if config.connect_args:
        engine_kwargs["connect_args"] = config.connect_args

    if config.is_sqlite:
        if config.is_memory:
            # In-memory SQLite needs StaticPool to maintain single connection
            engine_kwargs["poolclass"] = StaticPool
        else:
            # File-based SQLite should not use connection pooling
            engine_kwargs["poolclass"] = NullPool
    else:
        # PostgreSQL uses connection pooling
        engine_kwargs.update(
            {
                "pool_size": config.pool_size,
                "max_overflow": config.max_overflow,
                "pool_timeout": config.pool_timeout,
                "pool_recycle": config.pool_recycle,
                "pool_pre_ping": True,  # Verify connections before use
            },
        )

    return create_async_engine(config.url, **engine_kwargs)


def create_session_factory(
    engine: AsyncEngine,
    expire_on_commit: bool = False,
) -> async_sessionmaker[AsyncSession]:
    """Create async session factory.

    Args:
        engine: Database engine
        expire_on_commit: Whether to expire objects after commit.
            Set to False for better performance with read-after-write patterns.

    Returns:
        Configured session factory

    """
    return async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=expire_on_commit,
        autoflush=True,
        autocommit=False,
    )


async def init_database(engine: AsyncEngine) -> None:
    """Initialize database schema.

    Creates all tables defined in the ORM models.
    Safe to call multiple times (uses CREATE IF NOT EXISTS).

    Args:
        engine: Database engine

    Example:
        engine = create_database_engine(config)
        await init_database(engine)

    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def drop_database(engine: AsyncEngine) -> None:
    """Drop all database tables.

    WARNING: This permanently deletes all data. Use only in testing.

    Args:
        engine: Database engine

    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


async def health_check(engine: AsyncEngine) -> bool:
    """Check database connectivity.

    Performs a simple query to verify the database is accessible.

    Args:
        engine: Database engine

    Returns:
        True if database is healthy, False otherwise

    """
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return True
    except (
        Exception
    ):  # Intentional: health probe — connection errors expected when DB unconfigured
        return False
