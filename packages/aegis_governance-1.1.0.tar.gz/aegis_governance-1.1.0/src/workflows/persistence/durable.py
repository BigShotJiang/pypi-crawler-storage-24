"""Durable Workflow Engine

Provides a wrapper that adds automatic persistence to workflow instances.
Handles checkpoint management, crash recovery, and state restoration.

Usage:
    from workflows.persistence import WorkflowPersistence, DurableWorkflowEngine
    from workflows.proposal import ProposalWorkflow

    # Initialize
    persistence = WorkflowPersistence(config)
    await persistence.initialize()

    engine = DurableWorkflowEngine(persistence)

    # Create new durable workflow
    workflow = await engine.create(
        ProposalWorkflow,
        workflow_id="prop-123",
        metadata=ProposalMetadata(...),
    )

    # Workflow state automatically persisted on transitions
    workflow.transition_to(ProposalState.SUBMITTED, actor_id="user-1")

    # Resume existing workflow after crash
    workflow = await engine.resume(ProposalWorkflow, "prop-123")
"""

import inspect
import logging
from dataclasses import dataclass
from typing import Any, Optional, TypeVar, cast

from workflows.persistence.repository import SerializableWorkflow, WorkflowPersistence

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=SerializableWorkflow)


@dataclass
class DurableWorkflowContext:
    """Context for durable workflow operations.

    Tracks persistence state and provides actor context for transitions.
    """

    persistence: WorkflowPersistence
    actor_id: str
    auto_checkpoint: bool = True
    checkpoint_on_transition: bool = True


class DurableWorkflowEngine:
    """Engine for managing durable workflows.

    Provides:
    - Workflow creation with automatic persistence
    - Crash recovery and resume capability
    - Batch operations for multiple workflows
    - Lifecycle management (create, resume, complete, abort)
    """

    def __init__(
        self,
        persistence: WorkflowPersistence,
        default_actor_id: str = "system",
    ):
        """Initialize durable workflow engine.

        Args:
            persistence: WorkflowPersistence instance
            default_actor_id: Default actor ID for system operations

        """
        self._persistence = persistence
        self._default_actor_id = default_actor_id

    @property
    def persistence(self) -> WorkflowPersistence:
        """Get the persistence layer."""
        return self._persistence

    async def create(
        self,
        workflow_class: type[T],
        actor_id: Optional[str] = None,
        **init_kwargs: Any,
    ) -> T:
        """Create a new durable workflow.

        Creates the workflow instance and immediately persists the initial state.

        Args:
            workflow_class: Workflow class to instantiate
            actor_id: Actor creating the workflow
            **init_kwargs: Arguments passed to workflow constructor

        Returns:
            New workflow instance

        Example:
            workflow = await engine.create(
                ProposalWorkflow,
                actor_id="user-123",
                proposal_id="prop-456",
                metadata=ProposalMetadata(...),
            )

        """
        workflow = workflow_class(**init_kwargs)

        # Save initial checkpoint
        await self._persistence.save_checkpoint(
            workflow=workflow,
            actor_id=actor_id or self._default_actor_id,
            transition_reason="Workflow created",
        )

        return workflow

    async def resume(
        self,
        workflow_class: type[T],
        workflow_id: str,
    ) -> Optional[T]:
        """Resume a workflow from its last checkpoint.

        Args:
            workflow_class: Expected workflow class
            workflow_id: Workflow identifier

        Returns:
            Restored workflow instance, or None if not found

        Example:
            workflow = await engine.resume(ProposalWorkflow, "prop-456")
            if workflow:
                # Continue processing
                workflow.transition_to(...)

        """
        state_data = await self._persistence.load_checkpoint(workflow_id)

        if state_data is None:
            return None

        return cast("T", workflow_class.from_dict(state_data))

    async def resume_or_create(
        self,
        workflow_class: type[T],
        workflow_id: str,
        actor_id: Optional[str] = None,
        strict_id: bool = True,
        **create_kwargs: Any,
    ) -> tuple[T, bool]:
        """Resume existing workflow or create new one.

        Args:
            workflow_class: Workflow class
            workflow_id: Workflow identifier to resume or use for creation
            actor_id: Actor ID for creation
            strict_id: If True (default), raise ValueError when resumed workflow's
                workflow_id differs from the requested workflow_id. This indicates
                a bug in the caller (workflow_id should match). The same validation
                is applied after creating a new workflow. If False, logs a
                warning and returns the stored workflow (legacy behavior).
            **create_kwargs: Arguments for new workflow creation

        Returns:
            Tuple of (workflow, is_new) where is_new indicates if created

        Raises:
            ValueError: If strict_id=True and resumed/created workflow has different
                workflow_id than requested (indicates caller bug)

        Note:
            ID mismatch typically indicates one of:
            1. workflow_id parameter doesn't match the key used to persist
            2. workflow_class.from_dict() reconstructs workflow_id differently
            3. Corruption in persisted data

        """
        # Try to resume first
        workflow = await self.resume(workflow_class, workflow_id)

        if workflow:
            # Verify workflow_id matches (B3-5 fix)
            if workflow.workflow_id != workflow_id:
                if strict_id:
                    raise ValueError(
                        f"Workflow ID mismatch: requested '{workflow_id}' but "
                        f"restored workflow has ID '{workflow.workflow_id}'. "
                        "This indicates a bug in the caller or data corruption. "
                        "Use strict_id=False to suppress this error."
                    )
                else:
                    logger.warning(
                        f"Workflow ID mismatch: requested '{workflow_id}' but "
                        f"restored workflow has ID '{workflow.workflow_id}'. "
                        "Returning stored workflow (strict_id=False)."
                    )
            return workflow, False

        # Create new workflow
        create_kwargs = dict(create_kwargs)

        # Propagate requested workflow_id when constructor uses a known ID parameter.
        # This prevents accidental random-ID creation when callers omit the ID field.
        if "workflow_id" not in create_kwargs and "proposal_id" not in create_kwargs:
            try:
                init_params = dict(inspect.signature(workflow_class).parameters)
            except (TypeError, ValueError):
                init_params = {}

            if "workflow_id" in init_params:
                create_kwargs["workflow_id"] = workflow_id
            elif "proposal_id" in init_params:
                create_kwargs["proposal_id"] = workflow_id

        workflow = await self.create(
            workflow_class,
            actor_id=actor_id,
            **create_kwargs,
        )

        # Validate ID match on creation path too (symmetry with resume path).
        if workflow.workflow_id != workflow_id:
            if strict_id:
                raise ValueError(
                    f"Workflow ID mismatch: requested '{workflow_id}' but "
                    f"created workflow has ID '{workflow.workflow_id}'. "
                    "Ensure create kwargs include the correct identifier field."
                )
            logger.warning(
                f"Workflow ID mismatch: requested '{workflow_id}' but "
                f"created workflow has ID '{workflow.workflow_id}'. "
                "Returning created workflow (strict_id=False)."
            )

        return workflow, True

    async def checkpoint(
        self,
        workflow: SerializableWorkflow,
        actor_id: Optional[str] = None,
        reason: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> str:
        """Create a checkpoint for workflow.

        Args:
            workflow: Workflow to checkpoint
            actor_id: Actor triggering checkpoint
            reason: Optional reason for checkpoint
            metadata: Optional metadata

        Returns:
            Checkpoint ID

        """
        return await self._persistence.save_checkpoint(
            workflow=workflow,
            actor_id=actor_id or self._default_actor_id,
            transition_reason=reason,
            transition_metadata=metadata,
        )

    async def complete(
        self,
        workflow: SerializableWorkflow,
        actor_id: Optional[str] = None,
        final_state: Optional[str] = None,
    ) -> bool:
        """Mark workflow as completed.

        Args:
            workflow: Workflow to complete
            actor_id: Actor completing workflow
            final_state: Final state (defaults to current state)

        Returns:
            True if marked completed

        """
        return await self._persistence.mark_completed(
            workflow_id=workflow.workflow_id,
            actor_id=actor_id or self._default_actor_id,
            final_state=final_state or workflow.current_state,
        )

    async def abort(
        self,
        workflow: SerializableWorkflow,
        actor_id: Optional[str] = None,
        reason: str = "Workflow aborted",
    ) -> bool:
        """Abort workflow with reason.

        Args:
            workflow: Workflow to abort
            actor_id: Actor aborting workflow
            reason: Abort reason

        Returns:
            True if aborted

        """
        # Save final checkpoint with abort reason
        await self._persistence.save_checkpoint(
            workflow=workflow,
            actor_id=actor_id or self._default_actor_id,
            transition_reason=reason,
            transition_metadata={"aborted": True, "abort_reason": reason},
        )

        return await self._persistence.mark_completed(
            workflow_id=workflow.workflow_id,
            actor_id=actor_id or self._default_actor_id,
            final_state="aborted",
        )

    async def delete(
        self,
        workflow_id: str,
    ) -> bool:
        """Delete workflow and all associated data.

        Args:
            workflow_id: Workflow identifier

        Returns:
            True if deleted

        """
        return await self._persistence.delete_workflow(workflow_id)

    # ========================================================================
    # Batch Operations
    # ========================================================================

    async def list_pending(
        self,
        workflow_type: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List pending (non-completed) workflows.

        Args:
            workflow_type: Optional type filter
            limit: Maximum results

        Returns:
            List of workflow state data

        """
        return await self._persistence.list_pending_workflows(
            workflow_type=workflow_type,
            limit=limit,
        )

    async def resume_all_pending(
        self,
        workflow_class: type[T],
        workflow_type: Optional[str] = None,
        limit: int = 100,
    ) -> list[T]:
        """Resume all pending workflows of a type.

        Args:
            workflow_class: Workflow class
            workflow_type: Type filter
            limit: Maximum workflows to resume

        Returns:
            List of restored workflow instances

        """
        pending = await self.list_pending(workflow_type=workflow_type, limit=limit)

        workflows: list[T] = []
        skipped_count = 0
        for state_data in pending:
            try:
                workflow = cast("T", workflow_class.from_dict(state_data))
                workflows.append(workflow)
            except (KeyError, ValueError, TypeError, AttributeError) as e:
                # Log and skip corrupted/invalid workflows (L11 fix)
                workflow_id = (
                    state_data.get("workflow_id", "unknown")
                    if isinstance(state_data, dict)
                    else "unknown"
                )
                logger.warning(
                    f"Skipping corrupted workflow during resume_all_pending: "
                    f"workflow_id={workflow_id}, error={type(e).__name__}: {e}"
                )
                skipped_count += 1
                continue

        # Log successful resume summary (L31 fix)
        if workflows:
            logger.info(
                f"Successfully resumed {len(workflows)} workflows "
                f"(skipped {skipped_count} corrupted)"
            )

        return workflows

    # ========================================================================
    # Audit Operations
    # ========================================================================

    async def get_audit_trail(
        self,
        workflow_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get audit trail for workflow.

        Args:
            workflow_id: Workflow identifier
            limit: Maximum transitions

        Returns:
            List of transition records

        """
        return await self._persistence.get_audit_trail(
            workflow_id=workflow_id,
            limit=limit,
        )

    async def verify_integrity(
        self,
        workflow_id: str,
    ) -> tuple[bool, Optional[str]]:
        """Verify audit trail integrity.

        Args:
            workflow_id: Workflow identifier

        Returns:
            Tuple of (is_valid, error_message)

        """
        return await self._persistence.verify_audit_chain(workflow_id)

    async def get_checkpoint(
        self,
        workflow_class: type[T],
        workflow_id: str,
        checkpoint_number: int,
    ) -> Optional[T]:
        """Load workflow from specific checkpoint.

        Useful for time-travel debugging or rollback.

        Args:
            workflow_class: Workflow class
            workflow_id: Workflow identifier
            checkpoint_number: Checkpoint number

        Returns:
            Workflow at that checkpoint, or None

        """
        state_data = await self._persistence.load_checkpoint_by_number(
            workflow_id=workflow_id,
            checkpoint_number=checkpoint_number,
        )

        if state_data is None:
            return None

        return cast("T", workflow_class.from_dict(state_data))


class DurableWorkflowMixin:
    """Mixin that adds persistence hooks to workflow classes.

    Add this mixin to workflow classes to enable automatic checkpointing
    on state transitions.

    Example:
        class MyWorkflow(DurableWorkflowMixin):
            def __init__(self, ..., persistence: WorkflowPersistence = None):
                super().__init__()
                self._durable_context = None
                if persistence:
                    self.enable_durability(persistence)

            def transition_to(self, new_state, actor_id):
                old_state = self.state
                self.state = new_state
                self._on_transition(old_state, new_state, actor_id)

    """

    _durable_context: Optional[DurableWorkflowContext] = None

    def enable_durability(
        self,
        persistence: WorkflowPersistence,
        actor_id: str = "system",
        auto_checkpoint: bool = True,
    ) -> None:
        """Enable durability for this workflow.

        Args:
            persistence: WorkflowPersistence instance
            actor_id: Default actor ID
            auto_checkpoint: Auto-checkpoint on transitions

        """
        self._durable_context = DurableWorkflowContext(
            persistence=persistence,
            actor_id=actor_id,
            auto_checkpoint=auto_checkpoint,
        )

    def disable_durability(self) -> None:
        """Disable durability for this workflow."""
        self._durable_context = None

    @property
    def is_durable(self) -> bool:
        """Check if durability is enabled."""
        return self._durable_context is not None

    async def _checkpoint_async(
        self,
        actor_id: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> Optional[str]:
        """Create checkpoint if durability enabled.

        Returns checkpoint ID or None.
        """
        if not self._durable_context:
            return None

        # Cast self to SerializableWorkflow - the implementing class must
        # implement the SerializableWorkflow protocol for this to work correctly
        return await self._durable_context.persistence.save_checkpoint(
            workflow=cast("SerializableWorkflow", self),
            actor_id=actor_id or self._durable_context.actor_id,
            transition_reason=reason,
        )
