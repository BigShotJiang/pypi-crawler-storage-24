"""Multi-Party Consensus Workflow

Implements LIBERTAS OPUS async consensus protocol with quorum requirements.
"""

import copy
import hashlib
import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, ClassVar, Optional

from .serialization import SerializableMixin, ensure_utc

logger = logging.getLogger(__name__)


class VoteOutcome(str, Enum):
    """Possible vote outcomes."""

    APPROVE = "approve"
    REJECT = "reject"
    ABSTAIN = "abstain"
    DEFER = "defer"


class ConsensusState(str, Enum):
    """Consensus workflow states."""

    PENDING = "pending"  # Awaiting votes
    QUORUM_MET = "quorum_met"  # Minimum votes received
    APPROVED = "approved"  # Consensus reached for approval
    REJECTED = "rejected"  # Consensus reached for rejection
    TIMEOUT = "timeout"  # Deadline passed without consensus
    ESCALATED = "escalated"  # Escalated to higher authority


@dataclass
class Vote:
    """Individual vote in consensus."""

    actor_id: str
    outcome: VoteOutcome
    timestamp: datetime
    rationale: Optional[str] = None
    signature: Optional[str] = None  # BIP-322 signature

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return f"Vote({self.actor_id}, {self.outcome.value})"


@dataclass
class ConsensusResult:
    """Result of consensus workflow."""

    state: ConsensusState
    votes: dict[str, Vote]
    approval_count: int
    rejection_count: int
    quorum_met: bool
    consensus_hash: str
    finalized_at: Optional[datetime] = None
    # BH45-D3: Monitoring fields for all-abstain quorum detection
    all_abstained: bool = False
    abstention_count: int = 0

    @property
    def decisive_votes(self) -> int:
        """Count of APPROVE + REJECT votes (excludes ABSTAIN and DEFER)."""
        return self.approval_count + self.rejection_count

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return (
            f"ConsensusResult({self.state.value}, "
            f"approvals={self.approval_count}, rejections={self.rejection_count})"
        )


@dataclass
class ConsensusConfig:
    """Configuration for consensus workflow."""

    # Operational upper bound to prevent OverflowError in timedelta construction
    # and unreasonably long-running workflows due to misconfiguration.
    MAX_TIMEOUT_HOURS: ClassVar[int] = 24 * 365 * 10  # 10 years

    quorum_percentage: float = 0.51  # 51% minimum
    approval_threshold: float = 2 / 3  # 2/3 majority for approval
    timeout_hours: int = 48  # 48-hour deadline
    required_roles: set[str] = field(default_factory=lambda: {"risk_lead"})
    allow_abstain: bool = True

    def __post_init__(self) -> None:
        """Validate configuration thresholds are within valid range [0.0, 1.0]."""
        if isinstance(self.quorum_percentage, bool):
            raise TypeError("quorum_percentage must be numeric, got bool")
        if isinstance(self.approval_threshold, bool):
            raise TypeError("approval_threshold must be numeric, got bool")
        if not (0.0 <= self.quorum_percentage <= 1.0):
            raise ValueError(
                f"quorum_percentage must be between 0.0 and 1.0, got {self.quorum_percentage}"
            )
        if not (0.0 <= self.approval_threshold <= 1.0):
            raise ValueError(
                f"approval_threshold must be between 0.0 and 1.0, got {self.approval_threshold}"
            )
        if isinstance(self.timeout_hours, bool):
            raise TypeError("timeout_hours must be numeric, got bool")
        if isinstance(self.timeout_hours, float):
            if not math.isfinite(self.timeout_hours):
                raise ValueError(
                    f"timeout_hours must be a finite number, got {self.timeout_hours}"
                )
            if self.timeout_hours < 1:
                raise ValueError(
                    f"timeout_hours must be >= 1 (got {self.timeout_hours}); "
                    "fractional hours < 1 create impractically short deadlines"
                )
        if self.timeout_hours <= 0:
            raise ValueError(
                f"timeout_hours must be positive, got {self.timeout_hours}"
            )
        if self.timeout_hours > self.MAX_TIMEOUT_HOURS:
            raise ValueError(
                f"timeout_hours={self.timeout_hours} exceeds maximum allowed "
                f"{self.MAX_TIMEOUT_HOURS} hours"
            )
        if not isinstance(self.allow_abstain, bool):
            raise TypeError(
                f"allow_abstain must be bool, got {type(self.allow_abstain).__name__}"
            )


class ConsensusWorkflow(SerializableMixin):
    """Async multi-party consensus workflow.

    Implements LIBERTAS OPUS consensus protocol:
    1. Proposal submitted to voting pool
    2. Actors vote within timeout window
    3. Quorum check (51% participation)
    4. Approval threshold check (67% approval)
    5. Finalization with cryptographic hash

    Note:
        This class is NOT thread-safe. Callers must serialize access
        to cast_vote() and check_timeout(). The LIBERTAS orchestration
        layer guarantees single-threaded execution per workflow instance.
        See QG60-8 for analysis.
    """

    def __init__(
        self,
        proposal_id: str,
        eligible_voters: set[str],
        config: Optional[ConsensusConfig] = None,
    ):
        """Initialize consensus workflow.

        Args:
            proposal_id: Unique proposal identifier
            eligible_voters: Set of actor IDs eligible to vote
            config: Consensus configuration

        Raises:
            ValueError: If eligible_voters is empty and quorum_percentage is 0
                (would allow quorum_met=True with no voters)
            ValueError: If eligible_voters is empty with positive quorum_percentage
                (would cause confusing runtime behavior - quorum can never be met)

        """
        config = config or ConsensusConfig()
        if not eligible_voters and config.quorum_percentage == 0.0:
            raise ValueError(
                "Cannot create consensus with empty eligible_voters and "
                "quorum_percentage=0.0 (would trivially pass quorum)"
            )
        if not eligible_voters and config.quorum_percentage > 0.0:
            raise ValueError(
                "Cannot create consensus with empty eligible_voters and "
                f"quorum_percentage={config.quorum_percentage} (quorum can never be met). "
                "Use quorum_percentage=0.0 explicitly if this is intentional."
            )
        self.proposal_id = proposal_id
        # Defensive copy prevents external mutation from changing eligibility.
        self.eligible_voters = set(eligible_voters)
        self.config = config

        self.votes: dict[str, Vote] = {}
        self.state = ConsensusState.PENDING
        self.created_at = datetime.now(timezone.utc)
        self.deadline = self.created_at + timedelta(hours=self.config.timeout_hours)
        self._finalized_at: Optional[datetime] = None

    @property
    def total_eligible(self) -> int:
        """Total eligible voters."""
        return len(self.eligible_voters)

    @property
    def votes_cast(self) -> int:
        """Number of votes cast (excluding DEFER, which defers judgment)."""
        return sum(1 for v in self.votes.values() if v.outcome != VoteOutcome.DEFER)

    @property
    def participation_rate(self) -> float:
        """Current participation rate (DEFER votes don't count as participation)."""
        if self.total_eligible == 0:
            return 0.0
        return self.votes_cast / self.total_eligible

    @property
    def quorum_met(self) -> bool:
        """Check if quorum is met."""
        return self.participation_rate >= self.config.quorum_percentage

    def cast_vote(
        self,
        actor_id: str,
        outcome: VoteOutcome,
        rationale: Optional[str] = None,
        signature: Optional[str] = None,
    ) -> bool:
        """Cast a vote.

        Args:
            actor_id: Voting actor's ID
            outcome: Vote outcome
            rationale: Optional rationale
            signature: Optional BIP-322 signature

        Returns:
            True if vote was accepted

        """
        if actor_id not in self.eligible_voters:
            return False

        if self.state not in (ConsensusState.PENDING, ConsensusState.QUORUM_MET):
            return False

        if outcome == VoteOutcome.ABSTAIN and not self.config.allow_abstain:
            return False

        if datetime.now(timezone.utc) > self.deadline:
            self._finalize(ConsensusState.TIMEOUT)
            return False

        if actor_id in self.votes:
            logger.warning(
                "Vote overwrite: actor=%s, proposal_id=%s, "
                "previous_outcome=%s, new_outcome=%s",
                actor_id,
                self.proposal_id,
                self.votes[actor_id].outcome.value,
                outcome.value,
            )

        self.votes[actor_id] = Vote(
            actor_id=actor_id,
            outcome=outcome,
            timestamp=datetime.now(timezone.utc),
            rationale=rationale,
            signature=signature,
        )
        logger.debug(
            f"Vote cast: proposal_id={self.proposal_id}, actor_id={actor_id}, "
            f"outcome={outcome.value}"
        )

        self._check_consensus()
        return True

    def _check_consensus(self) -> None:
        """Check if consensus has been reached."""
        if not self.quorum_met:
            # Revert QUORUM_MET if quorum was lost (e.g., vote overwrite to DEFER)
            if self.state == ConsensusState.QUORUM_MET:
                self.state = ConsensusState.PENDING
            return

        if self.state == ConsensusState.PENDING:
            self.state = ConsensusState.QUORUM_MET

        # Count votes (excluding abstentions and deferrals)
        approvals = sum(
            1 for v in self.votes.values() if v.outcome == VoteOutcome.APPROVE
        )
        rejections = sum(
            1 for v in self.votes.values() if v.outcome == VoteOutcome.REJECT
        )
        decisive_votes = approvals + rejections

        # If all participating votes are abstentions (no decisive votes), only
        # reject once every eligible voter has either voted or deferred.
        # DEFER votes don't count as participation, so voters who deferred are
        # still "outstanding" until timeout. Premature rejection would lock out
        # voters who could still cast decisive votes.
        if decisive_votes == 0:
            all_responded = len(self.votes) >= self.total_eligible
            if all_responded:
                defer_count = sum(
                    1 for v in self.votes.values() if v.outcome == VoteOutcome.DEFER
                )
                logger.warning(
                    f"All {len(self.votes)} voters responded for proposal "
                    f"{self.proposal_id} ({defer_count} deferred, rest abstained). "
                    "Rejecting due to lack of positive approval."
                )
                self._finalize(ConsensusState.REJECTED)
            return

        approval_rate = approvals / decisive_votes

        if approval_rate >= self.config.approval_threshold:
            self._finalize(ConsensusState.APPROVED)
        elif (1 - approval_rate) >= self.config.approval_threshold:
            self._finalize(ConsensusState.REJECTED)
        elif len(self.votes) >= self.total_eligible:
            # All voters have responded but neither threshold met — deadlock.
            # Reject: insufficient consensus to approve.
            logger.warning(
                f"Consensus deadlocked for {self.proposal_id}: "
                f"{approvals}/{decisive_votes} decisive votes, "
                f"threshold={self.config.approval_threshold}. "
                "Rejecting: insufficient consensus."
            )
            self._finalize(ConsensusState.REJECTED)

    def _finalize(self, state: ConsensusState) -> None:
        """Finalize consensus with given state."""
        self.state = state
        self._finalized_at = datetime.now(timezone.utc)
        logger.info(
            f"Consensus finalized: proposal_id={self.proposal_id}, "
            f"state={state.value}, votes_cast={self.votes_cast}"
        )

    def check_timeout(self) -> bool:
        """Check and handle timeout.

        Returns True only if the workflow actually timed out (transitioned
        to TIMEOUT now, or was already in TIMEOUT state).  Returns False
        for workflows that were finalized before the deadline, even if
        the current wall-clock time is past the deadline.
        """
        if datetime.now(timezone.utc) > self.deadline:
            if self.state in (ConsensusState.PENDING, ConsensusState.QUORUM_MET):
                self._finalize(ConsensusState.TIMEOUT)
                return True
            return self.state == ConsensusState.TIMEOUT
        return False

    def get_result(self) -> ConsensusResult:
        """Get current consensus result."""
        approvals = sum(
            1 for v in self.votes.values() if v.outcome == VoteOutcome.APPROVE
        )
        rejections = sum(
            1 for v in self.votes.values() if v.outcome == VoteOutcome.REJECT
        )
        abstentions = sum(
            1 for v in self.votes.values() if v.outcome == VoteOutcome.ABSTAIN
        )

        # Compute consensus hash
        vote_data = "|".join(
            f"{k}:{v.outcome.value}" for k, v in sorted(self.votes.items())
        )
        consensus_hash = hashlib.sha256(
            f"{self.proposal_id}:{vote_data}".encode(),
        ).hexdigest()

        # BH45-D3: Flag all-abstained condition for monitoring
        decisive = approvals + rejections
        _all_abstained = self.quorum_met and decisive == 0 and self.votes_cast > 0

        return ConsensusResult(
            state=self.state,
            votes={k: copy.copy(v) for k, v in self.votes.items()},
            approval_count=approvals,
            rejection_count=rejections,
            quorum_met=self.quorum_met,
            consensus_hash=consensus_hash,
            finalized_at=self._finalized_at,
            all_abstained=_all_abstained,
            abstention_count=abstentions,
        )

    def get_missing_voters(self) -> set[str]:
        """Get voters who haven't voted yet."""
        return self.eligible_voters - set(self.votes.keys())

    def get_required_missing(
        self, actor_roles: Optional[dict[str, set[str]]] = None
    ) -> set[str]:
        """Get required roles that haven't voted.

        Args:
            actor_roles: Optional mapping of actor_id -> set of role names.
                         If not provided, returns all required_roles (cannot determine
                         which roles have voted without role information).
                         If provided but empty, logs a warning and returns all
                         required_roles (indicates possible configuration issue).

        Returns:
            Set of role names that are required but haven't voted yet.

        """
        if actor_roles is None:
            # Without role mapping, we cannot determine which roles have voted
            # Return all required roles as missing (conservative approach)
            return self.config.required_roles.copy()

        if not actor_roles and self.config.required_roles:
            # Empty actor_roles dict with required_roles configured is suspicious
            # Log warning and return all required roles as missing
            logger.warning(
                f"get_required_missing called with empty actor_roles dict but "
                f"required_roles={self.config.required_roles}. "
                "Cannot determine which roles have voted."
            )
            return self.config.required_roles.copy()

        # BH41-M4: Collect roles that have voted with a substantive outcome.
        # DEFER does not satisfy required-role obligations — it is excluded from
        # quorum counting (votes_cast) and must also be excluded here for
        # consistency. A DEFER voter has made no governance decision.
        voted_roles: set[str] = set()
        for actor_id, vote in self.votes.items():
            if vote.outcome == VoteOutcome.DEFER:
                continue
            if actor_id in actor_roles:
                voted_roles.update(actor_roles[actor_id])

        return self.config.required_roles - voted_roles

    # =========================================================================
    # Serialization Methods (GAP-M3 Workflow Persistence)
    # =========================================================================

    @property
    def workflow_id(self) -> str:
        """Unique workflow identifier (namespaced to avoid collisions)."""
        return f"consensus:{self.proposal_id}"

    @property
    def workflow_type(self) -> str:
        """Workflow type discriminator."""
        return "consensus"

    @property
    def current_state(self) -> str:
        """Current state value for persistence."""
        return self.state.value

    def to_dict(self) -> dict[str, Any]:
        """Serialize workflow to dictionary for persistence.

        Converts all instance attributes to JSON-serializable format:
        - Enums: Use .value
        - datetime: Use .isoformat()
        - set: Convert to sorted list

        Returns:
            Dictionary representation of workflow state

        """
        return {
            "proposal_id": self.proposal_id,
            "eligible_voters": sorted(self.eligible_voters),
            "config": {
                "quorum_percentage": self.config.quorum_percentage,
                "approval_threshold": self.config.approval_threshold,
                "timeout_hours": self.config.timeout_hours,
                "required_roles": sorted(self.config.required_roles),
                "allow_abstain": self.config.allow_abstain,
            },
            "votes": {
                actor_id: {
                    "actor_id": vote.actor_id,
                    "outcome": vote.outcome.value,
                    "timestamp": vote.timestamp.isoformat(),
                    "rationale": vote.rationale,
                    "signature": vote.signature,
                }
                for actor_id, vote in self.votes.items()
            },
            "state": self.state.value,
            "created_at": self.created_at.isoformat(),
            "deadline": self.deadline.isoformat(),
            "finalized_at": (
                self._finalized_at.isoformat() if self._finalized_at else None
            ),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ConsensusWorkflow":
        """Deserialize workflow from dictionary.

        Reconstructs workflow instance from persisted state:
        - Enums: Reconstruct from value
        - datetime: Parse from ISO format
        - set: Convert from list

        Args:
            data: Dictionary representation of workflow state

        Returns:
            Reconstructed ConsensusWorkflow instance

        """
        # Reconstruct config
        config_data = data["config"]
        config = ConsensusConfig(
            quorum_percentage=config_data["quorum_percentage"],
            approval_threshold=config_data["approval_threshold"],
            timeout_hours=config_data["timeout_hours"],
            required_roles=set(config_data.get("required_roles", [])),
            allow_abstain=config_data.get("allow_abstain", True),
        )

        # BH39-L1: use cls.__new__(cls) to bypass __init__ and avoid the
        # intermediate inconsistent state where created_at/deadline are set
        # to datetime.now() before being overwritten from serialized data.
        # This mirrors the identical pattern in OverrideWorkflow.from_dict().
        # MAINTENANCE NOTE: all attributes set in __init__ MUST be set below.
        # Required attrs: proposal_id, eligible_voters, config, votes, state,
        #                 created_at, deadline, _finalized_at
        workflow = cls.__new__(cls)
        workflow.proposal_id = data["proposal_id"]
        # Defensive copy — prevents external mutation from changing eligibility.
        workflow.eligible_voters = set(data["eligible_voters"])
        workflow.config = config

        # Restore votes (ensure timezone-aware timestamps)
        workflow.votes = {
            actor_id: Vote(
                actor_id=vote_data["actor_id"],
                outcome=VoteOutcome(vote_data["outcome"]),
                timestamp=ensure_utc(datetime.fromisoformat(vote_data["timestamp"])),
                rationale=vote_data.get("rationale"),
                signature=vote_data.get("signature"),
            )
            for actor_id, vote_data in data.get("votes", {}).items()
        }

        # Restore state and timestamps (ensure timezone-aware)
        workflow.state = ConsensusState(data["state"])
        workflow.created_at = ensure_utc(datetime.fromisoformat(data["created_at"]))
        workflow.deadline = ensure_utc(datetime.fromisoformat(data["deadline"]))
        finalized_at_str = data.get("finalized_at")
        workflow._finalized_at = (
            ensure_utc(datetime.fromisoformat(finalized_at_str))
            if finalized_at_str
            else None
        )

        return workflow
