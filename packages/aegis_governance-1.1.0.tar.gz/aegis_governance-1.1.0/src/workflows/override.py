"""Two-Key Override Workflow

Implements dual signature validation for gate override requests.
Supports multiple signature providers:
- HybridSignatureProvider: Ed25519 + ML-DSA-44 hybrid (post-quantum, future)
- BIP322Provider: BIP-340 Schnorr on secp256k1 (recommended, Bitcoin-native)
- Ed25519Provider: Ed25519 signatures (deprecated, legacy fallback)

Key Store Integration (GAP-Q2 Phase 2):
- Optional key_store parameter for signing with stored keys
- sign_with_stored_key() async method for automated signing
- Key usage recorded in audit trail

GAP-M4: BIP-322 Signature Format Standardization
GAP-Q1: Post-Quantum Signature Hardening
GAP-Q2: Key Store Integration
"""

import base64
import copy
import hashlib
import inspect
import json
import logging
import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

# Import signature providers
# BIP322Provider is preferred, HybridProvider for post-quantum, Ed25519 is legacy
try:
    from crypto import (
        BIP322_AVAILABLE,
        ED25519_AVAILABLE,
        HYBRID_AVAILABLE,
        SignatureProvider,
        get_default_provider,
    )

    PROVIDERS_AVAILABLE = True
except ImportError:
    PROVIDERS_AVAILABLE = False
    BIP322_AVAILABLE = False
    ED25519_AVAILABLE = False
    HYBRID_AVAILABLE = False

# Legacy cryptography import for backward compatibility
try:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )

    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

from .serialization import SerializableMixin, ensure_utc

if TYPE_CHECKING:
    from crypto.providers import SignatureProvider
    from rbac import RBACEnforcer
    from telemetry.alert import AlertSink as AlertSinkProtocol
    from telemetry.emitter import TelemetryEmitter
    from telemetry.prometheus_exporter import PrometheusExporter
    from workflows.persistence.key_store import KeyStoreRepository

logger = logging.getLogger(__name__)


class OverrideState(str, Enum):
    """Override request states."""

    PENDING = "pending"  # Awaiting signatures
    PARTIAL = "partial"  # One signature received
    APPROVED = "approved"  # Both signatures received
    REJECTED = "rejected"  # Explicitly rejected
    EXPIRED = "expired"  # Timeout reached


@dataclass
class SignatureRecord:
    """Signature record supporting multiple algorithms (BIP-322, Ed25519, Hybrid).

    GAP-Q1: Extended to support post-quantum hybrid signatures.
    """

    signer_id: str
    role: str
    signature: str  # Base64-encoded signature (size varies by algorithm)
    message_hash: str  # SHA-256 hash as hex string
    timestamp: datetime
    public_key: Optional[str] = (
        None  # Base64-encoded public key (size varies by algorithm)
    )
    algorithm: str = "bip322-simple"  # Signature algorithm identifier


@dataclass
class OverrideRequest:
    """Two-key override request."""

    proposal_id: str
    justification: str
    failed_gates: list[str]
    requested_by: str
    requested_at: datetime
    state: OverrideState = OverrideState.PENDING
    # Rejection metadata (populated by reject() method)
    rejected_by: Optional[str] = None
    rejection_reason: Optional[str] = None
    rejected_at: Optional[datetime] = None


@dataclass
class OverrideResult:
    """Result of override validation."""

    approved: bool
    state: OverrideState
    risk_lead_signature: Optional[SignatureRecord]
    security_lead_signature: Optional[SignatureRecord]
    combined_hash: Optional[str]
    expires_at: datetime


class DualSignatureValidator:
    """Validate dual signatures for override authorization.

    Supports multiple signature providers:
    - BIP322Provider: BIP-340 Schnorr on secp256k1 (recommended)
    - Ed25519Provider: Ed25519 signatures (deprecated)

    Provider is selected at initialization. Default is BIP322Provider if
    btclib is available, otherwise falls back to Ed25519Provider.

    Per Spec Section 6 (RBAC):
    - Risk Lead signature: Required
    - Security Lead signature: Required
    - Both signatures must be on the same message hash
    - 24-hour expiration window

    Security Properties:
    - 128-bit security level (both providers)
    - Constant-time signature verification via library
    - Audit logging for validation failures
    - Provider abstraction for algorithm agility

    GAP-M4: BIP-322 Signature Format Standardization
    """

    REQUIRED_ROLES = {"risk_lead", "security_lead"}

    # Upper bound to prevent OverflowError in timedelta construction
    MAX_EXPIRATION_HOURS = 24 * 365 * 10  # 10 years (parity with ConsensusConfig)

    # Class-level constants (not overridden by provider)
    PRIVATE_KEY_SIZE = 32  # Both use 32-byte private keys
    SHA256_HEX_LENGTH = 64  # SHA-256 hash as hex string

    def __init__(
        self,
        expiration_hours: int = 24,
        provider: Optional["SignatureProvider"] = None,
    ):
        """Initialize validator with signature provider.

        Args:
            expiration_hours: Hours until override request expires
            provider: Signature provider (default: auto-select best available)
                     - BIP322Provider if btclib available (recommended)
                     - Ed25519Provider if only cryptography available
                     - None uses legacy Ed25519 code path

        """
        if isinstance(expiration_hours, bool):
            raise TypeError("expiration_hours must be numeric, got bool")
        if isinstance(expiration_hours, float):
            if not math.isfinite(expiration_hours):
                raise ValueError(
                    f"expiration_hours must be a finite number, got {expiration_hours}"
                )
            if expiration_hours < 1:
                raise ValueError(
                    f"expiration_hours must be >= 1 (got {expiration_hours}); "
                    "fractional hours < 1 create impractically short expirations"
                )
        if expiration_hours <= 0:
            raise ValueError(
                f"expiration_hours must be positive, got {expiration_hours}"
            )
        if expiration_hours > self.MAX_EXPIRATION_HOURS:
            raise ValueError(
                f"expiration_hours={expiration_hours} exceeds maximum allowed "
                f"{self.MAX_EXPIRATION_HOURS} hours"
            )
        self.expiration_hours = expiration_hours
        self._provider = provider

        # Instance-level sizes (W-1 fix: prevents class-level mutation)
        self._signature_size = 64  # Both Ed25519 and BIP-340 are 64 bytes
        self._public_key_size = 32  # Both use 32-byte public keys

        # Auto-select provider if not specified
        if provider is None and PROVIDERS_AVAILABLE:
            try:
                self._provider = get_default_provider()
                logger.info(
                    f"Using signature provider: {self._provider.algorithm_name}",
                )
            except RuntimeError:
                logger.warning("No signature provider available, using legacy Ed25519")
                self._provider = None

        # Update sizes from provider if available
        if self._provider is not None:
            self._signature_size = self._provider.signature_size
            self._public_key_size = self._provider.public_key_size

    @property
    def provider(self) -> Optional["SignatureProvider"]:
        """Return the configured signature provider."""
        return self._provider

    @property
    def algorithm_name(self) -> str:
        """Return the algorithm name of the current provider."""
        if self._provider is not None:
            name: str = self._provider.algorithm_name
            return name
        return "ed25519-legacy"

    def create_message_hash(
        self,
        proposal_id: str,
        justification: str,
        failed_gates: list[str],
    ) -> str:
        """Create canonical message hash for signing.

        Uses provider-specific hash algorithm:
        - BIP322Provider: BIP-340 tagged hash
        - Ed25519Provider: SHA-256 of JSON
        - Legacy: SHA-256 of JSON

        Args:
            proposal_id: Proposal identifier
            justification: Override justification
            failed_gates: List of failed gate names

        Returns:
            Hex-encoded message hash

        """
        # Use provider if available
        if self._provider is not None:
            msg_hash = self._provider.create_message_hash(
                proposal_id,
                justification,
                failed_gates,
            )
            hash_hex: str = msg_hash.hex()
            return hash_hex

        # Legacy path: SHA-256 of canonical JSON
        canonical = json.dumps(
            {
                "proposal_id": proposal_id,
                "justification": justification,
                "failed_gates": sorted(failed_gates),
                "version": "1.0",
            },
            sort_keys=True,
        )

        return hashlib.sha256(canonical.encode()).hexdigest()

    def validate_signature(
        self,
        signature: str,
        message_hash: str,
        public_key: str,
    ) -> bool:
        """Validate signature using configured provider.

        Supports both provider-based and legacy validation:
        - BIP322Provider: BIP-340 Schnorr verification
        - Ed25519Provider: Ed25519 verification
        - Legacy: Ed25519 via cryptography library

        Args:
            signature: Base64-encoded signature (64 bytes decoded)
            message_hash: Hex-encoded message hash (from create_message_hash)
            public_key: Base64-encoded public key (32 bytes decoded)

        Returns:
            True if signature is cryptographically valid

        Security:
            - Uses provider's constant-time verification
            - Falls back to format validation if no provider/library available
            - Logs validation failures for audit trail

        """
        # Provider-based validation (preferred)
        if self._provider is not None:
            try:
                sig_bytes = base64.b64decode(signature, validate=True)
                key_bytes = base64.b64decode(public_key, validate=True)
                msg_bytes = bytes.fromhex(message_hash)

                result = self._provider.verify(sig_bytes, msg_bytes, key_bytes)
                if result:
                    logger.debug(
                        f"Signature validation succeeded (provider: {self._provider.algorithm_name})",
                    )
                else:
                    logger.warning(
                        f"Signature validation failed (provider: {self._provider.algorithm_name})",
                    )
                verified: bool = result
                return verified
            except (ValueError, TypeError, KeyError) as e:
                # Expected validation errors - log and return False
                logger.warning(f"Signature validation failed: {e}")
                return False
            except Exception as e:
                # Unexpected errors - log at error level and re-raise
                logger.error(f"Unexpected error during signature validation: {e}")
                raise

        # Legacy Ed25519 path (fallback)
        if not CRYPTO_AVAILABLE:
            logger.warning(
                "Cryptography library unavailable - using format validation only. "
                "Install 'cryptography>=41.0.0' for full cryptographic validation.",
            )
            return self._validate_signature_format(signature, message_hash, public_key)

        try:
            # Decode signature and public key from base64
            sig_bytes = base64.b64decode(signature, validate=True)
            key_bytes = base64.b64decode(public_key, validate=True)
            message_bytes = bytes.fromhex(message_hash)

            # Validate sizes before cryptographic operations
            if len(sig_bytes) != self._signature_size:
                logger.warning(
                    "Signature validation failed: invalid signature size "
                    f"(got {len(sig_bytes)}, expected {self._signature_size})",
                )
                return False

            if len(key_bytes) != self._public_key_size:
                logger.warning(
                    "Signature validation failed: invalid public key size "
                    f"(got {len(key_bytes)}, expected {self._public_key_size})",
                )
                return False

            # Load public key and verify signature
            pk = Ed25519PublicKey.from_public_bytes(key_bytes)
            pk.verify(sig_bytes, message_bytes)

            logger.debug("Signature validation succeeded (legacy Ed25519)")
            return True

        except InvalidSignature:
            logger.warning(
                "Signature validation failed: cryptographic verification failed",
            )
            return False
        except ValueError as e:
            logger.warning(f"Signature validation failed: invalid format - {e}")
            return False
        except TypeError as e:
            logger.warning(f"Signature validation failed: type error - {e}")
            return False

    def _validate_signature_format(
        self,
        signature: str,
        message_hash: str,
        public_key: str,
    ) -> bool:
        """Fallback format validation when cryptography library unavailable.

        Validates format only - NOT cryptographically secure.
        This is a degraded mode that should only be used when the
        cryptography library cannot be installed.

        Args:
            signature: Base64-encoded signature string
            message_hash: SHA-256 hash as hex string
            public_key: Base64-encoded public key string

        Returns:
            True if format is valid (does NOT verify cryptographic correctness)

        Warning:
            This method does NOT provide cryptographic security.
            It only validates that inputs are properly formatted.

        """
        logger.warning(
            "SECURITY WARNING: Using format-only validation. "
            "Signatures are NOT cryptographically verified.",
        )

        try:
            # Validate base64 format and sizes
            sig_bytes = base64.b64decode(signature, validate=True)
            key_bytes = base64.b64decode(public_key, validate=True)

            # Ed25519 signature is 64 bytes, public key is 32 bytes
            if len(sig_bytes) != self._signature_size:
                logger.warning(
                    f"Format validation failed: signature size {len(sig_bytes)} "
                    f"!= expected {self._signature_size}",
                )
                return False

            if len(key_bytes) != self._public_key_size:
                logger.warning(
                    f"Format validation failed: public key size {len(key_bytes)} "
                    f"!= expected {self._public_key_size}",
                )
                return False

            # Validate message_hash is valid hex SHA-256 (64 chars)
            if len(message_hash) != self.SHA256_HEX_LENGTH:
                logger.warning(
                    f"Format validation failed: message hash length {len(message_hash)} "
                    f"!= expected {self.SHA256_HEX_LENGTH}",
                )
                return False

            # Validate hex format
            bytes.fromhex(message_hash)

            return True

        except (ValueError, TypeError) as e:
            logger.warning(f"Format validation failed: {e}")
            return False

    def generate_keypair(self) -> tuple[str, str]:
        """Generate keypair for testing and initial setup.

        Uses the configured provider's algorithm:
        - BIP322Provider: secp256k1 keypair
        - Ed25519Provider: Ed25519 keypair
        - Legacy: Ed25519 keypair

        This method is provided for testing and development purposes.
        In production, keys should be generated and stored using
        proper key management infrastructure.

        Returns:
            Tuple of (private_key_b64, public_key_b64) as base64-encoded strings

        Raises:
            RuntimeError: If no provider/library is available

        Example:
            >>> validator = DualSignatureValidator()
            >>> private_key, public_key = validator.generate_keypair()
            >>> # Keys are base64-encoded, algorithm depends on provider

        """
        # Provider-based key generation (preferred)
        if self._provider is not None:
            private_bytes, public_bytes = self._provider.generate_keypair()
            return (
                base64.b64encode(private_bytes).decode("ascii"),
                base64.b64encode(public_bytes).decode("ascii"),
            )

        # Legacy Ed25519 path
        if not CRYPTO_AVAILABLE:
            raise RuntimeError(
                "No signature provider or cryptography library available. "
                "Install btclib>=2023.7.12 or cryptography>=41.0.0",
            )

        private_key = Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        private_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

        return (
            base64.b64encode(private_bytes).decode("ascii"),
            base64.b64encode(public_bytes).decode("ascii"),
        )

    def sign_message(self, message_hash: str, private_key_b64: str) -> str:
        """Sign a message hash with private key.

        Uses the configured provider's algorithm:
        - BIP322Provider: BIP-340 Schnorr signature
        - Ed25519Provider: Ed25519 signature
        - Legacy: Ed25519 signature

        This method is provided for testing and development purposes.
        In production, signing should occur in a secure environment
        with proper key protection.

        Args:
            message_hash: Hex-encoded message hash (from create_message_hash)
            private_key_b64: Base64-encoded private key (32 bytes decoded)

        Returns:
            Base64-encoded signature (64 bytes decoded)

        Raises:
            RuntimeError: If no provider/library is available
            ValueError: If inputs are malformed

        Example:
            >>> validator = DualSignatureValidator()
            >>> private_key, public_key = validator.generate_keypair()
            >>> msg_hash = validator.create_message_hash("prop-1", "test", ["gate1"])
            >>> signature = validator.sign_message(msg_hash, private_key)
            >>> assert validator.validate_signature(signature, msg_hash, public_key)

        """
        # Provider-based signing (preferred)
        if self._provider is not None:
            private_bytes = base64.b64decode(private_key_b64, validate=True)
            message_bytes = bytes.fromhex(message_hash)
            signature = self._provider.sign(message_bytes, private_bytes)
            return base64.b64encode(signature).decode("ascii")

        # Legacy Ed25519 path
        if not CRYPTO_AVAILABLE:
            raise RuntimeError(
                "No signature provider or cryptography library available. "
                "Install btclib>=2023.7.12 or cryptography>=41.0.0",
            )

        private_bytes = base64.b64decode(private_key_b64, validate=True)
        private_key = Ed25519PrivateKey.from_private_bytes(private_bytes)

        message_bytes = bytes.fromhex(message_hash)
        signature = private_key.sign(message_bytes)

        return base64.b64encode(signature).decode("ascii")

    def combine_signatures(
        self,
        sig1: SignatureRecord,
        sig2: SignatureRecord,
    ) -> str:
        """Combine two signatures into authorization hash.

        Signatures are sorted by role before hashing to ensure the
        combined hash is order-independent (W-2 fix).

        Args:
            sig1: First signature
            sig2: Second signature

        Returns:
            Combined authorization hash (deterministic regardless of arg order)

        """
        # Sort by role for order-independent hash (W-2 fix)
        sigs = sorted([sig1, sig2], key=lambda s: s.role)

        combined = json.dumps(
            {
                "message_hash": sigs[0].message_hash,
                "sig1": {
                    "signer": sigs[0].signer_id,
                    "role": sigs[0].role,
                    "signature": sigs[0].signature,
                },
                "sig2": {
                    "signer": sigs[1].signer_id,
                    "role": sigs[1].role,
                    "signature": sigs[1].signature,
                },
            },
            sort_keys=True,
        )

        return hashlib.sha256(combined.encode()).hexdigest()


class OverrideWorkflow(SerializableMixin):
    """Manage two-key override request workflow.

    Workflow:
    1. Request created with justification and failed gates
    2. Message hash generated for signing
    3. Risk Lead provides signature (manual or from key store)
    4. Security Lead provides signature (manual or from key store)
    5. Both signatures validated
    6. Override approved or rejected

    Key Store Integration (GAP-Q2):
        When key_store is provided, use sign_with_stored_key() for automated
        signing with keys stored in the governance key store.
    """

    # Terminal states where no further signatures are accepted
    _TERMINAL_STATES: frozenset = frozenset(
        {
            OverrideState.APPROVED,
            OverrideState.REJECTED,
            OverrideState.EXPIRED,
        }
    )

    # Type annotations for instance attributes
    # validator can be None when created via from_dict() deserialization
    validator: Optional[DualSignatureValidator]
    key_store: Optional["KeyStoreRepository"]

    def __init__(
        self,
        proposal_id: str,
        justification: str,
        failed_gates: list[str],
        requested_by: str,
        validator: Optional[DualSignatureValidator] = None,
        key_store: Optional["KeyStoreRepository"] = None,
        rbac_enforcer: Optional["RBACEnforcer"] = None,
        telemetry_emitter: Optional["TelemetryEmitter"] = None,
        prometheus_exporter: Optional["PrometheusExporter"] = None,
        alert_sink: Optional["AlertSinkProtocol"] = None,
    ):
        """Initialize override workflow.

        Args:
            proposal_id: Proposal requesting override
            justification: Justification for override
            failed_gates: List of failed gate names
            requested_by: Actor requesting override
            validator: Signature validator
            key_store: Key store repository for sign_with_stored_key()
            rbac_enforcer: Optional RBAC enforcer for authorization checks
            telemetry_emitter: Optional telemetry emitter for override events
            prometheus_exporter: Optional Prometheus exporter for metrics
            alert_sink: Optional alert sink for override notifications

        """
        self.validator = validator or DualSignatureValidator()
        self.key_store = key_store
        self.rbac_enforcer = rbac_enforcer
        self.telemetry_emitter = telemetry_emitter
        self.prometheus_exporter = prometheus_exporter
        self.alert_sink = alert_sink

        self.request = OverrideRequest(
            proposal_id=proposal_id,
            justification=justification,
            failed_gates=list(failed_gates),
            requested_by=requested_by,
            requested_at=datetime.now(timezone.utc),
        )

        self.message_hash = self.validator.create_message_hash(
            proposal_id=proposal_id,
            justification=justification,
            failed_gates=failed_gates,
        )

        self.expires_at = self.request.requested_at + timedelta(
            hours=self.validator.expiration_hours,
        )

        self.risk_lead_signature: Optional[SignatureRecord] = None
        self.security_lead_signature: Optional[SignatureRecord] = None

        # Record Prometheus metric for override request creation
        if self.prometheus_exporter is not None:
            self.prometheus_exporter.record_override_request(outcome="requested")

        # Emit override requested event
        if self.telemetry_emitter is not None:
            self.telemetry_emitter.emit_override_requested(
                proposal_id=proposal_id,
                requester_id=requested_by,
                failed_gates=failed_gates,
                justification=justification,
            )
        if self.alert_sink is not None:
            from telemetry.alert import AlertSeverity

            self.alert_sink.send_alert(
                AlertSeverity.INFO,
                f"Override requested for {proposal_id}",
                {
                    "proposal_id": proposal_id,
                    "requester_id": requested_by,
                    "failed_gates": failed_gates,
                },
            )

    @property
    def is_expired(self) -> bool:
        """Check if request has expired.

        ADVISORY ONLY: This property is subject to TOCTOU (time-of-check to
        time-of-use) race conditions. The expiration status may change between
        checking this property and performing subsequent operations.

        For atomic operations that need guaranteed expiration handling, use
        check_and_mark_expired() instead, or rely on the expiration check
        performed within add_signature() which atomically checks and updates
        state.

        Returns:
            True if the current time is past expires_at, False otherwise.

        Note:
            Signature operations (add_signature, sign_with_stored_key) perform
            their own expiration check atomically before accepting signatures,
            so relying on is_expired before those operations is safe.
        """
        return datetime.now(timezone.utc) > self.expires_at

    def check_and_mark_expired(self) -> bool:
        """Atomically check expiration and mark state as EXPIRED if applicable.

        This method provides an atomic check-and-update operation to avoid
        TOCTOU race conditions when expiration handling is critical.

        Returns:
            True if the request was (or already is) expired, False if still valid.

        Example:
            >>> if workflow.check_and_mark_expired():
            ...     # Handle expired workflow
            ...     return "Request has expired"
            >>> # Safe to proceed with operations

        """
        if self.request.state in self._TERMINAL_STATES:
            return self.request.state == OverrideState.EXPIRED

        if datetime.now(timezone.utc) > self.expires_at:
            self.request.state = OverrideState.EXPIRED
            logger.info(
                f"Override request expired: proposal={self.request.proposal_id}, "
                f"expires_at={self.expires_at.isoformat()}"
            )
            return True

        return False

    def _validate_signature_preconditions(
        self,
        role: str,
        signature: str,
        public_key: str,
    ) -> tuple[bool, Optional[str]]:
        """Validate preconditions before accepting a signature.

        Checks expiration, role validity, and cryptographic signature validity.

        Args:
            role: Signer's role (risk_lead or security_lead)
            signature: Base64-encoded Ed25519 signature
            public_key: Base64-encoded Ed25519 public key

        Returns:
            (valid, error_message) tuple. If valid is True, error_message is None.

        """
        if self.is_expired:
            self.request.state = OverrideState.EXPIRED
            return False, "Override request has expired"

        if role not in DualSignatureValidator.REQUIRED_ROLES:
            return (
                False,
                f"Invalid role: {role}. Required: {DualSignatureValidator.REQUIRED_ROLES}",
            )

        if self.validator is None:
            return (
                False,
                "Validator not set - call set_validator() after deserialization",
            )

        if not self.validator.validate_signature(
            signature,
            self.message_hash,
            public_key,
        ):
            return False, "Signature validation failed"

        return True, None

    def _record_signature(
        self,
        role: str,
        record: SignatureRecord,
    ) -> tuple[bool, str]:
        """Record a signature for the specified role.

        Checks for duplicate signatures and stores the record.

        Args:
            role: Signer's role (risk_lead or security_lead)
            record: The signature record to store

        Returns:
            (success, message) tuple

        """
        if role == "risk_lead":
            if self.risk_lead_signature:
                return False, "Risk Lead signature already provided"
            if (
                self.security_lead_signature
                and self.security_lead_signature.signer_id == record.signer_id
            ):
                return (
                    False,
                    "Four-eyes violation: signer must be different for each role",
                )
            self.risk_lead_signature = record
        else:  # security_lead
            if self.security_lead_signature:
                return False, "Security Lead signature already provided"
            if (
                self.risk_lead_signature
                and self.risk_lead_signature.signer_id == record.signer_id
            ):
                return (
                    False,
                    "Four-eyes violation: signer must be different for each role",
                )
            self.security_lead_signature = record

        return True, f"{role} signature accepted"

    def _update_override_state(self) -> None:
        """Update the override request state based on collected signatures.

        Sets state to APPROVED if both signatures present, PARTIAL if one signature.
        Emits telemetry events and alerts on state transitions.
        """
        if self.risk_lead_signature and self.security_lead_signature:
            self.request.state = OverrideState.APPROVED
            # Emit approval events
            if self.telemetry_emitter is not None:
                self.telemetry_emitter.emit_override_approved(
                    proposal_id=self.request.proposal_id,
                    risk_lead_id=self.risk_lead_signature.signer_id,
                    security_lead_id=self.security_lead_signature.signer_id,
                )
            if self.prometheus_exporter is not None:
                self.prometheus_exporter.record_override_request(outcome="approved")
            if self.alert_sink is not None:
                from telemetry.alert import AlertSeverity

                self.alert_sink.send_alert(
                    AlertSeverity.CRITICAL,
                    f"Override APPROVED for {self.request.proposal_id}",
                    {
                        "proposal_id": self.request.proposal_id,
                        "risk_lead": self.risk_lead_signature.signer_id,
                        "security_lead": self.security_lead_signature.signer_id,
                        "failed_gates": self.request.failed_gates,
                    },
                )
        elif self.risk_lead_signature or self.security_lead_signature:
            self.request.state = OverrideState.PARTIAL
            if self.prometheus_exporter is not None:
                self.prometheus_exporter.record_override_request(outcome="partial")

    def add_signature(
        self,
        signer_id: str,
        role: str,
        signature: str,
        public_key: str,
    ) -> tuple[bool, str]:
        """Add a signature to the override request.

        Args:
            signer_id: Signer identifier
            role: Signer's role (risk_lead or security_lead)
            signature: Base64-encoded Ed25519 signature
            public_key: Base64-encoded Ed25519 public key

        Returns:
            (success, message) tuple

        """
        # State guard: reject signatures on terminal states
        if self.request.state in self._TERMINAL_STATES:
            return False, f"Override request is already {self.request.state.value}"

        # RBAC authorization check (if enforcer is configured)
        if self.rbac_enforcer is not None:
            authorized, reason = self.rbac_enforcer.authorize_override(
                signer_id=signer_id,
                role=role,
                requester_id=self.request.requested_by,
            )
            if not authorized:
                logger.warning(
                    "RBAC denied override signature: signer=%s, role=%s, reason=%s",
                    signer_id,
                    role,
                    reason,
                )
                # Emit unauthorized attempt as telemetry + alert
                if self.telemetry_emitter is not None:
                    self.telemetry_emitter.emit_override_rejected(
                        proposal_id=self.request.proposal_id,
                        rejected_by="rbac_enforcer",
                        reason=reason or "RBAC authorization failed",
                    )
                if self.alert_sink is not None:
                    from telemetry.alert import AlertSeverity

                    self.alert_sink.send_alert(
                        AlertSeverity.EMERGENCY,
                        f"Unauthorized override attempt on {self.request.proposal_id}",
                        {
                            "signer_id": signer_id,
                            "role": role,
                            "requester_id": self.request.requested_by,
                            "reason": reason,
                        },
                    )
                return False, reason or "RBAC authorization failed"

        # Validate preconditions (expiration, role, signature)
        valid, error_message = self._validate_signature_preconditions(
            role,
            signature,
            public_key,
        )
        if not valid:
            return False, error_message  # type: ignore[return-value]

        # Create signature record
        algorithm = (
            self.validator.algorithm_name
            if self.validator is not None
            else "ed25519-legacy"
        )
        record = SignatureRecord(
            signer_id=signer_id,
            role=role,
            signature=signature,
            message_hash=self.message_hash,
            timestamp=datetime.now(timezone.utc),
            public_key=public_key,
            algorithm=algorithm,
        )

        # Record the signature (checks for duplicates)
        success, message = self._record_signature(role, record)
        if not success:
            return False, message

        # Update state based on collected signatures
        self._update_override_state()

        return True, message

    def reject(self, actor_id: str, reason: str) -> bool:
        """Explicitly reject override request.

        Records rejection metadata for audit compliance. The actor_id, reason,
        and timestamp are stored in the request for audit trail purposes.

        Args:
            actor_id: Actor rejecting the override request
            reason: Rejection reason (required for audit trail)

        Returns:
            True if rejection succeeded, False if request was already
            approved or expired

        """
        if self.request.state in self._TERMINAL_STATES:
            return False
        if self.check_and_mark_expired():
            return False

        self.request.state = OverrideState.REJECTED
        self.request.rejected_by = actor_id
        self.request.rejection_reason = reason
        self.request.rejected_at = datetime.now(timezone.utc)

        logger.info(
            f"Override rejected: proposal={self.request.proposal_id}, "
            f"rejected_by={actor_id}, reason={reason}",
        )

        # Emit rejection events
        if self.telemetry_emitter is not None:
            self.telemetry_emitter.emit_override_rejected(
                proposal_id=self.request.proposal_id,
                rejected_by=actor_id,
                reason=reason,
            )
        if self.prometheus_exporter is not None:
            self.prometheus_exporter.record_override_request(outcome="rejected")
        if self.alert_sink is not None:
            from telemetry.alert import AlertSeverity

            self.alert_sink.send_alert(
                AlertSeverity.WARNING,
                f"Override rejected for {self.request.proposal_id}",
                {
                    "proposal_id": self.request.proposal_id,
                    "rejected_by": actor_id,
                    "reason": reason,
                },
            )

        return True

    def get_result(self) -> OverrideResult:
        """Get current override result."""
        combined_hash = None
        if self.risk_lead_signature and self.security_lead_signature and self.validator:
            combined_hash = self.validator.combine_signatures(
                self.risk_lead_signature,
                self.security_lead_signature,
            )

        return OverrideResult(
            approved=self.request.state == OverrideState.APPROVED,
            state=self.request.state,
            risk_lead_signature=(
                copy.copy(self.risk_lead_signature)
                if self.risk_lead_signature
                else None
            ),
            security_lead_signature=(
                copy.copy(self.security_lead_signature)
                if self.security_lead_signature
                else None
            ),
            combined_hash=combined_hash,
            expires_at=self.expires_at,
        )

    def get_pending_signatures(self) -> list[str]:
        """Get list of roles still needing to sign."""
        pending = []
        if not self.risk_lead_signature:
            pending.append("risk_lead")
        if not self.security_lead_signature:
            pending.append("security_lead")
        return pending

    # =========================================================================
    # Serialization Methods (GAP-M3 Workflow Persistence)
    # =========================================================================

    @property
    def workflow_id(self) -> str:
        """Unique workflow identifier for persistence.

        Uses proposal_id combined with message_hash to ensure uniqueness
        across different override requests for the same proposal.
        """
        return f"{self.request.proposal_id}:{self.message_hash[:16]}"

    @property
    def workflow_type(self) -> str:
        """Workflow type discriminator for persistence layer."""
        return "override"

    @property
    def current_state(self) -> str:
        """Current state value for persistence.

        Returns the canonical request state for persistence layer indexing.
        Previously derived from signature presence, which failed to reflect
        REJECTED/EXPIRED states correctly.
        """
        return self.request.state.value

    def _serialize_signature(
        self,
        sig: Optional[SignatureRecord],
    ) -> Optional[dict[str, Any]]:
        """Helper to serialize a SignatureRecord to dictionary.

        Args:
            sig: SignatureRecord to serialize, or None

        Returns:
            Dictionary representation or None if input is None

        """
        if sig is None:
            return None
        return {
            "signer_id": sig.signer_id,
            "role": sig.role,
            "signature": sig.signature,  # Already base64-encoded string
            "message_hash": sig.message_hash,
            "timestamp": sig.timestamp.isoformat(),
            "public_key": sig.public_key,
            "algorithm": sig.algorithm,
        }

    @classmethod
    def _deserialize_signature(
        cls,
        data: Optional[dict[str, Any]],
    ) -> Optional[SignatureRecord]:
        """Helper to deserialize a SignatureRecord from dictionary.

        Args:
            data: Dictionary representation or None

        Returns:
            SignatureRecord instance or None if input is None

        """
        if data is None:
            return None
        return SignatureRecord(
            signer_id=data["signer_id"],
            role=data["role"],
            signature=data["signature"],
            message_hash=data["message_hash"],
            timestamp=ensure_utc(datetime.fromisoformat(data["timestamp"])),
            public_key=data.get("public_key"),
            algorithm=data.get("algorithm", "ed25519-legacy"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize workflow to dictionary for persistence.

        Serializes all instance attributes required for checkpoint storage.
        The validator is NOT serialized as it contains cryptographic material
        that should be recreated on deserialization.

        Returns:
            Dictionary suitable for JSON serialization and storage

        Note:
            datetime objects are converted to ISO format strings.
            SignatureRecord objects are converted to nested dictionaries.

        """
        request_dict: dict[str, Any] = {
            "proposal_id": self.request.proposal_id,
            "justification": self.request.justification,
            "failed_gates": list(self.request.failed_gates),
            "requested_by": self.request.requested_by,
            "requested_at": self.request.requested_at.isoformat(),
            "state": self.request.state.value,
        }
        # Include rejection metadata if present (for audit trail)
        if self.request.rejected_by is not None:
            request_dict["rejected_by"] = self.request.rejected_by
        if self.request.rejection_reason is not None:
            request_dict["rejection_reason"] = self.request.rejection_reason
        if self.request.rejected_at is not None:
            request_dict["rejected_at"] = self.request.rejected_at.isoformat()

        return {
            "workflow_id": self.workflow_id,
            "workflow_type": self.workflow_type,
            "current_state": self.current_state,
            "request": request_dict,
            "message_hash": self.message_hash,
            "expires_at": self.expires_at.isoformat(),
            "risk_lead_signature": self._serialize_signature(self.risk_lead_signature),
            "security_lead_signature": self._serialize_signature(
                self.security_lead_signature,
            ),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OverrideWorkflow":
        """Deserialize workflow from dictionary.

        Reconstructs an OverrideWorkflow instance from a persisted dictionary.
        The validator is set to None and must be set separately if signature
        verification is needed post-restore.

        Args:
            data: Dictionary from to_dict() or checkpoint storage

        Returns:
            Reconstructed OverrideWorkflow instance

        Note:
            The validator attribute will be None after deserialization.
            Call set_validator() or assign directly if verification is needed.

        """
        # Reconstruct request
        req_data = data["request"]
        # Parse optional rejection timestamp
        rejected_at_raw = req_data.get("rejected_at")
        rejected_at = (
            ensure_utc(datetime.fromisoformat(rejected_at_raw))
            if rejected_at_raw
            else None
        )
        request = OverrideRequest(
            proposal_id=req_data["proposal_id"],
            justification=req_data["justification"],
            failed_gates=list(req_data["failed_gates"]),
            requested_by=req_data["requested_by"],
            requested_at=ensure_utc(datetime.fromisoformat(req_data["requested_at"])),
            state=OverrideState(req_data.get("state", "pending")),
            rejected_by=req_data.get("rejected_by"),
            rejection_reason=req_data.get("rejection_reason"),
            rejected_at=rejected_at,
        )

        # Create workflow instance without calling __init__
        # This avoids regenerating message_hash and timestamps.
        # MAINTENANCE NOTE: All attributes set in __init__ MUST be set below.
        # If __init__ adds new attributes, update this method accordingly.
        # Required attrs: validator, key_store, rbac_enforcer, telemetry_emitter,
        #                 prometheus_exporter, alert_sink, request, message_hash,
        #                 expires_at, risk_lead_signature, security_lead_signature
        workflow = cls.__new__(cls)
        workflow.validator = None  # Cannot deserialize validator - set separately
        workflow.key_store = None  # Cannot deserialize key_store - set separately
        workflow.rbac_enforcer = None
        workflow.telemetry_emitter = None
        workflow.prometheus_exporter = None
        workflow.alert_sink = None
        workflow.request = request
        workflow.message_hash = data["message_hash"]
        workflow.expires_at = ensure_utc(datetime.fromisoformat(data["expires_at"]))
        workflow.risk_lead_signature = cls._deserialize_signature(
            data.get("risk_lead_signature"),
        )
        workflow.security_lead_signature = cls._deserialize_signature(
            data.get("security_lead_signature"),
        )

        return workflow

    @classmethod
    def from_dict_with_validator(
        cls,
        data: dict[str, Any],
        validator: Optional[DualSignatureValidator] = None,
        key_store: Optional["KeyStoreRepository"] = None,
    ) -> "OverrideWorkflow":
        """Deserialize workflow with validator and key_store pre-configured.

        This is the recommended factory method for restoring workflows
        that need immediate signature operations.

        Args:
            data: Dictionary from to_dict() or checkpoint storage
            validator: DualSignatureValidator for signature verification
                      (default: creates new DualSignatureValidator)
            key_store: KeyStoreRepository for key operations (optional)

        Returns:
            Reconstructed OverrideWorkflow ready for signature operations

        Example:
            >>> data = workflow.to_dict()
            >>> # Later, restore with validator ready:
            >>> restored = OverrideWorkflow.from_dict_with_validator(
            ...     data,
            ...     validator=DualSignatureValidator(),
            ...     key_store=my_key_store,
            ... )
            >>> # Can immediately add signatures
            >>> success, msg = restored.add_signature(...)

        """
        workflow = cls.from_dict(data)
        workflow.validator = validator or DualSignatureValidator()
        workflow.key_store = key_store
        return workflow

    def set_validator(self, validator: DualSignatureValidator) -> None:
        """Set the signature validator after deserialization.

        The validator cannot be serialized as it may contain cryptographic
        key material. This method allows setting a validator on a
        deserialized workflow instance.

        Args:
            validator: DualSignatureValidator instance to use for verification

        Note:
            Consider using from_dict_with_validator() instead for cleaner code.

        """
        self.validator = validator

    def set_key_store(self, key_store: "KeyStoreRepository") -> None:
        """Set the key store after deserialization.

        The key store cannot be serialized as it contains database
        connections. This method allows setting a key store on a
        deserialized workflow instance.

        Args:
            key_store: KeyStoreRepository instance for key operations

        """
        self.key_store = key_store

    def _check_four_eyes_violation(self, role: str, actor_id: str) -> Optional[str]:
        """Check if signing would violate four-eyes principle (W-10 fix).

        Returns error message if violation detected, None otherwise.
        """
        other_sig = (
            self.security_lead_signature
            if role == "risk_lead"
            else self.risk_lead_signature
        )
        if other_sig is not None and other_sig.signer_id == actor_id:
            return "Four-eyes violation: same signer cannot sign both roles"
        return None

    # =========================================================================
    # Key Store Integration (GAP-Q2 Phase 2)
    # =========================================================================

    async def _fetch_signing_keys(
        self,
        role: str,
        algorithm: str,
    ) -> "tuple[bytes, bytes, Optional[int]] | str":
        """Fetch private+public key bytes with version pinning.

        Returns (private_bytes, public_bytes, key_version) on success, or an
        error string. Pins key version to avoid race windows where key rotation
        causes private/public reads from different versions.
        """
        assert self.key_store is not None  # caller guarantees
        key_version: Optional[int] = None
        get_key_info = getattr(self.key_store, "get_key_info", None)
        if get_key_info is not None:
            result = get_key_info(role, algorithm)
            if inspect.isawaitable(result):
                result = await result
            if isinstance(result, dict):
                raw_version = result.get("key_version")
                if isinstance(raw_version, int) and not isinstance(raw_version, bool):
                    key_version = raw_version

        kw = {"version": key_version} if key_version is not None else {}
        private_key_bytes = await self.key_store.get_private_key(role, algorithm, **kw)
        if private_key_bytes is None:
            return f"No active key found for {role}/{algorithm}"

        public_key_bytes = await self.key_store.get_public_key(role, algorithm, **kw)
        if public_key_bytes is None:
            return f"No public key found for {role}/{algorithm}"

        return private_key_bytes, public_key_bytes, key_version

    async def sign_with_stored_key(
        self,
        role: str,
        actor_id: str,
    ) -> tuple[bool, str]:
        """Sign override using key from key store.

        Retrieves the private key for the specified role from the key store,
        signs the message hash, and adds the signature to the workflow.
        Records key usage in audit trail.

        This method is asynchronous because it accesses the database.

        Args:
            role: Signer's role ('risk_lead' or 'security_lead')
            actor_id: Actor performing the signing operation

        Returns:
            (success, message) tuple:
                - (True, "risk_lead signature accepted") on success
                - (False, error_message) on failure

        Raises:
            RuntimeError: If key_store or validator not configured

        Example:
            >>> workflow = OverrideWorkflow(
            ...     proposal_id="prop-1",
            ...     justification="emergency fix",
            ...     failed_gates=["quality_gate"],
            ...     requested_by="dev@aegis.io",
            ...     key_store=key_store,
            ... )
            >>> success, msg = await workflow.sign_with_stored_key("risk_lead", "risk@aegis.io")
            >>> if success:
            ...     # Continue with security lead signature
            ...     success, msg = await workflow.sign_with_stored_key("security_lead", "sec@aegis.io")

        """
        # Validate preconditions
        if self.key_store is None:
            return False, "Key store not configured - provide key_store to constructor"

        if self.validator is None:
            return False, "Validator not configured - call set_validator() first"

        # Check terminal states before any key operations (avoid unnecessary
        # private key decryption for no-op operations)
        if self.request.state in self._TERMINAL_STATES:
            return False, f"Override request is already {self.request.state.value}"

        if role not in DualSignatureValidator.REQUIRED_ROLES:
            return (
                False,
                f"Invalid role: {role}. Required: {DualSignatureValidator.REQUIRED_ROLES}",
            )

        # Check for existing signature
        if role == "risk_lead" and self.risk_lead_signature:
            return False, "Risk Lead signature already provided"
        if role == "security_lead" and self.security_lead_signature:
            return False, "Security Lead signature already provided"

        # Four-eyes pre-check: reject before key fetch to avoid unnecessary
        # private key decryption for a no-op operation (W-10 fix)
        violation = self._check_four_eyes_violation(role, actor_id)
        if violation is not None:
            return False, violation

        # Check expiration
        if self.is_expired:
            self.request.state = OverrideState.EXPIRED
            return False, "Override request has expired"

        # Get algorithm from validator
        algorithm = self.validator.algorithm_name

        try:
            # Retrieve keys with version pinning to avoid rotation races
            result = await self._fetch_signing_keys(role, algorithm)
            if isinstance(result, str):
                return False, result
            private_key_bytes, public_key_bytes, key_version = result

            # Encode keys as base64 for validator interface
            private_key_b64 = base64.b64encode(private_key_bytes).decode("ascii")
            public_key_b64 = base64.b64encode(public_key_bytes).decode("ascii")

            # Sign the message hash
            signature_b64 = self.validator.sign_message(
                self.message_hash,
                private_key_b64,
            )

            # Add signature using existing method
            success, message = self.add_signature(
                signer_id=actor_id,
                role=role,
                signature=signature_b64,
                public_key=public_key_b64,
            )

            if success:
                # Record key usage in audit trail
                await self.key_store.record_usage(
                    role=role,
                    algorithm=algorithm,
                    operation="sign",
                    actor_id=actor_id,
                    context={
                        "proposal_id": self.request.proposal_id,
                        "message_hash": self.message_hash,
                        "workflow_type": "override",
                    },
                    version=key_version,
                )
                logger.info(
                    f"Override signed with stored key: role={role}, "
                    f"actor={actor_id}, proposal={self.request.proposal_id}",
                )

            return success, message

        except (ValueError, RuntimeError, KeyError) as e:
            logger.error(f"sign_with_stored_key failed: {e}")
            return False, f"Signing failed: {e}"

    async def get_stored_key_info(
        self,
        role: str,
    ) -> Optional[dict[str, Any]]:
        """Get information about the stored key for a role.

        Useful for verifying key availability before signing.

        Args:
            role: Role to check ('risk_lead' or 'security_lead')

        Returns:
            Key info dict or None if not found/no key store

        Raises:
            RuntimeError: If key_store not configured

        """
        if self.key_store is None:
            return None

        if self.validator is None:
            return None

        algorithm = self.validator.algorithm_name
        return await self.key_store.get_key_info(role, algorithm)
