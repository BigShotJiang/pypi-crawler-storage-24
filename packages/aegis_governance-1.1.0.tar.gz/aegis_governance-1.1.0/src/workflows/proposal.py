"""Proposal Lifecycle Workflow

Manages proposal state machine through evaluation, consensus, and execution.

GAP-L1 Integration:
    Prometheus metrics are recorded for each state transition when prometheus_exporter
    is provided, tracking proposal lifecycle progression.
"""

import copy
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

from .serialization import SerializableMixin, ensure_utc

if TYPE_CHECKING:
    from telemetry.prometheus_exporter import PrometheusExporter


class ProposalState(str, Enum):
    """Proposal lifecycle states."""

    DRAFT = "draft"  # Initial creation
    SUBMITTED = "submitted"  # Awaiting evaluation
    EVALUATING = "evaluating"  # Gate evaluation in progress
    GATE_PASSED = "gate_passed"  # All gates passed
    GATE_FAILED = "gate_failed"  # One or more gates failed
    OVERRIDE_REQUESTED = "override_requested"  # Override pending
    CONSENSUS_PENDING = "consensus_pending"  # Awaiting consensus
    APPROVED = "approved"  # Ready for execution
    REJECTED = "rejected"  # Permanently rejected
    EXECUTING = "executing"  # Execution in progress
    COMPLETED = "completed"  # Successfully completed
    ROLLED_BACK = "rolled_back"  # Rolled back after failure


class ProposalPriority(str, Enum):
    """Proposal priority levels."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class StateTransition:
    """Record of state transition."""

    from_state: ProposalState
    to_state: ProposalState
    timestamp: datetime
    actor_id: str
    reason: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProposalMetadata:
    """Proposal metadata and context."""

    title: str
    description: str
    author_id: str
    priority: ProposalPriority = ProposalPriority.MEDIUM
    tags: list[str] = field(default_factory=list)
    related_proposals: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Validate required metadata fields."""
        if not self.title or not self.title.strip():
            raise ValueError("ProposalMetadata requires a non-empty title")
        if not self.description or not self.description.strip():
            raise ValueError("ProposalMetadata requires a non-empty description")
        if not self.author_id or not self.author_id.strip():
            raise ValueError("ProposalMetadata requires a non-empty author_id")


@dataclass
class EvaluationResult:
    """Gate evaluation result attached to proposal."""

    gate_results: dict[str, Any]
    all_passed: bool
    override_eligible: bool
    evaluated_at: datetime
    evaluator_id: str


class ProposalWorkflow(SerializableMixin):
    """Proposal lifecycle state machine.

    States:
    DRAFT -> SUBMITTED -> EVALUATING -> GATE_PASSED -> CONSENSUS_PENDING -> APPROVED -> EXECUTING -> COMPLETED
                                     -> GATE_FAILED -> OVERRIDE_REQUESTED -> ...
                                                    -> REJECTED

    Transitions are validated and recorded for audit trail.
    """

    # Valid state transitions
    VALID_TRANSITIONS = {
        ProposalState.DRAFT: {ProposalState.SUBMITTED},
        ProposalState.SUBMITTED: {ProposalState.EVALUATING},
        ProposalState.EVALUATING: {
            ProposalState.GATE_PASSED,
            ProposalState.GATE_FAILED,
        },
        ProposalState.GATE_PASSED: {
            ProposalState.CONSENSUS_PENDING,
            ProposalState.APPROVED,
        },
        ProposalState.GATE_FAILED: {
            ProposalState.OVERRIDE_REQUESTED,
            ProposalState.REJECTED,
        },
        ProposalState.OVERRIDE_REQUESTED: {
            ProposalState.CONSENSUS_PENDING,
            ProposalState.REJECTED,
        },
        ProposalState.CONSENSUS_PENDING: {
            ProposalState.APPROVED,
            ProposalState.REJECTED,
        },
        ProposalState.APPROVED: {ProposalState.EXECUTING},
        ProposalState.EXECUTING: {ProposalState.COMPLETED, ProposalState.ROLLED_BACK},
        ProposalState.REJECTED: set(),  # Terminal state
        ProposalState.COMPLETED: set(),  # Terminal state
        ProposalState.ROLLED_BACK: {ProposalState.DRAFT},  # Can restart
    }

    def __init__(
        self,
        metadata: ProposalMetadata,
        proposal_id: Optional[str] = None,
        prometheus_exporter: Optional["PrometheusExporter"] = None,
    ):
        """Initialize proposal workflow.

        Args:
            metadata: Proposal metadata
            proposal_id: Optional ID (generated if not provided)
            prometheus_exporter: Optional Prometheus exporter for metrics (GAP-L1)

        """
        self.proposal_id = proposal_id or str(uuid.uuid4())
        self.metadata = metadata
        self.state = ProposalState.DRAFT
        self.created_at = datetime.now(timezone.utc)
        self.updated_at = self.created_at

        self.transitions: list[StateTransition] = []
        self.evaluation_result: Optional[EvaluationResult] = None
        self.consensus_id: Optional[str] = None
        self.execution_id: Optional[str] = None

        self._prometheus_exporter = prometheus_exporter

    def __repr__(self) -> str:
        """Return informative string representation for debugging."""
        return (
            f"ProposalWorkflow("
            f"id={self.proposal_id!r}, "
            f"state={self.state.value!r}, "
            f"title={self.metadata.title!r}, "
            f"author={self.metadata.author_id!r})"
        )

    def can_transition_to(self, target_state: ProposalState) -> bool:
        """Check if transition to target state is valid."""
        return target_state in self.VALID_TRANSITIONS.get(self.state, set())

    def transition_to(
        self,
        target_state: ProposalState,
        actor_id: str,
        reason: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> bool:
        """Transition to a new state.

        Args:
            target_state: Target state
            actor_id: Actor performing transition
            reason: Reason for transition
            metadata: Additional metadata

        Returns:
            True if transition succeeded

        """
        if not self.can_transition_to(target_state):
            return False

        transition = StateTransition(
            from_state=self.state,
            to_state=target_state,
            timestamp=datetime.now(timezone.utc),
            actor_id=actor_id,
            reason=reason,
            metadata=copy.deepcopy(metadata) if metadata is not None else {},
        )

        self.transitions.append(transition)
        from_state_value = self.state.value
        self.state = target_state
        self.updated_at = transition.timestamp

        # Record state transition metrics (GAP-L1)
        if self._prometheus_exporter:
            self._prometheus_exporter.record_proposal_transition(
                from_state=from_state_value,
                to_state=target_state.value,
            )
            self._prometheus_exporter.record_proposal_state(
                state=target_state.value,
            )

        return True

    def submit(self, actor_id: str) -> bool:
        """Submit proposal for evaluation."""
        return self.transition_to(
            ProposalState.SUBMITTED,
            actor_id=actor_id,
            reason="Proposal submitted for evaluation",
        )

    def start_evaluation(self, evaluator_id: str) -> bool:
        """Start gate evaluation."""
        return self.transition_to(
            ProposalState.EVALUATING,
            actor_id=evaluator_id,
            reason="Starting gate evaluation",
        )

    def complete_evaluation(
        self,
        evaluator_id: str,
        result: EvaluationResult,
    ) -> bool:
        """Complete evaluation with result.

        Args:
            evaluator_id: Evaluator ID
            result: Evaluation result

        Returns:
            True if transition succeeded

        """
        target_state = (
            ProposalState.GATE_PASSED
            if result.all_passed
            else ProposalState.GATE_FAILED
        )

        success = self.transition_to(
            target_state,
            actor_id=evaluator_id,
            reason=f"Evaluation complete: {'passed' if result.all_passed else 'failed'}",
            metadata={"gate_results": result.gate_results},
        )
        # Only set evaluation_result if transition succeeded (W-5 fix)
        if success:
            self.evaluation_result = result
        return success

    def request_override(self, actor_id: str, justification: str) -> bool:
        """Request override for failed gates."""
        if self.evaluation_result is None:
            return False  # Cannot verify override eligibility without evaluation
        if not self.evaluation_result.override_eligible:
            return False

        return self.transition_to(
            ProposalState.OVERRIDE_REQUESTED,
            actor_id=actor_id,
            reason=f"Override requested: {justification}",
        )

    def start_consensus(self, actor_id: str, consensus_id: str) -> bool:
        """Start consensus workflow."""
        success = self.transition_to(
            ProposalState.CONSENSUS_PENDING,
            actor_id=actor_id,
            reason="Consensus workflow started",
            metadata={"consensus_id": consensus_id},
        )
        if success:
            self.consensus_id = consensus_id
        return success

    def approve(self, actor_id: str) -> bool:
        """Approve proposal."""
        return self.transition_to(
            ProposalState.APPROVED,
            actor_id=actor_id,
            reason="Proposal approved",
        )

    def reject(self, actor_id: str, reason: str) -> bool:
        """Reject proposal."""
        return self.transition_to(
            ProposalState.REJECTED,
            actor_id=actor_id,
            reason=f"Proposal rejected: {reason}",
        )

    def start_execution(self, actor_id: str, execution_id: str) -> bool:
        """Start execution."""
        success = self.transition_to(
            ProposalState.EXECUTING,
            actor_id=actor_id,
            reason="Execution started",
            metadata={"execution_id": execution_id},
        )
        if success:
            self.execution_id = execution_id
        return success

    def complete_execution(self, actor_id: str) -> bool:
        """Mark execution as complete."""
        return self.transition_to(
            ProposalState.COMPLETED,
            actor_id=actor_id,
            reason="Execution completed successfully",
        )

    def rollback(self, actor_id: str, reason: str) -> bool:
        """Roll back failed execution."""
        return self.transition_to(
            ProposalState.ROLLED_BACK,
            actor_id=actor_id,
            reason=f"Rolled back: {reason}",
        )

    def get_audit_trail(self) -> list[dict[str, Any]]:
        """Get full audit trail of transitions."""
        return [
            {
                "from_state": t.from_state.value,
                "to_state": t.to_state.value,
                "timestamp": t.timestamp.isoformat(),
                "actor_id": t.actor_id,
                "reason": t.reason,
                "metadata": dict(t.metadata) if t.metadata else {},
            }
            for t in self.transitions
        ]

    @property
    def is_terminal(self) -> bool:
        """Check if proposal is in terminal state.

        Note: ROLLED_BACK is NOT terminal - it can transition back to DRAFT
        for re-submission. Only REJECTED and COMPLETED are true terminal states.
        """
        return self.state in (
            ProposalState.REJECTED,
            ProposalState.COMPLETED,
        )

    @property
    def is_active(self) -> bool:
        """Check if proposal is actively being processed."""
        return self.state in (
            ProposalState.EVALUATING,
            ProposalState.CONSENSUS_PENDING,
            ProposalState.EXECUTING,
        )

    @property
    def workflow_id(self) -> str:
        """Unique workflow identifier."""
        return self.proposal_id

    @property
    def workflow_type(self) -> str:
        """Workflow type discriminator for persistence."""
        return "proposal"

    @property
    def current_state(self) -> str:
        """Current state value for persistence."""
        return self.state.value

    def to_dict(self) -> dict[str, Any]:
        """Serialize workflow to dictionary for persistence.

        Returns:
            Dictionary representation of workflow state.

        """
        return {
            "proposal_id": self.proposal_id,
            "metadata": {
                "title": self.metadata.title,
                "description": self.metadata.description,
                "author_id": self.metadata.author_id,
                "priority": self.metadata.priority.value,
                "tags": list(self.metadata.tags),
                "related_proposals": list(self.metadata.related_proposals),
            },
            "state": self.state.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "transitions": [
                {
                    "from_state": t.from_state.value,
                    "to_state": t.to_state.value,
                    "timestamp": t.timestamp.isoformat(),
                    "actor_id": t.actor_id,
                    "reason": t.reason,
                    "metadata": copy.deepcopy(t.metadata) if t.metadata else {},
                }
                for t in self.transitions
            ],
            "evaluation_result": (
                {
                    "gate_results": copy.deepcopy(self.evaluation_result.gate_results),
                    "all_passed": self.evaluation_result.all_passed,
                    "override_eligible": self.evaluation_result.override_eligible,
                    "evaluated_at": self.evaluation_result.evaluated_at.isoformat(),
                    "evaluator_id": self.evaluation_result.evaluator_id,
                }
                if self.evaluation_result is not None
                else None
            ),
            "consensus_id": self.consensus_id,
            "execution_id": self.execution_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProposalWorkflow":
        """Deserialize workflow from dictionary.

        Note:
            The prometheus_exporter attribute is NOT restored during
            deserialization because it cannot be serialized (it contains
            runtime state and metric registries). After restoring a workflow,
            call set_prometheus_exporter() or use from_dict_with_exporter()
            to enable metrics recording for state transitions.

        Args:
            data: Dictionary representation of workflow state.

        Returns:
            Reconstructed ProposalWorkflow instance.

        See Also:
            from_dict_with_exporter: Factory method that sets exporter during restoration.
            set_prometheus_exporter: Method to set exporter after restoration.

        """
        # Reconstruct metadata
        meta_data = data["metadata"]
        metadata = ProposalMetadata(
            title=meta_data["title"],
            description=meta_data["description"],
            author_id=meta_data["author_id"],
            priority=ProposalPriority(meta_data["priority"]),
            tags=list(meta_data.get("tags", [])),
            related_proposals=list(meta_data.get("related_proposals", [])),
        )

        # MAINTENANCE NOTE: all attributes set in __init__ MUST be set below.
        # Use cls.__new__(cls) to bypass __init__ and avoid side effects during
        # deserialization (BH43-L4: parity with ConsensusWorkflow/OverrideWorkflow).
        workflow = cls.__new__(cls)
        workflow.proposal_id = data["proposal_id"]
        workflow.metadata = metadata
        workflow._prometheus_exporter = None

        # Restore state
        workflow.state = ProposalState(data["state"])
        workflow.created_at = ensure_utc(datetime.fromisoformat(data["created_at"]))
        workflow.updated_at = ensure_utc(datetime.fromisoformat(data["updated_at"]))

        # Restore transitions
        workflow.transitions = [
            StateTransition(
                from_state=ProposalState(t["from_state"]),
                to_state=ProposalState(t["to_state"]),
                timestamp=ensure_utc(datetime.fromisoformat(t["timestamp"])),
                actor_id=t["actor_id"],
                reason=t.get("reason"),
                metadata=copy.deepcopy(t.get("metadata", {})),
            )
            for t in data.get("transitions", [])
        ]

        # Restore evaluation result if present (default None matches __init__)
        workflow.evaluation_result = None
        eval_data = data.get("evaluation_result")
        if eval_data is not None:
            workflow.evaluation_result = EvaluationResult(
                gate_results=copy.deepcopy(eval_data["gate_results"]),
                all_passed=eval_data["all_passed"],
                override_eligible=eval_data["override_eligible"],
                evaluated_at=ensure_utc(
                    datetime.fromisoformat(eval_data["evaluated_at"])
                ),
                evaluator_id=eval_data["evaluator_id"],
            )

        # Restore optional linked workflow IDs
        workflow.consensus_id = data.get("consensus_id")
        workflow.execution_id = data.get("execution_id")

        return workflow

    @classmethod
    def from_dict_with_exporter(
        cls,
        data: dict[str, Any],
        prometheus_exporter: Optional["PrometheusExporter"] = None,
    ) -> "ProposalWorkflow":
        """Deserialize workflow with prometheus_exporter pre-configured.

        This is the recommended factory method for restoring workflows
        that need immediate metrics recording for state transitions.

        Args:
            data: Dictionary from to_dict() or checkpoint storage
            prometheus_exporter: PrometheusExporter for metrics recording (GAP-L1)

        Returns:
            Reconstructed ProposalWorkflow ready for metrics recording

        Example:
            >>> data = workflow.to_dict()
            >>> # Later, restore with exporter ready:
            >>> restored = ProposalWorkflow.from_dict_with_exporter(
            ...     data,
            ...     prometheus_exporter=get_exporter(),
            ... )
            >>> # State transitions will now record metrics
            >>> restored.approve("admin")

        """
        workflow = cls.from_dict(data)
        workflow._prometheus_exporter = prometheus_exporter
        return workflow

    def set_prometheus_exporter(
        self, prometheus_exporter: "PrometheusExporter"
    ) -> None:
        """Set the Prometheus exporter after deserialization.

        The prometheus_exporter cannot be serialized as it contains runtime
        state and metric registries. This method allows setting an exporter
        on a deserialized workflow instance to enable metrics recording.

        Args:
            prometheus_exporter: PrometheusExporter instance for metrics (GAP-L1)

        Note:
            Consider using from_dict_with_exporter() instead for cleaner code.

        Example:
            >>> restored = ProposalWorkflow.from_dict(data)
            >>> restored.set_prometheus_exporter(get_exporter())
            >>> # Now state transitions will record metrics

        """
        self._prometheus_exporter = prometheus_exporter
