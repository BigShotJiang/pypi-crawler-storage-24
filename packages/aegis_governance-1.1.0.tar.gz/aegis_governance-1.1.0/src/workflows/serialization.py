"""Shared serialization helpers for workflow modules.

Extracted from ConsensusWorkflow, OverrideWorkflow, and ProposalWorkflow
to eliminate identical _ensure_utc() static methods.

TD-2: SerializableMixin documents the shared workflow serialization interface.
"""

from datetime import datetime, timezone
from typing import Any


def ensure_utc(dt: datetime) -> datetime:
    """Ensure datetime is timezone-aware (UTC).

    If the datetime is naive (no timezone info), assumes it represents
    UTC time and attaches the UTC timezone.  This prevents comparison
    errors between timezone-aware and naive datetimes.

    Args:
        dt: Datetime to normalize.

    Returns:
        Timezone-aware datetime in UTC.

    """
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class SerializableMixin:
    """Mixin documenting the shared workflow serialization interface.

    All LIBERTAS workflow classes (ConsensusWorkflow, OverrideWorkflow,
    ProposalWorkflow) implement to_dict()/from_dict() with this shared
    contract. Subclasses MUST provide:
    - workflow_id: str property
    - workflow_type: str property
    - current_state: str property
    - to_dict() -> dict[str, Any]
    - from_dict(cls, data) -> instance  (classmethod)
    """

    @property
    def workflow_id(self) -> str:
        """Unique workflow identifier."""
        raise NotImplementedError

    @property
    def workflow_type(self) -> str:
        """Workflow type discriminator for persistence."""
        raise NotImplementedError

    @property
    def current_state(self) -> str:
        """Current state value for persistence."""
        raise NotImplementedError

    def to_dict(self) -> dict[str, Any]:
        """Serialize workflow to dictionary."""
        raise NotImplementedError

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SerializableMixin":
        """Deserialize workflow from dictionary."""
        raise NotImplementedError
