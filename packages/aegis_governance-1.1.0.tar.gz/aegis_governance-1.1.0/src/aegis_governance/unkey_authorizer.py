"""AEGIS Lambda Authorizer — Unkey-based API key validation.

Deployed as a separate Lambda function, invoked by API Gateway as a
TOKEN authorizer. Validates ``Authorization: Bearer uk_live_xxx`` tokens
via the Unkey API and returns an IAM policy document with customer
context in the authorizer response.

Falls back to allowing legacy API Gateway key authentication when no
Bearer token is present (dual-auth migration period).

Environment variables:
    UNKEY_ROOT_KEY_SECRET  — Secrets Manager ARN for Unkey root key
    UNKEY_API_ID           — Unkey API namespace ID
    AEGIS_STAGE            — Deployment stage (dev/staging/prod)
"""

from __future__ import annotations

import json
import logging
import os
import threading
from typing import Any

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# --- Singleton Unkey Client (Lambda warm-start) ---
_UNKEY_CLIENT_LOCK = threading.Lock()
_UNKEY_CLIENT: Any = None


def _get_unkey_client() -> Any:
    """Lazy-init UnkeyClient singleton (survives Lambda warm starts)."""
    global _UNKEY_CLIENT  # noqa: PLW0603
    if _UNKEY_CLIENT is not None:
        return _UNKEY_CLIENT
    with _UNKEY_CLIENT_LOCK:
        if _UNKEY_CLIENT is None:
            root_key = _load_root_key()
            api_id = os.environ.get("UNKEY_API_ID", "")
            from aegis_governance.unkey import UnkeyClient

            _UNKEY_CLIENT = UnkeyClient(root_key=root_key, api_id=api_id)
    return _UNKEY_CLIENT


def _load_root_key() -> str:
    """Load Unkey root key from Secrets Manager."""
    secret_arn = os.environ.get("UNKEY_ROOT_KEY_SECRET", "")
    if not secret_arn:
        raise RuntimeError("UNKEY_ROOT_KEY_SECRET environment variable not set")

    import boto3

    client = boto3.client("secretsmanager")
    resp = client.get_secret_value(SecretId=secret_arn)
    secret_str = resp.get("SecretString", "")
    if not secret_str:
        raise RuntimeError("Unkey root key secret is empty")

    # Support both plain string and JSON {"root_key": "..."} formats
    try:
        data = json.loads(secret_str)
        root_key = str(data.get("root_key", data.get("key", "")))
    except (json.JSONDecodeError, AttributeError):
        root_key = secret_str

    if not root_key:
        raise RuntimeError(
            "Unkey root key not found in secret. "
            "Expected plain string or JSON with 'root_key' field."
        )
    return root_key


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda Authorizer entry point.

    Args:
        event: API Gateway TOKEN authorizer event.
        context: Lambda context.

    Returns:
        IAM policy document with AEGIS customer context.
    """
    token = event.get("authorizationToken", "")
    method_arn = event.get("methodArn", "")

    # Extract Bearer token — only accept Bearer scheme or uk_ prefixed keys
    if token.lower().startswith("bearer "):
        api_key = token[7:].strip()
    elif token.strip().startswith("uk_"):
        # Allow raw Unkey tokens (e.g. uk_live_xxx) without Bearer prefix
        api_key = token.strip()
    else:
        # Reject non-Unkey tokens locally — do not forward unknown credentials
        logger.info("Unsupported token format — deny")
        return _build_policy("anonymous", "Deny", method_arn)

    if not api_key:
        logger.info("No API key provided — deny")
        return _build_policy("anonymous", "Deny", method_arn)

    # Verify via Unkey
    try:
        client = _get_unkey_client()
        result = client.verify_key(api_key)
    except Exception as e:
        logger.error("Unkey verification failed: %s", e)
        return _build_policy("anonymous", "Deny", method_arn)

    if not result.valid:
        logger.info("Key invalid: code=%s", result.code)
        return _build_policy("anonymous", "Deny", method_arn)

    # Extract customer context from Unkey metadata
    customer_id = result.owner_id or result.meta.get("customer_id", "")
    tier = result.meta.get("tier", "community")

    logger.info(
        "Authorized: customer=%s tier=%s remaining=%s",
        customer_id,
        tier,
        result.remaining,
    )

    policy = _build_policy(customer_id or "unkey-user", "Allow", method_arn)

    # Inject AEGIS context into authorizer response
    # result.remaining is Unkey rate-limit remaining, not usage quota
    policy["context"] = {
        "customer_id": customer_id,
        "tier": tier,
        "rate_remaining": result.remaining if result.remaining is not None else -1,
    }

    return policy


def _build_policy(
    principal_id: str,
    effect: str,
    method_arn: str,
) -> dict[str, Any]:
    """Build an IAM policy document for API Gateway authorizer response.

    Args:
        principal_id: The principal (customer) identifier.
        effect: "Allow" or "Deny".
        method_arn: The API Gateway method ARN to authorize.

    Returns:
        IAM policy document dict.
    """
    # Wildcard the method ARN to allow all methods on this API
    # Format: arn:aws:execute-api:{region}:{account}:{api-id}/{stage}/{method}/{resource}
    arn_parts = method_arn.split(":")
    api_gateway_arn = ":".join(arn_parts[:5])
    api_parts = arn_parts[5].split("/") if len(arn_parts) > 5 else []

    if len(api_parts) >= 2:
        # Wildcard: allow all methods and resources under this API/stage
        resource_arn = f"{api_gateway_arn}:{api_parts[0]}/{api_parts[1]}/*"
    else:
        resource_arn = method_arn

    return {
        "principalId": principal_id,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": effect,
                    "Resource": resource_arn,
                }
            ],
        },
    }
