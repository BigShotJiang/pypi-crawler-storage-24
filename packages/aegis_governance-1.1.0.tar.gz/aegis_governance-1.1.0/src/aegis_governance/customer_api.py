"""AEGIS Customer API — self-service customer endpoints.

Deployed as a separate Lambda function to isolate from the hot governance
evaluation path. Provides customer-facing endpoints for profile management,
usage viewing, and API key management via Unkey.

Routes:
    GET    /customer/profile          — Own profile + tier info
    PATCH  /customer/profile          — Update name, company
    GET    /customer/usage            — Current month usage
    GET    /customer/usage/{month}    — Historical usage
    POST   /customer/keys             — Create Unkey API key
    DELETE /customer/keys/{key_id}    — Revoke key
    GET    /customer/keys             — List own keys
    POST   /customer/upgrade-request  — Submit tier upgrade request

Authentication:
    All endpoints require a valid Unkey API key via the Lambda Authorizer.
    The customer_id is extracted from ``requestContext.authorizer.customer_id``.

Environment variables:
    AEGIS_TABLE_NAME         — DynamoDB table name
    UNKEY_ROOT_KEY_SECRET    — Secrets Manager ARN for Unkey root key
    UNKEY_API_ID             — Unkey API namespace ID
    AEGIS_STAGE              — Deployment stage
"""

from __future__ import annotations

import hmac as hmac_mod
import json
import logging
import os
import re
import threading
from typing import Any

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# --- Singletons (Lambda warm-start) ---
_LOCK = threading.Lock()
_CUSTOMER_MGR: Any = None
_UNKEY_CLIENT: Any = None
_UNKEY_INIT_DONE: bool = False


def _get_customer_manager() -> Any:
    """Lazy-init CustomerManager singleton."""
    global _CUSTOMER_MGR  # noqa: PLW0603
    if _CUSTOMER_MGR is not None:
        return _CUSTOMER_MGR
    with _LOCK:
        if _CUSTOMER_MGR is None:
            from aegis_governance.customer import CustomerManager

            _CUSTOMER_MGR = CustomerManager()
    return _CUSTOMER_MGR


def _get_unkey_client() -> Any:
    """Lazy-init UnkeyClient singleton."""
    global _UNKEY_CLIENT, _UNKEY_INIT_DONE  # noqa: PLW0603
    if _UNKEY_INIT_DONE:
        return _UNKEY_CLIENT
    with _LOCK:
        if not _UNKEY_INIT_DONE:
            from aegis_governance.unkey import UnkeyClient

            secret_arn = os.environ.get("UNKEY_ROOT_KEY_SECRET", "")
            if secret_arn:
                import boto3

                sm = boto3.client("secretsmanager")
                resp = sm.get_secret_value(SecretId=secret_arn)
                secret = resp.get("SecretString", "")
                try:
                    data = json.loads(secret)
                    root_key = str(data.get("root_key", secret))
                except (json.JSONDecodeError, AttributeError):
                    root_key = secret
            else:
                root_key = os.environ.get("UNKEY_ROOT_KEY", "")

            api_id = os.environ.get("UNKEY_API_ID", "")
            if root_key:
                _UNKEY_CLIENT = UnkeyClient(root_key=root_key, api_id=api_id)
            _UNKEY_INIT_DONE = True
    return _UNKEY_CLIENT


_SERVICE_KEY: str = ""
_SERVICE_KEY_LOADED: bool = False


def _get_service_key() -> str:
    """Load service key for provisioning endpoint auth (cached for Lambda warm starts)."""
    global _SERVICE_KEY, _SERVICE_KEY_LOADED  # noqa: PLW0603
    if _SERVICE_KEY_LOADED:
        return _SERVICE_KEY
    with _LOCK:
        if not _SERVICE_KEY_LOADED:
            secret_arn = os.environ.get("AEGIS_SERVICE_KEY_SECRET", "")
            if secret_arn:
                import boto3

                sm = boto3.client("secretsmanager")
                resp = sm.get_secret_value(SecretId=secret_arn)
                secret = resp.get("SecretString", "")
                try:
                    data = json.loads(secret)
                    _SERVICE_KEY = str(data.get("service_key", secret))
                except (json.JSONDecodeError, AttributeError):
                    _SERVICE_KEY = secret
            else:
                _SERVICE_KEY = os.environ.get("AEGIS_SERVICE_KEY", "")
            _SERVICE_KEY_LOADED = True
    return _SERVICE_KEY


def _route_authenticated(
    customer_id: str, http_method: str, path: str, event: dict[str, Any]
) -> dict[str, Any]:
    """Route authenticated requests to handlers."""
    if path == "/customer/profile" and http_method == "GET":
        return _handle_get_profile(customer_id)
    if path == "/customer/profile" and http_method == "PATCH":
        return _handle_update_profile(customer_id, event)
    if path == "/customer/usage" and http_method == "GET":
        return _handle_get_usage(customer_id)
    if path.startswith("/customer/usage/") and http_method == "GET":
        month = path.rsplit("/", maxsplit=1)[-1]
        if not _is_valid_month(month):
            return _response(400, {"error": "Invalid month format. Use YYYY-MM."})
        return _handle_get_usage(customer_id, month=month)
    if path == "/customer/keys" and http_method == "POST":
        return _handle_create_key(customer_id, event)
    if path.startswith("/customer/keys/") and http_method == "DELETE":
        key_id = path.rsplit("/", maxsplit=1)[-1]
        if not key_id:
            return _response(400, {"error": "key_id is required"})
        return _handle_revoke_key(customer_id, key_id)
    if path == "/customer/keys" and http_method == "GET":
        return _handle_list_keys(customer_id)
    if path == "/customer/upgrade-request" and http_method == "POST":
        return _handle_upgrade_request(customer_id, event)
    return _response(404, {"error": f"Not found: {http_method} {path}"})


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Customer API Lambda entry point."""
    http_method = event.get("httpMethod", "GET")
    path = event.get("path", "")

    # Provision endpoint uses service key auth (no Unkey token required)
    if path == "/customer/provision" and http_method == "POST":
        return _handle_provision(event)

    # Extract customer_id from authorizer context
    authorizer = event.get("requestContext", {}).get("authorizer", {})
    customer_id = authorizer.get("customer_id", "")

    if not customer_id:
        return _response(401, {"error": "Authentication required"})

    return _route_authenticated(customer_id, http_method, path, event)


# --- Route Handlers ---


def _handle_provision(event: dict[str, Any]) -> dict[str, Any]:
    """POST /customer/provision — create customer + API key for new users.

    Authenticated via X-Service-Key header (portal server-to-server).
    Accepts { clerk_user_id, email, name, company? }.
    Returns { customer_id, api_key, api_key_id }.
    """
    # Validate service key
    headers = event.get("headers", {}) or {}
    # API Gateway lowercases headers in proxy mode
    service_key = headers.get("X-Service-Key") or headers.get("x-service-key", "")
    expected_key = _get_service_key()

    if (
        not expected_key
        or not service_key
        or not hmac_mod.compare_digest(service_key, expected_key)
    ):
        return _response(401, {"error": "Invalid service key"})

    try:
        body = _parse_body(event)
    except (json.JSONDecodeError, ValueError) as e:
        return _response(400, {"error": f"Invalid body: {e}"})

    clerk_user_id = body.get("clerk_user_id", "")
    email = body.get("email", "")
    name = body.get("name", "")
    company = body.get("company", "")

    if not clerk_user_id:
        return _response(400, {"error": "clerk_user_id is required"})
    if not email:
        return _response(400, {"error": "email is required"})
    if not name:
        return _response(400, {"error": "name is required"})

    mgr = _get_customer_manager()
    unkey = _get_unkey_client()

    if not unkey:
        return _response(503, {"error": "Key management not available"})

    # Check if customer already exists by email
    existing = mgr.get_customer_by_email(email)
    if existing:
        customer = existing
        logger.info(
            "Found existing customer %s for email %s", customer.customer_id, email
        )
    else:
        # Create new customer
        customer = mgr.create_customer(
            name=name,
            email=email,
            company=company,
            tier="community",
            metadata={"clerk_user_id": clerk_user_id},
        )
        logger.info(
            "Created new customer %s for Clerk user %s",
            customer.customer_id,
            clerk_user_id,
        )

    # Create a new Unkey API key
    from aegis_governance.tiers import get_tier

    ratelimit = None
    try:
        tier = get_tier(customer.tier)
        ratelimit = {
            "type": "fast",
            "limit": tier.rate_per_minute,
            "duration": 60_000,
        }
    except ValueError:
        pass

    try:
        key_info = unkey.create_key(
            owner_id=customer.customer_id,
            name=f"auto-{clerk_user_id[:16]}",
            meta={"tier": customer.tier, "clerk_user_id": clerk_user_id},
            ratelimit=ratelimit,
        )
    except Exception as e:
        logger.error("Key creation failed during provisioning: %s", e)
        return _response(500, {"error": "Failed to create API key"})

    # Update customer with the new key ID
    mgr.update_customer(customer.customer_id, api_key_id=key_info.key_id)

    return _response(
        201,
        {
            "customer_id": customer.customer_id,
            "api_key": key_info.key,
            "api_key_id": key_info.key_id,
        },
    )


def _handle_get_profile(customer_id: str) -> dict[str, Any]:
    """GET /customer/profile — return own profile."""
    mgr = _get_customer_manager()
    customer = mgr.get_customer(customer_id)
    if not customer:
        return _response(404, {"error": "Customer not found"})

    from aegis_governance.tiers import get_tier

    try:
        tier_info = get_tier(customer.tier).to_dict()
    except ValueError:
        tier_info = {"name": customer.tier}

    response_body: dict[str, Any] = {
        "customer": customer.to_dict(),
        "tier_details": tier_info,
    }

    # Include subscription info if available
    subscription = mgr.get_subscription(customer_id)
    if subscription:
        response_body["subscription"] = subscription.to_dict()

    return _response(200, response_body)


def _handle_update_profile(customer_id: str, event: dict[str, Any]) -> dict[str, Any]:
    """PATCH /customer/profile — update name, company."""
    try:
        body = _parse_body(event)
    except (json.JSONDecodeError, ValueError) as e:
        return _response(400, {"error": f"Invalid body: {e}"})

    # Only allow safe fields
    allowed = {"name", "company"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        return _response(400, {"error": "No valid fields to update"})

    mgr = _get_customer_manager()
    try:
        customer = mgr.update_customer(customer_id, **updates)
    except ValueError as e:
        return _response(400, {"error": str(e)})

    if not customer:
        return _response(404, {"error": "Customer not found"})

    return _response(200, {"customer": customer.to_dict()})


def _handle_get_usage(customer_id: str, month: str | None = None) -> dict[str, Any]:
    """GET /customer/usage — current or historical usage."""
    mgr = _get_customer_manager()
    summary = mgr.get_usage(customer_id, month=month)

    from aegis_governance.tiers import get_tier

    # Look up the customer to get their tier for quota context
    customer = mgr.get_customer(customer_id)
    tier_name = customer.tier if customer else "community"

    try:
        tier = get_tier(tier_name)
        quota = tier.monthly_evaluations
    except ValueError:
        quota = 100  # Default to community tier cap

    usage_dict = summary.to_dict()
    usage_dict["quota"] = quota
    usage_dict["quota_remaining"] = max(0, quota - summary.total_evaluations)
    usage_dict["quota_percent"] = (
        round(summary.total_evaluations / quota * 100, 1) if quota > 0 else 0.0
    )

    return _response(200, usage_dict)


def _handle_create_key(customer_id: str, event: dict[str, Any]) -> dict[str, Any]:
    """POST /customer/keys — create a new Unkey API key."""
    unkey = _get_unkey_client()
    if not unkey:
        return _response(503, {"error": "Key management not available"})

    try:
        body = _parse_body(event)
    except (json.JSONDecodeError, ValueError) as e:
        return _response(400, {"error": f"Invalid body: {e}"})

    name = body.get("name", "")
    if not isinstance(name, str):
        return _response(400, {"error": "name must be a string"})

    # Check key limit
    mgr = _get_customer_manager()
    customer = mgr.get_customer(customer_id)
    if customer:
        from aegis_governance.tiers import get_tier

        try:
            tier = get_tier(customer.tier)
            existing_keys = unkey.list_keys(owner_id=customer_id)
            if len(existing_keys) >= tier.max_keys:
                return _response(
                    429,
                    {
                        "error": f"Key limit reached ({tier.max_keys} keys "
                        f"for {tier.display_name} tier)"
                    },
                )
        except ValueError:
            pass  # Unknown tier — allow key creation

    # Determine rate limit from tier
    ratelimit = None
    if customer:
        try:
            tier = get_tier(customer.tier)
            ratelimit = {
                "type": "fast",
                "limit": tier.rate_per_minute,
                "duration": 60_000,  # 1 minute in ms
            }
        except ValueError:
            pass

    try:
        key_info = unkey.create_key(
            owner_id=customer_id,
            name=name or f"key-{customer_id}",
            meta={"tier": customer.tier if customer else "community"},
            ratelimit=ratelimit,
        )
    except Exception as e:
        logger.error("Key creation failed: %s", e)
        return _response(500, {"error": "Key creation failed"})

    response_body: dict[str, Any] = {
        "key_id": key_info.key_id,
        "name": key_info.name,
    }
    if key_info.key:
        response_body["key"] = key_info.key
        response_body["message"] = (
            "Key created. Save the key value now — it will not be shown again."
        )
    else:
        response_body["message"] = "Key created."

    return _response(201, response_body)


def _handle_revoke_key(customer_id: str, key_id: str) -> dict[str, Any]:
    """DELETE /customer/keys/{key_id} — revoke a key."""
    unkey = _get_unkey_client()
    if not unkey:
        return _response(503, {"error": "Key management not available"})

    # Verify the key belongs to this customer
    keys = unkey.list_keys(owner_id=customer_id)
    if not any(k.key_id == key_id for k in keys):
        return _response(404, {"error": "Key not found or not owned by you"})

    success = unkey.revoke_key(key_id)
    if not success:
        return _response(500, {"error": "Key revocation failed"})

    return _response(200, {"message": f"Key {key_id} revoked"})


def _handle_list_keys(customer_id: str) -> dict[str, Any]:
    """GET /customer/keys — list own keys."""
    unkey = _get_unkey_client()
    if not unkey:
        return _response(503, {"error": "Key management not available"})

    keys = unkey.list_keys(owner_id=customer_id)
    return _response(
        200,
        {
            "count": len(keys),
            "keys": [
                {
                    "key_id": k.key_id,
                    "name": k.name,
                    "created_at": k.created_at,
                    "enabled": k.enabled,
                }
                for k in keys
            ],
        },
    )


def _handle_upgrade_request(customer_id: str, event: dict[str, Any]) -> dict[str, Any]:
    """POST /customer/upgrade-request — submit tier upgrade request."""
    try:
        body = _parse_body(event)
    except (json.JSONDecodeError, ValueError) as e:
        return _response(400, {"error": f"Invalid body: {e}"})

    requested_tier = body.get("tier", "")
    reason = body.get("reason", "")

    if not requested_tier:
        return _response(400, {"error": "tier is required"})

    from aegis_governance.tiers import TIERS

    if requested_tier not in TIERS:
        return _response(400, {"error": f"Invalid tier. Valid: {sorted(TIERS.keys())}"})

    # Log the upgrade request (in production, this would notify sales/ops)
    logger.info(
        "Upgrade request: customer=%s requested_tier=%s reason=%s",
        customer_id,
        requested_tier,
        reason,
    )

    return _response(
        200,
        {
            "message": "Upgrade request submitted",
            "customer_id": customer_id,
            "requested_tier": requested_tier,
            "status": "pending_review",
        },
    )


# --- Helpers ---

_MONTH_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")


def _is_valid_month(month: str) -> bool:
    """Validate month string is in YYYY-MM format."""
    return bool(_MONTH_RE.match(month))


def _parse_body(event: dict[str, Any]) -> dict[str, Any]:
    """Parse API Gateway event body."""
    raw = event.get("body", "{}")
    if raw is None:
        raw = "{}"
    if event.get("isBase64Encoded"):
        import base64

        raw = base64.b64decode(raw, validate=True).decode("utf-8")
    result = json.loads(raw)
    if not isinstance(result, dict):
        raise ValueError("Request body must be a JSON object")
    return result


def _response(status_code: int, body: dict[str, Any]) -> dict[str, Any]:
    """Build API Gateway proxy response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
        },
        "body": json.dumps(body),
    }
