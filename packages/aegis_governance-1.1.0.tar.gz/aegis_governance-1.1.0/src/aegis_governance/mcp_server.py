"""AEGIS MCP Server — governance gates for AI agents via MCP protocol.

Provides AEGIS governance gates as MCP tools that AI agents (Claude Code,
Codex, custom agents) can call to evaluate proposals before taking action.

Transport: stdio (standard MCP pattern via FastMCP)

Tools:
    aegis_evaluate_proposal  — Full gate evaluation via pcw_decide()
    aegis_quick_risk_check   — Simplified risk threshold check
    aegis_check_thresholds   — Introspect current gate thresholds
    aegis_get_scoring_guide  — Domain-specific parameter derivation guidance
    aegis_crypto_status      — Cryptographic provider availability and status

Usage:
    aegis-mcp-server          # stdio (default, for Claude Code)
"""

from __future__ import annotations

import json
import logging
import math
import os
import sys
import threading
from typing import Any

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:

    class FastMCP:  # type: ignore[no-redef]
        """Stub so module is importable without the mcp package."""

        def __init__(self, *a: Any, **kw: Any) -> None:
            pass

        def tool(self) -> Any:
            return lambda f: f

        def run(self, **kw: Any) -> None:
            raise RuntimeError(
                "mcp package required: pip install aegis-governance[mcp]"
            )


logger = logging.getLogger(__name__)

mcp = FastMCP(
    "aegis-governance",
    instructions=(
        "AEGIS Governance evaluates engineering proposals through "
        "6 quantitative gates (Risk, Profit, Novelty, Complexity, "
        "Quality, Utility) plus KL divergence drift detection. "
        "Recommended flow: (1) aegis_check_thresholds to see gate "
        "config, (2) aegis_get_scoring_guide(domain) for derivation "
        "formulas, (3) aegis_evaluate_proposal with derived values. "
        "Key semantics: higher complexity_score means SIMPLER "
        "(counterintuitive). Complexity gate at 0.5 is a HARD "
        "floor that cannot be overridden."
    ),
)

# ---------------------------------------------------------------------------
# Lazy singletons — created on first tool call
# ---------------------------------------------------------------------------

_STATE: dict[str, Any] = {}
_STATE_LOCK = threading.RLock()  # Reentrant: _get_audit() calls _get_config()

# Symmetric PERT spread: ±20% of the scalar value.
# Must match Lambda _make_pert and CLI _compute_utility spread.
_PERT_SPREAD_FACTOR = 0.2

# Minimal positive profit offset when caller omits profit fields.
# Prevents the utility gate from spuriously blocking proposals that
# pass all other gates (kappa only applies on risk reduction, so
# zero profit delta → utility exactly 0.0 → fails strict > 0.0).
_PROFIT_DELTA_EPSILON = 0.001


def _get_config() -> Any:
    """Return (and cache) the AegisConfig singleton."""
    with _STATE_LOCK:
        if "config" not in _STATE:
            from config import AegisConfig

            _STATE["config"] = AegisConfig.default()
    return _STATE["config"]


def _get_audit() -> Any:
    """Return (and cache) the AuditMiddleware singleton."""
    with _STATE_LOCK:
        if "audit" not in _STATE:
            from aegis_governance.middleware import AuditMiddleware, RateLimiter

            cfg = _get_config()
            limiter = None
            if cfg.mcp_rate_limit > 0:
                limiter = RateLimiter(
                    capacity=cfg.mcp_rate_limit,
                    rate=cfg.mcp_rate_limit / 60.0,
                )
            customer_id = os.environ.get("AEGIS_CUSTOMER_ID")
            _STATE["audit"] = AuditMiddleware(
                source="aegis-mcp-server",
                customer_id=customer_id or None,
                rate_limiter=limiter,
            )
    return _STATE["audit"]


# ---------------------------------------------------------------------------
# Utility synthesis (bridges flat MCP params → UtilityCalculator)
# ---------------------------------------------------------------------------


def _synthesize_utility(context: Any) -> Any:
    """Synthesize a UtilityResult from flat MCP parameters.

    MCP callers provide scalar profit/risk/complexity values rather than
    the full ThreePointEstimate + ComplexityBreakdown required by the
    UtilityCalculator.  This method bridges the gap by constructing
    symmetric PERT estimates from the flat inputs.
    """
    from engine.utility import (
        ComplexityBreakdown,
        ThreePointEstimate,
    )

    def _pert(value: float) -> ThreePointEstimate:
        spread = abs(value) * _PERT_SPREAD_FACTOR
        return ThreePointEstimate(
            best=value - spread,
            likely=value,
            worst=value + spread,
        )

    profit_delta = context.profit_proposed - context.profit_baseline

    if abs(profit_delta) < _PROFIT_DELTA_EPSILON:
        profit_delta = _PROFIT_DELTA_EPSILON

    try:
        cfg = _get_config()
        calc = cfg.create_utility_calculator()
        # Zero risk: risk gate evaluates independently; kappa*delta_R
        # at normalized [0,1] scale distorts utility.  Matches Lambda.
        return calc.calculate(
            profit_estimate=_pert(profit_delta),
            risk_estimate=_pert(0.0),
            complexity=ComplexityBreakdown(static=0.0, dynamic=0.0),
        )
    except Exception:
        logger.debug("Utility synthesis failed", exc_info=True)
        return None


# ---------------------------------------------------------------------------
# Result formatting
# ---------------------------------------------------------------------------


def _safe_round(value: float | None, ndigits: int = 6) -> float | None:
    """Round a float, replacing non-finite/None values with None for JSON safety."""
    if value is None or not math.isfinite(value):
        return None
    return round(value, ndigits)


def _build_result(decision: Any) -> dict[str, Any]:
    """Build JSON-serializable result dict from PCWDecision."""
    result: dict[str, Any] = {
        "status": decision.status.value,
        "confidence": _safe_round(decision.confidence),
        "gates_passed": decision.gates_passed,
        "gates_failed": decision.gates_failed,
        "failing_gates": decision.failing_gates,
        "rationale": decision.rationale,
        "next_steps": decision.next_steps,
        "constraints": decision.constraints,
        "decision_id": decision.decision_id,
        "timestamp": decision.timestamp.isoformat(),
        "override_eligible": decision.override_eligible,
        "override_requires": decision.override_requires,
    }

    if decision.gate_evaluation:
        result["gates"] = {}
        for gate_type, gate_result in decision.gate_evaluation.gates.items():
            result["gates"][gate_type.value] = {
                "passed": gate_result.passed,
                "value": _safe_round(gate_result.value),
                "threshold": _safe_round(gate_result.threshold),
                "confidence": (
                    _safe_round(gate_result.confidence)
                    if gate_result.confidence is not None
                    else None
                ),
                "message": gate_result.message,
            }

    if decision.drift_result is not None:
        dr = decision.drift_result
        result["drift"] = {
            "status": dr.status.value,
            "kl_divergence": _safe_round(dr.kl_divergence),
            "action": dr.action.value,
            "message": dr.message,
        }

    if decision.shadow_result is not None:
        shadow_dict: dict[str, Any] = {
            "shadow_only": decision.shadow_result.shadow_only,
            "observation_values": [
                _safe_round(v) for v in decision.shadow_result.observation_values
            ],
            "baseline_hash": decision.shadow_result.baseline_hash,
        }
        if decision.shadow_result.drift_result is not None:
            sdr = decision.shadow_result.drift_result
            shadow_dict["drift"] = {
                "status": sdr.status.value,
                "kl_divergence": _safe_round(sdr.kl_divergence),
                "action": sdr.action.value,
                "message": sdr.message,
            }
        result["shadow_result"] = shadow_dict

    return result


# ---------------------------------------------------------------------------
# MCP Tool definitions
# ---------------------------------------------------------------------------


@mcp.tool()
def aegis_evaluate_proposal(
    proposal_summary: str,
    estimated_impact: str = "medium",
    risk_score: float | None = None,
    risk_baseline: float | None = None,
    risk_proposed: float | None = None,
    profit_baseline: float | None = None,
    profit_proposed: float | None = None,
    novelty_score: float | None = None,
    complexity_score: float | None = None,
    quality_score: float | None = None,
    quality_subscores: list[float] | None = None,
    agent_id: str | None = None,
    phase: str | None = None,
    shadow_mode: bool | None = None,
    telemetry_url: str | None = None,
    drift_baseline_data: list[float] | None = None,
    requires_human_approval: bool | None = None,
    time_sensitive: bool | None = None,
    reversible: bool | None = None,
    metadata: dict[str, Any] | None = None,
    session_id: str | None = None,
) -> str:
    """Evaluate a proposal through AEGIS governance gates (Risk, Profit, Novelty, Complexity, Quality, Utility). Returns PROCEED/PAUSE/ESCALATE/HALT with per-gate details and rationale.

    Args:
        proposal_summary: Brief description of the proposed action
        estimated_impact: Blast radius - low/medium/high/critical
        risk_score: Alias for risk_proposed (0.0-1.0)
        risk_baseline: Current risk level before the change (0.0-1.0, default 0.0)
        risk_proposed: Predicted risk level after the change (0.0-1.0, default 0.0)
        profit_baseline: Current profit/performance metric (default 0.0)
        profit_proposed: Expected profit/performance after change (default 0.0)
        novelty_score: How unprecedented (0.0=routine, 1.0=novel, default 0.5). Gate passes when >= ~0.84
        complexity_score: HIGHER = SIMPLER (0.0=complex, 1.0=trivial, default 0.5). Hard floor at 0.5
        quality_score: Overall quality (0.0-1.0, default 0.7). Must be >= 0.7
        quality_subscores: Individual quality subscores - none may be zero
        agent_id: Calling agent identifier for audit trail
        phase: Lifecycle phase - plan/work/commit (default plan)
        shadow_mode: Advisory only, no enforcement
        telemetry_url: HTTPS URL for telemetry events
        drift_baseline_data: 30+ historical observations for KL divergence
        requires_human_approval: Whether human approval needed (default false)
        time_sensitive: Whether time-sensitive (default false)
        reversible: Whether reversible (default true)
        metadata: Additional key-value metadata
        session_id: Session ID for correlation
    """
    from aegis_governance.middleware import build_pcw_context, validate_drift_baseline

    # Build args dict, only including non-None values
    args: dict[str, Any] = {
        "proposal_summary": proposal_summary,
        "estimated_impact": estimated_impact,
    }
    for key, val in [
        ("risk_score", risk_score),
        ("risk_baseline", risk_baseline),
        ("risk_proposed", risk_proposed),
        ("profit_baseline", profit_baseline),
        ("profit_proposed", profit_proposed),
        ("novelty_score", novelty_score),
        ("complexity_score", complexity_score),
        ("quality_score", quality_score),
        ("quality_subscores", quality_subscores),
        ("agent_id", agent_id),
        ("phase", phase),
        ("shadow_mode", shadow_mode),
        ("telemetry_url", telemetry_url),
        ("drift_baseline_data", drift_baseline_data),
        ("requires_human_approval", requires_human_approval),
        ("time_sensitive", time_sensitive),
        ("reversible", reversible),
        ("metadata", metadata),
        ("session_id", session_id),
    ]:
        if val is not None:
            args[key] = val

    try:
        context = build_pcw_context(args)
        drift_data = validate_drift_baseline(args)
    except (TypeError, ValueError) as exc:
        return json.dumps({"error": str(exc)}, indent=2)

    # Synthesize utility from flat MCP parameters
    if context.utility_result is None:
        context.utility_result = _synthesize_utility(context)

    # Validate telemetry URL if provided (emitter is created but not yet
    # wired into AuditMiddleware — AuditMiddleware uses its own internal
    # emitter configured at construction time).
    _wire_telemetry(args)

    # Wire drift monitor if baseline data provided
    drift_monitor = None
    if drift_data is not None:
        cfg = _get_config()
        drift_monitor = cfg.create_drift_monitor()
        drift_monitor.set_baseline(drift_data)

    _sm = args.get("shadow_mode")
    is_shadow = bool(_sm) if isinstance(_sm, bool) else False

    audit = _get_audit()
    cfg = _get_config()
    evaluator = cfg.create_gate_evaluator()

    try:
        decision = audit.decide(
            context,
            gate_evaluator=evaluator,
            shadow_mode=is_shadow,
            drift_monitor=drift_monitor,
        )
    except RuntimeError as exc:
        return json.dumps({"error": str(exc)}, indent=2)

    return json.dumps(_build_result(decision), indent=2)


@mcp.tool()
def aegis_quick_risk_check(
    action_description: str,
    risk_score: float,
    threshold: float = 0.5,
    agent_id: str | None = None,
) -> str:
    """Quick risk threshold check (risk_score < threshold). Simplified check without Bayesian evaluation. For governance decisions, use aegis_evaluate_proposal instead.

    Args:
        action_description: Brief description of the action to risk-check
        risk_score: Estimated risk score (0.0-1.0)
        threshold: Risk threshold (0.0-1.0, default 0.5)
        agent_id: Calling agent identifier
    """
    from integration.pcw_decide import quick_risk_check

    aid = agent_id if isinstance(agent_id, str) and agent_id else "mcp-agent"
    safe = quick_risk_check(
        agent_id=aid,
        action_description=action_description,
        risk_score=risk_score,
        threshold=threshold,
    )

    return json.dumps(
        {
            "safe": safe,
            "risk_score": risk_score,
            "threshold": threshold,
            "rationale": (
                f"Risk score {risk_score} is "
                f"{'below' if safe else 'at or above'} "
                f"threshold {threshold}"
            ),
        },
        indent=2,
    )


@mcp.tool()
def aegis_check_thresholds() -> str:
    """Introspect all 6 gate thresholds and current configuration. Call this before submitting proposals to understand gate behavior."""
    cfg = _get_config()
    result = {
        "gates": [
            {
                "name": "risk",
                "type": "bayesian_posterior",
                "threshold": cfg.trigger_confidence_prob,
                "trigger_factor": cfg.risk_trigger_factor,
                "description": "Risk increase detection via Bayesian posterior P(delta >= 2 | data) > 0.95",
            },
            {
                "name": "profit",
                "type": "bayesian_posterior",
                "threshold": cfg.trigger_confidence_prob,
                "trigger_factor": cfg.profit_trigger_factor,
                "description": "Profit change detection via Bayesian posterior",
            },
            {
                "name": "novelty",
                "type": "logistic",
                "threshold": cfg.novelty_threshold,
                "parameters": {
                    "N0": cfg.novelty_N0,
                    "k": cfg.novelty_k,
                },
                "description": "Novelty gate G(N) using logistic function",
            },
            {
                "name": "complexity",
                "type": "floor",
                "threshold": cfg.complexity_floor,
                "description": "Complexity floor (hard requirement, cannot be overridden)",
            },
            {
                "name": "quality",
                "type": "minimum",
                "threshold": cfg.quality_min_score,
                "no_zero_subscore": cfg.quality_no_zero_subscore,
                "description": "Quality minimum score with no-zero-subscore rule",
            },
            {
                "name": "utility",
                "type": "lower_confidence_bound",
                "threshold": cfg.utility_threshold,
                "lcb_alpha": cfg.lcb_alpha,
                "description": "Utility LCB gate: lower confidence bound must exceed threshold",
            },
        ],
        "config": cfg.to_dict(),
    }
    return json.dumps(result, indent=2)


@mcp.tool()
def aegis_get_scoring_guide(domain: str | None = None) -> str:
    """Get parameter derivation guidance for a specific domain. Returns formulas, examples, range guides, common mistakes, and a worked example.

    Args:
        domain: Domain for tailored guidance - trading/cicd/moderation/agents/generic. Omit for generic.
    """
    from aegis_governance.scoring_guide import get_scoring_guide

    guide = get_scoring_guide(domain)
    return json.dumps(guide, indent=2)


@mcp.tool()
def aegis_crypto_status() -> str:
    """Check availability of AEGIS cryptographic providers (signatures, encryption, key management, schema signing)."""
    from crypto import (
        BIP322_AVAILABLE,
        ED25519_AVAILABLE,
        HSM_KEK_AVAILABLE,
        HYBRID_AVAILABLE,
        HYBRID_KEM_AVAILABLE,
        KMS_KEK_AVAILABLE,
        MLDSA_AVAILABLE,
        MLKEM_AVAILABLE,
        SCHEMA_SIGNER_AVAILABLE,
    )

    # Determine default signature provider
    if BIP322_AVAILABLE:
        default_provider = "bip322-simple"
    elif ED25519_AVAILABLE:
        default_provider = "ed25519"
    else:
        default_provider = "none"

    # Determine KEK provider (check in priority order)
    if KMS_KEK_AVAILABLE:
        kek_provider = "kms"
    elif HSM_KEK_AVAILABLE:
        kek_provider = "hsm"
    else:
        kek_provider = "environment"

    result = {
        "signatures": {
            "hybrid": HYBRID_AVAILABLE,
            "bip322": BIP322_AVAILABLE,
            "ed25519": ED25519_AVAILABLE,
        },
        "encryption": {
            "hybrid_kem": HYBRID_KEM_AVAILABLE,
        },
        "post_quantum": {
            "ml_dsa": MLDSA_AVAILABLE,
            "ml_kem": MLKEM_AVAILABLE,
        },
        "key_management": {
            "aws_kms": KMS_KEK_AVAILABLE,
            "hsm_pkcs11": HSM_KEK_AVAILABLE,
        },
        "schema_signing": {
            "available": SCHEMA_SIGNER_AVAILABLE,
        },
        "default_provider": default_provider,
        "kek_provider": kek_provider,
        "documentation_url": (
            "https://aegis.undercurrentholdings.com/integration/crypto-overview/"
        ),
    }
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Telemetry wiring
# ---------------------------------------------------------------------------


def _wire_telemetry(arguments: dict[str, Any]) -> Any:
    """Create a TelemetryEmitter from arguments if a valid URL is provided."""
    from telemetry.url_validation import validate_telemetry_url

    telemetry_url = arguments.get("telemetry_url")
    if not (isinstance(telemetry_url, str) and telemetry_url):
        return None
    if not validate_telemetry_url(telemetry_url):
        logger.warning("Rejected telemetry_url: %s", telemetry_url)
        return None
    try:
        from telemetry.emitter import HTTPEventSink, TelemetryEmitter

        emitter = TelemetryEmitter(source="aegis-mcp")
        emitter.add_sink(HTTPEventSink(url=telemetry_url))
        return emitter
    except ValueError as exc:
        logger.warning("Telemetry sink rejected: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> int:
    """MCP server entry point (stdio transport)."""
    mcp.run(transport="stdio")
    return 0


if __name__ == "__main__":
    sys.exit(main())
