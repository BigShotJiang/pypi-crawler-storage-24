"""AEGIS Governance Middleware — shared validation, audit, and rate limiting.

Extracted from ``mcp_server.py`` so that **every** entry point (MCP, Lambda,
CLI, direct Python import) gets the same input-validation and audit-trail
guarantees.  The MCP server and Lambda handler become thin protocol adapters
over this middleware layer.

Usage (direct Python import)::

    from aegis_governance.middleware import (
        validate_float,
        validate_quality_subscores,
        validate_drift_baseline,
        build_pcw_context,
        AuditMiddleware,
    )

    # Input validation
    risk = validate_float(args, "risk_proposed", default=0.0)

    # Build validated PCWContext from a raw dict
    ctx = build_pcw_context(raw_args)

    # Audited pcw_decide wrapper
    audit = AuditMiddleware(source="my-app")
    decision = audit.decide(ctx, gate_evaluator=evaluator)

Design principles:

- **Zero required dependencies**: Works with stdlib only; telemetry, rate
  limiting, and Prometheus are opt-in.
- **Fail-closed**: Invalid inputs raise immediately; ambiguous values
  (NaN, Inf, bool-as-number) are never silently accepted.
- **Idempotent**: All functions are pure or produce side-effects only via
  explicitly injected emitters.
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from engine.drift import DriftMonitor
    from engine.gates import GateEvaluator
    from integration.pcw_decide import PCWContext, PCWDecision
    from rbac import RBACEnforcer
    from telemetry.emitter import TelemetryEmitter
    from telemetry.prometheus_exporter import PrometheusExporter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Input validation helpers
# ---------------------------------------------------------------------------


def validate_float(
    args: dict[str, Any],
    key: str,
    default: float,
) -> float:
    """Extract a float argument with NaN/Inf rejection and bool guarding.

    Unlike ``float(args.get(key) or default)``, this preserves legitimate
    falsy values such as ``0`` and ``0.0``.

    Args:
        args: Raw input dict.
        key: Argument name.
        default: Returned when value is ``None`` or absent.

    Returns:
        Validated float.

    Raises:
        TypeError: If value is a bool.
        ValueError: If value is NaN or Inf.
    """
    v = args.get(key)
    if v is None:
        return default
    if isinstance(v, bool):
        raise TypeError(f"Argument '{key}' must be numeric, got bool")
    result = float(v)
    if not math.isfinite(result):
        raise ValueError(f"Argument '{key}' must be finite, got {result}")
    return result


def validate_bool(
    args: dict[str, Any],
    key: str,
    default: bool,
) -> bool:
    """Extract a bool argument, rejecting non-bool truthy/falsy values.

    Args:
        args: Raw input dict.
        key: Argument name.
        default: Returned when value is ``None`` or absent.

    Returns:
        Validated bool.

    Raises:
        TypeError: If value is present but not a bool.
    """
    val = args.get(key)
    if val is None:
        return default
    if not isinstance(val, bool):
        raise TypeError(f"'{key}' must be a boolean (got {type(val).__name__})")
    return val


def validate_quality_subscores(
    args: dict[str, Any],
) -> list[float]:
    """Extract and validate ``quality_subscores`` from raw arguments.

    Returns:
        Validated list of floats (defaults to ``[0.7, 0.7, 0.7]``).

    Raises:
        TypeError: If any subscore is a bool.
        ValueError: If any subscore is NaN/Inf or non-numeric.
    """
    raw = args.get("quality_subscores")
    if not isinstance(raw, list):
        return [0.7, 0.7, 0.7]

    validated: list[float] = []
    saw_non_null = False
    for s in raw:
        if s is not None:
            saw_non_null = True
            if isinstance(s, bool):
                raise TypeError("quality subscore must be numeric, got bool")
            try:
                fv = float(s)
            except (ValueError, TypeError):
                raise ValueError(
                    f"quality subscore must be numeric, got {s!r}"
                ) from None
            if not math.isfinite(fv):
                raise ValueError(f"quality subscore must be finite, got {fv}")
            validated.append(fv)

    if validated:
        return validated
    # All-null list → default; explicit empty list → empty (fail-safe)
    if raw and not saw_non_null:
        return [0.7, 0.7, 0.7]
    return []


def validate_drift_baseline(
    args: dict[str, Any],
) -> list[float] | None:
    """Extract and validate ``drift_baseline_data`` from raw arguments.

    Returns:
        Validated list of floats, or ``None`` if absent/empty.

    Raises:
        TypeError: If any element is a bool.
        ValueError: If any element is NaN/Inf or non-numeric.
    """
    raw = args.get("drift_baseline_data")
    if not (isinstance(raw, list) and raw):
        return None

    filtered: list[float] = []
    for v in raw:
        if v is not None:
            if isinstance(v, bool):
                raise TypeError("drift_baseline_data element must be numeric, got bool")
            fv = float(v)
            if not math.isfinite(fv):
                raise ValueError(
                    f"drift_baseline_data element must be finite, got {fv}"
                )
            filtered.append(fv)

    return filtered if filtered else None


def validate_str(
    args: dict[str, Any],
    key: str,
    default: str,
) -> str:
    """Extract a string argument, returning *default* for missing/non-string values."""
    val = args.get(key)
    if isinstance(val, str) and val:
        return val
    return default


# ---------------------------------------------------------------------------
# PCWContext builder (shared across MCP / Lambda / CLI / SDK)
# ---------------------------------------------------------------------------

# Phase string → PCWPhase mapping (populated lazily to avoid import-time
# dependency on integration.pcw_decide which may not be on sys.path yet).
_PHASE_MAP_CACHE: dict[str, Any] = {}


def _get_phase_map() -> dict[str, Any]:
    """Return (and cache) the phase-string → PCWPhase mapping."""
    if not _PHASE_MAP_CACHE:
        from integration.pcw_decide import PCWPhase

        _PHASE_MAP_CACHE.update(
            {
                "plan": PCWPhase.PLAN,
                "work": PCWPhase.WORK,
                "commit": PCWPhase.COMMIT,
            }
        )
    return _PHASE_MAP_CACHE


def build_pcw_context(args: dict[str, Any]) -> PCWContext:
    """Build a validated :class:`PCWContext` from a raw input dict.

    This is the single canonical factory used by every entry point.
    All input validation (type checks, NaN/Inf rejection, bool guards)
    happens here so callers don't need to duplicate it.

    Args:
        args: Raw input dict (e.g. MCP arguments, Lambda body, CLI args).

    Returns:
        Fully validated ``PCWContext``.

    Raises:
        TypeError: On type-invalid inputs (bool where float expected, etc.).
        ValueError: On value-invalid inputs (NaN, Inf, etc.).
    """
    from integration.pcw_decide import PCWContext

    phase_map = _get_phase_map()

    # Phase
    phase_raw = args.get("phase")
    _default_phase = next(iter(phase_map.values()))
    phase = (
        phase_map.get(phase_raw.lower(), _default_phase)
        if isinstance(phase_raw, str)
        else _default_phase
    )

    # Agent / session
    agent_id = validate_str(args, "agent_id", "sdk-caller")
    session_id = validate_str(args, "session_id", str(uuid.uuid4()))

    # Proposal text
    proposal_summary = str(args.get("proposal_summary") or "")
    estimated_impact = str(args.get("estimated_impact") or "medium")

    # Numeric fields with risk_score → risk_proposed alias
    risk_proposed = (
        validate_float(args, "risk_proposed", 0.0)
        if args.get("risk_proposed") is not None
        else validate_float(args, "risk_score", 0.0)
    )

    quality_subscores = validate_quality_subscores(args)

    # Metadata
    metadata = args.get("metadata", {})
    if metadata is None:
        metadata = {}
    if not isinstance(metadata, dict):
        raise TypeError(
            f"metadata must be a JSON object (got {type(metadata).__name__})"
        )

    return PCWContext(
        agent_id=agent_id,
        session_id=session_id,
        phase=phase,
        proposal_summary=proposal_summary,
        estimated_impact=estimated_impact,
        risk_baseline=validate_float(args, "risk_baseline", 0.0),
        risk_proposed=risk_proposed,
        profit_baseline=validate_float(args, "profit_baseline", 0.0),
        profit_proposed=validate_float(args, "profit_proposed", 0.0),
        novelty_score=validate_float(args, "novelty_score", 0.5),
        complexity_score=validate_float(args, "complexity_score", 0.5),
        quality_score=validate_float(args, "quality_score", 0.7),
        quality_subscores=quality_subscores,
        requires_human_approval=validate_bool(args, "requires_human_approval", False),
        time_sensitive=validate_bool(args, "time_sensitive", False),
        reversible=validate_bool(args, "reversible", True),
        metadata=metadata,
    )


# ---------------------------------------------------------------------------
# Rate limiter (extracted from _MCPRateLimiter)
# ---------------------------------------------------------------------------


class RateLimiter:
    """Token-bucket rate limiter.

    Thread-safe.  Tokens refill at *rate* tokens/second up to *capacity*.

    Args:
        capacity: Maximum burst size.
        rate: Sustained refill rate (tokens/second).
    """

    def __init__(self, capacity: int, rate: float) -> None:
        self._capacity = capacity
        self._tokens = float(capacity)
        self._rate = rate
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    def allow(self) -> bool:
        """Consume one token.  Returns ``True`` if the request is allowed."""
        with self._lock:
            now = time.monotonic()
            elapsed = now - self._last_refill
            self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)
            self._last_refill = now
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return True
            return False


# ---------------------------------------------------------------------------
# Audit event data
# ---------------------------------------------------------------------------


@dataclass
class AuditEvent:
    """Lightweight record of a governance decision for audit trail.

    Produced by :class:`AuditMiddleware` for every ``pcw_decide()`` call.
    Can be serialized to JSON, sent to telemetry sinks, or logged.
    """

    decision_id: str
    timestamp_utc: str
    source: str
    agent_id: str
    status: str
    gates_passed: int
    gates_failed: int
    failing_gates: list[str]
    params_hash: str
    latency_ms: float
    shadow_mode: bool
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict."""
        return {
            "decision_id": self.decision_id,
            "timestamp_utc": self.timestamp_utc,
            "source": self.source,
            "agent_id": self.agent_id,
            "status": self.status,
            "gates_passed": self.gates_passed,
            "gates_failed": self.gates_failed,
            "failing_gates": self.failing_gates,
            "params_hash": self.params_hash,
            "latency_ms": round(self.latency_ms, 2),
            "shadow_mode": self.shadow_mode,
            "metadata": self.metadata,
        }


# ---------------------------------------------------------------------------
# AuditMiddleware — wraps pcw_decide() with automatic audit emission
# ---------------------------------------------------------------------------


class AuditMiddleware:
    """Wraps ``pcw_decide()`` with automatic input validation and audit logging.

    Every call to :meth:`decide` produces an :class:`AuditEvent` that is:

    1. Sent to all configured telemetry sinks (if any).
    2. Logged at INFO level.
    3. Returned as ``decision._audit_event`` for programmatic access.

    This ensures that **every** path through AEGIS — MCP, Lambda, CLI, and
    direct Python import — produces the same audit guarantees.

    Args:
        source: Identifier for the calling system (e.g. ``"agoraiv-bridge"``,
            ``"aegis-mcp-server"``, ``"aegis-lambda"``).
        telemetry_emitter: Optional emitter for structured telemetry events.
        rate_limiter: Optional rate limiter; raises ``RuntimeError`` when
            exceeded.
        prometheus_exporter: Optional Prometheus exporter for metrics.

    Example::

        from aegis_governance.middleware import AuditMiddleware

        audit = AuditMiddleware(source="my-service")
        decision = audit.decide(context, gate_evaluator=evaluator)
        print(decision.decision_id)  # audit trail included automatically
    """

    def __init__(
        self,
        source: str = "aegis-sdk",
        *,
        customer_id: str | None = None,
        telemetry_emitter: TelemetryEmitter | None = None,
        rate_limiter: RateLimiter | None = None,
        prometheus_exporter: PrometheusExporter | None = None,
    ) -> None:
        self.source = source
        self.customer_id = customer_id
        self._telemetry_emitter = telemetry_emitter
        self._rate_limiter = rate_limiter
        self._prometheus_exporter = prometheus_exporter

    def decide(
        self,
        context: PCWContext,
        *,
        gate_evaluator: GateEvaluator | None = None,
        rbac_enforcer: RBACEnforcer | None = None,
        shadow_mode: bool = False,
        drift_monitor: DriftMonitor | None = None,
    ) -> PCWDecision:
        """Evaluate a proposal with full audit trail.

        Delegates to ``pcw_decide()`` and wraps the call with:
        - Rate limiting (if configured)
        - Timing measurement
        - Audit event emission
        - Telemetry emission
        - Prometheus metrics recording

        Args:
            context: Validated PCWContext.
            gate_evaluator: Optional gate evaluator (uses default if absent).
            rbac_enforcer: Optional RBAC enforcer.
            shadow_mode: Shadow mode flag.
            drift_monitor: Optional drift monitor.

        Returns:
            PCWDecision with audit metadata attached.

        Raises:
            RuntimeError: If rate limit is exceeded.
        """
        from integration.pcw_decide import pcw_decide

        # Rate limit
        if self._rate_limiter is not None and not self._rate_limiter.allow():
            raise RuntimeError("Rate limit exceeded")

        # Hash context for audit trail
        params_hash = _hash_context(context)

        # Execute with timing
        t0 = time.monotonic()
        decision = pcw_decide(
            context,
            gate_evaluator=gate_evaluator,
            prometheus_exporter=self._prometheus_exporter,
            rbac_enforcer=rbac_enforcer,
            shadow_mode=shadow_mode,
            drift_monitor=drift_monitor,
            telemetry_emitter=self._telemetry_emitter,
        )
        latency_ms = (time.monotonic() - t0) * 1000

        # Build audit event
        audit_metadata: dict[str, Any] = {}
        if self.customer_id:
            audit_metadata["customer_id"] = self.customer_id
        audit_event = AuditEvent(
            decision_id=decision.decision_id,
            timestamp_utc=decision.timestamp.isoformat(),
            source=self.source,
            agent_id=context.agent_id,
            status=decision.status.value,
            gates_passed=decision.gates_passed,
            gates_failed=decision.gates_failed,
            failing_gates=decision.failing_gates,
            params_hash=params_hash,
            latency_ms=latency_ms,
            shadow_mode=shadow_mode,
            metadata=audit_metadata,
        )

        # Emit audit via telemetry (best-effort, never raises)
        self._emit_audit(audit_event)

        # Log audit event
        logger.info(
            "AEGIS_AUDIT source=%s decision_id=%s status=%s "
            "gates=%d/%d latency=%.1fms agent=%s",
            self.source,
            audit_event.decision_id,
            audit_event.status,
            audit_event.gates_passed,
            audit_event.gates_passed + audit_event.gates_failed,
            audit_event.latency_ms,
            audit_event.agent_id,
        )

        return decision

    def _emit_audit(self, audit_event: AuditEvent) -> None:
        """Emit audit event to telemetry (best-effort, never raises)."""
        if self._telemetry_emitter is None:
            return
        try:
            from telemetry.emitter import EventType

            self._telemetry_emitter.emit(
                EventType.PROPOSAL_EVALUATED,
                payload=audit_event.to_dict(),
                correlation_id=audit_event.decision_id,
            )
        except Exception:  # Intentional: audit must never crash the caller
            logger.debug("Audit telemetry emission failed", exc_info=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _hash_context(context: PCWContext) -> str:
    """Produce a truncated SHA-256 hash of the context's key fields."""
    data = json.dumps(
        {
            "agent_id": context.agent_id,
            "session_id": context.session_id,
            "phase": context.phase.value,
            "proposal_summary": context.proposal_summary,
            "estimated_impact": context.estimated_impact,
            "risk_baseline": context.risk_baseline,
            "risk_proposed": context.risk_proposed,
            "profit_baseline": context.profit_baseline,
            "profit_proposed": context.profit_proposed,
            "novelty_score": context.novelty_score,
            "complexity_score": context.complexity_score,
            "quality_score": context.quality_score,
        },
        sort_keys=True,
        default=str,
    ).encode()
    return hashlib.sha256(data).hexdigest()[:16]


def safe_round(value: float, ndigits: int = 6) -> float | None:
    """Round a float, replacing non-finite values with ``None``.

    Ensures JSON output uses ``null`` instead of non-standard
    ``-Infinity``/``Infinity``/``NaN`` tokens.
    """
    if not math.isfinite(value):
        return None
    return round(value, ndigits)
