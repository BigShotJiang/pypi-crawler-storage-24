"""AEGIS Tier Definitions — single source of truth for pricing tiers.

Frozen tier definitions used by customer management, rate limiting,
quota enforcement, and billing. All tier-related logic across AEGIS
(Lambda, MCP, CLI, SDK, GitHub Action) imports from here.

Tier migration:
    Phase 1 used ``free/pro/enterprise``. Phase 2 renames to
    ``community/professional/enterprise/financial_services`` with
    backward-compatible aliases so existing customer records continue
    to work.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class TierDefinition:
    """Immutable tier specification.

    Attributes:
        name: Canonical tier name (e.g. ``"professional"``).
        display_name: Human-readable label (e.g. ``"Professional"``).
        monthly_evaluations: Included evaluations per month (0 = unlimited).
        rate_per_minute: Max requests per minute.
        max_keys: Maximum API keys per customer.
        overage_per_eval: Overage cost per evaluation (USD), 0.0 if N/A.
        monthly_price_usd: Monthly price in USD (0 = free).
        features: Set of feature flags enabled for this tier.
    """

    name: str
    display_name: str
    monthly_evaluations: int
    rate_per_minute: int
    max_keys: int
    overage_per_eval: float
    monthly_price_usd: int
    features: frozenset[str]

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-safe dict."""
        return {
            "name": self.name,
            "display_name": self.display_name,
            "monthly_evaluations": self.monthly_evaluations,
            "rate_per_minute": self.rate_per_minute,
            "max_keys": self.max_keys,
            "overage_per_eval": self.overage_per_eval,
            "monthly_price_usd": self.monthly_price_usd,
            "features": sorted(self.features),
        }


# ---------------------------------------------------------------------------
# Tier registry (frozen, authoritative)
# ---------------------------------------------------------------------------

_COMMUNITY_FEATURES: frozenset[str] = frozenset(
    {"gates", "cli", "pcw_decide", "basic_telemetry"}
)

_PROFESSIONAL_FEATURES: frozenset[str] = _COMMUNITY_FEATURES | frozenset(
    {"mcp_server", "http_sink", "shadow_mode", "prometheus", "api_access"}
)

_ENTERPRISE_FEATURES: frozenset[str] = _PROFESSIONAL_FEATURES | frozenset(
    {"crypto_overrides", "rbac", "dr", "hsm", "sla", "dedicated_support"}
)

_FINANCIAL_SERVICES_FEATURES: frozenset[str] = _ENTERPRISE_FEATURES | frozenset(
    {"compliance_export", "regulatory_reporting", "pq_crypto", "audit_export"}
)

COMMUNITY = TierDefinition(
    name="community",
    display_name="Community",
    monthly_evaluations=100,
    rate_per_minute=10,
    max_keys=1,
    overage_per_eval=0.0,
    monthly_price_usd=0,
    features=_COMMUNITY_FEATURES,
)

PROFESSIONAL = TierDefinition(
    name="professional",
    display_name="Professional",
    monthly_evaluations=10_000,
    rate_per_minute=100,
    max_keys=5,
    overage_per_eval=0.25,
    monthly_price_usd=3_500,
    features=_PROFESSIONAL_FEATURES,
)

ENTERPRISE = TierDefinition(
    name="enterprise",
    display_name="Enterprise",
    monthly_evaluations=100_000,
    rate_per_minute=1_000,
    max_keys=20,
    overage_per_eval=0.10,
    monthly_price_usd=18_000,
    features=_ENTERPRISE_FEATURES,
)

FINANCIAL_SERVICES = TierDefinition(
    name="financial_services",
    display_name="Financial Services",
    monthly_evaluations=250_000,
    rate_per_minute=2_000,
    max_keys=50,
    overage_per_eval=0.08,
    monthly_price_usd=50_000,
    features=_FINANCIAL_SERVICES_FEATURES,
)

# Canonical name → TierDefinition mapping
TIERS: dict[str, TierDefinition] = {
    "community": COMMUNITY,
    "professional": PROFESSIONAL,
    "enterprise": ENTERPRISE,
    "financial_services": FINANCIAL_SERVICES,
}

# Backward-compatible aliases (Phase 1 → Phase 2 migration)
_TIER_ALIASES: dict[str, str] = {
    "free": "community",
    "pro": "professional",
}

# All valid tier strings (canonical + aliases)
VALID_TIER_NAMES: frozenset[str] = frozenset(TIERS.keys()) | frozenset(
    _TIER_ALIASES.keys()
)


def resolve_tier_name(name: str) -> str:
    """Resolve a tier name to its canonical form.

    Handles backward-compatible aliases (``free`` → ``community``,
    ``pro`` → ``professional``).

    Args:
        name: Tier name (canonical or alias).

    Returns:
        Canonical tier name.

    Raises:
        ValueError: If name is not a valid tier.
    """
    canonical = _TIER_ALIASES.get(name, name)
    if canonical not in TIERS:
        valid = sorted(VALID_TIER_NAMES)
        raise ValueError(f"Invalid tier '{name}', must be one of: {valid}")
    return canonical


def get_tier(name: str) -> TierDefinition:
    """Look up a TierDefinition by name (supports aliases).

    Args:
        name: Tier name (canonical or alias).

    Returns:
        The corresponding TierDefinition.

    Raises:
        ValueError: If name is not a valid tier.
    """
    return TIERS[resolve_tier_name(name)]
