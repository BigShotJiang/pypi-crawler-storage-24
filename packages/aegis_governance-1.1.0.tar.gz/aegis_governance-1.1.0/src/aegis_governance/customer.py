"""AEGIS Customer Management — Phase 1 visibility layer.

Provides customer records and per-evaluation usage metering using
DynamoDB single-table design in the existing ``aegis-governance-state-{stage}``
table.

DynamoDB Item Patterns:
    Customer profile:
        pk = "CUSTOMER#{customer_id}"
        sk = "PROFILE"

    Daily usage:
        pk = "USAGE#{customer_id}#{YYYY-MM}"
        sk = "DAY#{DD}"

    API key → customer mapping:
        pk = "APIKEY#{api_key_id}"
        sk = "MAPPING"

Usage:
    from aegis_governance.customer import CustomerManager

    mgr = CustomerManager(table_name="aegis-governance-state-dev")
    customer = mgr.create_customer(name="Acme Corp", email="admin@acme.com")
    mgr.record_usage(customer.customer_id, channel="api", route="/evaluate")
    usage = mgr.get_usage(customer.customer_id, month="2026-03")
"""

from __future__ import annotations

import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aegis_governance.tiers import VALID_TIER_NAMES, resolve_tier_name

logger = logging.getLogger(__name__)

# Customer ID prefix (follows Stripe convention)
_CUSTOMER_ID_PREFIX = "cust_"


@dataclass
class Customer:
    """An AEGIS customer record."""

    customer_id: str
    name: str
    email: str
    company: str = ""
    tier: str = (
        "community"  # community | professional | enterprise | financial_services (aliases: free, pro)
    )
    status: str = "active"  # active | suspended
    api_key_id: str = ""  # AWS API Gateway API key ID
    created_at: str = ""
    updated_at: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.customer_id:
            raise ValueError("customer_id is required")
        if not self.name:
            raise ValueError("name is required")
        if not self.email:
            raise ValueError("email is required")
        if self.tier not in VALID_TIER_NAMES:
            valid = sorted(VALID_TIER_NAMES)
            raise ValueError(f"tier must be one of {valid}, got {self.tier}")
        # Normalize alias to canonical name
        self.tier = resolve_tier_name(self.tier)
        if self.status not in ("active", "suspended"):
            raise ValueError(f"status must be active|suspended, got {self.status}")
        now = datetime.now(timezone.utc).isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now

    def to_item(self) -> dict[str, Any]:
        """Serialize to DynamoDB item dict."""
        return {
            "pk": f"CUSTOMER#{self.customer_id}",
            "sk": "PROFILE",
            "customer_id": self.customer_id,
            "name": self.name,
            "email": self.email,
            "company": self.company,
            "tier": self.tier,
            "status": self.status,
            "api_key_id": self.api_key_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata,
            "entity_type": "CUSTOMER",
        }

    @classmethod
    def from_item(cls, item: dict[str, Any]) -> Customer:
        """Deserialize from DynamoDB item dict."""
        return cls(
            customer_id=item["customer_id"],
            name=item["name"],
            email=item["email"],
            company=item.get("company", ""),
            tier=item.get("tier", "community"),
            status=item.get("status", "active"),
            api_key_id=item.get("api_key_id", ""),
            created_at=item.get("created_at", ""),
            updated_at=item.get("updated_at", ""),
            metadata=item.get("metadata", {}),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to plain dict (JSON-safe)."""
        return {
            "customer_id": self.customer_id,
            "name": self.name,
            "email": self.email,
            "company": self.company,
            "tier": self.tier,
            "status": self.status,
            "api_key_id": self.api_key_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata,
        }


@dataclass
class UsageRecord:
    """Daily usage counters for a customer."""

    customer_id: str
    month: str  # YYYY-MM
    day: str  # DD
    evaluate_count: int = 0
    risk_check_count: int = 0
    total_calls: int = 0
    channels: dict[str, int] = field(default_factory=dict)  # channel → count

    def to_item(self) -> dict[str, Any]:
        """Serialize to DynamoDB item dict."""
        return {
            "pk": f"USAGE#{self.customer_id}#{self.month}",
            "sk": f"DAY#{self.day}",
            "customer_id": self.customer_id,
            "month": self.month,
            "day": self.day,
            "evaluate_count": self.evaluate_count,
            "risk_check_count": self.risk_check_count,
            "total_calls": self.total_calls,
            "channels": self.channels,
            "entity_type": "USAGE",
        }

    @classmethod
    def from_item(cls, item: dict[str, Any]) -> UsageRecord:
        """Deserialize from DynamoDB item dict."""
        return cls(
            customer_id=item["customer_id"],
            month=item["month"],
            day=item["day"],
            evaluate_count=int(item.get("evaluate_count", 0)),
            risk_check_count=int(item.get("risk_check_count", 0)),
            total_calls=int(item.get("total_calls", 0)),
            channels=item.get("channels", {}),
        )


@dataclass
class UsageSummary:
    """Aggregated usage for a customer over a month."""

    customer_id: str
    month: str
    total_evaluations: int = 0
    total_risk_checks: int = 0
    total_calls: int = 0
    daily_breakdown: list[UsageRecord] = field(default_factory=list)
    channels: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to plain dict."""
        return {
            "customer_id": self.customer_id,
            "month": self.month,
            "total_evaluations": self.total_evaluations,
            "total_risk_checks": self.total_risk_checks,
            "total_calls": self.total_calls,
            "channels": self.channels,
            "daily_breakdown": [
                {
                    "day": r.day,
                    "evaluate_count": r.evaluate_count,
                    "risk_check_count": r.risk_check_count,
                    "total_calls": r.total_calls,
                }
                for r in self.daily_breakdown
            ],
        }


@dataclass
class Subscription:
    """Active subscription record for a customer."""

    customer_id: str
    stripe_subscription_id: str = ""
    stripe_customer_id: str = ""
    tier: str = "community"
    status: str = "active"  # active | past_due | canceled | trialing
    current_period_start: str = ""
    current_period_end: str = ""
    cancel_at_period_end: bool = False

    _VALID_STATUSES = ("active", "past_due", "canceled", "trialing")

    def __post_init__(self) -> None:
        if not self.customer_id:
            raise ValueError("customer_id is required")
        if self.status not in self._VALID_STATUSES:
            raise ValueError(
                f"status must be one of {self._VALID_STATUSES}, got {self.status}"
            )

    def to_item(self) -> dict[str, Any]:
        """Serialize to DynamoDB item dict."""
        return {
            "pk": f"SUBSCRIPTION#{self.customer_id}",
            "sk": "ACTIVE",
            "customer_id": self.customer_id,
            "stripe_subscription_id": self.stripe_subscription_id,
            "stripe_customer_id": self.stripe_customer_id,
            "tier": self.tier,
            "status": self.status,
            "current_period_start": self.current_period_start,
            "current_period_end": self.current_period_end,
            "cancel_at_period_end": self.cancel_at_period_end,
            "entity_type": "SUBSCRIPTION",
        }

    @classmethod
    def from_item(cls, item: dict[str, Any]) -> Subscription:
        """Deserialize from DynamoDB item dict."""
        return cls(
            customer_id=item["customer_id"],
            stripe_subscription_id=item.get("stripe_subscription_id", ""),
            stripe_customer_id=item.get("stripe_customer_id", ""),
            tier=item.get("tier", "community"),
            status=item.get("status", "active"),
            current_period_start=item.get("current_period_start", ""),
            current_period_end=item.get("current_period_end", ""),
            cancel_at_period_end=item.get("cancel_at_period_end", False),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to plain dict (JSON-safe)."""
        return {
            "status": self.status,
            "tier": self.tier,
            "current_period_end": self.current_period_end,
            "cancel_at_period_end": self.cancel_at_period_end,
        }


def generate_customer_id() -> str:
    """Generate a unique customer ID."""
    return f"{_CUSTOMER_ID_PREFIX}{uuid.uuid4().hex[:12]}"


class CustomerManager:
    """Customer and usage management backed by DynamoDB.

    Designed for Lambda warm-start caching — customer lookups are cached
    in-memory for the lifetime of the Lambda instance.

    Args:
        table_name: DynamoDB table name. Defaults to AEGIS_TABLE_NAME env var.
        region: AWS region. Defaults to AWS_DEFAULT_REGION or us-west-2.
        dynamodb_resource: Optional pre-built boto3 DynamoDB resource (for testing).
    """

    def __init__(
        self,
        table_name: str | None = None,
        region: str | None = None,
        dynamodb_resource: Any = None,
    ) -> None:
        self._table_name = table_name or os.environ.get(
            "AEGIS_TABLE_NAME", "aegis-governance-state-dev"
        )
        self._region = region or os.environ.get("AWS_DEFAULT_REGION", "us-west-2")
        self._dynamodb = dynamodb_resource
        self._table: Any = None
        # In-memory cache: api_key_id → Customer (Lambda warm-start optimization)
        self._customer_cache: dict[str, Customer] = {}

    def _get_table(self) -> Any:
        """Lazy-init DynamoDB table resource."""
        if self._table is None:
            if self._dynamodb is None:
                import boto3

                self._dynamodb = boto3.resource("dynamodb", region_name=self._region)
            self._table = self._dynamodb.Table(self._table_name)
        return self._table

    # --- Customer CRUD ---

    def create_customer(
        self,
        name: str,
        email: str,
        company: str = "",
        tier: str = "free",
        api_key_id: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Customer:
        """Create a new customer record in DynamoDB.

        Returns:
            The created Customer object.
        """
        customer = Customer(
            customer_id=generate_customer_id(),
            name=name,
            email=email,
            company=company,
            tier=tier,
            api_key_id=api_key_id,
            metadata=metadata or {},
        )

        table = self._get_table()

        # Write customer profile
        table.put_item(Item=customer.to_item())

        # Write API key mapping if provided
        if api_key_id:
            table.put_item(
                Item={
                    "pk": f"APIKEY#{api_key_id}",
                    "sk": "MAPPING",
                    "customer_id": customer.customer_id,
                    "entity_type": "APIKEY_MAPPING",
                }
            )
            self._customer_cache[api_key_id] = customer

        logger.info("Created customer %s (%s)", customer.customer_id, customer.name)
        return customer

    def get_customer(self, customer_id: str) -> Customer | None:
        """Look up a customer by ID."""
        table = self._get_table()
        resp = table.get_item(Key={"pk": f"CUSTOMER#{customer_id}", "sk": "PROFILE"})
        item = resp.get("Item")
        if not item:
            return None
        return Customer.from_item(item)

    def get_customer_by_api_key(self, api_key_id: str) -> Customer | None:
        """Look up a customer by their API key ID (cached for Lambda warm starts)."""
        # Check cache first
        if api_key_id in self._customer_cache:
            return self._customer_cache[api_key_id]

        table = self._get_table()

        # Look up the mapping
        resp = table.get_item(Key={"pk": f"APIKEY#{api_key_id}", "sk": "MAPPING"})
        item = resp.get("Item")
        if not item:
            return None

        customer_id = item.get("customer_id", "")
        if not customer_id:
            return None

        customer = self.get_customer(customer_id)
        if customer:
            self._customer_cache[api_key_id] = customer
        return customer

    def list_customers(self) -> list[Customer]:
        """List all customers (paginated scan — use sparingly)."""
        table = self._get_table()
        customers: list[Customer] = []
        scan_kwargs: dict[str, Any] = {
            "FilterExpression": "entity_type = :et",
            "ExpressionAttributeValues": {":et": "CUSTOMER"},
        }
        while True:
            resp = table.scan(**scan_kwargs)
            for item in resp.get("Items", []):
                customers.append(Customer.from_item(item))
            last_key = resp.get("LastEvaluatedKey")
            if not last_key:
                break
            scan_kwargs["ExclusiveStartKey"] = last_key
        return sorted(customers, key=lambda c: c.created_at)

    def update_customer(
        self,
        customer_id: str,
        **updates: Any,
    ) -> Customer | None:
        """Update customer fields. Returns updated Customer or None if not found."""
        customer = self.get_customer(customer_id)
        if not customer:
            return None

        allowed_fields = {
            "name",
            "email",
            "company",
            "tier",
            "status",
            "metadata",
            "api_key_id",
        }
        for k, v in updates.items():
            if k in allowed_fields:
                setattr(customer, k, v)

        # Re-validate after mutation (dataclass __post_init__ only runs at construction)
        if not customer.name:
            raise ValueError("name is required")
        if not customer.email:
            raise ValueError("email is required")
        _VALID_STATUSES = ("active", "suspended")
        if customer.tier not in VALID_TIER_NAMES:
            valid = sorted(VALID_TIER_NAMES)
            raise ValueError(f"tier must be one of {valid}, got {customer.tier}")
        customer.tier = resolve_tier_name(customer.tier)
        if customer.status not in _VALID_STATUSES:
            raise ValueError(
                f"status must be {' | '.join(_VALID_STATUSES)}, got {customer.status}"
            )

        customer.updated_at = datetime.now(timezone.utc).isoformat()
        table = self._get_table()
        table.put_item(Item=customer.to_item())

        # Write APIKEY mapping if api_key_id was updated
        if "api_key_id" in updates and customer.api_key_id:
            table.put_item(
                Item={
                    "pk": f"APIKEY#{customer.api_key_id}",
                    "sk": "MAPPING",
                    "customer_id": customer.customer_id,
                    "entity_type": "APIKEY_MAPPING",
                }
            )

        # Update cache
        if customer.api_key_id and customer.api_key_id in self._customer_cache:
            self._customer_cache[customer.api_key_id] = customer

        return customer

    def get_customer_by_email(self, email: str) -> Customer | None:
        """Look up a customer by email using the gsi-email GSI."""
        table = self._get_table()
        resp = table.query(
            IndexName="gsi-email",
            KeyConditionExpression="email = :email",
            ExpressionAttributeValues={":email": email},
            Limit=1,
        )
        items = resp.get("Items", [])
        if not items:
            return None
        return Customer.from_item(items[0])

    # --- Subscription ---

    def get_subscription(self, customer_id: str) -> Subscription | None:
        """Look up active subscription for a customer."""
        table = self._get_table()
        resp = table.get_item(Key={"pk": f"SUBSCRIPTION#{customer_id}", "sk": "ACTIVE"})
        item = resp.get("Item")
        if not item:
            return None
        return Subscription.from_item(item)

    def upsert_subscription(self, subscription: Subscription) -> None:
        """Create or update a subscription record."""
        table = self._get_table()
        table.put_item(Item=subscription.to_item())
        logger.info(
            "Upserted subscription for customer %s (status=%s, tier=%s)",
            subscription.customer_id,
            subscription.status,
            subscription.tier,
        )

    # --- Usage Metering ---

    def record_usage(
        self,
        customer_id: str,
        channel: str = "api",
        route: str = "/evaluate",
    ) -> None:
        """Record a single usage event (async-safe DynamoDB atomic counter).

        Uses DynamoDB UpdateItem with ADD expression for lock-free atomic
        increments. Safe for concurrent Lambda invocations.

        Args:
            customer_id: The customer ID.
            channel: Delivery channel (api, mcp, sdk, cli, github-action).
            route: API route (/evaluate or /risk-check).
        """
        now = datetime.now(timezone.utc)
        month = now.strftime("%Y-%m")
        day = now.strftime("%d")

        table = self._get_table()

        # Determine which counter to increment
        route_counter = "evaluate_count" if route == "/evaluate" else "risk_check_count"

        try:
            # Channel attribute name must be aliased (DynamoDB reserved words)
            channel_attr = "channels.#ch"
            table.update_item(
                Key={
                    "pk": f"USAGE#{customer_id}#{month}",
                    "sk": f"DAY#{day}",
                },
                UpdateExpression=(
                    "SET customer_id = :cid, #m = :month, #d = :day, "
                    "entity_type = :et "
                    f"ADD {route_counter} :one, total_calls :one, "
                    f"{channel_attr} :one"
                ),
                ExpressionAttributeNames={
                    "#m": "month",
                    "#d": "day",
                    "#ch": channel,
                },
                ExpressionAttributeValues={
                    ":cid": customer_id,
                    ":month": month,
                    ":day": day,
                    ":et": "USAGE",
                    ":one": 1,
                },
            )
            logger.debug(
                "Recorded usage: customer=%s channel=%s route=%s",
                customer_id,
                channel,
                route,
            )
        except Exception as e:
            # Usage metering failure should never block evaluation
            logger.warning("Usage metering failed for %s: %s", customer_id, e)

    def get_usage(
        self,
        customer_id: str,
        month: str | None = None,
    ) -> UsageSummary:
        """Get aggregated usage for a customer for a given month.

        Args:
            customer_id: The customer ID.
            month: Month in YYYY-MM format. Defaults to current month.

        Returns:
            UsageSummary with daily breakdown.
        """
        if month is None:
            month = datetime.now(timezone.utc).strftime("%Y-%m")

        table = self._get_table()
        resp = table.query(
            KeyConditionExpression="pk = :pk AND begins_with(sk, :prefix)",
            ExpressionAttributeValues={
                ":pk": f"USAGE#{customer_id}#{month}",
                ":prefix": "DAY#",
            },
        )

        daily: list[UsageRecord] = []
        total_evals = 0
        total_risk = 0
        total_calls = 0
        channels: dict[str, int] = {}

        for item in resp.get("Items", []):
            record = UsageRecord.from_item(item)
            daily.append(record)
            total_evals += record.evaluate_count
            total_risk += record.risk_check_count
            total_calls += record.total_calls
            for ch, count in record.channels.items():
                channels[ch] = channels.get(ch, 0) + int(count)

        return UsageSummary(
            customer_id=customer_id,
            month=month,
            total_evaluations=total_evals,
            total_risk_checks=total_risk,
            total_calls=total_calls,
            daily_breakdown=sorted(daily, key=lambda r: r.day),
            channels=channels,
        )
