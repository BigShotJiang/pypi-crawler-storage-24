"""Domain Mapper — standardized protocol for mapping domain metrics to AEGIS gates.

Defines the :class:`DomainMapper` protocol that external systems implement to
translate domain-specific data (trading signals, CI/CD metrics, content
moderation scores, health claim evidence) into AEGIS gate inputs.

This addresses GAP-8: domain integration templates exist as documentation
(``docs/integration/domain-templates.md``) but lack a code-level contract.
AgoraIV's ``ResearchToAegisMapper`` (350+ lines, hardcoded for health claims)
is a concrete example of what this protocol standardizes.

Usage (structural subtyping --- no inheritance required)::

    from aegis_governance.mapper import DomainMapper, GateInputs

    class TradingMapper:
        @property
        def domain_name(self) -> str:
            return "trading"

        def map_to_gate_inputs(self, domain_data: dict[str, Any]) -> GateInputs:
            return GateInputs(
                risk_baseline=domain_data["current_var"] / domain_data["var_limit"],
                risk_proposed=domain_data["projected_var"] / domain_data["var_limit"],
                profit_baseline=domain_data["current_sharpe"],
                profit_proposed=domain_data["backtest_sharpe"],
                novelty_score=1.0 - domain_data["strategy_similarity"],
                complexity_score=1.0 - domain_data["instrument_count"] / 100,
                quality_score=domain_data["backtest_quality"],
                proposal_summary=domain_data.get("summary", ""),
                estimated_impact=domain_data.get("impact", "medium"),
            )

    # Structural subtyping: isinstance check works without inheritance
    mapper: DomainMapper = TradingMapper()

Design principles:

- **Structural subtyping**: Uses ``typing.Protocol`` so callers never need to
  inherit from AEGIS --- they just implement the method signatures.
- **Minimal surface area**: One method + one property.  This is a contract,
  not a framework.
- **Fail-closed validation**: ``GateInputs.__post_init__`` rejects NaN, Inf,
  and out-of-range values at construction time.
- **Zero required dependencies**: Works with stdlib only; the ``to_pcw_context``
  convenience method uses a lazy import guarded by ``TYPE_CHECKING``.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from integration.pcw_decide import PCWContext, PCWPhase


# ---------------------------------------------------------------------------
# DomainMapper protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class DomainMapper(Protocol):
    """Protocol for mapping domain-specific metrics to AEGIS gate inputs.

    Implementors translate domain data (trading signals, CI/CD metrics,
    content moderation scores, etc.) into the standardized :class:`GateInputs`
    container that AEGIS gate evaluation expects.

    This is a structural protocol --- callers satisfy it by implementing the
    required method and property without inheriting from ``DomainMapper``.

    Example::

        class CICDMapper:
            @property
            def domain_name(self) -> str:
                return "cicd"

            def map_to_gate_inputs(self, domain_data: dict[str, Any]) -> GateInputs:
                return GateInputs(
                    risk_baseline=domain_data["current_error_rate"],
                    risk_proposed=domain_data["estimated_error_rate"],
                    ...
                )

        mapper: DomainMapper = CICDMapper()  # structural match
    """

    @property
    def domain_name(self) -> str:
        """Return the domain identifier (e.g. ``"trading"``, ``"cicd"``)."""
        ...  # pragma: no cover

    def map_to_gate_inputs(self, domain_data: dict[str, Any]) -> GateInputs:
        """Map domain-specific data to AEGIS gate inputs.

        Args:
            domain_data: Domain-specific metrics dict.  The keys and semantics
                are defined by the domain; the mapper is responsible for
                translating them into AEGIS parameters.

        Returns:
            Validated :class:`GateInputs` ready for gate evaluation.

        Raises:
            KeyError: If required domain keys are missing.
            ValueError: If domain values are out of expected ranges.
            TypeError: If domain values have unexpected types.
        """
        ...  # pragma: no cover


# ---------------------------------------------------------------------------
# GateInputs container
# ---------------------------------------------------------------------------

# Fields that must be finite floats (no NaN / Inf)
_FINITE_FLOAT_FIELDS = (
    "risk_baseline",
    "risk_proposed",
    "profit_baseline",
    "profit_proposed",
    "novelty_score",
    "complexity_score",
    "quality_score",
)


@dataclass
class GateInputs:
    """Container for all AEGIS gate input values.

    Provides validated, typed access to the parameters that
    :func:`~integration.pcw_decide.pcw_decide` and
    :class:`~engine.gates.GateEvaluator` expect.

    Validation (in ``__post_init__``):

    - All numeric fields must be finite (no NaN / Inf).
    - ``quality_subscores`` elements must each be finite.
    - ``estimated_impact`` is lowercased and validated against the
      allowed set (``low``, ``medium``, ``high``, ``critical``).

    Attributes:
        risk_baseline: Current risk level (0.0 = no risk).
        risk_proposed: Projected risk after the proposed change.
        profit_baseline: Current performance / profit metric.
        profit_proposed: Projected performance after the proposed change.
        novelty_score: How novel the proposal is (0.0 = routine, 1.0 = unprecedented).
        complexity_score: Inverse complexity (1.0 = simple, 0.0 = maximally complex).
            Must be >= 0.5 to pass the complexity floor gate.
        quality_score: Composite quality score (0.0--1.0).
        quality_subscores: Individual quality dimensions (e.g. test coverage,
            code review, documentation).
        proposal_summary: Human-readable description of the proposed change.
        estimated_impact: Blast radius category.

    Example::

        inputs = GateInputs(
            risk_baseline=0.09,
            risk_proposed=0.156,
            profit_baseline=1.2,
            profit_proposed=1.8,
            novelty_score=0.65,
            complexity_score=0.9,
            quality_score=0.85,
            quality_subscores=[0.85, 0.9, 0.8],
            proposal_summary="Deploy mean-reversion strategy on ES futures",
            estimated_impact="medium",
        )
    """

    risk_baseline: float = 0.0
    risk_proposed: float = 0.0
    profit_baseline: float = 0.0
    profit_proposed: float = 0.0
    novelty_score: float = 0.5
    complexity_score: float = 0.5
    quality_score: float = 0.7
    quality_subscores: list[float] = field(default_factory=lambda: [0.7, 0.7, 0.7])
    proposal_summary: str = ""
    estimated_impact: str = "medium"

    _VALID_IMPACTS: tuple[str, ...] = (
        "low",
        "medium",
        "high",
        "critical",
    )

    def __post_init__(self) -> None:
        """Validate all fields at construction time (fail-closed)."""
        # Validate finite floats
        for name in _FINITE_FLOAT_FIELDS:
            value = getattr(self, name)
            if not isinstance(value, (int, float)):
                raise TypeError(f"{name} must be numeric, got {type(value).__name__}")
            if isinstance(value, bool):
                raise TypeError(f"{name} must be numeric, got bool")
            if not math.isfinite(value):
                raise ValueError(f"{name} must be finite, got {value}")

        # Validate quality_subscores
        if not isinstance(self.quality_subscores, list):
            raise TypeError(
                f"quality_subscores must be a list, got {type(self.quality_subscores).__name__}"
            )
        for i, score in enumerate(self.quality_subscores):
            if isinstance(score, bool):
                raise TypeError(f"quality_subscores[{i}] must be numeric, got bool")
            if not isinstance(score, (int, float)):
                raise TypeError(
                    f"quality_subscores[{i}] must be numeric, got {type(score).__name__}"
                )
            if not math.isfinite(score):
                raise ValueError(f"quality_subscores[{i}] must be finite, got {score}")

        # Validate and normalize estimated_impact
        if not isinstance(self.estimated_impact, str):
            raise TypeError(
                f"estimated_impact must be a string, got {type(self.estimated_impact).__name__}"
            )
        self.estimated_impact = self.estimated_impact.lower()
        if self.estimated_impact not in self._VALID_IMPACTS:
            raise ValueError(
                f"estimated_impact must be one of {self._VALID_IMPACTS}, "
                f"got {self.estimated_impact!r}"
            )

        # Validate proposal_summary
        if not isinstance(self.proposal_summary, str):
            raise TypeError(
                f"proposal_summary must be a string, got {type(self.proposal_summary).__name__}"
            )

    def to_pcw_context(
        self,
        agent_id: str,
        session_id: str,
        phase: PCWPhase | str = "plan",
        *,
        requires_human_approval: bool = False,
        time_sensitive: bool = False,
        reversible: bool = True,
        metadata: dict[str, Any] | None = None,
    ) -> PCWContext:
        """Build a :class:`PCWContext` from these gate inputs.

        Convenience method that avoids callers having to manually copy
        each field into a ``PCWContext`` constructor.

        Args:
            agent_id: Unique identifier for the calling agent.
            session_id: Session or correlation identifier.
            phase: PCW lifecycle phase (``"plan"``, ``"commit"``, or ``"work"``).
                Accepts either a :class:`PCWPhase` enum or a lowercase string.
            requires_human_approval: Explicit human approval requirement.
            time_sensitive: Whether the proposal is time-sensitive.
            reversible: Whether the proposed change can be rolled back.
            metadata: Additional key-value metadata for the decision context.

        Returns:
            Fully populated ``PCWContext`` ready for ``pcw_decide()``.

        Raises:
            ValueError: If *phase* is an unrecognized string.
        """
        from integration.pcw_decide import PCWContext, PCWPhase

        # Resolve phase
        if isinstance(phase, str):
            phase_map = {
                "plan": PCWPhase.PLAN,
                "commit": PCWPhase.COMMIT,
                "work": PCWPhase.WORK,
            }
            resolved_phase = phase_map.get(phase.lower())
            if resolved_phase is None:
                raise ValueError(
                    f"Unknown phase {phase!r}; expected one of {list(phase_map)}"
                )
            phase = resolved_phase

        return PCWContext(
            agent_id=agent_id,
            session_id=session_id,
            phase=phase,
            proposal_summary=self.proposal_summary,
            estimated_impact=self.estimated_impact,
            risk_baseline=self.risk_baseline,
            risk_proposed=self.risk_proposed,
            profit_baseline=self.profit_baseline,
            profit_proposed=self.profit_proposed,
            novelty_score=self.novelty_score,
            complexity_score=self.complexity_score,
            quality_score=self.quality_score,
            quality_subscores=list(self.quality_subscores),
            requires_human_approval=requires_human_approval,
            time_sensitive=time_sensitive,
            reversible=reversible,
            metadata=metadata if metadata is not None else {},
        )


# ---------------------------------------------------------------------------
# PassthroughMapper — reference implementation
# ---------------------------------------------------------------------------


class PassthroughMapper:
    """Reference ``DomainMapper`` that passes raw values through unchanged.

    Expects ``domain_data`` to contain keys matching AEGIS parameter names
    (e.g. ``risk_baseline``, ``risk_proposed``).  Missing keys fall back to
    ``GateInputs`` defaults.

    Useful for:

    - **Testing**: Inject exact gate values without transformation.
    - **Template**: Copy and modify to create domain-specific mappers.
    - **Direct integration**: When the upstream system already emits AEGIS
      parameter names.

    Example::

        mapper = PassthroughMapper()
        inputs = mapper.map_to_gate_inputs({
            "risk_baseline": 0.1,
            "risk_proposed": 0.3,
            "proposal_summary": "Add caching layer",
        })
    """

    @property
    def domain_name(self) -> str:
        """Return ``"passthrough"``."""
        return "passthrough"

    def map_to_gate_inputs(self, domain_data: dict[str, Any]) -> GateInputs:
        """Map raw AEGIS parameter names to :class:`GateInputs`.

        Extracts known AEGIS parameters from *domain_data*, passing them
        directly to the ``GateInputs`` constructor.  Unknown keys are
        silently ignored; missing keys use ``GateInputs`` defaults.

        Args:
            domain_data: Dict with AEGIS parameter names as keys.

        Returns:
            Validated ``GateInputs`` instance.

        Raises:
            TypeError: If a value has an invalid type.
            ValueError: If a value is NaN, Inf, or out of range.
        """
        kwargs: dict[str, Any] = {}

        # Extract numeric fields
        for key in _FINITE_FLOAT_FIELDS:
            if key in domain_data:
                kwargs[key] = domain_data[key]

        # Extract list field
        if "quality_subscores" in domain_data:
            kwargs["quality_subscores"] = list(domain_data["quality_subscores"])

        # Extract string fields
        if "proposal_summary" in domain_data:
            kwargs["proposal_summary"] = domain_data["proposal_summary"]
        if "estimated_impact" in domain_data:
            kwargs["estimated_impact"] = domain_data["estimated_impact"]

        return GateInputs(**kwargs)
