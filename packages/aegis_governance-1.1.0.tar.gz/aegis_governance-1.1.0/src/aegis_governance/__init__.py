"""AEGIS Governance Decision SDK

Autonomous Engineering Governance Integration System — a quantitative
governance toolkit for engineering decision-making.

Usage:
    from aegis_governance import pcw_decide, PCWContext, PCWPhase, AegisConfig

    config = AegisConfig.default()
    evaluator = config.create_gate_evaluator()

    decision = pcw_decide(
        PCWContext(
            agent_id="my-agent",
            session_id="session-1",
            phase=PCWPhase.PLAN,
            proposal_summary="Add caching layer",
            estimated_impact="medium",
            risk_proposed=0.3,
            complexity_score=0.6,
        ),
        gate_evaluator=evaluator,
    )

    if decision.status == PCWStatus.PROCEED:
        print("Safe to proceed")
"""

from __future__ import annotations

import contextlib
import importlib.metadata

# --- Version ---
try:
    __version__ = importlib.metadata.version("aegis-governance")
except importlib.metadata.PackageNotFoundError:
    __version__ = "1.1.0"

# --- Configuration ---
# --- Actors ---
from actors import (
    Actor,
    ActorCapabilities,
    ActorRole,
    Analyst,
    Approver,
    Executor,
    Proposer,
)
from actors.calibrator import Calibrator
from actors.governance import Governance

# --- Mapper (domain integration protocol) ---
from aegis_governance.mapper import DomainMapper, GateInputs, PassthroughMapper

# --- Middleware (shared validation & audit) ---
from aegis_governance.middleware import (
    AuditEvent,
    AuditMiddleware,
    RateLimiter,
    build_pcw_context,
    safe_round,
    validate_bool,
    validate_drift_baseline,
    validate_float,
    validate_quality_subscores,
    validate_str,
)

# --- Tiers ---
from aegis_governance.tiers import (
    TIERS,
    TierDefinition,
    get_tier,
    resolve_tier_name,
)
from config import AegisConfig, KLDriftConfig

# Availability flags (always importable, False when optional dep missing)
from crypto import HYBRID_KEM_AVAILABLE

# --- Key Management (KEK providers, optional) ---
from crypto.kek_provider import KEKMetadata, KEKProvider, get_kek_provider

# --- Engine (core math) ---
from engine import (
    BayesianPosterior,
    ComplexityDecomposer,
    DriftAction,
    DriftMonitor,
    DriftResult,
    DriftStatus,
    GateEvaluationResult,
    GateEvaluator,
    GateResult,
    GateType,
    UtilityCalculator,
    UtilityComponents,
    UtilityResult,
)

# --- Integration (decision interface) ---
from integration import (
    AFABridge,
    DecisionRequest,
    DecisionResponse,
    PCWContext,
    PCWDecision,
    pcw_decide,
)
from integration.pcw_decide import (
    PCWPhase,
    PCWStatus,
    ShadowResult,
    quick_risk_check,
    require_human_approval,
)

# --- Telemetry (HTTP sinks) ---
from telemetry.emitter import BatchHTTPSink, HTTPEventSink, http_sink

# --- Workflows ---
from workflows import (
    ConsensusResult,
    ConsensusWorkflow,
    DualSignatureValidator,
    OverrideWorkflow,
    ProposalState,
    ProposalWorkflow,
    VoteOutcome,
)

try:
    from crypto import KMS_KEK_AVAILABLE
except ImportError:
    KMS_KEK_AVAILABLE = False

try:
    from crypto import HSM_KEK_AVAILABLE
except ImportError:
    HSM_KEK_AVAILABLE = False

with contextlib.suppress(ImportError):
    from crypto.kms_kek_provider import AWSKMSKEKProvider

with contextlib.suppress(ImportError):
    from crypto.hsm_kek_provider import HSMKEKProvider

__all__ = [
    "HSM_KEK_AVAILABLE",
    "HYBRID_KEM_AVAILABLE",
    "KMS_KEK_AVAILABLE",
    "TIERS",
    "AFABridge",
    "AWSKMSKEKProvider",
    "Actor",
    "ActorCapabilities",
    "ActorRole",
    "AegisConfig",
    "Analyst",
    "Approver",
    "AuditEvent",
    "AuditMiddleware",
    "BatchHTTPSink",
    "BayesianPosterior",
    "Calibrator",
    "ComplexityDecomposer",
    "ConsensusResult",
    "ConsensusWorkflow",
    "DecisionRequest",
    "DecisionResponse",
    "DomainMapper",
    "DriftAction",
    "DriftMonitor",
    "DriftResult",
    "DriftStatus",
    "DualSignatureValidator",
    "Executor",
    "GateEvaluationResult",
    "GateEvaluator",
    "GateInputs",
    "GateResult",
    "GateType",
    "Governance",
    "HSMKEKProvider",
    "HTTPEventSink",
    "KEKMetadata",
    "KEKProvider",
    "KLDriftConfig",
    "OverrideWorkflow",
    "PCWContext",
    "PCWDecision",
    "PCWPhase",
    "PCWStatus",
    "PassthroughMapper",
    "ProposalState",
    "ProposalWorkflow",
    "Proposer",
    "RateLimiter",
    "ShadowResult",
    "TierDefinition",
    "UtilityCalculator",
    "UtilityComponents",
    "UtilityResult",
    "VoteOutcome",
    "__version__",
    "build_pcw_context",
    "get_kek_provider",
    "get_tier",
    "http_sink",
    "pcw_decide",
    "quick_risk_check",
    "require_human_approval",
    "resolve_tier_name",
    "safe_round",
    "validate_bool",
    "validate_drift_baseline",
    "validate_float",
    "validate_quality_subscores",
    "validate_str",
]
