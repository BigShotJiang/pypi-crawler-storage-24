"""AEGIS Unkey Client — API key management via Unkey.

Wraps the Unkey v2 REST API for creating, verifying, revoking, and
listing API keys. Used by the Lambda Authorizer (Phase 2b) and
Customer API (Phase 2c) for self-service key management.

Requires the ``[unkey]`` optional dependency group (httpx>=0.27).

Usage:
    from aegis_governance.unkey import UnkeyClient

    client = UnkeyClient(root_key="unkey_xxx")
    result = client.verify_key("uk_live_abc123")
    if result.valid:
        print(f"Customer: {result.owner_id}, Tier: {result.meta.get('tier')}")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

try:
    import httpx

    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

# Unkey API base URL (migrated from api.unkey.dev → api.unkey.com, 2026-03)
_UNKEY_API_BASE = "https://api.unkey.com"


@dataclass
class VerifyResult:
    """Result of an Unkey key verification."""

    valid: bool
    owner_id: str = ""
    meta: dict[str, Any] = field(default_factory=dict)
    remaining: int | None = None
    code: str = ""
    error: str = ""

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> VerifyResult:
        """Parse from Unkey API v2 response (unwrapped ``data`` envelope).

        Handles v2 field layout:
        - ``identity.externalId`` → owner_id (v1 used ``ownerId``)
        - ``ratelimits[0].remaining`` → remaining (v1 used top-level)
        """
        # owner_id: v2 nests under identity.externalId; fall back to v1 ownerId
        identity = data.get("identity") or {}
        owner_id = (
            identity.get("externalId", "") if isinstance(identity, dict) else ""
        ) or data.get("ownerId", "")

        # remaining: v2 nests under ratelimits[]; fall back to v1 top-level
        remaining: int | None = data.get("remaining")
        ratelimits = data.get("ratelimits")
        if remaining is None and isinstance(ratelimits, list) and ratelimits:
            remaining = ratelimits[0].get("remaining")

        return cls(
            valid=data.get("valid", False),
            owner_id=owner_id,
            meta=data.get("meta", {}),
            remaining=remaining,
            code=data.get("code", ""),
            error=(
                data.get("error", {}).get("message", "")
                if isinstance(data.get("error"), dict)
                else ""
            ),
        )


@dataclass
class KeyInfo:
    """Information about an Unkey API key."""

    key_id: str
    api_id: str
    name: str = ""
    owner_id: str = ""
    meta: dict[str, Any] = field(default_factory=dict)
    created_at: int = 0
    expires: int | None = None
    remaining: int | None = None
    enabled: bool = True
    key: str = ""

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> KeyInfo:
        """Parse from Unkey API response."""
        # owner_id: v2 uses identity.externalId; fall back to v1 ownerId
        identity = data.get("identity") or {}
        owner_id = (
            identity.get("externalId", "") if isinstance(identity, dict) else ""
        ) or data.get("ownerId", "")

        return cls(
            key_id=data.get("keyId", data.get("id", "")),
            api_id=data.get("apiId", ""),
            name=data.get("name", ""),
            owner_id=owner_id,
            meta=data.get("meta", {}),
            created_at=data.get("createdAt", 0),
            expires=data.get("expires"),
            remaining=data.get("remaining"),
            enabled=data.get("enabled", True),
            key=data.get("key", ""),
        )


class UnkeyClient:
    """Client for the Unkey API key management service (v2).

    Args:
        root_key: Unkey root API key (``unkey_xxx``).
        api_id: Unkey API namespace ID.
        timeout: HTTP request timeout in seconds.

    Raises:
        RuntimeError: If httpx is not installed.
    """

    def __init__(
        self,
        root_key: str,
        api_id: str = "",
        timeout: float = 10.0,
    ) -> None:
        if not _HAS_HTTPX:
            raise RuntimeError(
                "httpx is required for Unkey integration: "
                "pip install aegis-governance[unkey]"
            )
        if not root_key:
            raise ValueError("Unkey root_key is required")
        self._root_key = root_key
        self._api_id = api_id
        self._timeout = timeout
        self._client = httpx.Client(
            base_url=_UNKEY_API_BASE,
            headers={
                "Authorization": f"Bearer {self._root_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    def verify_key(self, key: str) -> VerifyResult:
        """Verify an API key.

        This is the hot path — called on every API request by the
        Lambda Authorizer. Unkey caches key state at the edge for
        low-latency verification.

        Args:
            key: The API key value to verify (``uk_live_xxx``).

        Returns:
            VerifyResult with validity, owner, metadata, and rate limit info.
        """
        body: dict[str, Any] = {"key": key}

        try:
            resp = self._client.post("/v2/keys.verifyKey", json=body)
            resp.raise_for_status()
            raw = resp.json()
            # v2 wraps payload in {"data": {...}}
            payload = raw.get("data", raw)
            return VerifyResult.from_response(payload)
        except Exception as e:
            logger.warning("Unkey verify_key failed: %s", e)
            return VerifyResult(valid=False, error=str(e))

    def create_key(
        self,
        owner_id: str,
        name: str = "",
        *,
        meta: dict[str, Any] | None = None,
        expires: int | None = None,
        remaining: int | None = None,
        ratelimit: dict[str, Any] | None = None,
        prefix: str = "uk_live",
    ) -> KeyInfo:
        """Create a new API key.

        Args:
            owner_id: Customer ID (maps to Unkey externalId).
            name: Human-readable key name.
            meta: Metadata to attach (e.g. tier, company).
            expires: Unix timestamp for key expiration (None = no expiry).
            remaining: Number of remaining uses (None = unlimited).
            ratelimit: Rate limit configuration dict.
                v1 format: ``{"type": "fast", "limit": 100, "duration": 60000}``
                Automatically converted to v2 array format.
            prefix: Key prefix (default ``uk_live``).

        Returns:
            KeyInfo with the new key details. The key value is in
            the response only at creation time.

        Raises:
            RuntimeError: If key creation fails.
        """
        body: dict[str, Any] = {
            "apiId": self._api_id,
            "externalId": owner_id,
            "prefix": prefix,
            "enabled": True,
        }
        if name:
            body["name"] = name
        if meta:
            body["meta"] = meta
        if expires is not None:
            body["expires"] = expires
        if remaining is not None:
            body["remaining"] = remaining
        if ratelimit:
            # Convert v1-style single ratelimit to v2-style array
            body["ratelimits"] = [
                {
                    "name": ratelimit.get("name", "requests"),
                    "limit": ratelimit["limit"],
                    "duration": ratelimit["duration"],
                    "autoApply": ratelimit.get("autoApply", True),
                }
            ]

        resp = self._client.post("/v2/keys.createKey", json=body)
        resp.raise_for_status()
        raw = resp.json()
        # v2 wraps payload in {"data": {...}}
        data = raw.get("data", raw)
        return KeyInfo(
            key_id=data.get("keyId", ""),
            api_id=self._api_id,
            name=name,
            owner_id=owner_id,
            meta=meta or {},
            key=data.get("key", ""),
        )

    def revoke_key(self, key_id: str) -> bool:
        """Revoke (delete) an API key.

        Args:
            key_id: The Unkey key ID to revoke.

        Returns:
            True if revocation succeeded, False otherwise.
        """
        try:
            resp = self._client.post(
                "/v2/keys.deleteKey",
                json={"keyId": key_id},
            )
            resp.raise_for_status()
            return True
        except Exception as e:
            logger.warning("Unkey revoke_key failed for %s: %s", key_id, e)
            return False

    def list_keys(self, owner_id: str | None = None) -> list[KeyInfo]:
        """List API keys, optionally filtered by owner.

        Args:
            owner_id: Filter by customer ID (externalId).

        Returns:
            List of KeyInfo objects.
        """
        body: dict[str, Any] = {"apiId": self._api_id}
        if owner_id:
            body["externalId"] = owner_id

        try:
            resp = self._client.post("/v2/apis.listKeys", json=body)
            resp.raise_for_status()
            raw = resp.json()
            # v2 wraps in {"data": {"keys": [...]}}
            data = raw.get("data", raw)
            keys_data = data.get("keys", [])
            return [KeyInfo.from_response(k) for k in keys_data]
        except Exception as e:
            logger.warning("Unkey list_keys failed: %s", e)
            return []

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> UnkeyClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
