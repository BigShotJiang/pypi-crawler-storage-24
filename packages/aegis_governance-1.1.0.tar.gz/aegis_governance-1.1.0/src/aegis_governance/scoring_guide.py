"""AEGIS Scoring Guide — domain-specific parameter derivation guidance.

Surfaces the content from docs/integration/parameter-reference.md and
docs/integration/domain-templates.md as structured data that the MCP
protocol can return via the ``aegis_get_scoring_guide`` tool.

New domains are added by inserting a new entry into ``_DOMAIN_GUIDES``.
No code changes required — pure data.
"""

from __future__ import annotations

import copy
from typing import Any

# ── Valid domain identifiers ──────────────────────────────────────────
VALID_DOMAINS = frozenset({"trading", "cicd", "moderation", "agents", "generic"})

# ── Per-parameter generic guidance (shared across all domains) ────────

_GENERIC_PARAMS: dict[str, dict[str, Any]] = {
    "risk_baseline": {
        "description": "Current risk level before the proposed change (0.0-1.0)",
        "derivation": "Normalize your primary risk metric to a 0-1 scale",
        "formula": "risk_baseline = current_risk_metric / maximum_acceptable_risk",
        "example": "If your error rate is 2% and your SLA allows 10%, risk_baseline = 0.02/0.10 = 0.20",
        "range_guide": {
            "0.0-0.1": "Low risk — well within limits",
            "0.1-0.3": "Moderate risk — approaching limits",
            "0.3-0.5": "Elevated risk — near capacity",
            "0.5+": "High risk — at or exceeding limits",
        },
    },
    "risk_proposed": {
        "description": "Predicted risk level after the proposed change (0.0-1.0)",
        "derivation": "Estimate what your risk metric will be after the change",
        "formula": "risk_proposed = estimated_post_change_risk / maximum_acceptable_risk",
        "example": "If you expect error rate to rise to 5% with a 10% SLA, risk_proposed = 0.05/0.10 = 0.50",
        "gate_behavior": (
            "Gate triggers when risk more than doubles: "
            "P((risk_proposed - risk_baseline) / max(risk_baseline, 0.01) >= 2.0) > 0.95"
        ),
    },
    "profit_baseline": {
        "description": "Current performance/profit metric before the change",
        "derivation": "Use your primary performance metric (not normalized to 0-1)",
        "formula": "profit_baseline = current_performance_metric",
        "example": "Current throughput: 100 requests/sec, profit_baseline = 100",
        "note": "Units are domain-specific. The gate compares relative change, not absolute values.",
    },
    "profit_proposed": {
        "description": "Expected performance/profit after the change",
        "derivation": "Estimate what your performance metric will be after the change",
        "formula": "profit_proposed = expected_post_change_performance",
        "example": "Expected throughput after optimization: 130 req/sec, profit_proposed = 130",
        "gate_behavior": (
            "Gate detects performance DECREASES. Positive changes (improvement) always pass. "
            "Gate triggers when performance drops by 2x with 95% Bayesian confidence."
        ),
    },
    "novelty_score": {
        "description": "How unprecedented this proposal is (0.0=routine, 1.0=completely novel)",
        "derivation": "Assess how similar this is to past actions",
        "formula": "novelty_score = 1.0 - similarity_to_nearest_precedent",
        "example": "If you've done 10 similar deployments, novelty_score = 0.2. If this is brand new, novelty_score = 0.95.",
        "gate_behavior": (
            "Gate PASSES for high novelty (>= ~0.84). "
            "Low novelty FAILS — this reflects that proposals should demonstrate "
            "sufficient novelty to warrant consideration."
        ),
        "common_mistake": (
            "The novelty gate is counterintuitive: routine changes FAIL, novel changes PASS. "
            "If your domain treats novelty as risk, use 1.0 - your_risk_metric."
        ),
    },
    "complexity_score": {
        "description": "Normalized complexity where HIGHER = SIMPLER (0.0=maximally complex, 1.0=trivial)",
        "derivation": "Invert your raw complexity measure",
        "formula": "complexity_score = 1.0 - (raw_complexity / max_complexity)",
        "example": "Touching 3 systems out of a max 20: complexity_score = 1.0 - (3/20) = 0.85",
        "gate_behavior": (
            "Hard floor at 0.5 — below this, the proposal HALTs and CANNOT be overridden. "
            "This is the only non-overridable gate."
        ),
        "common_mistake": (
            "complexity_score is INVERTED: higher = simpler. "
            "A complex change gets a LOW score. Don't pass raw complexity!"
        ),
    },
    "quality_score": {
        "description": "Overall proposal quality (0.0-1.0, threshold: 0.7)",
        "derivation": "Average your quality subscores",
        "formula": "quality_score = mean(quality_subscores)",
        "example": "review=0.9, tests=0.8, docs=0.7 → quality_score = 0.8",
        "gate_behavior": "Must be >= 0.7. If quality_subscores provided, none may be zero.",
    },
    "quality_subscores": {
        "description": "Per-dimension quality scores (array of 0.0-1.0 values)",
        "derivation": "Score each quality dimension independently",
        "dimensions": ["review_quality", "test_coverage", "documentation"],
        "gate_behavior": "If any subscore is exactly 0.0, the quality gate fails (no-zero rule).",
    },
    "estimated_impact": {
        "description": "Blast radius if something goes wrong",
        "derivation": "Count affected users, systems, or services",
        "options": {
            "low": "1 feature, 1 config, isolated change",
            "medium": "Several features, a migration, a service update",
            "high": "Many users or services, major infrastructure",
            "critical": "System-wide, security-critical, regulatory",
        },
    },
}

# ── Domain-specific overrides & worked examples ───────────────────────

_TRADING_GUIDE: dict[str, Any] = {
    "domain": "trading",
    "domain_description": "Algorithmic trading, portfolio management, quantitative finance",
    "parameters": {
        "risk_baseline": {
            **_GENERIC_PARAMS["risk_baseline"],
            "derivation": "Divide current Value-at-Risk by position limit",
            "formula": "risk_baseline = current_VaR / position_limit",
            "example": "$45K daily VaR / $500K limit = 0.09",
        },
        "risk_proposed": {
            **_GENERIC_PARAMS["risk_proposed"],
            "derivation": "Divide projected VaR (with new strategy) by position limit",
            "formula": "risk_proposed = projected_VaR / position_limit",
            "example": "$78K projected VaR / $500K limit = 0.156",
        },
        "profit_baseline": {
            **_GENERIC_PARAMS["profit_baseline"],
            "derivation": "Use trailing Sharpe ratio or annualized return",
            "formula": "profit_baseline = trailing_sharpe_ratio",
            "example": "Trailing 6-month Sharpe: 1.2",
        },
        "profit_proposed": {
            **_GENERIC_PARAMS["profit_proposed"],
            "derivation": "Use backtest or projected Sharpe ratio",
            "formula": "profit_proposed = backtest_sharpe_ratio",
            "example": "2-year backtest Sharpe: 1.8",
        },
        "novelty_score": {
            **_GENERIC_PARAMS["novelty_score"],
            "derivation": "1 minus cosine similarity of new strategy to nearest historical strategy",
            "formula": "novelty_score = 1.0 - cosine_sim(new_strategy, nearest_historical)",
            "example": "New market regime strategy: 0.65",
        },
        "complexity_score": {
            **_GENERIC_PARAMS["complexity_score"],
            "derivation": "1 minus (instruments x markets / max allowed)",
            "formula": "complexity_score = 1.0 - (num_instruments * num_markets / max_allowed)",
            "example": "1 instrument, 1 market, max 20: 1.0 - (1/20) = 0.95",
        },
        "quality_score": {
            **_GENERIC_PARAMS["quality_score"],
            "dimensions": ["backtest_quality", "data_quality", "code_review_score"],
            "example": "[0.85, 0.9, 0.8] → avg = 0.85",
        },
        "quality_subscores": {
            **_GENERIC_PARAMS["quality_subscores"],
            "dimensions": ["backtest_quality", "data_quality", "code_review_score"],
        },
        "estimated_impact": _GENERIC_PARAMS["estimated_impact"],
    },
    "common_mistakes": [
        "complexity_score is INVERTED: higher = simpler. A complex multi-instrument strategy gets a LOW score.",
        "novelty gate PASSES for high novelty (>= 0.84). Routine strategies (low novelty) FAIL.",
        "Setting risk_proposed without risk_baseline — the gate compares the two, so both matter.",
        "Using VaR values directly instead of normalizing by position limit.",
    ],
    "worked_example": {
        "scenario": "Deploy mean-reversion strategy on ES futures (backtest Sharpe 1.8, 2yr)",
        "input": {
            "proposal_summary": "Deploy mean-reversion strategy on ES futures (backtest Sharpe 1.8, 2yr)",
            "estimated_impact": "medium",
            "risk_baseline": 0.09,
            "risk_proposed": 0.156,
            "profit_baseline": 1.2,
            "profit_proposed": 1.8,
            "novelty_score": 0.65,
            "complexity_score": 0.9,
            "quality_score": 0.85,
            "quality_subscores": [0.85, 0.9, 0.8],
        },
        "expected_gates": {
            "risk": {"passed": True, "reason": "Risk increased 73% but not 2x"},
            "profit": {"passed": True, "reason": "Sharpe improved from 1.2 to 1.8"},
            "novelty": {"passed": False, "reason": "G(0.65) = 0.38 < 0.8 threshold"},
            "complexity": {"passed": True, "reason": "0.9 well above 0.5 floor"},
            "quality": {"passed": True, "reason": "0.85 >= 0.7, no zero subscores"},
        },
        "expected_status": "PAUSE",
    },
}

_CICD_GUIDE: dict[str, Any] = {
    "domain": "cicd",
    "domain_description": "CI/CD pipelines, deployments, infrastructure changes",
    "parameters": {
        "risk_baseline": {
            **_GENERIC_PARAMS["risk_baseline"],
            "derivation": "Current production error rate",
            "formula": "risk_baseline = current_error_rate",
            "example": "2% error rate → risk_baseline = 0.02",
        },
        "risk_proposed": {
            **_GENERIC_PARAMS["risk_proposed"],
            "derivation": "Estimated post-deploy error rate",
            "formula": "risk_proposed = estimated_post_deploy_error_rate",
            "example": "8% during migration window → risk_proposed = 0.08",
        },
        "profit_baseline": {
            **_GENERIC_PARAMS["profit_baseline"],
            "derivation": "Deployment throughput normalized by team capacity",
            "formula": "profit_baseline = deploys_per_day / max_deploys_per_day",
            "example": "12 deploys/day, team max 50 → 12/50 = 0.24",
        },
        "profit_proposed": {
            **_GENERIC_PARAMS["profit_proposed"],
            "derivation": "Expected throughput after the change",
            "formula": "profit_proposed = expected_deploys_per_day / max_deploys_per_day",
            "example": "14 deploys/day expected → 14/50 = 0.28",
        },
        "novelty_score": {
            **_GENERIC_PARAMS["novelty_score"],
            "derivation": "Based on change type classification",
            "formula": "config=0.2, dependency=0.5, schema_migration=0.6, new_service=0.8, architecture=0.95",
            "example": "Schema migration → novelty_score = 0.6",
        },
        "complexity_score": {
            **_GENERIC_PARAMS["complexity_score"],
            "derivation": "1 minus (services x tables / max)",
            "formula": "complexity_score = 1.0 - (services_touched * tables_changed / max_complexity_budget)",
            "example": "3 services, 1 table, max 20 → 1.0 - (3/20) = 0.85",
        },
        "quality_score": {
            **_GENERIC_PARAMS["quality_score"],
            "dimensions": ["test_pass_rate", "lint_score", "review_approval"],
            "example": "[0.98, 1.0, 0.9] → avg = 0.96",
        },
        "quality_subscores": {
            **_GENERIC_PARAMS["quality_subscores"],
            "dimensions": ["test_pass_rate", "lint_score", "review_approval"],
        },
        "estimated_impact": _GENERIC_PARAMS["estimated_impact"],
    },
    "common_mistakes": [
        "complexity_score is INVERTED: higher = simpler. A complex multi-service deploy gets a LOW score.",
        "novelty gate PASSES for high novelty (>= 0.84). Routine deploys (low novelty) FAIL.",
        "Forgetting to set reversible=false for irreversible migrations.",
        "Using lines-of-code directly for complexity instead of normalizing to 0-1.",
    ],
    "worked_example": {
        "scenario": "Schema migration: users table (5M rows), 3 services, 10-min maintenance window",
        "input": {
            "proposal_summary": "Schema migration: users table (5M rows), 3 services, 10-min maintenance window",
            "estimated_impact": "high",
            "risk_baseline": 0.02,
            "risk_proposed": 0.08,
            "profit_baseline": 0.24,
            "profit_proposed": 0.28,
            "novelty_score": 0.6,
            "complexity_score": 0.85,
            "quality_score": 0.96,
            "quality_subscores": [0.98, 1.0, 0.9],
            "reversible": False,
            "requires_human_approval": True,
        },
        "expected_gates": {
            "risk": {
                "passed": False,
                "reason": "Error rate 4x (3.0 > trigger_factor 2.0)",
            },
            "profit": {"passed": True, "reason": "Throughput improved 0.24 to 0.28"},
            "novelty": {"passed": False, "reason": "G(0.6) = 0.27 < 0.8 threshold"},
            "complexity": {"passed": True, "reason": "0.85 well above 0.5 floor"},
            "quality": {"passed": True, "reason": "0.96 >= 0.7, no zero subscores"},
        },
        "expected_status": "ESCALATE",
    },
}

_MODERATION_GUIDE: dict[str, Any] = {
    "domain": "moderation",
    "domain_description": "Content moderation, trust & safety, policy enforcement",
    "parameters": {
        "risk_baseline": {
            **_GENERIC_PARAMS["risk_baseline"],
            "derivation": "Current false positive rate from quality dashboard",
            "formula": "risk_baseline = current_false_positive_rate",
            "example": "3% FPR → risk_baseline = 0.03",
        },
        "risk_proposed": {
            **_GENERIC_PARAMS["risk_proposed"],
            "derivation": "Estimated FPR with new rules",
            "formula": "risk_proposed = estimated_post_change_fpr",
            "example": "5% estimated FPR → risk_proposed = 0.05",
        },
        "profit_baseline": {
            **_GENERIC_PARAMS["profit_baseline"],
            "derivation": "Current precision (1 - false discovery rate)",
            "formula": "profit_baseline = current_precision",
            "example": "95% precision → profit_baseline = 0.95",
        },
        "profit_proposed": {
            **_GENERIC_PARAMS["profit_proposed"],
            "derivation": "Expected precision after policy update",
            "formula": "profit_proposed = expected_precision",
            "example": "92% expected precision → profit_proposed = 0.92",
        },
        "novelty_score": {
            **_GENERIC_PARAMS["novelty_score"],
            "derivation": "Based on policy precedent",
            "formula": "existing_policy=0.3, new_policy_area=0.7, unprecedented=0.95",
            "example": "AI-generated misinformation (no precedent) → novelty_score = 0.85",
        },
        "complexity_score": {
            **_GENERIC_PARAMS["complexity_score"],
            "derivation": "1 minus (new rules / total rules)",
            "formula": "complexity_score = 1.0 - (new_rules / total_rules)",
            "example": "15 new rules out of 200 total → 1.0 - (15/200) = 0.925",
        },
        "quality_score": {
            **_GENERIC_PARAMS["quality_score"],
            "dimensions": ["rule_clarity", "legal_review", "annotator_agreement"],
            "example": "[0.9, 0.8, 0.75] → avg = 0.82",
        },
        "quality_subscores": {
            **_GENERIC_PARAMS["quality_subscores"],
            "dimensions": ["rule_clarity", "legal_review", "annotator_agreement"],
        },
        "estimated_impact": _GENERIC_PARAMS["estimated_impact"],
    },
    "common_mistakes": [
        "complexity_score is INVERTED: higher = simpler. Many new rules = LOW complexity_score.",
        "novelty gate PASSES for high novelty (>= 0.84). Existing policy updates (low novelty) FAIL.",
        "Forgetting to set estimated_impact='critical' when all users are affected.",
        "Using raw rule count instead of normalizing to 0-1.",
    ],
    "worked_example": {
        "scenario": "Add AI-generated misinformation category (15 new rules, all users affected)",
        "input": {
            "proposal_summary": "Add AI-generated misinformation category to content moderation policy (15 new rules)",
            "estimated_impact": "critical",
            "risk_baseline": 0.03,
            "risk_proposed": 0.05,
            "profit_baseline": 0.95,
            "profit_proposed": 0.92,
            "novelty_score": 0.85,
            "complexity_score": 0.925,
            "quality_score": 0.82,
            "quality_subscores": [0.9, 0.8, 0.75],
            "requires_human_approval": True,
        },
        "expected_gates": {
            "risk": {"passed": True, "reason": "FPR increase 67%, below 2x trigger"},
            "profit": {
                "passed": True,
                "reason": "Precision drop minimal (0.95 to 0.92)",
            },
            "novelty": {"passed": True, "reason": "G(0.85) = 0.82 >= 0.8 threshold"},
            "complexity": {"passed": True, "reason": "0.925 well above 0.5 floor"},
            "quality": {"passed": True, "reason": "0.82 >= 0.7, no zero subscores"},
        },
        "expected_status": "ESCALATE",
        "note": "All gates pass, but critical impact always escalates.",
    },
}

_AGENTS_GUIDE: dict[str, Any] = {
    "domain": "agents",
    "domain_description": "Autonomous AI agents, coding assistants, self-governance",
    "parameters": {
        "risk_baseline": {
            **_GENERIC_PARAMS["risk_baseline"],
            "derivation": "Recent task failure rate",
            "formula": "risk_baseline = recent_failures / total_tasks",
            "example": "5% failure rate → risk_baseline = 0.05",
        },
        "risk_proposed": {
            **_GENERIC_PARAMS["risk_proposed"],
            "derivation": "Estimated failure rate for this specific task",
            "formula": "risk_proposed = estimated_failure_rate_for_task",
            "example": "Complex refactor → risk_proposed = 0.12",
        },
        "profit_baseline": {
            **_GENERIC_PARAMS["profit_baseline"],
            "derivation": "Current code quality or maintainability index",
            "formula": "profit_baseline = current_quality_metric",
            "example": "Maintainability index 0.7 → profit_baseline = 0.7",
        },
        "profit_proposed": {
            **_GENERIC_PARAMS["profit_proposed"],
            "derivation": "Expected quality after the change",
            "formula": "profit_proposed = expected_quality_metric",
            "example": "Cleaner architecture → profit_proposed = 0.85",
        },
        "novelty_score": {
            **_GENERIC_PARAMS["novelty_score"],
            "derivation": "Based on action familiarity (NOT agent confidence)",
            "formula": "novelty_score = 1.0 - (similar_past_actions / total_historical_actions)",
            "example": "First-time architecture change → novelty_score = 0.95. Routine refactor → 0.3",
            "common_mistake": (
                "Do NOT map novelty = 1.0 - confidence. High confidence in a novel task "
                "should still have high novelty. Map based on action precedent, not certainty."
            ),
        },
        "complexity_score": {
            **_GENERIC_PARAMS["complexity_score"],
            "derivation": "1 minus (files x modules / max plan length)",
            "formula": "complexity_score = 1.0 - (files_changed * modules / max_allowed)",
            "example": "15 files, 3 modules, max 100 → 1.0 - (45/100) = 0.55",
        },
        "quality_score": {
            **_GENERIC_PARAMS["quality_score"],
            "dimensions": ["plan_coherence", "test_coverage", "safety_check"],
            "example": "[0.8, 0.7, 0.9] → avg = 0.8",
        },
        "quality_subscores": {
            **_GENERIC_PARAMS["quality_subscores"],
            "dimensions": ["plan_coherence", "test_coverage", "safety_check"],
        },
        "estimated_impact": _GENERIC_PARAMS["estimated_impact"],
    },
    "common_mistakes": [
        "complexity_score is INVERTED: higher = simpler. A complex multi-file refactor gets a LOW score.",
        "novelty gate PASSES for high novelty (>= 0.84). Routine operations (low novelty) FAIL.",
        "Mapping novelty_score = 1.0 - confidence is wrong. Use action precedent, not certainty.",
        "Forgetting that complexity_score = 0.55 is dangerously close to the 0.5 non-overridable floor.",
    ],
    "worked_example": {
        "scenario": "Refactor authentication module: 15 files across 3 modules",
        "input": {
            "proposal_summary": "Refactor authentication module: 15 files across 3 modules for improved maintainability",
            "estimated_impact": "high",
            "risk_baseline": 0.05,
            "risk_proposed": 0.12,
            "profit_baseline": 0.7,
            "profit_proposed": 0.85,
            "novelty_score": 0.25,
            "complexity_score": 0.55,
            "quality_score": 0.8,
            "quality_subscores": [0.8, 0.7, 0.9],
            "shadow_mode": True,
        },
        "expected_gates": {
            "risk": {
                "passed": True,
                "reason": "Failure rate increase 1.4x, below 2x trigger",
            },
            "profit": {"passed": True, "reason": "Quality improved from 0.7 to 0.85"},
            "novelty": {
                "passed": False,
                "reason": "G(0.25) = 0.01 < 0.8 (familiar pattern)",
            },
            "complexity": {"passed": True, "reason": "0.55 barely above 0.5 floor"},
            "quality": {"passed": True, "reason": "0.8 >= 0.7, no zero subscores"},
        },
        "expected_status": "ESCALATE",
        "note": "Shadow mode: advisory only. Novelty fails because routine refactor lacks precedent novelty.",
    },
}

_GENERIC_GUIDE: dict[str, Any] = {
    "domain": "generic",
    "domain_description": "General-purpose guidance applicable to any domain",
    "parameters": _GENERIC_PARAMS,
    "common_mistakes": [
        "complexity_score is INVERTED: higher = simpler. A complex change gets a LOW score.",
        "novelty gate PASSES for high novelty (>= 0.84). Routine changes (low novelty) FAIL.",
        "Setting risk_proposed without risk_baseline — the gate compares the two, so both matter.",
        "Passing raw complexity metrics without normalizing to 0-1.",
        "Forgetting that the complexity floor (0.5) is a HARD halt that CANNOT be overridden.",
    ],
    "worked_example": {
        "scenario": "General proposal evaluation",
        "input": {
            "proposal_summary": "Example proposal",
            "estimated_impact": "medium",
            "risk_baseline": 0.1,
            "risk_proposed": 0.2,
            "profit_baseline": 0.5,
            "profit_proposed": 0.6,
            "novelty_score": 0.85,
            "complexity_score": 0.7,
            "quality_score": 0.8,
            "quality_subscores": [0.8, 0.8, 0.8],
        },
        "expected_gates": {
            "risk": {"passed": True, "reason": "Risk doubled but P(delta>=2) < 0.95"},
            "profit": {"passed": True, "reason": "Performance improved"},
            "novelty": {"passed": True, "reason": "G(0.85) = 0.82 >= 0.8"},
            "complexity": {"passed": True, "reason": "0.7 above 0.5 floor"},
            "quality": {"passed": True, "reason": "0.8 >= 0.7, no zeros"},
        },
        "expected_status": "PROCEED",
    },
}

# ── Master domain registry ────────────────────────────────────────────

_DOMAIN_GUIDES: dict[str, dict[str, Any]] = {
    "trading": _TRADING_GUIDE,
    "cicd": _CICD_GUIDE,
    "moderation": _MODERATION_GUIDE,
    "agents": _AGENTS_GUIDE,
    "generic": _GENERIC_GUIDE,
}


def get_scoring_guide(domain: str | None = None) -> dict[str, Any]:
    """Return parameter derivation guidance for the given domain.

    Args:
        domain: One of 'trading', 'cicd', 'moderation', 'agents', 'generic'.
                If *None* or not recognised, falls back to 'generic'.

    Returns:
        Dict with keys: domain, domain_description, parameters,
        common_mistakes, worked_example.
    """
    if domain is None or domain not in _DOMAIN_GUIDES:
        domain = "generic"
    return copy.deepcopy(_DOMAIN_GUIDES[domain])
