"""AEGIS Stripe Webhook Handler — subscription lifecycle management.

Deployed as a separate Lambda function to handle Stripe webhook events
for subscription creation, updates, cancellation, and invoice lifecycle.

Routes:
    POST /webhooks/stripe — Stripe event webhook (signature-verified)

Authentication:
    Stripe webhook signature verification (NOT Unkey token auth).
    The webhook signing secret is stored in Secrets Manager.

Environment variables:
    AEGIS_TABLE_NAME              — DynamoDB table name
    STRIPE_WEBHOOK_SECRET_ARN     — Secrets Manager ARN for webhook signing secret
    STRIPE_SECRET_KEY_ARN         — Secrets Manager ARN for Stripe API key
    AEGIS_STAGE                   — Deployment stage
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# --- Singletons (Lambda warm-start) ---
_LOCK = threading.Lock()
_CUSTOMER_MGR: Any = None
_WEBHOOK_SECRET: str = ""
_WEBHOOK_SECRET_LOADED: bool = False


def _get_customer_manager() -> Any:
    """Lazy-init CustomerManager singleton."""
    global _CUSTOMER_MGR  # noqa: PLW0603
    if _CUSTOMER_MGR is not None:
        return _CUSTOMER_MGR
    with _LOCK:
        if _CUSTOMER_MGR is None:
            from aegis_governance.customer import CustomerManager

            _CUSTOMER_MGR = CustomerManager()
    return _CUSTOMER_MGR


def _get_webhook_secret() -> str:
    """Load Stripe webhook signing secret."""
    global _WEBHOOK_SECRET, _WEBHOOK_SECRET_LOADED  # noqa: PLW0603
    if _WEBHOOK_SECRET_LOADED:
        return _WEBHOOK_SECRET
    with _LOCK:
        if not _WEBHOOK_SECRET_LOADED:
            secret_arn = os.environ.get("STRIPE_WEBHOOK_SECRET_ARN", "")
            if secret_arn:
                import boto3

                sm = boto3.client("secretsmanager")
                resp = sm.get_secret_value(SecretId=secret_arn)
                secret = resp.get("SecretString", "")
                try:
                    data = json.loads(secret)
                    _WEBHOOK_SECRET = str(data.get("webhook_secret", secret))
                except (json.JSONDecodeError, AttributeError):
                    _WEBHOOK_SECRET = secret
            else:
                _WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
            _WEBHOOK_SECRET_LOADED = True
    return _WEBHOOK_SECRET


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Stripe Webhook Lambda entry point."""
    http_method = event.get("httpMethod", "GET")
    path = event.get("path", "")

    if path == "/webhooks/stripe" and http_method == "POST":
        return _handle_stripe_webhook(event)

    return _response(404, {"error": f"Not found: {http_method} {path}"})


def _handle_stripe_webhook(event: dict[str, Any]) -> dict[str, Any]:
    """POST /webhooks/stripe — process Stripe webhook event."""
    # Verify Stripe signature
    headers = event.get("headers", {}) or {}
    signature = headers.get("Stripe-Signature") or headers.get("stripe-signature", "")
    raw_body = event.get("body", "")

    if event.get("isBase64Encoded"):
        import base64

        raw_body = base64.b64decode(raw_body, validate=True).decode("utf-8")

    if not _verify_stripe_signature(raw_body, signature):
        logger.warning("Invalid Stripe webhook signature")
        return _response(401, {"error": "Invalid signature"})

    try:
        payload = json.loads(raw_body)
    except (json.JSONDecodeError, ValueError) as e:
        return _response(400, {"error": f"Invalid payload: {e}"})

    event_type = payload.get("type", "")
    data_object = payload.get("data", {}).get("object", {})

    logger.info(
        "Processing Stripe event: %s (id=%s)", event_type, payload.get("id", "")
    )

    # Route to event-specific handler
    if event_type == "customer.subscription.created":
        return _handle_subscription_created(data_object)
    elif event_type == "customer.subscription.updated":
        return _handle_subscription_updated(data_object)
    elif event_type == "customer.subscription.deleted":
        return _handle_subscription_deleted(data_object)
    elif event_type == "invoice.paid":
        return _handle_invoice_paid(data_object)
    elif event_type == "invoice.payment_failed":
        return _handle_invoice_payment_failed(data_object)
    else:
        # Acknowledge unhandled events without error
        logger.info("Ignoring unhandled Stripe event type: %s", event_type)
        return _response(200, {"received": True})


# --- Stripe Event Handlers ---


def _handle_subscription_created(sub: dict[str, Any]) -> dict[str, Any]:
    """Handle customer.subscription.created event.

    Creates SUBSCRIPTION#{customer_id} / ACTIVE in DynamoDB and updates
    the customer tier based on the subscribed product.
    """
    customer_id = _resolve_customer_id(sub)
    if not customer_id:
        logger.warning("Cannot resolve customer_id for subscription %s", sub.get("id"))
        return _response(200, {"received": True, "warning": "customer_id not resolved"})

    tier = _resolve_tier_from_subscription(sub)
    if not tier:
        return _response(
            200, {"received": True, "warning": "aegis_tier metadata missing"}
        )

    from aegis_governance.customer import Subscription

    subscription = Subscription(
        customer_id=customer_id,
        stripe_subscription_id=sub.get("id", ""),
        stripe_customer_id=sub.get("customer", ""),
        tier=tier,
        status=sub.get("status", "active"),
        current_period_start=_unix_to_iso(sub.get("current_period_start", 0)),
        current_period_end=_unix_to_iso(sub.get("current_period_end", 0)),
        cancel_at_period_end=sub.get("cancel_at_period_end", False),
    )

    mgr = _get_customer_manager()
    mgr.upsert_subscription(subscription)

    # Update customer tier
    mgr.update_customer(customer_id, tier=tier)
    logger.info(
        "Subscription created: customer=%s tier=%s stripe_sub=%s",
        customer_id,
        tier,
        sub.get("id"),
    )

    return _response(200, {"received": True})


def _handle_subscription_updated(sub: dict[str, Any]) -> dict[str, Any]:
    """Handle customer.subscription.updated event.

    Updates subscription record and customer tier if plan changed.
    """
    customer_id = _resolve_customer_id(sub)
    if not customer_id:
        return _response(200, {"received": True, "warning": "customer_id not resolved"})

    tier = _resolve_tier_from_subscription(sub)
    if not tier:
        return _response(
            200, {"received": True, "warning": "aegis_tier metadata missing"}
        )

    from aegis_governance.customer import Subscription

    subscription = Subscription(
        customer_id=customer_id,
        stripe_subscription_id=sub.get("id", ""),
        stripe_customer_id=sub.get("customer", ""),
        tier=tier,
        status=sub.get("status", "active"),
        current_period_start=_unix_to_iso(sub.get("current_period_start", 0)),
        current_period_end=_unix_to_iso(sub.get("current_period_end", 0)),
        cancel_at_period_end=sub.get("cancel_at_period_end", False),
    )

    mgr = _get_customer_manager()
    mgr.upsert_subscription(subscription)

    # Sync tier to customer record
    mgr.update_customer(customer_id, tier=tier)

    # Update Unkey key metadata with new tier rate limits
    _update_unkey_key_metadata(customer_id, tier)

    logger.info(
        "Subscription updated: customer=%s tier=%s status=%s",
        customer_id,
        tier,
        sub.get("status"),
    )

    return _response(200, {"received": True})


def _handle_subscription_deleted(sub: dict[str, Any]) -> dict[str, Any]:
    """Handle customer.subscription.deleted event.

    Downgrades customer to community tier.
    """
    customer_id = _resolve_customer_id(sub)
    if not customer_id:
        return _response(200, {"received": True, "warning": "customer_id not resolved"})

    from aegis_governance.customer import Subscription

    subscription = Subscription(
        customer_id=customer_id,
        stripe_subscription_id=sub.get("id", ""),
        stripe_customer_id=sub.get("customer", ""),
        tier="community",
        status="canceled",
        current_period_start=_unix_to_iso(sub.get("current_period_start", 0)),
        current_period_end=_unix_to_iso(sub.get("current_period_end", 0)),
        cancel_at_period_end=False,
    )

    mgr = _get_customer_manager()
    mgr.upsert_subscription(subscription)
    mgr.update_customer(customer_id, tier="community")

    logger.info(
        "Subscription deleted: customer=%s downgraded to community",
        customer_id,
    )

    return _response(200, {"received": True})


def _handle_invoice_paid(invoice: dict[str, Any]) -> dict[str, Any]:
    """Handle invoice.paid event. Log for audit trail."""
    customer_id = _resolve_customer_id_from_invoice(invoice)
    logger.info(
        "Invoice paid: customer=%s amount=%s currency=%s invoice=%s",
        customer_id or "unknown",
        invoice.get("amount_paid", 0),
        invoice.get("currency", "usd"),
        invoice.get("id", ""),
    )
    return _response(200, {"received": True})


def _handle_invoice_payment_failed(invoice: dict[str, Any]) -> dict[str, Any]:
    """Handle invoice.payment_failed event.

    Marks account as past_due if a subscription invoice fails.
    """
    customer_id = _resolve_customer_id_from_invoice(invoice)
    if not customer_id:
        return _response(200, {"received": True, "warning": "customer_id not resolved"})

    mgr = _get_customer_manager()
    subscription = mgr.get_subscription(customer_id)
    if subscription:
        from aegis_governance.customer import Subscription

        updated = Subscription(
            customer_id=subscription.customer_id,
            stripe_subscription_id=subscription.stripe_subscription_id,
            stripe_customer_id=subscription.stripe_customer_id,
            tier=subscription.tier,
            status="past_due",
            current_period_start=subscription.current_period_start,
            current_period_end=subscription.current_period_end,
            cancel_at_period_end=subscription.cancel_at_period_end,
        )
        mgr.upsert_subscription(updated)

    logger.warning(
        "Invoice payment failed: customer=%s invoice=%s",
        customer_id,
        invoice.get("id", ""),
    )

    return _response(200, {"received": True})


# --- Helpers ---


# Stripe product metadata key → AEGIS tier mapping
# Products MUST have metadata.aegis_tier set to one of these values
_STRIPE_TIER_MAP: dict[str, str] = {
    "professional": "professional",
    "enterprise": "enterprise",
    "financial_services": "financial_services",
}


def _resolve_customer_id(sub: dict[str, Any]) -> str:
    """Extract AEGIS customer_id from Stripe subscription metadata.

    Stripe subscriptions MUST have metadata.aegis_customer_id set during
    Checkout Session creation.
    """
    metadata = sub.get("metadata", {})
    return metadata.get("aegis_customer_id", "")


def _resolve_customer_id_from_invoice(invoice: dict[str, Any]) -> str:
    """Extract AEGIS customer_id from invoice subscription metadata."""
    sub_metadata = invoice.get("subscription_details", {}).get("metadata", {})
    return sub_metadata.get("aegis_customer_id", "")


def _resolve_tier_from_subscription(sub: dict[str, Any]) -> str | None:
    """Determine AEGIS tier from Stripe subscription items.

    Uses product metadata.aegis_tier field. Returns None if no tier metadata
    is found (indicates misconfigured Stripe product).
    """
    items = sub.get("items", {}).get("data", [])
    for item in items:
        product_meta = item.get("price", {}).get("metadata", {})
        aegis_tier = product_meta.get("aegis_tier", "")
        if aegis_tier in _STRIPE_TIER_MAP:
            return _STRIPE_TIER_MAP[aegis_tier]

    # Fallback: check subscription-level metadata
    sub_meta = sub.get("metadata", {})
    tier = sub_meta.get("aegis_tier", "")
    if tier in _STRIPE_TIER_MAP:
        return _STRIPE_TIER_MAP[tier]

    logger.warning(
        "No aegis_tier metadata found in subscription %s — Stripe product may be misconfigured",
        sub.get("id", "unknown"),
    )
    return None


def _update_unkey_key_metadata(customer_id: str, tier: str) -> None:
    """Update Unkey key rate limits when tier changes (best-effort)."""
    try:
        # Import at call site to avoid circular import
        from aegis_governance.customer_api import _get_unkey_client

        unkey = _get_unkey_client()
        if not unkey:
            return

        from aegis_governance.tiers import get_tier

        tier_def = get_tier(tier)
        keys = unkey.list_keys(owner_id=customer_id)
        for key in keys:
            logger.info(
                "Would update key %s rate limit to %d/min for tier %s",
                key.key_id,
                tier_def.rate_per_minute,
                tier,
            )
            # Note: Unkey key update API would be called here.
            # The current UnkeyClient doesn't have an update_key method,
            # so this is logged for now and can be wired when the method is added.
    except Exception as e:
        logger.warning("Failed to update Unkey key metadata for %s: %s", customer_id, e)


def _verify_stripe_signature(payload: str, signature: str) -> bool:
    """Verify Stripe webhook signature using HMAC-SHA256.

    Stripe sends signatures in the format:
        t=<timestamp>,v1=<hmac_hex>

    We verify the v1 signature against:
        HMAC-SHA256(secret, f"{timestamp}.{payload}")
    """
    secret = _get_webhook_secret()
    if not secret:
        logger.error("Stripe webhook secret not configured")
        return False

    if not signature:
        return False

    # Parse signature header
    parts: dict[str, str] = {}
    for item in signature.split(","):
        if "=" in item:
            key, value = item.split("=", 1)
            parts[key.strip()] = value.strip()

    timestamp = parts.get("t", "")
    expected_sig = parts.get("v1", "")

    if not timestamp or not expected_sig:
        return False

    # Reject timestamps older than 5 minutes (replay protection)
    try:
        ts = int(timestamp)
        if abs(time.time() - ts) > 300:
            logger.warning("Stripe webhook timestamp too old: %s", timestamp)
            return False
    except ValueError:
        return False

    # Compute expected signature
    signed_payload = f"{timestamp}.{payload}"
    computed = hmac.new(
        secret.encode("utf-8"),
        signed_payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(computed, expected_sig)


def _unix_to_iso(unix_ts: int) -> str:
    """Convert Unix timestamp to ISO 8601 string."""
    if not unix_ts:
        return ""
    from datetime import datetime, timezone

    return datetime.fromtimestamp(unix_ts, tz=timezone.utc).isoformat()


def _response(status_code: int, body: dict[str, Any]) -> dict[str, Any]:
    """Build API Gateway proxy response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
        },
        "body": json.dumps(body),
    }
