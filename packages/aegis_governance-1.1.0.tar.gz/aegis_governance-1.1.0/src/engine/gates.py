"""Quantitative Gate Evaluators

Implements Guardrails v1.1.1 gate logic:
- Risk gate: P(Δ ≥ 2 | data) > 0.95
- Profit gate: P(Δ ≥ 2 | data) > 0.95
- Novelty gate: G(N) ≥ 0.8
- Complexity floor: C_norm ≥ 0.5
- Quality gate: Q ≥ 0.7, no zero sub-scores
- Utility LCB gate: LCB(U) > θ

GAP-L1 Integration:
    Prometheus metrics are recorded for each gate evaluation when
    prometheus_exporter is provided, tracking pass/fail rates and latency.
"""

import logging
import math
import time
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Optional

from .bayesian import BayesianPosterior
from .utility import UtilityResult
from .validation import validate_normalized, validate_positive, validate_range

if TYPE_CHECKING:
    from telemetry.prometheus_exporter import PrometheusExporter

logger = logging.getLogger(__name__)


class GateType(str, Enum):
    """Types of quantitative gates."""

    RISK = "risk"
    PROFIT = "profit"
    NOVELTY = "novelty"
    COMPLEXITY = "complexity"
    QUALITY = "quality"
    UTILITY = "utility"


@dataclass
class GateResult:
    """Result of a single gate evaluation."""

    gate_type: GateType
    passed: bool
    value: float
    threshold: float
    confidence: Optional[float] = None
    posterior_probability: Optional[float] = None
    message: Optional[str] = None

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        status = "PASS" if self.passed else "FAIL"
        return (
            f"GateResult({self.gate_type.value}, {status}, "
            f"value={self.value:.3f}, threshold={self.threshold:.3f})"
        )

    @property
    def margin(self) -> float:
        """Distance from threshold.

        Interpretation varies by gate type:
        - Complexity/Quality/Novelty/Utility: positive = passed by margin
        - Risk/Profit: value is the normalized delta; pass/fail is determined
          by posterior probability, not by this margin value
        """
        return self.value - self.threshold


@dataclass
class GateEvaluationResult:
    """Result of evaluating all gates."""

    gates: dict[GateType, GateResult]
    all_passed: bool
    override_eligible: bool
    min_confidence: float

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        failures = [g.gate_type.value for g in self.gates.values() if not g.passed]
        status = "ALL_PASSED" if self.all_passed else f"FAILED({', '.join(failures)})"
        return f"GateEvaluationResult({status}, override_eligible={self.override_eligible})"

    def get_failures(self) -> list[GateResult]:
        """Get list of failed gates."""
        return [g for g in self.gates.values() if not g.passed]


class GateEvaluator:
    """Evaluate proposals against quantitative gates.

    Gates are evaluated in order:
    1. Risk gate (Bayesian)
    2. Profit gate (Bayesian)
    3. Novelty gate (Logistic)
    4. Complexity floor (Hard)
    5. Quality gate (Weighted)
    6. Utility LCB gate
    """

    # Exponent clamp limit to prevent math.exp() overflow.
    # math.exp(x) overflows for x > ~709, so we use 700 for safety margin.
    _EXP_CLAMP_LIMIT: float = 700.0

    def __init__(
        self,
        epsilon_R: float = 0.01,
        epsilon_P: float = 0.01,
        risk_trigger_factor: float = 2.0,
        profit_trigger_factor: float = 2.0,
        trigger_confidence_prob: float = 0.95,
        novelty_N0: float = 0.7,
        novelty_k: float = 10.0,
        novelty_threshold: float = 0.8,
        complexity_floor: float = 0.5,
        quality_min_score: float = 0.7,
        quality_no_zero_subscore: bool = True,
        utility_threshold: float = 0.0,
        prometheus_exporter: Optional["PrometheusExporter"] = None,
    ):
        """Initialize GateEvaluator with configurable thresholds.

        Args:
            epsilon_R: Minimum denominator for risk normalization (must be > 0)
            epsilon_P: Minimum denominator for profit normalization (must be > 0)
            risk_trigger_factor: Threshold for risk gate. Negative values invert
                the gate logic (useful for testing or special scenarios where
                risk reduction should trigger the gate)
            profit_trigger_factor: Threshold for profit gate. Negative values
                invert the gate logic (useful for detecting profit decreases)
            trigger_confidence_prob: Bayesian confidence threshold
            novelty_N0: Novelty gate midpoint
            novelty_k: Novelty gate steepness
            novelty_threshold: Novelty gate pass threshold
            complexity_floor: Minimum complexity score required
            quality_min_score: Minimum quality score required
            quality_no_zero_subscore: Whether to reject proposals with zero sub-scores
            utility_threshold: Minimum utility LCB required
            prometheus_exporter: Optional metrics exporter

        Raises:
            ValueError: If epsilon_R or epsilon_P is not positive

        Note:
            Negative trigger_factor values are allowed and invert the gate logic.
            For example, risk_trigger_factor=-2.0 would trigger on risk decreases
            of 2x or more instead of increases. Values outside [-10, 10] suggest
            potential misconfiguration and will log a warning.

        """
        # Bug 1 fix: Validate epsilon values are positive to prevent division by zero
        validate_positive(
            "epsilon_R",
            epsilon_R,
            context="This value is used as minimum denominator to prevent division by zero",
        )
        validate_positive(
            "epsilon_P",
            epsilon_P,
            context="This value is used as minimum denominator to prevent division by zero",
        )

        # Validate trigger_factor values - allow negative (inverts gate logic)
        # but warn on extreme values outside [-10, 10]
        for name, value in [
            ("risk_trigger_factor", risk_trigger_factor),
            ("profit_trigger_factor", profit_trigger_factor),
        ]:
            if isinstance(value, bool):
                raise TypeError(f"{name} must be numeric, got bool")
            if math.isnan(value):
                raise ValueError(f"{name} must be a finite number, got NaN")
            if math.isinf(value):
                raise ValueError(
                    f"{name} must be a finite number, got {value}. "
                    "Infinite trigger factor makes the Bayesian gate permanently pass "
                    "(posterior probability of exceeding infinity is always 0)."
                )
            if value == 0.0:
                raise ValueError(
                    f"{name} must be non-zero. A zero threshold causes the "
                    "gate to always fail because P(|Delta|>=0) = 1.0."
                )
            if not (-10.0 <= value <= 10.0):
                logger.warning(
                    f"{name}={value} is outside recommended range [-10, 10]. "
                    "Extreme values may indicate misconfiguration. "
                    "Negative values invert gate logic (trigger on decreases)."
                )

        # Validate probability and threshold params (fail-OPEN prevention)
        if isinstance(trigger_confidence_prob, bool):
            raise TypeError("trigger_confidence_prob must be numeric, got bool")
        validate_range(
            "trigger_confidence_prob",
            trigger_confidence_prob,
            0.0,
            1.0,
            inclusive_lower=False,
            inclusive_upper=True,
            check_nan=True,
        )

        # Validate remaining threshold parameters for NaN/Inf.
        # NaN in any threshold causes the corresponding gate to permanently
        # fail due to IEEE 754 comparison semantics (e.g., score >= NaN is
        # always False). complexity_floor NaN is especially dangerous because
        # override_eligible depends on the complexity gate passing.
        for _name, _val in [
            ("novelty_N0", novelty_N0),
            ("novelty_k", novelty_k),
            ("novelty_threshold", novelty_threshold),
            ("complexity_floor", complexity_floor),
            ("quality_min_score", quality_min_score),
            ("utility_threshold", utility_threshold),
        ]:
            if isinstance(_val, bool):
                raise TypeError(f"{_name} must be numeric, got bool")
            if not math.isfinite(_val):
                raise ValueError(f"{_name} must be a finite number, got {_val}")
            if _name == "novelty_k" and _val <= 0:
                raise ValueError(
                    f"novelty_k must be strictly positive (logistic steepness parameter), "
                    f"got {_val}. A zero or negative value makes the gate score-insensitive."
                )
            if (
                _name
                in (
                    "novelty_N0",
                    "novelty_threshold",
                    "complexity_floor",
                    "quality_min_score",
                )
                and _val < 0
            ):
                raise ValueError(
                    f"{_name} must be non-negative, got {_val}. "
                    "A negative threshold trivially passes the gate, disabling the governance control."
                )

        self.epsilon_R = epsilon_R
        self.epsilon_P = epsilon_P
        self.risk_trigger_factor = risk_trigger_factor
        self.profit_trigger_factor = profit_trigger_factor
        self.trigger_confidence_prob = trigger_confidence_prob
        self.novelty_N0 = novelty_N0
        self.novelty_k = novelty_k
        self.novelty_threshold = novelty_threshold
        self.complexity_floor = complexity_floor
        self.quality_min_score = quality_min_score
        self.quality_no_zero_subscore = quality_no_zero_subscore
        self.utility_threshold = utility_threshold

        self.bayesian = BayesianPosterior()
        self._prometheus_exporter = prometheus_exporter

    def evaluate_all(
        self,
        risk_baseline: float,
        risk_proposed: float,
        profit_baseline: float,
        profit_proposed: float,
        novelty_score: float,
        complexity_score: float,
        quality_score: float,
        quality_subscores: list[float],
        utility_result: UtilityResult,
    ) -> GateEvaluationResult:
        """Evaluate proposal against all gates.

        Args:
            risk_baseline: Baseline risk value
            risk_proposed: Proposed risk value
            profit_baseline: Baseline profit value
            profit_proposed: Proposed profit value
            novelty_score: Novelty score N ∈ [0,1]
            complexity_score: Complexity score C_norm ∈ [0,1]
            quality_score: Quality score Q ∈ [0,1]
            quality_subscores: Individual quality sub-scores
            utility_result: Result from utility calculation

        Returns:
            GateEvaluationResult with all gate results

        Raises:
            ValueError: If normalized scores are outside [0, 1] range

        """
        # QG67-G3: Reject bool inputs for numeric baseline/proposed parameters.
        # bool is subclass of int in Python — silently coerces True→1, False→0.
        # Pattern consistency with GateEvaluator.__init__ bool guards.
        for _name, _val in [
            ("risk_baseline", risk_baseline),
            ("risk_proposed", risk_proposed),
            ("profit_baseline", profit_baseline),
            ("profit_proposed", profit_proposed),
        ]:
            if isinstance(_val, bool):
                raise TypeError(f"{_name} must be numeric, got bool")

        # Validate normalized scores are in valid range
        for name, score in [
            ("novelty_score", novelty_score),
            ("complexity_score", complexity_score),
            ("quality_score", quality_score),
        ]:
            validate_normalized(name, score)
        for i, subscore in enumerate(quality_subscores):
            validate_normalized(f"quality_subscores[{i}]", subscore)

        gates = {}

        # Risk gate
        start_time = time.time()
        gates[GateType.RISK] = self._evaluate_risk_gate(risk_baseline, risk_proposed)
        if self._prometheus_exporter:
            latency = time.time() - start_time
            self._prometheus_exporter.record_gate_evaluation(
                gate_type="risk",
                passed=gates[GateType.RISK].passed,
                value=gates[GateType.RISK].value,
                latency=latency,
            )

        # Profit gate
        start_time = time.time()
        gates[GateType.PROFIT] = self._evaluate_profit_gate(
            profit_baseline,
            profit_proposed,
        )
        if self._prometheus_exporter:
            latency = time.time() - start_time
            self._prometheus_exporter.record_gate_evaluation(
                gate_type="profit",
                passed=gates[GateType.PROFIT].passed,
                value=gates[GateType.PROFIT].value,
                latency=latency,
            )

        # Novelty gate
        start_time = time.time()
        gates[GateType.NOVELTY] = self._evaluate_novelty_gate(novelty_score)
        if self._prometheus_exporter:
            latency = time.time() - start_time
            self._prometheus_exporter.record_gate_evaluation(
                gate_type="novelty",
                passed=gates[GateType.NOVELTY].passed,
                value=gates[GateType.NOVELTY].value,
                latency=latency,
            )

        # Complexity floor
        start_time = time.time()
        gates[GateType.COMPLEXITY] = self._evaluate_complexity_gate(complexity_score)
        if self._prometheus_exporter:
            latency = time.time() - start_time
            self._prometheus_exporter.record_gate_evaluation(
                gate_type="complexity",
                passed=gates[GateType.COMPLEXITY].passed,
                value=gates[GateType.COMPLEXITY].value,
                latency=latency,
            )

        # Quality gate
        start_time = time.time()
        gates[GateType.QUALITY] = self._evaluate_quality_gate(
            quality_score,
            quality_subscores,
        )
        if self._prometheus_exporter:
            latency = time.time() - start_time
            self._prometheus_exporter.record_gate_evaluation(
                gate_type="quality",
                passed=gates[GateType.QUALITY].passed,
                value=gates[GateType.QUALITY].value,
                latency=latency,
            )

        # Utility LCB gate
        start_time = time.time()
        gates[GateType.UTILITY] = self._evaluate_utility_gate(utility_result)
        if self._prometheus_exporter:
            latency = time.time() - start_time
            self._prometheus_exporter.record_gate_evaluation(
                gate_type="utility",
                passed=gates[GateType.UTILITY].passed,
                value=gates[GateType.UTILITY].value,
                latency=latency,
            )

        # Aggregate results
        all_passed = all(g.passed for g in gates.values())

        # Override eligibility: failed but not on complexity floor
        override_eligible = not all_passed and gates[GateType.COMPLEXITY].passed

        # Minimum confidence across gates (filter NaN to avoid min() order-dependence)
        confidences = [
            g.confidence
            for g in gates.values()
            if g.confidence is not None and not math.isnan(g.confidence)
        ]
        min_confidence = min(confidences) if confidences else 0.0

        return GateEvaluationResult(
            gates=gates,
            all_passed=all_passed,
            override_eligible=override_eligible,
            min_confidence=min_confidence,
        )

    def evaluate_risk_gate(
        self,
        baseline: float,
        proposed: float,
    ) -> GateResult:
        """Evaluate risk gate: P(Δ ≥ 2 | data) must be < 0.95 to pass.

        This is the public interface for single-gate risk evaluation.
        Use evaluate_all() for full gate evaluation.

        Args:
            baseline: Baseline risk value
            proposed: Proposed risk value

        Returns:
            GateResult with pass/fail, posterior probability, and confidence

        Example:
            >>> evaluator = GateEvaluator()
            >>> result = evaluator.evaluate_risk_gate(baseline=0.1, proposed=0.3)
            >>> if not result.passed:
            ...     print(f"Risk gate failed: {result.message}")

        """
        return self._evaluate_risk_gate(baseline, proposed)

    def evaluate_profit_gate(
        self,
        baseline: float,
        proposed: float,
    ) -> GateResult:
        """Evaluate profit gate: P(|Δ| ≥ 2 | data) must be < 0.95 to pass.

        This is the public interface for single-gate profit evaluation.
        Use evaluate_all() for full gate evaluation.

        Args:
            baseline: Baseline profit value
            proposed: Proposed profit value

        Returns:
            GateResult with pass/fail, posterior probability, and confidence

        Example:
            >>> evaluator = GateEvaluator()
            >>> result = evaluator.evaluate_profit_gate(baseline=1000, proposed=2500)
            >>> if not result.passed:
            ...     print(f"Profit gate failed: {result.message}")

        """
        return self._evaluate_profit_gate(baseline, proposed)

    def evaluate_novelty_gate(
        self,
        novelty_score: float,
    ) -> GateResult:
        """Evaluate novelty gate: G(N) ≥ 0.8 to pass.

        This is the public interface for single-gate novelty evaluation.
        Use evaluate_all() for full gate evaluation.

        Args:
            novelty_score: Novelty score N ∈ [0,1]

        Returns:
            GateResult with pass/fail, gate value, and confidence

        Example:
            >>> evaluator = GateEvaluator()
            >>> result = evaluator.evaluate_novelty_gate(novelty_score=0.75)
            >>> if not result.passed:
            ...     print(f"Novelty gate failed: {result.message}")

        """
        if not 0.0 <= novelty_score <= 1.0:
            logger.warning(
                f"novelty_score={novelty_score} outside expected range [0,1]. "
                "Evaluation will proceed but results may be unexpected."
            )
        return self._evaluate_novelty_gate(novelty_score)

    def evaluate_complexity_gate(
        self,
        complexity_score: float,
    ) -> GateResult:
        """Evaluate complexity floor: C_norm ≥ 0.5 to pass.

        This is a hard requirement - cannot be overridden.
        This is the public interface for single-gate complexity evaluation.
        Use evaluate_all() for full gate evaluation.

        Args:
            complexity_score: Complexity score C_norm ∈ [0,1]

        Returns:
            GateResult with pass/fail and confidence

        Example:
            >>> evaluator = GateEvaluator()
            >>> result = evaluator.evaluate_complexity_gate(complexity_score=0.45)
            >>> if not result.passed:
            ...     print("Hard requirement not met - cannot be overridden")

        """
        if not 0.0 <= complexity_score <= 1.0:
            logger.warning(
                f"complexity_score={complexity_score} outside expected range [0,1]. "
                "Evaluation will proceed but results may be unexpected."
            )
        return self._evaluate_complexity_gate(complexity_score)

    def evaluate_quality_gate(
        self,
        quality_score: float,
        subscores: list[float],
    ) -> GateResult:
        """Evaluate quality gate: Q ≥ 0.7 AND no zero sub-scores.

        This is the public interface for single-gate quality evaluation.
        Use evaluate_all() for full gate evaluation.

        Args:
            quality_score: Quality score Q ∈ [0,1]
            subscores: Individual quality sub-scores

        Returns:
            GateResult with pass/fail and confidence

        Example:
            >>> evaluator = GateEvaluator()
            >>> result = evaluator.evaluate_quality_gate(
            ...     quality_score=0.75,
            ...     subscores=[0.8, 0.7, 0.75]
            ... )
            >>> if not result.passed:
            ...     print(f"Quality gate failed: {result.message}")

        """
        if not 0.0 <= quality_score <= 1.0:
            logger.warning(
                f"quality_score={quality_score} outside expected range [0,1]. "
                "Evaluation will proceed but results may be unexpected."
            )
        out_of_range = [s for s in subscores if not 0.0 <= s <= 1.0]
        if out_of_range:
            logger.warning(
                f"subscores contain values outside [0,1]: {out_of_range}. "
                "Evaluation will proceed but results may be unexpected."
            )
        return self._evaluate_quality_gate(quality_score, subscores)

    def evaluate_utility_gate(
        self,
        utility_result: UtilityResult,
    ) -> GateResult:
        """Evaluate utility LCB gate: LCB(U) > θ to pass.

        This is the public interface for single-gate utility evaluation.
        Use evaluate_all() for full gate evaluation.

        Args:
            utility_result: Result from utility calculation

        Returns:
            GateResult with pass/fail and confidence

        Example:
            >>> evaluator = GateEvaluator()
            >>> result = evaluator.evaluate_utility_gate(utility_result)
            >>> if not result.passed:
            ...     print(f"Utility gate failed: {result.message}")

        """
        return self._evaluate_utility_gate(utility_result)

    def _evaluate_risk_gate(
        self,
        baseline: float,
        proposed: float,
    ) -> GateResult:
        """Internal risk gate evaluation.

        ΔRisk_norm = (R_prop - R_base) / max(|R_base|, ε_R)

        Bug 2 fix: Negative trigger_factor now correctly triggers on decreases.
        - Positive factor (e.g., 2.0): Triggers on large increases P(Δ >= t)
        - Negative factor (e.g., -2.0): Triggers on large decreases P(Δ <= t)
        """
        # Normalize
        delta_norm = (proposed - baseline) / max(abs(baseline), self.epsilon_R)

        # BH37-M1: Guard against NaN delta (from NaN inputs) — fail closed
        if not math.isfinite(delta_norm):
            return GateResult(
                gate_type=GateType.RISK,
                passed=False,
                value=delta_norm,
                threshold=self.risk_trigger_factor,
                confidence=0.0,
                posterior_probability=1.0,
                message=f"Non-finite delta_norm={delta_norm}: fail-closed",
            )

        # Bug 2 fix: Handle negative trigger_factor for left-tail probability
        if self.risk_trigger_factor < 0:
            # Negative factor: trigger on decreases (left tail)
            # P(Δ <= t) = 1 - P(Δ >= t) for continuous distribution
            raw_posterior = self.bayesian.compute_posterior(
                observed_delta=delta_norm,
                trigger_threshold=self.risk_trigger_factor,
            )
            posterior = 1.0 - raw_posterior
            message = f"P(Δ≤{self.risk_trigger_factor}) = {posterior:.3f}"
        else:
            # Positive factor: trigger on increases (right tail)
            posterior = self.bayesian.compute_posterior(
                observed_delta=delta_norm,
                trigger_threshold=self.risk_trigger_factor,
            )
            message = f"P(Δ≥{self.risk_trigger_factor}) = {posterior:.3f}"

        # Pass if probability of exceeding threshold is low
        passed = posterior < self.trigger_confidence_prob

        return GateResult(
            gate_type=GateType.RISK,
            passed=passed,
            value=delta_norm,
            threshold=self.risk_trigger_factor,
            confidence=1.0 - posterior,
            posterior_probability=posterior,
            message=message,
        )

    def _evaluate_profit_gate(
        self,
        baseline: float,
        proposed: float,
    ) -> GateResult:
        """Profit gate: P(|Δ| ≥ threshold | data) must be < 0.95 to pass.

        ΔProfit_norm = (P_prop - P_base) / max(|P_base|, ε_P)

        Bug 2 fix: Use abs(trigger_factor) since profit gate is symmetric.
        The profit gate checks for large changes in EITHER direction, so
        negative trigger factors should behave identically to positive ones.
        """
        # Normalize
        delta_norm = (proposed - baseline) / max(abs(baseline), self.epsilon_P)

        # BH37-M1: Guard against NaN delta (from NaN inputs) — fail closed
        if not math.isfinite(delta_norm):
            return GateResult(
                gate_type=GateType.PROFIT,
                passed=False,
                value=delta_norm,
                threshold=self.profit_trigger_factor,
                confidence=0.0,
                posterior_probability=1.0,
                message=f"Non-finite delta_norm={delta_norm}: fail-closed",
            )

        # Bug 2 fix: Use absolute value of trigger factor for symmetric check
        # Profit gate detects large changes in either direction
        threshold_magnitude = abs(self.profit_trigger_factor)

        # Compute posterior probability for large increase or decrease
        posterior_upper = self.bayesian.compute_posterior(
            observed_delta=delta_norm,
            trigger_threshold=threshold_magnitude,
        )
        # Clamp to [0, 1] to handle numerical precision issues
        posterior_lower = max(
            0.0,
            1.0
            - self.bayesian.compute_posterior(
                observed_delta=delta_norm,
                trigger_threshold=-threshold_magnitude,
            ),
        )
        posterior = min(1.0, posterior_upper + posterior_lower)

        # Pass if probability of exceeding threshold is low
        passed = posterior < self.trigger_confidence_prob

        return GateResult(
            gate_type=GateType.PROFIT,
            passed=passed,
            value=delta_norm,
            threshold=self.profit_trigger_factor,
            confidence=1.0 - posterior,
            posterior_probability=posterior,
            message=f"P(|Δ|≥{threshold_magnitude}) = {posterior:.3f}",
        )

    def _evaluate_novelty_gate(
        self,
        novelty_score: float,
    ) -> GateResult:
        """Novelty gate: G(N) ≥ 0.8 to pass.

        G(N) = 1 / (1 + e^{-k(N - N_0)})
        """
        # QG67-G2: Non-finite inputs fail-closed with zero confidence.
        # Without this guard, NaN produces misleading confidence=1.0 via
        # the clamping path (NaN→700→gate_value≈0→confidence≈1.0).
        if not math.isfinite(novelty_score):
            return GateResult(
                gate_type=GateType.NOVELTY,
                passed=False,
                value=float("nan"),
                threshold=self.novelty_threshold,
                confidence=0.0,
                message=f"Non-finite novelty_score={novelty_score}: fail-closed",
            )

        # Logistic function with overflow protection
        # math.exp() overflows for exponent > ~709, so clamp to safe range
        exponent = -self.novelty_k * (novelty_score - self.novelty_N0)
        exponent = max(-self._EXP_CLAMP_LIMIT, min(self._EXP_CLAMP_LIMIT, exponent))
        gate_value = 1.0 / (1.0 + math.exp(exponent))

        passed = gate_value >= self.novelty_threshold

        return GateResult(
            gate_type=GateType.NOVELTY,
            passed=passed,
            value=gate_value,
            threshold=self.novelty_threshold,
            confidence=gate_value if passed else 1.0 - gate_value,
            message=f"G(N={novelty_score:.2f}) = {gate_value:.3f}",
        )

    def _evaluate_complexity_gate(
        self,
        complexity_score: float,
    ) -> GateResult:
        """Complexity floor: C_norm ≥ 0.5 to pass.

        This is a hard requirement - cannot be overridden.
        """
        passed = complexity_score >= self.complexity_floor

        return GateResult(
            gate_type=GateType.COMPLEXITY,
            passed=passed,
            value=complexity_score,
            threshold=self.complexity_floor,
            confidence=1.0 if passed else 0.0,
            message="Hard requirement" if not passed else "Met",
        )

    def _evaluate_quality_gate(
        self,
        quality_score: float,
        subscores: list[float],
    ) -> GateResult:
        """Quality gate: Q ≥ 0.7 AND no zero sub-scores.

        Note: Empty subscores list is treated as a fail-safe condition,
        returning min_subscore=0.0 which triggers has_zero=True. This is
        intentional - proposals without quality sub-scores should not pass
        the quality gate. If empty subscores should pass, change to:
            min_subscore = min(subscores) if subscores else 1.0

        """
        # QG67-G1: NaN subscores are order-dependent under min() and bypass
        # the zero-check (NaN <= 0.0 is False). Treat NaN as zero (fail-safe).
        if subscores and any(math.isnan(s) for s in subscores):
            logger.warning("NaN in quality subscores — treating as zero (fail-safe)")
            subscores = [0.0 if math.isnan(s) else s for s in subscores]

        min_subscore = min(subscores) if subscores else 0.0
        has_zero = min_subscore <= 0.0 and self.quality_no_zero_subscore

        passed = quality_score >= self.quality_min_score and not has_zero

        message = ""
        if has_zero:
            message = f"Zero sub-score detected (min={min_subscore})"
        elif quality_score < self.quality_min_score:
            message = f"Below minimum ({quality_score:.2f} < {self.quality_min_score})"
        else:
            message = "Passed"

        # Confidence reflects certainty of measurement, not pass/fail status
        # Use quality_score directly - we're confident in the measured value
        return GateResult(
            gate_type=GateType.QUALITY,
            passed=passed,
            value=quality_score,
            threshold=self.quality_min_score,
            confidence=quality_score,
            message=message,
        )

    def _evaluate_utility_gate(
        self,
        utility_result: UtilityResult,
    ) -> GateResult:
        """Utility LCB gate: LCB(U) > θ to pass."""
        passed = utility_result.lcb > self.utility_threshold

        # Bug 3 fix: Confidence should reflect distance from threshold, not raw LCB
        # This ensures confidence aligns with pass/fail: confidence > 0.5 when passing
        lcb = utility_result.lcb
        # Compute margin from threshold for confidence calculation
        margin = lcb - self.utility_threshold

        # Sigmoid-based confidence: maps margin to (0, 1) range.
        # Positive margin (passing) -> confidence > 0.5
        # Negative margin (failing) -> confidence < 0.5
        # Guard against math.exp overflow for extreme margin values.
        if math.isinf(margin):
            confidence = 1.0 if margin > 0 else 0.0
        else:
            exponent = -margin
            exponent = max(-self._EXP_CLAMP_LIMIT, min(self._EXP_CLAMP_LIMIT, exponent))
            confidence = 1.0 / (1.0 + math.exp(exponent))

        return GateResult(
            gate_type=GateType.UTILITY,
            passed=passed,
            value=utility_result.lcb,
            threshold=self.utility_threshold,
            confidence=confidence,
            message=f"LCB={utility_result.lcb:.2f}, path={utility_result.decision_path}",
        )
