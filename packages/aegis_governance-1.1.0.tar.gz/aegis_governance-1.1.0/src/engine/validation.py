"""Shared validation helpers for engine modules.

Pure functions for parameter validation. Raises ValueError
with consistent, message-compatible error strings.
"""

import math


def validate_positive(name: str, value: float, *, context: str = "") -> None:
    """Raise ValueError if *value* is not strictly positive.

    Args:
        name: Parameter name (used in error message).
        value: The value to check.
        context: Optional extra sentence appended to the error message.

    Raises:
        TypeError: If value is a bool.
        ValueError: If value <= 0.

    """
    if isinstance(value, bool):
        msg = f"{name} must be positive, got bool"
        if context:
            msg = f"{msg}. {context}"
        raise TypeError(msg)
    if not math.isfinite(value) or value <= 0:
        msg = f"{name} must be positive, got {value}"
        if context:
            msg = f"{msg}. {context}"
        raise ValueError(msg)


def validate_range(
    name: str,
    value: float,
    lower: float,
    upper: float,
    *,
    inclusive_lower: bool = True,
    inclusive_upper: bool = True,
    check_nan: bool = True,
) -> None:
    """Raise ValueError if *value* is outside the specified range.

    Args:
        name: Parameter name (used in error message).
        value: The value to check.
        lower: Lower bound.
        upper: Upper bound.
        inclusive_lower: Whether the lower bound is inclusive (default True).
        inclusive_upper: Whether the upper bound is inclusive (default True).
        check_nan: If True (default), also reject NaN values. NaN passes all
            IEEE 754 comparisons silently, so the default rejects it to prevent
            silent governance gate bypass. Pass check_nan=False only when NaN
            is explicitly expected and handled by the caller.

    Raises:
        ValueError: If value is out of range (or NaN when check_nan is True).

    """
    if check_nan and math.isnan(value):
        lb = "[" if inclusive_lower else "("
        ub = "]" if inclusive_upper else ")"
        raise ValueError(f"{name} must be in {lb}{lower}, {upper}{ub}, got {value}")

    below = value < lower if inclusive_lower else value <= lower
    above = value > upper if inclusive_upper else value >= upper

    if below or above:
        lb = "[" if inclusive_lower else "("
        ub = "]" if inclusive_upper else ")"
        raise ValueError(f"{name} must be in {lb}{lower}, {upper}{ub}, got {value}")


def validate_normalized(name: str, value: float) -> None:
    """Raise ValueError if *value* is not in [0, 1].

    Args:
        name: Parameter name (used in error message).
        value: The value to check.

    Raises:
        TypeError: If value is a bool.
        ValueError: If value < 0 or value > 1.

    """
    if isinstance(value, bool):
        raise TypeError(f"{name} must be numeric, got bool")
    if not (0.0 <= value <= 1.0):
        raise ValueError(f"{name} must be in [0, 1], got {value}")


def validate_threshold_ordering(
    lower_name: str,
    lower_value: float,
    upper_name: str,
    upper_value: float,
) -> None:
    """Raise ValueError if lower_value >= upper_value.

    Args:
        lower_name: Name of the lower-bound parameter.
        lower_value: The lower value.
        upper_name: Name of the upper-bound parameter.
        upper_value: The upper value.

    Raises:
        ValueError: If lower_value >= upper_value.

    """
    if math.isnan(lower_value) or math.isnan(upper_value) or lower_value >= upper_value:
        raise ValueError(
            f"{lower_name} ({lower_value}) must be less than "
            f"{upper_name} ({upper_value})"
        )
