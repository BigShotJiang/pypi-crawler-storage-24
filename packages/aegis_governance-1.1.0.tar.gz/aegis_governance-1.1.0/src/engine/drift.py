"""KL Divergence Drift Detection

Monitors distribution drift between baseline and current data.
Triggers recalibration when thresholds exceeded.
"""

import hashlib
import json
import logging
import math
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .validation import validate_positive, validate_threshold_ordering

logger = logging.getLogger(__name__)


class DriftStatus(str, Enum):
    """Drift detection status."""

    NORMAL = "normal"  # KL < τ_warning
    WARNING = "warning"  # τ_warning ≤ KL < τ_critical
    CRITICAL = "critical"  # KL ≥ τ_critical


class DriftAction(str, Enum):
    """Recommended action based on drift status."""

    CONTINUE = "continue"
    ALERT_AND_CONTINUE = "alert_and_continue"
    HALT_AND_RECALIBRATE = "halt_and_recalibrate"


@dataclass
class DriftResult:
    """Result of drift detection."""

    status: DriftStatus
    kl_divergence: float
    action: DriftAction
    baseline_hash: str
    window_size: int
    message: Optional[str] = None

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return (
            f"DriftResult({self.status.value}, kl={self.kl_divergence:.4f}, "
            f"action={self.action.value})"
        )


class DriftMonitor:
    """Monitor distribution drift using KL divergence.

    D_KL(P || Q) = Σ P(x) log(P(x) / Q(x))

    Thresholds from ADR-001:
    - τ_warning: P90 of calibration data (default 0.3)
    - τ_critical: P99 of calibration data (default 0.5)
    """

    def __init__(
        self,
        tau_warning: float = 0.3,
        tau_critical: float = 0.5,
        window_days: int = 30,
        num_bins: int = 50,
        epsilon: float = 1e-10,
    ):
        """Initialize drift monitor.

        Args:
            tau_warning: Warning threshold (P90)
            tau_critical: Critical threshold (P99)
            window_days: Rolling window for baseline
            num_bins: Number of bins for histogram
            epsilon: Small value to prevent log(0)

        Raises:
            ValueError: If thresholds are non-finite, negative, or misordered.

        """
        if not math.isfinite(tau_warning):
            raise ValueError(f"tau_warning must be finite, got {tau_warning}")
        if not math.isfinite(tau_critical):
            raise ValueError(f"tau_critical must be finite, got {tau_critical}")
        if tau_warning < 0:
            raise ValueError(f"tau_warning must be non-negative, got {tau_warning}")
        if tau_critical < 0:
            raise ValueError(f"tau_critical must be non-negative, got {tau_critical}")
        validate_threshold_ordering(
            "tau_warning", tau_warning, "tau_critical", tau_critical
        )
        if not isinstance(num_bins, int) or isinstance(num_bins, bool):
            raise TypeError(
                f"num_bins must be an integer, got {type(num_bins).__name__}"
            )
        validate_positive("num_bins", num_bins)
        validate_positive("epsilon", epsilon)
        if not isinstance(window_days, int) or isinstance(window_days, bool):
            raise TypeError(
                f"window_days must be an integer, got {type(window_days).__name__}"
            )
        validate_positive("window_days", window_days)
        self.tau_warning = tau_warning
        self.tau_critical = tau_critical
        self.window_days = window_days
        self.num_bins = num_bins
        self.epsilon = epsilon

        self.baseline_distribution: Optional[list[float]] = None
        self.baseline_hash: Optional[str] = None
        self._baseline_min: Optional[float] = None
        self._baseline_max: Optional[float] = None

    def set_baseline(self, data: list[float]) -> str:
        """Set baseline distribution from historical data.

        Args:
            data: Historical values for baseline

        Returns:
            SHA-256 hash of baseline

        Raises:
            ValueError: If data is empty

        """
        if not data:
            raise ValueError(
                "Cannot set baseline with empty data. "
                "Provide at least one historical value."
            )
        finite_data = [v for v in data if math.isfinite(v)]
        if not finite_data:
            raise ValueError(
                "Baseline data contains no finite values. "
                "Provide at least one finite historical value."
            )
        self._baseline_min = min(finite_data)
        self._baseline_max = max(finite_data)
        self.baseline_distribution = self._to_histogram(
            finite_data,
            min_val=self._baseline_min,
            max_val=self._baseline_max,
        )
        self.baseline_hash = self._compute_hash(self.baseline_distribution)
        return self.baseline_hash

    def evaluate(
        self,
        current_window: list[float],
    ) -> DriftResult:
        """Evaluate drift of current window against baseline.

        Args:
            current_window: Recent values to compare

        Returns:
            DriftResult with status and recommended action

        Raises:
            ValueError: If baseline not set or current_window is empty

        """
        if self.baseline_distribution is None:
            raise ValueError("Baseline not set. Call set_baseline() first.")

        if not current_window:
            raise ValueError(
                "Cannot evaluate drift with empty current_window. "
                "Provide at least one observation."
            )

        finite_values = [v for v in current_window if math.isfinite(v)]
        if not finite_values:
            raise ValueError(
                "current_window contains no finite values. "
                "Provide at least one finite observation."
            )

        # Convert to histogram (use finite_values only — baseline was also
        # built from finite data; including Inf would inflate boundary bins).
        current_hist = self._to_histogram(
            finite_values,
            min_val=self._baseline_min,
            max_val=self._baseline_max,
        )

        # Compute KL divergence
        kl = self._compute_kl_divergence(current_hist, self.baseline_distribution)

        # Determine status and action
        if kl >= self.tau_critical:
            status = DriftStatus.CRITICAL
            action = DriftAction.HALT_AND_RECALIBRATE
            message = (
                f"Critical drift detected (KL={kl:.4f} ≥ τ_crit={self.tau_critical})"
            )
        elif kl >= self.tau_warning:
            status = DriftStatus.WARNING
            action = DriftAction.ALERT_AND_CONTINUE
            message = f"Drift warning (KL={kl:.4f} ≥ τ_warn={self.tau_warning})"
        else:
            status = DriftStatus.NORMAL
            action = DriftAction.CONTINUE
            message = f"No significant drift (KL={kl:.4f})"

        return DriftResult(
            status=status,
            kl_divergence=kl,
            action=action,
            baseline_hash=self.baseline_hash or "",
            window_size=len(finite_values),
            message=message,
        )

    def _to_histogram(
        self,
        data: list[float],
        min_val: Optional[float] = None,
        max_val: Optional[float] = None,
    ) -> list[float]:
        """Convert data to normalized histogram (probability distribution)."""
        if not data:
            logger.warning(
                "_to_histogram received empty data, returning uniform distribution. "
                "This may indicate a bug in the calling code."
            )
            return [1.0 / self.num_bins] * self.num_bins

        # Filter to finite values for range computation
        finite_data = [v for v in data if math.isfinite(v)]
        if not finite_data and min_val is None and max_val is None:
            return [1.0 / self.num_bins] * self.num_bins

        # Find range (or use provided range for consistent binning)
        min_val = (
            min_val
            if min_val is not None
            else (min(finite_data) if finite_data else 0.0)
        )
        max_val = (
            max_val
            if max_val is not None
            else (max(finite_data) if finite_data else 1.0)
        )

        # Handle edge case of constant range (avoid division by zero).
        # Use relative adjustment for large magnitudes where +-1.0 is
        # absorbed by IEEE 754 precision (values > 2^53).
        if min_val == max_val:
            adjustment = max(abs(min_val) * 1e-7, 1.0)
            min_val -= adjustment
            max_val += adjustment

        # Bin width
        bin_width = (max_val - min_val) / self.num_bins

        # Count bins
        hist = [0.0] * self.num_bins
        for value in data:
            if math.isnan(value):
                continue  # Skip NaN — cannot be meaningfully binned
            if not math.isfinite(value):
                # Inf/-inf go to boundary bins
                bin_idx = 0 if value == float("-inf") else self.num_bins - 1
            else:
                bin_idx = int((value - min_val) / bin_width)
                if bin_idx < 0:
                    bin_idx = 0
                elif bin_idx >= self.num_bins:
                    bin_idx = self.num_bins - 1
            hist[bin_idx] += 1

        # Normalize to probability distribution
        total = sum(hist)
        if total > 0:
            hist = [h / total for h in hist]
        else:
            # No data fell into bins — return uniform distribution
            hist = [1.0 / self.num_bins] * self.num_bins

        return hist

    def _compute_kl_divergence(
        self,
        p: list[float],
        q: list[float],
    ) -> float:
        """Compute KL divergence D_KL(P || Q).

        D_KL(P || Q) = Σ P(x) log(P(x) / Q(x))

        Raises:
            ValueError: If p and q have different lengths.
        """
        if len(p) != len(q):
            raise ValueError(
                f"Distribution lengths must match: len(p)={len(p)}, len(q)={len(q)}"
            )
        # Apply epsilon smoothing and re-normalize to maintain valid distributions
        p_smooth = [max(p_i, self.epsilon) for p_i in p]
        q_smooth = [max(q_i, self.epsilon) for q_i in q]
        p_sum = sum(p_smooth)
        q_sum = sum(q_smooth)
        if p_sum > 0:
            p_smooth = [x / p_sum for x in p_smooth]
        if q_sum > 0:
            q_smooth = [x / q_sum for x in q_smooth]

        kl = 0.0
        for p_i, q_i in zip(p_smooth, q_smooth):
            if p_i > 0:
                kl += p_i * math.log(p_i / q_i)

        return kl

    def _compute_hash(self, distribution: list[float]) -> str:
        """Compute SHA-256 hash of distribution."""
        data = json.dumps(distribution, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()

    def calibrate_thresholds(
        self,
        historical_kl_values: list[float],
        warning_percentile: float = 90,
        critical_percentile: float = 99,
    ) -> tuple[float, float]:
        """Calibrate thresholds from historical KL values.

        Per ADR-001: Use P90 for warning, P99 for critical.

        Args:
            historical_kl_values: KL divergence values from calibration period
            warning_percentile: Percentile for warning threshold
            critical_percentile: Percentile for critical threshold

        Returns:
            (tau_warning, tau_critical)

        Note:
            If computed thresholds violate tau_warning < tau_critical
            (e.g., due to insufficient data or pathological distribution),
            the original thresholds are returned with a warning logged.
        """
        if isinstance(warning_percentile, bool):
            raise TypeError(
                f"warning_percentile must be numeric, got bool ({warning_percentile})"
            )
        if isinstance(critical_percentile, bool):
            raise TypeError(
                f"critical_percentile must be numeric, got bool ({critical_percentile})"
            )
        if not (0 <= warning_percentile <= 100):
            raise ValueError(
                f"warning_percentile must be between 0 and 100, got {warning_percentile}"
            )
        if not (0 <= critical_percentile <= 100):
            raise ValueError(
                f"critical_percentile must be between 0 and 100, got {critical_percentile}"
            )
        validate_threshold_ordering(
            "warning_percentile",
            warning_percentile,
            "critical_percentile",
            critical_percentile,
        )

        if not historical_kl_values:
            return (self.tau_warning, self.tau_critical)

        # Filter non-finite values (NaN, inf) to prevent returning NaN
        # thresholds that would silently disable drift detection.
        finite_values = [v for v in historical_kl_values if math.isfinite(v)]

        if len(finite_values) < 2:
            logger.warning(
                "calibrate_thresholds requires at least 2 finite values, got "
                f"{len(finite_values)} finite out of {len(historical_kl_values)} total. "
                "Returning original thresholds."
            )
            return (self.tau_warning, self.tau_critical)

        sorted_values = sorted(finite_values)
        n = len(sorted_values)

        def percentile_index(percentile: float) -> int:
            # Nearest-rank percentile (1-based rank), clamped to valid range.
            rank = math.ceil((percentile / 100) * n)
            return min(max(rank - 1, 0), n - 1)

        # Calculate percentile indices
        warning_idx = percentile_index(warning_percentile)
        critical_idx = percentile_index(critical_percentile)

        new_tau_warning = sorted_values[warning_idx]
        new_tau_critical = sorted_values[critical_idx]

        # Validate threshold ordering (L5 fix)
        if new_tau_warning >= new_tau_critical:
            logger.warning(
                f"calibrate_thresholds produced invalid thresholds: "
                f"tau_warning={new_tau_warning} >= tau_critical={new_tau_critical}. "
                f"This can occur with insufficient data (n={n}) or pathological distributions. "
                f"Returning original thresholds: "
                f"tau_warning={self.tau_warning}, tau_critical={self.tau_critical}"
            )
            return (self.tau_warning, self.tau_critical)

        return (new_tau_warning, new_tau_critical)

    def update_thresholds(
        self,
        tau_warning: float,
        tau_critical: float,
    ) -> None:
        """Update thresholds after recalibration.

        Raises:
            ValueError: If thresholds are non-finite, negative, or misordered.

        """
        if not math.isfinite(tau_warning):
            raise ValueError(f"tau_warning must be finite, got {tau_warning}")
        if not math.isfinite(tau_critical):
            raise ValueError(f"tau_critical must be finite, got {tau_critical}")
        if tau_warning < 0:
            raise ValueError(f"tau_warning must be non-negative, got {tau_warning}")
        if tau_critical < 0:
            raise ValueError(f"tau_critical must be non-negative, got {tau_critical}")
        validate_threshold_ordering(
            "tau_warning", tau_warning, "tau_critical", tau_critical
        )
        self.tau_warning = tau_warning
        self.tau_critical = tau_critical
