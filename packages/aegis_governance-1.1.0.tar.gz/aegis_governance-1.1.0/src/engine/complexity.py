"""Complexity Decomposition

Implements DOS/Rubric complexity analysis:
C = C_S + C_D (Static + Dynamic)
"""

import math
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .validation import validate_positive, validate_range


class ComplexityMetric(str, Enum):
    """Individual complexity metrics."""

    # Static complexity (C_S)
    CYCLOMATIC = "cyclomatic"
    COGNITIVE = "cognitive"
    HALSTEAD = "halstead"
    LOC = "lines_of_code"
    DEPENDENCIES = "dependencies"

    # Dynamic complexity (C_D)
    COUPLING = "coupling"
    STATE_SPACE = "state_space"
    CONCURRENCY = "concurrency"
    DATA_FLOW = "data_flow"
    ERROR_PATHS = "error_paths"


@dataclass
class ComplexityScore:
    """Score for a single complexity metric."""

    metric: ComplexityMetric
    value: float
    normalized: float  # 0-1 scale
    weight: float
    is_static: bool


@dataclass
class ComplexityAnalysis:
    """Full complexity analysis result."""

    static_total: float  # C_S
    dynamic_total: float  # C_D
    combined_total: float  # C = C_S + C_D
    normalized: float  # C_norm ∈ [0,1]
    scores: dict[ComplexityMetric, ComplexityScore]
    meets_floor: bool  # C_norm >= 0.5

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        status = "MEETS_FLOOR" if self.meets_floor else "BELOW_FLOOR"
        return f"ComplexityAnalysis(C_norm={self.normalized:.3f}, {status})"


class ComplexityDecomposer:
    """Decompose code complexity into static and dynamic components.

    Static (C_S): Structural complexity measurable from code alone
    Dynamic (C_D): Runtime/behavioral complexity

    Asymmetric weighting: φ_D ≈ 20× φ_S
    """

    # Default weights for each metric
    DEFAULT_WEIGHTS = {
        # Static metrics
        ComplexityMetric.CYCLOMATIC: 0.25,
        ComplexityMetric.COGNITIVE: 0.25,
        ComplexityMetric.HALSTEAD: 0.15,
        ComplexityMetric.LOC: 0.15,
        ComplexityMetric.DEPENDENCIES: 0.20,
        # Dynamic metrics
        ComplexityMetric.COUPLING: 0.25,
        ComplexityMetric.STATE_SPACE: 0.20,
        ComplexityMetric.CONCURRENCY: 0.25,
        ComplexityMetric.DATA_FLOW: 0.15,
        ComplexityMetric.ERROR_PATHS: 0.15,
    }

    # Classification of metrics
    STATIC_METRICS = {
        ComplexityMetric.CYCLOMATIC,
        ComplexityMetric.COGNITIVE,
        ComplexityMetric.HALSTEAD,
        ComplexityMetric.LOC,
        ComplexityMetric.DEPENDENCIES,
    }

    DYNAMIC_METRICS = {
        ComplexityMetric.COUPLING,
        ComplexityMetric.STATE_SPACE,
        ComplexityMetric.CONCURRENCY,
        ComplexityMetric.DATA_FLOW,
        ComplexityMetric.ERROR_PATHS,
    }

    # Default complexity tax coefficients
    # Calibrated from alpha_eng = $200/hour (fully-loaded engineering cost)
    # phi_S = 0.5 × alpha_eng = $100/month/kLOC
    # phi_D = 10.0 × alpha_eng = $2000/month/service
    DEFAULT_ALPHA_ENG = 200.0  # $/hour
    DEFAULT_PHI_S = 100.0  # 0.5 × alpha_eng
    DEFAULT_PHI_D = 2000.0  # 10.0 × alpha_eng

    # Default weight for unknown metrics not in DEFAULT_WEIGHTS
    # Used as fallback in analyze() when a metric is not in the weights dict
    _DEFAULT_METRIC_WEIGHT = 0.1

    def __init__(
        self,
        complexity_floor: float = 0.5,
        normalization_max: float = 100.0,
        weights: Optional[dict[ComplexityMetric, float]] = None,
    ):
        """Initialize complexity decomposer.

        Args:
            complexity_floor: Minimum C_norm required (default 0.5)
            normalization_max: Max raw value for normalization
            weights: Custom metric weights

        """
        if isinstance(complexity_floor, bool):
            raise TypeError("complexity_floor must be numeric, got bool")
        validate_range("complexity_floor", complexity_floor, 0.0, 1.0, check_nan=True)
        validate_positive("normalization_max", normalization_max)

        self.complexity_floor = complexity_floor
        self.normalization_max = normalization_max
        self.weights = dict(weights) if weights else dict(self.DEFAULT_WEIGHTS)

    def analyze(
        self,
        metrics: dict[ComplexityMetric, float],
    ) -> ComplexityAnalysis:
        """Analyze complexity from raw metric values.

        Args:
            metrics: Raw metric values

        Returns:
            ComplexityAnalysis with decomposed scores

        """
        scores = {}
        static_sum = 0.0
        dynamic_sum = 0.0
        static_weight_sum = 0.0
        dynamic_weight_sum = 0.0

        for metric, value in metrics.items():
            if not math.isfinite(value):
                raise ValueError(f"Metric {metric.value} has non-finite value: {value}")
            is_static = metric in self.STATIC_METRICS
            weight = self.weights.get(metric, self._DEFAULT_METRIC_WEIGHT)
            normalized = max(0.0, min(1.0, value / self.normalization_max))

            score = ComplexityScore(
                metric=metric,
                value=value,
                normalized=normalized,
                weight=weight,
                is_static=is_static,
            )
            scores[metric] = score

            weighted = normalized * weight
            if is_static:
                static_sum += weighted
                static_weight_sum += weight
            else:
                dynamic_sum += weighted
                dynamic_weight_sum += weight

        # Normalize by weight sums
        static_total = static_sum / static_weight_sum if static_weight_sum > 0 else 0.0
        dynamic_total = (
            dynamic_sum / dynamic_weight_sum if dynamic_weight_sum > 0 else 0.0
        )

        # Combined (simple sum since both are normalized)
        combined_total = static_total + dynamic_total

        # Overall normalized (0-2 range mapped to 0-1)
        normalized = min(1.0, combined_total / 2.0)

        return ComplexityAnalysis(
            static_total=static_total,
            dynamic_total=dynamic_total,
            combined_total=combined_total,
            normalized=normalized,
            scores=scores,
            meets_floor=normalized >= self.complexity_floor,
        )

    def compute_delta(
        self,
        baseline: ComplexityAnalysis,
        proposed: ComplexityAnalysis,
    ) -> dict[str, float]:
        """Compute complexity delta between baseline and proposed.

        Negative delta = complexity reduction (good for refactoring path)

        Returns:
            Dict with static_delta, dynamic_delta, total_delta

        """
        return {
            "static_delta": proposed.static_total - baseline.static_total,
            "dynamic_delta": proposed.dynamic_total - baseline.dynamic_total,
            "total_delta": proposed.combined_total - baseline.combined_total,
            "normalized_delta": proposed.normalized - baseline.normalized,
        }

    # Upper bounds for phi_S and phi_D to catch misconfiguration (L47 fix)
    # phi_S: $/month/kLOC - $10,000/month/kLOC would be extreme
    # phi_D: $/month/service - $100,000/month/service would be extreme
    PHI_S_UPPER_BOUND: float = 10000.0
    PHI_D_UPPER_BOUND: float = 100000.0

    def compute_complexity_tax(
        self,
        delta: dict[str, float],
        phi_S: float = DEFAULT_PHI_S,
        phi_D: float = DEFAULT_PHI_D,
    ) -> float:
        """Compute dollar-denominated complexity tax.

        Tax = φ_S · ΔC_S + φ_D · ΔC_D

        Args:
            delta: Complexity delta from compute_delta()
            phi_S: Static complexity cost ($/month/kLOC), default 0.5 × alpha_eng.
                Must be in [0, 10000]. Values > 10000 suggest misconfiguration.
            phi_D: Dynamic complexity cost ($/month/service), default 10.0 × alpha_eng.
                Must be in [0, 100000]. Values > 100000 suggest misconfiguration.

        Returns:
            Complexity tax in dollars

        Raises:
            KeyError: If delta dict is missing required keys (static_delta, dynamic_delta)
            ValueError: If phi_S or phi_D are negative or exceed upper bounds

        """
        # Validate cost coefficients (M10 fix + L47 upper bound + NaN guard + BH36 bool)
        if isinstance(phi_S, bool):
            raise TypeError("phi_S must be numeric, got bool")
        if isinstance(phi_D, bool):
            raise TypeError("phi_D must be numeric, got bool")
        if math.isnan(phi_S) or phi_S < 0:
            raise ValueError(
                f"phi_S must be non-negative, got {phi_S}. "
                "Negative complexity costs are not meaningful."
            )
        if phi_S > self.PHI_S_UPPER_BOUND:
            raise ValueError(
                f"phi_S={phi_S} exceeds upper bound of {self.PHI_S_UPPER_BOUND}. "
                "This likely indicates misconfiguration. "
                "phi_S represents $/month/kLOC; typical values are 50-500."
            )
        if math.isnan(phi_D) or phi_D < 0:
            raise ValueError(
                f"phi_D must be non-negative, got {phi_D}. "
                "Negative complexity costs are not meaningful."
            )
        if phi_D > self.PHI_D_UPPER_BOUND:
            raise ValueError(
                f"phi_D={phi_D} exceeds upper bound of {self.PHI_D_UPPER_BOUND}. "
                "This likely indicates misconfiguration. "
                "phi_D represents $/month/service; typical values are 1000-10000."
            )

        required_keys = {"static_delta", "dynamic_delta"}
        missing = required_keys - delta.keys()
        if missing:
            raise KeyError(
                f"delta dict missing required keys: {missing}. "
                f"Expected keys from compute_delta(): {required_keys}"
            )
        for key in required_keys:
            val = delta[key]
            if not math.isfinite(val):
                raise ValueError(f"delta['{key}'] must be finite, got {val}")
        return phi_S * delta["static_delta"] + phi_D * delta["dynamic_delta"]

    def is_refactoring_eligible(
        self,
        delta: dict[str, float],
    ) -> bool:
        """Check if change qualifies for refactoring path.

        Refactoring path requires net complexity reduction.

        Args:
            delta: Complexity delta dict from compute_delta()

        Returns:
            True if total_delta < 0 (net complexity reduction)

        Raises:
            KeyError: If delta dict is missing required 'total_delta' key
        """
        if "total_delta" not in delta:
            raise KeyError(
                "delta dict missing required key 'total_delta'. "
                "Use compute_delta() to generate a valid delta dict."
            )
        return delta["total_delta"] < 0
