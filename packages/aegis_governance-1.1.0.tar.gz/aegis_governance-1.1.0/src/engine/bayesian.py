"""Bayesian Posterior Probability Calculator

Computes P(Δ ≥ threshold | observed_data) using Bayesian updating.

Prior Calibration Guide
-----------------------
The default priors (μ=0, σ=1, σ_L=0.5) encode the assumption that:
- μ=0: No expected change (neutral prior)
- σ=1: Moderate uncertainty about the true delta
- σ_L=0.5: Observation noise is moderate

For deployment, calibrate priors based on your domain:

1. **Conservative (risk-averse)**:
   - Use σ=0.5 (tighter prior) to require stronger evidence for changes
   - Use σ_L=1.0 (higher noise) to discount single observations

2. **Historical calibration**:
   - Collect historical delta values from your system
   - Use update_prior() to compute empirical mean/std
   - Example:
     ```python
     historical = [0.1, -0.05, 0.2, 0.15, ...]  # past deltas
     calculator = BayesianPosterior()
     new_mean, new_std = calculator.update_prior(historical)
     calculator = BayesianPosterior(prior_mean=new_mean, prior_std=new_std)
     ```

3. **Domain-specific adjustment**:
   - Financial: Use smaller σ (0.3-0.5) for tighter control
   - R&D: Use larger σ (1.5-2.0) for more exploration tolerance
   - Security: Use σ_L=0.3 to trust individual observations more

See: ADR-001-workflow-persistence.md for threshold calibration guidance.
See: ADR-006-posterior-predictive.md for posterior vs predictive distribution guidance.
"""

import math
from dataclasses import dataclass
from typing import Optional

from .validation import validate_positive


@dataclass
class PosteriorResult:
    """Result of Bayesian posterior computation."""

    probability: float  # P(Δ ≥ threshold | data)
    posterior_mean: float  # Updated mean
    posterior_std: float  # Updated standard deviation
    confidence: float  # 1 - probability
    predictive_std: Optional[float] = None  # Posterior predictive std (if computed)


class BayesianPosterior:
    """Compute Bayesian posterior probability for threshold exceedance.

    Uses conjugate normal-normal model:
    - Prior: N(μ_0, σ_0²)
    - Likelihood: N(observed, σ_L²)
    - Posterior: N(μ_post, σ_post²)
    """

    # Minimum std to prevent division by zero and numerical instability
    _MIN_STD: float = 1e-10

    # Fallback std when empirical variance is exactly zero (e.g., all observations identical).
    # Uses 0.1 as a conservative non-zero value to allow continued computation.
    _FALLBACK_STD: float = 0.1

    # Threshold for full empirical weight in update_prior().
    # At n=30 observations, empirical data receives full weight (1.0).
    # Below n=30, weight is n/30 (linear ramp-up).
    # Rationale: 30 samples provide reasonable convergence for Gaussian priors
    # (similar to CLT heuristic). Adjust if domain requires different calibration.
    _PRIOR_WEIGHT_THRESHOLD: int = 30

    def __init__(
        self,
        prior_mean: float = 0.0,
        prior_std: float = 1.0,
        likelihood_std: float = 0.5,
    ):
        """Initialize Bayesian calculator.

        Args:
            prior_mean: Prior mean for delta (default: 0 = no change expected).
                For historical calibration, use update_prior() to compute from data.
            prior_std: Prior standard deviation (default: 1.0 = moderate uncertainty).
                Smaller values (0.3-0.5) for conservative/risk-averse settings.
                Larger values (1.5-2.0) for exploratory/R&D settings.
                Must be positive (>0).
            likelihood_std: Observation noise (default: 0.5 = moderate noise).
                Smaller values trust observations more; larger values discount them.
                Must be positive (>0).

        Raises:
            ValueError: If prior_std or likelihood_std is not positive.

        Deployment Note:
            These defaults encode "neutral, moderately uncertain" assumptions.
            For production, calibrate using historical data via update_prior()
            or set domain-appropriate values. See module docstring for guidance.

        Example:
            >>> # Conservative financial setting
            >>> calc = BayesianPosterior(prior_mean=0.0, prior_std=0.5, likelihood_std=0.3)
            >>> # R&D exploration setting
            >>> calc = BayesianPosterior(prior_mean=0.0, prior_std=2.0, likelihood_std=1.0)

        """
        if not math.isfinite(prior_mean):
            raise ValueError(f"prior_mean must be finite, got {prior_mean}")
        validate_positive("prior_std", prior_std)
        validate_positive("likelihood_std", likelihood_std)

        self.prior_mean = prior_mean
        self.prior_std = prior_std
        self.likelihood_std = likelihood_std

    def compute_posterior(
        self,
        observed_delta: float,
        trigger_threshold: float,
        prior_mean: Optional[float] = None,
        prior_std: Optional[float] = None,
        likelihood_std: Optional[float] = None,
        use_predictive: bool = False,
    ) -> float:
        """Compute P(Δ ≥ threshold | observed_delta).

        Args:
            observed_delta: Observed normalized delta
            trigger_threshold: Threshold value (e.g., 2.0)
            prior_mean: Override prior mean
            prior_std: Override prior std
            likelihood_std: Override likelihood std
            use_predictive: If True, use posterior predictive distribution
                which accounts for observation noise in future predictions.
                This is more conservative and mathematically correct for
                decision-making about future observations. See ADR-006.

        Returns:
            Posterior probability that true delta exceeds threshold.
            If use_predictive=True, returns posterior predictive probability
            that a future observation will exceed threshold.

        Raises:
            ValueError: If prior_std or likelihood_std (override) is not positive.

        """
        # Validate call-site arguments
        if not math.isfinite(observed_delta):
            raise ValueError(f"observed_delta must be finite, got {observed_delta}")
        if not math.isfinite(trigger_threshold):
            raise ValueError(
                f"trigger_threshold must be finite, got {trigger_threshold}"
            )

        # Use overrides or defaults
        mu_0 = prior_mean if prior_mean is not None else self.prior_mean
        sigma_0 = prior_std if prior_std is not None else self.prior_std
        sigma_L = likelihood_std if likelihood_std is not None else self.likelihood_std

        # Validate overrides (prior_mean can be any finite value including negative)
        if not math.isfinite(mu_0):
            raise ValueError(f"prior_mean must be finite, got {mu_0}")
        validate_positive("prior_std", sigma_0)
        validate_positive("likelihood_std", sigma_L)

        # Compute posterior parameters
        prior_precision = 1.0 / (sigma_0**2)
        likelihood_precision = 1.0 / (sigma_L**2)

        posterior_precision = prior_precision + likelihood_precision
        posterior_variance = 1.0 / posterior_precision

        posterior_mean = posterior_variance * (
            (mu_0 * prior_precision) + (observed_delta * likelihood_precision)
        )

        posterior_std = math.sqrt(posterior_variance)

        # Determine which std to use for threshold computation
        if use_predictive:
            # Posterior predictive std includes observation noise
            # σ_pred = √(σ_post² + σ_L²)
            effective_std = math.sqrt(posterior_std**2 + sigma_L**2)
        else:
            effective_std = posterior_std

        # Clamp effective_std to prevent ZeroDivisionError from numerical precision
        effective_std = max(effective_std, self._MIN_STD)

        # Compute P(Δ ≥ threshold)
        # = 1 - Φ((threshold - μ_post) / σ_effective)
        z = (trigger_threshold - posterior_mean) / effective_std
        probability = 1.0 - self._standard_normal_cdf(z)

        return probability

    def compute_posterior_predictive(
        self,
        observed_delta: float,
        trigger_threshold: float,
        prior_mean: Optional[float] = None,
        prior_std: Optional[float] = None,
        likelihood_std: Optional[float] = None,
    ) -> float:
        """Compute P(Y_new ≥ threshold | observed_delta) using posterior predictive.

        The posterior predictive distribution accounts for both:
        1. Uncertainty about the latent parameter θ (posterior uncertainty)
        2. Observation noise in future measurements (likelihood noise)

        This is the correct distribution for making decisions about future
        realized values, not the underlying parameter. It is more conservative
        than the posterior distribution.

        Formula:
            σ_pred = √(σ_post² + σ_L²)
            P(Y_new ≥ t | y) = 1 - Φ((t - μ_post) / σ_pred)

        Args:
            observed_delta: Observed normalized delta
            trigger_threshold: Threshold value (e.g., 2.0)
            prior_mean: Override prior mean
            prior_std: Override prior std
            likelihood_std: Override likelihood std

        Returns:
            Posterior predictive probability that a future observation
            will exceed the threshold.

        Example:
            >>> calc = BayesianPosterior()
            >>> # Posterior: probability latent parameter exceeds threshold
            >>> p_post = calc.compute_posterior(1.5, 2.0)
            >>> # Posterior predictive: probability future observation exceeds threshold
            >>> p_pred = calc.compute_posterior_predictive(1.5, 2.0)
            >>> assert p_pred <= p_post  # Predictive is more conservative

        See Also:
            ADR-006-posterior-predictive.md for rationale and when to use.

        """
        return self.compute_posterior(
            observed_delta=observed_delta,
            trigger_threshold=trigger_threshold,
            prior_mean=prior_mean,
            prior_std=prior_std,
            likelihood_std=likelihood_std,
            use_predictive=True,
        )

    def compute_full(
        self,
        observed_delta: float,
        trigger_threshold: float,
        prior_mean: Optional[float] = None,
        prior_std: Optional[float] = None,
        likelihood_std: Optional[float] = None,
        use_predictive: bool = False,
    ) -> PosteriorResult:
        """Compute full posterior result with diagnostics.

        Args:
            observed_delta: Observed normalized delta
            trigger_threshold: Threshold value (e.g., 2.0)
            prior_mean: Override prior mean
            prior_std: Override prior std
            likelihood_std: Override likelihood std
            use_predictive: If True, use posterior predictive distribution.
                See ADR-006 for details.

        Returns:
            PosteriorResult with probability, mean, std, confidence,
            and optionally predictive_std

        Raises:
            ValueError: If prior_std or likelihood_std (override) is not positive.

        """
        # Validate call-site arguments
        if not math.isfinite(observed_delta):
            raise ValueError(f"observed_delta must be finite, got {observed_delta}")
        if not math.isfinite(trigger_threshold):
            raise ValueError(
                f"trigger_threshold must be finite, got {trigger_threshold}"
            )

        # Use overrides or defaults
        mu_0 = prior_mean if prior_mean is not None else self.prior_mean
        sigma_0 = prior_std if prior_std is not None else self.prior_std
        sigma_L = likelihood_std if likelihood_std is not None else self.likelihood_std

        # Validate overrides (prior_mean can be any finite value including negative)
        if not math.isfinite(mu_0):
            raise ValueError(f"prior_mean must be finite, got {mu_0}")
        validate_positive("prior_std", sigma_0)
        validate_positive("likelihood_std", sigma_L)

        # Compute posterior parameters
        prior_precision = 1.0 / (sigma_0**2)
        likelihood_precision = 1.0 / (sigma_L**2)

        posterior_precision = prior_precision + likelihood_precision
        posterior_variance = 1.0 / posterior_precision

        posterior_mean = posterior_variance * (
            (mu_0 * prior_precision) + (observed_delta * likelihood_precision)
        )

        posterior_std = math.sqrt(posterior_variance)

        # Compute posterior predictive std
        predictive_std = math.sqrt(posterior_std**2 + sigma_L**2)

        # Determine which std to use for threshold computation
        effective_std = predictive_std if use_predictive else posterior_std

        # Clamp effective_std to prevent ZeroDivisionError from numerical precision
        effective_std = max(effective_std, self._MIN_STD)

        # Compute probability
        z = (trigger_threshold - posterior_mean) / effective_std
        probability = 1.0 - self._standard_normal_cdf(z)

        return PosteriorResult(
            probability=probability,
            posterior_mean=posterior_mean,
            posterior_std=posterior_std,
            confidence=1.0 - probability,
            predictive_std=predictive_std,
        )

    def _standard_normal_cdf(self, z: float) -> float:
        """Approximate standard normal CDF using error function.

        Φ(z) = 0.5 * (1 + erf(z / sqrt(2)))
        """
        return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))

    def update_prior(
        self,
        observations: list[float],
        current_mean: Optional[float] = None,
        current_std: Optional[float] = None,
        ddof: int = 0,
    ) -> tuple[float, float]:
        """Update prior based on historical observations.

        Args:
            observations: List of historical delta values
            current_mean: Current prior mean
            current_std: Current prior std
            ddof: Delta degrees of freedom for variance calculation.
                0 = population variance (MLE, default, consistent with Bayesian updating)
                1 = sample variance (Bessel's correction, unbiased estimator)
                Use ddof=1 for small samples (n < 30) in conservative governance settings.
                Must be non-negative integer (0 or 1 recommended).

        Returns:
            (new_mean, new_std) updated prior parameters

        Raises:
            TypeError: If ddof is not an integer (or is bool).
            ValueError: If ddof is negative.

        """
        if isinstance(ddof, bool) or not isinstance(ddof, int):
            raise TypeError(f"ddof must be an integer, got {type(ddof).__name__}")
        if ddof < 0:
            raise ValueError(f"ddof must be non-negative, got {ddof}")
        if current_mean is not None:
            if isinstance(current_mean, bool):
                raise TypeError("current_mean must be a number, got bool")
            if not math.isfinite(current_mean):
                raise ValueError(f"current_mean must be finite, got {current_mean}")
        if current_std is not None:
            validate_positive("current_std", current_std)

        # Filter non-finite values (NaN, inf) to prevent silent propagation
        # into downstream posterior computations. Consistent with
        # DriftMonitor.set_baseline which also filters non-finite values.
        observations = [x for x in observations if math.isfinite(x)]

        if not observations:
            return (
                self.prior_mean if current_mean is None else current_mean,
                self.prior_std if current_std is None else current_std,
            )

        # Empirical mean and std — guard against OverflowError from extreme values
        n = len(observations)
        fallback = (
            current_mean if current_mean is not None else self.prior_mean,
            current_std if current_std is not None else self.prior_std,
        )
        try:
            empirical_mean = sum(observations) / n
            if not math.isfinite(empirical_mean):
                return fallback
            divisor = max(n - ddof, 1)  # Prevent division by zero when n=1 and ddof=1
            empirical_var = (
                sum((x - empirical_mean) ** 2 for x in observations) / divisor
            )
            if not math.isfinite(empirical_var):
                return fallback
            empirical_std = (
                math.sqrt(empirical_var) if empirical_var > 0 else self._FALLBACK_STD
            )
        except OverflowError:
            return fallback

        # Weighted combination with current prior
        mu_0 = fallback[0]
        sigma_0 = fallback[1]

        # More observations = more weight to empirical
        # Full weight at _PRIOR_WEIGHT_THRESHOLD observations (default: 30)
        weight = min(n / self._PRIOR_WEIGHT_THRESHOLD, 1.0)

        new_mean = (1 - weight) * mu_0 + weight * empirical_mean
        # Combine in variance space to avoid underestimating uncertainty
        # (Jensen's inequality: linear interp of stds < sqrt of interp of vars).
        # Guard against OverflowError / 0.0*inf=NaN when sigma values are extreme.
        try:
            prior_var = sigma_0**2 if weight < 1.0 else 0.0
            emp_var = empirical_std**2 if weight > 0.0 else 0.0
            new_var = (1 - weight) * prior_var + weight * emp_var
            new_std = math.sqrt(new_var)
        except (OverflowError, ValueError):
            new_std = max(sigma_0, empirical_std)

        return (new_mean, new_std)
