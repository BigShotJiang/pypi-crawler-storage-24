"""Utility Function Calculator

Implements Rubric v2.1 vectorized utility function:
U = (ΔP_H + γ·ΔV_L) + κ·ΔR - (φ_S·ΔC_S + φ_D·ΔC_D) - ΔOPEX
"""

import logging
import math
from dataclasses import dataclass
from typing import Optional

from .complexity import ComplexityDecomposer
from .validation import validate_range

try:
    import scipy.stats  # noqa: F401 — availability check only

    _HAS_SCIPY = True
except ImportError:
    _HAS_SCIPY = False

# Precomputed z-scores for common confidence levels (scipy.stats.norm.ppf).
# Used as fallback when scipy is not installed.  Exact dict.get() lookup is
# safe — all callers derive confidence as ``1 - lcb_alpha`` where lcb_alpha
# is one of a small set of IEEE-754-exact floats (0.05, 0.10, 0.20, 0.30, …).
_FALLBACK_Z_SCORES: dict[float, float] = {
    0.70: 0.5244005127080407,
    0.75: 0.6744897501960817,
    0.80: 0.8416212335729143,
    0.85: 1.0364333894937894,
    0.90: 1.2815515655446004,
    0.95: 1.6448536269514720,
    0.975: 1.959963984540054,
    0.99: 2.3263478740408408,
    0.995: 2.5758293035489004,
    0.999: 3.090232306167813,
}

logger = logging.getLogger(__name__)


@dataclass
class ThreePointEstimate:
    """PERT distribution three-point estimate."""

    best: float  # Optimistic (a)
    likely: float  # Most likely (m)
    worst: float  # Pessimistic (b)

    def __post_init__(self) -> None:
        """Validate PERT constraint: best <= likely <= worst, all finite."""
        for _name, _val in [
            ("best", self.best),
            ("likely", self.likely),
            ("worst", self.worst),
        ]:
            if isinstance(_val, bool):
                raise TypeError(f"PERT {_name} must be numeric, got bool")
            if not math.isfinite(_val):
                raise ValueError(f"PERT {_name} must be finite, got {_val}")
        if not (self.best <= self.likely <= self.worst):
            raise ValueError(
                f"PERT requires best <= likely <= worst, got "
                f"best={self.best}, likely={self.likely}, worst={self.worst}"
            )

    @property
    def expected(self) -> float:
        """PERT expected value: E[X] = (a + 4m + b) / 6"""
        return (self.best + 4 * self.likely + self.worst) / 6

    @property
    def variance(self) -> float:
        """PERT variance approximation: Var[X] = ((b - a) / 6)^2

        This is the simplified variance formula commonly used with PERT.
        However, the true Beta-PERT variance depends on mode position and
        varies by approximately ±22-40% from this approximation:

        - Symmetric mode (m = (a+b)/2): Underestimates by ~22%
        - Skewed mode (m near a or b): Overestimates by up to ~40%

        The true Beta-PERT variance is:
            α = 1 + 4*(m-a)/(b-a)
            β = 1 + 4*(b-m)/(b-a)
            Var[X] = (b-a)² * αβ / ((α+β)²(α+β+1))

        For governance decisions requiring precise uncertainty bounds,
        consider using the true Beta distribution variance formula or
        applying a safety factor to this approximation.

        See: docs/analysis/multi-model-coherence-review.md (P1*)

        Returns:
            Approximate PERT variance using the (range/6)² formula.

        """
        return ((self.worst - self.best) / 6) ** 2

    @property
    def std_dev(self) -> float:
        """Standard deviation."""
        return math.sqrt(self.variance)


@dataclass
class ComplexityBreakdown:
    """Complexity decomposition into static and dynamic."""

    static: float  # C_S: structural complexity
    dynamic: float  # C_D: runtime complexity

    def __post_init__(self) -> None:
        """Validate fields are numeric (not bool) and finite."""
        for _name, _val in [("static", self.static), ("dynamic", self.dynamic)]:
            if isinstance(_val, bool):
                raise TypeError(
                    f"ComplexityBreakdown.{_name} must be numeric, got bool"
                )
            if not math.isfinite(_val):
                raise ValueError(
                    f"ComplexityBreakdown.{_name} must be finite, got {_val}"
                )

    @property
    def total(self) -> float:
        """Total complexity: C = C_S + C_D"""
        return self.static + self.dynamic


@dataclass
class UtilityComponents:
    """Breakdown of utility calculation components."""

    profit_high_conf: float
    value_low_conf: float
    risk_adjustment: float
    complexity_tax: float
    opex_delta: float

    @property
    def gross_value(self) -> float:
        """Gross value before costs."""
        return self.profit_high_conf + self.value_low_conf + self.risk_adjustment

    @property
    def total_cost(self) -> float:
        """Total costs."""
        return self.complexity_tax + self.opex_delta


@dataclass
class UtilityResult:
    """Result of utility calculation."""

    raw: float  # U
    variance: float  # Var(U)
    lcb: float  # Lower confidence bound
    components: Optional[UtilityComponents]  # None when estimated externally
    decision_path: str  # INVESTMENT or REFACTORING

    def __post_init__(self) -> None:
        # NaN in any field causes silent IEEE 754 failures (nan > threshold is always
        # False), making the utility gate permanently fail with no diagnostic.  Reject
        # NaN early.  Note: -inf IS intentionally allowed for raw/lcb (it signals
        # extremely low utility and correctly fails the gate with a meaningful value).
        for _name, _val in [
            ("raw", self.raw),
            ("variance", self.variance),
            ("lcb", self.lcb),
        ]:
            if isinstance(_val, bool):
                raise ValueError(f"UtilityResult.{_name} must be numeric, got bool")
            if math.isnan(_val):
                raise ValueError(f"UtilityResult.{_name} must not be NaN, got {_val}")
        # variance must be finite and non-negative (±inf or negative variance
        # is not physically meaningful and would corrupt std_dev computation).
        if not math.isfinite(self.variance) or self.variance < 0:
            raise ValueError(
                f"UtilityResult.variance must be finite and non-negative, got {self.variance}"
            )

    @property
    def std_dev(self) -> float:
        """Standard deviation of utility."""
        if self.variance < 0:
            logger.warning(
                "UtilityResult.variance is negative (%.6f); clamping to 0 for std_dev",
                self.variance,
            )
        return math.sqrt(max(0.0, self.variance))


class UtilityCalculator:
    """Calculate vectorized utility per Rubric v2.1.

    U = (ΔP_H + γ·ΔV_L) + κ·ΔR - (φ_S·ΔC_S + φ_D·ΔC_D) - ΔOPEX
    """

    def __init__(
        self,
        gamma: float = 0.3,  # Discount for uncertain value
        kappa: float = 1.0,  # Risk coefficient
        phi_S: float = 100.0,  # Static complexity cost ($/point) - per frozen spec
        phi_D: float = 2000.0,  # Dynamic complexity cost ($/point) - per frozen spec
        lcb_alpha: float = 0.05,  # LCB confidence level (95%)
        migration_budget: float = 5000.0,  # Refactoring path budget
    ):
        # Validate lcb_alpha at construction time (fail-fast)
        validate_range(
            "lcb_alpha",
            lcb_alpha,
            0.0,
            1.0,
            inclusive_lower=False,
            inclusive_upper=False,
            check_nan=True,
        )

        # Validate phi_S bounds (L47 — match ComplexityDecomposer validation)
        if isinstance(phi_S, bool):
            raise TypeError("phi_S must be numeric, got bool")
        validate_range(
            "phi_S",
            phi_S,
            0,
            ComplexityDecomposer.PHI_S_UPPER_BOUND,
            check_nan=True,
        )
        # Validate phi_D bounds (L47 — match ComplexityDecomposer validation)
        if isinstance(phi_D, bool):
            raise TypeError("phi_D must be numeric, got bool")
        validate_range(
            "phi_D",
            phi_D,
            0,
            ComplexityDecomposer.PHI_D_UPPER_BOUND,
            check_nan=True,
        )

        for _name, _val in [
            ("gamma", gamma),
            ("kappa", kappa),
            ("migration_budget", migration_budget),
        ]:
            if isinstance(_val, bool):
                raise TypeError(f"{_name} must be numeric, got bool")
            if not math.isfinite(_val):
                raise ValueError(f"{_name} must be a finite number, got {_val}")

        self.gamma = gamma
        self.kappa = kappa
        self.phi_S = phi_S
        self.phi_D = phi_D
        self.lcb_alpha = lcb_alpha
        self.migration_budget = migration_budget

        # z-score for LCB (95% = 1.645)
        self.z_alpha = self._get_z_score(1 - lcb_alpha)

    def _get_z_score(self, confidence: float) -> float:
        """Get z-score for given confidence level.

        Uses scipy.stats.norm.ppf() when available.  When scipy is absent,
        falls back to a precomputed lookup table for common confidence levels.

        Args:
            confidence: Confidence level in (0, 1)

        Returns:
            Z-score (standard normal quantile) for the given confidence level

        Raises:
            ValueError: If confidence is not in open interval (0, 1).
            ImportError: If scipy is absent *and* confidence is not in the
                fallback table.

        """
        if not math.isfinite(confidence):
            raise ValueError(
                f"confidence must be a finite number in (0, 1), got {confidence}"
            )
        if confidence <= 0.0 or confidence >= 1.0:
            raise ValueError(
                f"confidence must be in open interval (0, 1), got {confidence}. "
                f"Values 0 and 1 would produce infinite z-scores."
            )
        if _HAS_SCIPY:
            from scipy.stats import norm

            return float(norm.ppf(confidence))
        z = _FALLBACK_Z_SCORES.get(confidence)
        if z is not None:
            return z
        raise ImportError(
            f"scipy is required for z-score calculation at confidence={confidence}. "
            f"Without scipy, only these confidence levels are supported: "
            f"{sorted(_FALLBACK_Z_SCORES.keys())}. "
            f"Install with: pip install aegis-governance[engine]"
        )

    def calculate(
        self,
        profit_estimate: ThreePointEstimate,
        risk_estimate: ThreePointEstimate,
        complexity: ComplexityBreakdown,
        value_low_conf: float = 0.0,
        value_variance: float = 0.0,
        opex_delta: float = 0.0,
        cov_pv: Optional[float] = None,
        cov_pr: Optional[float] = None,
        cov_vr: Optional[float] = None,
    ) -> UtilityResult:
        """Calculate utility with full breakdown.

        Args:
            profit_estimate: Three-point profit estimate
            risk_estimate: Three-point risk estimate
            complexity: Static/dynamic complexity breakdown (static and dynamic
                should each be in [0, 1] range for normalized values, or
                reasonable bounds for raw deltas)
            value_low_conf: Low-confidence value (discounted by γ)
            value_variance: Variance of low-confidence value
            opex_delta: Change in operational expenses
            cov_pv: Covariance between profit and value estimates.
                If None (default), assumes independence (cov=0).
            cov_pr: Covariance between profit and risk estimates.
                If None (default), assumes independence (cov=0).
            cov_vr: Covariance between value and risk estimates.
                If None (default), assumes independence (cov=0).

        Returns:
            UtilityResult with raw utility, LCB, and components

        Note:
            The variance calculation uses Var(aX + bY) = a²Var(X) + b²Var(Y) + 2ab·Cov(X,Y).
            The factor of 2 on covariance terms comes from the standard variance formula.
            Omitting covariance when estimates are correlated will underestimate variance,
            leading to overly narrow confidence bounds. See multi-model-coherence-review.md (U1+).

        """
        # Validate calculate() input parameters for finiteness/non-negativity
        # (BH43-M3: negative value_variance silently floored to 0, producing
        # overly optimistic LCB; BH43-L2: NaN/Inf propagation through value_low_conf/opex_delta;
        # BH43-L3: NaN/Inf covariance terms corrupt variance computation)
        for _name, _val in [
            ("value_low_conf", value_low_conf),
            ("opex_delta", opex_delta),
        ]:
            if isinstance(_val, bool):
                raise TypeError(f"{_name} must be numeric, got bool")
            if not math.isfinite(_val):
                raise ValueError(f"{_name} must be finite, got {_val}")
        if isinstance(value_variance, bool):
            raise TypeError("value_variance must be numeric, got bool")
        if not math.isfinite(value_variance) or value_variance < 0:
            raise ValueError(
                f"value_variance must be finite and non-negative, got {value_variance}"
            )
        _cov_pairs: list[tuple[str, Optional[float]]] = [
            ("cov_pv", cov_pv),
            ("cov_pr", cov_pr),
            ("cov_vr", cov_vr),
        ]
        for _cov_name, _cov_val in _cov_pairs:
            if _cov_val is not None:
                if isinstance(_cov_val, bool):
                    raise TypeError(f"{_cov_name} must be numeric, got bool")
                if not math.isfinite(_cov_val):
                    raise ValueError(f"{_cov_name} must be finite, got {_cov_val}")

        # Defensive validation of complexity values (B2-10 fix)
        # Normalized complexity should be in [0, 1], but raw deltas can be outside
        # Log warning for suspicious values but don't error (upstream should validate)
        for name, value in [
            ("complexity.static", complexity.static),
            ("complexity.dynamic", complexity.dynamic),
        ]:
            # For normalized scores, expect [0, 1]; for deltas, allow [-1, 1]
            # Values significantly outside this range suggest misconfiguration
            if not (-2.0 <= value <= 2.0):
                logger.warning(
                    f"{name}={value} is outside expected range [-2, 2]. "
                    "Normalized complexity should be in [0, 1]. "
                    "Raw deltas should typically be in [-1, 1]. "
                    "Calculation will proceed but results may be unexpected."
                )

        # Determine decision path
        complexity_delta = complexity.total
        decision_path = "REFACTORING" if complexity_delta < 0 else "INVESTMENT"

        # Extract expected values
        delta_P_H = profit_estimate.expected
        delta_R = risk_estimate.expected
        delta_C_S = complexity.static
        delta_C_D = complexity.dynamic

        # Apply kappa only when risk is reduced (R < 0).
        # Note: This creates a discontinuity at delta_R=0 in both the utility
        # value and its variance (kappa²·Var(R) drops to 0). This is intentional:
        # risk reduction is rewarded, risk increase is not penalized via kappa.
        kappa_effective = self.kappa if delta_R < 0 else 0.0

        # Calculate utility components
        profit_term = delta_P_H
        value_term = self.gamma * value_low_conf
        risk_term = kappa_effective * delta_R
        complexity_tax = self.phi_S * delta_C_S + self.phi_D * delta_C_D

        # Raw utility
        U = (profit_term + value_term) + risk_term - complexity_tax - opex_delta

        # Variance calculation with optional covariance terms
        # Var(U) = Var(P) + γ²Var(V) + κ²Var(R) + 2γCov(P,V) + 2κCov(P,R) + 2γκCov(V,R)
        variance = (
            profit_estimate.variance
            + (self.gamma**2) * value_variance
            + (kappa_effective**2) * risk_estimate.variance
            # Covariance terms with factor of 2 per variance formula
            + 2 * self.gamma * (cov_pv if cov_pv is not None else 0.0)
            + 2 * kappa_effective * (cov_pr if cov_pr is not None else 0.0)
            + 2 * self.gamma * kappa_effective * (cov_vr if cov_vr is not None else 0.0)
        )

        # Ensure variance is non-negative (covariance terms could make it negative)
        if variance < 0.0:
            logger.warning(
                f"Utility variance computed as negative ({variance:.6f}), "
                f"flooring to 0. This typically indicates invalid covariance inputs "
                f"(e.g., |cov| > sqrt(var1 * var2)). Review cov_pv={cov_pv}, "
                f"cov_pr={cov_pr}, cov_vr={cov_vr}."
            )
            variance = 0.0

        # Lower confidence bound
        lcb = U - self.z_alpha * math.sqrt(variance)

        # Build components
        components = UtilityComponents(
            profit_high_conf=profit_term,
            value_low_conf=value_term,
            risk_adjustment=risk_term,
            complexity_tax=complexity_tax,
            opex_delta=opex_delta,
        )

        return UtilityResult(
            raw=U,
            variance=variance,
            lcb=lcb,
            components=components,
            decision_path=decision_path,
        )

    def check_refactoring_path(
        self,
        result: UtilityResult,
    ) -> bool:
        """Check if proposal qualifies for refactoring path.

        Refactoring path has relaxed requirements:
        - Complexity delta must be negative (reducing debt)
        - Utility can be up to MIGRATION_BUDGET below threshold
        """
        if result.decision_path != "REFACTORING":
            return False

        # Allow negative utility up to migration budget
        return result.raw >= -self.migration_budget
