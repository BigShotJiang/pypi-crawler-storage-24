"""AWS Lambda handler wrapping pcw_decide() for API Gateway.

This is a thin wrapper — all governance logic lives in pcw_decide().
Handles API Gateway proxy integration format and routes to the
appropriate handler based on the HTTP path.

Routes:
    POST /evaluate    — Full proposal evaluation via pcw_decide()
    POST /risk-check  — Quick threshold check (no Bayesian)
    GET  /health      — Health check endpoint

Environment variables:
    AEGIS_CONFIG_PATH      — Path to YAML config file (optional)
    AEGIS_TABLE_NAME       — DynamoDB table name (for future audit logging)
    AEGIS_STAGE            — Deployment stage (dev/staging/prod)
"""

from __future__ import annotations

import json
import logging
import math
import os
import threading
import uuid
from typing import Any

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# --- Customer Manager (Lambda warm-start singleton) ---
_CUSTOMER_MGR_LOCK = threading.Lock()
_CUSTOMER_MGR: Any = None


def _get_customer_manager() -> Any:
    """Lazy-init CustomerManager singleton (survives Lambda warm starts)."""
    global _CUSTOMER_MGR  # noqa: PLW0603
    if _CUSTOMER_MGR is not None:
        return _CUSTOMER_MGR
    with _CUSTOMER_MGR_LOCK:
        if _CUSTOMER_MGR is None:
            try:
                from aegis_governance.customer import CustomerManager

                _CUSTOMER_MGR = CustomerManager()
            except Exception as e:
                logger.warning("Customer tracking unavailable: %s", e)
                return None
    return _CUSTOMER_MGR


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda entry point for API Gateway proxy integration.

    Args:
        event: API Gateway proxy event (v1 format).
        context: Lambda context object.

    Returns:
        API Gateway proxy response dict.
    """
    http_method = event.get("httpMethod", "GET")
    path = event.get("path", "/")
    tenant_id = _extract_tenant_id(event)
    request_id = _extract_request_id(event, context)

    # Look up customer (non-blocking — cache hit on warm starts)
    customer = None
    customer_mgr = _get_customer_manager()
    if customer_mgr and tenant_id != "anonymous":
        try:
            if tenant_id.startswith("cust_"):
                # Unkey authorizer path: tenant_id is already a customer_id
                customer = customer_mgr.get_customer(tenant_id)
            else:
                # Legacy API Gateway path: tenant_id is an API key ID
                customer = customer_mgr.get_customer_by_api_key(tenant_id)
        except Exception as e:
            logger.debug("Customer lookup skipped: %s", e)

    # Route requests
    if path == "/health" and http_method == "GET":
        return _handle_health(event, context)
    elif path == "/evaluate" and http_method == "POST":
        resp = _handle_evaluate(event, context)
        resp = _inject_tenant_context(resp, tenant_id, request_id)
        resp = _inject_customer_context(resp, customer, event)
        _track_usage(customer_mgr, customer, route="/evaluate")
        return resp
    elif path == "/risk-check" and http_method == "POST":
        resp = _handle_risk_check(event, context)
        resp = _inject_tenant_context(resp, tenant_id, request_id)
        resp = _inject_customer_context(resp, customer, event)
        _track_usage(customer_mgr, customer, route="/risk-check")
        return resp
    else:
        resp = _response(404, {"error": f"Not found: {http_method} {path}"})
        return _inject_tenant_context(resp, tenant_id, request_id)


def _handle_health(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Health check endpoint."""

    stage = os.environ.get("AEGIS_STAGE", "unknown")

    try:
        _load_config()
        config_ok = True
    except Exception as e:
        config_ok = False
        logger.warning("Config health check failed: %s", e)

    try:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator()
        result = evaluator.evaluate_risk_gate(baseline=0.1, proposed=0.15)
        gates_ok = result.passed is not None
    except Exception as e:
        gates_ok = False
        logger.warning("Gate health check failed: %s", e)

    healthy = config_ok and gates_ok
    body = {
        "status": "ok" if healthy else "degraded",
        "version": _get_version(),
        "stage": stage,
        "checks": {
            "config": {"ok": config_ok},
            "gates": {"ok": gates_ok},
        },
    }
    return _response(200 if healthy else 503, body)


def _wire_lambda_telemetry(config: Any) -> Any:
    """Create a TelemetryEmitter from config if telemetry_url is set.

    Deployment-time URL — no SSRF validation needed (not user input).
    """
    if not config.telemetry_url:
        return None
    try:
        from telemetry.emitter import HTTPEventSink, TelemetryEmitter

        emitter = TelemetryEmitter(source="aegis-lambda")
        emitter.add_sink(HTTPEventSink(url=config.telemetry_url))
        return emitter
    except (ImportError, ValueError) as e:
        logger.warning("Telemetry unavailable: %s", e)
        return None


def _handle_evaluate(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Full proposal evaluation via pcw_decide()."""
    from integration.pcw_decide import pcw_decide

    # Parse request body
    try:
        body = _parse_body(event)
    except (json.JSONDecodeError, ValueError) as e:
        return _response(400, {"error": f"Invalid request body: {e}"})

    # Load config
    try:
        config = _load_config()
    except Exception as e:
        logger.error("Failed to load config: %s", e)
        return _response(500, {"error": "Configuration error"})

    # Build PCWContext from request
    try:
        ctx = _build_context(body)
    except (ValueError, TypeError, KeyError) as e:
        return _response(400, {"error": f"Invalid proposal data: {e}"})

    # Auto-compute utility if not explicitly provided
    ctx.utility_result = ctx.utility_result or _compute_utility(ctx, config)

    # Create gate evaluator
    evaluator = config.create_gate_evaluator()

    # Wire drift monitor if baseline data provided
    drift_monitor = None
    baseline_data = body.get("drift_baseline_data")
    if isinstance(baseline_data, list):
        try:
            filtered = []
            for v in baseline_data:
                if v is not None:
                    if isinstance(v, bool):
                        raise TypeError("drift_baseline_data element is bool")
                    fv = float(v)
                    if not math.isfinite(fv):
                        raise ValueError(
                            f"drift_baseline_data element must be finite, got {fv}"
                        )
                    filtered.append(fv)
        except (ValueError, TypeError):
            return _response(
                400, {"error": "drift_baseline_data must contain numeric values"}
            )
        if filtered:
            drift_monitor = config.create_drift_monitor()
            drift_monitor.set_baseline(filtered)

    telemetry_emitter = _wire_lambda_telemetry(config)

    # Evaluate
    try:
        _sm = body.get("shadow_mode")
        if _sm is not None and not isinstance(_sm, bool):
            return _response(
                400,
                {
                    "error": f"'shadow_mode' must be a boolean (got {type(_sm).__name__})"
                },
            )
        shadow_mode = bool(_sm) if _sm is not None else False
        decision = pcw_decide(
            ctx,
            gate_evaluator=evaluator,
            shadow_mode=shadow_mode,
            drift_monitor=drift_monitor,
            telemetry_emitter=telemetry_emitter,
        )
    except Exception as e:
        logger.error("Evaluation failed: %s", e, exc_info=True)
        return _response(500, {"error": "Evaluation error"})

    # Build response — all governance decisions return 200 (the decision
    # status is in the body, not the HTTP status code)
    result = _decision_to_dict(decision)
    return _response(200, result)


def _handle_risk_check(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Quick risk check (threshold-only, no Bayesian)."""
    from integration.pcw_decide import quick_risk_check

    try:
        body = _parse_body(event)
    except (json.JSONDecodeError, ValueError) as e:
        return _response(400, {"error": f"Invalid request body: {e}"})

    agent_id = _str_or_default(body, "agent_id", "lambda-caller")
    action = _str_field(body, "action_description", "Lambda risk check")
    risk_score = body.get("risk_score")
    threshold = body.get("threshold")
    if threshold is None:
        threshold = 0.5

    if risk_score is None:
        return _response(400, {"error": "risk_score is required"})

    try:
        if isinstance(risk_score, bool) or isinstance(threshold, bool):
            return _response(
                400, {"error": "risk_score and threshold must be numeric, not bool"}
            )
        risk_score = float(risk_score)
        threshold = float(threshold)
        if not math.isfinite(risk_score) or not math.isfinite(threshold):
            return _response(
                400, {"error": "risk_score and threshold must be finite numbers"}
            )
    except (ValueError, TypeError) as e:
        return _response(400, {"error": f"Invalid numeric value: {e}"})

    safe = quick_risk_check(agent_id, action, risk_score, threshold)
    return _response(
        200,
        {
            "safe": safe,
            "risk_score": risk_score,
            "threshold": threshold,
            "agent_id": agent_id,
        },
    )


# --- Customer Context Helpers ---


def _inject_customer_context(
    response: dict[str, Any],
    customer: Any,
    event: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Add customer info to response headers and body if customer is known."""
    if customer is None:
        return response

    headers = response.get("headers", {})
    headers["X-AEGIS-Customer"] = customer.customer_id
    headers["X-AEGIS-Tier"] = customer.tier

    # Forward rate remaining from authorizer context (Phase 2b: Unkey)
    if event is not None:
        authorizer = event.get("requestContext", {}).get("authorizer", {})
        rate_remaining = authorizer.get("rate_remaining")
        if rate_remaining is not None:
            headers["X-AEGIS-Rate-Remaining"] = str(rate_remaining)

    response["headers"] = headers

    try:
        body = json.loads(response["body"])
        body["_customer_id"] = customer.customer_id
        body["_tier"] = customer.tier
        response["body"] = json.dumps(body)
    except (json.JSONDecodeError, KeyError, TypeError):
        pass

    return response


def _track_usage(
    mgr: Any,
    customer: Any,
    route: str,
) -> None:
    """Record usage event (fire-and-forget — never blocks response)."""
    if mgr is None or customer is None:
        return
    try:
        mgr.record_usage(
            customer.customer_id,
            channel="api",
            route=route,
        )
    except Exception as e:
        logger.warning("Usage tracking failed: %s", e)


# --- Tenant Context Helpers ---


def _extract_tenant_id(event: dict[str, Any]) -> str:
    """Extract tenant ID from API Gateway authorizer or API key identity.

    Checks in order:
    1. ``requestContext.authorizer.customer_id`` (Unkey Lambda Authorizer path)
    2. ``requestContext.identity.apiKeyId`` (legacy API Gateway key path)
    3. Falls back to ``"anonymous"``
    """
    try:
        # Phase 2b: Unkey authorizer injects customer_id
        authorizer = event.get("requestContext", {}).get("authorizer", {})
        if authorizer:
            cid = authorizer.get("customer_id", "")
            if cid:
                return str(cid)
        # Legacy: API Gateway API key identity
        return (
            event.get("requestContext", {}).get("identity", {}).get("apiKeyId", "")
        ) or "anonymous"
    except (AttributeError, TypeError):
        return "anonymous"


def _extract_request_id(event: dict[str, Any], context: Any) -> str:
    """Extract a request ID — prefer API Gateway's, fall back to Lambda's."""
    try:
        apigw_id = event.get("requestContext", {}).get("requestId", "")
        if apigw_id:
            return str(apigw_id)
    except (AttributeError, TypeError):
        pass
    try:
        return str(context.aws_request_id)
    except AttributeError:
        return str(uuid.uuid4())


def _inject_tenant_context(
    response: dict[str, Any],
    tenant_id: str,
    request_id: str,
) -> dict[str, Any]:
    """Add tenant and request context to an existing response."""
    # Add tenant/request headers
    headers = response.get("headers", {})
    headers["X-AEGIS-Tenant"] = tenant_id
    headers["X-AEGIS-Request-Id"] = request_id
    response["headers"] = headers

    # Add tenant/request fields to response body
    try:
        body = json.loads(response["body"])
        body["_tenant_id"] = tenant_id
        body["_request_id"] = request_id
        response["body"] = json.dumps(body)
    except (json.JSONDecodeError, KeyError, TypeError):
        pass  # Don't corrupt response on serialization failure

    return response


# --- Helpers ---


def _parse_body(event: dict[str, Any]) -> dict[str, Any]:
    """Parse API Gateway event body."""
    raw_body = event.get("body", "{}")
    if raw_body is None:
        raw_body = "{}"

    # API Gateway may base64 encode the body
    if event.get("isBase64Encoded"):
        import base64

        raw_body = base64.b64decode(raw_body, validate=True).decode("utf-8")

    result = json.loads(raw_body)
    if not isinstance(result, dict):
        raise ValueError("Request body must be a JSON object")
    return result


def _str_or_default(body: dict[str, Any], key: str, default: str) -> str:
    """Return body[key] if it's a non-empty string, else default."""
    val = body.get(key)
    if isinstance(val, str) and val:
        return val
    return default


def _str_field(
    body: dict[str, Any], key: str, default: str, *, strict: bool = False
) -> str:
    """Extract a string field from *body*, defaulting on None/empty.

    When *strict* is True, non-string falsy values (False, 0) raise TypeError
    instead of falling back to the default.  This prevents the ``value or default``
    pattern from silently coercing falsy non-strings (BH36).
    """
    raw = body.get(key)
    if raw is None or raw == "":
        return default
    if strict and not isinstance(raw, str):
        raise TypeError(f"{key} must be a string (got {type(raw).__name__})")
    return str(raw) if isinstance(raw, str) else default


def _build_context(body: dict[str, Any]) -> Any:
    """Build PCWContext from request body."""
    from integration.pcw_decide import PCWContext, PCWPhase

    # Required fields — use _str_field to avoid `or` falsy bypass (BH36)
    proposal_summary = _str_field(body, "proposal_summary", "API evaluation")
    estimated_impact = _str_field(body, "estimated_impact", "medium", strict=True)

    # Phase mapping
    phase_raw = _str_field(body, "phase", "plan", strict=True)
    phase_str = phase_raw.lower()
    phase_map = {
        "plan": PCWPhase.PLAN,
        "commit": PCWPhase.COMMIT,
        "work": PCWPhase.WORK,
    }
    phase = phase_map.get(phase_str, PCWPhase.PLAN)

    # Float helper: returns default if key missing or value is None
    def _float(key: str, default: float) -> float:
        val = body.get(key)
        if val is None:
            return default
        if isinstance(val, bool):
            raise TypeError(f"'{key}' must be numeric, got bool")
        result = float(val)
        if not math.isfinite(result):
            raise ValueError(f"'{key}' must be finite, got {result}")
        return result

    # Bool helper: reject non-bool values to avoid truthiness confusion
    def _bool(key: str, default: bool) -> bool:
        val = body.get(key)
        if val is None:
            return default
        if not isinstance(val, bool):
            raise TypeError(f"'{key}' must be a boolean (got {type(val).__name__})")
        return val

    # Subscore helper: validates each element for bool/NaN/Inf (transport parity)
    def _validate_subscores(raw: list[Any]) -> list[float]:
        result: list[float] = []
        saw_non_null = False
        for s in raw:
            if s is not None:
                saw_non_null = True
                if isinstance(s, bool):
                    raise TypeError("quality subscore must be numeric, got bool")
                v = float(s)
                if not math.isfinite(v):
                    raise ValueError(f"quality subscore must be finite, got {v}")
                result.append(v)
        if result:
            return result
        # Preserve explicit empty list so quality gate can fail-safe on missing subscores.
        if raw and not saw_non_null:
            return [0.7, 0.7, 0.7]
        return []

    raw_quality_subscores = body.get("quality_subscores")
    if raw_quality_subscores is None:
        quality_subscores = [0.7, 0.7, 0.7]
    else:
        if not isinstance(raw_quality_subscores, list):
            raise TypeError(
                f"'quality_subscores' must be a list (got {type(raw_quality_subscores).__name__})"
            )
        quality_subscores = _validate_subscores(raw_quality_subscores)

    metadata = body.get("metadata", {})
    if metadata is None:
        metadata = {}
    if not isinstance(metadata, dict):
        raise TypeError(
            f"metadata must be a JSON object (got {type(metadata).__name__})",
        )

    return PCWContext(
        agent_id=_str_or_default(body, "agent_id", "lambda-caller"),
        session_id=_str_or_default(body, "session_id", str(uuid.uuid4())),
        phase=phase,
        proposal_summary=proposal_summary,
        estimated_impact=estimated_impact,
        risk_baseline=_float("risk_baseline", 0.0),
        risk_proposed=(
            _float("risk_proposed", 0.0)
            if body.get("risk_proposed") is not None
            else _float("risk_score", 0.0)
        ),
        profit_baseline=_float("profit_baseline", 0.0),
        profit_proposed=_float("profit_proposed", 0.0),
        novelty_score=_float("novelty_score", 0.5),
        complexity_score=_float("complexity_score", 0.5),
        quality_score=_float("quality_score", 0.7),
        quality_subscores=quality_subscores,
        requires_human_approval=_bool("requires_human_approval", False),
        time_sensitive=_bool("time_sensitive", False),
        reversible=_bool("reversible", True),
        metadata=metadata,
    )


def _make_pert(delta: float, spread: float = 0.20) -> Any:
    """Create a ThreePointEstimate from a point delta.

    Builds PERT best/likely/worst from a single delta value using a
    symmetric spread margin.  Maintains best <= likely <= worst invariant
    for both positive and negative deltas.

    Args:
        delta: The point-estimate change (positive or negative).
        spread: Fractional margin around the point estimate (default 20%).

    Returns:
        ThreePointEstimate(best, likely, worst).
    """
    from engine.utility import ThreePointEstimate

    if delta == 0.0:
        return ThreePointEstimate(0.0, 0.0, 0.0)

    margin = abs(delta * spread)
    if delta > 0:
        return ThreePointEstimate(
            best=delta - margin, likely=delta, worst=delta + margin
        )
    # delta < 0: best is more negative, worst is less negative
    return ThreePointEstimate(best=delta - margin, likely=delta, worst=delta + margin)


def _compute_utility(ctx: Any, config: Any) -> Any | None:
    """Derive UtilityResult from PCWContext risk/profit fields.

    Synthesizes PERT three-point estimates from the flat risk/profit/complexity
    parameters already present in the context, then runs the full utility
    calculation.  Returns None on any failure (graceful degradation — the
    utility gate will fall back to lcb=-inf as before).

    Risk and complexity are zeroed because their gates evaluate
    independently, and the UtilityCalculator's kappa/phi_S/phi_D
    coefficients expect dollar-denominated inputs — not the normalized
    [0,1] scores the advisor provides.  Specifically:
      - risk_term = kappa * delta_R is negative when risk decreases,
        which *subtracts* from utility (penalises risk reduction).
      - complexity_tax = phi_S * static is ~100x the profit delta
        at normalized scale.

    Args:
        ctx: PCWContext with risk/profit/complexity fields.
        config: AegisConfig for creating the calculator.

    Returns:
        UtilityResult or None on failure.
    """
    try:
        from engine.utility import ComplexityBreakdown

        profit_delta = ctx.profit_proposed - ctx.profit_baseline

        # Epsilon clamp: zero profit_delta yields utility exactly 0.0 which
        # fails the strict > 0.0 gate.  Matches MCP and CLI.
        if abs(profit_delta) < 0.001:
            profit_delta = 0.001

        profit_estimate = _make_pert(profit_delta)
        # Zero risk: risk gate evaluates independently; kappa*delta_R
        # penalises risk *reduction* (negative delta) at normalized scale.
        risk_estimate = _make_pert(0.0)
        # Zero complexity: complexity gate evaluates independently;
        # phi_S=100 $/pt would overwhelm normalized [0,1] deltas.
        complexity = ComplexityBreakdown(static=0.0, dynamic=0.0)

        calculator = config.create_utility_calculator()
        return calculator.calculate(profit_estimate, risk_estimate, complexity)
    except Exception as e:
        logger.warning("Auto-utility computation failed: %s", e)
        return None


def _decision_to_dict(decision: Any) -> dict[str, Any]:
    """Convert PCWDecision to JSON-serializable dict."""
    import math

    def _safe(val: float | None) -> float | None:
        if val is None or not math.isfinite(val):
            return None
        return round(val, 6)

    result: dict[str, Any] = {
        "status": decision.status.value,
        "confidence": _safe(decision.confidence),
        "gates_passed": decision.gates_passed,
        "gates_failed": decision.gates_failed,
        "failing_gates": decision.failing_gates,
        "rationale": decision.rationale,
        "next_steps": decision.next_steps,
        "constraints": decision.constraints,
        "decision_id": decision.decision_id,
        "timestamp": decision.timestamp.isoformat(),
        "override_eligible": decision.override_eligible,
        "override_requires": decision.override_requires,
    }

    # Include gate details
    if decision.gate_evaluation:
        result["gates"] = {}
        for gate_type, gate_result in decision.gate_evaluation.gates.items():
            result["gates"][gate_type.value] = {
                "passed": gate_result.passed,
                "value": _safe(gate_result.value),
                "threshold": _safe(gate_result.threshold),
                "confidence": (
                    _safe(gate_result.confidence)
                    if gate_result.confidence is not None
                    else None
                ),
                "message": gate_result.message,
            }

    # Include drift result
    if decision.drift_result is not None:
        dr = decision.drift_result
        result["drift"] = {
            "status": dr.status.value,
            "kl_divergence": _safe(dr.kl_divergence),
            "action": dr.action.value,
            "message": dr.message,
        }

    # Include shadow result
    if decision.shadow_result is not None:
        sr = decision.shadow_result
        shadow_dict: dict[str, Any] = {
            "shadow_only": sr.shadow_only,
            "observation_values": [_safe(v) for v in sr.observation_values],
            "baseline_hash": sr.baseline_hash,
        }
        if sr.drift_result is not None:
            shadow_dict["drift"] = {
                "status": sr.drift_result.status.value,
                "kl_divergence": _safe(sr.drift_result.kl_divergence),
                "action": sr.drift_result.action.value,
                "message": sr.drift_result.message,
            }
        result["shadow_result"] = shadow_dict

    return result


def _load_config() -> Any:
    """Load AegisConfig from environment or return defaults."""
    from config import AegisConfig

    config_path = os.environ.get("AEGIS_CONFIG_PATH")
    if config_path:
        return AegisConfig.from_yaml(config_path)
    return AegisConfig.default()


def _get_version() -> str:
    """Get AEGIS version string."""
    try:
        import importlib.metadata

        return importlib.metadata.version("aegis-governance")
    except Exception:
        return "1.1.0"


def _response(status_code: int, body: dict[str, Any]) -> dict[str, Any]:
    """Build API Gateway proxy response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "X-AEGIS-Version": _get_version(),
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Api-Key",
            "Access-Control-Allow-Methods": "POST,GET,OPTIONS",
        },
        "body": json.dumps(body),
    }
