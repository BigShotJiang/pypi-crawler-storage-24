"""AEGIS Governance CLI

Command-line interface for the AEGIS Governance Decision SDK.

Usage:
    aegis evaluate --input proposal.json [--config config.yaml]
    aegis evaluate < proposal.json
    aegis validate-config config.yaml
    aegis version
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from config import AegisConfig
    from engine.utility import UtilityResult
    from integration.pcw_decide import PCWContext


def _get_version() -> str:
    """Get AEGIS version string."""
    try:
        import importlib.metadata

        return importlib.metadata.version("aegis-governance")
    except Exception:  # Intentional: graceful fallback when package not installed
        return "1.1.0"


def _load_config(config_path: str | None) -> Any:
    """Load AegisConfig from path or return default."""
    from config import AegisConfig

    if config_path:
        return AegisConfig.from_yaml(config_path)
    return AegisConfig.default()


def _coerce_risk_score(raw: Any) -> float | None:
    """Validate and coerce a raw risk_score value, returning None if absent."""
    if raw is None:
        return None
    if isinstance(raw, bool):
        raise TypeError("'risk_score' must be numeric, got bool")
    result = float(raw)
    if not math.isfinite(result):
        raise ValueError(f"'risk_score' must be finite, got {result}")
    return result


def _extract_risk_alias_and_subscores(
    data: dict[str, Any],
    kwargs: dict[str, Any],
) -> None:
    """Extract risk_score alias and quality_subscores with bool guards."""
    # Simplified: risk_score maps to risk_proposed only when the user
    # did not supply a value via either the canonical "risk_proposed"
    # key or the simplified "risk" alias.
    _has_risk = ("risk_proposed" in data and data["risk_proposed"] is not None) or (
        "risk" in data and data["risk"] is not None
    )
    if "risk_score" in data and not _has_risk:
        _rs = _coerce_risk_score(data["risk_score"])
        if _rs is not None:
            kwargs["risk_proposed"] = _rs

    # Quality subscores (transport parity with Lambda _validate_subscores / MCP
    # _validate_quality_subscores: explicit [] → [], all-null → defaults)
    if "quality_subscores" in data:
        _raw_qs = data["quality_subscores"]
        if _raw_qs is None:
            # Explicit null → defaults (transport parity: Lambda/MCP treat null same as omitted)
            kwargs["quality_subscores"] = [0.7, 0.7, 0.7]
            return
        if not isinstance(_raw_qs, list):
            raise TypeError(
                f"'quality_subscores' must be a list (got {type(_raw_qs).__name__})"
            )
        _subs: list[float] = []
        _saw_non_null = False
        for s in _raw_qs:
            if s is not None:
                _saw_non_null = True
                if isinstance(s, bool):
                    raise TypeError("quality subscore must be numeric, got bool")
                _v = float(s)
                if not math.isfinite(_v):
                    raise ValueError(f"quality subscore must be finite, got {_v}")
                _subs.append(_v)
        if _subs:
            kwargs["quality_subscores"] = _subs
        elif _raw_qs and not _saw_non_null:
            kwargs["quality_subscores"] = [0.7, 0.7, 0.7]
        else:
            kwargs["quality_subscores"] = []


def _extract_bool_flags(
    data: dict[str, Any],
    kwargs: dict[str, Any],
) -> None:
    """Extract and validate boolean control flags from input data.

    Rejects non-bool values to prevent Python truthiness confusion
    (transport parity with Lambda _bool() helper).
    """
    for key, default in [
        ("requires_human_approval", False),
        ("time_sensitive", False),
        ("reversible", True),
    ]:
        val = data.get(key)
        if val is None:
            kwargs[key] = default
        elif not isinstance(val, bool):
            raise TypeError(f"'{key}' must be a boolean (got {type(val).__name__})")
        else:
            kwargs[key] = val


def _parse_proposal(data: dict[str, Any]) -> dict[str, Any]:
    """Parse proposal JSON into PCWContext kwargs.

    Accepts either full PCWContext fields or simplified input:
    - Full: all PCWContext fields directly
    - Simplified: proposal_summary, estimated_impact, risk_score, etc.
    """
    from integration.pcw_decide import PCWPhase

    # Map simplified field names to PCWContext fields
    kwargs: dict[str, Any] = {}

    # Required fields — use explicit None/empty check, NOT `or`, which
    # treats falsy non-strings (False, 0) as missing (BH36-M3 transport parity).
    _raw_summary = data.get("proposal_summary")
    kwargs["proposal_summary"] = (
        _raw_summary
        if isinstance(_raw_summary, str) and _raw_summary
        else "CLI evaluation"
    )
    _raw_impact = data.get("estimated_impact")
    if _raw_impact is None or _raw_impact == "":
        _raw_impact = "medium"
    if not isinstance(_raw_impact, str):
        raise TypeError(
            f"estimated_impact must be a string (got {type(_raw_impact).__name__})"
        )
    kwargs["estimated_impact"] = _raw_impact

    # Agent identification (defaults for CLI usage)
    _raw_agent = data.get("agent_id", "aegis-cli")
    kwargs["agent_id"] = _raw_agent if isinstance(_raw_agent, str) else "aegis-cli"
    _raw_session = data.get("session_id")
    kwargs["session_id"] = (
        _raw_session
        if isinstance(_raw_session, str) and _raw_session
        else str(uuid.uuid4())
    )

    # Phase
    phase_raw = data.get("phase", "plan")
    if not isinstance(phase_raw, str):
        phase_raw = "plan"
    phase_str = phase_raw.lower()
    phase_map = {
        "plan": PCWPhase.PLAN,
        "commit": PCWPhase.COMMIT,
        "work": PCWPhase.WORK,
    }
    kwargs["phase"] = phase_map.get(phase_str, PCWPhase.PLAN)

    # Numeric metrics with defaults
    _METRIC_DEFAULTS: dict[str, float] = {
        "risk_baseline": 0.0,
        "risk_proposed": 0.0,
        "profit_baseline": 0.0,
        "profit_proposed": 0.0,
        "novelty_score": 0.5,
        "complexity_score": 0.5,
        "quality_score": 0.7,
    }

    _SIMPLIFIED_NAMES: dict[str, str] = {
        "risk_baseline": "risk_base",
        "risk_proposed": "risk",
        "profit_baseline": "profit_base",
        "profit_proposed": "profit",
        "novelty_score": "novelty",
        "complexity_score": "complexity",
        "quality_score": "quality",
    }

    for field_name, default in _METRIC_DEFAULTS.items():
        # Accept both full field names and simplified names.
        # Split into explicit checks: dict.get(key, fallback) returns None
        # (not fallback) when key exists with null value (BH43-L1 fix).
        simple_name = _SIMPLIFIED_NAMES.get(field_name, field_name)
        raw = data.get(field_name)
        if raw is None:
            raw = data.get(simple_name)
        if raw is None:
            raw = default
        # raw is guaranteed non-None here (default is always a float)
        if isinstance(raw, bool):
            raise TypeError(f"'{field_name}' must be numeric, got bool")
        val = float(raw)
        if not math.isfinite(val):
            raise ValueError(f"'{field_name}' must be finite, got {val}")
        kwargs[field_name] = val

    # Simplified alias + subscores (extracted to helper for PLR0912 branch budget)
    _extract_risk_alias_and_subscores(data, kwargs)

    # Boolean flags (extracted to helper for PLR0912 branch budget)
    _extract_bool_flags(data, kwargs)

    # Metadata (transport parity with Lambda)
    _raw_metadata = data.get("metadata", {})
    if _raw_metadata is None:
        _raw_metadata = {}
    if not isinstance(_raw_metadata, dict):
        raise TypeError(
            f"'metadata' must be a dict (got {type(_raw_metadata).__name__})"
        )
    kwargs["metadata"] = _raw_metadata

    return kwargs


def _build_telemetry_emitter(args: Any, config: Any) -> Any:
    """Create a TelemetryEmitter with HTTPEventSink if a URL is configured."""
    telemetry_url = getattr(args, "telemetry_url", None) or (
        config.telemetry_url if config else None
    )
    if not telemetry_url:
        return None

    # SSRF validation (transport parity with MCP)
    from telemetry.url_validation import validate_telemetry_url

    if not validate_telemetry_url(telemetry_url):
        print(
            json.dumps(
                {"warning": f"Telemetry URL rejected (SSRF check): {telemetry_url}"}
            ),
            file=sys.stderr,
        )
        return None

    from telemetry.emitter import HTTPEventSink, TelemetryEmitter

    try:
        emitter = TelemetryEmitter(source="aegis-cli")
        emitter.add_sink(HTTPEventSink(url=telemetry_url))
        return emitter
    except ValueError as e:
        print(json.dumps({"warning": f"Telemetry disabled: {e}"}), file=sys.stderr)
        return None


def _load_drift_monitor(args: Any, config: Any) -> Any:
    """Create a DriftMonitor from --drift-baseline file, or None."""
    drift_baseline_path = getattr(args, "drift_baseline", None)
    if not drift_baseline_path:
        return None

    bp = Path(drift_baseline_path)
    if not bp.exists():
        raise FileNotFoundError(f"Baseline file not found: {drift_baseline_path}")

    with open(bp) as f:
        baseline_data = json.load(f)

    if not isinstance(baseline_data, list):
        raise ValueError("Baseline file must contain a JSON array of numbers")

    filtered = []
    for v in baseline_data:
        if v is not None:
            if isinstance(v, bool):
                raise TypeError("drift_baseline_data element must be numeric, got bool")
            fv = float(v)
            if not math.isfinite(fv):
                raise ValueError(
                    f"drift_baseline_data element must be finite, got {fv}"
                )
            filtered.append(fv)
    if not filtered:
        raise ValueError("Baseline file contains no valid numeric values")

    drift_monitor = config.create_drift_monitor()
    drift_monitor.set_baseline(filtered)
    return drift_monitor


def _safe_round(value: float, ndigits: int = 6) -> float | None:
    """Round a float, replacing non-finite values (inf, -inf, NaN) with None.

    json.dumps produces non-standard tokens (-Infinity, Infinity, NaN) for
    non-finite floats.  Replacing them with None emits JSON null instead,
    keeping output RFC 7159 compliant.
    """
    if not math.isfinite(value):
        return None
    return round(value, ndigits)


def _decision_to_dict(decision: Any) -> dict[str, Any]:
    """Convert PCWDecision to JSON-serializable dict."""
    result: dict[str, Any] = {
        "status": decision.status.value,
        "confidence": _safe_round(decision.confidence),
        "gates_passed": decision.gates_passed,
        "gates_failed": decision.gates_failed,
        "failing_gates": decision.failing_gates,
        "rationale": decision.rationale,
        "next_steps": decision.next_steps,
        "constraints": decision.constraints,
        "decision_id": decision.decision_id,
        "timestamp": decision.timestamp.isoformat(),
        "override_eligible": decision.override_eligible,
        "override_requires": decision.override_requires,
    }

    # Include gate details if available
    if decision.gate_evaluation:
        result["gates"] = {}
        for gate_type, gate_result in decision.gate_evaluation.gates.items():
            result["gates"][gate_type.value] = {
                "passed": gate_result.passed,
                "value": _safe_round(gate_result.value),
                "threshold": _safe_round(gate_result.threshold),
                "confidence": (
                    _safe_round(gate_result.confidence)
                    if gate_result.confidence is not None
                    else None
                ),
                "message": gate_result.message,
            }

    return result


def _build_output(decision: Any) -> dict[str, Any]:
    """Build full JSON output dict from a PCWDecision."""
    output = _decision_to_dict(decision)
    if decision.drift_result is not None:
        dr = decision.drift_result
        output["drift"] = {
            "status": dr.status.value,
            "kl_divergence": _safe_round(dr.kl_divergence),
            "action": dr.action.value,
            "message": dr.message,
        }
    if decision.shadow_result is not None:
        shadow_dict: dict[str, Any] = {
            "shadow_only": decision.shadow_result.shadow_only,
            "observation_values": [
                _safe_round(v) for v in decision.shadow_result.observation_values
            ],
            "baseline_hash": decision.shadow_result.baseline_hash,
        }
        if decision.shadow_result.drift_result is not None:
            dr = decision.shadow_result.drift_result
            shadow_dict["drift"] = {
                "status": dr.status.value,
                "kl_divergence": _safe_round(dr.kl_divergence),
                "action": dr.action.value,
                "message": dr.message,
            }
        output["shadow_result"] = shadow_dict
    return output


def _compute_utility(ctx: PCWContext, config: AegisConfig) -> UtilityResult | None:
    """Derive UtilityResult from PCWContext risk/profit fields.

    Matches the auto-utility synthesis in lambda_handler and mcp_server
    so all three surfaces produce consistent results.
    """
    try:
        from engine.utility import ComplexityBreakdown, ThreePointEstimate

        profit_delta = ctx.profit_proposed - ctx.profit_baseline

        # Epsilon clamp: zero profit_delta yields utility exactly 0.0 which
        # fails the strict > 0.0 gate.  Nudge to a tiny positive value so
        # proposals that pass all other gates are not spuriously blocked.
        # Matches MCP _PROFIT_DELTA_EPSILON and Lambda _compute_utility.
        if abs(profit_delta) < 0.001:
            profit_delta = 0.001

        def _pert(delta: float) -> ThreePointEstimate:
            if delta == 0.0:
                return ThreePointEstimate(0.0, 0.0, 0.0)
            margin = abs(delta * 0.2)
            return ThreePointEstimate(
                best=delta - margin, likely=delta, worst=delta + margin
            )

        calculator = config.create_utility_calculator()
        return calculator.calculate(
            _pert(profit_delta),
            _pert(0.0),  # risk gate evaluates independently
            ComplexityBreakdown(static=0.0, dynamic=0.0),
        )
    except Exception:
        return None


def cmd_evaluate(args: argparse.Namespace) -> int:
    """Execute the evaluate command."""
    from integration.pcw_decide import PCWContext, pcw_decide

    # Load config
    try:
        config = _load_config(args.config)
    except (FileNotFoundError, ImportError, ValueError, TypeError) as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        return 1

    # Read input
    try:
        if args.input:
            input_path = Path(args.input)
            if not input_path.exists():
                print(
                    json.dumps({"error": f"Input file not found: {args.input}"}),
                    file=sys.stderr,
                )
                return 1
            with open(input_path) as f:
                data = json.load(f)
        elif not sys.stdin.isatty():
            data = json.load(sys.stdin)
        else:
            print(
                json.dumps(
                    {
                        "error": "No input provided. Use --input FILE or pipe JSON to stdin."
                    }
                ),
                file=sys.stderr,
            )
            return 1
    except json.JSONDecodeError as e:
        print(json.dumps({"error": f"Invalid JSON: {e}"}), file=sys.stderr)
        return 1

    # Wire drift monitor if baseline provided
    try:
        drift_monitor = _load_drift_monitor(args, config)
    except (FileNotFoundError, ValueError, TypeError, json.JSONDecodeError) as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        return 1

    # Parse and evaluate
    try:
        ctx_kwargs = _parse_proposal(data)
        context = PCWContext(**ctx_kwargs)

        # Auto-compute utility from profit/risk if not explicitly provided
        # (matches Lambda and MCP server behaviour)
        if context.utility_result is None:
            context.utility_result = _compute_utility(context, config)

        evaluator = config.create_gate_evaluator()
        telemetry_emitter = _build_telemetry_emitter(args, config)

        decision = pcw_decide(
            context,
            gate_evaluator=evaluator,
            shadow_mode=getattr(args, "shadow", False),
            drift_monitor=drift_monitor,
            telemetry_emitter=telemetry_emitter,
        )
    except (ValueError, TypeError) as e:
        print(json.dumps({"error": f"Evaluation failed: {e}"}), file=sys.stderr)
        return 1

    # Output and exit code
    output = _build_output(decision)
    print(json.dumps(output, indent=2))

    _EXIT_CODES = {"proceed": 0, "halt": 1}
    return _EXIT_CODES.get(decision.status.value, 2)


def cmd_validate_config(args: argparse.Namespace) -> int:
    """Execute the validate-config command."""
    from config import AegisConfig

    try:
        config = AegisConfig.from_yaml(args.config_file)
    except ImportError as e:
        print(json.dumps({"valid": False, "error": str(e)}), file=sys.stderr)
        return 1
    except FileNotFoundError as e:
        print(json.dumps({"valid": False, "error": str(e)}), file=sys.stderr)
        return 1
    except (ValueError, TypeError) as e:
        print(json.dumps({"valid": False, "error": str(e)}), file=sys.stderr)
        return 1

    output = {"valid": True, "parameters": config.to_dict()}
    print(json.dumps(output, indent=2))
    return 0


def cmd_version(args: argparse.Namespace) -> int:
    """Execute the version command."""
    info = {
        "aegis_governance": _get_version(),
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
    }
    print(json.dumps(info, indent=2))
    return 0


def cmd_health(args: argparse.Namespace) -> int:
    """Execute the health command — check system health."""
    checks: dict[str, Any] = {}

    # Check config
    try:
        from config import AegisConfig

        config = AegisConfig.default()
        checks["config"] = {"ok": True, "epsilon_R": config.epsilon_R}
    except (
        Exception
    ) as e:  # Intentional: health check resilience — config errors are non-fatal
        checks["config"] = {"ok": False, "error": str(e)}

    # Check gate evaluator
    try:
        from engine.gates import GateEvaluator

        evaluator = GateEvaluator()
        result = evaluator.evaluate_risk_gate(baseline=0.1, proposed=0.15)
        checks["gates"] = {
            "ok": True,
            "risk_gate_functional": result.passed is not None,
        }
    except (
        Exception
    ) as e:  # Intentional: health check resilience — gate init errors are non-fatal
        checks["gates"] = {"ok": False, "error": str(e)}

    # Check persistence (optional)
    try:
        import importlib.util

        if importlib.util.find_spec("sqlalchemy") is not None:
            checks["persistence"] = {"ok": True, "available": True}
        else:
            checks["persistence"] = {"ok": True, "available": False}
    except ImportError:
        checks["persistence"] = {"ok": True, "available": False}

    # Check Prometheus (optional)
    try:
        from telemetry.prometheus_exporter import get_metrics

        metrics = get_metrics()
        checks["prometheus"] = {"ok": True, "metrics_bytes": len(metrics)}
    except ImportError:
        checks["prometheus"] = {"ok": True, "available": False}

    healthy = all(c["ok"] for c in checks.values())
    output = {"healthy": healthy, "checks": checks}
    print(json.dumps(output, indent=2))
    return 0 if healthy else 1


def cmd_metrics(args: argparse.Namespace) -> int:
    """Execute the metrics command — dump current Prometheus metrics."""
    try:
        from telemetry.prometheus_exporter import get_metrics

        print(get_metrics().decode("utf-8"), end="")
        return 0
    except ImportError:
        print(
            json.dumps(
                {
                    "error": "prometheus_client not installed. Run: pip install prometheus_client"
                }
            ),
            file=sys.stderr,
        )
        return 1


# --- Admin Commands ---


def cmd_admin_create_customer(args: argparse.Namespace) -> int:
    """Create a new customer record."""
    try:
        from aegis_governance.customer import CustomerManager
    except ImportError:
        print(
            json.dumps({"error": "boto3 required: pip install boto3"}),
            file=sys.stderr,
        )
        return 1

    mgr = CustomerManager(
        table_name=getattr(args, "table", None),
        region=getattr(args, "region", None),
    )

    try:
        customer = mgr.create_customer(
            name=args.name,
            email=args.email,
            company=getattr(args, "company", "") or "",
            tier=getattr(args, "tier", "free") or "free",
            api_key_id=getattr(args, "api_key_id", "") or "",
        )
    except ImportError as e:
        print(
            json.dumps({"error": f"Missing dependency: {e}. Run: pip install boto3"}),
            file=sys.stderr,
        )
        return 1
    except (ValueError, TypeError) as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        return 1

    print(json.dumps(customer.to_dict(), indent=2))
    return 0


def cmd_admin_list_customers(args: argparse.Namespace) -> int:
    """List all customers."""
    try:
        from aegis_governance.customer import CustomerManager
    except ImportError:
        print(
            json.dumps({"error": "boto3 required: pip install boto3"}),
            file=sys.stderr,
        )
        return 1

    mgr = CustomerManager(
        table_name=getattr(args, "table", None),
        region=getattr(args, "region", None),
    )
    try:
        customers = mgr.list_customers()
    except ImportError as e:
        print(
            json.dumps({"error": f"Missing dependency: {e}. Run: pip install boto3"}),
            file=sys.stderr,
        )
        return 1

    output = {
        "count": len(customers),
        "customers": [c.to_dict() for c in customers],
    }
    print(json.dumps(output, indent=2))
    return 0


def cmd_admin_get_customer(args: argparse.Namespace) -> int:
    """Get a single customer by ID."""
    try:
        from aegis_governance.customer import CustomerManager
    except ImportError:
        print(
            json.dumps({"error": "boto3 required: pip install boto3"}),
            file=sys.stderr,
        )
        return 1

    mgr = CustomerManager(
        table_name=getattr(args, "table", None),
        region=getattr(args, "region", None),
    )
    try:
        customer = mgr.get_customer(args.customer_id)
    except ImportError as e:
        print(
            json.dumps({"error": f"Missing dependency: {e}. Run: pip install boto3"}),
            file=sys.stderr,
        )
        return 1

    if not customer:
        print(
            json.dumps({"error": f"Customer not found: {args.customer_id}"}),
            file=sys.stderr,
        )
        return 1

    print(json.dumps(customer.to_dict(), indent=2))
    return 0


def cmd_admin_usage(args: argparse.Namespace) -> int:
    """Get usage summary for a customer."""
    try:
        from aegis_governance.customer import CustomerManager
    except ImportError:
        print(
            json.dumps({"error": "boto3 required: pip install boto3"}),
            file=sys.stderr,
        )
        return 1

    mgr = CustomerManager(
        table_name=getattr(args, "table", None),
        region=getattr(args, "region", None),
    )
    try:
        summary = mgr.get_usage(
            customer_id=args.customer_id,
            month=getattr(args, "month", None),
        )
    except ImportError as e:
        print(
            json.dumps({"error": f"Missing dependency: {e}. Run: pip install boto3"}),
            file=sys.stderr,
        )
        return 1

    print(json.dumps(summary.to_dict(), indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="aegis",
        description="AEGIS Governance Decision SDK — quantitative governance for engineering decisions",
    )
    parser.add_argument(
        "--customer-id",
        dest="customer_id",
        default=os.environ.get("AEGIS_CUSTOMER_ID"),
        help="Customer ID for usage tracking (or AEGIS_CUSTOMER_ID env var)",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # evaluate
    eval_parser = subparsers.add_parser(
        "evaluate",
        help="Evaluate a proposal through AEGIS governance gates",
    )
    eval_parser.add_argument(
        "--input",
        "-i",
        help="Path to proposal JSON file (or pipe to stdin)",
    )
    eval_parser.add_argument(
        "--config",
        "-c",
        help="Path to AEGIS YAML config file (defaults to built-in values)",
    )
    eval_parser.add_argument(
        "--shadow",
        action="store_true",
        default=False,
        help="Run in shadow mode (evaluate without enforcing decisions)",
    )
    eval_parser.add_argument(
        "--telemetry-url",
        help="HTTP URL to POST telemetry events to",
    )
    eval_parser.add_argument(
        "--drift-baseline",
        help="Path to JSON file with baseline data array for drift detection",
    )
    eval_parser.set_defaults(func=cmd_evaluate)

    # validate-config
    validate_parser = subparsers.add_parser(
        "validate-config",
        help="Validate an AEGIS YAML configuration file",
    )
    validate_parser.add_argument(
        "config_file",
        help="Path to YAML config file to validate",
    )
    validate_parser.set_defaults(func=cmd_validate_config)

    # version
    version_parser = subparsers.add_parser(
        "version",
        help="Show AEGIS version information",
    )
    version_parser.set_defaults(func=cmd_version)

    # health
    health_parser = subparsers.add_parser(
        "health",
        help="Check AEGIS system health",
    )
    health_parser.set_defaults(func=cmd_health)

    # metrics
    metrics_parser = subparsers.add_parser(
        "metrics",
        help="Dump current Prometheus metrics in text format",
    )
    metrics_parser.set_defaults(func=cmd_metrics)

    # --- admin ---
    admin_parser = subparsers.add_parser(
        "admin",
        help="Customer management and usage tracking commands",
    )
    admin_sub = admin_parser.add_subparsers(dest="admin_command")

    def _add_admin_common(p: argparse.ArgumentParser) -> None:
        """Add shared --table and --region args to an admin subparser."""
        p.add_argument(
            "--table", help="DynamoDB table name (default: AEGIS_TABLE_NAME env)"
        )
        p.add_argument("--region", help="AWS region (default: us-west-2)")

    # admin create-customer
    create_cust = admin_sub.add_parser("create-customer", help="Create a new customer")
    create_cust.add_argument("--name", required=True, help="Customer name")
    create_cust.add_argument("--email", required=True, help="Customer email")
    create_cust.add_argument("--company", default="", help="Company name")
    create_cust.add_argument(
        "--tier",
        default="community",
        choices=[
            "community",
            "professional",
            "enterprise",
            "financial_services",
            "free",
            "pro",
        ],
        help="Pricing tier (free/pro are aliases for community/professional)",
    )
    create_cust.add_argument(
        "--api-key-id",
        dest="api_key_id",
        default="",
        help="AWS API Gateway API key ID to associate",
    )
    _add_admin_common(create_cust)
    create_cust.set_defaults(func=cmd_admin_create_customer)

    # admin list-customers
    list_cust = admin_sub.add_parser("list-customers", help="List all customers")
    _add_admin_common(list_cust)
    list_cust.set_defaults(func=cmd_admin_list_customers)

    # admin get-customer
    get_cust = admin_sub.add_parser("get-customer", help="Get customer details by ID")
    get_cust.add_argument("customer_id", help="Customer ID (e.g., cust_abc123)")
    _add_admin_common(get_cust)
    get_cust.set_defaults(func=cmd_admin_get_customer)

    # admin usage
    usage_cmd = admin_sub.add_parser("usage", help="Get usage summary for a customer")
    usage_cmd.add_argument("customer_id", help="Customer ID")
    usage_cmd.add_argument(
        "--month", help="Month in YYYY-MM format (default: current month)"
    )
    _add_admin_common(usage_cmd)
    usage_cmd.set_defaults(func=cmd_admin_usage)

    return parser


def main() -> int:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    # Handle admin subcommand routing
    if args.command == "admin" and not getattr(args, "admin_command", None):
        # No admin subcommand — print usage hint
        print(
            json.dumps(
                {
                    "error": "No admin subcommand. Use: "
                    "aegis admin {create-customer|list-customers|get-customer|usage}"
                }
            ),
            file=sys.stderr,
        )
        return 1

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
