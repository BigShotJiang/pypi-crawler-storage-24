"""AFA Bridge

Bridges AEGIS guardrails with Autonomous Framework for Action (AFA) agents.
Provides the interface for autonomous agents to request decisions.

Integration with Guardrails v1.1.1:
- Uses GateEvaluator for proper Bayesian posterior gate calculations
- Risk/Profit gates use P(Delta>=2|data) > 0.95 threshold
- Novelty gate uses logistic function G(N)
- All gates return confidence scores and posterior probabilities
"""

import hashlib
import json
import logging
import math
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

# Import gate evaluator for proper Bayesian gate logic
from engine.gates import GateEvaluator, GateType
from engine.utility import UtilityResult

logger = logging.getLogger(__name__)


class DecisionType(str, Enum):
    """Types of decisions that can be requested."""

    PROPOSAL = "proposal"  # Full proposal evaluation
    RISK_CHECK = "risk_check"  # Quick risk gate check
    AUTHORIZATION = "authorization"  # Authorization request
    EXECUTION = "execution"  # Execution permission


class DecisionOutcome(str, Enum):
    """Possible decision outcomes."""

    APPROVED = "approved"
    REJECTED = "rejected"
    PENDING = "pending"
    ESCALATED = "escalated"
    ERROR = "error"


@dataclass
class DecisionRequest:
    """Request for a guardrail decision."""

    request_id: str
    decision_type: DecisionType
    agent_id: str
    context: dict[str, Any]
    urgency: str = "normal"  # low, normal, high, critical
    metadata: dict[str, Any] = field(default_factory=dict)
    requested_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return f"DecisionRequest({self.request_id}, {self.decision_type.value}, agent={self.agent_id})"


@dataclass
class DecisionResponse:
    """Response to a guardrail decision request."""

    request_id: str
    outcome: DecisionOutcome
    confidence: float
    gates_evaluated: list[str]
    gates_passed: list[str]
    gates_failed: list[str]
    rationale: str
    next_steps: list[str]
    expires_at: Optional[datetime] = None
    decision_hash: Optional[str] = None
    responded_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    agent_id: Optional[str] = None  # Agent that made the request (for filtering)

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return f"DecisionResponse({self.request_id}, {self.outcome.value}, confidence={self.confidence:.3f})"


class AFABridge:
    """Bridge between AEGIS guardrails and AFA agents.

    Provides a simplified interface for autonomous agents to:
    1. Request permission before actions
    2. Check risk levels
    3. Get authorization for sensitive operations
    4. Report execution outcomes

    Gate Evaluation Logic:
    - Risk gate: P(Delta>=2|data) > 0.95 triggers failure
    - Profit gate: P(Delta>=2|data) > 0.95 triggers failure
    - Novelty gate: G(N) = 1/(1+e^{-k(N-N0)}) >= 0.8
    - Complexity floor: C_norm >= 0.5 (hard requirement)
    - Quality gate: Q >= 0.7, no zero sub-scores
    - Utility LCB gate: LCB(U) > theta
    """

    def __init__(
        self,
        gate_evaluator: Optional[GateEvaluator] = None,
        utility_calculator: Any = None,  # UtilityCalculator instance
        default_timeout_hours: int = 24,
    ):
        """Initialize AFA bridge.

        Args:
            gate_evaluator: Gate evaluator instance for Bayesian gate calculations.
                If not provided, a default GateEvaluator is created.
            utility_calculator: Utility calculator instance
            default_timeout_hours: Default decision timeout

        """
        if isinstance(default_timeout_hours, bool):
            raise TypeError(
                f"default_timeout_hours must be numeric, got {type(default_timeout_hours).__name__}"
            )
        if isinstance(default_timeout_hours, float):
            if not math.isfinite(default_timeout_hours):
                raise ValueError(
                    f"default_timeout_hours must be a finite number, got {default_timeout_hours}"
                )
            if default_timeout_hours < 1:
                raise ValueError(
                    f"default_timeout_hours must be >= 1 (got {default_timeout_hours}); "
                    "fractional hours < 1 create impractically short timeouts"
                )
        if default_timeout_hours <= 0:
            raise ValueError(
                f"default_timeout_hours must be positive, got {default_timeout_hours}"
            )

        self.gate_evaluator = gate_evaluator or GateEvaluator()
        self.utility_calculator = utility_calculator
        self.default_timeout_hours = default_timeout_hours

        self.pending_requests: dict[str, DecisionRequest] = {}
        # Use deque with maxlen to prevent unbounded memory growth
        # Default: retain last 10,000 decisions (~1MB assuming 100 bytes each)
        self.decision_history: deque[DecisionResponse] = deque(maxlen=10000)

    def request_decision(
        self,
        request: DecisionRequest,
    ) -> DecisionResponse:
        """Request a guardrail decision.

        Args:
            request: Decision request

        Returns:
            DecisionResponse with outcome

        """
        self.pending_requests[request.request_id] = request

        try:
            # Route based on decision type
            if request.decision_type == DecisionType.PROPOSAL:
                response = self._evaluate_proposal(request)
            elif request.decision_type == DecisionType.RISK_CHECK:
                response = self._evaluate_risk_check(request)
            elif request.decision_type == DecisionType.AUTHORIZATION:
                response = self._evaluate_authorization(request)
            elif request.decision_type == DecisionType.EXECUTION:
                response = self._evaluate_execution(request)
            else:
                response = DecisionResponse(
                    request_id=request.request_id,
                    outcome=DecisionOutcome.ERROR,
                    confidence=0.0,
                    gates_evaluated=[],
                    gates_passed=[],
                    gates_failed=[],
                    rationale=f"Unknown decision type: {request.decision_type}",
                    next_steps=["Contact system administrator"],
                )

            # Compute decision hash for verification
            response.decision_hash = self._compute_decision_hash(request, response)

            # Track agent_id for history filtering (M3 fix)
            response.agent_id = request.agent_id

            # Store in history
            self.decision_history.append(response)
            return response
        finally:
            # Always clean up pending_requests, even on exception
            self.pending_requests.pop(request.request_id, None)

    @staticmethod
    def _coalesce_float(
        context: dict,
        key: str,
        default: float,
    ) -> float:
        """Return context[key] as float if present and non-None, else default.

        Handles the Python dict.get() quirk where .get(k, default) returns
        None when the key exists with an explicit null/None value.
        Rejects NaN/Inf from user-supplied values (transport parity with
        CLI and Lambda); defaults are returned as-is.
        """
        if key not in context:
            return default
        val = context[key]
        if val is None:
            return default
        if isinstance(val, bool):
            raise TypeError(f"Boolean value not allowed for numeric field {key}: {val}")
        result = float(val)
        if not math.isfinite(result):
            raise ValueError(f"Non-finite value for {key}: {val}")
        return result

    @staticmethod
    def _validate_quality_subscores(context: dict) -> list[float]:
        """Extract and validate quality_subscores from context.

        Returns validated list of finite floats.

        Behavior:
        - Missing key / None -> defaults [0.7, 0.7, 0.7]
        - All-null list -> defaults [0.7, 0.7, 0.7]
        - Explicit empty list -> [] (fail-safe at quality gate)
        """
        raw_subscores = context.get("quality_subscores", [0.7, 0.7, 0.7])
        if raw_subscores is None:
            raw_subscores = [0.7, 0.7, 0.7]
        if not isinstance(raw_subscores, list):
            raise TypeError(
                f"quality_subscores must be a list, got {type(raw_subscores).__name__}"
            )
        quality_subscores: list[float] = []
        saw_non_null = False
        for s in raw_subscores:
            if s is not None:
                saw_non_null = True
                if isinstance(s, bool):
                    raise TypeError("quality subscore must be numeric, got bool")
                v = float(s)
                if not math.isfinite(v):
                    raise ValueError(f"quality subscore must be finite, got {v}")
                quality_subscores.append(v)
        if quality_subscores:
            return quality_subscores
        if raw_subscores and not saw_non_null:
            return [0.7, 0.7, 0.7]
        return []

    def _extract_metrics(
        self,
        context: dict,
    ) -> tuple:
        """Extract and null-coalesce all gate metrics from context."""
        _c = self._coalesce_float
        risk_baseline = _c(context, "risk_baseline", 0.0)
        risk_proposed_raw = context.get("risk_proposed")
        if risk_proposed_raw is None:
            risk_delta = _c(context, "risk_delta", 0.0)
            risk_proposed = risk_baseline + risk_delta
        else:
            risk_proposed = _c(context, "risk_proposed", 0.0)

        profit_baseline = _c(context, "profit_baseline", 0.0)
        profit_proposed_raw = context.get("profit_proposed")
        if profit_proposed_raw is None:
            profit_delta = _c(context, "profit_delta", 0.0)
            profit_proposed = profit_baseline + profit_delta
        else:
            profit_proposed = _c(context, "profit_proposed", 0.0)

        novelty_score = _c(context, "novelty_score", 0.5)
        complexity_score = _c(context, "complexity_score", 0.5)
        quality_score = _c(context, "quality_score", 0.7)
        quality_subscores = self._validate_quality_subscores(context)

        utility_result = context.get("utility_result")
        if utility_result is not None and not isinstance(utility_result, UtilityResult):
            raise TypeError(
                f"utility_result must be a UtilityResult, got {type(utility_result).__name__}"
            )
        if utility_result is None:
            utility_lcb = _c(context, "utility_lcb", float("-inf"))
            utility_result = UtilityResult(
                raw=utility_lcb,
                variance=0.01,
                lcb=utility_lcb,
                components=None,
                decision_path="INVESTMENT",
            )

        return (
            risk_baseline,
            risk_proposed,
            profit_baseline,
            profit_proposed,
            novelty_score,
            complexity_score,
            quality_score,
            quality_subscores,
            utility_result,
        )

    def _evaluate_proposal(
        self,
        request: DecisionRequest,
    ) -> DecisionResponse:
        """Evaluate a full proposal through all gates using Bayesian gate logic.

        Uses GateEvaluator for proper posterior probability calculations:
        - Risk gate: P(Delta>=2|data) > 0.95 triggers failure
        - Profit gate: P(Delta>=2|data) > 0.95 triggers failure
        - Novelty gate: G(N) = 1/(1+e^{-k(N-N0)}) >= 0.8
        - Complexity floor: C_norm >= 0.5 (hard requirement, non-overridable)
        - Quality gate: Q >= 0.7, no zero sub-scores
        - Utility LCB gate: LCB(U) > theta

        Args:
            request: Decision request containing proposal context

        Returns:
            DecisionResponse with Bayesian confidence scores and audit trail

        """
        context = request.context

        # Evaluate all gates using GateEvaluator (proper Bayesian logic)
        try:
            # Extract metrics from context with null-coalescing
            (
                risk_baseline,
                risk_proposed,
                profit_baseline,
                profit_proposed,
                novelty_score,
                complexity_score,
                quality_score,
                quality_subscores,
                utility_result,
            ) = self._extract_metrics(context)

            gate_result = self.gate_evaluator.evaluate_all(
                risk_baseline=risk_baseline,
                risk_proposed=risk_proposed,
                profit_baseline=profit_baseline,
                profit_proposed=profit_proposed,
                novelty_score=novelty_score,
                complexity_score=complexity_score,
                quality_score=quality_score,
                quality_subscores=quality_subscores,
                utility_result=utility_result,
            )
        except (ValueError, TypeError, ZeroDivisionError, AttributeError) as e:
            logger.error(
                f"Gate evaluation failed for request {request.request_id}: {e}"
            )
            return DecisionResponse(
                request_id=request.request_id,
                outcome=DecisionOutcome.ERROR,
                confidence=0.0,
                gates_evaluated=[],
                gates_passed=[],
                gates_failed=["evaluation_error"],
                rationale=f"Gate evaluation failed: {e}",
                next_steps=["Investigate and fix invalid context data before retry"],
            )

        # Extract gate names for response
        gates_evaluated = [g.value for g in GateType]
        failing_gates = [g.gate_type.value for g in gate_result.get_failures()]
        gates_passed = [g for g in gates_evaluated if g not in failing_gates]
        gates_failed = failing_gates

        # Check if complexity floor failed (hard requirement)
        complexity_passed = gate_result.gates[GateType.COMPLEXITY].passed

        # Build detailed rationale with posterior probabilities for audit
        rationale_parts = []
        for gate_type, gate in gate_result.gates.items():
            if gate.posterior_probability is not None:
                rationale_parts.append(
                    f"{gate_type.value}: P(Delta>=2|data)={gate.posterior_probability:.3f}, "
                    f"confidence={gate.confidence:.3f}",
                )
            elif gate.message:
                rationale_parts.append(f"{gate_type.value}: {gate.message}")

        gate_detail = "; ".join(rationale_parts) if rationale_parts else ""

        # Determine outcome using gate evaluation results
        if gate_result.all_passed:
            outcome = DecisionOutcome.APPROVED
            rationale = (
                f"All gates passed (min confidence: {gate_result.min_confidence:.3f})"
            )
            if gate_detail:
                rationale += f". Detail: {gate_detail}"
            next_steps = ["Proceed with execution"]
        elif not complexity_passed:
            outcome = DecisionOutcome.REJECTED
            rationale = "Complexity floor not met (hard requirement, non-overridable)"
            next_steps = [
                "Restructure proposal to meet complexity floor (C_norm >= 0.5)",
            ]
        else:
            outcome = DecisionOutcome.ESCALATED
            rationale = f"Gates failed: {', '.join(gates_failed)}. Override eligible: {gate_result.override_eligible}"
            if gate_detail:
                rationale += f". Detail: {gate_detail}"
            next_steps = [
                "Request two-key override",
                "Revise proposal to address failing gates",
            ]

        # Use minimum confidence from gate evaluation
        confidence = gate_result.min_confidence

        return DecisionResponse(
            request_id=request.request_id,
            outcome=outcome,
            confidence=confidence,
            gates_evaluated=gates_evaluated,
            gates_passed=gates_passed,
            gates_failed=gates_failed,
            rationale=rationale,
            next_steps=next_steps,
        )

    def _evaluate_risk_check(
        self,
        request: DecisionRequest,
    ) -> DecisionResponse:
        """Quick risk gate check using Bayesian posterior calculation.

        Uses GateEvaluator._evaluate_risk_gate() for proper Bayesian logic:
        - Computes P(Delta>=2|data) posterior probability
        - Gate passes if posterior < 0.95 (low probability of exceeding trigger)
        - Returns posterior probability and confidence in response

        Args:
            request: Decision request with risk context

        Returns:
            DecisionResponse with posterior probability in rationale

        """
        context = request.context

        # Use GateEvaluator public API for Bayesian risk gate evaluation
        try:
            # BH17-M1: use _coalesce_float for NaN/Inf rejection + None handling
            risk_baseline = self._coalesce_float(context, "risk_baseline", 0.0)
            risk_proposed_raw = context.get("risk_proposed")

            # Backward compat: if risk_delta provided, compute proposed from delta
            if risk_proposed_raw is None:
                risk_delta = self._coalesce_float(context, "risk_delta", 0.0)
                risk_proposed = risk_baseline + risk_delta
            else:
                risk_proposed = self._coalesce_float(context, "risk_proposed", 0.0)

            risk_gate = self.gate_evaluator.evaluate_risk_gate(
                baseline=risk_baseline,
                proposed=risk_proposed,
            )
        except (ValueError, TypeError, ZeroDivisionError, AttributeError) as e:
            logger.error(
                f"Risk gate evaluation failed for request {request.request_id}: {e}"
            )
            return DecisionResponse(
                request_id=request.request_id,
                outcome=DecisionOutcome.ERROR,
                confidence=0.0,
                gates_evaluated=["risk"],
                gates_passed=[],
                gates_failed=["evaluation_error"],
                rationale=f"Risk gate evaluation failed: {e}",
                next_steps=[
                    "Investigate and fix invalid risk context data before retry"
                ],
            )

        passed = risk_gate.passed
        posterior = (
            risk_gate.posterior_probability
            if risk_gate.posterior_probability is not None
            else 0.0
        )
        confidence = (
            risk_gate.confidence
            if risk_gate.confidence is not None
            else (1.0 - posterior)
        )

        # Build informative rationale with Bayesian details
        rationale = (
            f"Risk gate: P(Delta>=2|data) = {posterior:.3f}. "
            f"Threshold: 0.95. "
            f"{'Passed' if passed else 'Failed'} (confidence: {confidence:.3f})"
        )

        return DecisionResponse(
            request_id=request.request_id,
            outcome=DecisionOutcome.APPROVED if passed else DecisionOutcome.REJECTED,
            confidence=confidence,
            gates_evaluated=["risk"],
            gates_passed=["risk"] if passed else [],
            gates_failed=[] if passed else ["risk"],
            rationale=rationale,
            next_steps=[
                "Continue" if passed else "Mitigate risk to reduce P(Delta>=2|data)",
            ],
        )

    def _evaluate_authorization(
        self,
        request: DecisionRequest,
    ) -> DecisionResponse:
        """Evaluate authorization request."""
        try:
            context = request.context

            # Guard against JSON null while preserving explicit falsy values.
            # Using `or []` fail-opens invalid falsy types (e.g., 0) into [].
            raw_required = context.get("required_authorizations")
            raw_provided = context.get("provided_authorizations")
            required = [] if raw_required is None else raw_required
            provided = [] if raw_provided is None else raw_provided

            # Guard against string-as-iterable: set("admin") → {'a','d','m','i','n'}
            if isinstance(required, str):
                required = [required]
            if isinstance(provided, str):
                provided = [provided]

            missing = set(required) - set(provided)

            if not missing:
                return DecisionResponse(
                    request_id=request.request_id,
                    outcome=DecisionOutcome.APPROVED,
                    confidence=1.0,
                    gates_evaluated=["authorization"],
                    gates_passed=["authorization"],
                    gates_failed=[],
                    rationale="All required authorizations provided",
                    next_steps=["Proceed"],
                )
            return DecisionResponse(
                request_id=request.request_id,
                outcome=DecisionOutcome.PENDING,
                confidence=0.0,
                gates_evaluated=["authorization"],
                gates_passed=[],
                gates_failed=["authorization"],
                rationale=f"Missing authorizations: {', '.join(sorted(missing))}",
                next_steps=[f"Obtain {auth} authorization" for auth in sorted(missing)],
            )
        except (ValueError, TypeError, AttributeError) as e:
            logger.error(
                f"Authorization evaluation failed for request {request.request_id}: {e}"
            )
            return DecisionResponse(
                request_id=request.request_id,
                outcome=DecisionOutcome.ERROR,
                confidence=0.0,
                gates_evaluated=["authorization"],
                gates_passed=[],
                gates_failed=["evaluation_error"],
                rationale=f"Authorization evaluation failed: {e}",
                next_steps=["Investigate authorization context data"],
            )

    def _evaluate_execution(
        self,
        request: DecisionRequest,
    ) -> DecisionResponse:
        """Evaluate execution permission request."""
        context = request.context

        # Check if proposal was approved (strict boolean validation)
        proposal_approved = context.get("proposal_approved", False)
        has_execution_plan = context.get("has_execution_plan", False)
        if not isinstance(proposal_approved, bool) or not isinstance(
            has_execution_plan, bool
        ):
            return DecisionResponse(
                request_id=request.request_id,
                outcome=DecisionOutcome.ERROR,
                confidence=0.0,
                gates_evaluated=["execution"],
                gates_passed=[],
                gates_failed=["type_error"],
                rationale="proposal_approved and has_execution_plan must be boolean",
                next_steps=["Fix context data types"],
            )

        if proposal_approved and has_execution_plan:
            return DecisionResponse(
                request_id=request.request_id,
                outcome=DecisionOutcome.APPROVED,
                confidence=0.95,
                gates_evaluated=["execution"],
                gates_passed=["execution"],
                gates_failed=[],
                rationale="Proposal approved and execution plan present",
                next_steps=["Execute according to plan"],
            )
        issues = []
        if not proposal_approved:
            issues.append("proposal not approved")
        if not has_execution_plan:
            issues.append("execution plan missing")

        return DecisionResponse(
            request_id=request.request_id,
            outcome=DecisionOutcome.REJECTED,
            confidence=0.0,
            gates_evaluated=["execution"],
            gates_passed=[],
            gates_failed=["execution"],
            rationale=f"Execution blocked: {', '.join(issues)}",
            next_steps=["Obtain approval", "Create execution plan"],
        )

    def _compute_decision_hash(
        self,
        request: DecisionRequest,
        response: DecisionResponse,
    ) -> str:
        """Compute hash of decision for verification.

        The hash includes all fields that affect the decision outcome:
        - request_id: Links to original request
        - agent_id: Identity of requesting agent
        - outcome: The decision result
        - confidence: Confidence score (derived but critical for tamper detection)
        - gates_passed/failed: Which gates passed or failed
        - timestamp: When the decision was made

        Note:
            The confidence field is included even though it's derived from
            gate evaluation, because tampering with confidence could mislead
            downstream systems about decision reliability.
        """
        data = json.dumps(
            {
                "request_id": request.request_id,
                "agent_id": request.agent_id,
                "outcome": response.outcome.value,
                "confidence": response.confidence,
                "gates_passed": sorted(response.gates_passed),
                "gates_failed": sorted(response.gates_failed),
                "timestamp": response.responded_at.isoformat(),
            },
            sort_keys=True,
        )

        return hashlib.sha256(data.encode()).hexdigest()

    def verify_decision(
        self,
        response: DecisionResponse,
        original_request: DecisionRequest,
    ) -> bool:
        """Verify a decision hasn't been tampered with."""
        expected_hash = self._compute_decision_hash(original_request, response)
        return response.decision_hash == expected_hash

    def get_decision_history(
        self,
        agent_id: Optional[str] = None,
        limit: int = 100,
    ) -> list[DecisionResponse]:
        """Get decision history, optionally filtered by agent.

        Args:
            agent_id: Filter by agent ID (None returns all)
            limit: Maximum number of decisions to return (must be positive)

        Returns:
            List of DecisionResponse, most recent last

        Raises:
            ValueError: If limit is not positive
        """
        if isinstance(limit, bool) or not isinstance(limit, int):
            raise TypeError(f"limit must be an integer, got {type(limit).__name__}")
        if limit <= 0:
            raise ValueError(f"limit must be positive, got {limit}")

        # Convert deque to list for processing
        history_list = list(self.decision_history)

        # Filter by agent_id if specified (M3 fix)
        if agent_id is not None:
            history_list = [r for r in history_list if r.agent_id == agent_id]

        # Apply limit (return most recent)
        return history_list[-limit:]
