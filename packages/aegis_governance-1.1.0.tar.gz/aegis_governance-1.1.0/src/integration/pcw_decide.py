"""PCW Decide Interface

Implements the Plan-Commit-Work decision function for AFA agents.
This is the primary entry point for autonomous agents to request
guardrail evaluation.

Integration with Guardrails v1.1.1:
- Uses GateEvaluator for proper Bayesian posterior gate calculations
- Risk/Profit gates use P(Δ≥2|data) > 0.95 threshold
- Novelty gate uses logistic function G(N)
- All gates return confidence scores

GAP-L1 Integration:
    Prometheus metrics are recorded for each decision when prometheus_exporter
    is provided, tracking decision outcomes and end-to-end latency.
"""

import hashlib
import logging
import time
import uuid
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

# Import gate evaluator for proper Bayesian gate logic
from engine.gates import GateEvaluationResult, GateEvaluator, GateType
from engine.utility import UtilityComponents, UtilityResult

if TYPE_CHECKING:
    from engine.drift import DriftMonitor, DriftResult
    from rbac import RBACEnforcer
    from telemetry.emitter import TelemetryEmitter
    from telemetry.prometheus_exporter import PrometheusExporter

logger = logging.getLogger(__name__)


class PCWPhase(str, Enum):
    """PCW lifecycle phases."""

    PLAN = "plan"  # Planning phase - evaluate feasibility
    COMMIT = "commit"  # Commit phase - authorize execution
    WORK = "work"  # Work phase - execute with monitoring


class PCWStatus(str, Enum):
    """PCW decision status."""

    PROCEED = "proceed"  # Safe to proceed
    PAUSE = "pause"  # Pause for human review
    HALT = "halt"  # Stop immediately
    ESCALATE = "escalate"  # Escalate to higher authority


@dataclass
class PCWContext:
    """Context for PCW decision."""

    # Agent identification
    agent_id: str
    session_id: str

    # Current phase
    phase: PCWPhase

    # Proposal details
    proposal_summary: str
    estimated_impact: str  # low, medium, high, critical

    # Metrics for evaluation
    risk_baseline: float = 0.0
    risk_proposed: float = 0.0
    profit_baseline: float = 0.0
    profit_proposed: float = 0.0
    novelty_score: float = 0.5
    complexity_score: float = 0.5
    quality_score: float = 0.7

    # Optional detailed metrics for full gate evaluation
    quality_subscores: list[float] = field(default_factory=lambda: [0.7, 0.7, 0.7])
    utility_result: Optional[UtilityResult] = None

    # Execution context
    requires_human_approval: bool = False
    time_sensitive: bool = False
    reversible: bool = True

    # Additional metadata
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PCWDecision:
    """Decision result from pcw_decide."""

    # Decision outcome
    status: PCWStatus
    confidence: float

    # Gate results
    gates_passed: int
    gates_failed: int
    failing_gates: list[str]

    # Guidance
    rationale: str
    next_steps: list[str]
    constraints: list[str]

    # Audit trail
    decision_id: str
    timestamp: datetime

    # Override eligibility
    override_eligible: bool
    override_requires: list[str]

    # Detailed gate evaluation result (for full audit trail)
    gate_evaluation: Optional[GateEvaluationResult] = None

    # Structured decision trace (deterministic, audit-friendly)
    decision_trace: Optional["DecisionTrace"] = None

    # Shadow mode metadata (populated when shadow_mode=True)
    shadow_result: Optional["ShadowResult"] = None

    # Drift policy enforcement result (populated when drift_monitor provided
    # in production mode and drift is detected)
    drift_result: Optional["DriftResult"] = None


@dataclass
class DecisionTrace:
    """Structured trace of decision inputs, gate outputs, and summary."""

    decision_id: str
    timestamp: datetime
    context_snapshot: dict[str, Any]
    metric_snapshot: dict[str, Any]
    gate_summaries: list[dict[str, Any]]
    decision_summary: dict[str, Any]


@dataclass
class ShadowResult:
    """Shadow mode evaluation metadata.

    Attached to PCWDecision.shadow_result when shadow_mode=True.
    Contains drift analysis from the proposal's risk/profit deltas.
    """

    drift_result: Optional["DriftResult"] = None
    observation_values: list[float] = field(default_factory=list)
    baseline_hash: Optional[str] = None
    shadow_only: bool = True


def pcw_decide(
    context: PCWContext,
    gate_evaluator: Optional[GateEvaluator] = None,
    prometheus_exporter: Optional["PrometheusExporter"] = None,
    rbac_enforcer: Optional["RBACEnforcer"] = None,
    *,
    shadow_mode: bool = False,
    drift_monitor: Optional["DriftMonitor"] = None,
    telemetry_emitter: Optional["TelemetryEmitter"] = None,
) -> PCWDecision:
    """Primary decision function for AFA agents.

    Evaluates the proposal context against guardrail gates using the
    GateEvaluator for proper Bayesian posterior calculations.

    Args:
        context: PCW context with proposal details and metrics
        gate_evaluator: Optional pre-configured gate evaluator. If not
            provided, uses default configuration.
        prometheus_exporter: Optional Prometheus exporter for metrics (GAP-L1)
        rbac_enforcer: Optional RBAC enforcer. When provided, checks that
            context.agent_id has submit_proposals permission. Advisory only —
            does not break existing API when not provided.
        shadow_mode: When True, collects drift data without enforcing
            decisions. Gates still evaluate normally. Default False.
        drift_monitor: Optional DriftMonitor instance. In production mode,
            CRITICAL drift halts the decision (non-overridable); WARNING
            drift adds an advisory constraint. In shadow mode, drift is
            evaluated for calibration data only.
        telemetry_emitter: Optional TelemetryEmitter. Emits
            DRIFT_POLICY_ENFORCED events (production) and
            SHADOW_EVALUATION events (shadow mode).

    Returns:
        PCWDecision with status and guidance

    Example:
        >>> context = PCWContext(
        ...     agent_id="agent-001",
        ...     session_id="session-abc",
        ...     phase=PCWPhase.PLAN,
        ...     proposal_summary="Add caching layer",
        ...     estimated_impact="medium",
        ...     risk_proposed=0.3,
        ...     complexity_score=0.6,
        ... )
        >>> decision = pcw_decide(context)
        >>> if decision.status == PCWStatus.PROCEED:
        ...     # Safe to continue
        ...     pass

    """
    # RBAC permission check (advisory — does not block if enforcer absent)
    if rbac_enforcer is not None and not rbac_enforcer.has_permission(
        context.agent_id, "submit_proposals"
    ):
        logger.warning("RBAC denied submit_proposals for agent %s", context.agent_id)
        return PCWDecision(
            status=PCWStatus.HALT,
            confidence=1.0,
            gates_passed=0,
            gates_failed=0,
            failing_gates=["rbac_denied"],
            rationale=f"Agent {context.agent_id!r} lacks submit_proposals permission",
            next_steps=["Contact administrator to assign appropriate role"],
            constraints=["RBAC: submit_proposals permission required"],
            decision_id=str(uuid.uuid4()),
            timestamp=datetime.now(timezone.utc),
            override_eligible=False,
            override_requires=[],
        )

    # Start timing for decision latency (GAP-L1)
    start_time = time.time()

    decision_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc)

    # Use provided evaluator or create default
    evaluator = gate_evaluator or GateEvaluator()

    # Evaluate all gates using GateEvaluator (proper Bayesian logic)
    # Wrap in try/except to handle invalid input data gracefully
    # M-ENG-005 fix: Added AttributeError for malformed context objects
    # The try block covers all context attribute access to catch malformed inputs
    try:
        # Create default utility result if not provided
        # UtilityResult requires: raw, variance, lcb, components, decision_path
        #
        # IMPORTANT: Default uses lcb=float('-inf') for FAIL-CLOSED behavior.
        # When utility is not provided, the utility gate should FAIL, requiring
        # explicit utility calculation for approval. This prevents unexpected
        # approvals when utility computation is missing.
        # See multi-model-coherence-review.md (I1).
        utility_result = context.utility_result
        if utility_result is None:
            default_components = UtilityComponents(
                profit_high_conf=0.0,
                value_low_conf=0.0,
                risk_adjustment=0.0,
                complexity_tax=0.0,
                opex_delta=0.0,
            )
            utility_result = UtilityResult(
                raw=0.0,
                variance=0.01,  # Small variance for default
                lcb=float("-inf"),  # Fail-closed: missing utility fails gate
                components=default_components,
                decision_path="INVESTMENT",
            )

        gate_result = evaluator.evaluate_all(
            risk_baseline=context.risk_baseline,
            risk_proposed=context.risk_proposed,
            profit_baseline=context.profit_baseline,
            profit_proposed=context.profit_proposed,
            novelty_score=context.novelty_score,
            complexity_score=context.complexity_score,
            quality_score=context.quality_score,
            quality_subscores=context.quality_subscores,
            utility_result=utility_result,
        )
    except (ValueError, TypeError, ZeroDivisionError, AttributeError) as e:
        logger.error(f"Gate evaluation failed: {e}")
        return PCWDecision(
            status=PCWStatus.HALT,
            confidence=0.0,
            gates_passed=0,
            gates_failed=0,
            failing_gates=["evaluation_error"],
            rationale=f"Gate evaluation failed: {e}",
            next_steps=["Investigate and fix invalid context data before retry"],
            constraints=[str(e)],
            decision_id=decision_id,
            timestamp=timestamp,
            override_eligible=False,
            override_requires=[],
        )

    # Extract results from gate evaluation
    failing_gates = [g.gate_type.value for g in gate_result.get_failures()]
    gates_failed = len(failing_gates)
    gates_passed = len(gate_result.gates) - gates_failed
    constraints = []

    # Check if complexity floor failed (hard requirement)
    complexity_passed = gate_result.gates[GateType.COMPLEXITY].passed
    if not complexity_passed:
        constraints.append("Complexity floor not met - cannot be overridden")

    # Determine if human approval is required even when all gates pass
    risk_gate = gate_result.gates[GateType.RISK]
    risk_posterior = (
        risk_gate.posterior_probability
        if risk_gate.posterior_probability is not None
        else 0.0
    )
    _impact = (
        context.estimated_impact.lower()
        if isinstance(context.estimated_impact, str)
        else context.estimated_impact
    )
    high_impact = _impact in ("high", "critical")
    human_required = (
        high_impact
        or not context.reversible
        or context.requires_human_approval
        or risk_posterior >= 0.5
    )

    # Determine status using gate evaluation results
    total_gates = gates_passed + gates_failed
    all_passed = gate_result.all_passed

    if all_passed:
        if human_required:
            status = PCWStatus.ESCALATE if high_impact else PCWStatus.PAUSE
            rationale = (
                "High impact proposal requires human approval"
                if high_impact
                else "Human approval required"
            )
            confidence = gate_result.min_confidence
        else:
            status = PCWStatus.PROCEED
            rationale = f"All {total_gates} gates passed (Bayesian confidence)"
            confidence = gate_result.min_confidence
    elif not complexity_passed:
        status = PCWStatus.HALT
        rationale = "Complexity floor not met (hard requirement)"
        confidence = 1.0
    elif high_impact:
        status = PCWStatus.ESCALATE
        rationale = (
            f"High impact proposal with failing gates: {', '.join(failing_gates)}"
        )
        confidence = gate_result.min_confidence
    elif human_required:
        status = PCWStatus.PAUSE
        rationale = "Human approval required"
        confidence = gate_result.min_confidence
    else:
        status = PCWStatus.PAUSE
        rationale = f"Gates failed: {', '.join(failing_gates)}"
        confidence = gate_result.min_confidence

    # Determine next steps based on phase and status
    next_steps = _get_next_steps(context.phase, status, failing_gates)

    # Use gate evaluation's override eligibility
    override_eligible = gate_result.override_eligible
    override_requires = ["risk_lead", "security_lead"] if override_eligible else []

    decision_trace = _build_decision_trace(
        context=context,
        decision_id=decision_id,
        timestamp=timestamp,
        gate_result=gate_result,
        gates_passed=gates_passed,
        gates_failed=gates_failed,
        utility_result=utility_result,
    )

    # Drift policy enforcement (production mode only)
    drift_result_val: Optional[DriftResult] = None
    if not shadow_mode:
        status, constraints, drift_result_val = _evaluate_drift_policy(
            drift_monitor=drift_monitor,
            context=context,
            current_status=status,
            constraints=constraints,
            telemetry_emitter=telemetry_emitter,
            decision_id=decision_id,
        )
        # Critical drift is non-overridable (same as complexity floor);
        # also recomputes next_steps since status may have changed.
        override_eligible, override_requires, rationale, next_steps = (
            _apply_drift_overrides(
                drift_result_val,
                status,
                override_eligible,
                override_requires,
                rationale,
                context.phase,
                failing_gates,
                next_steps=next_steps,
            )
        )

    # Shadow mode + metrics recording
    latency = time.time() - start_time
    shadow_result = _record_and_shadow(
        shadow_mode=shadow_mode,
        context=context,
        decision_id=decision_id,
        status_value=status.value,
        gates_passed=gates_passed,
        gates_total=total_gates,
        latency=latency,
        drift_monitor=drift_monitor,
        telemetry_emitter=telemetry_emitter,
        prometheus_exporter=prometheus_exporter,
    )

    return PCWDecision(
        status=status,
        confidence=confidence,
        gates_passed=gates_passed,
        gates_failed=gates_failed,
        failing_gates=failing_gates,
        rationale=rationale,
        next_steps=next_steps,
        constraints=constraints,
        decision_id=decision_id,
        timestamp=timestamp,
        override_eligible=override_eligible,
        override_requires=override_requires,
        gate_evaluation=gate_result,
        decision_trace=decision_trace,
        shadow_result=shadow_result,
        drift_result=drift_result_val,
    )


def _apply_drift_overrides(
    drift_result: Optional["DriftResult"],
    status: PCWStatus,
    override_eligible: bool,
    override_requires: list[str],
    rationale: str,
    phase: "PCWPhase",
    failing_gates: list[str],
    next_steps: Optional[list[str]] = None,
) -> tuple[bool, list[str], str, list[str]]:
    """Disable overrides, update rationale, and recompute next_steps after drift.

    Args:
        next_steps: Caller's already-computed next_steps. When drift_result is
            None, these are returned unchanged (BH45-D1: avoids discarding
            caller's original steps via unconditional recomputation).

    Returns:
        (override_eligible, override_requires, rationale, next_steps)
    """
    if drift_result is None:
        if next_steps is None:
            next_steps = _get_next_steps(phase, status, failing_gates)
        return override_eligible, override_requires, rationale, next_steps

    next_steps = _get_next_steps(phase, status, failing_gates)

    from engine.drift import DriftStatus as _DriftStatus

    if drift_result.status == _DriftStatus.CRITICAL and status == PCWStatus.HALT:
        override_eligible = False
        override_requires = []
        if "drift" not in rationale.lower():
            rationale = f"{rationale}; critical distribution drift detected"
        next_steps = [
            "Stop all work on this proposal",
            "Recalibrate drift baseline before resubmitting",
        ]
    elif drift_result.status == _DriftStatus.WARNING:
        # FC-5: WARNING drift adds recalibration guidance to next_steps
        # without blocking the decision (advisory only).
        if "drift" not in rationale.lower():
            rationale = (
                f"{rationale}; distribution drift warning "
                f"(KL={drift_result.kl_divergence:.4f})"
            )
        next_steps.append("Review baseline calibration — drift warning detected")
    return override_eligible, override_requires, rationale, next_steps


def _evaluate_drift_policy(
    drift_monitor: Optional["DriftMonitor"],
    context: PCWContext,
    current_status: PCWStatus,
    constraints: list[str],
    telemetry_emitter: Optional["TelemetryEmitter"],
    decision_id: str,
) -> tuple[PCWStatus, list[str], Optional["DriftResult"]]:
    """Evaluate drift and upgrade status if necessary.

    Rules:
    - CRITICAL drift -> HALT (non-overridable)
    - WARNING drift -> add constraint (advisory)
    - NORMAL drift / no monitor -> no change
    - Never downgrades status (HALT stays HALT)

    Returns:
        (possibly_upgraded_status, updated_constraints, drift_result)
    """
    if drift_monitor is None:
        return (current_status, list(constraints), None)

    observation_values = [
        context.risk_proposed - context.risk_baseline,
        context.profit_proposed - context.profit_baseline,
    ]

    try:
        drift_eval = drift_monitor.evaluate(observation_values)
    except ValueError:
        logger.debug("Drift policy skipped: baseline not set")
        return (current_status, list(constraints), None)

    from engine.drift import DriftStatus as _DriftStatus

    status = current_status
    updated_constraints = list(constraints)

    if drift_eval.status == _DriftStatus.CRITICAL:
        if status != PCWStatus.HALT:
            status = PCWStatus.HALT
        updated_constraints.append(
            f"Critical distribution drift detected (KL={drift_eval.kl_divergence:.4f})"
            " — decision halted for recalibration"
        )
    elif drift_eval.status == _DriftStatus.WARNING:
        updated_constraints.append(
            f"Distribution drift warning (KL={drift_eval.kl_divergence:.4f})"
            " — review baseline calibration"
        )

    # Emit telemetry if drift is non-normal
    if telemetry_emitter is not None and drift_eval.status != _DriftStatus.NORMAL:
        from telemetry.emitter import EventType

        telemetry_emitter.emit(
            EventType.DRIFT_POLICY_ENFORCED,
            payload={
                "decision_id": decision_id,
                "drift_status": drift_eval.status.value,
                "kl_divergence": drift_eval.kl_divergence,
                "action": drift_eval.action.value,
            },
            correlation_id=decision_id,
        )

    return (status, updated_constraints, drift_eval)


def _record_and_shadow(
    shadow_mode: bool,
    context: PCWContext,
    decision_id: str,
    status_value: str,
    gates_passed: int,
    gates_total: int,
    latency: float,
    drift_monitor: Optional["DriftMonitor"],
    telemetry_emitter: Optional["TelemetryEmitter"],
    prometheus_exporter: Optional["PrometheusExporter"],
) -> Optional[ShadowResult]:
    """Record metrics and optionally evaluate shadow mode.

    Extracted from pcw_decide() to keep branch count within PLR0912 limits.
    Handles both Prometheus recording (production + shadow) and shadow-mode
    drift evaluation + telemetry emission.
    """
    mode = "shadow" if shadow_mode else "production"

    if prometheus_exporter is not None:
        prometheus_exporter.record_decision(
            status=status_value,
            gates_passed=gates_passed,
            gates_total=gates_total,
            latency=latency,
            mode=mode,
        )
        if shadow_mode:
            prometheus_exporter.record_shadow_evaluation(status=status_value)

    if not shadow_mode:
        return None
    observation_values = [
        context.risk_proposed - context.risk_baseline,
        context.profit_proposed - context.profit_baseline,
    ]
    drift_eval: Optional[DriftResult] = None
    baseline_hash: Optional[str] = None

    if drift_monitor is not None:
        try:
            drift_eval = drift_monitor.evaluate(observation_values)
            baseline_hash = drift_eval.baseline_hash
        except ValueError:
            logger.debug("Shadow mode drift evaluation skipped: baseline not set")

    # Emit shadow telemetry event
    if telemetry_emitter is not None:
        from telemetry.emitter import EventType

        drift_payload: dict[str, Any] = {}
        if drift_eval is not None:
            drift_payload = {
                "drift_kl": drift_eval.kl_divergence,
                "drift_status": drift_eval.status.value,
                "drift_action": drift_eval.action.value,
            }
        telemetry_emitter.emit(
            EventType.SHADOW_EVALUATION,
            payload={
                "decision_id": decision_id,
                "status": status_value,
                "gates_passed": gates_passed,
                "gates_total": gates_total,
                **drift_payload,
            },
            correlation_id=decision_id,
        )

    return ShadowResult(
        drift_result=drift_eval,
        observation_values=observation_values,
        baseline_hash=baseline_hash,
        shadow_only=True,
    )


# Lookup tables for _get_next_steps to reduce cyclomatic complexity
_PROCEED_PHASE_STEPS: dict[PCWPhase, str] = {
    PCWPhase.PLAN: "Move to COMMIT phase",
    PCWPhase.COMMIT: "Move to WORK phase",
    PCWPhase.WORK: "Continue execution",
}

_STATUS_STEPS: dict[PCWStatus, list[str]] = {
    PCWStatus.HALT: [
        "Stop all work on this proposal",
        "Revise proposal to meet complexity floor",
    ],
    PCWStatus.ESCALATE: [
        "Escalate to Risk Lead for review",
        "Prepare justification document",
    ],
}

_GATE_REMEDIATION: dict[str, str] = {
    "risk": "Review and mitigate identified risks",
    "profit": "Improve profit projections or reduce scope",
    "novelty": "Document precedents or increase novelty score",
    "complexity": "Reduce complexity or decompose into smaller changes",
    "quality": "Improve proposal quality score",
    "utility": "Improve expected utility or adjust cost-benefit parameters",
}


def _get_next_steps(
    phase: PCWPhase,
    status: PCWStatus,
    failing_gates: list[str],
) -> list[str]:
    """Generate next steps based on phase and status."""
    # Handle PROCEED status with phase-specific step
    if status == PCWStatus.PROCEED:
        return [_PROCEED_PHASE_STEPS.get(phase, "Continue execution")]

    # Handle HALT and ESCALATE statuses
    if status in _STATUS_STEPS:
        return list(_STATUS_STEPS[status])

    # PAUSE status: generate remediation steps for each failing gate
    steps = [
        _GATE_REMEDIATION[gate] for gate in failing_gates if gate in _GATE_REMEDIATION
    ]

    if failing_gates:
        steps.append("Request override if gates cannot be satisfied")

    if not steps and status == PCWStatus.PAUSE:
        steps = ["Await human approval before proceeding"]

    return steps


def _normalize_summary(summary: Any) -> str:
    """Normalize proposal summary to text for deterministic tracing."""
    if isinstance(summary, str):
        return summary
    if isinstance(summary, bytes):
        return summary.decode("utf-8", errors="replace")
    if summary is None:
        return ""
    return str(summary)


def _hash_summary(summary: Any) -> str:
    """Hash proposal summary to avoid storing raw content in trace data."""
    normalized = _normalize_summary(summary)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _build_decision_trace(
    context: PCWContext,
    decision_id: str,
    timestamp: datetime,
    gate_result: GateEvaluationResult,
    gates_passed: int,
    gates_failed: int,
    utility_result: Optional[UtilityResult] = None,
) -> DecisionTrace:
    """Build a structured, audit-friendly decision trace."""
    summary_text = _normalize_summary(context.proposal_summary)
    metadata_obj = context.metadata
    if not isinstance(metadata_obj, Mapping):
        logger.warning(
            "PCWContext.metadata is %s; expected mapping. Using empty metadata_keys.",
            type(metadata_obj).__name__,
        )
        metadata_obj = {}

    gate_summaries = [
        {
            "gate": gate.gate_type.value,
            "passed": gate.passed,
            "value": gate.value,
            "threshold": gate.threshold,
            "margin": gate.margin,
            "confidence": gate.confidence,
            "posterior_probability": gate.posterior_probability,
            "message": gate.message,
        }
        for gate in gate_result.gates.values()
    ]

    context_snapshot = {
        "agent_id": context.agent_id,
        "session_id": context.session_id,
        "phase": context.phase.value,
        "estimated_impact": context.estimated_impact,
        "proposal_summary_sha256": _hash_summary(summary_text),
        "proposal_summary_length": len(summary_text),
        "requires_human_approval": context.requires_human_approval,
        "time_sensitive": context.time_sensitive,
        "reversible": context.reversible,
        "metadata_keys": sorted(str(key) for key in metadata_obj),
    }

    utility_snapshot = None
    if utility_result is not None:
        utility_snapshot = {
            "raw": utility_result.raw,
            "variance": utility_result.variance,
            "lcb": utility_result.lcb,
            "decision_path": utility_result.decision_path,
            "components": (
                {
                    "profit_high_conf": utility_result.components.profit_high_conf,
                    "value_low_conf": utility_result.components.value_low_conf,
                    "risk_adjustment": utility_result.components.risk_adjustment,
                    "complexity_tax": utility_result.components.complexity_tax,
                    "opex_delta": utility_result.components.opex_delta,
                }
                if utility_result.components is not None
                else None
            ),
        }

    metric_snapshot = {
        "risk_baseline": context.risk_baseline,
        "risk_proposed": context.risk_proposed,
        "profit_baseline": context.profit_baseline,
        "profit_proposed": context.profit_proposed,
        "novelty_score": context.novelty_score,
        "complexity_score": context.complexity_score,
        "quality_score": context.quality_score,
        "quality_subscores": list(context.quality_subscores),
        "utility_result": utility_snapshot,
    }

    decision_summary = {
        "all_passed": gate_result.all_passed,
        "override_eligible": gate_result.override_eligible,
        "min_confidence": gate_result.min_confidence,
        "gates_passed": gates_passed,
        "gates_failed": gates_failed,
    }

    return DecisionTrace(
        decision_id=decision_id,
        timestamp=timestamp,
        context_snapshot=context_snapshot,
        metric_snapshot=metric_snapshot,
        gate_summaries=gate_summaries,
        decision_summary=decision_summary,
    )


def quick_risk_check(
    agent_id: str,
    action_description: str,
    risk_score: float,
    threshold: float = 0.5,
) -> bool:
    """Quick risk check for simple actions.

    Returns True if action is safe to proceed, False otherwise.

    Warning:
        This is a SIMPLIFIED check that performs a direct threshold comparison
        WITHOUT using the Bayesian GateEvaluator. It does NOT compute posterior
        probabilities or apply the full risk gate logic. For governance decisions
        that require audit trails or regulatory compliance, use pcw_decide() or
        require_human_approval() instead, which use proper Bayesian evaluation.

    Args:
        agent_id: Agent identifier (logged for audit but not used in calculation)
        action_description: Brief description of action (for documentation only)
        risk_score: Estimated risk score (0-1)
        threshold: Risk threshold (default 0.5)

    Returns:
        True if risk_score < threshold (safe to proceed)

    """
    logger.debug(
        f"quick_risk_check: agent={agent_id}, action={action_description!r}, "
        f"risk={risk_score}, threshold={threshold}"
    )
    return risk_score < threshold


def require_human_approval(
    context: PCWContext,
    gate_evaluator: Optional[GateEvaluator] = None,
) -> bool:
    """Determine if proposal requires human approval.

    Uses GateEvaluator for proper Bayesian risk assessment.

    Args:
        context: PCW context
        gate_evaluator: Optional pre-configured gate evaluator

    Returns:
        True if human approval required

    """
    # High/critical impact always requires approval
    _impact = (
        context.estimated_impact.lower()
        if isinstance(context.estimated_impact, str)
        else context.estimated_impact
    )
    if _impact in ("high", "critical"):
        return True

    # Irreversible actions require approval
    if not context.reversible:
        return True

    # Explicitly marked as requiring approval
    if context.requires_human_approval:
        return True

    # Use GateEvaluator for proper Bayesian risk assessment
    evaluator = gate_evaluator or GateEvaluator()
    risk_gate = evaluator.evaluate_risk_gate(
        baseline=context.risk_baseline,
        proposed=context.risk_proposed,
    )

    # Require approval if risk gate fails (posterior probability >= 0.95)
    if not risk_gate.passed:
        return True

    # Also check if the posterior probability is concerning (>= 0.5)
    if (
        risk_gate.posterior_probability is not None
        and risk_gate.posterior_probability >= 0.5
    ):
        return True

    return False
