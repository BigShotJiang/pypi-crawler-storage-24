"""AIPEA Bridge

Preprocesses claims through AIPEA before AEGIS gate evaluation.
Uses dependency injection — AIPEA is an optional import that degrades
gracefully when not installed.

Integration with AIPEA v1.0.0+:
- Uses enhance_prompt() for claim preprocessing
- Maps EnhancementResult fields to AEGIS gate input format
- Supports compliance modes (general, hipaa, tactical, fedramp)
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aipea import EnhancementResult

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PreprocessedClaim:
    """Result of AIPEA preprocessing for AEGIS gate input.

    Immutable dataclass mirroring DecisionResponse's frozen pattern.
    """

    request_id: str
    enhanced_claim: str
    query_type: str
    complexity: float
    needs_current_info: bool
    search_context: dict[str, Any] | None
    security_flags: list[str]
    processing_tier: str
    enhancement_time_ms: float
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class AIPEAGateAdapter:
    """Preprocesses claims through AIPEA before gate evaluation.

    Uses dependency injection — AIPEA is an optional import.
    Fails gracefully if AIPEA is not installed, returning
    passthrough results via _passthrough().
    """

    def __init__(self, compliance_mode: str = "general") -> None:
        self._compliance_mode_str = compliance_mode
        self._aipea_available: bool | None = None

    def _ensure_aipea(self) -> bool:
        """Lazy-check AIPEA availability."""
        if self._aipea_available is None:
            try:
                import aipea  # noqa: F401

                self._aipea_available = True
            except ImportError:
                logger.warning(
                    "aipea not installed — adapter will return " "passthrough results"
                )
                self._aipea_available = False
        return self._aipea_available

    async def preprocess_claim(
        self,
        claim_text: str,
        model_id: str = "claude-opus-4-6",
    ) -> PreprocessedClaim:
        """Enhance a claim through AIPEA before gate evaluation.

        Args:
            claim_text: Raw claim text to preprocess
            model_id: Target model identifier

        Returns:
            PreprocessedClaim with enhanced text and metadata
        """
        request_id = uuid.uuid4().hex[:12]

        if not self._ensure_aipea():
            return self._passthrough(request_id, claim_text)

        try:
            from aipea import ComplianceMode, enhance_prompt

            result = await enhance_prompt(
                query=claim_text,
                model_id=model_id,
                compliance_mode=ComplianceMode(self._compliance_mode_str),
            )
            return self._map_result(request_id, result)
        except Exception:
            logger.exception(
                "AIPEA preprocessing failed for request %s",
                request_id,
            )
            return self._passthrough(request_id, claim_text)

    def _map_result(
        self,
        request_id: str,
        result: EnhancementResult,
    ) -> PreprocessedClaim:
        """Map AIPEA EnhancementResult to PreprocessedClaim."""
        return PreprocessedClaim(
            request_id=request_id,
            enhanced_claim=result.enhanced_prompt,
            query_type=result.query_analysis.query_type.value,
            complexity=result.query_analysis.complexity,
            needs_current_info=(result.query_analysis.needs_current_info),
            search_context=(
                {
                    "source": result.search_context.source,
                    "confidence": result.search_context.confidence,
                    "result_count": len(result.search_context.results),
                }
                if result.search_context
                else None
            ),
            security_flags=[],
            processing_tier=result.processing_tier.value,
            enhancement_time_ms=result.enhancement_time_ms,
        )

    @staticmethod
    def _passthrough(request_id: str, claim_text: str) -> PreprocessedClaim:
        """Return unenhanced passthrough when AIPEA is unavailable."""
        return PreprocessedClaim(
            request_id=request_id,
            enhanced_claim=claim_text,
            query_type="unknown",
            complexity=0.5,
            needs_current_info=False,
            search_context=None,
            security_flags=[],
            processing_tier="offline",
            enhancement_time_ms=0.0,
        )
