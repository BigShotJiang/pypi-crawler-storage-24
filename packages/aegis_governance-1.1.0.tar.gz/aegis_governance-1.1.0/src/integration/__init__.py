"""AFA Integration Layer

Bridges the Guardrails system with the Autonomous Framework for Action (AFA).
Implements the pcw_decide interface for autonomous agent decision-making.
Provides AIPEA bridge for claim preprocessing before gate evaluation.
"""

from .afa_bridge import AFABridge, DecisionRequest, DecisionResponse
from .aipea_bridge import AIPEAGateAdapter, PreprocessedClaim
from .pcw_decide import PCWContext, PCWDecision, pcw_decide

__all__ = [
    "AFABridge",
    "AIPEAGateAdapter",
    "DecisionRequest",
    "DecisionResponse",
    "PCWContext",
    "PCWDecision",
    "PreprocessedClaim",
    "pcw_decide",
]
