"""RBAC Enforcement Layer

Thin enforcement layer that loads schema/rbac-definitions.yaml as the
authoritative policy source. Provides permission resolution with role
inheritance, constraint checking, and two-key override authorization.

Usage:
    # From YAML (requires pyyaml)
    enforcer = RBACEnforcer.from_yaml("schema/rbac-definitions.yaml")

    # Programmatic
    resolver = YAMLRoleResolver()
    resolver.assign_role("alice", "risk_lead")
    enforcer = RBACEnforcer(resolver, rbac_definitions)

    # Check permissions
    enforcer.has_permission("alice", "first_key_override")

    # Authorize override (four-eyes)
    ok, reason = enforcer.authorize_override("bob", "security_lead", "alice")
"""

import logging
import math
from enum import Enum
from typing import Any, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)

# Maximum inheritance depth to prevent infinite loops on circular definitions
_MAX_INHERITANCE_DEPTH = 20


class Permission(str, Enum):
    """All permissions from schema/rbac-definitions.yaml."""

    # Read permissions (viewer)
    READ_PROPOSALS = "read_proposals"
    READ_TELEMETRY = "read_telemetry"
    READ_DASHBOARDS = "read_dashboards"
    VIEW_AUDIT_LOGS = "view_audit_logs"

    # Developer permissions
    SUBMIT_PROPOSALS = "submit_proposals"
    VIEW_OWN_DECISIONS = "view_own_decisions"
    CANCEL_OWN_PROPOSALS = "cancel_own_proposals"

    # Reviewer permissions
    APPROVE_PROPOSALS = "approve_proposals"
    REJECT_PROPOSALS = "reject_proposals"
    REQUEST_OVERRIDE = "request_override"
    ADD_REVIEW_COMMENTS = "add_review_comments"

    # Override permissions
    FIRST_KEY_OVERRIDE = "first_key_override"
    SECOND_KEY_OVERRIDE = "second_key_override"

    # Risk lead permissions
    PROPOSE_THRESHOLD_CHANGES = "propose_threshold_changes"
    VIEW_RISK_ANALYTICS = "view_risk_analytics"
    TRIGGER_RECALIBRATION = "trigger_recalibration"

    # Security lead permissions
    VIEW_SECURITY_AUDIT = "view_security_audit"
    MANAGE_SECURITY_GATES = "manage_security_gates"

    # Calibrator permissions
    PROPOSE_RECALIBRATION = "propose_recalibration"
    VIEW_CALIBRATION_HISTORY = "view_calibration_history"
    RUN_STATISTICAL_ANALYSIS = "run_statistical_analysis"

    # Admin permissions
    MANAGE_ROLES = "manage_roles"
    AUDIT_ALL = "audit_all"
    SYSTEM_CONFIG = "system_config"
    MANAGE_INTEGRATIONS = "manage_integrations"
    EMERGENCY_SHUTDOWN = "emergency_shutdown"

    # Analyst permissions
    RUN_QUERIES = "run_queries"
    EXPORT_REPORTS = "export_reports"
    VIEW_STATISTICS = "view_statistics"


class RBACConstraint(str, Enum):
    """Hard constraints from schema/rbac-definitions.yaml."""

    CANNOT_APPROVE_OWN_PROPOSALS = "cannot_approve_own_proposals"
    REQUIRES_SECOND_KEY_FOR_OVERRIDE = "requires_second_key_for_override"
    CANNOT_BYPASS_SECURITY_INVARIANTS = "cannot_bypass_security_invariants"
    NO_UNILATERAL_OVERRIDE = "no_unilateral_override"
    FOUR_EYES_PRINCIPLE = "four_eyes_principle"
    ALL_ACTIONS_LOGGED = "all_actions_logged"
    REQUIRES_FIRST_KEY_FOR_OVERRIDE = "requires_first_key_for_override"
    REQUIRES_APPROVAL_FOR_DEPLOY = "requires_approval_for_deploy"


@runtime_checkable
class RoleResolver(Protocol):
    """Abstract interface for resolving actor IDs to role sets."""

    def resolve_roles(self, actor_id: str) -> set[str]:
        """Resolve an actor ID to its assigned roles.

        Args:
            actor_id: Unique identifier for the actor.

        Returns:
            Set of role names assigned to the actor.
        """
        ...  # pragma: no cover


class YAMLRoleResolver:
    """Default role resolver with in-memory role assignments.

    Stores actor-to-role mappings in memory. Suitable for testing and
    lightweight deployments. Production systems should implement
    RoleResolver with a persistent backend.
    """

    def __init__(self) -> None:
        self._assignments: dict[str, set[str]] = {}

    def assign_role(self, actor_id: str, role: str) -> None:
        """Assign a role to an actor.

        Args:
            actor_id: Unique identifier for the actor.
            role: Role name to assign.
        """
        if actor_id not in self._assignments:
            self._assignments[actor_id] = set()
        self._assignments[actor_id].add(role)
        logger.debug("Assigned role %r to actor %r", role, actor_id)

    def resolve_roles(self, actor_id: str) -> set[str]:
        """Resolve an actor ID to its assigned roles.

        Args:
            actor_id: Unique identifier for the actor.

        Returns:
            Set of role names assigned to the actor, or empty set if unknown.
        """
        return set(self._assignments.get(actor_id, set()))

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        count = sum(len(roles) for roles in self._assignments.values())
        return f"YAMLRoleResolver(actors={len(self._assignments)}, assignments={count})"


class RBACEnforcer:
    """Core RBAC enforcement engine.

    Loads role definitions from schema/rbac-definitions.yaml and enforces
    permission checks, constraint validation, and two-key override
    authorization with inheritance resolution.
    """

    def __init__(
        self,
        role_resolver: RoleResolver,
        rbac_definitions: dict[str, Any],
    ) -> None:
        """Initialize the enforcer.

        Args:
            role_resolver: Resolver for mapping actor IDs to roles.
            rbac_definitions: Parsed RBAC definitions dict (from YAML).
        """
        self._resolver = role_resolver
        self._definitions = rbac_definitions
        self._roles: dict[str, Any] = rbac_definitions.get("roles", {})
        self._constraints: dict[str, Any] = rbac_definitions.get("constraints", {})

        # Cache for resolved permissions per role (avoids repeated inheritance walks)
        self._permission_cache: dict[str, frozenset[str]] = {}

    @classmethod
    def from_yaml(
        cls,
        rbac_path: str,
        role_resolver: Optional[RoleResolver] = None,
    ) -> "RBACEnforcer":
        """Load RBAC definitions from a YAML file.

        Args:
            rbac_path: Path to schema/rbac-definitions.yaml.
            role_resolver: Optional role resolver; creates YAMLRoleResolver
                if not provided.

        Returns:
            Configured RBACEnforcer instance.

        Raises:
            ImportError: If PyYAML is not installed.
            FileNotFoundError: If the YAML file does not exist.
            ValueError: If YAML content is not a valid dict.
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required to load RBAC definitions from YAML. "
                "Install it with: pip install pyyaml"
            ) from None

        from pathlib import Path

        path = Path(rbac_path)
        if not path.exists():
            raise FileNotFoundError(f"RBAC definitions file not found: {path}")

        with open(path) as f:
            raw = yaml.safe_load(f)

        if not isinstance(raw, dict):
            raise ValueError(
                f"Expected YAML dict for RBAC definitions, got {type(raw).__name__}"
            )

        if role_resolver is None:
            role_resolver = YAMLRoleResolver()

        return cls(role_resolver=role_resolver, rbac_definitions=raw)

    def _resolve_permissions(self, role: str) -> frozenset[str]:
        """Resolve all permissions for a role, walking the inheritance chain.

        Handles multi-parent inheritance (e.g., admin inherits from
        risk_lead, security_lead, and calibrator) and caches results.
        Includes circular inheritance protection via depth limiting.

        Args:
            role: Role name to resolve permissions for.

        Returns:
            Frozenset of all permission strings granted to the role (direct + inherited).
        """
        if role in self._permission_cache:
            return self._permission_cache[role]

        permissions: set[str] = set()
        visited: set[str] = set()

        def _walk(current_role: str, depth: int) -> None:
            if current_role in visited:
                return
            if depth > _MAX_INHERITANCE_DEPTH:
                logger.warning(
                    "Inheritance depth exceeded for role %r (max=%d); "
                    "possible circular inheritance",
                    current_role,
                    _MAX_INHERITANCE_DEPTH,
                )
                return
            visited.add(current_role)

            role_def = self._roles.get(current_role, {})

            # Add direct permissions
            direct_perms = role_def.get("permissions", [])
            permissions.update(direct_perms)

            # Walk inherited roles
            inherits = role_def.get("inherits", [])
            for parent_role in inherits:
                _walk(parent_role, depth + 1)

        _walk(role, 0)
        resolved = frozenset(permissions)
        self._permission_cache[role] = resolved
        return resolved

    def has_permission(self, actor_id: str, permission: str) -> bool:
        """Check if an actor has a specific permission.

        Resolves all roles for the actor, then checks whether any role
        (including inherited roles) grants the requested permission.

        Args:
            actor_id: Unique identifier for the actor.
            permission: Permission string to check (e.g., "read_proposals").

        Returns:
            True if the actor has the permission, False otherwise.
        """
        roles = self._resolver.resolve_roles(actor_id)
        return any(permission in self._resolve_permissions(role) for role in roles)

    # Identity-pair constraints: (key_a, key_b, failure_message)
    _IDENTITY_CONSTRAINTS: dict[str, tuple[str, str, str]] = {
        RBACConstraint.CANNOT_APPROVE_OWN_PROPOSALS.value: (
            "proposer_id",
            "approver_id",
            "Self-approval prohibited",
        ),
        RBACConstraint.FOUR_EYES_PRINCIPLE.value: (
            "actor1_id",
            "actor2_id",
            "Four-eyes principle violated: same actor",
        ),
    }

    # Boolean-flag constraints: (ctx_key, default_pass, failure_message)
    # default_pass=True means flag=True => pass; False means flag=True => fail
    _BOOL_CONSTRAINTS: dict[str, tuple[str, bool, str]] = {
        RBACConstraint.REQUIRES_SECOND_KEY_FOR_OVERRIDE.value: (
            "has_second_key",
            True,
            "Override requires second-key approval",
        ),
        RBACConstraint.REQUIRES_FIRST_KEY_FOR_OVERRIDE.value: (
            "has_first_key",
            True,
            "Override requires first-key approval",
        ),
        RBACConstraint.REQUIRES_APPROVAL_FOR_DEPLOY.value: (
            "has_approval",
            True,
            "Deployment requires prior approval",
        ),
        RBACConstraint.ALL_ACTIONS_LOGGED.value: (
            "is_logged",
            True,
            "Action must be logged to audit trail",
        ),
        RBACConstraint.CANNOT_BYPASS_SECURITY_INVARIANTS.value: (
            "bypassing",
            False,
            "Security invariants cannot be bypassed",
        ),
    }

    def check_constraint(
        self,
        constraint: str,
        **ctx: Any,
    ) -> tuple[bool, Optional[str]]:
        """Check a constraint against the provided context.

        Dispatches to constraint-specific logic based on the constraint name.
        Returns a tuple of (passed, reason) where reason is None on pass
        and a descriptive string on failure.

        Args:
            constraint: Constraint name (must match RBACConstraint values).
            **ctx: Context keyword arguments specific to the constraint.
                - cannot_approve_own_proposals: proposer_id, approver_id
                - four_eyes_principle: actor1_id, actor2_id
                - requires_second_key_for_override: has_second_key (bool)
                - requires_first_key_for_override: has_first_key (bool)
                - no_unilateral_override: signer_count (int)
                - requires_approval_for_deploy: has_approval (bool)
                - all_actions_logged: is_logged (bool)
                - cannot_bypass_security_invariants: bypassing (bool)

        Returns:
            Tuple of (passed: bool, reason: Optional[str]).
        """
        # Identity-pair constraints (two actors must differ)
        if constraint in self._IDENTITY_CONSTRAINTS:
            return self._check_identity_constraint(constraint, ctx)

        # Boolean-flag constraints
        if constraint in self._BOOL_CONSTRAINTS:
            return self._check_bool_constraint(constraint, ctx)

        # Signer-count constraint
        if constraint == RBACConstraint.NO_UNILATERAL_OVERRIDE.value:
            signer_count = ctx.get("signer_count", 0)
            if signer_count is None or not isinstance(signer_count, (int, float)):
                return (False, "Unilateral override prohibited; requires 2+ signers")
            if isinstance(signer_count, bool):
                return (False, "Unilateral override prohibited; requires 2+ signers")
            if not math.isfinite(float(signer_count)):
                return (False, "Unilateral override prohibited; requires 2+ signers")
            if signer_count < 2:
                return (False, "Unilateral override prohibited; requires 2+ signers")
            return (True, None)

        logger.warning("Unknown constraint: %r", constraint)
        return (False, f"Unknown constraint: {constraint}")

    def _check_identity_constraint(
        self,
        constraint: str,
        ctx: dict[str, Any],
    ) -> tuple[bool, Optional[str]]:
        """Check an identity-pair constraint (two actors must differ).

        Args:
            constraint: Constraint name.
            ctx: Context dict with actor ID keys.

        Returns:
            Tuple of (passed, reason).
        """
        key_a, key_b, message = self._IDENTITY_CONSTRAINTS[constraint]
        actor_a = ctx.get(key_a)
        actor_b = ctx.get(key_b)
        # Fail-closed: missing actor IDs violate the constraint
        if actor_a is None or actor_b is None:
            return (False, f"Missing required context: {key_a}, {key_b}")
        if actor_a == actor_b:
            return (False, message)
        return (True, None)

    def _check_bool_constraint(
        self,
        constraint: str,
        ctx: dict[str, Any],
    ) -> tuple[bool, Optional[str]]:
        """Check a boolean-flag constraint.

        For pass_when_true=True: flag must be True to pass.
        For pass_when_true=False: flag must be False to pass.

        Args:
            constraint: Constraint name.
            ctx: Context dict with the boolean flag key.

        Returns:
            Tuple of (passed, reason).
        """
        ctx_key, pass_when_true, message = self._BOOL_CONSTRAINTS[constraint]
        if ctx_key not in ctx:
            return (False, f"Missing required context: {ctx_key}")
        flag_value = ctx[ctx_key]
        # Fail-closed: non-boolean values (including None) violate the constraint
        if not isinstance(flag_value, bool):
            return (
                False,
                f"Expected bool for {ctx_key}, got {type(flag_value).__name__}",
            )
        if pass_when_true and not flag_value:
            return (False, message)
        if not pass_when_true and flag_value:
            return (False, message)
        return (True, None)

    def authorize_override(
        self,
        signer_id: str,
        role: str,
        requester_id: str,
    ) -> tuple[bool, Optional[str]]:
        """Authorize a two-key override signer.

        Validates that:
        1. The signer actually has the claimed role.
        2. The signer has first_key_override or second_key_override permission.
        3. The signer is not the same as the requester (four-eyes principle).

        Args:
            signer_id: Actor ID of the person signing the override.
            role: Role the signer claims to hold.
            requester_id: Actor ID of the person requesting the override.

        Returns:
            Tuple of (authorized: bool, reason: Optional[str]).
        """
        # Check four-eyes principle
        if signer_id == requester_id:
            return (
                False,
                "Four-eyes violation: signer and requester must be different actors",
            )

        # Verify signer has the claimed role
        signer_roles = self._resolver.resolve_roles(signer_id)
        if role not in signer_roles:
            return (False, f"Signer {signer_id!r} does not have role {role!r}")

        # Verify signer has override permission via the claimed role
        role_perms = self._resolve_permissions(role)
        has_first = Permission.FIRST_KEY_OVERRIDE.value in role_perms
        has_second = Permission.SECOND_KEY_OVERRIDE.value in role_perms
        if not has_first and not has_second:
            return (
                False,
                f"Role {role!r} does not grant override permission",
            )

        logger.info(
            "Override authorized: signer=%r role=%r requester=%r",
            signer_id,
            role,
            requester_id,
        )
        return (True, None)

    def get_role_constraints(self, role: str) -> list[str]:
        """Get constraints applicable to a specific role.

        Args:
            role: Role name.

        Returns:
            List of constraint names from the role definition.
        """
        role_def = self._roles.get(role, {})
        return list(role_def.get("constraints", []))

    def get_all_constraints(self) -> dict[str, Any]:
        """Get the full constraints section from the RBAC definitions.

        Returns:
            Dictionary of constraint definitions.
        """
        return dict(self._constraints)

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return (
            f"RBACEnforcer(roles={len(self._roles)}, "
            f"constraints={len(self._constraints)})"
        )
