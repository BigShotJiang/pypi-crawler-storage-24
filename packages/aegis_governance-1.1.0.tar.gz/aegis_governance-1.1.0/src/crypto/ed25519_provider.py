"""Ed25519 Signature Provider (Deprecated).

Provides Ed25519 signatures as a legacy fallback for environments where
btclib is not available. This provider will be removed in v2.0.

DEPRECATION NOTICE:
    This provider is deprecated and will be removed in AEGIS v2.0.
    Use BIP322Provider for new implementations.

Migration Path:
    v1.2.0: Ed25519Provider available, BIP322Provider default
    v1.3.0: Ed25519Provider deprecated with warnings
    v2.0.0: Ed25519Provider removed

GAP-M4: BIP-322 Signature Format Standardization
"""

import base64
import hashlib
import json
import logging
import warnings

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

logger = logging.getLogger(__name__)


class Ed25519Provider:
    """Ed25519 signature provider (DEPRECATED).

    This provider uses Ed25519 signatures which provide equivalent
    security to BIP-340 Schnorr but are NOT Bitcoin-compatible.

    .. deprecated:: 1.3.0
        Use :class:`BIP322Provider` instead. Ed25519Provider will be
        removed in version 2.0.0.

    Security Properties:
        - 128-bit security level
        - Fast verification
        - 64-byte signatures, 32-byte keys
        - NOT Bitcoin-compatible

    Example:
        >>> provider = Ed25519Provider()  # Issues deprecation warning
        >>> private_key, public_key = provider.generate_keypair()
        >>> msg_hash = provider.create_message_hash("prop-1", "test", ["gate1"])
        >>> signature = provider.sign(msg_hash, private_key)
        >>> assert provider.verify(signature, msg_hash, public_key)

    """

    # Ed25519 signature and key sizes
    SIGNATURE_SIZE = 64
    PUBLIC_KEY_SIZE = 32
    PRIVATE_KEY_SIZE = 32

    def __init__(self) -> None:
        """Initialize Ed25519Provider with deprecation warning."""
        warnings.warn(
            "Ed25519Provider is deprecated and will be removed in AEGIS v2.0. "
            "Use BIP322Provider for new implementations. "
            "Install btclib>=2023.7.12 for BIP-322 support.",
            DeprecationWarning,
            stacklevel=2,
        )

    @property
    def algorithm_name(self) -> str:
        """Return algorithm identifier."""
        return "ed25519"

    @property
    def signature_size(self) -> int:
        """Return signature size in bytes."""
        return self.SIGNATURE_SIZE

    @property
    def public_key_size(self) -> int:
        """Return public key size in bytes."""
        return self.PUBLIC_KEY_SIZE

    def generate_keypair(self) -> tuple[bytes, bytes]:
        """Generate Ed25519 keypair.

        Returns:
            (private_key, public_key) as 32-byte each

        """
        private_key = Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        private_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

        return private_bytes, public_bytes

    def create_message_hash(
        self,
        proposal_id: str,
        justification: str,
        failed_gates: list[str],
    ) -> bytes:
        """Create SHA-256 message hash for signing.

        Note: This uses simple SHA-256, NOT BIP-340 tagged hash.
        For Bitcoin compatibility, use BIP322Provider.

        Args:
            proposal_id: Proposal identifier
            justification: Override justification
            failed_gates: List of failed gate names

        Returns:
            32-byte SHA-256 hash

        """
        canonical = json.dumps(
            {
                "proposal_id": proposal_id,
                "justification": justification,
                "failed_gates": sorted(failed_gates),
                "version": "1.0",
            },
            sort_keys=True,
        )

        return hashlib.sha256(canonical.encode("utf-8")).digest()

    def sign(self, message_hash: bytes, private_key: bytes) -> bytes:
        """Sign message hash with Ed25519.

        Ed25519 can sign messages of arbitrary length, but this API expects
        a pre-computed hash (typically 32 bytes from SHA-256). Empty messages
        are rejected to catch common errors.

        Args:
            message_hash: Message hash to sign (any length, but typically 32 bytes).
                Must not be empty.
            private_key: 32-byte Ed25519 private key

        Returns:
            64-byte Ed25519 signature

        Raises:
            ValueError: If message_hash is empty or private_key is wrong size

        """
        if len(message_hash) == 0:
            raise ValueError(
                "message_hash must not be empty. "
                "Use create_message_hash() to generate a valid hash."
            )

        if len(private_key) != self.PRIVATE_KEY_SIZE:
            raise ValueError(
                f"Private key must be {self.PRIVATE_KEY_SIZE} bytes, "
                f"got {len(private_key)}",
            )

        pk = Ed25519PrivateKey.from_private_bytes(private_key)
        signature = pk.sign(message_hash)

        logger.debug(
            f"Ed25519 signature created: {len(signature)} bytes, "
            f"hash prefix: {message_hash[:8].hex()}",
        )
        result: bytes = signature
        return result

    def verify(
        self,
        signature: bytes,
        message_hash: bytes,
        public_key: bytes,
    ) -> bool:
        """Verify Ed25519 signature.

        Args:
            signature: 64-byte signature
            message_hash: 32-byte message hash
            public_key: 32-byte public key

        Returns:
            True if signature is valid, False otherwise

        """
        if len(signature) != self.SIGNATURE_SIZE:
            logger.warning(
                f"Signature size mismatch: got {len(signature)}, "
                f"expected {self.SIGNATURE_SIZE}",
            )
            return False

        if len(public_key) != self.PUBLIC_KEY_SIZE:
            logger.warning(
                f"Public key size mismatch: got {len(public_key)}, "
                f"expected {self.PUBLIC_KEY_SIZE}",
            )
            return False

        try:
            pk = Ed25519PublicKey.from_public_bytes(public_key)
            pk.verify(signature, message_hash)
            logger.debug("Ed25519 signature verification succeeded")
            return True
        except InvalidSignature:
            logger.warning("Ed25519 signature verification failed")
            return False
        except (ValueError, TypeError) as e:
            logger.warning(f"Ed25519 signature verification error: {e}")
            return False

    # Base64 encoding helpers for API compatibility

    def generate_keypair_b64(self) -> tuple[str, str]:
        """Generate keypair with base64 encoding.

        Returns:
            (private_key_b64, public_key_b64) as base64 strings

        """
        private_bytes, public_bytes = self.generate_keypair()
        return (
            base64.b64encode(private_bytes).decode("ascii"),
            base64.b64encode(public_bytes).decode("ascii"),
        )

    def sign_b64(self, message_hash_hex: str, private_key_b64: str) -> str:
        """Sign message hash with base64 encoded inputs/outputs.

        Args:
            message_hash_hex: Hex-encoded message hash
            private_key_b64: Base64-encoded private key

        Returns:
            Base64-encoded signature

        """
        message_hash = bytes.fromhex(message_hash_hex)
        private_key = base64.b64decode(private_key_b64, validate=True)
        signature = self.sign(message_hash, private_key)
        return base64.b64encode(signature).decode("ascii")

    def verify_b64(
        self,
        signature_b64: str,
        message_hash_hex: str,
        public_key_b64: str,
    ) -> bool:
        """Verify signature with base64 encoded inputs.

        Args:
            signature_b64: Base64-encoded signature
            message_hash_hex: Hex-encoded message hash
            public_key_b64: Base64-encoded public key

        Returns:
            True if signature is valid

        """
        try:
            signature = base64.b64decode(signature_b64, validate=True)
            message_hash = bytes.fromhex(message_hash_hex)
            public_key = base64.b64decode(public_key_b64, validate=True)
            return self.verify(signature, message_hash, public_key)
        except (ValueError, TypeError) as e:
            logger.warning(f"Ed25519 verification decode error: {e}")
            return False
