"""HSM PKCS#11 KEK Provider — envelope encryption via Hardware Security Module.

Uses a PKCS#11-compatible HSM to wrap/unwrap the HybridKEM private key blob.
At startup, the HSM unwraps the key using CKM_AES_KEY_WRAP_KWP (RFC 5649);
all HybridKEM crypto operations happen in software because no HSM supports
ML-KEM-768 natively.

Security Model:
- HSM protects the private key AT REST via AES key wrapping
- The AES wrapping key NEVER leaves the HSM boundary
- Private key is held in memory only while the process is running
- HSM audit log tracks every unwrap operation

Supported HSMs:
- AWS CloudHSM (PKCS#11 interface)
- YubiHSM 2 (PKCS#11 interface)
- SoftHSM2 (development/testing)

Environment Variables (from_environment):
- AEGIS_HSM_PKCS11_LIB: Path to PKCS#11 shared library (.so/.dylib)
- AEGIS_HSM_TOKEN_LABEL: HSM token/slot label
- AEGIS_HSM_PIN: User PIN
- AEGIS_HSM_WRAPPING_KEY_LABEL: AES wrapping key label in HSM
- AEGIS_HSM_WRAPPED_PRIVATE_KEY: Base64-encoded wrapped private key blob
- AEGIS_MASTER_KEK_PUBLIC: Base64-encoded HybridKEM public key (1,216 bytes)

GAP-Q2 Phase 3: HSM/KMS Key Store Integration
"""

from __future__ import annotations

import base64
import collections
import contextlib
import logging
import os
import threading
from datetime import datetime, timezone
from typing import Any

from . import HYBRID_KEM_AVAILABLE

if HYBRID_KEM_AVAILABLE:
    from .hybrid_kem import (
        HybridEncryptedBlob,
        HybridKEMPrivateKey,
        HybridKEMProvider,
        HybridKEMPublicKey,
    )

from .kek_provider import KEKMetadata, KEKProvider

logger = logging.getLogger(__name__)

try:
    import pkcs11
    from pkcs11 import KeyType, Mechanism, ObjectClass

    _HAS_PKCS11 = True
except ImportError:
    _HAS_PKCS11 = False
    pkcs11 = None
    KeyType = None
    Mechanism = None
    ObjectClass = None


class HSMKEKProvider(KEKProvider):
    """KEK provider using PKCS#11 HSM for envelope encryption.

    Wraps the HybridKEM private key blob using an AES key stored in
    the HSM. At startup, uses CKM_AES_KEY_WRAP_KWP to unwrap the
    private key into memory. Session pooling amortises HSM connection
    overhead across concurrent requests.

    Supported HSMs:
    - AWS CloudHSM (production)
    - YubiHSM 2 (on-premises)
    - SoftHSM2 (development/testing)

    Security Properties:
    - AES wrapping key never leaves HSM boundary
    - CKM_AES_KEY_WRAP_KWP (RFC 5649) for key wrapping
    - Session pool with bounded size prevents resource exhaustion
    - HSM audit log for every key operation
    """

    _DEFAULT_POOL_SIZE = 4

    def __init__(
        self,
        pkcs11_lib_path: str,
        token_label: str,
        pin: str,
        wrapping_key_label: str,
        wrapped_private_key: bytes,
        public_key_bytes: bytes,
        version: int = 1,
        pool_size: int = _DEFAULT_POOL_SIZE,
    ) -> None:
        """Initialize HSM-backed KEK provider.

        Args:
            pkcs11_lib_path: Path to PKCS#11 shared library (.so/.dylib)
            token_label: HSM token/slot label
            pin: HSM user PIN
            wrapping_key_label: Label of AES wrapping key in HSM
            wrapped_private_key: HSM-wrapped HybridKEM private key blob
            public_key_bytes: Raw HybridKEM public key (1,216 bytes)
            version: KEK version number
            pool_size: Maximum number of pooled HSM sessions

        Raises:
            RuntimeError: If python-pkcs11 or HybridKEM is not available
            RuntimeError: If HSM connection or key unwrap fails
            ValueError: If public key is malformed

        """
        if not _HAS_PKCS11:
            raise RuntimeError(
                "python-pkcs11 is required for HSMKEKProvider. "
                "Install with: pip install aegis-governance[hsm]",
            )
        if not HYBRID_KEM_AVAILABLE:
            raise RuntimeError(
                "HybridKEMProvider not available. "
                "Install liboqs-python>=0.10.0 for post-quantum support.",
            )

        self._version = version
        self._pin = pin
        self._wrapping_key_label = wrapping_key_label
        self._lock = threading.Lock()
        self._kem_provider = HybridKEMProvider()
        self._created_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

        # Initialize PKCS#11 library and find token
        self._lib = pkcs11.lib(pkcs11_lib_path)
        self._token = self._lib.get_token(token_label=token_label)

        # Session pool (bounded deque)
        self._session_pool: collections.deque[Any] = collections.deque(maxlen=pool_size)
        self._pool_lock = threading.Lock()

        # Load public key (not secret)
        self._public_key = HybridKEMPublicKey.from_bytes(public_key_bytes)

        # Unwrap private key via HSM
        self._private_key = self._unwrap_private_key(wrapped_private_key)

        logger.info(
            "HSM KEK provider initialized: token=%s, wrapping_key=%s, version=%d",
            token_label,
            wrapping_key_label,
            self._version,
        )

    def _borrow_session(self) -> Any:
        """Borrow a session from the pool, or open a new one.

        Returns:
            An open PKCS#11 session

        """
        with self._pool_lock:
            if self._session_pool:
                return self._session_pool.popleft()
        return self._token.open(user_pin=self._pin)

    def _return_session(self, session: Any) -> None:
        """Return a session to the pool.

        If the pool is full, the session is closed instead.

        Args:
            session: PKCS#11 session to return

        """
        with self._pool_lock:
            if len(self._session_pool) < (self._session_pool.maxlen or 0):
                self._session_pool.append(session)
                return
        # Pool full — close the session (best-effort cleanup)
        with contextlib.suppress(Exception):
            session.close()

    def _find_wrapping_key(self, session: Any) -> Any:
        """Find the AES wrapping key in the HSM by label.

        Args:
            session: Open PKCS#11 session

        Returns:
            HSM key object

        Raises:
            RuntimeError: If wrapping key not found

        """
        keys = list(
            session.get_objects(
                {
                    pkcs11.Attribute.CLASS: ObjectClass.SECRET_KEY,
                    pkcs11.Attribute.KEY_TYPE: KeyType.AES,
                    pkcs11.Attribute.LABEL: self._wrapping_key_label,
                }
            )
        )
        if not keys:
            raise RuntimeError(
                f"Wrapping key '{self._wrapping_key_label}' not found in HSM"
            )
        return keys[0]

    def _unwrap_private_key(self, wrapped_blob: bytes) -> HybridKEMPrivateKey:
        """Unwrap the HybridKEM private key using the HSM AES wrapping key.

        Uses CKM_AES_KEY_WRAP_KWP (RFC 5649) which supports arbitrary-length
        payloads (the HybridKEM private key is 2,432 bytes).

        Args:
            wrapped_blob: HSM-wrapped private key bytes

        Returns:
            HybridKEMPrivateKey loaded from unwrapped bytes

        Raises:
            RuntimeError: If unwrap operation fails

        """
        session = self._borrow_session()
        try:
            wrapping_key = self._find_wrapping_key(session)
            # Template marks the unwrapped key as extractable so we can
            # read its bytes.  Without CKA_EXTRACTABLE most HSMs default
            # to non-extractable, which would prevent software-side use.
            unwrap_template = {
                pkcs11.Attribute.CLASS: ObjectClass.SECRET_KEY,
                pkcs11.Attribute.KEY_TYPE: KeyType.GENERIC_SECRET,
                pkcs11.Attribute.EXTRACTABLE: True,
                pkcs11.Attribute.SENSITIVE: False,
                pkcs11.Attribute.TOKEN: False,
            }
            private_key_obj = wrapping_key.unwrap_key(
                Mechanism.AES_KEY_WRAP_KWP,
                wrapped_blob,
                template=unwrap_template,
            )
            return HybridKEMPrivateKey.from_bytes(bytes(private_key_obj))
        except Exception as exc:
            raise RuntimeError(f"HSM key unwrap failed: {exc}") from exc
        finally:
            self._return_session(session)

    @classmethod
    def from_environment(
        cls,
        version: int = 1,
        pool_size: int = _DEFAULT_POOL_SIZE,
    ) -> HSMKEKProvider:
        """Create provider from environment variables.

        Environment Variables:
            AEGIS_HSM_PKCS11_LIB: Path to PKCS#11 shared library
            AEGIS_HSM_TOKEN_LABEL: HSM token label
            AEGIS_HSM_PIN: User PIN
            AEGIS_HSM_WRAPPING_KEY_LABEL: AES wrapping key label
            AEGIS_HSM_WRAPPED_PRIVATE_KEY: Base64-encoded wrapped private key
            AEGIS_MASTER_KEK_PUBLIC: Base64-encoded HybridKEM public key

        Args:
            version: KEK version number
            pool_size: Session pool size

        Returns:
            Configured HSMKEKProvider

        Raises:
            ValueError: If required environment variables are missing

        """
        pkcs11_lib = os.environ.get("AEGIS_HSM_PKCS11_LIB")
        if not pkcs11_lib:
            raise ValueError("AEGIS_HSM_PKCS11_LIB environment variable is required")

        token_label = os.environ.get("AEGIS_HSM_TOKEN_LABEL")
        if not token_label:
            raise ValueError("AEGIS_HSM_TOKEN_LABEL environment variable is required")

        pin = os.environ.get("AEGIS_HSM_PIN")
        if not pin:
            raise ValueError("AEGIS_HSM_PIN environment variable is required")

        wrapping_key_label = os.environ.get("AEGIS_HSM_WRAPPING_KEY_LABEL")
        if not wrapping_key_label:
            raise ValueError(
                "AEGIS_HSM_WRAPPING_KEY_LABEL environment variable is required"
            )

        wrapped_b64 = os.environ.get("AEGIS_HSM_WRAPPED_PRIVATE_KEY")
        if not wrapped_b64:
            raise ValueError(
                "AEGIS_HSM_WRAPPED_PRIVATE_KEY environment variable is required"
            )

        public_b64 = os.environ.get("AEGIS_MASTER_KEK_PUBLIC")
        if not public_b64:
            raise ValueError("AEGIS_MASTER_KEK_PUBLIC environment variable is required")

        wrapped_private_key = base64.b64decode(wrapped_b64, validate=True)
        public_key_bytes = base64.b64decode(public_b64, validate=True)

        return cls(
            pkcs11_lib_path=pkcs11_lib,
            token_label=token_label,
            pin=pin,
            wrapping_key_label=wrapping_key_label,
            wrapped_private_key=wrapped_private_key,
            public_key_bytes=public_key_bytes,
            version=version,
            pool_size=pool_size,
        )

    @property
    def algorithm_name(self) -> str:
        """Return the algorithm name."""
        return "x25519+ml-kem-768+aes-256-gcm"

    @property
    def current_version(self) -> int:
        """Return the current KEK version."""
        return self._version

    def get_public_key(self, version: int = 0) -> HybridKEMPublicKey:
        """Get KEK public key.

        Args:
            version: KEK version (0 = current)

        Returns:
            HybridKEMPublicKey for the specified version

        Raises:
            ValueError: If version does not match current

        """
        if version not in (0, self._version):
            raise ValueError(
                f"KEK version {version} not found (current: {self._version})",
            )
        return self._public_key

    def encrypt(
        self,
        plaintext: bytes,
        version: int = 0,
        *,
        allow_empty: bool = False,
    ) -> bytes:
        """Encrypt data using KEK.

        Args:
            plaintext: Data to encrypt
            version: KEK version (0 = current)
            allow_empty: Allow empty plaintext

        Returns:
            Encrypted blob bytes

        """
        public_key = self.get_public_key(version)
        with self._lock:
            blob = self._kem_provider.encrypt(
                plaintext, public_key, allow_empty=allow_empty
            )
        return blob.to_bytes()

    def decrypt(self, encrypted_blob: bytes, version: int = 0) -> bytes:
        """Decrypt data using KEK.

        Args:
            encrypted_blob: HybridEncryptedBlob bytes
            version: KEK version used for encryption

        Returns:
            Decrypted plaintext bytes

        Raises:
            ValueError: If version mismatch or decryption fails

        """
        if version not in (0, self._version):
            raise ValueError(f"KEK version {version} not found")

        blob = HybridEncryptedBlob.from_bytes(encrypted_blob)
        with self._lock:
            return self._kem_provider.decrypt(blob, self._private_key)

    def get_metadata(self) -> KEKMetadata:
        """Get KEK metadata."""
        return KEKMetadata(
            version=self._version,
            algorithm=self.algorithm_name,
            created_at=self._created_at,
            provider_type="hsm",
        )


__all__ = [
    "HSMKEKProvider",
]
