"""BIP-340 Tagged Hash Implementation.

Implements the tagged hash function as specified in BIP-340:
    H_tag(m) = SHA256(SHA256(tag) || SHA256(tag) || m)

This is used by BIP-322 for message signing with the tag "BIP0322-signed-message".

References:
- BIP-340: https://bips.dev/340/
- BIP-322: https://bips.dev/322/

"""

import hashlib

# BIP-322 message signing tag
BIP322_TAG = b"BIP0322-signed-message"

# Pre-computed tag hash for BIP-322 (optimization)
_BIP322_TAG_HASH = hashlib.sha256(BIP322_TAG).digest()


def tagged_hash(tag: bytes, message: bytes) -> bytes:
    """Compute BIP-340 tagged hash.

    The tagged hash is defined as:
        H_tag(m) = SHA256(SHA256(tag) || SHA256(tag) || m)

    This construction ensures domain separation between different uses
    of the hash function by including the tag in a way that cannot be
    confused with other uses.

    Args:
        tag: Tag bytes (e.g., BIP322_TAG for message signing)
        message: Message to hash

    Returns:
        32-byte tagged hash

    Example:
        >>> from src.crypto.bip340 import tagged_hash, BIP322_TAG
        >>> result = tagged_hash(BIP322_TAG, b"Hello World")
        >>> result.hex()
        'f0eb03b1a75ac6d9847f55c624a99169b5dccba2a31f5b23bea77ba270de0a7a'

    """
    tag_hash = hashlib.sha256(tag).digest()
    return hashlib.sha256(tag_hash + tag_hash + message).digest()


def bip322_message_hash(message: bytes) -> bytes:
    """Compute BIP-322 message hash using pre-computed tag hash.

    This is an optimized version of tagged_hash() specifically for
    BIP-322 message signing. Uses pre-computed tag hash to avoid
    redundant hashing.

    Args:
        message: Message to hash

    Returns:
        32-byte BIP-322 message hash

    """
    return hashlib.sha256(_BIP322_TAG_HASH + _BIP322_TAG_HASH + message).digest()


# Test vectors from BIP-322 specification
_TEST_VECTORS = {
    b"": bytes.fromhex(
        "c90c269c4f8fcbe6880f72a721ddfbf1914268a794cbb21cfafee13770ae19f1",
    ),
    b"Hello World": bytes.fromhex(
        "f0eb03b1a75ac6d9847f55c624a99169b5dccba2a31f5b23bea77ba270de0a7a",
    ),
}


def verify_test_vectors() -> bool:
    """Verify BIP-322 test vectors from specification.

    Returns:
        True if all test vectors pass

    Raises:
        AssertionError: If any test vector fails

    """
    for message, expected in _TEST_VECTORS.items():
        result = tagged_hash(BIP322_TAG, message)
        if result != expected:  # nosec B101 - test vector validation
            raise ValueError(
                f"Test vector failed for message {message!r}: "
                f"got {result.hex()}, expected {expected.hex()}",
            )
    return True
