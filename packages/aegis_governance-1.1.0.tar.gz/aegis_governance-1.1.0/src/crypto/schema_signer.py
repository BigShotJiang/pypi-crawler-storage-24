"""MCP Tool Schema Signing (AMTSS Protocol v1).

Implements the AEGIS MCP Tool Schema Signing protocol for detecting
tool schema tampering and rug pull attacks (CoSAI MCP-T6).

Design: docs/research/004-mcp-schema-signing-design.md
Dialogue: dialogue_state/debate_1771249715.json

Protocol overview:
1. Canonicalize tool objects using RFC 8785-style JSON (sorted keys, compact)
2. Compute SHA-256 digest of canonical bytes
3. Sign typed statements (per-tool + manifest) with Ed25519
4. Embed proofs in tools/list response via _meta field
5. Advertise keys in initialize capabilities

Forward-compatibility:
- Uses _meta with reverse DNS key (com.aegis.governance/toolSchemaSigning)
- Typed, versioned statements allow protocol evolution
- Algorithm-agile: Ed25519 baseline, ML-DSA-44 optional
"""

import base64
import hashlib
import json
import logging
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

logger = logging.getLogger(__name__)

# AMTSS protocol constants
AMTSS_VERSION = 1
AMTSS_META_KEY = "com.aegis.governance/toolSchemaSigning"
AMTSS_TOOL_STATEMENT_TYPE = "mcp.tool.schemaDigest"
AMTSS_MANIFEST_STATEMENT_TYPE = "mcp.tools.manifest"
AMTSS_CAPABILITY_KEY = "toolSchemaSigning"


def _base64url_encode(data: bytes) -> str:
    """Encode bytes as base64url (no padding)."""
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _base64url_decode(s: str) -> bytes:
    """Decode base64url string (with or without padding).

    Uses strict validation: rejects characters outside the base64url
    alphabet (A-Za-z0-9_-) to prevent garbage-in/garbage-out.
    """
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    # Convert base64url to standard base64 for strict validation
    std = s.replace("-", "+").replace("_", "/")
    return base64.b64decode(std, validate=True)


def _canonicalize_json(obj: Any) -> bytes:
    """RFC 8785-style JSON canonicalization.

    Produces deterministic JSON bytes:
    - Object keys sorted lexicographically
    - No whitespace
    - No trailing commas
    - ASCII-safe output

    For AEGIS tool schemas (which use only strings, numbers, booleans,
    arrays, and objects), this is equivalent to full RFC 8785 JCS.
    """
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def compute_tool_digest(tool: dict[str, Any]) -> str:
    """Compute SHA-256 digest of a canonicalized tool schema.

    Strips ``_meta`` before hashing so that transport metadata embedded
    by the signing layer does not alter the digest.

    Args:
        tool: MCP tool object (name, description, inputSchema, etc.)

    Returns:
        Digest string in format "sha256:<base64url>"
    """
    # Strip _meta (transport metadata) before hashing
    if "_meta" in tool:
        tool = {k: v for k, v in tool.items() if k != "_meta"}
    canonical = _canonicalize_json(tool)
    digest = hashlib.sha256(canonical).digest()
    return f"sha256:{_base64url_encode(digest)}"


@dataclass(frozen=True)
class SigningKeyPair:
    """Ed25519 key pair for schema signing."""

    private_key: bytes  # 32 bytes
    public_key: bytes  # 32 bytes

    @classmethod
    def generate(cls) -> "SigningKeyPair":
        """Generate a new Ed25519 key pair."""
        private = Ed25519PrivateKey.generate()
        private_bytes = private.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        public_bytes = private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return cls(private_key=private_bytes, public_key=public_bytes)

    @property
    def kid(self) -> str:
        """Key ID: sha256 of public key (first 12 bytes, base64url)."""
        h = hashlib.sha256(self.public_key).digest()[:12]
        return f"sha256:{_base64url_encode(h)}"


class ToolSchemaSigner:
    """Sign and verify MCP tool schemas using AMTSS protocol.

    This class produces cryptographic proofs that tool schemas have not
    been tampered with. Proofs are embedded in the _meta field of
    tools/list responses.

    Args:
        key_pair: Ed25519 key pair for signing. If None, generates a new one.
        issuer: Server identity string (default: "aegis-governance").
        schema_revisions: Optional dict mapping tool names to revision numbers.
            Defaults to 1 for all tools.
    """

    def __init__(
        self,
        key_pair: Optional[SigningKeyPair] = None,
        *,
        issuer: str = "aegis-governance",
        schema_revisions: Optional[dict[str, int]] = None,
    ) -> None:
        self._key_pair = key_pair or SigningKeyPair.generate()
        self._issuer = issuer
        self._schema_revisions: dict[str, int] = dict(schema_revisions or {})
        self._prev_digests: dict[str, Optional[str]] = {}
        self._manifest_revision = 1
        # QG67-C9: Protect _prev_digests and _manifest_revision from
        # concurrent sign_tools_list calls that would corrupt AMTSS chain.
        self._sign_lock = threading.Lock()

    @property
    def issuer(self) -> str:
        """Return the issuer identity."""
        return self._issuer

    @property
    def public_key(self) -> bytes:
        """Return the public key bytes."""
        return self._key_pair.public_key

    @property
    def kid(self) -> str:
        """Return the key ID."""
        return self._key_pair.kid

    def create_tool_statement(
        self,
        tool: dict[str, Any],
    ) -> dict[str, Any]:
        """Create a typed tool schema digest statement.

        Args:
            tool: MCP tool object with at least "name" field.

        Returns:
            Statement dict ready for signing.
        """
        name = tool["name"]
        digest = compute_tool_digest(tool)
        revision = self._schema_revisions.get(name, 1)
        prev = self._prev_digests.get(name)

        statement: dict[str, Any] = {
            "typ": AMTSS_TOOL_STATEMENT_TYPE,
            "v": AMTSS_VERSION,
            "issuer": self._issuer,
            "tool": {
                "name": name,
                "digest": digest,
                "schemaRevision": revision,
            },
            "issuedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        if prev is not None:
            statement["tool"]["prevDigest"] = prev

        # BH41-M3: Do NOT update _prev_digests here. Chain state is committed
        # atomically in sign_tools_list() only after sign_statement() succeeds,
        # preventing corrupt prevDigest links when signing raises an exception.

        return statement

    def create_manifest_statement(
        self,
        tools: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Create a manifest statement binding all tools.

        Args:
            tools: List of MCP tool objects.

        Returns:
            Manifest statement dict ready for signing.
        """
        tool_entries = []
        for tool in tools:
            name = tool["name"]
            digest = compute_tool_digest(tool)
            revision = self._schema_revisions.get(name, 1)
            tool_entries.append(
                {
                    "name": name,
                    "digest": digest,
                    "schemaRevision": revision,
                }
            )

        return {
            "typ": AMTSS_MANIFEST_STATEMENT_TYPE,
            "v": AMTSS_VERSION,
            "issuer": self._issuer,
            "manifestRevision": self._manifest_revision,
            "tools": tool_entries,
            "issuedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    def sign_statement(self, statement: dict[str, Any]) -> dict[str, Any]:
        """Sign a statement with Ed25519.

        Args:
            statement: Statement dict to sign.

        Returns:
            Proof dict containing {statement, signatures}.
        """
        canonical = _canonicalize_json(statement)
        private_key = Ed25519PrivateKey.from_private_bytes(self._key_pair.private_key)
        signature = private_key.sign(canonical)

        return {
            "statement": statement,
            "signatures": [
                {
                    "alg": "Ed25519",
                    "kid": self._key_pair.kid,
                    "sig": _base64url_encode(signature),
                }
            ],
        }

    def sign_tools_list(
        self,
        tools: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Generate complete _meta signing block for tools/list response.

        This is the main entry point for integrating with mcp_server.py.

        Args:
            tools: List of MCP tool objects from _handle_tools_list().

        Returns:
            Dict to be placed at result._meta[AMTSS_META_KEY].
        """
        # Reject duplicate tool names before signing — duplicates would silently
        # corrupt the _prev_digests chain state (last writer wins).
        tool_names = [t["name"] for t in tools]
        if len(tool_names) != len(set(tool_names)):
            seen: set[str] = set()
            dupes: set[str] = set()
            for n in tool_names:
                if n in seen:
                    dupes.add(n)
                seen.add(n)
            raise ValueError(f"Duplicate tool names detected: {sorted(dupes)}")

        # QG67-C9: Serialize concurrent sign_tools_list calls to prevent
        # _prev_digests chain corruption and _manifest_revision skipping.
        with self._sign_lock:
            # BH41-M3: Collect new digests separately; commit to _prev_digests
            # only after all sign_statement() calls succeed (atomic update).
            pending_digests: dict[str, str] = {}
            for tool in tools:
                pending_digests[tool["name"]] = compute_tool_digest(tool)

            # BH45-D2: Update _schema_revisions BEFORE creating statements so
            # that tool proofs and manifest embed the correct schemaRevision.
            # Save originals for rollback on signing failure.
            orig_revisions = dict(self._schema_revisions)
            for name, digest in pending_digests.items():
                prev_digest = self._prev_digests.get(name)
                if prev_digest is None:
                    self._schema_revisions.setdefault(name, 1)
                elif prev_digest != digest:
                    self._schema_revisions[name] = (
                        self._schema_revisions.get(name, 1) + 1
                    )

            try:
                tool_proofs = []
                for tool in tools:
                    stmt = self.create_tool_statement(tool)
                    proof = self.sign_statement(stmt)  # may raise
                    tool_proofs.append(proof)
                manifest_stmt = self.create_manifest_statement(tools)
                manifest_proof = self.sign_statement(manifest_stmt)
            except Exception:
                self._schema_revisions = orig_revisions
                raise

            # All signing succeeded - commit chain state atomically.
            self._prev_digests.update(pending_digests)

            # Increment manifest revision for rollback detection.
            self._manifest_revision += 1

        return {
            "v": AMTSS_VERSION,
            "canonicalization": "RFC8785",
            "hash": "SHA-256",
            "toolProofs": tool_proofs,
            "manifestProof": manifest_proof,
        }

    def get_capability_info(self) -> dict[str, Any]:
        """Get capability info for initialize response.

        Returns:
            Dict to be placed in capabilities.experimental[AMTSS_CAPABILITY_KEY].
        """
        return {
            "v": AMTSS_VERSION,
            "required": False,
            "algorithms": ["Ed25519"],
            "keys": [
                {
                    "alg": "Ed25519",
                    "kid": self._key_pair.kid,
                    "pub": _base64url_encode(self._key_pair.public_key),
                }
            ],
        }

    @staticmethod
    def verify_tool_proof(
        proof: dict[str, Any],
        tool: dict[str, Any],
        public_key: bytes,
    ) -> bool:
        """Verify a tool schema proof.

        Args:
            proof: Proof dict containing {statement, signatures}.
            tool: MCP tool object to verify against.
            public_key: Ed25519 public key bytes (32 bytes).

        Returns:
            True if the proof is valid for the given tool.
        """
        statement = proof.get("statement")
        signatures = proof.get("signatures")
        if not isinstance(statement, dict) or not isinstance(signatures, list):
            return False

        # 1. Verify statement type
        if statement.get("typ") != AMTSS_TOOL_STATEMENT_TYPE:
            logger.warning(
                "Statement type mismatch: expected=%s, got=%s",
                AMTSS_TOOL_STATEMENT_TYPE,
                statement.get("typ"),
            )
            return False

        # 2. Verify digest matches tool
        expected_digest = compute_tool_digest(tool)
        stated_digest = statement.get("tool", {}).get("digest")
        if expected_digest != stated_digest:
            logger.warning(
                "Tool digest mismatch: expected=%s, stated=%s",
                expected_digest,
                stated_digest,
            )
            return False

        # 3. Verify at least one Ed25519 signature
        canonical = _canonicalize_json(statement)
        for sig_entry in signatures:
            if sig_entry.get("alg") != "Ed25519":
                continue
            try:
                sig_raw = sig_entry.get("sig")
                if not isinstance(sig_raw, str):
                    continue
                sig_bytes = _base64url_decode(sig_raw)
                pub = Ed25519PublicKey.from_public_bytes(public_key)
                pub.verify(sig_bytes, canonical)
                return True
            except (InvalidSignature, ValueError, TypeError):
                continue

        logger.warning("No valid Ed25519 signature found in proof")
        return False

    @staticmethod
    def verify_manifest_proof(
        proof: dict[str, Any],
        tools: list[dict[str, Any]],
        public_key: bytes,
    ) -> bool:
        """Verify a manifest proof.

        Args:
            proof: Manifest proof dict containing {statement, signatures}.
            tools: List of MCP tool objects to verify against.
            public_key: Ed25519 public key bytes (32 bytes).

        Returns:
            True if the manifest proof covers all tools correctly.
        """
        statement = proof.get("statement")
        signatures = proof.get("signatures")
        if not isinstance(statement, dict) or not isinstance(signatures, list):
            return False

        # 1. Verify statement type
        if statement.get("typ") != AMTSS_MANIFEST_STATEMENT_TYPE:
            logger.warning(
                "Statement type mismatch: expected=%s, got=%s",
                AMTSS_MANIFEST_STATEMENT_TYPE,
                statement.get("typ"),
            )
            return False

        # 2. Verify each tool digest in manifest matches actual tools
        manifest_tools = statement.get("tools", [])
        if len(manifest_tools) != len(tools):
            return False

        tool_by_name = {t["name"]: t for t in tools}
        # Collect manifest tool names as a set to detect duplicates
        # and verify full coverage of all actual tools
        manifest_names: set[str] = set()
        for mt in manifest_tools:
            name = mt.get("name")
            if name in manifest_names:
                # Duplicate tool name in manifest — reject
                logger.warning("Duplicate tool name in manifest: %s", name)
                return False
            manifest_names.add(name)
            if name not in tool_by_name:
                return False
            expected = compute_tool_digest(tool_by_name[name])
            if mt.get("digest") != expected:
                return False

        # Verify manifest covers ALL actual tools (no tool left uncovered)
        if manifest_names != set(tool_by_name.keys()):
            logger.warning("Manifest does not cover all tools")
            return False

        # 3. Verify signature
        canonical = _canonicalize_json(statement)
        for sig_entry in signatures:
            if sig_entry.get("alg") != "Ed25519":
                continue
            try:
                sig_raw = sig_entry.get("sig")
                if not isinstance(sig_raw, str):
                    continue
                sig_bytes = _base64url_decode(sig_raw)
                pub = Ed25519PublicKey.from_public_bytes(public_key)
                pub.verify(sig_bytes, canonical)
                return True
            except (InvalidSignature, ValueError, TypeError):
                continue

        return False
