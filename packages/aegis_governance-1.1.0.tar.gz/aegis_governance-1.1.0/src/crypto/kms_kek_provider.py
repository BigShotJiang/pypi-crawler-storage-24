"""AWS KMS KEK Provider — envelope encryption for HybridKEM keys.

Uses AWS KMS to wrap/unwrap the HybridKEM private key blob at rest.
At startup, KMS decrypts the wrapped key; all HybridKEM crypto operations
(X25519 + ML-KEM-768 + AES-256-GCM) happen in software because no HSM
supports ML-KEM-768 natively.

Security Model:
- KMS protects the private key AT REST (storage, rotation, access control)
- Private key is held in memory only while the process is running
- KMS key policy controls who can unwrap the key
- CloudTrail logs every KMS Decrypt call

Environment Variables (from_environment):
- AEGIS_KMS_KEY_ID: KMS key ARN or alias
- AEGIS_KMS_WRAPPED_PRIVATE_KEY: Base64-encoded KMS-encrypted private key blob
- AEGIS_MASTER_KEK_PUBLIC: Base64-encoded HybridKEM public key (1,216 bytes)

GAP-Q2 Phase 3: HSM/KMS Key Store Integration
"""

from __future__ import annotations

import base64
import logging
import os
import threading
from datetime import datetime, timezone
from typing import Any

from . import HYBRID_KEM_AVAILABLE

if HYBRID_KEM_AVAILABLE:
    from .hybrid_kem import (
        HybridEncryptedBlob,
        HybridKEMPrivateKey,
        HybridKEMProvider,
        HybridKEMPublicKey,
    )

from .kek_provider import KEKMetadata, KEKProvider

logger = logging.getLogger(__name__)

try:
    import boto3

    _HAS_BOTO3 = True
except ImportError:
    _HAS_BOTO3 = False


class AWSKMSKEKProvider(KEKProvider):
    """KEK provider using AWS KMS for envelope encryption.

    Wraps the HybridKEM private key blob using AWS KMS. At startup,
    calls KMS Decrypt to unwrap the private key into memory. All
    subsequent encrypt/decrypt operations use the in-memory HybridKEM
    keypair directly.

    This is the recommended production KEK provider for AWS deployments.

    Security Properties:
    - Private key encrypted at rest by KMS (AES-256-GCM under the hood)
    - KMS key policy + IAM controls who can unwrap
    - CloudTrail audit log for every Decrypt call
    - Key rotation via KMS automatic key rotation
    """

    def __init__(
        self,
        kms_key_id: str,
        wrapped_private_key: bytes,
        public_key_bytes: bytes,
        version: int = 1,
        region_name: str | None = None,
        boto3_session: Any | None = None,
    ) -> None:
        """Initialize KMS-backed KEK provider.

        Args:
            kms_key_id: KMS key ARN, key ID, or alias ARN
            wrapped_private_key: KMS-encrypted HybridKEM private key blob
            public_key_bytes: Raw HybridKEM public key (1,216 bytes)
            version: KEK version number
            region_name: AWS region (defaults to boto3 default)
            boto3_session: Optional boto3.Session for custom credentials

        Raises:
            RuntimeError: If boto3 or HybridKEM is not available
            RuntimeError: If KMS Decrypt fails
            ValueError: If public key is malformed

        """
        if not _HAS_BOTO3:
            raise RuntimeError(
                "boto3 is required for AWSKMSKEKProvider. "
                "Install with: pip install aegis-governance[kms]",
            )
        if not HYBRID_KEM_AVAILABLE:
            raise RuntimeError(
                "HybridKEMProvider not available. "
                "Install liboqs-python>=0.10.0 for post-quantum support.",
            )

        self._kms_key_id = kms_key_id
        self._version = version
        self._lock = threading.Lock()
        self._kem_provider = HybridKEMProvider()
        self._created_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

        # Build KMS client
        if boto3_session is not None:
            self._kms_client = boto3_session.client("kms", region_name=region_name)
        else:
            self._kms_client = boto3.client("kms", region_name=region_name)

        # Load public key (not secret — no KMS needed)
        self._public_key = HybridKEMPublicKey.from_bytes(public_key_bytes)

        # Unwrap private key via KMS Decrypt
        self._private_key = self._unwrap_private_key(wrapped_private_key)

        logger.info(
            "KMS KEK provider initialized: key_id=%s, version=%d",
            self._kms_key_id,
            self._version,
        )

    def _unwrap_private_key(self, wrapped_blob: bytes) -> HybridKEMPrivateKey:
        """Unwrap the HybridKEM private key using KMS Decrypt.

        Args:
            wrapped_blob: KMS-encrypted private key bytes

        Returns:
            HybridKEMPrivateKey loaded from the decrypted bytes

        Raises:
            RuntimeError: If KMS Decrypt fails

        """
        try:
            response = self._kms_client.decrypt(
                CiphertextBlob=wrapped_blob,
                KeyId=self._kms_key_id,
                EncryptionContext={
                    "purpose": "aegis-kek",
                    "version": str(self._version),
                },
            )
            private_bytes: bytes = response["Plaintext"]
            return HybridKEMPrivateKey.from_bytes(private_bytes)
        except Exception as exc:
            raise RuntimeError(
                f"KMS Decrypt failed for key {self._kms_key_id}: {exc}"
            ) from exc

    @classmethod
    def from_environment(
        cls,
        version: int = 1,
        region_name: str | None = None,
        boto3_session: Any | None = None,
    ) -> AWSKMSKEKProvider:
        """Create provider from environment variables.

        Environment Variables:
            AEGIS_KMS_KEY_ID: KMS key ARN or alias
            AEGIS_KMS_WRAPPED_PRIVATE_KEY: Base64-encoded KMS-encrypted private key
            AEGIS_MASTER_KEK_PUBLIC: Base64-encoded HybridKEM public key

        Args:
            version: KEK version number
            region_name: AWS region override
            boto3_session: Optional boto3.Session for custom credentials

        Returns:
            Configured AWSKMSKEKProvider

        Raises:
            ValueError: If required environment variables are missing

        """
        kms_key_id = os.environ.get("AEGIS_KMS_KEY_ID")
        if not kms_key_id:
            raise ValueError("AEGIS_KMS_KEY_ID environment variable is required")

        wrapped_b64 = os.environ.get("AEGIS_KMS_WRAPPED_PRIVATE_KEY")
        if not wrapped_b64:
            raise ValueError(
                "AEGIS_KMS_WRAPPED_PRIVATE_KEY environment variable is required"
            )

        public_b64 = os.environ.get("AEGIS_MASTER_KEK_PUBLIC")
        if not public_b64:
            raise ValueError("AEGIS_MASTER_KEK_PUBLIC environment variable is required")

        wrapped_private_key = base64.b64decode(wrapped_b64, validate=True)
        public_key_bytes = base64.b64decode(public_b64, validate=True)

        return cls(
            kms_key_id=kms_key_id,
            wrapped_private_key=wrapped_private_key,
            public_key_bytes=public_key_bytes,
            version=version,
            region_name=region_name,
            boto3_session=boto3_session,
        )

    @property
    def algorithm_name(self) -> str:
        """Return the algorithm name."""
        return "x25519+ml-kem-768+aes-256-gcm"

    @property
    def current_version(self) -> int:
        """Return the current KEK version."""
        return self._version

    def get_public_key(self, version: int = 0) -> HybridKEMPublicKey:
        """Get KEK public key.

        Args:
            version: KEK version (0 = current)

        Returns:
            HybridKEMPublicKey for the specified version

        Raises:
            ValueError: If version does not match current

        """
        if version not in (0, self._version):
            raise ValueError(
                f"KEK version {version} not found (current: {self._version})",
            )
        return self._public_key

    def encrypt(
        self,
        plaintext: bytes,
        version: int = 0,
        *,
        allow_empty: bool = False,
    ) -> bytes:
        """Encrypt data using KEK.

        Args:
            plaintext: Data to encrypt
            version: KEK version (0 = current)
            allow_empty: Allow empty plaintext

        Returns:
            Encrypted blob bytes

        """
        public_key = self.get_public_key(version)
        with self._lock:
            blob = self._kem_provider.encrypt(
                plaintext, public_key, allow_empty=allow_empty
            )
        return blob.to_bytes()

    def decrypt(self, encrypted_blob: bytes, version: int = 0) -> bytes:
        """Decrypt data using KEK.

        Args:
            encrypted_blob: HybridEncryptedBlob bytes
            version: KEK version used for encryption

        Returns:
            Decrypted plaintext bytes

        Raises:
            ValueError: If version mismatch or decryption fails

        """
        if version not in (0, self._version):
            raise ValueError(f"KEK version {version} not found")

        blob = HybridEncryptedBlob.from_bytes(encrypted_blob)
        with self._lock:
            return self._kem_provider.decrypt(blob, self._private_key)

    def get_metadata(self) -> KEKMetadata:
        """Get KEK metadata."""
        return KEKMetadata(
            version=self._version,
            algorithm=self.algorithm_name,
            created_at=self._created_at,
            provider_type="kms",
        )


__all__ = [
    "AWSKMSKEKProvider",
]
