"""ML-DSA (Dilithium) Post-Quantum Signature Wrapper.

Provides a thin wrapper around liboqs-python for ML-DSA-44 (Dilithium Level 2)
post-quantum digital signatures as standardized in FIPS 204.

ML-DSA-44 Properties:
- Security level: NIST Level 2 (128-bit post-quantum)
- Signature size: 2,420 bytes
- Public key size: 1,312 bytes
- Private key size: 2,560 bytes

References:
- FIPS 204: https://csrc.nist.gov/pubs/fips/204/final
- liboqs: https://openquantumsafe.org/liboqs/

GAP-Q1: Post-Quantum Signature Hardening

"""

import logging
from typing import Any

logger = logging.getLogger(__name__)

# ML-DSA-44 (Dilithium Level 2) constants per FIPS 204
ALGORITHM_NAME = "ML-DSA-44"
SIGNATURE_SIZE = 2420
PUBLIC_KEY_SIZE = 1312
PRIVATE_KEY_SIZE = 2560

# liboqs algorithm identifier (use FIPS 204 name, not legacy Dilithium2)
LIBOQS_ALGORITHM = "ML-DSA-44"

# Module availability flag - typed as Any to allow dynamic attribute access
_oqs: Any = None
MLDSA_AVAILABLE = False

try:
    import oqs

    _oqs = oqs
    MLDSA_AVAILABLE = True
    logger.debug("liboqs-python loaded successfully for ML-DSA support")
except ImportError:
    logger.warning(
        "liboqs-python not available. Install with: pip install liboqs-python",
    )
except (SystemExit, RuntimeError, OSError) as e:
    # liboqs-python may raise SystemExit if native liboqs library is not installed
    # or RuntimeError/OSError if shared library loading fails
    logger.warning(
        f"liboqs native library not available ({type(e).__name__}). "
        "Install liboqs: brew install liboqs (macOS) or build from source.",
    )


class MLDSAError(Exception):
    """Exception raised for ML-DSA cryptographic errors."""


def generate_keypair() -> tuple[bytes, bytes]:
    """Generate ML-DSA-44 keypair.

    Returns:
        (private_key, public_key) as bytes

    Raises:
        MLDSAError: If liboqs is not available or key generation fails

    """
    if not MLDSA_AVAILABLE or _oqs is None:
        raise MLDSAError("liboqs-python is not installed")

    try:
        sig = _oqs.Signature(LIBOQS_ALGORITHM)
        public_key = sig.generate_keypair()
        private_key = sig.export_secret_key()

        if len(public_key) != PUBLIC_KEY_SIZE:
            raise MLDSAError(
                f"Unexpected public key size: {len(public_key)} != {PUBLIC_KEY_SIZE}",
            )

        if len(private_key) != PRIVATE_KEY_SIZE:
            raise MLDSAError(
                f"Unexpected private key size: {len(private_key)} != {PRIVATE_KEY_SIZE}",
            )

        logger.debug(
            f"ML-DSA-44 keypair generated: pub={len(public_key)}B, priv={len(private_key)}B",
        )
        return private_key, public_key

    except (ValueError, TypeError, RuntimeError, OSError) as e:
        raise MLDSAError(f"Key generation failed: {e}") from e


def sign(message: bytes, private_key: bytes) -> bytes:
    """Sign message with ML-DSA-44.

    Args:
        message: Message bytes to sign (any length)
        private_key: 2,560-byte ML-DSA private key

    Returns:
        2,420-byte ML-DSA signature

    Raises:
        MLDSAError: If signing fails or inputs are invalid

    """
    if not MLDSA_AVAILABLE or _oqs is None:
        raise MLDSAError("liboqs-python is not installed")

    if len(private_key) != PRIVATE_KEY_SIZE:
        raise MLDSAError(
            f"Invalid private key size: {len(private_key)} != {PRIVATE_KEY_SIZE}",
        )

    if len(message) == 0:
        raise MLDSAError(
            "message must not be empty. Provide at least 1 byte of data to sign."
        )

    try:
        sig = _oqs.Signature(LIBOQS_ALGORITHM, private_key)
        signature = sig.sign(message)

        if len(signature) != SIGNATURE_SIZE:
            raise MLDSAError(
                f"Unexpected signature size: {len(signature)} != {SIGNATURE_SIZE}",
            )

        logger.debug(f"ML-DSA-44 signature created: {len(signature)} bytes")
        result: bytes = signature
        return result

    except (ValueError, TypeError, RuntimeError, OSError) as e:
        raise MLDSAError(f"Signing failed: {e}") from e


def verify(signature: bytes, message: bytes, public_key: bytes) -> bool:
    """Verify ML-DSA-44 signature.

    Args:
        signature: 2,420-byte ML-DSA signature
        message: Original message bytes
        public_key: 1,312-byte ML-DSA public key

    Returns:
        True if signature is valid, False otherwise

    """
    if not MLDSA_AVAILABLE or _oqs is None:
        logger.warning("liboqs-python not available for verification")
        return False

    if len(signature) != SIGNATURE_SIZE:
        logger.warning(f"Invalid signature size: {len(signature)} != {SIGNATURE_SIZE}")
        return False

    if len(public_key) != PUBLIC_KEY_SIZE:
        logger.warning(
            f"Invalid public key size: {len(public_key)} != {PUBLIC_KEY_SIZE}",
        )
        return False

    try:
        sig = _oqs.Signature(LIBOQS_ALGORITHM)
        result = sig.verify(message, signature, public_key)

        if result:
            logger.debug("ML-DSA-44 signature verification succeeded")
        else:
            logger.warning("ML-DSA-44 signature verification failed")

        verified: bool = result
        return verified

    except (ValueError, TypeError, RuntimeError, OSError) as e:
        logger.warning(f"ML-DSA-44 verification error: {e}")
        return False


def get_algorithm_info() -> dict[str, object]:
    """Get ML-DSA algorithm information.

    Returns:
        Dictionary with algorithm properties

    """
    return {
        "name": ALGORITHM_NAME,
        "liboqs_name": LIBOQS_ALGORITHM,
        "signature_size": SIGNATURE_SIZE,
        "public_key_size": PUBLIC_KEY_SIZE,
        "private_key_size": PRIVATE_KEY_SIZE,
        "security_level": "NIST Level 2 (128-bit post-quantum)",
        "standard": "FIPS 204",
        "available": MLDSA_AVAILABLE,
    }
