"""Hybrid Signature Provider (Ed25519 + ML-DSA-44).

Implements hybrid post-quantum signatures combining classical Ed25519
with ML-DSA-44 (Dilithium Level 2) for defense-in-depth security.

Hybrid Signature Format:
- Ed25519 signature: 64 bytes
- ML-DSA-44 signature: 2,420 bytes
- Total: 2,484 bytes

Hybrid Public Key Format:
- Ed25519 public key: 32 bytes
- ML-DSA-44 public key: 1,312 bytes
- Total: 1,344 bytes

Hybrid Private Key Format:
- Ed25519 private key: 32 bytes
- ML-DSA-44 private key: 2,560 bytes
- Total: 2,592 bytes

Security Properties:
- Requires BOTH signatures to verify (defense in depth)
- Protects against "harvest now, decrypt later" attacks
- Future-proof against quantum computing threats
- Backward compatible via provider injection

References:
- NIST SP 800-208: Hybrid Signatures
- FIPS 204: ML-DSA (Dilithium)

GAP-Q1: Post-Quantum Signature Hardening

"""

import hashlib
import json
import logging
from dataclasses import dataclass

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from . import mldsa

logger = logging.getLogger(__name__)

# Ed25519 constants
ED25519_SIGNATURE_SIZE = 64
ED25519_PUBLIC_KEY_SIZE = 32
ED25519_PRIVATE_KEY_SIZE = 32

# Hybrid signature format (Ed25519 || ML-DSA)
HYBRID_SIGNATURE_SIZE = ED25519_SIGNATURE_SIZE + mldsa.SIGNATURE_SIZE  # 2,484
HYBRID_PUBLIC_KEY_SIZE = ED25519_PUBLIC_KEY_SIZE + mldsa.PUBLIC_KEY_SIZE  # 1,344
HYBRID_PRIVATE_KEY_SIZE = ED25519_PRIVATE_KEY_SIZE + mldsa.PRIVATE_KEY_SIZE  # 2,592


@dataclass
class HybridKeyPair:
    """Container for hybrid keypair components."""

    ed25519_private: bytes
    ed25519_public: bytes
    mldsa_private: bytes
    mldsa_public: bytes

    @property
    def private_key(self) -> bytes:
        """Combined private key (Ed25519 || ML-DSA)."""
        return self.ed25519_private + self.mldsa_private

    @property
    def public_key(self) -> bytes:
        """Combined public key (Ed25519 || ML-DSA)."""
        return self.ed25519_public + self.mldsa_public


@dataclass
class HybridSignature:
    """Container for hybrid signature components."""

    ed25519_sig: bytes
    mldsa_sig: bytes

    @property
    def combined(self) -> bytes:
        """Combined signature (Ed25519 || ML-DSA)."""
        return self.ed25519_sig + self.mldsa_sig

    @classmethod
    def from_bytes(cls, data: bytes) -> "HybridSignature":
        """Parse combined signature bytes."""
        if len(data) != HYBRID_SIGNATURE_SIZE:
            raise ValueError(
                f"Invalid hybrid signature size: {len(data)} != {HYBRID_SIGNATURE_SIZE}",
            )
        return cls(
            ed25519_sig=data[:ED25519_SIGNATURE_SIZE],
            mldsa_sig=data[ED25519_SIGNATURE_SIZE:],
        )


class HybridSignatureProvider:
    """Hybrid Ed25519 + ML-DSA-44 signature provider.

    Implements the SignatureProvider protocol with post-quantum security.
    Both Ed25519 and ML-DSA signatures must verify for acceptance.

    Args:
        audit_mode: If True, enables detailed logging of cryptographic operations
            including timing information for each signature verification step.
            Default is False to prevent timing side-channel leakage in logs.
            Only enable for debugging or security audits in controlled environments.

    Example:
        >>> provider = HybridSignatureProvider()
        >>> private_key, public_key = provider.generate_keypair()
        >>> msg_hash = provider.create_message_hash("prop-1", "test", ["gate1"])
        >>> signature = provider.sign(msg_hash, private_key)
        >>> assert provider.verify(signature, msg_hash, public_key)

    Security Note:
        When audit_mode=False (default), verification logging is minimized to
        prevent timing side-channel attacks. Detailed logs showing which
        signature component (Ed25519 vs ML-DSA) passed or failed could leak
        information useful to attackers.

    """

    # Size constants
    SIGNATURE_SIZE = HYBRID_SIGNATURE_SIZE  # 2,484 bytes
    PUBLIC_KEY_SIZE = HYBRID_PUBLIC_KEY_SIZE  # 1,344 bytes
    PRIVATE_KEY_SIZE = HYBRID_PRIVATE_KEY_SIZE  # 2,592 bytes

    def __init__(self, *, audit_mode: bool = False) -> None:
        """Initialize HybridSignatureProvider.

        Args:
            audit_mode: Enable detailed cryptographic operation logging.
                Default False prevents timing info leakage in logs.

        """
        self._audit_mode = audit_mode

    @property
    def audit_mode(self) -> bool:
        """Return whether audit mode is enabled."""
        return self._audit_mode

    @property
    def algorithm_name(self) -> str:
        """Return algorithm identifier."""
        return "ed25519+ml-dsa-44"

    @property
    def signature_size(self) -> int:
        """Return signature size in bytes."""
        return self.SIGNATURE_SIZE

    @property
    def public_key_size(self) -> int:
        """Return public key size in bytes."""
        return self.PUBLIC_KEY_SIZE

    def generate_keypair(self) -> tuple[bytes, bytes]:
        """Generate hybrid keypair (Ed25519 + ML-DSA-44).

        Returns:
            (private_key, public_key) as concatenated bytes
            - private_key: 2,592 bytes (32 Ed25519 + 2,560 ML-DSA)
            - public_key: 1,344 bytes (32 Ed25519 + 1,312 ML-DSA)

        Raises:
            RuntimeError: If ML-DSA is not available

        """
        if not mldsa.MLDSA_AVAILABLE:
            raise RuntimeError(
                "ML-DSA not available. Install liboqs-python: pip install liboqs-python",
            )

        # Generate Ed25519 keypair
        ed_private = Ed25519PrivateKey.generate()
        ed_public = ed_private.public_key()

        ed_private_bytes = ed_private.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        ed_public_bytes = ed_public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

        # Generate ML-DSA keypair
        mldsa_private_bytes, mldsa_public_bytes = mldsa.generate_keypair()

        # Create hybrid keypair
        keypair = HybridKeyPair(
            ed25519_private=ed_private_bytes,
            ed25519_public=ed_public_bytes,
            mldsa_private=mldsa_private_bytes,
            mldsa_public=mldsa_public_bytes,
        )

        logger.debug(
            f"Hybrid keypair generated: pub={len(keypair.public_key)}B, "
            f"priv={len(keypair.private_key)}B",
        )

        return keypair.private_key, keypair.public_key

    def create_message_hash(
        self,
        proposal_id: str,
        justification: str,
        failed_gates: list[str],
    ) -> bytes:
        """Create message hash for signing.

        Uses SHA-256 of canonical JSON for compatibility with both
        Ed25519 and ML-DSA signing (both accept arbitrary-length messages,
        but we hash for consistency with other providers).

        Args:
            proposal_id: Proposal identifier
            justification: Override justification
            failed_gates: List of failed gate names

        Returns:
            32-byte SHA-256 hash

        """
        canonical = json.dumps(
            {
                "proposal_id": proposal_id,
                "justification": justification,
                "failed_gates": sorted(failed_gates),
                "version": "1.0",
                "algorithm": "ed25519+ml-dsa-44",
            },
            sort_keys=True,
        )

        return hashlib.sha256(canonical.encode("utf-8")).digest()

    def sign(self, message_hash: bytes, private_key: bytes) -> bytes:
        """Sign message hash with both Ed25519 and ML-DSA.

        Args:
            message_hash: 32-byte message hash
            private_key: 2,592-byte hybrid private key

        Returns:
            2,484-byte hybrid signature (Ed25519 || ML-DSA)

        Raises:
            ValueError: If inputs are malformed
            RuntimeError: If ML-DSA is not available

        """
        if len(message_hash) == 0:
            raise ValueError(
                "message_hash must not be empty. "
                "Use create_message_hash() to generate a valid hash."
            )
        if len(message_hash) != 32:
            raise ValueError(f"Message hash must be 32 bytes, got {len(message_hash)}")

        if len(private_key) != self.PRIVATE_KEY_SIZE:
            raise ValueError(
                f"Private key must be {self.PRIVATE_KEY_SIZE} bytes, "
                f"got {len(private_key)}",
            )

        if not mldsa.MLDSA_AVAILABLE:
            raise RuntimeError("ML-DSA not available")

        # Split hybrid private key
        ed_private_bytes = private_key[:ED25519_PRIVATE_KEY_SIZE]
        mldsa_private_bytes = private_key[ED25519_PRIVATE_KEY_SIZE:]

        # Sign with Ed25519
        ed_private = Ed25519PrivateKey.from_private_bytes(ed_private_bytes)
        ed_signature = ed_private.sign(message_hash)

        # Sign with ML-DSA
        mldsa_signature = mldsa.sign(message_hash, mldsa_private_bytes)

        # Combine signatures
        hybrid_sig = HybridSignature(
            ed25519_sig=ed_signature,
            mldsa_sig=mldsa_signature,
        )

        logger.debug(
            f"Hybrid signature created: Ed25519={len(ed_signature)}B, "
            f"ML-DSA={len(mldsa_signature)}B, total={len(hybrid_sig.combined)}B",
        )

        return hybrid_sig.combined

    def verify(
        self,
        signature: bytes,
        message_hash: bytes,
        public_key: bytes,
    ) -> bool:
        """Verify hybrid signature (BOTH must be valid).

        Args:
            signature: 2,484-byte hybrid signature
            message_hash: 32-byte message hash
            public_key: 1,344-byte hybrid public key

        Returns:
            True only if BOTH signatures are valid

        Note:
            Detailed verification timing is only logged when audit_mode=True
            to prevent timing side-channel leakage. In normal mode, only the
            final verification result is logged.

        """
        # Validate sizes (these checks don't leak timing info about crypto operations)
        if len(signature) != self.SIGNATURE_SIZE:
            logger.warning(
                f"Signature size mismatch: got {len(signature)}, "
                f"expected {self.SIGNATURE_SIZE}",
            )
            return False

        if len(public_key) != self.PUBLIC_KEY_SIZE:
            logger.warning(
                f"Public key size mismatch: got {len(public_key)}, "
                f"expected {self.PUBLIC_KEY_SIZE}",
            )
            return False

        if len(message_hash) != 32:
            logger.warning(
                f"Message hash size mismatch: got {len(message_hash)}, expected 32",
            )
            return False

        # Parse hybrid signature and public key
        try:
            hybrid_sig = HybridSignature.from_bytes(signature)
        except ValueError as e:
            logger.warning(f"Failed to parse hybrid signature: {e}")
            return False

        ed_public_bytes = public_key[:ED25519_PUBLIC_KEY_SIZE]
        mldsa_public_bytes = public_key[ED25519_PUBLIC_KEY_SIZE:]

        # Verify Ed25519
        ed25519_valid = self._verify_ed25519_component(
            hybrid_sig.ed25519_sig, message_hash, ed_public_bytes
        )

        # Verify ML-DSA
        mldsa_valid = mldsa.verify(
            hybrid_sig.mldsa_sig,
            message_hash,
            mldsa_public_bytes,
        )
        if self._audit_mode:
            self._log_mldsa_result(mldsa_valid)

        # BOTH must be valid (defense in depth)
        return self._finalize_verification(ed25519_valid, mldsa_valid)

    def _verify_ed25519_component(
        self,
        ed25519_sig: bytes,
        message_hash: bytes,
        ed_public_bytes: bytes,
    ) -> bool:
        """Verify Ed25519 signature component.

        Internal helper to reduce branch complexity in verify().
        """
        try:
            ed_public = Ed25519PublicKey.from_public_bytes(ed_public_bytes)
            ed_public.verify(ed25519_sig, message_hash)
            if self._audit_mode:
                logger.debug("Ed25519 signature verified")
            return True
        except (InvalidSignature, ValueError, TypeError) as e:
            if self._audit_mode:
                logger.warning(f"Ed25519 verification failed: {e}")
            return False

    def _log_mldsa_result(self, mldsa_valid: bool) -> None:
        """Log ML-DSA verification result (audit mode only)."""
        if mldsa_valid:
            logger.debug("ML-DSA signature verified")
        else:
            logger.warning("ML-DSA verification failed")

    def _finalize_verification(self, ed25519_valid: bool, mldsa_valid: bool) -> bool:
        """Finalize verification and log result.

        Internal helper to reduce branch complexity in verify().
        """
        if ed25519_valid and mldsa_valid:
            logger.debug("Hybrid signature verification succeeded")
            return True

        # In audit mode, log which component failed; otherwise just log failure
        if self._audit_mode:
            logger.warning(
                f"Hybrid signature verification failed: "
                f"Ed25519={ed25519_valid}, ML-DSA={mldsa_valid}",
            )
        else:
            logger.warning("Hybrid signature verification failed")
        return False

    def verify_ed25519_only(
        self,
        signature: bytes,
        message_hash: bytes,
        public_key: bytes,
    ) -> bool:
        """Verify only the Ed25519 component (for backward compatibility testing).

        This method is NOT recommended for production use.
        """
        if len(signature) < ED25519_SIGNATURE_SIZE:
            return False
        if len(public_key) < ED25519_PUBLIC_KEY_SIZE:
            return False

        try:
            ed_sig = signature[:ED25519_SIGNATURE_SIZE]
            ed_pub = public_key[:ED25519_PUBLIC_KEY_SIZE]

            ed_public = Ed25519PublicKey.from_public_bytes(ed_pub)
            ed_public.verify(ed_sig, message_hash)
            return True
        except (InvalidSignature, ValueError, TypeError):
            return False
