"""Cryptographic primitives for AEGIS.

Signature Providers (for override workflow):
- HybridSignatureProvider: Ed25519 + ML-DSA-44 hybrid (post-quantum, recommended)
- BIP322Provider: BIP-340 Schnorr signatures (Bitcoin-native)
- Ed25519Provider: Ed25519 signatures (deprecated, legacy fallback)

Encryption Providers (for data at rest):
- HybridKEMProvider: X25519 + ML-KEM-768 + AES-256-GCM (post-quantum)

KEK Providers (for key encryption at rest):
- AWSKMSKEKProvider: AWS KMS envelope encryption (requires boto3)
- HSMKEKProvider: PKCS#11 HSM envelope encryption (requires python-pkcs11)
- EnvironmentKEKProvider: Environment variable keys (containerized deployments)
- InMemoryKEKProvider: Ephemeral keys (testing only)

GAP-M4: BIP-322 Signature Format Standardization
GAP-Q1: Post-Quantum Signature Hardening
GAP-Q2: Post-Quantum Key Encapsulation
"""

from .bip340 import BIP322_TAG, tagged_hash
from .providers import SignatureProvider, SignatureResult

# Provider implementations are imported conditionally to handle
# optional dependencies gracefully

# ML-DSA availability (requires liboqs-python + native liboqs library)
try:
    from . import mldsa

    MLDSA_AVAILABLE = mldsa.MLDSA_AVAILABLE
except ImportError:
    MLDSA_AVAILABLE = False
    mldsa = None  # type: ignore[assignment]
except (SystemExit, RuntimeError, OSError):
    # liboqs-python may raise SystemExit if native liboqs is not installed
    MLDSA_AVAILABLE = False
    mldsa = None  # type: ignore[assignment]

# ML-KEM availability (requires liboqs-python + native liboqs library)
try:
    from . import mlkem

    MLKEM_AVAILABLE = mlkem.MLKEM_AVAILABLE
except ImportError:
    MLKEM_AVAILABLE = False
    mlkem = None  # type: ignore[assignment]
except (SystemExit, RuntimeError, OSError):
    # liboqs-python may raise SystemExit if native liboqs is not installed
    MLKEM_AVAILABLE = False
    mlkem = None  # type: ignore[assignment]

# Hybrid signature provider (requires liboqs-python + cryptography)
try:
    from .hybrid_provider import HybridSignatureProvider

    HYBRID_AVAILABLE = MLDSA_AVAILABLE  # Hybrid requires ML-DSA
except ImportError:
    HYBRID_AVAILABLE = False
    HybridSignatureProvider = None  # type: ignore[misc, assignment]

# Hybrid KEM provider (requires liboqs-python + cryptography)
HYBRID_KEM_AVAILABLE: bool = False
try:
    from .hybrid_kem import (
        HybridEncryptedBlob,
        HybridKEMKeyPair,
        HybridKEMPrivateKey,
        HybridKEMProvider,
        HybridKEMPublicKey,
    )

    HYBRID_KEM_AVAILABLE = MLKEM_AVAILABLE  # Hybrid KEM requires ML-KEM
except ImportError:
    HYBRID_KEM_AVAILABLE = False
    HybridKEMProvider = None  # type: ignore[misc, assignment]
    HybridKEMKeyPair = None  # type: ignore[misc, assignment]
    HybridKEMPublicKey = None  # type: ignore[misc, assignment]
    HybridKEMPrivateKey = None  # type: ignore[misc, assignment]
    HybridEncryptedBlob = None  # type: ignore[misc, assignment]

# BIP-322 provider (requires btclib)
try:
    from .bip322_provider import BIP322Provider

    BIP322_AVAILABLE = True
except ImportError:
    BIP322_AVAILABLE = False
    BIP322Provider = None  # type: ignore[misc, assignment]

# Ed25519 provider (requires cryptography, deprecated)
try:
    from .ed25519_provider import Ed25519Provider

    ED25519_AVAILABLE = True
except ImportError:
    ED25519_AVAILABLE = False
    Ed25519Provider = None  # type: ignore[misc, assignment]

# Schema signer (AMTSS Protocol v1 — requires cryptography)
try:
    from .schema_signer import (
        AMTSS_CAPABILITY_KEY,
        AMTSS_META_KEY,
        AMTSS_VERSION,
        SigningKeyPair,
        ToolSchemaSigner,
        compute_tool_digest,
    )

    SCHEMA_SIGNER_AVAILABLE = True
except ImportError:
    SCHEMA_SIGNER_AVAILABLE = False
    ToolSchemaSigner = None  # type: ignore[misc, assignment]
    SigningKeyPair = None  # type: ignore[misc, assignment]
    compute_tool_digest = None  # type: ignore[assignment]
    AMTSS_META_KEY = None  # type: ignore[assignment]
    AMTSS_CAPABILITY_KEY = None  # type: ignore[assignment]
    AMTSS_VERSION = None  # type: ignore[assignment]

# AWS KMS KEK provider (requires boto3)
try:
    from .kms_kek_provider import AWSKMSKEKProvider

    KMS_KEK_AVAILABLE = True
except ImportError:
    KMS_KEK_AVAILABLE = False
    AWSKMSKEKProvider = None  # type: ignore[misc, assignment]

# PKCS#11 HSM KEK provider (requires python-pkcs11)
try:
    from .hsm_kek_provider import HSMKEKProvider

    HSM_KEK_AVAILABLE = True
except ImportError:
    HSM_KEK_AVAILABLE = False
    HSMKEKProvider = None  # type: ignore[misc, assignment]


def get_default_provider() -> "SignatureProvider":
    """Get the default signature provider.

    Priority order (highest to lowest):
    1. HybridSignatureProvider (post-quantum, recommended for new deployments)
    2. BIP322Provider (Bitcoin-native Schnorr)
    3. Ed25519Provider (deprecated legacy)

    Note: HybridSignatureProvider is not returned by default until GAP-Q1 is
    fully validated. Use get_hybrid_provider() explicitly for post-quantum.

    Returns:
        Default SignatureProvider instance

    Raises:
        RuntimeError: If no signature provider is available

    """
    # For now, BIP322 remains default until hybrid is fully validated
    # To use hybrid, call get_hybrid_provider() explicitly
    if BIP322_AVAILABLE and BIP322Provider is not None:
        return BIP322Provider()
    if ED25519_AVAILABLE and Ed25519Provider is not None:
        import warnings

        warnings.warn(
            "BIP322Provider not available, falling back to Ed25519Provider. "
            "Install btclib>=2023.7.12 for BIP-322 support.",
            UserWarning,
            stacklevel=2,
        )
        return Ed25519Provider()
    raise RuntimeError(
        "No signature provider available. "
        "Install either btclib>=2023.7.12 or cryptography>=41.0.0",
    )


def get_hybrid_provider() -> "SignatureProvider":
    """Get the hybrid post-quantum signature provider.

    Returns HybridSignatureProvider for Ed25519 + ML-DSA-44 hybrid signatures.
    This provides defense-in-depth against quantum computing threats.

    Returns:
        HybridSignatureProvider instance

    Raises:
        RuntimeError: If liboqs-python is not available

    """
    if HYBRID_AVAILABLE and HybridSignatureProvider is not None:
        return HybridSignatureProvider()
    raise RuntimeError(
        "HybridSignatureProvider not available. "
        "Install liboqs-python>=0.10.0 for post-quantum support.",
    )


def get_hybrid_kem_provider() -> "HybridKEMProvider":
    """Get the hybrid post-quantum encryption provider.

    Returns HybridKEMProvider for X25519 + ML-KEM-768 + AES-256-GCM encryption.
    This provides defense-in-depth against quantum computing threats.

    Returns:
        HybridKEMProvider instance

    Raises:
        RuntimeError: If liboqs-python is not available

    """
    if HYBRID_KEM_AVAILABLE and HybridKEMProvider is not None:
        return HybridKEMProvider()
    raise RuntimeError(
        "HybridKEMProvider not available. "
        "Install liboqs-python>=0.10.0 for post-quantum support.",
    )


__all__ = [
    "AMTSS_CAPABILITY_KEY",
    "AMTSS_META_KEY",
    "AMTSS_VERSION",
    "BIP322_AVAILABLE",
    "BIP322_TAG",
    "ED25519_AVAILABLE",
    "HSM_KEK_AVAILABLE",
    "HYBRID_AVAILABLE",
    "HYBRID_KEM_AVAILABLE",
    "KMS_KEK_AVAILABLE",
    "MLDSA_AVAILABLE",
    "MLKEM_AVAILABLE",
    "SCHEMA_SIGNER_AVAILABLE",
    "AWSKMSKEKProvider",
    "BIP322Provider",
    "Ed25519Provider",
    "HSMKEKProvider",
    "HybridEncryptedBlob",
    "HybridKEMKeyPair",
    "HybridKEMPrivateKey",
    "HybridKEMProvider",
    "HybridKEMPublicKey",
    "HybridSignatureProvider",
    "SignatureProvider",
    "SignatureResult",
    "SigningKeyPair",
    "ToolSchemaSigner",
    "compute_tool_digest",
    "get_default_provider",
    "get_hybrid_kem_provider",
    "get_hybrid_provider",
    "mldsa",
    "mlkem",
    "tagged_hash",
]
