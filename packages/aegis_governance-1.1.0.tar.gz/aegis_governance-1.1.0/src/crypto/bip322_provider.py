"""BIP-322 Signature Provider.

Implements BIP-322 Simple format using BIP-340 Schnorr signatures on secp256k1.
This is the recommended signature provider for AEGIS override workflow.

BIP-322 Simple Format:
- Uses BIP-340 Schnorr signatures
- Message hash is BIP-340 tagged hash with "BIP0322-signed-message" tag
- Signature is 64 bytes (r || s)
- Public key is 32 bytes (x-only)

References:
- BIP-322: https://bips.dev/322/
- BIP-340: https://bips.dev/340/
- btclib: https://btclib.org

GAP-M4: BIP-322 Signature Format Standardization

"""

import base64
import binascii
import json
import logging
import secrets

from btclib.ec import mult, secp256k1
from btclib.ecc.ssa import Sig
from btclib.ecc.ssa import sign_ as schnorr_sign  # sign_ for pre-hashed messages
from btclib.ecc.ssa import verify_ as schnorr_verify
from btclib.to_prv_key import int_from_prv_key

from .bip340 import BIP322_TAG, tagged_hash

logger = logging.getLogger(__name__)


class BIP322Provider:
    """BIP-322 Simple signature provider.

    Uses BIP-340 Schnorr signatures on secp256k1 curve. This is the
    recommended provider for AEGIS override workflow as it provides:

    Security Properties:
        - 128-bit security level (equivalent to Ed25519)
        - Non-malleable signatures (x-only pubkeys)
        - Batch-verifiable (future optimization)
        - Compatible with Bitcoin Taproot

    Bitcoin Ecosystem Compatibility:
        - Signatures verifiable with Bitcoin Core
        - Compatible with hardware wallets
        - Standard message format for auditing

    Example:
        >>> provider = BIP322Provider()
        >>> private_key, public_key = provider.generate_keypair()
        >>> msg_hash = provider.create_message_hash("prop-1", "test", ["gate1"])
        >>> signature = provider.sign(msg_hash, private_key)
        >>> assert provider.verify(signature, msg_hash, public_key)

    """

    # BIP-340 signature and key sizes
    SIGNATURE_SIZE = 64  # Schnorr signature: r (32) + s (32)
    PUBLIC_KEY_SIZE = 32  # x-only public key
    PRIVATE_KEY_SIZE = 32  # secp256k1 private key

    @property
    def algorithm_name(self) -> str:
        """Return algorithm identifier."""
        return "bip322-simple"

    @property
    def signature_size(self) -> int:
        """Return signature size in bytes."""
        return self.SIGNATURE_SIZE

    @property
    def public_key_size(self) -> int:
        """Return public key size in bytes."""
        return self.PUBLIC_KEY_SIZE

    # Maximum attempts for key generation before raising an error
    # In practice, the probability of failing once is ~1/2^128, so hitting
    # this limit indicates a CSPRNG failure or other critical bug.
    _MAX_KEYGEN_ATTEMPTS = 1000

    def generate_keypair(self) -> tuple[bytes, bytes]:
        """Generate secp256k1 keypair for BIP-340 signing.

        Uses cryptographically secure random source for key generation.
        The public key is in x-only format (32 bytes) as required by BIP-340.

        Returns:
            (private_key, x_only_public_key) as 32-byte each

        Raises:
            RuntimeError: If key generation fails after max attempts (indicates
                CSPRNG failure or critical bug)

        Security:
            Uses secrets.token_bytes() for cryptographic randomness.
            Private key is in range [1, n-1] where n is curve order.

        """
        # Generate random 32 bytes for private key
        # btclib handles range validation internally
        for _attempt in range(self._MAX_KEYGEN_ATTEMPTS):
            private_key_bytes = secrets.token_bytes(32)
            try:
                # Validate private key is in valid range [1, n-1]
                prv_int = int_from_prv_key(private_key_bytes)
                if 0 < prv_int < secp256k1.n:
                    break
            except (ValueError, TypeError):
                # Key out of valid range, try again
                continue
        else:
            # This should never happen with a working CSPRNG
            raise RuntimeError(
                f"Key generation failed after {self._MAX_KEYGEN_ATTEMPTS} attempts. "
                "This indicates a CSPRNG failure or critical system bug."
            )

        # Compute public key point using btclib mult
        public_point = mult(prv_int, secp256k1.G, secp256k1)
        x_Q, y_Q = public_point[0], public_point[1]

        # BIP-340: If y is odd, negate the private key so public key has even y
        if y_Q % 2:
            prv_int = secp256k1.n - prv_int

        # Convert private key back to bytes
        private_key = prv_int.to_bytes(32, "big")

        # x-only public key (BIP-340 format)
        x_only_pubkey = x_Q.to_bytes(32, "big")

        return private_key, x_only_pubkey

    def create_message_hash(
        self,
        proposal_id: str,
        justification: str,
        failed_gates: list[str],
    ) -> bytes:
        """Create BIP-322 message hash for signing.

        Uses BIP-340 tagged hash with "BIP0322-signed-message" tag.
        Message is canonical JSON with sorted keys.

        Args:
            proposal_id: Proposal identifier
            justification: Override justification
            failed_gates: List of failed gate names

        Returns:
            32-byte BIP-322 message hash

        """
        canonical = json.dumps(
            {
                "proposal_id": proposal_id,
                "justification": justification,
                "failed_gates": sorted(failed_gates),
                "version": "1.0",
            },
            sort_keys=True,
        )

        return tagged_hash(BIP322_TAG, canonical.encode("utf-8"))

    def sign(self, message_hash: bytes, private_key: bytes) -> bytes:
        """Sign message hash with BIP-340 Schnorr.

        Args:
            message_hash: 32-byte message hash
            private_key: 32-byte secp256k1 private key

        Returns:
            64-byte Schnorr signature (r || s)

        Raises:
            ValueError: If inputs are malformed

        """
        if len(message_hash) == 0:
            raise ValueError(
                "message_hash must not be empty. "
                "Use create_message_hash() to generate a valid hash."
            )
        if len(message_hash) != 32:
            raise ValueError(f"Message hash must be 32 bytes, got {len(message_hash)}")

        if len(private_key) != self.PRIVATE_KEY_SIZE:
            raise ValueError(
                f"Private key must be {self.PRIVATE_KEY_SIZE} bytes, "
                f"got {len(private_key)}",
            )

        # btclib schnorr_sign returns a Sig object, serialize to bytes
        sig: Sig = schnorr_sign(message_hash, private_key)
        signature = sig.serialize()
        logger.debug(
            f"BIP-340 signature created: {len(signature)} bytes, "
            f"hash prefix: {message_hash[:8].hex()}",
        )
        result: bytes = signature
        return result

    def verify(
        self,
        signature: bytes,
        message_hash: bytes,
        public_key: bytes,
    ) -> bool:
        """Verify BIP-340 Schnorr signature.

        Args:
            signature: 64-byte signature (r || s)
            message_hash: 32-byte message hash
            public_key: 32-byte x-only public key

        Returns:
            True if signature is valid, False otherwise

        """
        if len(signature) != self.SIGNATURE_SIZE:
            logger.warning(
                f"Signature size mismatch: got {len(signature)}, "
                f"expected {self.SIGNATURE_SIZE}",
            )
            return False

        if len(public_key) != self.PUBLIC_KEY_SIZE:
            logger.warning(
                f"Public key size mismatch: got {len(public_key)}, "
                f"expected {self.PUBLIC_KEY_SIZE}",
            )
            return False

        if len(message_hash) != 32:
            logger.warning(
                f"Message hash size mismatch: got {len(message_hash)}, expected 32",
            )
            return False

        try:
            # btclib verify_ accepts (msg_hash, pubkey, sig) where sig can be bytes
            result: bool = schnorr_verify(message_hash, public_key, signature)
            if result:
                logger.debug("BIP-340 signature verification succeeded")
            else:
                logger.warning("BIP-340 signature verification failed")
            return result
        except (ValueError, TypeError) as e:
            logger.warning(f"BIP-340 signature verification error: {e}")
            return False

    def encode_simple(self, signature: bytes) -> str:
        """Encode signature in BIP-322 Simple format.

        Simple format: base64(witness_stack)
        For single-sig Schnorr, witness = [length_prefix + signature]

        Args:
            signature: 64-byte Schnorr signature

        Returns:
            Base64-encoded BIP-322 Simple signature

        """
        if len(signature) != self.SIGNATURE_SIZE:
            raise ValueError(
                f"Signature must be {self.SIGNATURE_SIZE} bytes for BIP-322 Simple "
                f"encoding, got {len(signature)}. Pass a Schnorr signature, not a "
                "hybrid or Ed25519 signature."
            )
        # Witness stack: length-prefixed signature
        # For simple single-sig: just the signature with length prefix
        witness = bytes([len(signature)]) + signature
        return base64.b64encode(witness).decode("ascii")

    def decode_simple(self, encoded: str) -> bytes:
        """Decode BIP-322 Simple format to raw signature.

        Parses a BIP-322 Simple encoded signature and extracts the raw 64-byte
        Schnorr signature. The BIP-322 Simple format consists of a length-prefixed
        witness stack.

        Note on trailing data:
            Per the BIP-322 specification, this method extracts only the signature
            portion (length prefix + signature bytes) and intentionally ignores any
            trailing witness data. This is correct behavior because:

            1. BIP-322 Simple format allows witness stacks with additional elements
               (e.g., for multisig or complex scripts)
            2. For single-sig Schnorr, we only need the first witness element
            3. Future BIP-322 extensions may add trailing data for versioning

            If strict length validation is required for your use case, check
            ``len(base64.b64decode(encoded)) == 1 + SIGNATURE_SIZE`` before calling.

        Args:
            encoded: Base64-encoded BIP-322 Simple signature

        Returns:
            64-byte Schnorr signature

        Raises:
            ValueError: If encoding is invalid or signature portion is malformed

        """
        try:
            witness = base64.b64decode(encoded, validate=True)
            if len(witness) < 1:
                raise ValueError("Empty witness stack")

            sig_len = witness[0]
            if len(witness) < 1 + sig_len:
                raise ValueError(
                    f"Witness too short: expected {1 + sig_len}, got {len(witness)}",
                )

            # Extract only the signature portion; trailing witness data is
            # intentionally ignored per BIP-322 spec (see docstring).
            signature = witness[1 : 1 + sig_len]
            if len(signature) != self.SIGNATURE_SIZE:
                raise ValueError(
                    f"Invalid signature size: {len(signature)} != {self.SIGNATURE_SIZE}",
                )

            return signature
        except (ValueError, binascii.Error) as e:
            raise ValueError(f"Failed to decode BIP-322 Simple format: {e}") from e
