"""Master Key Encryption Key (KEK) Provider.

Abstracts the source of the Master KEK for encrypting governance keys:
- Production: HSM or cloud KMS (AWS KMS, Azure Key Vault)
- Development: Environment variables
- Testing: Ephemeral in-memory generation

Security Principles:
- KEK NEVER stored in database
- KEK NEVER logged
- KEK loaded once at application startup
- Private key operations protected by try/finally for cleanup

Environment Variables (EnvironmentKEKProvider):
- AEGIS_MASTER_KEK_PUBLIC: Base64-encoded HybridKEM public key (1,216 bytes)
- AEGIS_MASTER_KEK_PRIVATE: Base64-encoded HybridKEM private key (2,432 bytes)

GAP-Q2 Phase 2: Key Store Integration
"""

import base64
import logging
import os
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# Import availability flag and provider (intentional placement for conditional import)
from . import HYBRID_KEM_AVAILABLE  # noqa: E402

if HYBRID_KEM_AVAILABLE:
    from .hybrid_kem import (
        HybridEncryptedBlob,
        HybridKEMKeyPair,
        HybridKEMPrivateKey,
        HybridKEMProvider,
        HybridKEMPublicKey,
    )


@dataclass
class KEKMetadata:
    """KEK metadata for tracking and rotation."""

    version: int
    algorithm: str
    created_at: str
    provider_type: str


class KEKProvider(ABC):
    """Abstract base class for Master Key Encryption Key providers.

    KEK providers manage the master key used to encrypt/decrypt
    governance keys stored in the key store.
    """

    @property
    @abstractmethod
    def algorithm_name(self) -> str:
        """Return the algorithm name for this KEK provider."""
        ...

    @property
    @abstractmethod
    def current_version(self) -> int:
        """Return the current KEK version."""
        ...

    @abstractmethod
    def get_public_key(self, version: int = 0) -> "HybridKEMPublicKey":
        """Get KEK public key for encryption.

        Args:
            version: KEK version (0 = current)

        Returns:
            HybridKEMPublicKey for encrypting data

        Raises:
            ValueError: If version not found
            RuntimeError: If KEK not available

        """
        ...

    @abstractmethod
    def encrypt(
        self,
        plaintext: bytes,
        version: int = 0,
        *,
        allow_empty: bool = False,
    ) -> bytes:
        """Encrypt data using KEK public key.

        Args:
            plaintext: Data to encrypt
            version: KEK version to use (0 = current)
            allow_empty: If True, allow encryption of empty plaintext.
                Defaults to False for security (empty ciphertext leaks metadata).

        Returns:
            Encrypted blob bytes

        Raises:
            ValueError: If plaintext is empty and allow_empty is False
            RuntimeError: If encryption fails

        """
        ...

    @abstractmethod
    def decrypt(self, encrypted_blob: bytes, version: int = 0) -> bytes:
        """Decrypt data using KEK private key.

        Args:
            encrypted_blob: HybridEncryptedBlob bytes to decrypt
            version: KEK version used for encryption

        Returns:
            Decrypted plaintext bytes

        Raises:
            ValueError: If decryption fails
            RuntimeError: If KEK not available

        """
        ...

    @abstractmethod
    def get_metadata(self) -> KEKMetadata:
        """Get KEK metadata.

        Returns:
            KEKMetadata with version, algorithm, etc.

        """
        ...


class EnvironmentKEKProvider(KEKProvider):
    """KEK provider using environment variables.

    Suitable for development and containerized deployments where
    secrets are injected via environment.

    Environment variables:
    - AEGIS_MASTER_KEK_PUBLIC: Base64-encoded public key (1,216 bytes raw)
    - AEGIS_MASTER_KEK_PRIVATE: Base64-encoded private key (2,432 bytes raw)

    Example setup:
        $ python scripts/generate_master_kek.py > kek.env
        $ source kek.env
        $ python your_app.py

    Security Note:
        For production, use HSMKEKProvider or cloud KMS integration instead.
    """

    def __init__(
        self,
        public_key_env: str = "AEGIS_MASTER_KEK_PUBLIC",
        private_key_env: str = "AEGIS_MASTER_KEK_PRIVATE",
        version: int = 1,
    ):
        """Initialize environment-based KEK provider.

        Args:
            public_key_env: Environment variable for public key
            private_key_env: Environment variable for private key
            version: KEK version number

        """
        if not HYBRID_KEM_AVAILABLE:
            raise RuntimeError(
                "HybridKEMProvider not available. "
                "Install liboqs-python>=0.10.0 for post-quantum support.",
            )

        self._public_key_env = public_key_env
        self._private_key_env = private_key_env
        self._version = version
        self._kem_provider = HybridKEMProvider()
        self._created_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        # QG67-C2: Thread safety for encrypt/decrypt (consistency with KMS/HSM).
        self._lock = threading.Lock()

        # Load and validate keys
        self._public_key: Optional[HybridKEMPublicKey] = None
        self._private_key: Optional[HybridKEMPrivateKey] = None
        self._load_keys()

    def _load_keys(self) -> None:
        """Load KEK from environment variables."""
        public_b64 = os.environ.get(self._public_key_env)
        private_b64 = os.environ.get(self._private_key_env)

        if not public_b64:
            raise ValueError(
                f"Master KEK public key not found in environment: {self._public_key_env}",
            )
        if not private_b64:
            raise ValueError(
                f"Master KEK private key not found in environment: {self._private_key_env}",
            )

        try:
            public_bytes = base64.b64decode(public_b64, validate=True)
            self._public_key = HybridKEMPublicKey.from_bytes(public_bytes)

            private_bytes = base64.b64decode(private_b64, validate=True)
            self._private_key = HybridKEMPrivateKey.from_bytes(private_bytes)

            logger.info(
                f"Environment KEK loaded: version={self._version}, "
                f"algorithm={self.algorithm_name}",
            )
        except (ValueError, TypeError) as e:
            raise ValueError(f"Failed to load Master KEK from environment: {e}") from e

    @property
    def algorithm_name(self) -> str:
        """Return the algorithm name."""
        return "x25519+ml-kem-768+aes-256-gcm"

    @property
    def current_version(self) -> int:
        """Return the current KEK version."""
        return self._version

    def get_public_key(self, version: int = 0) -> "HybridKEMPublicKey":
        """Get KEK public key.

        Args:
            version: KEK version to retrieve. Use 0 (default) as an alias
                for the current version, or specify an explicit version number.
                Note: version=0 always maps to current, not literal version 0.

        Returns:
            HybridKEMPublicKey for the specified version

        Raises:
            ValueError: If version is not 0 (current) or exact current version
            RuntimeError: If public key is not loaded
        """
        if version not in (0, self._version):
            raise ValueError(
                f"KEK version {version} not found (current: {self._version})",
            )

        if self._public_key is None:
            raise RuntimeError("KEK public key not loaded")

        return self._public_key

    def encrypt(
        self,
        plaintext: bytes,
        version: int = 0,
        *,
        allow_empty: bool = False,
    ) -> bytes:
        """Encrypt data using KEK."""
        with self._lock:
            public_key = self.get_public_key(version)
            blob = self._kem_provider.encrypt(
                plaintext, public_key, allow_empty=allow_empty
            )
            return blob.to_bytes()

    def decrypt(self, encrypted_blob: bytes, version: int = 0) -> bytes:
        """Decrypt data using KEK."""
        with self._lock:
            if version not in (0, self._version):
                raise ValueError(f"KEK version {version} not found")

            if self._private_key is None:
                raise RuntimeError("KEK private key not loaded")

            blob = HybridEncryptedBlob.from_bytes(encrypted_blob)
            return self._kem_provider.decrypt(blob, self._private_key)

    def get_metadata(self) -> KEKMetadata:
        """Get KEK metadata."""
        return KEKMetadata(
            version=self._version,
            algorithm=self.algorithm_name,
            created_at=self._created_at,
            provider_type="environment",
        )


class InMemoryKEKProvider(KEKProvider):
    """Ephemeral KEK provider for testing.

    Generates a fresh KEK at instantiation. Keys are lost when the
    provider is garbage collected. NOT suitable for production.

    This provider is useful for:
    - Unit tests
    - Integration tests
    - Local development without environment setup
    """

    def __init__(self, version: int = 1):
        """Initialize with freshly generated KEK.

        Args:
            version: KEK version number

        """
        if not HYBRID_KEM_AVAILABLE:
            raise RuntimeError(
                "HybridKEMProvider not available. "
                "Install liboqs-python>=0.10.0 for post-quantum support.",
            )

        self._version = version
        self._kem_provider = HybridKEMProvider()
        self._created_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        # QG67-C2: Thread safety for encrypt/decrypt (consistency with KMS/HSM).
        self._lock = threading.Lock()

        # Generate ephemeral KEK
        keypair = self._kem_provider.generate_keypair()
        self._public_key = keypair.public
        self._private_key = keypair.private

        logger.debug(
            f"In-memory KEK generated: version={self._version}, "
            f"algorithm={self.algorithm_name}",
        )

    @property
    def algorithm_name(self) -> str:
        """Return the algorithm name."""
        return "x25519+ml-kem-768+aes-256-gcm"

    @property
    def current_version(self) -> int:
        """Return the current KEK version."""
        return self._version

    def get_public_key(self, version: int = 0) -> "HybridKEMPublicKey":
        """Get KEK public key."""
        if version not in (0, self._version):
            raise ValueError(
                f"KEK version {version} not found (current: {self._version})",
            )
        return self._public_key

    def encrypt(
        self,
        plaintext: bytes,
        version: int = 0,
        *,
        allow_empty: bool = False,
    ) -> bytes:
        """Encrypt data using KEK."""
        with self._lock:
            public_key = self.get_public_key(version)
            blob = self._kem_provider.encrypt(
                plaintext, public_key, allow_empty=allow_empty
            )
            return blob.to_bytes()

    def decrypt(self, encrypted_blob: bytes, version: int = 0) -> bytes:
        """Decrypt data using KEK."""
        with self._lock:
            if version not in (0, self._version):
                raise ValueError(f"KEK version {version} not found")

            blob = HybridEncryptedBlob.from_bytes(encrypted_blob)
            return self._kem_provider.decrypt(blob, self._private_key)

    def get_metadata(self) -> KEKMetadata:
        """Get KEK metadata."""
        return KEKMetadata(
            version=self._version,
            algorithm=self.algorithm_name,
            created_at=self._created_at,
            provider_type="in_memory",
        )

    def get_keypair_for_testing(self) -> "HybridKEMKeyPair":
        """Get the full keypair for test assertions.

        WARNING: Only use in tests. Never expose in production.

        Returns:
            HybridKEMKeyPair containing both keys

        """
        return HybridKEMKeyPair(public=self._public_key, private=self._private_key)


def get_kek_provider(provider_type: str = "auto") -> KEKProvider:
    """Factory function to get appropriate KEK provider.

    Args:
        provider_type: One of "auto", "kms", "hsm", "environment", "in_memory"
            - "auto": Try KMS -> HSM -> environment -> in_memory (first available)
            - "kms": AWS KMS envelope encryption (requires boto3)
            - "hsm": PKCS#11 HSM envelope encryption (requires python-pkcs11)
            - "environment": Require environment variables (plaintext keys)
            - "in_memory": Always use ephemeral (testing only)

    Returns:
        Configured KEKProvider instance

    Raises:
        RuntimeError: If provider_type is invalid or configuration fails

    """
    if provider_type == "in_memory":
        return InMemoryKEKProvider()

    if provider_type == "environment":
        return EnvironmentKEKProvider()

    if provider_type == "kms":
        from .kms_kek_provider import AWSKMSKEKProvider

        return AWSKMSKEKProvider.from_environment()

    if provider_type == "hsm":
        from .hsm_kek_provider import HSMKEKProvider

        return HSMKEKProvider.from_environment()

    if provider_type == "auto":
        # Try KMS first (production-grade)
        if os.environ.get("AEGIS_KMS_KEY_ID"):
            from .kms_kek_provider import AWSKMSKEKProvider

            return AWSKMSKEKProvider.from_environment()

        # Try HSM second (on-premises production)
        if os.environ.get("AEGIS_HSM_PKCS11_LIB"):
            from .hsm_kek_provider import HSMKEKProvider

            return HSMKEKProvider.from_environment()

        # Try environment variables (containerized deployments)
        if os.environ.get("AEGIS_MASTER_KEK_PUBLIC") and os.environ.get(
            "AEGIS_MASTER_KEK_PRIVATE",
        ):
            return EnvironmentKEKProvider()

        # Fall back to in-memory (development only)
        logger.warning(
            "Master KEK not found in environment. "
            "Using ephemeral in-memory KEK (NOT for production).",
        )
        return InMemoryKEKProvider()

    raise RuntimeError(f"Unknown KEK provider type: {provider_type}")


__all__ = [
    "EnvironmentKEKProvider",
    "InMemoryKEKProvider",
    "KEKMetadata",
    "KEKProvider",
    "get_kek_provider",
]
