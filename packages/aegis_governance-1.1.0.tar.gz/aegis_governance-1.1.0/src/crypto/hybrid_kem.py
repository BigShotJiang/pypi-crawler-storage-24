"""Hybrid Key Encapsulation Provider (X25519 + ML-KEM-768).

Implements hybrid post-quantum key encapsulation combining classical X25519
with ML-KEM-768 (Kyber Level 3) for defense-in-depth security.

Hybrid Key Format:
- X25519 public key: 32 bytes
- ML-KEM-768 public key: 1,184 bytes
- Total public key: 1,216 bytes

- X25519 private key: 32 bytes
- ML-KEM-768 private key: 2,400 bytes
- Total private key: 2,432 bytes

Encrypted Blob Format:
- Ephemeral X25519 public key: 32 bytes
- ML-KEM-768 ciphertext: 1,088 bytes
- AES-GCM nonce: 12 bytes
- AES-GCM tag: 16 bytes
- Encrypted data: variable
- Total overhead: 1,148 bytes

Security Properties:
- Combines classical (X25519) and post-quantum (ML-KEM-768) secrets via HKDF
- AES-256-GCM for authenticated encryption
- Protects against "harvest now, decrypt later" attacks
- Future-proof against quantum computing threats

References:
- FIPS 203: ML-KEM (Kyber)
- RFC 7748: X25519
- RFC 5869: HKDF
- RFC 5116: AES-GCM

GAP-Q2: Post-Quantum Key Encapsulation

"""

import logging
import os
from dataclasses import dataclass

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from . import mlkem
from .mlkem import MLKEMError

logger = logging.getLogger(__name__)

# X25519 constants
X25519_PUBLIC_KEY_SIZE = 32
X25519_PRIVATE_KEY_SIZE = 32

# Hybrid key format (X25519 || ML-KEM-768)
HYBRID_PUBLIC_KEY_SIZE = X25519_PUBLIC_KEY_SIZE + mlkem.PUBLIC_KEY_SIZE  # 1,216
HYBRID_PRIVATE_KEY_SIZE = X25519_PRIVATE_KEY_SIZE + mlkem.PRIVATE_KEY_SIZE  # 2,432

# AES-GCM constants
AES_KEY_SIZE = 32  # AES-256
AES_NONCE_SIZE = 12
AES_TAG_SIZE = 16

# Encrypted blob overhead (ephemeral + ciphertext + nonce + tag)
ENCRYPTED_OVERHEAD = (
    X25519_PUBLIC_KEY_SIZE + mlkem.CIPHERTEXT_SIZE + AES_NONCE_SIZE + AES_TAG_SIZE
)  # 1,148 bytes

# HKDF info string for key derivation
HKDF_INFO = b"AEGIS-HybridKEM-v1"


@dataclass
class HybridKEMPublicKey:
    """Container for hybrid KEM public key components."""

    classical: bytes  # X25519 public key (32 bytes)
    post_quantum: bytes  # ML-KEM-768 public key (1,184 bytes)

    def to_bytes(self) -> bytes:
        """Serialize to combined bytes (X25519 || ML-KEM)."""
        return self.classical + self.post_quantum

    @classmethod
    def from_bytes(cls, data: bytes) -> "HybridKEMPublicKey":
        """Deserialize from combined bytes."""
        if len(data) != HYBRID_PUBLIC_KEY_SIZE:
            raise ValueError(
                f"Invalid hybrid public key size: {len(data)} != {HYBRID_PUBLIC_KEY_SIZE}",
            )
        return cls(
            classical=data[:X25519_PUBLIC_KEY_SIZE],
            post_quantum=data[X25519_PUBLIC_KEY_SIZE:],
        )


@dataclass
class HybridKEMPrivateKey:
    """Container for hybrid KEM private key components."""

    classical: bytes  # X25519 private key (32 bytes)
    post_quantum: bytes  # ML-KEM-768 private key (2,400 bytes)

    def to_bytes(self) -> bytes:
        """Serialize to combined bytes (X25519 || ML-KEM)."""
        return self.classical + self.post_quantum

    @classmethod
    def from_bytes(cls, data: bytes) -> "HybridKEMPrivateKey":
        """Deserialize from combined bytes."""
        if len(data) != HYBRID_PRIVATE_KEY_SIZE:
            raise ValueError(
                f"Invalid hybrid private key size: {len(data)} != {HYBRID_PRIVATE_KEY_SIZE}",
            )
        return cls(
            classical=data[:X25519_PRIVATE_KEY_SIZE],
            post_quantum=data[X25519_PRIVATE_KEY_SIZE:],
        )


@dataclass
class HybridKEMKeyPair:
    """Container for complete hybrid KEM key pair."""

    public: HybridKEMPublicKey
    private: HybridKEMPrivateKey


@dataclass
class HybridEncryptedBlob:
    """Container for hybrid-encrypted data.

    Format when serialized:
    [ephemeral_classical (32)] [pq_ciphertext (1088)] [nonce (12)] [tag (16)] [encrypted_data (...)]

    Note on from_bytes() and trailing data:
        The from_bytes() method includes all trailing data after the fixed-length
        header fields in encrypted_data. If blobs are concatenated without a
        length prefix, trailing garbage would be included. However, this is safe
        because AES-GCM tag verification will fail if the encrypted_data has been
        tampered with or extended. For use cases requiring blob concatenation,
        callers should implement their own length-prefixed framing.

    """

    ephemeral_classical: bytes  # Ephemeral X25519 public key (32 bytes)
    pq_ciphertext: bytes  # ML-KEM-768 ciphertext (1,088 bytes)
    nonce: bytes  # AES-GCM nonce (12 bytes)
    tag: bytes  # AES-GCM authentication tag (16 bytes)
    encrypted_data: bytes  # AES-GCM encrypted payload (variable)
    algorithm: str = "x25519+ml-kem-768+aes-256-gcm"

    def to_bytes(self) -> bytes:
        """Serialize to bytes for storage."""
        return (
            self.ephemeral_classical
            + self.pq_ciphertext
            + self.nonce
            + self.tag
            + self.encrypted_data
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "HybridEncryptedBlob":
        """Deserialize from bytes."""
        min_size = ENCRYPTED_OVERHEAD
        if len(data) < min_size:
            raise ValueError(
                f"Encrypted blob too small: {len(data)} < {min_size} (minimum)",
            )

        offset = 0

        ephemeral = data[offset : offset + X25519_PUBLIC_KEY_SIZE]
        offset += X25519_PUBLIC_KEY_SIZE

        pq_ct = data[offset : offset + mlkem.CIPHERTEXT_SIZE]
        offset += mlkem.CIPHERTEXT_SIZE

        nonce = data[offset : offset + AES_NONCE_SIZE]
        offset += AES_NONCE_SIZE

        tag = data[offset : offset + AES_TAG_SIZE]
        offset += AES_TAG_SIZE

        encrypted = data[offset:]

        return cls(
            ephemeral_classical=ephemeral,
            pq_ciphertext=pq_ct,
            nonce=nonce,
            tag=tag,
            encrypted_data=encrypted,
        )


class HybridKEMProvider:
    """Hybrid X25519 + ML-KEM-768 + AES-256-GCM encryption provider.

    Provides defense-in-depth encryption by combining classical X25519
    key exchange with post-quantum ML-KEM-768 key encapsulation.

    The encryption process:
    1. Generate ephemeral X25519 keypair
    2. Perform X25519 DH with recipient's classical public key -> secret1
    3. Encapsulate to recipient's ML-KEM public key -> (ciphertext, secret2)
    4. Derive AES key from HKDF(secret1 || secret2)
    5. Encrypt payload with AES-256-GCM

    Example:
        >>> provider = HybridKEMProvider()
        >>> keypair = provider.generate_keypair()
        >>> blob = provider.encrypt(b"secret data", keypair.public)
        >>> plaintext = provider.decrypt(blob, keypair.private)
        >>> assert plaintext == b"secret data"

    """

    # Size constants
    PUBLIC_KEY_SIZE = HYBRID_PUBLIC_KEY_SIZE  # 1,216 bytes
    PRIVATE_KEY_SIZE = HYBRID_PRIVATE_KEY_SIZE  # 2,432 bytes
    CIPHERTEXT_SIZE = mlkem.CIPHERTEXT_SIZE  # 1,088 bytes
    ENCRYPTED_OVERHEAD = ENCRYPTED_OVERHEAD  # 1,148 bytes

    @property
    def algorithm_name(self) -> str:
        """Return algorithm identifier."""
        return "x25519+ml-kem-768+aes-256-gcm"

    def generate_keypair(self) -> HybridKEMKeyPair:
        """Generate hybrid KEM keypair (X25519 + ML-KEM-768).

        Returns:
            HybridKEMKeyPair containing both key components

        Raises:
            RuntimeError: If ML-KEM is not available

        """
        if not mlkem.MLKEM_AVAILABLE:
            raise RuntimeError(
                "ML-KEM not available. Install liboqs-python: pip install liboqs-python",
            )

        # Generate X25519 keypair
        x25519_private = X25519PrivateKey.generate()
        x25519_public = x25519_private.public_key()

        x25519_private_bytes = x25519_private.private_bytes_raw()
        x25519_public_bytes = x25519_public.public_bytes_raw()

        # Generate ML-KEM keypair
        mlkem_private_bytes, mlkem_public_bytes = mlkem.generate_keypair()

        keypair = HybridKEMKeyPair(
            public=HybridKEMPublicKey(
                classical=x25519_public_bytes,
                post_quantum=mlkem_public_bytes,
            ),
            private=HybridKEMPrivateKey(
                classical=x25519_private_bytes,
                post_quantum=mlkem_private_bytes,
            ),
        )

        logger.debug(
            f"Hybrid KEM keypair generated: pub={len(keypair.public.to_bytes())}B, "
            f"priv={len(keypair.private.to_bytes())}B",
        )

        return keypair

    def encrypt(
        self,
        plaintext: bytes,
        recipient_public_key: HybridKEMPublicKey,
        *,
        allow_empty: bool = False,
    ) -> HybridEncryptedBlob:
        """Encrypt data using hybrid KEM.

        Process:
        1. Generate ephemeral X25519 keypair
        2. X25519 DH with recipient's classical key -> secret1
        3. ML-KEM encapsulate to recipient's PQ key -> (ciphertext, secret2)
        4. Derive AES key from HKDF(secret1 || secret2)
        5. AES-256-GCM encrypt with random nonce

        Args:
            plaintext: Data to encrypt (any length)
            recipient_public_key: Recipient's hybrid public key
            allow_empty: If True, allow empty plaintext without error.
                Use with caution - empty encryption may indicate a bug.

        Returns:
            HybridEncryptedBlob containing all components needed for decryption

        Raises:
            RuntimeError: If ML-KEM is not available
            ValueError: If plaintext is empty and allow_empty is False

        """
        if not mlkem.MLKEM_AVAILABLE:
            raise RuntimeError("ML-KEM not available")

        if len(plaintext) == 0:
            if not allow_empty:
                raise ValueError(
                    "plaintext must not be empty. "
                    "If empty encryption is intentional, use allow_empty=True."
                )
            logger.warning(
                "encrypt() called with empty plaintext and allow_empty=True. "
                "This is cryptographically valid but unusual."
            )

        # Generate ephemeral X25519 keypair
        ephemeral_private = X25519PrivateKey.generate()
        ephemeral_public = ephemeral_private.public_key()
        ephemeral_public_bytes = ephemeral_public.public_bytes_raw()

        # X25519 key exchange with recipient's classical key
        recipient_x25519 = X25519PublicKey.from_public_bytes(
            recipient_public_key.classical,
        )
        classical_secret = ephemeral_private.exchange(recipient_x25519)

        # ML-KEM encapsulation with recipient's PQ key
        pq_ciphertext, pq_secret = mlkem.encapsulate(recipient_public_key.post_quantum)

        # Derive AES key from combined secrets
        aes_key = self._derive_key(classical_secret, pq_secret)

        # AES-256-GCM encrypt
        nonce = os.urandom(AES_NONCE_SIZE)
        aesgcm = AESGCM(aes_key)
        ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, None)

        # Split ciphertext and tag (GCM appends 16-byte tag)
        encrypted_data = ciphertext_with_tag[:-AES_TAG_SIZE]
        tag = ciphertext_with_tag[-AES_TAG_SIZE:]

        blob = HybridEncryptedBlob(
            ephemeral_classical=ephemeral_public_bytes,
            pq_ciphertext=pq_ciphertext,
            nonce=nonce,
            tag=tag,
            encrypted_data=encrypted_data,
        )

        logger.debug(
            f"Hybrid encryption: plaintext={len(plaintext)}B, "
            f"blob={len(blob.to_bytes())}B, overhead={ENCRYPTED_OVERHEAD}B",
        )

        return blob

    def decrypt(
        self,
        blob: HybridEncryptedBlob,
        recipient_private_key: HybridKEMPrivateKey,
    ) -> bytes:
        """Decrypt data using hybrid KEM.

        Process:
        1. X25519 DH with ephemeral public key -> secret1
        2. ML-KEM decapsulate with private key -> secret2
        3. Derive AES key from HKDF(secret1 || secret2)
        4. AES-256-GCM decrypt and verify tag

        Args:
            blob: HybridEncryptedBlob from encrypt()
            recipient_private_key: Recipient's hybrid private key

        Returns:
            Decrypted plaintext bytes (may be empty if encrypted with allow_empty=True)

        Raises:
            RuntimeError: If ML-KEM is not available
            ValueError: If decryption fails (invalid key, corrupted data, etc.)

        Note on empty encrypted_data:
            Empty ``encrypted_data`` is valid when the original plaintext was empty
            (encrypted with ``allow_empty=True``). AES-GCM authenticates even empty
            messages via the authentication tag, so no data corruption can occur.
            If decryption fails due to key mismatch or corruption, AES-GCM raises
            ``InvalidTag`` which is wrapped in ``ValueError`` with a descriptive message.

        """
        if not mlkem.MLKEM_AVAILABLE:
            raise RuntimeError("ML-KEM not available")

        # Note: Empty encrypted_data is valid for AES-GCM when encrypting empty
        # plaintext. The authentication tag provides integrity even for zero-length
        # ciphertext. No validation needed here - AES-GCM handles it correctly.

        try:
            # X25519 key exchange with ephemeral public key
            ephemeral_x25519 = X25519PublicKey.from_public_bytes(
                blob.ephemeral_classical,
            )
            recipient_x25519 = X25519PrivateKey.from_private_bytes(
                recipient_private_key.classical,
            )
            classical_secret = recipient_x25519.exchange(ephemeral_x25519)

            # ML-KEM decapsulation
            pq_secret = mlkem.decapsulate(
                blob.pq_ciphertext,
                recipient_private_key.post_quantum,
            )

            # Derive AES key from combined secrets
            aes_key = self._derive_key(classical_secret, pq_secret)

            # AES-256-GCM decrypt
            aesgcm = AESGCM(aes_key)
            ciphertext_with_tag = blob.encrypted_data + blob.tag
            plaintext = aesgcm.decrypt(blob.nonce, ciphertext_with_tag, None)

            logger.debug(f"Hybrid decryption succeeded: plaintext={len(plaintext)}B")

            result: bytes = plaintext
            return result

        except (ValueError, TypeError, InvalidTag, MLKEMError) as e:
            logger.warning(f"Hybrid decryption failed: {e}")
            raise ValueError(f"Decryption failed: {e}") from e

    def _derive_key(self, secret1: bytes, secret2: bytes) -> bytes:
        """Derive AES key from combined secrets using HKDF.

        Combines the classical (X25519) and post-quantum (ML-KEM) secrets
        using HKDF-SHA256 to produce a 256-bit AES key.

        Args:
            secret1: X25519 shared secret (32 bytes)
            secret2: ML-KEM shared secret (32 bytes)

        Returns:
            32-byte AES-256 key

        """
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=AES_KEY_SIZE,
            salt=None,
            info=HKDF_INFO,
        )
        derived_key: bytes = hkdf.derive(secret1 + secret2)
        return derived_key


def get_algorithm_info() -> dict[str, object]:
    """Get hybrid KEM algorithm information.

    Returns:
        Dictionary with algorithm properties

    """
    return {
        "name": "x25519+ml-kem-768+aes-256-gcm",
        "classical_kem": "X25519",
        "post_quantum_kem": "ML-KEM-768",
        "symmetric_cipher": "AES-256-GCM",
        "key_derivation": "HKDF-SHA256",
        "public_key_size": HYBRID_PUBLIC_KEY_SIZE,
        "private_key_size": HYBRID_PRIVATE_KEY_SIZE,
        "ciphertext_overhead": ENCRYPTED_OVERHEAD,
        "security_level": "NIST Level 3 (192-bit post-quantum)",
        "standard": "FIPS 203 (ML-KEM) + RFC 7748 (X25519)",
        "available": mlkem.MLKEM_AVAILABLE,
    }
