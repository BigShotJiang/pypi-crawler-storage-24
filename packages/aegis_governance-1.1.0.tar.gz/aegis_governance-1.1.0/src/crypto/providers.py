"""Signature Provider Interface.

Defines the SignatureProvider protocol for pluggable signature algorithms.
This allows the override workflow to use different signature schemes:
- BIP322Provider: BIP-340 Schnorr on secp256k1 (recommended)
- Ed25519Provider: Ed25519 on Curve25519 (deprecated)
- HybridPQProvider: Post-quantum hybrid (future, GAP-Q1)

Design Pattern: Strategy Pattern
- Signature algorithm is selected at runtime via provider injection
- All providers implement the same interface
- Easy to add new signature schemes without changing workflow logic
"""

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class SignatureResult:
    """Result of a signing operation.

    Attributes:
        signature: Raw signature bytes
        public_key: Public key used for verification
        algorithm: Algorithm identifier (e.g., 'bip322-simple', 'ed25519')
        message_hash: Hash that was signed

    """

    signature: bytes
    public_key: bytes
    algorithm: str
    message_hash: bytes

    def to_base64(self) -> str:
        """Return base64-encoded signature."""
        import base64

        return base64.b64encode(self.signature).decode("ascii")


@runtime_checkable
class SignatureProvider(Protocol):
    """Protocol for signature providers.

    All signature providers must implement these methods to be used
    with the DualSignatureValidator.

    Security Requirements:
    - generate_keypair(): Must use cryptographically secure random source
    - sign(): May be non-deterministic (BIP-340 and ML-DSA use randomized
      nonces for hedged signing). Callers MUST NOT assume same input
      produces same output.
    - verify(): Must be constant-time to prevent timing attacks
    """

    @property
    def algorithm_name(self) -> str:
        """Return algorithm identifier.

        Examples: 'bip322-simple', 'ed25519', 'ml-dsa-65'
        """
        ...

    @property
    def signature_size(self) -> int:
        """Return signature size in bytes."""
        ...

    @property
    def public_key_size(self) -> int:
        """Return public key size in bytes."""
        ...

    def generate_keypair(self) -> tuple[bytes, bytes]:
        """Generate a new keypair.

        Returns:
            (private_key, public_key) as raw bytes

        """
        ...

    def create_message_hash(
        self,
        proposal_id: str,
        justification: str,
        failed_gates: list[str],
    ) -> bytes:
        """Create canonical message hash for signing.

        The hash algorithm depends on the provider:
        - BIP322: BIP-340 tagged hash
        - Ed25519: SHA-256 of JSON

        Args:
            proposal_id: Proposal identifier
            justification: Override justification
            failed_gates: List of failed gate names

        Returns:
            Message hash as bytes

        """
        ...

    def sign(self, message_hash: bytes, private_key: bytes) -> bytes:
        """Sign a message hash.

        Args:
            message_hash: Hash to sign (output of create_message_hash)
            private_key: Private key bytes

        Returns:
            Signature bytes

        """
        ...

    def verify(
        self,
        signature: bytes,
        message_hash: bytes,
        public_key: bytes,
    ) -> bool:
        """Verify a signature.

        Args:
            signature: Signature bytes
            message_hash: Hash that was signed
            public_key: Public key bytes

        Returns:
            True if signature is valid

        """
        ...


def is_valid_provider(provider: object) -> bool:
    """Check if an object implements the SignatureProvider protocol.

    Args:
        provider: Object to check

    Returns:
        True if provider implements all required methods

    """
    return isinstance(provider, SignatureProvider)
