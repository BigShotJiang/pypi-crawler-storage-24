"""ML-KEM (Kyber) Post-Quantum Key Encapsulation Wrapper.

Provides a thin wrapper around liboqs-python for ML-KEM-768 (Kyber Level 3)
post-quantum key encapsulation as standardized in FIPS 203.

ML-KEM-768 Properties:
- Security level: NIST Level 3 (192-bit post-quantum)
- Public key size: 1,184 bytes
- Private key size: 2,400 bytes
- Ciphertext size: 1,088 bytes
- Shared secret size: 32 bytes

References:
- FIPS 203: https://csrc.nist.gov/pubs/fips/203/final
- liboqs: https://openquantumsafe.org/liboqs/

GAP-Q2: Post-Quantum Key Encapsulation

"""

import logging
from typing import Any

logger = logging.getLogger(__name__)

# ML-KEM-768 (Kyber Level 3) constants per FIPS 203
ALGORITHM_NAME = "ML-KEM-768"
PUBLIC_KEY_SIZE = 1184
PRIVATE_KEY_SIZE = 2400
CIPHERTEXT_SIZE = 1088
SHARED_SECRET_SIZE = 32

# liboqs algorithm identifier (use FIPS 203 name, not legacy Kyber768)
LIBOQS_ALGORITHM = "ML-KEM-768"

# Module availability flag - typed as Any to allow dynamic attribute access
_oqs: Any = None
MLKEM_AVAILABLE = False

try:
    import oqs

    _oqs = oqs
    MLKEM_AVAILABLE = True
    logger.debug("liboqs-python loaded successfully for ML-KEM support")
except ImportError:
    logger.warning(
        "liboqs-python not available. Install with: pip install liboqs-python",
    )
except (SystemExit, RuntimeError, OSError) as e:
    # liboqs-python may raise SystemExit if native liboqs library is not installed
    # or RuntimeError/OSError if shared library loading fails
    logger.warning(
        f"liboqs native library not available ({type(e).__name__}). "
        "Install liboqs: brew install liboqs (macOS) or build from source.",
    )


class MLKEMError(Exception):
    """Exception raised for ML-KEM cryptographic errors."""


def generate_keypair() -> tuple[bytes, bytes]:
    """Generate ML-KEM-768 keypair.

    Returns:
        (private_key, public_key) as bytes
        - private_key: 2,400 bytes
        - public_key: 1,184 bytes

    Raises:
        MLKEMError: If liboqs is not available or key generation fails

    """
    if not MLKEM_AVAILABLE or _oqs is None:
        raise MLKEMError("liboqs-python is not installed")

    try:
        kem = _oqs.KeyEncapsulation(LIBOQS_ALGORITHM)
        public_key = kem.generate_keypair()
        private_key = kem.export_secret_key()

        if len(public_key) != PUBLIC_KEY_SIZE:
            raise MLKEMError(
                f"Unexpected public key size: {len(public_key)} != {PUBLIC_KEY_SIZE}",
            )

        if len(private_key) != PRIVATE_KEY_SIZE:
            raise MLKEMError(
                f"Unexpected private key size: {len(private_key)} != {PRIVATE_KEY_SIZE}",
            )

        logger.debug(
            f"ML-KEM-768 keypair generated: pub={len(public_key)}B, priv={len(private_key)}B",
        )
        return private_key, public_key

    except (ValueError, TypeError, RuntimeError, OSError) as e:
        raise MLKEMError(f"Key generation failed: {e}") from e


def encapsulate(public_key: bytes) -> tuple[bytes, bytes]:
    """Encapsulate a shared secret using recipient's public key.

    This generates a random shared secret and encapsulates it so that
    only the holder of the corresponding private key can recover it.

    Args:
        public_key: 1,184-byte ML-KEM public key

    Returns:
        (ciphertext, shared_secret) as bytes
        - ciphertext: 1,088 bytes
        - shared_secret: 32 bytes

    Raises:
        MLKEMError: If encapsulation fails or inputs are invalid

    """
    if not MLKEM_AVAILABLE or _oqs is None:
        raise MLKEMError("liboqs-python is not installed")

    if len(public_key) != PUBLIC_KEY_SIZE:
        raise MLKEMError(
            f"Invalid public key size: {len(public_key)} != {PUBLIC_KEY_SIZE}",
        )

    try:
        kem = _oqs.KeyEncapsulation(LIBOQS_ALGORITHM)
        ciphertext, shared_secret = kem.encap_secret(public_key)

        if len(ciphertext) != CIPHERTEXT_SIZE:
            raise MLKEMError(
                f"Unexpected ciphertext size: {len(ciphertext)} != {CIPHERTEXT_SIZE}",
            )

        if len(shared_secret) != SHARED_SECRET_SIZE:
            raise MLKEMError(
                f"Unexpected shared secret size: {len(shared_secret)} != {SHARED_SECRET_SIZE}",
            )

        logger.debug(
            f"ML-KEM-768 encapsulation: ct={len(ciphertext)}B, ss={len(shared_secret)}B",
        )
        return ciphertext, shared_secret

    except (ValueError, TypeError, RuntimeError, OSError) as e:
        raise MLKEMError(f"Encapsulation failed: {e}") from e


def decapsulate(ciphertext: bytes, private_key: bytes) -> bytes:
    """Decapsulate to recover shared secret.

    Args:
        ciphertext: 1,088-byte ML-KEM ciphertext
        private_key: 2,400-byte ML-KEM private key

    Returns:
        32-byte shared secret

    Raises:
        MLKEMError: If decapsulation fails or inputs are invalid

    """
    if not MLKEM_AVAILABLE or _oqs is None:
        raise MLKEMError("liboqs-python is not installed")

    if len(ciphertext) != CIPHERTEXT_SIZE:
        raise MLKEMError(
            f"Invalid ciphertext size: {len(ciphertext)} != {CIPHERTEXT_SIZE}",
        )

    if len(private_key) != PRIVATE_KEY_SIZE:
        raise MLKEMError(
            f"Invalid private key size: {len(private_key)} != {PRIVATE_KEY_SIZE}",
        )

    try:
        kem = _oqs.KeyEncapsulation(LIBOQS_ALGORITHM, private_key)
        shared_secret = kem.decap_secret(ciphertext)

        if len(shared_secret) != SHARED_SECRET_SIZE:
            raise MLKEMError(
                f"Unexpected shared secret size: {len(shared_secret)} != {SHARED_SECRET_SIZE}",
            )

        logger.debug(f"ML-KEM-768 decapsulation: ss={len(shared_secret)}B")
        result: bytes = shared_secret
        return result

    except (ValueError, TypeError, RuntimeError, OSError) as e:
        raise MLKEMError(f"Decapsulation failed: {e}") from e


def get_algorithm_info() -> dict[str, object]:
    """Get ML-KEM algorithm information.

    Returns:
        Dictionary with algorithm properties

    """
    return {
        "name": ALGORITHM_NAME,
        "liboqs_name": LIBOQS_ALGORITHM,
        "public_key_size": PUBLIC_KEY_SIZE,
        "private_key_size": PRIVATE_KEY_SIZE,
        "ciphertext_size": CIPHERTEXT_SIZE,
        "shared_secret_size": SHARED_SECRET_SIZE,
        "security_level": "NIST Level 3 (192-bit post-quantum)",
        "standard": "FIPS 203",
        "available": MLKEM_AVAILABLE,
    }
