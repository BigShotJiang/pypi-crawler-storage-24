"""Calibrator Actor — statistical threshold tuning for AEGIS gates.

Maps to CALIBRATOR actor type in schema/rbac-definitions.yaml
with recalibrate and analyze_drift capabilities.

Workflow: aegis_recalibration (collect_telemetry -> propose -> review -> deploy/reject)
"""

import math
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

from engine.bayesian import BayesianPosterior
from engine.drift import DriftMonitor
from engine.gates import GateEvaluator

from .base import ActionResult, Actor, ActorRole

if TYPE_CHECKING:
    from telemetry.emitter import TelemetryEmitter

DEFAULT_HISTORY_LIMIT: int = 10000


class CalibrationStatus(str, Enum):
    """Status of a calibration proposal."""

    PROPOSED = "proposed"
    APPROVED = "approved"
    REJECTED = "rejected"
    APPLIED = "applied"


@dataclass
class CalibrationProposal:
    """A proposal to change a threshold parameter.

    Mirrors CALIBRATION_REVIEW handoff context from workflow-definitions.yaml:
    proposed_thresholds, justification, data_window.
    """

    proposal_id: str
    parameter_name: str
    current_value: float
    proposed_value: float
    justification: str
    data_window: int
    statistical_method: str
    status: CalibrationStatus = CalibrationStatus.PROPOSED
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    reviewed_by: Optional[str] = None
    review_reason: Optional[str] = None

    def __post_init__(self) -> None:
        """Validate calibration proposal fields."""
        if not isinstance(self.data_window, int) or isinstance(self.data_window, bool):
            raise TypeError(
                f"data_window must be int, got {type(self.data_window).__name__}"
            )
        if self.data_window < 0:
            raise ValueError(
                f"data_window must be non-negative, got {self.data_window}"
            )
        if isinstance(self.current_value, bool):
            raise TypeError("current_value must be numeric, got bool")
        if not math.isfinite(self.current_value):
            raise ValueError(f"current_value must be finite, got {self.current_value}")
        if isinstance(self.proposed_value, bool):
            raise TypeError("proposed_value must be numeric, got bool")
        if not math.isfinite(self.proposed_value):
            raise ValueError(
                f"proposed_value must be finite, got {self.proposed_value}"
            )

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return (
            f"CalibrationProposal(id={self.proposal_id!r}, "
            f"param={self.parameter_name!r}, "
            f"{self.current_value}->{self.proposed_value}, "
            f"status={self.status.value})"
        )


class Calibrator(Actor):
    """Calibrator actor — statistical threshold tuning.

    Responsibilities:
    - Propose drift threshold recalibration from historical KL values
    - Propose Bayesian prior updates from empirical observations
    - Propose gate parameter changes with statistical evidence
    - Track approval workflow (propose -> approve/reject -> apply)
    - Emit telemetry events for calibration lifecycle

    All threshold changes are approval-gated: proposals must be APPROVED
    before they can be applied. This enforces the RBAC constraint
    ``requires_approval_for_deploy`` at the actor level.
    """

    _RECOGNIZED_PARAMETERS: frozenset[str] = frozenset(
        {
            # GateEvaluator
            "epsilon_R",
            "epsilon_P",
            "risk_trigger_factor",
            "profit_trigger_factor",
            "trigger_confidence_prob",
            "novelty_N0",
            "novelty_k",
            "novelty_threshold",
            "complexity_floor",
            "quality_min_score",
            "utility_threshold",
            # DriftMonitor
            "tau_warning",
            "tau_critical",
            # BayesianPosterior
            "prior_mean",
            "prior_std",
            "likelihood_std",
        }
    )

    def __init__(
        self,
        actor_id: str,
        name: str,
        additional_roles: Optional[set[ActorRole]] = None,
        history_limit: int = DEFAULT_HISTORY_LIMIT,
    ):
        """Initialize calibrator actor.

        Args:
            actor_id: Unique identifier
            name: Display name
            additional_roles: Additional roles beyond calibrator
            history_limit: Maximum history entries to retain (prevents memory growth)

        """
        roles: set[ActorRole] = {ActorRole.CALIBRATOR}
        if additional_roles:
            roles.update(additional_roles)

        super().__init__(
            actor_id=actor_id,
            name=name,
            roles=roles,
        )

        self.proposals: dict[str, CalibrationProposal] = {}
        self.proposal_history: deque[str] = deque(maxlen=history_limit)
        self._history_limit = history_limit
        self._lock = threading.Lock()

    def _evict_old_proposals(self) -> None:
        """Remove proposals not in the bounded history deque."""
        if len(self.proposals) > self._history_limit:
            live_ids = set(self.proposal_history)
            for pid in list(self.proposals):
                if pid not in live_ids:
                    del self.proposals[pid]

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return (
            f"Calibrator(id={self.actor_id!r}, name={self.name!r}, "
            f"proposals={len(self.proposals)})"
        )

    def get_primary_role(self) -> ActorRole:
        """Get the primary role for this actor type."""
        return ActorRole.CALIBRATOR

    def get_allowed_actions(self) -> list[str]:
        """Get list of actions this actor can perform."""
        return [
            "propose_drift_calibration",
            "propose_prior_update",
            "propose_gate_threshold",
            "approve_calibration",
            "reject_calibration",
            "apply_calibration",
            "get_proposal_status",
            "list_proposals",
        ]

    # ------------------------------------------------------------------
    # Proposal creation
    # ------------------------------------------------------------------

    def propose_drift_calibration(
        self,
        proposal_id: str,
        drift_detector: DriftMonitor,
        historical_kl_values: list[float],
        warning_percentile: float = 90,
        critical_percentile: float = 99,
        justification: str = "",
        telemetry_emitter: Optional["TelemetryEmitter"] = None,
    ) -> ActionResult:
        """Propose new drift thresholds from historical KL divergence values.

        Delegates to ``DriftMonitor.calibrate_thresholds()`` for P90/P99
        percentile computation. Creates proposals for tau_warning and
        tau_critical if they differ from current values.

        Args:
            proposal_id: Unique identifier for this calibration batch
            drift_detector: DriftMonitor whose thresholds to recalibrate
            historical_kl_values: Historical KL divergence values
            warning_percentile: Percentile for warning threshold
            critical_percentile: Percentile for critical threshold
            justification: Reason for recalibration
            telemetry_emitter: Optional emitter for CALIBRATION_STARTED event

        Returns:
            ActionResult with proposed thresholds

        """
        if not self.capabilities.can_configure:
            return self.record_action(
                "propose_drift_calibration",
                success=False,
                error="Actor does not have configure capability",
            )

        with self._lock:
            if proposal_id in self.proposals:
                return self.record_action(
                    "propose_drift_calibration",
                    success=False,
                    error=f"Proposal ID {proposal_id!r} already exists",
                )

        new_warning, new_critical = drift_detector.calibrate_thresholds(
            historical_kl_values,
            warning_percentile=warning_percentile,
            critical_percentile=critical_percentile,
        )

        proposals_created: list[dict[str, Any]] = []
        sample_count = len([v for v in historical_kl_values if math.isfinite(v)])

        with self._lock:
            # Guard re-check after releasing lock for calibrate_thresholds
            warn_id = f"{proposal_id}_tau_warning"
            crit_id = f"{proposal_id}_tau_critical"
            for check_id in (proposal_id, warn_id, crit_id):
                if check_id in self.proposals:
                    return self.record_action(
                        "propose_drift_calibration",
                        success=False,
                        error=f"Proposal ID {check_id!r} already exists",
                    )

            if new_warning != drift_detector.tau_warning:
                self.proposals[warn_id] = CalibrationProposal(
                    proposal_id=warn_id,
                    parameter_name="tau_warning",
                    current_value=drift_detector.tau_warning,
                    proposed_value=new_warning,
                    justification=justification,
                    data_window=sample_count,
                    statistical_method=f"percentile_p{int(warning_percentile)}",
                )
                self.proposal_history.append(warn_id)
                proposals_created.append(
                    {
                        "proposal_id": warn_id,
                        "parameter": "tau_warning",
                        "current": drift_detector.tau_warning,
                        "proposed": new_warning,
                    }
                )

            if new_critical != drift_detector.tau_critical:
                self.proposals[crit_id] = CalibrationProposal(
                    proposal_id=crit_id,
                    parameter_name="tau_critical",
                    current_value=drift_detector.tau_critical,
                    proposed_value=new_critical,
                    justification=justification,
                    data_window=sample_count,
                    statistical_method=f"percentile_p{int(critical_percentile)}",
                )
                self.proposal_history.append(crit_id)
                proposals_created.append(
                    {
                        "proposal_id": crit_id,
                        "parameter": "tau_critical",
                        "current": drift_detector.tau_critical,
                        "proposed": new_critical,
                    }
                )
            self._evict_old_proposals()

        if telemetry_emitter is not None:
            self._emit(
                telemetry_emitter,
                "CALIBRATION_STARTED",
                {
                    "batch_id": proposal_id,
                    "method": "drift_calibration",
                    "sample_count": sample_count,
                    "proposals": len(proposals_created),
                },
            )

        return self.record_action(
            "propose_drift_calibration",
            success=True,
            result_data={
                "batch_id": proposal_id,
                "proposals": proposals_created,
                "new_tau_warning": new_warning,
                "new_tau_critical": new_critical,
            },
        )

    def propose_prior_update(
        self,
        proposal_id: str,
        bayesian: BayesianPosterior,
        observations: list[float],
        justification: str = "",
        telemetry_emitter: Optional["TelemetryEmitter"] = None,
    ) -> ActionResult:
        """Propose updated Bayesian prior from empirical observations.

        Delegates to ``BayesianPosterior.update_prior()`` for weighted
        mean/std computation. Creates proposals for prior_mean and
        prior_std if they differ from current values.

        Args:
            proposal_id: Unique identifier for this calibration batch
            bayesian: BayesianPosterior whose prior to update
            observations: Historical delta values
            justification: Reason for update
            telemetry_emitter: Optional emitter for CALIBRATION_STARTED event

        Returns:
            ActionResult with proposed prior parameters

        """
        if not self.capabilities.can_configure:
            return self.record_action(
                "propose_prior_update",
                success=False,
                error="Actor does not have configure capability",
            )

        with self._lock:
            if proposal_id in self.proposals:
                return self.record_action(
                    "propose_prior_update",
                    success=False,
                    error=f"Proposal ID {proposal_id!r} already exists",
                )

        new_mean, new_std = bayesian.update_prior(observations)

        proposals_created: list[dict[str, Any]] = []
        sample_count = len([v for v in observations if math.isfinite(v)])

        with self._lock:
            mean_id = f"{proposal_id}_prior_mean"
            std_id = f"{proposal_id}_prior_std"
            for check_id in (proposal_id, mean_id, std_id):
                if check_id in self.proposals:
                    return self.record_action(
                        "propose_prior_update",
                        success=False,
                        error=f"Proposal ID {check_id!r} already exists",
                    )

            if new_mean != bayesian.prior_mean:
                self.proposals[mean_id] = CalibrationProposal(
                    proposal_id=mean_id,
                    parameter_name="prior_mean",
                    current_value=bayesian.prior_mean,
                    proposed_value=new_mean,
                    justification=justification,
                    data_window=sample_count,
                    statistical_method="bayesian_update",
                )
                self.proposal_history.append(mean_id)
                proposals_created.append(
                    {
                        "proposal_id": mean_id,
                        "parameter": "prior_mean",
                        "current": bayesian.prior_mean,
                        "proposed": new_mean,
                    }
                )

            if new_std != bayesian.prior_std:
                self.proposals[std_id] = CalibrationProposal(
                    proposal_id=std_id,
                    parameter_name="prior_std",
                    current_value=bayesian.prior_std,
                    proposed_value=new_std,
                    justification=justification,
                    data_window=sample_count,
                    statistical_method="bayesian_update",
                )
                self.proposal_history.append(std_id)
                proposals_created.append(
                    {
                        "proposal_id": std_id,
                        "parameter": "prior_std",
                        "current": bayesian.prior_std,
                        "proposed": new_std,
                    }
                )
            self._evict_old_proposals()

        if telemetry_emitter is not None:
            self._emit(
                telemetry_emitter,
                "CALIBRATION_STARTED",
                {
                    "batch_id": proposal_id,
                    "method": "prior_update",
                    "sample_count": sample_count,
                    "proposals": len(proposals_created),
                },
            )

        return self.record_action(
            "propose_prior_update",
            success=True,
            result_data={
                "batch_id": proposal_id,
                "proposals": proposals_created,
                "new_prior_mean": new_mean,
                "new_prior_std": new_std,
            },
        )

    def propose_gate_threshold(
        self,
        proposal_id: str,
        parameter_name: str,
        current_value: float,
        proposed_value: float,
        justification: str,
        data_window: int,
        statistical_method: str,
    ) -> ActionResult:
        """Propose a gate parameter change with statistical evidence.

        Args:
            proposal_id: Unique proposal identifier
            parameter_name: Parameter to change (must be in _RECOGNIZED_PARAMETERS)
            current_value: Current parameter value
            proposed_value: Proposed new value
            justification: Reason for change
            data_window: Number of samples in the analysis
            statistical_method: Statistical method used (e.g., "z_test", "bootstrap")

        Returns:
            ActionResult with proposal details

        """
        if not self.capabilities.can_configure:
            return self.record_action(
                "propose_gate_threshold",
                success=False,
                error="Actor does not have configure capability",
            )

        if parameter_name not in self._RECOGNIZED_PARAMETERS:
            return self.record_action(
                "propose_gate_threshold",
                success=False,
                error=(
                    f"Unrecognized parameter: {parameter_name!r}. "
                    f"Recognized parameters: {sorted(self._RECOGNIZED_PARAMETERS)}"
                ),
            )

        with self._lock:
            if proposal_id in self.proposals:
                return self.record_action(
                    "propose_gate_threshold",
                    success=False,
                    error=f"Proposal ID {proposal_id!r} already exists",
                )

            self.proposals[proposal_id] = CalibrationProposal(
                proposal_id=proposal_id,
                parameter_name=parameter_name,
                current_value=current_value,
                proposed_value=proposed_value,
                justification=justification,
                data_window=data_window,
                statistical_method=statistical_method,
            )
            self.proposal_history.append(proposal_id)
            self._evict_old_proposals()

        return self.record_action(
            "propose_gate_threshold",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "parameter": parameter_name,
                "current": current_value,
                "proposed": proposed_value,
                "method": statistical_method,
            },
        )

    # ------------------------------------------------------------------
    # Approval workflow
    # ------------------------------------------------------------------

    def approve_calibration(
        self,
        proposal_id: str,
        reviewer_id: str,
        reason: str = "",
    ) -> ActionResult:
        """Approve a calibration proposal.

        Args:
            proposal_id: Proposal to approve
            reviewer_id: ID of the approving reviewer
            reason: Optional approval reason

        Returns:
            ActionResult with approval status

        """
        with self._lock:
            if proposal_id not in self.proposals:
                return self.record_action(
                    "approve_calibration",
                    success=False,
                    error=f"Proposal {proposal_id!r} not found",
                )

            proposal = self.proposals[proposal_id]
            if proposal.status != CalibrationStatus.PROPOSED:
                return self.record_action(
                    "approve_calibration",
                    success=False,
                    error=(
                        f"Proposal {proposal_id!r} is {proposal.status.value}, "
                        "expected proposed"
                    ),
                )

            proposal.status = CalibrationStatus.APPROVED
            proposal.reviewed_by = reviewer_id
            proposal.review_reason = reason

        return self.record_action(
            "approve_calibration",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "status": CalibrationStatus.APPROVED.value,
                "reviewer": reviewer_id,
            },
        )

    def reject_calibration(
        self,
        proposal_id: str,
        reviewer_id: str,
        reason: str,
    ) -> ActionResult:
        """Reject a calibration proposal.

        Args:
            proposal_id: Proposal to reject
            reviewer_id: ID of the rejecting reviewer
            reason: Rejection reason (required)

        Returns:
            ActionResult with rejection status

        """
        with self._lock:
            if proposal_id not in self.proposals:
                return self.record_action(
                    "reject_calibration",
                    success=False,
                    error=f"Proposal {proposal_id!r} not found",
                )

            proposal = self.proposals[proposal_id]
            if proposal.status != CalibrationStatus.PROPOSED:
                return self.record_action(
                    "reject_calibration",
                    success=False,
                    error=(
                        f"Proposal {proposal_id!r} is {proposal.status.value}, "
                        "expected proposed"
                    ),
                )

            proposal.status = CalibrationStatus.REJECTED
            proposal.reviewed_by = reviewer_id
            proposal.review_reason = reason

        return self.record_action(
            "reject_calibration",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "status": CalibrationStatus.REJECTED.value,
                "reviewer": reviewer_id,
                "reason": reason,
            },
        )

    # ------------------------------------------------------------------
    # Application
    # ------------------------------------------------------------------

    def apply_calibration(
        self,
        proposal_id: str,
        drift_detector: Optional[DriftMonitor] = None,
        gate_evaluator: Optional[GateEvaluator] = None,
        bayesian: Optional[BayesianPosterior] = None,
        telemetry_emitter: Optional["TelemetryEmitter"] = None,
    ) -> ActionResult:
        """Apply an approved calibration proposal.

        Routes by parameter_name:
        - tau_warning/tau_critical -> drift_detector.update_thresholds()
        - GateEvaluator params -> setattr(gate_evaluator, param, value)
        - prior_mean/prior_std -> returns new params (BayesianPosterior is immutable)

        Args:
            proposal_id: Approved proposal to apply
            drift_detector: Required for tau_warning/tau_critical
            gate_evaluator: Required for GateEvaluator parameters
            bayesian: Required for prior_mean/prior_std (advisory — returns new values)
            telemetry_emitter: Optional emitter for THRESHOLD_UPDATED event

        Returns:
            ActionResult with application details

        """
        if not self.capabilities.can_configure:
            return self.record_action(
                "apply_calibration",
                success=False,
                error="Actor does not have configure capability",
            )

        with self._lock:
            if proposal_id not in self.proposals:
                return self.record_action(
                    "apply_calibration",
                    success=False,
                    error=f"Proposal {proposal_id!r} not found",
                )

            proposal = self.proposals[proposal_id]
            if proposal.status != CalibrationStatus.APPROVED:
                return self.record_action(
                    "apply_calibration",
                    success=False,
                    error=(
                        f"Proposal {proposal_id!r} is {proposal.status.value}, "
                        "expected approved — proposals must be approved before application"
                    ),
                )

            # U-3: Transition to APPLIED under lock to prevent concurrent
            # double-apply (two threads seeing APPROVED simultaneously).
            proposal.status = CalibrationStatus.APPLIED

            # Snapshot proposal data under lock
            param = proposal.parameter_name
            new_value = proposal.proposed_value
            old_value = proposal.current_value

        # Apply outside lock (engine methods may do their own locking).
        # U-1: Wrap in try/except to return ActionResult on failure
        # instead of propagating raw ValueError.
        result_data: dict[str, Any] = {
            "proposal_id": proposal_id,
            "parameter": param,
            "old_value": old_value,
            "new_value": new_value,
        }

        _DRIFT_PARAMS = frozenset({"tau_warning", "tau_critical"})
        _PRIOR_PARAMS = frozenset({"prior_mean", "prior_std", "likelihood_std"})
        _GATE_PARAMS = self._RECOGNIZED_PARAMETERS - _DRIFT_PARAMS - _PRIOR_PARAMS

        try:
            if param in _DRIFT_PARAMS:
                if drift_detector is None:
                    # Revert status since we couldn't apply
                    with self._lock:
                        proposal.status = CalibrationStatus.APPROVED
                    return self.record_action(
                        "apply_calibration",
                        success=False,
                        error="drift_detector required for tau_warning/tau_critical",
                    )
                if param == "tau_warning":
                    drift_detector.update_thresholds(
                        tau_warning=new_value,
                        tau_critical=drift_detector.tau_critical,
                    )
                else:
                    drift_detector.update_thresholds(
                        tau_warning=drift_detector.tau_warning,
                        tau_critical=new_value,
                    )
                result_data["target"] = "drift_detector"

            elif param in _PRIOR_PARAMS:
                result_data["target"] = "bayesian_prior"
                result_data["note"] = (
                    "BayesianPosterior is immutable"
                    " — new values returned for caller to use"
                )

            elif param in _GATE_PARAMS:
                if gate_evaluator is None:
                    with self._lock:
                        proposal.status = CalibrationStatus.APPROVED
                    return self.record_action(
                        "apply_calibration",
                        success=False,
                        error=f"gate_evaluator required for {param}",
                    )
                # U-2: Validate gate params that have constructor constraints
                _validate_gate_param(param, new_value)
                setattr(gate_evaluator, param, new_value)
                result_data["target"] = "gate_evaluator"

        except (ValueError, TypeError) as exc:
            # Revert status — apply failed
            with self._lock:
                proposal.status = CalibrationStatus.APPROVED
            return self.record_action(
                "apply_calibration",
                success=False,
                error=f"Apply failed for {param}: {exc}",
            )

        if telemetry_emitter is not None:
            self._emit(
                telemetry_emitter,
                "THRESHOLD_UPDATED",
                {
                    "proposal_id": proposal_id,
                    "parameter": param,
                    "old_value": old_value,
                    "new_value": new_value,
                },
            )

        return self.record_action(
            "apply_calibration",
            success=True,
            result_data=result_data,
        )

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_proposal_status(self, proposal_id: str) -> ActionResult:
        """Get the status of a calibration proposal.

        Args:
            proposal_id: Proposal to query

        Returns:
            ActionResult with proposal details

        """
        with self._lock:
            if proposal_id not in self.proposals:
                return self.record_action(
                    "get_proposal_status",
                    success=False,
                    error=f"Proposal {proposal_id!r} not found",
                )

            p = self.proposals[proposal_id]
            return self.record_action(
                "get_proposal_status",
                success=True,
                result_data={
                    "proposal_id": p.proposal_id,
                    "parameter": p.parameter_name,
                    "current_value": p.current_value,
                    "proposed_value": p.proposed_value,
                    "status": p.status.value,
                    "justification": p.justification,
                    "data_window": p.data_window,
                    "statistical_method": p.statistical_method,
                    "reviewed_by": p.reviewed_by,
                    "review_reason": p.review_reason,
                },
            )

    def list_proposals(
        self,
        status_filter: Optional[CalibrationStatus] = None,
    ) -> ActionResult:
        """List calibration proposals, optionally filtered by status.

        Args:
            status_filter: Optional status to filter by

        Returns:
            ActionResult with list of proposal summaries

        """
        # BH41-L1: Snapshot all status values under the lock.
        # CalibrationProposal is a mutable dataclass; reading p.status outside
        # the lock races with approve/reject/apply which mutate status under the
        # lock. Capture status at snapshot time to eliminate the data race.
        proposals_snapshot: list[dict[str, Any]] = []
        with self._lock:
            proposals_snapshot = [
                {
                    "proposal_id": p.proposal_id,
                    "parameter": p.parameter_name,
                    "current_value": p.current_value,
                    "proposed_value": p.proposed_value,
                    "status": p.status,  # enum value captured under lock
                }
                for p in self.proposals.values()
            ]

        if status_filter is not None:
            proposals_snapshot = [
                s for s in proposals_snapshot if s["status"] == status_filter
            ]

        summaries = [{**s, "status": s["status"].value} for s in proposals_snapshot]

        return self.record_action(
            "list_proposals",
            success=True,
            result_data={
                "count": len(summaries),
                "proposals": summaries,
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _emit(
        emitter: "TelemetryEmitter",
        event_name: str,
        payload: dict[str, Any],
    ) -> None:
        """Emit a telemetry event by name, importing EventType lazily."""
        from telemetry.emitter import EventType

        # U-5: Use getattr directly — returns the EventType member.
        event_type = getattr(EventType, event_name)
        emitter.emit(event_type=event_type, payload=payload)


# Module-level helper (not a method — avoids exposing validation internals).
# Gate parameters that have constructor constraints in GateEvaluator.
_POSITIVE_GATE_PARAMS: frozenset[str] = frozenset(
    {"epsilon_R", "epsilon_P", "novelty_k"}
)
_NONZERO_GATE_PARAMS: frozenset[str] = frozenset(
    {"risk_trigger_factor", "profit_trigger_factor"}
)
_NONNEGATIVE_GATE_PARAMS: frozenset[str] = frozenset(
    {
        "complexity_floor",
        "quality_min_score",
        "novelty_threshold",
        "novelty_N0",
    }
)


def _validate_gate_param(param: str, value: float) -> None:
    """Validate a gate parameter value matches GateEvaluator constraints.

    Raises:
        ValueError: If the value violates the parameter's constraint.

    """
    if isinstance(value, bool):
        raise TypeError(f"{param} must be numeric, got bool")
    if not math.isfinite(value):
        raise ValueError(f"{param} must be a finite number, got {value}")
    if param in _POSITIVE_GATE_PARAMS and value <= 0:
        raise ValueError(
            f"{param} must be positive (> 0), got {value}. "
            "This value is used as minimum denominator to prevent division by zero."
        )
    if param in _NONZERO_GATE_PARAMS and value == 0.0:
        raise ValueError(
            f"{param} must be non-zero, got {value}. "
            "A zero threshold causes the gate to always fail."
        )
    if param in _NONNEGATIVE_GATE_PARAMS and value < 0:
        raise ValueError(
            f"{param} must be non-negative (>= 0), got {value}. "
            "Negative thresholds cause gates to trivially pass."
        )
    if param == "trigger_confidence_prob" and not (0.0 < value <= 1.0):
        raise ValueError(
            f"{param} must be in (0, 1], got {value}. "
            "This is a probability threshold used for Bayesian gate decisions."
        )
