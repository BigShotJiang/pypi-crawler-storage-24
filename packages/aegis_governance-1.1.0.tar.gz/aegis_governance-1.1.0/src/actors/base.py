"""Base Actor Classes

Foundational types for LIBERTAS OPUS actor system.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


class ActorRole(str, Enum):
    """Actor roles in the LIBERTAS system."""

    PROPOSER = "proposer"
    ANALYST = "analyst"
    APPROVER = "approver"
    EXECUTOR = "executor"

    # Specialized roles (can be combined)
    CALIBRATOR = "calibrator"
    GOVERNANCE = "governance"
    RISK_LEAD = "risk_lead"
    SECURITY_LEAD = "security_lead"
    TECH_LEAD = "tech_lead"
    ADMIN = "admin"


@dataclass
class ActorCapabilities:
    """Capabilities granted to an actor."""

    can_create_proposals: bool = False
    can_evaluate_gates: bool = False
    can_vote: bool = False
    can_approve: bool = False
    can_execute: bool = False
    can_override: bool = False
    can_rollback: bool = False
    can_configure: bool = False

    def __repr__(self) -> str:
        """Return concise representation showing enabled capabilities."""
        enabled = [k for k, v in self.__dict__.items() if v]
        caps = ", ".join(enabled) if enabled else "none"
        return f"ActorCapabilities({caps})"

    @classmethod
    def for_role(cls, role: ActorRole) -> "ActorCapabilities":
        """Get default capabilities for a role."""
        if role == ActorRole.PROPOSER:
            return cls(can_create_proposals=True)
        if role == ActorRole.ANALYST:
            return cls(can_evaluate_gates=True, can_vote=True)
        if role == ActorRole.APPROVER:
            return cls(can_vote=True, can_approve=True, can_override=True)
        if role == ActorRole.EXECUTOR:
            return cls(can_execute=True, can_rollback=True)
        if role == ActorRole.CALIBRATOR:
            return cls(
                can_evaluate_gates=True,
                can_vote=True,
                can_configure=True,
            )
        if role == ActorRole.GOVERNANCE:
            return cls(
                can_evaluate_gates=True,
                can_vote=True,
                can_override=True,
                can_configure=True,
            )
        if role == ActorRole.RISK_LEAD:
            return cls(
                can_evaluate_gates=True,
                can_vote=True,
                can_approve=True,
                can_override=True,
            )
        if role == ActorRole.SECURITY_LEAD:
            return cls(
                can_vote=True,
                can_approve=True,
                can_override=True,
            )
        if role == ActorRole.TECH_LEAD:
            return cls(
                can_evaluate_gates=True,
                can_vote=True,
                can_approve=True,
                can_configure=True,
            )
        if role == ActorRole.ADMIN:
            return cls(
                can_create_proposals=True,
                can_evaluate_gates=True,
                can_vote=True,
                can_approve=True,
                can_execute=True,
                can_override=True,
                can_rollback=True,
                can_configure=True,
            )
        return cls()


@dataclass
class ActorContext:
    """Runtime context for actor operations."""

    actor_id: str
    session_id: str
    timestamp: datetime
    metadata: dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        """Return concise representation for debugging."""
        return f"ActorContext(actor={self.actor_id}, session={self.session_id})"


@dataclass
class ActionResult:
    """Result of an actor action."""

    success: bool
    action: str
    actor_id: str
    timestamp: datetime
    result_data: Optional[dict[str, Any]] = None
    error: Optional[str] = None


class Actor(ABC):
    """Base actor class for LIBERTAS OPUS.

    Actors participate in the proposal lifecycle with role-specific
    capabilities and responsibilities.
    """

    def __init__(
        self,
        actor_id: str,
        name: str,
        roles: set[ActorRole],
        capabilities: Optional[ActorCapabilities] = None,
    ):
        """Initialize actor.

        Args:
            actor_id: Unique identifier
            name: Display name
            roles: Set of assigned roles
            capabilities: Custom capabilities (derived from roles if not provided)

        """
        self.actor_id = actor_id
        self.name = name
        self.roles = roles
        self.created_at = datetime.now(timezone.utc)

        # Merge capabilities from all roles if not provided
        if capabilities:
            self.capabilities = capabilities
        else:
            self.capabilities = self._merge_capabilities(roles)

    def _merge_capabilities(self, roles: set[ActorRole]) -> ActorCapabilities:
        """Merge capabilities from multiple roles."""
        merged = ActorCapabilities()
        for role in roles:
            role_caps = ActorCapabilities.for_role(role)
            merged.can_create_proposals |= role_caps.can_create_proposals
            merged.can_evaluate_gates |= role_caps.can_evaluate_gates
            merged.can_vote |= role_caps.can_vote
            merged.can_approve |= role_caps.can_approve
            merged.can_execute |= role_caps.can_execute
            merged.can_override |= role_caps.can_override
            merged.can_rollback |= role_caps.can_rollback
            merged.can_configure |= role_caps.can_configure
        return merged

    def has_role(self, role: ActorRole) -> bool:
        """Check if actor has a specific role."""
        return role in self.roles

    # Valid capability names (must match ActorCapabilities dataclass fields)
    _VALID_CAPABILITIES: frozenset[str] = frozenset(
        {
            "can_create_proposals",
            "can_evaluate_gates",
            "can_vote",
            "can_approve",
            "can_execute",
            "can_override",
            "can_rollback",
            "can_configure",
        }
    )

    def has_capability(self, capability: str) -> bool:
        """Check if actor has a specific capability.

        Args:
            capability: Capability name (must be one of the valid capability names
                defined in ActorCapabilities)

        Returns:
            True if actor has the capability, False otherwise

        Raises:
            ValueError: If capability is not a valid capability name

        """
        if capability not in self._VALID_CAPABILITIES:
            raise ValueError(
                f"Invalid capability name: {capability!r}. "
                f"Valid capabilities: {sorted(self._VALID_CAPABILITIES)}"
            )
        return getattr(self.capabilities, capability, False)

    @abstractmethod
    def get_primary_role(self) -> ActorRole:
        """Get the primary role for this actor type."""

    @abstractmethod
    def get_allowed_actions(self) -> list[str]:
        """Get list of actions this actor can perform."""

    def create_context(self, session_id: str) -> ActorContext:
        """Create a runtime context for operations."""
        return ActorContext(
            actor_id=self.actor_id,
            session_id=session_id,
            timestamp=datetime.now(timezone.utc),
        )

    def record_action(
        self,
        action: str,
        success: bool,
        result_data: Optional[dict[str, Any]] = None,
        error: Optional[str] = None,
    ) -> ActionResult:
        """Record an action result."""
        return ActionResult(
            success=success,
            action=action,
            actor_id=self.actor_id,
            timestamp=datetime.now(timezone.utc),
            result_data=result_data,
            error=error,
        )
