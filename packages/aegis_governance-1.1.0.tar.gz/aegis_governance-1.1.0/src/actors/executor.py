"""Executor Actor

Implements approved proposals and manages execution lifecycle.
"""

import math
import threading
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from .base import ActionResult, Actor, ActorRole

# Default history limit for bounded collections (prevents unbounded memory growth)
DEFAULT_HISTORY_LIMIT: int = 10000


class ExecutionStatus(str, Enum):
    """Execution status states."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"
    PAUSED = "paused"


@dataclass
class ExecutionPlan:
    """Plan for executing a proposal."""

    proposal_id: str
    steps: list[dict[str, Any]]
    rollback_steps: list[dict[str, Any]]
    timeout_seconds: int
    requires_confirmation: bool = True

    def __post_init__(self) -> None:
        """Validate execution plan parameters."""
        if not isinstance(self.timeout_seconds, (int, float)) or isinstance(
            self.timeout_seconds, bool
        ):
            raise TypeError(
                f"timeout_seconds must be numeric, got {type(self.timeout_seconds).__name__}"
            )
        if isinstance(self.timeout_seconds, float) and not math.isfinite(
            self.timeout_seconds
        ):
            raise ValueError(
                f"timeout_seconds must be finite, got {self.timeout_seconds}"
            )
        if self.timeout_seconds <= 0:
            raise ValueError(
                f"timeout_seconds must be positive, got {self.timeout_seconds}"
            )


@dataclass
class ExecutionProgress:
    """Progress of an execution."""

    proposal_id: str
    status: ExecutionStatus
    current_step: int
    total_steps: int
    started_at: datetime
    completed_at: Optional[datetime] = None
    error: Optional[str] = None


class Executor(Actor):
    """Executor actor - implements approved proposals.

    Responsibilities:
    - Execute approved proposals
    - Monitor execution progress
    - Handle failures and rollbacks
    - Report execution status
    """

    def __init__(
        self,
        actor_id: str,
        name: str,
        execution_environment: str = "production",
        additional_roles: Optional[set[ActorRole]] = None,
        history_limit: int = DEFAULT_HISTORY_LIMIT,
    ):
        """Initialize executor.

        Args:
            actor_id: Unique identifier
            name: Display name
            execution_environment: Environment for execution
            additional_roles: Additional roles beyond executor
            history_limit: Maximum history entries to retain (prevents memory growth)

        """
        roles = {ActorRole.EXECUTOR}
        if additional_roles:
            roles.update(additional_roles)

        super().__init__(
            actor_id=actor_id,
            name=name,
            roles=roles,
        )

        self.execution_environment = execution_environment
        self.active_executions: dict[str, ExecutionProgress] = {}
        self.completed_executions: deque[str] = deque(maxlen=history_limit)
        # W-8 fix: retain final progress for completed executions so
        # get_execution_status() can return them after completion
        self._completed_status: dict[str, ExecutionProgress] = {}
        self._history_limit = history_limit
        self._lock = threading.Lock()  # Thread safety for active_executions access

    def get_primary_role(self) -> ActorRole:
        """Get the primary role for this actor type."""
        return ActorRole.EXECUTOR

    def get_allowed_actions(self) -> list[str]:
        """Get list of actions this actor can perform."""
        actions = [
            "start_execution",
            "advance_step",
            "complete_execution",
            "rollback",
            "pause_execution",
            "resume_execution",
        ]
        return actions

    def start_execution(
        self,
        plan: ExecutionPlan,
    ) -> ActionResult:
        """Start executing a proposal.

        Args:
            plan: Execution plan

        Returns:
            ActionResult with execution ID

        """
        if not self.capabilities.can_execute:
            return self.record_action(
                "start_execution",
                success=False,
                error="Actor does not have execution capability",
            )

        with self._lock:
            if plan.proposal_id in self.active_executions:
                return self.record_action(
                    "start_execution",
                    success=False,
                    error=f"Execution already in progress for {plan.proposal_id}",
                )

            if plan.proposal_id in self._completed_status:
                prev = self._completed_status[plan.proposal_id]
                # Allow retry after rollback or failure (state machine permits restart)
                if prev.status in (ExecutionStatus.ROLLED_BACK, ExecutionStatus.FAILED):
                    del self._completed_status[plan.proposal_id]
                else:
                    return self.record_action(
                        "start_execution",
                        success=False,
                        error=f"Proposal {plan.proposal_id} was already executed (status: {prev.status.value})",
                    )

            progress = ExecutionProgress(
                proposal_id=plan.proposal_id,
                status=ExecutionStatus.IN_PROGRESS,
                current_step=0,
                total_steps=len(plan.steps),
                started_at=datetime.now(timezone.utc),
            )

            # Treat empty plans as immediate completion to avoid stuck executions.
            if progress.total_steps == 0:
                progress.status = ExecutionStatus.COMPLETED
                progress.completed_at = datetime.now(timezone.utc)
                self.completed_executions.append(plan.proposal_id)
                self._save_completed_status(plan.proposal_id, progress)
                return self.record_action(
                    "start_execution",
                    success=True,
                    result_data={
                        "proposal_id": plan.proposal_id,
                        "status": progress.status.value,
                        "total_steps": progress.total_steps,
                        "started_at": progress.started_at.isoformat(),
                        "completed_at": progress.completed_at.isoformat(),
                    },
                )

            self.active_executions[plan.proposal_id] = progress

            # Snapshot mutable fields before releasing lock (parity with
            # advance_step which correctly snapshots at lines 258-260).
            status_snapshot = progress.status
            total_steps_snapshot = progress.total_steps
            started_at_snapshot = progress.started_at

        return self.record_action(
            "start_execution",
            success=True,
            result_data={
                "proposal_id": plan.proposal_id,
                "status": status_snapshot.value,
                "total_steps": total_steps_snapshot,
                "started_at": started_at_snapshot.isoformat(),
            },
        )

    def advance_step(
        self,
        proposal_id: str,
        step_result: dict[str, Any],
    ) -> ActionResult:
        """Advance execution to next step.

        Args:
            proposal_id: Proposal being executed
            step_result: Result of completed step

        Returns:
            ActionResult with updated progress

        """
        with self._lock:
            if proposal_id not in self.active_executions:
                return self.record_action(
                    "advance_step",
                    success=False,
                    error=f"No active execution for {proposal_id}",
                )

            progress = self.active_executions[proposal_id]

            if progress.status != ExecutionStatus.IN_PROGRESS:
                return self.record_action(
                    "advance_step",
                    success=False,
                    error=f"Execution is not in progress: {progress.status.value}",
                )

            progress.current_step += 1

            # Check if complete
            if progress.current_step >= progress.total_steps:
                progress.status = ExecutionStatus.COMPLETED
                progress.completed_at = datetime.now(timezone.utc)
                self.completed_executions.append(proposal_id)
                self._save_completed_status(proposal_id, progress)
                del self.active_executions[proposal_id]

            current_step = progress.current_step
            total_steps = progress.total_steps
            status = progress.status

        return self.record_action(
            "advance_step",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "current_step": current_step,
                "total_steps": total_steps,
                "status": status.value,
                "completed": status == ExecutionStatus.COMPLETED,
            },
        )

    def rollback(
        self,
        proposal_id: str,
        reason: str,
    ) -> ActionResult:
        """Roll back an execution.

        Args:
            proposal_id: Proposal to roll back
            reason: Reason for rollback

        Returns:
            ActionResult with rollback status

        """
        if not self.capabilities.can_rollback:
            return self.record_action(
                "rollback",
                success=False,
                error="Actor does not have rollback capability",
            )

        with self._lock:
            if proposal_id not in self.active_executions:
                return self.record_action(
                    "rollback",
                    success=False,
                    error=f"No active execution for {proposal_id}",
                )

            progress = self.active_executions[proposal_id]
            progress.status = ExecutionStatus.ROLLED_BACK
            progress.completed_at = datetime.now(timezone.utc)
            progress.error = reason
            completed_at = progress.completed_at

            self.completed_executions.append(proposal_id)
            self._save_completed_status(proposal_id, progress)
            del self.active_executions[proposal_id]

        return self.record_action(
            "rollback",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "status": ExecutionStatus.ROLLED_BACK.value,
                "reason": reason,
                "rolled_back_at": completed_at.isoformat(),
            },
        )

    def pause_execution(
        self,
        proposal_id: str,
        reason: str,
    ) -> ActionResult:
        """Pause an active execution.

        Args:
            proposal_id: Proposal to pause
            reason: Reason for pausing

        Returns:
            ActionResult with pause status

        """
        with self._lock:
            if proposal_id not in self.active_executions:
                return self.record_action(
                    "pause_execution",
                    success=False,
                    error=f"No active execution for {proposal_id}",
                )

            progress = self.active_executions[proposal_id]

            if progress.status != ExecutionStatus.IN_PROGRESS:
                return self.record_action(
                    "pause_execution",
                    success=False,
                    error="Can only pause in-progress executions",
                )

            progress.status = ExecutionStatus.PAUSED

        return self.record_action(
            "pause_execution",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "status": ExecutionStatus.PAUSED.value,
                "reason": reason,
            },
        )

    def resume_execution(
        self,
        proposal_id: str,
    ) -> ActionResult:
        """Resume a paused execution.

        Args:
            proposal_id: Proposal to resume

        Returns:
            ActionResult with resume status

        """
        with self._lock:
            if proposal_id not in self.active_executions:
                return self.record_action(
                    "resume_execution",
                    success=False,
                    error=f"No active execution for {proposal_id}",
                )

            progress = self.active_executions[proposal_id]

            if progress.status != ExecutionStatus.PAUSED:
                return self.record_action(
                    "resume_execution",
                    success=False,
                    error="Can only resume paused executions",
                )

            progress.status = ExecutionStatus.IN_PROGRESS

        return self.record_action(
            "resume_execution",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "status": ExecutionStatus.IN_PROGRESS.value,
            },
        )

    def _save_completed_status(
        self,
        proposal_id: str,
        progress: ExecutionProgress,
    ) -> None:
        """Save a snapshot of completed execution status (W-8 fix).

        Must be called under self._lock. Evicts oldest entry if over limit.
        """
        from dataclasses import replace

        self._completed_status[proposal_id] = replace(progress)
        # Evict oldest if over history limit
        while len(self._completed_status) > self._history_limit:
            oldest_key = next(iter(self._completed_status))
            del self._completed_status[oldest_key]

    def get_execution_status(
        self,
        proposal_id: str,
    ) -> Optional[ExecutionProgress]:
        """Get status of an execution (active or completed).

        Returns a defensive copy to prevent external mutation that would
        bypass the thread-safety lock protections.
        W-8 fix: also checks completed status for recently finished executions.
        """
        with self._lock:
            progress = self.active_executions.get(proposal_id)
            if progress is None:
                # Check completed status (W-8 fix)
                progress = self._completed_status.get(proposal_id)
            if progress is None:
                return None
            # Return a copy to prevent external mutation bypassing the lock
            from dataclasses import replace

            return replace(progress)

    def get_active_count(self) -> int:
        """Get count of active executions."""
        with self._lock:
            return len(self.active_executions)
