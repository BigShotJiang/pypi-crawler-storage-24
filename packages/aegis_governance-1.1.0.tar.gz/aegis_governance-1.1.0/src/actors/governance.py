"""Governance Actor

Orchestrates override workflows and enforces compliance.
Maps to GOVERNANCE actor type in schema/rbac-definitions.yaml
with two_key_override and emergency_halt capabilities.
"""

import threading
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Optional

from engine.gates import GateType
from workflows.override import OverrideState, OverrideWorkflow

from .base import ActionResult, Actor, ActorRole

if TYPE_CHECKING:
    from rbac import RBACEnforcer
    from telemetry.alert import AlertSink as AlertSinkProtocol
    from telemetry.emitter import TelemetryEmitter
    from telemetry.prometheus_exporter import PrometheusExporter

DEFAULT_HISTORY_LIMIT: int = 10000


@dataclass
class ComplianceCheckResult:
    """Result of a compliance check on a proposal."""

    proposal_id: str
    compliant: bool
    violations: list[str]
    checked_at: datetime


class Governance(Actor):
    """Governance actor - orchestrates override workflows and compliance.

    Responsibilities:
    - Initiate and manage override request lifecycle
    - Collect signatures from Risk Lead and Security Lead
    - Enforce compliance (e.g., complexity gate cannot be overridden)
    - Perform emergency halts
    - Report override status
    """

    def __init__(
        self,
        actor_id: str,
        name: str,
        additional_roles: Optional[set[ActorRole]] = None,
        history_limit: int = DEFAULT_HISTORY_LIMIT,
    ):
        """Initialize governance actor.

        Args:
            actor_id: Unique identifier
            name: Display name
            additional_roles: Additional roles beyond governance
            history_limit: Maximum history entries to retain (prevents memory growth)

        """
        roles: set[ActorRole] = {ActorRole.GOVERNANCE}
        if additional_roles:
            roles.update(additional_roles)

        super().__init__(
            actor_id=actor_id,
            name=name,
            roles=roles,
        )

        self.active_overrides: dict[str, OverrideWorkflow] = {}
        self.override_history: deque[str] = deque(maxlen=history_limit)
        self.compliance_checks: deque[ComplianceCheckResult] = deque(
            maxlen=history_limit,
        )
        self._halted = False
        self._halt_reason: Optional[str] = None
        self._lock = threading.Lock()

    def get_primary_role(self) -> ActorRole:
        """Get the primary role for this actor type."""
        return ActorRole.GOVERNANCE

    def get_allowed_actions(self) -> list[str]:
        """Get list of actions this actor can perform."""
        return [
            "initiate_override",
            "add_override_signature",
            "reject_override",
            "check_override_status",
            "check_compliance",
            "emergency_halt",
        ]

    def initiate_override(
        self,
        proposal_id: str,
        justification: str,
        failed_gates: list[str],
        requested_by: str,
        validator: Any = None,
        rbac_enforcer: Optional["RBACEnforcer"] = None,
        telemetry_emitter: Optional["TelemetryEmitter"] = None,
        prometheus_exporter: Optional["PrometheusExporter"] = None,
        alert_sink: Optional["AlertSinkProtocol"] = None,
    ) -> ActionResult:
        """Initiate a two-key override workflow.

        Args:
            proposal_id: Proposal requesting override
            justification: Justification for override
            failed_gates: Gates that failed (complexity gate is blocked)
            requested_by: Actor requesting override
            validator: Optional DualSignatureValidator
            rbac_enforcer: Optional RBAC enforcer
            telemetry_emitter: Optional telemetry emitter
            prometheus_exporter: Optional Prometheus exporter
            alert_sink: Optional alert sink

        Returns:
            ActionResult with override workflow info

        """
        if not self.capabilities.can_override:
            return self.record_action(
                "initiate_override",
                success=False,
                error="Actor does not have override capability",
            )

        if GateType.COMPLEXITY.value in failed_gates:
            return self.record_action(
                "initiate_override",
                success=False,
                error="Complexity gate cannot be overridden",
            )

        with self._lock:
            # U-1: Block new overrides when system is halted (inside lock for atomicity)
            if self._halted:
                return self.record_action(
                    "initiate_override",
                    success=False,
                    error="System is halted — cannot initiate new overrides",
                )

            existing = self.active_overrides.get(proposal_id)
            if existing is not None:
                # Evict expired override so a new request can proceed.
                if existing.check_and_mark_expired():
                    del self.active_overrides[proposal_id]
                else:
                    return self.record_action(
                        "initiate_override",
                        success=False,
                        error=f"Override already active for {proposal_id}",
                    )

            workflow = OverrideWorkflow(
                proposal_id=proposal_id,
                justification=justification,
                failed_gates=failed_gates,
                requested_by=requested_by,
                validator=validator,
                rbac_enforcer=rbac_enforcer,
                telemetry_emitter=telemetry_emitter,
                prometheus_exporter=prometheus_exporter,
                alert_sink=alert_sink,
            )

            self.active_overrides[proposal_id] = workflow
            self.override_history.append(proposal_id)

        return self.record_action(
            "initiate_override",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "state": OverrideState.PENDING.value,
                "failed_gates": failed_gates,
                "requested_by": requested_by,
                "expires_at": workflow.expires_at.isoformat(),
            },
        )

    def add_override_signature(
        self,
        proposal_id: str,
        signer_id: str,
        role: str,
        signature: str,
        public_key: str,
    ) -> ActionResult:
        """Add a signature to an active override workflow.

        Args:
            proposal_id: Proposal with active override
            signer_id: Signer identifier
            role: Signer's role (risk_lead or security_lead)
            signature: Base64-encoded signature
            public_key: Base64-encoded public key

        Returns:
            ActionResult with signature status

        """
        with self._lock:
            # U-2: Block signature additions when system is halted (inside lock for atomicity)
            if self._halted:
                return self.record_action(
                    "add_override_signature",
                    success=False,
                    error="System is halted — cannot add signatures",
                )

            if proposal_id not in self.active_overrides:
                return self.record_action(
                    "add_override_signature",
                    success=False,
                    error=f"No active override for {proposal_id}",
                )

            workflow = self.active_overrides[proposal_id]
            success, message = workflow.add_signature(
                signer_id=signer_id,
                role=role,
                signature=signature,
                public_key=public_key,
            )

            if not success:
                # Clean up terminal workflows (e.g., expired during signature)
                if workflow.request.state in OverrideWorkflow._TERMINAL_STATES:
                    del self.active_overrides[proposal_id]
                return self.record_action(
                    "add_override_signature",
                    success=False,
                    error=message,
                )

            result = workflow.get_result()
            state = result.state

            # Move to history if terminal
            if state == OverrideState.APPROVED:
                del self.active_overrides[proposal_id]

        return self.record_action(
            "add_override_signature",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "signer_id": signer_id,
                "role": role,
                "state": state.value,
                "approved": result.approved,
            },
        )

    def reject_override(
        self,
        proposal_id: str,
        reason: str,
    ) -> ActionResult:
        """Reject an active override request.

        Args:
            proposal_id: Proposal with active override
            reason: Rejection reason

        Returns:
            ActionResult with rejection status

        """
        with self._lock:
            if proposal_id not in self.active_overrides:
                return self.record_action(
                    "reject_override",
                    success=False,
                    error=f"No active override for {proposal_id}",
                )

            workflow = self.active_overrides[proposal_id]
            rejected = workflow.reject(self.actor_id, reason)

            if not rejected:
                # U-4: Clean up terminal workflow even if reject fails
                if workflow.request.state in OverrideWorkflow._TERMINAL_STATES:
                    del self.active_overrides[proposal_id]
                return self.record_action(
                    "reject_override",
                    success=False,
                    error="Override could not be rejected (already terminal)",
                )

            del self.active_overrides[proposal_id]

        return self.record_action(
            "reject_override",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "state": OverrideState.REJECTED.value,
                "reason": reason,
                "rejected_by": self.actor_id,
            },
        )

    def check_override_status(
        self,
        proposal_id: str,
    ) -> ActionResult:
        """Check the status of an active override.

        Args:
            proposal_id: Proposal to check

        Returns:
            ActionResult with override status

        """
        with self._lock:
            if proposal_id not in self.active_overrides:
                return self.record_action(
                    "check_override_status",
                    success=False,
                    error=f"No active override for {proposal_id}",
                )

            workflow = self.active_overrides[proposal_id]
            expired = workflow.check_and_mark_expired()

            result = workflow.get_result()

            result_data: dict[str, Any] = {
                "proposal_id": proposal_id,
                "state": result.state.value,
                "approved": result.approved,
                "expires_at": result.expires_at.isoformat(),
                "pending_signatures": workflow.get_pending_signatures(),
            }

            # Move to history if expired
            if expired:
                del self.active_overrides[proposal_id]

        return self.record_action(
            "check_override_status",
            success=True,
            result_data=result_data,
        )

    def check_compliance(
        self,
        proposal_id: str,
        gate_results: dict[str, bool],
    ) -> ActionResult:
        """Check compliance for a proposal against gate results.

        Verifies that non-overridable gates (complexity) have passed.
        Fail-closed: missing complexity gate result is a violation.

        Args:
            proposal_id: Proposal to check
            gate_results: Dict mapping gate name to pass/fail

        Returns:
            ActionResult with compliance status

        """
        if not self.capabilities.can_evaluate_gates:
            return self.record_action(
                "check_compliance",
                success=False,
                error="Actor does not have gate evaluation capability",
            )

        violations: list[str] = []

        # U-3: Complexity gate MUST pass (non-overridable), fail-closed
        complexity_key = GateType.COMPLEXITY.value
        if complexity_key not in gate_results:
            violations.append(
                "Complexity gate result missing — cannot verify compliance"
            )
        elif not gate_results[complexity_key]:
            violations.append("Complexity gate failed — cannot be overridden")

        compliant = len(violations) == 0
        check_result = ComplianceCheckResult(
            proposal_id=proposal_id,
            compliant=compliant,
            violations=violations,
            checked_at=datetime.now(timezone.utc),
        )
        self.compliance_checks.append(check_result)

        return self.record_action(
            "check_compliance",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "compliant": compliant,
                "violations": violations,
                "checked_at": check_result.checked_at.isoformat(),
            },
        )

    def emergency_halt(
        self,
        reason: str,
    ) -> ActionResult:
        """Activate emergency halt.

        Args:
            reason: Reason for emergency halt

        Returns:
            ActionResult with halt confirmation

        """
        if not self.capabilities.can_configure:
            return self.record_action(
                "emergency_halt",
                success=False,
                error="Actor does not have configure capability",
            )

        with self._lock:
            halt_time = datetime.now(timezone.utc)
            self._halted = True
            self._halt_reason = reason
            # Reject all active overrides — halt means ALL operations stop
            # Track both successfully rejected AND already-terminal overrides
            # for complete audit trail (100% coverage requirement)
            cancelled_ids = []
            already_terminal_ids = []
            for pid in list(self.active_overrides):
                workflow = self.active_overrides[pid]
                if workflow.reject(self.actor_id, f"Emergency halt: {reason}"):
                    cancelled_ids.append(pid)
                else:
                    already_terminal_ids.append(pid)
            self.active_overrides.clear()

        return self.record_action(
            "emergency_halt",
            success=True,
            result_data={
                "halted": True,
                "reason": reason,
                "halted_at": halt_time.isoformat(),
                "cancelled_overrides": cancelled_ids,
                "already_terminal_overrides": already_terminal_ids,
            },
        )

    def _evict_expired_overrides(self) -> int:
        """Evict expired overrides from active_overrides dict.

        Must be called while holding self._lock.

        Returns:
            Number of evicted overrides.
        """
        expired_ids = [
            pid
            for pid, wf in self.active_overrides.items()
            if wf.check_and_mark_expired()
        ]
        for pid in expired_ids:
            del self.active_overrides[pid]
        return len(expired_ids)

    def get_active_overrides(self) -> dict[str, Any]:
        """Get summary of all active override workflows.

        Returns:
            Dict mapping proposal_id to override status summary

        """
        with self._lock:
            self._evict_expired_overrides()
            summary: dict[str, Any] = {}
            for proposal_id, workflow in self.active_overrides.items():
                result = workflow.get_result()
                summary[proposal_id] = {
                    "state": result.state.value,
                    "pending_signatures": workflow.get_pending_signatures(),
                    "expires_at": result.expires_at.isoformat(),
                }
        return summary

    def is_halted(self) -> bool:
        """Check if emergency halt is active."""
        with self._lock:
            return self._halted
