"""Analyst Actor

Evaluates proposals against quantitative gates and provides analysis.

Integration with Guardrails v1.1.1:
- Uses GateEvaluator for proper Bayesian posterior gate calculations
- Risk/Profit gates use P(Delta>=2|data) > 0.95 threshold
- Novelty gate uses logistic function G(N)
- All gates return confidence scores
"""

import math
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

# Gate evaluation imports
from engine.gates import GateEvaluator
from engine.utility import UtilityComponents, UtilityResult

from .base import ActionResult, Actor, ActorRole

# Default history limit for bounded collections (prevents unbounded memory growth)
DEFAULT_HISTORY_LIMIT: int = 10000


# Valid analysis types
VALID_ANALYSIS_TYPES: frozenset[str] = frozenset(
    {
        "full",
        "risk_only",
        "profit_only",
        "quick",
    }
)


@dataclass
class AnalysisRequest:
    """Request for proposal analysis."""

    proposal_id: str
    analysis_type: str  # "full", "risk_only", "profit_only", "quick"
    include_recommendations: bool = True

    def __post_init__(self) -> None:
        """Validate analysis_type on construction."""
        if self.analysis_type not in VALID_ANALYSIS_TYPES:
            raise ValueError(
                f"Invalid analysis_type '{self.analysis_type}'. "
                f"Must be one of: {', '.join(sorted(VALID_ANALYSIS_TYPES))}"
            )


@dataclass
class GateAnalysis:
    """Analysis of a single gate."""

    gate_name: str
    passed: bool
    value: float
    threshold: float
    confidence: float
    notes: Optional[str] = None


@dataclass
class ProposalAnalysis:
    """Complete proposal analysis."""

    proposal_id: str
    analyst_id: str
    timestamp: datetime
    gate_analyses: list[GateAnalysis]
    overall_passed: bool
    recommendations: list[str]
    risk_assessment: str
    confidence_score: float


class Analyst(Actor):
    """Analyst actor - evaluates proposals against gates.

    Responsibilities:
    - Evaluate proposals against quantitative gates
    - Provide detailed analysis and recommendations
    - Flag potential risks and concerns
    - Support override justification review
    """

    def __init__(
        self,
        actor_id: str,
        name: str,
        specializations: Optional[list[str]] = None,
        additional_roles: Optional[set[ActorRole]] = None,
        gate_evaluator: Optional[GateEvaluator] = None,
        history_limit: int = DEFAULT_HISTORY_LIMIT,
    ):
        """Initialize analyst.

        Args:
            actor_id: Unique identifier
            name: Display name
            specializations: Areas of expertise (risk, profit, security, etc.)
            additional_roles: Additional roles beyond analyst
            gate_evaluator: Optional pre-configured GateEvaluator for Bayesian
                gate logic. If not provided, creates default evaluator.
            history_limit: Maximum history entries to retain (prevents memory growth)

        """
        roles = {ActorRole.ANALYST}
        if additional_roles:
            roles.update(additional_roles)

        super().__init__(
            actor_id=actor_id,
            name=name,
            roles=roles,
        )

        self.specializations = specializations or ["general"]
        self.analyses_completed: deque[str] = deque(maxlen=history_limit)
        self.gate_evaluator = gate_evaluator or GateEvaluator()

    def get_primary_role(self) -> ActorRole:
        """Get the primary role for this actor type."""
        return ActorRole.ANALYST

    def get_allowed_actions(self) -> list[str]:
        """Get list of actions this actor can perform."""
        actions = [
            "analyze_proposal",
            "evaluate_gate",
            "provide_recommendation",
            "review_override",
            "vote",
        ]
        if self.has_role(ActorRole.RISK_LEAD):
            actions.extend(["approve_risk", "sign_override"])
        return actions

    def analyze_proposal(
        self,
        request: AnalysisRequest,
        proposal_data: dict[str, Any],
    ) -> ActionResult:
        """Analyze a proposal against gates.

        Args:
            request: Analysis request
            proposal_data: Proposal data to analyze

        Returns:
            ActionResult with analysis

        """
        if not self.capabilities.can_evaluate_gates:
            return self.record_action(
                "analyze_proposal",
                success=False,
                error="Actor does not have gate evaluation capability",
            )

        # Perform gate evaluations
        gate_analyses = []
        try:
            # Risk gate
            if request.analysis_type in ("full", "risk_only", "quick"):
                gate_analyses.append(self._evaluate_risk_gate(proposal_data))

            # Profit gate
            if request.analysis_type in ("full", "profit_only"):
                gate_analyses.append(self._evaluate_profit_gate(proposal_data))

            # Other gates for full analysis
            if request.analysis_type == "full":
                gate_analyses.extend(
                    [
                        self._evaluate_novelty_gate(proposal_data),
                        self._evaluate_complexity_gate(proposal_data),
                        self._evaluate_quality_gate(proposal_data),
                        self._evaluate_utility_gate(proposal_data),
                    ],
                )
        except (ValueError, TypeError, ZeroDivisionError, AttributeError) as e:
            return self.record_action(
                "analyze_proposal",
                success=False,
                error=f"Gate evaluation failed: {e}",
            )

        # Defense in depth: ensure at least one gate was evaluated
        # This prevents false approvals if analysis_type validation was bypassed
        if not gate_analyses:
            return self.record_action(
                "analyze_proposal",
                success=False,
                error=f"No gates evaluated for analysis_type '{request.analysis_type}'",
            )

        overall_passed = all(g.passed for g in gate_analyses)

        # Generate recommendations
        recommendations = []
        if request.include_recommendations:
            recommendations = self._generate_recommendations(gate_analyses)

        analysis = ProposalAnalysis(
            proposal_id=request.proposal_id,
            analyst_id=self.actor_id,
            timestamp=datetime.now(timezone.utc),
            gate_analyses=gate_analyses,
            overall_passed=overall_passed,
            recommendations=recommendations,
            risk_assessment=self._assess_overall_risk(gate_analyses),
            confidence_score=self._calculate_confidence(gate_analyses),
        )

        self.analyses_completed.append(request.proposal_id)

        return self.record_action(
            "analyze_proposal",
            success=True,
            result_data={
                "proposal_id": request.proposal_id,
                "overall_passed": overall_passed,
                "gate_count": len(gate_analyses),
                "passed_count": sum(1 for g in gate_analyses if g.passed),
                "confidence": analysis.confidence_score,
            },
        )

    def _evaluate_risk_gate(self, data: dict[str, Any]) -> GateAnalysis:
        """Evaluate risk gate using Bayesian posterior P(Delta>=2|data).

        Supports both old-style (risk_delta) and new-style (risk_baseline + risk_proposed)
        input formats for backward compatibility.
        """
        # Support both old-style delta and new-style baseline/proposed inputs
        risk_baseline = data.get("risk_baseline", 0.0)
        if risk_baseline is None:
            risk_baseline = 0.0
        risk_proposed = data.get("risk_proposed")
        if risk_proposed is None:
            risk_delta = data.get("risk_delta", 0.0)
            if risk_delta is None:
                risk_delta = 0.0
            risk_proposed = risk_baseline + risk_delta

        # Use GateEvaluator for proper Bayesian calculation
        gate_result = self.gate_evaluator.evaluate_risk_gate(
            baseline=risk_baseline,
            proposed=risk_proposed,
        )

        return GateAnalysis(
            gate_name="risk",
            passed=gate_result.passed,
            value=gate_result.value,
            threshold=gate_result.threshold,
            confidence=(
                gate_result.confidence if gate_result.confidence is not None else 0.0
            ),
            notes=gate_result.message,
        )

    def _evaluate_profit_gate(self, data: dict[str, Any]) -> GateAnalysis:
        """Evaluate profit gate using Bayesian posterior P(Delta>=2|data).

        Supports both old-style (profit_delta) and new-style (profit_baseline + profit_proposed)
        input formats for backward compatibility.
        """
        # Support both old-style delta and new-style baseline/proposed inputs
        profit_baseline = data.get("profit_baseline", 0.0)
        if profit_baseline is None:
            profit_baseline = 0.0
        profit_proposed = data.get("profit_proposed")
        if profit_proposed is None:
            profit_delta = data.get("profit_delta", 0.0)
            if profit_delta is None:
                profit_delta = 0.0
            profit_proposed = profit_baseline + profit_delta

        # Use GateEvaluator public method for proper Bayesian calculation
        gate_result = self.gate_evaluator.evaluate_profit_gate(
            baseline=profit_baseline,
            proposed=profit_proposed,
        )

        return GateAnalysis(
            gate_name="profit",
            passed=gate_result.passed,
            value=gate_result.value,
            threshold=gate_result.threshold,
            confidence=(
                gate_result.confidence if gate_result.confidence is not None else 0.0
            ),
            notes=gate_result.message,
        )

    def _evaluate_novelty_gate(self, data: dict[str, Any]) -> GateAnalysis:
        """Evaluate novelty gate using logistic function G(N).

        G(N) = 1 / (1 + e^{-k(N - N0)}) >= 0.8 to pass.
        """
        novelty = data.get("novelty_score", 0.5)
        if novelty is None:
            novelty = 0.5

        # Use GateEvaluator public method for proper logistic function calculation
        gate_result = self.gate_evaluator.evaluate_novelty_gate(novelty)

        return GateAnalysis(
            gate_name="novelty",
            passed=gate_result.passed,
            value=gate_result.value,
            threshold=gate_result.threshold,
            confidence=(
                gate_result.confidence if gate_result.confidence is not None else 0.0
            ),
            notes=gate_result.message,
        )

    def _evaluate_complexity_gate(self, data: dict[str, Any]) -> GateAnalysis:
        """Evaluate complexity floor (hard requirement).

        C_norm >= 0.5 to pass. This gate cannot be overridden.
        """
        complexity = data.get("complexity_score", 0.5)
        if complexity is None:
            complexity = 0.5

        # Use GateEvaluator public method for proper complexity floor check
        gate_result = self.gate_evaluator.evaluate_complexity_gate(complexity)

        # Add explicit hard requirement note if failed
        notes = gate_result.message
        if not gate_result.passed and notes != "Hard requirement":
            notes = "Hard requirement - cannot be overridden"

        return GateAnalysis(
            gate_name="complexity",
            passed=gate_result.passed,
            value=gate_result.value,
            threshold=gate_result.threshold,
            confidence=(
                gate_result.confidence if gate_result.confidence is not None else 0.0
            ),
            notes=notes,
        )

    def _evaluate_quality_gate(self, data: dict[str, Any]) -> GateAnalysis:
        """Evaluate quality gate: Q >= 0.7 AND no zero sub-scores.

        Both conditions must be met for the gate to pass.
        """
        quality = data.get("quality_score", 0.7)
        if quality is None:
            quality = 0.7
        subscores = data.get("quality_subscores", [0.7, 0.7, 0.7])
        if subscores is None:
            # Treat explicit null the same as an omitted field.
            subscores = [0.7, 0.7, 0.7]
        elif isinstance(subscores, list):
            # BH41-M1: Filter None elements (transport parity with MCP/AFA saw_non_null pattern).
            # [None, 0.8] would raise TypeError in GateEvaluator's 0.0 <= s <= 1.0 comparison.
            _filtered = []
            _saw_non_null = False
            for _s in subscores:
                if _s is not None:
                    _saw_non_null = True
                    _filtered.append(_s)
            if _filtered:
                subscores = _filtered
            elif subscores and not _saw_non_null:
                # All-null list (e.g. [None, None]) — default like explicit null
                subscores = [0.7, 0.7, 0.7]
            # else: explicit empty list passes through (fail-closed)
        else:
            raise TypeError(
                f"quality_subscores must be a list, got {type(subscores).__name__}"
            )

        # Use GateEvaluator public method for proper quality gate check with subscores
        gate_result = self.gate_evaluator.evaluate_quality_gate(quality, subscores)

        return GateAnalysis(
            gate_name="quality",
            passed=gate_result.passed,
            value=gate_result.value,
            threshold=gate_result.threshold,
            confidence=(
                gate_result.confidence if gate_result.confidence is not None else 0.0
            ),
            notes=gate_result.message,
        )

    def _coerce_to_float(self, value: Any, field_name: str) -> float:
        """Coerce a value to float with type validation.

        Args:
            value: Value to coerce (may be int, float, str, or other)
            field_name: Name of the field for error messages

        Returns:
            Float value

        Raises:
            TypeError: If value cannot be coerced to float

        """
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            result = float(value)
            if not math.isfinite(result):
                raise TypeError(f"{field_name}={value!r} is not a finite number")
            return result
        if isinstance(value, str):
            try:
                result = float(value)
            except ValueError:
                raise TypeError(
                    f"Cannot convert {field_name}={value!r} to float: "
                    f"string is not a valid number"
                ) from None
            if not math.isfinite(result):
                raise TypeError(
                    f"Cannot convert {field_name}={value!r} to float: "
                    f"NaN/Inf values are not accepted"
                )
            return result
        raise TypeError(
            f"Cannot convert {field_name}={value!r} (type {type(value).__name__}) "
            f"to float: expected numeric type"
        )

    def _evaluate_utility_gate(self, data: dict[str, Any]) -> GateAnalysis:
        """Evaluate utility LCB gate: LCB(U) > theta.

        If a UtilityResult object is provided directly, uses it.
        Otherwise constructs one from available data fields.

        Type coercion is applied to numeric fields to handle cases where
        values may be passed as strings (e.g., from JSON deserialization).
        """
        # Check if a UtilityResult is provided directly
        utility_result = data.get("utility_result")

        if utility_result is None:
            # Construct UtilityResult from available data with type coercion
            # Guard explicit None from dict.get() (JSON null) before coercion
            raw_lcb = data.get("utility_lcb", 0.0)
            utility_lcb = self._coerce_to_float(
                0.0 if raw_lcb is None else raw_lcb, "utility_lcb"
            )
            raw_util = data.get("net_utility", data.get("raw_utility", 0.0))
            raw_utility = self._coerce_to_float(
                0.0 if raw_util is None else raw_util, "raw_utility"
            )
            raw_var = data.get("utility_variance", 0.0)
            variance = self._coerce_to_float(
                0.0 if raw_var is None else raw_var, "utility_variance"
            )
            decision_path = data.get("decision_path", "INVESTMENT")

            # Build components from available data with type coercion
            # Guard explicit None from dict.get() (JSON null) before coercion
            def _comp(key: str) -> float:
                v = data.get(key, 0.0)
                return self._coerce_to_float(0.0 if v is None else v, key)

            components = UtilityComponents(
                profit_high_conf=_comp("profit_high_conf"),
                value_low_conf=_comp("value_low_conf"),
                risk_adjustment=_comp("risk_adjustment"),
                complexity_tax=_comp("complexity_tax"),
                opex_delta=_comp("opex_delta"),
            )

            utility_result = UtilityResult(
                raw=raw_utility,
                variance=variance,
                lcb=utility_lcb,
                components=components,
                decision_path=decision_path,
            )

        # Use GateEvaluator public method for proper utility LCB check
        gate_result = self.gate_evaluator.evaluate_utility_gate(utility_result)

        return GateAnalysis(
            gate_name="utility",
            passed=gate_result.passed,
            value=gate_result.value,
            threshold=gate_result.threshold,
            confidence=(
                gate_result.confidence if gate_result.confidence is not None else 0.0
            ),
            notes=gate_result.message,
        )

    def _generate_recommendations(
        self,
        analyses: list[GateAnalysis],
    ) -> list[str]:
        """Generate recommendations based on gate analyses."""
        recommendations = []

        for analysis in analyses:
            if not analysis.passed:
                if analysis.gate_name == "complexity":
                    recommendations.append(
                        "Complexity below floor - proposal cannot proceed without restructuring",
                    )
                elif analysis.gate_name == "risk":
                    recommendations.append(
                        f"Risk delta {analysis.value:.2f} exceeds threshold - consider risk mitigation strategies",
                    )
                elif analysis.gate_name == "quality":
                    recommendations.append(
                        "Quality score below minimum - review and improve proposal quality",
                    )

        return recommendations

    def _assess_overall_risk(self, analyses: list[GateAnalysis]) -> str:
        """Assess overall risk level."""
        failed_count = sum(1 for a in analyses if not a.passed)

        if failed_count == 0:
            return "LOW"
        if failed_count <= 2:
            return "MEDIUM"
        return "HIGH"

    def _calculate_confidence(self, analyses: list[GateAnalysis]) -> float:
        """Calculate overall confidence score."""
        if not analyses:
            return 0.0
        finite = [a.confidence for a in analyses if math.isfinite(a.confidence)]
        if not finite:
            return 0.0
        return sum(finite) / len(finite)
