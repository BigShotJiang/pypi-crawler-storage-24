"""Proposer Actor

Initiates proposals and manages proposal lifecycle from the author's perspective.
"""

import logging
import math
import uuid
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from .base import ActionResult, Actor, ActorRole

logger = logging.getLogger(__name__)

# Default history limit for bounded collections (prevents unbounded memory growth)
DEFAULT_HISTORY_LIMIT: int = 10000


@dataclass
class ProposalDraft:
    """Draft proposal created by proposer."""

    title: str
    description: str
    estimated_profit: dict[str, float]  # best, likely, worst
    estimated_risk: dict[str, float]  # best, likely, worst
    complexity_assessment: dict[str, float]  # static, dynamic
    tags: list[str]
    attachments: list[str]


class Proposer(Actor):
    """Proposer actor - initiates and manages proposals.

    Responsibilities:
    - Create proposal drafts
    - Provide estimates (PERT three-point)
    - Submit proposals for evaluation
    - Respond to feedback
    - Withdraw proposals if needed
    """

    def __init__(
        self,
        actor_id: str,
        name: str,
        additional_roles: Optional[set[ActorRole]] = None,
        history_limit: int = DEFAULT_HISTORY_LIMIT,
    ):
        """Initialize proposer.

        Args:
            actor_id: Unique identifier
            name: Display name
            additional_roles: Additional roles beyond proposer
            history_limit: Maximum history entries to retain (prevents memory growth)

        """
        roles = {ActorRole.PROPOSER}
        if additional_roles:
            roles.update(additional_roles)

        super().__init__(
            actor_id=actor_id,
            name=name,
            roles=roles,
        )

        self.active_proposals: deque[str] = deque(maxlen=history_limit)
        self.submitted_proposals: deque[str] = deque(maxlen=history_limit)

    def get_primary_role(self) -> ActorRole:
        """Get the primary role for this actor type."""
        return ActorRole.PROPOSER

    def get_allowed_actions(self) -> list[str]:
        """Get list of actions this actor can perform."""
        return [
            "create_draft",
            "update_draft",
            "submit_proposal",
            "withdraw_proposal",
            "respond_to_feedback",
            "view_status",
        ]

    def _validate_pert_estimates(self, draft: ProposalDraft) -> Optional[str]:
        """Validate PERT estimates for key presence and numeric types.

        Args:
            draft: The proposal draft to validate

        Returns:
            Error message string if validation fails, None if valid

        Raises:
            TypeError: If estimate values are not numeric (int or float)

        """
        required_keys = ("best", "likely", "worst")

        for estimate_name, estimate in [
            ("profit", draft.estimated_profit),
            ("risk", draft.estimated_risk),
        ]:
            # Check key presence
            if not all(k in estimate for k in required_keys):
                return f"Invalid {estimate_name} estimate: requires best, likely, worst"

            # Check numeric types (B1-1 fix: explicit numeric type validation)
            for key in required_keys:
                value = estimate[key]
                # Check for bool first since bool is a subclass of int
                if isinstance(value, bool):
                    raise TypeError(
                        f"Invalid {estimate_name} estimate: '{key}' must be numeric "
                        f"(int or float), got bool"
                    )
                if not isinstance(value, (int, float)):
                    raise TypeError(
                        f"Invalid {estimate_name} estimate: '{key}' must be numeric "
                        f"(int or float), got {type(value).__name__}"
                    )
                if not math.isfinite(float(value)):
                    raise TypeError(
                        f"Invalid {estimate_name} estimate: '{key}' must be finite, "
                        f"got {value}"
                    )

        return None

    def create_draft(
        self,
        draft: ProposalDraft,
    ) -> ActionResult:
        """Create a new proposal draft.

        Args:
            draft: Proposal draft data

        Returns:
            ActionResult with proposal ID if successful

        """
        if not self.capabilities.can_create_proposals:
            return self.record_action(
                "create_draft",
                success=False,
                error="Actor does not have proposal creation capability",
            )

        # Validate draft
        if not draft.title or not draft.description:
            return self.record_action(
                "create_draft",
                success=False,
                error="Title and description are required",
            )

        # Validate PERT estimates (key presence and numeric types)
        # Note: Numeric ordering (best <= likely <= worst) is NOT validated here
        # because "best" for profit means highest value while "worst" means lowest.
        # The proper PERT ordering validation occurs in ThreePointEstimate.__post_init__
        # when estimates are converted to the mathematical model.
        try:
            validation_error = self._validate_pert_estimates(draft)
        except TypeError as exc:
            return self.record_action(
                "create_draft",
                success=False,
                error=str(exc),
            )
        if validation_error:
            return self.record_action(
                "create_draft",
                success=False,
                error=validation_error,
            )

        # Generate proposal ID (in production, this would be from a service)
        proposal_id = str(uuid.uuid4())

        self.active_proposals.append(proposal_id)
        logger.debug(
            f"Proposer {self.actor_id} created draft: proposal_id={proposal_id}, "
            f"title={draft.title!r}"
        )

        return self.record_action(
            "create_draft",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "title": draft.title,
                "status": "draft",
            },
        )

    def submit_proposal(
        self,
        proposal_id: str,
    ) -> ActionResult:
        """Submit a draft proposal for evaluation.

        Note: This method is designed for single-threaded use. Concurrent access
        to the same Proposer instance from multiple threads requires external
        synchronization.

        Args:
            proposal_id: ID of draft to submit

        Returns:
            ActionResult with submission status

        """
        # Check if already submitted first (before attempting removal)
        if proposal_id in self.submitted_proposals:
            return self.record_action(
                "submit_proposal",
                success=False,
                error=f"Proposal {proposal_id} has already been submitted",
            )

        # Use try/except to avoid TOCTOU race between membership check and removal
        try:
            self.active_proposals.remove(proposal_id)
        except ValueError:
            return self.record_action(
                "submit_proposal",
                success=False,
                error=f"Proposal {proposal_id} not found in active drafts",
            )

        self.submitted_proposals.append(proposal_id)
        logger.debug(
            f"Proposer {self.actor_id} submitted proposal: proposal_id={proposal_id}"
        )

        return self.record_action(
            "submit_proposal",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "status": "submitted",
                "submitted_at": datetime.now(timezone.utc).isoformat(),
            },
        )

    def withdraw_proposal(
        self,
        proposal_id: str,
        reason: str,
    ) -> ActionResult:
        """Withdraw a submitted proposal.

        Note: This method is designed for single-threaded use. Concurrent access
        to the same Proposer instance from multiple threads requires external
        synchronization.

        Args:
            proposal_id: ID of proposal to withdraw
            reason: Reason for withdrawal

        Returns:
            ActionResult with withdrawal status

        """
        # Use try/except to avoid TOCTOU race between membership check and removal
        # Try active_proposals first, then submitted_proposals
        try:
            self.active_proposals.remove(proposal_id)
            status = "draft_withdrawn"
        except ValueError:
            # Not in active_proposals, try submitted_proposals
            try:
                self.submitted_proposals.remove(proposal_id)
                status = "submitted_withdrawn"
            except ValueError:
                # Not found in either collection
                return self.record_action(
                    "withdraw_proposal",
                    success=False,
                    error=f"Proposal {proposal_id} not found",
                )

        logger.debug(
            f"Proposer {self.actor_id} withdrew proposal: proposal_id={proposal_id}, "
            f"status={status}, reason={reason!r}"
        )

        return self.record_action(
            "withdraw_proposal",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "status": status,
                "reason": reason,
            },
        )

    def get_proposal_status(self, proposal_id: str) -> dict[str, Any]:
        """Get status of a proposal."""
        if proposal_id in self.active_proposals:
            return {"status": "draft", "proposal_id": proposal_id}
        if proposal_id in self.submitted_proposals:
            return {"status": "submitted", "proposal_id": proposal_id}
        return {"status": "unknown", "proposal_id": proposal_id}
