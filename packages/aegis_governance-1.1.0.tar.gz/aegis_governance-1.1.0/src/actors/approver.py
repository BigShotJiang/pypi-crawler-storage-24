"""Approver Actor

Provides approval decisions and can authorize overrides.
"""

import logging
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Optional

from engine.gates import GateType

from .base import ActionResult, Actor, ActorRole

# Optional BIP-322 crypto dependency (requires btclib)
try:
    from crypto.bip322_provider import BIP322Provider

    _HAS_BTCLIB = True
except ImportError:
    _HAS_BTCLIB = False

if TYPE_CHECKING:
    from crypto.bip322_provider import BIP322Provider

logger = logging.getLogger(__name__)

# Default history limit for bounded collections (prevents unbounded memory growth)
DEFAULT_HISTORY_LIMIT: int = 10000


_VALID_VOTES: frozenset[str] = frozenset({"approve", "reject", "abstain", "defer"})


@dataclass
class ApprovalVote:
    """Vote cast by an approver."""

    proposal_id: str
    vote: str  # "approve", "reject", "abstain", "defer"
    rationale: str
    conditions: Optional[list[str]] = None

    def __post_init__(self) -> None:
        """Validate vote value."""
        if self.vote not in _VALID_VOTES:
            raise ValueError(
                f"Invalid vote {self.vote!r}. Must be one of: {sorted(_VALID_VOTES)}"
            )


@dataclass
class OverrideAuthorization:
    """Override authorization from an approver."""

    proposal_id: str
    failed_gates: list[str]
    justification: str
    signature: str
    expires_at: datetime


class Approver(Actor):
    """Approver actor - provides approval decisions.

    Responsibilities:
    - Vote on proposals in consensus workflows
    - Provide approval/rejection decisions
    - Authorize overrides (if Risk Lead or Security Lead)
    - Set conditions for approval
    """

    def __init__(
        self,
        actor_id: str,
        name: str,
        is_risk_lead: bool = False,
        is_security_lead: bool = False,
        additional_roles: Optional[set[ActorRole]] = None,
        history_limit: int = DEFAULT_HISTORY_LIMIT,
        signature_verifier: Optional["BIP322Provider"] = None,
    ):
        """Initialize approver.

        Args:
            actor_id: Unique identifier
            name: Display name
            is_risk_lead: Whether this approver is a Risk Lead
            is_security_lead: Whether this approver is a Security Lead
            additional_roles: Additional roles beyond approver
            history_limit: Maximum history entries to retain (prevents memory growth)
            signature_verifier: Optional BIP322Provider for cryptographic signature
                validation. When None, authorize_override() falls back to the
                non-empty string check (graceful degradation).

        """
        roles = {ActorRole.APPROVER}
        if is_risk_lead:
            roles.add(ActorRole.RISK_LEAD)
        if is_security_lead:
            roles.add(ActorRole.SECURITY_LEAD)
        if additional_roles:
            roles.update(additional_roles)

        super().__init__(
            actor_id=actor_id,
            name=name,
            roles=roles,
        )

        self.is_risk_lead = is_risk_lead
        self.is_security_lead = is_security_lead
        self.votes_cast: deque[str] = deque(maxlen=history_limit)
        self.overrides_authorized: deque[str] = deque(maxlen=history_limit)
        self.signature_verifier = signature_verifier

    def get_primary_role(self) -> ActorRole:
        """Get the primary role for this actor type."""
        if self.is_risk_lead:
            return ActorRole.RISK_LEAD
        if self.is_security_lead:
            return ActorRole.SECURITY_LEAD
        return ActorRole.APPROVER

    def get_allowed_actions(self) -> list[str]:
        """Get list of actions this actor can perform."""
        actions = [
            "vote",
            "approve",
            "reject",
            "set_conditions",
        ]
        if self.capabilities.can_override:
            actions.extend(["authorize_override", "sign_override"])
        return actions

    def cast_vote(
        self,
        vote: ApprovalVote,
    ) -> ActionResult:
        """Cast a vote on a proposal.

        Args:
            vote: Vote to cast

        Returns:
            ActionResult with vote status

        """
        if not self.capabilities.can_vote:
            return self.record_action(
                "vote",
                success=False,
                error="Actor does not have voting capability",
            )

        # Note: vote.vote validation is handled by ApprovalVote.__post_init__
        # If an invalid vote was passed, the dataclass would have raised ValueError
        self.votes_cast.append(vote.proposal_id)

        return self.record_action(
            "vote",
            success=True,
            result_data={
                "proposal_id": vote.proposal_id,
                "vote": vote.vote,
                "has_conditions": bool(vote.conditions),
            },
        )

    def authorize_override(
        self,
        proposal_id: str,
        failed_gates: list[str],
        justification: str,
        signature: str,
        public_key: Optional[bytes] = None,
    ) -> ActionResult:
        """Authorize an override for failed gates.

        Requires Risk Lead or Security Lead role.

        When a ``signature_verifier`` (BIP322Provider) was supplied at construction
        **and** ``public_key`` is provided, the signature is decoded from BIP-322
        Simple format and cryptographically verified against the message hash
        derived from (proposal_id, justification, failed_gates).

        When no verifier is configured or no public_key is supplied, the method
        falls back to the legacy non-empty string check (graceful degradation).

        Args:
            proposal_id: Proposal to override
            failed_gates: Gates that failed
            justification: Justification for override
            signature: BIP-322 signature (base64-encoded BIP-322 Simple format
                when verifier is active, or any non-empty string for legacy mode)
            public_key: Optional 32-byte x-only public key of the signer.
                Required for cryptographic verification; when omitted the method
                falls back to the non-empty string check.

        Returns:
            ActionResult with override status

        """
        if not self.capabilities.can_override:
            return self.record_action(
                "authorize_override",
                success=False,
                error="Actor does not have override capability",
            )

        if not (self.is_risk_lead or self.is_security_lead):
            return self.record_action(
                "authorize_override",
                success=False,
                error="Override requires Risk Lead or Security Lead role",
            )

        # Validate that complexity gate is not being overridden
        if GateType.COMPLEXITY.value in failed_gates:
            return self.record_action(
                "authorize_override",
                success=False,
                error="Complexity floor cannot be overridden",
            )

        # --- Signature validation ---
        # Path 1: Cryptographic BIP-322 verification (production path)
        if self.signature_verifier is not None and public_key is not None:
            try:
                # Decode the BIP-322 Simple encoded signature to raw bytes
                raw_signature = self.signature_verifier.decode_simple(signature)
            except (ValueError, TypeError) as exc:
                logger.warning(
                    "BIP-322 signature decode failed for proposal %s: %s",
                    proposal_id,
                    type(exc).__name__,
                )
                return self.record_action(
                    "authorize_override",
                    success=False,
                    error="BIP-322 signature decode failed",
                )

            # Reconstruct the canonical message hash that was signed
            message_hash = self.signature_verifier.create_message_hash(
                proposal_id, justification, failed_gates
            )

            # Cryptographic verification
            if not self.signature_verifier.verify(
                raw_signature, message_hash, public_key
            ):
                logger.warning(
                    "BIP-322 signature verification failed for proposal %s",
                    proposal_id,
                )
                return self.record_action(
                    "authorize_override",
                    success=False,
                    error="BIP-322 signature verification failed",
                )

            logger.info(
                "BIP-322 signature verified for proposal %s by %s",
                proposal_id,
                self.actor_id,
            )
        # Path 2: Legacy fallback — non-empty string check
        elif not signature:
            return self.record_action(
                "authorize_override",
                success=False,
                error="Valid BIP-322 signature required",
            )

        self.overrides_authorized.append(proposal_id)

        return self.record_action(
            "authorize_override",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "failed_gates": failed_gates,
                "justification": justification,
                "role": "risk_lead" if self.is_risk_lead else "security_lead",
                "authorized_at": datetime.now(timezone.utc).isoformat(),
                "crypto_verified": (
                    self.signature_verifier is not None and public_key is not None
                ),
            },
        )

    def approve_proposal(
        self,
        proposal_id: str,
        conditions: Optional[list[str]] = None,
    ) -> ActionResult:
        """Directly approve a proposal.

        Args:
            proposal_id: Proposal to approve
            conditions: Optional conditions for approval

        Returns:
            ActionResult with approval status

        """
        if not self.capabilities.can_approve:
            return self.record_action(
                "approve",
                success=False,
                error="Actor does not have approval capability",
            )

        return self.record_action(
            "approve",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "approved_by": self.actor_id,
                "conditions": conditions or [],
                "approved_at": datetime.now(timezone.utc).isoformat(),
            },
        )

    def reject_proposal(
        self,
        proposal_id: str,
        reason: str,
        allow_resubmission: bool = True,
    ) -> ActionResult:
        """Reject a proposal.

        Args:
            proposal_id: Proposal to reject
            reason: Reason for rejection
            allow_resubmission: Whether resubmission is allowed

        Returns:
            ActionResult with rejection status

        """
        if not self.capabilities.can_approve:
            return self.record_action(
                "reject",
                success=False,
                error="Actor does not have approval capability",
            )

        return self.record_action(
            "reject",
            success=True,
            result_data={
                "proposal_id": proposal_id,
                "rejected_by": self.actor_id,
                "reason": reason,
                "allow_resubmission": allow_resubmission,
                "rejected_at": datetime.now(timezone.utc).isoformat(),
            },
        )

    def get_override_status(self) -> dict[str, Any]:
        """Get override authorization status for two-key requirement."""
        return {
            "actor_id": self.actor_id,
            "is_risk_lead": self.is_risk_lead,
            "is_security_lead": self.is_security_lead,
            "can_sign_override": self.capabilities.can_override,
            "overrides_authorized": len(self.overrides_authorized),
        }
