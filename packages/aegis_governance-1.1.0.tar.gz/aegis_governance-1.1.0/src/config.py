"""AEGIS Configuration Management

Provides AegisConfig — the single source of truth for all frozen parameters.
Bridges schema/interface-contract.yaml to Python runtime, eliminating
parameter duplication and drift.

Usage:
    # Use defaults (matches frozen YAML values)
    config = AegisConfig.default()

    # Load from YAML file
    config = AegisConfig.from_yaml("schema/interface-contract.yaml")

    # Create configured components
    evaluator = config.create_gate_evaluator()
    calculator = config.create_utility_calculator()
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from engine.drift import DriftMonitor
    from engine.gates import GateEvaluator
    from engine.utility import UtilityCalculator
    from telemetry.prometheus_exporter import PrometheusExporter


@dataclass(frozen=True)
class KLDriftConfig:
    """KL divergence drift detection thresholds."""

    tau_warning: float = 0.3
    tau_critical: float = 0.5
    window_days: int = 30

    def __post_init__(self) -> None:
        """Validate threshold ordering at construction time."""
        if not math.isfinite(self.tau_warning):
            raise ValueError(f"tau_warning must be finite, got {self.tau_warning}")
        if not math.isfinite(self.tau_critical):
            raise ValueError(f"tau_critical must be finite, got {self.tau_critical}")
        if self.tau_warning >= self.tau_critical:
            raise ValueError(
                f"tau_warning ({self.tau_warning}) must be less than "
                f"tau_critical ({self.tau_critical})"
            )
        if not isinstance(self.window_days, int) or isinstance(self.window_days, bool):
            raise TypeError(
                f"window_days must be an integer, got {type(self.window_days).__name__}"
            )
        if self.window_days < 1:
            raise ValueError(f"window_days must be >= 1, got {self.window_days}")


@dataclass(frozen=True)
class AegisConfig:
    """Central configuration for all AEGIS frozen parameters.

    Default values match schema/interface-contract.yaml exactly.
    Use from_yaml() to load from file, or default() for built-in defaults.

    This is a frozen dataclass — instances are immutable after creation,
    which prevents accidental parameter drift during a session.
    """

    # Epsilon floors (prevent division by zero)
    epsilon_R: float = 0.01
    epsilon_P: float = 0.01

    # Trigger factors (normalized threshold multipliers)
    risk_trigger_factor: float = 2.0
    profit_trigger_factor: float = 2.0

    # Confidence threshold (Bayesian posterior)
    trigger_confidence_prob: float = 0.95

    # Novelty gate (logistic function)
    novelty_N0: float = 0.7
    novelty_k: float = 10.0
    novelty_threshold: float = 0.8

    # Complexity requirements
    complexity_floor: float = 0.5

    # Quality requirements
    quality_min_score: float = 0.7
    quality_no_zero_subscore: bool = True

    # Utility function parameters (Rubric v2.1)
    gamma: float = 0.3
    kappa: float = 1.0
    phi_S: float = 100.0
    phi_D: float = 2000.0
    lcb_alpha: float = 0.05
    migration_budget: float = 5000.0

    # Utility gate threshold
    utility_threshold: float = 0.0

    # KL drift detection
    kl_drift: KLDriftConfig = field(default_factory=KLDriftConfig)

    # Telemetry HTTP sink (optional — None means no HTTP sink)
    telemetry_url: str | None = None

    # MCP rate limiting (requests per minute, 0 = disabled)
    mcp_rate_limit: int = 60

    @classmethod
    def default(cls) -> AegisConfig:
        """Create config with built-in defaults matching frozen YAML values."""
        return cls()

    @classmethod
    def from_yaml(cls, path: str | Path) -> AegisConfig:
        """Load configuration from a YAML file.

        The YAML file should follow the schema/interface-contract.yaml format.
        Only recognized parameter keys are extracted; unknown keys are ignored.

        Args:
            path: Path to YAML configuration file.

        Returns:
            AegisConfig with values from the YAML file.

        Raises:
            FileNotFoundError: If the YAML file doesn't exist.
            ImportError: If PyYAML is not installed.
            ValueError: If YAML content is invalid.
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "PyYAML is required to load YAML config files. "
                "Install it with: pip install aegis-governance[config]"
            ) from None

        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        with open(path) as f:
            raw = yaml.safe_load(f)

        if not isinstance(raw, dict):
            raise ValueError(f"Expected YAML dict, got {type(raw).__name__}")

        return cls._from_raw_dict(raw)

    @staticmethod
    def _parse_kl_drift_dict(raw: dict[str, Any]) -> dict[str, Any]:
        """Parse and validate a kl_drift dict, returning kwargs for KLDriftConfig."""
        _KL_FIELDS = {"tau_warning", "tau_critical", "window_days"}
        for k, v in raw.items():
            if k in _KL_FIELDS and isinstance(v, bool):
                raise TypeError(f"Expected numeric value for {k}, got bool")
        result: dict[str, Any] = {}
        for k, v in raw.items():
            if k in _KL_FIELDS and v is not None:
                if k == "window_days":
                    fv_wd = float(v)
                    if not math.isfinite(fv_wd):
                        raise ValueError(
                            f"Non-finite value for kl_drift.window_days: {v}"
                        )
                    if not fv_wd.is_integer():
                        raise TypeError(
                            f"kl_drift.window_days must be an integer, got {v!r}. "
                            "Fractional values are silently truncated otherwise."
                        )
                    iv = int(fv_wd)
                    if iv < 1:
                        raise ValueError(f"kl_drift.window_days must be >= 1, got {iv}")
                    result[k] = iv
                else:
                    fv = float(v)
                    if not math.isfinite(fv):
                        raise ValueError(f"Non-finite value for kl_drift.{k}: {v}")
                    result[k] = fv
        return result

    @staticmethod
    def _parse_flat_novelty(data: dict[str, Any]) -> dict[str, float]:
        """Extract and validate flat novelty gate parameters from data dict."""
        result: dict[str, float] = {}
        for nkey in ("novelty_N0", "novelty_k", "novelty_threshold"):
            if nkey in data and data[nkey] is not None:
                val = data[nkey]
                if isinstance(val, bool):
                    raise TypeError(f"Expected numeric value for {nkey}, got bool")
                fval = float(val)
                if not math.isfinite(fval):
                    raise ValueError(f"Non-finite value for {nkey}: {val}")
                result[nkey] = fval
        return result

    @staticmethod
    def _coerce_bool(key: str, val: Any) -> bool:
        """Coerce a value to bool with strict validation.

        Accepts: bool, str ("true"/"false"/"1"/"0"/"yes"/"no"), int, float.
        Raises ValueError/TypeError for unconvertible values.
        """
        if isinstance(val, bool):
            return val
        if isinstance(val, str):
            _low = val.lower()
            if _low in ("true", "1", "yes"):
                return True
            if _low in ("false", "0", "no"):
                return False
            raise ValueError(f"Cannot convert {key}={val!r} to bool")
        if isinstance(val, (int, float)):
            if not math.isfinite(float(val)):
                raise ValueError(f"Non-finite value for bool field {key}: {val}")
            return bool(val)
        raise TypeError(f"Expected bool for {key}, got {type(val).__name__}")

    @staticmethod
    def _parse_flat_numeric(
        data: dict[str, Any],
        flat_keys: set[str],
        bool_allowed: set[str],
    ) -> dict[str, Any]:
        """Extract and validate flat numeric parameters from a dict.

        Handles bool rejection, string-to-float coercion, and NaN/Inf validation.
        """
        result: dict[str, Any] = {}
        for key in flat_keys:
            if key in data and data[key] is not None:
                val = data[key]
                if key in bool_allowed:
                    result[key] = AegisConfig._coerce_bool(key, val)
                    continue
                if isinstance(val, bool):
                    raise TypeError(f"Expected numeric value for {key}, got bool")
                if isinstance(val, str):
                    try:
                        fval = float(val)
                    except (ValueError, TypeError):
                        raise ValueError(  # noqa: B904
                            f"Cannot convert {key}={val!r} to float"
                        )
                    if not math.isfinite(fval):
                        raise ValueError(f"Non-finite value for {key}: {val}")
                    val = fval
                elif isinstance(val, (int, float)):
                    if not math.isfinite(float(val)):
                        raise ValueError(f"Non-finite value for {key}: {val}")
                else:
                    raise TypeError(
                        f"Expected numeric value for {key}, got {type(val).__name__}"
                    )
                result[key] = val
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AegisConfig:
        """Create config from a flat dictionary of parameter values.

        Args:
            data: Dictionary with parameter names as keys.

        Returns:
            AegisConfig with values from the dictionary.
        """
        _FLAT_KEYS = {
            "epsilon_R",
            "epsilon_P",
            "risk_trigger_factor",
            "profit_trigger_factor",
            "trigger_confidence_prob",
            "complexity_floor",
            "quality_min_score",
            "quality_no_zero_subscore",
            "gamma",
            "kappa",
            "phi_S",
            "phi_D",
            "lcb_alpha",
            "migration_budget",
            "utility_threshold",
        }
        _FLAT_BOOL_ALLOWED = {"quality_no_zero_subscore"}

        kwargs = cls._parse_flat_numeric(data, _FLAT_KEYS, _FLAT_BOOL_ALLOWED)

        # Novelty gate (flat or nested) — extracted to helper for PLR0912
        kwargs.update(cls._parse_flat_novelty(data))

        # KL drift (flat or nested) — filter to recognized fields only
        if "kl_drift" in data and isinstance(data["kl_drift"], dict):
            kwargs["kl_drift"] = KLDriftConfig(
                **cls._parse_kl_drift_dict(data["kl_drift"])
            )

        if "telemetry_url" in data and data["telemetry_url"] is not None:
            kwargs["telemetry_url"] = str(data["telemetry_url"])

        if "mcp_rate_limit" in data and data["mcp_rate_limit"] is not None:
            kwargs["mcp_rate_limit"] = cls._parse_mcp_rate_limit(data["mcp_rate_limit"])

        return cls(**kwargs)

    @staticmethod
    def _extract_nested_floats(
        section: dict[str, Any],
        mapping: dict[str, str],
    ) -> dict[str, float]:
        """Extract float values from a nested YAML section.

        Args:
            section: Nested dict from YAML (e.g., novelty_gate, utility).
            mapping: Maps YAML key → AegisConfig field name.

        Returns:
            Dict of AegisConfig field names to float values.
        """
        result: dict[str, float] = {}
        for yaml_key, config_key in mapping.items():
            if yaml_key in section and section[yaml_key] is not None:
                val = section[yaml_key]
                if isinstance(val, bool):
                    raise TypeError(f"Expected numeric value for {yaml_key}, got bool")
                fval = float(val)
                if not math.isfinite(fval):
                    raise ValueError(f"Non-finite value for {yaml_key}: {val}")
                result[config_key] = fval
        return result

    @classmethod
    def _from_raw_dict(cls, raw: dict[str, Any]) -> AegisConfig:
        """Parse the interface-contract.yaml format into AegisConfig."""
        params = raw.get("parameters", raw)
        kwargs: dict[str, Any] = {}

        # Direct flat parameters
        _DIRECT = [
            "epsilon_R",
            "epsilon_P",
            "risk_trigger_factor",
            "profit_trigger_factor",
            "trigger_confidence_prob",
            "complexity_floor",
            "quality_min_score",
            "quality_no_zero_subscore",
            "utility_threshold",
        ]
        _BOOL_ALLOWED = {"quality_no_zero_subscore"}
        for key in _DIRECT:
            if key in params and params[key] is not None:
                val = params[key]
                if key in _BOOL_ALLOWED:
                    kwargs[key] = cls._coerce_bool(key, val)
                    continue
                if isinstance(val, bool):
                    raise TypeError(f"Expected numeric value for {key}, got bool")
                # Coerce string values to float (YAML safe_load produces
                # strings for quoted numerics like "0.01").
                if isinstance(val, str):
                    val = float(val)  # raises ValueError for non-numeric
                if not isinstance(val, (int, float)):
                    raise TypeError(
                        f"Expected numeric value for {key}, "
                        f"got {type(val).__name__}"
                    )
                if not math.isfinite(float(val)):
                    raise ValueError(f"Non-finite value for {key}: {val}")
                kwargs[key] = val

        # Nested YAML sections: (section_key, {yaml_key: config_field})
        _NESTED_SECTIONS = [
            (
                "novelty_gate",
                {
                    "N0": "novelty_N0",
                    "k": "novelty_k",
                    "output_threshold": "novelty_threshold",
                },
            ),
            (
                "utility",
                {
                    "gamma": "gamma",
                    "kappa": "kappa",
                    "lcb_alpha": "lcb_alpha",
                    "theta": "utility_threshold",
                },
            ),
            ("complexity_tax", {"phi_S": "phi_S", "phi_D": "phi_D"}),
            ("refactoring_path", {"migration_budget": "migration_budget"}),
        ]
        for section_key, mapping in _NESTED_SECTIONS:
            section = params.get(section_key, {})
            if isinstance(section, dict):
                kwargs.update(cls._extract_nested_floats(section, mapping))

        # KL drift (nested in YAML, produces sub-dataclass)
        # BH17-L2: reuse _parse_kl_drift_dict for NaN/Inf validation parity
        kl = params.get("kl_drift", {})
        if isinstance(kl, dict) and kl:
            kl_kwargs = cls._parse_kl_drift_dict(kl)
            kwargs["kl_drift"] = KLDriftConfig(**kl_kwargs)

        # Telemetry URL (top-level, not inside parameters)
        telemetry_url = raw.get("telemetry_url")
        if telemetry_url is not None:
            kwargs["telemetry_url"] = str(telemetry_url)

        # MCP rate limit (top-level or inside parameters)
        mcp_rate_limit = raw.get("mcp_rate_limit", params.get("mcp_rate_limit"))
        if mcp_rate_limit is not None:
            kwargs["mcp_rate_limit"] = cls._parse_mcp_rate_limit(mcp_rate_limit)

        return cls(**kwargs)

    @staticmethod
    def _parse_mcp_rate_limit(value: Any) -> int:
        """Validate and parse mcp_rate_limit from raw config value."""
        if isinstance(value, bool):
            raise TypeError("Expected integer value for mcp_rate_limit, got bool")
        fv = float(value)
        if not math.isfinite(fv):
            raise ValueError(f"Non-finite value for mcp_rate_limit: {value}")
        if not fv.is_integer():
            raise TypeError(
                f"mcp_rate_limit must be an integer, got {value!r}. "
                "Fractional values are silently truncated otherwise."
            )
        return max(0, int(fv))

    def create_drift_monitor(self) -> DriftMonitor:
        """Create a DriftMonitor configured with these KL drift parameters.

        Returns:
            Configured DriftMonitor instance (baseline not set — caller must
            call set_baseline() before evaluating).
        """
        from engine.drift import DriftMonitor as _DriftMonitor

        return _DriftMonitor(
            tau_warning=self.kl_drift.tau_warning,
            tau_critical=self.kl_drift.tau_critical,
            window_days=self.kl_drift.window_days,
        )

    def create_gate_evaluator(
        self,
        prometheus_exporter: PrometheusExporter | None = None,
    ) -> GateEvaluator:
        """Create a GateEvaluator configured with these parameters.

        Args:
            prometheus_exporter: Optional Prometheus metrics exporter.

        Returns:
            Configured GateEvaluator instance.
        """
        from engine.gates import GateEvaluator as _GateEvaluator

        return _GateEvaluator(
            epsilon_R=self.epsilon_R,
            epsilon_P=self.epsilon_P,
            risk_trigger_factor=self.risk_trigger_factor,
            profit_trigger_factor=self.profit_trigger_factor,
            trigger_confidence_prob=self.trigger_confidence_prob,
            novelty_N0=self.novelty_N0,
            novelty_k=self.novelty_k,
            novelty_threshold=self.novelty_threshold,
            complexity_floor=self.complexity_floor,
            quality_min_score=self.quality_min_score,
            quality_no_zero_subscore=self.quality_no_zero_subscore,
            utility_threshold=self.utility_threshold,
            prometheus_exporter=prometheus_exporter,
        )

    def create_utility_calculator(self) -> UtilityCalculator:
        """Create a UtilityCalculator configured with these parameters.

        Returns:
            Configured UtilityCalculator instance.
        """
        from engine.utility import UtilityCalculator as _UtilityCalculator

        return _UtilityCalculator(
            gamma=self.gamma,
            kappa=self.kappa,
            phi_S=self.phi_S,
            phi_D=self.phi_D,
            lcb_alpha=self.lcb_alpha,
            migration_budget=self.migration_budget,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize config to a flat dictionary.

        Returns:
            Dictionary of all parameter values.
        """
        return {
            "epsilon_R": self.epsilon_R,
            "epsilon_P": self.epsilon_P,
            "risk_trigger_factor": self.risk_trigger_factor,
            "profit_trigger_factor": self.profit_trigger_factor,
            "trigger_confidence_prob": self.trigger_confidence_prob,
            "novelty_N0": self.novelty_N0,
            "novelty_k": self.novelty_k,
            "novelty_threshold": self.novelty_threshold,
            "complexity_floor": self.complexity_floor,
            "quality_min_score": self.quality_min_score,
            "quality_no_zero_subscore": self.quality_no_zero_subscore,
            "gamma": self.gamma,
            "kappa": self.kappa,
            "phi_S": self.phi_S,
            "phi_D": self.phi_D,
            "lcb_alpha": self.lcb_alpha,
            "migration_budget": self.migration_budget,
            "utility_threshold": self.utility_threshold,
            "kl_drift": {
                "tau_warning": self.kl_drift.tau_warning,
                "tau_critical": self.kl_drift.tau_critical,
                "window_days": self.kl_drift.window_days,
            },
            "telemetry_url": self.telemetry_url,
            "mcp_rate_limit": self.mcp_rate_limit,
        }
