"""Lightweight HTTP Metrics Server for Prometheus Scraping

Exposes /metrics endpoint serving Prometheus text format.
Uses stdlib http.server -- zero additional dependencies.

Usage:
    >>> from telemetry.metrics_server import MetricsServer
    >>> server = MetricsServer(port=9090)
    >>> server.start()  # Runs in background thread
    >>> # ... later ...
    >>> server.stop()
"""

import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Optional

from telemetry.prometheus_exporter import get_metrics

logger = logging.getLogger(__name__)


class _ReuseAddrHTTPServer(HTTPServer):
    """HTTPServer subclass with SO_REUSEADDR enabled (T-4 fix).

    Prevents 'Address already in use' errors on rapid restart cycles.
    """

    allow_reuse_address = True


class _MetricsHandler(BaseHTTPRequestHandler):
    """HTTP handler that serves Prometheus metrics on /metrics."""

    def do_GET(self) -> None:
        """Handle GET request."""
        if self.path == "/metrics":
            try:
                metrics_data = get_metrics()
            except (
                Exception
            ):  # Intentional: HTTP server must return 500, not crash thread
                logger.exception("Failed to collect metrics")
                self.send_response(500)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
            self.send_header("Content-Length", str(len(metrics_data)))
            self.end_headers()
            self.wfile.write(metrics_data)
        elif self.path == "/health":
            body = b'{"status": "healthy"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format: str, *args: object) -> None:
        """Redirect HTTP logs to Python logger instead of stderr."""
        logger.debug(format, *args)


class MetricsServer:
    """Lightweight HTTP server exposing /metrics for Prometheus.

    Runs in a background daemon thread so it doesn't block the main process.

    Args:
        host: Bind address (default: localhost)
        port: Port number (default: 9090)
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 9090) -> None:
        self._host = host
        self._port = port
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()  # Thread safety for start/stop (T-4 fix)

    @property
    def is_running(self) -> bool:
        """Check if server is running."""
        return self._thread is not None and self._thread.is_alive()

    @property
    def address(self) -> str:
        """Return server address string."""
        return f"http://{self._host}:{self._port}"

    def start(self) -> None:
        """Start the metrics server in a background thread.

        Thread-safe: uses lock to prevent concurrent start/stop (T-4 fix).
        """
        with self._lock:
            if self.is_running:
                logger.warning("Metrics server already running on %s", self.address)
                return

            self._server = _ReuseAddrHTTPServer(
                (self._host, self._port), _MetricsHandler
            )
            self._thread = threading.Thread(
                target=self._server.serve_forever,
                name="aegis-metrics-server",
                daemon=True,
            )
            self._thread.start()
            logger.info("Metrics server started on %s/metrics", self.address)

    def stop(self) -> None:
        """Stop the metrics server.

        Thread-safe: uses lock to prevent concurrent start/stop (T-4 fix).
        Lock is released before join() to avoid blocking concurrent start().
        """
        with self._lock:
            server = self._server
            thread = self._thread
            self._server = None
            self._thread = None
        # Shutdown and join outside the lock so a concurrent start() is not blocked
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None:
            thread.join(timeout=5)
        logger.info("Metrics server stopped")
