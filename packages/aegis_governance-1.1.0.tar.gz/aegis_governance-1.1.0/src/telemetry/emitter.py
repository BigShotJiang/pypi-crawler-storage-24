"""Telemetry Emitter

Emits structured telemetry events to configured sinks.
"""

import json
import logging
import math
import threading
import time
import uuid
import warnings
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Optional, Union
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


class EventType(str, Enum):
    """Types of telemetry events."""

    # Proposal lifecycle
    PROPOSAL_SUBMITTED = "proposal.submitted"
    PROPOSAL_EVALUATED = "proposal.evaluated"
    PROPOSAL_APPROVED = "proposal.approved"
    PROPOSAL_REJECTED = "proposal.rejected"

    # Gate events
    GATE_EVALUATED = "gate.evaluated"
    GATE_PASSED = "gate.passed"
    GATE_FAILED = "gate.failed"

    # Override events
    OVERRIDE_REQUESTED = "override.requested"
    OVERRIDE_APPROVED = "override.approved"
    OVERRIDE_REJECTED = "override.rejected"

    # Execution events
    EXECUTION_STARTED = "execution.started"
    EXECUTION_COMPLETED = "execution.completed"
    EXECUTION_FAILED = "execution.failed"
    EXECUTION_ROLLED_BACK = "execution.rolled_back"

    # Drift events
    DRIFT_DETECTED = "drift.detected"
    DRIFT_WARNING = "drift.warning"
    DRIFT_CRITICAL = "drift.critical"

    # Drift policy enforcement
    DRIFT_POLICY_ENFORCED = "drift.policy_enforced"

    # Shadow mode events
    SHADOW_EVALUATION = "shadow.evaluation"

    # MCP audit events
    MCP_TOOL_INVOCATION = "mcp.tool_invocation"

    # System events
    CALIBRATION_STARTED = "calibration.started"
    CALIBRATION_COMPLETED = "calibration.completed"
    THRESHOLD_UPDATED = "threshold.updated"


@dataclass
class TelemetryEvent:
    """Structured telemetry event."""

    event_id: str
    event_type: EventType
    timestamp: datetime
    source: str
    payload: dict[str, Any]
    correlation_id: Optional[str] = None
    parent_event_id: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        """Serialize event to JSON."""
        return json.dumps(
            {
                "event_id": self.event_id,
                "event_type": self.event_type.value,
                "timestamp": self.timestamp.isoformat(),
                "source": self.source,
                "payload": self.payload,
                "correlation_id": self.correlation_id,
                "parent_event_id": self.parent_event_id,
                "metadata": self.metadata,
            },
        )


# Type alias for event sinks
EventSink = Callable[[TelemetryEvent], None]


class TelemetryEmitter:
    """Emit telemetry events to configured sinks.

    Supports multiple sinks for different destinations:
    - Console (development)
    - File (local storage)
    - HTTP (remote collection)
    - Queue (async processing)

    Note:
        This class is NOT thread-safe. The `event_count` attribute is
        incremented without synchronization, which may cause slight
        inaccuracies under concurrent access. For thread-safe event
        counting in production, use external metrics (e.g., Prometheus).
    """

    def __init__(
        self,
        source: str,
        environment: str = "production",
        default_correlation_id: Optional[str] = None,
    ):
        """Initialize emitter.

        Args:
            source: Source identifier for events
            environment: Deployment environment
            default_correlation_id: Default correlation ID for event chains

        """
        self.source = source
        self.environment = environment
        self.default_correlation_id = default_correlation_id

        self.sinks: list[EventSink] = []
        self.event_count = 0
        self.last_event_id: Optional[str] = None

    def add_sink(self, sink: EventSink) -> None:
        """Add an event sink."""
        self.sinks.append(sink)

    def remove_sink(self, sink: EventSink) -> bool:
        """Remove an event sink."""
        if sink in self.sinks:
            self.sinks.remove(sink)
            return True
        return False

    def emit(
        self,
        event_type: EventType,
        payload: dict[str, Any],
        correlation_id: Optional[str] = None,
        parent_event_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> TelemetryEvent:
        """Emit a telemetry event.

        Args:
            event_type: Type of event
            payload: Event payload data
            correlation_id: Correlation ID for event chain
            parent_event_id: Parent event ID if this is a child event
            metadata: Additional metadata

        Returns:
            Emitted TelemetryEvent

        """
        event = TelemetryEvent(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            timestamp=datetime.now(timezone.utc),
            source=self.source,
            payload=payload,
            correlation_id=(
                correlation_id
                if correlation_id is not None
                else self.default_correlation_id
            ),
            parent_event_id=(
                parent_event_id
                if parent_event_id is not None
                else (self.last_event_id if self.default_correlation_id else None)
            ),
            metadata={
                "environment": self.environment,
                "event_number": self.event_count,
                **(metadata or {}),
            },
        )

        # Send to all sinks
        # Initialize sink_errors list once before loop to avoid repeated get() calls
        sink_errors: list[str] = []
        for sink in self.sinks:
            try:
                sink(event)
            except (
                Exception
            ) as e:  # Intentional: sink failure must not break event emission
                # Log sink errors to metadata for debugging
                sink_errors.append(str(e))

        # Only add sink_errors to metadata if there were any errors
        if sink_errors:
            event.metadata["sink_errors"] = sink_errors

        self.event_count += 1
        self.last_event_id = event.event_id

        return event

    def emit_proposal_submitted(
        self,
        proposal_id: str,
        author_id: str,
        summary: str,
        **kwargs: Any,
    ) -> TelemetryEvent:
        """Emit proposal submitted event."""
        return self.emit(
            EventType.PROPOSAL_SUBMITTED,
            payload={
                "proposal_id": proposal_id,
                "author_id": author_id,
                "summary": summary,
                **kwargs,
            },
        )

    def emit_gate_evaluated(
        self,
        proposal_id: str,
        gate_name: str,
        passed: bool,
        value: float,
        threshold: float,
        **kwargs: Any,
    ) -> TelemetryEvent:
        """Emit gate evaluated event."""
        event_type = EventType.GATE_PASSED if passed else EventType.GATE_FAILED

        return self.emit(
            event_type,
            payload={
                "proposal_id": proposal_id,
                "gate_name": gate_name,
                "passed": passed,
                "value": value,
                "threshold": threshold,
                **kwargs,
            },
        )

    def emit_proposal_decision(
        self,
        proposal_id: str,
        decision: str,
        rationale: str,
        actor_id: str,
        **kwargs: Any,
    ) -> TelemetryEvent:
        """Emit proposal decision event."""
        if decision == "approved":
            event_type = EventType.PROPOSAL_APPROVED
        elif decision == "rejected":
            event_type = EventType.PROPOSAL_REJECTED
        else:
            event_type = EventType.PROPOSAL_EVALUATED

        return self.emit(
            event_type,
            payload={
                "proposal_id": proposal_id,
                "decision": decision,
                "rationale": rationale,
                "actor_id": actor_id,
                **kwargs,
            },
        )

    def emit_drift_event(
        self,
        drift_status: str,
        kl_divergence: float,
        threshold: float,
        action: str,
        **kwargs: Any,
    ) -> TelemetryEvent:
        """Emit drift detection event."""
        if drift_status == "critical":
            event_type = EventType.DRIFT_CRITICAL
        elif drift_status == "warning":
            event_type = EventType.DRIFT_WARNING
        else:
            event_type = EventType.DRIFT_DETECTED

        return self.emit(
            event_type,
            payload={
                "drift_status": drift_status,
                "kl_divergence": kl_divergence,
                "threshold": threshold,
                "action": action,
                **kwargs,
            },
        )

    def emit_override_requested(
        self,
        proposal_id: str,
        requester_id: str,
        failed_gates: list[str],
        justification: str,
        **kwargs: Any,
    ) -> TelemetryEvent:
        """Emit override requested event.

        Payload keys use schema-compliant ``override_`` prefix
        (see ``schema/telemetry-schema.yaml``).
        """
        return self.emit(
            EventType.OVERRIDE_REQUESTED,
            payload={
                "proposal_id": proposal_id,
                "override_requester_id": requester_id,
                "override_failed_gates": failed_gates,
                "override_justification": justification,
                **kwargs,
            },
        )

    def emit_override_approved(
        self,
        proposal_id: str,
        risk_lead_id: str,
        security_lead_id: str,
        **kwargs: Any,
    ) -> TelemetryEvent:
        """Emit override approved event.

        Payload keys use schema-compliant ``override_`` prefix
        (see ``schema/telemetry-schema.yaml``).
        """
        return self.emit(
            EventType.OVERRIDE_APPROVED,
            payload={
                "proposal_id": proposal_id,
                "override_risk_lead_signer_id": risk_lead_id,
                "override_security_lead_signer_id": security_lead_id,
                **kwargs,
            },
        )

    def emit_override_rejected(
        self,
        proposal_id: str,
        rejected_by: str,
        reason: str,
        **kwargs: Any,
    ) -> TelemetryEvent:
        """Emit override rejected event.

        Payload keys use schema-compliant ``override_`` prefix
        (see ``schema/telemetry-schema.yaml``).
        """
        return self.emit(
            EventType.OVERRIDE_REJECTED,
            payload={
                "proposal_id": proposal_id,
                "override_rejected_by": rejected_by,
                "override_rejection_reason": reason,
                **kwargs,
            },
        )

    def emit_shadow_evaluation(
        self,
        decision_id: str,
        status: str,
        gates_passed: int,
        gates_total: int,
        drift_result: Optional[dict[str, Any]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> TelemetryEvent:
        """Emit shadow evaluation event.

        Args:
            decision_id: Decision identifier
            status: Decision status
            gates_passed: Number of gates that passed
            gates_total: Total gates evaluated
            drift_result: Optional drift evaluation data
            metadata: Optional additional metadata
        """
        payload: dict[str, Any] = {
            "decision_id": decision_id,
            "status": status,
            "gates_passed": gates_passed,
            "gates_total": gates_total,
        }
        if drift_result is not None:
            # Namespace drift keys under "drift" to prevent key collision
            # with top-level "status" field (BH21-L3).
            payload["drift"] = drift_result

        return self.emit(
            EventType.SHADOW_EVALUATION,
            payload=payload,
            correlation_id=decision_id,
            metadata=metadata,
        )

    def emit_mcp_invocation(
        self,
        tool_name: str,
        params_hash: str,
        decision: str,
        latency_ms: float,
        *,
        caller_id: str = "",
        deny_reason: str = "",
        correlation_id: Optional[str] = None,
    ) -> TelemetryEvent:
        """Emit MCP tool invocation audit event (CoSAI MCP-T12, RFC-006 aligned)."""
        # BH41-L2: Use explicit None-sentinel (not `or`) to distinguish "no
        # correlation provided" from an explicitly-passed empty string.
        # `correlation_id or self.default_correlation_id` treats "" as falsy,
        # silently linking audit events to the active correlation chain.
        # Mirrors BH40-L4 fix pattern used in get_decision_history().
        effective_cid = (
            correlation_id
            if correlation_id is not None
            else self.default_correlation_id
        )
        return self.emit(
            event_type=EventType.MCP_TOOL_INVOCATION,
            payload={
                "tool_name": tool_name,
                "params_hash": params_hash,
                "decision": decision,
                "latency_ms": round(latency_ms, 2),
                "caller_id": caller_id,
                "deny_reason": deny_reason,
            },
            correlation_id=effective_cid,
        )

    def start_correlation(self) -> str:
        """Start a new correlation chain and return the ID."""
        correlation_id = str(uuid.uuid4())
        self.default_correlation_id = correlation_id
        return correlation_id

    def end_correlation(self) -> None:
        """End the current correlation chain."""
        self.default_correlation_id = None
        self.last_event_id = None


# Convenience sinks
def console_sink(event: TelemetryEvent) -> None:
    """Print event to console."""
    print(f"[{event.timestamp.isoformat()}] {event.event_type.value}: {event.payload}")


def file_sink(filepath: str) -> EventSink:
    """Create a file sink.

    Note:
        This is a development utility. File writes are not locked,
        which may cause interleaved output under concurrent writes.
        For production, use a proper logging framework or queue-based sink.

    Args:
        filepath: Path to the output file

    Returns:
        EventSink function that appends events to the file

    Raises:
        ValueError: If filepath is empty or parent directory does not exist.
    """
    # TD-1: Validate path at construction time, not at first write
    if not filepath or not filepath.strip():
        raise ValueError("file_sink filepath must be a non-empty string")
    from pathlib import Path

    parent = Path(filepath).resolve().parent
    if not parent.is_dir():
        raise ValueError(f"file_sink parent directory does not exist: {parent}")

    def sink(event: TelemetryEvent) -> None:
        try:
            with open(filepath, "a") as f:
                f.write(event.to_json() + "\n")
        except OSError as e:
            # Warn instead of raising to avoid breaking event emission
            warnings.warn(
                f"file_sink write failed for {filepath}: {e}",
                RuntimeWarning,
                stacklevel=2,
            )

    return sink


def memory_sink(
    events: Union[list[TelemetryEvent], deque[TelemetryEvent]],
    maxlen: Optional[int] = 10000,
) -> EventSink:
    """Create an in-memory sink for testing or debugging.

    Args:
        events: Collection to store events. Can be a list or deque.
            If a list is provided and maxlen is specified, the list
            will be bounded by manually removing oldest events when
            the limit is reached. For optimal performance with bounded
            collections, pass a deque(maxlen=N) directly.
        maxlen: Maximum number of events to retain. Only applied when
            events is a list. Set to None for unbounded growth (not
            recommended for long-running processes). Default: 10000.

    Returns:
        EventSink function that appends events to the collection.

    Note:
        For bounded memory usage in long-running processes, either:
        1. Pass a deque with maxlen set (preferred)
        2. Use this function with a list and maxlen parameter

    Example:
        # Bounded deque (recommended)
        events: deque[TelemetryEvent] = deque(maxlen=1000)
        emitter.add_sink(memory_sink(events))

        # Bounded list
        events: list[TelemetryEvent] = []
        emitter.add_sink(memory_sink(events, maxlen=1000))
    """

    if not isinstance(events, deque) and maxlen is not None:
        if isinstance(maxlen, bool) or not isinstance(maxlen, int):
            raise TypeError(
                f"memory_sink maxlen must be an integer or None, got {type(maxlen).__name__}"
            )
        if maxlen < 1:
            raise ValueError(
                f"memory_sink maxlen must be >= 1 when provided, got {maxlen}"
            )

    def sink(event: TelemetryEvent) -> None:
        # For deques, maxlen is handled automatically by the deque itself
        if isinstance(events, deque):
            events.append(event)
        else:
            # For lists, manually enforce maxlen if specified
            if maxlen is not None and len(events) >= maxlen:
                # Remove oldest event to make room (FIFO eviction)
                del events[0]
            events.append(event)

    return sink


def _validate_sink_url(url: str, *, allow_insecure: bool, class_name: str) -> None:
    """Validate HTTP sink URL scheme.

    Enforces HTTPS by default (CoSAI MCP-T7 transport security).
    Pass ``allow_insecure=True`` for local development only.

    Raises:
        ValueError: If URL is empty, uses a non-http(s) scheme, or uses
            ``http://`` without ``allow_insecure=True``.
    """
    if not url or not url.strip():
        raise ValueError(f"{class_name} url must be a non-empty string")
    url = url.strip()
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()
    if scheme != "https" and not allow_insecure:
        raise ValueError(
            f"{class_name} requires https:// URLs for production use. "
            f"Got {scheme}://. Pass allow_insecure=True for local development."
        )
    if allow_insecure and scheme not in ("http", "https"):
        raise ValueError(
            f"{class_name} url scheme must be http or https, got {scheme!r}"
        )
    if not parsed.hostname:
        raise ValueError(f"{class_name} url must include a hostname")
    if allow_insecure and scheme == "http":
        logger.warning("%s using insecure http:// — local development only", class_name)


class HTTPEventSink:
    """Fire-and-forget HTTP POST sink for individual telemetry events.

    Uses stdlib urllib.request — zero external dependencies.
    Failures are logged but never propagated (telemetry must not crash producer).

    By default, only ``https://`` URLs are accepted (CoSAI MCP-T7).
    Pass ``allow_insecure=True`` to permit ``http://`` for local development.
    """

    def __init__(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        timeout: int = 10,
        *,
        allow_insecure: bool = False,
    ) -> None:
        _validate_sink_url(
            url, allow_insecure=allow_insecure, class_name="HTTPEventSink"
        )
        if isinstance(timeout, bool):
            raise TypeError("HTTPEventSink timeout must be an integer, got bool")
        if timeout < 1:
            raise ValueError(f"HTTPEventSink timeout must be >= 1, got {timeout}")
        self._url = url.strip()
        self._headers: dict[str, str] = {
            "Content-Type": "application/json",
            **(headers or {}),
        }
        self._timeout = timeout

    def __call__(self, event: TelemetryEvent) -> None:
        import urllib.request

        payload = event.to_json().encode("utf-8")
        req = urllib.request.Request(  # noqa: S310
            self._url, data=payload, headers=self._headers, method="POST"
        )
        try:
            with urllib.request.urlopen(  # noqa: S310  # nosec B310
                req, timeout=self._timeout
            ) as resp:
                logger.debug(
                    "HTTPEventSink sent %s: status=%d", event.event_id, resp.status
                )
        except Exception as e:  # Intentional: sink must not crash emission
            logger.error("HTTPEventSink POST failed for %s: %s", self._url, e)

    def __repr__(self) -> str:
        return f"HTTPEventSink(url={self._url!r})"


class BatchHTTPSink:
    """Batching HTTP POST sink for production telemetry.

    Buffers events and flushes as a JSON array on threshold or interval.
    Background daemon thread handles time-based flushing.
    Thread-safe: buffer access protected by ``_lock``.

    By default, only ``https://`` URLs are accepted (CoSAI MCP-T7).
    Pass ``allow_insecure=True`` to permit ``http://`` for local development.
    """

    def __init__(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        timeout: int = 10,
        batch_size: int = 100,
        flush_interval_seconds: int = 60,
        max_retries: int = 1,
        retry_delay_seconds: float = 1.0,
        *,
        allow_insecure: bool = False,
    ) -> None:
        _validate_sink_url(
            url, allow_insecure=allow_insecure, class_name="BatchHTTPSink"
        )
        for _int_name, _int_val in (
            ("batch_size", batch_size),
            ("flush_interval_seconds", flush_interval_seconds),
            ("max_retries", max_retries),
            ("timeout", timeout),
        ):
            if not isinstance(_int_val, int) or isinstance(_int_val, bool):
                raise TypeError(
                    f"BatchHTTPSink {_int_name} must be an integer, "
                    f"got {type(_int_val).__name__}"
                )
        if batch_size < 1:
            raise ValueError(f"BatchHTTPSink batch_size must be >= 1, got {batch_size}")
        if flush_interval_seconds < 1:
            raise ValueError(
                f"BatchHTTPSink flush_interval_seconds must be >= 1, got {flush_interval_seconds}"
            )
        if max_retries < 0:
            raise ValueError(
                f"BatchHTTPSink max_retries must be >= 0, got {max_retries}"
            )
        if timeout < 1:
            raise ValueError(f"BatchHTTPSink timeout must be >= 1, got {timeout}")
        if isinstance(retry_delay_seconds, bool):
            raise TypeError(
                "BatchHTTPSink retry_delay_seconds must be a number, got bool"
            )
        if not math.isfinite(float(retry_delay_seconds)):
            raise ValueError(
                f"BatchHTTPSink retry_delay_seconds must be finite, got {retry_delay_seconds}"
            )
        if retry_delay_seconds < 0:
            raise ValueError(
                f"BatchHTTPSink retry_delay_seconds must be >= 0, got {retry_delay_seconds}"
            )
        self._url = url.strip()
        self._headers: dict[str, str] = {
            "Content-Type": "application/json",
            **(headers or {}),
        }
        self._timeout = timeout
        self._batch_size = batch_size
        self._flush_interval = flush_interval_seconds
        self._max_retries = max_retries
        self._retry_delay = retry_delay_seconds

        self._buffer: deque[str] = deque(maxlen=batch_size * 10)
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Statistics — incremented outside self._lock. This is an accepted risk:
        # CPython GIL makes integer increment atomic at the bytecode level.
        # These counters are informational (observability), not control-flow.
        # See QG60-6 for analysis.
        self.events_sent = 0
        self.events_dropped = 0
        self.flush_count = 0
        self.error_count = 0

    def __call__(self, event: TelemetryEvent) -> None:
        """Buffer event; auto-flush at batch_size threshold."""
        serialized = event.to_json()
        with self._lock:
            buffer_was_full = (
                self._buffer.maxlen is not None
                and len(self._buffer) >= self._buffer.maxlen
            )
            self._buffer.append(serialized)
            if buffer_was_full:
                # deque evicted the oldest event to make room
                self.events_dropped += 1
            should_flush = len(self._buffer) >= self._batch_size
        if should_flush:
            self.flush()

    def start(self) -> None:
        """Start background flush daemon thread."""
        with self._lock:
            if self._running:
                return
            self._running = True
            self._thread = threading.Thread(
                target=self._flush_loop, daemon=True, name="aegis-batch-http-sink"
            )
            self._thread.start()

    def stop(self) -> None:
        """Stop background thread, drain remaining events."""
        with self._lock:
            self._running = False
            thread = self._thread  # extract ref under lock to avoid race with start()
            self._thread = None
        if thread is not None:
            thread.join(timeout=5.0)
        self.flush()

    def flush(self) -> int:
        """Flush buffered events via single HTTP POST. Returns events sent."""
        with self._lock:
            if not self._buffer:
                return 0
            batch = list(self._buffer)
            self._buffer.clear()

        payload = ("[" + ",".join(batch) + "]").encode("utf-8")
        sent = self._send_with_retry(payload, len(batch))

        # QG67-T1: Re-enqueue unsent events on failure to prevent data loss.
        # Without this, events cleared from the buffer are irreversibly lost
        # when _send_with_retry exhausts all retries.
        if sent == 0 and batch:
            with self._lock:
                # Prepend failed batch (older events first) up to buffer capacity.
                for item in reversed(batch):
                    self._buffer.appendleft(item)

        return sent

    def _send_with_retry(self, payload: bytes, event_count: int) -> int:
        """POST with simple retry. Returns number of events sent (0 on failure)."""
        import urllib.request

        for attempt in range(1 + self._max_retries):
            req = urllib.request.Request(  # noqa: S310
                self._url, data=payload, headers=self._headers, method="POST"
            )
            try:
                with urllib.request.urlopen(  # noqa: S310  # nosec B310
                    req, timeout=self._timeout
                ) as resp:
                    logger.debug(
                        "BatchHTTPSink flushed %d events: status=%d",
                        event_count,
                        resp.status,
                    )
                self.events_sent += event_count
                self.flush_count += 1
                return event_count
            except Exception as e:  # Intentional: sink must not crash emission
                self.error_count += 1
                if attempt < self._max_retries:
                    logger.warning(
                        "BatchHTTPSink attempt %d/%d failed for %s: %s",
                        attempt + 1,
                        1 + self._max_retries,
                        self._url,
                        e,
                    )
                    time.sleep(self._retry_delay)
                else:
                    logger.error(
                        "BatchHTTPSink POST failed after %d attempts for %s: %s",
                        1 + self._max_retries,
                        self._url,
                        e,
                    )
                    self.events_dropped += event_count
        return 0

    def _flush_loop(self) -> None:
        """Background: sleep in 1s increments, flush at interval."""
        elapsed = 0.0
        while self._running:
            time.sleep(1.0)
            elapsed += 1.0
            if elapsed >= self._flush_interval:
                self.flush()
                elapsed = 0.0
        # Final drain on shutdown is handled by stop()

    @property
    def pending_count(self) -> int:
        """Number of events buffered but not yet flushed."""
        with self._lock:
            return len(self._buffer)

    def __repr__(self) -> str:
        return (
            f"BatchHTTPSink(url={self._url!r}, "
            f"batch_size={self._batch_size}, pending={self.pending_count})"
        )


def http_sink(
    url: str,
    *,
    headers: Optional[dict[str, str]] = None,
    timeout: int = 10,
    batch_size: Optional[int] = None,
    flush_interval_seconds: int = 60,
    allow_insecure: bool = False,
) -> EventSink:
    """Create an HTTP sink for telemetry events.

    With ``batch_size`` → returns :class:`BatchHTTPSink` (call ``.start()``
    to enable background flushing).  Without → returns :class:`HTTPEventSink`.

    By default, only ``https://`` URLs are accepted (CoSAI MCP-T7).
    Pass ``allow_insecure=True`` to permit ``http://`` for local development.

    Args:
        url: Target HTTP endpoint URL.
        headers: Extra HTTP headers (e.g., ``{"Authorization": "Bearer ..."}``)
        timeout: HTTP request timeout in seconds.
        batch_size: If set, enables batching with this threshold.
        flush_interval_seconds: Interval for time-based flushes (batch mode only).
        allow_insecure: If True, allow ``http://`` URLs (local dev only).

    Returns:
        Callable ``EventSink``.
    """
    if batch_size is not None:
        return BatchHTTPSink(
            url=url,
            headers=headers,
            timeout=timeout,
            batch_size=batch_size,
            flush_interval_seconds=flush_interval_seconds,
            allow_insecure=allow_insecure,
        )
    return HTTPEventSink(
        url=url, headers=headers, timeout=timeout, allow_insecure=allow_insecure
    )
