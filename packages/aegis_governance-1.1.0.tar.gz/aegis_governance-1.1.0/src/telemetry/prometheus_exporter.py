"""Prometheus Metrics Exporter for AEGIS

Provides Prometheus-compatible metrics for monitoring AEGIS system health,
performance, and decision-making patterns.

Metrics Categories:
    1. Decision Outcomes - Counters for pass/fail by gate type
    2. Latency Tracking - Histograms for operation duration
    3. State Gauges - Current system state (active proposals, drift, etc.)
    4. Workflow Transitions - State machine progression tracking

Usage:
    >>> from telemetry.prometheus_exporter import PrometheusExporter, get_metrics
    >>> exporter = PrometheusExporter()
    >>> exporter.record_gate_evaluation("risk", passed=True, value=1.5, latency=0.023)
    >>> metrics_text = get_metrics()  # Returns Prometheus text format

GAP-L1 Implementation:
    - Phase 1: Exporter foundation + gate/decision/proposal metrics
    - Phase 2: Integration with gates.py, pcw_decide.py, proposal.py
    - Phase 3: Grafana dashboards + alerting rules
"""

from __future__ import annotations

import contextlib
import logging
import math
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)

try:
    from prometheus_client import REGISTRY, Counter, Gauge, Histogram, generate_latest

    _HAS_PROMETHEUS = True
except ImportError:
    _HAS_PROMETHEUS = False
    # Stubs so class body can reference these names at definition time.
    # __init__ guard ensures they are never called when prometheus_client is absent.
    Counter = Gauge = Histogram = Any  # type: ignore[assignment,misc]
    REGISTRY = None  # type: ignore[assignment]
    generate_latest = None  # type: ignore[assignment]

PROMETHEUS_AVAILABLE = _HAS_PROMETHEUS


class PrometheusExporter:
    """Prometheus metrics exporter for AEGIS telemetry.

    Implements RED Method (Rate, Errors, Duration) for monitoring:
    - Rate: Request throughput (decisions_total, proposals_total)
    - Errors: Failed gates, rejected proposals
    - Duration: Latency histograms for all operations

    Metrics cardinality: ~80 series max (8 gates × 10 states)

    Note:
        This class is idempotent - multiple instantiations will reuse
        existing metrics from the global registry rather than causing
        ValueError from duplicate registration. Prefer using get_exporter()
        singleton for normal usage.
    """

    def __init__(self) -> None:
        """Initialize Prometheus metrics collectors.

        Idempotent: If metrics already exist in the registry, reuses them
        instead of creating duplicates. This allows direct instantiation
        for testing with isolated registries while preventing ValueError
        from duplicate metric registration.

        Raises:
            ImportError: If prometheus_client is not installed.
        """
        if not _HAS_PROMETHEUS:
            raise ImportError(
                "prometheus_client is required for Prometheus metrics. "
                "Install with: pip install aegis-governance[telemetry]"
            )
        # Instance-level metrics cache to avoid repeated registry lookups (T-3 fix)
        self._metrics: dict[str, object] = {}

        # ===== DECISION METRICS =====

        self.decisions_total = self._get_or_create_counter(
            "aegis_decisions_total",
            "Total decision outcomes by gate type",
            ["decision", "gate"],
        )
        # Labels:
        #     decision: pass | fail
        #     gate: risk | profit | novelty | complexity | quality | utility
        # Expected cardinality: 2 x 6 = 12 series

        self.gates_evaluated_total = self._get_or_create_counter(
            "aegis_gates_evaluated_total",
            "Total gate evaluations performed",
            ["gate", "passed"],
        )
        # Labels:
        #     gate: risk | profit | novelty | complexity | quality | utility
        #     passed: true | false
        # Expected cardinality: 6 x 2 = 12 series

        # ===== LATENCY METRICS =====

        self.latency_seconds = self._get_or_create_histogram(
            "aegis_latency_seconds",
            "Operation latency in seconds",
            ["operation", "gate"],
            buckets=[0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0],
        )
        # Labels:
        #     operation: gate_evaluation | decision | state_transition
        #     gate: risk | profit | novelty | complexity | quality | utility
        # Buckets optimized for <100ms p99 target
        # Expected cardinality: 3 x 6 = 18 series

        self.decision_latency_seconds = self._get_or_create_histogram(
            "aegis_decision_latency_seconds",
            "End-to-end decision latency in seconds",
            ["status", "mode"],
            buckets=[0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
        )
        # Labels:
        #     status: approved | rejected | blocked
        #     mode: production | shadow
        # Expected cardinality: 3 x 2 = 6 series

        # ===== PROPOSAL METRICS =====

        self.proposals_total = self._get_or_create_counter(
            "aegis_proposals_total",
            "Total proposals by state",
            ["state"],
        )
        # Labels:
        #     state: draft | submitted | evaluating | approved | rejected | executing | completed | failed
        # Expected cardinality: 8 series

        self.proposal_transitions_total = self._get_or_create_counter(
            "aegis_proposal_transitions_total",
            "State transitions in proposal workflow",
            ["from_state", "to_state"],
        )
        # Labels:
        #     from_state: draft | submitted | evaluating | approved | rejected | executing | completed | failed
        #     to_state: draft | submitted | evaluating | approved | rejected | executing | completed | failed
        # Expected cardinality: ~20 series (valid transitions only)

        # ===== GAUGE METRICS (Current State) =====

        self.active_proposals = self._get_or_create_gauge(
            "aegis_active_proposals",
            "Number of proposals currently in progress",
        )

        self.kl_divergence = self._get_or_create_gauge(
            "aegis_kl_divergence",
            "Current KL divergence value for drift detection",
        )

        self.drift_status = self._get_or_create_gauge(
            "aegis_drift_status",
            "Drift monitor status",
            ["status"],
        )
        # Labels:
        #     status: normal | warning | critical
        # Expected cardinality: 3 series

        # ===== WORKFLOW METRICS =====

        self.override_requests_total = self._get_or_create_counter(
            "aegis_override_requests_total",
            "Total override requests by outcome",
            ["outcome"],
        )
        # Labels:
        #     outcome: requested | partial | approved | rejected
        # Expected cardinality: 4 series

        self.consensus_votes_total = self._get_or_create_counter(
            "aegis_consensus_votes_total",
            "Total consensus votes cast",
            ["vote_type"],
        )
        # Labels:
        #     vote_type: approve | reject | abstain
        # Expected cardinality: 3 series

        # ===== ERROR METRICS =====

        self.errors_total = self._get_or_create_counter(
            "aegis_errors_total",
            "Total errors by component",
            ["component", "error_type"],
        )
        # Labels:
        #     component: gates | workflows | actors | telemetry
        #     error_type: validation | crypto | timeout | ...
        # Expected cardinality: ~20 series

        # ===== SHADOW MODE METRICS =====

        self.shadow_evaluations_total = self._get_or_create_counter(
            "aegis_shadow_evaluations_total",
            "Total shadow mode evaluations by status",
            ["status"],
        )
        # Labels:
        #     status: proceed | pause | halt | escalate
        # Expected cardinality: 4 series

    # ===== METRIC FACTORY METHODS (Idempotent) =====

    def _get_or_create_counter(
        self,
        name: str,
        documentation: str,
        labelnames: list[str] | None = None,
    ) -> Counter:
        """Get existing counter from registry or create new one.

        Uses instance cache for fast repeated lookups. Falls back to
        registry lookup, then creation (T-3 fix).

        Args:
            name: Metric name
            documentation: Help text for the metric
            labelnames: Optional list of label names

        Returns:
            Counter metric (existing or newly created)
        """
        cached = self._metrics.get(name)
        if cached is not None:
            return cached  # type: ignore[return-value]
        # NOTE: prometheus_client has no public API to retrieve existing metrics
        # by name. Both _names_to_collectors lookup and try/except ValueError on
        # re-creation require private API access. This approach is more explicit
        # and debuggable than catching ValueError from duplicate registration.
        if name in REGISTRY._names_to_collectors:
            metric = REGISTRY._names_to_collectors[name]
            self._metrics[name] = metric
            return metric  # type: ignore[return-value]
        metric = Counter(name, documentation, labelnames=labelnames or [])
        self._metrics[name] = metric
        return metric

    def _get_or_create_histogram(
        self,
        name: str,
        documentation: str,
        labelnames: list[str] | None = None,
        buckets: list[float] | None = None,
    ) -> Histogram:
        """Get existing histogram from registry or create new one.

        Uses instance cache for fast repeated lookups (T-3 fix).

        Args:
            name: Metric name
            documentation: Help text for the metric
            labelnames: Optional list of label names
            buckets: Optional bucket boundaries

        Returns:
            Histogram metric (existing or newly created)
        """
        cached = self._metrics.get(name)
        if cached is not None:
            return cached  # type: ignore[return-value]
        if name in REGISTRY._names_to_collectors:
            metric = REGISTRY._names_to_collectors[name]
            self._metrics[name] = metric
            return metric  # type: ignore[return-value]
        kwargs: dict[str, object] = {"labelnames": labelnames or []}
        if buckets is not None:
            kwargs["buckets"] = buckets
        metric = Histogram(name, documentation, **kwargs)  # type: ignore[arg-type]
        self._metrics[name] = metric
        return metric

    def _get_or_create_gauge(
        self,
        name: str,
        documentation: str,
        labelnames: list[str] | None = None,
    ) -> Gauge:
        """Get existing gauge from registry or create new one.

        Uses instance cache for fast repeated lookups (T-3 fix).

        Args:
            name: Metric name
            documentation: Help text for the metric
            labelnames: Optional list of label names

        Returns:
            Gauge metric (existing or newly created)
        """
        cached = self._metrics.get(name)
        if cached is not None:
            return cached  # type: ignore[return-value]
        if name in REGISTRY._names_to_collectors:
            metric = REGISTRY._names_to_collectors[name]
            self._metrics[name] = metric
            return metric  # type: ignore[return-value]
        metric = Gauge(name, documentation, labelnames=labelnames or [])
        self._metrics[name] = metric
        return metric

    # ===== RECORDING METHODS =====

    def record_gate_evaluation(
        self,
        gate_type: str,
        passed: bool,
        value: float,
        latency: float,
    ) -> None:
        """Record a gate evaluation outcome and latency.

        Args:
            gate_type: Gate identifier (risk, profit, novelty, complexity, quality, utility)
            passed: Whether the gate passed
            value: Gate score/value
            latency: Evaluation duration in seconds

        Example:
            >>> exporter.record_gate_evaluation("risk", passed=True, value=1.5, latency=0.023)

        """
        if not math.isfinite(latency):
            logger.warning(
                "Non-finite latency rejected for gate %s: %s", gate_type, latency
            )
            return
        decision = "pass" if passed else "fail"
        self.decisions_total.labels(decision=decision, gate=gate_type).inc()
        self.gates_evaluated_total.labels(
            gate=gate_type,
            passed=str(passed).lower(),
        ).inc()
        self.latency_seconds.labels(
            operation="gate_evaluation",
            gate=gate_type,
        ).observe(latency)

    def record_decision(
        self,
        status: str,
        gates_passed: int,
        gates_total: int,
        latency: float,
        mode: str = "production",
    ) -> None:
        """Record a complete decision outcome.

        Args:
            status: Decision status (approved, rejected, blocked)
            gates_passed: Number of gates that passed
            gates_total: Total number of gates evaluated
            latency: Total decision duration in seconds
            mode: Evaluation mode ("production" or "shadow")

        Example:
            >>> exporter.record_decision("approved", gates_passed=6, gates_total=6, latency=0.15)

        """
        if not math.isfinite(latency):
            logger.warning(
                "Non-finite decision latency rejected for status %s: %s",
                status,
                latency,
            )
            return
        self.decision_latency_seconds.labels(status=status, mode=mode).observe(latency)

    def record_proposal_state(
        self,
        state: str,
        increment: int = 1,
    ) -> None:
        """Record proposal state count.

        Args:
            state: Proposal state (draft, submitted, evaluating, etc.)
            increment: Value to add (default 1)

        Example:
            >>> exporter.record_proposal_state("submitted")

        """
        self.proposals_total.labels(state=state).inc(increment)

    def record_proposal_transition(
        self,
        from_state: str,
        to_state: str,
    ) -> None:
        """Record a state transition in proposal workflow.

        Args:
            from_state: Previous state
            to_state: New state

        Example:
            >>> exporter.record_proposal_transition("submitted", "evaluating")

        """
        self.proposal_transitions_total.labels(
            from_state=from_state,
            to_state=to_state,
        ).inc()

    def set_active_proposals(self, count: int) -> None:
        """Update active proposal count gauge.

        Args:
            count: Current number of active proposals

        """
        self.active_proposals.set(count)

    def set_kl_divergence(self, value: float) -> None:
        """Update KL divergence gauge.

        Args:
            value: Current KL divergence value

        """
        if not math.isfinite(value):
            logger.warning("Non-finite KL divergence rejected: %s", value)
            return
        self.kl_divergence.set(value)

    _KNOWN_DRIFT_STATUSES = frozenset({"normal", "warning", "critical"})

    def set_drift_status(self, status: str) -> None:
        """Update drift status gauge.

        Args:
            status: Drift status (normal, warning, critical)

        Example:
            >>> exporter.set_drift_status("warning")

        Raises:
            ValueError: If status is not a known drift status.

        """
        if status not in self._KNOWN_DRIFT_STATUSES:
            raise ValueError(
                f"Unknown drift status '{status}'; "
                f"expected one of {sorted(self._KNOWN_DRIFT_STATUSES)}"
            )
        # Reset all statuses to 0, then set current to 1
        for s in ["normal", "warning", "critical"]:
            self.drift_status.labels(status=s).set(0)
        self.drift_status.labels(status=status).set(1)

    def record_override_request(self, outcome: str) -> None:
        """Record an override request outcome.

        Args:
            outcome: Request outcome (approved, rejected, expired)

        """
        self.override_requests_total.labels(outcome=outcome).inc()

    def record_consensus_vote(self, vote_type: str) -> None:
        """Record a consensus vote.

        Args:
            vote_type: Vote type (approve, reject, abstain)

        """
        self.consensus_votes_total.labels(vote_type=vote_type).inc()

    def record_error(self, component: str, error_type: str) -> None:
        """Record an error occurrence.

        Args:
            component: Component where error occurred
            error_type: Type of error

        Example:
            >>> exporter.record_error("gates", "validation")

        """
        self.errors_total.labels(component=component, error_type=error_type).inc()

    def record_shadow_evaluation(self, status: str) -> None:
        """Record a shadow mode evaluation.

        Args:
            status: Decision status (proceed, pause, halt, escalate)

        Example:
            >>> exporter.record_shadow_evaluation("proceed")

        """
        self.shadow_evaluations_total.labels(status=status).inc()


# ===== MODULE-LEVEL FUNCTIONS =====

# Global exporter instance (singleton pattern with thread-safe initialization)
_global_exporter: PrometheusExporter | None = None
_global_exporter_lock = threading.Lock()


def get_exporter() -> PrometheusExporter:
    """Get the global PrometheusExporter instance (singleton).

    Thread-safe: Uses double-checked locking to ensure only one instance
    is created even when multiple threads call this concurrently.

    Returns:
        Global PrometheusExporter instance

    Example:
        >>> exporter = get_exporter()
        >>> exporter.record_gate_evaluation(...)

    """
    global _global_exporter  # noqa: PLW0603
    if _global_exporter is None:
        with _global_exporter_lock:
            # Double-check after acquiring lock
            if _global_exporter is None:
                _global_exporter = PrometheusExporter()
    return _global_exporter


def get_metrics() -> bytes:
    """Generate Prometheus metrics in text exposition format.

    Returns:
        Prometheus metrics as bytes (UTF-8 encoded text)

    Example:
        >>> metrics = get_metrics()
        >>> print(metrics.decode('utf-8'))
        # HELP aegis_decisions_total Total decision outcomes by gate type
        # TYPE aegis_decisions_total counter
        aegis_decisions_total{decision="pass",gate="risk"} 42.0
        ...

    """
    if not _HAS_PROMETHEUS:
        raise ImportError(
            "prometheus_client is required for Prometheus metrics. "
            "Install with: pip install aegis-governance[telemetry]"
        )
    return generate_latest()


def reset_metrics() -> None:
    """Reset all metrics (for testing only).

    Warning:
        This clears all metric history. Use only in tests.

    """
    global _global_exporter  # noqa: PLW0603

    # Clear instance metrics cache if global exporter exists (T-3 fix)
    if _global_exporter is not None:
        _global_exporter._metrics.clear()

    # Unregister all AEGIS metrics from global registry
    if _HAS_PROMETHEUS:
        # Find collectors that have any aegis_ prefixed names
        collectors_to_remove = []
        for collector, names in list(REGISTRY._collector_to_names.items()):
            if any(name.startswith("aegis_") for name in names):
                collectors_to_remove.append(collector)

        for collector in collectors_to_remove:
            with contextlib.suppress(Exception):
                REGISTRY.unregister(collector)

    # Reset global exporter to None (will be recreated on next get_exporter() call)
    _global_exporter = None


# ===== PERFORMANCE MONITORING =====


class MetricsTimer:
    """Context manager for timing operations and recording to Prometheus.

    Example:
        >>> exporter = get_exporter()
        >>> with MetricsTimer(exporter, "gate_evaluation", "risk"):
        ...     result = evaluate_risk_gate(...)

    """

    def __init__(
        self,
        exporter: PrometheusExporter,
        operation: str,
        gate: str = "",
    ):
        """Initialize timer.

        Args:
            exporter: PrometheusExporter instance
            operation: Operation name
            gate: Optional gate identifier

        """
        self.exporter = exporter
        self.operation = operation
        self.gate = gate
        self.start_time: float | None = None

    def __enter__(self) -> MetricsTimer:
        """Start timing."""
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore
        """Stop timing and record metric."""
        if self.start_time is not None:
            latency = time.time() - self.start_time
            if not math.isfinite(latency):
                logger.warning(
                    "Non-finite timer latency rejected for %s/%s: %s",
                    self.operation,
                    self.gate,
                    latency,
                )
                return
            self.exporter.latency_seconds.labels(
                operation=self.operation,
                gate=self.gate,
            ).observe(latency)
