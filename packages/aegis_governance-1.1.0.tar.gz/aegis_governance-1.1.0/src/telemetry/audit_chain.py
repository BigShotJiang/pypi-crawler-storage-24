"""Hash-Chained Audit Trail

Implements tamper-evident hash chaining for telemetry events.

Each audit event receives an ``event_hash`` computed as:
    SHA-256(canonical(event_data) || previous_hash)

The first event in a chain uses a well-known genesis hash. Chain
integrity can be verified by iterating events and confirming each
hash links to its predecessor.

Thread Safety:
    All mutable chain state is protected by ``threading.Lock``.

Usage::

    chain = AuditChain()
    enriched = chain.append(event_dict)
    # enriched now contains "_chain_hash" and "_chain_previous_hash"

    # Verify a sequence of chained events
    ok, err = AuditChain.verify_chain(events)
"""

import hashlib
import json
import logging
import threading
from collections import deque
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Well-known genesis hash — SHA-256 of the string "AEGIS_GENESIS_v1".
# Changing this value would break all existing chains.
_GENESIS_HASH = hashlib.sha256(b"AEGIS_GENESIS_v1").hexdigest()

# Fields injected by the chain itself — excluded from canonical digest
# to avoid circular hashing.
_CHAIN_FIELDS = frozenset({"_chain_hash", "_chain_previous_hash", "_chain_seq"})

# Maximum recent hashes kept in memory for diagnostics / replay.
_MAX_HISTORY = 10_000


def canonical_json(data: dict[str, Any]) -> bytes:
    """Return a deterministic JSON encoding of *data*.

    Keys are sorted, no extra whitespace, ``ensure_ascii=True`` so the
    output is pure 7-bit ASCII bytes — identical across platforms and
    Python versions.  Chain metadata fields are stripped before encoding.
    """
    cleaned = {k: v for k, v in data.items() if k not in _CHAIN_FIELDS}
    return json.dumps(cleaned, sort_keys=True, ensure_ascii=True, default=str).encode(
        "ascii"
    )


def compute_hash(event_bytes: bytes, previous_hash: str) -> str:
    """Compute ``SHA-256(event_bytes || previous_hash_bytes)``."""
    h = hashlib.sha256()
    h.update(event_bytes)
    h.update(previous_hash.encode("ascii"))
    return h.hexdigest()


class AuditChain:
    """Thread-safe hash-chained audit trail.

    Args:
        genesis_hash: Override the default genesis hash (useful for testing).

    Attributes:
        head_hash: The hash at the tip of the chain.
        sequence: Number of events appended so far.
    """

    def __init__(self, genesis_hash: Optional[str] = None) -> None:
        self._lock = threading.Lock()
        self._genesis_hash = genesis_hash if genesis_hash is not None else _GENESIS_HASH
        self._head_hash: str = self._genesis_hash
        self._sequence: int = 0
        self._recent_hashes: deque[str] = deque(maxlen=_MAX_HISTORY)

    def __repr__(self) -> str:
        with self._lock:
            return (
                f"AuditChain(sequence={self._sequence}, "
                f"head_hash={self._head_hash[:16]}...)"
            )

    # ------------------------------------------------------------------
    # Properties (thread-safe reads)
    # ------------------------------------------------------------------

    @property
    def head_hash(self) -> str:
        with self._lock:
            return self._head_hash

    @property
    def sequence(self) -> int:
        with self._lock:
            return self._sequence

    @property
    def genesis_hash(self) -> str:
        return self._genesis_hash

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def append(self, event: dict[str, Any]) -> dict[str, Any]:
        """Append *event* to the chain and return the enriched copy.

        The returned dict contains three additional fields:

        - ``_chain_previous_hash``: hash of the preceding event (or genesis)
        - ``_chain_hash``: SHA-256 digest of this event + previous hash
        - ``_chain_seq``: 1-based sequence number in the chain

        Args:
            event: Telemetry event dict. Must not be empty.

        Returns:
            A *new* dict — the original is not mutated.

        Raises:
            ValueError: If *event* is empty.
        """
        if not event:
            raise ValueError("Cannot append an empty event to the audit chain")

        event_bytes = canonical_json(event)

        with self._lock:
            previous = self._head_hash
            new_hash = compute_hash(event_bytes, previous)
            self._head_hash = new_hash
            self._sequence += 1
            seq = self._sequence
            self._recent_hashes.append(new_hash)

        enriched = dict(event)
        enriched["_chain_previous_hash"] = previous
        enriched["_chain_hash"] = new_hash
        enriched["_chain_seq"] = seq
        return enriched

    def reset(self) -> None:
        """Reset the chain to genesis state."""
        with self._lock:
            self._head_hash = self._genesis_hash
            self._sequence = 0
            self._recent_hashes.clear()

    # ------------------------------------------------------------------
    # Verification (static — does not require chain instance)
    # ------------------------------------------------------------------

    @staticmethod
    def verify_chain(
        events: list[dict[str, Any]],
        genesis_hash: Optional[str] = None,
    ) -> tuple[bool, Optional[str]]:
        """Verify the integrity of a sequence of chained events.

        Events must be in chain order (ascending ``_chain_seq``).

        Args:
            events: List of event dicts containing chain metadata fields.
            genesis_hash: Expected genesis hash (defaults to module constant).

        Returns:
            ``(True, None)`` if the chain is valid, or
            ``(False, error_message)`` describing the first break.
        """
        expected_genesis = genesis_hash if genesis_hash is not None else _GENESIS_HASH

        if not events:
            return True, None

        previous_hash = expected_genesis
        for i, event in enumerate(events):
            stored_hash = event.get("_chain_hash")
            stored_prev = event.get("_chain_previous_hash")

            if stored_hash is None or stored_prev is None:
                return False, (
                    f"Event {i}: missing chain metadata "
                    f"(_chain_hash={stored_hash!r}, "
                    f"_chain_previous_hash={stored_prev!r})"
                )

            if stored_prev != previous_hash:
                return False, (
                    f"Event {i}: previous_hash mismatch — "
                    f"expected {previous_hash[:16]}..., "
                    f"got {stored_prev[:16]}..."
                )

            recomputed = compute_hash(canonical_json(event), stored_prev)
            if recomputed != stored_hash:
                return False, (
                    f"Event {i}: hash mismatch — "
                    f"expected {recomputed[:16]}..., "
                    f"got {stored_hash[:16]}... (possible tampering)"
                )

            previous_hash = stored_hash

        return True, None

    @staticmethod
    def detect_tampered_events(
        events: list[dict[str, Any]],
        genesis_hash: Optional[str] = None,
    ) -> list[int]:
        """Return indices of events whose hashes do not verify.

        Unlike :meth:`verify_chain` which stops at the first break, this
        method scans the entire sequence and returns all broken indices.
        """
        expected_genesis = genesis_hash if genesis_hash is not None else _GENESIS_HASH
        tampered: list[int] = []

        if not events:
            return tampered

        previous_hash = expected_genesis
        for i, event in enumerate(events):
            stored_hash = event.get("_chain_hash")
            stored_prev = event.get("_chain_previous_hash")

            if stored_hash is None or stored_prev is None:
                tampered.append(i)
                # Can't continue chain from this point — use stored hash if available
                previous_hash = stored_hash if stored_hash else previous_hash
                continue

            if stored_prev != previous_hash:
                tampered.append(i)
                previous_hash = stored_hash
                continue

            recomputed = compute_hash(canonical_json(event), stored_prev)
            if recomputed != stored_hash:
                tampered.append(i)

            previous_hash = stored_hash

        return tampered


class AuditChainEnricher:
    """Pipeline-compatible enricher that wraps :class:`AuditChain`.

    Designed to be registered via ``pipeline.add_enricher(enricher)``
    where the enricher callable signature is
    ``(event: dict) -> dict``.

    Example::

        chain_enricher = AuditChainEnricher()
        pipeline.add_enricher(chain_enricher)
    """

    def __init__(self, genesis_hash: Optional[str] = None) -> None:
        self.chain = AuditChain(genesis_hash=genesis_hash)

    def __call__(self, event: dict[str, Any]) -> dict[str, Any]:
        """Enrich *event* with hash-chain metadata."""
        return self.chain.append(event)

    def __repr__(self) -> str:
        return f"AuditChainEnricher(chain={self.chain!r})"
