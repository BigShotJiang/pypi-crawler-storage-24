"""PII Decryptor for Telemetry Events.

Provides decryption for PII fields encrypted by PIIEncryptionEnricher.
Includes integrity verification via SHA-256 hash comparison.

Security:
    - Decryption requires private key access
    - Integrity verification detects tampering
    - Supports versioned DEKs for rotation
    - Audit logging for decryption operations

Usage:
    # Create decryptor with private key
    decryptor = PIIDecryptor(
        private_key=dek_private_key,
    )

    # Decrypt a single event
    decrypted = decryptor.decrypt_event(encrypted_event)

    # Decrypt specific fields only
    decrypted = decryptor.decrypt_event(
        encrypted_event,
        fields=["actor_id", "decision_actor"],
    )

GAP-Q2 Phase 2: PII Decryption Layer
"""

import hashlib
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Import crypto components
try:
    from crypto import HYBRID_KEM_AVAILABLE

    if HYBRID_KEM_AVAILABLE:
        from crypto.hybrid_kem import (
            HybridEncryptedBlob,
            HybridKEMPrivateKey,
            HybridKEMProvider,
        )
except ImportError:
    HYBRID_KEM_AVAILABLE = False

# Import encryption types (requires HYBRID_KEM_AVAILABLE check above)
from .encryption import EncryptedField  # noqa: E402


@dataclass
class DecryptionResult:
    """Result of a decryption operation."""

    success: bool
    decrypted_value: Any
    integrity_verified: bool
    error: Optional[str] = None


class IntegrityError(Exception):
    """Raised when decrypted data fails integrity verification."""

    def __init__(self, field: str, expected_hash: str, actual_hash: str):
        self.field = field
        self.expected_hash = expected_hash
        self.actual_hash = actual_hash
        super().__init__(
            f"Integrity check failed for field '{field}': "
            f"expected={expected_hash[:16]}..., actual={actual_hash[:16]}...",
        )


class DecryptionError(Exception):
    """Raised when decryption fails."""


class PIIDecryptor:
    """Decrypt PII fields in telemetry events.

    Provides decryption with integrity verification for fields encrypted
    by PIIEncryptionEnricher.

    Thread Safety:
        Safe for concurrent use from multiple threads.
    """

    def __init__(
        self,
        private_key: "HybridKEMPrivateKey",
        verify_integrity: bool = True,
        strict_mode: bool = False,
    ):
        """Initialize PII decryptor.

        Args:
            private_key: HybridKEM private key for decryption
            verify_integrity: Whether to verify SHA-256 hash (default: True)
            strict_mode: Raise exceptions on errors vs return partial results

        """
        if not HYBRID_KEM_AVAILABLE:
            raise RuntimeError(
                "HybridKEMProvider not available. "
                "Install liboqs-python>=0.10.0 for post-quantum support.",
            )

        self._private_key = private_key
        self._verify_integrity = verify_integrity
        self._strict_mode = strict_mode
        self._kem_provider = HybridKEMProvider()

        logger.info(
            f"PIIDecryptor initialized: verify_integrity={verify_integrity}, "
            f"strict_mode={strict_mode}",
        )

    def _compute_hash(self, value: Any) -> str:
        """Compute SHA-256 hash of a value."""
        if isinstance(value, bytes):
            data = value
        elif isinstance(value, str):
            data = value.encode("utf-8")
        else:
            data = json.dumps(value, sort_keys=True).encode("utf-8")
        return hashlib.sha256(data).hexdigest()

    def _deserialize_value(
        self, data: bytes, original_field: str, value_type: str = "json"
    ) -> Any:
        """Deserialize decrypted bytes back to original value.

        Uses value_type metadata for lossless round-trip when available.
        Falls back to JSON-then-string heuristic for legacy data without
        value_type metadata.

        Args:
            data: Decrypted bytes to deserialize
            original_field: Field name (reserved for future field-specific
                deserialization logic, currently unused)
            value_type: Original value type ("str", "bytes", or "json")

        Returns:
            Deserialized value (dict, list, str, or raw bytes)
        """
        _ = original_field  # Silence unused parameter warning

        if value_type == "str":
            return data.decode("utf-8")
        if value_type == "bytes":
            return data

        # "json" (default) — legacy heuristic for backward compatibility
        try:
            # Try JSON first (for dicts, lists, numbers, bools)
            return json.loads(data.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Fall back to raw string
            try:
                return data.decode("utf-8")
            except UnicodeDecodeError:
                # Return raw bytes if not decodable
                return data

    def _decrypt_value(
        self,
        encrypted_field: EncryptedField,
        field_name: str,
    ) -> DecryptionResult:
        """Decrypt a single encrypted field.

        Args:
            encrypted_field: EncryptedField to decrypt
            field_name: Name of the field (for error messages)

        Returns:
            DecryptionResult with decrypted value

        """
        try:
            # Parse encrypted blob
            blob = HybridEncryptedBlob.from_bytes(encrypted_field.ciphertext)

            # Decrypt
            plaintext = self._kem_provider.decrypt(blob, self._private_key)

            # Deserialize using value_type for lossless round-trip
            value = self._deserialize_value(
                plaintext, field_name, encrypted_field.value_type
            )

            # Verify integrity
            integrity_verified = True
            if self._verify_integrity:
                actual_hash = self._compute_hash(value)
                if actual_hash != encrypted_field.plaintext_hash:
                    if self._strict_mode:
                        raise IntegrityError(
                            field=field_name,
                            expected_hash=encrypted_field.plaintext_hash,
                            actual_hash=actual_hash,
                        )
                    logger.warning(
                        f"Integrity check failed for field '{field_name}': "
                        f"hash mismatch",
                    )
                    integrity_verified = False

            return DecryptionResult(
                success=True,
                decrypted_value=value,
                integrity_verified=integrity_verified,
            )

        except IntegrityError:
            raise
        except (ValueError, TypeError, json.JSONDecodeError, UnicodeDecodeError) as e:
            error_msg = f"Decryption failed for field '{field_name}': {e}"
            if self._strict_mode:
                raise DecryptionError(error_msg) from e
            logger.error(error_msg)
            return DecryptionResult(
                success=False,
                decrypted_value=None,
                integrity_verified=False,
                error=str(e),
            )

    def decrypt_field(
        self,
        value: dict[str, Any],
        field_name: str,
    ) -> Any:
        """Decrypt a single encrypted field value.

        Args:
            value: Encrypted field dictionary
            field_name: Name of the field

        Returns:
            Decrypted value, or original value if not encrypted

        Raises:
            DecryptionError: If decryption fails in strict mode
            IntegrityError: If integrity check fails in strict mode

        """
        if not EncryptedField.is_encrypted_field(value):
            return value

        encrypted_field = EncryptedField.from_dict(value)
        if encrypted_field is None:
            return value

        result = self._decrypt_value(encrypted_field, field_name)
        if result.success:
            return result.decrypted_value
        return value  # Return original on failure in non-strict mode

    def _decrypt_dict(
        self,
        data: dict[str, Any],
        fields: Optional[set[str]] = None,
        path: str = "",
    ) -> dict[str, Any]:
        """Recursively decrypt PII fields in a dictionary.

        Args:
            data: Dictionary to process
            fields: Specific fields to decrypt (None = all PII fields)
            path: Current field path

        Returns:
            Dictionary with PII fields decrypted

        """
        result = {}

        for key, value in data.items():
            full_key = f"{path}.{key}" if path else key

            # Check if this is an encrypted field
            if EncryptedField.is_encrypted_field(value):
                # Only decrypt if in target fields (or no filter specified)
                if fields is None or key in fields or full_key in fields:
                    result[key] = self.decrypt_field(value, key)
                else:
                    result[key] = value
            elif isinstance(value, dict):
                # Recursively process nested dicts
                result[key] = self._decrypt_dict(value, fields, full_key)
            elif isinstance(value, list):
                # Recursively process lists containing dicts (Bug 5 fix)
                result[key] = self._decrypt_list(value, fields, full_key)
            else:
                result[key] = value

        return result

    def _decrypt_list(
        self,
        data: list[Any],
        fields: Optional[set[str]] = None,
        path: str = "",
    ) -> list[Any]:
        """Recursively decrypt PII fields in list elements.

        Args:
            data: List to process
            fields: Specific fields to decrypt (None = all PII fields)
            path: Current field path

        Returns:
            List with PII fields in nested dicts decrypted

        """
        result: list[Any] = []

        for i, item in enumerate(data):
            item_path = f"{path}[{i}]"
            if isinstance(item, dict):
                # Recursively process nested dicts in lists
                result.append(self._decrypt_dict(item, fields, item_path))
            elif isinstance(item, list):
                # Recursively process nested lists
                result.append(self._decrypt_list(item, fields, item_path))
            else:
                result.append(item)

        return result

    def decrypt_event(
        self,
        event: dict[str, Any],
        fields: Optional[set[str]] = None,
    ) -> dict[str, Any]:
        """Decrypt PII fields in a telemetry event.

        Args:
            event: Telemetry event with encrypted fields
            fields: Specific fields to decrypt (None = all encrypted fields)

        Returns:
            Event with specified fields decrypted

        Raises:
            DecryptionError: If decryption fails in strict mode
            IntegrityError: If integrity check fails in strict mode

        """
        try:
            decrypted = self._decrypt_dict(event, fields)

            # Update metadata
            decrypted["_pii_decrypted"] = True
            decrypted["_decrypted_at"] = (
                datetime.now(timezone.utc)
                .isoformat()
                .replace(
                    "+00:00",
                    "Z",
                )
            )

            return decrypted

        except (DecryptionError, IntegrityError):
            raise
        except (
            ValueError,
            TypeError,
            json.JSONDecodeError,
            UnicodeDecodeError,
            AttributeError,
            KeyError,
        ) as e:
            if self._strict_mode:
                raise DecryptionError(f"Event decryption failed: {e}") from e
            logger.error(f"Event decryption failed: {e}")
            result = dict(event)
            result["_decryption_error"] = str(e)
            return result

    def decrypt_events(
        self,
        events: list[dict[str, Any]],
        fields: Optional[set[str]] = None,
    ) -> list[dict[str, Any]]:
        """Decrypt PII fields in multiple events.

        Args:
            events: List of encrypted events
            fields: Specific fields to decrypt (None = all)

        Returns:
            List of decrypted events

        """
        return [self.decrypt_event(event, fields) for event in events]

    def verify_event_integrity(
        self,
        event: dict[str, Any],
    ) -> dict[str, bool]:
        """Verify integrity of all encrypted fields in an event.

        Args:
            event: Event to verify

        Returns:
            Dict mapping field names to integrity status

        """
        results: dict[str, bool] = {}
        self._verify_dict_integrity(event, results)
        return results

    def _verify_dict_integrity(
        self,
        data: dict[str, Any],
        results: dict[str, bool],
        path: str = "",
    ) -> None:
        """Recursively verify integrity of encrypted fields."""
        for key, value in data.items():
            full_key = f"{path}.{key}" if path else key

            if EncryptedField.is_encrypted_field(value):
                encrypted_field = EncryptedField.from_dict(value)
                if encrypted_field:
                    result = self._decrypt_value(encrypted_field, full_key)
                    results[full_key] = result.integrity_verified
            elif isinstance(value, dict):
                self._verify_dict_integrity(value, results, full_key)
            elif isinstance(value, list):
                self._verify_list_integrity(value, results, full_key)

    def _verify_list_integrity(
        self,
        data: list[Any],
        results: dict[str, bool],
        path: str = "",
    ) -> None:
        """Recursively verify integrity of encrypted fields in list elements."""
        for i, item in enumerate(data):
            item_path = f"{path}[{i}]"
            if isinstance(item, dict):
                self._verify_dict_integrity(item, results, item_path)
            elif isinstance(item, list):
                self._verify_list_integrity(item, results, item_path)


def create_decryptor(
    private_key: "HybridKEMPrivateKey",
    verify_integrity: bool = True,
    strict_mode: bool = False,
) -> PIIDecryptor:
    """Factory function to create a PII decryptor.

    Args:
        private_key: HybridKEM private key for decryption
        verify_integrity: Whether to verify integrity hash
        strict_mode: Raise exceptions on errors

    Returns:
        Configured PIIDecryptor instance

    """
    return PIIDecryptor(
        private_key=private_key,
        verify_integrity=verify_integrity,
        strict_mode=strict_mode,
    )


__all__ = [
    "DecryptionError",
    "DecryptionResult",
    "IntegrityError",
    "PIIDecryptor",
    "create_decryptor",
]
