"""Telemetry Pipeline

Manages the flow of telemetry data from emission to storage and analysis.

PII Encryption (GAP-Q2 Phase 2):
    When pii_encryptor is configured, the pipeline automatically encrypts
    PII fields before storage. This provides:
    - Field-level encryption using HybridKEM
    - Non-PII fields remain queryable
    - Integrity verification via SHA-256 hash

Pipeline Stages:
    1. Collection - Receive events from emitters
    2. Validation - Validate event structure and content
    3. Enrichment - Add context and system metrics
    4. PII Encryption - Encrypt PII fields (if configured)
    5. Aggregation - Aggregate events for analysis
    6. Storage - Persist to configured backend
    7. Analysis - Drift detection and alerting
"""

import copy
import logging
import queue
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable, Optional

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from .encryption import PIIEncryptionEnricher


class PipelineStage(str, Enum):
    """Pipeline processing stages."""

    COLLECTION = "collection"
    VALIDATION = "validation"
    ENRICHMENT = "enrichment"
    ENCRYPTION = "encryption"  # GAP-Q2: PII field encryption
    AGGREGATION = "aggregation"
    STORAGE = "storage"
    ANALYSIS = "analysis"


@dataclass
class PipelineConfig:
    """Configuration for telemetry pipeline."""

    # Buffer settings
    buffer_size: int = 1000
    flush_interval_seconds: int = 60
    flush_threshold: int = 100

    def __post_init__(self) -> None:
        """Validate buffer_size, flush_threshold, and flush_interval_seconds."""
        for field_name in ("buffer_size", "flush_threshold", "flush_interval_seconds"):
            val = getattr(self, field_name)
            if not isinstance(val, int) or isinstance(val, bool):
                raise TypeError(
                    f"{field_name} must be an integer, got {type(val).__name__}"
                )
        if self.buffer_size < 1:
            raise ValueError(
                f"buffer_size must be >= 1, got {self.buffer_size}. "
                "A zero-size buffer causes an infinite loop in ingest()."
            )
        if self.flush_threshold < 1:
            raise ValueError(
                f"flush_threshold must be >= 1, got {self.flush_threshold}. "
                "A zero/negative threshold triggers flush on every ingest."
            )
        if self.flush_interval_seconds < 1:
            raise ValueError(
                f"flush_interval_seconds must be >= 1, got {self.flush_interval_seconds}. "
                "A zero/negative interval degrades to flush-every-cycle."
            )
        # Validate retention_days and drift_window_size (same pattern as above)
        for field_name in ("retention_days", "drift_window_size"):
            val = getattr(self, field_name)
            if not isinstance(val, int) or isinstance(val, bool):
                raise TypeError(
                    f"{field_name} must be an integer, got {type(val).__name__}"
                )
            if val < 1:
                raise ValueError(f"{field_name} must be >= 1, got {val}")
        # Validate enum-constrained string fields
        _valid_pii = frozenset({"warn", "drop", "raise"})
        if self.pii_encryption_on_error not in _valid_pii:
            raise ValueError(
                f"pii_encryption_on_error must be one of {sorted(_valid_pii)}, "
                f"got {self.pii_encryption_on_error!r}"
            )
        _valid_storage = frozenset({"warn", "raise"})
        if self.storage_on_error not in _valid_storage:
            raise ValueError(
                f"storage_on_error must be one of {sorted(_valid_storage)}, "
                f"got {self.storage_on_error!r}"
            )

    # Validation settings
    strict_validation: bool = True
    drop_invalid: bool = False

    # Enrichment settings
    enrich_with_context: bool = True
    add_system_metrics: bool = True

    # PII Encryption settings (GAP-Q2)
    enable_pii_encryption: bool = False
    pii_encryption_on_error: str = "warn"  # "warn", "drop", "raise"

    # Storage settings
    storage_backend: str = "local"  # local, s3, elasticsearch
    retention_days: int = 90
    storage_on_error: str = "warn"  # "warn", "raise" - how to handle storage failures

    # Analysis settings
    enable_drift_detection: bool = True
    drift_window_size: int = 1000


@dataclass
class PipelineStats:
    """Statistics for pipeline monitoring."""

    events_received: int = 0
    events_processed: int = 0
    events_dropped: int = 0
    events_invalid: int = 0
    events_encrypted: int = 0  # GAP-Q2: PII encryption count
    encryption_errors: int = 0  # GAP-Q2: Encryption failure count
    storage_errors: int = 0  # Storage failure count
    last_flush_time: Optional[datetime] = None
    buffer_size: int = 0
    errors: deque[str] = field(default_factory=lambda: deque(maxlen=1000))


class TelemetryPipeline:
    """Pipeline for processing telemetry events.

    Stages:
    1. Collection - Receive events from emitters
    2. Validation - Validate event structure and content
    3. Enrichment - Add context and system metrics
    4. PII Encryption - Encrypt PII fields (if configured)
    5. Aggregation - Aggregate events for analysis
    6. Storage - Persist to configured backend
    7. Analysis - Drift detection and alerting
    """

    def __init__(
        self,
        config: Optional[PipelineConfig] = None,
        pii_encryptor: Optional["PIIEncryptionEnricher"] = None,
    ):
        """Initialize pipeline.

        Args:
            config: Pipeline configuration
            pii_encryptor: PII encryption enricher (GAP-Q2)

        """
        self.config = copy.copy(config) if config is not None else PipelineConfig()

        # Event buffer
        self.buffer: deque[dict[str, Any]] = deque(maxlen=self.config.buffer_size)

        # Processing queue
        self.queue: queue.Queue[dict[str, Any]] = queue.Queue()

        # Statistics
        self.stats = PipelineStats()

        # Processors for each stage
        self.validators: list[Callable[[dict[str, Any]], bool]] = []
        self.enrichers: list[Callable[[dict[str, Any]], dict[str, Any]]] = []
        self.aggregators: list[Callable[[list[dict[str, Any]]], None]] = []
        self.storage_handlers: list[Callable[[list[dict[str, Any]]], None]] = []
        self.analyzers: list[Callable[[list[dict[str, Any]]], None]] = []

        # PII Encryption (GAP-Q2)
        self._pii_encryptor = pii_encryptor
        if pii_encryptor is not None:
            self.config.enable_pii_encryption = True

        # State
        self.running = False
        self.worker_thread: Optional[threading.Thread] = None

        # Thread safety for buffer operations
        self._buffer_lock = threading.Lock()
        # Thread safety for start/stop (M22 fix)
        self._start_lock = threading.Lock()
        # Thread safety for stats operations (H-WF-003 fix)
        self._stats_lock = threading.Lock()

    def set_pii_encryptor(self, encryptor: "PIIEncryptionEnricher") -> None:
        """Set or update the PII encryptor.

        Thread-safe: both fields are set atomically under buffer lock to
        prevent flush() from seeing a partial update (T-5 fix).

        Args:
            encryptor: PIIEncryptionEnricher instance

        """
        with self._buffer_lock:
            self._pii_encryptor = encryptor
            self.config.enable_pii_encryption = True

    def add_validator(self, validator: Callable[[dict[str, Any]], bool]) -> None:
        """Add a validation function."""
        self.validators.append(validator)

    def add_enricher(
        self,
        enricher: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> None:
        """Add an enrichment function."""
        self.enrichers.append(enricher)

    def add_aggregator(
        self,
        aggregator: Callable[[list[dict[str, Any]]], None],
    ) -> None:
        """Add an aggregation function."""
        self.aggregators.append(aggregator)

    def add_storage_handler(
        self,
        handler: Callable[[list[dict[str, Any]]], None],
    ) -> None:
        """Add a storage handler."""
        self.storage_handlers.append(handler)

    def add_analyzer(self, analyzer: Callable[[list[dict[str, Any]]], None]) -> None:
        """Add an analysis function."""
        self.analyzers.append(analyzer)

    def ingest(self, event: dict[str, Any]) -> bool:
        """Ingest an event into the pipeline.

        Args:
            event: Event to ingest

        Returns:
            True if event was accepted

        """
        with self._stats_lock:
            self.stats.events_received += 1

        # Validate — evaluate ALL validators; count once per invalid event
        if self.config.strict_validation:
            event_is_invalid = False
            for validator in self.validators:
                try:
                    passed = validator(event)
                except (
                    Exception
                ) as e:  # Intentional: validator failure = validation failed, pipeline continues
                    logger.warning("Validator raised %s: %s", type(e).__name__, e)
                    passed = False
                if not passed:
                    if self.config.drop_invalid:
                        with self._stats_lock:
                            self.stats.events_invalid += 1
                            self.stats.events_dropped += 1
                        return False
                    event_is_invalid = True
            if event_is_invalid:
                with self._stats_lock:
                    self.stats.events_invalid += 1

        # Add to buffer (thread-safe). Flush first if buffer is full to avoid
        # deque(maxlen=...) silently dropping the oldest event.
        should_flush = False
        while True:
            with self._buffer_lock:
                buffer_full = (
                    self.buffer.maxlen is not None
                    and len(self.buffer) >= self.buffer.maxlen
                )
                if not buffer_full:
                    self.buffer.append(copy.deepcopy(event))
                    should_flush = len(self.buffer) >= self.config.flush_threshold
                    break
            self.flush()

        # Check if flush needed (outside lock to avoid deadlock)
        if should_flush:
            self.flush()

        return True

    def flush(self) -> int:
        """Flush buffer through pipeline.

        Returns:
            Number of events processed

        """
        # Atomically extract events and capture encryptor reference (thread-safe)
        # Capturing pii state under the same lock prevents flush() from seeing
        # a partial set_pii_encryptor() update (T-5 fix).
        with self._buffer_lock:
            if not self.buffer:
                return 0
            events = list(self.buffer)
            self.buffer.clear()
            pii_encryptor = self._pii_encryptor
            enable_pii_encryption = self.config.enable_pii_encryption

        # Enrich
        enriched_events = []
        for event in events:
            enriched = event.copy()
            for enricher in self.enrichers:
                enriched = enricher(enriched)
            enriched_events.append(enriched)

        # Encrypt PII fields (GAP-Q2)
        if enable_pii_encryption and pii_encryptor is not None:
            enriched_events = self._encrypt_pii_fields(
                enriched_events, encryptor=pii_encryptor
            )

        # Aggregate
        for aggregator in self.aggregators:
            try:
                aggregator(enriched_events)
            except (
                Exception
            ) as e:  # Intentional: aggregator failure logged to stats, pipeline continues
                with self._stats_lock:
                    self.stats.errors.append(f"Aggregation error: {e!s}")

        # Store
        for handler in self.storage_handlers:
            try:
                handler(enriched_events)
            except (
                Exception
            ) as e:  # Intentional: storage failure tracked in metrics, pipeline continues
                with self._stats_lock:
                    self.stats.storage_errors += 1
                    error_msg = f"Storage error: {e!s}"
                    self.stats.errors.append(error_msg)

                # Propagate exception in strict mode
                if self.config.storage_on_error == "raise":
                    raise RuntimeError(error_msg) from e

        # Analyze
        for analyzer in self.analyzers:
            try:
                analyzer(enriched_events)
            except (
                Exception
            ) as e:  # Intentional: analyzer failure logged to stats, pipeline continues
                with self._stats_lock:
                    self.stats.errors.append(f"Analysis error: {e!s}")

        with self._stats_lock:
            self.stats.events_processed += len(enriched_events)
            self.stats.last_flush_time = datetime.now(timezone.utc)

        return len(enriched_events)

    def _encrypt_pii_fields(
        self,
        events: list[dict[str, Any]],
        *,
        encryptor: Optional[Any] = None,
    ) -> list[dict[str, Any]]:
        """Encrypt PII fields in events.

        Args:
            events: List of events to encrypt
            encryptor: Encryptor instance to use (avoids re-reading self
                attribute outside lock). Falls back to self._pii_encryptor.

        Returns:
            List of events with PII fields encrypted

        Raises:
            RuntimeError: If pii_encryption_on_error is "raise" and encryption fails

        """
        enc = encryptor if encryptor is not None else self._pii_encryptor
        if enc is None:
            return events

        encrypted_events: list[dict[str, Any]] = []
        for event in events:
            try:
                encrypted = enc.enrich(event)
                encrypted_events.append(encrypted)
                with self._stats_lock:
                    self.stats.events_encrypted += 1
            except (
                Exception
            ) as e:  # Intentional: PII error boundary — behavior per config.pii_encryption_on_error
                error_msg = f"PII encryption error: {e!s}"

                if self.config.pii_encryption_on_error == "raise":
                    raise RuntimeError(error_msg) from e
                if self.config.pii_encryption_on_error == "drop":
                    with self._stats_lock:
                        self.stats.encryption_errors += 1
                        self.stats.events_dropped += 1
                        self.stats.errors.append(error_msg)
                    continue
                # "warn" - include unencrypted event (copy to avoid mutating input)
                with self._stats_lock:
                    self.stats.encryption_errors += 1
                    self.stats.errors.append(error_msg)
                event_copy = dict(event)
                event_copy["_pii_encryption_failed"] = True
                encrypted_events.append(event_copy)

        return encrypted_events

    def start(self) -> None:
        """Start background processing."""
        with self._start_lock:
            if self.running:
                return

            self.running = True
            self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
            self.worker_thread.start()

    def stop(self) -> None:
        """Stop background processing.

        Drains any pending events from the queue before final flush to prevent
        data loss (Bug 4 fix).  Acquires _start_lock to prevent race with
        concurrent start() calls.

        Thread safety: lock is released before thread.join() to avoid blocking
        a concurrent start() call for up to 5 seconds (BH39-M1 fix; mirrors
        the identical fix applied to MetricsServer.stop() in BH38-M4).
        """
        with self._start_lock:
            self.running = False
            thread = self.worker_thread
            self.worker_thread = None
        # Join outside the lock so a concurrent start() is not blocked.
        if thread is not None:
            thread.join(timeout=5.0)
            if thread.is_alive():
                logger.warning(
                    "TelemetryPipeline worker thread did not stop within "
                    "5 second timeout. Thread may be blocked."
                )

        # Bug 4 fix: Drain the queue before final flush to prevent data loss.
        # Wrap ingest in try/except so a storage error during mid-drain flush
        # does not abort the remaining queue events or skip the final flush.
        drained_count = 0
        while True:
            try:
                event = self.queue.get_nowait()
            except queue.Empty:
                break
            try:
                self.ingest(event)
            except Exception:
                logger.warning(
                    "Error during shutdown drain; event may be lost", exc_info=True
                )
            drained_count += 1

        if drained_count > 0:
            logger.info(f"Drained {drained_count} events from queue during shutdown")

        try:
            self.flush()  # Final flush
        except Exception:
            logger.warning("Error during final shutdown flush", exc_info=True)

    def _worker_loop(self) -> None:
        """Background worker loop."""
        last_flush = datetime.now(timezone.utc)

        try:
            while self.running:
                now = datetime.now(timezone.utc)

                # Time-based flush
                if (
                    now - last_flush
                ).total_seconds() >= self.config.flush_interval_seconds:
                    self.flush()
                    last_flush = now

                # Process any queued items
                try:
                    event = self.queue.get(timeout=1.0)
                    self.ingest(event)
                except queue.Empty:
                    pass
        finally:
            self.running = False

    def get_stats(self) -> PipelineStats:
        """Get pipeline statistics.

        Thread-safe: Returns a snapshot of current stats to avoid race conditions.
        Both buffer_lock and stats_lock are acquired to ensure consistency.
        (H-WF-003 fix: returns snapshot instead of mutable reference)
        """
        with self._buffer_lock:
            current_buffer_size = len(self.buffer)
        with self._stats_lock:
            # Return a snapshot (defensive copy) to avoid concurrent modification
            return PipelineStats(
                events_received=self.stats.events_received,
                events_processed=self.stats.events_processed,
                events_dropped=self.stats.events_dropped,
                events_invalid=self.stats.events_invalid,
                events_encrypted=self.stats.events_encrypted,
                encryption_errors=self.stats.encryption_errors,
                storage_errors=self.stats.storage_errors,
                last_flush_time=self.stats.last_flush_time,
                buffer_size=current_buffer_size,
                errors=deque(self.stats.errors, maxlen=1000),
            )

    def reset_stats(self) -> None:
        """Reset pipeline statistics.

        Thread-safe: Uses stats_lock to prevent concurrent access issues.
        (H-WF-003 fix: protects stats replacement with lock)
        """
        with self._stats_lock:
            self.stats = PipelineStats()


# Default validators
def validate_required_fields(event: dict[str, Any]) -> bool:
    """Validate that required fields are present."""
    required = ["event_id", "event_type", "timestamp", "source"]
    return all(field in event for field in required)


def validate_timestamp(event: dict[str, Any]) -> bool:
    """Validate timestamp is not in future."""
    timestamp = event.get("timestamp")
    if not timestamp:
        return False
    try:
        if isinstance(timestamp, str):
            dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        else:
            dt = timestamp
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt <= datetime.now(timezone.utc) + timedelta(minutes=5)
    except (ValueError, TypeError, AttributeError, OverflowError):
        return False


# Default enrichers
def enrich_with_timestamp(event: dict[str, Any]) -> dict[str, Any]:
    """Ensure event has processed timestamp."""
    result = dict(event)
    result["processed_at"] = datetime.now(timezone.utc).isoformat()
    return result


def enrich_with_environment(
    environment: str,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Create an environment enricher."""

    def enricher(event: dict[str, Any]) -> dict[str, Any]:
        result = dict(event)
        result["environment"] = environment
        return result

    return enricher


# Default storage handlers
def console_storage(events: list[dict[str, Any]]) -> None:
    """Print events to console (for development)."""
    for event in events:
        print(f"[STORED] {event.get('event_type')}: {event.get('event_id')}")


def memory_storage(
    storage: list[dict[str, Any]],
) -> Callable[[list[dict[str, Any]]], None]:
    """Create an in-memory storage handler."""

    def handler(events: list[dict[str, Any]]) -> None:
        storage.extend(events)

    return handler


_MAX_COMPLETED_WINDOWS = 100


@dataclass
class AggregationWindow:
    """A time-bounded aggregation window.

    Accumulates event counts by type and numeric sums by metric name
    within a fixed time boundary [start_time, end_time).
    """

    start_time: datetime
    end_time: datetime
    counts: dict[str, int] = field(default_factory=dict)
    sums: dict[str, float] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate window boundaries."""
        if self.end_time <= self.start_time:
            raise ValueError(
                f"end_time ({self.end_time}) must be after "
                f"start_time ({self.start_time})"
            )


class AggregationStage:
    """Configurable windowed aggregation for telemetry events.

    Accumulates events into fixed-duration time windows. Each window tracks:
    - **counts**: Number of events per ``event_type``
    - **sums**: Running totals for configured numeric metric fields

    When the current wall-clock time exceeds the active window's ``end_time``,
    the window is rotated into the completed-windows deque (bounded by
    ``_MAX_COMPLETED_WINDOWS`` to prevent memory growth) and a fresh window
    is started.

    Thread safety: all mutable state is protected by ``threading.Lock``.
    The class is callable with signature
    ``(events: list[dict[str, Any]]) -> None`` so it can be registered
    directly via ``pipeline.add_aggregator(stage)``.

    Args:
        window_seconds: Duration of each aggregation window in seconds.
            Must be >= 1.
        metrics: List of event-dict keys whose numeric values are summed.
            If ``None``, no sums are tracked (only counts).

    Raises:
        TypeError: If ``window_seconds`` is not an int or is a bool.
        ValueError: If ``window_seconds`` < 1.

    Example::

        stage = AggregationStage(window_seconds=30, metrics=["latency_ms"])
        pipeline.add_aggregator(stage)
        # ... ingest events ...
        window = stage.get_current_window()
        print(window.counts)  # {'proposal_submitted': 12, ...}
        print(window.sums)    # {'latency_ms': 4532.1, ...}
    """

    def __init__(
        self,
        window_seconds: int = 60,
        metrics: Optional[list[str]] = None,
    ) -> None:
        if not isinstance(window_seconds, int) or isinstance(window_seconds, bool):
            raise TypeError(
                f"window_seconds must be an integer, got {type(window_seconds).__name__}"
            )
        if window_seconds < 1:
            raise ValueError(f"window_seconds must be >= 1, got {window_seconds}")

        self._window_seconds = window_seconds
        self._metrics: list[str] = list(metrics) if metrics is not None else []
        self._lock = threading.Lock()
        self._current_window: Optional[AggregationWindow] = None
        self._completed_windows: deque[AggregationWindow] = deque(
            maxlen=_MAX_COMPLETED_WINDOWS
        )

    def __repr__(self) -> str:
        with self._lock:
            completed = len(self._completed_windows)
            has_current = self._current_window is not None
        return (
            f"AggregationStage(window_seconds={self._window_seconds}, "
            f"metrics={self._metrics!r}, "
            f"has_current_window={has_current}, "
            f"completed_windows={completed})"
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def __call__(self, events: list[dict[str, Any]]) -> None:
        """Process events (aggregator callback signature).

        Accumulates event counts and metric sums into the current window.
        Rotates the window if the current time exceeds the window boundary.

        Args:
            events: List of event dicts to aggregate. Each event should
                contain at minimum an ``event_type`` key.
        """
        now = datetime.now(timezone.utc)
        with self._lock:
            self._ensure_window(now)
            assert self._current_window is not None
            for event in events:
                event_type = event.get("event_type", "unknown")
                self._current_window.counts[event_type] = (
                    self._current_window.counts.get(event_type, 0) + 1
                )
                for metric in self._metrics:
                    value = event.get(metric)
                    if isinstance(value, (int, float)) and not isinstance(value, bool):
                        self._current_window.sums[metric] = (
                            self._current_window.sums.get(metric, 0.0) + float(value)
                        )

    def get_current_window(self) -> Optional[AggregationWindow]:
        """Return a defensive copy of the current (in-progress) window.

        Returns:
            Copy of the current ``AggregationWindow``, or ``None`` if no
            events have been processed yet.
        """
        now = datetime.now(timezone.utc)
        with self._lock:
            self._ensure_window_rotation(now)
            if self._current_window is None:
                return None
            return AggregationWindow(
                start_time=self._current_window.start_time,
                end_time=self._current_window.end_time,
                counts=dict(self._current_window.counts),
                sums=dict(self._current_window.sums),
            )

    def get_completed_windows(self) -> list[AggregationWindow]:
        """Return defensive copies of all completed windows.

        Returns:
            List of completed ``AggregationWindow`` objects, oldest first.
        """
        now = datetime.now(timezone.utc)
        with self._lock:
            self._ensure_window_rotation(now)
            return [
                AggregationWindow(
                    start_time=w.start_time,
                    end_time=w.end_time,
                    counts=dict(w.counts),
                    sums=dict(w.sums),
                )
                for w in self._completed_windows
            ]

    def reset(self) -> None:
        """Clear all windows and accumulated state."""
        with self._lock:
            self._current_window = None
            self._completed_windows.clear()

    # ------------------------------------------------------------------
    # Internal helpers (must be called under self._lock)
    # ------------------------------------------------------------------

    def _ensure_window(self, now: datetime) -> None:
        """Ensure a current window exists, rotating if expired."""
        self._ensure_window_rotation(now)
        if self._current_window is None:
            self._start_new_window(now)

    def _ensure_window_rotation(self, now: datetime) -> None:
        """Rotate the current window into completed if it has expired."""
        if self._current_window is not None and now >= self._current_window.end_time:
            self._completed_windows.append(self._current_window)
            self._current_window = None

    def _start_new_window(self, now: datetime) -> None:
        """Start a fresh aggregation window beginning at *now*."""
        self._current_window = AggregationWindow(
            start_time=now,
            end_time=now + timedelta(seconds=self._window_seconds),
        )


def create_default_pipeline(environment: str = "development") -> TelemetryPipeline:
    """Create a pipeline with default configuration."""
    pipeline = TelemetryPipeline()

    # Add default validators
    pipeline.add_validator(validate_required_fields)
    pipeline.add_validator(validate_timestamp)

    # Add default enrichers
    pipeline.add_enricher(enrich_with_timestamp)
    pipeline.add_enricher(enrich_with_environment(environment))

    # Add console storage for development
    if environment == "development":
        pipeline.add_storage_handler(console_storage)

    return pipeline


def create_encrypted_pipeline(
    pii_encryptor: "PIIEncryptionEnricher",
    environment: str = "development",
    on_error: str = "warn",
) -> TelemetryPipeline:
    """Create a pipeline with PII encryption enabled.

    Args:
        pii_encryptor: PIIEncryptionEnricher instance
        environment: Environment name
        on_error: Error handling mode ("warn", "drop", "raise")

    Returns:
        TelemetryPipeline with PII encryption configured

    Example:
        >>> from telemetry.encryption import PIIEncryptionEnricher
        >>> from crypto.hybrid_kem import HybridKEMProvider
        >>>
        >>> # Create encryptor with DEK
        >>> provider = HybridKEMProvider()
        >>> keypair = provider.generate_keypair()
        >>> encryptor = PIIEncryptionEnricher(
        ...     public_key=keypair.public,
        ...     dek_version="dek-v1-20251228",
        ... )
        >>>
        >>> # Create pipeline with encryption
        >>> pipeline = create_encrypted_pipeline(encryptor)
        >>> pipeline.ingest({"event_id": "1", "actor_id": "user@example.com", ...})
        >>> # actor_id will be encrypted before storage

    """
    config = PipelineConfig(
        enable_pii_encryption=True,
        pii_encryption_on_error=on_error,
    )

    pipeline = TelemetryPipeline(
        config=config,
        pii_encryptor=pii_encryptor,
    )

    # Add default validators
    pipeline.add_validator(validate_required_fields)
    pipeline.add_validator(validate_timestamp)

    # Add default enrichers
    pipeline.add_enricher(enrich_with_timestamp)
    pipeline.add_enricher(enrich_with_environment(environment))

    # Add console storage for development
    if environment == "development":
        pipeline.add_storage_handler(console_storage)

    return pipeline
