"""Alert Sink Protocol and Implementations

Pluggable alert dispatch for governance events. Consumers implement AlertSink
to route alerts to their preferred channel (Slack, email, SNS, etc.).

Default: LogAlertSink logs to Python logger at appropriate level.
"""

import json
import logging
from enum import Enum
from typing import Any, Optional, Protocol

logger = logging.getLogger(__name__)


class AlertSeverity(str, Enum):
    """Alert severity levels."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


# Map severity to logging level
_SEVERITY_LOG_LEVEL: dict[AlertSeverity, int] = {
    AlertSeverity.INFO: logging.INFO,
    AlertSeverity.WARNING: logging.WARNING,
    AlertSeverity.CRITICAL: logging.CRITICAL,
    AlertSeverity.EMERGENCY: logging.CRITICAL,
}


class AlertSink(Protocol):
    """Protocol for alert dispatch targets."""

    def send_alert(
        self, severity: AlertSeverity, title: str, details: dict[str, Any]
    ) -> None: ...


class LogAlertSink:
    """Default alert sink: logs alerts via Python logger at appropriate level.

    This is the zero-dependency default suitable for all environments.
    """

    def __init__(self, logger_name: str = "aegis.alerts") -> None:
        self._logger = logging.getLogger(logger_name)

    def send_alert(
        self, severity: AlertSeverity, title: str, details: dict[str, Any]
    ) -> None:
        """Log alert at severity-appropriate level."""
        level = _SEVERITY_LOG_LEVEL.get(severity, logging.WARNING)
        self._logger.log(
            level,
            "[%s] %s | %s",
            severity.value.upper(),
            title,
            json.dumps(details, default=str),
        )


class WebhookAlertSink:
    """Generic webhook POST to any URL (Slack, Discord, custom).

    Note: Uses urllib from stdlib to avoid adding requests as a dependency.
    Falls back to logging if the POST fails.
    """

    def __init__(
        self,
        url: str,
        headers: Optional[dict[str, str]] = None,
        *,
        allow_insecure: bool = False,
    ) -> None:
        from telemetry.emitter import _validate_sink_url  # local: avoid circular import

        _validate_sink_url(
            url, allow_insecure=allow_insecure, class_name="WebhookAlertSink"
        )
        self._url = url.strip()
        self._headers = {"Content-Type": "application/json", **(headers or {})}

    def send_alert(
        self, severity: AlertSeverity, title: str, details: dict[str, Any]
    ) -> None:
        """POST alert to webhook URL."""
        import urllib.request

        payload = json.dumps(
            {"severity": severity.value, "title": title, "details": details},
            default=str,
        ).encode("utf-8")

        req = urllib.request.Request(  # noqa: S310
            self._url,
            data=payload,
            headers=self._headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(  # noqa: S310  # nosec B310
                req, timeout=10
            ) as resp:
                logger.debug("Webhook alert sent: status=%d", resp.status)
        except Exception as e:  # Intentional: alert delivery must not crash producer
            logger.error("Webhook alert failed for %s: %s", self._url, e)


class CompositeAlertSink:
    """Fan-out to multiple alert sinks.

    Errors in individual sinks are logged but do not prevent delivery to other sinks.
    """

    def __init__(self, sinks: list[AlertSink]) -> None:
        self._sinks: list[AlertSink] = list(sinks)

    def add_sink(self, sink: AlertSink) -> None:
        """Add a sink to the fan-out list."""
        self._sinks.append(sink)

    def send_alert(
        self, severity: AlertSeverity, title: str, details: dict[str, Any]
    ) -> None:
        """Dispatch alert to all registered sinks."""
        for sink in self._sinks:
            try:
                sink.send_alert(severity, title, details)
            except (
                Exception
            ) as e:  # Intentional: one sink failure must not block other sinks
                logger.error("Alert sink %s failed: %s", type(sink).__name__, e)
