"""Shared SSRF-safe URL validation for telemetry endpoints.

Provides ``validate_telemetry_url`` and ``is_forbidden_ip`` for use by
all three AEGIS transports (CLI, MCP, Lambda).

Uses ``not addr.is_global`` which is consistent across Python 3.9-3.12
per cpython#119812: blocks private, loopback, link-local, reserved,
CGNAT (100.64/10), and unspecified ranges.
"""

from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlparse

_ALLOWED_TELEMETRY_SCHEMES = frozenset({"https"})


def is_forbidden_ip(addr: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    """Return True if *addr* is not a globally routable address.

    Uses ``not is_global`` which covers private, loopback, link-local,
    reserved, CGNAT (100.64/10), and unspecified ranges — stricter than
    checking the individual properties and consistent across Python 3.9-3.12.
    """
    return not addr.is_global


def validate_telemetry_url(url: str) -> bool:
    """Validate telemetry URL to prevent SSRF attacks.

    Rejects file://, ftp://, and URLs targeting private/link-local/loopback IPs.
    Uses resolve-then-validate to catch hex/octal/integer IP encodings and
    DNS names that resolve to private addresses.
    """
    parsed = urlparse(url)
    if parsed.scheme not in _ALLOWED_TELEMETRY_SCHEMES:
        return False
    hostname = parsed.hostname
    if not hostname:
        return False
    try:
        addr = ipaddress.ip_address(hostname)
        if is_forbidden_ip(addr):
            return False
    except ValueError:
        # Not a standard dotted-decimal IP — could be a DNS name OR an exotic
        # IP encoding (hex, octal, decimal integer).  Resolve via DNS and
        # re-validate every resolved address.
        try:
            infos = socket.getaddrinfo(
                hostname, parsed.port or 443, type=socket.SOCK_STREAM
            )
        except (socket.gaierror, OSError):
            return False  # Unresolvable hostname — fail closed
        for _family, _type, _proto, _canonname, sockaddr in infos:
            try:
                resolved = ipaddress.ip_address(sockaddr[0])
                if is_forbidden_ip(resolved):
                    return False
            except ValueError:
                return False  # Unparseable resolved IP — fail closed
    return True
