"""Telemetry Schema Definitions

Defines the structure of telemetry records per Interface Contract v2.0.0.
All fields marked as required MUST be present in every telemetry event.
"""

import dataclasses
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class TelemetryVersion(str, Enum):
    """Telemetry schema version."""

    V1_0 = "1.0.0"
    V2_0 = "2.0.0"  # Current version with DOS/Rubric integration


@dataclass
class ProposalIdentification:
    """Proposal identification fields (REQUIRED)."""

    proposal_id: str
    proposal_version: int
    baseline_snapshot_hash: str
    submission_timestamp: str  # ISO 8601


@dataclass
class MetricValues:
    """Raw metric values (REQUIRED)."""

    # Risk metrics
    risk_baseline: float
    risk_proposed: float
    delta_risk_norm: float

    # Profit metrics
    profit_baseline: float
    profit_proposed: float
    delta_profit_norm: float

    # Novelty metrics
    novelty_score: float
    novelty_gate_output: float

    # Complexity metrics
    complexity_static: float
    complexity_dynamic: float
    complexity_total: float
    complexity_normalized: float

    # Quality metrics
    quality_total: float
    quality_subscores: dict[str, float]

    # Utility metrics (v2.0)
    utility_raw: float
    utility_variance: float
    utility_lcb: float
    decision_path: str  # INVESTMENT or REFACTORING


@dataclass
class ThresholdValues:
    """Threshold values used (REQUIRED)."""

    epsilon_R: float
    epsilon_P: float
    risk_trigger_factor: float
    profit_trigger_factor: float
    trigger_confidence_prob: float
    novelty_N0: float
    novelty_k: float
    novelty_threshold: float
    complexity_floor: float
    quality_minimum: float

    # Utility thresholds (v2.0)
    gamma: float
    kappa: float
    phi_S: float
    phi_D: float


@dataclass
class GateResults:
    """Gate evaluation results (REQUIRED)."""

    risk_passed: bool
    risk_posterior: float
    profit_passed: bool
    profit_posterior: float
    novelty_passed: bool
    complexity_passed: bool
    quality_passed: bool
    utility_passed: bool
    all_gates_passed: bool
    override_eligible: bool


@dataclass
class GateTelemetry:
    """Telemetry for a single gate evaluation."""

    gate_name: str
    passed: bool
    value: float
    threshold: float
    posterior_probability: Optional[float] = None
    confidence: Optional[float] = None
    evaluated_at: str = ""  # ISO 8601


@dataclass
class OverrideInfo:
    """Override information (when applicable).

    Field names are unprefixed (no ``override_`` prefix) since they live
    under the ``override`` namespace in ``ProposalTelemetry``.  Use
    :meth:`to_schema_dict` for serialization with schema-compliant
    ``override_``-prefixed keys.
    """

    requested: bool = False
    approved: bool = False
    requester_id: Optional[str] = None
    risk_lead_signer_id: Optional[str] = None
    security_lead_signer_id: Optional[str] = None
    failed_gates: Optional[list[str]] = None
    risk_lead_signature: Optional[str] = None
    security_lead_signature: Optional[str] = None
    justification: Optional[str] = None
    timestamp: Optional[str] = None
    combined_hash: Optional[str] = None

    def to_schema_dict(self) -> dict[str, Any]:
        """Serialize with schema-compliant field names (override_ prefix).

        Returns a flat dict whose keys match ``schema/telemetry-schema.yaml``
        override field names exactly.
        """
        return {
            "override_requested": self.requested,
            "override_approved": self.approved,
            "override_requester_id": self.requester_id,
            "override_risk_lead_signer_id": self.risk_lead_signer_id,
            "override_security_lead_signer_id": self.security_lead_signer_id,
            "override_failed_gates": self.failed_gates,
            "override_risk_lead_signature": self.risk_lead_signature,
            "override_security_lead_signature": self.security_lead_signature,
            "override_justification": self.justification,
            "override_timestamp": self.timestamp,
            "override_combined_hash": self.combined_hash,
        }


@dataclass
class DecisionOutcome:
    """Final decision outcome (REQUIRED)."""

    decision: str  # approved, rejected, escalated, pending
    decision_timestamp: str  # ISO 8601
    decision_actor: str
    decision_rationale: str


# ============================================================================
# Validation field descriptors — data-driven validation for ProposalTelemetry
# ============================================================================

# Each tuple: (field_name, check) where check is "none" (is None) or "falsy" (not value)
_IDENTIFICATION_FIELDS: list[tuple[str, str]] = [
    ("proposal_id", "falsy"),
    ("proposal_version", "none"),
    ("baseline_snapshot_hash", "falsy"),
    ("submission_timestamp", "falsy"),
]

_METRICS_FIELDS: list[tuple[str, str]] = [
    ("risk_baseline", "none"),
    ("risk_proposed", "none"),
    ("delta_risk_norm", "none"),
    ("profit_baseline", "none"),
    ("profit_proposed", "none"),
    ("delta_profit_norm", "none"),
    ("novelty_score", "none"),
    ("novelty_gate_output", "none"),
    ("complexity_static", "none"),
    ("complexity_dynamic", "none"),
    ("complexity_total", "none"),
    ("complexity_normalized", "none"),
    ("quality_total", "none"),
    ("quality_subscores", "none"),
    ("utility_raw", "none"),
    ("utility_variance", "none"),
    ("utility_lcb", "none"),
    ("decision_path", "falsy"),
]

_THRESHOLDS_FIELDS: list[tuple[str, str]] = [
    ("epsilon_R", "none"),
    ("epsilon_P", "none"),
    ("risk_trigger_factor", "none"),
    ("profit_trigger_factor", "none"),
    ("trigger_confidence_prob", "none"),
    ("novelty_N0", "none"),
    ("novelty_k", "none"),
    ("novelty_threshold", "none"),
    ("complexity_floor", "none"),
    ("quality_minimum", "none"),
    ("gamma", "none"),
    ("kappa", "none"),
    ("phi_S", "none"),
    ("phi_D", "none"),
]

_GATES_FIELDS: list[tuple[str, str]] = [
    ("risk_passed", "none"),
    ("risk_posterior", "none"),
    ("profit_passed", "none"),
    ("profit_posterior", "none"),
    ("novelty_passed", "none"),
    ("complexity_passed", "none"),
    ("quality_passed", "none"),
    ("utility_passed", "none"),
    ("all_gates_passed", "none"),
    ("override_eligible", "none"),
]

_DECISION_FIELDS: list[tuple[str, str]] = [
    ("decision", "falsy"),
    ("decision_timestamp", "falsy"),
    ("decision_actor", "falsy"),
    ("decision_rationale", "falsy"),
]


def _validate_section(
    section: object,
    section_name: str,
    field_descriptors: list[tuple[str, str]],
    errors: list[str],
) -> None:
    """Validate all fields in a section using data-driven descriptors.

    Args:
        section: The dataclass section to validate
        section_name: Prefix for error messages (e.g., "metrics")
        field_descriptors: List of (field_name, check_type) tuples
        errors: Accumulator list for validation errors
    """
    for field_name, check in field_descriptors:
        value = getattr(section, field_name)
        if (check == "none" and value is None) or (check == "falsy" and not value):
            errors.append(f"Missing required: {section_name}.{field_name}")


@dataclass
class ProposalTelemetry:
    """Complete telemetry record for a proposal evaluation.

    This structure ensures 100% logging coverage as required by
    the Interface Contract.
    """

    # Schema version
    schema_version: str = TelemetryVersion.V2_0.value

    # Identification
    identification: Optional[ProposalIdentification] = None

    # Metrics
    metrics: Optional[MetricValues] = None

    # Thresholds
    thresholds: Optional[ThresholdValues] = None

    # Gate results
    gates: Optional[GateResults] = None

    # Gate-level telemetry
    gate_telemetry: list[GateTelemetry] = field(default_factory=list)

    # Override info
    override: Optional[OverrideInfo] = None

    # Decision
    decision: Optional[DecisionOutcome] = None

    # Additional metadata
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> list[str]:
        """Validate that all required fields are present.

        Returns:
            List of validation errors (empty if valid).
            Reports ALL validation errors, not just the first per group.

        Note:
            Performs complete nested validation on all required sections.
            Uses data-driven field descriptors for maintainability.
        """
        errors: list[str] = []

        _SECTIONS: list[tuple[Optional[object], str, list[tuple[str, str]]]] = [
            (self.identification, "identification", _IDENTIFICATION_FIELDS),
            (self.metrics, "metrics", _METRICS_FIELDS),
            (self.thresholds, "thresholds", _THRESHOLDS_FIELDS),
            (self.gates, "gates", _GATES_FIELDS),
            (self.decision, "decision", _DECISION_FIELDS),
        ]

        for section, name, fields in _SECTIONS:
            if section is None:
                errors.append(f"Missing required: {name}")
            else:
                _validate_section(section, name, fields, errors)

        return errors

    def is_valid(self) -> bool:
        """Check if telemetry record is valid."""
        return len(self.validate()) == 0


@dataclass
class TelemetryRecord:
    """Wrapper for telemetry records with metadata.

    Used for serialization and transmission.
    """

    record_id: str
    record_type: str  # proposal, gate, override, decision
    timestamp: datetime
    source: str  # Component that generated the record
    payload: ProposalTelemetry
    environment: str = "production"
    version: str = TelemetryVersion.V2_0.value

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "record_id": self.record_id,
            "record_type": self.record_type,
            "timestamp": self.timestamp.isoformat(),
            "source": self.source,
            "environment": self.environment,
            "version": self.version,
            "payload": self._payload_to_dict(),
        }

    def _payload_to_dict(self) -> dict[str, Any]:
        """Convert payload to dictionary.

        Override fields are flattened at the top level using schema-compliant
        ``override_``-prefixed keys via :meth:`OverrideInfo.to_schema_dict`.
        """
        # Uses module-level dataclasses import

        def asdict_recursive(obj: Any) -> Any:
            if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
                return {
                    k: asdict_recursive(v) for k, v in dataclasses.asdict(obj).items()
                }
            if isinstance(obj, list):
                return [asdict_recursive(v) for v in obj]
            if isinstance(obj, dict):
                return {k: asdict_recursive(v) for k, v in obj.items()}
            return obj

        result: dict[str, Any] = asdict_recursive(self.payload)

        # Always remove the nested "override" key (asdict serializes None
        # fields as {"override": None}, which is not a valid schema key).
        result.pop("override", None)

        # Flatten override using schema-compliant keys when present
        if self.payload.override is not None:
            result.update(self.payload.override.to_schema_dict())

        return result
