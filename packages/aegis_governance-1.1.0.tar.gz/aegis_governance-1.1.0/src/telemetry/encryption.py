"""PII Encryption Enricher for Telemetry Pipeline.

Provides field-level encryption for PII fields in telemetry events using
HybridKEM (X25519 + ML-KEM-768 + AES-256-GCM) encryption.

Architecture:
    - PIIManifest: Defines which fields contain PII
    - DEKCache: Thread-safe cache for Data Encryption Keys
    - PIIEncryptionEnricher: Pipeline enricher for encrypting PII fields
    - create_pii_enricher: Factory function for creating enricher

Encrypted Field Schema:
    {
        "field_name": {
            "_encrypted": True,
            "_algorithm": "x25519+ml-kem-768+aes-256-gcm",
            "_dek_version": "dek-v1-20251228",
            "_ciphertext": "base64-encoded-blob",
            "_plaintext_hash": "sha256-for-integrity",
            "_encrypted_at": "2025-12-28T00:00:00Z"
        }
    }

Security Properties:
    - PII fields encrypted with hybrid post-quantum encryption
    - Non-PII fields remain plaintext for querying
    - Integrity verification via SHA-256 hash
    - DEK versioning for rotation support
    - Thread-safe DEK caching

GAP-Q2 Phase 2: PII Encryption Layer
GAP-TelemetryPrivacy: Field-level PII protection
"""

import base64
import binascii
import hashlib
import json
import logging
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from types import MappingProxyType
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# Import crypto components
try:
    from crypto import HYBRID_KEM_AVAILABLE

    if HYBRID_KEM_AVAILABLE:
        from crypto.hybrid_kem import (
            HybridKEMProvider,
            HybridKEMPublicKey,
        )
except ImportError:
    HYBRID_KEM_AVAILABLE = False


class PIIPriority(str, Enum):
    """PII field priority levels."""

    CRITICAL = "critical"  # MUST encrypt
    HIGH = "high"  # SHOULD encrypt
    MEDIUM = "medium"  # MAY encrypt
    LOW = "low"  # Encrypt if performance allows


@dataclass
class PIIFieldDefinition:
    """Definition of a PII field."""

    name: str
    priority: PIIPriority
    description: str
    layer: str  # L1_Foundation, L2_Gates, L3_Orchestration, Audit, Override


class PIIManifest:
    """PII field definitions for telemetry events.

    Defines which fields contain Personally Identifiable Information (PII)
    and their encryption priority.

    Field Categories:
    - CRITICAL: Must always be encrypted (signatures, justifications)
    - HIGH: Should be encrypted (actor IDs, workflow IDs)
    - MEDIUM: Encrypt if feasible (proposal context)
    - LOW: Encrypt if performance allows
    """

    # Critical fields (MUST encrypt) - 6 fields
    CRITICAL_FIELDS: frozenset[str] = frozenset(
        {
            "actor_assignments",
            "override_justification",
            "risk_lead_signature",
            "security_lead_signature",
            "decision_actor",
            "decision_rationale",
        }
    )

    # High priority fields (SHOULD encrypt) - 4 fields
    HIGH_FIELDS: frozenset[str] = frozenset(
        {
            "workflow_id",
            "author_id",
            "actor_id",
            "combined_hash",
        }
    )

    # Medium priority fields (MAY encrypt) - 2 fields
    MEDIUM_FIELDS: frozenset[str] = frozenset(
        {
            "requested_by",
            "signer_id",
        }
    )

    # All PII fields combined
    ALL_PII_FIELDS: frozenset[str] = CRITICAL_FIELDS | HIGH_FIELDS | MEDIUM_FIELDS

    # Field definitions with metadata
    FIELD_DEFINITIONS: Mapping[str, PIIFieldDefinition] = MappingProxyType(
        {
            # Critical - L3_Orchestration
            "actor_assignments": PIIFieldDefinition(
                name="actor_assignments",
                priority=PIIPriority.CRITICAL,
                description="Role-to-actor mapping for workflow",
                layer="L3_Orchestration",
            ),
            # Critical - Audit
            "override_justification": PIIFieldDefinition(
                name="override_justification",
                priority=PIIPriority.CRITICAL,
                description="Justification text for override request",
                layer="Audit",
            ),
            # Critical - Override
            "risk_lead_signature": PIIFieldDefinition(
                name="risk_lead_signature",
                priority=PIIPriority.CRITICAL,
                description="Cryptographic signature from Risk Lead",
                layer="Override",
            ),
            "security_lead_signature": PIIFieldDefinition(
                name="security_lead_signature",
                priority=PIIPriority.CRITICAL,
                description="Cryptographic signature from Security Lead",
                layer="Override",
            ),
            # Critical - L2_Gates
            "decision_actor": PIIFieldDefinition(
                name="decision_actor",
                priority=PIIPriority.CRITICAL,
                description="Actor who made gate decision",
                layer="L2_Gates",
            ),
            "decision_rationale": PIIFieldDefinition(
                name="decision_rationale",
                priority=PIIPriority.CRITICAL,
                description="Rationale for gate decision",
                layer="L2_Gates",
            ),
            # High - L3_Orchestration
            "workflow_id": PIIFieldDefinition(
                name="workflow_id",
                priority=PIIPriority.HIGH,
                description="Unique workflow identifier",
                layer="L3_Orchestration",
            ),
            # High - Event
            "author_id": PIIFieldDefinition(
                name="author_id",
                priority=PIIPriority.HIGH,
                description="Event author identifier",
                layer="Event",
            ),
            "actor_id": PIIFieldDefinition(
                name="actor_id",
                priority=PIIPriority.HIGH,
                description="Acting entity identifier",
                layer="Event",
            ),
            # High - Override
            "combined_hash": PIIFieldDefinition(
                name="combined_hash",
                priority=PIIPriority.HIGH,
                description="Combined signature hash",
                layer="Override",
            ),
            # Medium - Event
            "requested_by": PIIFieldDefinition(
                name="requested_by",
                priority=PIIPriority.MEDIUM,
                description="Entity requesting action",
                layer="Event",
            ),
            "signer_id": PIIFieldDefinition(
                name="signer_id",
                priority=PIIPriority.MEDIUM,
                description="Signature author identifier",
                layer="Override",
            ),
        }
    )

    @classmethod
    def is_pii(cls, field_name: str) -> bool:
        """Check if a field is PII."""
        return field_name in cls.ALL_PII_FIELDS

    @classmethod
    def is_critical(cls, field_name: str) -> bool:
        """Check if a field is critical PII."""
        return field_name in cls.CRITICAL_FIELDS

    @classmethod
    def is_high(cls, field_name: str) -> bool:
        """Check if a field is high priority PII."""
        return field_name in cls.HIGH_FIELDS

    @classmethod
    def get_priority(cls, field_name: str) -> Optional[PIIPriority]:
        """Get priority for a PII field."""
        defn = cls.FIELD_DEFINITIONS.get(field_name)
        return defn.priority if defn else None

    @classmethod
    def get_fields_by_priority(
        cls,
        min_priority: PIIPriority = PIIPriority.CRITICAL,
    ) -> set[str]:
        """Get PII fields at or above a priority level.

        Args:
            min_priority: Minimum priority level

        Returns:
            Set of field names

        """
        priority_order = [
            PIIPriority.LOW,
            PIIPriority.MEDIUM,
            PIIPriority.HIGH,
            PIIPriority.CRITICAL,
        ]
        min_idx = priority_order.index(min_priority)

        return {
            name
            for name, defn in cls.FIELD_DEFINITIONS.items()
            if priority_order.index(defn.priority) >= min_idx
        }


@dataclass(frozen=True)
class DEKEntry:
    """Data Encryption Key cache entry (immutable)."""

    dek_id: str
    public_key: "HybridKEMPublicKey"
    created_at: datetime
    expires_at: datetime


class DEKCache:
    """Thread-safe Data Encryption Key cache with TTL.

    Caches DEK public keys to avoid repeated key store lookups.
    Keys expire after TTL (default: 1 hour).

    Thread Safety:
        Uses threading.Lock for all cache operations.
    """

    def __init__(self, ttl_seconds: int = 3600):
        """Initialize DEK cache.

        Args:
            ttl_seconds: Time-to-live for cached keys (default: 1 hour)

        Raises:
            TypeError: If ttl_seconds is a bool.
            ValueError: If ttl_seconds < 1.

        """
        if isinstance(ttl_seconds, bool):
            raise TypeError("ttl_seconds must be an integer, got bool")
        if ttl_seconds < 1:
            raise ValueError(f"ttl_seconds must be >= 1, got {ttl_seconds}")
        self._cache: dict[str, DEKEntry] = {}
        self._lock = threading.Lock()
        self._ttl = timedelta(seconds=ttl_seconds)

    def get(self, dek_id: str) -> Optional[DEKEntry]:
        """Get DEK entry if not expired.

        Args:
            dek_id: DEK identifier

        Returns:
            DEKEntry or None if not found/expired

        """
        with self._lock:
            entry = self._cache.get(dek_id)
            if entry is None:
                return None

            if datetime.now(timezone.utc) > entry.expires_at:
                del self._cache[dek_id]
                return None

            return entry

    def put(
        self,
        dek_id: str,
        public_key: "HybridKEMPublicKey",
    ) -> DEKEntry:
        """Cache a DEK public key.

        Args:
            dek_id: DEK identifier
            public_key: HybridKEM public key

        Returns:
            Created cache entry

        """
        now = datetime.now(timezone.utc)
        entry = DEKEntry(
            dek_id=dek_id,
            public_key=public_key,
            created_at=now,
            expires_at=now + self._ttl,
        )

        with self._lock:
            self._cache[dek_id] = entry

        return entry

    def invalidate(self, dek_id: str) -> bool:
        """Remove a DEK from cache.

        Args:
            dek_id: DEK identifier

        Returns:
            True if entry was removed

        """
        with self._lock:
            if dek_id in self._cache:
                del self._cache[dek_id]
                return True
            return False

    def clear(self) -> int:
        """Clear all cached entries.

        Returns:
            Number of entries cleared

        """
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            return count

    def cleanup_expired(self) -> int:
        """Remove all expired entries.

        Returns:
            Number of entries removed

        """
        now = datetime.now(timezone.utc)
        with self._lock:
            expired = [k for k, v in self._cache.items() if now > v.expires_at]
            for k in expired:
                del self._cache[k]
            return len(expired)


@dataclass
class EncryptedField:
    """Encrypted PII field representation.

    Stores encrypted ciphertext with metadata for decryption.
    """

    ciphertext: bytes  # HybridEncryptedBlob bytes
    algorithm: str  # Encryption algorithm name
    dek_version: str  # DEK version for decryption
    plaintext_hash: str  # SHA-256 for integrity verification
    encrypted_at: str  # ISO timestamp
    value_type: str = "json"  # Original value type: "str", "bytes", or "json"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "_encrypted": True,
            "_algorithm": self.algorithm,
            "_dek_version": self.dek_version,
            "_ciphertext": base64.b64encode(self.ciphertext).decode("ascii"),
            "_plaintext_hash": self.plaintext_hash,
            "_encrypted_at": self.encrypted_at,
            "_value_type": self.value_type,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Optional["EncryptedField"]:
        """Create from dictionary.

        Args:
            data: Dictionary with encrypted field data

        Returns:
            EncryptedField or None if not an encrypted field

        """
        if not data.get("_encrypted"):
            return None

        try:
            ciphertext = base64.b64decode(data["_ciphertext"], validate=True)
        except (binascii.Error, TypeError, ValueError) as exc:
            raise ValueError("Invalid base64 ciphertext in encrypted field") from exc

        return cls(
            ciphertext=ciphertext,
            algorithm=data["_algorithm"],
            dek_version=data["_dek_version"],
            plaintext_hash=data["_plaintext_hash"],
            encrypted_at=data["_encrypted_at"],
            value_type=data.get("_value_type", "json"),
        )

    @classmethod
    def is_encrypted_field(cls, value: Any) -> bool:
        """Check if a value is an encrypted field dict."""
        return isinstance(value, dict) and value.get("_encrypted") is True


class PIIEncryptionEnricher:
    """Pipeline enricher for PII field encryption.

    Encrypts PII fields in telemetry events using HybridKEM encryption.
    Non-PII fields remain plaintext for querying.

    Usage:
        # Create enricher
        encryptor = PIIEncryptionEnricher(
            public_key=dek_public_key,
            dek_version="dek-v1-20251228",
        )

        # Use in pipeline
        pipeline.add_enricher(encryptor.enrich)

    Thread Safety:
        Safe for concurrent use from multiple threads.
    """

    def __init__(
        self,
        public_key: "HybridKEMPublicKey",
        dek_version: str,
        min_priority: PIIPriority = PIIPriority.HIGH,
        encrypt_nested: bool = True,
        raise_on_error: bool = False,
    ):
        """Initialize PII encryption enricher.

        Args:
            public_key: HybridKEM public key for encryption
            dek_version: Version identifier for the DEK
            min_priority: Minimum PII priority to encrypt (default: HIGH)
            encrypt_nested: Whether to encrypt nested dict fields
            raise_on_error: If True, raise exceptions on encryption failure
                instead of returning unencrypted data with error flag.
                Use True for strict compliance environments.

        """
        if not HYBRID_KEM_AVAILABLE:
            raise RuntimeError(
                "HybridKEMProvider not available. "
                "Install liboqs-python>=0.10.0 for post-quantum support.",
            )

        self._public_key = public_key
        self._dek_version = dek_version
        self._min_priority = min_priority
        self._encrypt_nested = encrypt_nested
        self._raise_on_error = raise_on_error
        self._kem_provider = HybridKEMProvider()
        self._target_fields = PIIManifest.get_fields_by_priority(min_priority)

        logger.info(
            f"PIIEncryptionEnricher initialized: dek_version={dek_version}, "
            f"min_priority={min_priority.value}, target_fields={len(self._target_fields)}",
        )

    @property
    def algorithm_name(self) -> str:
        """Return the encryption algorithm name."""
        return str(self._kem_provider.algorithm_name)

    @property
    def dek_version(self) -> str:
        """Return the DEK version."""
        return self._dek_version

    def _compute_plaintext_hash(self, value: Any) -> str:
        """Compute SHA-256 hash of plaintext for integrity verification."""
        if isinstance(value, bytes):
            data = value
        elif isinstance(value, str):
            data = value.encode("utf-8")
        else:
            data = json.dumps(value, sort_keys=True).encode("utf-8")
        return hashlib.sha256(data).hexdigest()

    def _serialize_value(self, value: Any) -> bytes:
        """Serialize a value to bytes for encryption."""
        if isinstance(value, bytes):
            return value
        if isinstance(value, str):
            return value.encode("utf-8")
        return json.dumps(value, sort_keys=True).encode("utf-8")

    def _encrypt_value(self, value: Any) -> EncryptedField:
        """Encrypt a single value.

        Args:
            value: Value to encrypt

        Returns:
            EncryptedField with encrypted data

        """
        plaintext = self._serialize_value(value)
        plaintext_hash = self._compute_plaintext_hash(value)

        # Classify value type for lossless round-trip deserialization
        if isinstance(value, bytes):
            value_type = "bytes"
        elif isinstance(value, str):
            value_type = "str"
        else:
            value_type = "json"

        # Encrypt with HybridKEM
        blob = self._kem_provider.encrypt(plaintext, self._public_key)

        return EncryptedField(
            ciphertext=blob.to_bytes(),
            algorithm=self.algorithm_name,
            dek_version=self._dek_version,
            plaintext_hash=plaintext_hash,
            encrypted_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            value_type=value_type,
        )

    def _should_encrypt(self, field_name: str) -> bool:
        """Check if a field should be encrypted."""
        return field_name in self._target_fields

    def _encrypt_dict(
        self,
        data: dict[str, Any],
        path: str = "",
    ) -> dict[str, Any]:
        """Recursively encrypt PII fields in a dictionary.

        Args:
            data: Dictionary to process
            path: Current field path (for nested fields)

        Returns:
            Dictionary with PII fields encrypted

        """
        result: dict[str, Any] = {}

        for key, value in data.items():
            full_key = f"{path}.{key}" if path else key

            # Check if this field should be encrypted
            if self._should_encrypt(key):
                if value is not None:
                    encrypted = self._encrypt_value(value)
                    result[key] = encrypted.to_dict()
                else:
                    result[key] = None
            elif isinstance(value, dict) and self._encrypt_nested:
                # Recursively process nested dicts
                result[key] = self._encrypt_dict(value, full_key)
            elif isinstance(value, list) and self._encrypt_nested:
                # Recursively process lists containing dicts (Bug 5 fix)
                result[key] = self._encrypt_list(value, full_key)
            else:
                result[key] = value

        return result

    def _encrypt_list(
        self,
        data: list[Any],
        path: str = "",
    ) -> list[Any]:
        """Recursively encrypt PII fields in list elements.

        Args:
            data: List to process
            path: Current field path (for nested fields)

        Returns:
            List with PII fields in nested dicts encrypted

        """
        result: list[Any] = []

        for i, item in enumerate(data):
            item_path = f"{path}[{i}]"
            if isinstance(item, dict):
                # Recursively process nested dicts in lists
                result.append(self._encrypt_dict(item, item_path))
            elif isinstance(item, list):
                # Recursively process nested lists
                result.append(self._encrypt_list(item, item_path))
            else:
                result.append(item)

        return result

    def enrich(self, event: dict[str, Any]) -> dict[str, Any]:
        """Encrypt PII fields in a telemetry event.

        This method is the enricher interface for TelemetryPipeline.

        Args:
            event: Telemetry event dictionary

        Returns:
            Event with PII fields encrypted

        Raises:
            RuntimeError: If encryption fails and raise_on_error=True

        """
        try:
            encrypted_event = self._encrypt_dict(event)

            # Add encryption metadata
            encrypted_event["_pii_encrypted"] = True
            encrypted_event["_encryption_version"] = "1.0"
            encrypted_event["_dek_version"] = self._dek_version

            return encrypted_event

        except (
            Exception
        ) as e:  # Intentional: PII error boundary — behavior per config.pii_encryption_on_error
            # QG67-T10: Sanitize error messages to avoid leaking PII fragments.
            # Exception str(e) may contain plaintext field values from failed
            # serialization/encryption, so log only the exception type.
            safe_msg = f"PII encryption failed: {type(e).__name__}"
            logger.error(safe_msg)

            # Propagate exception in strict mode
            if self._raise_on_error:
                raise RuntimeError(safe_msg) from e

            # Return copy of original event on failure (preserve caller's data)
            result = dict(event)
            result["_pii_encryption_error"] = safe_msg
            return result


def create_pii_enricher(
    public_key: "HybridKEMPublicKey",
    dek_version: str,
    min_priority: PIIPriority = PIIPriority.HIGH,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Factory function to create a PII encryption enricher.

    Args:
        public_key: HybridKEM public key for encryption
        dek_version: Version identifier for the DEK
        min_priority: Minimum PII priority to encrypt

    Returns:
        Enricher function for TelemetryPipeline

    """
    encryptor = PIIEncryptionEnricher(
        public_key=public_key,
        dek_version=dek_version,
        min_priority=min_priority,
    )
    return encryptor.enrich


def generate_dek_version() -> str:
    """Generate a timestamped DEK version identifier.

    Returns:
        Version string like "dek-v1-20251228"

    """
    return f"dek-v1-{datetime.now(timezone.utc).strftime('%Y%m%d')}"


class DEKRotator:
    """Helper for DEK rotation in telemetry encryption.

    Manages the lifecycle of Data Encryption Keys used for PII encryption:
    - Generate new DEK keypairs
    - Create encryptors/decryptors for each version
    - Track active and historical DEKs

    Example:
        >>> rotator = DEKRotator()
        >>> dek_version, encryptor, decryptor = rotator.generate_dek()
        >>> pipeline.set_pii_encryptor(encryptor)
        >>>
        >>> # After 90 days, rotate
        >>> new_version, new_encryptor, _ = rotator.generate_dek()
        >>> pipeline.set_pii_encryptor(new_encryptor)

    """

    def __init__(self) -> None:
        """Initialize DEK rotator."""
        if not HYBRID_KEM_AVAILABLE:
            raise RuntimeError(
                "HybridKEMProvider not available. "
                "Install liboqs-python>=0.10.0 for post-quantum support.",
            )
        self._kem_provider = HybridKEMProvider()
        self._deks: dict[str, tuple[HybridKEMPublicKey, Any]] = {}
        # BH39-M2: serialize access to _deks to prevent TOCTOU race when two
        # threads call generate_dek() concurrently with the same version string
        # (especially day-granularity auto-generated versions).
        self._lock = threading.Lock()

    def generate_dek(
        self,
        version: Optional[str] = None,
        min_priority: PIIPriority = PIIPriority.HIGH,
    ) -> tuple[str, "PIIEncryptionEnricher", Any]:
        """Generate a new DEK and create encryptor/decryptor.

        Args:
            version: DEK version (auto-generated if None)
            min_priority: Minimum PII priority to encrypt

        Returns:
            Tuple of (dek_version, encryptor, decryptor_private_key)
            Note: decryptor_private_key should be stored securely

        """
        dek_version = version or generate_dek_version()

        # BH39-M2: acquire lock before check-then-write to prevent a TOCTOU
        # race between two threads that call generate_dek() concurrently with
        # the same (auto-generated, day-granularity) version string.
        with self._lock:
            if dek_version in self._deks:
                raise ValueError(
                    f"DEK version {dek_version!r} already exists. "
                    "Provide an explicit unique version string to avoid "
                    "overwriting an existing keypair (which causes data loss)."
                )

            # Generate keypair
            keypair = self._kem_provider.generate_keypair()

            # Create encryptor
            encryptor = PIIEncryptionEnricher(
                public_key=keypair.public,
                dek_version=dek_version,
                min_priority=min_priority,
            )

            # Store public key for reference
            self._deks[dek_version] = (keypair.public, keypair.private)

        logger.info(f"Generated new DEK: version={dek_version}")

        return dek_version, encryptor, keypair.private

    def get_decryptor(
        self,
        dek_version: str,
        verify_integrity: bool = True,
    ) -> Optional[Any]:
        """Get decryptor for a specific DEK version.

        Args:
            dek_version: DEK version to get decryptor for
            verify_integrity: Whether to verify SHA-256 hash

        Returns:
            PIIDecryptor or None if version not found

        """
        from .decryption import PIIDecryptor

        with self._lock:
            dek_data = self._deks.get(dek_version)
        if dek_data is None:
            return None

        _, private_key = dek_data

        return PIIDecryptor(
            private_key=private_key,
            verify_integrity=verify_integrity,
        )

    def list_versions(self) -> list[str]:
        """List all DEK versions."""
        with self._lock:
            return list(self._deks.keys())


__all__ = [
    "DEKCache",
    "DEKEntry",
    "DEKRotator",
    "EncryptedField",
    "PIIEncryptionEnricher",
    "PIIFieldDefinition",
    "PIIManifest",
    "PIIPriority",
    "create_pii_enricher",
    "generate_dek_version",
]
