"""AEGIS Telemetry Pipeline

Implements 100% logging coverage for all guardrail evaluations.
Provides structured telemetry for audit trail, drift detection, and recalibration.

PII Encryption (GAP-Q2 Phase 2):
- PIIManifest: Defines which fields contain PII
- PIIEncryptionEnricher: Pipeline enricher for encrypting PII fields
- PIIDecryptor: Decrypt PII fields with integrity verification
- create_pii_enricher / create_decryptor: Factory functions
"""

from .audit_chain import AuditChain, AuditChainEnricher
from .decryption import (
    DecryptionError,
    DecryptionResult,
    IntegrityError,
    PIIDecryptor,
    create_decryptor,
)
from .emitter import (
    BatchHTTPSink,
    EventType,
    HTTPEventSink,
    TelemetryEmitter,
    TelemetryEvent,
    http_sink,
)
from .encryption import (
    DEKCache,
    DEKRotator,
    EncryptedField,
    PIIEncryptionEnricher,
    PIIManifest,
    PIIPriority,
    create_pii_enricher,
    generate_dek_version,
)
from .pipeline import PipelineConfig, TelemetryPipeline, create_encrypted_pipeline
from .schema import GateTelemetry, ProposalTelemetry, TelemetryRecord

__all__ = [
    "AuditChain",
    "AuditChainEnricher",
    "BatchHTTPSink",
    "DEKCache",
    "DEKRotator",
    "DecryptionError",
    "DecryptionResult",
    "EncryptedField",
    "EventType",
    "GateTelemetry",
    "HTTPEventSink",
    "IntegrityError",
    "PIIDecryptor",
    "PIIEncryptionEnricher",
    "PIIManifest",
    "PIIPriority",
    "PipelineConfig",
    "ProposalTelemetry",
    "TelemetryEmitter",
    "TelemetryEvent",
    "TelemetryPipeline",
    "TelemetryRecord",
    "create_decryptor",
    "create_encrypted_pipeline",
    "create_pii_enricher",
    "generate_dek_version",
    "http_sink",
]
