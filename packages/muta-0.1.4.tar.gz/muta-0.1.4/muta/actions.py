"""Actions do browser. Cada chamada é um step com logging e retry."""

import time
from contextvars import ContextVar
from pathlib import Path
from typing import Any, Callable

from playwright.sync_api import Page

from ._browser import Browser
from ._logging import get_logger
from ._setup import _context_kwargs

logger = get_logger("muta.actions")
_current_page: ContextVar[Page | None] = ContextVar("_current_page", default=None)
_current_pipeline: ContextVar[str] = ContextVar("_current_pipeline", default="")


def _get_page() -> Page:
    """Get or create the current page."""
    page = _current_page.get()
    if page is None:
        page = Browser.new_page(**_context_kwargs())
        _current_page.set(page)
    return page


def _run_step(
    name: str,
    fn: Callable[..., Any],
    *args: Any,
    retry: int = 0,
    **kwargs: Any,
) -> Any:
    """Executa um step com logging e retry."""
    pipeline = _current_pipeline.get("")
    max_attempts = 1 + retry

    for attempt in range(1, max_attempts + 1):
        try:
            result = fn(*args, **kwargs)
            logger.info(f"[{pipeline}] {name} — ok")
            return result
        except Exception as e:
            if attempt < max_attempts:
                delay = 2 ** (attempt - 1)
                logger.warning(f"[{pipeline}] {name} — retry {attempt}/{retry} ({e})")
                time.sleep(delay)
            else:
                logger.error(f"[{pipeline}] {name} — fail: {e}")
                raise


# --- actions ---


def _page_action(method_name: str) -> Callable[..., Any]:
    def action(*args: Any, retry: int = 0, **kwargs: Any) -> Any:
        page = _get_page()
        fn = getattr(page, method_name)
        return _run_step(method_name, fn, *args, retry=retry, **kwargs)

    action.__name__ = method_name
    action.__qualname__ = method_name
    return action


goto = _page_action("goto")


def screenshot(*args: Any, **kwargs: Any) -> Any:
    page = _get_page()
    result = page.screenshot(*args, **kwargs)
    pipeline = _current_pipeline.get("")
    logger.info(f"[{pipeline}] screenshot — ok")
    return result


def press(key: str) -> None:
    page = _get_page()
    page.keyboard.press(key)
    pipeline = _current_pipeline.get("")
    logger.info(f"[{pipeline}] press {key} — ok")


def click(
    selector: str, *, has_text: str | None = None, retry: int = 0, **kwargs: Any
) -> None:
    page = _get_page()
    if has_text:
        selector = f'{selector}:has-text("{has_text}")'
    _run_step("click", page.click, selector, retry=retry, **kwargs)


def fill(
    selector: str | None = None,
    text: str = "",
    *,
    placeholder: str | None = None,
    has_text: str | None = None,
    retry: int = 0,
    keyboard_type: bool = False,
    focus: bool = True,
    **kwargs: Any,
) -> None:
    page = _get_page()
    if placeholder:
        selector = f'[placeholder="{placeholder}"]'
    if has_text and selector:
        selector = f'{selector}:has-text("{has_text}")'
    if not selector:
        raise ValueError("fill requires a selector or placeholder=")
    if keyboard_type:
        if focus:
            page.locator(selector).focus()
        _run_step("fill", page.keyboard.type, text, retry=retry, **kwargs)
    else:
        _run_step("fill", page.locator(selector).fill, text, retry=retry, **kwargs)


def get(
    selector: str, *, has_text: str | None = None, retry: int = 0, **kwargs: Any
) -> str | None:
    page = _get_page()
    if has_text:
        selector = f'{selector}:has-text("{has_text}")'
    return _run_step("get", page.text_content, selector, retry=retry, **kwargs)


def count(selector: str, *, has_text: str | None = None) -> int:
    page = _get_page()
    if has_text:
        selector = f'{selector}:has-text("{has_text}")'
    return page.locator(selector).count()


def wait(
    seconds: float | None = None,
    *,
    for_selector: str | None = None,
    for_url: str | None = None,
    for_state: str | None = None,
    timeout: float | None = None,
) -> None:
    page = _get_page()
    pipeline = _current_pipeline.get("")

    if for_selector is not None:
        kw: dict[str, Any] = {}
        if timeout:
            kw["timeout"] = int(timeout * 1000)
        _run_step("wait", page.wait_for_selector, for_selector, **kw)
    elif for_url is not None:
        kw = {}
        if timeout:
            kw["timeout"] = int(timeout * 1000)
        _run_step("wait url", page.wait_for_url, for_url, **kw)
    elif for_state is not None:
        _run_step("wait state", page.wait_for_load_state, for_state)
    else:
        delay = seconds if seconds is not None else 1
        logger.info(f"[{pipeline}] wait {delay}s")
        page.wait_for_timeout(int(delay * 1000))


def download(
    selector: str,
    has_text: str | None = None,
    *,
    path: str | Path,
    retry: int = 0,
    **kwargs: Any,
) -> None:
    page = _get_page()
    if has_text:
        selector = f'{selector}:has-text("{has_text}")'

    def _do_download() -> None:
        with page.expect_download() as download_info:
            page.click(selector, **kwargs)
        download_info.value.save_as(path)

    _run_step("download", _do_download, retry=retry)
