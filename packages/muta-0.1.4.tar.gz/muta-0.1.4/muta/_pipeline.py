"""Pipeline decorator and registry."""

from typing import Callable

from ._logging import get_logger

logger = get_logger("muta.pipeline")
_PIPELINE_REGISTRY: dict[str, Callable[..., None]] = {}


def pipeline(name: str) -> Callable[[Callable[..., None]], Callable[..., None]]:
    def decorator(fn: Callable[..., None]) -> Callable[..., None]:
        if name in _PIPELINE_REGISTRY:
            logger.warning(f"pipeline '{name}' already registered, overwriting")
        _PIPELINE_REGISTRY[name] = fn
        return fn

    return decorator
