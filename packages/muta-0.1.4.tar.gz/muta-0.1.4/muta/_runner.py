import importlib.util
import sys
import tomllib
from pathlib import Path
from typing import Any

from ._api import serve
from ._browser import Browser
from ._logging import get_logger
from ._pipeline import _PIPELINE_REGISTRY

logger = get_logger("muta.runner")


def _read_config() -> dict[str, Any]:
    path = Path("pyproject.toml")
    if not path.exists():
        return {}
    with open(path, "rb") as file:
        data = tomllib.load(file)
    return data.get("tool", {}).get("muta", {})


def _load_pipelines(directory: str) -> None:
    pipelines_dir = Path(directory)
    if not pipelines_dir.is_dir():
        raise FileNotFoundError(f"pipelines directory not found: {directory}")

    cwd = str(Path.cwd())
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    for path in sorted(pipelines_dir.glob("*.py")):
        if path.stem.startswith("_"):
            continue
        spec = importlib.util.spec_from_file_location(path.stem, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        logger.info(f"loaded {path.name}")


def run(host: str | None = None, port: int | None = None) -> None:
    config = _read_config()
    pipelines = config.get("pipelines", "pipelines")

    _load_pipelines(pipelines)

    if not _PIPELINE_REGISTRY:
        raise ValueError("no pipelines found")

    server_host = host or config.get("host", "0.0.0.0")
    server_port = port or config.get("port", 8000)
    Browser._headless = config.get("headless", True)
    Browser.start()

    try:
        serve(server_host, server_port)
    finally:
        Browser.stop()
