"""HTTP server for running pipelines."""

import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

from ._logging import get_logger
from ._pipeline import _PIPELINE_REGISTRY
from ._setup import _reset
from .actions import _current_page, _current_pipeline

logger = get_logger("muta.api")


def _send_json(
    handler: BaseHTTPRequestHandler, code: int, body: dict[str, Any]
) -> None:
    """Send a JSON response."""
    data = json.dumps(body).encode()
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


def _run_pipeline(name: str, fn: Any) -> dict[str, str]:
    _reset()
    _current_page.set(None)
    _current_pipeline.set(name)
    try:
        fn()
        logger.info(f"[{name}] finished")
        return {"status": "ok"}
    except Exception as error:
        logger.error(f"[{name}] failed: {error}")
        return {"status": "error", "message": str(error)}
    finally:
        page = _current_page.get()
        if page:
            page.context.close()


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        if self.path == "/":
            _send_json(self, 200, {"pipelines": list(_PIPELINE_REGISTRY.keys())})
        else:
            _send_json(self, 404, {"error": "not found"})

    def do_POST(self) -> None:
        name = self.path.strip("/")
        if name == "all":
            results: dict[str, dict[str, str]] = {}
            for n, fn in _PIPELINE_REGISTRY.items():
                results[n] = _run_pipeline(n, fn)
            _send_json(self, 200, results)
        elif name in _PIPELINE_REGISTRY:
            result = _run_pipeline(name, _PIPELINE_REGISTRY[name])
            _send_json(self, 200, result)
        else:
            _send_json(self, 404, {"error": f"pipeline '{name}' not found"})

    def log_message(self, format: str, *args: Any) -> None:
        logger.info(format % args)


def serve(host: str, port: int) -> None:
    server = HTTPServer((host, port), _Handler)
    logger.info(f"serving on {host}:{port}")
    try:
        server.serve_forever()
    finally:
        server.server_close()
