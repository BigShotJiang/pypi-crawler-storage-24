from contextvars import ContextVar
from typing import Any

_certs: ContextVar[list[dict[str, Any]]] = ContextVar("_certs", default=[])


def add_cert(origin: str, path: str, passphrase: str | None = None) -> None:
    """Add a client certificate for a specific origin."""
    cert: dict[str, Any] = {"origin": origin, "pfxPath": path}
    if passphrase:
        cert["passphrase"] = passphrase
    _certs.get().append(cert)


def _context_kwargs() -> dict[str, Any]:
    """Return kwargs for browser.new_context()."""
    certs = _certs.get()
    if certs:
        return {"client_certificates": certs}
    return {}


def _reset() -> None:
    """Reset setup for a new pipeline."""
    _certs.set([])
