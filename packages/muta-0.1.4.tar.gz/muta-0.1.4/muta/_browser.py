import subprocess
import sys
from typing import Any

from playwright.sync_api import (
    Browser as pwBrowser,
)
from playwright.sync_api import (
    Page,
    Playwright,
    sync_playwright,
)

from ._logging import get_logger

logger = get_logger("muta.browser")


class Browser:
    _playwright: Playwright | None = None
    _browser: pwBrowser | None = None
    _headless: bool = True

    @classmethod
    def start(cls) -> None:
        cls._playwright = sync_playwright().start()
        try:
            cls._browser = cls._playwright.chromium.launch(headless=cls._headless)
        except Exception as e:
            if "Executable doesn't exist" not in str(e):
                raise
            cls._playwright.stop()
            logger.info("browser not found, installing chromium...")
            subprocess.run(
                [sys.executable, "-m", "playwright", "install", "chromium"],
                check=True,
            )
            cls._playwright = sync_playwright().start()
            cls._browser = cls._playwright.chromium.launch(headless=cls._headless)
        logger.info("browser started")

    @classmethod
    def stop(cls) -> None:
        if cls._browser:
            cls._browser.close()
        if cls._playwright:
            cls._playwright.stop()
        logger.info("browser stopped")

    @classmethod
    def new_page(cls, **kwargs: Any) -> Page:
        if not cls._browser:
            raise RuntimeError("browser not started. call Browser.start() first.")
        context = cls._browser.new_context(**kwargs)
        return context.new_page()
