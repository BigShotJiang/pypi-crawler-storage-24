"""A home for shared types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ansible_creator.constants import GLOBAL_TEMPLATE_VARS


if TYPE_CHECKING:
    from collections.abc import Sequence


@dataclass
class TemplateData:
    """Dataclass representing the template data.

    Attributes:
        resource_type: The type of resource to be scaffolded.
        plugin_type: The type of plugin to be scaffolded.
        plugin_name: The name of the plugin to be scaffolded.
        role_name: The name of the role to be scaffolded.
        additions: A dictionary containing additional data to add to the gitignore.
        collection_name: The name of the collection.
        creator_version: The version of the creator.
        dev_container_image: The devcontainer image.
        dev_file_image: The devfile image.
        dev_file_name: The unique name entry in devfile.
        namespace: The namespace of the collection.
        execution_environment_image: The execution environment image.
        recommended_extensions: A list of recommended VsCode extensions.
        ee_base_image: Base image for execution environment.
        ee_collections: List of Ansible collections for execution environment (dicts with name,
            version, type, source).
        ee_python_deps: List of Python dependencies for execution environment.
        ee_system_packages: List of system packages for execution environment.
        ee_name: Name/tag for the execution environment image.
        ee_additional_build_files: List of additional files to include in the EE build context.
        ee_additional_build_steps: Dict with prepend_base, append_base, prepend_final,
            append_final steps.
        ee_options: Dict of EE build options (e.g., package_manager_path).
        ee_ansible_cfg: Content for ansible.cfg file (for Automation Hub auth).
    """

    resource_type: str = ""
    plugin_type: str = ""
    plugin_name: str = ""
    role_name: str = ""
    additions: dict[str, dict[str, dict[str, str | bool]]] = field(default_factory=dict)
    collection_name: str = ""
    creator_version: str = ""
    dev_container_image: Sequence[str] = GLOBAL_TEMPLATE_VARS["DEV_CONTAINER_IMAGE"]
    dev_file_image: Sequence[str] = GLOBAL_TEMPLATE_VARS["DEV_FILE_IMAGE"]
    dev_file_name: str = ""
    namespace: str = ""
    execution_environment_image: Sequence[str] = GLOBAL_TEMPLATE_VARS[
        "EXECUTION_ENVIRONMENT_DEFAULT_IMAGE"
    ]
    recommended_extensions: Sequence[str] = field(
        default_factory=lambda: GLOBAL_TEMPLATE_VARS["RECOMMENDED_EXTENSIONS"],
    )
    ee_base_image: str = "quay.io/fedora/fedora:41"
    ee_collections: Sequence[dict[str, str]] = field(default_factory=list)
    ee_python_deps: Sequence[str] = field(default_factory=list)
    ee_system_packages: Sequence[str] = field(default_factory=list)
    ee_name: str = "ansible_sample_ee"
    ee_additional_build_files: Sequence[dict[str, str]] = field(default_factory=list)
    ee_additional_build_steps: dict[str, list[str]] = field(default_factory=dict)
    ee_options: dict[str, Any] = field(default_factory=dict)
    ee_ansible_cfg: str = ""
