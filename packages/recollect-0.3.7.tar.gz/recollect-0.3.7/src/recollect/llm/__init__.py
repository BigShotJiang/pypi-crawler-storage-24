"""LLM provider abstraction for Memory SDK.

Three providers: Anthropic (Claude), OpenAI (gpt-5-mini, o1, o3),
and OpenAI-compatible (Ollama, LM Studio, local LLMs).
"""

from recollect.llm.anthropic import AnthropicProvider
from recollect.llm.openai import OpenAIProvider
from recollect.llm.openai_compat import OpenAICompatProvider
from recollect.llm.protocol import LLMProvider
from recollect.llm.types import (
    CompletionParams,
    Entity,
    ExtractionResult,
    Message,
    Relation,
)

__all__ = [
    "AnthropicProvider",
    "CompletionParams",
    "Entity",
    "ExtractionResult",
    "LLMProvider",
    "Message",
    "OpenAICompatProvider",
    "OpenAIProvider",
    "Relation",
]
