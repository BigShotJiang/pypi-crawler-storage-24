"""LLM provider protocol.

Any class implementing this protocol can be used with PatternExtractor
and other cognitive tasks. Ships with AnthropicProvider and
OpenAICompatProvider, or bring your own.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from recollect.llm.types import Message


class LLMProvider(Protocol):
    """Minimal interface for LLM completion."""

    async def complete(
        self,
        messages: list[Message],
        **kwargs: Any,
    ) -> str:
        """Send messages and return the text response."""
        ...

    @property
    def model_name(self) -> str:
        """Model identifier for logging and debugging."""
        ...
