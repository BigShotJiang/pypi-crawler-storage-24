"""Smoke tests – verify basic connectivity to the Anthropic endpoint."""

import logging

import pytest

from dotpromptz.typing import Message, RenderedPrompt, Role, TextPart

pytestmark = pytest.mark.integration

logger = logging.getLogger(__name__)


@pytest.mark.asyncio
async def test_simple_chat_completion(anthropic_adapter) -> None:
    """Send one user message and verify we get a non-empty response."""
    rendered = RenderedPrompt(
        config={'model': 'claude-haiku-4-5-20251001'},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='Say hello in one word.')]),
        ],
    )

    response = await anthropic_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    assert response.usage is not None
    assert response.usage.total_tokens > 0
    assert response.finish_reason == 'end_turn'
    logger.info('[smoke] response: %r', response.text)
    logger.info('[smoke] tokens:   %s', response.usage.total_tokens)


@pytest.mark.asyncio
async def test_system_and_user_message(anthropic_adapter) -> None:
    """Verify system + user messages work together."""
    rendered = RenderedPrompt(
        config={'model': 'claude-haiku-4-5-20251001'},
        messages=[
            Message(
                role=Role.SYSTEM,
                content=[TextPart(text='You are a helpful assistant. Reply in exactly one word.')],
            ),
            Message(
                role=Role.USER,
                content=[TextPart(text='What color is the sky on a clear day?')],
            ),
        ],
    )

    response = await anthropic_adapter.generate(rendered)

    assert response.text is not None
    assert len(response.text.strip()) > 0
    logger.info('[smoke] response: %r', response.text)


@pytest.mark.asyncio
async def test_thinking_config_low(anthropic_adapter) -> None:
    """Verify thinking config is mapped and works end-to-end."""
    rendered = RenderedPrompt(
        config={'model': 'claude-haiku-4-5-20251001', 'thinking': 'low'},
        messages=[
            Message(role=Role.USER, content=[TextPart(text='Reply with one short greeting word.')]),
        ],
    )

    request = anthropic_adapter.convert(rendered)
    assert request['thinking']['type'] == 'enabled'
    assert request['thinking']['budget_tokens'] >= 1024

    response = await anthropic_adapter.generate(rendered)
    assert response.text is not None
    assert len(response.text.strip()) > 0
