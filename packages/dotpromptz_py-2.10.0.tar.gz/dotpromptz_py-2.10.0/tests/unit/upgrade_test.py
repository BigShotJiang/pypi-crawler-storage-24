"""Tests for upgrade service helpers."""

from types import SimpleNamespace

import pytest

from dotpromptz.errors import UpgradeError
from dotpromptz.upgrade import run_upgrade


def test_run_upgrade_raises_when_uv_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise_file_not_found(*args: object, **kwargs: object) -> object:
        raise FileNotFoundError

    monkeypatch.setattr('dotpromptz.upgrade.subprocess.run', _raise_file_not_found)
    with pytest.raises(UpgradeError, match='uv not found'):
        run_upgrade()


def test_run_upgrade_returns_subprocess_code(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        'dotpromptz.upgrade.subprocess.run',
        lambda *args, **kwargs: SimpleNamespace(returncode=7),
    )
    assert run_upgrade() == 7
