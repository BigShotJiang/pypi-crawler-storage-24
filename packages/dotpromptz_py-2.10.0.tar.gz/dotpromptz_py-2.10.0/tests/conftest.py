"""Shared fixtures for the full test suite."""

import logging
from collections.abc import Iterator

import pytest


def _cleanup_closed_stream_handlers() -> None:
    """Remove handlers whose underlying stream has already been closed."""
    root = logging.getLogger()
    for handler in list(root.handlers):
        stream = getattr(handler, 'stream', None)
        if stream is not None and getattr(stream, 'closed', False):
            root.removeHandler(handler)
            handler.close()


@pytest.fixture(autouse=True)
def _cleanup_logging_handlers() -> Iterator[None]:
    """Prevent cross-test leakage of handlers bound to closed capture streams."""
    yield
    _cleanup_closed_stream_handlers()
