from __future__ import annotations

MODULE_SCOPES: dict[str, list[str]] = {
    "message":  ["im:message", "im:message.p2p_msg:readonly", "im:chat:readonly"],
    "document": ["docx:document", "wiki:wiki"],
    "bitable":  ["bitable:app"],
    "contact":  ["contact:user.base:readonly", "contact:contact.base:readonly", "contact:department.base:readonly"],
    "drive":    ["drive:drive", "drive:file"],
    "sheets":   ["drive:drive", "drive:file"],
    "calendar": ["calendar:calendar:readonly"],
    "minutes":  ["minutes:minutes:readonly"],
    "task":     ["task:task:read", "task:task:write", "task:tasklist:read", "task:tasklist:write"],
    "mail":     ["mail:user_mailbox.message:readonly", "mail:user_mailbox.message:send"],
}

BASE_SCOPES: list[str] = [
    "im:message",
    "im:message.p2p_msg:readonly",
    "im:chat:readonly",
    "docx:document",
    "wiki:wiki",
    "bitable:app",
    "contact:user.base:readonly",
    "contact:contact.base:readonly",
    "contact:department.base:readonly",
]


class InsufficientScopeError(RuntimeError):
    def __init__(self, missing: list[str], module: str = ""):
        self.missing = missing
        self.module = module
        scope_str = " ".join(missing)
        hint = f" (模块: {module})" if module else ""
        super().__init__(f"权限不足{hint}，缺少 scope: {scope_str}")


def scopes_for(*modules: str) -> list[str]:
    result: list[str] = []
    for m in modules:
        for s in MODULE_SCOPES.get(m, []):
            if s not in result:
                result.append(s)
    return result
