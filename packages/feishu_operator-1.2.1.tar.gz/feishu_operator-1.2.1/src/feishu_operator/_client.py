from __future__ import annotations

import lark_oapi as lark

_client: lark.Client | None = None


def get_client() -> lark.Client:
    global _client
    if _client is None:
        _client = (
            lark.Client.builder()
            .enable_set_token(True)
            .log_level(lark.LogLevel.WARNING)
            .build()
        )
    return _client


def make_option(user_access_token: str) -> lark.RequestOption:
    return lark.RequestOption.builder().user_access_token(user_access_token).build()


def reset_client() -> None:
    global _client
    _client = None
