from . import auth, bitable, calendar, contact, document, drive, mail, message, minutes, sheets, task
from ._scopes import InsufficientScopeError, scopes_for

__all__ = [
    "auth",
    "message",
    "document",
    "bitable",
    "contact",
    "drive",
    "calendar",
    "minutes",
    "task",
    "mail",
    "sheets",
    "InsufficientScopeError",
    "scopes_for",
]
