"""Shared test fixtures for pygubernator."""

from __future__ import annotations

from typing import Any

import pytest

from pygubernator._types import AgentResult, Message, ToolResult
from pygubernator.agents._base import BaseAgent
from pygubernator.llm._messages import LLMResponse
from pygubernator.transport._memory import InMemoryTransport

# -- Shared test helpers --


class _MockTool:
    """Simple mock tool for testing."""

    def __init__(self, name: str = "mock") -> None:
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return "A mock tool"

    @property
    def parameters_schema(self) -> dict:
        return {"type": "object", "properties": {}}

    async def execute(self, params: dict) -> ToolResult:
        return ToolResult(tool_name=self._name, success=True, output="done")


class _MockLLMProvider:
    """Mock LLM provider for testing."""

    def __init__(self, responses: list[LLMResponse]) -> None:
        self._responses = list(responses)
        self._idx = 0

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        resp = self._responses[min(self._idx, len(self._responses) - 1)]
        self._idx += 1
        return resp


class _SimpleAgent(BaseAgent):
    """Concrete BaseAgent for testing."""

    def __init__(
        self,
        agent_id: str,
        run_id: str | None = None,
        event_bus: Any | None = None,
    ) -> None:
        super().__init__(agent_id=agent_id, run_id=run_id, event_bus=event_bus)

    async def process(self, message: Message) -> AgentResult:
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
        )


# -- Fixtures --


@pytest.fixture
def transport() -> InMemoryTransport:
    """In-memory transport for testing."""
    return InMemoryTransport()
