"""Tests for local LLM provider (llama-cpp-python)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pygubernator.errors import LLMError
from pygubernator.llm._local import LocalLLMProvider


class TestLocalLLMProvider:
    """Tests for LocalLLMProvider."""

    def test_init(self) -> None:
        p = LocalLLMProvider(model_path="/path/to/model.gguf")
        assert p._model_path == "/path/to/model.gguf"
        assert p._n_ctx == 4096
        assert p._n_gpu_layers == -1
        assert p._llm is None

    def test_init_custom_params(self) -> None:
        p = LocalLLMProvider(
            model_path="/path/to/model.gguf",
            n_ctx=8192,
            n_gpu_layers=0,
            max_tokens=2048,
            temperature=0.5,
            top_p=0.9,
            top_k=40,
        )
        assert p._n_ctx == 8192
        assert p._n_gpu_layers == 0
        assert p._max_tokens == 2048
        assert p._top_p == 0.9
        assert p._top_k == 40

    def test_missing_llama_cpp(self) -> None:
        p = LocalLLMProvider(model_path="/path/to/model.gguf")
        with (
            patch.dict("sys.modules", {"llama_cpp": None}),
            pytest.raises(LLMError, match="llama-cpp-python is required"),
        ):
            p._ensure_loaded()

    def test_build_kwargs_basic(self) -> None:
        p = LocalLLMProvider(
            model_path="/path/to/model.gguf",
            max_tokens=1024,
            temperature=0.7,
        )
        kwargs = p._build_kwargs([{"role": "user", "content": "hello"}])
        assert kwargs["messages"] == [{"role": "user", "content": "hello"}]
        assert kwargs["max_tokens"] == 1024
        assert kwargs["temperature"] == 0.7
        assert "top_p" not in kwargs
        assert "top_k" not in kwargs

    def test_build_kwargs_with_sampling(self) -> None:
        p = LocalLLMProvider(
            model_path="/path/to/model.gguf",
            top_p=0.9,
            top_k=40,
        )
        kwargs = p._build_kwargs([])
        assert kwargs["top_p"] == 0.9
        assert kwargs["top_k"] == 40

    def test_build_kwargs_with_tools(self) -> None:
        p = LocalLLMProvider(model_path="/path/to/model.gguf")
        tools = [{"name": "search", "description": "Search tool"}]
        kwargs = p._build_kwargs([], tools=tools)
        assert "tools" in kwargs
        assert kwargs["tools"][0]["type"] == "function"

    def test_parse_response_text(self) -> None:
        response = {
            "choices": [
                {
                    "message": {"content": "Hello!"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 5,
                "total_tokens": 15,
            },
            "model": "test.gguf",
        }
        resp = LocalLLMProvider._parse_response(response)
        assert resp.content == "Hello!"
        assert resp.finish_reason == "stop"
        assert resp.usage["total_tokens"] == 15

    def test_parse_response_empty_choices(self) -> None:
        response = {"choices": []}
        resp = LocalLLMProvider._parse_response(response)
        assert resp.content == ""
        assert resp.finish_reason == "stop"

    @pytest.mark.asyncio
    async def test_chat_success(self) -> None:
        p = LocalLLMProvider(model_path="/path/to/model.gguf")
        mock_llm = MagicMock()
        mock_llm.create_chat_completion.return_value = {
            "choices": [
                {
                    "message": {"content": "Hi there!"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
            "model": "test.gguf",
        }
        p._llm = mock_llm

        resp = await p.chat([{"role": "user", "content": "hello"}])
        assert resp.content == "Hi there!"
        mock_llm.create_chat_completion.assert_called_once()

    @pytest.mark.asyncio
    async def test_chat_inference_error(self) -> None:
        p = LocalLLMProvider(model_path="/path/to/model.gguf")
        mock_llm = MagicMock()
        mock_llm.create_chat_completion.side_effect = RuntimeError("OOM")
        p._llm = mock_llm

        with pytest.raises(LLMError, match="Local LLM inference failed"):
            await p.chat([{"role": "user", "content": "hello"}])

    @pytest.mark.asyncio
    async def test_chat_with_tools_logs_warning(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        p = LocalLLMProvider(model_path="/path/to/model.gguf")
        mock_llm = MagicMock()
        mock_llm.create_chat_completion.return_value = {
            "choices": [
                {
                    "message": {"content": "result"},
                    "finish_reason": "stop",
                }
            ],
            "model": "test",
        }
        p._llm = mock_llm

        tools = [{"name": "search", "description": "Search"}]
        await p.chat(
            [{"role": "user", "content": "hello"}],
            tools=tools,
        )
        assert "limited tool-calling support" in caplog.text
