"""Tests for agent classes."""

from __future__ import annotations

import pytest
from pystator import StateMachine

from pygubernator._types import Message, StepResult, ToolResult
from pygubernator.agents._llm import LLMAgent
from pygubernator.agents._machines import (
    base_lifecycle_config,
    llm_lifecycle_config,
    pipeline_lifecycle_config,
)
from pygubernator.agents._pipeline import PipelineAgent, PipelineStep
from pygubernator.agents._state_machine import StateMachineAgent
from pygubernator.llm._messages import LLMResponse, ToolCall
from pygubernator.tools._registry import ToolRegistry
from tests.conftest import _MockLLMProvider, _SimpleAgent


class TestBaseAgent:
    """Tests for BaseAgent lifecycle."""

    def test_initial_state(self) -> None:
        agent = _SimpleAgent("test-1")
        assert agent.state == "idle"
        assert agent.agent_id == "test-1"

    def test_start(self) -> None:
        agent = _SimpleAgent("test-1")
        agent.start()
        assert agent.state == "running"

    def test_pause_resume(self) -> None:
        agent = _SimpleAgent("test-1")
        agent.start()
        agent.pause()
        assert agent.state == "paused"
        agent.resume()
        assert agent.state == "running"

    def test_stop(self) -> None:
        agent = _SimpleAgent("test-1")
        agent.start()
        agent.stop()
        assert agent.state == "stopped"

    def test_stop_from_idle(self) -> None:
        agent = _SimpleAgent("test-1")
        agent.stop()
        assert agent.state == "stopped"

    @pytest.mark.asyncio
    async def test_process(self) -> None:
        agent = _SimpleAgent("test-1")
        msg = Message(topic="t", payload={"v": 1})
        result = await agent.process(msg)
        assert result.success
        assert result.messages_processed == 1

    def test_run_id_property(self) -> None:
        agent = _SimpleAgent("test-1", run_id="run-123")
        assert agent.run_id == "run-123"

    def test_set_run_id(self) -> None:
        agent = _SimpleAgent("test-1")
        assert agent.run_id is None
        agent.set_run_id("run-456")
        assert agent.run_id == "run-456"

    @pytest.mark.asyncio
    async def test_emit_with_run_id(self) -> None:
        from pygubernator._events import AgentEventType, EventBus

        bus = EventBus()
        events = []

        class TestHandler:
            async def handle(self, event):
                events.append(event)

        bus.add_handler(TestHandler())
        agent = _SimpleAgent("test-1", event_bus=bus, run_id="run-789")
        await agent._emit(AgentEventType.AGENT_STARTED)
        assert len(events) == 1
        assert events[0].run_id == "run-789"

    @pytest.mark.asyncio
    async def test_emit_explicit_run_id_overrides(self) -> None:
        from pygubernator._events import AgentEventType, EventBus

        bus = EventBus()
        events = []

        class TestHandler:
            async def handle(self, event):
                events.append(event)

        bus.add_handler(TestHandler())
        agent = _SimpleAgent("test-1", event_bus=bus, run_id="run-default")
        await agent._emit(AgentEventType.AGENT_STARTED, run_id="run-explicit")
        assert len(events) == 1
        assert events[0].run_id == "run-explicit"


class TestMachineConfigs:
    """Tests for pre-built machine configs."""

    def test_base_lifecycle(self) -> None:
        config = base_lifecycle_config()
        machine = StateMachine.from_dict(config)
        assert machine.get_initial_state().name == "idle"

    def test_pipeline_lifecycle(self) -> None:
        config = pipeline_lifecycle_config()
        machine = StateMachine.from_dict(config)
        assert machine.get_initial_state().name == "idle"

    def test_llm_lifecycle(self) -> None:
        config = llm_lifecycle_config(max_iterations=5)
        machine = StateMachine.from_dict(config)
        assert machine.get_initial_state().name == "idle"
        assert machine.meta["max_iterations"] == 5


class TestStateMachineAgent:
    """Tests for StateMachineAgent."""

    def test_initial_state(self) -> None:
        workflow = StateMachine.from_dict(base_lifecycle_config())

        def handler(msg: Message, ctx: dict) -> dict:
            return {"event": "start"}

        agent = StateMachineAgent(
            agent_id="sm-1",
            workflow_machine=workflow,
            handler=handler,
        )
        assert agent.workflow_state == "idle"

    @pytest.mark.asyncio
    async def test_process_triggers_transition(self) -> None:
        workflow = StateMachine.from_dict(base_lifecycle_config())

        def handler(msg: Message, ctx: dict) -> dict:
            return {"event": "start"}

        agent = StateMachineAgent(
            agent_id="sm-1",
            workflow_machine=workflow,
            handler=handler,
        )
        msg = Message(topic="t", payload={"v": 1})
        result = await agent.process(msg)
        assert result.success
        assert agent.workflow_state == "running"

    @pytest.mark.asyncio
    async def test_process_handler_error(self) -> None:
        workflow = StateMachine.from_dict(base_lifecycle_config())

        def handler(msg: Message, ctx: dict) -> dict:
            raise RuntimeError("boom")

        agent = StateMachineAgent(
            agent_id="sm-1",
            workflow_machine=workflow,
            handler=handler,
        )
        msg = Message(topic="t")
        result = await agent.process(msg)
        assert not result.success
        assert "boom" in result.errors[0]


# -- Pipeline agent tests --


class _ExtractStep(PipelineStep):
    async def execute(self, data) -> StepResult:
        return StepResult(
            step_name=self.name,
            success=True,
            data={"extracted": data},
            duration_ms=1.0,
        )


class _TransformStep(PipelineStep):
    async def execute(self, data) -> StepResult:
        return StepResult(
            step_name=self.name,
            success=True,
            data={"transformed": data},
            duration_ms=2.0,
        )


class _LoadStep(PipelineStep):
    async def execute(self, data) -> StepResult:
        return StepResult(
            step_name=self.name,
            success=True,
            data={"loaded": True},
            duration_ms=3.0,
        )


class _FailStep(PipelineStep):
    async def execute(self, data) -> StepResult:
        return StepResult(
            step_name=self.name,
            success=False,
            error="step failed",
            duration_ms=0.0,
        )


class TestPipelineAgent:
    """Tests for PipelineAgent."""

    @pytest.mark.asyncio
    async def test_successful_pipeline(self) -> None:
        agent = PipelineAgent(
            agent_id="pipe-1",
            steps=[
                _ExtractStep("extract"),
                _TransformStep("transform"),
                _LoadStep("load"),
            ],
        )
        msg = Message(topic="t", payload={"data": "raw"})
        result = await agent.process(msg)
        assert result.success
        assert result.messages_processed == 1
        assert len(result.metadata["steps"]) == 3

    @pytest.mark.asyncio
    async def test_failed_step(self) -> None:
        agent = PipelineAgent(
            agent_id="pipe-1",
            steps=[
                _ExtractStep("extract"),
                _FailStep("transform"),
                _LoadStep("load"),
            ],
        )
        msg = Message(topic="t", payload={"data": "raw"})
        result = await agent.process(msg)
        assert not result.success
        assert len(result.errors) == 1
        assert "transform" in result.errors[0]

    @pytest.mark.asyncio
    async def test_exception_in_step(self) -> None:
        class _ErrorStep(PipelineStep):
            async def execute(self, data) -> StepResult:
                raise RuntimeError("kaboom")

        agent = PipelineAgent(
            agent_id="pipe-1",
            steps=[_ErrorStep("bad")],
        )
        msg = Message(topic="t", payload={})
        result = await agent.process(msg)
        assert not result.success
        assert "kaboom" in result.errors[0]


# -- LLM agent tests --


class TestLLMAgent:
    """Tests for LLMAgent."""

    @pytest.mark.asyncio
    async def test_simple_response(self) -> None:
        provider = _MockLLMProvider(
            [
                LLMResponse(content="Hello!", finish_reason="stop"),
            ]
        )
        agent = LLMAgent(
            agent_id="llm-1",
            llm_provider=provider,
            system_prompt="You are helpful.",
        )
        msg = Message(topic="t", payload={"content": "Hi"})
        result = await agent.process(msg)
        assert result.success
        assert result.metadata["response"] == "Hello!"
        assert result.metadata["iterations"] == 1

    @pytest.mark.asyncio
    async def test_tool_calling(self) -> None:
        registry = ToolRegistry()

        class _SearchTool:
            @property
            def name(self) -> str:
                return "search"

            @property
            def description(self) -> str:
                return "Search"

            @property
            def parameters_schema(self) -> dict:
                return {}

            async def execute(self, params) -> ToolResult:
                return ToolResult(
                    tool_name="search",
                    success=True,
                    output="found it",
                )

        registry.register(_SearchTool())

        provider = _MockLLMProvider(
            [
                LLMResponse(
                    content="Let me search",
                    tool_calls=(
                        ToolCall(
                            id="tc1",
                            name="search",
                            arguments={"q": "test"},
                        ),
                    ),
                    finish_reason="tool_calls",
                ),
                LLMResponse(
                    content="I found the answer!",
                    finish_reason="stop",
                ),
            ]
        )

        agent = LLMAgent(
            agent_id="llm-1",
            llm_provider=provider,
            tool_registry=registry,
        )
        msg = Message(topic="t", payload={"content": "find something"})
        result = await agent.process(msg)
        assert result.success
        assert result.metadata["iterations"] == 2
        assert len(result.metadata["tool_results"]) == 1

    @pytest.mark.asyncio
    async def test_llm_error(self) -> None:
        class _FailProvider:
            async def chat(self, messages, tools=None):
                raise RuntimeError("API error")

        agent = LLMAgent(
            agent_id="llm-1",
            llm_provider=_FailProvider(),
        )
        msg = Message(topic="t", payload={"content": "hi"})
        result = await agent.process(msg)
        assert not result.success
        assert "API error" in result.errors[0]


# -- BaseAgent ergonomics tests --


class TestBaseAgentIsProperties:
    """Tests for is_* convenience properties."""

    def test_is_idle(self) -> None:
        agent = _SimpleAgent("a1")
        assert agent.is_idle
        assert not agent.is_running

    def test_is_running(self) -> None:
        agent = _SimpleAgent("a1")
        agent.start()
        assert agent.is_running
        assert not agent.is_idle

    def test_is_paused(self) -> None:
        agent = _SimpleAgent("a1")
        agent.start()
        agent.pause()
        assert agent.is_paused

    def test_is_stopped(self) -> None:
        agent = _SimpleAgent("a1")
        agent.stop()
        assert agent.is_stopped

    def test_is_error_false_by_default(self) -> None:
        agent = _SimpleAgent("a1")
        assert not agent.is_error


class TestBaseAgentRepr:
    """Tests for __repr__."""

    def test_repr_idle(self) -> None:
        agent = _SimpleAgent("my-agent")
        r = repr(agent)
        assert r == "_SimpleAgent(agent_id='my-agent', state='idle')"

    def test_repr_running(self) -> None:
        agent = _SimpleAgent("my-agent")
        agent.start()
        assert "state='running'" in repr(agent)


class TestBaseAgentAsyncContextManager:
    """Tests for async context manager protocol."""

    @pytest.mark.asyncio
    async def test_starts_and_stops(self) -> None:
        agent = _SimpleAgent("ctx-1")
        async with agent as a:
            assert a is agent
            assert a.is_running
        assert agent.is_stopped

    @pytest.mark.asyncio
    async def test_stops_on_exception(self) -> None:
        agent = _SimpleAgent("ctx-2")
        with pytest.raises(RuntimeError, match="boom"):
            async with agent:
                assert agent.is_running
                raise RuntimeError("boom")
        assert agent.is_stopped

    @pytest.mark.asyncio
    async def test_does_not_stop_if_already_stopped(self) -> None:
        agent = _SimpleAgent("ctx-3")
        async with agent:
            agent.stop()
            assert agent.is_stopped
        # Should not raise — __aexit__ skips stop() when already stopped.
        assert agent.is_stopped
