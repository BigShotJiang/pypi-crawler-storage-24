"""Tests for OpenTelemetry observability handlers."""

from __future__ import annotations

from collections.abc import Sequence

import pytest
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import InMemoryMetricReader
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    ReadableSpan,
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)
from opentelemetry.trace import StatusCode

from pygubernator._events import AgentEvent, AgentEventType
from pygubernator.observability._metrics import OTelMetricsHandler
from pygubernator.observability._tracing import OTelEventHandler, configure_tracing


class _CollectingExporter(SpanExporter):
    """In-memory span exporter for tests."""

    def __init__(self) -> None:
        self.spans: list[ReadableSpan] = []

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        self.spans.extend(spans)
        return SpanExportResult.SUCCESS

    def shutdown(self) -> None:
        pass


# -- Tracing tests --


class TestOTelEventHandler:
    """Tests for OTelEventHandler span management."""

    def _make_handler(self) -> tuple[OTelEventHandler, _CollectingExporter]:
        """Create a handler with a dedicated tracer provider."""
        exporter = _CollectingExporter()
        provider = TracerProvider()
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        handler = OTelEventHandler(tracer_provider=provider)
        return handler, exporter

    @pytest.mark.asyncio
    async def test_run_span_created_and_ended(self) -> None:
        handler, exporter = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.RUN_STARTED,
                agent_id="a1",
                data={"mode": "batch"},
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.RUN_COMPLETED,
                agent_id="a1",
                data={"success": True},
            )
        )

        assert len(exporter.spans) == 1
        assert "run:a1" in exporter.spans[0].name

    @pytest.mark.asyncio
    async def test_child_spans_for_steps(self) -> None:
        handler, exporter = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.STEP_STARTED,
                agent_id="a1",
                data={"step_name": "extract"},
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.STEP_COMPLETED,
                agent_id="a1",
                data={"step_name": "extract", "duration_ms": 42},
            )
        )

        assert len(exporter.spans) == 1
        assert "extract" in exporter.spans[0].name

    @pytest.mark.asyncio
    async def test_failed_span_has_error_status(self) -> None:
        handler, exporter = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.STEP_STARTED,
                agent_id="a1",
                data={"step_name": "load"},
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.STEP_FAILED,
                agent_id="a1",
                data={"step_name": "load", "error": "db down"},
            )
        )

        assert len(exporter.spans) == 1
        assert exporter.spans[0].status.status_code == StatusCode.ERROR

    @pytest.mark.asyncio
    async def test_tool_call_spans(self) -> None:
        handler, exporter = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.TOOL_CALL_STARTED,
                agent_id="a1",
                data={"tool_name": "search"},
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.TOOL_CALL_COMPLETED,
                agent_id="a1",
                data={"tool_name": "search"},
            )
        )

        assert len(exporter.spans) == 1
        assert "search" in exporter.spans[0].name

    @pytest.mark.asyncio
    async def test_run_failure_has_error_status(self) -> None:
        handler, exporter = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.RUN_STARTED,
                agent_id="a1",
                data={"mode": "batch"},
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.RUN_COMPLETED,
                agent_id="a1",
                data={"success": False},
            )
        )

        assert len(exporter.spans) == 1
        assert exporter.spans[0].status.status_code == StatusCode.ERROR

    @pytest.mark.asyncio
    async def test_llm_request_span(self) -> None:
        handler, exporter = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.LLM_REQUEST_STARTED,
                agent_id="a1",
                data={"iteration": 1},
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.LLM_RESPONSE_RECEIVED,
                agent_id="a1",
                data={"iteration": 1},
            )
        )

        assert len(exporter.spans) == 1


# -- configure_tracing test --


class TestConfigureTracing:
    """Tests for configure_tracing helper."""

    def test_returns_provider(self) -> None:
        exporter = _CollectingExporter()
        provider = configure_tracing(
            service_name="test-svc",
            exporter=exporter,
        )
        assert isinstance(provider, TracerProvider)


# -- Metrics tests --


class TestOTelMetricsHandler:
    """Tests for OTelMetricsHandler counters and histograms."""

    def _make_handler(
        self,
    ) -> tuple[OTelMetricsHandler, InMemoryMetricReader]:
        """Create a handler with a dedicated meter provider."""
        reader = InMemoryMetricReader()
        provider = MeterProvider(metric_readers=[reader])
        handler = OTelMetricsHandler(meter_provider=provider)
        return handler, reader

    @pytest.mark.asyncio
    async def test_counter_incremented(self) -> None:
        handler, reader = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.MESSAGE_PROCESSED,
                agent_id="a1",
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.MESSAGE_PROCESSED,
                agent_id="a1",
            )
        )

        data = reader.get_metrics_data()
        metrics_list = []
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for metric in scope_metric.metrics:
                    metrics_list.append(metric)

        counter_metric = next(
            (m for m in metrics_list if m.name == "agent.messages.processed"),
            None,
        )
        assert counter_metric is not None
        total = sum(dp.value for dp in counter_metric.data.data_points)
        assert total == 2

    @pytest.mark.asyncio
    async def test_histogram_recorded(self) -> None:
        handler, reader = self._make_handler()

        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.STEP_COMPLETED,
                agent_id="a1",
                data={"step_name": "transform", "duration_ms": 55.0},
            )
        )

        data = reader.get_metrics_data()
        metrics_list = []
        for resource_metric in data.resource_metrics:
            for scope_metric in resource_metric.scope_metrics:
                for metric in scope_metric.metrics:
                    metrics_list.append(metric)

        hist_metric = next(
            (m for m in metrics_list if m.name == "agent.step.duration_ms"),
            None,
        )
        assert hist_metric is not None
        assert hist_metric.data.data_points[0].count == 1
