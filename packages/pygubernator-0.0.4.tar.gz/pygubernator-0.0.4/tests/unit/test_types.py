"""Tests for core value objects."""

from __future__ import annotations

import pytest

from pygubernator._types import AgentResult, Message, StepResult, ToolResult


class TestMessage:
    """Tests for Message dataclass."""

    def test_create_minimal(self) -> None:
        msg = Message(topic="t")
        assert msg.topic == "t"
        assert msg.key is None
        assert msg.payload == {}
        assert msg.headers == {}
        assert msg.timestamp is None

    def test_create_full(self) -> None:
        msg = Message(
            topic="orders",
            key="order-1",
            payload={"amount": 100},
            headers={"source": "api"},
            timestamp=1234.5,
        )
        assert msg.topic == "orders"
        assert msg.key == "order-1"
        assert msg.payload == {"amount": 100}

    def test_to_dict(self) -> None:
        msg = Message(topic="t", key="k", payload={"v": 1})
        d = msg.to_dict()
        assert d["topic"] == "t"
        assert d["key"] == "k"
        assert d["payload"] == {"v": 1}

    def test_frozen(self) -> None:
        msg = Message(topic="t")
        with pytest.raises(AttributeError):
            msg.topic = "other"  # type: ignore[misc]


class TestToolResult:
    """Tests for ToolResult dataclass."""

    def test_success(self) -> None:
        r = ToolResult(tool_name="search", success=True, output="found")
        assert r.success
        assert r.output == "found"
        assert r.error is None

    def test_failure(self) -> None:
        r = ToolResult(tool_name="search", success=False, error="not found")
        assert not r.success
        assert r.error == "not found"

    def test_to_dict(self) -> None:
        r = ToolResult(tool_name="t", success=True, output=42)
        d = r.to_dict()
        assert d["tool_name"] == "t"
        assert d["success"] is True
        assert d["output"] == 42


class TestAgentResult:
    """Tests for AgentResult dataclass."""

    def test_success(self) -> None:
        r = AgentResult(agent_id="a1", success=True, messages_processed=5)
        assert r.agent_id == "a1"
        assert r.messages_processed == 5
        assert r.errors == []

    def test_failure_with_errors(self) -> None:
        r = AgentResult(
            agent_id="a1",
            success=False,
            errors=["timeout", "retry failed"],
        )
        assert not r.success
        assert len(r.errors) == 2

    def test_to_dict(self) -> None:
        r = AgentResult(agent_id="a1", success=True)
        d = r.to_dict()
        assert d["agent_id"] == "a1"


class TestStepResult:
    """Tests for StepResult dataclass."""

    def test_success(self) -> None:
        r = StepResult(
            step_name="extract",
            success=True,
            data={"rows": 100},
            duration_ms=50.0,
        )
        assert r.success
        assert r.data == {"rows": 100}

    def test_to_dict(self) -> None:
        r = StepResult(step_name="s", success=True, duration_ms=10.0)
        d = r.to_dict()
        assert d["step_name"] == "s"
        assert d["duration_ms"] == 10.0
