"""Shared fixtures for unit tests that need a database."""

from __future__ import annotations

from sqlalchemy import inspect, text

from pygubernator.db.base import Base, get_engine
from pygubernator.db.session import set_engine

# Single in-memory engine shared across all DB tests, with schema
# stripping enabled so pygubernator-schema models work on SQLite.
test_engine = get_engine("sqlite:///:memory:")
set_engine(test_engine)


def reset_test_db() -> None:
    """Drop all existing tables and recreate from metadata.

    Uses raw SQL for the drop because ``Base.metadata.drop_all`` relies
    on the inspector to find tables in schema ``pygubernator``, which
    SQLite doesn't support.  After the drop, ``create_all`` succeeds
    because the inspector sees no tables (schema miss) and the DDL has
    the schema prefix stripped by ``get_engine``'s event listener.
    """
    with test_engine.connect() as conn:
        conn.execute(text("PRAGMA foreign_keys=OFF"))
        for name in inspect(test_engine).get_table_names():
            conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
        # Also drop alembic_version if present
        conn.execute(text("DROP TABLE IF EXISTS alembic_version"))
        conn.execute(text("PRAGMA foreign_keys=ON"))
        conn.commit()
    Base.metadata.create_all(bind=test_engine)
