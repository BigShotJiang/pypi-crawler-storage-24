"""Tests for transport layer."""

from __future__ import annotations

import pytest

from pygubernator._types import Message
from pygubernator.transport._memory import InMemoryTransport


class TestInMemoryTransport:
    """Tests for InMemoryTransport."""

    @pytest.mark.asyncio
    async def test_produce_and_consume(self) -> None:
        transport = InMemoryTransport()
        msg = Message(topic="t", payload={"v": 1})
        await transport.produce(msg)
        consumed = await transport.consume("t", max_messages=10)
        assert len(consumed) == 1
        assert consumed[0].payload == {"v": 1}

    @pytest.mark.asyncio
    async def test_inject(self) -> None:
        transport = InMemoryTransport()
        messages = [Message(topic="t", payload={"i": i}) for i in range(3)]
        transport.inject("t", messages)
        consumed = await transport.consume("t", max_messages=10)
        assert len(consumed) == 3

    @pytest.mark.asyncio
    async def test_consume_empty(self) -> None:
        transport = InMemoryTransport()
        consumed = await transport.consume("empty-topic")
        assert consumed == []

    @pytest.mark.asyncio
    async def test_produced_messages(self) -> None:
        transport = InMemoryTransport()
        msg = Message(topic="t", payload={"v": 1})
        await transport.produce(msg)
        assert len(transport.produced_messages) == 1

    @pytest.mark.asyncio
    async def test_close(self) -> None:
        transport = InMemoryTransport()
        assert not transport.is_closed
        await transport.close()
        assert transport.is_closed

    @pytest.mark.asyncio
    async def test_commit_noop(self) -> None:
        transport = InMemoryTransport()
        await transport.commit()

    @pytest.mark.asyncio
    async def test_clear(self) -> None:
        transport = InMemoryTransport()
        transport.inject("t", [Message(topic="t")])
        await transport.produce(Message(topic="t"))
        transport.clear()
        assert transport.produced_messages == []
        consumed = await transport.consume("t")
        assert consumed == []

    @pytest.mark.asyncio
    async def test_multiple_topics(self) -> None:
        transport = InMemoryTransport()
        transport.inject("a", [Message(topic="a", payload={"t": "a"})])
        transport.inject("b", [Message(topic="b", payload={"t": "b"})])
        a = await transport.consume("a")
        b = await transport.consume("b")
        assert len(a) == 1
        assert len(b) == 1
        assert a[0].payload["t"] == "a"
        assert b[0].payload["t"] == "b"
