"""Tests for database CLI commands."""

from __future__ import annotations

import os

from pygubernator.db.cli import cmd_current, cmd_init


class TestCmdInitSqlite:
    """Tests for cmd_init with SQLite."""

    def test_init_creates_tables(self, tmp_path: object) -> None:
        """Init creates database via Alembic migrations."""
        db_path = os.path.join(str(tmp_path), "test.db")
        db_url = f"sqlite:///{db_path}"
        result = cmd_init(database_url=db_url)
        assert result == 0
        assert os.path.exists(db_path)

    def test_init_force_reinitializes(self, tmp_path: object) -> None:
        """Init with --force drops and recreates tables."""
        db_path = os.path.join(str(tmp_path), "test.db")
        db_url = f"sqlite:///{db_path}"
        assert cmd_init(database_url=db_url) == 0
        # Re-init with force should succeed
        assert cmd_init(database_url=db_url, force=True) == 0

    def test_init_without_force_warns(self, tmp_path: object) -> None:
        """Init without --force on existing DB returns error."""
        db_path = os.path.join(str(tmp_path), "test.db")
        db_url = f"sqlite:///{db_path}"
        assert cmd_init(database_url=db_url) == 0
        # Second init without force should fail
        assert cmd_init(database_url=db_url) == 1


class TestCmdCurrentUninitialized:
    """Tests for cmd_current on uninitialized database."""

    def test_returns_1(self, tmp_path: object) -> None:
        """Current on empty DB returns exit code 1."""
        db_path = os.path.join(str(tmp_path), "empty.db")
        db_url = f"sqlite:///{db_path}"
        result = cmd_current(database_url=db_url)
        assert result == 1


class TestCmdCurrentInitialized:
    """Tests for cmd_current after init."""

    def test_shows_revision(self, tmp_path: object) -> None:
        """Current on initialized DB shows revision."""
        db_path = os.path.join(str(tmp_path), "test.db")
        db_url = f"sqlite:///{db_path}"
        cmd_init(database_url=db_url)
        result = cmd_current(database_url=db_url)
        assert result == 0
