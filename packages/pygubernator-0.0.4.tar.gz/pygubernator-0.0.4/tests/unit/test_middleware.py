"""Tests for middleware chain and built-in middleware."""

from __future__ import annotations

import logging
from typing import Any

import pytest

from pygubernator._middleware import MiddlewareChain, NextFn
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.errors import AgentError
from pygubernator.middleware._logging import LoggingMiddleware
from pygubernator.middleware._retry import RetryMiddleware
from pygubernator.middleware._timeout import TimeoutMiddleware
from pygubernator.middleware._validation import ValidationMiddleware

# -- Helpers --


class _EchoAgent(BaseAgent):
    """Agent that echoes the message topic in metadata."""

    async def process(self, message: Message) -> AgentResult:
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
            metadata={"topic": message.topic},
        )


class _FailAgent(BaseAgent):
    """Agent that always returns failure."""

    async def process(self, message: Message) -> AgentResult:
        return AgentResult(
            agent_id=self.agent_id,
            success=False,
            errors=["always fails"],
        )


class _ErrorAgent(BaseAgent):
    """Agent that always raises."""

    async def process(self, message: Message) -> AgentResult:
        raise RuntimeError("kaboom")


@pytest.fixture
def msg() -> Message:
    return Message(topic="test", payload={"content": "hi"})


# -- MiddlewareChain tests --


class TestMiddlewareChain:
    """Tests for MiddlewareChain onion pattern."""

    @pytest.mark.asyncio
    async def test_no_middleware(self, msg: Message) -> None:
        agent = _EchoAgent("a1")
        chain = MiddlewareChain(agent)
        result = await chain.process(msg)
        assert result.success
        assert result.metadata["topic"] == "test"

    @pytest.mark.asyncio
    async def test_single_middleware(self, msg: Message) -> None:
        agent = _EchoAgent("a1")
        order: list[str] = []

        async def mw(
            message: Message,
            agent: BaseAgent,
            next_fn: NextFn,
        ) -> AgentResult:
            order.append("before")
            result = await next_fn(message, agent)
            order.append("after")
            return result

        chain = MiddlewareChain(agent, [mw])
        result = await chain.process(msg)
        assert result.success
        assert order == ["before", "after"]

    @pytest.mark.asyncio
    async def test_middleware_ordering(self, msg: Message) -> None:
        agent = _EchoAgent("a1")
        order: list[str] = []

        async def mw_outer(
            message: Message,
            agent: BaseAgent,
            next_fn: NextFn,
        ) -> AgentResult:
            order.append("outer_before")
            result = await next_fn(message, agent)
            order.append("outer_after")
            return result

        async def mw_inner(
            message: Message,
            agent: BaseAgent,
            next_fn: NextFn,
        ) -> AgentResult:
            order.append("inner_before")
            result = await next_fn(message, agent)
            order.append("inner_after")
            return result

        chain = MiddlewareChain(agent, [mw_outer, mw_inner])
        await chain.process(msg)
        assert order == [
            "outer_before",
            "inner_before",
            "inner_after",
            "outer_after",
        ]

    @pytest.mark.asyncio
    async def test_add_middleware(self, msg: Message) -> None:
        agent = _EchoAgent("a1")
        chain = MiddlewareChain(agent)
        called = False

        async def mw(
            message: Message,
            agent: BaseAgent,
            next_fn: NextFn,
        ) -> AgentResult:
            nonlocal called
            called = True
            return await next_fn(message, agent)

        chain.add(mw)
        await chain.process(msg)
        assert called


# -- RetryMiddleware tests --


class TestRetryMiddleware:
    """Tests for RetryMiddleware."""

    @pytest.mark.asyncio
    async def test_no_retry_on_success(self, msg: Message) -> None:
        agent = _EchoAgent("a1")
        mw = RetryMiddleware(max_retries=3, base_delay=0.001)
        chain = MiddlewareChain(agent, [mw])
        result = await chain.process(msg)
        assert result.success

    @pytest.mark.asyncio
    async def test_retries_on_failure_result(self, msg: Message) -> None:
        call_count = 0

        class _CountingFailAgent(BaseAgent):
            async def process(self, message: Message) -> AgentResult:
                nonlocal call_count
                call_count += 1
                if call_count < 3:
                    return AgentResult(
                        agent_id=self.agent_id,
                        success=False,
                        errors=["fail"],
                    )
                return AgentResult(
                    agent_id=self.agent_id,
                    success=True,
                    messages_processed=1,
                )

        agent = _CountingFailAgent("a1")
        mw = RetryMiddleware(max_retries=3, base_delay=0.001)
        chain = MiddlewareChain(agent, [mw])
        result = await chain.process(msg)
        assert result.success
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_retries_on_exception(self, msg: Message) -> None:
        call_count = 0

        class _EventualAgent(BaseAgent):
            async def process(self, message: Message) -> AgentResult:
                nonlocal call_count
                call_count += 1
                if call_count < 2:
                    raise RuntimeError("transient")
                return AgentResult(
                    agent_id=self.agent_id,
                    success=True,
                    messages_processed=1,
                )

        agent = _EventualAgent("a1")
        mw = RetryMiddleware(max_retries=3, base_delay=0.001)
        chain = MiddlewareChain(agent, [mw])
        result = await chain.process(msg)
        assert result.success

    @pytest.mark.asyncio
    async def test_exhausted_retries_raises(self, msg: Message) -> None:
        agent = _ErrorAgent("a1")
        mw = RetryMiddleware(max_retries=2, base_delay=0.001)
        chain = MiddlewareChain(agent, [mw])
        with pytest.raises(RuntimeError, match="kaboom"):
            await chain.process(msg)

    @pytest.mark.asyncio
    async def test_retry_on_filter(self, msg: Message) -> None:
        agent = _ErrorAgent("a1")
        mw = RetryMiddleware(
            max_retries=2,
            base_delay=0.001,
            retry_on=(ValueError,),
        )
        chain = MiddlewareChain(agent, [mw])
        # RuntimeError does not match retry_on, should raise immediately
        with pytest.raises(RuntimeError, match="kaboom"):
            await chain.process(msg)


# -- TimeoutMiddleware tests --


class TestTimeoutMiddleware:
    """Tests for TimeoutMiddleware."""

    @pytest.mark.asyncio
    async def test_no_timeout(self, msg: Message) -> None:
        agent = _EchoAgent("a1")
        mw = TimeoutMiddleware(timeout_seconds=5.0)
        chain = MiddlewareChain(agent, [mw])
        result = await chain.process(msg)
        assert result.success

    @pytest.mark.asyncio
    async def test_timeout_exceeded(self, msg: Message) -> None:
        import asyncio

        class _SlowAgent(BaseAgent):
            async def process(self, message: Message) -> AgentResult:
                await asyncio.sleep(10)
                return AgentResult(agent_id=self.agent_id, success=True)

        agent = _SlowAgent("a1")
        mw = TimeoutMiddleware(timeout_seconds=0.05)
        chain = MiddlewareChain(agent, [mw])
        with pytest.raises(AgentError, match="timed out"):
            await chain.process(msg)


# -- LoggingMiddleware tests --


class TestLoggingMiddleware:
    """Tests for LoggingMiddleware."""

    @pytest.mark.asyncio
    async def test_logs_receipt_and_completion(
        self, msg: Message, caplog: pytest.LogCaptureFixture
    ) -> None:
        agent = _EchoAgent("a1")
        mw = LoggingMiddleware()
        chain = MiddlewareChain(agent, [mw])
        with caplog.at_level(logging.INFO):
            result = await chain.process(msg)
        assert result.success
        assert "received message" in caplog.text
        assert "processed message" in caplog.text

    @pytest.mark.asyncio
    async def test_logs_on_exception(
        self, msg: Message, caplog: pytest.LogCaptureFixture
    ) -> None:
        agent = _ErrorAgent("a1")
        mw = LoggingMiddleware()
        chain = MiddlewareChain(agent, [mw])
        with caplog.at_level(logging.ERROR), pytest.raises(RuntimeError):
            await chain.process(msg)
        assert "failed after" in caplog.text


# -- ValidationMiddleware tests --


class TestValidationMiddleware:
    """Tests for ValidationMiddleware."""

    @pytest.mark.asyncio
    async def test_valid_payload(self, msg: Message) -> None:
        class _OkValidator:
            def validate(self, data: dict[str, Any]) -> bool:
                return True

        agent = _EchoAgent("a1")
        mw = ValidationMiddleware(_OkValidator())
        chain = MiddlewareChain(agent, [mw])
        result = await chain.process(msg)
        assert result.success

    @pytest.mark.asyncio
    async def test_invalid_payload(self, msg: Message) -> None:
        class _FailValidator:
            def validate(self, data: dict[str, Any]) -> bool:
                raise ValueError("bad payload")

        agent = _EchoAgent("a1")
        mw = ValidationMiddleware(_FailValidator())
        chain = MiddlewareChain(agent, [mw])
        with pytest.raises(AgentError, match="validation failed"):
            await chain.process(msg)
