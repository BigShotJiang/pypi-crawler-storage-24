"""Tests for OpenAI-compatible LLM provider."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pygubernator.errors import LLMError
from pygubernator.llm._openai_compat import OpenAICompatibleProvider


class TestOpenAICompatibleProvider:
    """Tests for OpenAICompatibleProvider."""

    def test_init(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="llama3",
        )
        assert p._api_base == "http://localhost:8000/v1"
        assert p._model == "llama3"
        assert p._api_key is None

    def test_init_strips_trailing_slash(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1/",
            model="test",
        )
        assert p._api_base == "http://localhost:8000/v1"

    def test_build_request_body_basic(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test-model",
            max_tokens=1024,
            temperature=0.5,
        )
        body = p._build_request_body([{"role": "user", "content": "hello"}])
        assert body["model"] == "test-model"
        assert body["messages"] == [{"role": "user", "content": "hello"}]
        assert body["max_tokens"] == 1024
        assert body["temperature"] == 0.5
        assert "tools" not in body

    def test_build_request_body_with_tools(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
        )
        tools = [{"name": "search", "description": "Search"}]
        body = p._build_request_body(
            [{"role": "user", "content": "hi"}],
            tools=tools,
        )
        assert "tools" in body
        assert body["tools"][0]["type"] == "function"
        assert body["tools"][0]["function"]["name"] == "search"

    def test_build_request_body_with_top_p(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
            top_p=0.9,
        )
        body = p._build_request_body([])
        assert body["top_p"] == 0.9

    def test_parse_response_text(self) -> None:
        data = {
            "choices": [
                {
                    "message": {"content": "Hello!"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 5,
                "total_tokens": 15,
            },
            "model": "test-model",
        }
        resp = OpenAICompatibleProvider._parse_response(data)
        assert resp.content == "Hello!"
        assert resp.finish_reason == "stop"
        assert resp.model == "test-model"
        assert resp.usage["total_tokens"] == 15
        assert not resp.has_tool_calls

    def test_parse_response_with_tool_calls(self) -> None:
        data = {
            "choices": [
                {
                    "message": {
                        "content": "",
                        "tool_calls": [
                            {
                                "id": "tc1",
                                "function": {
                                    "name": "search",
                                    "arguments": '{"q": "test"}',
                                },
                            }
                        ],
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "model": "test",
        }
        resp = OpenAICompatibleProvider._parse_response(data)
        assert resp.has_tool_calls
        assert len(resp.tool_calls) == 1
        assert resp.tool_calls[0].name == "search"
        assert resp.tool_calls[0].arguments == {"q": "test"}

    def test_parse_response_malformed_tool_args(self) -> None:
        data = {
            "choices": [
                {
                    "message": {
                        "content": "",
                        "tool_calls": [
                            {
                                "id": "tc1",
                                "function": {
                                    "name": "search",
                                    "arguments": "not-json",
                                },
                            }
                        ],
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "model": "test",
        }
        resp = OpenAICompatibleProvider._parse_response(data)
        assert resp.tool_calls[0].arguments == {"raw": "not-json"}

    def test_parse_response_empty_choices(self) -> None:
        data = {"choices": [], "model": "test"}
        resp = OpenAICompatibleProvider._parse_response(data)
        assert resp.content == ""
        assert resp.finish_reason == "stop"

    @pytest.mark.asyncio
    async def test_chat_success(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
        )
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {"content": "Hi!"},
                    "finish_reason": "stop",
                }
            ],
            "model": "test",
        }

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch.object(p, "_make_client", return_value=mock_client):
            resp = await p.chat([{"role": "user", "content": "hello"}])
            assert resp.content == "Hi!"

    @pytest.mark.asyncio
    async def test_chat_http_error(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
        )
        mock_client = AsyncMock()
        mock_client.post = AsyncMock(side_effect=Exception("Connection refused"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with (
            patch.object(p, "_make_client", return_value=mock_client),
            pytest.raises(LLMError, match="Connection refused"),
        ):
            await p.chat([{"role": "user", "content": "hi"}])

    @pytest.mark.asyncio
    async def test_health_check_success(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
        )
        mock_response = MagicMock()
        mock_response.status_code = 200

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch.object(p, "_make_client", return_value=mock_client):
            result = await p.health_check()
            assert result is True

    @pytest.mark.asyncio
    async def test_health_check_failure(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
        )
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=Exception("Connection refused"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch.object(p, "_make_client", return_value=mock_client):
            result = await p.health_check()
            assert result is False

    @pytest.mark.asyncio
    async def test_list_models(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
        )
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [
                {"id": "llama3"},
                {"id": "mistral"},
            ]
        }

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch.object(p, "_make_client", return_value=mock_client):
            models = await p.list_models()
            assert models == ["llama3", "mistral"]

    def test_missing_httpx(self) -> None:
        p = OpenAICompatibleProvider(
            api_base="http://localhost:8000/v1",
            model="test",
        )
        with (
            patch.dict("sys.modules", {"httpx": None}),
            pytest.raises(LLMError, match="httpx is required"),
        ):
            p._make_client()
