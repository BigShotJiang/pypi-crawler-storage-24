"""Tests for LLM provider configuration and registry."""

from __future__ import annotations

from pygubernator.llm._config import (
    KNOWN_PROVIDERS,
    ProviderConfig,
    ProviderPreset,
    ProviderType,
)


class TestProviderType:
    """Tests for ProviderType enum."""

    def test_values(self) -> None:
        assert ProviderType.LITELLM.value == "litellm"
        assert ProviderType.OPENAI_COMPATIBLE.value == "openai_compatible"
        assert ProviderType.LOCAL.value == "local"

    def test_from_string(self) -> None:
        assert ProviderType("litellm") == ProviderType.LITELLM
        assert ProviderType("openai_compatible") == ProviderType.OPENAI_COMPATIBLE
        assert ProviderType("local") == ProviderType.LOCAL


class TestProviderConfig:
    """Tests for ProviderConfig dataclass."""

    def test_create_minimal(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.LITELLM,
            model="gpt-4o",
        )
        assert config.provider_type == ProviderType.LITELLM
        assert config.model == "gpt-4o"
        assert config.api_base is None
        assert config.max_tokens == 4096
        assert config.temperature == 0.0

    def test_create_full(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.OPENAI_COMPATIBLE,
            model="llama3",
            api_base="http://localhost:11434/v1",
            api_key="test-key",
            max_tokens=2048,
            temperature=0.7,
            top_p=0.9,
            top_k=40,
        )
        assert config.api_base == "http://localhost:11434/v1"
        assert config.api_key == "test-key"
        assert config.top_p == 0.9
        assert config.top_k == 40

    def test_frozen(self) -> None:
        config = ProviderConfig(provider_type=ProviderType.LITELLM, model="gpt-4")
        try:
            config.model = "gpt-3.5"  # type: ignore[misc]
            raise AssertionError("Should be frozen")
        except AttributeError:
            pass

    def test_to_dict(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.LOCAL,
            model="test.gguf",
            model_path="/path/to/test.gguf",
        )
        d = config.to_dict()
        assert d["provider_type"] == "local"
        assert d["model"] == "test.gguf"
        assert d["model_path"] == "/path/to/test.gguf"
        assert d["n_ctx"] == 4096

    def test_local_defaults(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.LOCAL,
            model="test.gguf",
        )
        assert config.n_ctx == 4096
        assert config.n_gpu_layers == -1


class TestProviderPreset:
    """Tests for ProviderPreset dataclass."""

    def test_create(self) -> None:
        preset = ProviderPreset(
            provider_type=ProviderType.OPENAI_COMPATIBLE,
            default_api_base="http://localhost:11434/v1",
            requires_api_key=False,
            models=("llama3",),
            description="Test",
        )
        assert preset.requires_api_key is False
        assert preset.models == ("llama3",)

    def test_to_dict(self) -> None:
        preset = ProviderPreset(
            provider_type=ProviderType.LITELLM,
            default_api_base=None,
            requires_api_key=True,
            models=("gpt-4o",),
            description="OpenAI",
        )
        d = preset.to_dict()
        assert d["provider_type"] == "litellm"
        assert d["requires_api_key"] is True
        assert d["models"] == ["gpt-4o"]


class TestKnownProviders:
    """Tests for the KNOWN_PROVIDERS registry."""

    def test_has_expected_entries(self) -> None:
        expected = {
            "openai",
            "anthropic",
            "gemini",
            "ollama",
            "deepseek",
            "glm",
            "vllm",
            "local",
        }
        assert expected <= set(KNOWN_PROVIDERS.keys())

    def test_all_have_required_fields(self) -> None:
        for name, preset in KNOWN_PROVIDERS.items():
            assert isinstance(preset.provider_type, ProviderType), name
            assert isinstance(preset.requires_api_key, bool), name
            assert isinstance(preset.models, tuple), name
            assert isinstance(preset.description, str), name

    def test_ollama_defaults(self) -> None:
        ollama = KNOWN_PROVIDERS["ollama"]
        assert ollama.provider_type == ProviderType.OPENAI_COMPATIBLE
        assert ollama.default_api_base == "http://localhost:11434/v1"
        assert ollama.requires_api_key is False
        assert len(ollama.models) > 0

    def test_deepseek_requires_key(self) -> None:
        ds = KNOWN_PROVIDERS["deepseek"]
        assert ds.requires_api_key is True
        assert "deepseek-chat" in ds.models

    def test_glm_requires_key(self) -> None:
        glm = KNOWN_PROVIDERS["glm"]
        assert glm.requires_api_key is True
        assert "glm-4-plus" in glm.models

    def test_local_no_api(self) -> None:
        local = KNOWN_PROVIDERS["local"]
        assert local.provider_type == ProviderType.LOCAL
        assert local.default_api_base is None
        assert local.requires_api_key is False

    def test_no_duplicate_keys(self) -> None:
        keys = list(KNOWN_PROVIDERS.keys())
        assert len(keys) == len(set(keys))
