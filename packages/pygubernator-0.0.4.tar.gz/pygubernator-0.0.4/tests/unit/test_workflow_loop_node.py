"""Tests for LoopNode."""

from __future__ import annotations

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._loop import LoopNode, LoopNodeFactory


class TestLoopNode:
    """Tests for LoopNode."""

    async def test_iterate_list(self) -> None:
        node = LoopNode(
            "l1",
            config={"collection_key": "items"},
        )
        ctx = NodeContext(
            node_id="l1",
            input_data={"items": [1, 2, 3]},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"items": [1, 2, 3], "count": 3}

    async def test_transform_expression(self) -> None:
        node = LoopNode(
            "l1",
            config={
                "collection_key": "items",
                "item_key": "x",
                "transform": "x * 2",
            },
        )
        ctx = NodeContext(
            node_id="l1",
            input_data={"items": [1, 2, 3]},
        )
        result = await node.execute(ctx)
        assert result.output["items"] == [2, 4, 6]

    async def test_index_variable(self) -> None:
        node = LoopNode(
            "l1",
            config={
                "collection_key": "items",
                "index_key": "i",
                "transform": "i",
            },
        )
        ctx = NodeContext(
            node_id="l1",
            input_data={"items": ["a", "b", "c"]},
        )
        result = await node.execute(ctx)
        assert result.output["items"] == [0, 1, 2]

    async def test_max_iterations_cap(self) -> None:
        node = LoopNode(
            "l1",
            config={
                "collection_key": "items",
                "max_iterations": 2,
            },
        )
        ctx = NodeContext(
            node_id="l1",
            input_data={"items": [1, 2, 3, 4, 5]},
        )
        result = await node.execute(ctx)
        assert result.output["count"] == 2
        assert result.output["items"] == [1, 2]

    async def test_empty_collection(self) -> None:
        node = LoopNode(
            "l1",
            config={"collection_key": "items"},
        )
        ctx = NodeContext(node_id="l1", input_data={"items": []})
        result = await node.execute(ctx)
        assert result.output == {"items": [], "count": 0}

    async def test_missing_collection_fails(self) -> None:
        node = LoopNode(
            "l1",
            config={"collection_key": "missing"},
        )
        ctx = NodeContext(node_id="l1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "not found" in (result.error or "")

    async def test_no_collection_key_fails(self) -> None:
        node = LoopNode("l1", config={})
        ctx = NodeContext(node_id="l1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "collection_key" in (result.error or "")

    async def test_transform_error_fails(self) -> None:
        node = LoopNode(
            "l1",
            config={
                "collection_key": "items",
                "transform": "undefined_var + 1",
            },
        )
        ctx = NodeContext(
            node_id="l1",
            input_data={"items": [1]},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED

    def test_factory(self) -> None:
        factory = LoopNodeFactory()
        node = factory.create("l1", {"collection_key": "items"})
        assert isinstance(node, LoopNode)
        assert node.node_type == "loop"
