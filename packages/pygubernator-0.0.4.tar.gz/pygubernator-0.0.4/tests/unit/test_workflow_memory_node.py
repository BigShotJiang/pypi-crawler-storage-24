"""Tests for memory node, memory stores, and LLM integration."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pygubernator._types import AgentResult
from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._memory import (
    BufferMemoryStore,
    MemoryNode,
    MemoryNodeFactory,
    MemoryStore,
    WindowMemoryStore,
    create_memory_store,
)

# ---------------------------------------------------------------------------
# MemoryStore protocol conformance
# ---------------------------------------------------------------------------


class TestMemoryStoreProtocol:
    """Verify concrete stores satisfy the MemoryStore protocol."""

    def test_buffer_is_memory_store(self) -> None:
        assert isinstance(BufferMemoryStore(), MemoryStore)

    def test_window_is_memory_store(self) -> None:
        assert isinstance(WindowMemoryStore(), MemoryStore)


# ---------------------------------------------------------------------------
# BufferMemoryStore
# ---------------------------------------------------------------------------


class TestBufferMemoryStore:
    """Tests for the unbounded buffer memory store."""

    def test_empty(self) -> None:
        store = BufferMemoryStore()
        assert store.get_messages() == []

    def test_add_and_get(self) -> None:
        store = BufferMemoryStore()
        msgs = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        store.add_messages(msgs)
        assert store.get_messages() == msgs

    def test_retains_all(self) -> None:
        store = BufferMemoryStore()
        for i in range(20):
            store.add_messages([{"role": "user", "content": str(i)}])
        assert len(store.get_messages()) == 20

    def test_returns_copy(self) -> None:
        store = BufferMemoryStore()
        store.add_messages([{"role": "user", "content": "a"}])
        result = store.get_messages()
        result.clear()
        assert len(store.get_messages()) == 1


# ---------------------------------------------------------------------------
# WindowMemoryStore
# ---------------------------------------------------------------------------


class TestWindowMemoryStore:
    """Tests for the sliding-window memory store."""

    def test_empty(self) -> None:
        store = WindowMemoryStore(window_size=5)
        assert store.get_messages() == []

    def test_returns_last_n(self) -> None:
        store = WindowMemoryStore(window_size=3)
        for i in range(6):
            store.add_messages([{"role": "user", "content": str(i)}])
        result = store.get_messages()
        assert len(result) == 3
        assert result[0]["content"] == "3"
        assert result[-1]["content"] == "5"

    def test_fewer_than_window(self) -> None:
        store = WindowMemoryStore(window_size=10)
        store.add_messages([{"role": "user", "content": "only"}])
        assert len(store.get_messages()) == 1

    def test_returns_copy(self) -> None:
        store = WindowMemoryStore(window_size=5)
        store.add_messages([{"role": "user", "content": "a"}])
        result = store.get_messages()
        result.clear()
        assert len(store.get_messages()) == 1


# ---------------------------------------------------------------------------
# create_memory_store factory
# ---------------------------------------------------------------------------


class TestCreateMemoryStore:
    """Tests for the memory store factory function."""

    def test_default_buffer(self) -> None:
        store = create_memory_store()
        assert isinstance(store, BufferMemoryStore)

    def test_explicit_buffer(self) -> None:
        store = create_memory_store("buffer")
        assert isinstance(store, BufferMemoryStore)

    def test_window(self) -> None:
        store = create_memory_store("window", window_size=5)
        assert isinstance(store, WindowMemoryStore)

    def test_unknown_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown memory_type"):
            create_memory_store("unknown")


# ---------------------------------------------------------------------------
# MemoryNode
# ---------------------------------------------------------------------------


class TestMemoryNode:
    """Tests for the MemoryNode workflow node."""

    async def test_creates_store_in_variables(self) -> None:
        node = MemoryNode("mem1", config={})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert "__memory_stores__" in variables
        assert "mem1" in variables["__memory_stores__"]
        assert isinstance(variables["__memory_stores__"]["mem1"], BufferMemoryStore)

    async def test_outputs_history_and_node_id(self) -> None:
        node = MemoryNode("mem1", config={})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.output["__memory_node_id__"] == "mem1"
        assert result.output["__memory_history__"] == []

    async def test_reuses_existing_store(self) -> None:
        node = MemoryNode("mem1", config={})
        store = BufferMemoryStore()
        store.add_messages([{"role": "user", "content": "prior"}])
        variables: dict = {"__memory_stores__": {"mem1": store}}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert len(result.output["__memory_history__"]) == 1
        assert result.output["__memory_history__"][0]["content"] == "prior"
        # Store object should be the same instance
        assert variables["__memory_stores__"]["mem1"] is store

    async def test_window_store_from_config(self) -> None:
        node = MemoryNode("mem1", config={"memory_type": "window", "window_size": 3})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert isinstance(variables["__memory_stores__"]["mem1"], WindowMemoryStore)

    async def test_invalid_memory_type_fails(self) -> None:
        node = MemoryNode("mem1", config={"memory_type": "bad"})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "memory_type" in (result.error or "").lower()

    def test_node_type(self) -> None:
        assert MemoryNode.node_type == "memory"


class TestMemoryNodeFactory:
    """Tests for MemoryNodeFactory."""

    def test_create(self) -> None:
        factory = MemoryNodeFactory()
        node = factory.create("mem1", {"memory_type": "buffer"})
        assert isinstance(node, MemoryNode)
        assert node.node_type == "memory"


# ---------------------------------------------------------------------------
# LLMNode + memory integration
# ---------------------------------------------------------------------------


def _mock_provider(response_text: str = "Hello!") -> MagicMock:
    """Create a mock LLM provider."""
    provider = MagicMock()
    provider.chat = AsyncMock(
        return_value=MagicMock(
            content=response_text,
            tool_calls=[],
        ),
    )
    return provider


def _mock_tool_registry() -> MagicMock:
    """Create a mock tool registry."""
    registry = MagicMock()
    registry.list_tools.return_value = []
    registry.get_schemas.return_value = []
    return registry


class TestLLMNodeWithMemory:
    """Tests for LLMNode memory read/write integration."""

    async def test_history_forwarded_to_agent(self) -> None:
        from pygubernator.workflow.nodes._llm import LLMNode

        history = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        node = LLMNode(
            "llm1",
            config={"prompt_template": "Say {{ text }}"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(
            node_id="llm1",
            input_data={
                "text": "something",
                "__memory_node_id__": "mem1",
                "__memory_history__": history,
            },
        )

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "OK"},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_agent_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            await node.execute(ctx)

            # Verify history was passed to agent.process()
            mock_agent.process.assert_called_once()
            call_kwargs = mock_agent.process.call_args
            assert call_kwargs.kwargs.get("history") == history

    async def test_write_back_to_store(self) -> None:
        from pygubernator.workflow.nodes._llm import LLMNode

        store = BufferMemoryStore()
        node = LLMNode(
            "llm1",
            config={"prompt_template": "Tell me about {{ topic }}"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        variables: dict = {"__memory_stores__": {"mem1": store}}
        ctx = NodeContext(
            node_id="llm1",
            input_data={
                "topic": "cats",
                "__memory_node_id__": "mem1",
                "__memory_history__": [],
            },
            variables=variables,
        )

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "Cats are great"},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_agent_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        messages = store.get_messages()
        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert "cats" in messages[0]["content"]
        assert messages[1] == {"role": "assistant", "content": "Cats are great"}

    async def test_no_memory_no_write(self) -> None:
        """LLMNode without memory keys should not attempt store access."""
        from pygubernator.workflow.nodes._llm import LLMNode

        node = LLMNode(
            "llm1",
            config={"prompt_template": "Hello"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(
            node_id="llm1",
            input_data={},
            variables={},
        )

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "Hi"},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_agent_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        # No __memory_stores__ should have been created
        assert "__memory_stores__" not in ctx.variables


# ---------------------------------------------------------------------------
# LLMAgent history insertion
# ---------------------------------------------------------------------------


class TestLLMAgentHistory:
    """Tests for LLMAgent.process() history parameter."""

    async def test_history_inserted_between_system_and_user(self) -> None:
        from pygubernator._types import Message
        from pygubernator.agents._llm import LLMAgent

        provider = _mock_provider("response")
        # Make chat return an object with no tool calls
        provider.chat = AsyncMock(
            return_value=MagicMock(
                content="response",
                has_tool_calls=False,
                tool_calls=[],
                finish_reason="stop",
            ),
        )
        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            system_prompt="You are helpful",
            max_iterations=1,
        )

        history = [
            {"role": "user", "content": "earlier question"},
            {"role": "assistant", "content": "earlier answer"},
        ]
        message = Message(topic="test", payload={"content": "new question"})

        await agent.process(message, history=history)

        # Inspect the messages arg passed to provider.chat
        call_args = provider.chat.call_args
        messages = call_args.args[0] if call_args.args else call_args.kwargs["messages"]

        assert messages[0] == {"role": "system", "content": "You are helpful"}
        assert messages[1] == {"role": "user", "content": "earlier question"}
        assert messages[2] == {"role": "assistant", "content": "earlier answer"}
        assert messages[3] == {"role": "user", "content": "new question"}

    async def test_no_history_no_extra_messages(self) -> None:
        from pygubernator._types import Message
        from pygubernator.agents._llm import LLMAgent

        provider = _mock_provider("response")
        provider.chat = AsyncMock(
            return_value=MagicMock(
                content="response",
                has_tool_calls=False,
                tool_calls=[],
                finish_reason="stop",
            ),
        )
        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            system_prompt="system",
            max_iterations=1,
        )

        message = Message(topic="test", payload={"content": "hello"})
        await agent.process(message)

        call_args = provider.chat.call_args
        messages = call_args.args[0] if call_args.args else call_args.kwargs["messages"]

        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"


# ---------------------------------------------------------------------------
# SqliteMemoryStore
# ---------------------------------------------------------------------------


class TestSqliteMemoryStore:
    """Tests for the SQLite-backed memory store."""

    def test_empty(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        store = SqliteMemoryStore(db_path=str(tmp_path / "test.db"))
        assert store.get_messages() == []

    def test_add_and_get(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        db = str(tmp_path / "test.db")
        store = SqliteMemoryStore(db_path=db)
        msgs = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        store.add_messages(msgs)
        assert store.get_messages() == msgs

    def test_persistence_across_instances(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        db = str(tmp_path / "test.db")
        store1 = SqliteMemoryStore(db_path=db)
        store1.add_messages([{"role": "user", "content": "persisted"}])

        store2 = SqliteMemoryStore(db_path=db)
        assert len(store2.get_messages()) == 1
        assert store2.get_messages()[0]["content"] == "persisted"

    def test_invalid_table_name(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        with pytest.raises(ValueError, match="Invalid SQL identifier"):
            SqliteMemoryStore(
                db_path=str(tmp_path / "test.db"),
                table_name="DROP TABLE; --",
            )

    def test_factory(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import (
            create_sqlite_store,
        )

        store = create_sqlite_store(
            {"db_path": str(tmp_path / "test.db"), "table_name": "msgs"}
        )
        store.add_messages([{"role": "user", "content": "ok"}])
        assert len(store.get_messages()) == 1


# ---------------------------------------------------------------------------
# create_memory_store — backend routing
# ---------------------------------------------------------------------------


class TestCreateMemoryStoreBackends:
    """Tests for backend routing in create_memory_store."""

    def test_in_memory_default(self) -> None:
        store = create_memory_store()
        assert isinstance(store, BufferMemoryStore)

    def test_in_memory_explicit(self) -> None:
        store = create_memory_store(backend="in_memory")
        assert isinstance(store, BufferMemoryStore)

    def test_unknown_backend_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown memory backend"):
            create_memory_store(backend="nonexistent")

    def test_sqlite_backend(self, tmp_path) -> None:
        store = create_memory_store(
            backend="sqlite",
            config={"db_path": str(tmp_path / "test.db")},
        )
        store.add_messages([{"role": "user", "content": "via factory"}])
        assert len(store.get_messages()) == 1

    def test_postgres_missing_dsn_raises(self) -> None:
        with pytest.raises((ValueError, ImportError)):
            create_memory_store(backend="postgres", config={})

    def test_mongodb_missing_uri_raises(self) -> None:
        with pytest.raises((ValueError, ImportError)):
            create_memory_store(backend="mongodb", config={})


# ---------------------------------------------------------------------------
# MemoryNode with backends
# ---------------------------------------------------------------------------


class TestMemoryNodeBackends:
    """Tests for MemoryNode with different storage backends."""

    async def test_sqlite_backend(self, tmp_path) -> None:
        node = MemoryNode(
            "mem1",
            config={
                "backend": "sqlite",
                "db_path": str(tmp_path / "test.db"),
            },
        )
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert result.output["__memory_history__"] == []
        assert "mem1" in variables["__memory_stores__"]

    async def test_unknown_backend_fails(self) -> None:
        node = MemoryNode("mem1", config={"backend": "nonexistent"})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "Unknown memory backend" in (result.error or "")

    async def test_import_error_fails_gracefully(self) -> None:
        """Missing library produces a clear failure, not a crash."""
        node = MemoryNode(
            "mem1",
            config={"backend": "postgres", "connection_string": "fake"},
        )
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        # Either ImportError (missing psycopg2) or connection error
        assert result.status == NodeStatus.FAILED
