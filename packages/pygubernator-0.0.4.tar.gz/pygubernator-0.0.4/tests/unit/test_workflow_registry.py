"""Tests for NodeTypeRegistry."""

from __future__ import annotations

from typing import Any

import pytest

from pygubernator.errors import NodeError
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import NodeContext, NodeResult, NodeStatus


class _StubNode:
    """Stub node for testing."""

    node_type = "stub"

    def __init__(self, node_id: str, config: dict[str, Any]) -> None:
        self._node_id = node_id
        self._config = config

    async def execute(self, context: NodeContext) -> NodeResult:
        return NodeResult(node_id=self._node_id, status=NodeStatus.SUCCESS)


class _StubFactory:
    """Stub factory for testing."""

    def create(self, node_id: str, config: dict[str, Any]) -> _StubNode:
        return _StubNode(node_id, config)


class TestNodeTypeRegistry:
    """Tests for the NodeTypeRegistry."""

    def test_register_and_has(self) -> None:
        registry = NodeTypeRegistry()
        registry.register("stub", _StubFactory())
        assert registry.has("stub")
        assert not registry.has("unknown")

    def test_register_duplicate_raises(self) -> None:
        registry = NodeTypeRegistry()
        registry.register("stub", _StubFactory())
        with pytest.raises(NodeError, match="already registered"):
            registry.register("stub", _StubFactory())

    def test_get(self) -> None:
        registry = NodeTypeRegistry()
        factory = _StubFactory()
        registry.register("stub", factory)
        assert registry.get("stub") is factory

    def test_get_not_found_raises(self) -> None:
        registry = NodeTypeRegistry()
        with pytest.raises(NodeError, match="not found"):
            registry.get("missing")

    def test_unregister(self) -> None:
        registry = NodeTypeRegistry()
        registry.register("stub", _StubFactory())
        registry.unregister("stub")
        assert not registry.has("stub")

    def test_unregister_not_found_raises(self) -> None:
        registry = NodeTypeRegistry()
        with pytest.raises(NodeError, match="not found"):
            registry.unregister("missing")

    def test_create(self) -> None:
        registry = NodeTypeRegistry()
        registry.register("stub", _StubFactory())
        node = registry.create("n1", "stub", {"key": "val"})
        assert isinstance(node, _StubNode)

    def test_create_not_found_raises(self) -> None:
        registry = NodeTypeRegistry()
        with pytest.raises(NodeError, match="not found"):
            registry.create("n1", "missing")

    def test_list_types(self) -> None:
        registry = NodeTypeRegistry()
        registry.register("b_type", _StubFactory())
        registry.register("a_type", _StubFactory())
        assert registry.list_types() == ["a_type", "b_type"]

    def test_len(self) -> None:
        registry = NodeTypeRegistry()
        assert len(registry) == 0
        registry.register("stub", _StubFactory())
        assert len(registry) == 1

    def test_contains(self) -> None:
        registry = NodeTypeRegistry()
        registry.register("stub", _StubFactory())
        assert "stub" in registry
        assert "other" not in registry
