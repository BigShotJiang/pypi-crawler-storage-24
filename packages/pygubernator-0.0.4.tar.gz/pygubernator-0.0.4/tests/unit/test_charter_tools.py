"""Tests for pycharter tool wrappers (mocking pycharter)."""

from __future__ import annotations

from typing import Any

import pytest

from pygubernator.tools.charter_tools import create_charter_tools


class _MockValidationError:
    """Mock pycharter validation error."""

    def __init__(self, msg: str) -> None:
        self._msg = msg

    def to_dict(self) -> dict[str, Any]:
        return {"message": self._msg}


class _MockResult:
    """Mock pycharter ValidationResult."""

    def __init__(
        self, is_valid: bool, errors: list[_MockValidationError] | None = None
    ) -> None:
        self.is_valid = is_valid
        self.errors = errors or []


class _MockValidator:
    """Mock pycharter Validator."""

    def __init__(self, results: list[_MockResult]) -> None:
        self._results = list(results)
        self._idx = 0

    def validate(self, data: Any) -> _MockResult:
        result = self._results[min(self._idx, len(self._results) - 1)]
        self._idx += 1
        return result


class TestCharterTools:
    """Tests for create_charter_tools factory."""

    def test_factory_returns_two_tools(self) -> None:
        tools = create_charter_tools({})
        assert len(tools) == 2
        names = {t.name for t in tools}
        assert names == {"validate_record", "validate_batch"}

    @pytest.mark.asyncio
    async def test_validate_record_unknown_contract(self) -> None:
        tools = create_charter_tools({})
        vr = next(t for t in tools if t.name == "validate_record")
        result = await vr.execute(
            {
                "record": {"a": 1},
                "contract_name": "missing",
            }
        )
        assert not result.success
        assert "not found" in result.error

    @pytest.mark.asyncio
    async def test_validate_record_valid(self) -> None:
        validator = _MockValidator([_MockResult(is_valid=True)])
        tools = create_charter_tools({"test": validator})
        vr = next(t for t in tools if t.name == "validate_record")
        result = await vr.execute(
            {
                "record": {"a": 1},
                "contract_name": "test",
            }
        )
        assert result.success
        assert result.output["valid"] is True

    @pytest.mark.asyncio
    async def test_validate_record_invalid(self) -> None:
        err = _MockValidationError("field 'x' missing")
        validator = _MockValidator([_MockResult(is_valid=False, errors=[err])])
        tools = create_charter_tools({"test": validator})
        vr = next(t for t in tools if t.name == "validate_record")
        result = await vr.execute(
            {
                "record": {},
                "contract_name": "test",
            }
        )
        assert result.success  # tool succeeded, validation result has errors
        assert result.output["valid"] is False
        assert len(result.output["errors"]) == 1

    @pytest.mark.asyncio
    async def test_validate_batch_summary(self) -> None:
        ok = _MockResult(is_valid=True)
        err = _MockValidationError("bad value")
        bad = _MockResult(is_valid=False, errors=[err])
        validator = _MockValidator([ok, bad, ok])
        tools = create_charter_tools({"test": validator})
        vb = next(t for t in tools if t.name == "validate_batch")
        result = await vb.execute(
            {
                "records": [{"a": 1}, {"a": 2}, {"a": 3}],
                "contract_name": "test",
            }
        )
        assert result.success
        assert result.output["total"] == 3
        assert result.output["valid_count"] == 2
        assert result.output["invalid_count"] == 1
