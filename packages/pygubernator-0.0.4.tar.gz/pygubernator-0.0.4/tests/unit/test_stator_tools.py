"""Tests for pystator tool wrappers."""

from __future__ import annotations

from typing import Any

import pytest
from pystator import StateMachine

from pygubernator.agents._machines import base_lifecycle_config
from pygubernator.tools.stator_tools import create_stator_tools


@pytest.fixture
def lifecycle_machine() -> StateMachine:
    return StateMachine.from_dict(base_lifecycle_config())


@pytest.fixture
def stator_tools(lifecycle_machine: StateMachine) -> list[Any]:
    return create_stator_tools({"lifecycle": lifecycle_machine})


class TestStatorTools:
    """Tests for create_stator_tools factory."""

    def test_factory_returns_four_tools(self, stator_tools: list[Any]) -> None:
        assert len(stator_tools) == 4
        names = {t.name for t in stator_tools}
        assert names == {
            "create_session",
            "send_event",
            "get_state",
            "list_triggers",
        }

    @pytest.mark.asyncio
    async def test_create_session(self, stator_tools: list[Any]) -> None:
        create = next(t for t in stator_tools if t.name == "create_session")
        result = await create.execute(
            {
                "entity_id": "e1",
                "machine_name": "lifecycle",
            }
        )
        assert result.success
        assert result.output["entity_id"] == "e1"
        assert result.output["state"] == "idle"

    @pytest.mark.asyncio
    async def test_create_session_unknown_machine(
        self, stator_tools: list[Any]
    ) -> None:
        create = next(t for t in stator_tools if t.name == "create_session")
        result = await create.execute(
            {
                "entity_id": "e1",
                "machine_name": "unknown",
            }
        )
        assert not result.success
        assert "not found" in result.error

    @pytest.mark.asyncio
    async def test_send_event(self, stator_tools: list[Any]) -> None:
        create = next(t for t in stator_tools if t.name == "create_session")
        send = next(t for t in stator_tools if t.name == "send_event")

        await create.execute(
            {
                "entity_id": "e1",
                "machine_name": "lifecycle",
            }
        )
        result = await send.execute(
            {
                "entity_id": "e1",
                "trigger": "start",
            }
        )
        assert result.success
        assert result.output["previous_state"] == "idle"
        assert result.output["current_state"] == "running"

    @pytest.mark.asyncio
    async def test_send_event_no_session(self, stator_tools: list[Any]) -> None:
        send = next(t for t in stator_tools if t.name == "send_event")
        result = await send.execute(
            {
                "entity_id": "missing",
                "trigger": "start",
            }
        )
        assert not result.success
        assert "No session" in result.error

    @pytest.mark.asyncio
    async def test_get_state(self, stator_tools: list[Any]) -> None:
        create = next(t for t in stator_tools if t.name == "create_session")
        get = next(t for t in stator_tools if t.name == "get_state")

        await create.execute(
            {
                "entity_id": "e1",
                "machine_name": "lifecycle",
            }
        )
        result = await get.execute({"entity_id": "e1"})
        assert result.success
        assert result.output["state"] == "idle"

    @pytest.mark.asyncio
    async def test_list_triggers(self, stator_tools: list[Any]) -> None:
        create = next(t for t in stator_tools if t.name == "create_session")
        lt = next(t for t in stator_tools if t.name == "list_triggers")

        await create.execute(
            {
                "entity_id": "e1",
                "machine_name": "lifecycle",
            }
        )
        result = await lt.execute({"entity_id": "e1"})
        assert result.success
        assert "start" in result.output["triggers"]
