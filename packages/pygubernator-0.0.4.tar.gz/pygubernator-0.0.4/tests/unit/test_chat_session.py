"""Tests for ChatSession multi-turn conversation wrapper."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest

from pygubernator._types import ToolResult
from pygubernator.chat._session import ChatSession
from pygubernator.chat._types import ChatTurn
from pygubernator.llm._messages import LLMResponse, ToolCall
from pygubernator.tools._registry import ToolRegistry


def _make_text_response(content: str) -> LLMResponse:
    """Build a simple text LLMResponse."""
    return LLMResponse(content=content, finish_reason="stop")


def _make_tool_response(name: str, arguments: dict[str, Any]) -> LLMResponse:
    """Build an LLMResponse with a single tool call."""
    return LLMResponse(
        content="",
        tool_calls=(ToolCall(id="call_1", name=name, arguments=arguments),),
        finish_reason="tool_calls",
    )


class TestChatTurn:
    """Tests for ChatTurn dataclass."""

    def test_defaults(self) -> None:
        turn = ChatTurn(response="hello")
        assert turn.response == "hello"
        assert turn.tool_calls == []
        assert turn.iterations == 0

    def test_frozen(self) -> None:
        turn = ChatTurn(response="x")
        with pytest.raises(AttributeError):
            turn.response = "y"  # type: ignore[misc]


class TestChatSession:
    """Tests for ChatSession."""

    def _make_session(
        self,
        llm: Any,
        tools: ToolRegistry | None = None,
        system_prompt: str = "You are helpful.",
    ) -> ChatSession:
        """Build a ChatSession with the given mocks."""
        return ChatSession(
            llm_provider=llm,
            tool_registry=tools or ToolRegistry(),
            system_prompt=system_prompt,
        )

    async def test_simple_text_response(self) -> None:
        """Send a message, LLM returns text, no tool calls."""
        llm = AsyncMock()
        llm.chat.return_value = _make_text_response("Hello there!")

        session = self._make_session(llm)
        turn = await session.send("Hi")

        assert turn.response == "Hello there!"
        assert turn.tool_calls == []
        assert turn.iterations == 1

    async def test_history_accumulates(self) -> None:
        """History should include system, user, and assistant messages."""
        llm = AsyncMock()
        llm.chat.return_value = _make_text_response("Reply 1")

        session = self._make_session(llm, system_prompt="sys")
        await session.send("msg1")

        assert len(session.history) == 3  # system + user + assistant
        assert session.history[0]["role"] == "system"
        assert session.history[1]["role"] == "user"
        assert session.history[1]["content"] == "msg1"
        assert session.history[2]["role"] == "assistant"
        assert session.history[2]["content"] == "Reply 1"

    async def test_multi_turn_history(self) -> None:
        """Multiple sends accumulate in history."""
        llm = AsyncMock()
        llm.chat.side_effect = [
            _make_text_response("R1"),
            _make_text_response("R2"),
        ]

        session = self._make_session(llm)
        await session.send("Q1")
        await session.send("Q2")

        # system + (user+assistant) * 2
        assert len(session.history) == 5

    async def test_tool_call_loop(self) -> None:
        """LLM calls a tool, gets result, then responds with text."""
        llm = AsyncMock()
        llm.chat.side_effect = [
            _make_tool_response("my_tool", {"x": 1}),
            _make_text_response("Done using tool."),
        ]

        mock_tool = AsyncMock()
        mock_tool.name = "my_tool"
        mock_tool.description = "A test tool"
        mock_tool.parameters_schema = {"type": "object"}
        mock_tool.execute.return_value = ToolResult(
            tool_name="my_tool", success=True, output="result_data"
        )

        registry = ToolRegistry()
        registry.register(mock_tool)

        session = self._make_session(llm, tools=registry)
        turn = await session.send("Use the tool")

        assert turn.response == "Done using tool."
        assert len(turn.tool_calls) == 1
        assert turn.tool_calls[0]["name"] == "my_tool"
        assert turn.iterations == 2
        mock_tool.execute.assert_awaited_once_with({"x": 1})

    async def test_tool_not_found(self) -> None:
        """Unknown tool name produces an error result in history."""
        llm = AsyncMock()
        llm.chat.side_effect = [
            _make_tool_response("unknown_tool", {}),
            _make_text_response("I see an error."),
        ]

        session = self._make_session(llm)
        turn = await session.send("Call unknown")

        assert turn.response == "I see an error."
        # Tool message should contain error text
        tool_msgs = [m for m in session.history if m["role"] == "tool"]
        assert len(tool_msgs) == 1
        assert "not found" in tool_msgs[0]["content"]

    async def test_clear_resets_history(self) -> None:
        """Clear should reset history to just the system prompt."""
        llm = AsyncMock()
        llm.chat.return_value = _make_text_response("ok")

        session = self._make_session(llm, system_prompt="sys")
        await session.send("hello")
        assert len(session.history) > 1

        session.clear()
        assert len(session.history) == 1
        assert session.history[0]["role"] == "system"
        assert session.history[0]["content"] == "sys"

    async def test_clear_no_system_prompt(self) -> None:
        """Clear with no system prompt results in empty history."""
        llm = AsyncMock()
        llm.chat.return_value = _make_text_response("ok")

        session = self._make_session(llm, system_prompt="")
        await session.send("hi")
        session.clear()

        assert session.history == []

    async def test_max_iterations_reached(self) -> None:
        """Session stops after max_iterations even if LLM keeps calling tools."""
        llm = AsyncMock()
        # Always return tool calls
        llm.chat.return_value = _make_tool_response("t", {"a": 1})

        mock_tool = AsyncMock()
        mock_tool.name = "t"
        mock_tool.description = "test"
        mock_tool.parameters_schema = {}
        mock_tool.execute.return_value = ToolResult(
            tool_name="t", success=True, output="ok"
        )

        registry = ToolRegistry()
        registry.register(mock_tool)

        session = ChatSession(
            llm_provider=llm,
            tool_registry=registry,
            system_prompt="",
            max_iterations=3,
        )
        turn = await session.send("loop forever")

        assert turn.iterations == 3
        assert len(turn.tool_calls) == 3

    async def test_history_returns_copy(self) -> None:
        """History property returns a copy, not the internal list."""
        llm = AsyncMock()
        llm.chat.return_value = _make_text_response("ok")
        session = self._make_session(llm, system_prompt="")

        h1 = session.history
        h1.append({"role": "user", "content": "injected"})
        assert len(session.history) == 0
