from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import sessionmaker

from pygubernator.api.main import create_app
from tests.unit.conftest import reset_test_db, test_engine


def _headers() -> dict[str, str]:
    return {
        "X-API-Token": "dev-token",
        "X-Actor": "test",
        "X-Role": "admin",
    }


SessionLocal = sessionmaker(bind=test_engine, autoflush=False, autocommit=False)


@pytest.fixture(autouse=True)
def _reset_db() -> None:
    reset_test_db()


def test_healthz() -> None:
    client = TestClient(create_app())
    res = client.get("/healthz")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"


def test_login_with_cfg_seed_user(monkeypatch: pytest.MonkeyPatch) -> None:
    # CI has no pygubernator.cfg; auth users are cfg/env-only (not DB rows).
    monkeypatch.setenv(
        "PYGUBERNATOR_AUTH_USERS",
        json.dumps([{"username": "admin", "password": "changeme", "role": "Admin"}]),
    )
    monkeypatch.setenv(
        "PYGUBERNATOR_AUTH_JWT_SECRET",
        "test-jwt-secret-for-unit-tests-32bytes!!",
    )
    client = TestClient(create_app())
    res = client.post(
        "/api/v1/auth/login",
        json={"username": "admin", "password": "changeme"},
    )
    assert res.status_code == 200
    body = res.json()
    assert body["token_type"] == "bearer"
    assert body["access_token"]


def test_agent_and_run_lifecycle() -> None:
    client = TestClient(create_app())

    create_agent = client.post(
        "/api/v1/agents",
        headers=_headers(),
        json={"name": "agent-a", "owner": "team-a", "status": "active"},
    )
    assert create_agent.status_code == 200
    agent_id = create_agent.json()["id"]

    create_version = client.post(
        f"/api/v1/agents/{agent_id}/versions",
        headers=_headers(),
        json={"version": "1.0.0", "model": "gpt-4o-mini"},
    )
    assert create_version.status_code == 200
    version_id = create_version.json()["id"]

    activate = client.post(
        f"/api/v1/agents/{agent_id}/versions/{version_id}/activate",
        headers=_headers(),
    )
    assert activate.status_code == 200
    assert activate.json()["current_version_id"] == version_id

    db = SessionLocal()
    try:
        from pygubernator.db.models import Run

        run = Run(agent_id=agent_id, agent_version_id=version_id, status="failed")
        db.add(run)
        db.commit()
        db.refresh(run)
        run_id = run.id
    finally:
        db.close()

    replay = client.post(f"/api/v1/runs/{run_id}/replay", headers=_headers())
    assert replay.status_code == 200
    assert replay.json()["ok"] is True


def test_create_run() -> None:
    client = TestClient(create_app())

    # Create agent first
    create_agent = client.post(
        "/api/v1/agents",
        headers=_headers(),
        json={"name": "agent-run-test", "owner": "test", "status": "active"},
    )
    assert create_agent.status_code == 200
    agent_id = create_agent.json()["id"]

    # Create version
    create_version = client.post(
        f"/api/v1/agents/{agent_id}/versions",
        headers=_headers(),
        json={"version": "1.0.0", "model": "gpt-4o-mini"},
    )
    assert create_version.status_code == 200
    version_id = create_version.json()["id"]

    # Create run
    create_run = client.post(
        "/api/v1/runs",
        headers=_headers(),
        json={
            "agent_id": agent_id,
            "agent_version_id": version_id,
            "correlation_id": "test-correlation",
            "trigger": "test",
            "metadata_json": {"test": True},
        },
    )
    assert create_run.status_code == 200
    run_data = create_run.json()
    assert run_data["agent_id"] == agent_id
    assert run_data["agent_version_id"] == version_id
    assert run_data["status"] == "queued"
    assert run_data["correlation_id"] == "test-correlation"
    assert run_data["trigger"] == "test"
    assert run_data["metadata_json"]["test"] is True

    # Test with missing agent
    bad_run = client.post(
        "/api/v1/runs",
        headers=_headers(),
        json={"agent_id": "nonexistent"},
    )
    assert bad_run.status_code == 404

    # Test with invalid version
    bad_version_run = client.post(
        "/api/v1/runs",
        headers=_headers(),
        json={
            "agent_id": agent_id,
            "agent_version_id": "nonexistent",
        },
    )
    assert bad_version_run.status_code == 404


def test_agent_dashboard_and_enqueue_run() -> None:
    client = TestClient(create_app())

    create_agent = client.post(
        "/api/v1/agents",
        headers=_headers(),
        json={"name": "dash-agent", "owner": "test", "status": "active"},
    )
    assert create_agent.status_code == 200
    agent_id = create_agent.json()["id"]

    create_version = client.post(
        f"/api/v1/agents/{agent_id}/versions",
        headers=_headers(),
        json={"version": "2.0.0", "model": "gpt-4o"},
    )
    assert create_version.status_code == 200
    version_id = create_version.json()["id"]

    dash = client.get(
        f"/api/v1/agents/{agent_id}/dashboard",
        headers=_headers(),
    )
    assert dash.status_code == 200
    body = dash.json()
    assert body["agent"]["id"] == agent_id
    assert len(body["versions"]) == 1
    assert body["versions"][0]["id"] == version_id

    enq = client.post(
        f"/api/v1/agents/{agent_id}/runs",
        headers=_headers(),
        json={"agent_version_id": version_id, "trigger": "test-enqueue"},
    )
    assert enq.status_code == 200
    run = enq.json()
    assert run["agent_id"] == agent_id
    assert run["agent_version_id"] == version_id
    assert run["status"] == "queued"
    assert run["trigger"] == "test-enqueue"

    bad = client.post(
        f"/api/v1/agents/{agent_id}/runs",
        headers=_headers(),
        json={"agent_version_id": "not-a-version"},
    )
    assert bad.status_code == 404


def test_observability_metrics_and_events() -> None:
    client = TestClient(create_app())
    db = SessionLocal()
    try:
        from pygubernator.db.models import Agent, Run

        agent = Agent(name="agent-observe", owner="obs")
        db.add(agent)
        db.commit()
        db.refresh(agent)
        run = Run(
            agent_id=agent.id,
            status="succeeded",
            duration_ms=100,
            token_input=10,
            token_output=5,
        )
        db.add(run)
        db.commit()
        db.refresh(run)
        run_id = run.id
    finally:
        db.close()

    evt = client.post(
        "/api/v1/observability/events",
        headers=_headers(),
        json={"run_id": run_id, "event_type": "run.completed", "level": "info"},
    )
    assert evt.status_code == 200

    metrics = client.get("/api/v1/observability/metrics", headers=_headers())
    assert metrics.status_code == 200
    assert metrics.json()["totals"]["runs"] >= 1


def test_windowed_metrics_and_runs_facets() -> None:
    client = TestClient(create_app())
    db = SessionLocal()
    try:
        from pygubernator.db.models import Agent, Run

        agent = Agent(name="agent-windowed", owner="obs")
        db.add(agent)
        db.commit()
        db.refresh(agent)
        db.add_all(
            [
                Run(
                    agent_id=agent.id,
                    status="succeeded",
                    duration_ms=80,
                    token_input=5,
                    token_output=10,
                    cost_usd_micros=100,
                    created_at=datetime.now(UTC) - timedelta(minutes=20),
                ),
                Run(
                    agent_id=agent.id,
                    status="failed",
                    error_message="boom",
                    duration_ms=120,
                    token_input=6,
                    token_output=11,
                    cost_usd_micros=120,
                    created_at=datetime.now(UTC) - timedelta(minutes=10),
                ),
            ]
        )
        db.commit()
    finally:
        db.close()

    metrics = client.get("/api/v1/observability/metrics?window=1h", headers=_headers())
    assert metrics.status_code == 200
    body = metrics.json()
    assert body["window"]["label"] == "1h"
    assert len(body["series"]) > 0

    runs = client.get("/api/v1/runs?has_error=true", headers=_headers())
    assert runs.status_code == 200
    runs_body = runs.json()
    assert runs_body["meta"]["total"] >= 1
    assert runs_body["facets"]["statuses"]
    assert all(item["error_message"] is not None for item in runs_body["items"])


def test_incident_lifecycle() -> None:
    client = TestClient(create_app())
    db = SessionLocal()
    try:
        from pygubernator.db.models import Agent, Run

        agent = Agent(name="agent-incident", owner="ops")
        db.add(agent)
        db.commit()
        db.refresh(agent)
        run = Run(agent_id=agent.id, status="failed", error_message="incident-source")
        db.add(run)
        db.commit()
        db.refresh(run)
        run_id = run.id
    finally:
        db.close()

    create = client.post(
        "/api/v1/observability/incidents",
        headers=_headers(),
        json={
            "title": "Run failed repeatedly",
            "severity": "critical",
            "run_id": run_id,
        },
    )
    assert create.status_code == 200
    incident_id = create.json()["id"]

    ack = client.post(
        f"/api/v1/observability/incidents/{incident_id}/ack", headers=_headers()
    )
    assert ack.status_code == 200
    assert ack.json()["status"] == "acknowledged"

    silence = client.post(
        f"/api/v1/observability/incidents/{incident_id}/silence",
        headers=_headers(),
        json={"until": (datetime.now(UTC) + timedelta(hours=1)).isoformat()},
    )
    assert silence.status_code == 200
    assert silence.json()["status"] == "silenced"

    assign = client.post(
        f"/api/v1/observability/incidents/{incident_id}/assign",
        headers=_headers(),
        json={"owner": "oncall-a"},
    )
    assert assign.status_code == 200
    assert assign.json()["owner"] == "oncall-a"

    resolve = client.post(
        f"/api/v1/observability/incidents/{incident_id}/resolve", headers=_headers()
    )
    assert resolve.status_code == 200
    assert resolve.json()["status"] == "resolved"


def test_alert_firing_state_and_history() -> None:
    client = TestClient(create_app())
    db = SessionLocal()
    try:
        from pygubernator.db.models import Agent, AlertRule, Run

        agent = Agent(name="agent-alerts", owner="ops")
        db.add(agent)
        db.commit()
        db.refresh(agent)
        alert = AlertRule(name="High failure rate", severity="critical", enabled=True)
        db.add(alert)
        db.commit()
        db.refresh(alert)
        run = Run(agent_id=agent.id, status="failed", error_message="failing run")
        db.add(run)
        db.commit()
        db.refresh(run)
        run_id = run.id
        alert_id = alert.id
    finally:
        db.close()

    incident = client.post(
        "/api/v1/observability/incidents",
        headers=_headers(),
        json={
            "title": "Alert fired for failed runs",
            "severity": "critical",
            "alert_id": alert_id,
            "run_id": run_id,
        },
    )
    assert incident.status_code == 200
    incident_id = incident.json()["id"]

    detail = client.get(
        f"/api/v1/observability/incidents/{incident_id}", headers=_headers()
    )
    assert detail.status_code == 200
    assert detail.json()["alert_id"] == alert_id

    alerts = client.get("/api/v1/policies/alerts", headers=_headers())
    assert alerts.status_code == 200
    alert_item = next(item for item in alerts.json()["items"] if item["id"] == alert_id)
    assert alert_item["firing"] is True
    assert alert_item["open_incidents"] >= 1

    history = client.get(
        f"/api/v1/policies/alerts/history?alert_id={alert_id}", headers=_headers()
    )
    assert history.status_code == 200
    assert any(item["alert_id"] == alert_id for item in history.json()["items"])

    toggle = client.post(
        f"/api/v1/policies/alerts/{alert_id}/toggle",
        headers=_headers(),
        json={"enabled": False},
    )
    assert toggle.status_code == 200
    assert toggle.json()["enabled"] is False


def test_incident_owner_filter() -> None:
    client = TestClient(create_app())
    db = SessionLocal()
    try:
        from pygubernator.db.models import Agent, Run

        agent = Agent(name="agent-owner-filter", owner="ops")
        db.add(agent)
        db.commit()
        db.refresh(agent)
        run = Run(agent_id=agent.id, status="failed", error_message="owner filter run")
        db.add(run)
        db.commit()
        db.refresh(run)
        run_id = run.id
    finally:
        db.close()

    client.post(
        "/api/v1/observability/incidents",
        headers=_headers(),
        json={
            "title": "Incident A",
            "severity": "warning",
            "run_id": run_id,
            "owner": "team-a",
        },
    )
    client.post(
        "/api/v1/observability/incidents",
        headers=_headers(),
        json={
            "title": "Incident B",
            "severity": "warning",
            "run_id": run_id,
            "owner": "team-b",
        },
    )

    filtered = client.get(
        "/api/v1/observability/incidents?owner=team-a", headers=_headers()
    )
    assert filtered.status_code == 200
    assert filtered.json()["items"]
    assert all(item["owner"] == "team-a" for item in filtered.json()["items"])
