"""Tests for pycatalyst tool wrappers (mocking pycatalyst)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pygubernator.tools.catalyst_tools import create_catalyst_tools


class TestCatalystTools:
    """Tests for create_catalyst_tools factory."""

    def test_factory_returns_two_tools(self) -> None:
        tools = create_catalyst_tools({})
        assert len(tools) == 2
        names = {t.name for t in tools}
        assert names == {"generate_data", "build_schema"}

    @pytest.mark.asyncio
    async def test_generate_data_unknown_schema(self) -> None:
        tools = create_catalyst_tools({})
        gen = next(t for t in tools if t.name == "generate_data")
        result = await gen.execute(
            {
                "schema_name": "missing",
                "count": 5,
            }
        )
        assert not result.success
        # Will fail with either "not found" or "pycatalyst is required"
        assert "not found" in result.error or "pycatalyst" in result.error

    @pytest.mark.asyncio
    async def test_generate_data_success(self) -> None:
        mock_schema = MagicMock()
        mock_engine = MagicMock()
        mock_engine.generate.return_value = [{"a": 1}, {"a": 2}]

        with patch.dict(
            "sys.modules",
            {
                "pycatalyst": MagicMock(),
                "pycatalyst.engine": MagicMock(
                    GenerationEngine=lambda **kw: mock_engine
                ),
            },
        ):
            tools = create_catalyst_tools({"test": mock_schema})
            gen = next(t for t in tools if t.name == "generate_data")
            result = await gen.execute(
                {
                    "schema_name": "test",
                    "count": 2,
                }
            )
            assert result.success
            assert len(result.output) == 2

    @pytest.mark.asyncio
    async def test_build_schema_no_pycatalyst(self) -> None:
        tools = create_catalyst_tools({})
        build = next(t for t in tools if t.name == "build_schema")
        result = await build.execute(
            {
                "fields": {"name": {"type": "string"}},
            }
        )
        assert not result.success
        assert "pycatalyst" in result.error.lower()
