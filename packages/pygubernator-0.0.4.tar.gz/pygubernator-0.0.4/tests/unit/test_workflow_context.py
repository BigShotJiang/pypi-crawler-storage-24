"""Tests for workflow data-flow merging utilities."""

from __future__ import annotations

import networkx as nx

from pygubernator.workflow._context import build_node_context, merge_upstream_outputs
from pygubernator.workflow._types import NodeResult, NodeStatus


def _make_graph_and_results(
    edges: list[tuple[str, str, str]],
    results: dict[str, dict],
) -> tuple[nx.DiGraph, dict[str, NodeResult], set[str]]:
    """Build a graph, node results, and active edges for testing."""
    graph = nx.DiGraph()
    active_edges: set[str] = set()
    for src, tgt, eid in edges:
        graph.add_edge(src, tgt, edge_id=eid)
        active_edges.add(eid)
    for nid, _output in results.items():
        graph.add_node(nid)
    node_results = {
        nid: NodeResult(node_id=nid, status=NodeStatus.SUCCESS, output=output)
        for nid, output in results.items()
    }
    return graph, node_results, active_edges


class TestMergeUpstreamOutputs:
    """Tests for merge_upstream_outputs."""

    def test_single_upstream_flattened(self) -> None:
        graph, results, active = _make_graph_and_results(
            edges=[("a", "b", "e1")],
            results={"a": {"x": 1, "y": 2}},
        )
        merged = merge_upstream_outputs("b", graph, results, active)
        assert merged == {"x": 1, "y": 2}

    def test_multiple_upstream_namespaced(self) -> None:
        graph, results, active = _make_graph_and_results(
            edges=[("a", "c", "e1"), ("b", "c", "e2")],
            results={"a": {"x": 1}, "b": {"y": 2}},
        )
        merged = merge_upstream_outputs("c", graph, results, active)
        assert merged == {"a": {"x": 1}, "b": {"y": 2}}

    def test_inactive_edges_excluded(self) -> None:
        graph, results, active = _make_graph_and_results(
            edges=[("a", "c", "e1"), ("b", "c", "e2")],
            results={"a": {"x": 1}, "b": {"y": 2}},
        )
        active.discard("e2")
        merged = merge_upstream_outputs("c", graph, results, active)
        # Only one active upstream → flattened
        assert merged == {"x": 1}

    def test_no_upstream_returns_empty(self) -> None:
        graph = nx.DiGraph()
        graph.add_node("a")
        merged = merge_upstream_outputs("a", graph, {}, set())
        assert merged == {}


class TestBuildNodeContext:
    """Tests for build_node_context."""

    def test_creates_frozen_context(self) -> None:
        ctx = build_node_context(
            node_id="n1",
            input_data={"key": "val"},
            variables={"v": 1},
            config={"c": True},
        )
        assert ctx.node_id == "n1"
        assert ctx.input_data == {"key": "val"}
        assert ctx.variables == {"v": 1}
        assert ctx.config == {"c": True}
