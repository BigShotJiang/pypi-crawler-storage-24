"""Tests for the workflow services module."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from pygubernator.services._workflows import (
    build_node_registry,
    execute_workflow,
)


class TestBuildNodeRegistry:
    """Tests for build_node_registry()."""

    def test_returns_registry_with_builtin_types(self):
        """Registry contains all standard node types."""
        registry = build_node_registry()
        expected = {
            "input",
            "output",
            "template",
            "condition",
            "code",
            "router",
            "loop",
            "map",
        }
        for name in expected:
            assert registry.has(name), f"Missing node type: {name}"

    def test_registry_length_at_least_eight(self):
        """At least 8 built-in types are registered."""
        registry = build_node_registry()
        assert len(registry) >= 8

    def test_can_create_nodes_from_registry(self):
        """Each registered type can create a node instance."""
        registry = build_node_registry()
        for type_name in [
            "input",
            "output",
            "template",
            "condition",
            "code",
        ]:
            node = registry.create(f"test_{type_name}", type_name, {})
            assert node is not None


class TestExecuteWorkflow:
    """Tests for execute_workflow()."""

    def test_invalid_spec_returns_failure(self):
        """An invalid spec_json returns success=False."""
        db = MagicMock()
        result = execute_workflow(
            spec_json={"invalid": True},
            input_json={},
            db=db,
            run_id="run-1",
        )
        assert result["success"] is False
        assert "Invalid spec" in result["errors"][0]
        assert result["duration_ms"] == 0

    def test_valid_passthrough_workflow(self):
        """A simple input->output workflow executes successfully."""
        db = MagicMock()
        spec = {
            "meta": {"name": "test", "version": "1.0.0"},
            "nodes": {
                "in": {"type": "input", "config": {}},
                "out": {
                    "type": "output",
                    "config": {},
                },
            },
            "edges": [{"source": "in", "target": "out"}],
        }

        # Patch the lazy imports inside execute_workflow
        mock_step = MagicMock()
        with (
            patch(
                "pygubernator.db.repositories.create_workflow_step_run",
                return_value=mock_step,
            ),
            patch(
                "pygubernator.db.repositories.update_workflow_step_run",
            ),
        ):
            result = execute_workflow(
                spec_json=spec,
                input_json={"message": "hello"},
                db=db,
                run_id="run-1",
            )

        assert result["success"] is True
        assert result["duration_ms"] >= 0
