"""Tests for Jinja2 template rendering."""

from __future__ import annotations

import pytest

from pygubernator.errors import NodeError
from pygubernator.workflow._templates import render_config_value, render_template


class TestRenderTemplate:
    """Tests for render_template function."""

    def test_simple_render(self) -> None:
        result = render_template("Hello, {{ name }}!", {"name": "World"})
        assert result == "Hello, World!"

    def test_multiple_variables(self) -> None:
        result = render_template(
            "{{ first }} {{ last }}",
            {"first": "John", "last": "Doe"},
        )
        assert result == "John Doe"

    def test_conditional(self) -> None:
        template = "{% if vip %}VIP{% else %}Regular{% endif %}"
        assert render_template(template, {"vip": True}) == "VIP"
        assert render_template(template, {"vip": False}) == "Regular"

    def test_loop(self) -> None:
        template = "{% for item in items %}{{ item }} {% endfor %}"
        result = render_template(template, {"items": ["a", "b", "c"]})
        assert result == "a b c "

    def test_filter(self) -> None:
        result = render_template("{{ name|upper }}", {"name": "hello"})
        assert result == "HELLO"

    def test_undefined_variable_raises(self) -> None:
        with pytest.raises(NodeError, match="Template rendering failed"):
            render_template("{{ undefined_var }}", {})

    def test_empty_template(self) -> None:
        result = render_template("", {})
        assert result == ""

    def test_no_templates(self) -> None:
        result = render_template("plain text", {})
        assert result == "plain text"

    def test_nested_access(self) -> None:
        result = render_template(
            "{{ user.name }}",
            {"user": {"name": "Alice"}},
        )
        assert result == "Alice"


class TestRenderConfigValue:
    """Tests for render_config_value function."""

    def test_string_with_template(self) -> None:
        result = render_config_value("Hello, {{ name }}!", {"name": "World"})
        assert result == "Hello, World!"

    def test_string_without_template(self) -> None:
        result = render_config_value("plain text", {})
        assert result == "plain text"

    def test_dict_recursion(self) -> None:
        config = {
            "url": "https://api.example.com/{{ endpoint }}",
            "method": "GET",
        }
        result = render_config_value(config, {"endpoint": "users"})
        assert result["url"] == "https://api.example.com/users"
        assert result["method"] == "GET"

    def test_list_recursion(self) -> None:
        config = ["{{ a }}", "{{ b }}", "static"]
        result = render_config_value(config, {"a": "x", "b": "y"})
        assert result == ["x", "y", "static"]

    def test_non_string_passthrough(self) -> None:
        assert render_config_value(42, {}) == 42
        assert render_config_value(True, {}) is True
        assert render_config_value(None, {}) is None
