"""Tests for sub-node resolution in the workflow converter."""

from __future__ import annotations

from pygubernator.workflow.config._converter import (
    _is_sub_node_type,
    _resolve_sub_nodes,
)
from pygubernator.workflow.config._models import EdgeDef


class TestIsSubNodeType:
    """Tests for sub-node type detection."""

    def test_chat_model_types(self) -> None:
        assert _is_sub_node_type("chat_model_openai") is True
        assert _is_sub_node_type("chat_model_anthropic") is True
        assert _is_sub_node_type("chat_model_ollama") is True
        assert _is_sub_node_type("chat_model_deepseek") is True
        assert _is_sub_node_type("chat_model_glm") is True
        assert _is_sub_node_type("chat_model_openai_compat") is True

    def test_memory_and_tool(self) -> None:
        assert _is_sub_node_type("memory") is True
        assert _is_sub_node_type("tool") is True

    def test_non_sub_node_types(self) -> None:
        assert _is_sub_node_type("llm") is False
        assert _is_sub_node_type("agent") is False
        assert _is_sub_node_type("input") is False
        assert _is_sub_node_type("code") is False


class TestResolveSubNodes:
    """Tests for sub-node resolution."""

    def test_no_sub_nodes(self) -> None:
        nodes = {
            "in": {"type": "input", "config": {}, "position": (0, 0)},
            "out": {"type": "output", "config": {}, "position": (0, 100)},
        }
        edges = [
            EdgeDef(source="in", target="out"),
        ]
        result_nodes, result_edges = _resolve_sub_nodes(nodes, edges)
        assert len(result_nodes) == 2
        assert len(result_edges) == 1

    def test_chat_model_merged_into_llm(self) -> None:
        nodes = {
            "llm_1": {
                "type": "llm",
                "config": {"prompt_template": "{{ data }}"},
                "position": (0, 0),
            },
            "chat_1": {
                "type": "chat_model_openai_compat",
                "config": {
                    "model_name": "llama3.1",
                    "api_base": "http://localhost:11434/v1",
                    "temperature": 0.7,
                },
                "position": (0, 100),
            },
        }
        edges = [
            EdgeDef(
                source="chat_1",
                target="llm_1",
                target_handle="sub:chat_model",
            ),
        ]

        result_nodes, result_edges = _resolve_sub_nodes(nodes, edges)

        # Sub-node removed
        assert "chat_1" not in result_nodes
        assert len(result_nodes) == 1

        # Config merged into parent
        llm_config = result_nodes["llm_1"]["config"]
        assert llm_config["model_name"] == "llama3.1"
        assert llm_config["api_base"] == "http://localhost:11434/v1"
        assert llm_config["temperature"] == 0.7
        assert llm_config["prompt_template"] == "{{ data }}"

        # Sub-edge removed
        assert len(result_edges) == 0

    def test_memory_merged_into_llm(self) -> None:
        nodes = {
            "llm_1": {
                "type": "llm",
                "config": {"prompt_template": "{{ q }}"},
                "position": (0, 0),
            },
            "mem_1": {
                "type": "memory",
                "config": {
                    "backend": "in_memory",
                    "memory_type": "buffer",
                },
                "position": (0, 100),
            },
        }
        edges = [
            EdgeDef(
                source="mem_1",
                target="llm_1",
                target_handle="sub:memory",
            ),
        ]

        result_nodes, result_edges = _resolve_sub_nodes(nodes, edges)

        assert "mem_1" not in result_nodes
        llm_config = result_nodes["llm_1"]["config"]
        assert llm_config["memory"]["backend"] == "in_memory"
        assert llm_config["memory"]["memory_type"] == "buffer"

    def test_tool_merged_into_agent(self) -> None:
        nodes = {
            "agent_1": {
                "type": "agent",
                "config": {
                    "model": "gpt-4o",
                    "prompt_template": "{{ task }}",
                },
                "position": (0, 0),
            },
            "tool_1": {
                "type": "tool",
                "config": {
                    "name": "search",
                    "module": "mypackage.tools",
                    "function": "search_docs",
                },
                "position": (0, 100),
            },
        }
        edges = [
            EdgeDef(
                source="tool_1",
                target="agent_1",
                target_handle="sub:tool",
            ),
        ]

        result_nodes, result_edges = _resolve_sub_nodes(nodes, edges)

        assert "tool_1" not in result_nodes
        agent_config = result_nodes["agent_1"]["config"]
        assert "search" in agent_config["tools"]
        assert agent_config["tools"]["search"]["module"] == "mypackage.tools"

    def test_multiple_sub_nodes(self) -> None:
        nodes = {
            "llm_1": {
                "type": "llm",
                "config": {"prompt_template": "{{ q }}"},
                "position": (0, 0),
            },
            "chat_1": {
                "type": "chat_model_deepseek",
                "config": {
                    "model_name": "deepseek-chat",
                    "api_key": "sk-test",
                },
                "position": (0, 100),
            },
            "mem_1": {
                "type": "memory",
                "config": {"backend": "sqlite"},
                "position": (100, 100),
            },
            "in": {
                "type": "input",
                "config": {},
                "position": (0, -100),
            },
            "out": {
                "type": "output",
                "config": {},
                "position": (0, 200),
            },
        }
        edges = [
            EdgeDef(source="in", target="llm_1"),
            EdgeDef(
                source="chat_1",
                target="llm_1",
                target_handle="sub:chat_model",
            ),
            EdgeDef(
                source="mem_1",
                target="llm_1",
                target_handle="sub:memory",
            ),
            EdgeDef(source="llm_1", target="out"),
        ]

        result_nodes, result_edges = _resolve_sub_nodes(nodes, edges)

        # Sub-nodes removed
        assert "chat_1" not in result_nodes
        assert "mem_1" not in result_nodes
        assert len(result_nodes) == 3  # llm_1, in, out

        # Config merged
        llm_config = result_nodes["llm_1"]["config"]
        assert llm_config["model_name"] == "deepseek-chat"
        assert llm_config["api_key"] == "sk-test"
        assert llm_config["memory"]["backend"] == "sqlite"

        # Only normal edges remain
        assert len(result_edges) == 2

    def test_non_sub_edge_not_affected(self) -> None:
        """Normal edges (without sub: handle) are not affected."""
        nodes = {
            "in": {"type": "input", "config": {}, "position": (0, 0)},
            "llm": {
                "type": "llm",
                "config": {"prompt_template": "{{ x }}"},
                "position": (0, 100),
            },
            "out": {"type": "output", "config": {}, "position": (0, 200)},
        }
        edges = [
            EdgeDef(source="in", target="llm"),
            EdgeDef(source="llm", target="out"),
        ]

        result_nodes, result_edges = _resolve_sub_nodes(nodes, edges)
        assert len(result_nodes) == 3
        assert len(result_edges) == 2
