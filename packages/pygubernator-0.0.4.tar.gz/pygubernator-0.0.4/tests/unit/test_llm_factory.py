"""Tests for LLM provider factory with auto-detection."""

from __future__ import annotations

from pygubernator.llm._config import ProviderConfig, ProviderType
from pygubernator.llm._factory import create_provider, create_provider_from_config
from pygubernator.llm._local import LocalLLMProvider
from pygubernator.llm._openai_compat import OpenAICompatibleProvider
from pygubernator.llm._provider import LiteLLMProvider


class TestCreateProvider:
    """Tests for create_provider auto-detection."""

    def test_gguf_path_returns_local(self) -> None:
        p = create_provider("./models/llama3.gguf")
        assert isinstance(p, LocalLLMProvider)
        assert p._model_path == "./models/llama3.gguf"

    def test_gguf_absolute_path(self) -> None:
        p = create_provider("/data/models/phi3.gguf")
        assert isinstance(p, LocalLLMProvider)

    def test_ollama_prefix_returns_openai_compat(self) -> None:
        p = create_provider("ollama/llama3.1")
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._model == "llama3.1"
        assert "localhost:11434" in p._api_base

    def test_ollama_prefix_custom_base(self) -> None:
        p = create_provider(
            "ollama/mistral",
            api_base="http://remote:11434/v1",
        )
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._api_base == "http://remote:11434/v1"

    def test_deepseek_prefix_returns_openai_compat(self) -> None:
        p = create_provider("deepseek-chat", api_key="sk-test")
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._model == "deepseek-chat"
        assert "deepseek.com" in p._api_base
        assert p._api_key == "sk-test"

    def test_deepseek_reasoner(self) -> None:
        p = create_provider("deepseek-reasoner")
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._model == "deepseek-reasoner"

    def test_glm_prefix_returns_openai_compat(self) -> None:
        p = create_provider("glm-4-plus", api_key="key-test")
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._model == "glm-4-plus"
        assert "bigmodel.cn" in p._api_base

    def test_api_base_returns_openai_compat(self) -> None:
        p = create_provider(
            "my-custom-model",
            api_base="http://localhost:8000/v1",
        )
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._model == "my-custom-model"
        assert p._api_base == "http://localhost:8000/v1"

    def test_bare_ollama_port_gets_v1_suffix(self) -> None:
        """Bare :11434 without /v1 must be normalized for OpenAI-compatible paths."""
        p = create_provider(
            "qwen3:14b",
            api_base="http://localhost:11434",
        )
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._model == "qwen3:14b"
        assert p._api_base == "http://localhost:11434/v1"

    def test_fallback_returns_litellm(self) -> None:
        p = create_provider("gpt-4o")
        assert isinstance(p, LiteLLMProvider)
        assert p._model == "gpt-4o"

    def test_cloud_model_returns_litellm(self) -> None:
        p = create_provider("claude-opus-4-20250514")
        assert isinstance(p, LiteLLMProvider)

    def test_passes_max_tokens(self) -> None:
        p = create_provider("gpt-4o", max_tokens=2048)
        assert isinstance(p, LiteLLMProvider)
        assert p._max_tokens == 2048

    def test_passes_temperature(self) -> None:
        p = create_provider("ollama/llama3", temperature=0.8)
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._temperature == 0.8


class TestCreateProviderFromConfig:
    """Tests for create_provider_from_config."""

    def test_litellm_config(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.LITELLM,
            model="gpt-4o",
            api_key="sk-test",
        )
        p = create_provider_from_config(config)
        assert isinstance(p, LiteLLMProvider)
        assert p._model == "gpt-4o"
        assert p._api_key == "sk-test"

    def test_openai_compatible_config(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.OPENAI_COMPATIBLE,
            model="llama3",
            api_base="http://localhost:11434/v1",
            max_tokens=2048,
        )
        p = create_provider_from_config(config)
        assert isinstance(p, OpenAICompatibleProvider)
        assert p._model == "llama3"
        assert p._max_tokens == 2048

    def test_local_config(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.LOCAL,
            model="test.gguf",
            model_path="/data/test.gguf",
            n_ctx=8192,
            n_gpu_layers=0,
        )
        p = create_provider_from_config(config)
        assert isinstance(p, LocalLLMProvider)
        assert p._model_path == "/data/test.gguf"
        assert p._n_ctx == 8192
        assert p._n_gpu_layers == 0

    def test_local_config_uses_model_as_path(self) -> None:
        config = ProviderConfig(
            provider_type=ProviderType.LOCAL,
            model="/data/model.gguf",
        )
        p = create_provider_from_config(config)
        assert isinstance(p, LocalLLMProvider)
        assert p._model_path == "/data/model.gguf"
