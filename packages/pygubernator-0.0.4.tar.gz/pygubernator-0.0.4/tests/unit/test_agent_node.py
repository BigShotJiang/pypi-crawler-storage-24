"""Tests for the agent workflow node."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from pygubernator.llm._messages import LLMResponse
from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._agent import AgentNode, AgentNodeFactory


def _mock_provider() -> MagicMock:
    """Create a mock LLM provider that returns a simple response."""
    provider = MagicMock()
    provider.chat = MagicMock(
        return_value=LLMResponse(
            content="Analysis complete.",
            finish_reason="stop",
        )
    )
    # Make chat a coroutine

    async def mock_chat(
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        return LLMResponse(
            content="Analysis complete.",
            finish_reason="stop",
        )

    provider.chat = mock_chat
    return provider


class TestAgentNode:
    """Tests for AgentNode execution."""

    @pytest.mark.asyncio
    async def test_missing_prompt_and_input(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={"model": "test-model"},
        )
        ctx = NodeContext(node_id="a1", input_data={}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "prompt" in result.error.lower()

    @pytest.mark.asyncio
    async def test_task_description_fallback(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={
                "model": "test-model",
                "task_description": "Answer: {{ message }}",
            },
        )
        node._resolve_provider = lambda: _mock_provider()
        ctx = NodeContext(
            node_id="a1",
            input_data={"message": "hello"},
            variables={},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_message_input_fallback(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={"model": "test-model"},
        )
        node._resolve_provider = lambda: _mock_provider()
        ctx = NodeContext(
            node_id="a1",
            input_data={"message": "what is 1+1"},
            variables={},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_missing_model(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={"prompt_template": "{{ data }}"},
        )
        ctx = NodeContext(node_id="a1", input_data={"data": "test"}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "model" in result.error.lower()

    @pytest.mark.asyncio
    async def test_successful_execution(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={
                "model": "test-model",
                "prompt_template": "Analyze: {{ data }}",
                "system_prompt": "You are a test agent.",
                "max_iterations": 1,
            },
        )
        # Patch the provider resolution to return our mock
        original_resolve = node._resolve_provider
        node._resolve_provider = lambda: _mock_provider()

        ctx = NodeContext(
            node_id="a1",
            input_data={"data": "test data"},
            variables={},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert "response" in result.output
        assert result.output["response"] == "Analysis complete."

        # Restore
        node._resolve_provider = original_resolve

    def test_load_tools_empty(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={"model": "test", "prompt_template": "{{ x }}"},
        )
        registry = node._load_tools()
        assert len(registry) == 0

    def test_load_tools_invalid_spec(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={
                "model": "test",
                "prompt_template": "{{ x }}",
                "tools": {"bad_tool": "not-a-dict"},
            },
        )
        registry = node._load_tools()
        assert len(registry) == 0

    def test_load_tools_missing_module(self) -> None:
        node = AgentNode(
            node_id="a1",
            config={
                "model": "test",
                "prompt_template": "{{ x }}",
                "tools": {
                    "missing": {
                        "module": "nonexistent_xyz",
                        "function": "foo",
                    }
                },
            },
        )
        registry = node._load_tools()
        assert len(registry) == 0  # Warns but doesn't fail


class TestAgentNodeFactory:
    """Tests for AgentNodeFactory."""

    def test_create(self) -> None:
        factory = AgentNodeFactory()
        node = factory.create(
            "a1",
            {"model": "test", "prompt_template": "{{ x }}"},
        )
        assert isinstance(node, AgentNode)
        assert node._node_id == "a1"
