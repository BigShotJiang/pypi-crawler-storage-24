"""Integration test: LLM agent with all three tool sets."""

from __future__ import annotations

import pytest
from pystator import StateMachine

from pygubernator._events import EventBus
from pygubernator._handlers import MetricsEventHandler
from pygubernator._types import Message
from pygubernator.agents._llm import LLMAgent
from pygubernator.agents._machines import base_lifecycle_config
from pygubernator.llm._messages import LLMResponse, ToolCall
from pygubernator.tools._registry import ToolRegistry
from pygubernator.tools.stator_tools import create_stator_tools
from tests.conftest import _MockLLMProvider


@pytest.mark.integration
class TestLLMAgentWithTools:
    """LLM agent using stator tools end-to-end."""

    @pytest.mark.asyncio
    async def test_llm_creates_session_and_sends_event(self) -> None:
        # Set up stator tools with a lifecycle machine
        machine = StateMachine.from_dict(base_lifecycle_config())
        stator_tools = create_stator_tools({"lifecycle": machine})

        registry = ToolRegistry()
        registry.register_all(stator_tools)

        # LLM will call create_session, then send_event
        provider = _MockLLMProvider(
            [
                LLMResponse(
                    content="Creating session",
                    tool_calls=(
                        ToolCall(
                            id="tc1",
                            name="create_session",
                            arguments={
                                "entity_id": "e1",
                                "machine_name": "lifecycle",
                            },
                        ),
                    ),
                    finish_reason="tool_calls",
                ),
                LLMResponse(
                    content="Sending start event",
                    tool_calls=(
                        ToolCall(
                            id="tc2",
                            name="send_event",
                            arguments={
                                "entity_id": "e1",
                                "trigger": "start",
                            },
                        ),
                    ),
                    finish_reason="tool_calls",
                ),
                LLMResponse(
                    content="Done! Entity is now running.",
                    finish_reason="stop",
                ),
            ]
        )

        bus = EventBus()
        metrics = MetricsEventHandler()
        bus.add_handler(metrics)

        agent = LLMAgent(
            agent_id="llm-stator",
            llm_provider=provider,
            tool_registry=registry,
            system_prompt="You manage state machines.",
            event_bus=bus,
        )

        msg = Message(
            topic="commands",
            payload={"content": "Start entity e1 on lifecycle machine"},
        )
        result = await agent.process(msg)

        assert result.success
        assert result.metadata["iterations"] == 3
        assert len(result.metadata["tool_results"]) == 2

        # Verify both tool calls succeeded
        for tr in result.metadata["tool_results"]:
            assert tr["success"] is True

        # Verify events were emitted
        m = metrics.get_metrics()
        assert m["counters"].get("tool_call.started", 0) == 2
        assert m["counters"].get("tool_call.completed", 0) == 2
        assert m["counters"].get("llm.request.started", 0) == 3
