# Contributing to PyGubernator

Thank you for your interest in contributing. This document describes how to set up a development environment, run checks, and submit changes.

## Prerequisites

- Python 3.11, 3.12, or 3.13
- Node.js 22+ (for the UI under `src/pygubernator/ui`)

## Development setup

From the repository root:

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip
pip install -e ".[dev]"
```

## Running tests

```bash
pytest
```

## Linting and formatting

```bash
ruff format --check src/pygubernator tests
ruff check src/pygubernator tests
```

## Type checking (Python)

```bash
mypy src/pygubernator
```

CI runs `mypy` with a non-failing fallback; fixing new type errors is still appreciated.

## UI (Next.js)

```bash
cd src/pygubernator/ui
npm ci
npm run type-check
```

See [`src/pygubernator/ui/README.md`](src/pygubernator/ui/README.md) for dev and build commands.

## Pull requests

1. Open an issue first for larger features or design changes so we can align early.
2. Keep changes focused; match existing style and patterns.
3. Add or update tests when behavior changes.
4. Target `main` or `develop` as used by the project (CI runs on PRs to both).

## Community conduct

Please read [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md). For security-sensitive reports, see [`SECURITY.md`](SECURITY.md).
