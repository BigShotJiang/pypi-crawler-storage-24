# Security policy

## Reporting a vulnerability

Please report security vulnerabilities **privately** so we can coordinate a fix before public disclosure.

- **Preferred:** [GitHub Security Advisories](https://github.com/optophi/pygubernator/security/advisories/new) (if enabled for the repository).
- **Email:** [contact@statfyi.com](mailto:contact@statfyi.com) with a subject line such as `[SECURITY] PyGubernator`.

Include a short description, affected versions or components, and steps to reproduce or assess impact.

We will acknowledge receipt as soon as we can and work with you on a timeline for disclosure and patch release.

## Supported versions

We typically release patches for the current release line published on PyPI. If you depend on an older release, contact us and we will assess severity.

## General security practices

- Do not open public issues for undisclosed vulnerabilities.
- For non-security bugs, use [GitHub Issues](https://github.com/optophi/pygubernator/issues).
