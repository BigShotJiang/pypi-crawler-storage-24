# Observability UI Specification

## Goals
- Support operational observability, not dashboard-only reporting.
- Keep UX consistent with existing PyGubernator table/card styling.
- Make triage and action flows explicit and auditable.

## Information Architecture
- Observability
  - Overview
  - Incidents
  - Runs Explorer
  - Alerts

## Global Interaction Rules
- Filters are represented in URL query parameters.
- Status is always shown with a status badge component.
- Tables always include deterministic sort order from API.
- Empty states use explicit "No data" messages.

## Overview
- Time-window selector: `15m`, `1h`, `24h`, `7d`.
- KPI cards for runs, outcomes, latency, tokens, cost.
- Recent incidents panel with quick navigation to full queue.

## Incidents
- Incident queue sorted by urgency then recency.
- Queue supports filtering by status and owner.
- Actions:
  - Acknowledge
  - Silence (preset 1 hour)
  - Resolve
  - Assign owner
- Incident detail:
  - Linked run and alert context.
  - Incident-specific audit trail.
- Action behavior:
  - Disable action buttons while request is in flight.
  - Refresh list after action success.

## Runs Explorer
- Filter by status and error presence.
- Display run-level metadata required for triage.
- Link directly to run detail trace.

## Run Detail
- Show run actions:
  - Cancel
  - Requeue
  - Restart
  - Replay
- Require user confirmation before action dispatch.
- Provide timeline drilldown with event/tool filters and event-level filter.

## Alerts
- Rule list includes `firing` and `open_incidents`.
- History panel lists alert-linked incident timeline.
- Rule management:
  - Create alert rule with severity and JSON condition.
  - Enable/disable existing rule.
