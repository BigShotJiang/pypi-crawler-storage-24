"""End-to-end example: pycatalyst → pygubernator → pycharter → pystator.

Generates mock order data with pycatalyst, ingests it through a pygubernator
pipeline that validates each record with pycharter, then drives pystator
state transitions. Everything runs in-memory — no Kafka, no filesystem.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pycatalyst import GenerationEngine, SchemaBuilder
from pycharter.runtime_validator import Validator
from pystator import StateMachine

from pygubernator import (
    AgentResult,
    InMemoryTransport,
    Message,
    PipelineAgent,
    PipelineStep,
    StepResult,
    run_batch,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 1. Mock-data generation
# ---------------------------------------------------------------------------

ORDER_SCHEMA = (
    SchemaBuilder("orders", description="Mock e-commerce orders")
    .add_uuid("order_id")
    .add_string("customer_name", min_len=2, max_len=60)
    .add_float("amount", min_val=0.01, max_val=10000.0)
    .add_enum("status", choices=["new"])
    .build()
)

# ---------------------------------------------------------------------------
# 2. Pycharter contract (inline dict)
# ---------------------------------------------------------------------------

ORDER_CONTRACT: dict[str, Any] = {
    "json_schema": {
        "type": "object",
        "version": "1.0.0",
        "properties": {
            "order_id": {"type": "string"},
            "customer_name": {"type": "string"},
            "amount": {"type": "number"},
            "status": {"type": "string", "enum": ["new"]},
        },
        "required": ["order_id", "customer_name", "amount", "status"],
    },
    "coercion_rules": {
        "amount": "coerce_to_float",
    },
    "validation_rules": {
        "amount": "greater_than_or_equal_to(threshold=0)",
    },
}

# ---------------------------------------------------------------------------
# 3. Pystator machine definition
# ---------------------------------------------------------------------------

ORDER_MACHINE_CONFIG: dict[str, Any] = {
    "meta": {
        "machine_name": "order_lifecycle",
        "version": "1.0.0",
        "description": "Simple order lifecycle for the demo.",
    },
    "states": [
        {"name": "pending", "type": "initial"},
        {"name": "submitted", "type": "stable"},
        {"name": "completed", "type": "terminal"},
        {"name": "error", "type": "error"},
    ],
    "transitions": [
        {"trigger": "submit", "source": "pending", "dest": "submitted"},
        {"trigger": "complete", "source": "submitted", "dest": "completed"},
        {
            "trigger": "fail",
            "source": ["pending", "submitted"],
            "dest": "error",
        },
    ],
}

# ---------------------------------------------------------------------------
# 4. Pipeline steps
# ---------------------------------------------------------------------------


class ExtractStep(PipelineStep):
    """Pass-through extraction step.

    Simply forwards the raw payload unchanged to the next step.
    """

    def __init__(self) -> None:
        super().__init__(name="extract")

    async def execute(self, data: Any) -> StepResult:
        """Return the data as-is."""
        return StepResult(step_name=self.name, success=True, data=data)


class ValidateStep(PipelineStep):
    """Validate a record against a pycharter contract.

    Args:
        validator: A pre-configured pycharter ``Validator``.
    """

    def __init__(self, validator: Validator) -> None:
        super().__init__(name="validate")
        self._validator = validator

    async def execute(self, data: Any) -> StepResult:
        """Run validation and return errors if the record is invalid."""
        result = self._validator.validate(data)
        if result.is_valid:
            return StepResult(step_name=self.name, success=True, data=data)
        return StepResult(
            step_name=self.name,
            success=False,
            data=data,
            error=f"Validation failed: {result.errors}",
        )


class StateLoadStep(PipelineStep):
    """Transition an order through a pystator state machine.

    Creates a fresh ``EntitySession`` for each record, sends the
    ``submit`` trigger, and reports the resulting state.
    """

    def __init__(self, machine: StateMachine) -> None:
        super().__init__(name="state_load")
        self._machine = machine

    async def execute(self, data: Any) -> StepResult:
        """Create a session, send 'submit', and return the new state."""
        session = self._machine.create(context=dict(data))
        transition = session.send("submit")
        if not transition.success:
            return StepResult(
                step_name=self.name,
                success=False,
                data=data,
                error=f"Transition failed: {transition.error}",
            )
        return StepResult(
            step_name=self.name,
            success=True,
            data={**data, "state": session.current_state},
        )


# ---------------------------------------------------------------------------
# 5. Main orchestration
# ---------------------------------------------------------------------------


async def main() -> None:
    """Generate orders, ingest, validate, and load into state machine."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # --- Generate mock data ---
    engine = GenerationEngine()
    gen_result = engine.generate(ORDER_SCHEMA, count=20, seed=42)
    records = gen_result.records
    logger.info("Generated %d mock order records", len(records))

    # --- Build components ---
    validator = Validator(contract_dict=ORDER_CONTRACT)
    machine = StateMachine.from_dict(ORDER_MACHINE_CONFIG)

    steps: list[PipelineStep] = [
        ExtractStep(),
        ValidateStep(validator),
        StateLoadStep(machine),
    ]

    agent = PipelineAgent(agent_id="order-ingest-agent", steps=steps)
    transport = InMemoryTransport()

    # --- Inject messages ---
    topic = "orders"
    messages = [
        Message(topic=topic, key=str(r.get("order_id", i)), payload=r)
        for i, r in enumerate(records)
    ]
    transport.inject(topic, messages)
    logger.info("Injected %d messages into topic '%s'", len(messages), topic)

    # --- Run batch ---
    result: AgentResult = await run_batch(
        agent=agent,
        transport=transport,
        topic=topic,
        max_messages=len(messages),
    )

    # --- Summary ---
    logger.info("Batch complete — processed: %d", result.messages_processed)
    logger.info("Success: %s", result.success)
    if result.errors:
        logger.warning("Errors (%d):", len(result.errors))
        for err in result.errors:
            logger.warning("  %s", err)
    else:
        logger.info("No errors")
    if result.metadata:
        logger.info("Metadata: %s", result.metadata)


if __name__ == "__main__":
    asyncio.run(main())
