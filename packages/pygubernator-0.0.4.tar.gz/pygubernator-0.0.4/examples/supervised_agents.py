"""Example: AgentSupervisor with multiple agents and middleware.

Demonstrates:
- AgentSupervisor managing 3 agents
- RetryMiddleware for fault tolerance
- LoggingMiddleware for observability
- AgentPipeline for chaining agents

Usage:
    python examples/supervised_agents.py
"""

from __future__ import annotations

import asyncio
import logging

from pygubernator._middleware import MiddlewareChain
from pygubernator._supervisor import AgentPipeline, AgentSupervisor, RestartPolicy
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.middleware._logging import LoggingMiddleware
from pygubernator.middleware._retry import RetryMiddleware

logging.basicConfig(level=logging.INFO, format="%(name)s | %(message)s")
logger = logging.getLogger(__name__)


# -- Example agents --


class ExtractAgent(BaseAgent):
    """Extracts raw data from a message."""

    async def process(self, message: Message) -> AgentResult:
        data = message.payload.get("records", [])
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
            metadata={"records": data, "stage": "extracted"},
        )


class TransformAgent(BaseAgent):
    """Transforms records by adding a computed field."""

    async def process(self, message: Message) -> AgentResult:
        records = message.payload.get("records", [])
        transformed = [{**r, "processed": True} for r in records]
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
            metadata={"records": transformed, "stage": "transformed"},
        )


class LoadAgent(BaseAgent):
    """Loads records to a destination (simulated)."""

    async def process(self, message: Message) -> AgentResult:
        records = message.payload.get("records", [])
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
            metadata={
                "loaded_count": len(records),
                "stage": "loaded",
            },
        )


async def main() -> None:
    """Run the supervised agents example."""
    # Create agents
    extractor = ExtractAgent("extractor")
    transformer = TransformAgent("transformer")
    loader = LoadAgent("loader")

    # Set up supervisor
    supervisor = AgentSupervisor(restart_policy=RestartPolicy.ON_FAILURE)
    supervisor.add_agent(extractor)
    supervisor.add_agent(transformer)
    supervisor.add_agent(loader)

    logger.info("Supervisor status: %s", supervisor.status())
    supervisor.start_all()
    logger.info("After start: %s", supervisor.status())

    # Use AgentPipeline to chain agents
    pipeline = AgentPipeline([extractor, transformer, loader])

    # Wrap pipeline with middleware
    _chain = MiddlewareChain(
        extractor,  # Just for middleware demo
        [
            LoggingMiddleware(),
            RetryMiddleware(max_retries=2, base_delay=0.01),
        ],
    )

    # Process a message through the pipeline
    msg = Message(
        topic="input",
        payload={
            "records": [
                {"id": 1, "name": "Alice"},
                {"id": 2, "name": "Bob"},
                {"id": 3, "name": "Charlie"},
            ]
        },
    )

    logger.info("Running agent pipeline...")
    result = await pipeline.process(msg)
    logger.info(
        "Pipeline result: success=%s, loaded=%s",
        result.success,
        result.metadata.get("loaded_count"),
    )

    # Health check
    health = await supervisor.check_health()
    logger.info("Health: %s", health)

    # Clean shutdown
    supervisor.stop_all()
    logger.info("Final status: %s", supervisor.status())


if __name__ == "__main__":
    asyncio.run(main())
