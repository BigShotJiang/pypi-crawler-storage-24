#!/usr/bin/env bash
# Stop tracking paths that are listed in .gitignore but were committed earlier
# (e.g. before .gitignore existed or after git add -f).
# Safe to run multiple times. Does not delete files on disk.
set -euo pipefail
cd "$(dirname "$0")/.."

say() { printf '%s\n' "$*"; }

say "Removing ignored paths from the git index (files stay on disk)..."

git rm -r --cached dist/ 2>/dev/null || true
git rm -r --cached src/pygubernator/ui/.next/ 2>/dev/null || true
git rm -r --cached src/pygubernator/ui/node_modules/ 2>/dev/null || true
git rm -r --cached src/pygubernator/ui/static/ 2>/dev/null || true
git rm -r --cached src/pygubernator/ui/out/ 2>/dev/null || true
git rm --cached pygubernator.cfg 2>/dev/null || true
git rm --cached pygubernator_control_plane.db 2>/dev/null || true
git rm -r --cached src/pygubernator.egg-info/ 2>/dev/null || true

# Bytecode / incremental TS (may need -f if index conflicts with working tree)
if git ls-files | grep -q '__pycache__'; then
  git ls-files | grep '__pycache__' | xargs git rm -f --cached
fi
if git ls-files | grep -q 'tsconfig\.tsbuildinfo$'; then
  git ls-files | grep 'tsconfig\.tsbuildinfo$' | xargs git rm -f --cached
fi

say "Done. Run: git status"
say "If this looks right: git commit -m 'chore: stop tracking gitignored build/local files'"
