"""LLM provider configuration and known-provider registry."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any


class ProviderType(StrEnum):
    """Supported LLM provider backends."""

    LITELLM = "litellm"
    OPENAI_COMPATIBLE = "openai_compatible"
    LOCAL = "local"


@dataclass(frozen=True, slots=True)
class ProviderConfig:
    """Typed configuration for creating an LLM provider.

    Attributes:
        provider_type: Which provider backend to use.
        model: Model identifier or name.
        api_base: Server URL for remote providers.
        api_key: API key for authenticated providers.
        max_tokens: Maximum tokens per response.
        temperature: Sampling temperature.
        top_p: Nucleus sampling parameter.
        top_k: Top-k sampling parameter.
        model_path: Local file path for GGUF models.
        n_ctx: Context window size for local models.
        n_gpu_layers: GPU layers for local models (-1 = all).
    """

    provider_type: ProviderType
    model: str
    api_base: str | None = None
    api_key: str | None = None
    max_tokens: int = 4096
    temperature: float = 0.0
    top_p: float | None = None
    top_k: int | None = None
    model_path: str | None = None
    n_ctx: int = 4096
    n_gpu_layers: int = -1

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "provider_type": self.provider_type.value,
            "model": self.model,
            "api_base": self.api_base,
            "api_key": self.api_key,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "top_k": self.top_k,
            "model_path": self.model_path,
            "n_ctx": self.n_ctx,
            "n_gpu_layers": self.n_gpu_layers,
        }


@dataclass(frozen=True, slots=True)
class ProviderPreset:
    """Known provider preset with sensible defaults.

    Attributes:
        provider_type: Backend type for this provider.
        default_api_base: Default server URL (None for local).
        requires_api_key: Whether an API key is needed.
        models: Known model identifiers for this provider.
        description: Human-readable description.
    """

    provider_type: ProviderType
    default_api_base: str | None
    requires_api_key: bool
    models: tuple[str, ...]
    description: str

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "provider_type": self.provider_type.value,
            "default_api_base": self.default_api_base,
            "requires_api_key": self.requires_api_key,
            "models": list(self.models),
            "description": self.description,
        }


KNOWN_PROVIDERS: dict[str, ProviderPreset] = {
    "openai": ProviderPreset(
        provider_type=ProviderType.LITELLM,
        default_api_base=None,
        requires_api_key=True,
        models=(
            "gpt-4o",
            "gpt-4o-mini",
            "gpt-4-turbo",
            "o1",
            "o3-mini",
        ),
        description="OpenAI ChatGPT models",
    ),
    "anthropic": ProviderPreset(
        provider_type=ProviderType.LITELLM,
        default_api_base=None,
        requires_api_key=True,
        models=(
            "claude-opus-4-20250514",
            "claude-sonnet-4-20250514",
            "claude-haiku-4-5-20251001",
        ),
        description="Anthropic Claude models",
    ),
    "gemini": ProviderPreset(
        provider_type=ProviderType.LITELLM,
        default_api_base=None,
        requires_api_key=True,
        models=(
            "gemini-2.5-pro",
            "gemini-2.5-flash",
            "gemini-2.0-flash",
        ),
        description="Google Gemini models",
    ),
    "ollama": ProviderPreset(
        provider_type=ProviderType.OPENAI_COMPATIBLE,
        default_api_base="http://localhost:11434/v1",
        requires_api_key=False,
        models=(
            "llama3.1",
            "llama3.2",
            "mistral",
            "codellama",
            "qwen2.5",
            "phi3",
            "gemma2",
        ),
        description="Local models via Ollama",
    ),
    "deepseek": ProviderPreset(
        provider_type=ProviderType.OPENAI_COMPATIBLE,
        default_api_base="https://api.deepseek.com/v1",
        requires_api_key=True,
        models=(
            "deepseek-chat",
            "deepseek-reasoner",
        ),
        description="Deepseek API",
    ),
    "glm": ProviderPreset(
        provider_type=ProviderType.OPENAI_COMPATIBLE,
        default_api_base="https://open.bigmodel.cn/api/paas/v4",
        requires_api_key=True,
        models=(
            "glm-4-plus",
            "glm-4-flash",
            "glm-4-long",
            "glm-4v-plus",
        ),
        description="GLM / ChatGLM models",
    ),
    "vllm": ProviderPreset(
        provider_type=ProviderType.OPENAI_COMPATIBLE,
        default_api_base="http://localhost:8000/v1",
        requires_api_key=False,
        models=(),
        description="vLLM inference server",
    ),
    "local": ProviderPreset(
        provider_type=ProviderType.LOCAL,
        default_api_base=None,
        requires_api_key=False,
        models=(),
        description="Local GGUF models via llama-cpp-python",
    ),
}
