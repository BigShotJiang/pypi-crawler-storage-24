"""OpenAI-compatible LLM provider using httpx."""

from __future__ import annotations

import json
import logging
from typing import Any

from pygubernator.errors import LLMError
from pygubernator.llm._messages import LLMResponse, ToolCall

logger = logging.getLogger(__name__)

_PROVIDER_NAME = "openai_compatible"


class OpenAICompatibleProvider:
    """LLM provider for any OpenAI-compatible API server.

    Works with Ollama, vLLM, Deepseek API, GLM API, LocalAI,
    LM Studio, and any server implementing ``/v1/chat/completions``.

    Args:
        api_base: Base URL (e.g. ``http://localhost:11434/v1``).
        model: Model identifier.
        api_key: API key (optional for local servers).
        max_tokens: Maximum tokens per response.
        temperature: Sampling temperature.
        top_p: Nucleus sampling parameter.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        api_base: str,
        model: str,
        api_key: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        top_p: float | None = None,
        timeout: float = 120.0,
    ) -> None:
        self._api_base = api_base.rstrip("/")
        self._model = model
        self._api_key = api_key
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._top_p = top_p
        self._timeout = timeout

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Send a chat completion request.

        Args:
            messages: Conversation messages in OpenAI format.
            tools: Optional tool schemas for function calling.

        Returns:
            LLM response with content and/or tool calls.

        Raises:
            LLMError: If the request fails.
        """
        client = self._make_client()
        body = self._build_request_body(messages, tools)

        try:
            async with client:
                resp = await client.post(
                    f"{self._api_base}/chat/completions",
                    json=body,
                )
                resp.raise_for_status()
                data = resp.json()
        except Exception as exc:
            raise LLMError(
                f"OpenAI-compatible API call failed: {exc}",
                provider=_PROVIDER_NAME,
                context={"model": self._model, "api_base": self._api_base},
            ) from exc

        return self._parse_response(data)

    async def list_models(self) -> list[str]:
        """Fetch available models from the server.

        Returns:
            List of model identifiers.

        Raises:
            LLMError: If the request fails.
        """
        client = self._make_client()
        try:
            async with client:
                resp = await client.get(f"{self._api_base}/models")
                resp.raise_for_status()
                data = resp.json()
        except Exception as exc:
            raise LLMError(
                f"Failed to list models: {exc}",
                provider=_PROVIDER_NAME,
                context={"api_base": self._api_base},
            ) from exc

        models_data = data.get("data", [])
        return [m.get("id", "") for m in models_data if m.get("id")]

    async def health_check(self) -> bool:
        """Ping the server to check if it is reachable.

        Returns:
            True if the server responds, False otherwise.
        """
        client = self._make_client()
        try:
            async with client:
                resp = await client.get(
                    f"{self._api_base}/models",
                )
                return resp.status_code < 500
        except Exception:
            return False

    def _make_client(self) -> Any:
        """Create an httpx async client."""
        try:
            import httpx
        except ImportError as exc:
            raise LLMError(
                "httpx is required for OpenAICompatibleProvider. "
                "Install with: pip install pygubernator[openai-compat]",
                provider=_PROVIDER_NAME,
            ) from exc

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        return httpx.AsyncClient(
            headers=headers,
            timeout=self._timeout,
        )

    def _build_request_body(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Build the OpenAI-format request body."""
        body: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
        }
        if self._top_p is not None:
            body["top_p"] = self._top_p
        if tools:
            body["tools"] = _format_tools(tools)
        return body

    @staticmethod
    def _parse_response(data: dict[str, Any]) -> LLMResponse:
        """Parse an OpenAI-format JSON response into LLMResponse."""
        choices = data.get("choices", [])
        if not choices:
            return LLMResponse(content="", finish_reason="stop")

        choice = choices[0]
        message = choice.get("message", {})

        tool_calls: list[ToolCall] = []
        raw_calls = message.get("tool_calls") or []
        for tc in raw_calls:
            func = tc.get("function", {})
            args = func.get("arguments", "{}")
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            tool_calls.append(
                ToolCall(
                    id=tc.get("id", ""),
                    name=func.get("name", ""),
                    arguments=args,
                )
            )

        usage_data = data.get("usage") or {}
        usage: dict[str, int] = {}
        if usage_data:
            usage = {
                "prompt_tokens": usage_data.get("prompt_tokens", 0),
                "completion_tokens": usage_data.get("completion_tokens", 0),
                "total_tokens": usage_data.get("total_tokens", 0),
            }

        return LLMResponse(
            content=message.get("content") or "",
            tool_calls=tuple(tool_calls),
            finish_reason=choice.get("finish_reason") or "stop",
            usage=usage,
            model=data.get("model") or "",
        )


def _format_tools(
    tools: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert tool schemas to OpenAI-compatible format."""
    formatted: list[dict[str, Any]] = []
    for t in tools:
        formatted.append(
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("parameters", {}),
                },
            }
        )
    return formatted
