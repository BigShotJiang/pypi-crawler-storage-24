"""Logging middleware for message processing observability."""

from __future__ import annotations

import logging
import time

from pygubernator._middleware import NextFn
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent

logger = logging.getLogger(__name__)


class LoggingMiddleware:
    """Logs message receipt, processing duration, and outcome."""

    async def __call__(
        self,
        message: Message,
        agent: BaseAgent,
        next_fn: NextFn,
    ) -> AgentResult:
        """Log before and after processing.

        Args:
            message: The incoming message.
            agent: The processing agent.
            next_fn: Next middleware or agent call.

        Returns:
            The agent result.
        """
        logger.info(
            "Agent %s received message on topic %s",
            agent.agent_id,
            message.topic,
        )
        start = time.perf_counter()
        try:
            result = await next_fn(message, agent)
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "Agent %s processed message in %.1fms (success=%s)",
                agent.agent_id,
                elapsed_ms,
                result.success,
            )
            return result
        except Exception:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.error(
                "Agent %s failed after %.1fms",
                agent.agent_id,
                elapsed_ms,
            )
            raise
