"""Retry middleware with exponential backoff and jitter."""

from __future__ import annotations

import asyncio
import logging
import random

from pygubernator._middleware import NextFn
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent

logger = logging.getLogger(__name__)


class RetryMiddleware:
    """Retries failed agent processing with exponential backoff.

    Args:
        max_retries: Maximum number of retry attempts.
        base_delay: Base delay in seconds before first retry.
        max_delay: Maximum delay cap in seconds.
        retry_on: Optional tuple of exception types to retry on.
            If None, retries on all exceptions.
    """

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 0.1,
        max_delay: float = 30.0,
        retry_on: tuple[type[Exception], ...] | None = None,
    ) -> None:
        self._max_retries = max_retries
        self._base_delay = base_delay
        self._max_delay = max_delay
        self._retry_on = retry_on

    async def __call__(
        self,
        message: Message,
        agent: BaseAgent,
        next_fn: NextFn,
    ) -> AgentResult:
        """Execute with retries on failure.

        Args:
            message: The incoming message.
            agent: The processing agent.
            next_fn: Next middleware or agent call.

        Returns:
            The result from a successful attempt.
        """
        last_exc: Exception | None = None
        for attempt in range(self._max_retries + 1):
            try:
                result = await next_fn(message, agent)
                if result.success or attempt == self._max_retries:
                    return result
                # Non-success result: treat as retriable failure.
                last_exc = None
            except Exception as exc:
                if self._retry_on and not isinstance(exc, self._retry_on):
                    raise
                last_exc = exc
                if attempt == self._max_retries:
                    raise

            delay = min(
                self._base_delay * (2**attempt) + random.uniform(0, 0.1),
                self._max_delay,
            )
            logger.warning(
                "Retry %d/%d for agent %s after %.2fs",
                attempt + 1,
                self._max_retries,
                agent.agent_id,
                delay,
            )
            await asyncio.sleep(delay)

        # Should not reach here, but satisfy type checker.
        if last_exc:
            raise last_exc
        return result  # type: ignore[possibly-undefined]
