'use client'

import { useEffect, useRef, useState } from 'react'

const OVERLAP_RATIO = 0.85

/**
 * Returns whether the toolbar should be collapsed based on its width vs parent.
 * When toolbar width exceeds ~85% of parent width, collapses to avoid overflow.
 */
export function useToolbarCompression(toolbarRef: React.RefObject<HTMLDivElement | null>): boolean {
  const uncollapsedWidthRef = useRef(0)
  const isCollapsedRef = useRef(false)
  const [isCollapsed, setIsCollapsed] = useState(false)

  useEffect(() => {
    const toolbar = toolbarRef.current
    const parent = toolbar?.parentElement
    if (!toolbar || !parent) return

    const wouldOverlap = (toolbarW: number, parentW: number) =>
      toolbarW > parentW * OVERLAP_RATIO

    const check = () => {
      const parentWidth = parent.clientWidth
      if (!isCollapsedRef.current) {
        uncollapsedWidthRef.current = toolbar.offsetWidth
        if (wouldOverlap(uncollapsedWidthRef.current, parentWidth)) {
          isCollapsedRef.current = true
          setIsCollapsed(true)
        }
      } else if (!wouldOverlap(uncollapsedWidthRef.current, parentWidth)) {
        isCollapsedRef.current = false
        setIsCollapsed(false)
        requestAnimationFrame(() => {
          const freshWidth = toolbar.offsetWidth
          uncollapsedWidthRef.current = freshWidth
          if (wouldOverlap(freshWidth, parent.clientWidth)) {
            isCollapsedRef.current = true
            setIsCollapsed(true)
          }
        })
      }
    }

    const observer = new ResizeObserver(check)
    observer.observe(parent)
    return () => observer.disconnect()
  }, [toolbarRef])

  return isCollapsed
}
