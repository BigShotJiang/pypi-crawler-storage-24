"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Polls a fetcher at a given interval. Returns the last-updated timestamp
 * and a manual refresh trigger.
 */
export function usePolling(
  fetcher: () => Promise<void>,
  intervalMs: number,
  enabled: boolean = true
): { lastUpdated: Date | null; refresh: () => void } {
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  const refresh = useCallback(async () => {
    await fetcherRef.current();
    setLastUpdated(new Date());
  }, []);

  useEffect(() => {
    if (!enabled) return;
    let active = true;

    const tick = async () => {
      if (!active) return;
      try {
        await fetcherRef.current();
        if (active) setLastUpdated(new Date());
      } catch {
        // swallow polling errors silently
      }
    };

    const id = window.setInterval(() => void tick(), intervalMs);
    return () => {
      active = false;
      window.clearInterval(id);
    };
  }, [intervalMs, enabled]);

  return { lastUpdated, refresh };
}
