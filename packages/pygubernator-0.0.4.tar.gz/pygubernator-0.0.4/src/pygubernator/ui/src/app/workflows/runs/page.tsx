import { Suspense } from "react";

import WorkflowRunInner from "./WorkflowRunInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function WorkflowRunsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading runs..." />}>
      <WorkflowRunInner />
    </Suspense>
  );
}
