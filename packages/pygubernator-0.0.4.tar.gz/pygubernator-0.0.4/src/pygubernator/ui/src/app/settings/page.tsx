import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function SettingsPage() {
  return (
    <PageContainer>
      <PageHeader
        title="Settings"
        description="Environment variables for the control-plane UI"
      />
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">API connection</CardTitle>
          <CardDescription>
            Set at build time (static export) or via your shell when running{" "}
            <code className="text-xs bg-muted px-1 py-0.5 rounded">npm run dev</code>.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-sm space-y-3 text-muted-foreground">
          <ul className="list-disc list-inside space-y-2">
            <li>
              <code className="text-foreground">NEXT_PUBLIC_PYGUBERNATOR_API_URL</code> — API base URL (e.g.{" "}
              <code className="text-xs">http://127.0.0.1:8010</code>)
            </li>
            <li>
              <code className="text-foreground">NEXT_PUBLIC_PYGUBERNATOR_TOKEN</code> —{" "}
              <code className="text-xs">X-API-Token</code> value (default <code className="text-xs">dev-token</code>)
            </li>
          </ul>
          <p>
            In development, Next.js can proxy <code className="text-xs bg-muted px-1 rounded">/api/*</code> to the
            backend when <code className="text-xs">NEXT_PUBLIC_PYGUBERNATOR_API_URL</code> is set (see{" "}
            <code className="text-xs">next.config.mjs</code>).
          </p>
        </CardContent>
      </Card>
    </PageContainer>
  );
}
