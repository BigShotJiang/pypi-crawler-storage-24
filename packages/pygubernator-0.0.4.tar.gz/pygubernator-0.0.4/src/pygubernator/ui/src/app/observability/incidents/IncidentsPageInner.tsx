"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { RefreshCw } from "lucide-react";

import { ObservabilityTabs } from "@/components/observability/ObservabilityTabs";
import { StatusBadge } from "@/components/observability/StatusBadge";
import { IncidentsTable } from "@/components/observability/IncidentsTable";
import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiGet } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { cn, formatDateTimeShort } from "@/lib/utils";

interface IncidentItem {
  id: string;
  title: string;
  run_id: string | null;
  alert_id: string | null;
  status: string;
  severity: string;
  owner: string | null;
  acknowledged_at: string | null;
  silenced_until: string | null;
  resolved_at: string | null;
  details: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

interface AuditItem {
  id: string;
  actor: string;
  action: string;
  resource_type: string;
  resource_id: string | null;
  created_at: string;
}

export default function IncidentsPageInner() {
  const searchParams = useSearchParams();
  const id = searchParams.get("id");
  const status = searchParams.get("status") ?? undefined;
  const owner = searchParams.get("owner") ?? undefined;
  const activeWindow = searchParams.get("window") ?? "24h";

  const [list, setList] = useState<{ items: IncidentItem[] } | null>(null);
  const [detail, setDetail] = useState<{
    incident: IncidentItem;
    audit: AuditItem[];
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const loadList = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ items: IncidentItem[] }>("/api/v1/observability/incidents", {
        status,
        owner,
        limit: 200
      });
      setList(data);
      setDetail(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [status, owner]);

  const loadDetail = useCallback(async (incidentId: string) => {
    setLoading(true);
    setError(null);
    try {
      const [incident, auditRes] = await Promise.all([
        apiGet<IncidentItem>(`/api/v1/observability/incidents/${incidentId}`),
        apiGet<{ items: AuditItem[] }>("/api/v1/policies/audit", { limit: 100 })
      ]);
      const relevantAudit = auditRes.items.filter(
        (item) => item.resource_type === "incident" && item.resource_id === incident.id
      );
      setDetail({ incident, audit: relevantAudit });
      setList(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (id) loadDetail(id);
    else loadList();
  }, [id, loadDetail, loadList]);

  const refresh = () => {
    if (id) loadDetail(id);
    else loadList();
  };

  const statuses = ["open", "acknowledged", "silenced", "resolved"];

  function listHref(next?: { status?: string | null; owner?: string | null }) {
    const q = new URLSearchParams();
    q.set("window", activeWindow);
    const s = next && "status" in next ? next.status : status;
    const o = next && "owner" in next ? next.owner : owner;
    if (s) q.set("status", s);
    if (o) q.set("owner", o);
    return `${ROUTES.OBS_INCIDENTS}?${q.toString()}`;
  }

  if (loading && !list && !detail) {
    return (
      <PageContainer>
        <PageLoading message="Loading incidents…" />
      </PageContainer>
    );
  }

  if (id && detail) {
    const { incident, audit } = detail;
    const backHref = listHref();
    return (
      <PageContainer>
        <PageHeader
          title={`Incident ${incident.id.slice(0, 8)}…`}
          description={incident.title}
          actions={
            <>
              <Button variant="outline" size="sm" onClick={refresh}>
                <RefreshCw className="h-4 w-4 mr-1" />
                Refresh
              </Button>
              <Link href={backHref} className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}>
                Back to queue
              </Link>
            </>
          }
        />
        <ObservabilityTabs />
        {error && <ErrorDisplay error={error} className="mb-4" />}
        <Card className="mb-4">
          <CardHeader>
            <CardTitle className="text-base">Summary</CardTitle>
          </CardHeader>
          <CardContent className="text-sm space-y-2">
            <p>
              Status: <StatusBadge label={incident.status} /> · Severity: {incident.severity} · Owner:{" "}
              {incident.owner ?? "unassigned"}
            </p>
            <p className="text-muted-foreground">
              Created {formatDateTimeShort(incident.created_at)} · Updated {formatDateTimeShort(incident.updated_at)}
            </p>
            {incident.run_id ? (
              <p>
                Linked run:{" "}
                <Link href={`${ROUTES.RUNS}?id=${encodeURIComponent(incident.run_id)}`} className="text-primary hover:underline font-mono text-xs">
                  {incident.run_id.slice(0, 8)}…
                </Link>
              </p>
            ) : null}
            {incident.alert_id ? (
              <p className="text-muted-foreground">Linked alert: {incident.alert_id.slice(0, 8)}…</p>
            ) : null}
          </CardContent>
        </Card>
        <Card className="mb-4">
          <CardHeader>
            <CardTitle className="text-base">Details</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="overflow-x-auto rounded-md border border-border bg-muted/50 p-3 text-xs">
              {JSON.stringify(incident.details, null, 2)}
            </pre>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Audit trail</CardTitle>
          </CardHeader>
          <CardContent>
            {audit.length === 0 ? (
              <p className="text-sm text-muted-foreground">No incident audit entries found.</p>
            ) : (
              <ul className="text-sm space-y-2">
                {audit.map((item) => (
                  <li key={item.id}>
                    {item.action} by {item.actor} at {formatDateTimeShort(item.created_at)}
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </PageContainer>
    );
  }

  const owners = list
    ? ([...new Set(list.items.map((i) => i.owner).filter(Boolean))] as string[])
    : [];

  return (
    <PageContainer>
      <PageHeader
        title="Incident queue"
        description="Track and triage incidents with ownership and lifecycle actions."
        actions={
          <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        }
      />
      <ObservabilityTabs />
      {error && <ErrorDisplay error={error} className="mb-4" />}
      <div className="flex flex-wrap gap-2 mb-4">
        <Link
          href={listHref({ status: null })}
          className={cn(
            buttonVariants({ variant: status ? "outline" : "default", size: "sm" }),
            "h-8"
          )}
        >
          All statuses
        </Link>
        {statuses.map((item) => (
          <Link
            key={item}
            href={listHref({ status: item })}
            className={cn(
              buttonVariants({ variant: status === item ? "default" : "outline", size: "sm" }),
              "h-8 capitalize"
            )}
          >
            {item}
          </Link>
        ))}
      </div>
      {owners.length > 0 ? (
        <div className="flex flex-wrap gap-2 mb-4">
          <Link
            href={listHref({ owner: null })}
            className={cn(
              buttonVariants({ variant: owner ? "outline" : "default", size: "sm" }),
              "h-8 text-xs"
            )}
          >
            All owners
          </Link>
          {owners.map((item) => (
            <Link
              key={item}
              href={listHref({ owner: item })}
              className={cn(
                buttonVariants({ variant: owner === item ? "default" : "outline", size: "sm" }),
                "h-8 text-xs"
              )}
            >
              {item}
            </Link>
          ))}
        </div>
      ) : null}
      {list && (
        <IncidentsTable
          incidents={list.items}
          activeWindow={activeWindow}
          onInvalidate={loadList}
        />
      )}
    </PageContainer>
  );
}
