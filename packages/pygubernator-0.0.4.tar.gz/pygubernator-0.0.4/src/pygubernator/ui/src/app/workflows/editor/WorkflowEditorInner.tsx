"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";

import {
  Panel as ResPanel,
  Group as ResGroup,
  Separator as ResSep,
} from "react-resizable-panels";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading } from "@/components/LoadingSpinner";
import { ResizableWorkspaceLayout } from "@/components/layout/ResizableWorkspaceLayout";
import WorkflowCanvas from "@/components/workflows/WorkflowCanvas";
import WorkflowEditorSidebar from "@/components/workflows/WorkflowEditorSidebar";
import WorkflowEditorToolbar from "@/components/workflows/WorkflowEditorToolbar";
import WorkflowInspectorPanel from "@/components/workflows/WorkflowInspectorPanel";
import { WorkflowCompanionPanel } from "@/components/workflows/WorkflowCompanionPanel";
import { CommandPalette } from "@/components/workflows/CommandPalette";
import { ExecuteInputDialog } from "@/components/workflows/ExecuteInputDialog";
import { useToast } from "@/components/ui/toaster";
import { apiGet, apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import type { WorkflowItem, VersionRow, SpecJson } from "@/lib/types/workflow";
import {
  useWorkflowEditorStore,
  selectSpec,
  selectSetSpec,
  selectAddNode,
  selectRemoveNode,
  selectUpdateNodeConfig,
  selectUpdateNodes,
  selectUpdateEdges,
  selectSelectedNodeIds,
  selectSetSelectedNodeIds,
  selectPastLength,
  selectFutureLength,
  selectUndo,
  selectRedo,
  selectRunOverlay,
  selectLastRunId,
  selectSetRunOverlay,
  selectSetLastRunId,
  selectBottomPanelOpen,
  selectMarkSaved,
} from "@/stores/workflow-editor";
import { useWorkflowShortcuts } from "@/hooks/useWorkflowShortcuts";
import { usePolling } from "@/hooks/usePolling";

export default function WorkflowEditorInner() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();
  const workflowIdParam = searchParams.get("id");

  const [workflowId, setWorkflowId] = useState<string | null>(workflowIdParam);
  const [workflow, setWorkflow] = useState<WorkflowItem | null>(null);
  const [versions, setVersions] = useState<VersionRow[]>([]);
  const [versionsLoading, setVersionsLoading] = useState(false);
  const [currentVersion, setCurrentVersion] = useState<string>("");
  const [loading, setLoading] = useState(!!workflowIdParam);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [saveVersion, setSaveVersion] = useState("1.0.0");
  const [saveName, setSaveName] = useState("");
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [inputDialogOpen, setInputDialogOpen] = useState(false);
  const [fitViewTrigger, setFitViewTrigger] = useState(0);

  // Keep workflowId in sync with URL param changes
  useEffect(() => {
    setWorkflowId(workflowIdParam);
    if (!workflowIdParam) {
      setLoading(false);
    }
  }, [workflowIdParam]);

  // Store selectors
  const spec = useWorkflowEditorStore(selectSpec);
  const setSpec = useWorkflowEditorStore(selectSetSpec);
  const addNode = useWorkflowEditorStore(selectAddNode);
  const removeNode = useWorkflowEditorStore(selectRemoveNode);
  const updateNodeConfig = useWorkflowEditorStore(selectUpdateNodeConfig);
  const updateNodes = useWorkflowEditorStore(selectUpdateNodes);
  const updateEdges = useWorkflowEditorStore(selectUpdateEdges);
  const selectedNodeIds = useWorkflowEditorStore(selectSelectedNodeIds);
  const setSelectedNodeIds = useWorkflowEditorStore(selectSetSelectedNodeIds);
  const canUndo = useWorkflowEditorStore(selectPastLength) > 0;
  const canRedo = useWorkflowEditorStore(selectFutureLength) > 0;
  const undo = useWorkflowEditorStore(selectUndo);
  const redo = useWorkflowEditorStore(selectRedo);
  const runOverlay = useWorkflowEditorStore(selectRunOverlay);
  const lastRunId = useWorkflowEditorStore(selectLastRunId);
  const setRunOverlay = useWorkflowEditorStore(selectSetRunOverlay);
  const setLastRunId = useWorkflowEditorStore(selectSetLastRunId);
  const bottomPanelOpen = useWorkflowEditorStore(selectBottomPanelOpen);
  const markSaved = useWorkflowEditorStore(selectMarkSaved);

  const isDraft = !workflowId;

  const refreshVersions = useCallback(async (id: string) => {
    setVersionsLoading(true);
    try {
      const result = await apiGet<{ items: VersionRow[] }>(
        `/api/v1/workflows/${id}/versions`,
      );
      const items = result.items ?? [];
      setVersions(items);
      const active = items.find((v) => v.active) ?? items[0] ?? null;
      setCurrentVersion(active?.version ?? "");
      return items;
    } finally {
      setVersionsLoading(false);
    }
  }, []);

  /* --- Load existing workflow --- */

  const loadWorkflow = useCallback(async () => {
    if (!workflowId) {
      setVersions([]);
      setCurrentVersion("");
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const [wf, versionsRes] = await Promise.all([
        apiGet<WorkflowItem>(`/api/v1/workflows/${workflowId}`),
        apiGet<{ items: VersionRow[] }>(
          `/api/v1/workflows/${workflowId}/versions`,
        ),
      ]);
      setWorkflow(wf);
      setSaveName(wf.name);
      const loadedVersions = versionsRes.items ?? [];
      setVersions(loadedVersions);
      const active =
        loadedVersions.find((v) => v.active) ?? loadedVersions[0] ?? null;
      setCurrentVersion(active?.version ?? "");
      if (active?.spec_json) {
        setSpec(active.spec_json, { replaceHistory: true });
        setSaveVersion(bumpPatch(active.version));
      }
    } catch (e) {
      // If workflow not found, fall back to draft mode
      setWorkflowId(null);
      setWorkflow(null);
      setLoading(false);
      return;
    } finally {
      setLoading(false);
    }
  }, [workflowId, setSpec]);

  const handleSelectVersion = useCallback((versionId: string) => {
    const selected = versions.find((v) => v.id === versionId);
    if (!selected) return;
    setSpec(selected.spec_json, { replaceHistory: true });
    setCurrentVersion(selected.version);
    setSaveVersion(bumpPatch(selected.version));
    markSaved();
    setRunOverlay(null);
  }, [versions, setSpec, markSaved, setRunOverlay]);

  useEffect(() => {
    loadWorkflow();
  }, [loadWorkflow]);

  // Reset spec when entering draft mode without a workflow
  useEffect(() => {
    if (isDraft && !workflow) {
      setVersions([]);
      setCurrentVersion("");
      setSaveVersion("1.0.0");
      setSpec({ meta: { name: "", version: "1.0.0" }, nodes: {}, edges: [] }, { replaceHistory: true });
    }
    // Only on mount / draft transition
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDraft]);

  /* --- Save (create-on-first-save for drafts) --- */

  const saveWorkflow = useCallback(async () => {
    if (!saveVersion.trim()) return;
    setBusy(true);
    setError(null);

    try {
      let targetId = workflowId;

      // Draft mode: create the workflow first
      if (!targetId) {
        const name = saveName.trim() || `Workflow ${new Date().toLocaleString()}`;
        const created = await apiPost<
          { name: string; owner: string },
          WorkflowItem
        >("/api/v1/workflows", { name, owner: "system" });
        targetId = created.id;
        setWorkflowId(targetId);
        setWorkflow(created);
        setSaveName(created.name);
        // Update URL without full navigation
        router.replace(`${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(targetId)}`);
      }

      await apiPost<{ version: string; spec_json: SpecJson }, VersionRow>(
        `/api/v1/workflows/${targetId}/versions`,
        { version: saveVersion.trim(), spec_json: spec },
      );
      const savedVersion = saveVersion.trim();
      const updatedVersions = await refreshVersions(targetId);
      if (!updatedVersions.some((v) => v.version === savedVersion)) {
        setCurrentVersion(savedVersion);
      }
      markSaved();
      toast(`Saved as version ${savedVersion}`, "success");
      setSaveVersion(bumpPatch(saveVersion));
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  }, [workflowId, saveVersion, saveName, spec, toast, router, markSaved, refreshVersions]);

  /* --- Execute --- */

  const executeWorkflow = useCallback(
    async (inputJson: Record<string, unknown> = {}) => {
      setInputDialogOpen(false);
      setBusy(true);
      setError(null);
      setRunOverlay(null);

      try {
        // Auto-save before executing so the DB has the latest canvas state
        let targetId = workflowId;
        if (!targetId) {
          const name = saveName.trim() || `Workflow ${new Date().toLocaleString()}`;
          const created = await apiPost<
            { name: string; owner: string },
            WorkflowItem
          >("/api/v1/workflows", { name, owner: "system" });
          targetId = created.id;
          setWorkflowId(targetId);
          setWorkflow(created);
          setSaveName(created.name);
          router.replace(`${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(targetId)}`);
        }

        await apiPost<{ version: string; spec_json: SpecJson }, VersionRow>(
          `/api/v1/workflows/${targetId}/versions`,
          { version: saveVersion.trim() || "1.0.0", spec_json: spec },
        );
        const savedVersion = saveVersion.trim() || "1.0.0";
        const updatedVersions = await refreshVersions(targetId);
        if (!updatedVersions.some((v) => v.version === savedVersion)) {
          setCurrentVersion(savedVersion);
        }
        setSaveVersion(bumpPatch(saveVersion));

        const res = await apiPost<
          { input_json: Record<string, unknown> },
          { run: { id: string; status: string } }
        >(`/api/v1/workflows/${targetId}/execute`, {
          input_json: inputJson,
        });
        toast(
          `Run ${res.run.id.slice(0, 8)}... ${res.run.status}`,
          "success",
        );
        setLastRunId(res.run.id);
      } catch (e) {
        const err = e instanceof Error ? e : new Error(String(e));
        setError(err);
        toast(err.message, "error");
      } finally {
        setBusy(false);
      }
    },
    [workflowId, saveName, saveVersion, spec, toast, router, setRunOverlay, setLastRunId, refreshVersions],
  );

  /* --- Run polling --- */

  const pollRun = useCallback(async () => {
    if (!lastRunId || !workflowId) return;
    try {
      const run = await apiGet<{
        id: string;
        status: string;
        steps: Array<{
          id: string; workflow_run_id: string; node_id: string;
          node_type: string; status: string;
          input_json: Record<string, unknown>;
          output_json: Record<string, unknown>;
          error_message: string | null; output_handle: string;
          started_at: string | null; completed_at: string | null;
          duration_ms: number | null;
        }>;
      }>(`/api/v1/workflows/runs/${lastRunId}`);
      const overlay: Record<string, typeof run.steps[0]> = {};
      for (const step of run.steps ?? []) {
        overlay[step.node_id] = step;
      }
      setRunOverlay(overlay);
      const terminal = ["completed", "failed", "cancelled", "success"];
      if (terminal.includes(run.status)) {
        setLastRunId(null);
      }
    } catch {
      // Silently ignore poll errors
    }
  }, [lastRunId, workflowId, setRunOverlay, setLastRunId]);

  usePolling(pollRun, 2000, !!lastRunId);

  /* --- Keyboard shortcuts --- */

  const openExecuteDialog = useCallback(() => {
    setInputDialogOpen(true);
  }, []);

  const shortcutActions = useMemo(() => ({
    onSave: () => void saveWorkflow(),
    onExecute: openExecuteDialog,
    onFitView: () => setFitViewTrigger((n) => n + 1),
    onOpenPalette: () => setPaletteOpen(true),
  }), [saveWorkflow, openExecuteDialog]);

  useWorkflowShortcuts(shortcutActions);

  /* --- Inspector selected node --- */

  const firstSelectedId = selectedNodeIds.length > 0 ? selectedNodeIds[0] : null;
  const nodes = spec.nodes ?? {};
  const edges = spec.edges ?? [];

  /* --- Render --- */

  if (loading) {
    return (
      <div className="flex items-center justify-center" style={{ height: "calc(100vh - 4rem)" }}>
        <PageLoading message="Loading editor..." />
      </div>
    );
  }

  const canvasContent = (
    <div className="relative h-full w-full overflow-hidden">
      <WorkflowCanvas
        nodes={nodes}
        edges={edges}
        selectedNodeIds={selectedNodeIds}
        onSelectNodeIds={setSelectedNodeIds}
        onNodesChange={updateNodes}
        onEdgesChange={updateEdges}
        onRemoveNode={removeNode}
        onAddNode={addNode}
        runOverlay={runOverlay}
        fitViewTrigger={fitViewTrigger}
      />
    </div>
  );

  return (
    <ResizableWorkspaceLayout
      renderSidebar={(api) => (
        <WorkflowEditorSidebar {...api} onAddNode={addNode} />
      )}
    >
      <div className="relative flex flex-col flex-1 h-full overflow-hidden">
        <WorkflowEditorToolbar
          workflowName={workflow?.name ?? (isDraft ? "New Workflow" : "Workflow Editor")}
          workflowId={workflowId ?? ""}
          saveVersion={saveVersion}
          onSaveVersionChange={setSaveVersion}
          currentVersion={currentVersion}
          versions={versions}
          versionsLoading={versionsLoading}
          onSelectVersion={handleSelectVersion}
          onSave={() => void saveWorkflow()}
          onExecute={openExecuteDialog}
          onReload={() => void loadWorkflow()}
          onUndo={undo}
          onRedo={redo}
          canUndo={canUndo}
          canRedo={canRedo}
          busy={busy}
          loading={loading}
          lastRunId={runOverlay ? Object.values(runOverlay)[0]?.workflow_run_id ?? null : null}
          runStatus={runOverlay ? inferRunStatus(runOverlay) : null}
          isDraft={isDraft}
          saveName={saveName}
          onSaveNameChange={setSaveName}
        />
        <WorkflowInspectorPanel
          nodeId={firstSelectedId}
          nodeSpec={firstSelectedId ? nodes[firstSelectedId] ?? null : null}
          onUpdateConfig={(config) =>
            firstSelectedId && updateNodeConfig(firstSelectedId, config)
          }
          onRemoveNode={() => firstSelectedId && removeNode(firstSelectedId)}
          onClose={() => setSelectedNodeIds([])}
          runStep={firstSelectedId && runOverlay ? runOverlay[firstSelectedId] ?? null : null}
        />

        {/* Vertical split: canvas + companion panel */}
        {bottomPanelOpen ? (
          <ResGroup id="wf-editor-vertical" orientation="vertical" style={{ flex: "1 1 0%", minHeight: 0 }}>
            <ResPanel id="wf-editor-main" defaultSize={75} minSize={15}>
              {canvasContent}
            </ResPanel>
            <ResSep className="shrink-0 bg-border hover:bg-primary/50 transition-colors cursor-row-resize" style={{ height: 6 }} />
            <ResPanel id="wf-editor-companion" defaultSize={25} minSize={10}>
              <div className="h-full overflow-hidden">
                <WorkflowCompanionPanel />
              </div>
            </ResPanel>
          </ResGroup>
        ) : (
          canvasContent
        )}

        {paletteOpen && (
          <CommandPalette
            onClose={() => setPaletteOpen(false)}
            onSave={() => void saveWorkflow()}
            onExecute={openExecuteDialog}
            onFitView={() => setFitViewTrigger((n) => n + 1)}
          />
        )}
        {inputDialogOpen && (
          <ExecuteInputDialog
            spec={spec}
            busy={busy}
            onExecute={(inputJson) => void executeWorkflow(inputJson)}
            onClose={() => setInputDialogOpen(false)}
          />
        )}
        {error && (
          <div className="absolute bottom-3 left-3 right-3 z-10">
            <ErrorDisplay error={error} />
          </div>
        )}
      </div>
    </ResizableWorkspaceLayout>
  );
}

function bumpPatch(version: string): string {
  const parts = version.split(".");
  if (parts.length === 3) {
    const patch = parseInt(parts[2], 10);
    if (!isNaN(patch)) return `${parts[0]}.${parts[1]}.${patch + 1}`;
  }
  return version;
}

function inferRunStatus(
  overlay: Record<string, { status: string }>,
): string | null {
  const statuses = Object.values(overlay).map((s) => s.status);
  if (statuses.length === 0) return null;
  if (statuses.some((s) => s === "failed")) return "failed";
  if (statuses.some((s) => s === "running")) return "running";
  if (statuses.every((s) => s === "completed" || s === "success")) {
    return "completed";
  }
  return "running";
}
