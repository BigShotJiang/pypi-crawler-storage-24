import { Suspense } from "react";

import WorkflowsPageInner from "./WorkflowsPageInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function WorkflowsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading..." />}>
      <WorkflowsPageInner />
    </Suspense>
  );
}
