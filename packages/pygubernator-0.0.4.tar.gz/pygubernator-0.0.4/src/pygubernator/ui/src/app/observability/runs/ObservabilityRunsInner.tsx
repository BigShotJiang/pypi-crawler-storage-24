"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { RefreshCw } from "lucide-react";

import { ObservabilityTabs } from "@/components/observability/ObservabilityTabs";
import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { apiGet } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { cn } from "@/lib/utils";

interface RunItem {
  id: string;
  agent_id: string;
  status: string;
  duration_ms: number | null;
  token_input: number;
  token_output: number;
  cost_usd_micros: number;
  error_message: string | null;
  created_at: string;
}

interface RunsResponse {
  items: RunItem[];
  meta: { total: number; page: number; page_size: number };
  facets: { statuses: Array<{ status: string; count: number }> };
}

export default function ObservabilityRunsInner() {
  const searchParams = useSearchParams();
  const status = searchParams.get("status") ?? undefined;
  const has_error = searchParams.get("has_error");
  const activeWindow = searchParams.get("window") ?? "24h";

  const hasError = has_error === "true" ? true : has_error === "false" ? false : undefined;

  const [data, setData] = useState<RunsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiGet<RunsResponse>("/api/v1/runs", {
        status,
        has_error: hasError,
        sort_by: "created_at",
        sort_order: "desc",
        page_size: 50
      });
      setData(res);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [status, hasError]);

  useEffect(() => {
    load();
  }, [load]);

  function hrefWith(patch?: { status?: string | null; has_error?: string | null }) {
    const q = new URLSearchParams();
    q.set("window", activeWindow);
    const st = patch && "status" in patch ? patch.status : status;
    const he = patch && "has_error" in patch ? patch.has_error : has_error;
    if (st) q.set("status", st);
    if (he === "true" || he === "false") q.set("has_error", he);
    return `${ROUTES.OBS_RUNS}?${q.toString()}`;
  }

  if (loading && !data) {
    return (
      <PageContainer>
        <PageLoading message="Loading runs…" />
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Runs explorer"
        description="Filter runs by status and errors"
        actions={
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        }
      />
      <ObservabilityTabs />
      {error && <ErrorDisplay error={error} className="mb-4" />}
      {data && (
        <>
          <div className="flex flex-wrap gap-2 mb-4">
            <Link
              href={hrefWith({ status: null, has_error: null })}
              className={cn(
                buttonVariants({ variant: status || has_error ? "outline" : "default", size: "sm" }),
                "h-8"
              )}
            >
              All
            </Link>
            {data.facets.statuses.map((entry) => (
              <Link
                key={entry.status}
                href={hrefWith({ status: entry.status, has_error: null })}
                className={cn(
                  buttonVariants({ variant: status === entry.status ? "default" : "outline", size: "sm" }),
                  "h-8"
                )}
              >
                {entry.status} ({entry.count})
              </Link>
            ))}
            <Link
              href={hrefWith({ status: null, has_error: "true" })}
              className={cn(
                buttonVariants({ variant: has_error === "true" ? "destructive" : "outline", size: "sm" }),
                "h-8"
              )}
            >
              Error only
            </Link>
          </div>

          <p className="text-sm text-muted-foreground mb-4">
            Showing {data.items.length} of {data.meta.total} runs.
          </p>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Run</TableHead>
                <TableHead>Agent</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Latency</TableHead>
                <TableHead>Tokens</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead>Error</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.items.map((run) => (
                <TableRow key={run.id}>
                  <TableCell>
                    <Link
                      href={`${ROUTES.RUNS}?id=${encodeURIComponent(run.id)}`}
                      className="font-mono text-xs text-primary hover:underline"
                    >
                      {run.id.slice(0, 8)}…
                    </Link>
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {run.agent_id.slice(0, 8)}…
                  </TableCell>
                  <TableCell>{run.status}</TableCell>
                  <TableCell>{run.duration_ms ?? "—"}</TableCell>
                  <TableCell>
                    {run.token_input}/{run.token_output}
                  </TableCell>
                  <TableCell>{run.cost_usd_micros}</TableCell>
                  <TableCell className="max-w-[200px] truncate text-xs text-muted-foreground">
                    {run.error_message ?? "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </>
      )}
    </PageContainer>
  );
}
