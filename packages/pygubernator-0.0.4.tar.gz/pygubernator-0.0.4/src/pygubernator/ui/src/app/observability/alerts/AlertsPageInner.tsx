"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { RefreshCw } from "lucide-react";

import { AlertRulesManager } from "@/components/observability/AlertRulesManager";
import { ObservabilityTabs } from "@/components/observability/ObservabilityTabs";
import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading } from "@/components/LoadingSpinner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiGet } from "@/lib/api";
import { ROUTES } from "@/lib/constants";

interface AlertRule {
  id: string;
  name: string;
  severity: string;
  enabled: boolean;
  firing: boolean;
  open_incidents: number;
}

interface AlertHistoryItem {
  id: string;
  alert_id: string;
  title: string;
  severity: string;
  status: string;
  owner: string | null;
  created_at: string;
  resolved_at: string | null;
}

export default function AlertsPageInner() {
  const searchParams = useSearchParams();
  const windowParam = searchParams.get("window") ?? "24h";
  const alert_id = searchParams.get("alert_id") ?? undefined;

  const [alerts, setAlerts] = useState<{ items: AlertRule[] } | null>(null);
  const [history, setHistory] = useState<{ items: AlertHistoryItem[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [a, h] = await Promise.all([
        apiGet<{ items: AlertRule[] }>("/api/v1/policies/alerts"),
        apiGet<{ items: AlertHistoryItem[] }>("/api/v1/policies/alerts/history", {
          limit: 50,
          alert_id: alert_id
        })
      ]);
      setAlerts(a);
      setHistory(h);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [alert_id]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading && !alerts) {
    return (
      <PageContainer>
        <PageLoading message="Loading alerts…" />
      </PageContainer>
    );
  }

  const clearHref = `${ROUTES.OBS_ALERTS}?window=${encodeURIComponent(windowParam)}`;

  return (
    <PageContainer>
      <PageHeader
        title="Alerts"
        description="Alert rules and recent alert history"
        actions={
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        }
      />
      <ObservabilityTabs />
      {error && <ErrorDisplay error={error} className="mb-4" />}

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Alert rules</CardTitle>
        </CardHeader>
        <CardContent>
          {alerts && <AlertRulesManager rules={alerts.items} onInvalidate={load} />}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg">Alert history</CardTitle>
          {alert_id ? (
            <Link href={clearHref} className="text-xs text-primary hover:underline">
              Clear filter
            </Link>
          ) : null}
        </CardHeader>
        <CardContent>
          {history && history.items.length === 0 ? (
            <p className="text-sm text-muted-foreground">No alert history found.</p>
          ) : (
            <ul className="space-y-3 text-sm">
              {history?.items.map((item) => (
                <li key={item.id} className="rounded-lg border border-border p-3">
                  <p className="font-medium">
                    <Link
                      href={`${ROUTES.OBS_ALERTS}?window=${encodeURIComponent(windowParam)}&alert_id=${encodeURIComponent(item.alert_id)}`}
                      className="text-primary hover:underline"
                    >
                      {item.title}
                    </Link>
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {item.severity} | {item.status} | owner: {item.owner ?? "unassigned"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    created {new Date(item.created_at).toLocaleString()}
                    {item.resolved_at ? ` | resolved ${new Date(item.resolved_at).toLocaleString()}` : ""}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </PageContainer>
  );
}
