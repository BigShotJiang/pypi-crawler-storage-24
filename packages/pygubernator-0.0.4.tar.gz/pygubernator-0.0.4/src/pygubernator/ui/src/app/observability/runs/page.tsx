import { Suspense } from "react";

import ObservabilityRunsInner from "./ObservabilityRunsInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function ObservabilityRunsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <ObservabilityRunsInner />
    </Suspense>
  );
}
