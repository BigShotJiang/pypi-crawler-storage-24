"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { RefreshCw } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Pagination } from "@/components/common/Pagination";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading, TableSkeleton } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import WorkflowRunDag from "@/components/workflows/WorkflowRunDag";
import StepDetailPanel from "@/components/workflows/StepDetailPanel";
import { usePolling } from "@/hooks/usePolling";
import { apiGet } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { cn, formatDateTimeShort } from "@/lib/utils";

interface WorkflowRunItem {
  id: string;
  workflow_id: string;
  workflow_version_id: string | null;
  status: string;
  input_json: Record<string, unknown>;
  output_json: Record<string, unknown>;
  error_message: string | null;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
  created_by: string;
}

interface StepItem {
  id: string;
  workflow_run_id: string;
  node_id: string;
  node_type: string;
  status: string;
  input_json: Record<string, unknown>;
  output_json: Record<string, unknown>;
  error_message: string | null;
  output_handle: string;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
}

export default function WorkflowRunInner() {
  const searchParams = useSearchParams();
  const runId = searchParams.get("run_id");
  const workflowId = searchParams.get("workflow_id");

  const [page, setPage] = useState(1);
  const [list, setList] = useState<{ items: WorkflowRunItem[]; meta: { total: number; page: number; page_size: number } } | null>(null);
  const [detail, setDetail] = useState<{ run: WorkflowRunItem; steps: StepItem[] } | null>(null);
  const [selectedStep, setSelectedStep] = useState<StepItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const loadList = useCallback(async (p: number = page) => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ items: WorkflowRunItem[]; meta: { total: number; page: number; page_size: number } }>(
        "/api/v1/workflows/runs/list",
        { page: p, page_size: 25, workflow_id: workflowId ?? undefined }
      );
      setList(data);
      setDetail(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [workflowId, page]);

  const loadDetail = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ run: WorkflowRunItem; steps: StepItem[] }>(
        `/api/v1/workflows/runs/${id}`
      );
      setDetail(data);
      setList(null);
      setSelectedStep(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (runId) loadDetail(runId);
    else loadList(page);
  }, [runId, loadDetail, loadList, page]);

  const refresh = () => { if (runId) loadDetail(runId); else loadList(page); };

  const isRunActive = detail?.run.status === "pending" || detail?.run.status === "running";
  const { lastUpdated } = usePolling(
    () => (runId ? loadDetail(runId) : loadList(page)),
    runId ? 5000 : 10000,
    runId ? isRunActive : !runId
  );

  const handlePageChange = (p: number) => {
    setPage(p);
    loadList(p);
  };

  if (loading && !list && !detail) {
    return <PageContainer><PageLoading message="Loading workflow runs..." /></PageContainer>;
  }

  if (runId && detail) {
    const { run, steps } = detail;
    const statusColor: Record<string, string> = {
      completed: "text-green-600",
      failed: "text-red-600",
      running: "text-yellow-600",
      pending: "text-muted-foreground",
    };

    return (
      <PageContainer>
        <PageHeader
          title={`Run ${run.id.slice(0, 8)}...`}
          description={`Status: ${run.status} · Duration: ${run.duration_ms ?? "—"}ms`}
          actions={
            <>
              <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
                <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
              </Button>
              <Link
                href={`${ROUTES.WORKFLOW_RUNS}?workflow_id=${run.workflow_id}`}
                className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}
              >
                Back to runs
              </Link>
            </>
          }
        />
        {error && <ErrorDisplay error={error} className="mb-4" />}
        {lastUpdated && (
          <p className="text-xs text-muted-foreground mb-2">
            Last updated {lastUpdated.toLocaleTimeString()}
          </p>
        )}

        <div className="grid gap-4 lg:grid-cols-[1fr_350px]">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Step timeline</CardTitle>
                <CardDescription>{steps.length} step(s)</CardDescription>
              </CardHeader>
              <CardContent>
                <WorkflowRunDag steps={steps} selectedStep={selectedStep?.node_id ?? null} onSelectStep={(nodeId) => {
                  const step = steps.find((s) => s.node_id === nodeId) ?? null;
                  setSelectedStep(step);
                }} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-lg">Steps</CardTitle></CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Node</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Handle</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {steps.map((step) => (
                      <TableRow
                        key={step.id}
                        className={cn("cursor-pointer", selectedStep?.id === step.id && "bg-muted/50")}
                        onClick={() => setSelectedStep(step)}
                      >
                        <TableCell className="font-medium">{step.node_id}</TableCell>
                        <TableCell className="text-muted-foreground">{step.node_type}</TableCell>
                        <TableCell className={statusColor[step.status] ?? ""}>{step.status}</TableCell>
                        <TableCell className="text-muted-foreground">{step.duration_ms != null ? `${step.duration_ms}ms` : "—"}</TableCell>
                        <TableCell className="text-muted-foreground">{step.output_handle}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {run.error_message && (
              <Card>
                <CardHeader><CardTitle className="text-lg text-red-600">Error</CardTitle></CardHeader>
                <CardContent><pre className="text-sm whitespace-pre-wrap text-red-600">{run.error_message}</pre></CardContent>
              </Card>
            )}
          </div>

          <StepDetailPanel step={selectedStep} />
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Workflow Runs"
        description={list ? `${list.meta.total} run(s)` : "Workflow execution history"}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
            </Button>
            <Link href={ROUTES.WORKFLOWS} className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}>
              Workflows
            </Link>
          </>
        }
      />
      {error && <ErrorDisplay error={error} className="mb-4" />}
      {lastUpdated && (
        <p className="text-xs text-muted-foreground mb-2">
          Last updated {lastUpdated.toLocaleTimeString()}
        </p>
      )}

      {loading && list ? <TableSkeleton rows={6} /> : null}
      {!loading && list && (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Run ID</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Created by</TableHead>
                <TableHead>Started</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {list.items.map((run) => (
                <TableRow key={run.id}>
                  <TableCell>
                    <Link
                      href={`${ROUTES.WORKFLOW_RUNS}?run_id=${encodeURIComponent(run.id)}`}
                      className="font-medium text-primary hover:underline font-mono text-sm"
                    >
                      {run.id.slice(0, 12)}...
                    </Link>
                  </TableCell>
                  <TableCell>{run.status}</TableCell>
                  <TableCell className="text-muted-foreground">{run.duration_ms != null ? `${run.duration_ms}ms` : "—"}</TableCell>
                  <TableCell className="text-muted-foreground">{run.created_by}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{run.started_at ? formatDateTimeShort(run.started_at) : "—"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Pagination
            page={list.meta.page ?? page}
            pageSize={list.meta.page_size ?? 25}
            total={list.meta.total}
            onPageChange={handlePageChange}
          />
        </>
      )}
    </PageContainer>
  );
}
