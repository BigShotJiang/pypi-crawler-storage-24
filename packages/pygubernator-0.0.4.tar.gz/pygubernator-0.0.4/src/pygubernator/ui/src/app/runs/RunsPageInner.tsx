"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { RefreshCw } from "lucide-react";

import { RunActions } from "@/components/observability/RunActions";
import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Pagination } from "@/components/common/Pagination";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading, TableSkeleton } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import { usePolling } from "@/hooks/usePolling";
import { apiGet } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { formatDateTimeShort } from "@/lib/utils";

interface RunItem {
  id: string;
  agent_id: string;
  status: string;
  duration_ms: number | null;
  token_input: number;
  token_output: number;
  cost_usd_micros: number;
  error_message: string | null;
  created_at?: string;
}

export default function RunsPageInner() {
  const searchParams = useSearchParams();
  const id = searchParams.get("id");
  const agentIdFilter = searchParams.get("agent_id");

  const [page, setPage] = useState(1);
  const [list, setList] = useState<{ items: RunItem[]; meta: { total: number; page: number; page_size: number } } | null>(null);
  const [runDetail, setRunDetail] = useState<{
    run: RunItem & { correlation_id: string | null };
    trace: {
      tool_calls: Array<{ id: string; tool_name: string; status: string; latency_ms: number | null }>;
      events: Array<{ id: string; event_type: string; level: string; message: string | null }>;
    };
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const loadList = useCallback(async (p: number = page) => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ items: RunItem[]; meta: { total: number; page: number; page_size: number } }>("/api/v1/runs", {
        page: p,
        page_size: 25,
        agent_id: agentIdFilter ?? undefined
      });
      setList(data);
      setRunDetail(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [agentIdFilter, page]);

  const loadDetail = useCallback(async (runId: string) => {
    setLoading(true);
    setError(null);
    try {
      const [run, trace] = await Promise.all([
        apiGet<RunItem & { correlation_id: string | null }>(`/api/v1/runs/${runId}`),
        apiGet<{
          tool_calls: Array<{ id: string; tool_name: string; status: string; latency_ms: number | null }>;
          events: Array<{ id: string; event_type: string; level: string; message: string | null }>;
        }>(`/api/v1/observability/traces/${runId}`)
      ]);
      setRunDetail({ run, trace });
      setList(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (id) loadDetail(id);
    else loadList(page);
  }, [id, agentIdFilter, loadDetail, loadList, page]);

  const refresh = () => {
    if (id) loadDetail(id);
    else loadList(page);
  };

  const { lastUpdated } = usePolling(
    () => (id ? loadDetail(id) : loadList(page)),
    30000,
    !id
  );

  const handlePageChange = (p: number) => {
    setPage(p);
    loadList(p);
  };

  if (loading && !list && !runDetail) {
    return <PageContainer><PageLoading message="Loading runs..." /></PageContainer>;
  }

  if (id && runDetail) {
    const { run, trace } = runDetail;
    return (
      <PageContainer>
        <PageHeader
          title={`Run ${run.id.slice(0, 8)}...`}
          description={`Status ${run.status} · correlation ${run.correlation_id ?? "—"} · latency ${run.duration_ms ?? "—"} ms`}
          actions={
            <>
              <Button variant="outline" size="sm" onClick={refresh}>
                <RefreshCw className="h-4 w-4 mr-1" /> Refresh
              </Button>
              <Link href={ROUTES.RUNS} className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}>
                Back to list
              </Link>
            </>
          }
        />
        {error && <ErrorDisplay error={error} className="mb-4" />}
        <div className="grid gap-3 md:grid-cols-2 text-sm mb-4">
          <Card>
            <CardHeader className="py-3">
              <CardTitle className="text-base">Tokens & cost</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              <p>In / out: {run.token_input} / {run.token_output}</p>
              <p>Cost (uUSD): {run.cost_usd_micros}</p>
            </CardContent>
          </Card>
        </div>
        {run.error_message ? (
          <p className="text-sm text-destructive mb-4">Error: {run.error_message}</p>
        ) : null}
        <RunActions runId={run.id} status={run.status} onDone={refresh} />
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-lg">Tool calls</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm space-y-2">
              {trace.tool_calls.map((t) => (
                <li key={t.id}>
                  {t.tool_name} — {t.status} ({t.latency_ms ?? "—"} ms)
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-lg">Events</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm space-y-2">
              {trace.events.map((e) => (
                <li key={e.id}>
                  [{e.level}] {e.event_type}
                  {e.message ? ` — ${e.message}` : ""}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <div className="mt-4 text-sm text-muted-foreground">
          <Link href={ROUTES.WORKFLOW_RUNS} className="text-primary hover:underline">
            View workflow runs
          </Link>
          {" for DAG-based execution history with step timelines."}
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Runs"
        description={
          list
            ? `${list.meta.total} run(s)${agentIdFilter ? ` · filtered to agent ${agentIdFilter.slice(0, 8)}...` : ""}`
            : "Execution history"
        }
        actions={
          <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        }
      />
      {error && <ErrorDisplay error={error} className="mb-4" />}
      {lastUpdated && (
        <p className="text-xs text-muted-foreground mb-2">
          Last updated {lastUpdated.toLocaleTimeString()}
        </p>
      )}
      {loading && list ? <TableSkeleton rows={6} /> : null}
      {!loading && list && (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Run</TableHead>
                <TableHead>Agent</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Latency (ms)</TableHead>
                <TableHead>Tokens</TableHead>
                <TableHead>Cost (uUSD)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {list.items.map((run) => (
                <TableRow key={run.id}>
                  <TableCell>
                    <Link
                      href={`${ROUTES.RUNS}?id=${encodeURIComponent(run.id)}`}
                      className="font-mono text-xs text-primary hover:underline"
                    >
                      {run.id.slice(0, 8)}...
                    </Link>
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {run.agent_id.slice(0, 8)}...
                  </TableCell>
                  <TableCell>{run.status}</TableCell>
                  <TableCell>{run.duration_ms ?? "—"}</TableCell>
                  <TableCell>{run.token_input}/{run.token_output}</TableCell>
                  <TableCell>{run.cost_usd_micros}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Pagination
            page={list.meta.page ?? page}
            pageSize={list.meta.page_size ?? 25}
            total={list.meta.total}
            onPageChange={handlePageChange}
          />
        </>
      )}
    </PageContainer>
  );
}
