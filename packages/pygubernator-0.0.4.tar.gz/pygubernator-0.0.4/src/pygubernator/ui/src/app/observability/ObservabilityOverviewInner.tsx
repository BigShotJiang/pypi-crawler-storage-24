"use client";

import { useCallback, useEffect, useState } from "react";
import { RefreshCw } from "lucide-react";

import { ObservabilityTabs } from "@/components/observability/ObservabilityTabs";
import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading } from "@/components/LoadingSpinner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiGet } from "@/lib/api";

export default function ObservabilityOverviewInner() {
  const [metrics, setMetrics] = useState<{
    totals: {
      runs: number;
      succeeded: number;
      failed: number;
      avg_latency_ms: number;
      token_input: number;
      token_output: number;
      cost_usd_micros: number;
    };
  } | null>(null);
  const [alerts, setAlerts] = useState<{
    items: Array<{ id: string; name: string; severity: string; enabled: boolean }>;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [m, a] = await Promise.all([
        apiGet<{
          totals: {
            runs: number;
            succeeded: number;
            failed: number;
            avg_latency_ms: number;
            token_input: number;
            token_output: number;
            cost_usd_micros: number;
          };
        }>("/api/v1/observability/metrics"),
        apiGet<{ items: Array<{ id: string; name: string; severity: string; enabled: boolean }> }>(
          "/api/v1/policies/alerts"
        )
      ]);
      setMetrics(m);
      setAlerts(a);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading && !metrics) {
    return (
      <PageContainer>
        <PageLoading message="Loading observability…" />
      </PageContainer>
    );
  }

  const t = metrics?.totals;

  return (
    <PageContainer>
      <PageHeader
        title="Observability"
        description="Aggregate metrics and alert rules"
        actions={
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        }
      />
      <ObservabilityTabs />
      {error && <ErrorDisplay error={error} className="mb-4" />}
      {t && (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 mb-6">
          <MetricCard label="Runs" value={t.runs} />
          <MetricCard label="Succeeded" value={t.succeeded} />
          <MetricCard label="Failed" value={t.failed} />
          <MetricCard label="Avg latency (ms)" value={t.avg_latency_ms} />
          <MetricCard label="Input tokens" value={t.token_input} />
          <MetricCard label="Output tokens" value={t.token_output} />
          <MetricCard label="Cost (µUSD)" value={t.cost_usd_micros} />
        </div>
      )}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Alert rules</CardTitle>
        </CardHeader>
        <CardContent>
          {alerts && alerts.items.length === 0 ? (
            <p className="text-sm text-muted-foreground">No alert rules configured.</p>
          ) : (
            <ul className="text-sm space-y-2">
              {alerts?.items.map((a) => (
                <li key={a.id}>
                  {a.name}{" "}
                  <span className="text-muted-foreground">
                    ({a.severity}) — {a.enabled ? "enabled" : "disabled"}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </PageContainer>
  );
}

function MetricCard({ label, value }: { label: string; value: number }) {
  return (
    <Card>
      <CardHeader className="py-3 pb-0">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
      </CardHeader>
      <CardContent className="pt-2">
        <p className="text-2xl font-semibold tabular-nums">{value}</p>
      </CardContent>
    </Card>
  );
}
