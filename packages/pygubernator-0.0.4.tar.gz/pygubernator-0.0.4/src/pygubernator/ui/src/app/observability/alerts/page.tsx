import { Suspense } from "react";

import AlertsPageInner from "./AlertsPageInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function AlertsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <AlertsPageInner />
    </Suspense>
  );
}
