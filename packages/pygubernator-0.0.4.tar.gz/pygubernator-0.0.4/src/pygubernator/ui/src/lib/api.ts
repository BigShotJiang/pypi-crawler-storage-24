import { getApiBaseUrl } from "@/lib/settings";

const TOKEN = process.env.NEXT_PUBLIC_PYGUBERNATOR_TOKEN ?? "dev-token";

function headers(): HeadersInit {
  return {
    "X-API-Token": TOKEN,
    "X-Actor": "ui",
    "X-Role": "admin",
    "Content-Type": "application/json"
  };
}

/** Build absolute or same-origin URL for API calls. */
export function apiUrl(path: string, query?: Record<string, string | number | boolean | undefined | null>): string {
  const base = getApiBaseUrl();
  const p = path.startsWith("/") ? path : `/${path}`;
  if (!query || Object.keys(query).length === 0) {
    return `${base}${p}`;
  }
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) {
    if (v === undefined || v === null || v === "") continue;
    q.set(k, String(v));
  }
  const s = q.toString();
  return s ? `${base}${p}?${s}` : `${base}${p}`;
}

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public body?: string
  ) {
    super(message);
    this.name = "ApiError";
  }
}

async function parseJsonOrText(res: Response): Promise<unknown> {
  const ct = res.headers.get("content-type") ?? "";
  if (ct.includes("application/json")) {
    try {
      return await res.json();
    } catch {
      return null;
    }
  }
  return await res.text();
}

function extractErrorMessage(data: unknown, status: number): string {
  if (typeof data === "object" && data !== null && "detail" in data) {
    return String((data as { detail: unknown }).detail);
  }
  return `API ${status}`;
}

async function _request<T>(
  method: string,
  url: string,
  body?: unknown
): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: headers(),
      body: body !== undefined ? JSON.stringify(body) : undefined,
      cache: "no-store"
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Failed to fetch";
    if (msg.includes("Failed to fetch") || msg.includes("NetworkError")) {
      throw new ApiError(
        `Unable to connect to API at ${getApiBaseUrl() || "(same origin)"}`,
        0
      );
    }
    throw e;
  }
  const data = await parseJsonOrText(res);
  if (!res.ok) {
    throw new ApiError(
      extractErrorMessage(data, res.status),
      res.status,
      String(data)
    );
  }
  return data as T;
}

export async function apiGet<T>(
  path: string,
  query?: Record<string, string | number | boolean | undefined | null>
): Promise<T> {
  return _request<T>("GET", apiUrl(path, query));
}

export async function apiPost<TReq extends object, TRes>(
  path: string,
  body?: TReq
): Promise<TRes> {
  return _request<TRes>("POST", apiUrl(path), body);
}

export async function apiPatch<TReq extends object, TRes>(
  path: string,
  body: TReq
): Promise<TRes> {
  return _request<TRes>("PATCH", apiUrl(path), body);
}

export async function apiDelete<T>(
  path: string
): Promise<T> {
  return _request<T>("DELETE", apiUrl(path));
}
