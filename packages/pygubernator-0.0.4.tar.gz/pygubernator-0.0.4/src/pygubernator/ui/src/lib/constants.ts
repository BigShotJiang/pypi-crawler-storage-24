/** Default app name (overridden by injected config / API). */
export const APP_NAME = "PyGubernator";

/** localStorage key for theme (inline script in layout reads this). */
export const THEME_STORAGE_KEY = "pygubernator-theme";

export const NAMED_THEME_IDS = [
  "ocean",
  "forest",
  "sunset",
  "high-contrast",
  "sepia",
  "violet",
  "cathay"
] as const;
export type NamedThemeId = (typeof NAMED_THEME_IDS)[number];

export const API_CONNECTION_ERROR_MESSAGE =
  "API server not connected. Start it with: pygubernator api";

export const ROUTES = {
  HOME: "/",
  AGENTS: "/agents/",
  RUNS: "/runs/",
  OBSERVABILITY: "/observability/",
  OBS_INCIDENTS: "/observability/incidents/",
  OBS_RUNS: "/observability/runs/",
  OBS_ALERTS: "/observability/alerts/",
  WORKFLOWS: "/workflows/",
  WORKFLOW_EDITOR: "/workflows/editor/",
  WORKFLOW_RUNS: "/workflows/runs/",
  SETTINGS: "/settings/"
} as const;
