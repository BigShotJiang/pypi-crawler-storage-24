/**
 * API base URL resolution (mirrors pycharter / pystator).
 * In dev, when NEXT_PUBLIC_PYGUBERNATOR_API_URL is set, Next rewrites `/api/*` to the API
 * so the browser can use same-origin `''` and avoid CORS.
 */
const DEFAULT_API =
  typeof process !== "undefined" && process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL
    ? process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL
    : "http://127.0.0.1:8010";

export function getApiBaseUrl(): string {
  if (
    typeof window !== "undefined" &&
    process.env.NODE_ENV === "development" &&
    process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL
  ) {
    return "";
  }
  return DEFAULT_API.replace(/\/$/, "");
}
