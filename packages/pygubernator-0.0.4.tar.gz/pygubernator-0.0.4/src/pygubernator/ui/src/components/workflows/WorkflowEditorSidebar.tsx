"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowRightLeft,
  Brain,
  ChevronDown,
  ChevronRight,
  Database,
  FolderOpen,
  GitBranch,
  LayoutGrid,
  MessageSquare,
  Plus,
  RefreshCw,
  Wrench,
} from "lucide-react";
import { SidebarHeaderWithToggle } from "@/components/layout/SidebarHeaderWithToggle";
import type { SidebarLayoutApi } from "@/components/layout/ResizableWorkspaceLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiGet, apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { cn, formatDateTimeShort } from "@/lib/utils";

/* ---------- Node type definition ---------- */

interface NodeTypeItem {
  type: string;
  label: string;
  description: string;
  color: string;
}

/* ---------- Categorized node palette data ---------- */

interface NodeCategory {
  id: string;
  label: string;
  icon: typeof ArrowRightLeft;
  defaultOpen: boolean;
  nodes: NodeTypeItem[];
}

const NODE_CATEGORIES: NodeCategory[] = [
  {
    id: "io",
    label: "I/O",
    icon: ArrowRightLeft,
    defaultOpen: true,
    nodes: [
      { type: "input",  label: "Input",  description: "Workflow entry point", color: "#60a5fa" },
      { type: "output", label: "Output", description: "Workflow exit point",  color: "#4ade80" },
    ],
  },
  {
    id: "logic",
    label: "Logic & Control",
    icon: GitBranch,
    defaultOpen: true,
    nodes: [
      { type: "condition", label: "Condition", description: "Boolean branching",  color: "#facc15" },
      { type: "router",    label: "Router",    description: "Multi-way routing",  color: "#f472b6" },
      { type: "loop",      label: "Loop",      description: "Iterate over items", color: "#22d3ee" },
      { type: "map",       label: "Map",       description: "Parallel map",       color: "#2dd4bf" },
    ],
  },
  {
    id: "processing",
    label: "Processing",
    icon: Wrench,
    defaultOpen: true,
    nodes: [
      { type: "template", label: "Template", description: "String templating", color: "#c084fc" },
      { type: "code",     label: "Code",     description: "Python expression", color: "#fb923c" },
      { type: "http",     label: "HTTP",     description: "HTTP request",      color: "#f87171" },
    ],
  },
  {
    id: "ai",
    label: "AI & LLM",
    icon: Brain,
    defaultOpen: true,
    nodes: [
      { type: "llm",   label: "LLM",   description: "LLM call",             color: "#818cf8" },
      { type: "agent", label: "Agent", description: "Python package agent", color: "#e879f9" },
    ],
  },
  {
    id: "chat_models",
    label: "Chat Models",
    icon: MessageSquare,
    defaultOpen: false,
    nodes: [
      { type: "chat_model_openai",        label: "OpenAI",        description: "ChatGPT models",           color: "#10a37f" },
      { type: "chat_model_anthropic",     label: "Anthropic",     description: "Claude models",            color: "#d97706" },
      { type: "chat_model_gemini",        label: "Gemini",        description: "Google Gemini models",     color: "#4285f4" },
      { type: "chat_model_ollama",        label: "Ollama",        description: "Local/self-hosted models", color: "#808080" },
      { type: "chat_model_deepseek",      label: "Deepseek",      description: "Deepseek models",          color: "#1a73e8" },
      { type: "chat_model_glm",          label: "GLM",           description: "GLM / ChatGLM models",     color: "#ff6b35" },
      { type: "chat_model_openai_compat", label: "OpenAI-Compat", description: "Any OpenAI-compatible API", color: "#6b7280" },
    ],
  },
  {
    id: "agent_utils",
    label: "Memory & Tools",
    icon: Database,
    defaultOpen: false,
    nodes: [
      { type: "memory", label: "Memory", description: "Agent memory store",    color: "#f59e0b" },
      { type: "tool",   label: "Tool",   description: "Agent tool capability", color: "#34d399" },
    ],
  },
];

/** Flat list of all node types for search filtering */
const ALL_NODES: NodeTypeItem[] = NODE_CATEGORIES.flatMap((cat) => cat.nodes);

/* ---------- Tab definitions ---------- */

type SidebarTab = "components" | "browser";

const SIDEBAR_TABS: Array<{ id: SidebarTab; label: string; icon: typeof LayoutGrid }> = [
  { id: "components", label: "Components", icon: LayoutGrid },
  { id: "browser", label: "Browser", icon: FolderOpen },
];

/* ---------- Types ---------- */

interface WorkflowBrowserItem {
  id: string;
  name: string;
  owner: string;
  status: string;
  created_at: string;
}

interface WorkflowEditorSidebarProps extends SidebarLayoutApi {
  onAddNode: (type: string) => void;
}

/* ---------- Component ---------- */

export default function WorkflowEditorSidebar({
  isPanelCollapsed,
  sidebarDisplayMode,
  onCollapseRequested,
  onExpandRequested,
  onAddNode,
}: WorkflowEditorSidebarProps) {
  const [tab, setTab] = useState<SidebarTab>("components");

  const isExpanded = sidebarDisplayMode === "expanded";
  const isCompact = sidebarDisplayMode === "compact";
  const isCollapsed = sidebarDisplayMode === "collapsed";

  return (
    <div className="flex flex-col h-full">
      <SidebarHeaderWithToggle
        isCollapsed={isPanelCollapsed}
        displayMode={sidebarDisplayMode}
        onToggle={isPanelCollapsed ? onExpandRequested : onCollapseRequested}
      >
        {/* Tab toggle — matching pycharter/pystator pattern */}
        <div className="flex rounded-lg border border-border/70 bg-background/50 p-0.5" role="tablist" aria-label="Sidebar mode">
          {SIDEBAR_TABS.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-label={item.label}
                title={item.label}
                aria-selected={active}
                onClick={() => setTab(item.id)}
                className={cn(
                  "inline-flex h-7 shrink-0 items-center rounded-md transition-colors text-xs font-medium",
                  isCompact ? "justify-center px-2 w-7" : "gap-1.5 px-2.5",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {!isCompact && <span>{item.label}</span>}
              </button>
            );
          })}
        </div>
      </SidebarHeaderWithToggle>

      {tab === "components" ? (
        <ComponentsTab
          isExpanded={isExpanded}
          isCompact={isCompact}
          isCollapsed={isCollapsed}
          onAddNode={onAddNode}
        />
      ) : (
        <BrowserTab
          isExpanded={isExpanded}
          isCollapsed={isCollapsed}
        />
      )}
    </div>
  );
}

/* ---------- Node row (shared between categories and flat search results) ---------- */

function NodeRow({
  node,
  isExpanded,
  isCollapsed,
  onAddNode,
  onDragStart,
}: {
  node: NodeTypeItem;
  isExpanded: boolean;
  isCollapsed: boolean;
  onAddNode: (type: string) => void;
  onDragStart: (e: React.DragEvent, type: string) => void;
}) {
  return (
    <div
      draggable={!isCollapsed}
      onDragStart={(e) => onDragStart(e, node.type)}
      onClick={() => onAddNode(node.type)}
      className={cn(
        "group flex items-center gap-2 rounded-md border",
        "cursor-grab active:cursor-grabbing transition-colors select-none",
        "border-border/40 bg-background/70 hover:border-border hover:bg-muted/35",
        isCollapsed ? "justify-center px-1 py-2" : "px-2.5 py-1.5",
      )}
      title={isCollapsed ? node.label : undefined}
    >
      <div
        className="w-3 h-3 rounded-full shrink-0"
        style={{ backgroundColor: node.color }}
      />
      {!isCollapsed && (
        <div className="min-w-0">
          <div className="text-[13px] font-semibold leading-tight">{node.label}</div>
          {isExpanded && (
            <div className="text-[11px] text-muted-foreground/90 leading-tight">
              {node.description}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ---------- Collapsible category group ---------- */

function CategoryGroup({
  category,
  isExpanded,
  isCompact,
  isCollapsed,
  onAddNode,
  onDragStart,
}: {
  category: NodeCategory;
  isExpanded: boolean;
  isCompact: boolean;
  isCollapsed: boolean;
  onAddNode: (type: string) => void;
  onDragStart: (e: React.DragEvent, type: string) => void;
}) {
  const [open, setOpen] = useState(category.defaultOpen);
  const Icon = category.icon;

  if (isCollapsed) {
    // In collapsed mode, show just colored dots
    return (
      <div className="space-y-0.5">
        {category.nodes.map((node) => (
          <NodeRow
            key={node.type}
            node={node}
            isExpanded={false}
            isCollapsed
            onAddNode={onAddNode}
            onDragStart={onDragStart}
          />
        ))}
      </div>
    );
  }

  return (
    <div
      className={cn(
        "rounded-md border transition-colors",
        open
          ? "border-border/70 bg-muted/20"
          : "border-border/40 bg-transparent",
      )}
    >
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={cn(
          "flex items-center gap-1.5 w-full text-left rounded-md px-2.5 py-2 transition-colors",
          "hover:bg-muted/50",
          open ? "text-foreground" : "text-muted-foreground hover:text-foreground",
        )}
      >
        {open ? (
          <ChevronDown className="h-3 w-3 shrink-0" />
        ) : (
          <ChevronRight className="h-3 w-3 shrink-0" />
        )}
        <Icon className="h-3.5 w-3.5 shrink-0" />
        <span className="text-xs font-semibold uppercase tracking-wide">
          {isCompact ? category.label.split(" ")[0] : category.label}
        </span>
        <span className="ml-auto inline-flex items-center rounded-sm border border-border/60 bg-background/80 px-1.5 py-0.5 text-[10px] text-muted-foreground tabular-nums">
          {category.nodes.length}
        </span>
      </button>

      {open && (
        <div className="ml-2 mb-1.5 mr-1.5 border-l-2 border-border/70 pl-2">
          <div className="space-y-0.5">
          {category.nodes.map((node) => (
            <NodeRow
              key={node.type}
              node={node}
              isExpanded={isExpanded}
              isCollapsed={false}
              onAddNode={onAddNode}
              onDragStart={onDragStart}
            />
          ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Components tab (categorized node palette) ---------- */

function ComponentsTab({
  isExpanded,
  isCompact,
  isCollapsed,
  onAddNode,
}: {
  isExpanded: boolean;
  isCompact: boolean;
  isCollapsed: boolean;
  onAddNode: (type: string) => void;
}) {
  const [search, setSearch] = useState("");

  const handleDragStart = (e: React.DragEvent, type: string) => {
    e.dataTransfer.setData("application/pygubernator-node-type", type);
    e.dataTransfer.effectAllowed = "move";
  };

  const isSearching = search.trim().length > 0;

  const filteredNodes = useMemo(() => {
    if (!isSearching) return [];
    const q = search.toLowerCase();
    return ALL_NODES.filter(
      (nt) =>
        nt.label.toLowerCase().includes(q) ||
        nt.description.toLowerCase().includes(q) ||
        nt.type.toLowerCase().includes(q),
    );
  }, [search, isSearching]);

  return (
    <>
      {!isCollapsed && (
        <div className="px-2 pb-1 pt-1">
          <input
            className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            placeholder="Search nodes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
        {isSearching ? (
          /* Flat search results */
          filteredNodes.length === 0 ? (
            <div className="text-xs text-muted-foreground text-center py-4">
              No matching nodes
            </div>
          ) : (
            <div className="space-y-0.5">
              {filteredNodes.map((node) => (
                <NodeRow
                  key={node.type}
                  node={node}
                  isExpanded={isExpanded}
                  isCollapsed={isCollapsed}
                  onAddNode={onAddNode}
                  onDragStart={handleDragStart}
                />
              ))}
            </div>
          )
        ) : (
          /* Categorized groups */
          <div className="space-y-1.5">
            {NODE_CATEGORIES.map((cat) => (
            <CategoryGroup
              key={cat.id}
              category={cat}
              isExpanded={isExpanded}
              isCompact={isCompact}
              isCollapsed={isCollapsed}
              onAddNode={onAddNode}
              onDragStart={handleDragStart}
            />
            ))}
          </div>
        )}
      </div>

      {!isCollapsed && (
        <div className="px-3 py-2 border-t border-border/50">
          <p className="text-[11px] text-muted-foreground">
            {isCompact ? "Click or drag" : "Drag onto canvas or click to add"}
          </p>
        </div>
      )}
    </>
  );
}

/* ---------- Browser tab (workflow list + create) ---------- */

function BrowserTab({
  isExpanded,
  isCollapsed,
}: {
  isExpanded: boolean;
  isCollapsed: boolean;
}) {
  const router = useRouter();
  const [workflows, setWorkflows] = useState<WorkflowBrowserItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [newName, setNewName] = useState("");
  const [creating, setCreating] = useState(false);

  const loadWorkflows = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiGet<{
        items: WorkflowBrowserItem[];
      }>("/api/v1/workflows", { page_size: 100 });
      setWorkflows(data.items.filter((w) => w.status !== "deleted"));
    } catch {
      // Silently handle errors
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadWorkflows();
  }, [loadWorkflows]);

  const createWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = newName.trim();
    if (!name) return;
    setCreating(true);
    try {
      const wf = await apiPost<
        { name: string; owner: string },
        WorkflowBrowserItem
      >("/api/v1/workflows", { name, owner: "system" });
      setNewName("");
      router.push(`${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(wf.id)}`);
    } catch {
      // Silently handle errors
    } finally {
      setCreating(false);
    }
  };

  const filtered = useMemo(() => {
    if (!search.trim()) return workflows;
    const q = search.toLowerCase();
    return workflows.filter(
      (w) => w.name.toLowerCase().includes(q) || w.owner.toLowerCase().includes(q),
    );
  }, [search, workflows]);

  if (isCollapsed) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <FolderOpen className="h-4 w-4 text-muted-foreground" />
      </div>
    );
  }

  return (
    <>
      {/* Search */}
      <div className="px-2 pb-1 pt-1">
        <input
          className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          placeholder="Search workflows..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Create new */}
      <div className="px-2 pb-2">
        <form className="flex gap-1" onSubmit={(e) => void createWorkflow(e)}>
          <Input
            className="h-8 text-xs flex-1"
            placeholder="New workflow name..."
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
          />
          <Button
            type="submit"
            variant="outline"
            size="sm"
            className="h-8 px-2 shrink-0"
            disabled={creating || !newName.trim()}
          >
            <Plus className="h-3.5 w-3.5" />
          </Button>
        </form>
      </div>

      {/* Workflow list */}
      <div className="flex-1 overflow-y-auto px-2 space-y-0.5">
        {loading && (
          <div className="text-xs text-muted-foreground text-center py-4">
            Loading...
          </div>
        )}
        {!loading && filtered.length === 0 && (
          <div className="text-xs text-muted-foreground text-center py-4">
            {workflows.length === 0 ? "No workflows yet" : "No matches"}
          </div>
        )}
        {filtered.map((wf) => (
          <button
            key={wf.id}
            type="button"
            onClick={() =>
              router.push(`${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(wf.id)}`)
            }
            className="flex flex-col w-full text-left rounded-lg border border-transparent px-3 py-2 hover:border-border hover:bg-muted/50 transition-colors"
          >
            <div className="text-sm font-medium leading-tight truncate">{wf.name}</div>
            {isExpanded && (
              <div className="text-[11px] text-muted-foreground leading-tight mt-0.5">
                {wf.owner} · {formatDateTimeShort(wf.created_at)}
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Footer */}
      <div className="px-2 py-2 border-t border-border/50 flex items-center justify-between">
        <p className="text-[11px] text-muted-foreground">
          {workflows.length} workflow{workflows.length !== 1 ? "s" : ""}
        </p>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-1.5"
          onClick={() => void loadWorkflows()}
          disabled={loading}
        >
          <RefreshCw className={cn("h-3 w-3", loading && "animate-spin")} />
        </Button>
      </div>
    </>
  );
}
