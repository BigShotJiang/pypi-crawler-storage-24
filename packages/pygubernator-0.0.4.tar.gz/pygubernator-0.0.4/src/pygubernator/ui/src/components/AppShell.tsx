"use client";

import ApiUnavailableBanner from "@/components/ApiUnavailableBanner";
import Navigation from "@/components/Navigation";

export default function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <ApiUnavailableBanner />
      <main
        className="flex-1"
        style={{ minHeight: 0, overflow: "auto", position: "relative" }}
      >
        {children}
      </main>
    </div>
  );
}
