"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

import { StatusBadge } from "@/components/observability/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";

interface IncidentItem {
  id: string;
  title: string;
  status: string;
  severity: string;
  owner: string | null;
  acknowledged_at: string | null;
  silenced_until: string | null;
  resolved_at: string | null;
  created_at: string;
}

export function IncidentsTable({
  incidents,
  activeWindow,
  onInvalidate
}: {
  incidents: IncidentItem[];
  activeWindow: string;
  onInvalidate?: () => void;
}) {
  const [busyId, setBusyId] = useState<string | null>(null);
  const [ownerInput, setOwnerInput] = useState<Record<string, string>>({});

  const sorted = useMemo(
    () =>
      [...incidents].sort((a, b) => {
        if (a.status === "resolved" && b.status !== "resolved") return 1;
        if (a.status !== "resolved" && b.status === "resolved") return -1;
        return Date.parse(b.created_at) - Date.parse(a.created_at);
      }),
    [incidents]
  );

  async function executeAction(id: string, path: string, payload?: Record<string, string>) {
    setBusyId(id);
    try {
      await apiPost(path, payload ?? {});
      onInvalidate?.();
    } finally {
      setBusyId(null);
    }
  }

  if (sorted.length === 0) {
    return (
      <p className="rounded-md border border-dashed border-border bg-muted/30 p-6 text-center text-sm text-muted-foreground">
        No incidents found.
      </p>
    );
  }

  return (
    <div className="space-y-3">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Title</TableHead>
            <TableHead>Severity</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Owner</TableHead>
            <TableHead>Created</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sorted.map((item) => {
            const isBusy = busyId === item.id;
            const q = new URLSearchParams({ window: activeWindow });
            return (
              <TableRow key={item.id}>
                <TableCell>
                  <Link
                    href={`${ROUTES.OBS_INCIDENTS}?${q.toString()}&id=${encodeURIComponent(item.id)}`}
                    className="font-medium text-primary hover:underline"
                  >
                    {item.title}
                  </Link>
                </TableCell>
                <TableCell>{item.severity}</TableCell>
                <TableCell>
                  <StatusBadge label={item.status} />
                </TableCell>
                <TableCell className="text-muted-foreground">{item.owner ?? "unassigned"}</TableCell>
                <TableCell className="text-muted-foreground text-xs">
                  {new Date(item.created_at).toLocaleString()}
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap items-center justify-end gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      disabled={isBusy || item.status === "acknowledged" || item.status === "resolved"}
                      onClick={() =>
                        executeAction(item.id, `/api/v1/observability/incidents/${item.id}/ack`)
                      }
                    >
                      Ack
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      disabled={isBusy || item.status === "resolved"}
                      onClick={() =>
                        executeAction(item.id, `/api/v1/observability/incidents/${item.id}/silence`, {
                          until: new Date(Date.now() + 60 * 60 * 1000).toISOString()
                        })
                      }
                    >
                      Silence 1h
                    </Button>
                    <Button
                      type="button"
                      variant="default"
                      size="sm"
                      disabled={isBusy || item.status === "resolved"}
                      onClick={() =>
                        executeAction(item.id, `/api/v1/observability/incidents/${item.id}/resolve`)
                      }
                    >
                      Resolve
                    </Button>
                    <Input
                      value={ownerInput[item.id] ?? ""}
                      onChange={(event) =>
                        setOwnerInput((prev) => ({ ...prev, [item.id]: event.target.value }))
                      }
                      placeholder="Owner"
                      className="h-8 w-24 text-xs"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={isBusy || !(ownerInput[item.id] ?? "").trim()}
                      onClick={() =>
                        executeAction(item.id, `/api/v1/observability/incidents/${item.id}/assign`, {
                          owner: (ownerInput[item.id] ?? "").trim()
                        })
                      }
                    >
                      Assign
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>

      <p className="text-xs text-muted-foreground">Window context: {activeWindow}</p>
    </div>
  );
}
