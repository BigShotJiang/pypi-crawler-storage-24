"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for input nodes: comma-separated keys. */
export function InputNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const keys = Array.isArray(config.keys) ? (config.keys as string[]).join(", ") : "";

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Input Keys</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="key1, key2, key3"
          value={keys}
          onChange={(e) => {
            const parsed = e.target.value
              .split(",")
              .map((s) => s.trim())
              .filter(Boolean);
            onChange({ ...config, keys: parsed });
          }}
        />
        <p className="text-[11px] text-muted-foreground">Comma-separated list of input variable names</p>
      </div>
    </div>
  );
}
