"use client";

import {
  type NodeProps,
  Handle,
  Position,
} from "@xyflow/react";
import { cn } from "@/lib/utils";

/* ---------- Colour map ---------- */

export const TYPE_COLORS: Record<string, { bg: string; border: string; text: string }> = {
  input:     { bg: "#dbeafe", border: "#60a5fa", text: "#1e40af" },
  output:    { bg: "#dcfce7", border: "#4ade80", text: "#166534" },
  template:  { bg: "#f3e8ff", border: "#c084fc", text: "#6b21a8" },
  condition: { bg: "#fef9c3", border: "#facc15", text: "#854d0e" },
  code:      { bg: "#ffedd5", border: "#fb923c", text: "#9a3412" },
  router:    { bg: "#fce7f3", border: "#f472b6", text: "#9d174d" },
  loop:      { bg: "#cffafe", border: "#22d3ee", text: "#155e75" },
  map:       { bg: "#ccfbf1", border: "#2dd4bf", text: "#115e59" },
  http:      { bg: "#fee2e2", border: "#f87171", text: "#991b1b" },
  llm:                 { bg: "#e0e7ff", border: "#818cf8", text: "#3730a3" },
  agent:               { bg: "#fdf2f8", border: "#e879f9", text: "#86198f" },
  chat_model_openai:   { bg: "#d1fae5", border: "#10a37f", text: "#065f46" },
  chat_model_anthropic:{ bg: "#fef3c7", border: "#d97706", text: "#92400e" },
  chat_model_gemini:   { bg: "#dbeafe", border: "#4285f4", text: "#1e40af" },
  chat_model_ollama:   { bg: "#f1f5f9", border: "#808080", text: "#334155" },
  chat_model_deepseek: { bg: "#dbeafe", border: "#1a73e8", text: "#1e3a5f" },
  chat_model_glm:      { bg: "#fff4e6", border: "#ff6b35", text: "#8b3e1a" },
  chat_model_openai_compat: { bg: "#f3f4f6", border: "#6b7280", text: "#374151" },
  memory:              { bg: "#fef3c7", border: "#f59e0b", text: "#92400e" },
  tool:                { bg: "#d1fae5", border: "#34d399", text: "#065f46" },
};

export const DEFAULT_COLOR = { bg: "#f1f5f9", border: "#94a3b8", text: "#334155" };

const STATUS_BADGE: Record<string, { icon: string; color: string; glow: string }> = {
  completed: { icon: "\u2713", color: "#16a34a", glow: "rgba(22,163,74,0.3)" },
  success:   { icon: "\u2713", color: "#16a34a", glow: "rgba(22,163,74,0.3)" },
  failed:    { icon: "\u2717", color: "#dc2626", glow: "rgba(220,38,38,0.3)" },
  running:   { icon: "\u25CB", color: "#ca8a04", glow: "rgba(202,138,4,0.3)" },
  pending:   { icon: "\u25CB", color: "#9ca3af", glow: "rgba(156,163,175,0.2)" },
  skipped:   { icon: "\u2014", color: "#9ca3af", glow: "rgba(156,163,175,0.2)" },
};

/* ---------- Custom node component ---------- */

export function WorkflowNode({ data, selected }: NodeProps) {
  const nodeData = data as {
    label: string;
    nodeType: string;
    runStatus?: string;
    runDuration?: number | null;
  };
  const color = TYPE_COLORS[nodeData.nodeType] ?? DEFAULT_COLOR;
  const badge = nodeData.runStatus ? STATUS_BADGE[nodeData.runStatus] ?? null : null;
  const isSubNode = nodeData.nodeType.startsWith("chat_model_") || nodeData.nodeType === "memory" || nodeData.nodeType === "tool";
  const isLlm = nodeData.nodeType === "llm" || nodeData.nodeType === "agent";
  const hasLeftInput = isLlm || nodeData.nodeType === "input" || nodeData.nodeType === "output";

  const SUB_PORTS = [
    { id: "sub:chat_model", label: "Model", left: "20%", color: "#a78bfa" },
    { id: "sub:memory",     label: "Memory", left: "50%", color: "#f59e0b" },
    { id: "sub:tool",       label: "Tool", left: "80%", color: "#34d399" },
  ];

  return (
    <div
      className={cn(
        "relative px-4 rounded-xl border-2 shadow-sm min-w-[160px] transition-shadow",
        isLlm ? "pt-3 pb-7" : "py-3",
        selected && "shadow-lg ring-2 ring-blue-500",
      )}
      style={{
        backgroundColor: color.bg,
        borderColor: badge ? badge.color : color.border,
        boxShadow: badge ? `0 0 8px ${badge.glow}` : undefined,
      }}
    >
      {/* Input handles — sub-nodes get source at top, LLM/Agent get target on left, others get target at top */}
      {isSubNode ? (
        <Handle type="source" position={Position.Top} className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white" />
      ) : (
        <Handle
          type="target"
          position={hasLeftInput ? Position.Left : Position.Top}
          className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white"
          style={hasLeftInput ? { top: "50%" } : undefined}
        />
      )}
      {/* Bottom handles */}
      {isSubNode ? null : nodeData.nodeType === "condition" ? (
        <>
          <Handle
            type="source"
            position={Position.Bottom}
            id="true"
            className="!w-3 !h-3 !bg-green-500 !border-2 !border-white"
            style={{ left: "30%" }}
          />
          <Handle
            type="source"
            position={Position.Bottom}
            id="false"
            className="!w-3 !h-3 !bg-red-400 !border-2 !border-white"
            style={{ left: "70%" }}
          />
        </>
      ) : (
        <Handle
          type="source"
          position={Position.Right}
          className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white"
          style={hasLeftInput ? { top: "50%" } : undefined}
        />
      )}
      {/* LLM/Agent sub-node target ports at bottom */}
      {isLlm && SUB_PORTS.map((port) => (
        <div key={port.id}>
          <Handle
            type="target"
            position={Position.Bottom}
            id={port.id}
            className="!w-3 !h-3 !border-2 !border-white"
            style={{ left: port.left, backgroundColor: port.color }}
          />
          <div
            className="absolute text-[8px] font-medium pointer-events-none"
            style={{ left: port.left, bottom: 2, transform: "translateX(-50%)", color: port.color }}
          >
            {port.label}
          </div>
        </div>
      ))}
      {badge && (
        <div
          className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
          style={{ backgroundColor: badge.color }}
        >
          {badge.icon}
        </div>
      )}
      <div className="text-[10px] uppercase tracking-widest font-semibold mb-0.5" style={{ color: color.border }}>
        {nodeData.nodeType === "chat_model_openai" ? "OpenAI"
          : nodeData.nodeType === "chat_model_anthropic" ? "Anthropic"
          : nodeData.nodeType === "chat_model_gemini" ? "Gemini"
          : nodeData.nodeType === "chat_model_ollama" ? "Ollama"
          : nodeData.nodeType === "chat_model_deepseek" ? "Deepseek"
          : nodeData.nodeType === "chat_model_glm" ? "GLM"
          : nodeData.nodeType === "chat_model_openai_compat" ? "OpenAI-Compat"
          : nodeData.nodeType}
      </div>
      <div className="text-sm font-medium truncate max-w-[180px]" style={{ color: color.text }}>
        {nodeData.label}
      </div>
      {badge && nodeData.runDuration != null && (
        <div className="text-[10px] text-muted-foreground mt-0.5">
          {nodeData.runDuration}ms
        </div>
      )}
    </div>
  );
}
