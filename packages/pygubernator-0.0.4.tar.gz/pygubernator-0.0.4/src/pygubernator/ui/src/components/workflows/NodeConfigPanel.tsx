"use client";

import { useEffect, useState } from "react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import type { SpecNode } from "@/lib/types/workflow";
import { configFormRegistry, type TypedNodeConfigFormProps } from "@/components/workflows/config-forms";

interface NodeConfigFormProps {
  nodeId: string;
  nodeSpec: SpecNode;
  onUpdateConfig: (config: Record<string, unknown>) => void;
  onRemoveNode: () => void;
}

/** Reusable form content: typed config form + JSON Advanced tab. */
export function NodeConfigForm({ nodeId, nodeSpec, onUpdateConfig, onRemoveNode }: NodeConfigFormProps) {
  const [tab, setTab] = useState<"config" | "advanced">("config");
  const [configText, setConfigText] = useState("{}");

  useEffect(() => {
    setConfigText(JSON.stringify(nodeSpec.config ?? {}, null, 2));
  }, [nodeSpec, nodeId]);

  const TypedForm = configFormRegistry[nodeSpec.type] as
    | React.ComponentType<TypedNodeConfigFormProps>
    | undefined;

  const applyConfig = () => {
    try {
      const parsed = JSON.parse(configText);
      onUpdateConfig(parsed);
    } catch {
      // keep current text, user can fix
    }
  };

  const handleTabSwitch = (next: "config" | "advanced") => {
    if (next === "advanced") {
      setConfigText(JSON.stringify(nodeSpec.config ?? {}, null, 2));
    } else if (next === "config" && tab === "advanced") {
      // Attempt to apply advanced JSON before switching back
      try {
        const parsed = JSON.parse(configText);
        onUpdateConfig(parsed);
      } catch {
        // keep as-is
      }
    }
    setTab(next);
  };

  return (
    <div className="space-y-3">
      {/* Tab buttons — only show if typed form exists */}
      {TypedForm && (
        <div className="flex gap-1 border-b pb-1">
          <button
            className={`text-xs px-2 py-1 rounded-t transition-colors ${
              tab === "config" ? "bg-muted font-medium" : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => handleTabSwitch("config")}
          >
            Config
          </button>
          <button
            className={`text-xs px-2 py-1 rounded-t transition-colors ${
              tab === "advanced" ? "bg-muted font-medium" : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => handleTabSwitch("advanced")}
          >
            Advanced
          </button>
        </div>
      )}

      {/* Typed form tab */}
      {TypedForm && tab === "config" ? (
        <TypedForm config={nodeSpec.config ?? {}} onChange={onUpdateConfig} />
      ) : (
        /* Advanced / fallback JSON tab */
        <div className="flex flex-col gap-1">
          <label className="text-sm text-muted-foreground">Configuration (JSON)</label>
          <textarea
            className="flex min-h-[200px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background font-mono placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            value={configText}
            onChange={(e) => setConfigText(e.target.value)}
          />
          <Button size="sm" onClick={applyConfig}>Apply</Button>
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <Button size="sm" variant="destructive" onClick={onRemoveNode}>
          <Trash2 className="h-4 w-4 mr-1" /> Remove
        </Button>
      </div>
    </div>
  );
}

interface NodeConfigPanelProps {
  nodeId: string | null;
  nodeSpec: SpecNode | null;
  onUpdateConfig: (config: Record<string, unknown>) => void;
  onRemoveNode: () => void;
}

export default function NodeConfigPanel({ nodeId, nodeSpec, onUpdateConfig, onRemoveNode }: NodeConfigPanelProps) {
  if (!nodeId || !nodeSpec) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Node config</CardTitle>
          <CardDescription>Select a node to configure</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Click a node on the canvas to view and edit its configuration.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{nodeId}</CardTitle>
        <CardDescription>Type: {nodeSpec.type}</CardDescription>
      </CardHeader>
      <CardContent>
        <NodeConfigForm
          nodeId={nodeId}
          nodeSpec={nodeSpec}
          onUpdateConfig={onUpdateConfig}
          onRemoveNode={onRemoveNode}
        />
      </CardContent>
    </Card>
  );
}
