"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for code nodes: Python code textarea. */
export function CodeNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const code = typeof config.code === "string" ? config.code : "";
  const outputKey = typeof config.output_key === "string" ? config.output_key : "";

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Code</label>
        <textarea
          className="flex min-h-[200px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono leading-relaxed"
          placeholder="result = ctx['value'] * 2"
          value={code}
          onChange={(e) => onChange({ ...config, code: e.target.value })}
        />
        <p className="text-[11px] text-muted-foreground">Python expression or statement block</p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Output Key</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="result"
          value={outputKey}
          onChange={(e) => onChange({ ...config, output_key: e.target.value })}
        />
      </div>
    </div>
  );
}
