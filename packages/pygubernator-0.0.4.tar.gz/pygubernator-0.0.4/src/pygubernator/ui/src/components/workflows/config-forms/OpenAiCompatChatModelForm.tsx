"use client";

import type { TypedNodeConfigFormProps } from "./index";

/* ---------- Provider presets ---------- */

interface ProviderPreset {
  label: string;
  baseUrl: string;
  requiresKey: boolean;
  models: string[];
  placeholder: string;
}

const PRESETS: Record<string, ProviderPreset> = {
  groq: {
    label: "Groq (free)",
    baseUrl: "https://api.groq.com/openai/v1",
    requiresKey: true,
    models: [
      "llama-3.3-70b-versatile",
      "llama-3.1-8b-instant",
      "mixtral-8x7b-32768",
      "gemma2-9b-it",
    ],
    placeholder: "gsk_...",
  },
  together: {
    label: "Together AI",
    baseUrl: "https://api.together.xyz/v1",
    requiresKey: true,
    models: [
      "meta-llama/Llama-3.1-8B-Instruct-Turbo",
      "meta-llama/Llama-3.1-70B-Instruct-Turbo",
      "mistralai/Mixtral-8x7B-Instruct-v0.1",
      "Qwen/Qwen2.5-72B-Instruct-Turbo",
    ],
    placeholder: "sk-...",
  },
  sambanova: {
    label: "SambaNova (free)",
    baseUrl: "https://api.sambanova.ai/v1",
    requiresKey: true,
    models: [
      "Meta-Llama-3.1-8B-Instruct",
      "Meta-Llama-3.1-70B-Instruct",
      "Meta-Llama-3.1-405B-Instruct",
    ],
    placeholder: "API key...",
  },
  openrouter: {
    label: "OpenRouter",
    baseUrl: "https://openrouter.ai/api/v1",
    requiresKey: true,
    models: [
      "meta-llama/llama-3.1-8b-instruct:free",
      "mistralai/mistral-7b-instruct:free",
      "google/gemma-2-9b-it:free",
      "qwen/qwen-2.5-72b-instruct",
    ],
    placeholder: "sk-or-...",
  },
  ollama: {
    label: "Ollama (local)",
    baseUrl: "http://localhost:11434/v1",
    requiresKey: false,
    models: [],
    placeholder: "",
  },
  vllm: {
    label: "vLLM (local)",
    baseUrl: "http://localhost:8000/v1",
    requiresKey: false,
    models: [],
    placeholder: "",
  },
  lmstudio: {
    label: "LM Studio (local)",
    baseUrl: "http://localhost:1234/v1",
    requiresKey: false,
    models: [],
    placeholder: "",
  },
  custom: {
    label: "Custom endpoint",
    baseUrl: "",
    requiresKey: false,
    models: [],
    placeholder: "",
  },
};

/** Detect which preset matches the current base URL. */
function detectPreset(baseUrl: string): string {
  if (!baseUrl) return "";
  for (const [key, preset] of Object.entries(PRESETS)) {
    if (key !== "custom" && preset.baseUrl && baseUrl.startsWith(preset.baseUrl.replace(/\/v1$/, ""))) {
      return key;
    }
  }
  return "custom";
}

/* ---------- Component ---------- */

/** Config form for generic OpenAI-compatible Chat Model sub-nodes. */
export function OpenAiCompatChatModelForm({ config, onChange }: TypedNodeConfigFormProps) {
  const baseUrl = typeof config.base_url === "string" ? config.base_url : "";
  const apiKey = typeof config.api_key === "string" ? config.api_key : "";
  const modelName = typeof config.model_name === "string" ? config.model_name : "";
  const temperature = typeof config.temperature === "number" ? config.temperature : 0.7;
  const maxTokens = typeof config.max_tokens === "number" ? config.max_tokens : "";

  const selectedPreset = detectPreset(baseUrl);
  const preset = selectedPreset ? PRESETS[selectedPreset] : null;
  const hasModels = preset && preset.models.length > 0;
  const showKeyField = !preset || preset.requiresKey || selectedPreset === "custom";

  const handlePresetChange = (key: string) => {
    const p = PRESETS[key];
    if (!p) return;
    onChange({
      ...config,
      base_url: p.baseUrl,
      model_name: p.models[0] ?? "",
      api_key: undefined,
    });
  };

  return (
    <div className="space-y-3">
      {/* Provider preset selector */}
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Provider</label>
        <select
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={selectedPreset}
          onChange={(e) => handlePresetChange(e.target.value)}
        >
          <option value="">Select a provider...</option>
          <optgroup label="Cloud (API key required)">
            <option value="groq">{PRESETS.groq.label}</option>
            <option value="together">{PRESETS.together.label}</option>
            <option value="sambanova">{PRESETS.sambanova.label}</option>
            <option value="openrouter">{PRESETS.openrouter.label}</option>
          </optgroup>
          <optgroup label="Local (no API key)">
            <option value="ollama">{PRESETS.ollama.label}</option>
            <option value="vllm">{PRESETS.vllm.label}</option>
            <option value="lmstudio">{PRESETS.lmstudio.label}</option>
          </optgroup>
          <optgroup label="Other">
            <option value="custom">{PRESETS.custom.label}</option>
          </optgroup>
        </select>
      </div>

      {/* API Key — shown for cloud providers and custom */}
      {showKeyField && (
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium">API Key</label>
            {preset && (
              <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${
                preset.requiresKey
                  ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400"
                  : "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
              }`}>
                {preset.requiresKey ? "Required" : "Optional"}
              </span>
            )}
          </div>
          <input
            type="password"
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder={preset?.placeholder || "API key..."}
            value={apiKey}
            onChange={(e) => onChange({ ...config, api_key: e.target.value || undefined })}
          />
        </div>
      )}

      {/* Model — dropdown for presets with known models, free text otherwise */}
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Model</label>
        {hasModels ? (
          <>
            <select
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
              value={preset.models.includes(modelName) ? modelName : "__custom__"}
              onChange={(e) => {
                if (e.target.value !== "__custom__") {
                  onChange({ ...config, model_name: e.target.value });
                }
              }}
            >
              {preset.models.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
              {modelName && !preset.models.includes(modelName) && (
                <option value="__custom__">{modelName} (custom)</option>
              )}
            </select>
            <input
              className="flex h-8 w-full rounded-md border border-input bg-background px-3 py-1 text-xs text-muted-foreground"
              placeholder="Or type a custom model ID..."
              value={preset.models.includes(modelName) ? "" : modelName}
              onChange={(e) => onChange({ ...config, model_name: e.target.value })}
            />
          </>
        ) : (
          <>
            <input
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
              placeholder="llama3.1, mistral, qwen2.5..."
              value={modelName}
              onChange={(e) => onChange({ ...config, model_name: e.target.value })}
            />
            {preset && !preset.requiresKey && (
              <p className="text-[11px] text-muted-foreground">
                Enter any model available on your server.
              </p>
            )}
          </>
        )}
      </div>

      {/* Base URL — shown but de-emphasized (auto-filled by preset) */}
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium text-muted-foreground">Base URL</label>
        <input
          className="flex h-8 w-full rounded-md border border-input bg-muted/30 px-3 py-1 text-xs text-muted-foreground"
          placeholder="http://localhost:8000/v1"
          value={baseUrl}
          onChange={(e) => onChange({ ...config, base_url: e.target.value })}
        />
        <p className="text-[10px] text-muted-foreground">
          Auto-filled from provider. Edit for custom setups.
        </p>
      </div>

      {/* Temperature */}
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Temperature</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          min={0}
          max={2}
          step={0.1}
          value={temperature}
          onChange={(e) => onChange({ ...config, temperature: parseFloat(e.target.value) || 0 })}
        />
      </div>

      {/* Max Tokens */}
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Max Tokens</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="Optional"
          value={maxTokens}
          onChange={(e) => {
            const v = e.target.value;
            onChange({ ...config, max_tokens: v ? parseInt(v, 10) : undefined });
          }}
        />
      </div>
    </div>
  );
}
