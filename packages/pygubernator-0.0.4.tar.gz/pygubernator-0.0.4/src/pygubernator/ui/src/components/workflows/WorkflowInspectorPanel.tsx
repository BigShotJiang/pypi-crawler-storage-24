"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { NodeConfigForm } from "@/components/workflows/NodeConfigPanel";
import type { SpecNode, StepItem } from "@/lib/types/workflow";

interface WorkflowInspectorPanelProps {
  nodeId: string | null;
  nodeSpec: SpecNode | null;
  onUpdateConfig: (config: Record<string, unknown>) => void;
  onRemoveNode: () => void;
  onClose: () => void;
  runStep?: StepItem | null;
}

const MIN_WIDTH = 280;

const STATUS_COLORS: Record<string, string> = {
  completed: "text-green-600 bg-green-50",
  success: "text-green-600 bg-green-50",
  failed: "text-red-600 bg-red-50",
  running: "text-yellow-600 bg-yellow-50",
  pending: "text-gray-500 bg-gray-50",
  skipped: "text-gray-400 bg-gray-50",
};

export default function WorkflowInspectorPanel({
  nodeId,
  nodeSpec,
  onUpdateConfig,
  onRemoveNode,
  onClose,
  runStep,
}: WorkflowInspectorPanelProps) {
  const [width, setWidth] = useState(340);
  const dragRef = useRef<{ startX: number; startWidth: number } | null>(null);

  const onMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dragRef.current = { startX: e.clientX, startWidth: width };

      const onMouseMove = (ev: MouseEvent) => {
        if (!dragRef.current) return;
        const delta = dragRef.current.startX - ev.clientX;
        const next = Math.max(MIN_WIDTH, dragRef.current.startWidth + delta);
        setWidth(Math.min(next, window.innerWidth * 0.8));
      };

      const onMouseUp = () => {
        dragRef.current = null;
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      };

      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    },
    [width],
  );

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);

  if (!nodeId || !nodeSpec) return null;

  return (
    <div
      className="absolute top-0 right-0 bottom-0 z-20 flex bg-background border-l shadow-lg"
      style={{
        width,
        animation: "inspectorSlideIn 0.2s ease-out",
      }}
    >
      <div
        className="w-1.5 shrink-0 cursor-col-resize hover:bg-primary/50 active:bg-primary transition-colors"
        onMouseDown={onMouseDown}
      />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-muted/30 shrink-0">
          <div className="min-w-0">
            <div className="text-sm font-semibold truncate">{nodeId}</div>
            <div className="text-xs text-muted-foreground">Type: {nodeSpec.type}</div>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose} className="shrink-0 h-7 w-7 p-0">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <NodeConfigForm
            nodeId={nodeId}
            nodeSpec={nodeSpec}
            onUpdateConfig={onUpdateConfig}
            onRemoveNode={onRemoveNode}
          />

          {runStep && (
            <div className="space-y-2 border-t pt-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Last Run
              </h4>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-medium px-2 py-0.5 rounded ${STATUS_COLORS[runStep.status] ?? "text-gray-500 bg-gray-50"}`}>
                  {runStep.status}
                </span>
                {runStep.duration_ms != null && (
                  <span className="text-xs text-muted-foreground">{runStep.duration_ms}ms</span>
                )}
              </div>
              {runStep.error_message && (
                <div className="text-xs text-red-600 bg-red-50 rounded p-2 whitespace-pre-wrap">
                  {runStep.error_message}
                </div>
              )}
              {Object.keys(runStep.input_json ?? {}).length > 0 && (
                <details className="group">
                  <summary className="text-xs font-medium cursor-pointer text-muted-foreground">
                    Input
                  </summary>
                  <pre className="mt-1 text-[11px] bg-muted/50 rounded p-2 overflow-auto max-h-[160px]">
                    {JSON.stringify(runStep.input_json, null, 2)}
                  </pre>
                </details>
              )}
              {Object.keys(runStep.output_json ?? {}).length > 0 && (
                <details className="group">
                  <summary className="text-xs font-medium cursor-pointer text-muted-foreground">
                    Output
                  </summary>
                  <pre className="mt-1 text-[11px] bg-muted/50 rounded p-2 overflow-auto max-h-[160px]">
                    {JSON.stringify(runStep.output_json, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
