"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for loop nodes. */
export function LoopNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const collectionKey = typeof config.collection_key === "string" ? config.collection_key : "";
  const itemKey = typeof config.item_key === "string" ? config.item_key : "item";
  const indexKey = typeof config.index_key === "string" ? config.index_key : "index";
  const transform = typeof config.transform === "string" ? config.transform : "";
  const maxIterations = typeof config.max_iterations === "number" ? config.max_iterations : 100;

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Collection Key</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="items"
          value={collectionKey}
          onChange={(e) => onChange({ ...config, collection_key: e.target.value })}
        />
        <p className="text-[11px] text-muted-foreground">Context key containing the iterable</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Item Key</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            value={itemKey}
            onChange={(e) => onChange({ ...config, item_key: e.target.value })}
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Index Key</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            value={indexKey}
            onChange={(e) => onChange({ ...config, index_key: e.target.value })}
          />
        </div>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Transform</label>
        <textarea
          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
          placeholder="Optional transform expression"
          value={transform}
          onChange={(e) => onChange({ ...config, transform: e.target.value })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Max Iterations</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={maxIterations}
          min={1}
          onChange={(e) => onChange({ ...config, max_iterations: parseInt(e.target.value, 10) || 100 })}
        />
      </div>
    </div>
  );
}
