"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for condition nodes: condition expression. */
export function ConditionNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const condition = typeof config.condition === "string" ? config.condition : "";

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Condition</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
          placeholder="ctx.status == 'active'"
          value={condition}
          onChange={(e) => onChange({ ...config, condition: e.target.value })}
        />
        <p className="text-[11px] text-muted-foreground">
          Expression that evaluates to true/false. Routes to &quot;true&quot; or &quot;false&quot; handle.
        </p>
      </div>
    </div>
  );
}
