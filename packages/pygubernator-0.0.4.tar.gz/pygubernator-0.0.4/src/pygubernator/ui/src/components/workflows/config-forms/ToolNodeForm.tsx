"use client";

import type { TypedNodeConfigFormProps } from "./index";

const TOOL_MODULES = ["charter_tools", "catalyst_tools", "stator_tools"] as const;

/** Config form for Tool sub-nodes: tool module selection and optional name filter. */
export function ToolNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const toolModule = typeof config.tool_module === "string" ? config.tool_module : "charter_tools";
  const toolNames = typeof config.tool_names === "string" ? config.tool_names : "";

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Module</label>
        <select
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={toolModule}
          onChange={(e) => onChange({ ...config, tool_module: e.target.value })}
        >
          {TOOL_MODULES.map((m) => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Names</label>
        <textarea
          className="flex min-h-[60px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
          placeholder="search, calculate, fetch_data"
          value={toolNames}
          onChange={(e) => onChange({ ...config, tool_names: e.target.value })}
        />
        <p className="text-[11px] text-muted-foreground">
          Comma-separated list of tool names. Leave blank to include all tools in the module.
        </p>
      </div>
    </div>
  );
}
