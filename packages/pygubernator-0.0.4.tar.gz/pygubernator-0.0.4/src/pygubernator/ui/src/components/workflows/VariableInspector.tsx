"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface VariableInspectorProps {
  variables: Record<string, unknown>;
  input: Record<string, unknown>;
  output: Record<string, unknown>;
}

export default function VariableInspector({ variables, input, output }: VariableInspectorProps) {
  const hasData = Object.keys(variables).length > 0
    || Object.keys(input).length > 0
    || Object.keys(output).length > 0;

  if (!hasData) {
    return (
      <Card>
        <CardHeader><CardTitle className="text-lg">Variables</CardTitle></CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No variable data recorded for this run.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader><CardTitle className="text-lg">Variables</CardTitle></CardHeader>
      <CardContent className="space-y-4 text-sm">
        {Object.keys(input).length > 0 && (
          <div>
            <h4 className="font-medium text-muted-foreground mb-1">Input</h4>
            <pre className="text-xs bg-muted rounded-md p-2 overflow-auto max-h-40">
              {JSON.stringify(input, null, 2)}
            </pre>
          </div>
        )}
        {Object.keys(output).length > 0 && (
          <div>
            <h4 className="font-medium text-muted-foreground mb-1">Output</h4>
            <pre className="text-xs bg-muted rounded-md p-2 overflow-auto max-h-40">
              {JSON.stringify(output, null, 2)}
            </pre>
          </div>
        )}
        {Object.keys(variables).length > 0 && (
          <div>
            <h4 className="font-medium text-muted-foreground mb-1">Workflow variables</h4>
            <pre className="text-xs bg-muted rounded-md p-2 overflow-auto max-h-40">
              {JSON.stringify(variables, null, 2)}
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
