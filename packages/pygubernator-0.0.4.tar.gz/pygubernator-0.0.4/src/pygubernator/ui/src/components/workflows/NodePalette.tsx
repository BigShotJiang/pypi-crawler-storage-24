"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const NODE_TYPES = [
  { type: "input",     label: "Input",     description: "Workflow entry point",  color: "#60a5fa" },
  { type: "output",    label: "Output",    description: "Workflow exit point",   color: "#4ade80" },
  { type: "template",  label: "Template",  description: "String templating",     color: "#c084fc" },
  { type: "condition", label: "Condition", description: "Boolean branching",     color: "#facc15" },
  { type: "code",      label: "Code",      description: "Python expression",     color: "#fb923c" },
  { type: "router",    label: "Router",    description: "Multi-way routing",     color: "#f472b6" },
  { type: "loop",      label: "Loop",      description: "Iterate over items",    color: "#22d3ee" },
  { type: "map",       label: "Map",       description: "Parallel map",          color: "#2dd4bf" },
  { type: "http",      label: "HTTP",      description: "HTTP request",          color: "#f87171" },
  { type: "llm",       label: "LLM",       description: "LLM call",             color: "#818cf8" },
] as const;

interface NodePaletteProps {
  onAddNode: (type: string) => void;
}

export default function NodePalette({ onAddNode }: NodePaletteProps) {
  const handleDragStart = (e: React.DragEvent, type: string) => {
    e.dataTransfer.setData("application/pygubernator-node-type", type);
    e.dataTransfer.effectAllowed = "move";
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Nodes</CardTitle>
        <p className="text-xs text-muted-foreground">Drag onto canvas or click to add</p>
      </CardHeader>
      <CardContent className="space-y-1.5">
        {NODE_TYPES.map((nt) => (
          <div
            key={nt.type}
            draggable
            onDragStart={(e) => handleDragStart(e, nt.type)}
            onClick={() => onAddNode(nt.type)}
            className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg border border-transparent
                       hover:border-border hover:bg-muted/50 cursor-grab active:cursor-grabbing
                       transition-colors select-none"
          >
            <div
              className="w-3 h-3 rounded-full shrink-0"
              style={{ backgroundColor: nt.color }}
            />
            <div className="min-w-0">
              <div className="text-sm font-medium leading-tight">{nt.label}</div>
              <div className="text-[11px] text-muted-foreground leading-tight">{nt.description}</div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
