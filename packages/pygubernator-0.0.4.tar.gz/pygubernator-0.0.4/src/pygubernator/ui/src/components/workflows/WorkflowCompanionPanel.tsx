"use client";

import { useMemo } from "react";
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Info,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  useWorkflowEditorStore,
  selectSpec,
  selectRunOverlay,
} from "@/stores/workflow-editor";
import type { StepItem } from "@/lib/types/workflow";

type Severity = "error" | "warning" | "info";

interface Issue {
  id: string;
  nodeId: string;
  nodeName: string;
  severity: Severity;
  message: string;
  category: string;
}

const SEVERITY_ICON = {
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info,
} as const;

const SEVERITY_CLASS: Record<Severity, string> = {
  error: "text-destructive",
  warning: "text-amber-500",
  info: "text-muted-foreground",
};

/** Derive validation issues from spec + run overlay. */
function deriveIssues(
  nodes: Record<string, { type: string; config: Record<string, unknown> }>,
  overlay: Record<string, StepItem> | null,
): Issue[] {
  const issues: Issue[] = [];
  for (const [id, node] of Object.entries(nodes)) {
    // Check for failed run steps
    const step = overlay?.[id];
    if (step?.status === "failed" && step.error_message) {
      issues.push({
        id: `${id}-run-error`,
        nodeId: id,
        nodeName: id,
        severity: "error",
        message: step.error_message,
        category: "runtime",
      });
    }
    // Check for missing config on certain node types
    if (node.type === "llm" && !node.config.prompt_template) {
      issues.push({
        id: `${id}-no-prompt`,
        nodeId: id,
        nodeName: id,
        severity: "warning",
        message: "Missing prompt template",
        category: "config",
      });
    }
    if (node.type === "http" && !node.config.url) {
      issues.push({
        id: `${id}-no-url`,
        nodeId: id,
        nodeName: id,
        severity: "warning",
        message: "Missing URL",
        category: "config",
      });
    }
  }
  return issues;
}

/** Bottom companion panel showing validation and run issues. */
export function WorkflowCompanionPanel() {
  const spec = useWorkflowEditorStore(selectSpec);
  const overlay = useWorkflowEditorStore(selectRunOverlay);
  const setSelectedNodeIds = useWorkflowEditorStore((s) => s.setSelectedNodeIds);

  const issues = useMemo(
    () => deriveIssues(spec.nodes ?? {}, overlay),
    [spec.nodes, overlay],
  );

  const sorted = useMemo(
    () => [...issues].sort((a, b) => {
      const order: Record<Severity, number> = { error: 0, warning: 1, info: 2 };
      return order[a.severity] - order[b.severity];
    }),
    [issues],
  );

  const errorCount = issues.filter((i) => i.severity === "error").length;
  const warningCount = issues.filter((i) => i.severity === "warning").length;

  return (
    <div className="flex h-full flex-col bg-background border-t border-border">
      {/* Tab bar */}
      <div className="flex items-center gap-1 border-b border-border px-3 py-1.5">
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium bg-primary text-primary-foreground"
        >
          Validation
          {issues.length > 0 && (
            <span className="ml-1 rounded-full bg-primary-foreground/20 px-1.5 py-0.5 text-[10px] leading-none">
              {issues.length}
            </span>
          )}
        </button>
        <button
          type="button"
          disabled
          className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium text-muted-foreground/50 cursor-not-allowed"
        >
          Run Log
        </button>

        {/* Summary badges */}
        <div className="ml-auto flex items-center gap-2 text-xs text-muted-foreground">
          {errorCount > 0 && (
            <span className="flex items-center gap-1 text-destructive">
              <AlertCircle className="h-3 w-3" />
              {errorCount}
            </span>
          )}
          {warningCount > 0 && (
            <span className="flex items-center gap-1 text-amber-500">
              <AlertTriangle className="h-3 w-3" />
              {warningCount}
            </span>
          )}
        </div>
      </div>

      {/* Issue list */}
      <div className="flex-1 overflow-y-auto">
        {sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
            <CheckCircle2 className="h-8 w-8 text-emerald-500/60 mb-2" />
            <p className="text-sm font-medium">No issues found</p>
            <p className="text-xs text-muted-foreground/70 mt-1">
              All validation checks passed
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-border">
            {sorted.map((issue) => {
              const Icon = SEVERITY_ICON[issue.severity];
              return (
                <li key={issue.id}>
                  <button
                    type="button"
                    className="flex w-full items-start gap-2.5 px-3 py-2 text-left hover:bg-muted/50 transition-colors"
                    onClick={() => setSelectedNodeIds([issue.nodeId])}
                  >
                    <Icon
                      className={cn(
                        "h-4 w-4 mt-0.5 shrink-0",
                        SEVERITY_CLASS[issue.severity],
                      )}
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">
                        {issue.nodeName}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {issue.message}
                      </p>
                    </div>
                    <span className="ml-auto shrink-0 rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                      {issue.category}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
