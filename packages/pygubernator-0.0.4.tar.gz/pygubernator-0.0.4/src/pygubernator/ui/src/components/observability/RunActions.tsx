"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";

interface RunActionsProps {
  runId: string;
  status: string;
  /** Called after a successful control / replay action */
  onDone?: () => void;
}

export function RunActions({ runId, status, onDone }: RunActionsProps) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function control(action: "cancel" | "requeue" | "restart") {
    const confirmed = window.confirm(`Confirm ${action} for run ${runId.slice(0, 8)}?`);
    if (!confirmed) return;
    setBusy(true);
    try {
      await apiPost(`/api/v1/runs/${runId}/control`, { action });
      onDone?.();
    } finally {
      setBusy(false);
    }
  }

  async function replay() {
    const confirmed = window.confirm(`Create replay for run ${runId.slice(0, 8)}?`);
    if (!confirmed) return;
    setBusy(true);
    try {
      const result = await apiPost<object, { new_run_id: string }>(`/api/v1/runs/${runId}/replay`, {});
      router.push(`${ROUTES.RUNS}?id=${encodeURIComponent(result.new_run_id)}`);
      onDone?.();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Run actions</CardTitle>
        <CardDescription>Current status: {status}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="destructive"
            size="sm"
            disabled={busy || ["succeeded", "failed", "cancelled"].includes(status)}
            onClick={() => control("cancel")}
          >
            Cancel
          </Button>
          <Button variant="secondary" size="sm" disabled={busy || status === "running"} onClick={() => control("requeue")}>
            Requeue
          </Button>
          <Button variant="secondary" size="sm" disabled={busy || status === "running"} onClick={() => control("restart")}>
            Restart
          </Button>
          <Button variant="default" size="sm" disabled={busy} onClick={replay}>
            Replay
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
