"use client";

import { useState } from "react";

import { StatusBadge } from "@/components/observability/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { apiPost } from "@/lib/api";

interface AlertRule {
  id: string;
  name: string;
  severity: string;
  enabled: boolean;
  firing: boolean;
  open_incidents: number;
}

export function AlertRulesManager({
  rules,
  onInvalidate
}: {
  rules: AlertRule[];
  onInvalidate?: () => void;
}) {
  const [busyId, setBusyId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [severity, setSeverity] = useState("warning");
  const [conditionText, setConditionText] = useState('{"type":"threshold","metric":"failure_rate"}');
  const [errorText, setErrorText] = useState<string | null>(null);

  async function toggleRule(rule: AlertRule) {
    setBusyId(rule.id);
    try {
      await apiPost(`/api/v1/policies/alerts/${rule.id}/toggle`, { enabled: !rule.enabled });
      onInvalidate?.();
    } finally {
      setBusyId(null);
    }
  }

  async function createRule() {
    setErrorText(null);
    let condition: Record<string, unknown>;
    try {
      condition = JSON.parse(conditionText) as Record<string, unknown>;
    } catch {
      setErrorText("Condition must be valid JSON.");
      return;
    }

    if (!name.trim()) {
      setErrorText("Name is required.");
      return;
    }

    setCreating(true);
    try {
      await apiPost("/api/v1/policies/alerts", {
        name: name.trim(),
        severity,
        condition,
        enabled: true
      });
      setName("");
      setConditionText('{"type":"threshold","metric":"failure_rate"}');
      onInvalidate?.();
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="space-y-3">
      <div className="grid gap-2 rounded-lg border border-border bg-muted/20 p-3 md:grid-cols-4">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Alert rule name" />
        <select
          value={severity}
          onChange={(e) => setSeverity(e.target.value)}
          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
        >
          <option value="info">info</option>
          <option value="warning">warning</option>
          <option value="critical">critical</option>
        </select>
        <Input
          value={conditionText}
          onChange={(e) => setConditionText(e.target.value)}
          placeholder='{"type":"threshold"}'
          className="font-mono text-xs md:col-span-2"
        />
        <Button type="button" disabled={creating} onClick={createRule} className="md:col-span-4 justify-self-start">
          Create alert
        </Button>
      </div>

      {errorText ? <p className="text-xs text-destructive">{errorText}</p> : null}

      {rules.length === 0 ? (
        <p className="text-sm text-muted-foreground">No alert rules configured.</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Severity</TableHead>
              <TableHead>Enabled</TableHead>
              <TableHead>Firing</TableHead>
              <TableHead>Open incidents</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rules.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.name}</TableCell>
                <TableCell>{item.severity}</TableCell>
                <TableCell>{item.enabled ? "yes" : "no"}</TableCell>
                <TableCell>
                  {item.firing ? <StatusBadge label="firing" /> : <span className="text-muted-foreground">idle</span>}
                </TableCell>
                <TableCell>{item.open_incidents}</TableCell>
                <TableCell className="text-right">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    disabled={busyId === item.id}
                    onClick={() => toggleRule(item)}
                  >
                    {item.enabled ? "Disable" : "Enable"}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
