"use client";

import type { TypedNodeConfigFormProps } from "./index";

const MODELS = [
  "claude-sonnet-4-20250514",
  "claude-haiku-4-5-20251001",
  "claude-opus-4-20250514",
] as const;

/** Config form for Anthropic Chat Model sub-nodes. */
export function AnthropicChatModelForm({ config, onChange }: TypedNodeConfigFormProps) {
  const apiKey = typeof config.api_key === "string" ? config.api_key : "";
  const modelName = typeof config.model_name === "string" ? config.model_name : "";
  const temperature = typeof config.temperature === "number" ? config.temperature : 0.7;
  const maxTokens = typeof config.max_tokens === "number" ? config.max_tokens : 4096;

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">API Key</label>
        <input
          type="password"
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="sk-ant-..."
          value={apiKey}
          onChange={(e) => onChange({ ...config, api_key: e.target.value || undefined })}
        />
        <p className="text-[11px] text-muted-foreground">
          Leave blank to use the server environment variable.
        </p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Model</label>
        <select
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={modelName}
          onChange={(e) => onChange({ ...config, model_name: e.target.value })}
        >
          <option value="" disabled>Select a model…</option>
          {MODELS.map((m) => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Temperature</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          min={0}
          max={1}
          step={0.1}
          value={temperature}
          onChange={(e) => onChange({ ...config, temperature: parseFloat(e.target.value) || 0 })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Max Tokens</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={maxTokens}
          onChange={(e) => {
            const v = e.target.value;
            onChange({ ...config, max_tokens: v ? parseInt(v, 10) : undefined });
          }}
        />
      </div>
    </div>
  );
}
