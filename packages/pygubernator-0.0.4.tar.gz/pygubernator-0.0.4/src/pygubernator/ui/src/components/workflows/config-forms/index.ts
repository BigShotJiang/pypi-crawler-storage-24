/** Registry of typed config forms keyed by node type. */

import type { ComponentType } from "react";
import { InputNodeForm } from "./InputNodeForm";
import { OutputNodeForm } from "./OutputNodeForm";
import { TemplateNodeForm } from "./TemplateNodeForm";
import { ConditionNodeForm } from "./ConditionNodeForm";
import { CodeNodeForm } from "./CodeNodeForm";
import { HttpNodeForm } from "./HttpNodeForm";
import { RouterNodeForm } from "./RouterNodeForm";
import { LoopNodeForm } from "./LoopNodeForm";
import { MapNodeForm } from "./MapNodeForm";
import { LlmNodeForm } from "./LlmNodeForm";
import { AgentNodeForm } from "./AgentNodeForm";
import { OpenAiChatModelForm } from "./OpenAiChatModelForm";
import { AnthropicChatModelForm } from "./AnthropicChatModelForm";
import { GeminiChatModelForm } from "./GeminiChatModelForm";
import { OllamaChatModelForm } from "./OllamaChatModelForm";
import { DeepseekChatModelForm } from "./DeepseekChatModelForm";
import { GlmChatModelForm } from "./GlmChatModelForm";
import { OpenAiCompatChatModelForm } from "./OpenAiCompatChatModelForm";
import { MemoryNodeForm } from "./MemoryNodeForm";
import { ToolNodeForm } from "./ToolNodeForm";

export interface TypedNodeConfigFormProps {
  config: Record<string, unknown>;
  onChange: (config: Record<string, unknown>) => void;
}

export const configFormRegistry: Record<string, ComponentType<TypedNodeConfigFormProps>> = {
  input: InputNodeForm,
  output: OutputNodeForm,
  template: TemplateNodeForm,
  condition: ConditionNodeForm,
  code: CodeNodeForm,
  http: HttpNodeForm,
  router: RouterNodeForm,
  loop: LoopNodeForm,
  map: MapNodeForm,
  llm: LlmNodeForm,
  agent: AgentNodeForm,
  chat_model_openai: OpenAiChatModelForm,
  chat_model_anthropic: AnthropicChatModelForm,
  chat_model_gemini: GeminiChatModelForm,
  chat_model_ollama: OllamaChatModelForm,
  chat_model_deepseek: DeepseekChatModelForm,
  chat_model_glm: GlmChatModelForm,
  chat_model_openai_compat: OpenAiCompatChatModelForm,
  memory: MemoryNodeForm,
  tool: ToolNodeForm,
};
