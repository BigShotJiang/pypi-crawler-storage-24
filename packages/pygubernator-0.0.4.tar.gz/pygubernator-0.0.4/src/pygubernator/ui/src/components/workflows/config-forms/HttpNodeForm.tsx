"use client";

import { useCallback } from "react";
import type { TypedNodeConfigFormProps } from "./index";

const HTTP_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"] as const;

interface HeaderEntry {
  key: string;
  value: string;
}

/** Config form for HTTP nodes: URL, method, headers, body, timeout. */
export function HttpNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const url = typeof config.url === "string" ? config.url : "";
  const method = typeof config.method === "string" ? config.method : "GET";
  const body = typeof config.body === "string" ? config.body : "";
  const timeout = typeof config.timeout === "number" ? config.timeout : 30;

  const headers: HeaderEntry[] = Array.isArray(config.headers)
    ? (config.headers as HeaderEntry[])
    : [];

  const updateHeaders = useCallback(
    (next: HeaderEntry[]) => onChange({ ...config, headers: next }),
    [config, onChange],
  );

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">URL</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
          placeholder="https://api.example.com/data"
          value={url}
          onChange={(e) => onChange({ ...config, url: e.target.value })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Method</label>
        <select
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={method}
          onChange={(e) => onChange({ ...config, method: e.target.value })}
        >
          {HTTP_METHODS.map((m) => (
            <option key={m} value={m}>{m}</option>
          ))}
        </select>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Headers</label>
        {headers.map((h, idx) => (
          <div key={idx} className="flex gap-1">
            <input
              className="flex h-8 flex-1 rounded-md border border-input bg-background px-2 py-1 text-xs"
              placeholder="Key"
              value={h.key}
              onChange={(e) => {
                const next = [...headers];
                next[idx] = { ...h, key: e.target.value };
                updateHeaders(next);
              }}
            />
            <input
              className="flex h-8 flex-1 rounded-md border border-input bg-background px-2 py-1 text-xs"
              placeholder="Value"
              value={h.value}
              onChange={(e) => {
                const next = [...headers];
                next[idx] = { ...h, value: e.target.value };
                updateHeaders(next);
              }}
            />
            <button
              className="h-8 px-2 text-xs text-destructive hover:bg-destructive/10 rounded"
              onClick={() => updateHeaders(headers.filter((_, i) => i !== idx))}
            >
              X
            </button>
          </div>
        ))}
        <button
          className="text-xs text-primary hover:underline self-start"
          onClick={() => updateHeaders([...headers, { key: "", value: "" }])}
        >
          + Add Header
        </button>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Body</label>
        <textarea
          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
          placeholder='{"key": "value"}'
          value={body}
          onChange={(e) => onChange({ ...config, body: e.target.value })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Timeout (seconds)</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={timeout}
          min={1}
          max={300}
          onChange={(e) => onChange({ ...config, timeout: parseInt(e.target.value, 10) || 30 })}
        />
      </div>
    </div>
  );
}
