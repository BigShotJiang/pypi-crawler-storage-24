/** Zustand store for the workflow editor with undo/redo history. */

import { create } from "zustand";
import { devtools } from "zustand/middleware";
import type { SpecJson, SpecNode, StepItem } from "@/lib/types/workflow";

const MAX_UNDO = 50;

const DEFAULT_SPEC: SpecJson = {
  meta: { name: "", version: "1.0.0" },
  nodes: {},
  edges: [],
};


export interface SetSpecOptions {
  /** When true, clears undo/redo history (e.g. after loading from server). */
  replaceHistory?: boolean;
  /** When true, skips pushing an undo snapshot (e.g. drag position updates). */
  skipUndo?: boolean;
}

export interface ClipboardData {
  nodes: Record<string, SpecNode>;
  edges: { source: string; target: string; source_handle?: string; condition?: string | null }[];
}

export interface WorkflowEditorState {
  spec: SpecJson;
  past: SpecJson[];
  future: SpecJson[];
  isDirty: boolean;
  selectedNodeIds: string[];
  clipboard: ClipboardData | null;
  runOverlay: Record<string, StepItem> | null;
  lastRunId: string | null;
  bottomPanelOpen: boolean;

  setSpec: (
    updater: SpecJson | ((prev: SpecJson) => SpecJson),
    options?: SetSpecOptions,
  ) => void;
  undo: () => void;
  redo: () => void;
  markSaved: () => void;

  addNode: (type: string) => string;
  removeNode: (nodeId: string) => void;
  updateNodeConfig: (nodeId: string, config: Record<string, unknown>) => void;
  updateNodes: (nodes: Record<string, SpecNode>, options?: SetSpecOptions) => void;
  updateEdges: (
    edges: { source: string; target: string; source_handle?: string; target_handle?: string; condition?: string | null }[],
    options?: SetSpecOptions,
  ) => void;

  setSelectedNodeIds: (ids: string[]) => void;
  selectAll: () => void;

  copySelection: () => void;
  cutSelection: () => void;
  pasteClipboard: (offset?: number) => void;
  deleteSelection: () => void;

  setRunOverlay: (overlay: Record<string, StepItem> | null) => void;
  setLastRunId: (id: string | null) => void;
  toggleBottomPanel: () => void;
}

function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj)) as T;
}

export const useWorkflowEditorStore = create<WorkflowEditorState>()(
  devtools(
    (set, get) => ({
      spec: deepClone(DEFAULT_SPEC),
      past: [],
      future: [],
      isDirty: false,
      selectedNodeIds: [],
      clipboard: null,
      runOverlay: null,
      lastRunId: null,
      bottomPanelOpen: false,

      setSpec: (updater, options) => {
        set((s) => {
          const next = typeof updater === "function" ? updater(s.spec) : updater;
          if (options?.replaceHistory) {
            return { spec: next, past: [], future: [], isDirty: false };
          }
          if (options?.skipUndo) {
            return { spec: next, isDirty: true };
          }
          const snap = deepClone(s.spec);
          const newPast = [...s.past, snap].slice(-MAX_UNDO);
          return { spec: next, past: newPast, future: [], isDirty: true };
        });
      },

      undo: () => {
        const s = get();
        if (s.past.length === 0) return;
        const prev = s.past[s.past.length - 1];
        const newPast = s.past.slice(0, -1);
        const currentSnap = deepClone(s.spec);
        set({
          spec: prev,
          past: newPast,
          future: [currentSnap, ...s.future],
        });
      },

      redo: () => {
        const s = get();
        if (s.future.length === 0) return;
        const next = s.future[0];
        const newFuture = s.future.slice(1);
        const currentSnap = deepClone(s.spec);
        set({
          spec: next,
          past: [...s.past, currentSnap].slice(-MAX_UNDO),
          future: newFuture,
        });
      },

      markSaved: () => set({ isDirty: false }),

      addNode: (type: string) => {
        const id = `${type}_${Date.now().toString(36)}`;
        get().setSpec((prev) => ({
          ...prev,
          nodes: {
            ...(prev.nodes ?? {}),
            [id]: {
              type,
              config: {},
              position: {
                x: 250,
                y: Object.keys(prev.nodes ?? {}).length * 120 + 50,
              },
            },
          },
        }));
        set({ selectedNodeIds: [id] });
        return id;
      },

      removeNode: (nodeId: string) => {
        get().setSpec((prev) => {
          const { [nodeId]: _, ...rest } = prev.nodes ?? {};
          return {
            ...prev,
            nodes: rest,
            edges: (prev.edges ?? []).filter(
              (e) => e.source !== nodeId && e.target !== nodeId,
            ),
          };
        });
        set((s) => ({
          selectedNodeIds: s.selectedNodeIds.filter((id) => id !== nodeId),
        }));
      },

      updateNodeConfig: (nodeId, config) => {
        get().setSpec((prev) => ({
          ...prev,
          nodes: {
            ...(prev.nodes ?? {}),
            [nodeId]: { ...(prev.nodes ?? {})[nodeId], config },
          },
        }));
      },

      updateNodes: (nodes, options) => {
        get().setSpec(
          (prev) => ({ ...prev, nodes }),
          options,
        );
      },

      updateEdges: (edges, options) => {
        get().setSpec(
          (prev) => ({ ...prev, edges }),
          options,
        );
      },

      setSelectedNodeIds: (ids) => set({ selectedNodeIds: ids }),

      selectAll: () => {
        const nodes = get().spec.nodes ?? {};
        set({ selectedNodeIds: Object.keys(nodes) });
      },

      copySelection: () => {
        const s = get();
        const ids = new Set(s.selectedNodeIds);
        if (ids.size === 0) return;
        const allNodes = s.spec.nodes ?? {};
        const copiedNodes: Record<string, SpecNode> = {};
        for (const id of ids) {
          if (allNodes[id]) copiedNodes[id] = deepClone(allNodes[id]);
        }
        const copiedEdges = (s.spec.edges ?? []).filter(
          (e) => ids.has(e.source) && ids.has(e.target),
        );
        set({ clipboard: { nodes: copiedNodes, edges: deepClone(copiedEdges) } });
      },

      cutSelection: () => {
        get().copySelection();
        get().deleteSelection();
      },

      pasteClipboard: (offset = 50) => {
        const s = get();
        if (!s.clipboard) return;
        const idMap = new Map<string, string>();
        const newNodes: Record<string, SpecNode> = {};
        for (const [oldId, node] of Object.entries(s.clipboard.nodes)) {
          const newId = `${node.type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`;
          idMap.set(oldId, newId);
          newNodes[newId] = {
            ...deepClone(node),
            position: {
              x: (node.position?.x ?? 250) + offset,
              y: (node.position?.y ?? 50) + offset,
            },
          };
        }
        const newEdges = s.clipboard.edges
          .filter((e) => idMap.has(e.source) && idMap.has(e.target))
          .map((e) => ({
            ...e,
            source: idMap.get(e.source)!,
            target: idMap.get(e.target)!,
          }));

        get().setSpec((prev) => ({
          ...prev,
          nodes: { ...(prev.nodes ?? {}), ...newNodes },
          edges: [...(prev.edges ?? []), ...newEdges],
        }));
        set({ selectedNodeIds: Array.from(idMap.values()) });
      },

      deleteSelection: () => {
        const s = get();
        if (s.selectedNodeIds.length === 0) return;
        const ids = new Set(s.selectedNodeIds);
        get().setSpec((prev) => {
          const nodes = { ...(prev.nodes ?? {}) };
          for (const id of ids) delete nodes[id];
          return {
            ...prev,
            nodes,
            edges: (prev.edges ?? []).filter(
              (e) => !ids.has(e.source) && !ids.has(e.target),
            ),
          };
        });
        set({ selectedNodeIds: [] });
      },

      setRunOverlay: (overlay) => set({ runOverlay: overlay }),
      setLastRunId: (id) => set({ lastRunId: id }),
      toggleBottomPanel: () => set((s) => ({ bottomPanelOpen: !s.bottomPanelOpen })),
    }),
    { name: "workflow-editor" },
  ),
);

// Granular selectors
export const selectSpec = (s: WorkflowEditorState) => s.spec;
export const selectPastLength = (s: WorkflowEditorState) => s.past.length;
export const selectFutureLength = (s: WorkflowEditorState) => s.future.length;
export const selectUndo = (s: WorkflowEditorState) => s.undo;
export const selectRedo = (s: WorkflowEditorState) => s.redo;
export const selectSetSpec = (s: WorkflowEditorState) => s.setSpec;
export const selectAddNode = (s: WorkflowEditorState) => s.addNode;
export const selectRemoveNode = (s: WorkflowEditorState) => s.removeNode;
export const selectUpdateNodeConfig = (s: WorkflowEditorState) => s.updateNodeConfig;
export const selectUpdateNodes = (s: WorkflowEditorState) => s.updateNodes;
export const selectUpdateEdges = (s: WorkflowEditorState) => s.updateEdges;
export const selectSelectedNodeIds = (s: WorkflowEditorState) => s.selectedNodeIds;
export const selectSetSelectedNodeIds = (s: WorkflowEditorState) => s.setSelectedNodeIds;
export const selectSelectAll = (s: WorkflowEditorState) => s.selectAll;
export const selectClipboard = (s: WorkflowEditorState) => s.clipboard;
export const selectCopySelection = (s: WorkflowEditorState) => s.copySelection;
export const selectCutSelection = (s: WorkflowEditorState) => s.cutSelection;
export const selectPasteClipboard = (s: WorkflowEditorState) => s.pasteClipboard;
export const selectDeleteSelection = (s: WorkflowEditorState) => s.deleteSelection;
export const selectRunOverlay = (s: WorkflowEditorState) => s.runOverlay;
export const selectLastRunId = (s: WorkflowEditorState) => s.lastRunId;
export const selectSetRunOverlay = (s: WorkflowEditorState) => s.setRunOverlay;
export const selectSetLastRunId = (s: WorkflowEditorState) => s.setLastRunId;
export const selectIsDirty = (s: WorkflowEditorState) => s.isDirty;
export const selectMarkSaved = (s: WorkflowEditorState) => s.markSaved;
export const selectBottomPanelOpen = (s: WorkflowEditorState) => s.bottomPanelOpen;
export const selectToggleBottomPanel = (s: WorkflowEditorState) => s.toggleBottomPanel;
