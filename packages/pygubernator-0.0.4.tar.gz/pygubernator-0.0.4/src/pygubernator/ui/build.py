"""Build script for PyGubernator UI. Builds Next.js and copies output to static/."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def get_ui_root() -> Path:
    return Path(__file__).parent


def build_ui() -> int:
    """
    Build the Next.js UI for production.

    Returns:
        0 on success, 1 on failure.
    """
    ui_root = get_ui_root()
    package_json = ui_root / "package.json"
    if not package_json.exists():
        print(f"❌ Error: package.json not found at {package_json}", file=sys.stderr)
        print("Please initialize the Next.js project first.", file=sys.stderr)
        return 1

    node_modules = ui_root / "node_modules"
    if not node_modules.exists():
        print("Installing npm dependencies...", file=sys.stderr)
        try:
            subprocess.run(
                ["npm", "install"],
                cwd=str(ui_root),
                check=True,
            )
        except subprocess.CalledProcessError as e:
            print(f"❌ Error: npm install failed: {e}", file=sys.stderr)
            return 1
        except FileNotFoundError:
            print(
                "❌ Error: npm not found. Please install Node.js and npm.",
                file=sys.stderr,
            )
            return 1

    print("Building Next.js application...", file=sys.stderr)
    env = os.environ.copy()
    env["NODE_ENV"] = "production"
    try:
        subprocess.run(
            ["npm", "run", "build"],
            cwd=str(ui_root),
            check=True,
            env=env,
        )
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: npm run build failed: {e}", file=sys.stderr)
        return 1
    except FileNotFoundError:
        print(
            "❌ Error: npm not found. Please install Node.js and npm.",
            file=sys.stderr,
        )
        return 1

    out_dir = ui_root / "out"
    if not out_dir.exists():
        print(
            f"❌ Error: Build output directory not found at {out_dir}",
            file=sys.stderr,
        )
        print("Next.js build may have failed.", file=sys.stderr)
        return 1

    static_dir = ui_root / "static"
    if static_dir.exists():
        print("Removing existing static directory...", file=sys.stderr)
        shutil.rmtree(static_dir)

    print(f"Copying build output to {static_dir}...", file=sys.stderr)
    try:
        shutil.copytree(out_dir, static_dir)
    except OSError as e:
        print(f"❌ Error copying build output: {e}", file=sys.stderr)
        return 1

    print(
        f"✓ Successfully built UI. Static files are in {static_dir}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(build_ui())
