"""Run Next.js development server for PyGubernator UI (mirrors pycharter / pystator)."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from pygubernator.config import ControlPlaneSettings


def get_ui_root() -> Path:
    return Path(__file__).parent


def run_dev_server(
    api_url: str | None = None,
    port: int | None = None,
) -> int:
    """
    Run Next.js development server.

    Args:
        api_url: PyGubernator API URL (defaults to PYGUBERNATOR_API_URL or config).
        port: Dev server port (defaults to PYGUBERNATOR_UI_PORT or config).
    """
    ui_root = get_ui_root()
    package_json = ui_root / "package.json"
    if not package_json.exists():
        print(f"Error: package.json not found at {package_json}", file=sys.stderr)
        print("Please initialize the Next.js project first.", file=sys.stderr)
        return 1

    settings = ControlPlaneSettings.from_env()
    if api_url is None:
        api_url = os.getenv("PYGUBERNATOR_API_URL", settings.api_url)
    if port is None:
        port = int(os.getenv("PYGUBERNATOR_UI_PORT", str(settings.ui_port)))

    env = os.environ.copy()
    env["NEXT_PUBLIC_PYGUBERNATOR_API_URL"] = api_url
    env["PORT"] = str(port)

    node_modules = ui_root / "node_modules"
    if not node_modules.exists():
        print(
            "Warning: node_modules not found. Running 'npm install' first...",
            file=sys.stderr,
        )
        try:
            subprocess.run(
                ["npm", "install"],
                cwd=str(ui_root),
                check=True,
                env=env,
            )
        except subprocess.CalledProcessError as e:
            print(f"Error: npm install failed: {e}", file=sys.stderr)
            return 1
        except FileNotFoundError:
            print(
                "Error: npm not found. Please install Node.js and npm.",
                file=sys.stderr,
            )
            return 1

    print("PyGubernator UI development server starting...")
    print(f"  UI: http://localhost:{port}")
    print(f"  API: {api_url}")
    print(f"  API proxied via: /api/* -> {api_url}/api/*")
    print()

    try:
        proc = subprocess.run(
            ["npm", "run", "dev"],
            cwd=str(ui_root),
            env=env,
        )
    except KeyboardInterrupt:
        print("\nShutting down dev server...", file=sys.stderr)
        return 0
    except FileNotFoundError:
        print("Error: npm not found. Please install Node.js and npm.", file=sys.stderr)
        return 1
    return proc.returncode


if __name__ == "__main__":
    import argparse

    s = ControlPlaneSettings.from_env()
    parser = argparse.ArgumentParser(description="PyGubernator UI development server")
    parser.add_argument(
        "--api-url",
        type=str,
        default=None,
        help=("URL of the PyGubernator API (default: PYGUBERNATOR_API_URL or config)"),
    )
    parser.add_argument(
        "--port",
        type=int,
        default=s.ui_port,
        help="Port to run dev server on (default: from config)",
    )
    args = parser.parse_args()
    raise SystemExit(run_dev_server(api_url=args.api_url, port=args.port))
