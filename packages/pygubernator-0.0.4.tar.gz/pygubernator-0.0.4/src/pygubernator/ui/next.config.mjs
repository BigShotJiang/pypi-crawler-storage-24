/** @type {import('next').NextConfig} */
const nextConfig = {
  ...(process.env.NODE_ENV === "production" && { output: "export" }),
  trailingSlash: true,
  images: { unoptimized: true },
  async rewrites() {
    if (
      process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL &&
      process.env.NODE_ENV !== "production"
    ) {
      const base = process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL.replace(/\/$/, "");
      return [
        { source: "/api/:path*", destination: `${base}/api/:path*` },
        // Same-origin as /api/* — health lives at FastAPI root, not under /api
        { source: "/healthz", destination: `${base}/healthz` },
        { source: "/healthz/", destination: `${base}/healthz` }
      ];
    }
    return [];
  }
};

export default nextConfig;
