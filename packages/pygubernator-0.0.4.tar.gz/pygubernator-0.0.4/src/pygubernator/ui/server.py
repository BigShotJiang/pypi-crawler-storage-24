"""Serve built UI files and proxy API requests."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import httpx
import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from pygubernator import __version__ as pygubernator_version
from pygubernator.config import ControlPlaneSettings, get_ui_app_name, get_ui_theme

_index_html_cache: str | None = None
_index_html_static_dir: Path | None = None


def _static_dir() -> Path:
    candidates = [
        Path(__file__).parent / "static",
        Path(__file__).parent / "out",
        Path.cwd() / "src" / "pygubernator" / "ui" / "static",
    ]
    for c in candidates:
        if c.exists() and (c / "index.html").exists():
            return c
    raise FileNotFoundError("UI static files not found. Run: pygubernator ui build")


def _index_html_with_config(static_dir: Path, theme: str, app_name: str) -> str:
    global _index_html_cache, _index_html_static_dir
    if _index_html_cache is None or _index_html_static_dir != static_dir:
        _index_html_cache = (static_dir / "index.html").read_text(
            encoding="utf-8", errors="replace"
        )
        _index_html_static_dir = static_dir
    return _inject_app_config_into_html(_index_html_cache, theme, app_name)


def _inject_app_config_into_html(html: str, theme: str, app_name: str) -> str:
    if "</head>" not in html:
        return html
    theme_js = json.dumps(theme)
    app_name_js = json.dumps(app_name)
    version_js = json.dumps(pygubernator_version or "")
    named_themes_js = json.dumps(
        ["ocean", "forest", "sunset", "high-contrast", "sepia", "violet", "cathay"]
    )
    script = (
        f'<script>window.__APP_CONFIG__={{"theme":{theme_js},'
        f'"appName":{app_name_js},"version":{version_js}}};'
        "var cfg=window.__APP_CONFIG__;"
        "var theme=cfg.theme||'light';"
        f"var namedThemes={named_themes_js};"
        "function resolved(t){if(t==='system'){return window.matchMedia("
        "'(prefers-color-scheme: dark)').matches?'dark':'light';}return t;}"
        "function applyTheme(){var t=resolved(theme);var el=document.documentElement;"
        "if(t==='dark'){el.classList.add('dark');el.removeAttribute('data-theme');}"
        "else{el.classList.remove('dark');if(namedThemes.indexOf(t)!==-1){"
        "el.setAttribute('data-theme',t);}else{el.removeAttribute('data-theme');}}}"
        "applyTheme();"
        "if(theme==='system'){window.matchMedia("
        "'(prefers-color-scheme: dark)').addEventListener('change',applyTheme);}"
        "if(cfg.appName){document.title=cfg.appName+' Control Plane';}"
        "</script></head>"
    )
    return html.replace("</head>", script, 1)


def _resolve_export_path(static_dir: Path, path: str) -> Path | None:
    normalized = path.strip("/")
    candidate = static_dir / normalized if normalized else static_dir
    try:
        candidate.relative_to(static_dir)
    except ValueError:
        return None
    if candidate.is_file():
        return candidate
    if candidate.is_dir():
        index_file = candidate / "index.html"
        if index_file.is_file():
            return index_file
    return None


def create_app(api_url: str) -> FastAPI:
    app = FastAPI(title="PyGubernator UI")
    static_dir = _static_dir()
    next_static = static_dir / "_next"
    if next_static.exists():
        app.mount(
            "/_next",
            StaticFiles(directory=str(next_static)),
            name="next",
        )

    @app.get("/healthz")
    async def proxy_health() -> Response:
        """Forward health check to the control-plane API (banner + monitoring)."""
        url = f"{api_url.rstrip('/')}/healthz"
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(url, timeout=5.0)
            except httpx.RequestError:
                return Response(
                    content=b'{"status":"api_unavailable"}',
                    status_code=503,
                    media_type="application/json",
                )
            return Response(
                content=resp.content,
                status_code=resp.status_code,
                media_type=resp.headers.get("content-type", "application/json"),
            )

    @app.api_route(
        "/api/{path:path}",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    )
    async def proxy_api(request: Request, path: str) -> Response:
        url = f"{api_url.rstrip('/')}/api/{path}"
        if request.url.query:
            url = f"{url}?{request.url.query}"
        body = await request.body()
        headers = dict(request.headers)
        headers.pop("host", None)
        async with httpx.AsyncClient() as client:
            resp = await client.request(
                request.method,
                url,
                headers=headers,
                content=body,
                timeout=30.0,
            )
            return Response(
                content=resp.content,
                status_code=resp.status_code,
                media_type=resp.headers.get("content-type"),
            )

    @app.api_route("/{path:path}", methods=["GET", "HEAD"])
    async def serve_spa(path: str, request: Request) -> Response:
        resolved = _resolve_export_path(static_dir, path)
        if resolved is not None:
            if request.method == "HEAD":
                media_type = "text/html" if resolved.suffix.lower() == ".html" else None
                return Response(status_code=200, media_type=media_type)
            if resolved.suffix.lower() != ".html":
                return FileResponse(resolved)
            html = resolved.read_text(encoding="utf-8", errors="replace")
            html = _inject_app_config_into_html(html, get_ui_theme(), get_ui_app_name())
            return Response(content=html, media_type="text/html")
        if request.method == "HEAD":
            return Response(status_code=200, media_type="text/html")
        html = _index_html_with_config(static_dir, get_ui_theme(), get_ui_app_name())
        return Response(content=html, media_type="text/html")

    return app


def serve_ui(
    api_url: str | None = None,
    host: str | None = None,
    port: int | None = None,
) -> int:
    """
    Serve the built UI and proxy ``/api/*`` to the control-plane API.

    Args:
        api_url: Backend API base URL (default: ``PYGUBERNATOR_API_URL`` / config).
        host: Bind host (default: ``PYGUBERNATOR_UI_HOST`` / config).
        port: Bind port (default: ``PYGUBERNATOR_UI_PORT`` / config).
    """
    settings = ControlPlaneSettings.from_env()
    resolved_api = (
        api_url
        if api_url is not None
        else os.getenv("PYGUBERNATOR_API_URL", settings.api_url)
    )
    resolved_host = (
        host
        if host is not None
        else os.getenv("PYGUBERNATOR_UI_HOST", settings.ui_host)
    )
    if port is not None:
        resolved_port = port
    else:
        env_port = os.getenv("PYGUBERNATOR_UI_PORT")
        resolved_port = int(env_port) if env_port else settings.ui_port

    try:
        static_dir = _static_dir()
    except FileNotFoundError as e:
        print(f"❌ {e}", file=sys.stderr)
        print("Build with: pygubernator ui build", file=sys.stderr)
        return 1

    print(f"✓ UI static files: {static_dir}")
    print(f"PyGubernator UI: http://{resolved_host}:{resolved_port}")
    print(f"API: {resolved_api}")

    app = create_app(resolved_api)
    uvicorn.run(app, host=resolved_host, port=resolved_port, log_level="info")
    return 0


if __name__ == "__main__":
    import argparse

    s = ControlPlaneSettings.from_env()
    p = argparse.ArgumentParser(description="PyGubernator UI static server")
    p.add_argument("--api-url", type=str, default=None)
    p.add_argument("--host", type=str, default=s.ui_host)
    p.add_argument("--port", type=int, default=s.ui_port)
    args = p.parse_args()
    raise SystemExit(serve_ui(api_url=args.api_url, host=args.host, port=args.port))
