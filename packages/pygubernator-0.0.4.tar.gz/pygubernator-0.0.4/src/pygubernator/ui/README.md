# PyGubernator UI

Next.js 16 UI for the PyGubernator control plane.

## CLI (recommended; matches pycharter / pystator)

From the repo root with the package installed (`pip install -e ".[ui]"`):

```bash
pygubernator ui dev    # Next dev server; --api-url, --port
pygubernator ui serve  # Serves built UI + proxies /api; --api-url, --host, --port
pygubernator ui build  # npm install, next build, copy out/ → static/
```

Defaults come from `ControlPlaneSettings` (`pygubernator.cfg` / `PYGUBERNATOR_*` env vars), same as the API server.

**Development:** set `NEXT_PUBLIC_PYGUBERNATOR_API_URL` (e.g. `http://127.0.0.1:8010`) so `next.config.mjs` can rewrite `/api/*` **and `/healthz`** to the API (same-origin; avoids CORS). Without the `/healthz` rewrite, the “API server not connected” banner can appear even when `pygubernator api` is running, because the browser would hit the Next dev server for `/healthz` instead of the API.

Static `output: export` production builds do not apply rewrites—use the full API URL in the client bundle or serve via `pygubernator ui serve`, which proxies `/api` and `/healthz` to the backend.

## Manual npm

```bash
cd src/pygubernator/ui
npm install
npm run dev
```

## Build

```bash
npm run build
```

Production bundles are copied to `static/` by `pygubernator ui build`.

## Runtime env

- `NEXT_PUBLIC_PYGUBERNATOR_API_URL` (default `http://127.0.0.1:8010`)
- `NEXT_PUBLIC_PYGUBERNATOR_TOKEN` (default `dev-token`)
- `PYGUBERNATOR_API_URL` — API base URL for `ui serve` / dev when `--api-url` is omitted
- `PYGUBERNATOR_UI_HOST` / `PYGUBERNATOR_UI_PORT` — bind address for `ui serve`
