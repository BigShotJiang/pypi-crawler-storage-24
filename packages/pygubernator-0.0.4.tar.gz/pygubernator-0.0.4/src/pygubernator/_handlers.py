"""Built-in event handlers for logging, metrics, and database persistence."""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any

from pygubernator._events import AgentEvent, AgentEventType

logger = logging.getLogger(__name__)

# Events that indicate errors or warnings.
_ERROR_EVENTS = frozenset(
    {
        AgentEventType.AGENT_ERROR,
        AgentEventType.STEP_FAILED,
        AgentEventType.TOOL_CALL_FAILED,
    }
)

_WARNING_EVENTS = frozenset(
    {
        AgentEventType.AGENT_PAUSED,
    }
)


class LoggingEventHandler:
    """Logs agent events at appropriate severity levels.

    - Error events log at ERROR.
    - Warning events log at WARNING.
    - All other events log at INFO.
    """

    async def handle(self, event: AgentEvent) -> None:
        """Log the event.

        Args:
            event: The event to log.
        """
        if event.event_type in _ERROR_EVENTS:
            logger.error(
                "[%s] %s: %s",
                event.agent_id,
                event.event_type.value,
                event.data,
            )
        elif event.event_type in _WARNING_EVENTS:
            logger.warning(
                "[%s] %s",
                event.agent_id,
                event.event_type.value,
            )
        else:
            logger.info(
                "[%s] %s",
                event.agent_id,
                event.event_type.value,
            )


class MetricsEventHandler:
    """Accumulates in-memory counters and duration histograms.

    Use ``get_metrics()`` to retrieve a snapshot of collected data.
    """

    def __init__(self) -> None:
        self._counters: dict[str, int] = defaultdict(int)
        self._durations: dict[str, list[float]] = defaultdict(list)

    async def handle(self, event: AgentEvent) -> None:
        """Record the event in counters and histograms.

        Args:
            event: The event to record.
        """
        key = event.event_type.value
        self._counters[key] += 1

        duration = event.data.get("duration_ms")
        if duration is not None:
            self._durations[key].append(float(duration))

    def get_metrics(self) -> dict[str, Any]:
        """Return a snapshot of all collected metrics.

        Returns:
            Dictionary with ``counters`` and ``durations`` keys.
        """
        return {
            "counters": dict(self._counters),
            "durations": {k: list(v) for k, v in self._durations.items()},
        }

    def reset(self) -> None:
        """Clear all accumulated metrics."""
        self._counters.clear()
        self._durations.clear()


class DatabaseEventHandler:
    """Persists events to the database via a SQLAlchemy session factory.

    Args:
        session_factory: Callable that returns a SQLAlchemy Session.
    """

    def __init__(self, session_factory: Any) -> None:
        self._session_factory = session_factory

    async def handle(self, event: AgentEvent) -> None:
        """Write the event to the RunEvent or ToolCall table.

        Args:
            event: The event to persist.
        """
        # Lazy import to avoid hard dependency on db module.

        if event.run_id is None:
            return

        db = self._session_factory()
        try:
            if event.event_type in (
                AgentEventType.TOOL_CALL_STARTED,
                AgentEventType.TOOL_CALL_COMPLETED,
                AgentEventType.TOOL_CALL_FAILED,
            ):
                self._persist_tool_call(db, event)
            else:
                self._persist_run_event(db, event)
            db.commit()
        except Exception:
            db.rollback()
            logger.exception(
                "Failed to persist event %s for run %s",
                event.event_type.value,
                event.run_id,
            )
        finally:
            db.close()

    @staticmethod
    def _persist_run_event(db: Any, event: AgentEvent) -> None:
        """Write a RunEvent row."""
        from pygubernator.db.models import RunEvent as RunEventModel

        level = "error" if event.event_type in _ERROR_EVENTS else "info"
        record = RunEventModel(
            run_id=event.run_id,
            event_type=event.event_type.value,
            level=level,
            message=event.data.get("message"),
            payload=event.data,
        )
        db.add(record)

    @staticmethod
    def _persist_tool_call(db: Any, event: AgentEvent) -> None:
        """Write a ToolCall row."""
        from pygubernator.db.models import ToolCall as ToolCallModel

        is_failed = event.event_type == AgentEventType.TOOL_CALL_FAILED
        status = "failed" if is_failed else "completed"
        record = ToolCallModel(
            run_id=event.run_id,
            tool_name=event.data.get("tool_name", "unknown"),
            status=status,
            latency_ms=event.data.get("duration_ms"),
            input_payload=event.data.get("input", {}),
            output_payload=event.data.get("output", {}),
            error_message=event.data.get("error"),
        )
        db.add(record)
