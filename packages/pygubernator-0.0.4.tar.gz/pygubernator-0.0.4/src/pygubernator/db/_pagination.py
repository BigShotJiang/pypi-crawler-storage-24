"""Pagination helper for SQLAlchemy queries."""

from __future__ import annotations

__all__ = ["paginate"]


def paginate(query, page: int, page_size: int):
    """Apply offset/limit pagination to a query.

    Args:
        query: SQLAlchemy select statement.
        page: Page number (1-indexed).
        page_size: Results per page.

    Returns:
        The query with offset and limit applied.
    """
    return query.offset((page - 1) * page_size).limit(page_size)
