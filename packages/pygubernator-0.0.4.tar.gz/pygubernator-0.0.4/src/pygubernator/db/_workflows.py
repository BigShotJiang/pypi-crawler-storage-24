"""Repository helpers for workflow entities."""

from __future__ import annotations

from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pygubernator.db._pagination import paginate
from pygubernator.db.models import (
    Workflow,
    WorkflowRun,
    WorkflowStepRun,
    WorkflowVersion,
)

__all__ = [
    "activate_workflow_version",
    "create_workflow",
    "create_workflow_run",
    "create_workflow_step_run",
    "create_workflow_version",
    "get_workflow",
    "get_workflow_run",
    "list_step_runs",
    "list_workflow_runs",
    "list_workflow_versions",
    "list_workflows",
    "update_workflow",
    "update_workflow_run",
    "update_workflow_step_run",
]


def create_workflow(
    db: Session,
    *,
    name: str,
    description: str = "",
    owner: str = "system",
    status: str = "active",
) -> Workflow:
    """Create a new Workflow record.

    Args:
        db: SQLAlchemy session.
        name: Unique workflow name.
        description: Brief description.
        owner: Owner identifier.
        status: Initial status.

    Returns:
        The created Workflow.
    """
    wf = Workflow(
        name=name,
        description=description,
        owner=owner,
        status=status,
    )
    db.add(wf)
    return wf


def get_workflow(db: Session, workflow_id: str) -> Workflow | None:
    """Get a workflow by ID."""
    return db.get(Workflow, workflow_id)


def list_workflows(
    db: Session,
    *,
    page: int = 1,
    page_size: int = 25,
    status: str | None = None,
) -> tuple[list[Workflow], int]:
    """List workflows with pagination and optional status filter.

    Args:
        db: SQLAlchemy session.
        page: Page number (1-indexed).
        page_size: Results per page.
        status: Optional status filter.

    Returns:
        Tuple of (workflows, total_count).
    """
    query = select(Workflow)
    count_query = select(func.count(Workflow.id))
    if status:
        query = query.where(Workflow.status == status)
        count_query = count_query.where(Workflow.status == status)
    items = db.scalars(
        paginate(query.order_by(Workflow.created_at.desc()), page, page_size)
    ).all()
    total = int(db.scalar(count_query) or 0)
    return items, total


def update_workflow(
    db: Session,
    workflow: Workflow,
    **kwargs: Any,
) -> Workflow:
    """Update fields on an existing Workflow.

    Args:
        db: SQLAlchemy session.
        workflow: The Workflow to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated Workflow.
    """
    for key, value in kwargs.items():
        if hasattr(workflow, key):
            setattr(workflow, key, value)
    return workflow


def create_workflow_version(
    db: Session,
    *,
    workflow_id: str,
    version: str,
    spec_json: dict[str, Any] | None = None,
    active: bool = False,
    created_by: str = "system",
) -> WorkflowVersion:
    """Create a new WorkflowVersion record.

    Args:
        db: SQLAlchemy session.
        workflow_id: Parent workflow ID.
        version: Version string.
        spec_json: Workflow specification as JSON dict.
        active: Whether this version is active.
        created_by: Actor who created this version.

    Returns:
        The created WorkflowVersion.
    """
    wv = WorkflowVersion(
        workflow_id=workflow_id,
        version=version,
        spec_json=spec_json or {},
        active=active,
        created_by=created_by,
    )
    db.add(wv)
    return wv


def list_workflow_versions(
    db: Session,
    workflow_id: str,
) -> list[WorkflowVersion]:
    """List all versions for a workflow, newest first."""
    return list(
        db.scalars(
            select(WorkflowVersion)
            .where(WorkflowVersion.workflow_id == workflow_id)
            .order_by(WorkflowVersion.created_at.desc())
        ).all()
    )


def activate_workflow_version(
    db: Session,
    workflow: Workflow,
    version_id: str,
) -> None:
    """Activate a specific workflow version, deactivating all others.

    Args:
        db: SQLAlchemy session.
        workflow: The workflow whose version to activate.
        version_id: The version ID to activate.
    """
    for version in workflow.versions:
        version.active = version.id == version_id


def create_workflow_run(
    db: Session,
    *,
    workflow_id: str,
    workflow_version_id: str | None = None,
    status: str = "pending",
    input_json: dict[str, Any] | None = None,
    created_by: str = "system",
) -> WorkflowRun:
    """Create a new WorkflowRun record.

    Args:
        db: SQLAlchemy session.
        workflow_id: Parent workflow ID.
        workflow_version_id: Optional version ID.
        status: Initial run status.
        input_json: Input data for the run.
        created_by: Actor who created this run.

    Returns:
        The created WorkflowRun.
    """
    wr = WorkflowRun(
        workflow_id=workflow_id,
        workflow_version_id=workflow_version_id,
        status=status,
        input_json=input_json or {},
        created_by=created_by,
    )
    db.add(wr)
    return wr


def get_workflow_run(db: Session, run_id: str) -> WorkflowRun | None:
    """Get a workflow run by ID."""
    return db.get(WorkflowRun, run_id)


def list_workflow_runs(
    db: Session,
    *,
    page: int = 1,
    page_size: int = 25,
    workflow_id: str | None = None,
    status: str | None = None,
) -> tuple[list[WorkflowRun], int]:
    """List workflow runs with pagination and optional filters.

    Args:
        db: SQLAlchemy session.
        page: Page number (1-indexed).
        page_size: Results per page.
        workflow_id: Optional workflow filter.
        status: Optional status filter.

    Returns:
        Tuple of (workflow_runs, total_count).
    """
    query = select(WorkflowRun)
    count_query = select(func.count(WorkflowRun.id))
    if workflow_id:
        query = query.where(WorkflowRun.workflow_id == workflow_id)
        count_query = count_query.where(WorkflowRun.workflow_id == workflow_id)
    if status:
        query = query.where(WorkflowRun.status == status)
        count_query = count_query.where(WorkflowRun.status == status)
    items = db.scalars(
        paginate(
            query.order_by(WorkflowRun.started_at.desc().nulls_last()),
            page,
            page_size,
        )
    ).all()
    total = int(db.scalar(count_query) or 0)
    return items, total


def update_workflow_run(
    db: Session,
    run: WorkflowRun,
    **kwargs: Any,
) -> WorkflowRun:
    """Update fields on an existing WorkflowRun.

    Args:
        db: SQLAlchemy session.
        run: The WorkflowRun to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated WorkflowRun.
    """
    for key, value in kwargs.items():
        if hasattr(run, key):
            setattr(run, key, value)
    return run


def create_workflow_step_run(
    db: Session,
    *,
    workflow_run_id: str,
    node_id: str,
    node_type: str,
    status: str = "pending",
    input_json: dict[str, Any] | None = None,
) -> WorkflowStepRun:
    """Create a WorkflowStepRun record.

    Args:
        db: SQLAlchemy session.
        workflow_run_id: Parent workflow run ID.
        node_id: Workflow node ID.
        node_type: Node type string.
        status: Initial step status.
        input_json: Node input data.

    Returns:
        The created WorkflowStepRun.
    """
    step = WorkflowStepRun(
        workflow_run_id=workflow_run_id,
        node_id=node_id,
        node_type=node_type,
        status=status,
        input_json=input_json or {},
    )
    db.add(step)
    return step


def list_step_runs(
    db: Session,
    workflow_run_id: str,
) -> list[WorkflowStepRun]:
    """List all step runs for a workflow run, ordered by start time.

    Args:
        db: SQLAlchemy session.
        workflow_run_id: The workflow run to list steps for.

    Returns:
        List of WorkflowStepRun records.
    """
    return list(
        db.scalars(
            select(WorkflowStepRun)
            .where(WorkflowStepRun.workflow_run_id == workflow_run_id)
            .order_by(WorkflowStepRun.started_at.asc().nulls_last())
        ).all()
    )


def update_workflow_step_run(
    db: Session,
    step: WorkflowStepRun,
    **kwargs: Any,
) -> WorkflowStepRun:
    """Update fields on an existing WorkflowStepRun.

    Args:
        db: SQLAlchemy session.
        step: The WorkflowStepRun to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated WorkflowStepRun.
    """
    for key, value in kwargs.items():
        if hasattr(step, key):
            setattr(step, key, value)
    return step
