"""Base SQLAlchemy configuration.

Mirrors PyStator's db/base.py for consistent behavior across SQLite and PostgreSQL.
"""

from __future__ import annotations

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker
from sqlalchemy.pool import StaticPool


class Base(DeclarativeBase):
    """Declarative base for all pygubernator models."""


def get_engine(connection_string: str):
    """Create SQLAlchemy engine from connection string.

    For SQLite, configures the engine to handle schema references properly.
    SQLite doesn't support schemas, so schema prefixes are stripped from SQL.

    Args:
        connection_string: Database connection URL.

    Returns:
        SQLAlchemy engine instance.
    """
    if connection_string.startswith("sqlite://"):
        is_memory = connection_string == "sqlite:///:memory:"
        extra_kw: dict = {"echo": False}
        if is_memory:
            # StaticPool ensures all connections share the same
            # underlying database for in-memory SQLite.
            extra_kw["poolclass"] = StaticPool
            extra_kw["connect_args"] = {"check_same_thread": False}
        else:
            extra_kw["connect_args"] = {"check_same_thread": False}
        engine = create_engine(connection_string, **extra_kw)

        @event.listens_for(engine, "connect")
        def _set_sqlite_pragma(dbapi_conn, connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

        @event.listens_for(engine, "before_cursor_execute", retval=True)
        def _strip_schema_prefix(
            conn, cursor, statement, parameters, context, executemany
        ):
            if connection_string.startswith("sqlite://"):
                statement = statement.replace('"pygubernator".', "").replace(
                    "pygubernator.", ""
                )
            return statement, parameters

        return engine
    return create_engine(connection_string, echo=False)


def get_session(connection_string: str) -> Session:
    """Create SQLAlchemy session from connection string.

    Args:
        connection_string: Database connection URL.

    Returns:
        New session instance bound to the created engine.
    """
    engine = get_engine(connection_string)
    factory = sessionmaker(bind=engine)
    return factory()


def get_schema_prefix(connection_string: str) -> str:
    """Return schema prefix for raw SQL.

    Args:
        connection_string: Database connection URL.

    Returns:
        Empty string for SQLite, ``'pygubernator.'`` for PostgreSQL.
    """
    if connection_string.startswith("sqlite://"):
        return ""
    return "pygubernator."
