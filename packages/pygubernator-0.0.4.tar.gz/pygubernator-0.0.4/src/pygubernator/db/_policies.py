"""Repository helpers for PolicyAssignment entities."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from pygubernator.db.models import PolicyAssignment

__all__ = ["list_policies"]


def list_policies(db: Session, agent_id: str | None = None) -> list[PolicyAssignment]:
    """List policy assignments, optionally filtered by agent.

    Args:
        db: SQLAlchemy session.
        agent_id: Optional agent ID filter.

    Returns:
        List of policy assignments.
    """
    q = select(PolicyAssignment).order_by(PolicyAssignment.created_at.desc())
    if agent_id:
        q = q.where(PolicyAssignment.agent_id == agent_id)
    return db.scalars(q).all()
