"""Retention utilities for high-volume observability tables."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import delete
from sqlalchemy.orm import Session

from pygubernator.db.models import RunEvent, ToolCall


def purge_old_events(db: Session, retention_days: int) -> dict[str, int]:
    cutoff = datetime.now(UTC) - timedelta(days=retention_days)
    run_events_deleted = (
        db.execute(delete(RunEvent).where(RunEvent.created_at < cutoff)).rowcount or 0
    )
    tool_calls_deleted = (
        db.execute(delete(ToolCall).where(ToolCall.created_at < cutoff)).rowcount or 0
    )
    db.commit()
    return {
        "run_events_deleted": run_events_deleted,
        "tool_calls_deleted": tool_calls_deleted,
    }
