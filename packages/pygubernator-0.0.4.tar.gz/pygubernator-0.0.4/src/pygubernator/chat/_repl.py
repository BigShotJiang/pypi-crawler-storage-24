"""Interactive REPL loop for the chat CLI."""

from __future__ import annotations

import logging
import sys

from pygubernator.chat._session import ChatSession

logger = logging.getLogger(__name__)

_WELCOME = """\
pygubernator chat — interactive agent REPL
Type a message to chat. Special commands:
  /tools  — list available tools
  /clear  — reset conversation history
  /quit   — exit (or Ctrl+C)
"""


async def run_chat_repl(session: ChatSession) -> None:
    """Run an interactive chat REPL.

    Reads user input, sends it through the chat session, and
    prints responses with tool call details.

    Args:
        session: Configured ChatSession instance.
    """
    print(_WELCOME)  # noqa: T201

    while True:
        try:
            user_input = _read_input()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")  # noqa: T201
            break

        if not user_input:
            continue

        if user_input == "/quit":
            print("Goodbye!")  # noqa: T201
            break

        if user_input == "/clear":
            session.clear()
            print("History cleared.\n")  # noqa: T201
            continue

        if user_input == "/tools":
            _print_tools(session)
            continue

        try:
            turn = await session.send(user_input)
        except Exception:
            logger.exception("Error processing message")
            print(  # noqa: T201
                "An error occurred. Please try again.\n",
                file=sys.stderr,
            )
            continue

        if turn.tool_calls:
            for tc in turn.tool_calls:
                print(  # noqa: T201
                    f"  -> {tc['name']}({_format_args(tc.get('arguments', {}))})"
                )

        if turn.response:
            print(f"\n{turn.response}\n")  # noqa: T201
        else:
            print()  # noqa: T201


def _read_input() -> str:
    """Read a line of input from the user."""
    return input("you> ").strip()


def _print_tools(session: ChatSession) -> None:
    """Print the list of available tools."""
    # Access tool registry via session internals
    tools = session._tools  # noqa: SLF001
    print("\nAvailable tools:")  # noqa: T201
    for schema in tools.get_schemas():
        print(  # noqa: T201
            f"  - {schema['name']}: {schema.get('description', '')}"
        )
    print()  # noqa: T201


def _format_args(args: dict) -> str:  # type: ignore[type-arg]
    """Format tool arguments for display."""
    parts: list[str] = []
    for key, value in args.items():
        if isinstance(value, str):
            parts.append(f"{key}={value!r}")
        elif isinstance(value, list) and len(value) > 3:
            parts.append(f"{key}=[...{len(value)} items]")
        else:
            parts.append(f"{key}={value}")
    return ", ".join(parts)
