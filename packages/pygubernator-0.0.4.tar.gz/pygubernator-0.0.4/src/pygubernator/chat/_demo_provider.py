"""Scripted LLM provider for demo/testing without an API key."""

from __future__ import annotations

import uuid
from typing import Any

from pygubernator.llm._messages import LLMResponse, ToolCall


class DemoLLMProvider:
    """Scripted LLM provider that recognizes simple patterns.

    Returns pre-scripted tool-calling responses based on keyword
    matching. Useful for testing the full tool pipeline without
    requiring an actual API key.
    """

    def __init__(self) -> None:
        self._last_generated: list[dict[str, Any]] | None = None

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Return scripted responses based on the last user message.

        Args:
            messages: Conversation messages.
            tools: Tool schemas (unused but required by protocol).

        Returns:
            Scripted LLMResponse with tool calls or text.
        """
        user_msg = self._last_user_message(messages)
        lower = user_msg.lower()

        # Check if this is a follow-up after a tool result
        if messages and messages[-1].get("role") == "tool":
            content = messages[-1].get("content", "")
            return self._text_response(f"Here are the results:\n\n{content}")

        if "generate" in lower:
            count = self._extract_count(lower, default=5)
            return self._tool_response(
                "generate_data",
                {"schema_name": "orders", "count": count},
            )

        if "validate" in lower:
            return self._tool_response(
                "validate_batch",
                {
                    "records": self._last_generated or [],
                    "contract_name": "orders",
                },
            )

        if "submit" in lower or "start" in lower:
            entity_id = f"order-{uuid.uuid4().hex[:8]}"
            return self._tool_response(
                "create_session",
                {
                    "entity_id": entity_id,
                    "machine_name": "order_lifecycle",
                },
            )

        if "state" in lower or "status" in lower:
            return self._tool_response(
                "list_triggers",
                {"entity_id": self._extract_entity_id(lower)},
            )

        return self._text_response(
            "I can help you with data engineering tasks. Try:\n"
            "- 'Generate 5 orders' — create mock data\n"
            "- 'Validate those records' — validate against "
            "the orders contract\n"
            "- 'Submit an order' — start a state machine "
            "session\n"
            "- 'What's the status?' — check entity state"
        )

    @staticmethod
    def _last_user_message(
        messages: list[dict[str, Any]],
    ) -> str:
        """Extract the last user message from the conversation."""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                return str(msg.get("content", ""))
        return ""

    @staticmethod
    def _extract_count(text: str, default: int = 5) -> int:
        """Extract a numeric count from text."""
        for word in text.split():
            if word.isdigit():
                return int(word)
        return default

    @staticmethod
    def _extract_entity_id(text: str) -> str:
        """Extract an entity ID from text, or return a default."""
        for word in text.split():
            if word.startswith("order-"):
                return word
        return "order-1"

    @staticmethod
    def _tool_response(
        name: str,
        arguments: dict[str, Any],
    ) -> LLMResponse:
        """Build a response with a single tool call."""
        return LLMResponse(
            content="",
            tool_calls=(
                ToolCall(
                    id=f"call_{uuid.uuid4().hex[:12]}",
                    name=name,
                    arguments=arguments,
                ),
            ),
            finish_reason="tool_calls",
        )

    @staticmethod
    def _text_response(content: str) -> LLMResponse:
        """Build a plain text response."""
        return LLMResponse(
            content=content,
            finish_reason="stop",
        )
