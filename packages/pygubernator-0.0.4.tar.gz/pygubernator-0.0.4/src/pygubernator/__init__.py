"""General-purpose Python agent framework with pystator integration."""

from __future__ import annotations

try:
    from importlib.metadata import version as _get_version

    __version__ = _get_version("pygubernator")
except Exception:
    __version__ = "0.0.1.dev0"

# Events
from pygubernator._events import AgentEvent, AgentEventType, EventBus, EventHandler
from pygubernator._handlers import (
    DatabaseEventHandler,
    LoggingEventHandler,
    MetricsEventHandler,
)

# Middleware
from pygubernator._middleware import Middleware, MiddlewareChain

# Core types
from pygubernator._protocols import LLMProvider, Tool, Transport

# Supervisor
from pygubernator._supervisor import AgentPipeline, AgentSupervisor, RestartPolicy
from pygubernator._types import AgentResult, Message, StepResult, ToolResult

# Agents
from pygubernator.agents import (
    BaseAgent,
    LLMAgent,
    PipelineAgent,
    PipelineStep,
    StateMachineAgent,
)

# Config
from pygubernator.config import AgentSettings

# Errors
from pygubernator.errors import (
    AgentError,
    ConfigError,
    ErrorCode,
    ExecutionError,
    ExpressionError,
    GubernatorError,
    LLMError,
    NodeError,
    PipelineStepError,
    ToolError,
    TransportError,
    WorkflowError,
)

# LLM
from pygubernator.llm import (
    ChatMessage,
    ChatRole,
    LLMResponse,
    OpenAICompatibleProvider,
    ProviderConfig,
    ProviderType,
    ToolCall,
    create_provider,
)
from pygubernator.middleware import (
    LoggingMiddleware,
    RetryMiddleware,
    TimeoutMiddleware,
    ValidationMiddleware,
)

# Runners
from pygubernator.runners import run_batch, run_stream

# Tools
from pygubernator.tools import ToolRegistry, tool

# Transport
from pygubernator.transport import InMemoryTransport

# Workflow (optional, requires [workflow] extra)
try:
    from pygubernator.workflow import (
        ExecutionMode,
        NodeTypeRegistry,
        WorkflowEngine,
        WorkflowLoader,
        WorkflowResult,
        WorkflowSpec,
    )
except ImportError:
    ExecutionMode = None  # type: ignore[assignment, misc]
    NodeTypeRegistry = None  # type: ignore[assignment, misc]
    WorkflowEngine = None  # type: ignore[assignment, misc]
    WorkflowLoader = None  # type: ignore[assignment, misc]
    WorkflowResult = None  # type: ignore[assignment, misc]
    WorkflowSpec = None  # type: ignore[assignment, misc]

# Client (optional, requires [api] extra)
try:
    from pygubernator.client import ControlPlaneClient
except ImportError:
    ControlPlaneClient = None  # type: ignore[assignment, misc]

__all__ = [
    # Events
    "AgentEvent",
    "AgentEventType",
    "DatabaseEventHandler",
    "EventBus",
    "EventHandler",
    "LoggingEventHandler",
    "MetricsEventHandler",
    # Middleware
    "LoggingMiddleware",
    "Middleware",
    "MiddlewareChain",
    "RetryMiddleware",
    "TimeoutMiddleware",
    "ValidationMiddleware",
    # Supervisor
    "AgentPipeline",
    "AgentSupervisor",
    "RestartPolicy",
    # Agents
    "BaseAgent",
    "LLMAgent",
    "PipelineAgent",
    "PipelineStep",
    "StateMachineAgent",
    # Config
    "AgentSettings",
    # Errors
    "AgentError",
    "ConfigError",
    "ErrorCode",
    "ExecutionError",
    "ExpressionError",
    "GubernatorError",
    "LLMError",
    "NodeError",
    "PipelineStepError",
    "ToolError",
    "TransportError",
    "WorkflowError",
    # LLM
    "ChatMessage",
    "ChatRole",
    "LLMResponse",
    "OpenAICompatibleProvider",
    "ProviderConfig",
    "ProviderType",
    "ToolCall",
    "create_provider",
    # Protocols
    "LLMProvider",
    "Tool",
    "Transport",
    # Runners
    "run_batch",
    "run_stream",
    # Tools
    "ToolRegistry",
    "tool",
    # Transport
    "InMemoryTransport",
    # Types
    "AgentResult",
    "Message",
    "StepResult",
    "ToolResult",
    # Workflow
    "ExecutionMode",
    "NodeTypeRegistry",
    "WorkflowEngine",
    "WorkflowLoader",
    "WorkflowResult",
    "WorkflowSpec",
    # Client
    "ControlPlaneClient",
]
