"""Run management and replay routes."""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, HTTPException, Query

from pygubernator.api.deps import AdminActor, CurrentActor, DbSession
from pygubernator.api.models import (
    PageMeta,
    RunControlRequest,
    RunCreateRequest,
    RunOut,
)
from pygubernator.db.models import Run
from pygubernator.db.repositories import (
    create_audit,
    create_run,
    get_agent,
    get_run,
    get_run_status_facets,
    list_runs_filtered,
)

router = APIRouter(prefix="/api/v1/runs", tags=["runs"])


@router.post("", response_model=RunOut)
def create_run_endpoint(
    payload: RunCreateRequest, db: DbSession, actor: CurrentActor
) -> RunOut:
    """Create a new run.

    Args:
        payload: Run creation request with agent_id and optional metadata.
        db: Database session.
        actor: Current authenticated actor.

    Returns:
        Created run record.

    Raises:
        HTTPException: If agent not found or invalid input.
    """
    # Verify agent exists
    agent = get_agent(db, payload.agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    # Verify agent_version_id if provided
    if payload.agent_version_id:
        from pygubernator.db.models import AgentVersion

        version = db.get(AgentVersion, payload.agent_version_id)
        if not version or version.agent_id != payload.agent_id:
            raise HTTPException(
                status_code=404,
                detail="Agent version not found or does not belong to agent",
            )

    # Create run
    run = create_run(
        db,
        agent_id=payload.agent_id,
        agent_version_id=payload.agent_version_id,
        status="queued",
        correlation_id=payload.correlation_id,
        trigger=payload.trigger,
        metadata_json=payload.metadata_json,
    )
    create_audit(
        db,
        actor=actor["actor"],
        action="run.create",
        resource_type="run",
        resource_id=run.id,
        details=payload.model_dump(),
    )
    db.commit()
    db.refresh(run)
    return RunOut.model_validate(run)


@router.get("")
def list_runs(
    db: DbSession,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    status: str | None = None,
    agent_id: str | None = None,
    correlation_id: str | None = None,
    has_error: bool | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
    sort_by: str = Query(
        "created_at", pattern="^(created_at|duration_ms|cost_usd_micros)$"
    ),
    sort_order: str = Query("desc", pattern="^(asc|desc)$"),
) -> dict:
    items, total = list_runs_filtered(
        db,
        page=page,
        page_size=page_size,
        status=status,
        agent_id=agent_id,
        correlation_id=correlation_id,
        has_error=has_error,
        created_from=created_from,
        created_to=created_to,
        sort_by=sort_by,
        sort_order=sort_order,
    )
    return {
        "items": [
            {
                "id": i.id,
                "agent_id": i.agent_id,
                "status": i.status,
                "created_at": i.created_at,
                "started_at": i.started_at,
                "ended_at": i.ended_at,
                "duration_ms": i.duration_ms,
                "token_input": i.token_input,
                "token_output": i.token_output,
                "cost_usd_micros": i.cost_usd_micros,
                "error_message": i.error_message,
                "correlation_id": i.correlation_id,
            }
            for i in items
        ],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
        "facets": {"statuses": get_run_status_facets(db)},
    }


@router.get("/{run_id}")
def get_run_detail(run_id: str, db: DbSession, _: CurrentActor) -> dict:
    run = get_run(db, run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return {
        "id": run.id,
        "agent_id": run.agent_id,
        "agent_version_id": run.agent_version_id,
        "status": run.status,
        "trigger": run.trigger,
        "correlation_id": run.correlation_id,
        "started_at": run.started_at,
        "ended_at": run.ended_at,
        "duration_ms": run.duration_ms,
        "token_input": run.token_input,
        "token_output": run.token_output,
        "cost_usd_micros": run.cost_usd_micros,
        "metadata_json": run.metadata_json,
        "error_message": run.error_message,
    }


@router.post("/{run_id}/control")
def control_run(
    run_id: str, payload: RunControlRequest, db: DbSession, actor: AdminActor
) -> dict:
    run = get_run(db, run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    if payload.action not in {"cancel", "requeue", "restart"}:
        raise HTTPException(status_code=400, detail="Unsupported run action")

    if payload.action == "cancel" and run.status in {
        "succeeded",
        "failed",
        "cancelled",
    }:
        raise HTTPException(status_code=409, detail="Run is already terminal")
    if payload.action in {"requeue", "restart"} and run.status == "running":
        raise HTTPException(status_code=409, detail="Run is already running")

    if payload.action == "cancel":
        run.status = "cancelled"
        run.ended_at = datetime.now(UTC)
    elif payload.action == "requeue":
        run.status = "queued"
        run.started_at = None
        run.ended_at = None
        run.error_message = None
    else:
        run.status = "running"
        run.started_at = datetime.now(UTC)
        run.ended_at = None
    create_audit(
        db,
        actor=actor["actor"],
        action="run.control",
        resource_type="run",
        resource_id=run_id,
        details=payload.model_dump(),
    )
    db.commit()
    return {"ok": True, "run_id": run_id, "status": run.status}


@router.post("/{run_id}/replay")
def replay_run(run_id: str, db: DbSession, actor: AdminActor) -> dict:
    run = get_run(db, run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    replay = Run(
        agent_id=run.agent_id,
        agent_version_id=run.agent_version_id,
        status="queued",
        trigger="replay",
        correlation_id=run.correlation_id,
        metadata_json={"replay_of": run.id},
    )
    db.add(replay)
    create_audit(
        db,
        actor=actor["actor"],
        action="run.replay",
        resource_type="run",
        resource_id=replay.id,
        details={"source_run_id": run.id},
    )
    db.commit()
    db.refresh(replay)
    return {"ok": True, "new_run_id": replay.id}
