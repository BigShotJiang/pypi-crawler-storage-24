"""Authentication routes backed by cfg/env users."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import jwt
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from pygubernator.config import get_auth_jwt_secret, get_auth_users

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


@router.post("/login")
def login(payload: LoginRequest) -> dict:
    users = get_auth_users()
    user = next(
        (
            u
            for u in users
            if u["username"] == payload.username and u["password"] == payload.password
        ),
        None,
    )
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    secret = get_auth_jwt_secret()
    if not secret:
        raise HTTPException(status_code=500, detail="Auth secret is not configured")
    now = datetime.now(UTC)
    token = jwt.encode(
        {
            "sub": user["username"],
            "role": user.get("role", "User"),
            "iat": int(now.timestamp()),
            "exp": int((now + timedelta(hours=8)).timestamp()),
        },
        secret,
        algorithm="HS256",
    )
    return {
        "access_token": token,
        "token_type": "bearer",
        "role": user.get("role", "User"),
    }
