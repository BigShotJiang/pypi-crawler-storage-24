"""FastAPI app for pygubernator control plane."""

from __future__ import annotations

from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from pygubernator.api.routes_agents import router as agents_router
from pygubernator.api.routes_auth import router as auth_router
from pygubernator.api.routes_llm import router as llm_router
from pygubernator.api.routes_observability import router as observability_router
from pygubernator.api.routes_policies import router as policies_router
from pygubernator.api.routes_runs import router as runs_router
from pygubernator.api.routes_workflows import router as workflows_router
from pygubernator.config import ControlPlaneSettings, get_ui_app_name, get_ui_theme
from pygubernator.db.config import get_db_url
from pygubernator.db.retention import purge_old_events
from pygubernator.db.session import get_db, init_db


def create_app() -> FastAPI:
    settings = ControlPlaneSettings.from_env()
    app = FastAPI(title="PyGubernator Control Plane API", version="0.1.0")
    cors_origins = [o.strip() for o in settings.allow_origins.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(auth_router)
    app.include_router(agents_router)
    app.include_router(runs_router)
    app.include_router(observability_router)
    app.include_router(policies_router)
    app.include_router(workflows_router)
    app.include_router(llm_router)

    @app.on_event("startup")
    def _startup() -> None:
        # Auto-init SQLite only if the file doesn't exist yet.
        db_url = get_db_url(required=False)
        if db_url and db_url.startswith("sqlite:///"):
            from pathlib import Path

            db_path = db_url[10:]
            if db_path != ":memory:" and not Path(db_path).exists():
                init_db(db_url)

    @app.post("/api/v1/admin/retention")
    def run_retention() -> dict:
        db = next(get_db())
        try:
            result = purge_old_events(db, settings.event_retention_days)
        finally:
            db.close()
        return {"ok": True, **result}

    @app.get("/healthz")
    def health() -> dict:
        return {"status": "ok"}

    @app.get("/api/v1/ui/config")
    def ui_config() -> dict:
        # Theme/name from cfg/env each request (not the import-time settings snapshot).
        return {
            "theme": get_ui_theme(),
            "app_name": get_ui_app_name(),
        }

    return app


app = create_app()


def _package_root() -> Path:
    """Return the pygubernator package directory (installed or editable)."""
    try:
        import pygubernator as _pkg

        return Path(_pkg.__file__).resolve().parent
    except ImportError:
        return Path(__file__).resolve().parent.parent


def _reload_dirs_excluding_ui() -> list[str]:
    """Dirs for uvicorn reload (exclude ui/ to avoid node_modules inotify limits)."""
    pkg_root = _package_root()
    return [
        str(d)
        for d in sorted(pkg_root.iterdir())
        if d.is_dir()
        and d.name != "ui"
        and not d.name.startswith("__")
        and not d.name.startswith(".")
    ]


def run_api(
    *,
    host: str | None = None,
    port: int | None = None,
    reload: bool = False,
) -> None:
    """Run the control-plane API with uvicorn (CLI / ``python -m`` entry)."""
    settings = ControlPlaneSettings.from_env()
    h = host if host is not None else settings.api_host
    p = port if port is not None else settings.api_port

    run_kw: dict[str, object] = {
        "host": h,
        "port": p,
        "reload": reload,
        "log_level": "info",
    }
    if reload:
        run_kw["reload_dirs"] = _reload_dirs_excluding_ui()

    uvicorn.run("pygubernator.api.main:app", **run_kw)


def serve_api() -> None:
    """Default production-style serve (config from env / .cfg only, no reload)."""
    settings = ControlPlaneSettings.from_env()
    run_api(host=settings.api_host, port=settings.api_port, reload=False)


if __name__ == "__main__":
    serve_api()
