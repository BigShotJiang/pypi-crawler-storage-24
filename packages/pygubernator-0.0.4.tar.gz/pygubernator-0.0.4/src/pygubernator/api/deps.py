"""FastAPI dependencies for auth and db."""

from __future__ import annotations

from typing import Annotated

import jwt
from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from pygubernator.config import (
    ControlPlaneSettings,
    get_auth_admin_role_claims,
    get_auth_jwt_secret,
    is_auth_disabled,
)
from pygubernator.db.session import get_db


def get_current_actor(
    x_api_token: Annotated[str | None, Header(alias="X-API-Token")] = None,
    x_actor: Annotated[str | None, Header(alias="X-Actor")] = None,
    x_role: Annotated[str | None, Header(alias="X-Role")] = None,
    authorization: Annotated[str | None, Header(alias="Authorization")] = None,
) -> dict[str, str]:
    if is_auth_disabled():
        return {"actor": x_actor or "system", "role": x_role or "admin"}

    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
        secret = get_auth_jwt_secret()
        if not secret:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="JWT secret is not configured",
            )
        try:
            claims = jwt.decode(token, secret, algorithms=["HS256"])
            role = str(claims.get("role", "User"))
            return {"actor": str(claims.get("sub", "user")), "role": role}
        except jwt.PyJWTError as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid bearer token",
            ) from exc

    settings = ControlPlaneSettings.from_env()
    if x_api_token != settings.auth_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API token",
        )
    return {"actor": x_actor or "system", "role": x_role or settings.auth_role}


def require_admin(actor: CurrentActor) -> dict[str, str]:
    admin_claims = get_auth_admin_role_claims()
    if str(actor.get("role", "")).lower() not in {c.lower() for c in admin_claims} | {
        "owner"
    }:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required",
        )
    return actor


DbSession = Annotated[Session, Depends(get_db)]
CurrentActor = Annotated[dict[str, str], Depends(get_current_actor)]
AdminActor = Annotated[dict[str, str], Depends(require_admin)]
