"""Pydantic API models for control plane."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class PageMeta(BaseModel):
    total: int
    page: int
    page_size: int


class AgentCreateRequest(BaseModel):
    name: str
    owner: str = "system"
    status: str = "active"


class AgentUpdateRequest(BaseModel):
    status: str | None = None
    archived: bool | None = None


class LLMProviderConfigRequest(BaseModel):
    """Structured LLM provider configuration."""

    provider_type: str = Field(
        ..., description="Provider backend: litellm, openai_compatible, local"
    )
    model: str = Field(..., description="Model identifier")
    api_base: str | None = Field(None, description="Server URL")
    api_key: str | None = Field(None, description="API key")
    max_tokens: int = Field(4096, ge=1)
    temperature: float = Field(0.0, ge=0.0, le=2.0)
    top_p: float | None = Field(None, ge=0.0, le=1.0)
    top_k: int | None = Field(None, ge=1)


class LLMProviderPresetOut(BaseModel):
    """Known provider preset for the UI."""

    name: str
    provider_type: str
    default_api_base: str | None
    requires_api_key: bool
    models: list[str]
    description: str


class LLMHealthCheckRequest(BaseModel):
    """Request to health-check an LLM provider endpoint."""

    api_base: str = Field(..., description="Server URL to check")
    api_key: str | None = Field(None, description="Optional API key")


class LLMHealthCheckResponse(BaseModel):
    """Response from provider health check."""

    reachable: bool
    models: list[str] = Field(default_factory=list)
    error: str | None = None


class AgentVersionCreateRequest(BaseModel):
    version: str
    model: str | None = None
    prompt: str | None = None
    tools: dict[str, Any] = Field(default_factory=dict)
    config: dict[str, Any] = Field(default_factory=dict)
    provider: LLMProviderConfigRequest | None = None


class RunCreateRequest(BaseModel):
    agent_id: str
    agent_version_id: str | None = None
    correlation_id: str | None = None
    trigger: str | None = None
    metadata_json: dict[str, Any] = Field(default_factory=dict)


class RunEnqueueRequest(BaseModel):
    """Enqueue a run for an agent (``agent_id`` comes from the URL path)."""

    agent_version_id: str | None = None
    correlation_id: str | None = None
    trigger: str | None = None
    metadata_json: dict[str, Any] = Field(default_factory=dict)


class RunControlRequest(BaseModel):
    action: str
    reason: str | None = None


class IncidentCreateRequest(BaseModel):
    title: str
    severity: str = "warning"
    run_id: str | None = None
    alert_id: str | None = None
    owner: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class IncidentAssignRequest(BaseModel):
    owner: str


class IncidentSilenceRequest(BaseModel):
    until: datetime


class PolicyAssignmentRequest(BaseModel):
    agent_id: str
    policy_type: str
    policy_value: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True


class AlertRuleRequest(BaseModel):
    name: str
    severity: str = "warning"
    condition: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True


class AlertRuleToggleRequest(BaseModel):
    enabled: bool


class RunEventIngestRequest(BaseModel):
    run_id: str
    event_type: str
    level: str = "info"
    message: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class AgentOut(BaseModel):
    id: str
    name: str
    owner: str
    status: str
    archived: bool
    current_version_id: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AgentVersionOut(BaseModel):
    id: str
    agent_id: str
    version: str
    model: str | None
    prompt: str | None
    tools: dict[str, Any]
    config: dict[str, Any]
    active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class AgentDashboardOut(BaseModel):
    """Agent plus versions in one response (UI / client convenience)."""

    agent: AgentOut
    versions: list[AgentVersionOut]


class WorkflowCreateRequest(BaseModel):
    """Request to create a new workflow."""

    name: str
    description: str = ""
    owner: str = "system"


class WorkflowUpdateRequest(BaseModel):
    """Request to update a workflow."""

    name: str | None = None
    description: str | None = None
    status: str | None = None


class WorkflowVersionCreateRequest(BaseModel):
    """Request to create a workflow version."""

    version: str
    spec_json: dict[str, Any] = Field(default_factory=dict)


class WorkflowExecuteRequest(BaseModel):
    """Request to execute a workflow."""

    input_json: dict[str, Any] = Field(default_factory=dict)
    version_id: str | None = None


class WorkflowOut(BaseModel):
    """Workflow response model."""

    id: str
    name: str
    description: str
    owner: str
    status: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class WorkflowVersionOut(BaseModel):
    """Workflow version response model."""

    id: str
    workflow_id: str
    version: str
    spec_json: dict[str, Any]
    active: bool
    created_at: datetime
    created_by: str

    model_config = {"from_attributes": True}


class WorkflowRunOut(BaseModel):
    """Workflow run response model."""

    id: str
    workflow_id: str
    workflow_version_id: str | None
    status: str
    input_json: dict[str, Any]
    output_json: dict[str, Any]
    variables_json: dict[str, Any]
    error_message: str | None
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None
    created_by: str

    model_config = {"from_attributes": True}


class WorkflowStepRunOut(BaseModel):
    """Workflow step run response model."""

    id: str
    workflow_run_id: str
    node_id: str
    node_type: str
    status: str
    input_json: dict[str, Any]
    output_json: dict[str, Any]
    error_message: str | None
    output_handle: str
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None

    model_config = {"from_attributes": True}


class RunOut(BaseModel):
    id: str
    agent_id: str
    agent_version_id: str | None
    status: str
    trigger: str | None
    correlation_id: str | None
    created_at: datetime
    started_at: datetime | None
    ended_at: datetime | None
    duration_ms: int | None
    token_input: int
    token_output: int
    cost_usd_micros: int
    metadata_json: dict[str, Any]
    error_message: str | None

    model_config = {"from_attributes": True}
