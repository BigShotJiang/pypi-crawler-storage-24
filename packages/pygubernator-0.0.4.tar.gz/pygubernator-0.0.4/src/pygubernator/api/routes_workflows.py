"""Workflow management and execution routes."""

from __future__ import annotations

import logging
from datetime import UTC, datetime

from fastapi import APIRouter, HTTPException, Query

from pygubernator.api.deps import CurrentActor, DbSession
from pygubernator.api.models import (
    PageMeta,
    WorkflowCreateRequest,
    WorkflowExecuteRequest,
    WorkflowOut,
    WorkflowRunOut,
    WorkflowStepRunOut,
    WorkflowUpdateRequest,
    WorkflowVersionCreateRequest,
    WorkflowVersionOut,
)
from pygubernator.db.repositories import (
    activate_workflow_version,
    create_audit,
    create_workflow,
    create_workflow_run,
    create_workflow_version,
    get_workflow,
    get_workflow_run,
    list_step_runs,
    list_workflow_runs,
    list_workflow_versions,
    list_workflows,
    update_workflow,
    update_workflow_run,
)
from pygubernator.services._workflows import execute_workflow

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/workflows", tags=["workflows"])


@router.post("", response_model=WorkflowOut)
def create_workflow_route(
    payload: WorkflowCreateRequest,
    db: DbSession,
    actor: CurrentActor,
) -> WorkflowOut:
    """Create a new workflow."""
    wf = create_workflow(
        db,
        name=payload.name,
        description=payload.description,
        owner=payload.owner,
    )
    create_audit(
        db,
        actor=actor["actor"],
        action="workflow.create",
        resource_type="workflow",
        resource_id=wf.id,
        details=payload.model_dump(),
    )
    db.commit()
    db.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.get("")
def list_workflows_route(
    db: DbSession,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    status: str | None = None,
    q: str | None = None,
) -> dict:
    """List workflows with pagination."""
    items, total = list_workflows(db, page=page, page_size=page_size, status=status)
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i.name.lower() or ql in i.owner.lower()]
    return {
        "items": [WorkflowOut.model_validate(w).model_dump() for w in items],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
    }


@router.get("/{workflow_id}", response_model=WorkflowOut)
def get_workflow_route(workflow_id: str, db: DbSession, _: CurrentActor) -> WorkflowOut:
    """Get workflow detail."""
    wf = get_workflow(db, workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return WorkflowOut.model_validate(wf)


@router.patch("/{workflow_id}", response_model=WorkflowOut)
def update_workflow_route(
    workflow_id: str,
    payload: WorkflowUpdateRequest,
    db: DbSession,
    actor: CurrentActor,
) -> WorkflowOut:
    """Update workflow metadata."""
    wf = get_workflow(db, workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    updates = payload.model_dump(exclude_none=True)
    update_workflow(db, wf, **updates)
    create_audit(
        db,
        actor=actor["actor"],
        action="workflow.update",
        resource_type="workflow",
        resource_id=workflow_id,
        details=updates,
    )
    db.commit()
    db.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.delete("/{workflow_id}", response_model=WorkflowOut)
def delete_workflow_route(
    workflow_id: str,
    db: DbSession,
    actor: CurrentActor,
) -> WorkflowOut:
    """Soft-delete a workflow by setting status to 'deleted'."""
    wf = get_workflow(db, workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    update_workflow(db, wf, status="deleted")
    create_audit(
        db,
        actor=actor["actor"],
        action="workflow.delete",
        resource_type="workflow",
        resource_id=workflow_id,
        details={"status": "deleted"},
    )
    db.commit()
    db.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.post("/{workflow_id}/versions", response_model=WorkflowVersionOut)
def create_version_route(
    workflow_id: str,
    payload: WorkflowVersionCreateRequest,
    db: DbSession,
    actor: CurrentActor,
) -> WorkflowVersionOut:
    """Create a new workflow version."""
    if not get_workflow(db, workflow_id):
        raise HTTPException(status_code=404, detail="Workflow not found")
    wv = create_workflow_version(
        db,
        workflow_id=workflow_id,
        version=payload.version,
        spec_json=payload.spec_json,
        created_by=actor["actor"],
    )
    create_audit(
        db,
        actor=actor["actor"],
        action="workflow.version.create",
        resource_type="workflow_version",
        resource_id=wv.id,
        details={"version": payload.version},
    )
    db.commit()
    db.refresh(wv)
    return WorkflowVersionOut.model_validate(wv)


@router.get("/{workflow_id}/versions")
def list_versions_route(workflow_id: str, db: DbSession, _: CurrentActor) -> dict:
    """List all versions for a workflow."""
    versions = list_workflow_versions(db, workflow_id)
    return {
        "items": [WorkflowVersionOut.model_validate(v).model_dump() for v in versions],
    }


@router.post(
    "/{workflow_id}/versions/{version_id}/activate",
    response_model=WorkflowOut,
)
def activate_version_route(
    workflow_id: str,
    version_id: str,
    db: DbSession,
    actor: CurrentActor,
) -> WorkflowOut:
    """Activate a specific workflow version."""
    wf = get_workflow(db, workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    versions = list_workflow_versions(db, workflow_id)
    if not any(v.id == version_id for v in versions):
        raise HTTPException(status_code=404, detail="Version not found")
    activate_workflow_version(db, wf, version_id)
    create_audit(
        db,
        actor=actor["actor"],
        action="workflow.version.activate",
        resource_type="workflow",
        resource_id=workflow_id,
        details={"version_id": version_id},
    )
    db.commit()
    db.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.post("/{workflow_id}/execute")
def execute_workflow_route(
    workflow_id: str,
    payload: WorkflowExecuteRequest,
    db: DbSession,
    actor: CurrentActor,
) -> dict:
    """Execute a workflow and return the run result."""
    wf = get_workflow(db, workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    versions = list_workflow_versions(db, workflow_id)
    if payload.version_id:
        version = next((v for v in versions if v.id == payload.version_id), None)
    else:
        version = next((v for v in versions if v.active), None)
        if not version and versions:
            version = versions[0]

    if not version:
        raise HTTPException(status_code=400, detail="No workflow version available")

    run = create_workflow_run(
        db,
        workflow_id=workflow_id,
        workflow_version_id=version.id,
        status="running",
        input_json=payload.input_json,
        created_by=actor["actor"],
    )
    run.started_at = datetime.now(UTC)
    db.commit()
    db.refresh(run)

    result = execute_workflow(version.spec_json, payload.input_json, db, run.id)

    if result["success"]:
        update_workflow_run(
            db,
            run,
            status="completed",
            output_json=result.get("output", {}),
            completed_at=datetime.now(UTC),
            duration_ms=result.get("duration_ms"),
        )
    else:
        update_workflow_run(
            db,
            run,
            status="failed",
            error_message="; ".join(result.get("errors", [])),
            completed_at=datetime.now(UTC),
            duration_ms=result.get("duration_ms"),
        )
    db.commit()
    db.refresh(run)

    return {
        "run": WorkflowRunOut.model_validate(run).model_dump(),
        "result": result,
    }


@router.get("/runs/list")
def list_runs_route(
    db: DbSession,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    workflow_id: str | None = None,
    status: str | None = None,
) -> dict:
    """List workflow runs."""
    items, total = list_workflow_runs(
        db,
        page=page,
        page_size=page_size,
        workflow_id=workflow_id,
        status=status,
    )
    return {
        "items": [WorkflowRunOut.model_validate(r).model_dump() for r in items],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
    }


@router.get("/runs/{run_id}")
def get_run_detail_route(run_id: str, db: DbSession, _: CurrentActor) -> dict:
    """Get workflow run detail with step timeline."""
    run = get_workflow_run(db, run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    steps = list_step_runs(db, run_id)
    return {
        "run": WorkflowRunOut.model_validate(run).model_dump(),
        "steps": [WorkflowStepRunOut.model_validate(s).model_dump() for s in steps],
    }


@router.get("/runs/{run_id}/trace")
def get_run_trace_route(run_id: str, db: DbSession, _: CurrentActor) -> dict:
    """Get full step-by-step trace with timing for a workflow run."""
    run = get_workflow_run(db, run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    steps = list_step_runs(db, run_id)
    trace = []
    for step in steps:
        trace.append(
            {
                "node_id": step.node_id,
                "node_type": step.node_type,
                "status": step.status,
                "input": step.input_json,
                "output": step.output_json,
                "error": step.error_message,
                "output_handle": step.output_handle,
                "started_at": (
                    step.started_at.isoformat() if step.started_at else None
                ),
                "completed_at": (
                    step.completed_at.isoformat() if step.completed_at else None
                ),
                "duration_ms": step.duration_ms,
            }
        )
    return {
        "run_id": run_id,
        "workflow_id": run.workflow_id,
        "status": run.status,
        "trace": trace,
    }
