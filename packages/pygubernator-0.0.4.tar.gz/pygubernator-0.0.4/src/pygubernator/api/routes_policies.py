"""Policy assignment and alert routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, select

from pygubernator.api.deps import AdminActor, CurrentActor, DbSession
from pygubernator.api.models import (
    AlertRuleRequest,
    AlertRuleToggleRequest,
    PolicyAssignmentRequest,
)
from pygubernator.db.models import AlertRule, Incident, PolicyAssignment
from pygubernator.db.repositories import create_audit, list_audit_logs, list_policies

router = APIRouter(prefix="/api/v1/policies", tags=["policies"])


@router.get("")
def get_policies(db: DbSession, _: CurrentActor, agent_id: str | None = None) -> dict:
    items = list_policies(db, agent_id=agent_id)
    return {
        "items": [
            {
                "id": i.id,
                "agent_id": i.agent_id,
                "policy_type": i.policy_type,
                "policy_value": i.policy_value,
                "enabled": i.enabled,
                "created_at": i.created_at,
            }
            for i in items
        ]
    }


@router.post("")
def upsert_policy(
    payload: PolicyAssignmentRequest, db: DbSession, actor: AdminActor
) -> dict:
    rec = PolicyAssignment(
        agent_id=payload.agent_id,
        policy_type=payload.policy_type,
        policy_value=payload.policy_value,
        enabled=payload.enabled,
    )
    db.add(rec)
    create_audit(
        db,
        actor=actor["actor"],
        action="policy.create",
        resource_type="policy_assignment",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    db.commit()
    db.refresh(rec)
    return {"id": rec.id}


@router.get("/alerts")
def get_alerts(db: DbSession, _: CurrentActor) -> dict:
    incident_counts = {
        alert_id: count
        for alert_id, count in db.execute(
            select(Incident.alert_id, func.count(Incident.id))
            .where(Incident.alert_id.is_not(None), Incident.status != "resolved")
            .group_by(Incident.alert_id)
        ).all()
    }
    items = db.scalars(select(AlertRule).order_by(AlertRule.created_at.desc())).all()
    return {
        "items": [
            {
                "id": i.id,
                "name": i.name,
                "severity": i.severity,
                "condition": i.condition,
                "enabled": i.enabled,
                "open_incidents": int(incident_counts.get(i.id, 0)),
                "firing": int(incident_counts.get(i.id, 0)) > 0,
            }
            for i in items
        ]
    }


@router.post("/alerts")
def create_alert(payload: AlertRuleRequest, db: DbSession, actor: AdminActor) -> dict:
    rec = AlertRule(
        name=payload.name,
        severity=payload.severity,
        condition=payload.condition,
        enabled=payload.enabled,
    )
    db.add(rec)
    create_audit(
        db,
        actor=actor["actor"],
        action="alert.create",
        resource_type="alert",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    db.commit()
    db.refresh(rec)
    return {"id": rec.id}


@router.post("/alerts/{alert_id}/toggle")
def toggle_alert(
    alert_id: str,
    payload: AlertRuleToggleRequest,
    db: DbSession,
    actor: AdminActor,
) -> dict:
    rec = db.get(AlertRule, alert_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Alert not found")
    rec.enabled = payload.enabled
    create_audit(
        db,
        actor=actor["actor"],
        action="alert.toggle",
        resource_type="alert",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    db.commit()
    db.refresh(rec)
    return {"ok": True, "id": rec.id, "enabled": rec.enabled}


@router.get("/audit")
def get_audit_logs(
    db: DbSession,
    _: CurrentActor,
    limit: int = Query(100, ge=1, le=500),
    resource_id: str | None = None,
    resource_type: str | None = None,
) -> dict:
    rows = list_audit_logs(
        db,
        limit=limit,
        resource_id=resource_id,
        resource_type=resource_type,
    )
    return {
        "items": [
            {
                "id": r.id,
                "actor": r.actor,
                "action": r.action,
                "resource_type": r.resource_type,
                "resource_id": r.resource_id,
                "details": r.details,
                "created_at": r.created_at,
            }
            for r in rows
        ]
    }


@router.get("/alerts/history")
def get_alert_history(
    db: DbSession,
    _: CurrentActor,
    alert_id: str | None = None,
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    query = (
        select(Incident)
        .where(Incident.alert_id.is_not(None))
        .order_by(Incident.created_at.desc())
    )
    if alert_id:
        query = query.where(Incident.alert_id == alert_id)
    rows = db.scalars(query.limit(limit)).all()
    return {
        "items": [
            {
                "id": row.id,
                "alert_id": row.alert_id,
                "title": row.title,
                "severity": row.severity,
                "status": row.status,
                "owner": row.owner,
                "created_at": row.created_at,
                "resolved_at": row.resolved_at,
            }
            for row in rows
        ]
    }
