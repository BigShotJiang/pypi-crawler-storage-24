"""Tool wrappers for pycatalyst mock data generation."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)


def create_catalyst_tools(schemas: dict[str, Any]) -> list[Any]:
    """Create pycatalyst tools pre-loaded with schema definitions.

    Args:
        schemas: Mapping of schema name to SchemaSpec objects.

    Returns:
        List of tool objects ready for registration.
    """

    @tool(
        name="generate_data",
        description=(
            "Generate mock data records using a named schema. "
            "Returns a list of dictionaries."
        ),
    )
    async def generate_data(
        schema_name: str,
        count: int = 10,
        seed: int | None = None,
    ) -> list[dict[str, Any]]:
        """Generate mock data from a registered schema.

        Args:
            schema_name: Name of the schema to use.
            count: Number of records to generate.
            seed: Optional random seed for reproducibility.

        Returns:
            List of generated records.
        """
        try:
            from pycatalyst.engine import GenerationEngine
        except ImportError as exc:
            raise RuntimeError(
                "pycatalyst is required: pip install pycatalyst"
            ) from exc

        if schema_name not in schemas:
            raise ValueError(
                f"Schema '{schema_name}' not found. Available: {list(schemas.keys())}"
            )

        engine = GenerationEngine(schema=schemas[schema_name], seed=seed)
        return engine.generate(count)

    @tool(
        name="build_schema",
        description=(
            "Build a pycatalyst SchemaSpec from field definitions. "
            "Returns a serializable schema dict."
        ),
    )
    async def build_schema(
        fields: dict[str, dict[str, Any]],
    ) -> dict[str, Any]:
        """Build a schema from field definitions.

        Args:
            fields: Mapping of field name to field config dicts
                with keys like 'type', 'min', 'max', etc.

        Returns:
            Serialized SchemaSpec dictionary.
        """
        try:
            from pycatalyst.schema import SchemaBuilder
        except ImportError as exc:
            raise RuntimeError(
                "pycatalyst is required: pip install pycatalyst"
            ) from exc

        builder = SchemaBuilder()
        for name, config in fields.items():
            builder.add_field(name, **config)
        return builder.build().to_dict()

    return [generate_data, build_schema]
