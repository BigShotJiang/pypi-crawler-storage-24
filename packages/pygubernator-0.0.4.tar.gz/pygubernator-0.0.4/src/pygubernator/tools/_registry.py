"""Tool registry for managing agent tools."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator._types import ToolResult
from pygubernator.errors import ToolError

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Registry for tools that agents can use.

    Manages tool registration, lookup, and execution. Tools must
    implement the Tool protocol (name, description, parameters_schema,
    execute).

    Example:
        >>> registry = ToolRegistry()
        >>> registry.register(my_tool)
        >>> result = await registry.execute("my_tool", {"param": "value"})
    """

    def __init__(self) -> None:
        self._tools: dict[str, Any] = {}

    def register(self, tool: Any) -> None:
        """Register a tool.

        Args:
            tool: Tool implementing the Tool protocol.

        Raises:
            ToolError: If a tool with the same name is already registered.
        """
        name = tool.name
        if name in self._tools:
            raise ToolError(
                f"Tool '{name}' is already registered",
                tool_name=name,
            )
        self._tools[name] = tool
        logger.debug("Registered tool: %s", name)

    def unregister(self, name: str) -> None:
        """Unregister a tool by name.

        Args:
            name: Name of the tool to remove.

        Raises:
            ToolError: If the tool is not registered.
        """
        if name not in self._tools:
            raise ToolError(
                f"Tool '{name}' not found",
                tool_name=name,
            )
        del self._tools[name]

    def get(self, name: str) -> Any:
        """Get a tool by name.

        Args:
            name: Tool name.

        Returns:
            The registered tool.

        Raises:
            ToolError: If the tool is not registered.
        """
        if name not in self._tools:
            raise ToolError(
                f"Tool '{name}' not found",
                tool_name=name,
            )
        return self._tools[name]

    def has(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._tools

    async def execute(self, name: str, params: dict[str, Any]) -> ToolResult:
        """Execute a tool by name.

        Args:
            name: Tool name.
            params: Parameters to pass to the tool.

        Returns:
            Result of the tool execution.
        """
        tool = self.get(name)
        try:
            result = await tool.execute(params)
            return result
        except Exception as exc:
            logger.error("Tool '%s' failed: %s", name, exc)
            return ToolResult(
                tool_name=name,
                success=False,
                output=None,
                error=str(exc),
            )

    def list_tools(self) -> list[str]:
        """List all registered tool names."""
        return list(self._tools.keys())

    def get_schemas(self) -> list[dict[str, Any]]:
        """Get parameter schemas for all registered tools.

        Returns:
            List of tool schema dicts with name, description,
            and parameters.
        """
        schemas: list[dict[str, Any]] = []
        for tool in self._tools.values():
            schemas.append(
                {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters_schema,
                }
            )
        return schemas

    def register_all(self, tools: list[Any]) -> None:
        """Register multiple tools at once.

        Args:
            tools: List of tools implementing the Tool protocol.

        Raises:
            ToolError: If any tool's name is already registered.
        """
        for t in tools:
            self.register(t)

    def register_module(self, module: Any) -> int:
        """Register all ``@tool``-decorated functions from a module.

        Scans ``dir(module)`` for ``_DecoratedTool`` instances and
        registers each one.

        Args:
            module: A Python module containing decorated tools.

        Returns:
            Number of tools registered from the module.
        """
        from pygubernator.tools._decorator import _DecoratedTool

        count = 0
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if isinstance(attr, _DecoratedTool):
                self.register(attr)
                count += 1
        return count

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools
