"""Tool wrappers for pycharter data contract validation."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)


def create_charter_tools(validators: dict[str, Any]) -> list[Any]:
    """Create pycharter validation tools pre-loaded with validators.

    Args:
        validators: Mapping of contract name to Validator objects.

    Returns:
        List of tool objects ready for registration.
    """

    @tool(
        name="validate_record",
        description=(
            "Validate a single record against a named data contract. "
            "Returns a validation result dict."
        ),
    )
    async def validate_record(
        record: dict[str, Any],
        contract_name: str,
    ) -> dict[str, Any]:
        """Validate a record against a data contract.

        Args:
            record: The data record to validate.
            contract_name: Name of the contract to validate against.

        Returns:
            Dict with 'valid' bool and 'errors' list.
        """
        if contract_name not in validators:
            raise ValueError(
                f"Contract '{contract_name}' not found. "
                f"Available: {list(validators.keys())}"
            )

        validator = validators[contract_name]
        result = validator.validate(record)
        return {
            "valid": result.is_valid,
            "errors": [e.to_dict() for e in result.errors],
        }

    @tool(
        name="validate_batch",
        description=(
            "Validate a batch of records against a named data contract. "
            "Returns summary statistics."
        ),
    )
    async def validate_batch(
        records: list[dict[str, Any]],
        contract_name: str,
    ) -> dict[str, Any]:
        """Validate a batch of records against a data contract.

        Args:
            records: List of data records to validate.
            contract_name: Name of the contract to validate against.

        Returns:
            Dict with total, valid_count, invalid_count, and errors.
        """
        if contract_name not in validators:
            raise ValueError(
                f"Contract '{contract_name}' not found. "
                f"Available: {list(validators.keys())}"
            )

        validator = validators[contract_name]
        total = len(records)
        valid_count = 0
        all_errors: list[dict[str, Any]] = []

        for i, record in enumerate(records):
            result = validator.validate(record)
            if result.is_valid:
                valid_count += 1
            else:
                for err in result.errors:
                    err_dict = err.to_dict()
                    err_dict["record_index"] = i
                    all_errors.append(err_dict)

        return {
            "total": total,
            "valid_count": valid_count,
            "invalid_count": total - valid_count,
            "errors": all_errors,
        }

    return [validate_record, validate_batch]
