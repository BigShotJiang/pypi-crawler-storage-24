"""Tool wrappers for pystator state machine interactions."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)


def create_stator_tools(
    machines: dict[str, Any],
) -> list[Any]:
    """Create pystator tools with access to registered state machines.

    The factory captures a session registry via closure so that
    tools can create and interact with entity sessions.

    Args:
        machines: Mapping of machine name to StateMachine objects.

    Returns:
        List of tool objects ready for registration.
    """
    # Session registry: entity_id -> EntitySession
    sessions: dict[str, Any] = {}

    @tool(
        name="create_session",
        description=(
            "Create a new pystator entity session for a state machine. "
            "Returns the initial state."
        ),
    )
    async def create_session(
        entity_id: str,
        machine_name: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new entity session.

        Args:
            entity_id: Unique identifier for the entity.
            machine_name: Name of the state machine to use.
            context: Optional initial context dict.

        Returns:
            Dict with entity_id and initial state.
        """
        if machine_name not in machines:
            raise ValueError(
                f"Machine '{machine_name}' not found. "
                f"Available: {list(machines.keys())}"
            )

        machine = machines[machine_name]
        session = machine.create(context=context or {})
        sessions[entity_id] = session
        return {
            "entity_id": entity_id,
            "state": session.current_state,
        }

    @tool(
        name="send_event",
        description=(
            "Send an event/trigger to a pystator entity session. "
            "Returns the transition result."
        ),
    )
    async def send_event(
        entity_id: str,
        trigger: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send an event to an entity session.

        Args:
            entity_id: The entity to send the event to.
            trigger: The event/trigger name.
            payload: Optional payload kwargs for the transition.

        Returns:
            Dict with success, previous_state, and current_state.
        """
        if entity_id not in sessions:
            raise ValueError(f"No session found for entity '{entity_id}'")

        session = sessions[entity_id]
        prev_state = session.current_state
        result = session.send(trigger, **(payload or {}))
        return {
            "success": result.success,
            "previous_state": prev_state,
            "current_state": session.current_state,
            "error": result.error if not result.success else None,
        }

    @tool(
        name="get_state",
        description=("Get the current state and context of a pystator entity."),
    )
    async def get_state(entity_id: str) -> dict[str, Any]:
        """Get current state of an entity.

        Args:
            entity_id: The entity to query.

        Returns:
            Dict with state and context.
        """
        if entity_id not in sessions:
            raise ValueError(f"No session found for entity '{entity_id}'")

        session = sessions[entity_id]
        return {
            "entity_id": entity_id,
            "state": session.current_state,
            "context": dict(session.context),
        }

    @tool(
        name="list_triggers",
        description=("List available triggers for an entity in its current state."),
    )
    async def list_triggers(entity_id: str) -> dict[str, Any]:
        """List available triggers for the entity's current state.

        Args:
            entity_id: The entity to query.

        Returns:
            Dict with state and available trigger names.
        """
        if entity_id not in sessions:
            raise ValueError(f"No session found for entity '{entity_id}'")

        session = sessions[entity_id]
        triggers = session.allowed_triggers
        return {
            "entity_id": entity_id,
            "state": session.current_state,
            "triggers": triggers,
        }

    return [create_session, send_event, get_state, list_triggers]
