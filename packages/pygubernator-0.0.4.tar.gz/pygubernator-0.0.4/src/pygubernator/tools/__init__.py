"""Tool system for pygubernator agents."""

from __future__ import annotations

from pygubernator.tools._decorator import tool
from pygubernator.tools._registry import ToolRegistry

__all__ = ["ToolRegistry", "tool"]
