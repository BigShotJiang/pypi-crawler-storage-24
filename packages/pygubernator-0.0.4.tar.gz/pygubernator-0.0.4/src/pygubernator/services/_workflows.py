"""Workflow execution service — business logic extracted from routes."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from pygubernator.workflow._registry import NodeTypeRegistry

logger = logging.getLogger(__name__)


def build_node_registry() -> NodeTypeRegistry:
    """Build a NodeTypeRegistry with all built-in node factories.

    Returns:
        Configured NodeTypeRegistry instance with all standard node types.
    """
    from pygubernator.workflow.nodes._code import CodeNodeFactory
    from pygubernator.workflow.nodes._condition import ConditionNodeFactory
    from pygubernator.workflow.nodes._input import InputNodeFactory
    from pygubernator.workflow.nodes._loop import LoopNodeFactory
    from pygubernator.workflow.nodes._map import MapNodeFactory
    from pygubernator.workflow.nodes._memory import MemoryNodeFactory
    from pygubernator.workflow.nodes._output import OutputNodeFactory
    from pygubernator.workflow.nodes._router import RouterNodeFactory
    from pygubernator.workflow.nodes._template import TemplateNodeFactory

    registry = NodeTypeRegistry()
    for name, factory_cls in [
        ("input", InputNodeFactory),
        ("output", OutputNodeFactory),
        ("template", TemplateNodeFactory),
        ("condition", ConditionNodeFactory),
        ("code", CodeNodeFactory),
        ("router", RouterNodeFactory),
        ("loop", LoopNodeFactory),
        ("map", MapNodeFactory),
        ("memory", MemoryNodeFactory),
    ]:
        registry.register(name, factory_cls())

    try:
        from pygubernator.workflow.nodes._http import HttpNodeFactory

        registry.register("http", HttpNodeFactory())
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._llm import LLMNodeFactory

        registry.register("llm", LLMNodeFactory(llm_provider=None))
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._agent import AgentNodeFactory

        registry.register("agent", AgentNodeFactory())
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._tool import ToolNodeFactory

        registry.register("tool", ToolNodeFactory())
    except ImportError:
        pass

    return registry


def execute_workflow(
    spec_json: dict[str, Any],
    input_json: dict[str, Any],
    db: Any,
    run_id: str,
) -> dict[str, Any]:
    """Build and execute a workflow spec, persisting step results.

    Args:
        spec_json: Workflow spec as a JSON dict.
        input_json: Input data for the workflow.
        db: SQLAlchemy session for step persistence.
        run_id: Workflow run ID for step association.

    Returns:
        Result dict with success, output, errors, and duration_ms.
    """
    from pygubernator.db.repositories import (
        create_workflow_step_run,
        update_workflow_step_run,
    )
    from pygubernator.workflow._engine import WorkflowEngine
    from pygubernator.workflow._types import NodeResult
    from pygubernator.workflow.config._loader import WorkflowLoader

    loader = WorkflowLoader()
    try:
        spec = loader.load_dict(spec_json)
    except Exception as exc:
        return {
            "success": False,
            "output": {},
            "errors": [f"Invalid spec: {exc}"],
            "duration_ms": 0,
        }

    registry = build_node_registry()

    def persist_step(node_id: str, result: NodeResult) -> None:
        """Persist a single step execution result."""
        node_spec = spec.nodes.get(node_id)
        node_type = node_spec.node_type if node_spec else "unknown"
        step = create_workflow_step_run(
            db,
            workflow_run_id=run_id,
            node_id=node_id,
            node_type=node_type,
            status=result.status.value,
            input_json={},
        )
        update_workflow_step_run(
            db,
            step,
            output_json=result.output,
            output_handle=result.output_handle,
            error_message=result.error,
        )

    engine = WorkflowEngine(spec=spec, registry=registry, persist_callback=persist_step)

    start = time.monotonic()
    try:
        wf_result = asyncio.run(engine.run(input_json))
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        return {
            "success": False,
            "output": {},
            "errors": [str(exc)],
            "duration_ms": elapsed,
        }

    elapsed = int((time.monotonic() - start) * 1000)
    return {
        "success": wf_result.success,
        "output": wf_result.output,
        "errors": wf_result.errors,
        "duration_ms": elapsed,
    }
