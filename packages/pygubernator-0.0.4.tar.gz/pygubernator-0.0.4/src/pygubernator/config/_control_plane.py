"""Control plane settings for optional API/DB/UI layers."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass

from pygubernator.config._helpers import _cfg
from pygubernator.config.auth import get_auth_jwt_secret
from pygubernator.config.database import get_database_url, get_default_sqlite_url
from pygubernator.config.ui import get_ui_app_name, get_ui_theme

logger = logging.getLogger(__name__)
_warned_default_jwt_secret = False


@dataclass
class ControlPlaneSettings:
    """Environment-driven settings for API, DB, and UI control-plane services."""

    api_host: str = "127.0.0.1"
    api_port: int = 8010
    ui_host: str = "127.0.0.1"
    ui_port: int = 3010
    api_url: str = "http://127.0.0.1:8010"
    database_url: str = "sqlite+pysqlite:///./pygubernator_control_plane.db"
    auth_token: str = "dev-token"
    auth_role: str = "admin"
    ui_theme: str = "light"
    ui_app_name: str = "PyGubernator"
    auth_jwt_secret: str = "change-me"
    event_retention_days: int = 30
    allow_origins: str = "*"

    @classmethod
    def from_env(cls) -> ControlPlaneSettings:
        global _warned_default_jwt_secret

        def _get(name: str, default: str) -> str:
            return os.getenv(
                f"PYGUBERNATOR_{name}",
                _cfg("control_plane", f"PYGUBERNATOR_{name}") or default,
            )

        settings = cls(
            api_host=_get("API_HOST", cls.api_host),
            api_port=int(_get("API_PORT", str(cls.api_port))),
            ui_host=_get("UI_HOST", cls.ui_host),
            ui_port=int(_get("UI_PORT", str(cls.ui_port))),
            api_url=_get("API_URL", cls.api_url),
            database_url=_get(
                "DATABASE_URL", get_database_url() or get_default_sqlite_url()
            ),
            auth_token=_get("AUTH_TOKEN", cls.auth_token),
            auth_role=_get("AUTH_ROLE", cls.auth_role),
            ui_theme=get_ui_theme(),
            ui_app_name=get_ui_app_name(),
            auth_jwt_secret=_get(
                "AUTH_JWT_SECRET", get_auth_jwt_secret() or cls.auth_jwt_secret
            ),
            event_retention_days=int(
                _get("EVENT_RETENTION_DAYS", str(cls.event_retention_days))
            ),
            allow_origins=_get("ALLOW_ORIGINS", cls.allow_origins),
        )
        if settings.auth_jwt_secret == "change-me" and not _warned_default_jwt_secret:
            logger.warning(
                "auth_jwt_secret is set to the default 'change-me' — "
                "set PYGUBERNATOR_AUTH_JWT_SECRET for production use"
            )
            _warned_default_jwt_secret = True
        return settings
