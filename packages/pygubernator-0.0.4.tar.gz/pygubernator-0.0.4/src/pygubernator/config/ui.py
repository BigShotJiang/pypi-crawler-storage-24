"""UI configuration accessors (theme, app name)."""

from __future__ import annotations

import os

from pygubernator.config._helpers import _cfg

_VALID_THEMES = (
    "light",
    "dark",
    "system",
    "ocean",
    "forest",
    "sunset",
    "high-contrast",
    "sepia",
    "violet",
    "cathay",
)


def get_ui_theme() -> str:
    raw = (
        os.getenv("PYGUBERNATOR_UI_THEME") or _cfg("ui", "PYGUBERNATOR_UI_THEME") or ""
    )
    value = raw.strip().lower()
    return value if value in _VALID_THEMES else "light"


def get_ui_app_name() -> str:
    raw = (
        os.getenv("PYGUBERNATOR_UI_APP_NAME")
        or _cfg("ui", "PYGUBERNATOR_UI_APP_NAME")
        or ""
    )
    return raw.strip() or "PyGubernator"
