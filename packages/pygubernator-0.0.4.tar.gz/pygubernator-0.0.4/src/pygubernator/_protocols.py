"""Protocol definitions for pluggable pygubernator components."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from pygubernator._types import Message, ToolResult

if TYPE_CHECKING:
    from pygubernator.llm._messages import LLMResponse


@runtime_checkable
class Tool(Protocol):
    """Protocol for executable tools that agents can invoke."""

    @property
    def name(self) -> str:
        """The unique name of the tool."""
        ...

    @property
    def description(self) -> str:
        """A human-readable description of what the tool does."""
        ...

    @property
    def parameters_schema(self) -> dict[str, Any]:
        """JSON Schema describing the tool's input parameters."""
        ...

    async def execute(self, params: dict[str, Any]) -> ToolResult:
        """Execute the tool with the given parameters.

        Args:
            params: Input parameters matching parameters_schema.

        Returns:
            The result of the tool execution.
        """
        ...


@runtime_checkable
class LLMProvider(Protocol):
    """Protocol for LLM provider integrations."""

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Send a chat completion request to the LLM.

        Args:
            messages: Conversation messages in OpenAI-compatible
                format.
            tools: Optional list of tool definitions available to
                the model.

        Returns:
            The LLM's response.
        """
        ...


@runtime_checkable
class Transport(Protocol):
    """Protocol for message transport layers (e.g., Kafka)."""

    async def consume(self, topic: str, max_messages: int = 1) -> list[Message]:
        """Consume messages from a topic.

        Args:
            topic: The topic to consume from.
            max_messages: Maximum number of messages to return.

        Returns:
            List of consumed messages.
        """
        ...

    async def produce(self, message: Message) -> None:
        """Produce a message to its designated topic.

        Args:
            message: The message to produce.
        """
        ...

    async def commit(self) -> None:
        """Commit consumed message offsets."""
        ...

    async def close(self) -> None:
        """Close the transport connection and release resources."""
        ...
