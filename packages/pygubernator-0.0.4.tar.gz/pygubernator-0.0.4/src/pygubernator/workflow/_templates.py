"""Jinja2 sandboxed template rendering for workflow nodes."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.errors import NodeError

logger = logging.getLogger(__name__)

try:
    from jinja2 import StrictUndefined
    from jinja2.sandbox import SandboxedEnvironment

    _HAS_JINJA2 = True
except ImportError:
    _HAS_JINJA2 = False


def _get_env() -> Any:
    """Create a sandboxed Jinja2 environment."""
    if not _HAS_JINJA2:
        raise NodeError(
            "jinja2 is required for template rendering. "
            "Install with: pip install pygubernator[workflow]",
            node_id="template",
        )
    return SandboxedEnvironment(undefined=StrictUndefined)


def render_template(template_str: str, context: dict[str, Any]) -> str:
    """Render a Jinja2 template string with the given context.

    Uses a sandboxed environment to prevent unsafe operations.

    Args:
        template_str: Jinja2 template string.
        context: Variables available in the template.

    Returns:
        Rendered string.

    Raises:
        NodeError: If jinja2 is not installed or rendering fails.
    """
    env = _get_env()
    try:
        template = env.from_string(template_str)
        return template.render(**context)
    except Exception as exc:
        raise NodeError(
            f"Template rendering failed: {exc}",
            node_id="template",
        ) from exc


def render_config_value(value: Any, context: dict[str, Any]) -> Any:
    """Recursively render Jinja2 templates in config values.

    Strings containing ``{{`` are treated as templates. Other types
    are passed through unchanged.

    Args:
        value: Config value (str, dict, list, or scalar).
        context: Variables available for template rendering.

    Returns:
        Value with any template strings rendered.
    """
    if isinstance(value, str) and "{{" in value:
        return render_template(value, context)
    if isinstance(value, dict):
        return {k: render_config_value(v, context) for k, v in value.items()}
    if isinstance(value, list):
        return [render_config_value(item, context) for item in value]
    return value
