"""DAG-based workflow execution engine."""

from __future__ import annotations

import asyncio
import enum
import logging
import time
from collections.abc import Callable
from typing import Any

import networkx as nx

from pygubernator._events import AgentEvent, AgentEventType, EventBus
from pygubernator.errors import ExecutionError
from pygubernator.workflow._context import build_node_context, merge_upstream_outputs
from pygubernator.workflow._expressions import evaluate_condition
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import (
    NodeResult,
    NodeStatus,
    WorkflowResult,
    WorkflowSpec,
)

logger = logging.getLogger(__name__)


class ExecutionMode(enum.Enum):
    """Workflow execution mode."""

    FULL = "full"
    DRY_RUN = "dry_run"
    STEP = "step"


class WorkflowEngine:
    """Execute a workflow spec as a DAG using topological-level scheduling.

    Resolves execution order via NetworkX, runs nodes concurrently per
    topological level, handles conditional routing and fan-in/fan-out.

    Args:
        spec: The workflow specification to execute.
        registry: Registry of node type factories.
        event_bus: Optional event bus for observability.
        mode: Execution mode (full, dry_run, or step).
    """

    def __init__(
        self,
        spec: WorkflowSpec,
        registry: NodeTypeRegistry,
        event_bus: EventBus | None = None,
        mode: ExecutionMode = ExecutionMode.FULL,
        persist_callback: Callable[[str, NodeResult], None] | None = None,
    ) -> None:
        self._spec = spec
        self._registry = registry
        self._event_bus = event_bus
        self._mode = mode
        self._persist_callback = persist_callback

    async def run(
        self,
        input_data: dict[str, Any],
        variables: dict[str, Any] | None = None,
    ) -> WorkflowResult:
        """Execute the workflow.

        Args:
            input_data: Initial input data for the workflow.
            variables: Shared variables accessible by all nodes.

        Returns:
            Aggregate result with per-node results and final output.

        Raises:
            ExecutionError: If the graph contains cycles or is invalid.
        """
        variables = dict(variables or {})
        graph = self._build_graph()
        self._validate_dag(graph)
        nodes = self._instantiate_nodes()

        if self._mode == ExecutionMode.DRY_RUN:
            return WorkflowResult(
                name=self._spec.name,
                success=True,
                node_results={},
                output={},
                errors=[],
            )

        await self._emit(
            AgentEventType.WORKFLOW_STARTED,
            {"workflow": self._spec.name, "mode": self._mode.value},
        )

        node_results: dict[str, NodeResult] = {}
        active_edges: set[str] = {e.edge_id for e in self._spec.edges}
        active_nodes: set[str] = set(self._spec.nodes)
        errors: list[str] = []

        for level in nx.topological_generations(graph):
            level_results = await self._execute_level(
                level=list(level),
                graph=graph,
                nodes=nodes,
                node_results=node_results,
                active_edges=active_edges,
                active_nodes=active_nodes,
                input_data=input_data,
                variables=variables,
            )
            node_results.update(level_results)

            for nid, result in level_results.items():
                if result.status == NodeStatus.FAILED:
                    errors.append(f"Node '{nid}' failed: {result.error}")

        output = self._collect_outputs(node_results)
        success = len(errors) == 0

        await self._emit(
            AgentEventType.WORKFLOW_COMPLETED,
            {"workflow": self._spec.name, "success": success},
        )

        return WorkflowResult(
            name=self._spec.name,
            success=success,
            node_results=node_results,
            output=output,
            errors=errors,
        )

    def _build_graph(self) -> nx.DiGraph:
        """Build a NetworkX DiGraph from the workflow spec."""
        graph = nx.DiGraph()
        for node_id in self._spec.nodes:
            graph.add_node(node_id)
        for edge in self._spec.edges:
            graph.add_edge(
                edge.source_id,
                edge.target_id,
                edge_id=edge.edge_id,
                source_handle=edge.source_handle,
                condition=edge.condition,
            )
        return graph

    def _validate_dag(self, graph: nx.DiGraph) -> None:
        """Raise ExecutionError if the graph has cycles."""
        if not nx.is_directed_acyclic_graph(graph):
            cycles = list(nx.simple_cycles(graph))
            raise ExecutionError(
                f"Workflow contains cycles: {cycles}",
                workflow_name=self._spec.name,
            )

    def _instantiate_nodes(self) -> dict[str, Any]:
        """Create node instances from the registry."""
        instances: dict[str, Any] = {}
        for node_id, node_spec in self._spec.nodes.items():
            instances[node_id] = self._registry.create(
                node_id=node_id,
                type_name=node_spec.node_type,
                config=node_spec.config,
            )
        return instances

    async def _execute_level(
        self,
        level: list[str],
        graph: nx.DiGraph,
        nodes: dict[str, Any],
        node_results: dict[str, NodeResult],
        active_edges: set[str],
        active_nodes: set[str],
        input_data: dict[str, Any],
        variables: dict[str, Any],
    ) -> dict[str, NodeResult]:
        """Execute all nodes at one topological level concurrently."""
        tasks: list[tuple[str, asyncio.Task[NodeResult]]] = []

        for node_id in level:
            if node_id not in active_nodes:
                continue

            # Start with workflow input as baseline, overlay upstream
            merged = dict(input_data)
            upstream = merge_upstream_outputs(
                node_id,
                graph,
                node_results,
                active_edges,
            )
            merged.update(upstream)

            node_spec = self._spec.nodes[node_id]
            ctx = build_node_context(
                node_id=node_id,
                input_data=merged,
                variables=variables,
                config=node_spec.config,
            )

            task = asyncio.create_task(
                self._execute_node(node_id, nodes[node_id], ctx),
            )
            tasks.append((node_id, task))

        results: dict[str, NodeResult] = {}

        for node_id in level:
            if node_id not in active_nodes:
                results[node_id] = NodeResult(
                    node_id=node_id,
                    status=NodeStatus.SKIPPED,
                )
                # Deactivate all outgoing edges of skipped nodes
                for _, target_id, data in graph.out_edges(node_id, data=True):
                    active_edges.discard(data["edge_id"])
                    self._deactivate_unreachable(
                        target_id,
                        graph,
                        active_nodes,
                        active_edges,
                    )

        for node_id, task in tasks:
            result = await task
            results[node_id] = result

            if result.status == NodeStatus.SUCCESS:
                self._evaluate_outgoing_edges(
                    node_id,
                    result,
                    graph,
                    active_edges,
                    active_nodes,
                )

        return results

    async def _execute_node(
        self,
        node_id: str,
        node: Any,
        ctx: Any,
    ) -> NodeResult:
        """Execute a single node with event emission."""
        await self._emit(
            AgentEventType.WORKFLOW_NODE_STARTED,
            {"node_id": node_id},
        )

        try:
            result = await node.execute(ctx)
        except Exception as exc:
            logger.error("Node %s raised: %s", node_id, exc)
            result = NodeResult(
                node_id=node_id,
                status=NodeStatus.FAILED,
                error=str(exc),
            )

        event_type = (
            AgentEventType.WORKFLOW_NODE_COMPLETED
            if result.status != NodeStatus.FAILED
            else AgentEventType.WORKFLOW_NODE_FAILED
        )
        await self._emit(event_type, {"node_id": node_id})

        if self._persist_callback is not None:
            try:
                self._persist_callback(node_id, result)
            except Exception:
                logger.warning("persist_callback failed for node %s", node_id)

        return result

    def _evaluate_outgoing_edges(
        self,
        source_id: str,
        result: NodeResult,
        graph: nx.DiGraph,
        active_edges: set[str],
        active_nodes: set[str],
    ) -> None:
        """Evaluate outgoing edges after a node completes."""
        for _, target_id, data in graph.out_edges(source_id, data=True):
            edge_id: str = data["edge_id"]
            if not self._evaluate_edge(data, result):
                active_edges.discard(edge_id)
                self._deactivate_unreachable(
                    target_id,
                    graph,
                    active_nodes,
                    active_edges,
                )

    def _evaluate_edge(
        self,
        edge_data: dict[str, Any],
        source_result: NodeResult,
    ) -> bool:
        """Check if an edge is active given the source result."""
        source_handle = edge_data.get("source_handle", "default")
        if source_result.output_handle != source_handle:
            return False

        condition = edge_data.get("condition")
        if condition:
            namespace = dict(source_result.output)
            try:
                return evaluate_condition(condition, namespace)
            except Exception:
                logger.warning(
                    "Edge condition evaluation failed: %s",
                    condition,
                )
                return False

        return True

    def _deactivate_unreachable(
        self,
        target_id: str,
        graph: nx.DiGraph,
        active_nodes: set[str],
        active_edges: set[str],
    ) -> None:
        """Deactivate a node only if ALL its incoming edges are inactive."""
        for pred in graph.predecessors(target_id):
            edge_data = graph.edges[pred, target_id]
            edge_id: str = edge_data["edge_id"]
            if edge_id in active_edges:
                return
        active_nodes.discard(target_id)

    def _collect_outputs(
        self,
        node_results: dict[str, NodeResult],
    ) -> dict[str, Any]:
        """Collect output from output-type nodes."""
        output: dict[str, Any] = {}
        for node_id, node_spec in self._spec.nodes.items():
            if node_spec.node_type == "output":
                result = node_results.get(node_id)
                if result and result.status == NodeStatus.SUCCESS:
                    output.update(result.output)
        return output

    async def _emit(
        self,
        event_type: AgentEventType,
        data: dict[str, Any],
    ) -> None:
        """Emit an event if an event bus is configured."""
        if self._event_bus is None:
            return
        event = AgentEvent(
            event_type=event_type,
            agent_id=self._spec.name,
            timestamp=time.time(),
            data=data,
        )
        await self._event_bus.emit(event)
