"""Convert Pydantic workflow config models to frozen WorkflowSpec."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._types import EdgeSpec, NodeSpec, WorkflowSpec
from pygubernator.workflow.config._models import WorkflowConfig

logger = logging.getLogger(__name__)

_SUB_NODE_PREFIXES = ("chat_model_",)
_SUB_NODE_TYPES = {"memory", "tool"}
_PARENT_TYPES = {"llm", "agent"}


def workflow_config_to_spec(config: WorkflowConfig) -> WorkflowSpec:
    """Transform a validated WorkflowConfig into a frozen WorkflowSpec.

    Resolves UI sub-nodes (``chat_model_*``, ``memory``, ``tool``)
    by merging their config into parent ``llm``/``agent`` nodes and
    removing them from the spec. Also validates graph integrity.

    Args:
        config: Validated Pydantic workflow config.

    Returns:
        Frozen WorkflowSpec ready for the execution engine.

    Raises:
        ConfigError: If the config has invalid references.
    """
    # Build mutable nodes and edges
    raw_nodes: dict[str, dict[str, Any]] = {
        nid: {
            "type": ndef.type,
            "config": dict(ndef.config),
            "position": (ndef.position.x, ndef.position.y),
        }
        for nid, ndef in config.nodes.items()
    }
    raw_edges = list(config.edges)

    # Resolve sub-nodes into parent nodes
    raw_nodes, raw_edges = _resolve_sub_nodes(raw_nodes, raw_edges)

    # Convert to frozen specs
    nodes = {
        nid: NodeSpec(
            node_id=nid,
            node_type=n["type"],
            config=n["config"],
            position=n["position"],
        )
        for nid, n in raw_nodes.items()
    }

    edges: list[EdgeSpec] = []
    referenced_nodes: set[str] = set()

    for idx, edef in enumerate(raw_edges):
        edge_id = f"edge_{idx}"
        referenced_nodes.add(edef.source)
        referenced_nodes.add(edef.target)

        edges.append(
            EdgeSpec(
                edge_id=edge_id,
                source_id=edef.source,
                target_id=edef.target,
                source_handle=edef.source_handle,
                target_handle=edef.target_handle,
                condition=edef.condition,
            )
        )

    orphaned = set(raw_nodes.keys()) - referenced_nodes
    if orphaned:
        logger.warning("Orphaned nodes (not referenced by any edge): %s", orphaned)

    _check_graph_connectivity(nodes, edges)

    return WorkflowSpec(
        name=config.meta.name,
        version=config.meta.version,
        description=config.meta.description,
        nodes=nodes,
        edges=tuple(edges),
    )


def _is_sub_node_type(node_type: str) -> bool:
    """Check if a node type is a UI sub-node."""
    if node_type in _SUB_NODE_TYPES:
        return True
    return any(node_type.startswith(p) for p in _SUB_NODE_PREFIXES)


def _resolve_sub_nodes(
    nodes: dict[str, dict[str, Any]],
    edges: list[Any],
) -> tuple[dict[str, dict[str, Any]], list[Any]]:
    """Merge sub-node configs into parent nodes and remove them.

    Sub-nodes (``chat_model_*``, ``memory``, ``tool``) are UI
    abstractions. When connected to a parent ``llm``/``agent`` node
    via a ``sub:*`` edge, their config is merged into the parent
    and they are removed from the spec.

    Args:
        nodes: Mutable node dict.
        edges: Edge definitions.

    Returns:
        Updated (nodes, edges) with sub-nodes resolved.
    """
    sub_node_ids: set[str] = set()
    sub_edges: set[int] = set()

    for idx, edge in enumerate(edges):
        target_handle = getattr(edge, "target_handle", "default")
        source_id = edge.source
        target_id = edge.target
        source_node = nodes.get(source_id)
        target_node = nodes.get(target_id)

        if not source_node or not target_node:
            continue

        source_type = source_node["type"]
        target_type = target_node["type"]

        # Match sub-node edges by either:
        # 1. target_handle starts with "sub:" (explicit UI connection)
        # 2. source is a sub-node type AND target is a parent type
        is_sub_edge = target_handle.startswith("sub:")
        is_type_match = _is_sub_node_type(source_type) and target_type in _PARENT_TYPES
        if not is_sub_edge and not is_type_match:
            continue

        # Merge sub-node config into parent
        sub_config = source_node["config"]
        parent_config = target_node["config"]

        if source_type.startswith("chat_model_"):
            # Merge provider config fields into parent
            for key in (
                "model_name",
                "model",
                "api_key",
                "api_base",
                "base_url",
                "temperature",
                "max_tokens",
                "top_p",
                "top_k",
            ):
                if key in sub_config:
                    parent_config[key] = sub_config[key]
            # Ollama UI may show a default base URL without persisting it until the
            # user edits the field. Without base_url, create_provider() falls through
            # to LiteLLM with model=qwen3:14b (invalid). OpenAI-compat needs .../v1.
            if source_type == "chat_model_ollama" and not (
                parent_config.get("base_url") or parent_config.get("api_base")
            ):
                parent_config["base_url"] = "http://localhost:11434/v1"
            logger.debug(
                "Merged chat_model config from '%s' into '%s'",
                source_id,
                target_id,
            )
        elif source_type == "memory":
            parent_config["memory"] = sub_config
            logger.debug(
                "Merged memory config from '%s' into '%s'",
                source_id,
                target_id,
            )
        elif source_type == "tool":
            # Accumulate tool configs
            existing_tools = parent_config.get("tools", {})
            tool_name = sub_config.get("name", source_id)
            existing_tools[tool_name] = {
                k: v for k, v in sub_config.items() if k != "name"
            }
            parent_config["tools"] = existing_tools
            logger.debug(
                "Merged tool config from '%s' into '%s'",
                source_id,
                target_id,
            )

        sub_node_ids.add(source_id)
        sub_edges.add(idx)

    # Remove sub-nodes and their edges
    for nid in sub_node_ids:
        del nodes[nid]

    remaining_edges = [e for idx, e in enumerate(edges) if idx not in sub_edges]
    # Also remove any other edges referencing removed sub-nodes
    remaining_edges = [
        e
        for e in remaining_edges
        if e.source not in sub_node_ids and e.target not in sub_node_ids
    ]

    if sub_node_ids:
        logger.info(
            "Resolved %d sub-node(s) into parent nodes: %s",
            len(sub_node_ids),
            sub_node_ids,
        )

    return nodes, remaining_edges


def _check_graph_connectivity(
    nodes: dict[str, NodeSpec],
    edges: list[EdgeSpec],
) -> None:
    """Check graph connectivity and warn about issues."""
    input_nodes = [n for n in nodes.values() if n.node_type == "input"]
    output_nodes = [n for n in nodes.values() if n.node_type == "output"]

    if not input_nodes:
        logger.warning("Workflow has no input nodes")
    if not output_nodes:
        logger.warning("Workflow has no output nodes")

    # Check that output nodes have at least one incoming edge
    targets = {e.target_id for e in edges}
    for output_node in output_nodes:
        if output_node.node_id not in targets:
            logger.warning(
                "Output node '%s' has no incoming edges",
                output_node.node_id,
            )

    # Check that input nodes have at least one outgoing edge
    sources = {e.source_id for e in edges}
    for input_node in input_nodes:
        if input_node.node_id not in sources:
            logger.warning(
                "Input node '%s' has no outgoing edges",
                input_node.node_id,
            )
