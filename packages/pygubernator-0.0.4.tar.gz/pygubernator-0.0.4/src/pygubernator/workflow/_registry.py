"""Node type registry for workflow node management."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.errors import NodeError
from pygubernator.workflow._protocols import Node, NodeFactory

logger = logging.getLogger(__name__)


class NodeTypeRegistry:
    """Registry for workflow node types.

    Manages registration and lookup of node factories by type name.
    Mirrors the ToolRegistry pattern from ``tools/_registry.py``.

    Example:
        >>> registry = NodeTypeRegistry()
        >>> registry.register("template", TemplateNodeFactory())
        >>> node = registry.create("node_1", "template", {"template": "Hello"})
    """

    def __init__(self) -> None:
        self._factories: dict[str, NodeFactory] = {}

    def register(self, type_name: str, factory: NodeFactory) -> None:
        """Register a node factory for a given type name.

        Args:
            type_name: Node type identifier (e.g. "template").
            factory: Factory that creates node instances.

        Raises:
            NodeError: If the type name is already registered.
        """
        if type_name in self._factories:
            raise NodeError(
                f"Node type '{type_name}' is already registered",
                node_id=type_name,
            )
        self._factories[type_name] = factory
        logger.debug("Registered node type: %s", type_name)

    def unregister(self, type_name: str) -> None:
        """Remove a registered node type.

        Args:
            type_name: Node type to remove.

        Raises:
            NodeError: If the type name is not registered.
        """
        if type_name not in self._factories:
            raise NodeError(
                f"Node type '{type_name}' not found",
                node_id=type_name,
            )
        del self._factories[type_name]

    def get(self, type_name: str) -> NodeFactory:
        """Get a node factory by type name.

        Args:
            type_name: Node type identifier.

        Returns:
            The registered node factory.

        Raises:
            NodeError: If the type name is not registered.
        """
        if type_name not in self._factories:
            raise NodeError(
                f"Node type '{type_name}' not found. "
                f"Available: {sorted(self._factories.keys())}",
                node_id=type_name,
            )
        return self._factories[type_name]

    def has(self, type_name: str) -> bool:
        """Check if a node type is registered."""
        return type_name in self._factories

    def create(
        self,
        node_id: str,
        type_name: str,
        config: dict[str, Any] | None = None,
    ) -> Node:
        """Create a node instance by type name.

        Args:
            node_id: Unique node identifier.
            type_name: Node type to create.
            config: Node-specific configuration.

        Returns:
            Configured node instance.

        Raises:
            NodeError: If the type name is not registered.
        """
        factory = self.get(type_name)
        return factory.create(node_id, config or {})

    def list_types(self) -> list[str]:
        """List all registered node type names."""
        return sorted(self._factories.keys())

    def __len__(self) -> int:
        return len(self._factories)

    def __contains__(self, type_name: str) -> bool:
        return type_name in self._factories
