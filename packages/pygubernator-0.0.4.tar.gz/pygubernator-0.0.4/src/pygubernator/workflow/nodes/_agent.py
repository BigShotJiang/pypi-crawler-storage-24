"""Autonomous LLM agent workflow node with tool calling."""

from __future__ import annotations

import importlib
import logging
from typing import Any

from pygubernator.workflow._templates import render_template
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

try:
    from pygubernator._types import Message
    from pygubernator.agents import LLMAgent
    from pygubernator.tools import ToolRegistry

    _HAS_AGENT = True
except ImportError:
    _HAS_AGENT = False


class AgentNode(AbstractNode):
    """Autonomous LLM agent with dynamic tool loading.

    Wraps ``LLMAgent`` with a provider created from config and tools
    loaded via importlib. Runs a think-act-observe loop.

    Config:
        model: Model identifier (e.g. ``ollama/llama3.1``, ``gpt-4o``).
        api_base: Optional server URL for OpenAI-compatible providers.
        api_key: Optional API key.
        system_prompt: System prompt for the agent.
        prompt_template: Jinja2 template for the user message.
        max_iterations: Max tool-calling loop iterations (default: 10).
        max_tokens: Max tokens per LLM response (default: 4096).
        temperature: Sampling temperature (default: 0.0).
        tools: Dict of tool references, each with ``module`` and
            ``function`` keys.
    """

    node_type = "agent"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the agent with tool calling.

        Args:
            context: Execution context with input data.

        Returns:
            Result with the agent's final response.
        """
        if not _HAS_AGENT:
            return self._failure(
                "Agent dependencies not available. "
                "Install with: pip install pygubernator[llm]"
            )

        prompt_template = (
            self._config.get("prompt_template")
            or self._config.get("task_description")
            or ""
        )

        # Resolve LLM provider from config
        provider = self._resolve_provider()
        if provider is None:
            return self._failure("No model configured. Set 'model' in agent config.")

        # Load tools from config
        registry = self._load_tools()

        system_prompt = self._config.get("system_prompt", "")
        max_iterations = self._config.get("max_iterations", 10)

        template_ctx = {**context.variables, **context.input_data}
        try:
            if prompt_template:
                prompt = render_template(prompt_template, template_ctx)
            else:
                prompt = str(
                    context.input_data.get("message", "")
                    or context.input_data.get("prompt", "")
                    or context.input_data.get("query", "")
                )
        except Exception as exc:
            return self._failure(f"Prompt template error: {exc}")

        if not prompt:
            return self._failure(
                "No prompt available. Set a task description or "
                "provide a 'message' input."
            )

        try:
            agent = LLMAgent(
                agent_id=f"agent_node_{self._node_id}",
                llm_provider=provider,
                tool_registry=registry if len(registry) > 0 else None,
                system_prompt=system_prompt,
                max_iterations=max_iterations,
            )

            message = Message(
                topic="workflow",
                payload={"content": prompt, **context.input_data},
            )
            result = await agent.process(message)
        except Exception as exc:
            logger.error("Agent node %s failed: %s", self._node_id, exc)
            return self._failure(f"Agent execution failed: {exc}")

        if not result.success:
            errors = "; ".join(result.errors) if result.errors else "Unknown error"
            return self._failure(f"Agent LLM call failed: {errors}")

        response = result.metadata.get("response", "")
        tool_results = result.metadata.get("tool_results", [])

        return self._success(
            {
                "response": response,
                "tool_results": tool_results,
                "iterations": result.metadata.get("iterations", 0),
            }
        )

    def _resolve_provider(self) -> Any | None:
        """Create an LLM provider from config fields."""
        model = self._config.get("model_name") or self._config.get("model")
        if not model:
            return None

        try:
            from pygubernator.llm._factory import create_provider

            return create_provider(
                model=model,
                api_base=(self._config.get("base_url") or self._config.get("api_base")),
                api_key=self._config.get("api_key"),
                max_tokens=self._config.get("max_tokens", 4096),
                temperature=self._config.get("temperature", 0.0),
            )
        except Exception:
            logger.warning("Could not create provider for model '%s'", model)
            return None

    def _load_tools(self) -> ToolRegistry:
        """Load tools from config's tools dict."""
        registry = ToolRegistry()
        tools_config = self._config.get("tools", {})
        if not isinstance(tools_config, dict):
            return registry

        for tool_name, tool_spec in tools_config.items():
            if not isinstance(tool_spec, dict):
                logger.warning("Tool '%s' has invalid spec, skipping", tool_name)
                continue

            module_path = tool_spec.get("module", "")
            func_name = tool_spec.get("function", "")
            if not module_path or not func_name:
                logger.warning(
                    "Tool '%s' missing module/function, skipping",
                    tool_name,
                )
                continue

            try:
                module = importlib.import_module(module_path)
                func = getattr(module, func_name)
                registry.register(func)
                logger.debug(
                    "Loaded tool '%s' from %s.%s",
                    tool_name,
                    module_path,
                    func_name,
                )
            except (ImportError, AttributeError) as exc:
                logger.warning("Failed to load tool '%s': %s", tool_name, exc)

        return registry


class AgentNodeFactory:
    """Factory for creating AgentNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> AgentNode:
        """Create an AgentNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured AgentNode instance.
        """
        return AgentNode(node_id=node_id, config=config)
