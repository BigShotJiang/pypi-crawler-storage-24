"""Built-in workflow node types."""

from __future__ import annotations

from pygubernator.workflow.nodes._base import AbstractNode
from pygubernator.workflow.nodes._code import CodeNode, CodeNodeFactory
from pygubernator.workflow.nodes._condition import (
    ConditionNode,
    ConditionNodeFactory,
)
from pygubernator.workflow.nodes._input import InputNode, InputNodeFactory
from pygubernator.workflow.nodes._loop import LoopNode, LoopNodeFactory
from pygubernator.workflow.nodes._map import MapNode, MapNodeFactory
from pygubernator.workflow.nodes._memory import MemoryNode, MemoryNodeFactory
from pygubernator.workflow.nodes._output import OutputNode, OutputNodeFactory
from pygubernator.workflow.nodes._router import RouterNode, RouterNodeFactory
from pygubernator.workflow.nodes._template import (
    TemplateNode,
    TemplateNodeFactory,
)

__all__ = [
    "AbstractNode",
    "CodeNode",
    "CodeNodeFactory",
    "ConditionNode",
    "ConditionNodeFactory",
    "InputNode",
    "InputNodeFactory",
    "LoopNode",
    "LoopNodeFactory",
    "MapNode",
    "MapNodeFactory",
    "MemoryNode",
    "MemoryNodeFactory",
    "OutputNode",
    "OutputNodeFactory",
    "RouterNode",
    "RouterNodeFactory",
    "TemplateNode",
    "TemplateNodeFactory",
]

# HTTP node is optional (requires httpx)
try:
    from pygubernator.workflow.nodes._http import HttpNode, HttpNodeFactory

    __all__ += ["HttpNode", "HttpNodeFactory"]
except ImportError:
    pass

# LLM node is optional (requires [llm] extra)
try:
    from pygubernator.workflow.nodes._llm import LLMNode, LLMNodeFactory

    __all__ += ["LLMNode", "LLMNodeFactory"]
except ImportError:
    pass
