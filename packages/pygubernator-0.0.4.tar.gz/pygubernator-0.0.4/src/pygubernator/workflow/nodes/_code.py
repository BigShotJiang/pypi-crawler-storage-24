"""Sandboxed Python code execution workflow node."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

_FORBIDDEN_NAMES = frozenset(
    {
        "__import__",
        "exec",
        "eval",
        "compile",
        "open",
        "getattr",
        "setattr",
        "delattr",
        "globals",
        "locals",
        "vars",
        "dir",
        "type",
        "breakpoint",
        "__builtins__",
    }
)

_MAX_CODE_LENGTH = 5000


class CodeNode(AbstractNode):
    """Executes a Python code snippet in a restricted namespace.

    The code has access to ``input_data`` and ``variables`` dicts,
    and must assign results to the ``output`` dict.

    Config:
        code: Python code string (required).
    """

    node_type = "code"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the configured code snippet.

        Args:
            context: Execution context with input data.

        Returns:
            Result with output dict populated by the code.
        """
        code_str = self._config.get("code", "")

        if not code_str:
            return self._failure("No code configured")

        if len(code_str) > _MAX_CODE_LENGTH:
            return self._failure(f"Code exceeds max length of {_MAX_CODE_LENGTH}")

        for name in _FORBIDDEN_NAMES:
            if name in code_str:
                return self._failure(f"Forbidden construct in code: '{name}'")

        output: dict[str, Any] = {}
        namespace: dict[str, Any] = {
            "__builtins__": {},
            "input_data": dict(context.input_data),
            "variables": dict(context.variables),
            "output": output,
            "len": len,
            "str": str,
            "int": int,
            "float": float,
            "bool": bool,
            "list": list,
            "dict": dict,
            "tuple": tuple,
            "set": set,
            "sorted": sorted,
            "reversed": reversed,
            "enumerate": enumerate,
            "zip": zip,
            "range": range,
            "min": min,
            "max": max,
            "sum": sum,
            "abs": abs,
            "round": round,
            "isinstance": isinstance,
            "any": any,
            "all": all,
        }

        try:
            compiled = compile(code_str, "<workflow_code>", "exec")
            exec(compiled, namespace)  # noqa: S102
        except Exception as exc:
            logger.error("Code node %s failed: %s", self._node_id, exc)
            return self._failure(f"Code execution failed: {exc}")

        return self._success(output)


class CodeNodeFactory:
    """Factory for creating CodeNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> CodeNode:
        """Create a CodeNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured CodeNode instance.
        """
        return CodeNode(node_id=node_id, config=config)
