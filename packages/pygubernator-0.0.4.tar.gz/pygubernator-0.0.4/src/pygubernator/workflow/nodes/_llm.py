"""LLM integration workflow node."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._templates import render_template
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

try:
    from pygubernator._types import Message
    from pygubernator.agents import LLMAgent
    from pygubernator.tools import ToolRegistry

    _HAS_LLM = True
except ImportError:
    _HAS_LLM = False


class LLMNode(AbstractNode):
    """Sends a prompt to an LLM and returns the response.

    Wraps LLMAgent: NodeContext.input_data → Message → agent.process()
    → AgentResult.metadata["response"] → NodeResult.output["response"].

    Config:
        system_prompt: System prompt for the LLM (optional).
        prompt_template: Jinja2 template for the user prompt (required).
        model: Model identifier override (optional).
        max_iterations: Max tool-calling iterations (default: 5).
    """

    node_type = "llm"

    def __init__(
        self,
        node_id: str,
        config: dict[str, Any],
        llm_provider: Any,
        tool_registry: Any | None = None,
    ) -> None:
        super().__init__(node_id, config)
        self._llm_provider = llm_provider
        self._tool_registry = tool_registry

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the LLM prompt.

        Args:
            context: Execution context with input data.

        Returns:
            Result with the LLM response.
        """
        if not _HAS_LLM:
            return self._failure(
                "LLM dependencies not available. "
                "Install with: pip install pygubernator[llm]"
            )

        prompt_template = self._config.get("prompt_template", "")
        if not prompt_template:
            return self._failure("No prompt_template configured")

        system_prompt = self._config.get("system_prompt", "")
        max_iterations = self._config.get("max_iterations", 5)

        template_ctx = {**context.variables, **context.input_data}
        try:
            prompt = render_template(prompt_template, template_ctx)
        except Exception as exc:
            return self._failure(f"Prompt template error: {exc}")

        # Read memory history from upstream MemoryNode (if connected)
        memory_history = context.input_data.get("__memory_history__")
        memory_node_id = context.input_data.get("__memory_node_id__")

        try:
            agent = LLMAgent(
                agent_id=f"llm_node_{self._node_id}",
                llm_provider=self._llm_provider,
                tool_registry=self._tool_registry or ToolRegistry(),
                system_prompt=system_prompt,
                max_iterations=max_iterations,
            )

            message = Message(
                topic="workflow",
                payload={"content": prompt, **context.input_data},
            )
            result = await agent.process(message, history=memory_history)
        except Exception as exc:
            logger.error("LLM node %s failed: %s", self._node_id, exc)
            return self._failure(f"LLM execution failed: {exc}")

        response = result.metadata.get("response", "")

        # Write exchange back to memory store (if connected)
        if memory_node_id:
            stores = context.variables.get("__memory_stores__", {})
            store = stores.get(memory_node_id)
            if store is not None:
                store.add_messages(
                    [
                        {"role": "user", "content": prompt},
                        {"role": "assistant", "content": response},
                    ]
                )

        return self._success({"response": response})


class LLMNodeFactory:
    """Factory for creating LLMNode instances with injected provider.

    Args:
        llm_provider: LLM provider instance.
        tool_registry: Optional tool registry for agent tool calls.
    """

    def __init__(
        self,
        llm_provider: Any,
        tool_registry: Any | None = None,
    ) -> None:
        self._llm_provider = llm_provider
        self._tool_registry = tool_registry

    def create(self, node_id: str, config: dict[str, Any]) -> LLMNode:
        """Create an LLMNode.

        If no provider was injected and the config contains provider
        settings (from a connected chat_model sub-node), auto-creates
        a provider via ``create_provider``.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured LLMNode instance.
        """
        provider = self._llm_provider
        if provider is None:
            provider = self._resolve_provider_from_config(config)

        return LLMNode(
            node_id=node_id,
            config=config,
            llm_provider=provider,
            tool_registry=self._tool_registry,
        )

    @staticmethod
    def _resolve_provider_from_config(
        config: dict[str, Any],
    ) -> Any | None:
        """Try to create a provider from node config fields."""
        model = config.get("model_name") or config.get("model")
        if not model:
            return None

        try:
            from pygubernator.llm._factory import create_provider

            return create_provider(
                model=model,
                api_base=(config.get("base_url") or config.get("api_base")),
                api_key=config.get("api_key"),
                max_tokens=config.get("max_tokens", 4096),
                temperature=config.get("temperature", 0.0),
            )
        except Exception:
            logger.warning(
                "Could not auto-create provider from config for model '%s'",
                model,
            )
            return None
