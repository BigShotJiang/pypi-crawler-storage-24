"""Abstract base for workflow nodes with common helpers."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from pygubernator.workflow._types import NodeContext, NodeResult, NodeStatus

logger = logging.getLogger(__name__)


class AbstractNode(ABC):
    """Base class for workflow nodes providing common helpers.

    Subclasses must implement ``execute`` and set ``node_type``.

    Args:
        node_id: Unique identifier for this node instance.
        config: Node-specific configuration dict.
    """

    node_type: str = ""

    def __init__(self, node_id: str, config: dict[str, Any]) -> None:
        self._node_id = node_id
        self._config = config

    @abstractmethod
    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the node.

        Args:
            context: Execution context with input data and variables.

        Returns:
            Node result with output data and status.
        """

    def _success(
        self,
        output: dict[str, Any] | None = None,
        output_handle: str = "default",
    ) -> NodeResult:
        """Create a success result."""
        return NodeResult(
            node_id=self._node_id,
            status=NodeStatus.SUCCESS,
            output=output or {},
            output_handle=output_handle,
        )

    def _failure(self, error: str) -> NodeResult:
        """Create a failure result."""
        return NodeResult(
            node_id=self._node_id,
            status=NodeStatus.FAILED,
            error=error,
        )
