"""Memory node: conversation history store for LLM workflows."""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

_MEMORY_STORES_KEY = "__memory_stores__"


@runtime_checkable
class MemoryStore(Protocol):
    """Protocol for conversation memory stores."""

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored conversation messages.

        Returns:
            List of message dicts with ``role`` and ``content`` keys.
        """
        ...

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Append messages to the store.

        Args:
            messages: Messages to add.
        """
        ...


class BufferMemoryStore:
    """Unbounded memory store that retains all messages."""

    def __init__(self) -> None:
        self._messages: list[dict[str, str]] = []

    def get_messages(self) -> list[dict[str, str]]:
        """Return all stored messages.

        Returns:
            List of all message dicts.
        """
        return list(self._messages)

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Append messages to the buffer.

        Args:
            messages: Messages to add.
        """
        self._messages.extend(messages)


class WindowMemoryStore:
    """Sliding-window memory store that retains the last N messages.

    Args:
        window_size: Maximum number of messages to retain.
    """

    def __init__(self, window_size: int = 10) -> None:
        self._messages: list[dict[str, str]] = []
        self._window_size = window_size

    def get_messages(self) -> list[dict[str, str]]:
        """Return the last ``window_size`` messages.

        Returns:
            List of the most recent message dicts.
        """
        return list(self._messages[-self._window_size :])

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Append messages, trimming to the window size.

        Args:
            messages: Messages to add.
        """
        self._messages.extend(messages)


def create_memory_store(
    memory_type: str = "buffer",
    window_size: int = 10,
    backend: str = "in_memory",
    config: dict[str, Any] | None = None,
) -> MemoryStore:
    """Factory for creating memory store instances.

    Args:
        memory_type: Retrieval strategy — ``"buffer"`` or ``"window"``.
        window_size: Window size (only used for ``"window"`` type).
        backend: Storage backend identifier.
        config: Full node config dict for backend-specific settings.

    Returns:
        A memory store instance.

    Raises:
        ValueError: If ``memory_type`` or ``backend`` is not recognised.
        ImportError: If the required library for a backend is missing.
    """
    cfg = config or {}

    if backend == "in_memory":
        if memory_type == "buffer":
            return BufferMemoryStore()
        if memory_type == "window":
            return WindowMemoryStore(window_size=window_size)
        msg = f"Unknown memory_type: {memory_type!r}"
        raise ValueError(msg)

    return _create_persistent_store(backend, cfg)


# Maps backend name → (module_path, factory_function_name)
_BACKEND_REGISTRY: dict[str, tuple[str, str]] = {
    "sqlite": (
        "pygubernator.workflow.nodes._memory_sqlite",
        "create_sqlite_store",
    ),
    "postgres": (
        "pygubernator.workflow.nodes._memory_postgres",
        "create_postgres_store",
    ),
    "mongodb": (
        "pygubernator.workflow.nodes._memory_mongodb",
        "create_mongo_store",
    ),
    "pinecone": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_pinecone_store",
    ),
    "chroma": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_chroma_store",
    ),
    "qdrant": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_qdrant_store",
    ),
    "weaviate": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_weaviate_store",
    ),
    "milvus": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_milvus_store",
    ),
}


def _create_persistent_store(backend: str, config: dict[str, Any]) -> MemoryStore:
    """Lazily import and instantiate a persistent memory store.

    Args:
        backend: Backend identifier (e.g. ``"sqlite"``, ``"postgres"``).
        config: Node configuration dict.

    Returns:
        A memory store instance.

    Raises:
        ValueError: If the backend is unknown.
        ImportError: If the required library is not installed.
    """
    import importlib

    entry = _BACKEND_REGISTRY.get(backend)
    if entry is None:
        msg = f"Unknown memory backend: {backend!r}"
        raise ValueError(msg)

    module_path, factory_name = entry
    module = importlib.import_module(module_path)
    factory_fn = getattr(module, factory_name)
    return factory_fn(config)  # type: ignore[no-any-return]


class MemoryNode(AbstractNode):
    """Workflow node that provides conversation memory to downstream LLM nodes.

    Creates or reuses a ``MemoryStore`` in the shared ``variables`` dict
    and outputs the current message history for the downstream LLM node.

    Config:
        backend: Storage backend — ``"in_memory"`` (default), ``"sqlite"``,
            ``"postgres"``, ``"mongodb"``, ``"pinecone"``, ``"chroma"``,
            ``"qdrant"``, ``"weaviate"``, or ``"milvus"``.
        memory_type: ``"buffer"`` (default) or ``"window"``.
        window_size: Number of messages for window mode (default 10).

    Backend-specific keys (e.g. ``db_path``, ``connection_string``,
    ``api_key``) are passed through to the store constructor.
    """

    node_type = "memory"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Read or initialise the memory store and output history.

        Args:
            context: Execution context with shared variables.

        Returns:
            Result containing ``__memory_node_id__`` and
            ``__memory_history__``.
        """
        stores = context.variables.setdefault(_MEMORY_STORES_KEY, {})

        if self._node_id not in stores:
            memory_type = self._config.get("memory_type", "buffer")
            window_size = self._config.get("window_size", 10)
            backend = self._config.get("backend", "in_memory")
            try:
                stores[self._node_id] = create_memory_store(
                    memory_type=memory_type,
                    window_size=window_size,
                    backend=backend,
                    config=self._config,
                )
            except Exception as exc:
                logger.error("MemoryNode %s store init failed: %s", self._node_id, exc)
                return self._failure(f"Memory store init failed: {exc}")

        store: MemoryStore = stores[self._node_id]
        history = store.get_messages()

        logger.debug("MemoryNode %s returning %d messages", self._node_id, len(history))

        return self._success(
            {
                "__memory_node_id__": self._node_id,
                "__memory_history__": history,
            }
        )


class MemoryNodeFactory:
    """Factory for creating MemoryNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> MemoryNode:
        """Create a MemoryNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured MemoryNode instance.
        """
        return MemoryNode(node_id=node_id, config=config)
