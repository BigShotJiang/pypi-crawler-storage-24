"""If/else branching workflow node using safe expressions."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._expressions import evaluate_condition
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)


class ConditionNode(AbstractNode):
    """Evaluates a condition and routes to true/false output handles.

    Config:
        condition: Expression string evaluated against input data
            and variables (required).
    """

    node_type = "condition"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Evaluate the condition expression.

        Args:
            context: Execution context with input data.

        Returns:
            Result with output_handle set to "true" or "false".
        """
        expr = self._config.get("condition", "")

        if not expr:
            return self._failure("No condition configured")

        namespace = {**context.variables, **context.input_data}

        try:
            result = evaluate_condition(expr, namespace)
        except Exception as exc:
            logger.error("Condition node %s failed: %s", self._node_id, exc)
            return self._failure(str(exc))

        handle = "true" if result else "false"
        return self._success(
            {"result": result},
            output_handle=handle,
        )


class ConditionNodeFactory:
    """Factory for creating ConditionNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> ConditionNode:
        """Create a ConditionNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured ConditionNode instance.
        """
        return ConditionNode(node_id=node_id, config=config)
