"""Jinja2 template rendering workflow node."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._templates import render_template
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)


class TemplateNode(AbstractNode):
    """Renders a Jinja2 template with input data and variables.

    Config:
        template: Jinja2 template string (required).
        output_key: Key name for the rendered output (default: "result").
    """

    node_type = "template"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Render the configured template.

        Args:
            context: Execution context with input data.

        Returns:
            Result with rendered template in output.
        """
        template_str = self._config.get("template", "")
        output_key = self._config.get("output_key", "result")

        if not template_str:
            return self._failure("No template configured")

        template_context = {**context.variables, **context.input_data}

        try:
            rendered = render_template(template_str, template_context)
        except Exception as exc:
            logger.error("Template node %s failed: %s", self._node_id, exc)
            return self._failure(str(exc))

        return self._success({output_key: rendered})


class TemplateNodeFactory:
    """Factory for creating TemplateNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> TemplateNode:
        """Create a TemplateNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured TemplateNode instance.
        """
        return TemplateNode(node_id=node_id, config=config)
