"""PostgreSQL-backed memory store for conversation history."""

from __future__ import annotations

import logging
import os
import re
from typing import Any

logger = logging.getLogger(__name__)

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

try:
    import psycopg2  # type: ignore[import-untyped]

    _HAS_PSYCOPG2 = True
except ImportError:
    _HAS_PSYCOPG2 = False


def _safe_identifier(name: str) -> str:
    """Validate that *name* is a safe SQL identifier."""
    if not _IDENT_RE.match(name):
        msg = f"Invalid SQL identifier: {name!r}"
        raise ValueError(msg)
    return name


class PostgresMemoryStore:
    """Persistent memory store backed by PostgreSQL.

    Args:
        connection_string: PostgreSQL DSN.
        table_name: Table used to store messages.
    """

    def __init__(
        self,
        connection_string: str,
        table_name: str = "messages",
    ) -> None:
        if not _HAS_PSYCOPG2:
            msg = (
                "psycopg2 is required for PostgreSQL memory. "
                "Install with: pip install psycopg2-binary"
            )
            raise ImportError(msg)
        self._dsn = connection_string
        self._table = _safe_identifier(table_name)
        self._ensure_table()

    def _ensure_table(self) -> None:
        """Create the messages table if it does not exist."""
        with psycopg2.connect(self._dsn) as conn, conn.cursor() as cur:
            cur.execute(
                f"CREATE TABLE IF NOT EXISTS {self._table} ("
                "  id SERIAL PRIMARY KEY,"
                "  role TEXT NOT NULL,"
                "  content TEXT NOT NULL,"
                "  created_at TIMESTAMPTZ DEFAULT NOW()"
                ")"
            )
            conn.commit()

    def get_messages(self) -> list[dict[str, str]]:
        """Return all stored messages ordered by insertion.

        Returns:
            List of message dicts.
        """
        with psycopg2.connect(self._dsn) as conn, conn.cursor() as cur:
            cur.execute(f"SELECT role, content FROM {self._table} ORDER BY id")
            rows = cur.fetchall()
        return [{"role": r[0], "content": r[1]} for r in rows]

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Persist messages to PostgreSQL.

        Args:
            messages: Messages to add.
        """
        with psycopg2.connect(self._dsn) as conn, conn.cursor() as cur:
            cur.executemany(
                f"INSERT INTO {self._table} (role, content) VALUES (%s, %s)",
                [(m["role"], m["content"]) for m in messages],
            )
            conn.commit()


def create_postgres_store(config: dict[str, Any]) -> PostgresMemoryStore:
    """Create a PostgresMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured PostgresMemoryStore.
    """
    dsn = config.get("connection_string") or os.environ.get("MEMORY_POSTGRES_DSN", "")
    if not dsn:
        msg = (
            "PostgreSQL connection_string is required. "
            "Set it in the node config or via MEMORY_POSTGRES_DSN."
        )
        raise ValueError(msg)
    return PostgresMemoryStore(
        connection_string=dsn,
        table_name=config.get("table_name", "messages"),
    )
