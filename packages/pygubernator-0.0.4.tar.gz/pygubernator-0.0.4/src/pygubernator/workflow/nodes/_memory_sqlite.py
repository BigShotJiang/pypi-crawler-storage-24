"""SQLite-backed memory store for conversation history."""

from __future__ import annotations

import logging
import re
import sqlite3
from typing import Any

logger = logging.getLogger(__name__)

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _safe_identifier(name: str) -> str:
    """Validate that *name* is a safe SQL identifier."""
    if not _IDENT_RE.match(name):
        msg = f"Invalid SQL identifier: {name!r}"
        raise ValueError(msg)
    return name


class SqliteMemoryStore:
    """Persistent memory store backed by a local SQLite database.

    Args:
        db_path: Path to the SQLite database file.
        table_name: Table used to store messages.
    """

    def __init__(
        self,
        db_path: str = "memory.db",
        table_name: str = "messages",
    ) -> None:
        self._db_path = db_path
        self._table = _safe_identifier(table_name)
        self._ensure_table()

    def _ensure_table(self) -> None:
        """Create the messages table if it does not exist."""
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                f"CREATE TABLE IF NOT EXISTS {self._table} ("
                "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
                "  role TEXT NOT NULL,"
                "  content TEXT NOT NULL,"
                "  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
                ")"
            )

    def get_messages(self) -> list[dict[str, str]]:
        """Return all stored messages ordered by insertion.

        Returns:
            List of message dicts.
        """
        with sqlite3.connect(self._db_path) as conn:
            rows = conn.execute(
                f"SELECT role, content FROM {self._table} ORDER BY id"
            ).fetchall()
        return [{"role": r[0], "content": r[1]} for r in rows]

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Persist messages to the SQLite database.

        Args:
            messages: Messages to add.
        """
        with sqlite3.connect(self._db_path) as conn:
            conn.executemany(
                f"INSERT INTO {self._table} (role, content) VALUES (?, ?)",
                [(m["role"], m["content"]) for m in messages],
            )


def create_sqlite_store(config: dict[str, Any]) -> SqliteMemoryStore:
    """Create a SqliteMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured SqliteMemoryStore.
    """
    return SqliteMemoryStore(
        db_path=config.get("db_path", "memory.db"),
        table_name=config.get("table_name", "messages"),
    )
