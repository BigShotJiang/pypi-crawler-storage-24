"""Parallel map workflow node."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pygubernator.workflow._expressions import SafeExpressionEvaluator
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

_DEFAULT_MAX_CONCURRENCY = 10


class MapNode(AbstractNode):
    """Apply a transform to each item in a collection concurrently.

    Config:
        collection_key: Key in input_data holding the iterable.
        item_key: Variable name for the current item (default: "item").
        transform: Expression applied to each item (required).
        max_concurrency: Maximum concurrent tasks (default: 10).
    """

    node_type = "map"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Map transform over collection with concurrency control.

        Args:
            context: Execution context with input data.

        Returns:
            Result with {"items": [...], "count": N}.
        """
        collection_key = self._config.get("collection_key", "")
        item_key = self._config.get("item_key", "item")
        transform = self._config.get("transform", "")
        max_concurrency = self._config.get(
            "max_concurrency",
            _DEFAULT_MAX_CONCURRENCY,
        )

        if not collection_key:
            return self._failure("No collection_key configured")

        if not transform:
            return self._failure("No transform configured")

        collection = context.input_data.get(collection_key)
        if collection is None:
            return self._failure(
                f"Collection key '{collection_key}' not found in input"
            )

        if not hasattr(collection, "__iter__"):
            return self._failure(f"Value at '{collection_key}' is not iterable")

        items = list(collection)
        if not items:
            return self._success({"items": [], "count": 0})

        semaphore = asyncio.Semaphore(max_concurrency)

        async def _process(item: Any, idx: int) -> Any:
            async with semaphore:
                namespace = {
                    **context.variables,
                    **context.input_data,
                    item_key: item,
                    "index": idx,
                }
                evaluator = SafeExpressionEvaluator(namespace)
                return evaluator.evaluate(transform)

        try:
            results = await asyncio.gather(
                *[_process(item, i) for i, item in enumerate(items)],
            )
        except Exception as exc:
            return self._failure(f"Map transform failed: {exc}")

        return self._success(
            {"items": list(results), "count": len(results)},
        )


class MapNodeFactory:
    """Factory for creating MapNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> MapNode:
        """Create a MapNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured MapNode instance.
        """
        return MapNode(node_id=node_id, config=config)
