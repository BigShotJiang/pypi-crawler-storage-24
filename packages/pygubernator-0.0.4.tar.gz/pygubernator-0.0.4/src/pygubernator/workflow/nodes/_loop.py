"""Iterative loop workflow node."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._expressions import SafeExpressionEvaluator
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

_DEFAULT_MAX_ITERATIONS = 1000


class LoopNode(AbstractNode):
    """Iterate over a collection with per-item transform.

    Config:
        collection_key: Key in input_data holding the iterable.
        item_key: Variable name for the current item (default: "item").
        index_key: Variable name for the current index (default: "index").
        transform: Optional expression applied to each item.
        max_iterations: Safety cap (default: 1000).
    """

    node_type = "loop"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Iterate over the collection and apply transform.

        Args:
            context: Execution context with input data.

        Returns:
            Result with {"items": [...], "count": N}.
        """
        collection_key = self._config.get("collection_key", "")
        item_key = self._config.get("item_key", "item")
        index_key = self._config.get("index_key", "index")
        transform = self._config.get("transform", "")
        max_iterations = self._config.get(
            "max_iterations",
            _DEFAULT_MAX_ITERATIONS,
        )

        if not collection_key:
            return self._failure("No collection_key configured")

        collection = context.input_data.get(collection_key)
        if collection is None:
            return self._failure(
                f"Collection key '{collection_key}' not found in input"
            )

        if not hasattr(collection, "__iter__"):
            return self._failure(f"Value at '{collection_key}' is not iterable")

        results: list[Any] = []
        for i, item in enumerate(collection):
            if i >= max_iterations:
                logger.warning(
                    "Loop node %s hit max_iterations %d",
                    self._node_id,
                    max_iterations,
                )
                break

            if transform:
                namespace = {
                    **context.variables,
                    **context.input_data,
                    item_key: item,
                    index_key: i,
                }
                evaluator = SafeExpressionEvaluator(namespace)
                try:
                    results.append(evaluator.evaluate(transform))
                except Exception as exc:
                    return self._failure(f"Transform failed at index {i}: {exc}")
            else:
                results.append(item)

        return self._success({"items": results, "count": len(results)})


class LoopNodeFactory:
    """Factory for creating LoopNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> LoopNode:
        """Create a LoopNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured LoopNode instance.
        """
        return LoopNode(node_id=node_id, config=config)
