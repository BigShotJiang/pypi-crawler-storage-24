"""Stream runner: consume forever until shutdown."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from datetime import UTC, datetime

from pygubernator._events import AgentEvent, AgentEventType, EventBus
from pygubernator._handlers import DatabaseEventHandler
from pygubernator._protocols import Transport
from pygubernator._types import AgentResult
from pygubernator.agents._base import BaseAgent
from pygubernator.db.repositories import create_run, get_run, update_run

logger = logging.getLogger(__name__)


async def run_stream(
    agent: BaseAgent,
    transport: Transport,
    topic: str,
    shutdown_event: asyncio.Event | None = None,
    batch_size: int = 10,
    commit_interval: int = 100,
    event_bus: EventBus | None = None,
    run_id: str | None = None,
) -> AgentResult:
    """Run an agent in streaming mode.

    Continuously consumes messages until the shutdown event is set.
    Suitable for long-running K8s deployments.

    Args:
        agent: Agent implementing BaseAgent protocol.
        transport: Transport implementing Transport protocol.
        topic: Topic to consume from.
        shutdown_event: Event to signal shutdown. If None, creates one.
        batch_size: Messages to consume per poll.
        commit_interval: Commit offsets every N messages.
        event_bus: Optional event bus for emitting run events.
        run_id: Optional run identifier for correlating events.

    Returns:
        Aggregate result when shutdown completes.
    """
    if shutdown_event is None:
        shutdown_event = asyncio.Event()

    if run_id is not None:
        agent.set_run_id(run_id)

    agent.start()
    if event_bus:
        await event_bus.emit(
            AgentEvent(
                event_type=AgentEventType.RUN_STARTED,
                agent_id=agent.agent_id,
                data={"mode": "stream", "topic": topic},
                run_id=run_id,
            )
        )
    total_processed = 0
    all_errors: list[str] = []
    since_commit = 0

    try:
        logger.info(
            "Stream run: consuming from %s (batch_size=%d)",
            topic,
            batch_size,
        )

        while not shutdown_event.is_set():
            messages = await transport.consume(topic, batch_size)

            if not messages:
                try:
                    await asyncio.wait_for(shutdown_event.wait(), timeout=1.0)
                except TimeoutError:
                    continue

            for msg in messages:
                if shutdown_event.is_set():
                    break

                result = await agent.process(msg)
                total_processed += result.messages_processed
                all_errors.extend(result.errors)
                since_commit += 1

                if since_commit >= commit_interval:
                    await transport.commit()
                    since_commit = 0

        # Final commit
        if since_commit > 0:
            await transport.commit()

    except Exception as exc:
        logger.error("Stream run failed: %s", exc)
        all_errors.append(str(exc))
    finally:
        agent.stop()
        await transport.close()

    success = len(all_errors) == 0
    if event_bus:
        await event_bus.emit(
            AgentEvent(
                event_type=AgentEventType.RUN_COMPLETED,
                agent_id=agent.agent_id,
                data={
                    "mode": "stream",
                    "topic": topic,
                    "success": success,
                    "messages_processed": total_processed,
                },
                run_id=run_id,
            )
        )
    return AgentResult(
        agent_id=agent.agent_id,
        success=success,
        messages_processed=total_processed,
        errors=all_errors,
        metadata={"mode": "stream", "topic": topic},
    )


async def run_stream_with_db(
    agent: BaseAgent,
    transport: Transport,
    topic: str,
    db_session_factory: Callable[[], object],
    agent_id: str,
    agent_version_id: str | None = None,
    shutdown_event: asyncio.Event | None = None,
    batch_size: int = 10,
    commit_interval: int = 100,
    correlation_id: str | None = None,
    trigger: str | None = None,
    metadata_json: dict | None = None,
) -> AgentResult:
    """Run an agent in streaming mode with database integration.

    Creates a Run record, sets up DatabaseEventHandler, and updates run status.
    Suitable for workers that share database access with the control plane.

    Args:
        agent: Agent implementing BaseAgent protocol.
        transport: Transport implementing Transport protocol.
        topic: Topic to consume from.
        db_session_factory: Callable that returns a SQLAlchemy Session.
        agent_id: Agent ID for the run record.
        agent_version_id: Optional agent version ID.
        shutdown_event: Event to signal shutdown. If None, creates one.
        batch_size: Messages to consume per poll.
        commit_interval: Commit offsets every N messages.
        correlation_id: Optional correlation ID for the run.
        trigger: Optional trigger source for the run.
        metadata_json: Optional metadata dict for the run.

    Returns:
        Aggregate result when shutdown completes.
    """
    # Create Run record
    db = db_session_factory()
    try:
        run = create_run(
            db,
            agent_id=agent_id,
            agent_version_id=agent_version_id,
            status="queued",
            correlation_id=correlation_id,
            trigger=trigger,
            metadata_json=metadata_json or {},
        )
        db.commit()
        db.refresh(run)
        run_id = run.id
    finally:
        db.close()

    event_bus = agent.ensure_event_bus()
    db_handler = DatabaseEventHandler(db_session_factory)
    event_bus.add_handler(db_handler)

    # Update run status to running
    db = db_session_factory()
    try:
        run = get_run(db, run_id)
        if run:
            update_run(db, run, status="running", started_at=datetime.now(UTC))
            db.commit()
    finally:
        db.close()

    # Run the agent
    try:
        result = await run_stream(
            agent=agent,
            transport=transport,
            topic=topic,
            shutdown_event=shutdown_event,
            batch_size=batch_size,
            commit_interval=commit_interval,
            event_bus=event_bus,
            run_id=run_id,
        )

        # Update run status on completion
        db = db_session_factory()
        try:
            run = get_run(db, run_id)
            if run:
                ended_at = datetime.now(UTC)
                duration_ms = None
                if run.started_at:
                    delta = ended_at - run.started_at
                    duration_ms = int(delta.total_seconds() * 1000)
                update_run(
                    db,
                    run,
                    status="succeeded" if result.success else "failed",
                    ended_at=ended_at,
                    duration_ms=duration_ms,
                    error_message="; ".join(result.errors) if result.errors else None,
                )
                db.commit()
        finally:
            db.close()

        return result
    except Exception as exc:
        # Update run status on error
        db = db_session_factory()
        try:
            run = get_run(db, run_id)
            if run:
                update_run(
                    db,
                    run,
                    status="failed",
                    ended_at=datetime.now(UTC),
                    error_message=str(exc),
                )
                db.commit()
        finally:
            db.close()
        raise
