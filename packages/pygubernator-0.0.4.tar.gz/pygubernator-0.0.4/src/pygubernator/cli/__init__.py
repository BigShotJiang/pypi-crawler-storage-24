"""CLI entrypoint for pygubernator optional services.

Mirrors pycharter / pystator: ``pygubernator api`` starts the API server; ``ui`` uses
``serve`` / ``dev`` / ``build`` with the same flags and defaults (config + env).
"""

from __future__ import annotations

import argparse
import importlib.util
import os
import sys


def main() -> int:
    """Parse CLI arguments and dispatch to the appropriate handler.

    Returns:
        Exit code.
    """
    parser = argparse.ArgumentParser(
        prog="pygubernator",
        description="PyGubernator — agent framework and optional control plane",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="Command", required=True)

    from pygubernator.config import ControlPlaneSettings

    settings = ControlPlaneSettings.from_env()

    # --- api ------------------------------------------------------------------
    api_p = sub.add_parser("api", help="Start the control-plane API server")
    api_p.add_argument(
        "--host",
        type=str,
        default=settings.api_host,
        help="Host to bind to (default: from config)",
    )
    api_p.add_argument(
        "--port",
        type=int,
        default=settings.api_port,
        help="Port to bind to (default: from config)",
    )
    api_p.add_argument("--reload", action="store_true", default=True)
    api_p.add_argument("--no-reload", dest="reload", action="store_false")

    # --- chat -----------------------------------------------------------------
    chat_p = sub.add_parser("chat", help="Start an interactive chat REPL")
    chat_p.add_argument(
        "--model",
        type=str,
        default=os.environ.get("PYGUBERNATOR_LLM_MODEL", "gpt-4"),
    )
    chat_p.add_argument("--demo", action="store_true", default=False)
    chat_p.add_argument("--max-iterations", type=int, default=10)

    # --- ui -------------------------------------------------------------------
    ui_parser = sub.add_parser("ui", help="UI management commands")
    ui_sub = ui_parser.add_subparsers(dest="ui_command", required=True)

    serve_p = ui_sub.add_parser("serve", help="Serve the built UI")
    serve_p.add_argument("--api-url", type=str, default=None)
    serve_p.add_argument("--host", type=str, default=settings.ui_host)
    serve_p.add_argument("--port", type=int, default=settings.ui_port)

    dev_p = ui_sub.add_parser("dev", help="Run UI development server")
    dev_p.add_argument("--api-url", type=str, default=None)
    dev_p.add_argument("--port", type=int, default=settings.ui_port)

    ui_sub.add_parser("build", help="Build the UI for production")

    # --- db -------------------------------------------------------------------
    sub.add_parser(
        "db",
        help="Database management commands",
        description=(
            "Manage pygubernator database: init, upgrade, downgrade, seed, truncate"
        ),
    )

    # --- workflow --------------------------------------------------------------
    wf_p = sub.add_parser("workflow", help="Workflow orchestration commands")
    wf_sub = wf_p.add_subparsers(dest="workflow_command", required=True)

    wf_run_p = wf_sub.add_parser("run", help="Run a workflow from YAML")
    wf_run_p.add_argument("path", help="Path to workflow YAML file")
    wf_run_p.add_argument("--input", type=str, default="{}")
    wf_run_p.add_argument("--dry-run", action="store_true", default=False)

    args, remaining = parser.parse_known_args()

    if args.command == "db":
        return _run_db(remaining)

    if args.command == "api":
        if importlib.util.find_spec("uvicorn") is None:
            print(
                "Error: uvicorn is required. Install with: "
                "pip install pygubernator[api]",
                file=sys.stderr,
            )
            return 1
        from pygubernator.api.main import run_api

        run_api(host=args.host, port=args.port, reload=args.reload)
        return 0

    if args.command == "chat":
        from pygubernator.cli._chat import run_chat

        return run_chat(args)

    if args.command == "ui":
        if args.ui_command == "serve":
            from pygubernator.ui.server import serve_ui

            return serve_ui(api_url=args.api_url, host=args.host, port=args.port)
        if args.ui_command == "dev":
            from pygubernator.ui.dev import run_dev_server

            return run_dev_server(api_url=args.api_url, port=args.port)
        if args.ui_command == "build":
            from pygubernator.ui.build import build_ui

            return build_ui()

    if args.command == "workflow" and args.workflow_command == "run":
        from pygubernator.cli._workflow import run_workflow

        return run_workflow(args)

    parser.print_help()
    return 1


def _run_db(remaining: list[str]) -> int:
    """Delegate to pygubernator.db.cli.main with remaining args."""
    try:
        from pygubernator.db.cli import main as db_main
    except ImportError as e:
        print(f"Database CLI not available: {e}", file=sys.stderr)
        return 1
    sys.argv = ["pygubernator db", *remaining]
    return db_main()


if __name__ == "__main__":
    raise SystemExit(main())
