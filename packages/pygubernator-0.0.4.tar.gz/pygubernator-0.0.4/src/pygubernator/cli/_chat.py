"""CLI handler for the interactive chat REPL."""

from __future__ import annotations

import argparse
import asyncio


def run_chat(args: argparse.Namespace) -> int:
    """Set up and run the interactive chat REPL.

    Args:
        args: Parsed CLI arguments (model, demo, max_iterations).

    Returns:
        Exit code.
    """
    from pygubernator.chat._demo import (
        create_demo_machines,
        create_demo_schemas,
        create_demo_system_prompt,
        create_demo_validators,
    )
    from pygubernator.chat._repl import run_chat_repl
    from pygubernator.chat._session import ChatSession
    from pygubernator.tools._registry import ToolRegistry
    from pygubernator.tools.catalyst_tools import create_catalyst_tools
    from pygubernator.tools.charter_tools import create_charter_tools
    from pygubernator.tools.stator_tools import create_stator_tools

    schemas = create_demo_schemas()
    validators = create_demo_validators()
    machines = create_demo_machines()

    registry = ToolRegistry()
    registry.register_all(create_catalyst_tools(schemas))
    registry.register_all(create_charter_tools(validators))
    registry.register_all(create_stator_tools(machines))

    if args.demo:
        from pygubernator.chat._demo_provider import DemoLLMProvider

        provider = DemoLLMProvider()
    else:
        from pygubernator.llm._provider import LiteLLMProvider

        provider = LiteLLMProvider(model=args.model)

    session = ChatSession(
        llm_provider=provider,
        tool_registry=registry,
        system_prompt=create_demo_system_prompt(),
        max_iterations=args.max_iterations,
    )

    asyncio.run(run_chat_repl(session))
    return 0
