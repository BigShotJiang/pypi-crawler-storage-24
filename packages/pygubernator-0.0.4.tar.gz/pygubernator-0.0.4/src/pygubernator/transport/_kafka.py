"""Kafka transport using confluent-kafka."""

from __future__ import annotations

import json
import logging
from typing import Any

from pygubernator._types import Message
from pygubernator.errors import TransportError

logger = logging.getLogger(__name__)


class KafkaTransport:
    """Kafka message transport using confluent-kafka.

    Follows pycatalyst KafkaSink pattern: lazy initialization,
    delivery callbacks, JSON serialization.

    Args:
        bootstrap_servers: Kafka bootstrap servers.
        group_id: Consumer group ID.
        consumer_config: Additional consumer configuration.
        producer_config: Additional producer configuration.
    """

    def __init__(
        self,
        bootstrap_servers: str,
        group_id: str,
        consumer_config: dict[str, Any] | None = None,
        producer_config: dict[str, Any] | None = None,
    ) -> None:
        self._bootstrap_servers = bootstrap_servers
        self._group_id = group_id
        self._consumer_config = consumer_config or {}
        self._producer_config = producer_config or {}
        self._consumer: Any = None
        self._producer: Any = None
        self._subscribed_topics: set[str] = set()

    def _ensure_consumer(self, topic: str) -> Any:
        """Lazily initialize consumer and subscribe to topic."""
        try:
            from confluent_kafka import Consumer
        except ImportError as exc:
            raise TransportError(
                "confluent-kafka is required for KafkaTransport."
                " Install with: pip install pygubernator[kafka]",
                transport_type="kafka",
            ) from exc

        if self._consumer is None:
            config = {
                "bootstrap.servers": self._bootstrap_servers,
                "group.id": self._group_id,
                "auto.offset.reset": "earliest",
                "enable.auto.commit": False,
                **self._consumer_config,
            }
            self._consumer = Consumer(config)
            logger.info(
                "Kafka consumer created for group %s",
                self._group_id,
            )

        if topic not in self._subscribed_topics:
            self._subscribed_topics.add(topic)
            self._consumer.subscribe(list(self._subscribed_topics))
            logger.info("Subscribed to topic %s", topic)

        return self._consumer

    def _ensure_producer(self) -> Any:
        """Lazily initialize producer."""
        try:
            from confluent_kafka import Producer
        except ImportError as exc:
            raise TransportError(
                "confluent-kafka is required for KafkaTransport."
                " Install with: pip install pygubernator[kafka]",
                transport_type="kafka",
            ) from exc

        if self._producer is None:
            config = {
                "bootstrap.servers": self._bootstrap_servers,
                **self._producer_config,
            }
            self._producer = Producer(config)
            logger.info("Kafka producer created")

        return self._producer

    async def consume(self, topic: str, max_messages: int = 1) -> list[Message]:
        """Consume messages from Kafka topic.

        Args:
            topic: Topic to consume from.
            max_messages: Maximum messages to consume.

        Returns:
            List of consumed messages.
        """
        consumer = self._ensure_consumer(topic)
        results: list[Message] = []

        for _ in range(max_messages):
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                break
            if msg.error():
                logger.warning("Consumer error: %s", msg.error())
                continue

            try:
                payload = json.loads(msg.value().decode("utf-8"))
            except (
                json.JSONDecodeError,
                UnicodeDecodeError,
            ) as exc:
                logger.warning(
                    "Failed to decode message from %s: %s",
                    topic,
                    exc,
                )
                continue

            headers: dict[str, str] = {}
            if msg.headers():
                for k, v in msg.headers():
                    headers[k] = v.decode("utf-8") if v else ""

            key = msg.key().decode("utf-8") if msg.key() is not None else None

            results.append(
                Message(
                    topic=msg.topic(),
                    key=key,
                    payload=payload,
                    headers=headers,
                    timestamp=msg.timestamp()[1] / 1000.0
                    if msg.timestamp()[0] != 0
                    else None,
                )
            )

        return results

    async def produce(self, message: Message) -> None:
        """Produce a message to Kafka.

        Args:
            message: Message to produce.
        """
        producer = self._ensure_producer()
        value = json.dumps(message.payload).encode("utf-8")
        key = message.key.encode("utf-8") if message.key else None
        headers = [(k, v.encode("utf-8")) for k, v in message.headers.items()]

        producer.produce(
            topic=message.topic,
            value=value,
            key=key,
            headers=headers,
            callback=self._delivery_callback,
        )
        producer.poll(0)

    @staticmethod
    def _delivery_callback(err: Any, msg: Any) -> None:
        """Callback for message delivery confirmation."""
        if err is not None:
            logger.error(
                "Message delivery failed for %s: %s",
                msg.topic(),
                err,
            )
        else:
            logger.debug(
                "Message delivered to %s [%d]",
                msg.topic(),
                msg.partition(),
            )

    async def commit(self) -> None:
        """Commit consumer offsets."""
        if self._consumer is not None:
            self._consumer.commit(asynchronous=False)

    async def close(self) -> None:
        """Close consumer and producer."""
        if self._consumer is not None:
            self._consumer.close()
            self._consumer = None
            logger.info("Kafka consumer closed")
        if self._producer is not None:
            self._producer.flush(timeout=5.0)
            self._producer = None
            logger.info("Kafka producer closed")
        self._subscribed_topics.clear()
