"""In-memory transport for testing."""

from __future__ import annotations

import asyncio
import logging

from pygubernator._types import Message

logger = logging.getLogger(__name__)


class InMemoryTransport:
    """In-memory message transport for testing.

    Uses asyncio.Queue per topic. Messages can be injected for testing
    and produced messages can be inspected via the produced_messages
    property.
    """

    def __init__(self) -> None:
        self._queues: dict[str, asyncio.Queue[Message]] = {}
        self._produced: list[Message] = []
        self._closed = False

    def _get_queue(self, topic: str) -> asyncio.Queue[Message]:
        """Get or create queue for topic."""
        if topic not in self._queues:
            self._queues[topic] = asyncio.Queue()
        return self._queues[topic]

    def inject(self, topic: str, messages: list[Message]) -> None:
        """Inject messages into a topic for testing.

        Args:
            topic: Topic to inject into.
            messages: Messages to add to the queue.
        """
        queue = self._get_queue(topic)
        for msg in messages:
            queue.put_nowait(msg)

    async def consume(self, topic: str, max_messages: int = 1) -> list[Message]:
        """Consume messages from a topic.

        Args:
            topic: Topic to consume from.
            max_messages: Maximum number of messages to return.

        Returns:
            List of consumed messages (may be empty if queue
            is empty).
        """
        queue = self._get_queue(topic)
        results: list[Message] = []
        for _ in range(max_messages):
            try:
                msg = queue.get_nowait()
                results.append(msg)
            except asyncio.QueueEmpty:
                break
        return results

    async def produce(self, message: Message) -> None:
        """Produce a message to the transport.

        Args:
            message: Message to produce.
        """
        self._produced.append(message)
        queue = self._get_queue(message.topic)
        await queue.put(message)
        logger.debug("Produced message to topic %s", message.topic)

    async def commit(self) -> None:
        """Commit offsets (no-op for in-memory)."""

    async def close(self) -> None:
        """Close the transport."""
        self._closed = True

    @property
    def produced_messages(self) -> list[Message]:
        """All messages produced through this transport."""
        return list(self._produced)

    @property
    def is_closed(self) -> bool:
        """Whether the transport has been closed."""
        return self._closed

    def clear(self) -> None:
        """Clear all queues and produced messages."""
        self._queues.clear()
        self._produced.clear()
