"""Pipeline agent: sequential extract-transform-load steps."""

from __future__ import annotations

import abc
import logging
import time
from typing import Any

from pystator import StateMachine

from pygubernator._events import AgentEventType, EventBus
from pygubernator._types import AgentResult, Message, StepResult
from pygubernator.agents._base import BaseAgent
from pygubernator.agents._machines import pipeline_lifecycle_config
from pygubernator.errors import PipelineStepError

logger = logging.getLogger(__name__)


class PipelineStep(abc.ABC):
    """A single step in a pipeline.

    Attributes:
        name: Step identifier.
    """

    def __init__(self, name: str) -> None:
        self._name = name

    @property
    def name(self) -> str:
        """Step name."""
        return self._name

    @abc.abstractmethod
    async def execute(self, data: Any) -> StepResult:
        """Execute this step.

        Args:
            data: Input data from previous step.

        Returns:
            Step result with output data.
        """


class PipelineAgent(BaseAgent):
    """Agent that runs sequential pipeline steps.

    Each step is a PipelineStep object that executes and returns
    a StepResult. Steps run in order: extract -> transform -> load.
    Optional pycharter contract validation between steps.

    Args:
        agent_id: Unique identifier.
        steps: Ordered list of pipeline steps.
        validate_between_steps: Whether to validate data between steps.
        validator: Optional validator object with a ``validate()`` method.
            Used when ``validate_between_steps`` is True.
        lifecycle_machine: Optional lifecycle machine override.
        context: Optional initial context.
        event_bus: Optional event bus for emitting step events.
    """

    def __init__(
        self,
        agent_id: str,
        steps: list[PipelineStep],
        validate_between_steps: bool = False,
        validator: Any | None = None,
        lifecycle_machine: StateMachine | None = None,
        context: dict[str, Any] | None = None,
        event_bus: EventBus | None = None,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            machine=lifecycle_machine,
            context=context,
            event_bus=event_bus,
        )
        self._steps = steps
        self._validate = validate_between_steps
        self._validator = validator
        self._pipeline_machine = StateMachine.from_dict(pipeline_lifecycle_config())
        self._pipeline_session = self._pipeline_machine.create()

    async def process(self, message: Message) -> AgentResult:
        """Process a message through the pipeline steps.

        Args:
            message: The input message.

        Returns:
            Result with step metadata.
        """
        step_results: list[dict[str, Any]] = []
        data: Any = message.payload
        errors: list[str] = []

        self._pipeline_session = self._pipeline_machine.create()
        self._pipeline_session.send("start_extract")

        step_events = ["extract_done", "transform_done", "load_done"]

        for i, step in enumerate(self._steps):
            start_time = time.perf_counter()
            await self._emit(
                AgentEventType.STEP_STARTED,
                {
                    "step_name": step.name,
                    "step_index": i,
                },
            )
            try:
                if self._validate and i > 0:
                    data = self._validate_data(step.name, data)

                result = await step.execute(data)
                elapsed = (time.perf_counter() - start_time) * 1000
                step_results.append(result.to_dict())

                if not result.success:
                    errors.append(f"Step '{step.name}' failed: {result.error}")
                    await self._emit(
                        AgentEventType.STEP_FAILED,
                        {
                            "step_name": step.name,
                            "error": result.error,
                            "duration_ms": elapsed,
                        },
                    )
                    self._pipeline_session.send("fail")
                    break

                await self._emit(
                    AgentEventType.STEP_COMPLETED,
                    {
                        "step_name": step.name,
                        "duration_ms": elapsed,
                    },
                )
                data = result.data

                if i < len(step_events):
                    self._pipeline_session.send(step_events[i])

            except Exception as exc:
                elapsed = (time.perf_counter() - start_time) * 1000
                errors.append(f"Step '{step.name}' error: {exc}")
                step_results.append(
                    StepResult(
                        step_name=step.name,
                        success=False,
                        data=None,
                        error=str(exc),
                        duration_ms=elapsed,
                    ).to_dict()
                )
                await self._emit(
                    AgentEventType.STEP_FAILED,
                    {
                        "step_name": step.name,
                        "error": str(exc),
                        "duration_ms": elapsed,
                    },
                )
                self._pipeline_session.send("fail")
                break

        success = len(errors) == 0
        return AgentResult(
            agent_id=self._agent_id,
            success=success,
            messages_processed=1 if success else 0,
            errors=errors,
            metadata={
                "steps": step_results,
                "pipeline_state": self._pipeline_session.current_state,
            },
        )

    def _validate_data(self, step_name: str, data: Any) -> Any:
        """Validate data between steps.

        Uses the injected validator if available. Falls back to a
        no-op if no validator is configured.

        Args:
            step_name: Name of the next step (for error context).
            data: Data to validate.

        Returns:
            The validated data.

        Raises:
            PipelineStepError: If validation fails.
        """
        if self._validator is None:
            return data

        try:
            result = self._validator.validate(data)
            if hasattr(result, "is_valid") and not result.is_valid:
                errors = getattr(result, "errors", [])
                raise PipelineStepError(
                    f"Validation failed before step '{step_name}': "
                    f"{len(errors)} error(s)",
                    step_name=step_name,
                )
        except PipelineStepError:
            raise
        except Exception as exc:
            raise PipelineStepError(
                f"Validation error before step '{step_name}': {exc}",
                step_name=step_name,
            ) from exc

        return data
