"""Pre-built pystator state machine definitions for agents."""

from __future__ import annotations

from typing import Any


def base_lifecycle_config() -> dict[str, Any]:
    """Base agent lifecycle machine config.

    States: idle -> running -> paused -> stopped, plus error transitions.

    Returns:
        Machine config dict for StateMachine.from_dict().
    """
    return {
        "meta": {
            "machine_name": "agent_lifecycle",
            "version": "1.0.0",
        },
        "states": [
            {
                "name": "idle",
                "type": "initial",
                "description": "Agent is idle, not processing",
            },
            {
                "name": "running",
                "type": "stable",
                "description": "Agent is actively processing",
            },
            {
                "name": "paused",
                "type": "stable",
                "description": "Agent is paused",
            },
            {
                "name": "stopped",
                "type": "terminal",
                "description": "Agent has stopped",
            },
            {
                "name": "error",
                "type": "error",
                "description": "Agent encountered an error",
            },
        ],
        "transitions": [
            {
                "trigger": "start",
                "source": "idle",
                "dest": "running",
            },
            {
                "trigger": "pause",
                "source": "running",
                "dest": "paused",
            },
            {
                "trigger": "resume",
                "source": "paused",
                "dest": "running",
            },
            {
                "trigger": "stop",
                "source": ["running", "paused", "idle"],
                "dest": "stopped",
            },
            {
                "trigger": "fail",
                "source": ["running", "paused"],
                "dest": "error",
            },
            {
                "trigger": "recover",
                "source": "error",
                "dest": "idle",
            },
        ],
    }


def pipeline_lifecycle_config() -> dict[str, Any]:
    """Pipeline agent lifecycle machine config.

    States: idle -> extracting -> transforming -> loading -> completed,
    with per-step error transitions.

    Returns:
        Machine config dict for StateMachine.from_dict().
    """
    return {
        "meta": {
            "machine_name": "pipeline_lifecycle",
            "version": "1.0.0",
        },
        "states": [
            {
                "name": "idle",
                "type": "initial",
                "description": "Pipeline idle",
            },
            {
                "name": "extracting",
                "type": "stable",
                "description": "Extracting data",
            },
            {
                "name": "transforming",
                "type": "stable",
                "description": "Transforming data",
            },
            {
                "name": "loading",
                "type": "stable",
                "description": "Loading data to destination",
            },
            {
                "name": "completed",
                "type": "terminal",
                "description": "Pipeline completed successfully",
            },
            {
                "name": "error",
                "type": "error",
                "description": "Pipeline step failed",
            },
        ],
        "transitions": [
            {
                "trigger": "start_extract",
                "source": "idle",
                "dest": "extracting",
            },
            {
                "trigger": "extract_done",
                "source": "extracting",
                "dest": "transforming",
            },
            {
                "trigger": "transform_done",
                "source": "transforming",
                "dest": "loading",
            },
            {
                "trigger": "load_done",
                "source": "loading",
                "dest": "completed",
            },
            {
                "trigger": "fail",
                "source": [
                    "extracting",
                    "transforming",
                    "loading",
                ],
                "dest": "error",
            },
            {
                "trigger": "retry",
                "source": "error",
                "dest": "idle",
            },
        ],
    }


def llm_lifecycle_config(max_iterations: int = 10) -> dict[str, Any]:
    """LLM agent lifecycle machine config.

    States: idle -> thinking -> acting -> observing -> deciding ->
    (thinking | completed), with max_iterations guard.

    Args:
        max_iterations: Maximum think-act-observe iterations.

    Returns:
        Machine config dict for StateMachine.from_dict().
    """
    return {
        "meta": {
            "machine_name": "llm_lifecycle",
            "version": "1.0.0",
            "max_iterations": max_iterations,
        },
        "states": [
            {
                "name": "idle",
                "type": "initial",
                "description": "LLM agent idle",
            },
            {
                "name": "thinking",
                "type": "stable",
                "description": "LLM is generating a response",
            },
            {
                "name": "acting",
                "type": "stable",
                "description": "Executing tool calls",
            },
            {
                "name": "observing",
                "type": "stable",
                "description": "Processing tool results",
            },
            {
                "name": "deciding",
                "type": "stable",
                "description": "Deciding next step",
            },
            {
                "name": "completed",
                "type": "terminal",
                "description": "LLM agent finished",
            },
            {
                "name": "error",
                "type": "error",
                "description": "LLM agent error",
            },
        ],
        "transitions": [
            {
                "trigger": "start",
                "source": "idle",
                "dest": "thinking",
            },
            {
                "trigger": "thought",
                "source": "thinking",
                "dest": "acting",
            },
            {
                "trigger": "no_tools",
                "source": "thinking",
                "dest": "completed",
            },
            {
                "trigger": "acted",
                "source": "acting",
                "dest": "observing",
            },
            {
                "trigger": "observed",
                "source": "observing",
                "dest": "deciding",
            },
            {
                "trigger": "continue",
                "source": "deciding",
                "dest": "thinking",
            },
            {
                "trigger": "finish",
                "source": "deciding",
                "dest": "completed",
            },
            {
                "trigger": "fail",
                "source": [
                    "thinking",
                    "acting",
                    "observing",
                    "deciding",
                ],
                "dest": "error",
            },
            {
                "trigger": "recover",
                "source": "error",
                "dest": "idle",
            },
        ],
    }
