"""Factory functions for creating agents from database records."""

from __future__ import annotations

import importlib
import logging
from collections.abc import Callable

from pygubernator._events import EventBus
from pygubernator._protocols import LLMProvider
from pygubernator.agents._llm import LLMAgent
from pygubernator.db.models import AgentVersion
from pygubernator.errors import ConfigError
from pygubernator.tools._registry import ToolRegistry

logger = logging.getLogger(__name__)

__all__ = [
    "create_llm_agent_from_version",
    "load_tools_from_version",
]


def load_tools_from_version(
    version: AgentVersion,
    registry: ToolRegistry | None = None,
) -> ToolRegistry:
    """Load tools from an AgentVersion's tools dict into a ToolRegistry.

    Supports tool references in the format:
    {
        "tool_name": {
            "module": "path.to.module",
            "function": "function_name"
        }
    }

    Args:
        version: AgentVersion record containing tools dict.
        registry: Optional existing registry to add tools to. Creates new if None.

    Returns:
        ToolRegistry with loaded tools.

    Raises:
        ConfigError: If tool loading fails.
    """
    if registry is None:
        registry = ToolRegistry()

    if not version.tools:
        return registry

    for tool_name, tool_spec in version.tools.items():
        if not isinstance(tool_spec, dict):
            logger.warning(
                "Tool '%s' has invalid spec (expected dict), skipping",
                tool_name,
            )
            continue

        # Support reference format: {"module": "...", "function": "..."}
        if "module" in tool_spec and "function" in tool_spec:
            try:
                module_path = tool_spec["module"]
                func_name = tool_spec["function"]
                module = importlib.import_module(module_path)
                tool_func = getattr(module, func_name)
                registry.register(tool_func)
                logger.debug(
                    "Loaded tool '%s' from %s.%s", tool_name, module_path, func_name
                )
            except (ImportError, AttributeError) as exc:
                raise ConfigError(
                    f"Failed to load tool '{tool_name}': {exc}",
                ) from exc
        else:
            logger.warning(
                "Tool '%s' spec missing 'module'/'function', skipping",
                tool_name,
            )

    return registry


def _default_provider_factory(model: str | None) -> LLMProvider:
    """Default factory using create_provider with auto-detection."""
    from pygubernator.llm._factory import create_provider

    return create_provider(model or "gpt-4")


def create_llm_agent_from_version(
    version: AgentVersion,
    llm_provider_factory: (Callable[[str | None], LLMProvider] | None) = None,
    tool_loader: (
        Callable[[AgentVersion, ToolRegistry | None], ToolRegistry] | None
    ) = None,
    event_bus: EventBus | None = None,
    run_id: str | None = None,
) -> LLMAgent:
    """Create an LLMAgent instance from an AgentVersion database record.

    Args:
        version: AgentVersion record containing model, prompt, tools, config.
        llm_provider_factory: Callable that takes model string (or None)
            and returns LLMProvider.
        tool_loader: Optional custom tool loader. Defaults to load_tools_from_version.
        event_bus: Optional event bus for the agent.
        run_id: Optional run identifier for correlating events.

    Returns:
        Configured LLMAgent instance.

    Example:
        >>> from pygubernator.llm._provider import LiteLLMProvider
        >>> version = db.get(AgentVersion, version_id)
        >>> agent = create_llm_agent_from_version(
        ...     version,
        ...     llm_provider_factory=lambda m: LiteLLMProvider(
        ...         model=m or "gpt-4o-mini"
        ...     ),
        ...     run_id=run_id,
        ... )
    """
    # Extract config values
    config = version.config or {}

    # Create LLM provider — prefer structured config, then factory
    provider_dict = config.get("provider")
    if provider_dict and isinstance(provider_dict, dict):
        from pygubernator.llm._config import ProviderConfig, ProviderType
        from pygubernator.llm._factory import create_provider_from_config

        pc = ProviderConfig(
            provider_type=ProviderType(provider_dict["provider_type"]),
            model=provider_dict.get("model", version.model or ""),
            api_base=provider_dict.get("api_base"),
            api_key=provider_dict.get("api_key"),
            max_tokens=provider_dict.get("max_tokens", 4096),
            temperature=provider_dict.get("temperature", 0.0),
            top_p=provider_dict.get("top_p"),
            top_k=provider_dict.get("top_k"),
            model_path=provider_dict.get("model_path"),
            n_ctx=provider_dict.get("n_ctx", 4096),
            n_gpu_layers=provider_dict.get("n_gpu_layers", -1),
        )
        llm_provider = create_provider_from_config(pc)
    else:
        factory = llm_provider_factory or _default_provider_factory
        llm_provider = factory(version.model)

    # Load tools
    if tool_loader is None:
        tool_loader = load_tools_from_version
    tool_registry = tool_loader(version, None)
    max_iterations = config.get("max_iterations", 10)
    if not isinstance(max_iterations, int) or max_iterations < 1:
        logger.warning(
            "Invalid max_iterations in config, using default: 10",
        )
        max_iterations = 10

    # Create agent (only pass registry if it has tools)
    final_registry = tool_registry if len(tool_registry) > 0 else None

    agent = LLMAgent(
        agent_id=version.agent_id,
        llm_provider=llm_provider,
        tool_registry=final_registry,
        system_prompt=version.prompt or "",
        max_iterations=max_iterations,
        event_bus=event_bus,
        run_id=run_id,
    )

    return agent
