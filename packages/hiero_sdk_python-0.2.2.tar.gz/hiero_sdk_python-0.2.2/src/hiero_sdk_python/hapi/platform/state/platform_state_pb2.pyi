from ...services import basic_types_pb2 as _basic_types_pb2
from ...services import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PlatformState(_message.Message):
    __slots__ = ("creation_software_version", "rounds_non_ancient", "consensus_snapshot", "freeze_time", "last_frozen_time", "latest_freeze_round", "legacy_running_event_hash")
    CREATION_SOFTWARE_VERSION_FIELD_NUMBER: _ClassVar[int]
    ROUNDS_NON_ANCIENT_FIELD_NUMBER: _ClassVar[int]
    CONSENSUS_SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    FREEZE_TIME_FIELD_NUMBER: _ClassVar[int]
    LAST_FROZEN_TIME_FIELD_NUMBER: _ClassVar[int]
    LATEST_FREEZE_ROUND_FIELD_NUMBER: _ClassVar[int]
    LEGACY_RUNNING_EVENT_HASH_FIELD_NUMBER: _ClassVar[int]
    creation_software_version: _basic_types_pb2.SemanticVersion
    rounds_non_ancient: int
    consensus_snapshot: ConsensusSnapshot
    freeze_time: _timestamp_pb2.Timestamp
    last_frozen_time: _timestamp_pb2.Timestamp
    latest_freeze_round: int
    legacy_running_event_hash: bytes
    def __init__(self, creation_software_version: _Optional[_Union[_basic_types_pb2.SemanticVersion, _Mapping]] = ..., rounds_non_ancient: _Optional[int] = ..., consensus_snapshot: _Optional[_Union[ConsensusSnapshot, _Mapping]] = ..., freeze_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., last_frozen_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., latest_freeze_round: _Optional[int] = ..., legacy_running_event_hash: _Optional[bytes] = ...) -> None: ...

class ConsensusSnapshot(_message.Message):
    __slots__ = ("round", "minimum_judge_info_list", "next_consensus_number", "consensus_timestamp", "judge_ids")
    ROUND_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_JUDGE_INFO_LIST_FIELD_NUMBER: _ClassVar[int]
    NEXT_CONSENSUS_NUMBER_FIELD_NUMBER: _ClassVar[int]
    CONSENSUS_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    JUDGE_IDS_FIELD_NUMBER: _ClassVar[int]
    round: int
    minimum_judge_info_list: _containers.RepeatedCompositeFieldContainer[MinimumJudgeInfo]
    next_consensus_number: int
    consensus_timestamp: _timestamp_pb2.Timestamp
    judge_ids: _containers.RepeatedCompositeFieldContainer[JudgeId]
    def __init__(self, round: _Optional[int] = ..., minimum_judge_info_list: _Optional[_Iterable[_Union[MinimumJudgeInfo, _Mapping]]] = ..., next_consensus_number: _Optional[int] = ..., consensus_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., judge_ids: _Optional[_Iterable[_Union[JudgeId, _Mapping]]] = ...) -> None: ...

class JudgeId(_message.Message):
    __slots__ = ("creator_id", "judge_hash")
    CREATOR_ID_FIELD_NUMBER: _ClassVar[int]
    JUDGE_HASH_FIELD_NUMBER: _ClassVar[int]
    creator_id: int
    judge_hash: bytes
    def __init__(self, creator_id: _Optional[int] = ..., judge_hash: _Optional[bytes] = ...) -> None: ...

class MinimumJudgeInfo(_message.Message):
    __slots__ = ("round", "minimum_judge_birth_round")
    ROUND_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_JUDGE_BIRTH_ROUND_FIELD_NUMBER: _ClassVar[int]
    round: int
    minimum_judge_birth_round: int
    def __init__(self, round: _Optional[int] = ..., minimum_judge_birth_round: _Optional[int] = ...) -> None: ...

class NodeId(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: int
    def __init__(self, id: _Optional[int] = ...) -> None: ...

class SigSet(_message.Message):
    __slots__ = ("nodeIdSignaturePairs",)
    NODEIDSIGNATUREPAIRS_FIELD_NUMBER: _ClassVar[int]
    nodeIdSignaturePairs: _containers.RepeatedCompositeFieldContainer[NodeIdSignaturePair]
    def __init__(self, nodeIdSignaturePairs: _Optional[_Iterable[_Union[NodeIdSignaturePair, _Mapping]]] = ...) -> None: ...

class NodeIdSignaturePair(_message.Message):
    __slots__ = ("nodeId", "signatureType", "signatureBytes")
    NODEID_FIELD_NUMBER: _ClassVar[int]
    SIGNATURETYPE_FIELD_NUMBER: _ClassVar[int]
    SIGNATUREBYTES_FIELD_NUMBER: _ClassVar[int]
    nodeId: int
    signatureType: int
    signatureBytes: bytes
    def __init__(self, nodeId: _Optional[int] = ..., signatureType: _Optional[int] = ..., signatureBytes: _Optional[bytes] = ...) -> None: ...
