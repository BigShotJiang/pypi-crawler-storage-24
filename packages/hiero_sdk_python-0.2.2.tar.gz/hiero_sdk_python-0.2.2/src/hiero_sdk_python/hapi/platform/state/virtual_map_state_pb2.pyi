from ...services import timestamp_pb2 as _timestamp_pb2
from ...services import basic_types_pb2 as _basic_types_pb2
from ...services import hook_types_pb2 as _hook_types_pb2
from ...services import exchange_rate_pb2 as _exchange_rate_pb2
from ...services.auxiliary.hints import crs_publication_pb2 as _crs_publication_pb2
from ...services.auxiliary.tss import tss_message_pb2 as _tss_message_pb2
from ...services.auxiliary.tss import tss_vote_pb2 as _tss_vote_pb2
from ...platform.state import platform_state_pb2 as _platform_state_pb2
from ...services.state import primitives_pb2 as _primitives_pb2
from ...services.state import common_pb2 as _common_pb2
from ...services.state.addressbook import node_pb2 as _node_pb2
from ...services.state.blockrecords import block_info_pb2 as _block_info_pb2
from ...services.state.blockrecords import running_hashes_pb2 as _running_hashes_pb2
from ...services.state.blockstream import block_stream_info_pb2 as _block_stream_info_pb2
from ...services.state.congestion import congestion_level_starts_pb2 as _congestion_level_starts_pb2
from ...services.state.consensus import topic_pb2 as _topic_pb2
from ...services.state.contract import bytecode_pb2 as _bytecode_pb2
from ...services.state.contract import storage_slot_pb2 as _storage_slot_pb2
from ...services.state.contract import evm_hook_state_pb2 as _evm_hook_state_pb2
from ...services.state.entity import entity_counts_pb2 as _entity_counts_pb2
from ...services.state.file import file_pb2 as _file_pb2
from ...services.state.hints import hints_types_pb2 as _hints_types_pb2
from ...services.state.history import history_types_pb2 as _history_types_pb2
from ...services.state.recordcache import recordcache_pb2 as _recordcache_pb2
from ...services.state.roster import roster_pb2 as _roster_pb2
from ...services.state.roster import roster_state_pb2 as _roster_state_pb2
from ...services.state.schedule import schedule_pb2 as _schedule_pb2
from ...services.state.throttles import throttle_usage_snapshots_pb2 as _throttle_usage_snapshots_pb2
from ...services.state.token import account_pb2 as _account_pb2
from ...services.state.token import account_pending_airdrop_pb2 as _account_pending_airdrop_pb2
from ...services.state.token import network_staking_rewards_pb2 as _network_staking_rewards_pb2
from ...services.state.token import node_rewards_pb2 as _node_rewards_pb2
from ...services.state.token import node_payments_pb2 as _node_payments_pb2
from ...services.state.token import nft_pb2 as _nft_pb2
from ...services.state.token import staking_node_info_pb2 as _staking_node_info_pb2
from ...services.state.token import token_pb2 as _token_pb2
from ...services.state.token import token_relation_pb2 as _token_relation_pb2
from ...services.state.tss import tss_encryption_keys_pb2 as _tss_encryption_keys_pb2
from ...services.state.tss import tss_message_map_key_pb2 as _tss_message_map_key_pb2
from ...services.state.tss import tss_vote_map_key_pb2 as _tss_vote_map_key_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SingletonType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNKNOWN: _ClassVar[SingletonType]
    EntityIdService_I_ENTITY_ID: _ClassVar[SingletonType]
    TokenService_I_STAKING_NETWORK_REWARDS: _ClassVar[SingletonType]
    CongestionThrottleService_I_THROTTLE_USAGE_SNAPSHOTS: _ClassVar[SingletonType]
    CongestionThrottleService_I_CONGESTION_LEVEL_STARTS: _ClassVar[SingletonType]
    FeeService_I_MIDNIGHT_RATES: _ClassVar[SingletonType]
    BlockRecordService_I_RUNNING_HASHES: _ClassVar[SingletonType]
    BlockRecordService_I_BLOCKS: _ClassVar[SingletonType]
    FreezeService_I_UPGRADE_FILE_HASH: _ClassVar[SingletonType]
    FreezeService_I_FREEZE_TIME: _ClassVar[SingletonType]
    BlockStreamService_I_BLOCK_STREAM_INFO: _ClassVar[SingletonType]
    PlatformStateService_I_PLATFORM_STATE: _ClassVar[SingletonType]
    RosterService_I_ROSTER_STATE: _ClassVar[SingletonType]
    HintsService_I_ACTIVE_HINTS_CONSTRUCTION: _ClassVar[SingletonType]
    HintsService_I_NEXT_HINTS_CONSTRUCTION: _ClassVar[SingletonType]
    EntityIdService_I_ENTITY_COUNTS: _ClassVar[SingletonType]
    HistoryService_I_LEDGER_ID: _ClassVar[SingletonType]
    HistoryService_I_ACTIVE_PROOF_CONSTRUCTION: _ClassVar[SingletonType]
    HistoryService_I_NEXT_PROOF_CONSTRUCTION: _ClassVar[SingletonType]
    HintsService_I_CRS_STATE: _ClassVar[SingletonType]
    TokenService_I_NODE_REWARDS: _ClassVar[SingletonType]
    TokenService_I_NODE_PAYMENTS: _ClassVar[SingletonType]
    RecordCache_I_TRANSACTION_RECEIPTS: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_150: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_151: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_152: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_153: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_154: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_155: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_156: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_157: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_158: _ClassVar[SingletonType]
    FileService_I_UPGRADE_DATA_159: _ClassVar[SingletonType]
UNKNOWN: SingletonType
EntityIdService_I_ENTITY_ID: SingletonType
TokenService_I_STAKING_NETWORK_REWARDS: SingletonType
CongestionThrottleService_I_THROTTLE_USAGE_SNAPSHOTS: SingletonType
CongestionThrottleService_I_CONGESTION_LEVEL_STARTS: SingletonType
FeeService_I_MIDNIGHT_RATES: SingletonType
BlockRecordService_I_RUNNING_HASHES: SingletonType
BlockRecordService_I_BLOCKS: SingletonType
FreezeService_I_UPGRADE_FILE_HASH: SingletonType
FreezeService_I_FREEZE_TIME: SingletonType
BlockStreamService_I_BLOCK_STREAM_INFO: SingletonType
PlatformStateService_I_PLATFORM_STATE: SingletonType
RosterService_I_ROSTER_STATE: SingletonType
HintsService_I_ACTIVE_HINTS_CONSTRUCTION: SingletonType
HintsService_I_NEXT_HINTS_CONSTRUCTION: SingletonType
EntityIdService_I_ENTITY_COUNTS: SingletonType
HistoryService_I_LEDGER_ID: SingletonType
HistoryService_I_ACTIVE_PROOF_CONSTRUCTION: SingletonType
HistoryService_I_NEXT_PROOF_CONSTRUCTION: SingletonType
HintsService_I_CRS_STATE: SingletonType
TokenService_I_NODE_REWARDS: SingletonType
TokenService_I_NODE_PAYMENTS: SingletonType
RecordCache_I_TRANSACTION_RECEIPTS: SingletonType
FileService_I_UPGRADE_DATA_150: SingletonType
FileService_I_UPGRADE_DATA_151: SingletonType
FileService_I_UPGRADE_DATA_152: SingletonType
FileService_I_UPGRADE_DATA_153: SingletonType
FileService_I_UPGRADE_DATA_154: SingletonType
FileService_I_UPGRADE_DATA_155: SingletonType
FileService_I_UPGRADE_DATA_156: SingletonType
FileService_I_UPGRADE_DATA_157: SingletonType
FileService_I_UPGRADE_DATA_158: SingletonType
FileService_I_UPGRADE_DATA_159: SingletonType

class StateItem(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: StateKey
    value: StateValue
    def __init__(self, key: _Optional[_Union[StateKey, _Mapping]] = ..., value: _Optional[_Union[StateValue, _Mapping]] = ...) -> None: ...

class QueueState(_message.Message):
    __slots__ = ("head", "tail")
    HEAD_FIELD_NUMBER: _ClassVar[int]
    TAIL_FIELD_NUMBER: _ClassVar[int]
    head: int
    tail: int
    def __init__(self, head: _Optional[int] = ..., tail: _Optional[int] = ...) -> None: ...

class StateKey(_message.Message):
    __slots__ = ("singleton", "TokenService_I_ACCOUNTS", "TokenService_I_ALIASES", "ContractService_I_STORAGE", "ContractService_I_BYTECODE", "FileService_I_FILES", "TokenService_I_TOKENS", "TokenService_I_NFTS", "TokenService_I_TOKEN_RELS", "TokenService_I_STAKING_INFOS", "ScheduleService_I_SCHEDULES_BY_ID", "ScheduleService_I_SCHEDULES_BY_EXPIRY_SEC", "ScheduleService_I_SCHEDULES_BY_EQUALITY", "AddressBookService_I_NODES", "ConsensusService_I_TOPICS", "TokenService_I_PENDING_AIRDROPS", "RosterService_I_ROSTERS", "ScheduleService_I_SCHEDULED_COUNTS", "ScheduleService_I_SCHEDULE_ID_BY_EQUALITY", "TssBaseService_I_TSS_MESSAGES", "TssBaseService_I_TSS_VOTES", "ScheduleService_I_SCHEDULED_ORDERS", "ScheduleService_I_SCHEDULED_USAGES", "TssBaseService_I_TSS_ENCRYPTION_KEYS", "HintsService_I_HINTS_KEY_SETS", "HintsService_I_PREPROCESSING_VOTES", "HistoryService_I_PROOF_KEY_SETS", "HistoryService_I_HISTORY_SIGNATURES", "HistoryService_I_PROOF_VOTES", "HintsService_I_CRS_PUBLICATIONS", "ContractService_I_EVM_HOOK_STATES", "ContractService_I_EVM_HOOK_STORAGE", "AddressBookService_I_ACCOUNT_NODE_REL", "HistoryService_I_WRAPS_MESSAGE_HISTORIES", "RecordCache_I_TRANSACTION_RECEIPTS", "FileService_I_UPGRADE_DATA_150", "FileService_I_UPGRADE_DATA_151", "FileService_I_UPGRADE_DATA_152", "FileService_I_UPGRADE_DATA_153", "FileService_I_UPGRADE_DATA_154", "FileService_I_UPGRADE_DATA_155", "FileService_I_UPGRADE_DATA_156", "FileService_I_UPGRADE_DATA_157", "FileService_I_UPGRADE_DATA_158", "FileService_I_UPGRADE_DATA_159")
    SINGLETON_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_ACCOUNTS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_ALIASES_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_STORAGE_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_BYTECODE_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_FILES_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_NFTS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_TOKEN_RELS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_STAKING_INFOS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULES_BY_ID_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULES_BY_EXPIRY_SEC_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULES_BY_EQUALITY_FIELD_NUMBER: _ClassVar[int]
    ADDRESSBOOKSERVICE_I_NODES_FIELD_NUMBER: _ClassVar[int]
    CONSENSUSSERVICE_I_TOPICS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_PENDING_AIRDROPS_FIELD_NUMBER: _ClassVar[int]
    ROSTERSERVICE_I_ROSTERS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULED_COUNTS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULE_ID_BY_EQUALITY_FIELD_NUMBER: _ClassVar[int]
    TSSBASESERVICE_I_TSS_MESSAGES_FIELD_NUMBER: _ClassVar[int]
    TSSBASESERVICE_I_TSS_VOTES_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULED_ORDERS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULED_USAGES_FIELD_NUMBER: _ClassVar[int]
    TSSBASESERVICE_I_TSS_ENCRYPTION_KEYS_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_HINTS_KEY_SETS_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_PREPROCESSING_VOTES_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_PROOF_KEY_SETS_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_HISTORY_SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_PROOF_VOTES_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_CRS_PUBLICATIONS_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_EVM_HOOK_STATES_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_EVM_HOOK_STORAGE_FIELD_NUMBER: _ClassVar[int]
    ADDRESSBOOKSERVICE_I_ACCOUNT_NODE_REL_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_WRAPS_MESSAGE_HISTORIES_FIELD_NUMBER: _ClassVar[int]
    RECORDCACHE_I_TRANSACTION_RECEIPTS_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_150_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_151_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_152_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_153_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_154_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_155_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_156_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_157_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_158_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_159_FIELD_NUMBER: _ClassVar[int]
    singleton: SingletonType
    TokenService_I_ACCOUNTS: _basic_types_pb2.AccountID
    TokenService_I_ALIASES: _primitives_pb2.ProtoBytes
    ContractService_I_STORAGE: _storage_slot_pb2.SlotKey
    ContractService_I_BYTECODE: _basic_types_pb2.ContractID
    FileService_I_FILES: _basic_types_pb2.FileID
    TokenService_I_TOKENS: _basic_types_pb2.TokenID
    TokenService_I_NFTS: _basic_types_pb2.NftID
    TokenService_I_TOKEN_RELS: _common_pb2.EntityIDPair
    TokenService_I_STAKING_INFOS: _common_pb2.EntityNumber
    ScheduleService_I_SCHEDULES_BY_ID: _basic_types_pb2.ScheduleID
    ScheduleService_I_SCHEDULES_BY_EXPIRY_SEC: _primitives_pb2.ProtoLong
    ScheduleService_I_SCHEDULES_BY_EQUALITY: _primitives_pb2.ProtoBytes
    AddressBookService_I_NODES: _common_pb2.EntityNumber
    ConsensusService_I_TOPICS: _basic_types_pb2.TopicID
    TokenService_I_PENDING_AIRDROPS: _basic_types_pb2.PendingAirdropId
    RosterService_I_ROSTERS: _primitives_pb2.ProtoBytes
    ScheduleService_I_SCHEDULED_COUNTS: _timestamp_pb2.TimestampSeconds
    ScheduleService_I_SCHEDULE_ID_BY_EQUALITY: _primitives_pb2.ProtoBytes
    TssBaseService_I_TSS_MESSAGES: _tss_message_map_key_pb2.TssMessageMapKey
    TssBaseService_I_TSS_VOTES: _tss_vote_map_key_pb2.TssVoteMapKey
    ScheduleService_I_SCHEDULED_ORDERS: _schedule_pb2.ScheduledOrder
    ScheduleService_I_SCHEDULED_USAGES: _timestamp_pb2.TimestampSeconds
    TssBaseService_I_TSS_ENCRYPTION_KEYS: _common_pb2.EntityNumber
    HintsService_I_HINTS_KEY_SETS: _hints_types_pb2.HintsPartyId
    HintsService_I_PREPROCESSING_VOTES: _hints_types_pb2.PreprocessingVoteId
    HistoryService_I_PROOF_KEY_SETS: _platform_state_pb2.NodeId
    HistoryService_I_HISTORY_SIGNATURES: _history_types_pb2.ConstructionNodeId
    HistoryService_I_PROOF_VOTES: _history_types_pb2.ConstructionNodeId
    HintsService_I_CRS_PUBLICATIONS: _platform_state_pb2.NodeId
    ContractService_I_EVM_HOOK_STATES: _basic_types_pb2.HookId
    ContractService_I_EVM_HOOK_STORAGE: _evm_hook_state_pb2.EvmHookSlotKey
    AddressBookService_I_ACCOUNT_NODE_REL: _basic_types_pb2.AccountID
    HistoryService_I_WRAPS_MESSAGE_HISTORIES: _history_types_pb2.ConstructionNodeId
    RecordCache_I_TRANSACTION_RECEIPTS: int
    FileService_I_UPGRADE_DATA_150: int
    FileService_I_UPGRADE_DATA_151: int
    FileService_I_UPGRADE_DATA_152: int
    FileService_I_UPGRADE_DATA_153: int
    FileService_I_UPGRADE_DATA_154: int
    FileService_I_UPGRADE_DATA_155: int
    FileService_I_UPGRADE_DATA_156: int
    FileService_I_UPGRADE_DATA_157: int
    FileService_I_UPGRADE_DATA_158: int
    FileService_I_UPGRADE_DATA_159: int
    def __init__(self, singleton: _Optional[_Union[SingletonType, str]] = ..., TokenService_I_ACCOUNTS: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., TokenService_I_ALIASES: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., ContractService_I_STORAGE: _Optional[_Union[_storage_slot_pb2.SlotKey, _Mapping]] = ..., ContractService_I_BYTECODE: _Optional[_Union[_basic_types_pb2.ContractID, _Mapping]] = ..., FileService_I_FILES: _Optional[_Union[_basic_types_pb2.FileID, _Mapping]] = ..., TokenService_I_TOKENS: _Optional[_Union[_basic_types_pb2.TokenID, _Mapping]] = ..., TokenService_I_NFTS: _Optional[_Union[_basic_types_pb2.NftID, _Mapping]] = ..., TokenService_I_TOKEN_RELS: _Optional[_Union[_common_pb2.EntityIDPair, _Mapping]] = ..., TokenService_I_STAKING_INFOS: _Optional[_Union[_common_pb2.EntityNumber, _Mapping]] = ..., ScheduleService_I_SCHEDULES_BY_ID: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., ScheduleService_I_SCHEDULES_BY_EXPIRY_SEC: _Optional[_Union[_primitives_pb2.ProtoLong, _Mapping]] = ..., ScheduleService_I_SCHEDULES_BY_EQUALITY: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., AddressBookService_I_NODES: _Optional[_Union[_common_pb2.EntityNumber, _Mapping]] = ..., ConsensusService_I_TOPICS: _Optional[_Union[_basic_types_pb2.TopicID, _Mapping]] = ..., TokenService_I_PENDING_AIRDROPS: _Optional[_Union[_basic_types_pb2.PendingAirdropId, _Mapping]] = ..., RosterService_I_ROSTERS: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., ScheduleService_I_SCHEDULED_COUNTS: _Optional[_Union[_timestamp_pb2.TimestampSeconds, _Mapping]] = ..., ScheduleService_I_SCHEDULE_ID_BY_EQUALITY: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., TssBaseService_I_TSS_MESSAGES: _Optional[_Union[_tss_message_map_key_pb2.TssMessageMapKey, _Mapping]] = ..., TssBaseService_I_TSS_VOTES: _Optional[_Union[_tss_vote_map_key_pb2.TssVoteMapKey, _Mapping]] = ..., ScheduleService_I_SCHEDULED_ORDERS: _Optional[_Union[_schedule_pb2.ScheduledOrder, _Mapping]] = ..., ScheduleService_I_SCHEDULED_USAGES: _Optional[_Union[_timestamp_pb2.TimestampSeconds, _Mapping]] = ..., TssBaseService_I_TSS_ENCRYPTION_KEYS: _Optional[_Union[_common_pb2.EntityNumber, _Mapping]] = ..., HintsService_I_HINTS_KEY_SETS: _Optional[_Union[_hints_types_pb2.HintsPartyId, _Mapping]] = ..., HintsService_I_PREPROCESSING_VOTES: _Optional[_Union[_hints_types_pb2.PreprocessingVoteId, _Mapping]] = ..., HistoryService_I_PROOF_KEY_SETS: _Optional[_Union[_platform_state_pb2.NodeId, _Mapping]] = ..., HistoryService_I_HISTORY_SIGNATURES: _Optional[_Union[_history_types_pb2.ConstructionNodeId, _Mapping]] = ..., HistoryService_I_PROOF_VOTES: _Optional[_Union[_history_types_pb2.ConstructionNodeId, _Mapping]] = ..., HintsService_I_CRS_PUBLICATIONS: _Optional[_Union[_platform_state_pb2.NodeId, _Mapping]] = ..., ContractService_I_EVM_HOOK_STATES: _Optional[_Union[_basic_types_pb2.HookId, _Mapping]] = ..., ContractService_I_EVM_HOOK_STORAGE: _Optional[_Union[_evm_hook_state_pb2.EvmHookSlotKey, _Mapping]] = ..., AddressBookService_I_ACCOUNT_NODE_REL: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., HistoryService_I_WRAPS_MESSAGE_HISTORIES: _Optional[_Union[_history_types_pb2.ConstructionNodeId, _Mapping]] = ..., RecordCache_I_TRANSACTION_RECEIPTS: _Optional[int] = ..., FileService_I_UPGRADE_DATA_150: _Optional[int] = ..., FileService_I_UPGRADE_DATA_151: _Optional[int] = ..., FileService_I_UPGRADE_DATA_152: _Optional[int] = ..., FileService_I_UPGRADE_DATA_153: _Optional[int] = ..., FileService_I_UPGRADE_DATA_154: _Optional[int] = ..., FileService_I_UPGRADE_DATA_155: _Optional[int] = ..., FileService_I_UPGRADE_DATA_156: _Optional[int] = ..., FileService_I_UPGRADE_DATA_157: _Optional[int] = ..., FileService_I_UPGRADE_DATA_158: _Optional[int] = ..., FileService_I_UPGRADE_DATA_159: _Optional[int] = ...) -> None: ...

class StateValue(_message.Message):
    __slots__ = ("EntityIdService_I_ENTITY_ID", "TokenService_I_ACCOUNTS", "TokenService_I_ALIASES", "ContractService_I_STORAGE", "ContractService_I_BYTECODE", "FileService_I_FILES", "TokenService_I_TOKENS", "TokenService_I_NFTS", "TokenService_I_TOKEN_RELS", "TokenService_I_STAKING_INFOS", "TokenService_I_STAKING_NETWORK_REWARDS", "CongestionThrottleService_I_THROTTLE_USAGE_SNAPSHOTS", "CongestionThrottleService_I_CONGESTION_LEVEL_STARTS", "ScheduleService_I_SCHEDULES_BY_ID", "ScheduleService_I_SCHEDULES_BY_EXPIRY_SEC", "ScheduleService_I_SCHEDULES_BY_EQUALITY", "FeeService_I_MIDNIGHT_RATES", "BlockRecordService_I_RUNNING_HASHES", "BlockRecordService_I_BLOCKS", "AddressBookService_I_NODES", "ConsensusService_I_TOPICS", "FreezeService_I_UPGRADE_FILE_HASH", "FreezeService_I_FREEZE_TIME", "BlockStreamService_I_BLOCK_STREAM_INFO", "TokenService_I_PENDING_AIRDROPS", "PlatformStateService_I_PLATFORM_STATE", "RosterService_I_ROSTER_STATE", "RosterService_I_ROSTERS", "ScheduleService_I_SCHEDULED_COUNTS", "ScheduleService_I_SCHEDULE_ID_BY_EQUALITY", "TssBaseService_I_TSS_MESSAGES", "TssBaseService_I_TSS_VOTES", "ScheduleService_I_SCHEDULED_ORDERS", "ScheduleService_I_SCHEDULED_USAGES", "TssBaseService_I_TSS_ENCRYPTION_KEYS", "HintsService_I_HINTS_KEY_SETS", "HintsService_I_ACTIVE_HINTS_CONSTRUCTION", "HintsService_I_NEXT_HINTS_CONSTRUCTION", "HintsService_I_PREPROCESSING_VOTES", "EntityIdService_I_ENTITY_COUNTS", "HistoryService_I_LEDGER_ID", "HistoryService_I_PROOF_KEY_SETS", "HistoryService_I_ACTIVE_PROOF_CONSTRUCTION", "HistoryService_I_NEXT_PROOF_CONSTRUCTION", "HistoryService_I_HISTORY_SIGNATURES", "HistoryService_I_PROOF_VOTES", "HintsService_I_CRS_STATE", "HintsService_I_CRS_PUBLICATIONS", "TokenService_I_NODE_REWARDS", "ContractService_I_EVM_HOOK_STATES", "ContractService_I_EVM_HOOK_STORAGE", "AddressBookService_I_ACCOUNT_NODE_REL", "HistoryService_I_WRAPS_MESSAGE_HISTORIES", "TokenService_I_NODE_PAYMENTS", "RecordCache_I_TRANSACTION_RECEIPTS", "queue_state", "FileService_I_UPGRADE_DATA_150", "FileService_I_UPGRADE_DATA_151", "FileService_I_UPGRADE_DATA_152", "FileService_I_UPGRADE_DATA_153", "FileService_I_UPGRADE_DATA_154", "FileService_I_UPGRADE_DATA_155", "FileService_I_UPGRADE_DATA_156", "FileService_I_UPGRADE_DATA_157", "FileService_I_UPGRADE_DATA_158", "FileService_I_UPGRADE_DATA_159")
    ENTITYIDSERVICE_I_ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_ACCOUNTS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_ALIASES_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_STORAGE_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_BYTECODE_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_FILES_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_NFTS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_TOKEN_RELS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_STAKING_INFOS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_STAKING_NETWORK_REWARDS_FIELD_NUMBER: _ClassVar[int]
    CONGESTIONTHROTTLESERVICE_I_THROTTLE_USAGE_SNAPSHOTS_FIELD_NUMBER: _ClassVar[int]
    CONGESTIONTHROTTLESERVICE_I_CONGESTION_LEVEL_STARTS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULES_BY_ID_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULES_BY_EXPIRY_SEC_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULES_BY_EQUALITY_FIELD_NUMBER: _ClassVar[int]
    FEESERVICE_I_MIDNIGHT_RATES_FIELD_NUMBER: _ClassVar[int]
    BLOCKRECORDSERVICE_I_RUNNING_HASHES_FIELD_NUMBER: _ClassVar[int]
    BLOCKRECORDSERVICE_I_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    ADDRESSBOOKSERVICE_I_NODES_FIELD_NUMBER: _ClassVar[int]
    CONSENSUSSERVICE_I_TOPICS_FIELD_NUMBER: _ClassVar[int]
    FREEZESERVICE_I_UPGRADE_FILE_HASH_FIELD_NUMBER: _ClassVar[int]
    FREEZESERVICE_I_FREEZE_TIME_FIELD_NUMBER: _ClassVar[int]
    BLOCKSTREAMSERVICE_I_BLOCK_STREAM_INFO_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_PENDING_AIRDROPS_FIELD_NUMBER: _ClassVar[int]
    PLATFORMSTATESERVICE_I_PLATFORM_STATE_FIELD_NUMBER: _ClassVar[int]
    ROSTERSERVICE_I_ROSTER_STATE_FIELD_NUMBER: _ClassVar[int]
    ROSTERSERVICE_I_ROSTERS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULED_COUNTS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULE_ID_BY_EQUALITY_FIELD_NUMBER: _ClassVar[int]
    TSSBASESERVICE_I_TSS_MESSAGES_FIELD_NUMBER: _ClassVar[int]
    TSSBASESERVICE_I_TSS_VOTES_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULED_ORDERS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULESERVICE_I_SCHEDULED_USAGES_FIELD_NUMBER: _ClassVar[int]
    TSSBASESERVICE_I_TSS_ENCRYPTION_KEYS_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_HINTS_KEY_SETS_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_ACTIVE_HINTS_CONSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_NEXT_HINTS_CONSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_PREPROCESSING_VOTES_FIELD_NUMBER: _ClassVar[int]
    ENTITYIDSERVICE_I_ENTITY_COUNTS_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_LEDGER_ID_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_PROOF_KEY_SETS_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_ACTIVE_PROOF_CONSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_NEXT_PROOF_CONSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_HISTORY_SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_PROOF_VOTES_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_CRS_STATE_FIELD_NUMBER: _ClassVar[int]
    HINTSSERVICE_I_CRS_PUBLICATIONS_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_NODE_REWARDS_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_EVM_HOOK_STATES_FIELD_NUMBER: _ClassVar[int]
    CONTRACTSERVICE_I_EVM_HOOK_STORAGE_FIELD_NUMBER: _ClassVar[int]
    ADDRESSBOOKSERVICE_I_ACCOUNT_NODE_REL_FIELD_NUMBER: _ClassVar[int]
    HISTORYSERVICE_I_WRAPS_MESSAGE_HISTORIES_FIELD_NUMBER: _ClassVar[int]
    TOKENSERVICE_I_NODE_PAYMENTS_FIELD_NUMBER: _ClassVar[int]
    RECORDCACHE_I_TRANSACTION_RECEIPTS_FIELD_NUMBER: _ClassVar[int]
    QUEUE_STATE_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_150_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_151_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_152_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_153_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_154_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_155_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_156_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_157_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_158_FIELD_NUMBER: _ClassVar[int]
    FILESERVICE_I_UPGRADE_DATA_159_FIELD_NUMBER: _ClassVar[int]
    EntityIdService_I_ENTITY_ID: _common_pb2.EntityNumber
    TokenService_I_ACCOUNTS: _account_pb2.Account
    TokenService_I_ALIASES: _basic_types_pb2.AccountID
    ContractService_I_STORAGE: _storage_slot_pb2.SlotValue
    ContractService_I_BYTECODE: _bytecode_pb2.Bytecode
    FileService_I_FILES: _file_pb2.File
    TokenService_I_TOKENS: _token_pb2.Token
    TokenService_I_NFTS: _nft_pb2.Nft
    TokenService_I_TOKEN_RELS: _token_relation_pb2.TokenRelation
    TokenService_I_STAKING_INFOS: _staking_node_info_pb2.StakingNodeInfo
    TokenService_I_STAKING_NETWORK_REWARDS: _network_staking_rewards_pb2.NetworkStakingRewards
    CongestionThrottleService_I_THROTTLE_USAGE_SNAPSHOTS: _throttle_usage_snapshots_pb2.ThrottleUsageSnapshots
    CongestionThrottleService_I_CONGESTION_LEVEL_STARTS: _congestion_level_starts_pb2.CongestionLevelStarts
    ScheduleService_I_SCHEDULES_BY_ID: _schedule_pb2.Schedule
    ScheduleService_I_SCHEDULES_BY_EXPIRY_SEC: _schedule_pb2.ScheduleList
    ScheduleService_I_SCHEDULES_BY_EQUALITY: _schedule_pb2.ScheduleList
    FeeService_I_MIDNIGHT_RATES: _exchange_rate_pb2.ExchangeRateSet
    BlockRecordService_I_RUNNING_HASHES: _running_hashes_pb2.RunningHashes
    BlockRecordService_I_BLOCKS: _block_info_pb2.BlockInfo
    AddressBookService_I_NODES: _node_pb2.Node
    ConsensusService_I_TOPICS: _topic_pb2.Topic
    FreezeService_I_UPGRADE_FILE_HASH: _primitives_pb2.ProtoBytes
    FreezeService_I_FREEZE_TIME: _timestamp_pb2.Timestamp
    BlockStreamService_I_BLOCK_STREAM_INFO: _block_stream_info_pb2.BlockStreamInfo
    TokenService_I_PENDING_AIRDROPS: _account_pending_airdrop_pb2.AccountPendingAirdrop
    PlatformStateService_I_PLATFORM_STATE: _platform_state_pb2.PlatformState
    RosterService_I_ROSTER_STATE: _roster_state_pb2.RosterState
    RosterService_I_ROSTERS: _roster_pb2.Roster
    ScheduleService_I_SCHEDULED_COUNTS: _schedule_pb2.ScheduledCounts
    ScheduleService_I_SCHEDULE_ID_BY_EQUALITY: _basic_types_pb2.ScheduleID
    TssBaseService_I_TSS_MESSAGES: _tss_message_pb2.TssMessageTransactionBody
    TssBaseService_I_TSS_VOTES: _tss_vote_pb2.TssVoteTransactionBody
    ScheduleService_I_SCHEDULED_ORDERS: _basic_types_pb2.ScheduleID
    ScheduleService_I_SCHEDULED_USAGES: _throttle_usage_snapshots_pb2.ThrottleUsageSnapshots
    TssBaseService_I_TSS_ENCRYPTION_KEYS: _tss_encryption_keys_pb2.TssEncryptionKeys
    HintsService_I_HINTS_KEY_SETS: _hints_types_pb2.HintsKeySet
    HintsService_I_ACTIVE_HINTS_CONSTRUCTION: _hints_types_pb2.HintsConstruction
    HintsService_I_NEXT_HINTS_CONSTRUCTION: _hints_types_pb2.HintsConstruction
    HintsService_I_PREPROCESSING_VOTES: _hints_types_pb2.PreprocessingVote
    EntityIdService_I_ENTITY_COUNTS: _entity_counts_pb2.EntityCounts
    HistoryService_I_LEDGER_ID: _primitives_pb2.ProtoBytes
    HistoryService_I_PROOF_KEY_SETS: _history_types_pb2.ProofKeySet
    HistoryService_I_ACTIVE_PROOF_CONSTRUCTION: _history_types_pb2.HistoryProofConstruction
    HistoryService_I_NEXT_PROOF_CONSTRUCTION: _history_types_pb2.HistoryProofConstruction
    HistoryService_I_HISTORY_SIGNATURES: _history_types_pb2.RecordedHistorySignature
    HistoryService_I_PROOF_VOTES: _history_types_pb2.HistoryProofVote
    HintsService_I_CRS_STATE: _hints_types_pb2.CRSState
    HintsService_I_CRS_PUBLICATIONS: _crs_publication_pb2.CrsPublicationTransactionBody
    TokenService_I_NODE_REWARDS: _node_rewards_pb2.NodeRewards
    ContractService_I_EVM_HOOK_STATES: _evm_hook_state_pb2.EvmHookState
    ContractService_I_EVM_HOOK_STORAGE: _storage_slot_pb2.SlotValue
    AddressBookService_I_ACCOUNT_NODE_REL: _platform_state_pb2.NodeId
    HistoryService_I_WRAPS_MESSAGE_HISTORIES: _history_types_pb2.WrapsMessageHistory
    TokenService_I_NODE_PAYMENTS: _node_payments_pb2.NodePayments
    RecordCache_I_TRANSACTION_RECEIPTS: _recordcache_pb2.TransactionReceiptEntries
    queue_state: QueueState
    FileService_I_UPGRADE_DATA_150: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_151: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_152: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_153: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_154: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_155: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_156: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_157: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_158: _primitives_pb2.ProtoBytes
    FileService_I_UPGRADE_DATA_159: _primitives_pb2.ProtoBytes
    def __init__(self, EntityIdService_I_ENTITY_ID: _Optional[_Union[_common_pb2.EntityNumber, _Mapping]] = ..., TokenService_I_ACCOUNTS: _Optional[_Union[_account_pb2.Account, _Mapping]] = ..., TokenService_I_ALIASES: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., ContractService_I_STORAGE: _Optional[_Union[_storage_slot_pb2.SlotValue, _Mapping]] = ..., ContractService_I_BYTECODE: _Optional[_Union[_bytecode_pb2.Bytecode, _Mapping]] = ..., FileService_I_FILES: _Optional[_Union[_file_pb2.File, _Mapping]] = ..., TokenService_I_TOKENS: _Optional[_Union[_token_pb2.Token, _Mapping]] = ..., TokenService_I_NFTS: _Optional[_Union[_nft_pb2.Nft, _Mapping]] = ..., TokenService_I_TOKEN_RELS: _Optional[_Union[_token_relation_pb2.TokenRelation, _Mapping]] = ..., TokenService_I_STAKING_INFOS: _Optional[_Union[_staking_node_info_pb2.StakingNodeInfo, _Mapping]] = ..., TokenService_I_STAKING_NETWORK_REWARDS: _Optional[_Union[_network_staking_rewards_pb2.NetworkStakingRewards, _Mapping]] = ..., CongestionThrottleService_I_THROTTLE_USAGE_SNAPSHOTS: _Optional[_Union[_throttle_usage_snapshots_pb2.ThrottleUsageSnapshots, _Mapping]] = ..., CongestionThrottleService_I_CONGESTION_LEVEL_STARTS: _Optional[_Union[_congestion_level_starts_pb2.CongestionLevelStarts, _Mapping]] = ..., ScheduleService_I_SCHEDULES_BY_ID: _Optional[_Union[_schedule_pb2.Schedule, _Mapping]] = ..., ScheduleService_I_SCHEDULES_BY_EXPIRY_SEC: _Optional[_Union[_schedule_pb2.ScheduleList, _Mapping]] = ..., ScheduleService_I_SCHEDULES_BY_EQUALITY: _Optional[_Union[_schedule_pb2.ScheduleList, _Mapping]] = ..., FeeService_I_MIDNIGHT_RATES: _Optional[_Union[_exchange_rate_pb2.ExchangeRateSet, _Mapping]] = ..., BlockRecordService_I_RUNNING_HASHES: _Optional[_Union[_running_hashes_pb2.RunningHashes, _Mapping]] = ..., BlockRecordService_I_BLOCKS: _Optional[_Union[_block_info_pb2.BlockInfo, _Mapping]] = ..., AddressBookService_I_NODES: _Optional[_Union[_node_pb2.Node, _Mapping]] = ..., ConsensusService_I_TOPICS: _Optional[_Union[_topic_pb2.Topic, _Mapping]] = ..., FreezeService_I_UPGRADE_FILE_HASH: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FreezeService_I_FREEZE_TIME: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., BlockStreamService_I_BLOCK_STREAM_INFO: _Optional[_Union[_block_stream_info_pb2.BlockStreamInfo, _Mapping]] = ..., TokenService_I_PENDING_AIRDROPS: _Optional[_Union[_account_pending_airdrop_pb2.AccountPendingAirdrop, _Mapping]] = ..., PlatformStateService_I_PLATFORM_STATE: _Optional[_Union[_platform_state_pb2.PlatformState, _Mapping]] = ..., RosterService_I_ROSTER_STATE: _Optional[_Union[_roster_state_pb2.RosterState, _Mapping]] = ..., RosterService_I_ROSTERS: _Optional[_Union[_roster_pb2.Roster, _Mapping]] = ..., ScheduleService_I_SCHEDULED_COUNTS: _Optional[_Union[_schedule_pb2.ScheduledCounts, _Mapping]] = ..., ScheduleService_I_SCHEDULE_ID_BY_EQUALITY: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., TssBaseService_I_TSS_MESSAGES: _Optional[_Union[_tss_message_pb2.TssMessageTransactionBody, _Mapping]] = ..., TssBaseService_I_TSS_VOTES: _Optional[_Union[_tss_vote_pb2.TssVoteTransactionBody, _Mapping]] = ..., ScheduleService_I_SCHEDULED_ORDERS: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., ScheduleService_I_SCHEDULED_USAGES: _Optional[_Union[_throttle_usage_snapshots_pb2.ThrottleUsageSnapshots, _Mapping]] = ..., TssBaseService_I_TSS_ENCRYPTION_KEYS: _Optional[_Union[_tss_encryption_keys_pb2.TssEncryptionKeys, _Mapping]] = ..., HintsService_I_HINTS_KEY_SETS: _Optional[_Union[_hints_types_pb2.HintsKeySet, _Mapping]] = ..., HintsService_I_ACTIVE_HINTS_CONSTRUCTION: _Optional[_Union[_hints_types_pb2.HintsConstruction, _Mapping]] = ..., HintsService_I_NEXT_HINTS_CONSTRUCTION: _Optional[_Union[_hints_types_pb2.HintsConstruction, _Mapping]] = ..., HintsService_I_PREPROCESSING_VOTES: _Optional[_Union[_hints_types_pb2.PreprocessingVote, _Mapping]] = ..., EntityIdService_I_ENTITY_COUNTS: _Optional[_Union[_entity_counts_pb2.EntityCounts, _Mapping]] = ..., HistoryService_I_LEDGER_ID: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., HistoryService_I_PROOF_KEY_SETS: _Optional[_Union[_history_types_pb2.ProofKeySet, _Mapping]] = ..., HistoryService_I_ACTIVE_PROOF_CONSTRUCTION: _Optional[_Union[_history_types_pb2.HistoryProofConstruction, _Mapping]] = ..., HistoryService_I_NEXT_PROOF_CONSTRUCTION: _Optional[_Union[_history_types_pb2.HistoryProofConstruction, _Mapping]] = ..., HistoryService_I_HISTORY_SIGNATURES: _Optional[_Union[_history_types_pb2.RecordedHistorySignature, _Mapping]] = ..., HistoryService_I_PROOF_VOTES: _Optional[_Union[_history_types_pb2.HistoryProofVote, _Mapping]] = ..., HintsService_I_CRS_STATE: _Optional[_Union[_hints_types_pb2.CRSState, _Mapping]] = ..., HintsService_I_CRS_PUBLICATIONS: _Optional[_Union[_crs_publication_pb2.CrsPublicationTransactionBody, _Mapping]] = ..., TokenService_I_NODE_REWARDS: _Optional[_Union[_node_rewards_pb2.NodeRewards, _Mapping]] = ..., ContractService_I_EVM_HOOK_STATES: _Optional[_Union[_evm_hook_state_pb2.EvmHookState, _Mapping]] = ..., ContractService_I_EVM_HOOK_STORAGE: _Optional[_Union[_storage_slot_pb2.SlotValue, _Mapping]] = ..., AddressBookService_I_ACCOUNT_NODE_REL: _Optional[_Union[_platform_state_pb2.NodeId, _Mapping]] = ..., HistoryService_I_WRAPS_MESSAGE_HISTORIES: _Optional[_Union[_history_types_pb2.WrapsMessageHistory, _Mapping]] = ..., TokenService_I_NODE_PAYMENTS: _Optional[_Union[_node_payments_pb2.NodePayments, _Mapping]] = ..., RecordCache_I_TRANSACTION_RECEIPTS: _Optional[_Union[_recordcache_pb2.TransactionReceiptEntries, _Mapping]] = ..., queue_state: _Optional[_Union[QueueState, _Mapping]] = ..., FileService_I_UPGRADE_DATA_150: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_151: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_152: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_153: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_154: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_155: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_156: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_157: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_158: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ..., FileService_I_UPGRADE_DATA_159: _Optional[_Union[_primitives_pb2.ProtoBytes, _Mapping]] = ...) -> None: ...
