from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GossipKnownTips(_message.Message):
    __slots__ = ("knownTips",)
    KNOWNTIPS_FIELD_NUMBER: _ClassVar[int]
    knownTips: _containers.RepeatedScalarFieldContainer[bool]
    def __init__(self, knownTips: _Optional[_Iterable[bool]] = ...) -> None: ...
