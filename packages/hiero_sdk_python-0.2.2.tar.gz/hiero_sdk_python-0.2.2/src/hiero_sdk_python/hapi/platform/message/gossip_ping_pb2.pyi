from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GossipPing(_message.Message):
    __slots__ = ("correlationId",)
    CORRELATIONID_FIELD_NUMBER: _ClassVar[int]
    correlationId: int
    def __init__(self, correlationId: _Optional[int] = ...) -> None: ...
