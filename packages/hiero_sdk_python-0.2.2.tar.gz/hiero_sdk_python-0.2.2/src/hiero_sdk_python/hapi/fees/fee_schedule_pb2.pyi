from ..services import basic_types_pb2 as _basic_types_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Extra(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SIGNATURES: _ClassVar[Extra]
    KEYS: _ClassVar[Extra]
    NFT_SERIALS: _ClassVar[Extra]
    ACCOUNTS: _ClassVar[Extra]
    TOKEN_TYPES: _ClassVar[Extra]
    GAS: _ClassVar[Extra]
    ALLOWANCES: _ClassVar[Extra]
    AIRDROPS: _ClassVar[Extra]
    HOOK_UPDATES: _ClassVar[Extra]
    TOKEN_TRANSFER_BASE: _ClassVar[Extra]
    TOKEN_TRANSFER_BASE_CUSTOM_FEES: _ClassVar[Extra]
    HOOK_EXECUTION: _ClassVar[Extra]
    TOKEN_CREATE_WITH_CUSTOM_FEE: _ClassVar[Extra]
    TOKEN_MINT_NFT: _ClassVar[Extra]
    CONSENSUS_CREATE_TOPIC_WITH_CUSTOM_FEE: _ClassVar[Extra]
    CONSENSUS_SUBMIT_MESSAGE_WITH_CUSTOM_FEE: _ClassVar[Extra]
    SCHEDULE_CREATE_CONTRACT_CALL_BASE: _ClassVar[Extra]
    TOKEN_ASSOCIATE: _ClassVar[Extra]
    HOOK_SLOT_UPDATE: _ClassVar[Extra]
    TOKEN_MINT_NFT_BASE: _ClassVar[Extra]
    NFT_UPDATE: _ClassVar[Extra]
    RECORDS: _ClassVar[Extra]
    STATE_BYTES: _ClassVar[Extra]
    PROCESSING_BYTES: _ClassVar[Extra]
SIGNATURES: Extra
KEYS: Extra
NFT_SERIALS: Extra
ACCOUNTS: Extra
TOKEN_TYPES: Extra
GAS: Extra
ALLOWANCES: Extra
AIRDROPS: Extra
HOOK_UPDATES: Extra
TOKEN_TRANSFER_BASE: Extra
TOKEN_TRANSFER_BASE_CUSTOM_FEES: Extra
HOOK_EXECUTION: Extra
TOKEN_CREATE_WITH_CUSTOM_FEE: Extra
TOKEN_MINT_NFT: Extra
CONSENSUS_CREATE_TOPIC_WITH_CUSTOM_FEE: Extra
CONSENSUS_SUBMIT_MESSAGE_WITH_CUSTOM_FEE: Extra
SCHEDULE_CREATE_CONTRACT_CALL_BASE: Extra
TOKEN_ASSOCIATE: Extra
HOOK_SLOT_UPDATE: Extra
TOKEN_MINT_NFT_BASE: Extra
NFT_UPDATE: Extra
RECORDS: Extra
STATE_BYTES: Extra
PROCESSING_BYTES: Extra

class FeeSchedule(_message.Message):
    __slots__ = ("node", "network", "unreadable", "extras", "services")
    NODE_FIELD_NUMBER: _ClassVar[int]
    NETWORK_FIELD_NUMBER: _ClassVar[int]
    UNREADABLE_FIELD_NUMBER: _ClassVar[int]
    EXTRAS_FIELD_NUMBER: _ClassVar[int]
    SERVICES_FIELD_NUMBER: _ClassVar[int]
    node: NodeFee
    network: NetworkFee
    unreadable: UnreadableTransactionFee
    extras: _containers.RepeatedCompositeFieldContainer[ExtraFeeDefinition]
    services: _containers.RepeatedCompositeFieldContainer[ServiceFeeSchedule]
    def __init__(self, node: _Optional[_Union[NodeFee, _Mapping]] = ..., network: _Optional[_Union[NetworkFee, _Mapping]] = ..., unreadable: _Optional[_Union[UnreadableTransactionFee, _Mapping]] = ..., extras: _Optional[_Iterable[_Union[ExtraFeeDefinition, _Mapping]]] = ..., services: _Optional[_Iterable[_Union[ServiceFeeSchedule, _Mapping]]] = ...) -> None: ...

class ExtraFeeDefinition(_message.Message):
    __slots__ = ("name", "fee")
    NAME_FIELD_NUMBER: _ClassVar[int]
    FEE_FIELD_NUMBER: _ClassVar[int]
    name: Extra
    fee: int
    def __init__(self, name: _Optional[_Union[Extra, str]] = ..., fee: _Optional[int] = ...) -> None: ...

class NodeFee(_message.Message):
    __slots__ = ("base_fee", "extras")
    BASE_FEE_FIELD_NUMBER: _ClassVar[int]
    EXTRAS_FIELD_NUMBER: _ClassVar[int]
    base_fee: int
    extras: _containers.RepeatedCompositeFieldContainer[ExtraFeeReference]
    def __init__(self, base_fee: _Optional[int] = ..., extras: _Optional[_Iterable[_Union[ExtraFeeReference, _Mapping]]] = ...) -> None: ...

class NetworkFee(_message.Message):
    __slots__ = ("multiplier",)
    MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    multiplier: int
    def __init__(self, multiplier: _Optional[int] = ...) -> None: ...

class ServiceFeeSchedule(_message.Message):
    __slots__ = ("name", "schedule")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    name: str
    schedule: _containers.RepeatedCompositeFieldContainer[ServiceFeeDefinition]
    def __init__(self, name: _Optional[str] = ..., schedule: _Optional[_Iterable[_Union[ServiceFeeDefinition, _Mapping]]] = ...) -> None: ...

class ServiceFeeDefinition(_message.Message):
    __slots__ = ("name", "base_fee", "extras", "free", "high_volume_rates")
    NAME_FIELD_NUMBER: _ClassVar[int]
    BASE_FEE_FIELD_NUMBER: _ClassVar[int]
    EXTRAS_FIELD_NUMBER: _ClassVar[int]
    FREE_FIELD_NUMBER: _ClassVar[int]
    HIGH_VOLUME_RATES_FIELD_NUMBER: _ClassVar[int]
    name: _basic_types_pb2.HederaFunctionality
    base_fee: int
    extras: _containers.RepeatedCompositeFieldContainer[ExtraFeeReference]
    free: bool
    high_volume_rates: VariableRateDefinition
    def __init__(self, name: _Optional[_Union[_basic_types_pb2.HederaFunctionality, str]] = ..., base_fee: _Optional[int] = ..., extras: _Optional[_Iterable[_Union[ExtraFeeReference, _Mapping]]] = ..., free: bool = ..., high_volume_rates: _Optional[_Union[VariableRateDefinition, _Mapping]] = ...) -> None: ...

class ExtraFeeReference(_message.Message):
    __slots__ = ("name", "included_count")
    NAME_FIELD_NUMBER: _ClassVar[int]
    INCLUDED_COUNT_FIELD_NUMBER: _ClassVar[int]
    name: Extra
    included_count: int
    def __init__(self, name: _Optional[_Union[Extra, str]] = ..., included_count: _Optional[int] = ...) -> None: ...

class UnreadableTransactionFee(_message.Message):
    __slots__ = ("fee",)
    FEE_FIELD_NUMBER: _ClassVar[int]
    fee: int
    def __init__(self, fee: _Optional[int] = ...) -> None: ...

class VariableRateDefinition(_message.Message):
    __slots__ = ("max_multiplier", "pricing_curve")
    MAX_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    PRICING_CURVE_FIELD_NUMBER: _ClassVar[int]
    max_multiplier: int
    pricing_curve: PricingCurve
    def __init__(self, max_multiplier: _Optional[int] = ..., pricing_curve: _Optional[_Union[PricingCurve, _Mapping]] = ...) -> None: ...

class PricingCurve(_message.Message):
    __slots__ = ("piecewise_linear",)
    PIECEWISE_LINEAR_FIELD_NUMBER: _ClassVar[int]
    piecewise_linear: PiecewiseLinearCurve
    def __init__(self, piecewise_linear: _Optional[_Union[PiecewiseLinearCurve, _Mapping]] = ...) -> None: ...

class PiecewiseLinearCurve(_message.Message):
    __slots__ = ("points",)
    POINTS_FIELD_NUMBER: _ClassVar[int]
    points: _containers.RepeatedCompositeFieldContainer[PiecewiseLinearPoint]
    def __init__(self, points: _Optional[_Iterable[_Union[PiecewiseLinearPoint, _Mapping]]] = ...) -> None: ...

class PiecewiseLinearPoint(_message.Message):
    __slots__ = ("utilization_basis_points", "multiplier")
    UTILIZATION_BASIS_POINTS_FIELD_NUMBER: _ClassVar[int]
    MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    utilization_basis_points: int
    multiplier: int
    def __init__(self, utilization_basis_points: _Optional[int] = ..., multiplier: _Optional[int] = ...) -> None: ...
