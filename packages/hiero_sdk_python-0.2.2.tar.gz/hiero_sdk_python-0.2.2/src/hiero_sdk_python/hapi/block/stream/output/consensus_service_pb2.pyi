from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class RunningHashVersion(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WITH_MESSAGE_DIGEST_AND_PAYER: _ClassVar[RunningHashVersion]
    WITH_MESSAGE_DIGEST: _ClassVar[RunningHashVersion]
    WITH_FULL_MESSAGE: _ClassVar[RunningHashVersion]
WITH_MESSAGE_DIGEST_AND_PAYER: RunningHashVersion
WITH_MESSAGE_DIGEST: RunningHashVersion
WITH_FULL_MESSAGE: RunningHashVersion

class CreateTopicOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UpdateTopicOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DeleteTopicOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubmitMessageOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
