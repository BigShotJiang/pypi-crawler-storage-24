from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class BlockFooter(_message.Message):
    __slots__ = ("previous_block_root_hash", "root_hash_of_all_block_hashes_tree", "start_of_block_state_root_hash")
    PREVIOUS_BLOCK_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    ROOT_HASH_OF_ALL_BLOCK_HASHES_TREE_FIELD_NUMBER: _ClassVar[int]
    START_OF_BLOCK_STATE_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    previous_block_root_hash: bytes
    root_hash_of_all_block_hashes_tree: bytes
    start_of_block_state_root_hash: bytes
    def __init__(self, previous_block_root_hash: _Optional[bytes] = ..., root_hash_of_all_block_hashes_tree: _Optional[bytes] = ..., start_of_block_state_root_hash: _Optional[bytes] = ...) -> None: ...
