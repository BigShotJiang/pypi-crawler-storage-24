from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SignedRecordFileProof(_message.Message):
    __slots__ = ("version", "record_file_signatures")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    RECORD_FILE_SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    version: int
    record_file_signatures: _containers.RepeatedCompositeFieldContainer[RecordFileSignature]
    def __init__(self, version: _Optional[int] = ..., record_file_signatures: _Optional[_Iterable[_Union[RecordFileSignature, _Mapping]]] = ...) -> None: ...

class RecordFileSignature(_message.Message):
    __slots__ = ("signatures_bytes", "node_id")
    SIGNATURES_BYTES_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    signatures_bytes: bytes
    node_id: int
    def __init__(self, signatures_bytes: _Optional[bytes] = ..., node_id: _Optional[int] = ...) -> None: ...
