from ...services import timestamp_pb2 as _timestamp_pb2
from ...streams import sidecar_file_pb2 as _sidecar_file_pb2
from ...streams import record_stream_file_pb2 as _record_stream_file_pb2
from ...services import transaction_record_pb2 as _transaction_record_pb2
from ...services import transaction_contents_pb2 as _transaction_contents_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RecordFileItem(_message.Message):
    __slots__ = ("creation_time", "record_file_contents", "sidecar_file_contents", "amendments")
    CREATION_TIME_FIELD_NUMBER: _ClassVar[int]
    RECORD_FILE_CONTENTS_FIELD_NUMBER: _ClassVar[int]
    SIDECAR_FILE_CONTENTS_FIELD_NUMBER: _ClassVar[int]
    AMENDMENTS_FIELD_NUMBER: _ClassVar[int]
    creation_time: _timestamp_pb2.Timestamp
    record_file_contents: _record_stream_file_pb2.RecordStreamFile
    sidecar_file_contents: _containers.RepeatedCompositeFieldContainer[_sidecar_file_pb2.SidecarFile]
    amendments: _containers.RepeatedCompositeFieldContainer[_record_stream_file_pb2.RecordStreamItem]
    def __init__(self, creation_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., record_file_contents: _Optional[_Union[_record_stream_file_pb2.RecordStreamFile, _Mapping]] = ..., sidecar_file_contents: _Optional[_Iterable[_Union[_sidecar_file_pb2.SidecarFile, _Mapping]]] = ..., amendments: _Optional[_Iterable[_Union[_record_stream_file_pb2.RecordStreamItem, _Mapping]]] = ...) -> None: ...
