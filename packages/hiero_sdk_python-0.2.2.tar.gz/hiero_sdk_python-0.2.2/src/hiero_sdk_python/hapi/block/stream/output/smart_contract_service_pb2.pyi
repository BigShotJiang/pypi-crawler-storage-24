from ....services import contract_types_pb2 as _contract_types_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CallContractOutput(_message.Message):
    __slots__ = ("evm_transaction_result",)
    EVM_TRANSACTION_RESULT_FIELD_NUMBER: _ClassVar[int]
    evm_transaction_result: _contract_types_pb2.EvmTransactionResult
    def __init__(self, evm_transaction_result: _Optional[_Union[_contract_types_pb2.EvmTransactionResult, _Mapping]] = ...) -> None: ...

class CreateContractOutput(_message.Message):
    __slots__ = ("evm_transaction_result",)
    EVM_TRANSACTION_RESULT_FIELD_NUMBER: _ClassVar[int]
    evm_transaction_result: _contract_types_pb2.EvmTransactionResult
    def __init__(self, evm_transaction_result: _Optional[_Union[_contract_types_pb2.EvmTransactionResult, _Mapping]] = ...) -> None: ...

class UpdateContractOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DeleteContractOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SystemUnDeleteContractOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SystemDeleteContractOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EthereumOutput(_message.Message):
    __slots__ = ("evm_call_transaction_result", "evm_create_transaction_result")
    EVM_CALL_TRANSACTION_RESULT_FIELD_NUMBER: _ClassVar[int]
    EVM_CREATE_TRANSACTION_RESULT_FIELD_NUMBER: _ClassVar[int]
    evm_call_transaction_result: _contract_types_pb2.EvmTransactionResult
    evm_create_transaction_result: _contract_types_pb2.EvmTransactionResult
    def __init__(self, evm_call_transaction_result: _Optional[_Union[_contract_types_pb2.EvmTransactionResult, _Mapping]] = ..., evm_create_transaction_result: _Optional[_Union[_contract_types_pb2.EvmTransactionResult, _Mapping]] = ...) -> None: ...
