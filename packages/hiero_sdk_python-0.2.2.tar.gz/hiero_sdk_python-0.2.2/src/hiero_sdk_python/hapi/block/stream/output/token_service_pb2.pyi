from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class CreateTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FreezeTokenAccountOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UnfreezeTokenAccountOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GrantTokenKycOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RevokeTokenKycOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DeleteTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UpdateTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MintTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class BurnTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class WipeTokenAccountOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class AssociateTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DissociateTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UpdateTokenFeeScheduleOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PauseTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UnpauseTokenOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UpdateTokenNftsOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TokenAirdropOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
