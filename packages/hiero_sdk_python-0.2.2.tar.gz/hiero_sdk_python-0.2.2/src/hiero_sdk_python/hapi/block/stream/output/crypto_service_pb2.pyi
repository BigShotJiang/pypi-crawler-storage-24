from ....services import basic_types_pb2 as _basic_types_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ApproveAllowanceOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DeleteAllowanceOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CreateAccountOutput(_message.Message):
    __slots__ = ("created_account_id",)
    CREATED_ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    created_account_id: _basic_types_pb2.AccountID
    def __init__(self, created_account_id: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ...) -> None: ...

class DeleteAccountOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CryptoTransferOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UpdateAccountOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
