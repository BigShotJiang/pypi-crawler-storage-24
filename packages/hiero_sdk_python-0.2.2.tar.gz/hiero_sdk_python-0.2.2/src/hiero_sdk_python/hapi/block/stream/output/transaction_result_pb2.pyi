from ....services import basic_types_pb2 as _basic_types_pb2
from ....services import custom_fees_pb2 as _custom_fees_pb2
from ....services import response_code_pb2 as _response_code_pb2
from ....services import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransactionResult(_message.Message):
    __slots__ = ("status", "consensus_timestamp", "parent_consensus_timestamp", "schedule_ref", "transaction_fee_charged", "transfer_list", "token_transfer_lists", "automatic_token_associations", "paid_staking_rewards", "congestion_pricing_multiplier", "assessed_custom_fees", "high_volume_pricing_multiplier")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CONSENSUS_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    PARENT_CONSENSUS_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_REF_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_FEE_CHARGED_FIELD_NUMBER: _ClassVar[int]
    TRANSFER_LIST_FIELD_NUMBER: _ClassVar[int]
    TOKEN_TRANSFER_LISTS_FIELD_NUMBER: _ClassVar[int]
    AUTOMATIC_TOKEN_ASSOCIATIONS_FIELD_NUMBER: _ClassVar[int]
    PAID_STAKING_REWARDS_FIELD_NUMBER: _ClassVar[int]
    CONGESTION_PRICING_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    ASSESSED_CUSTOM_FEES_FIELD_NUMBER: _ClassVar[int]
    HIGH_VOLUME_PRICING_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    status: _response_code_pb2.ResponseCodeEnum
    consensus_timestamp: _timestamp_pb2.Timestamp
    parent_consensus_timestamp: _timestamp_pb2.Timestamp
    schedule_ref: _basic_types_pb2.ScheduleID
    transaction_fee_charged: int
    transfer_list: _basic_types_pb2.TransferList
    token_transfer_lists: _containers.RepeatedCompositeFieldContainer[_basic_types_pb2.TokenTransferList]
    automatic_token_associations: _containers.RepeatedCompositeFieldContainer[_basic_types_pb2.TokenAssociation]
    paid_staking_rewards: _containers.RepeatedCompositeFieldContainer[_basic_types_pb2.AccountAmount]
    congestion_pricing_multiplier: int
    assessed_custom_fees: _containers.RepeatedCompositeFieldContainer[_custom_fees_pb2.AssessedCustomFee]
    high_volume_pricing_multiplier: int
    def __init__(self, status: _Optional[_Union[_response_code_pb2.ResponseCodeEnum, str]] = ..., consensus_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., parent_consensus_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., schedule_ref: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., transaction_fee_charged: _Optional[int] = ..., transfer_list: _Optional[_Union[_basic_types_pb2.TransferList, _Mapping]] = ..., token_transfer_lists: _Optional[_Iterable[_Union[_basic_types_pb2.TokenTransferList, _Mapping]]] = ..., automatic_token_associations: _Optional[_Iterable[_Union[_basic_types_pb2.TokenAssociation, _Mapping]]] = ..., paid_staking_rewards: _Optional[_Iterable[_Union[_basic_types_pb2.AccountAmount, _Mapping]]] = ..., congestion_pricing_multiplier: _Optional[int] = ..., assessed_custom_fees: _Optional[_Iterable[_Union[_custom_fees_pb2.AssessedCustomFee, _Mapping]]] = ..., high_volume_pricing_multiplier: _Optional[int] = ...) -> None: ...
