from ....platform.event import event_core_pb2 as _event_core_pb2
from ....platform.event import event_descriptor_pb2 as _event_descriptor_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EventHeader(_message.Message):
    __slots__ = ("event_core", "parents")
    EVENT_CORE_FIELD_NUMBER: _ClassVar[int]
    PARENTS_FIELD_NUMBER: _ClassVar[int]
    event_core: _event_core_pb2.EventCore
    parents: _containers.RepeatedCompositeFieldContainer[ParentEventReference]
    def __init__(self, event_core: _Optional[_Union[_event_core_pb2.EventCore, _Mapping]] = ..., parents: _Optional[_Iterable[_Union[ParentEventReference, _Mapping]]] = ...) -> None: ...

class ParentEventReference(_message.Message):
    __slots__ = ("event_descriptor", "index")
    EVENT_DESCRIPTOR_FIELD_NUMBER: _ClassVar[int]
    INDEX_FIELD_NUMBER: _ClassVar[int]
    event_descriptor: _event_descriptor_pb2.EventDescriptor
    index: int
    def __init__(self, event_descriptor: _Optional[_Union[_event_descriptor_pb2.EventDescriptor, _Mapping]] = ..., index: _Optional[int] = ...) -> None: ...
