from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class TssSignedBlockProof(_message.Message):
    __slots__ = ("block_signature",)
    BLOCK_SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    block_signature: bytes
    def __init__(self, block_signature: _Optional[bytes] = ...) -> None: ...
