from ...block.stream import signed_record_file_proof_pb2 as _signed_record_file_proof_pb2
from ...block.stream import state_proof_pb2 as _state_proof_pb2
from ...block.stream import tss_signed_block_proof_pb2 as _tss_signed_block_proof_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BlockProof(_message.Message):
    __slots__ = ("block", "signed_block_proof", "block_state_proof", "signed_record_file_proof")
    BLOCK_FIELD_NUMBER: _ClassVar[int]
    SIGNED_BLOCK_PROOF_FIELD_NUMBER: _ClassVar[int]
    BLOCK_STATE_PROOF_FIELD_NUMBER: _ClassVar[int]
    SIGNED_RECORD_FILE_PROOF_FIELD_NUMBER: _ClassVar[int]
    block: int
    signed_block_proof: _tss_signed_block_proof_pb2.TssSignedBlockProof
    block_state_proof: _state_proof_pb2.StateProof
    signed_record_file_proof: _signed_record_file_proof_pb2.SignedRecordFileProof
    def __init__(self, block: _Optional[int] = ..., signed_block_proof: _Optional[_Union[_tss_signed_block_proof_pb2.TssSignedBlockProof, _Mapping]] = ..., block_state_proof: _Optional[_Union[_state_proof_pb2.StateProof, _Mapping]] = ..., signed_record_file_proof: _Optional[_Union[_signed_record_file_proof_pb2.SignedRecordFileProof, _Mapping]] = ...) -> None: ...
