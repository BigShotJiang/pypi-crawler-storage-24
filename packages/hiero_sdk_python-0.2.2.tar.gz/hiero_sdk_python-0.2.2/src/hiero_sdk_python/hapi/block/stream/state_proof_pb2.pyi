from ...services import timestamp_pb2 as _timestamp_pb2
from ...block.stream import record_file_item_pb2 as _record_file_item_pb2
from ...block.stream import tss_signed_block_proof_pb2 as _tss_signed_block_proof_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StateProof(_message.Message):
    __slots__ = ("paths", "signed_block_proof")
    PATHS_FIELD_NUMBER: _ClassVar[int]
    SIGNED_BLOCK_PROOF_FIELD_NUMBER: _ClassVar[int]
    paths: _containers.RepeatedCompositeFieldContainer[MerklePath]
    signed_block_proof: _tss_signed_block_proof_pb2.TssSignedBlockProof
    def __init__(self, paths: _Optional[_Iterable[_Union[MerklePath, _Mapping]]] = ..., signed_block_proof: _Optional[_Union[_tss_signed_block_proof_pb2.TssSignedBlockProof, _Mapping]] = ...) -> None: ...

class MerklePath(_message.Message):
    __slots__ = ("siblings", "next_path_index", "hash", "state_item_leaf", "block_item_leaf", "timestamp_leaf")
    SIBLINGS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PATH_INDEX_FIELD_NUMBER: _ClassVar[int]
    HASH_FIELD_NUMBER: _ClassVar[int]
    STATE_ITEM_LEAF_FIELD_NUMBER: _ClassVar[int]
    BLOCK_ITEM_LEAF_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_LEAF_FIELD_NUMBER: _ClassVar[int]
    siblings: _containers.RepeatedCompositeFieldContainer[SiblingNode]
    next_path_index: int
    hash: bytes
    state_item_leaf: bytes
    block_item_leaf: bytes
    timestamp_leaf: bytes
    def __init__(self, siblings: _Optional[_Iterable[_Union[SiblingNode, _Mapping]]] = ..., next_path_index: _Optional[int] = ..., hash: _Optional[bytes] = ..., state_item_leaf: _Optional[bytes] = ..., block_item_leaf: _Optional[bytes] = ..., timestamp_leaf: _Optional[bytes] = ...) -> None: ...

class SiblingNode(_message.Message):
    __slots__ = ("is_left", "hash")
    IS_LEFT_FIELD_NUMBER: _ClassVar[int]
    HASH_FIELD_NUMBER: _ClassVar[int]
    is_left: bool
    hash: bytes
    def __init__(self, is_left: bool = ..., hash: _Optional[bytes] = ...) -> None: ...

class MerkleSiblingHash(_message.Message):
    __slots__ = ("is_first", "sibling_hash")
    IS_FIRST_FIELD_NUMBER: _ClassVar[int]
    SIBLING_HASH_FIELD_NUMBER: _ClassVar[int]
    is_first: bool
    sibling_hash: bytes
    def __init__(self, is_first: bool = ..., sibling_hash: _Optional[bytes] = ...) -> None: ...
