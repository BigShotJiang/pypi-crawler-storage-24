from ....block.stream.output import schedule_service_pb2 as _schedule_service_pb2
from ....block.stream.output import util_service_pb2 as _util_service_pb2
from ....block.stream.output import crypto_service_pb2 as _crypto_service_pb2
from ....block.stream.output import smart_contract_service_pb2 as _smart_contract_service_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransactionOutput(_message.Message):
    __slots__ = ("util_prng", "contract_call", "ethereum_call", "contract_create", "create_schedule", "sign_schedule", "account_create")
    UTIL_PRNG_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_CALL_FIELD_NUMBER: _ClassVar[int]
    ETHEREUM_CALL_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_CREATE_FIELD_NUMBER: _ClassVar[int]
    CREATE_SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    SIGN_SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_CREATE_FIELD_NUMBER: _ClassVar[int]
    util_prng: _util_service_pb2.UtilPrngOutput
    contract_call: _smart_contract_service_pb2.CallContractOutput
    ethereum_call: _smart_contract_service_pb2.EthereumOutput
    contract_create: _smart_contract_service_pb2.CreateContractOutput
    create_schedule: _schedule_service_pb2.CreateScheduleOutput
    sign_schedule: _schedule_service_pb2.SignScheduleOutput
    account_create: _crypto_service_pb2.CreateAccountOutput
    def __init__(self, util_prng: _Optional[_Union[_util_service_pb2.UtilPrngOutput, _Mapping]] = ..., contract_call: _Optional[_Union[_smart_contract_service_pb2.CallContractOutput, _Mapping]] = ..., ethereum_call: _Optional[_Union[_smart_contract_service_pb2.EthereumOutput, _Mapping]] = ..., contract_create: _Optional[_Union[_smart_contract_service_pb2.CreateContractOutput, _Mapping]] = ..., create_schedule: _Optional[_Union[_schedule_service_pb2.CreateScheduleOutput, _Mapping]] = ..., sign_schedule: _Optional[_Union[_schedule_service_pb2.SignScheduleOutput, _Mapping]] = ..., account_create: _Optional[_Union[_crypto_service_pb2.CreateAccountOutput, _Mapping]] = ...) -> None: ...
