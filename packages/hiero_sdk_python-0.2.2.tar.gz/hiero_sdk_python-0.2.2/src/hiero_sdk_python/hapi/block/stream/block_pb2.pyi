from ...block.stream import block_item_pb2 as _block_item_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Block(_message.Message):
    __slots__ = ("items",)
    ITEMS_FIELD_NUMBER: _ClassVar[int]
    items: _containers.RepeatedCompositeFieldContainer[_block_item_pb2.BlockItem]
    def __init__(self, items: _Optional[_Iterable[_Union[_block_item_pb2.BlockItem, _Mapping]]] = ...) -> None: ...
