from ....services import basic_types_pb2 as _basic_types_pb2
from ....services import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BlockHeader(_message.Message):
    __slots__ = ("hapi_proto_version", "software_version", "number", "block_timestamp", "hash_algorithm")
    HAPI_PROTO_VERSION_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_VERSION_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    BLOCK_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    HASH_ALGORITHM_FIELD_NUMBER: _ClassVar[int]
    hapi_proto_version: _basic_types_pb2.SemanticVersion
    software_version: _basic_types_pb2.SemanticVersion
    number: int
    block_timestamp: _timestamp_pb2.Timestamp
    hash_algorithm: _basic_types_pb2.BlockHashAlgorithm
    def __init__(self, hapi_proto_version: _Optional[_Union[_basic_types_pb2.SemanticVersion, _Mapping]] = ..., software_version: _Optional[_Union[_basic_types_pb2.SemanticVersion, _Mapping]] = ..., number: _Optional[int] = ..., block_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., hash_algorithm: _Optional[_Union[_basic_types_pb2.BlockHashAlgorithm, str]] = ...) -> None: ...
