from google.protobuf import wrappers_pb2 as _wrappers_pb2
from ....services import basic_types_pb2 as _basic_types_pb2
from ....services import exchange_rate_pb2 as _exchange_rate_pb2
from ....services.state.addressbook import node_pb2 as _node_pb2
from ....services.state.addressbook import registered_node_pb2 as _registered_node_pb2
from ....services.state.blockrecords import block_info_pb2 as _block_info_pb2
from ....services.state.blockrecords import running_hashes_pb2 as _running_hashes_pb2
from ....services.state.blockstream import block_stream_info_pb2 as _block_stream_info_pb2
from ....services.state.congestion import congestion_level_starts_pb2 as _congestion_level_starts_pb2
from ....services.state.consensus import topic_pb2 as _topic_pb2
from ....services.state.contract import bytecode_pb2 as _bytecode_pb2
from ....services.state.contract import storage_slot_pb2 as _storage_slot_pb2
from ....services.state.contract import evm_hook_state_pb2 as _evm_hook_state_pb2
from ....services.state.file import file_pb2 as _file_pb2
from ....services.state.recordcache import recordcache_pb2 as _recordcache_pb2
from ....services.state.roster import roster_pb2 as _roster_pb2
from ....services.state.roster import roster_state_pb2 as _roster_state_pb2
from ....services.state.schedule import schedule_pb2 as _schedule_pb2
from ....services.state.throttles import throttle_usage_snapshots_pb2 as _throttle_usage_snapshots_pb2
from ....services.state.token import account_pb2 as _account_pb2
from ....services.state.token import account_pending_airdrop_pb2 as _account_pending_airdrop_pb2
from ....services.state.token import network_staking_rewards_pb2 as _network_staking_rewards_pb2
from ....services.state.token import node_rewards_pb2 as _node_rewards_pb2
from ....services.state.token import node_payments_pb2 as _node_payments_pb2
from ....services.state.token import nft_pb2 as _nft_pb2
from ....services.state.token import staking_node_info_pb2 as _staking_node_info_pb2
from ....services.state.token import token_pb2 as _token_pb2
from ....services.state.token import token_relation_pb2 as _token_relation_pb2
from ....platform.state import platform_state_pb2 as _platform_state_pb2
from ....services import timestamp_pb2 as _timestamp_pb2
from ....services.auxiliary.tss import tss_message_pb2 as _tss_message_pb2
from ....services.auxiliary.tss import tss_vote_pb2 as _tss_vote_pb2
from ....services.state.tss import tss_encryption_keys_pb2 as _tss_encryption_keys_pb2
from ....services.state.tss import tss_message_map_key_pb2 as _tss_message_map_key_pb2
from ....services.state.tss import tss_vote_map_key_pb2 as _tss_vote_map_key_pb2
from ....services.state.hints import hints_types_pb2 as _hints_types_pb2
from ....services.state.history import history_types_pb2 as _history_types_pb2
from ....services.state.entity import entity_counts_pb2 as _entity_counts_pb2
from ....services.auxiliary.hints import crs_publication_pb2 as _crs_publication_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StateIdentifier(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNKNOWN: _ClassVar[StateIdentifier]
    STATE_ID_ENTITY_ID: _ClassVar[StateIdentifier]
    STATE_ID_ACCOUNTS: _ClassVar[StateIdentifier]
    STATE_ID_ALIASES: _ClassVar[StateIdentifier]
    STATE_ID_STORAGE: _ClassVar[StateIdentifier]
    STATE_ID_BYTECODE: _ClassVar[StateIdentifier]
    STATE_ID_FILES: _ClassVar[StateIdentifier]
    STATE_ID_TOKENS: _ClassVar[StateIdentifier]
    STATE_ID_NFTS: _ClassVar[StateIdentifier]
    STATE_ID_TOKEN_RELS: _ClassVar[StateIdentifier]
    STATE_ID_STAKING_INFOS: _ClassVar[StateIdentifier]
    STATE_ID_STAKING_NETWORK_REWARDS: _ClassVar[StateIdentifier]
    STATE_ID_THROTTLE_USAGE_SNAPSHOTS: _ClassVar[StateIdentifier]
    STATE_ID_CONGESTION_LEVEL_STARTS: _ClassVar[StateIdentifier]
    STATE_ID_SCHEDULES_BY_ID: _ClassVar[StateIdentifier]
    STATE_ID_SCHEDULES_BY_EXPIRY_SEC: _ClassVar[StateIdentifier]
    STATE_ID_SCHEDULES_BY_EQUALITY: _ClassVar[StateIdentifier]
    STATE_ID_MIDNIGHT_RATES: _ClassVar[StateIdentifier]
    STATE_ID_RUNNING_HASHES: _ClassVar[StateIdentifier]
    STATE_ID_BLOCKS: _ClassVar[StateIdentifier]
    STATE_ID_NODES: _ClassVar[StateIdentifier]
    STATE_ID_TOPICS: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_FILE_HASH: _ClassVar[StateIdentifier]
    STATE_ID_FREEZE_TIME: _ClassVar[StateIdentifier]
    STATE_ID_BLOCK_STREAM_INFO: _ClassVar[StateIdentifier]
    STATE_ID_PENDING_AIRDROPS: _ClassVar[StateIdentifier]
    STATE_ID_PLATFORM_STATE: _ClassVar[StateIdentifier]
    STATE_ID_ROSTER_STATE: _ClassVar[StateIdentifier]
    STATE_ID_ROSTERS: _ClassVar[StateIdentifier]
    STATE_ID_SCHEDULED_COUNTS: _ClassVar[StateIdentifier]
    STATE_ID_SCHEDULE_ID_BY_EQUALITY: _ClassVar[StateIdentifier]
    STATE_ID_TSS_MESSAGES: _ClassVar[StateIdentifier]
    STATE_ID_TSS_VOTES: _ClassVar[StateIdentifier]
    STATE_ID_SCHEDULED_ORDERS: _ClassVar[StateIdentifier]
    STATE_ID_SCHEDULED_USAGES: _ClassVar[StateIdentifier]
    STATE_ID_TSS_ENCRYPTION_KEYS: _ClassVar[StateIdentifier]
    STATE_ID_TSS_STATUS: _ClassVar[StateIdentifier]
    STATE_ID_HINTS_KEY_SETS: _ClassVar[StateIdentifier]
    STATE_ID_ACTIVE_HINTS_CONSTRUCTION: _ClassVar[StateIdentifier]
    STATE_ID_NEXT_HINTS_CONSTRUCTION: _ClassVar[StateIdentifier]
    STATE_ID_PREPROCESSING_VOTES: _ClassVar[StateIdentifier]
    STATE_ID_ENTITY_COUNTS: _ClassVar[StateIdentifier]
    STATE_ID_LEDGER_ID: _ClassVar[StateIdentifier]
    STATE_ID_PROOF_KEY_SETS: _ClassVar[StateIdentifier]
    STATE_ID_ACTIVE_PROOF_CONSTRUCTION: _ClassVar[StateIdentifier]
    STATE_ID_NEXT_PROOF_CONSTRUCTION: _ClassVar[StateIdentifier]
    STATE_ID_HISTORY_SIGNATURES: _ClassVar[StateIdentifier]
    STATE_ID_PROOF_VOTES: _ClassVar[StateIdentifier]
    STATE_ID_CRS_STATE: _ClassVar[StateIdentifier]
    STATE_ID_CRS_PUBLICATIONS: _ClassVar[StateIdentifier]
    STATE_ID_NODE_REWARDS: _ClassVar[StateIdentifier]
    STATE_ID_EVM_HOOK_STATES: _ClassVar[StateIdentifier]
    STATE_ID_EVM_HOOK_STORAGE: _ClassVar[StateIdentifier]
    STATE_ID_ACCOUNT_NODE_REL: _ClassVar[StateIdentifier]
    STATE_ID_WRAPS_MESSAGE_HISTORIES: _ClassVar[StateIdentifier]
    STATE_ID_NODE_PAYMENTS: _ClassVar[StateIdentifier]
    STATE_ID_REGISTERED_NODES: _ClassVar[StateIdentifier]
    STATE_ID_TRANSACTION_RECEIPTS: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_150: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_151: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_152: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_153: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_154: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_155: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_156: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_157: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_158: _ClassVar[StateIdentifier]
    STATE_ID_UPGRADE_DATA_159: _ClassVar[StateIdentifier]

class NewStateType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SINGLETON: _ClassVar[NewStateType]
    VIRTUAL_MAP: _ClassVar[NewStateType]
    QUEUE: _ClassVar[NewStateType]
UNKNOWN: StateIdentifier
STATE_ID_ENTITY_ID: StateIdentifier
STATE_ID_ACCOUNTS: StateIdentifier
STATE_ID_ALIASES: StateIdentifier
STATE_ID_STORAGE: StateIdentifier
STATE_ID_BYTECODE: StateIdentifier
STATE_ID_FILES: StateIdentifier
STATE_ID_TOKENS: StateIdentifier
STATE_ID_NFTS: StateIdentifier
STATE_ID_TOKEN_RELS: StateIdentifier
STATE_ID_STAKING_INFOS: StateIdentifier
STATE_ID_STAKING_NETWORK_REWARDS: StateIdentifier
STATE_ID_THROTTLE_USAGE_SNAPSHOTS: StateIdentifier
STATE_ID_CONGESTION_LEVEL_STARTS: StateIdentifier
STATE_ID_SCHEDULES_BY_ID: StateIdentifier
STATE_ID_SCHEDULES_BY_EXPIRY_SEC: StateIdentifier
STATE_ID_SCHEDULES_BY_EQUALITY: StateIdentifier
STATE_ID_MIDNIGHT_RATES: StateIdentifier
STATE_ID_RUNNING_HASHES: StateIdentifier
STATE_ID_BLOCKS: StateIdentifier
STATE_ID_NODES: StateIdentifier
STATE_ID_TOPICS: StateIdentifier
STATE_ID_UPGRADE_FILE_HASH: StateIdentifier
STATE_ID_FREEZE_TIME: StateIdentifier
STATE_ID_BLOCK_STREAM_INFO: StateIdentifier
STATE_ID_PENDING_AIRDROPS: StateIdentifier
STATE_ID_PLATFORM_STATE: StateIdentifier
STATE_ID_ROSTER_STATE: StateIdentifier
STATE_ID_ROSTERS: StateIdentifier
STATE_ID_SCHEDULED_COUNTS: StateIdentifier
STATE_ID_SCHEDULE_ID_BY_EQUALITY: StateIdentifier
STATE_ID_TSS_MESSAGES: StateIdentifier
STATE_ID_TSS_VOTES: StateIdentifier
STATE_ID_SCHEDULED_ORDERS: StateIdentifier
STATE_ID_SCHEDULED_USAGES: StateIdentifier
STATE_ID_TSS_ENCRYPTION_KEYS: StateIdentifier
STATE_ID_TSS_STATUS: StateIdentifier
STATE_ID_HINTS_KEY_SETS: StateIdentifier
STATE_ID_ACTIVE_HINTS_CONSTRUCTION: StateIdentifier
STATE_ID_NEXT_HINTS_CONSTRUCTION: StateIdentifier
STATE_ID_PREPROCESSING_VOTES: StateIdentifier
STATE_ID_ENTITY_COUNTS: StateIdentifier
STATE_ID_LEDGER_ID: StateIdentifier
STATE_ID_PROOF_KEY_SETS: StateIdentifier
STATE_ID_ACTIVE_PROOF_CONSTRUCTION: StateIdentifier
STATE_ID_NEXT_PROOF_CONSTRUCTION: StateIdentifier
STATE_ID_HISTORY_SIGNATURES: StateIdentifier
STATE_ID_PROOF_VOTES: StateIdentifier
STATE_ID_CRS_STATE: StateIdentifier
STATE_ID_CRS_PUBLICATIONS: StateIdentifier
STATE_ID_NODE_REWARDS: StateIdentifier
STATE_ID_EVM_HOOK_STATES: StateIdentifier
STATE_ID_EVM_HOOK_STORAGE: StateIdentifier
STATE_ID_ACCOUNT_NODE_REL: StateIdentifier
STATE_ID_WRAPS_MESSAGE_HISTORIES: StateIdentifier
STATE_ID_NODE_PAYMENTS: StateIdentifier
STATE_ID_REGISTERED_NODES: StateIdentifier
STATE_ID_TRANSACTION_RECEIPTS: StateIdentifier
STATE_ID_UPGRADE_DATA_150: StateIdentifier
STATE_ID_UPGRADE_DATA_151: StateIdentifier
STATE_ID_UPGRADE_DATA_152: StateIdentifier
STATE_ID_UPGRADE_DATA_153: StateIdentifier
STATE_ID_UPGRADE_DATA_154: StateIdentifier
STATE_ID_UPGRADE_DATA_155: StateIdentifier
STATE_ID_UPGRADE_DATA_156: StateIdentifier
STATE_ID_UPGRADE_DATA_157: StateIdentifier
STATE_ID_UPGRADE_DATA_158: StateIdentifier
STATE_ID_UPGRADE_DATA_159: StateIdentifier
SINGLETON: NewStateType
VIRTUAL_MAP: NewStateType
QUEUE: NewStateType

class StateChanges(_message.Message):
    __slots__ = ("consensus_timestamp", "state_changes")
    CONSENSUS_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    STATE_CHANGES_FIELD_NUMBER: _ClassVar[int]
    consensus_timestamp: _timestamp_pb2.Timestamp
    state_changes: _containers.RepeatedCompositeFieldContainer[StateChange]
    def __init__(self, consensus_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., state_changes: _Optional[_Iterable[_Union[StateChange, _Mapping]]] = ...) -> None: ...

class StateChange(_message.Message):
    __slots__ = ("state_id", "state_add", "state_remove", "singleton_update", "map_update", "map_delete", "queue_push", "queue_pop")
    STATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_ADD_FIELD_NUMBER: _ClassVar[int]
    STATE_REMOVE_FIELD_NUMBER: _ClassVar[int]
    SINGLETON_UPDATE_FIELD_NUMBER: _ClassVar[int]
    MAP_UPDATE_FIELD_NUMBER: _ClassVar[int]
    MAP_DELETE_FIELD_NUMBER: _ClassVar[int]
    QUEUE_PUSH_FIELD_NUMBER: _ClassVar[int]
    QUEUE_POP_FIELD_NUMBER: _ClassVar[int]
    state_id: int
    state_add: NewStateChange
    state_remove: RemovedStateChange
    singleton_update: SingletonUpdateChange
    map_update: MapUpdateChange
    map_delete: MapDeleteChange
    queue_push: QueuePushChange
    queue_pop: QueuePopChange
    def __init__(self, state_id: _Optional[int] = ..., state_add: _Optional[_Union[NewStateChange, _Mapping]] = ..., state_remove: _Optional[_Union[RemovedStateChange, _Mapping]] = ..., singleton_update: _Optional[_Union[SingletonUpdateChange, _Mapping]] = ..., map_update: _Optional[_Union[MapUpdateChange, _Mapping]] = ..., map_delete: _Optional[_Union[MapDeleteChange, _Mapping]] = ..., queue_push: _Optional[_Union[QueuePushChange, _Mapping]] = ..., queue_pop: _Optional[_Union[QueuePopChange, _Mapping]] = ...) -> None: ...

class NewStateChange(_message.Message):
    __slots__ = ("state_type",)
    STATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    state_type: NewStateType
    def __init__(self, state_type: _Optional[_Union[NewStateType, str]] = ...) -> None: ...

class RemovedStateChange(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SingletonUpdateChange(_message.Message):
    __slots__ = ("block_info_value", "congestion_level_starts_value", "entity_number_value", "exchange_rate_set_value", "network_staking_rewards_value", "bytes_value", "string_value", "running_hashes_value", "throttle_usage_snapshots_value", "timestamp_value", "block_stream_info_value", "platform_state_value", "roster_state_value", "hints_construction_value", "entity_counts_value", "history_proof_construction_value", "crs_state_value", "node_rewards_value", "node_payments_value")
    BLOCK_INFO_VALUE_FIELD_NUMBER: _ClassVar[int]
    CONGESTION_LEVEL_STARTS_VALUE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_NUMBER_VALUE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_RATE_SET_VALUE_FIELD_NUMBER: _ClassVar[int]
    NETWORK_STAKING_REWARDS_VALUE_FIELD_NUMBER: _ClassVar[int]
    BYTES_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_VALUE_FIELD_NUMBER: _ClassVar[int]
    RUNNING_HASHES_VALUE_FIELD_NUMBER: _ClassVar[int]
    THROTTLE_USAGE_SNAPSHOTS_VALUE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_VALUE_FIELD_NUMBER: _ClassVar[int]
    BLOCK_STREAM_INFO_VALUE_FIELD_NUMBER: _ClassVar[int]
    PLATFORM_STATE_VALUE_FIELD_NUMBER: _ClassVar[int]
    ROSTER_STATE_VALUE_FIELD_NUMBER: _ClassVar[int]
    HINTS_CONSTRUCTION_VALUE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_COUNTS_VALUE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_PROOF_CONSTRUCTION_VALUE_FIELD_NUMBER: _ClassVar[int]
    CRS_STATE_VALUE_FIELD_NUMBER: _ClassVar[int]
    NODE_REWARDS_VALUE_FIELD_NUMBER: _ClassVar[int]
    NODE_PAYMENTS_VALUE_FIELD_NUMBER: _ClassVar[int]
    block_info_value: _block_info_pb2.BlockInfo
    congestion_level_starts_value: _congestion_level_starts_pb2.CongestionLevelStarts
    entity_number_value: _wrappers_pb2.UInt64Value
    exchange_rate_set_value: _exchange_rate_pb2.ExchangeRateSet
    network_staking_rewards_value: _network_staking_rewards_pb2.NetworkStakingRewards
    bytes_value: _wrappers_pb2.BytesValue
    string_value: _wrappers_pb2.StringValue
    running_hashes_value: _running_hashes_pb2.RunningHashes
    throttle_usage_snapshots_value: _throttle_usage_snapshots_pb2.ThrottleUsageSnapshots
    timestamp_value: _timestamp_pb2.Timestamp
    block_stream_info_value: _block_stream_info_pb2.BlockStreamInfo
    platform_state_value: _platform_state_pb2.PlatformState
    roster_state_value: _roster_state_pb2.RosterState
    hints_construction_value: _hints_types_pb2.HintsConstruction
    entity_counts_value: _entity_counts_pb2.EntityCounts
    history_proof_construction_value: _history_types_pb2.HistoryProofConstruction
    crs_state_value: _hints_types_pb2.CRSState
    node_rewards_value: _node_rewards_pb2.NodeRewards
    node_payments_value: _node_payments_pb2.NodePayments
    def __init__(self, block_info_value: _Optional[_Union[_block_info_pb2.BlockInfo, _Mapping]] = ..., congestion_level_starts_value: _Optional[_Union[_congestion_level_starts_pb2.CongestionLevelStarts, _Mapping]] = ..., entity_number_value: _Optional[_Union[_wrappers_pb2.UInt64Value, _Mapping]] = ..., exchange_rate_set_value: _Optional[_Union[_exchange_rate_pb2.ExchangeRateSet, _Mapping]] = ..., network_staking_rewards_value: _Optional[_Union[_network_staking_rewards_pb2.NetworkStakingRewards, _Mapping]] = ..., bytes_value: _Optional[_Union[_wrappers_pb2.BytesValue, _Mapping]] = ..., string_value: _Optional[_Union[_wrappers_pb2.StringValue, _Mapping]] = ..., running_hashes_value: _Optional[_Union[_running_hashes_pb2.RunningHashes, _Mapping]] = ..., throttle_usage_snapshots_value: _Optional[_Union[_throttle_usage_snapshots_pb2.ThrottleUsageSnapshots, _Mapping]] = ..., timestamp_value: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., block_stream_info_value: _Optional[_Union[_block_stream_info_pb2.BlockStreamInfo, _Mapping]] = ..., platform_state_value: _Optional[_Union[_platform_state_pb2.PlatformState, _Mapping]] = ..., roster_state_value: _Optional[_Union[_roster_state_pb2.RosterState, _Mapping]] = ..., hints_construction_value: _Optional[_Union[_hints_types_pb2.HintsConstruction, _Mapping]] = ..., entity_counts_value: _Optional[_Union[_entity_counts_pb2.EntityCounts, _Mapping]] = ..., history_proof_construction_value: _Optional[_Union[_history_types_pb2.HistoryProofConstruction, _Mapping]] = ..., crs_state_value: _Optional[_Union[_hints_types_pb2.CRSState, _Mapping]] = ..., node_rewards_value: _Optional[_Union[_node_rewards_pb2.NodeRewards, _Mapping]] = ..., node_payments_value: _Optional[_Union[_node_payments_pb2.NodePayments, _Mapping]] = ...) -> None: ...

class MapUpdateChange(_message.Message):
    __slots__ = ("key", "value", "identical")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    IDENTICAL_FIELD_NUMBER: _ClassVar[int]
    key: MapChangeKey
    value: MapChangeValue
    identical: bool
    def __init__(self, key: _Optional[_Union[MapChangeKey, _Mapping]] = ..., value: _Optional[_Union[MapChangeValue, _Mapping]] = ..., identical: bool = ...) -> None: ...

class MapDeleteChange(_message.Message):
    __slots__ = ("key",)
    KEY_FIELD_NUMBER: _ClassVar[int]
    key: MapChangeKey
    def __init__(self, key: _Optional[_Union[MapChangeKey, _Mapping]] = ...) -> None: ...

class MapChangeKey(_message.Message):
    __slots__ = ("account_id_key", "token_relationship_key", "entity_number_key", "file_id_key", "nft_id_key", "proto_bytes_key", "proto_long_key", "proto_string_key", "schedule_id_key", "slot_key_key", "token_id_key", "topic_id_key", "contract_id_key", "pending_airdrop_id_key", "timestamp_seconds_key", "scheduled_order_key", "tss_message_map_key", "tss_vote_map_key", "hints_party_id_key", "preprocessing_vote_id_key", "node_id_key", "construction_node_id_key", "hook_id_key", "evm_hook_slot_key")
    ACCOUNT_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    TOKEN_RELATIONSHIP_KEY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_NUMBER_KEY_FIELD_NUMBER: _ClassVar[int]
    FILE_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    NFT_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    PROTO_BYTES_KEY_FIELD_NUMBER: _ClassVar[int]
    PROTO_LONG_KEY_FIELD_NUMBER: _ClassVar[int]
    PROTO_STRING_KEY_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    SLOT_KEY_KEY_FIELD_NUMBER: _ClassVar[int]
    TOKEN_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    TOPIC_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    PENDING_AIRDROP_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_SECONDS_KEY_FIELD_NUMBER: _ClassVar[int]
    SCHEDULED_ORDER_KEY_FIELD_NUMBER: _ClassVar[int]
    TSS_MESSAGE_MAP_KEY_FIELD_NUMBER: _ClassVar[int]
    TSS_VOTE_MAP_KEY_FIELD_NUMBER: _ClassVar[int]
    HINTS_PARTY_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    PREPROCESSING_VOTE_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    CONSTRUCTION_NODE_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    HOOK_ID_KEY_FIELD_NUMBER: _ClassVar[int]
    EVM_HOOK_SLOT_KEY_FIELD_NUMBER: _ClassVar[int]
    account_id_key: _basic_types_pb2.AccountID
    token_relationship_key: _basic_types_pb2.TokenAssociation
    entity_number_key: _wrappers_pb2.UInt64Value
    file_id_key: _basic_types_pb2.FileID
    nft_id_key: _basic_types_pb2.NftID
    proto_bytes_key: _wrappers_pb2.BytesValue
    proto_long_key: _wrappers_pb2.Int64Value
    proto_string_key: _wrappers_pb2.StringValue
    schedule_id_key: _basic_types_pb2.ScheduleID
    slot_key_key: _storage_slot_pb2.SlotKey
    token_id_key: _basic_types_pb2.TokenID
    topic_id_key: _basic_types_pb2.TopicID
    contract_id_key: _basic_types_pb2.ContractID
    pending_airdrop_id_key: _basic_types_pb2.PendingAirdropId
    timestamp_seconds_key: _timestamp_pb2.TimestampSeconds
    scheduled_order_key: _schedule_pb2.ScheduledOrder
    tss_message_map_key: _tss_message_map_key_pb2.TssMessageMapKey
    tss_vote_map_key: _tss_vote_map_key_pb2.TssVoteMapKey
    hints_party_id_key: _hints_types_pb2.HintsPartyId
    preprocessing_vote_id_key: _hints_types_pb2.PreprocessingVoteId
    node_id_key: _platform_state_pb2.NodeId
    construction_node_id_key: _history_types_pb2.ConstructionNodeId
    hook_id_key: _basic_types_pb2.HookId
    evm_hook_slot_key: _evm_hook_state_pb2.EvmHookSlotKey
    def __init__(self, account_id_key: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., token_relationship_key: _Optional[_Union[_basic_types_pb2.TokenAssociation, _Mapping]] = ..., entity_number_key: _Optional[_Union[_wrappers_pb2.UInt64Value, _Mapping]] = ..., file_id_key: _Optional[_Union[_basic_types_pb2.FileID, _Mapping]] = ..., nft_id_key: _Optional[_Union[_basic_types_pb2.NftID, _Mapping]] = ..., proto_bytes_key: _Optional[_Union[_wrappers_pb2.BytesValue, _Mapping]] = ..., proto_long_key: _Optional[_Union[_wrappers_pb2.Int64Value, _Mapping]] = ..., proto_string_key: _Optional[_Union[_wrappers_pb2.StringValue, _Mapping]] = ..., schedule_id_key: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., slot_key_key: _Optional[_Union[_storage_slot_pb2.SlotKey, _Mapping]] = ..., token_id_key: _Optional[_Union[_basic_types_pb2.TokenID, _Mapping]] = ..., topic_id_key: _Optional[_Union[_basic_types_pb2.TopicID, _Mapping]] = ..., contract_id_key: _Optional[_Union[_basic_types_pb2.ContractID, _Mapping]] = ..., pending_airdrop_id_key: _Optional[_Union[_basic_types_pb2.PendingAirdropId, _Mapping]] = ..., timestamp_seconds_key: _Optional[_Union[_timestamp_pb2.TimestampSeconds, _Mapping]] = ..., scheduled_order_key: _Optional[_Union[_schedule_pb2.ScheduledOrder, _Mapping]] = ..., tss_message_map_key: _Optional[_Union[_tss_message_map_key_pb2.TssMessageMapKey, _Mapping]] = ..., tss_vote_map_key: _Optional[_Union[_tss_vote_map_key_pb2.TssVoteMapKey, _Mapping]] = ..., hints_party_id_key: _Optional[_Union[_hints_types_pb2.HintsPartyId, _Mapping]] = ..., preprocessing_vote_id_key: _Optional[_Union[_hints_types_pb2.PreprocessingVoteId, _Mapping]] = ..., node_id_key: _Optional[_Union[_platform_state_pb2.NodeId, _Mapping]] = ..., construction_node_id_key: _Optional[_Union[_history_types_pb2.ConstructionNodeId, _Mapping]] = ..., hook_id_key: _Optional[_Union[_basic_types_pb2.HookId, _Mapping]] = ..., evm_hook_slot_key: _Optional[_Union[_evm_hook_state_pb2.EvmHookSlotKey, _Mapping]] = ...) -> None: ...

class MapChangeValue(_message.Message):
    __slots__ = ("account_value", "account_id_value", "bytecode_value", "file_value", "nft_value", "proto_string_value", "schedule_value", "schedule_list_value", "slot_value_value", "staking_node_info_value", "token_value", "token_relation_value", "topic_value", "node_value", "account_pending_airdrop_value", "roster_value", "scheduled_counts_value", "schedule_id_value", "throttle_usage_snapshots_value", "tss_encryption_keys_value", "tss_message_value", "tss_vote_value", "hints_key_set_value", "preprocessing_vote_value", "crs_publication_value", "history_signature_value", "history_proof_vote_value", "proof_key_set_value", "evm_hook_state_value", "node_id_value", "wraps_message_history_value", "registered_node_value")
    ACCOUNT_VALUE_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_VALUE_FIELD_NUMBER: _ClassVar[int]
    BYTECODE_VALUE_FIELD_NUMBER: _ClassVar[int]
    FILE_VALUE_FIELD_NUMBER: _ClassVar[int]
    NFT_VALUE_FIELD_NUMBER: _ClassVar[int]
    PROTO_STRING_VALUE_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_VALUE_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_LIST_VALUE_FIELD_NUMBER: _ClassVar[int]
    SLOT_VALUE_VALUE_FIELD_NUMBER: _ClassVar[int]
    STAKING_NODE_INFO_VALUE_FIELD_NUMBER: _ClassVar[int]
    TOKEN_VALUE_FIELD_NUMBER: _ClassVar[int]
    TOKEN_RELATION_VALUE_FIELD_NUMBER: _ClassVar[int]
    TOPIC_VALUE_FIELD_NUMBER: _ClassVar[int]
    NODE_VALUE_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_PENDING_AIRDROP_VALUE_FIELD_NUMBER: _ClassVar[int]
    ROSTER_VALUE_FIELD_NUMBER: _ClassVar[int]
    SCHEDULED_COUNTS_VALUE_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_ID_VALUE_FIELD_NUMBER: _ClassVar[int]
    THROTTLE_USAGE_SNAPSHOTS_VALUE_FIELD_NUMBER: _ClassVar[int]
    TSS_ENCRYPTION_KEYS_VALUE_FIELD_NUMBER: _ClassVar[int]
    TSS_MESSAGE_VALUE_FIELD_NUMBER: _ClassVar[int]
    TSS_VOTE_VALUE_FIELD_NUMBER: _ClassVar[int]
    HINTS_KEY_SET_VALUE_FIELD_NUMBER: _ClassVar[int]
    PREPROCESSING_VOTE_VALUE_FIELD_NUMBER: _ClassVar[int]
    CRS_PUBLICATION_VALUE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_SIGNATURE_VALUE_FIELD_NUMBER: _ClassVar[int]
    HISTORY_PROOF_VOTE_VALUE_FIELD_NUMBER: _ClassVar[int]
    PROOF_KEY_SET_VALUE_FIELD_NUMBER: _ClassVar[int]
    EVM_HOOK_STATE_VALUE_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_VALUE_FIELD_NUMBER: _ClassVar[int]
    WRAPS_MESSAGE_HISTORY_VALUE_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_NODE_VALUE_FIELD_NUMBER: _ClassVar[int]
    account_value: _account_pb2.Account
    account_id_value: _basic_types_pb2.AccountID
    bytecode_value: _bytecode_pb2.Bytecode
    file_value: _file_pb2.File
    nft_value: _nft_pb2.Nft
    proto_string_value: _wrappers_pb2.StringValue
    schedule_value: _schedule_pb2.Schedule
    schedule_list_value: _schedule_pb2.ScheduleList
    slot_value_value: _storage_slot_pb2.SlotValue
    staking_node_info_value: _staking_node_info_pb2.StakingNodeInfo
    token_value: _token_pb2.Token
    token_relation_value: _token_relation_pb2.TokenRelation
    topic_value: _topic_pb2.Topic
    node_value: _node_pb2.Node
    account_pending_airdrop_value: _account_pending_airdrop_pb2.AccountPendingAirdrop
    roster_value: _roster_pb2.Roster
    scheduled_counts_value: _schedule_pb2.ScheduledCounts
    schedule_id_value: _basic_types_pb2.ScheduleID
    throttle_usage_snapshots_value: _throttle_usage_snapshots_pb2.ThrottleUsageSnapshots
    tss_encryption_keys_value: _tss_encryption_keys_pb2.TssEncryptionKeys
    tss_message_value: _tss_message_pb2.TssMessageTransactionBody
    tss_vote_value: _tss_vote_pb2.TssVoteTransactionBody
    hints_key_set_value: _hints_types_pb2.HintsKeySet
    preprocessing_vote_value: _hints_types_pb2.PreprocessingVote
    crs_publication_value: _crs_publication_pb2.CrsPublicationTransactionBody
    history_signature_value: _history_types_pb2.RecordedHistorySignature
    history_proof_vote_value: _history_types_pb2.HistoryProofVote
    proof_key_set_value: _history_types_pb2.ProofKeySet
    evm_hook_state_value: _evm_hook_state_pb2.EvmHookState
    node_id_value: _platform_state_pb2.NodeId
    wraps_message_history_value: _history_types_pb2.WrapsMessageHistory
    registered_node_value: _registered_node_pb2.RegisteredNode
    def __init__(self, account_value: _Optional[_Union[_account_pb2.Account, _Mapping]] = ..., account_id_value: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., bytecode_value: _Optional[_Union[_bytecode_pb2.Bytecode, _Mapping]] = ..., file_value: _Optional[_Union[_file_pb2.File, _Mapping]] = ..., nft_value: _Optional[_Union[_nft_pb2.Nft, _Mapping]] = ..., proto_string_value: _Optional[_Union[_wrappers_pb2.StringValue, _Mapping]] = ..., schedule_value: _Optional[_Union[_schedule_pb2.Schedule, _Mapping]] = ..., schedule_list_value: _Optional[_Union[_schedule_pb2.ScheduleList, _Mapping]] = ..., slot_value_value: _Optional[_Union[_storage_slot_pb2.SlotValue, _Mapping]] = ..., staking_node_info_value: _Optional[_Union[_staking_node_info_pb2.StakingNodeInfo, _Mapping]] = ..., token_value: _Optional[_Union[_token_pb2.Token, _Mapping]] = ..., token_relation_value: _Optional[_Union[_token_relation_pb2.TokenRelation, _Mapping]] = ..., topic_value: _Optional[_Union[_topic_pb2.Topic, _Mapping]] = ..., node_value: _Optional[_Union[_node_pb2.Node, _Mapping]] = ..., account_pending_airdrop_value: _Optional[_Union[_account_pending_airdrop_pb2.AccountPendingAirdrop, _Mapping]] = ..., roster_value: _Optional[_Union[_roster_pb2.Roster, _Mapping]] = ..., scheduled_counts_value: _Optional[_Union[_schedule_pb2.ScheduledCounts, _Mapping]] = ..., schedule_id_value: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., throttle_usage_snapshots_value: _Optional[_Union[_throttle_usage_snapshots_pb2.ThrottleUsageSnapshots, _Mapping]] = ..., tss_encryption_keys_value: _Optional[_Union[_tss_encryption_keys_pb2.TssEncryptionKeys, _Mapping]] = ..., tss_message_value: _Optional[_Union[_tss_message_pb2.TssMessageTransactionBody, _Mapping]] = ..., tss_vote_value: _Optional[_Union[_tss_vote_pb2.TssVoteTransactionBody, _Mapping]] = ..., hints_key_set_value: _Optional[_Union[_hints_types_pb2.HintsKeySet, _Mapping]] = ..., preprocessing_vote_value: _Optional[_Union[_hints_types_pb2.PreprocessingVote, _Mapping]] = ..., crs_publication_value: _Optional[_Union[_crs_publication_pb2.CrsPublicationTransactionBody, _Mapping]] = ..., history_signature_value: _Optional[_Union[_history_types_pb2.RecordedHistorySignature, _Mapping]] = ..., history_proof_vote_value: _Optional[_Union[_history_types_pb2.HistoryProofVote, _Mapping]] = ..., proof_key_set_value: _Optional[_Union[_history_types_pb2.ProofKeySet, _Mapping]] = ..., evm_hook_state_value: _Optional[_Union[_evm_hook_state_pb2.EvmHookState, _Mapping]] = ..., node_id_value: _Optional[_Union[_platform_state_pb2.NodeId, _Mapping]] = ..., wraps_message_history_value: _Optional[_Union[_history_types_pb2.WrapsMessageHistory, _Mapping]] = ..., registered_node_value: _Optional[_Union[_registered_node_pb2.RegisteredNode, _Mapping]] = ...) -> None: ...

class QueuePushChange(_message.Message):
    __slots__ = ("proto_bytes_element", "proto_string_element", "transaction_receipt_entries_element")
    PROTO_BYTES_ELEMENT_FIELD_NUMBER: _ClassVar[int]
    PROTO_STRING_ELEMENT_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_RECEIPT_ENTRIES_ELEMENT_FIELD_NUMBER: _ClassVar[int]
    proto_bytes_element: _wrappers_pb2.BytesValue
    proto_string_element: _wrappers_pb2.StringValue
    transaction_receipt_entries_element: _recordcache_pb2.TransactionReceiptEntries
    def __init__(self, proto_bytes_element: _Optional[_Union[_wrappers_pb2.BytesValue, _Mapping]] = ..., proto_string_element: _Optional[_Union[_wrappers_pb2.StringValue, _Mapping]] = ..., transaction_receipt_entries_element: _Optional[_Union[_recordcache_pb2.TransactionReceiptEntries, _Mapping]] = ...) -> None: ...

class QueuePopChange(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
