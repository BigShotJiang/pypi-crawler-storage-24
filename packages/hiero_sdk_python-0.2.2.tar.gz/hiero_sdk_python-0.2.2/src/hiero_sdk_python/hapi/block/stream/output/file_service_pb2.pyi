from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class AppendFileOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CreateFileOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DeleteFileOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class UpdateFileOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SystemDeleteOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SystemUndeleteOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
