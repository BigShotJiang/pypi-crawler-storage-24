from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class WrappedRecordFileBlockHashes(_message.Message):
    __slots__ = ("block_number", "consensus_timestamp_hash", "output_items_tree_root_hash")
    BLOCK_NUMBER_FIELD_NUMBER: _ClassVar[int]
    CONSENSUS_TIMESTAMP_HASH_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_ITEMS_TREE_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    block_number: int
    consensus_timestamp_hash: bytes
    output_items_tree_root_hash: bytes
    def __init__(self, block_number: _Optional[int] = ..., consensus_timestamp_hash: _Optional[bytes] = ..., output_items_tree_root_hash: _Optional[bytes] = ...) -> None: ...

class WrappedRecordFileBlockHashesLog(_message.Message):
    __slots__ = ("entries",)
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[WrappedRecordFileBlockHashes]
    def __init__(self, entries: _Optional[_Iterable[_Union[WrappedRecordFileBlockHashes, _Mapping]]] = ...) -> None: ...
