from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LedgerIdPublicationTransactionBody(_message.Message):
    __slots__ = ("ledger_id", "history_proof_verification_key", "node_contributions")
    LEDGER_ID_FIELD_NUMBER: _ClassVar[int]
    HISTORY_PROOF_VERIFICATION_KEY_FIELD_NUMBER: _ClassVar[int]
    NODE_CONTRIBUTIONS_FIELD_NUMBER: _ClassVar[int]
    ledger_id: bytes
    history_proof_verification_key: bytes
    node_contributions: _containers.RepeatedCompositeFieldContainer[LedgerIdNodeContribution]
    def __init__(self, ledger_id: _Optional[bytes] = ..., history_proof_verification_key: _Optional[bytes] = ..., node_contributions: _Optional[_Iterable[_Union[LedgerIdNodeContribution, _Mapping]]] = ...) -> None: ...

class LedgerIdNodeContribution(_message.Message):
    __slots__ = ("node_id", "weight", "history_proof_key")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    HISTORY_PROOF_KEY_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    weight: int
    history_proof_key: bytes
    def __init__(self, node_id: _Optional[int] = ..., weight: _Optional[int] = ..., history_proof_key: _Optional[bytes] = ...) -> None: ...
