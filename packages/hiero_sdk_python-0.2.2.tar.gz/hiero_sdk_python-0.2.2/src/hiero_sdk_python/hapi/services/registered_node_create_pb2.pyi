from ..services import basic_types_pb2 as _basic_types_pb2
from ..services import registered_service_endpoint_pb2 as _registered_service_endpoint_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RegisteredNodeCreateTransactionBody(_message.Message):
    __slots__ = ("admin_key", "description", "service_endpoint")
    ADMIN_KEY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SERVICE_ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    admin_key: _basic_types_pb2.Key
    description: str
    service_endpoint: _containers.RepeatedCompositeFieldContainer[_registered_service_endpoint_pb2.RegisteredServiceEndpoint]
    def __init__(self, admin_key: _Optional[_Union[_basic_types_pb2.Key, _Mapping]] = ..., description: _Optional[str] = ..., service_endpoint: _Optional[_Iterable[_Union[_registered_service_endpoint_pb2.RegisteredServiceEndpoint, _Mapping]]] = ...) -> None: ...
