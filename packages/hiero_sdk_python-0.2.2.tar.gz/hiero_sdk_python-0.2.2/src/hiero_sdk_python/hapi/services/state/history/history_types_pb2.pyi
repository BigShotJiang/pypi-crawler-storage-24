from ....services import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class WrapsPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    R1: _ClassVar[WrapsPhase]
    R2: _ClassVar[WrapsPhase]
    R3: _ClassVar[WrapsPhase]
    AGGREGATE: _ClassVar[WrapsPhase]
    POST_AGGREGATION: _ClassVar[WrapsPhase]
R1: WrapsPhase
R2: WrapsPhase
R3: WrapsPhase
AGGREGATE: WrapsPhase
POST_AGGREGATION: WrapsPhase

class ProofKeySet(_message.Message):
    __slots__ = ("adoption_time", "key", "next_key")
    ADOPTION_TIME_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    NEXT_KEY_FIELD_NUMBER: _ClassVar[int]
    adoption_time: _timestamp_pb2.Timestamp
    key: bytes
    next_key: bytes
    def __init__(self, adoption_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., key: _Optional[bytes] = ..., next_key: _Optional[bytes] = ...) -> None: ...

class ProofKey(_message.Message):
    __slots__ = ("node_id", "key")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    key: bytes
    def __init__(self, node_id: _Optional[int] = ..., key: _Optional[bytes] = ...) -> None: ...

class History(_message.Message):
    __slots__ = ("address_book_hash", "metadata")
    ADDRESS_BOOK_HASH_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    address_book_hash: bytes
    metadata: bytes
    def __init__(self, address_book_hash: _Optional[bytes] = ..., metadata: _Optional[bytes] = ...) -> None: ...

class HistoryProof(_message.Message):
    __slots__ = ("target_proof_keys", "target_history", "chain_of_trust_proof", "uncompressed_wraps_proof")
    TARGET_PROOF_KEYS_FIELD_NUMBER: _ClassVar[int]
    TARGET_HISTORY_FIELD_NUMBER: _ClassVar[int]
    CHAIN_OF_TRUST_PROOF_FIELD_NUMBER: _ClassVar[int]
    UNCOMPRESSED_WRAPS_PROOF_FIELD_NUMBER: _ClassVar[int]
    target_proof_keys: _containers.RepeatedCompositeFieldContainer[ProofKey]
    target_history: History
    chain_of_trust_proof: ChainOfTrustProof
    uncompressed_wraps_proof: bytes
    def __init__(self, target_proof_keys: _Optional[_Iterable[_Union[ProofKey, _Mapping]]] = ..., target_history: _Optional[_Union[History, _Mapping]] = ..., chain_of_trust_proof: _Optional[_Union[ChainOfTrustProof, _Mapping]] = ..., uncompressed_wraps_proof: _Optional[bytes] = ...) -> None: ...

class HistoryProofConstruction(_message.Message):
    __slots__ = ("construction_id", "source_roster_hash", "target_roster_hash", "grace_period_end_time", "assembly_start_time", "target_proof", "failure_reason", "wraps_signing_state", "wraps_retry_count")
    CONSTRUCTION_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ROSTER_HASH_FIELD_NUMBER: _ClassVar[int]
    TARGET_ROSTER_HASH_FIELD_NUMBER: _ClassVar[int]
    GRACE_PERIOD_END_TIME_FIELD_NUMBER: _ClassVar[int]
    ASSEMBLY_START_TIME_FIELD_NUMBER: _ClassVar[int]
    TARGET_PROOF_FIELD_NUMBER: _ClassVar[int]
    FAILURE_REASON_FIELD_NUMBER: _ClassVar[int]
    WRAPS_SIGNING_STATE_FIELD_NUMBER: _ClassVar[int]
    WRAPS_RETRY_COUNT_FIELD_NUMBER: _ClassVar[int]
    construction_id: int
    source_roster_hash: bytes
    target_roster_hash: bytes
    grace_period_end_time: _timestamp_pb2.Timestamp
    assembly_start_time: _timestamp_pb2.Timestamp
    target_proof: HistoryProof
    failure_reason: str
    wraps_signing_state: WrapsSigningState
    wraps_retry_count: int
    def __init__(self, construction_id: _Optional[int] = ..., source_roster_hash: _Optional[bytes] = ..., target_roster_hash: _Optional[bytes] = ..., grace_period_end_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., assembly_start_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., target_proof: _Optional[_Union[HistoryProof, _Mapping]] = ..., failure_reason: _Optional[str] = ..., wraps_signing_state: _Optional[_Union[WrapsSigningState, _Mapping]] = ..., wraps_retry_count: _Optional[int] = ...) -> None: ...

class WrapsSigningState(_message.Message):
    __slots__ = ("phase", "grace_period_end_time")
    PHASE_FIELD_NUMBER: _ClassVar[int]
    GRACE_PERIOD_END_TIME_FIELD_NUMBER: _ClassVar[int]
    phase: WrapsPhase
    grace_period_end_time: _timestamp_pb2.Timestamp
    def __init__(self, phase: _Optional[_Union[WrapsPhase, str]] = ..., grace_period_end_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ConstructionNodeId(_message.Message):
    __slots__ = ("construction_id", "node_id")
    CONSTRUCTION_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    construction_id: int
    node_id: int
    def __init__(self, construction_id: _Optional[int] = ..., node_id: _Optional[int] = ...) -> None: ...

class HistoryProofVote(_message.Message):
    __slots__ = ("proof", "congruent_node_id")
    PROOF_FIELD_NUMBER: _ClassVar[int]
    CONGRUENT_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    proof: HistoryProof
    congruent_node_id: int
    def __init__(self, proof: _Optional[_Union[HistoryProof, _Mapping]] = ..., congruent_node_id: _Optional[int] = ...) -> None: ...

class HistorySignature(_message.Message):
    __slots__ = ("history", "signature")
    HISTORY_FIELD_NUMBER: _ClassVar[int]
    SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    history: History
    signature: bytes
    def __init__(self, history: _Optional[_Union[History, _Mapping]] = ..., signature: _Optional[bytes] = ...) -> None: ...

class RecordedHistorySignature(_message.Message):
    __slots__ = ("signing_time", "history_signature")
    SIGNING_TIME_FIELD_NUMBER: _ClassVar[int]
    HISTORY_SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    signing_time: _timestamp_pb2.Timestamp
    history_signature: HistorySignature
    def __init__(self, signing_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., history_signature: _Optional[_Union[HistorySignature, _Mapping]] = ...) -> None: ...

class WrapsMessageDetails(_message.Message):
    __slots__ = ("publication_time", "phase", "message")
    PUBLICATION_TIME_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    publication_time: _timestamp_pb2.Timestamp
    phase: WrapsPhase
    message: bytes
    def __init__(self, publication_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., phase: _Optional[_Union[WrapsPhase, str]] = ..., message: _Optional[bytes] = ...) -> None: ...

class WrapsMessageHistory(_message.Message):
    __slots__ = ("messages",)
    MESSAGES_FIELD_NUMBER: _ClassVar[int]
    messages: _containers.RepeatedCompositeFieldContainer[WrapsMessageDetails]
    def __init__(self, messages: _Optional[_Iterable[_Union[WrapsMessageDetails, _Mapping]]] = ...) -> None: ...

class ChainOfTrustProof(_message.Message):
    __slots__ = ("aggregated_node_signatures", "wraps_proof")
    AGGREGATED_NODE_SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    WRAPS_PROOF_FIELD_NUMBER: _ClassVar[int]
    aggregated_node_signatures: AggregatedNodeSignatures
    wraps_proof: bytes
    def __init__(self, aggregated_node_signatures: _Optional[_Union[AggregatedNodeSignatures, _Mapping]] = ..., wraps_proof: _Optional[bytes] = ...) -> None: ...

class AggregatedNodeSignatures(_message.Message):
    __slots__ = ("aggregated_signature", "signing_node_ids", "verification_key")
    AGGREGATED_SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    SIGNING_NODE_IDS_FIELD_NUMBER: _ClassVar[int]
    VERIFICATION_KEY_FIELD_NUMBER: _ClassVar[int]
    aggregated_signature: bytes
    signing_node_ids: _containers.RepeatedScalarFieldContainer[int]
    verification_key: bytes
    def __init__(self, aggregated_signature: _Optional[bytes] = ..., signing_node_ids: _Optional[_Iterable[int]] = ..., verification_key: _Optional[bytes] = ...) -> None: ...
