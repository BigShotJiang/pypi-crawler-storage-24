from ....services import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ThrottleUsageSnapshots(_message.Message):
    __slots__ = ("tps_throttles", "gas_throttle", "evm_ops_duration_throttle")
    TPS_THROTTLES_FIELD_NUMBER: _ClassVar[int]
    GAS_THROTTLE_FIELD_NUMBER: _ClassVar[int]
    EVM_OPS_DURATION_THROTTLE_FIELD_NUMBER: _ClassVar[int]
    tps_throttles: _containers.RepeatedCompositeFieldContainer[ThrottleUsageSnapshot]
    gas_throttle: ThrottleUsageSnapshot
    evm_ops_duration_throttle: ThrottleUsageSnapshot
    def __init__(self, tps_throttles: _Optional[_Iterable[_Union[ThrottleUsageSnapshot, _Mapping]]] = ..., gas_throttle: _Optional[_Union[ThrottleUsageSnapshot, _Mapping]] = ..., evm_ops_duration_throttle: _Optional[_Union[ThrottleUsageSnapshot, _Mapping]] = ...) -> None: ...

class ThrottleUsageSnapshot(_message.Message):
    __slots__ = ("used", "last_decision_time")
    USED_FIELD_NUMBER: _ClassVar[int]
    LAST_DECISION_TIME_FIELD_NUMBER: _ClassVar[int]
    used: int
    last_decision_time: _timestamp_pb2.Timestamp
    def __init__(self, used: _Optional[int] = ..., last_decision_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
