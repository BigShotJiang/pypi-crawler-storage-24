from ....services import basic_types_pb2 as _basic_types_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SlotKey(_message.Message):
    __slots__ = ("contractID", "key")
    CONTRACTID_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    contractID: _basic_types_pb2.ContractID
    key: bytes
    def __init__(self, contractID: _Optional[_Union[_basic_types_pb2.ContractID, _Mapping]] = ..., key: _Optional[bytes] = ...) -> None: ...

class SlotValue(_message.Message):
    __slots__ = ("value", "previous_key", "next_key")
    VALUE_FIELD_NUMBER: _ClassVar[int]
    PREVIOUS_KEY_FIELD_NUMBER: _ClassVar[int]
    NEXT_KEY_FIELD_NUMBER: _ClassVar[int]
    value: bytes
    previous_key: bytes
    next_key: bytes
    def __init__(self, value: _Optional[bytes] = ..., previous_key: _Optional[bytes] = ..., next_key: _Optional[bytes] = ...) -> None: ...
