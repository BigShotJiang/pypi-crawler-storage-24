from ...services import basic_types_pb2 as _basic_types_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EntityNumber(_message.Message):
    __slots__ = ("number",)
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    number: int
    def __init__(self, number: _Optional[int] = ...) -> None: ...

class EntityIDPair(_message.Message):
    __slots__ = ("account_id", "token_id")
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    TOKEN_ID_FIELD_NUMBER: _ClassVar[int]
    account_id: _basic_types_pb2.AccountID
    token_id: _basic_types_pb2.TokenID
    def __init__(self, account_id: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., token_id: _Optional[_Union[_basic_types_pb2.TokenID, _Mapping]] = ...) -> None: ...
