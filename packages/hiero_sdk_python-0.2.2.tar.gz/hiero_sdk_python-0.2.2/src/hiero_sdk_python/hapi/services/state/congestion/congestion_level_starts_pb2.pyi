from ....services import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CongestionLevelStarts(_message.Message):
    __slots__ = ("generic_level_starts", "gas_level_starts")
    GENERIC_LEVEL_STARTS_FIELD_NUMBER: _ClassVar[int]
    GAS_LEVEL_STARTS_FIELD_NUMBER: _ClassVar[int]
    generic_level_starts: _containers.RepeatedCompositeFieldContainer[_timestamp_pb2.Timestamp]
    gas_level_starts: _containers.RepeatedCompositeFieldContainer[_timestamp_pb2.Timestamp]
    def __init__(self, generic_level_starts: _Optional[_Iterable[_Union[_timestamp_pb2.Timestamp, _Mapping]]] = ..., gas_level_starts: _Optional[_Iterable[_Union[_timestamp_pb2.Timestamp, _Mapping]]] = ...) -> None: ...
