from ....services import basic_types_pb2 as _basic_types_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class File(_message.Message):
    __slots__ = ("file_id", "expiration_second", "keys", "contents", "memo", "deleted", "pre_system_delete_expiration_second")
    FILE_ID_FIELD_NUMBER: _ClassVar[int]
    EXPIRATION_SECOND_FIELD_NUMBER: _ClassVar[int]
    KEYS_FIELD_NUMBER: _ClassVar[int]
    CONTENTS_FIELD_NUMBER: _ClassVar[int]
    MEMO_FIELD_NUMBER: _ClassVar[int]
    DELETED_FIELD_NUMBER: _ClassVar[int]
    PRE_SYSTEM_DELETE_EXPIRATION_SECOND_FIELD_NUMBER: _ClassVar[int]
    file_id: _basic_types_pb2.FileID
    expiration_second: int
    keys: _basic_types_pb2.KeyList
    contents: bytes
    memo: str
    deleted: bool
    pre_system_delete_expiration_second: int
    def __init__(self, file_id: _Optional[_Union[_basic_types_pb2.FileID, _Mapping]] = ..., expiration_second: _Optional[int] = ..., keys: _Optional[_Union[_basic_types_pb2.KeyList, _Mapping]] = ..., contents: _Optional[bytes] = ..., memo: _Optional[str] = ..., deleted: bool = ..., pre_system_delete_expiration_second: _Optional[int] = ...) -> None: ...
