from ....services import timestamp_pb2 as _timestamp_pb2
from ....services import basic_types_pb2 as _basic_types_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BlockStreamInfo(_message.Message):
    __slots__ = ("block_number", "block_time", "trailing_output_hashes", "trailing_block_hashes", "input_tree_root_hash", "start_of_block_state_hash", "num_preceding_state_changes_items", "rightmost_preceding_state_changes_tree_hashes", "block_end_time", "post_upgrade_work_done", "creation_software_version", "last_interval_process_time", "last_handle_time", "consensus_header_root_hash", "output_item_root_hash", "trace_data_root_hash", "intermediate_previous_block_root_hashes", "intermediate_block_roots_leaf_count")
    BLOCK_NUMBER_FIELD_NUMBER: _ClassVar[int]
    BLOCK_TIME_FIELD_NUMBER: _ClassVar[int]
    TRAILING_OUTPUT_HASHES_FIELD_NUMBER: _ClassVar[int]
    TRAILING_BLOCK_HASHES_FIELD_NUMBER: _ClassVar[int]
    INPUT_TREE_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    START_OF_BLOCK_STATE_HASH_FIELD_NUMBER: _ClassVar[int]
    NUM_PRECEDING_STATE_CHANGES_ITEMS_FIELD_NUMBER: _ClassVar[int]
    RIGHTMOST_PRECEDING_STATE_CHANGES_TREE_HASHES_FIELD_NUMBER: _ClassVar[int]
    BLOCK_END_TIME_FIELD_NUMBER: _ClassVar[int]
    POST_UPGRADE_WORK_DONE_FIELD_NUMBER: _ClassVar[int]
    CREATION_SOFTWARE_VERSION_FIELD_NUMBER: _ClassVar[int]
    LAST_INTERVAL_PROCESS_TIME_FIELD_NUMBER: _ClassVar[int]
    LAST_HANDLE_TIME_FIELD_NUMBER: _ClassVar[int]
    CONSENSUS_HEADER_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_ITEM_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    TRACE_DATA_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    INTERMEDIATE_PREVIOUS_BLOCK_ROOT_HASHES_FIELD_NUMBER: _ClassVar[int]
    INTERMEDIATE_BLOCK_ROOTS_LEAF_COUNT_FIELD_NUMBER: _ClassVar[int]
    block_number: int
    block_time: _timestamp_pb2.Timestamp
    trailing_output_hashes: bytes
    trailing_block_hashes: bytes
    input_tree_root_hash: bytes
    start_of_block_state_hash: bytes
    num_preceding_state_changes_items: int
    rightmost_preceding_state_changes_tree_hashes: _containers.RepeatedScalarFieldContainer[bytes]
    block_end_time: _timestamp_pb2.Timestamp
    post_upgrade_work_done: bool
    creation_software_version: _basic_types_pb2.SemanticVersion
    last_interval_process_time: _timestamp_pb2.Timestamp
    last_handle_time: _timestamp_pb2.Timestamp
    consensus_header_root_hash: bytes
    output_item_root_hash: bytes
    trace_data_root_hash: bytes
    intermediate_previous_block_root_hashes: _containers.RepeatedScalarFieldContainer[bytes]
    intermediate_block_roots_leaf_count: int
    def __init__(self, block_number: _Optional[int] = ..., block_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., trailing_output_hashes: _Optional[bytes] = ..., trailing_block_hashes: _Optional[bytes] = ..., input_tree_root_hash: _Optional[bytes] = ..., start_of_block_state_hash: _Optional[bytes] = ..., num_preceding_state_changes_items: _Optional[int] = ..., rightmost_preceding_state_changes_tree_hashes: _Optional[_Iterable[bytes]] = ..., block_end_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., post_upgrade_work_done: bool = ..., creation_software_version: _Optional[_Union[_basic_types_pb2.SemanticVersion, _Mapping]] = ..., last_interval_process_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., last_handle_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., consensus_header_root_hash: _Optional[bytes] = ..., output_item_root_hash: _Optional[bytes] = ..., trace_data_root_hash: _Optional[bytes] = ..., intermediate_previous_block_root_hashes: _Optional[_Iterable[bytes]] = ..., intermediate_block_roots_leaf_count: _Optional[int] = ...) -> None: ...
