from ....services import basic_types_pb2 as _basic_types_pb2
from ....services import custom_fees_pb2 as _custom_fees_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Topic(_message.Message):
    __slots__ = ("topic_id", "sequence_number", "expiration_second", "auto_renew_period", "auto_renew_account_id", "deleted", "running_hash", "memo", "admin_key", "submit_key", "fee_schedule_key", "fee_exempt_key_list", "custom_fees")
    TOPIC_ID_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    EXPIRATION_SECOND_FIELD_NUMBER: _ClassVar[int]
    AUTO_RENEW_PERIOD_FIELD_NUMBER: _ClassVar[int]
    AUTO_RENEW_ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    DELETED_FIELD_NUMBER: _ClassVar[int]
    RUNNING_HASH_FIELD_NUMBER: _ClassVar[int]
    MEMO_FIELD_NUMBER: _ClassVar[int]
    ADMIN_KEY_FIELD_NUMBER: _ClassVar[int]
    SUBMIT_KEY_FIELD_NUMBER: _ClassVar[int]
    FEE_SCHEDULE_KEY_FIELD_NUMBER: _ClassVar[int]
    FEE_EXEMPT_KEY_LIST_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_FEES_FIELD_NUMBER: _ClassVar[int]
    topic_id: _basic_types_pb2.TopicID
    sequence_number: int
    expiration_second: int
    auto_renew_period: int
    auto_renew_account_id: _basic_types_pb2.AccountID
    deleted: bool
    running_hash: bytes
    memo: str
    admin_key: _basic_types_pb2.Key
    submit_key: _basic_types_pb2.Key
    fee_schedule_key: _basic_types_pb2.Key
    fee_exempt_key_list: _containers.RepeatedCompositeFieldContainer[_basic_types_pb2.Key]
    custom_fees: _containers.RepeatedCompositeFieldContainer[_custom_fees_pb2.FixedCustomFee]
    def __init__(self, topic_id: _Optional[_Union[_basic_types_pb2.TopicID, _Mapping]] = ..., sequence_number: _Optional[int] = ..., expiration_second: _Optional[int] = ..., auto_renew_period: _Optional[int] = ..., auto_renew_account_id: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., deleted: bool = ..., running_hash: _Optional[bytes] = ..., memo: _Optional[str] = ..., admin_key: _Optional[_Union[_basic_types_pb2.Key, _Mapping]] = ..., submit_key: _Optional[_Union[_basic_types_pb2.Key, _Mapping]] = ..., fee_schedule_key: _Optional[_Union[_basic_types_pb2.Key, _Mapping]] = ..., fee_exempt_key_list: _Optional[_Iterable[_Union[_basic_types_pb2.Key, _Mapping]]] = ..., custom_fees: _Optional[_Iterable[_Union[_custom_fees_pb2.FixedCustomFee, _Mapping]]] = ...) -> None: ...
