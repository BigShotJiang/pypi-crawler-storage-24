from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class RunningHashes(_message.Message):
    __slots__ = ("running_hash", "n_minus_1_running_hash", "n_minus_2_running_hash", "n_minus_3_running_hash")
    RUNNING_HASH_FIELD_NUMBER: _ClassVar[int]
    N_MINUS_1_RUNNING_HASH_FIELD_NUMBER: _ClassVar[int]
    N_MINUS_2_RUNNING_HASH_FIELD_NUMBER: _ClassVar[int]
    N_MINUS_3_RUNNING_HASH_FIELD_NUMBER: _ClassVar[int]
    running_hash: bytes
    n_minus_1_running_hash: bytes
    n_minus_2_running_hash: bytes
    n_minus_3_running_hash: bytes
    def __init__(self, running_hash: _Optional[bytes] = ..., n_minus_1_running_hash: _Optional[bytes] = ..., n_minus_2_running_hash: _Optional[bytes] = ..., n_minus_3_running_hash: _Optional[bytes] = ...) -> None: ...
