from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LedgerId(_message.Message):
    __slots__ = ("ledger_id", "round", "ledger_signature", "roster_signatures")
    LEDGER_ID_FIELD_NUMBER: _ClassVar[int]
    ROUND_FIELD_NUMBER: _ClassVar[int]
    LEDGER_SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    ROSTER_SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    ledger_id: bytes
    round: int
    ledger_signature: bytes
    roster_signatures: RosterSignatures
    def __init__(self, ledger_id: _Optional[bytes] = ..., round: _Optional[int] = ..., ledger_signature: _Optional[bytes] = ..., roster_signatures: _Optional[_Union[RosterSignatures, _Mapping]] = ...) -> None: ...

class RosterSignatures(_message.Message):
    __slots__ = ("roster_hash", "node_signatures")
    ROSTER_HASH_FIELD_NUMBER: _ClassVar[int]
    NODE_SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    roster_hash: bytes
    node_signatures: _containers.RepeatedCompositeFieldContainer[NodeSignature]
    def __init__(self, roster_hash: _Optional[bytes] = ..., node_signatures: _Optional[_Iterable[_Union[NodeSignature, _Mapping]]] = ...) -> None: ...

class NodeSignature(_message.Message):
    __slots__ = ("node_id", "node_signature")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    NODE_SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    node_signature: bytes
    def __init__(self, node_id: _Optional[int] = ..., node_signature: _Optional[bytes] = ...) -> None: ...
