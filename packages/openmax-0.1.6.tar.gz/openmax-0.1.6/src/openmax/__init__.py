"""openMax - Multi AI Agent orchestration hub."""

__version__ = "0.1.6"
