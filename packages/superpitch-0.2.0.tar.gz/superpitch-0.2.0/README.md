# Superpitch

[![PyPI](https://img.shields.io/pypi/v/superpitch)](https://pypi.org/project/superpitch/)
[![Python](https://img.shields.io/pypi/pyversions/superpitch)](https://pypi.org/project/superpitch/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

An AI agent that screens your inbound pitch emails — automatically.

---

## The idea

Forward your pitch inbox to a private `@superpitch.dev` address. Every email that arrives gets classified, researched, and triaged by Claude. You open your terminal and see a ranked inbox: what to escalate, what to review, what to pass — with evidence to back each call.

When a pitch needs more information, the agent emails the founder directly with targeted follow-up questions. The founder replies, the agent reads the answer, and your evidence packet updates automatically. All before you've looked at it.

---

## Install

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
uv tool install superpitch
```

---

## How it works

1. **Sign in** — `superpitch`, then `/signin`. You get a private receive address like `a7f3k2@superpitch.dev`.
2. **Forward your pitch inbox** — set up a Gmail or Outlook rule to copy inbound pitch emails to that address.
3. **Add your Anthropic API key** — pitches are processed locally on your machine. Your key never leaves it.
4. **Set your thesis** — a short description of what you invest in. Used to score thesis fit on every pitch.
5. **Open `superpitch`** — your inbox, already ranked.

---

## What you see

```
  Superpitch  Logged in as you@email.com              2 min ago
  ──────────────────────────────────────────────────────────────

  Inbox
  ······························································
    DATE        COMPANY                  ACTION     CONF   STATUS
  ······························································

    2026-03-20  Mira Health              ESCALATE   91%       New
    2026-03-20  Stackwise                REVIEW     74%  Awaiting
    2026-03-19  LogiRoute                REVIEW     68%    Opened
    2026-03-18  Widget Co                PASS       31%  ✗ Rejected

  ──────────────────────────────────────────────────────────────
  ↑↓ move  ·  ↵ open  ·  a/r/v decide  ·  / commands  ·  q quit
```

Each pitch gets an **action** (ESCALATE / REVIEW / PASS), a **confidence score**, and a full evidence packet: company overview, founder background, traction, raise details, thesis fit, research findings, and the questions worth asking before a call.

**Awaiting** means the agent has already sent follow-up questions to the founder and is waiting for a reply.

---

## Agent-to-agent follow-up

When a pitch is promising but incomplete, the agent sends the founder a short list of targeted questions — automatically, with `Reply-To` pointed back at your receive address. When the founder replies, the agent reads the thread, updates the evidence packet, and you see a richer result. Capped at two rounds.

The goal: by the time you open a pitch, the obvious gaps are already filled.

---

## Processing pipeline

For each email, the agent:

1. **Classifies** with Claude Haiku — is this a pitch, noise, or uncertain?
2. **Extracts** with Claude Sonnet 4.6 — reads the email body and any attached PDFs using native vision, runs web search to research the company and founders, returns a structured evidence packet
3. **Triages** — ESCALATE, REVIEW, or PASS with confidence and reasoning
4. **Follows up** — if there are open questions and a founder email is available, sends them automatically

Everything runs locally. Your Anthropic API key is stored in `~/.superpitch/config.json` and used directly from your machine.

---

## One-off analysis

```bash
superpitch pitch.pdf
cat pitch.txt | superpitch -
```

Processes a file or stdin and prints the evidence packet immediately. Also saves to history.

---

## Commands

| Key / command | Action |
|---|---|
| `↑ ↓` | Move selection |
| `enter` | Open pitch |
| `a / r / v` | Approve / reject / flag for review |
| `u` | Import a file |
| `/import <file>` | Import a PDF or text file |
| `/sync` | Process new emails now |
| `/today` | Filter to today |
| `/all` | Show everything |
| `/thesis` | Update your investor thesis |
| `/profile` | Show profile and receive address |
| `/signin` | Sign in with Google |
| `/signout` | Sign out |
| `/subscription` | Manage billing |
| `/upgrade` | Upgrade via pipx |
| `q` | Quit |

---

## Local files

Everything lives in `~/.superpitch/`. Override with `SUPERPITCH_HOME`.

- `data/history.jsonl` — evidence packet history
- `config.json` — settings, API key, receive address
- `sync.log` — background sync errors

---

## Development

```bash
git clone https://github.com/eyoellundberg/superpitch
cd superpitch
pipx install -e .
```

Python package in `superpitch/`. Worker (Cloudflare) in the `superpitch.dev` repo.
