# Iris — local pitch triage specialist (fine-tuned Qwen3-1.7B)
