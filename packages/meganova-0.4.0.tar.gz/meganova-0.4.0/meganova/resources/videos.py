from typing import Any, Dict, List, Optional
from ..transport import SyncTransport
from ..models.videos import VideoGenerationResponse


class VideosResource:
    def __init__(self, transport: SyncTransport):
        self._transport = transport

    def generate(
        self,
        *,
        model_name: str,
        **kwargs: Any,
    ) -> VideoGenerationResponse:
        """Generate a video using a generative model.

        Args:
            model_name: The video generation model name.
            **kwargs: Model-specific parameters (prompt, duration, resolution, etc.).

        Returns:
            VideoGenerationResponse with generation status and data.
        """
        payload = {"model_name": model_name, **kwargs}
        data = self._transport.request("POST", "/videos/generation", json=payload)
        return VideoGenerationResponse(**data)

    def list_models(self) -> List[str]:
        """List supported video generation models.

        Returns:
            List of supported model names.
        """
        data = self._transport.request("GET", "/videos/models/supported_models")
        return data.get("data", [])
