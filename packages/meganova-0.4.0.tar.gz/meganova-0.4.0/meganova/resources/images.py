from typing import Optional
from ..transport import SyncTransport
from ..models.images import ImageGenerationResponse


class ImagesResource:
    def __init__(self, transport: SyncTransport):
        self._transport = transport

    def generate(
        self,
        prompt: str,
        *,
        model: str,
        width: int = 1280,
        height: int = 720,
        num_steps: Optional[int] = None,
        guidance_scale: float = 30,
        seed: Optional[int] = None,
        negative_prompt: Optional[str] = None,
        max_sequence_length: int = 256,
        image: Optional[str] = None,
        mask: Optional[str] = None,
    ) -> ImageGenerationResponse:
        """Generate an image from a text prompt.

        Args:
            prompt: Text description of the desired image.
            model: Image generation model name.
            width: Image width in pixels.
            height: Image height in pixels.
            num_steps: Number of diffusion steps (None uses model default).
            guidance_scale: Classifier-free guidance scale.
            seed: Random seed (None for random).
            negative_prompt: Text describing what to avoid in the image.
            max_sequence_length: Maximum sequence length for the prompt.
            image: Base64-encoded input image for image-to-image generation.
            mask: Base64-encoded mask image for inpainting.

        Returns:
            ImageGenerationResponse containing base64-encoded image(s).
        """
        payload = {
            "model": model,
            "prompt": prompt,
            "guidance_scale": guidance_scale,
            "width": width,
            "height": height,
            "max_sequence_length": max_sequence_length,
        }
        if num_steps is not None:
            payload["num_steps"] = num_steps
        if seed is not None:
            payload["seed"] = seed
        if negative_prompt is not None:
            payload["negative_prompt"] = negative_prompt
        if image is not None:
            payload["image"] = image
        if mask is not None:
            payload["mask"] = mask
        data = self._transport.request("POST", "/images/generation", json=payload)
        return ImageGenerationResponse(**data)
