from typing import List, Optional, Union
from ..transport import SyncTransport
from ..models.embeddings import EmbeddingResponse


class EmbeddingsResource:
    def __init__(self, transport: SyncTransport):
        self._transport = transport

    def create(
        self,
        input: Union[str, List[str]],
        *,
        model: str,
        encoding_format: Optional[str] = None,
    ) -> EmbeddingResponse:
        """Generate embeddings for text input.

        Args:
            input: Text string or list of strings to embed.
            model: Embedding model name.
            encoding_format: Optional format ("float" or "base64").

        Returns:
            EmbeddingResponse with embedding vectors.
        """
        payload = {"input": input, "model": model}
        if encoding_format is not None:
            payload["encoding_format"] = encoding_format
        data = self._transport.request("POST", "/embeddings", json=payload)
        return EmbeddingResponse(**data)
