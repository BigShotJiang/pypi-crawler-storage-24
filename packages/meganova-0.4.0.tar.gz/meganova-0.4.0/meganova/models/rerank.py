from pydantic import BaseModel
from typing import List, Optional


class RerankResult(BaseModel):
    index: int
    relevance_score: float
    document: Optional[str] = None

    model_config = {"extra": "ignore"}


class RerankResponse(BaseModel):
    results: List[RerankResult]
    model: Optional[str] = None

    model_config = {"extra": "ignore"}
