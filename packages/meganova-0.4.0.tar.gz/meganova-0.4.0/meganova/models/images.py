from pydantic import BaseModel
from typing import Any, Dict, List, Optional


class ImageTimings(BaseModel):
    inference: Optional[float] = None

    model_config = {"extra": "ignore"}


class GeneratedImage(BaseModel):
    b64_json: str
    revised_prompt: Optional[str] = None
    index: Optional[int] = None
    timings: Optional[ImageTimings] = None

    model_config = {"extra": "ignore"}


class ImageGenerationResponse(BaseModel):
    data: List[GeneratedImage]
    model: Optional[str] = None
    object: Optional[str] = None
    message: Optional[str] = None
    status: Optional[str] = None
