from pydantic import BaseModel
from typing import Any, Dict, List, Optional


class VideoGenerationResponse(BaseModel):
    status: str
    message: Optional[str] = None
    data: Optional[Any] = None

    model_config = {"extra": "ignore"}


class SupportedVideoModel(BaseModel):
    model_name: str

    model_config = {"extra": "ignore"}
