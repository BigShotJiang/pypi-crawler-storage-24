from pydantic import BaseModel
from typing import List, Optional


class EmbeddingData(BaseModel):
    object: str = "embedding"
    embedding: List[float]
    index: int = 0

    model_config = {"extra": "ignore"}


class EmbeddingUsage(BaseModel):
    prompt_tokens: int
    total_tokens: int

    model_config = {"extra": "ignore"}


class EmbeddingResponse(BaseModel):
    object: str = "list"
    data: List[EmbeddingData]
    model: str
    usage: Optional[EmbeddingUsage] = None

    model_config = {"extra": "ignore"}
