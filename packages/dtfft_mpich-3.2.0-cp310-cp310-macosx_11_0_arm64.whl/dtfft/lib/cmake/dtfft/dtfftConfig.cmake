
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was dtfftConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(DTFFT_WITH_CUDA OFF)
set(DTFFT_WITH_MOCK_ENABLED OFF)
set(DTFFT_WITH_C_CXX_API ON)
set(DTFFT_WITH_MPI_MODULE ON)
set(DTFFT_WITH_NCCL OFF)
set(DTFFT_WITH_NVSHMEM OFF)
set(DTFFT_WITH_OPENMP OFF)

include(CMakeFindDependencyMacro)

find_dependency(MPI 5.0 EXACT REQUIRED)
if ( DTFFT_WITH_CUDA AND NOT DTFFT_WITH_MOCK_ENABLED)
  find_dependency(CUDAToolkit  REQUIRED)
  if ( DTFFT_WITH_NVSHMEM )
    set(NVHPC_CUDA_VERSION )
    set(NVHPC_CMAKE_PATH )
    list(APPEND CMAKE_PREFIX_PATH "${NVHPC_CMAKE_PATH}")
    find_dependency(NVHPC REQUIRED)
  endif()
endif()
if ( DTFFT_WITH_OPENMP )
  find_dependency(OpenMP REQUIRED)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/dtfftTargets.cmake")
