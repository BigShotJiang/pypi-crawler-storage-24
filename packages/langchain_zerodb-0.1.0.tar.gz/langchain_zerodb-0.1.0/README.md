# langchain-zerodb

ZeroDB vector store integration for [LangChain](https://python.langchain.com/) - the AI-native vector database with **free embeddings** and sub-millisecond semantic search.

## Why ZeroDB?

- **Free embeddings** - BAAI/bge-small-en-v1.5 (384-dim) powered by TEI, no OpenAI costs
- **Sub-millisecond search** - pgvector with HNSW indexes
- **Zero infrastructure** - fully managed, no servers to run
- **Instant provisioning** - `POST /api/v1/instant-db` gets you a database in one request
- **Built for agents** - MCP server, memory API, event streams

## Installation

```bash
pip install langchain-zerodb
```

## Quick Start

```python
from langchain_zerodb import ZeroDBVectorStore

# Initialize (get your API key at ainative.studio)
vectorstore = ZeroDBVectorStore(
    api_key="your-api-key",
    project_id="your-project-id",
)

# Add documents
ids = vectorstore.add_texts(
    ["ZeroDB is fast", "Semantic search is powerful"],
    metadatas=[{"source": "docs"}, {"source": "blog"}],
)

# Similarity search
results = vectorstore.similarity_search("fast database", k=5)
for doc in results:
    print(doc.page_content, doc.metadata)

# Search with scores
scored = vectorstore.similarity_search_with_score("fast database", k=5)
for doc, score in scored:
    print(f"{score:.3f}: {doc.page_content}")
```

## Use with LangChain Chains

```python
from langchain_zerodb import ZeroDBVectorStore
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough

vectorstore = ZeroDBVectorStore(
    api_key="your-api-key",
    project_id="your-project-id",
)
retriever = vectorstore.as_retriever(search_kwargs={"k": 5})

# RAG chain
template = "Answer based on context:\n{context}\n\nQuestion: {question}"
prompt = ChatPromptTemplate.from_template(template)

chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | prompt
)
```

## Get a Free API Key

1. Sign up at [ainative.studio](https://www.ainative.studio/signup)
2. Create a ZeroDB project
3. Copy your API key

Or get an instant database with no signup:
```bash
curl -X POST https://api.ainative.studio/api/v1/public/instant-db
```

## Links

- [ZeroDB Product Page](https://www.ainative.studio/products/zerodb)
- [API Documentation](https://docs.ainative.studio)
- [GitHub](https://github.com/AINative-Studio)
- [Discord](https://discord.gg/paipalooza)
- [LlamaIndex Integration](https://pypi.org/project/llama-index-vector-stores-zerodb/)

## License

MIT - Built by [AINative Studio](https://www.ainative.studio)
