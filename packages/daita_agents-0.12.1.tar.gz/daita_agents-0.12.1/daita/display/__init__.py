"""Display utilities for Daita framework."""
