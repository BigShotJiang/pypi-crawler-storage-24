# Fathom MCP Server

An MCP server for the [Fathom AI](https://fathom.video) meeting intelligence API, built with [FastMCP](https://gofastmcp.com).

Responses are optimized for LLM consumption -- compact plaintext instead of raw JSON, with playback URLs stripped and transcripts chunked by time window.

## Tools

| Tool | Description |
|------|-------------|
| `list_meetings` | List meetings with filtering by date, team, domain, recorder, and pagination |
| `get_transcript` | Get transcript for a recording, with optional time-window chunking (`start_time`/`end_time`) |
| `get_summary` | Get the AI-generated summary for a recording (clean markdown, no playback URLs) |
| `list_teams` | List all teams |
| `list_team_members` | List team members, optionally filtered by team |

## Prerequisites

1. Install [uv](https://docs.astral.sh/uv/getting-started/installation/):

```bash
# macOS (recommended -- required for Claude Desktop compatibility)
brew install uv

# Linux / other
curl -LsSf https://astral.sh/uv/install.sh | sh
```

2. Get a Fathom API key: go to [Fathom Settings](https://fathom.video/customize) > **API Access** > **Add +** > **Generate API Key**.

## Quick Start

No cloning or installing required. Just add the server to your MCP client config.

### Claude Code

```bash
claude mcp add Fathom -e FATHOM_API_KEY=your-api-key -- uvx fathom-ai-mcp
```

### Cursor / Windsurf

Add to your MCP config file:

- **Cursor**: `.cursor/mcp.json` in your project root
- **Windsurf**: `~/.codeium/windsurf/mcp_config.json`

```json
{
  "mcpServers": {
    "Fathom": {
      "command": "uvx",
      "args": ["fathom-ai-mcp"],
      "env": {
        "FATHOM_API_KEY": "your-api-key"
      }
    }
  }
}
```

### Claude Desktop

Download the `.mcpb` file from the [latest release](https://github.com/jerichosequitin/fathom-ai-mcp/releases/latest) and open it -- Claude Desktop will install the server and prompt for your API key.

Alternatively, add to `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "Fathom": {
      "command": "uvx",
      "args": ["fathom-ai-mcp"],
      "env": {
        "FATHOM_API_KEY": "your-api-key"
      }
    }
  }
}
```

> **Note**: Claude Desktop requires `uvx` to be in a standard system path. On macOS, install uv via Homebrew (`brew install uv`) to ensure compatibility.

### Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `FATHOM_API_KEY` | Yes | - | Your Fathom API key |
| `FATHOM_TIMEOUT` | No | `30` | HTTP request timeout in seconds |

## Development

```bash
git clone https://github.com/jerichosequitin/fathom-ai-mcp.git
cd fathom-ai-mcp
uv sync
uv run server.py
```

## License

MIT
