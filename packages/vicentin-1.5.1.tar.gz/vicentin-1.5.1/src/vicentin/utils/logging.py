import logging
import threading
from contextlib import contextmanager

_depth_context = threading.local()


def get_depth():
    return getattr(_depth_context, "depth", 0)


def increment_depth():
    _depth_context.depth = get_depth() + 1


def decrement_depth():
    _depth_context.depth = max(0, get_depth() - 1)


@contextmanager
def log_scope(name=None):
    """Context manager to handle indentation and entry/exit logs."""
    if name:
        info(f"==> {name}")

    increment_depth()
    try:
        yield
    finally:
        decrement_depth()


logger = logging.getLogger("vicentin")
logger.addHandler(logging.NullHandler())


def log(msg, level=logging.INFO):
    """Logs a message with the correct indentation based on recursion depth."""
    indent = "  " * get_depth()
    logger.log(level, f"{indent}{msg}")


def debug(msg):
    log(msg, logging.DEBUG)


def info(msg):
    log(msg, logging.INFO)


def warn(msg):
    log(msg, logging.WARNING)


def error(msg):
    log(msg, logging.ERROR)


# --- Colorful Formatter ---


class Formatter(logging.Formatter):
    """Custom formatter providing colors, bold text, and hierarchical symbols."""

    # ANSI Escape Codes
    GREY = "\x1b[38;20m"
    CYAN = "\x1b[36;20m"
    YELLOW = "\x1b[33;20m"
    RED = "\x1b[31;20m"
    BOLD_CYAN = "\x1b[1;36m"
    RESET = "\x1b[0m"

    # Map levels to colors and optional status symbols
    FORMATS = {
        logging.DEBUG: GREY + "%(message)s" + RESET,
        logging.INFO: CYAN + "%(message)s" + RESET,
        logging.WARNING: YELLOW + "● %(message)s" + RESET,
        logging.ERROR: RED + "✖ %(message)s" + RESET,
    }

    def format(self, record):
        # Apply bolding specifically to the "Dispatch" entries
        if "==>" in record.msg:
            record.msg = f"{self.BOLD_CYAN}{record.msg}{self.RESET}"

        log_fmt = self.FORMATS.get(record.levelno, self.RESET + "%(message)s")
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


def setup_logging(level=logging.INFO):
    """
    Configures the library-wide logger with the colorful Formatter.
    Usage: vicentin.utils.logging.setup_logging(level=logging.DEBUG)
    """
    handler = logging.StreamHandler()
    handler.setFormatter(Formatter())

    # Clear existing handlers to avoid duplicate logs if called twice
    if logger.hasHandlers():
        logger.handlers.clear()

    logger.addHandler(handler)
    logger.setLevel(level)
