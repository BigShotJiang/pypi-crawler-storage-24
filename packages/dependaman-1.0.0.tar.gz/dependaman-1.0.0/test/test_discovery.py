from pathlib import PosixPath

from dependaman import discovery


def test_discover(tmp_path):
    """Testing file discovery with"""
    # Files that we should find
    # main dir
    (tmp_path / "testing_project").mkdir()
    (tmp_path / "testing_project/__init__.py").touch()
    (tmp_path / "testing_project/project.py").touch()
    # nested package
    (tmp_path / "testing_project/nested_package").mkdir()
    (tmp_path / "testing_project/nested_package/__init__.py").touch()
    (tmp_path / "testing_project/nested_package/nested_project.py").touch()

    # Files that we should ignore
    (tmp_path / ".venv").mkdir()
    (tmp_path / ".venv/file_inside_ignored.py").touch()
    (tmp_path / ".venv/another_file_inside_ignored.py").touch()

    result: list[discovery.Package] = discovery.discover(tmp_path)
    assert len(result) == 2

    testing_packages = [package.name for package in result]
    assert (
        "testing_project" in testing_packages
        and "testing_project.nested_package" in testing_packages
    )

    testing_modules = []
    for package in result:
        testing_modules.extend(package.modules)
    assert (
        discovery.Module("project", PosixPath("testing_project/project.py")) in testing_modules
        and discovery.Module("nested_project", PosixPath("testing_project/nested_package/nested_project.py")) in testing_modules
    )
