"""git.py"""

import subprocess
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TypedDict

from .discovery import Module, Package, node_name_gen


def check_git_project() -> bool:
    """Checks if we are in a directory with git."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip() == "true"
    except subprocess.CalledProcessError:
        return False


# TODO: the main issue is that we are doing a subprocess call per each file
# that is in the project. Because we are waiting for IO, we could throw all of
# this to a threadpool or a coroutine to make all of this in parallel, as doing
# the complete `git log` would require a full parse change and we would also
# need a way to get the last person that worked on that node, which would
# complicate the process greatly.


class GitStats(TypedDict):
    node: str
    n_commits: int
    added_lines: int
    removed_lines: int
    last_author: str


def _get_git_stats(
    node: str,
    module: Module,
) -> GitStats:
    """returns the git stats for each module, which compose for our case,
    number of commits, added lines, removed lines, last author that touched
    that module.
    """
    git_freq = subprocess.run(
        [
            "git",
            "log",
            "--numstat",
            "--pretty=format:",
            "--",
            f"{module.path}",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    raw_commits = git_freq.stdout.strip().split()
    # here we are taking the first two values of the iteration even
    # thought we are jumping them in range of 3
    commits = [raw_commits[i : i + 2] for i in range(0, len(raw_commits), 3)]
    added_lines = sum([int(commit[0]) for commit in commits])
    removed_lines = sum([int(commit[1]) for commit in commits])
    n_commits = len(commits)
    git_last_author = subprocess.run(
        [
            "git",
            "log",
            "-1",
            "--pretty=format:%ae",
            "--",
            f"{module.path}",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    git_stats = GitStats(
        node=node,
        n_commits=n_commits,
        added_lines=added_lines,
        removed_lines=removed_lines,
        last_author=git_last_author.stdout.strip(),
    )
    return git_stats


def git_commit_freq(
    file_source: list[Package],
    project_nodes: set[str],
) -> defaultdict[str, dict[str, int | str]]:
    """Checks the amount of commits that each node has."""
    if not check_git_project():
        return defaultdict(dict)

    freq = defaultdict(dict)

    # DROWN ME IN A POOL BROTHER!!!!!!!
    with ThreadPoolExecutor() as pool:
        futures = []
        for package in file_source:
            for module in package.modules:
                node: str = node_name_gen(module)

                if node not in project_nodes:
                    continue

                # send me to hell
                futures.append(pool.submit(_get_git_stats, node, module))

        # the party is over, pick me up when you are done
        for future in as_completed(futures):
            results: GitStats = future.result()
            r_node = results.pop("node")
            freq[r_node] = results
    return freq
