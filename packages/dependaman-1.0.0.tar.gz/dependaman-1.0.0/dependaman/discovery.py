"""discovery.py"""

from dataclasses import dataclass
from pathlib import Path

EXCLUDED_DIRS: tuple = (
    ".venv",
    "__pycache__",
    ".git",
    "build",
    "dist",
    ".eggs",
)

PROJECT_MARKERS = (
    "pyproject.toml",
    "setup.py",
    "requirements.txt",
    "setup.cfg",
)


def find_project_root(start: Path) -> Path:
    """We walk up the directory from start and try to find any of the files
    that are in the PROJECT_MARKERS. When we find one, we found the origin
    folder of the project.
    """
    for parent in [start, *start.parents]:
        if any((parent / marker).exists() for marker in PROJECT_MARKERS):
            return parent
    return start


@dataclass(slots=True)
class Module:
    name: str
    path: Path


@dataclass(slots=True)
class Package:
    name: str
    modules: list[Module]


def discover(root: str | Path) -> list[Package]:
    """Walking throught the root directory matching all the *.py files and
    removing all the files that may be in the excluded directories defined at
    the package level.
    """
    root = Path(root).resolve()

    packages: list[Package] = []

    # Collecting root-level standalone scripts if there is not an init file in
    # the root folder
    if not (root / "__init__.py").exists():
        root_modules: list[Module] = []
        for file in root.iterdir():
            if file.suffix == ".py" and file.name != "__init__.py":
                root_modules.append(Module(file.stem, file.relative_to(root)))

        if root_modules:
            packages.append(Package(".", root_modules))

    for path in root.rglob("__init__.py"):
        # skipping the folders that are in the excluded directoreis list.
        if any(part in EXCLUDED_DIRS for part in path.parts):
            continue

        package_dir: Path = path.parent
        relative_path: Path = package_dir.relative_to(root)
        package_name = ".".join(relative_path.parts)

        # Iterating over the contents of each of the found directories.
        modules: list[Module] = []
        for file in package_dir.iterdir():
            if file.suffix == ".py" and file.name != "__init__.py":
                modules.append(Module(file.stem, file.relative_to(root)))

        packages.append(Package(package_name, modules))

    return packages


def node_name_gen(
    module: Module,
) -> str:
    """Creates the node string of a module."""
    node: list[str] = list(module.path.parts)
    node.pop(-1)
    node.append(module.name)
    return ".".join(node)


def module_level_node_generator(packages: list[Package]) -> set[str]:
    """Creating the set of nodes that we will use to filter out the internal
    packages.
    """
    module_level_nodes = set()
    for package in packages:
        module_level_nodes.add(package.name)
        for module in package.modules:
            module_level_nodes.add(node_name_gen(module))
    return module_level_nodes
