"""graph.py"""

from collections import defaultdict
from concurrent.futures import Future, as_completed

from .discovery import Module, Package, node_name_gen
from .parser import parse
from .pool import MIN_FILES_FOR_POOL, executor


def _parse_module_edges(
    module: Module, project_nodes: set[str]
) -> tuple[str, set[str]]:
    """module edges creator."""
    return node_name_gen(module), {e for e in parse(module) if e in project_nodes}


# NOTE: DROWN ME BABY!!!, another pool optimization.
def speed_grapher(
    file_source: list[Package],
    project_nodes: set[str],
) -> dict[str, set]:
    """Given the file source we create the directed graph of dependencies for
    each one of the nodes.
    """

    # creating a default dict that creates an empty set on missing keys.
    directed_graph = defaultdict(set)

    modules: list[Module] = [
        module for package in file_source for module in package.modules
    ]

    # looking at the pool from afar
    if len(modules) < MIN_FILES_FOR_POOL:
        for module in modules:
            node, edge = _parse_module_edges(module, project_nodes)
            directed_graph[node] = edge
        return directed_graph

    # drowned!!
    with executor() as pool:
        futures: list[Future[tuple[str, set[str]]]] = [
            pool.submit(_parse_module_edges, module, project_nodes)
            for module in modules
        ]

        for future in as_completed(futures):
            node, edge = future.result()
            directed_graph[node] = edge
    return directed_graph
