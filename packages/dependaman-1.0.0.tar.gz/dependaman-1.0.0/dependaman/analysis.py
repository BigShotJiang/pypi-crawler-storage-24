"""analysis.py"""

from .discovery import Module
from .parser import definition_collector


def fanin_analyzer(
    project_nodes: set[str],
    graph: dict[str, set[str]],
) -> dict[str, int]:
    """Checks how many times each module is being imported."""
    fanin = dict.fromkeys(project_nodes, 0)
    for _, value in graph.items():
        for edge in value:
            fanin[edge] += 1
    return fanin


def fanout_analyzer(graph: dict[str, set[str]]) -> dict[str, int]:
    """Checks how many imports each module has."""
    fanout = dict.fromkeys(graph.keys(), 0)
    for key, value in graph.items():
        fanout[key] += len(value)
    return fanout


def _dfs(
    key: str,
    graph: dict[str, set[str]],
    current_path: list[str],
    visited_nodes: set[str],
) -> list[str] | None:
    """Walking the directed graph of dependencies."""
    dfs = []
    current_path.append(key)

    for neighbor in graph[key]:
        if neighbor in current_path:
            dfs = current_path[current_path.index(neighbor) :].copy()
            dfs.append(neighbor)
            break
        if neighbor not in visited_nodes and neighbor in graph:
            dfs = _dfs(neighbor, graph, current_path, visited_nodes)
            if dfs:
                break
    current_path.pop(current_path.index(key))
    visited_nodes.add(key)
    return dfs


def circular_imports(graph: dict[str, set[str]]) -> list[list[str]]:
    """Checks if there are any circular imports that we should worry about."""
    visited_nodes = set()
    circular_imports = []
    for key in graph.keys():
        current_path = []
        if key in visited_nodes:
            continue
        eval = _dfs(key, graph, current_path, visited_nodes)
        if eval:
            circular_imports.append(eval)
    return circular_imports


def symbols_to_review_detector(
    module: Module, project_import_strings: set[str]
) -> set[str]:
    """we get all the import strings that are in the project and match them
    with all the function and class definitions that are in a module, we return
    the defined functions/classes in the module that are not imported anywhere.
    """
    definitions: set[str] = set()
    definitions.update(definition_collector(module))
    symbols_to_review: set[str] = definitions - project_import_strings
    return symbols_to_review
