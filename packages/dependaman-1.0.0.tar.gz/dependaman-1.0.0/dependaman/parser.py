"""parser.py"""

import ast
from concurrent.futures import Future, as_completed
from dataclasses import dataclass

from .discovery import Module, Package, node_name_gen
from .pool import MIN_FILES_FOR_POOL, executor


@dataclass(slots=True)
class DpdmanImport:
    module: str | None
    names: list[str]
    level: int


def node_generator(
    module: Module,
    dpdman_import: DpdmanImport,
) -> set[str]:
    """With the DpdmanImport corresponding to a module, we can create the
    import string nodes corresponding to it.
    """
    import_strings: set[str] = set()
    parents = []
    if dpdman_import.level != 0:
        module_path = list(module.path.parts)
        module_path.pop(-1)
        n = len(module_path)
        parents = module_path[: (n - (dpdman_import.level - 1))]
    if dpdman_import.module:
        parents.append(dpdman_import.module)
    import_str = ".".join(parents)

    # NOTE: Because we are in the module level, we are taking the functions and
    # classes too, which is good for the future. So for now, we will add also
    # the initial parents concatenation to the list, as we cannot differenciate
    # sym names from modules.
    # if not dpdman_import.names:
    #     import_strings.append(import_str)
    #     return import_strings
    import_strings.add(import_str)

    for name in dpdman_import.names:
        import_strings.add(f"{import_str}.{name}")
    return import_strings


def parse(module: Module) -> set[str]:
    """Analizes the imports a Module and returns its corresponding list of
    import string nodes.
    """
    text_source = module.path.read_text(encoding="utf-8")
    tree = ast.parse(text_source)

    # Creating DpdmanImport
    import_strings: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for imported_package in node.names:
                dpdman_import = DpdmanImport(
                    module=imported_package.name,
                    names=[],
                    level=0,
                )
                import_strings.update(node_generator(module, dpdman_import))
        elif isinstance(node, ast.ImportFrom):
            dpdman_import = DpdmanImport(
                module=node.module,
                names=[alias.name for alias in node.names],
                level=node.level,
            )
            import_strings.update(node_generator(module, dpdman_import))
    return import_strings


# NOTE: The project needs to be large for this optimization to take place, else
# the memory of creating a new process/thread pool and their shutting down will
# take away the gains.
def project_import_strings(file_source: list[Package]) -> set[str]:
    """Returns all the import nodes of the project."""
    project_imports = set()

    modules: list[Module] = [
        module for package in file_source for module in package.modules
    ]

    # Be vigilant of how many files are the ones needed for the sweet spot.
    if len(modules) < MIN_FILES_FOR_POOL:
        for module in modules:
            project_imports.update(parse(module))
        return project_imports

    with executor() as pool:
        futures: list[Future[set[str]]] = [
            pool.submit(parse, module) for module in modules
        ]
        for future in as_completed(futures):
            project_imports.update(future.result())
    return project_imports


def definition_collector(module: Module) -> set[str]:
    """Getting all the functions and class definitions that are in each of the
    modules.
    """
    text_source = module.path.read_text(encoding="utf-8")
    tree = ast.parse(text_source)

    # Creating the functions and classes definitions
    definitions: set[str] = set()

    # creating the node string
    module_name = node_name_gen(module)
    # we will only walk the top level nodes, not all the code.
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef, ast.ClassDef)):
            definition = f"{module_name}.{node.name}"
            definitions.add(definition)
    return definitions
