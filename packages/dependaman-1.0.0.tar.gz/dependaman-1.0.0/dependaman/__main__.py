"""__main__.py

Orchestator. Here is where everything takes shape. In dependaman we build all
tools that are needed to make the code analysis, here we put them together so
with a simple command/function call we can execute the project analysis.
"""

import sys
from pathlib import Path

from .core import dependaman
from .discovery import find_project_root

if __name__ == "__main__":
    path: Path = (
        Path(sys.argv[1]).resolve()
        if len(sys.argv) > 1
        else find_project_root(Path.cwd())
    )
    dependaman(path)
