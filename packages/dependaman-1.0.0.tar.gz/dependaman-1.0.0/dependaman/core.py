"""core.py

Orchestator. Here is where everything takes shape. In dependaman we build all
tools that are needed to make the code analysis, here we put them together so
with a simple command/function call we can execute the project analysis.
"""

import webbrowser
from pathlib import Path

from .analysis import (
    circular_imports,
    fanin_analyzer,
    fanout_analyzer,
)
from .discovery import discover, module_level_node_generator
from .git import git_commit_freq
from .graph import speed_grapher
from .parser import project_import_strings
from .renderer import data_constructor, render


def dependaman(path=".", in_memory=False) -> str | None:
    """Given the path of the project found, the folder structure and nodes of
    the project are generated. Then the different files are being parsed and
    from them we get the import nodes of each one of them. After both nodes are
    created, we match an see for each module, which other modules are imported
    to them.

    With that information we can analyze which modules are the ones that import
    the most, which are the ones that are imported the most and if there are
    circular imports detect them.
    """

    file_source = discover(path)
    project_nodes: set[str] = module_level_node_generator(file_source)
    project_imports: set[str] = project_import_strings(file_source)
    directed_graph = speed_grapher(file_source, project_nodes)
    fanin_analysis = fanin_analyzer(project_nodes, directed_graph)
    fanout_analysis = fanout_analyzer(directed_graph)
    circular_imports_analysis = circular_imports(directed_graph)
    git_freq = git_commit_freq(file_source, project_nodes)

    data = data_constructor(
        file_source,
        project_nodes,
        directed_graph,
        circular_imports_analysis,
        fanin_analysis,
        fanout_analysis,
        git_freq,
        project_imports,
    )

    rendered_data: str = render(data)

    if in_memory:
        return rendered_data

    with open("output.html", "w") as f:
        f.write(rendered_data)
    webbrowser.open(f"file://{Path('output.html').resolve()}")
