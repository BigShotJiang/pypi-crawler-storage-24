from .core import dependaman

__all__: list[str] = ["dependaman"]
