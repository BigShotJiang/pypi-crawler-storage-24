"""renderer.py"""

import json
from pathlib import Path

from .analysis import symbols_to_review_detector
from .discovery import Package, node_name_gen

CURRENT_FOLDER_LOCATION: Path = Path(__file__).parent


def data_constructor(
    file_source: list[Package],
    project_nodes: set[str],
    directed_graph: dict[str, set],
    cycles: list[list[str]],
    fanin: dict[str, int],
    fanout: dict[str, int],
    git_frequency: dict[str, dict[str, int | str]],
    project_imports: set[str],
) -> dict:
    """Returns the nodes with all the information"""

    data: dict = {}

    data["packages"] = []
    data["cycles"] = cycles

    for package in file_source:
        package_info = {"id": package.name, "modules": []}
        for module in package.modules:
            node: str = node_name_gen(module)

            if node not in project_nodes:
                continue

            git_info = git_frequency.get(node, {})
            package_info["modules"].append(
                {
                    "id": node,
                    "edges": list(directed_graph.get(node, set())),
                    "fan_in": fanin.get(node, 0),
                    "fan_out": fanout.get(node, 0),
                    "n_commits": git_info.get("n_commits", 0),
                    "added_lines": git_info.get("added_lines", 0),
                    "removed_lines": git_info.get("removed_lines", 0),
                    "last_author": git_info.get("last_author", ""),
                    "symbols_to_review": list(
                        symbols_to_review_detector(module, project_imports)
                    ),
                }
            )
        data["packages"].append(package_info)

    return data


def render(data: dict) -> str:
    """Creates a HTML string"""
    json_data: str = json.dumps(data)
    html_path = f"{CURRENT_FOLDER_LOCATION}/dependaman_template.html"
    js_path = f"{CURRENT_FOLDER_LOCATION}/dependaman_graph.js"
    with open(html_path) as html:
        with open(js_path) as js:
            js_data = js.read()
            html_data = html.read()
            html_data = html_data.replace("__GRAPH_DATA__", json_data)
            html_data = html_data.replace("__GRAPH_JS__", f"<script>{js_data}</script>")
            return html_data
