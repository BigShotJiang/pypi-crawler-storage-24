import os
from collections.abc import Generator
from unittest.mock import Mock, patch
from uuid import UUID, uuid4

import pytest
from sqlalchemy import text

import horizon_data_core.api as api_module
from horizon_data_core.api import (
    create_beamgram_specification, create_bearing_time_record_specification,
    create_data_rows, create_data_stream, create_mission,
    create_mission_platform, create_platform,
    create_platform_beamgram_specification,
    create_platform_bearing_time_record_specification,
    create_platform_information, create_platform_information_batch,
    delete_mission,
    delete_mission_platform, delete_platform, get_horizon_sdk, initialize_sdk,
    list_data_streams, list_mission_platforms, list_missions,
    list_platform_information, list_platforms,
    read_data_stream, read_mission, read_mission_platform, read_platform,
    update_data_stream, update_mission, update_mission_platform,
    update_platform, upsert_platform)
from horizon_data_core.base_types import (BeamgramSpecification,
                                          BearingTimeRecordSpecification,
                                          Platform)
from horizon_data_core.client import PostgresClient
from horizon_data_core.sdk import HorizonSDK


@pytest.fixture(autouse=True)
def reset_sdk() -> Generator[None, None, None]:
    """Reset the global SDK before and after each test."""
    # Reset before test
    api_module._sdk = None
    yield
    # Reset after test
    api_module._sdk = None


@pytest.fixture
def initialized_sdk() -> HorizonSDK:
    """Fixture to initialize SDK with database connection for tests that need it."""
    initialize_sdk(
        client=PostgresClient(
            user=os.environ.get("OWNER_PGUSER", "postgres"),
            password=os.environ.get("OWNER_PGPASSWORD", "password"),
            host=os.environ.get("PGHOST", "localhost"),
            port=int(os.environ.get("PGPORT", 5432)),
            database=os.environ.get("PGDATABASE", "horizon"),
            sslmode="disable",
            channel_binding="prefer",
        ),
        catalog_properties={
            "uri": "http://localhost:8181",
            "warehouse": "file://./iceberg/warehouse",
        },
        organization_id=None,
    )
    return get_horizon_sdk()


@pytest.fixture
def platform_kind_id(initialized_sdk: HorizonSDK) -> UUID:
    """Fixture to create a platform kind for use in platform tests."""
    kind_id = uuid4()
    with initialized_sdk.postgres_client.session() as session:
        session.execute(
            text("INSERT INTO horizon_public.platform_kind (id, name) VALUES (:id, :name)"),
            {"id": kind_id, "name": "Test Platform Kind"}
        )
        session.commit()
    return kind_id


def test_initialize_sdk() -> None:
    """Test that the SDK can be initialized."""
    with pytest.raises(RuntimeError):
        get_horizon_sdk()
    sdk = initialize_sdk(
        client=PostgresClient(
            # Because this is a lazy connection we don't need to use real values.
            user="postgres",
            password="password",
            host="localhost",
            port=5432,
            database="horizon",
        ),
        catalog_properties={
            "uri": "http://localhost:8181",
            "warehouse": "file://./iceberg/warehouse",
        },
        organization_id=None,
    )
    assert sdk is not None
    sdk = get_horizon_sdk()
    assert sdk is not None


def test_create_platform_beamgram_specification(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that the platform beamgram specification can be created."""
    # Create a beamgram specification
    beamgram_spec = create_beamgram_specification(BeamgramSpecification(id=uuid4()))
    beamgram_id = beamgram_spec.id
    assert beamgram_id is not None

    # Create a platform with the valid kind_id
    platform = create_platform(Platform(id=uuid4(), kind_id=platform_kind_id, name="Test Platform"))
    platform_id = platform.id
    assert platform_id is not None

    spec = create_platform_beamgram_specification(platform_id, beamgram_id)
    assert spec is not None
    assert spec.platform_id == platform_id
    assert spec.beamgram_specification_id == beamgram_id


def test_create_platform_bearing_time_record_specification(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that the platform bearing time record specification can be created."""
    # Create a bearing time record specification
    btr_spec = create_bearing_time_record_specification(BearingTimeRecordSpecification(id=uuid4()))
    btr_id = btr_spec.id
    assert btr_id is not None

    # Create a platform with the valid kind_id
    platform = create_platform(Platform(id=uuid4(), kind_id=platform_kind_id, name="Test Platform"))
    platform_id = platform.id
    assert platform_id is not None

    spec = create_platform_bearing_time_record_specification(platform_id, btr_id)
    assert spec is not None
    assert spec.platform_id == platform_id
    assert spec.bearing_time_record_specification_id == btr_id


# Platform CRUD Tests

def test_create_platform(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API create_platform calls the SDK create_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_platform = Mock()  # type: ignore[method-assign]
        create_platform(Platform(id=uuid4(), kind_id=platform_kind_id, name="Test Platform"))
        initialized_sdk.create_platform.assert_called_once()


def test_read_platform(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_platform calls the SDK read_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_platform = Mock()  # type: ignore[method-assign]
        read_platform(uuid4())
        initialized_sdk.read_platform.assert_called_once()


def test_read_platform_not_found(initialized_sdk: HorizonSDK) -> None:
    """Test that reading a non-existent platform returns None."""
    non_existent_id = uuid4()
    result = read_platform(non_existent_id)
    assert result is None


def test_update_platform(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API update_platform calls the SDK update_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_platform = Mock()  # type: ignore[method-assign]
        update_platform(Platform(id=uuid4(), kind_id=platform_kind_id, name="Test"))
        initialized_sdk.update_platform.assert_called_once()


def test_update_platform_not_found(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that updating a non-existent platform raises ValueError."""
    non_existent_platform = Platform(
        id=uuid4(),
        kind_id=platform_kind_id,
        name="Non-existent",
    )
    with pytest.raises(ValueError):
        update_platform(non_existent_platform)


def test_delete_platform(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API delete_platform calls the SDK delete_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_platform = Mock()  # type: ignore[method-assign]
        delete_platform(uuid4())
        initialized_sdk.delete_platform.assert_called_once()


def test_delete_platform_not_found(initialized_sdk: HorizonSDK) -> None:
    """Test that deleting a non-existent platform returns False."""
    non_existent_id = uuid4()
    result = delete_platform(non_existent_id)
    assert result is False


def test_list_platforms(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API list_platforms calls the SDK list_platforms method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_platforms = Mock()  # type: ignore[method-assign]
        list_platforms()
        initialized_sdk.list_platforms.assert_called_once()


def test_list_platforms_with_filters(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API list_platforms calls the SDK list_platforms method with filters."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_platforms = Mock()  # type: ignore[method-assign]
        list_platforms(name="Filtered Platform")
        initialized_sdk.list_platforms.assert_called_once_with(name="Filtered Platform")


def test_upsert_platform_create(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API upsert_platform calls the SDK create_or_update_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_or_update_platform = Mock()  # type: ignore[method-assign]
        upsert_platform(Platform(id=uuid4(), kind_id=platform_kind_id, name="Upserted Platform"))
        initialized_sdk.create_or_update_platform.assert_called_once()


def test_upsert_platform_update(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API upsert_platform calls the SDK create_or_update_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_or_update_platform = Mock()  # type: ignore[method-assign]
        upsert_platform(Platform(id=uuid4(), kind_id=platform_kind_id, name="Upserted Name"))
        initialized_sdk.create_or_update_platform.assert_called_once()


def test_platform_operations_without_sdk() -> None:
    """Test that platform operations raise RuntimeError when SDK is not initialized."""
    platform_id = uuid4()
    platform = Platform(id=platform_id, kind_id=uuid4(), name="Test")

    with pytest.raises(RuntimeError):
        read_platform(platform_id)

    with pytest.raises(RuntimeError):
        update_platform(platform)

    with pytest.raises(RuntimeError):
        delete_platform(platform_id)

    with pytest.raises(RuntimeError):
        list_platforms()

    with pytest.raises(RuntimeError):
        upsert_platform(platform)


def test_create_data_rows(initialized_sdk: HorizonSDK, platform_kind_id: UUID) -> None:
    """Test that API create_data_rows calls the SDK create_data_row_batch method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_data_row_batch = Mock()  # type: ignore[method-assign]
        create_data_rows([Mock()])
        initialized_sdk.create_data_row_batch.assert_called_once()

def test_create_data_stream(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_data_stream calls the SDK create_data_stream method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_data_stream = Mock()  # type: ignore[method-assign]
        mock_platform = Mock()
        mock_platform.id = uuid4()
        create_data_stream(mock_platform, "test_data_stream")
        initialized_sdk.create_data_stream.assert_called_once()

def test_read_data_stream(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_data_stream calls the SDK read_data_stream method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_data_stream = Mock()  # type: ignore[method-assign]
        read_data_stream(uuid4())
        initialized_sdk.read_data_stream.assert_called_once()

def test_update_data_stream(initialized_sdk: HorizonSDK) -> None:
    """Test that API update_data_stream calls the SDK update_data_stream method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_data_stream = Mock()  # type: ignore[method-assign]
        update_data_stream(Mock())
        initialized_sdk.update_data_stream.assert_called_once()

def test_list_data_streams(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_data_streams calls the SDK list_data_streams method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_data_streams = Mock()  # type: ignore[method-assign]
        list_data_streams()
        initialized_sdk.list_data_streams.assert_called_once()

def test_create_mission(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_mission calls the SDK create_mission method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_mission = Mock()  # type: ignore[method-assign]
        create_mission(Mock())
        initialized_sdk.create_mission.assert_called_once()

def test_read_mission(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_mission calls the SDK read_mission method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_mission = Mock()  # type: ignore[method-assign]
        read_mission(uuid4())
        initialized_sdk.read_mission.assert_called_once()

def test_update_mission(initialized_sdk: HorizonSDK) -> None:
    """Test that API update_mission calls the SDK update_mission method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_mission = Mock()  # type: ignore[method-assign]
        update_mission(Mock())
        initialized_sdk.update_mission.assert_called_once()

def test_delete_mission(initialized_sdk: HorizonSDK) -> None:
    """Test that API delete_mission calls the SDK delete_mission method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_mission = Mock()  # type: ignore[method-assign]
        delete_mission(uuid4())
        initialized_sdk.delete_mission.assert_called_once()

def test_list_missions(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_missions calls the SDK list_missions method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_missions = Mock()  # type: ignore[method-assign]
        list_missions()
        initialized_sdk.list_missions.assert_called_once()

def test_create_mission_platform(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_mission_platform calls the SDK create_mission_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_mission_platform = Mock()  # type: ignore[method-assign]
        create_mission_platform(Mock())
        initialized_sdk.create_mission_platform.assert_called_once()

def test_read_mission_platform(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_mission_platform calls the SDK read_mission_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_mission_platform = Mock()  # type: ignore[method-assign]
        read_mission_platform(uuid4())
        initialized_sdk.read_mission_platform.assert_called_once()

def test_update_mission_platform(initialized_sdk: HorizonSDK) -> None:
    """Test that API update_mission_platform calls the SDK update_mission_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_mission_platform = Mock()  # type: ignore[method-assign]
        update_mission_platform(Mock())
        initialized_sdk.update_mission_platform.assert_called_once()

def test_delete_mission_platform(initialized_sdk: HorizonSDK) -> None:
    """Test that API delete_mission_platform calls the SDK delete_mission_platform method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_mission_platform = Mock()  # type: ignore[method-assign]
        delete_mission_platform(uuid4())
        initialized_sdk.delete_mission_platform.assert_called_once()

def test_list_mission_platforms(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_mission_platforms calls the SDK list_mission_platforms method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_mission_platforms = Mock()  # type: ignore[method-assign]
        list_mission_platforms()
        initialized_sdk.list_mission_platforms.assert_called_once()


# DataStream delete test
def test_delete_data_stream(initialized_sdk: HorizonSDK) -> None:
    """Test that API delete_data_stream calls the SDK delete_data_stream method."""
    from horizon_data_core.api import delete_data_stream

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_data_stream = Mock()  # type: ignore[method-assign]
        delete_data_stream(uuid4())
        initialized_sdk.delete_data_stream.assert_called_once()


# Ontology CRUD tests
def test_create_ontology(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_ontology calls the SDK create_ontology method."""
    from horizon_data_core.api import create_ontology

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_ontology = Mock()  # type: ignore[method-assign]
        create_ontology(Mock())
        initialized_sdk.create_ontology.assert_called_once()


def test_read_ontology(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_ontology calls the SDK read_ontology method."""
    from horizon_data_core.api import read_ontology

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_ontology = Mock()  # type: ignore[method-assign]
        read_ontology(uuid4())
        initialized_sdk.read_ontology.assert_called_once()


def test_update_ontology(initialized_sdk: HorizonSDK) -> None:
    """Test that API update_ontology calls the SDK update_ontology method."""
    from horizon_data_core.api import update_ontology

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_ontology = Mock()  # type: ignore[method-assign]
        update_ontology(Mock())
        initialized_sdk.update_ontology.assert_called_once()


def test_delete_ontology(initialized_sdk: HorizonSDK) -> None:
    """Test that API delete_ontology calls the SDK delete_ontology method."""
    from horizon_data_core.api import delete_ontology

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_ontology = Mock()  # type: ignore[method-assign]
        delete_ontology(uuid4())
        initialized_sdk.delete_ontology.assert_called_once()


def test_list_ontologies(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_ontologies calls the SDK list_ontologies method."""
    from horizon_data_core.api import list_ontologies

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_ontologies = Mock()  # type: ignore[method-assign]
        list_ontologies()
        initialized_sdk.list_ontologies.assert_called_once()


# OntologyClass CRUD tests
def test_create_ontology_class(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_ontology_class calls the SDK create_ontology_class method."""
    from horizon_data_core.api import create_ontology_class

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_ontology_class = Mock()  # type: ignore[method-assign]
        create_ontology_class(Mock())
        initialized_sdk.create_ontology_class.assert_called_once()


def test_read_ontology_class(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_ontology_class calls the SDK read_ontology_class method."""
    from horizon_data_core.api import read_ontology_class

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_ontology_class = Mock()  # type: ignore[method-assign]
        read_ontology_class(uuid4())
        initialized_sdk.read_ontology_class.assert_called_once()


def test_update_ontology_class(initialized_sdk: HorizonSDK) -> None:
    """Test that API update_ontology_class calls the SDK update_ontology_class method."""
    from horizon_data_core.api import update_ontology_class

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_ontology_class = Mock()  # type: ignore[method-assign]
        update_ontology_class(Mock())
        initialized_sdk.update_ontology_class.assert_called_once()


def test_delete_ontology_class(initialized_sdk: HorizonSDK) -> None:
    """Test that API delete_ontology_class calls the SDK delete_ontology_class method."""
    from horizon_data_core.api import delete_ontology_class

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_ontology_class = Mock()  # type: ignore[method-assign]
        delete_ontology_class(uuid4())
        initialized_sdk.delete_ontology_class.assert_called_once()


def test_list_ontology_classes(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_ontology_classes calls the SDK list_ontology_classes method."""
    from horizon_data_core.api import list_ontology_classes

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_ontology_classes = Mock()  # type: ignore[method-assign]
        list_ontology_classes()
        initialized_sdk.list_ontology_classes.assert_called_once()


# BeamgramSpecification additional CRUD tests
def test_create_or_update_beamgram_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_or_update_beamgram_specification calls the SDK method."""
    from horizon_data_core.api import create_or_update_beamgram_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_or_update_beamgram_specification = Mock()  # type: ignore[method-assign]
        create_or_update_beamgram_specification(Mock())
        initialized_sdk.create_or_update_beamgram_specification.assert_called_once()


def test_read_beamgram_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_beamgram_specification calls the SDK read_beamgram_specification method."""
    from horizon_data_core.api import read_beamgram_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_beamgram_specification = Mock()  # type: ignore[method-assign]
        read_beamgram_specification(uuid4())
        initialized_sdk.read_beamgram_specification.assert_called_once()


def test_update_beamgram_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API update_beamgram_specification calls the SDK update_beamgram_specification method."""
    from horizon_data_core.api import update_beamgram_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_beamgram_specification = Mock()  # type: ignore[method-assign]
        update_beamgram_specification(Mock())
        initialized_sdk.update_beamgram_specification.assert_called_once()


def test_delete_beamgram_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API delete_beamgram_specification calls the SDK delete_beamgram_specification method."""
    from horizon_data_core.api import delete_beamgram_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_beamgram_specification = Mock()  # type: ignore[method-assign]
        delete_beamgram_specification(uuid4())
        initialized_sdk.delete_beamgram_specification.assert_called_once()


def test_list_beamgram_specifications(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_beamgram_specifications calls the SDK list_beamgram_specifications method."""
    from horizon_data_core.api import list_beamgram_specifications

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_beamgram_specifications = Mock()  # type: ignore[method-assign]
        list_beamgram_specifications()
        initialized_sdk.list_beamgram_specifications.assert_called_once()


# BearingTimeRecordSpecification additional CRUD tests
def test_create_or_update_bearing_time_record_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_or_update_bearing_time_record_specification calls the SDK method."""
    from horizon_data_core.api import \
        create_or_update_bearing_time_record_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_or_update_bearing_time_record_specification = Mock()  # type: ignore[method-assign]
        create_or_update_bearing_time_record_specification(Mock())
        initialized_sdk.create_or_update_bearing_time_record_specification.assert_called_once()


def test_read_bearing_time_record_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API read_bearing_time_record_specification calls the SDK method."""
    from horizon_data_core.api import read_bearing_time_record_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.read_bearing_time_record_specification = Mock()  # type: ignore[method-assign]
        read_bearing_time_record_specification(uuid4())
        initialized_sdk.read_bearing_time_record_specification.assert_called_once()


def test_update_bearing_time_record_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API update_bearing_time_record_specification calls the SDK method."""
    from horizon_data_core.api import update_bearing_time_record_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.update_bearing_time_record_specification = Mock()  # type: ignore[method-assign]
        update_bearing_time_record_specification(Mock())
        initialized_sdk.update_bearing_time_record_specification.assert_called_once()


def test_delete_bearing_time_record_specification(initialized_sdk: HorizonSDK) -> None:
    """Test that API delete_bearing_time_record_specification calls the SDK method."""
    from horizon_data_core.api import delete_bearing_time_record_specification

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.delete_bearing_time_record_specification = Mock()  # type: ignore[method-assign]
        delete_bearing_time_record_specification(uuid4())
        initialized_sdk.delete_bearing_time_record_specification.assert_called_once()


def test_list_bearing_time_record_specifications(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_bearing_time_record_specifications calls the SDK method."""
    from horizon_data_core.api import list_bearing_time_record_specifications

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_bearing_time_record_specifications = Mock()  # type: ignore[method-assign]
        list_bearing_time_record_specifications()
        initialized_sdk.list_bearing_time_record_specifications.assert_called_once()


# Iceberg operations tests
def test_create_data_row(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_data_row calls the SDK create_data_row method."""
    from horizon_data_core.api import create_data_row

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_data_row = Mock()  # type: ignore[method-assign]
        create_data_row(Mock())
        initialized_sdk.create_data_row.assert_called_once()


def test_list_data_rows(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_data_rows calls the SDK list_data_rows method."""
    from horizon_data_core.api import list_data_rows

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_data_rows = Mock()  # type: ignore[method-assign]
        list_data_rows()
        initialized_sdk.list_data_rows.assert_called_once()


def test_create_metadata_row(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_metadata_row calls the SDK create_metadata_row method."""
    from horizon_data_core.api import create_metadata_row

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_metadata_row = Mock()  # type: ignore[method-assign]
        create_metadata_row(Mock())
        initialized_sdk.create_metadata_row.assert_called_once()


def test_list_metadata_rows(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_metadata_rows calls the SDK list_metadata_rows method."""
    from horizon_data_core.api import list_metadata_rows

    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_metadata_rows = Mock()  # type: ignore[method-assign]
        list_metadata_rows()
        initialized_sdk.list_metadata_rows.assert_called_once()


# PlatformInformation tests
def test_create_platform_information(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_platform_information calls the SDK method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_platform_information = Mock()  # type: ignore[method-assign]
        create_platform_information(Mock())
        initialized_sdk.create_platform_information.assert_called_once()


def test_create_platform_information_batch(initialized_sdk: HorizonSDK) -> None:
    """Test that API create_platform_information_batch calls the SDK method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.create_platform_information_batch = Mock()  # type: ignore[method-assign]
        create_platform_information_batch([Mock()])
        initialized_sdk.create_platform_information_batch.assert_called_once()


def test_list_platform_information(initialized_sdk: HorizonSDK) -> None:
    """Test that API list_platform_information calls the SDK method."""
    with patch("horizon_data_core.api.get_horizon_sdk", return_value=initialized_sdk):
        initialized_sdk.list_platform_information = Mock()  # type: ignore[method-assign]
        list_platform_information()
        initialized_sdk.list_platform_information.assert_called_once()
