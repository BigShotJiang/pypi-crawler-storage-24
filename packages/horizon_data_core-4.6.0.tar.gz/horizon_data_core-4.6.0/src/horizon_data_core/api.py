"""Public API for Horizon Data Core operations."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

from .base_types import (
    AudioSpecification,
    BeamgramSpecification,
    BearingTimeRecordSpecification,
    DataRow,
    DataStream,
    MetadataRow,
    Mission,
    MissionPlatform,
    Ontology,
    OntologyClass,
    Platform,
    PlatformAudioSpecification,
    PlatformBeamgramSpecification,
    PlatformBearingTimeRecordSpecification,
    PlatformInformation,
    PlatformSpectrogramSpecification,
    SpectrogramSpecification,
)
from .sdk import HorizonSDK

if TYPE_CHECKING:
    from .client import Client

# API scoped singleton SDK instance - will be initialized by users
_sdk: HorizonSDK | None = None


logger = logging.getLogger(__name__)


def initialize_sdk(
    client: Client,
    catalog_properties: dict[str, str | None],
    organization_id: UUID | None,
    iceberg_batch_size: int = 32,
    max_retries: int = 10,
) -> HorizonSDK:
    """Initialize the global SDK instance.

    This function sets up the global SDK instance that is used by all API functions.
    Must be called before using any other API functions.

    Args:
        client: PostgreSQL client for database operations
        iceberg_catalog: Iceberg catalog for table operations
        organization_id: Organization ID for multi-tenancy (can be None)
        iceberg_batch_size: Batch size for Iceberg operations (default: 32)
        max_retries: Maximum retry attempts for failed operations (default: 10)

    Raises:
        RuntimeError: If SDK is already initialized
    """
    # TODO(abuck): Refactor thehis to a singleton class instance pattern # noqa: FIX002
    # https://github.com/spear-ai/horizon/issues/998
    #  Alternatively, we could do away with the global SDK and just let users construct their own SDK instance
    #  and pass it around as needed.
    global _sdk  # noqa: PLW0603
    _sdk = HorizonSDK(client, catalog_properties, organization_id, iceberg_batch_size, max_retries)
    return _sdk


def get_horizon_sdk() -> HorizonSDK:
    """Get the global SDK instance."""
    return _ensure_sdk_initialized()


def _ensure_sdk_initialized() -> HorizonSDK:
    """Ensure the SDK is initialized."""
    if _sdk is None:
        message = "SDK not initialized. Call initialize_sdk() first."
        logger.error(message)
        raise RuntimeError(message)
    return _sdk


def create_platform_beamgram_specification(
    platform_id: UUID, beamgram_specification_id: UUID
) -> PlatformBeamgramSpecification:
    """Create a new platform-beamgram specification relationship."""
    platform_beamgram_specification = PlatformBeamgramSpecification(
        id=uuid4(), platform_id=platform_id, beamgram_specification_id=beamgram_specification_id
    )
    return _ensure_sdk_initialized().create_platform_beamgram_specification(platform_beamgram_specification)


def create_platform_audio_specification(platform_id: UUID, audio_specification_id: UUID) -> PlatformAudioSpecification:
    """Create a new platform-audio specification relationship.

    Args:
        platform_id: The UUID of the platform
        audio_specification_id: The UUID of the audio specification

    Returns:
        The created platform-audio specification with generated ID
    """
    platform_audio_specification = PlatformAudioSpecification(
        id=uuid4(), platform_id=platform_id, audio_specification_id=audio_specification_id
    )
    return _ensure_sdk_initialized().create_platform_audio_specification(platform_audio_specification)


def create_platform_bearing_time_record_specification(
    platform_id: UUID, bearing_time_record_specification_id: UUID
) -> PlatformBearingTimeRecordSpecification:
    """Create a new platform-btr specification relationship."""
    platform_bearing_time_record_specification = PlatformBearingTimeRecordSpecification(
        id=uuid4(), platform_id=platform_id, bearing_time_record_specification_id=bearing_time_record_specification_id
    )
    return _ensure_sdk_initialized().create_platform_bearing_time_record_specification(
        platform_bearing_time_record_specification
    )


def create_platform_spectrogram_specification(
    platform_id: UUID, spectrogram_specification_id: UUID
) -> PlatformSpectrogramSpecification:
    """Create a new platform-spectrogram specification relationship."""
    platform_spectrogram_specification = PlatformSpectrogramSpecification(
        id=uuid4(), platform_id=platform_id, spectrogram_specification_id=spectrogram_specification_id
    )
    return _ensure_sdk_initialized().create_platform_spectrogram_specification(platform_spectrogram_specification)


# Platform operations
def create_platform(platform: Platform) -> Platform:
    """Create a new platform.

    Args:
        platform: The platform instance to create

    Returns:
        The created platform with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    logger.debug(
        "Creating platform",
        extra={"platform": platform},
    )
    return _ensure_sdk_initialized().create_platform(platform)


def upsert_platform(platform: Platform) -> Platform:
    """Create a new platform or update if it already exists.

    Args:
        platform: The platform instance to create or update

    Returns:
        The created or updated platform

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    logger.debug(
        "Creating or updating platform",
        extra={"platform": platform},
    )
    return _ensure_sdk_initialized().create_or_update_platform(platform)


def read_platform(id: UUID) -> Platform | None:
    """Read a platform by ID.

    Args:
        id: The UUID of the platform to read

    Returns:
        The platform if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_platform(id)


def update_platform(platform: Platform) -> Platform:
    """Update an existing platform.

    Args:
        platform: The platform instance with updated fields

    Returns:
        The updated platform

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If platform with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_platform(platform)


def delete_platform(id: UUID) -> bool:
    """Delete a platform by ID.

    Args:
        id: The UUID of the platform to delete

    Returns:
        True if the platform was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_platform(id)


def list_platforms(**filters: Any) -> list[Platform]:  # noqa: ANN401
    """List platforms with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of platforms matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_platforms(**filters)


# PlatformInformation operations (append-only)
def create_platform_information(platform_information: PlatformInformation) -> PlatformInformation:
    """Create a new platform information record.

    Args:
        platform_information: The platform information instance to create

    Returns:
        The created platform information with updated fields

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_platform_information(platform_information)


def create_platform_information_batch(
    platform_information_list: list[PlatformInformation],
) -> list[PlatformInformation]:
    """Create a batch of platform information records.

    Args:
        platform_information_list: List of platform information instances to create

    Returns:
        List of created platform information instances

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_platform_information_batch(platform_information_list)


def list_platform_information(**filters: Any) -> list[PlatformInformation]:  # noqa: ANN401
    """List platform information records with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of platform information records matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_platform_information(**filters)


# DataStream operations
def create_data_stream(platform: Platform, data_stream_name: str) -> DataStream:
    """Create a new data stream, or return the existing matching one.

    Args:
        platform: The platform this data_stream belongs to
        data_stream_name: The name of the stream or sensor

    Returns:
        The created data stream with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    data_stream = DataStream.from_platform_and_name(platform, data_stream_name)
    return _ensure_sdk_initialized().create_data_stream(data_stream)


def read_data_stream(id: UUID) -> DataStream | None:
    """Read a data stream by ID.

    Args:
        id: The UUID of the data stream to read

    Returns:
        The data stream if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_data_stream(id)


def update_data_stream(data_stream: DataStream) -> DataStream:
    """Update an existing data stream.

    Args:
        data_stream: The data stream instance with updated fields

    Returns:
        The updated data stream

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If data stream with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_data_stream(data_stream)


def delete_data_stream(id: UUID) -> bool:
    """Delete a data stream by ID.

    Args:
        id: The UUID of the data stream to delete

    Returns:
        True if the data stream was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_data_stream(id)


def list_data_streams(**filters: Any) -> list[DataStream]:  # noqa: ANN401
    """List data streams with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of data streams matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_data_streams(**filters)


# Mission operations
def create_mission(mission: Mission) -> Mission:
    """Create a new mission.

    Args:
        mission: The mission instance to create

    Returns:
        The created mission with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_mission(mission)


def read_mission(id: UUID) -> Mission | None:
    """Read a mission by ID.

    Args:
        id: The UUID of the mission to read

    Returns:
        The mission if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_mission(id)


def update_mission(mission: Mission) -> Mission:
    """Update an existing mission.

    Args:
        mission: The mission instance with updated fields

    Returns:
        The updated mission

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If mission with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_mission(mission)


def delete_mission(id: UUID) -> bool:
    """Delete a mission by ID.

    Args:
        id: The UUID of the mission to delete

    Returns:
        True if the mission was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_mission(id)


def list_missions(**filters: Any) -> list[Mission]:  # noqa: ANN401
    """List missions with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of missions matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_missions(**filters)


# MissionPlatform operations
def create_mission_platform(mission_platform: MissionPlatform) -> MissionPlatform:
    """Create a new mission-platform relationship.

    Args:
        mission_platform: The mission-platform relationship instance to create

    Returns:
        The created mission-platform relationship with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_mission_platform(mission_platform)


def read_mission_platform(id: UUID) -> MissionPlatform | None:
    """Read a mission-platform relationship by ID.

    Args:
        id: The UUID of the mission-platform relationship to read

    Returns:
        The mission-platform relationship if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_mission_platform(id)


def update_mission_platform(mission_platform: MissionPlatform) -> MissionPlatform:
    """Update an existing mission-platform relationship.

    Args:
        mission_platform: The mission-platform relationship instance with updated fields

    Returns:
        The updated mission-platform relationship

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If mission-platform relationship with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_mission_platform(mission_platform)


def delete_mission_platform(id: UUID) -> bool:
    """Delete a mission-platform relationship by ID.

    Args:
        id: The UUID of the mission-platform relationship to delete

    Returns:
        True if the mission-platform relationship was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_mission_platform(id)


def list_mission_platforms(**filters: Any) -> list[MissionPlatform]:  # noqa: ANN401
    """List mission-platform relationships with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of mission-platform relationships matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_mission_platforms(**filters)


# Ontology operations
def create_ontology(ontology: Ontology) -> Ontology:
    """Create a new ontology.

    Args:
        ontology: The ontology instance to create

    Returns:
        The created ontology with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_ontology(ontology)


def read_ontology(id: UUID) -> Ontology | None:
    """Read an ontology by ID.

    Args:
        id: The UUID of the ontology to read

    Returns:
        The ontology if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_ontology(id)


def update_ontology(ontology: Ontology) -> Ontology:
    """Update an existing ontology.

    Args:
        ontology: The ontology instance with updated fields

    Returns:
        The updated ontology

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If ontology with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_ontology(ontology)


def delete_ontology(id: UUID) -> bool:
    """Delete an ontology by ID.

    Args:
        id: The UUID of the ontology to delete

    Returns:
        True if the ontology was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_ontology(id)


def list_ontologies(**filters: Any) -> list[Ontology]:  # noqa: ANN401
    """List ontologies with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of ontologies matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_ontologies(**filters)


# OntologyClass operations
def create_ontology_class(ontology_class: OntologyClass) -> OntologyClass:
    """Create a new ontology class.

    Args:
        ontology_class: The ontology class instance to create

    Returns:
        The created ontology class with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_ontology_class(ontology_class)


def read_ontology_class(id: UUID) -> OntologyClass | None:
    """Read an ontology class by ID.

    Args:
        id: The UUID of the ontology class to read

    Returns:
        The ontology class if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_ontology_class(id)


def update_ontology_class(ontology_class: OntologyClass) -> OntologyClass:
    """Update an existing ontology class.

    Args:
        ontology_class: The ontology class instance with updated fields

    Returns:
        The updated ontology class

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If ontology class with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_ontology_class(ontology_class)


def delete_ontology_class(id: UUID) -> bool:
    """Delete an ontology class by ID.

    Args:
        id: The UUID of the ontology class to delete

    Returns:
        True if the ontology class was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_ontology_class(id)


def list_ontology_classes(**filters: Any) -> list[OntologyClass]:  # noqa: ANN401
    """List ontology classes with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of ontology classes matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_ontology_classes(**filters)


# BeamgramSpecification operations
def create_beamgram_specification(beamgram_specification: BeamgramSpecification) -> BeamgramSpecification:
    """Create a new beamgram specification.

    Args:
        beamgram_specification: The beamgram specification instance to create

    Returns:
        The created beamgram specification with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_beamgram_specification(beamgram_specification)


def create_or_update_beamgram_specification(beamgram_specification: BeamgramSpecification) -> BeamgramSpecification:
    """Create a new beamgram specification or update if it already exists.

    Args:
        beamgram_specification: The beamgram specification instance to create or update

    Returns:
        The created or updated beamgram specification

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_or_update_beamgram_specification(beamgram_specification)


def read_beamgram_specification(id: UUID) -> BeamgramSpecification | None:
    """Read a beamgram specification by ID.

    Args:
        id: The UUID of the beamgram specification to read

    Returns:
        The beamgram specification if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_beamgram_specification(id)


def update_beamgram_specification(beamgram_specification: BeamgramSpecification) -> BeamgramSpecification:
    """Update an existing beamgram specification.

    Args:
        beamgram_specification: The beamgram specification instance with updated fields

    Returns:
        The updated beamgram specification

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If beamgram specification with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_beamgram_specification(beamgram_specification)


def delete_beamgram_specification(id: UUID) -> bool:
    """Delete a beamgram specification by ID.

    Args:
        id: The UUID of the beamgram specification to delete

    Returns:
        True if the beamgram specification was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_beamgram_specification(id)


def list_beamgram_specifications(**filters: Any) -> list[BeamgramSpecification]:  # noqa: ANN401
    """List beamgram specifications with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of beamgram specifications matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_beamgram_specifications(**filters)


# BearingTimeRecordSpecification operations
def create_bearing_time_record_specification(
    bearing_time_record_specification: BearingTimeRecordSpecification,
) -> BearingTimeRecordSpecification:
    """Create a new bearing-time record specification.

    Args:
        bearing_time_record_specification: The bearing-time record specification instance to create

    Returns:
        The created bearing-time record specification with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_bearing_time_record_specification(bearing_time_record_specification)


def create_or_update_bearing_time_record_specification(
    bearing_time_record_specification: BearingTimeRecordSpecification,
) -> BearingTimeRecordSpecification:
    """Create a new bearing-time record specification or update if it already exists.

    Args:
        bearing_time_record_specification: The bearing-time record specification instance to create or update

    Returns:
        The created or updated bearing-time record specification

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_or_update_bearing_time_record_specification(
        bearing_time_record_specification
    )


def read_bearing_time_record_specification(id: UUID) -> BearingTimeRecordSpecification | None:
    """Read a bearing-time record specification by ID.

    Args:
        id: The UUID of the bearing-time record specification to read

    Returns:
        The bearing-time record specification if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_bearing_time_record_specification(id)


def update_bearing_time_record_specification(
    bearing_time_record_specification: BearingTimeRecordSpecification,
) -> BearingTimeRecordSpecification:
    """Update an existing bearing-time record specification.

    Args:
        bearing_time_record_specification: The bearing-time record specification instance with updated fields

    Returns:
        The updated bearing-time record specification

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If bearing-time record specification with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_bearing_time_record_specification(bearing_time_record_specification)


def delete_bearing_time_record_specification(id: UUID) -> bool:
    """Delete a bearing-time record specification by ID.

    Args:
        id: The UUID of the bearing-time record specification to delete

    Returns:
        True if the bearing-time record specification was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_bearing_time_record_specification(id)


def list_bearing_time_record_specifications(**filters: Any) -> list[BearingTimeRecordSpecification]:  # noqa: ANN401
    """List bearing-time record specifications with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of bearing-time record specifications matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_bearing_time_record_specifications(**filters)


# AudioSpecification operations
def create_audio_specification(audio_specification: AudioSpecification) -> AudioSpecification:
    """Create a new audio specification.

    Args:
        audio_specification: The audio specification instance to create

    Returns:
        The created audio specification with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_audio_specification(audio_specification)


def create_or_update_audio_specification(
    audio_specification: AudioSpecification,
) -> AudioSpecification:
    """Create a new audio specification or update if it already exists.

    Args:
        audio_specification: The audio specification instance to create or update

    Returns:
        The created or updated audio specification

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_or_update_audio_specification(audio_specification)


def read_audio_specification(id: UUID) -> AudioSpecification | None:
    """Read an audio specification by ID.

    Args:
        id: The UUID of the audio specification to read

    Returns:
        The audio specification if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_audio_specification(id)


def update_audio_specification(audio_specification: AudioSpecification) -> AudioSpecification:
    """Update an existing audio specification.

    Args:
        audio_specification: The audio specification instance with updated fields

    Returns:
        The updated audio specification

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If audio specification with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_audio_specification(audio_specification)


def delete_audio_specification(id: UUID) -> bool:
    """Delete an audio specification by ID.

    Args:
        id: The UUID of the audio specification to delete

    Returns:
        True if the audio specification was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_audio_specification(id)


def list_audio_specifications(**filters: Any) -> list[AudioSpecification]:  # noqa: ANN401
    """List audio specifications with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of audio specifications matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_audio_specifications(**filters)


# SpectrogramSpecification operations
def create_spectrogram_specification(
    spectrogram_specification: SpectrogramSpecification,
) -> SpectrogramSpecification:
    """Create a new spectrogram specification.

    Args:
        spectrogram_specification: The spectrogram specification instance to create

    Returns:
        The created spectrogram specification with updated fields (e.g., generated ID)

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_spectrogram_specification(spectrogram_specification)


def create_or_update_spectrogram_specification(
    spectrogram_specification: SpectrogramSpecification,
) -> SpectrogramSpecification:
    """Create a new spectrogram specification or update if it already exists.

    Args:
        spectrogram_specification: The spectrogram specification instance to create or update

    Returns:
        The created or updated spectrogram specification

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().create_or_update_spectrogram_specification(spectrogram_specification)


def read_spectrogram_specification(id: UUID) -> SpectrogramSpecification | None:
    """Read a spectrogram specification by ID.

    Args:
        id: The UUID of the spectrogram specification to read

    Returns:
        The spectrogram specification if found, None otherwise

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().read_spectrogram_specification(id)


def update_spectrogram_specification(
    spectrogram_specification: SpectrogramSpecification,
) -> SpectrogramSpecification:
    """Update an existing spectrogram specification.

    Args:
        spectrogram_specification: The spectrogram specification instance with updated fields

    Returns:
        The updated spectrogram specification

    Raises:
        RuntimeError: If SDK is not initialized
        ValueError: If spectrogram specification with the given ID is not found
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().update_spectrogram_specification(spectrogram_specification)


def delete_spectrogram_specification(id: UUID) -> bool:
    """Delete a spectrogram specification by ID.

    Args:
        id: The UUID of the spectrogram specification to delete

    Returns:
        True if the spectrogram specification was deleted, False if it didn't exist

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().delete_spectrogram_specification(id)


def list_spectrogram_specifications(**filters: Any) -> list[SpectrogramSpecification]:  # noqa: ANN401
    """List spectrogram specifications with optional filters.

    Args:
        **filters: Keyword arguments where keys are field names and values are filter values

    Returns:
        List of spectrogram specifications matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        SQLAlchemyError: If database operation fails
    """
    return _ensure_sdk_initialized().list_spectrogram_specifications(**filters)


# Iceberg operations
def create_data_row(data_row: DataRow, buffer_name: str | None = None) -> DataRow:
    """Create a new data row in Iceberg table.

    Args:
        data_row: The data row instance to create
        buffer_name: Optional buffer name for batching writes

    Returns:
        The data row instance (unchanged)

    Raises:
        RuntimeError: If SDK is not initialized
        CommitFailedException: If write operation fails after retries
    """
    return _ensure_sdk_initialized().create_data_row(data_row, buffer_name)


def create_data_rows(data_rows: list[DataRow], buffer_name: str | None = None) -> list[DataRow]:
    """Create a new data rows in Iceberg table.

    Args:
        data_rows: The list of data row instances to create
        buffer_name: Optional buffer name for batching writes

    Returns:
        The list of data row instances (unchanged)
    """
    return _ensure_sdk_initialized().create_data_row_batch(data_rows, buffer_name)


def list_data_rows(**filters: Any) -> list[DataRow]:  # noqa: ANN401
    """List data rows with optional filters from Iceberg table.

    Args:
        **filters: Iceberg scan parameters including:
            - row_filter: str | boolean_expr = True
            - selected_fields: tuple[str] = ("*",)
            - case_sensitive: bool = True
            - snapshot_id: str | None = None
            - options: Properties = {}
            - limit: int | None = None

    Returns:
        List of data rows matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        Exception: If Iceberg scan operation fails
    """
    return _ensure_sdk_initialized().list_data_rows(**filters)


def create_metadata_row(metadata_row: MetadataRow, buffer_name: str | None = None) -> MetadataRow:
    """Create a new metadata row in Iceberg table.

    Args:
        metadata_row: The metadata row instance to create
        buffer_name: Optional buffer name for batching writes

    Returns:
        The metadata row instance (unchanged)

    Raises:
        RuntimeError: If SDK is not initialized
        CommitFailedException: If write operation fails after retries
    """
    return _ensure_sdk_initialized().create_metadata_row(metadata_row, buffer_name)


def list_metadata_rows(**filters: Any) -> list[MetadataRow]:  # noqa: ANN401
    """List metadata rows with optional filters from Iceberg table.

    Args:
        **filters: Iceberg scan parameters including:
            - row_filter: str | boolean_expr = True
            - selected_fields: tuple[str] = ("*",)
            - case_sensitive: bool = True
            - snapshot_id: str | None = None
            - options: Properties = {}
            - limit: int | None = None

    Returns:
        List of metadata rows matching the filters

    Raises:
        RuntimeError: If SDK is not initialized
        Exception: If Iceberg scan operation fails
    """
    return _ensure_sdk_initialized().list_metadata_rows(**filters)


# Coverage operations (via HTTP to the BentoML horizon-coverage service)


def get_coa(request: dict[str, Any]) -> dict[str, Any]:
    """Generate course of action candidates for the provided objective.

    Args:
        request: The coverage scenario request payload.

    Returns:
        The course of action response from the BentoML service.

    Raises:
        RuntimeError: If SDK is not initialized or the coverage service is unreachable.
    """
    return _ensure_sdk_initialized().get_coa(request)


def get_coverage_heatmap(request: dict[str, Any]) -> dict[str, Any]:
    """Get coverage for the requested area.

    Args:
        request: The coverage scenario request payload.

    Returns:
        The coverage response from the BentoML service.

    Raises:
        RuntimeError: If SDK is not initialized or the coverage service is unreachable.
    """
    return _ensure_sdk_initialized().get_coverage_heatmap(request)


def get_predictive_heatmap(request: dict[str, Any]) -> dict[str, Any]:
    """Get a predictive heatmap for the requested area.

    Args:
        request: The coverage scenario request payload.

    Returns:
        The predictive heatmap response from the BentoML service.

    Raises:
        RuntimeError: If SDK is not initialized or the coverage service is unreachable.
    """
    return _ensure_sdk_initialized().get_predictive_heatmap(request)
