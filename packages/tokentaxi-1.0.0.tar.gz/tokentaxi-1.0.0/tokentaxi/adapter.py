# tokentaxi/adapter.py
"""
UniversalAdapter — a provider-agnostic wrapper for any LLM client.

This class uses dynamic feature detection to interact with different SDKs
(OpenAI-compatible, Anthropic, Gemini, etc.) through a uniform interface.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class AsyncChatClient(Protocol):
    """Protocol for clients that support async chat completions."""
    async def chat(self, *args: Any, **kwargs: Any) -> Any: ...

class BaseAdapter(ABC):
    """Abstract base for all internal adapter implementations."""
    
    @abstractmethod
    async def chat(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> tuple[str, int, int]:
        """Send a non-streaming chat request."""

    @abstractmethod
    async def stream(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        """Send a streaming chat request."""

class OpenAIAdapter(BaseAdapter):
    """Adapter for OpenAI and OpenAI-compatible clients (vLLM, Groq, Ollama)."""
    
    async def chat(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> tuple[str, int, int]:
        response = await client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs,
        )
        content = response.choices[0].message.content or ""
        input_tokens = response.usage.prompt_tokens
        output_tokens = response.usage.completion_tokens
        return content, input_tokens, output_tokens

    async def stream(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        stream = await client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            stream=True,
            **kwargs,
        )
        async for chunk in stream:
            if hasattr(chunk.choices[0].delta, "content"):
                delta = chunk.choices[0].delta.content
                if delta:
                    yield delta

class AnthropicAdapter(BaseAdapter):
    """Adapter for Anthropic clients."""
    
    async def chat(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> tuple[str, int, int]:
        system = None
        filtered_messages = []
        for m in messages:
            if m.get("role") == "system":
                system = m.get("content")
            else:
                filtered_messages.append(m)
        
        call_params = {
            "model": model,
            "messages": filtered_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            **kwargs,
        }
        if system:
            call_params["system"] = system
            
        response = await client.messages.create(**call_params)
        content = response.content[0].text if response.content else ""
        return content, response.usage.input_tokens, response.usage.output_tokens

    async def stream(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        system = None
        filtered_messages = []
        for m in messages:
            if m.get("role") == "system":
                system = m.get("content")
            else:
                filtered_messages.append(m)
        
        call_params = {
            "model": model,
            "messages": filtered_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            **kwargs,
        }
        if system:
            call_params["system"] = system
            
        async with client.messages.stream(**call_params) as stream:
            async for text in stream.text_stream:
                yield text

class GeminiAdapter(BaseAdapter):
    """Adapter for Google Gemini clients."""
    
    async def chat(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> tuple[str, int, int]:
        from google.generativeai.types import GenerationConfig, content_types
        
        history = []
        for m in messages:
            role = "model" if m["role"] == "assistant" else "user"
            history.append(content_types.to_content({"role": role, "parts": [m["content"]]}))
            
        prompt = history.pop() # Last one is prompt
        
        config = GenerationConfig(
            candidate_count=1,
            max_output_tokens=max_tokens,
            temperature=temperature,
            **kwargs
        )
        
        chat = client.start_chat(history=history)
        response = await chat.send_message_async(prompt, generation_config=config)
        
        content = response.text
        usage = response.usage_metadata
        return content, usage.prompt_token_count, usage.candidates_token_count

    async def stream(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        from google.generativeai.types import GenerationConfig, content_types
        
        history = []
        for m in messages:
            role = "model" if m["role"] == "assistant" else "user"
            history.append(content_types.to_content({"role": role, "parts": [m["content"]]}))
            
        prompt = history.pop()
        
        config = GenerationConfig(
            candidate_count=1,
            max_output_tokens=max_tokens,
            temperature=temperature,
            **kwargs
        )
        
        chat = client.start_chat(history=history)
        response = await chat.send_message_async(prompt, generation_config=config, stream=True)
        async for chunk in response:
            yield chunk.text

class UniversalAdapter:
    """Detects and delegates to the appropriate specialized adapter."""
    
    def __init__(self, client: Any):
        self._client = client
        self._impl = self._get_adapter(client)
        
    def _get_adapter(self, client: Any) -> BaseAdapter:
        client_type = str(type(client)).lower()
        if "openai" in client_type or hasattr(client, "chat") and hasattr(client.chat, "completions"):
            return OpenAIAdapter()
        if "anthropic" in client_type:
            return AnthropicAdapter()
        if "google.generativeai" in client_type or "generativemodel" in client_type:
            return GeminiAdapter()
        
        # Fallback to OpenAI-style if it looks similar enough
        if hasattr(client, "chat"):
            return OpenAIAdapter()
            
        raise ValueError(f"Unsupported client type: {type(client)}. "
                         "Client must be OpenAI-compatible, Anthropic, or Gemini.")

    async def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int = 1024,
        temperature: float = 0.7,
        **kwargs: Any,
    ) -> tuple[str, int, int]:
        return await self._impl.chat(self._client, model, messages, max_tokens, temperature, **kwargs)

    async def stream(
        self,
        model: str,
        messages: list[dict[str, Any]],
        max_tokens: int = 1024,
        temperature: float = 0.7,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        return self._impl.stream(self._client, model, messages, max_tokens, temperature, **kwargs)
