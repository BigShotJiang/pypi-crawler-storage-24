# Governance in Motion SDK

Runtime governance enforcement for AI agents. Every tool call your agent makes is checked against your governance policies and delegation contracts before it executes.

## Installation

```bash
pip install gim-sdk
```

With LangChain support:
```bash
pip install gim-sdk[langchain]
```

## Quick Start

```python
from gim_sdk import GIMAgent

agent = GIMAgent(
    gateway_url="http://localhost:8001",
    agent_id="my-agent-001",
    tenant_id="00000000-0000-0000-0000-000000000001",
)

# Check before acting
decision = agent.check("http_request", domain="api.example.com", method="GET")

if decision.allowed:
    response = requests.get("https://api.example.com/data")
elif decision.denied:
    print(f"Blocked: {decision.explanation}")
elif decision.requires_approval:
    print(f"Waiting for approval: {decision.approval_id}")
```

## Environment Variables

Set these instead of passing constructor args:

```bash
export GIM_GATEWAY_URL="http://localhost:8001"
export GIM_AGENT_ID="my-agent-001"
export GIM_TENANT_ID="00000000-0000-0000-0000-000000000001"
export GIM_ENVIRONMENT="prod"
```

Then just:
```python
from gim_sdk import GIMAgent
agent = GIMAgent()  # reads from env
```

## Action Types

### HTTP Request
```python
decision = agent.check(
    action_type="http_request",
    domain="api.stripe.com",
    method="POST",
    body={"amount": 1000},
)
```

### Send Message
```python
decision = agent.check(
    action_type="send_message",
    recipient="customer@example.com",
    data_class="internal",
)
```

### Database Query
```python
decision = agent.check(
    action_type="query_db",
    db="production",
    table="users",
)
```

## Decision Object

```python
decision.allowed           # bool — True if ALLOW
decision.denied            # bool — True if DENY
decision.requires_approval # bool — True if REQUIRE_APPROVAL
decision.redacted          # bool — True if REDACT
decision.explanation       # str  — human-readable reason
decision.policy_id         # str  — which policy matched
decision.approval_id       # str  — approval request ID (if pending)
decision.redacted_fields   # list — fields that were masked

# Raise exception instead of checking manually
decision.raise_if_denied()      # raises GovernanceError on DENY
decision.raise_if_not_allowed() # raises GovernanceError on anything except ALLOW
```

## Error Handling

```python
from gim_sdk import GIMAgent, GovernanceError

agent = GIMAgent(...)

try:
    decision = agent.check("http_request", domain="api.example.com")
    decision.raise_if_denied()
    # safe to proceed
except GovernanceError as e:
    print(f"Governance blocked: {e}")
    print(f"Decision was: {e.decision.decision}")
```

## Gateway Unreachable

If the gateway is down, the SDK returns `DENY` by default (fail-closed):

```python
decision = agent.check("http_request", domain="api.example.com")
# If gateway is unreachable:
# decision.denied == True
# decision.explanation == "Gateway unreachable — action blocked by default"
```

## LangChain Integration

### Wrap a tool

```python
from langchain.tools import tool
from gim_sdk import GIMAgent

agent = GIMAgent(...)

@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    return requests.get(f"https://api.search.com?q={query}").text

# Wrap with governance
governed_search = agent.as_langchain_tool(
    search_web,
    action_type="http_request",
    domain="api.search.com",
)

# Use in your agent as normal — governance runs automatically
```

### Callback handler (intercepts all tools)

```python
from langchain.agents import AgentExecutor

executor = AgentExecutor(
    agent=llm_agent,
    tools=tools,
    callbacks=[agent.as_langchain_callback()],
)
# Every tool call now goes through governance before executing
```

## Full ActionEvent (advanced)

```python
from gim_sdk import GIMAgent, ActionEvent

agent = GIMAgent(...)

event = ActionEvent(
    tenant_id   = "00000000-...",
    agent_id    = "my-agent-001",
    action_type = "http_request",
    tool_name   = "stripe_charge",
    target      = {"domain": "api.stripe.com", "method": "POST"},
    request     = {"body": {"amount": 5000, "currency": "usd"}},
    context     = {
        "data_class": "confidential",
        "tags":       ["verified", "production-ready"],
        "user_id":    "user-123",
    },
    environment = "prod",
)

decision = agent.invoke(event)
```

## Demo (works with local dev stack)

```python
from gim_sdk import GIMAgent

agent = GIMAgent(
    gateway_url = "http://localhost:8001",
    agent_id    = "demo-agent-001",
    tenant_id   = "00000000-0000-0000-0000-000000000001",
    environment = "dev",
)

# Should ALLOW (if policy permits)
d = agent.check("http_request", domain="api.example.com")
print(d)  # Decision(ALLOW: Permitted by policy)

# Should DENY (if blocklist policy active)
d = agent.check("http_request", domain="evil.com")
print(d)  # Decision(DENY: Domain blocked by policy)
```
