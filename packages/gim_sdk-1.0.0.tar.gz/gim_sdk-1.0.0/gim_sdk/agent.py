"""
Governance in Motion SDK — GIMAgent
"""

import os
import time
import uuid
import logging
from typing import Optional, Dict, Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .models import Decision, ActionEvent, GovernanceError

log = logging.getLogger("gim_sdk")


class GIMAgent:
    """
    Client for the Governance in Motion gateway.

    Quick start:
        from gim_sdk import GIMAgent

        agent = GIMAgent(
            gateway_url="http://localhost:8001",
            agent_id="my-agent-001",
            tenant_id="00000000-0000-0000-0000-000000000001",
        )

        decision = agent.check(
            action_type="http_request",
            domain="api.example.com",
            method="GET",
        )
        if decision.allowed:
            # do the thing
        else:
            print(f"Blocked: {decision.explanation}")
    """

    def __init__(
        self,
        gateway_url:  Optional[str] = None,
        agent_id:     Optional[str] = None,
        tenant_id:    Optional[str] = None,
        environment:  str = "prod",
        timeout:      float = 5.0,
        retries:      int = 2,
        data_class:   str = "public",
        tags:         Optional[list] = None,
    ):
        self.gateway_url = (gateway_url or os.getenv("GIM_GATEWAY_URL", "http://localhost:8001")).rstrip("/")
        self.agent_id    = agent_id    or os.getenv("GIM_AGENT_ID",   f"agent-{uuid.uuid4().hex[:8]}")
        self.tenant_id   = tenant_id   or os.getenv("GIM_TENANT_ID",  "")
        self.environment = environment or os.getenv("GIM_ENVIRONMENT", "prod")
        self.data_class  = data_class
        self.tags        = tags or []
        self.timeout     = timeout

        # HTTP session with retry
        self._session = requests.Session()
        retry = Retry(total=retries, backoff_factor=0.2,
                      status_forcelist=[502, 503, 504])
        self._session.mount("http://",  HTTPAdapter(max_retries=retry))
        self._session.mount("https://", HTTPAdapter(max_retries=retry))

    # ── High-level helpers ─────────────────────────────────

    def check(
        self,
        action_type: str,
        tool_name:   Optional[str] = None,
        domain:      Optional[str] = None,
        method:      Optional[str] = "GET",
        recipient:   Optional[str] = None,
        db:          Optional[str] = None,
        table:       Optional[str] = None,
        body:        Optional[Dict] = None,
        headers:     Optional[Dict] = None,
        data_class:  Optional[str] = None,
        tags:        Optional[list] = None,
        session_id:  Optional[str] = None,
    ) -> Decision:
        """
        Check a proposed action against governance before executing it.

        Examples:
            # HTTP call
            d = agent.check("http_request", domain="api.stripe.com", method="POST")

            # Sending a message
            d = agent.check("send_message", recipient="user@example.com")

            # Database query
            d = agent.check("query_db", db="production", table="users")
        """
        target = {}
        if action_type == "http_request":
            target = {"domain": domain or "", "method": method or "GET"}
        elif action_type == "send_message":
            target = {"recipient": recipient or ""}
        elif action_type == "query_db":
            target = {"db": db or "", "table": table or ""}

        event = ActionEvent(
            tenant_id   = self.tenant_id,
            agent_id    = self.agent_id,
            action_type = action_type,
            tool_name   = tool_name or f"{action_type}_tool",
            target      = target,
            request     = {"headers": headers or {}, "body": body or {}},
            context     = {
                "data_class": data_class or self.data_class,
                "tags":       tags or self.tags,
                "trace_id":   uuid.uuid4().hex,
            },
            session_id  = session_id or uuid.uuid4().hex,
            environment = self.environment,
        )
        return self.invoke(event)

    def invoke(self, event: ActionEvent) -> Decision:
        """
        Send a full ActionEvent to the gateway and return a Decision.
        """
        t0 = time.monotonic()
        try:
            resp = self._session.post(
                f"{self.gateway_url}/v1/invoke/{event.tool_name}",
                json    = event.to_dict(),
                timeout = self.timeout,
                headers = {"Content-Type": "application/json"},
            )
            latency_ms = round((time.monotonic() - t0) * 1000, 1)

            if resp.status_code == 200:
                data = resp.json()
                d = Decision(
                    decision        = data.get("decision", "DENY"),
                    explanation     = data.get("explanation", ""),
                    policy_id       = data.get("policy_id"),
                    rule_name       = data.get("rule_name"),
                    approval_id     = data.get("approval_id"),
                    redacted_fields = data.get("redacted_fields", []),
                    raw             = data,
                )
                log.debug("gim.invoke decision=%s latency=%sms agent=%s",
                          d.decision, latency_ms, self.agent_id)
                return d
            else:
                log.warning("gim.invoke http_error status=%s", resp.status_code)
                return Decision(
                    decision    = "DENY",
                    explanation = f"Gateway error {resp.status_code}: {resp.text[:200]}",
                )

        except requests.exceptions.Timeout:
            log.error("gim.invoke timeout after %ss", self.timeout)
            return Decision(decision="DENY", explanation="Gateway timeout — action blocked by default")

        except requests.exceptions.ConnectionError as e:
            log.error("gim.invoke connection_error %s", str(e))
            return Decision(decision="DENY", explanation="Gateway unreachable — action blocked by default")

    # ── LangChain integration ──────────────────────────────

    def as_langchain_tool(
        self,
        tool_fn,
        action_type: str = "http_request",
        domain:      Optional[str] = None,
        **check_kwargs,
    ):
        """
        Wrap a LangChain tool function with governance enforcement.

        Usage:
            from langchain.tools import tool

            @tool
            def search_web(query: str) -> str:
                return requests.get(f"https://api.search.com?q={query}").text

            governed_search = agent.as_langchain_tool(
                search_web,
                action_type="http_request",
                domain="api.search.com",
            )
            # Use governed_search in your LangChain agent — governance runs automatically
        """
        try:
            from langchain.tools import StructuredTool
        except ImportError:
            raise ImportError(
                "langchain is required for as_langchain_tool(). "
                "Install it with: pip install langchain"
            )

        agent = self  # capture self for closure

        def governed_fn(*args, **kwargs):
            decision = agent.check(
                action_type = action_type,
                domain      = domain,
                **check_kwargs,
            )
            if not decision.allowed:
                return f"[BLOCKED by Governance in Motion] {decision.decision}: {decision.explanation}"
            return tool_fn(*args, **kwargs)

        return StructuredTool.from_function(
            func        = governed_fn,
            name        = getattr(tool_fn, "name", tool_fn.__name__),
            description = getattr(tool_fn, "description", tool_fn.__doc__ or ""),
        )

    def as_langchain_callback(self):
        """
        Returns a LangChain callback handler that intercepts all tool calls
        and runs governance checks before execution.

        Usage:
            from langchain.agents import AgentExecutor

            executor = AgentExecutor(
                agent=agent,
                tools=tools,
                callbacks=[gim_agent.as_langchain_callback()],
            )
        """
        try:
            from langchain.callbacks.base import BaseCallbackHandler
        except ImportError:
            raise ImportError("langchain is required. pip install langchain")

        gim = self

        class GIMCallbackHandler(BaseCallbackHandler):
            def on_tool_start(self, serialized, input_str, **kwargs):
                tool_name = serialized.get("name", "unknown_tool")
                decision  = gim.check(
                    action_type = "http_request",
                    tool_name   = tool_name,
                )
                if not decision.allowed:
                    raise GovernanceError(
                        f"Tool '{tool_name}' blocked by governance: {decision.explanation}",
                        decision,
                    )

        return GIMCallbackHandler()
