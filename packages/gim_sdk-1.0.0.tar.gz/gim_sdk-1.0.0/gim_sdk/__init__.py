"""
Governance in Motion SDK
========================
Runtime governance enforcement for AI agents.

Quick start:
    from gim_sdk import GIMAgent

    agent = GIMAgent(
        gateway_url="http://localhost:8001",
        agent_id="my-agent-001",
        tenant_id="00000000-0000-0000-0000-000000000001",
    )

    decision = agent.check("http_request", domain="api.example.com")
    if decision.allowed:
        response = requests.get("https://api.example.com/data")

Environment variables (alternative to constructor args):
    GIM_GATEWAY_URL   — gateway base URL
    GIM_AGENT_ID      — agent identifier
    GIM_TENANT_ID     — tenant UUID
    GIM_ENVIRONMENT   — dev | test | prod (default: prod)
"""

from .agent  import GIMAgent
from .models import Decision, ActionEvent, GovernanceError

__all__ = ["GIMAgent", "Decision", "ActionEvent", "GovernanceError"]
__version__ = "1.0.0"
