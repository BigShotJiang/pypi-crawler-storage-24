"""
Governance in Motion SDK — Data Models
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class Decision:
    """Result of a governance check."""
    decision:        str                    # ALLOW | DENY | REQUIRE_APPROVAL | REDACT
    explanation:     str = ""
    policy_id:       Optional[str] = None
    rule_name:       Optional[str] = None
    approval_id:     Optional[str] = None
    redacted_fields: List[str] = field(default_factory=list)
    raw:             Dict[str, Any] = field(default_factory=dict)

    @property
    def allowed(self) -> bool:
        return self.decision == "ALLOW"

    @property
    def denied(self) -> bool:
        return self.decision == "DENY"

    @property
    def requires_approval(self) -> bool:
        return self.decision == "REQUIRE_APPROVAL"

    @property
    def redacted(self) -> bool:
        return self.decision == "REDACT"

    def __str__(self) -> str:
        return f"Decision({self.decision}: {self.explanation})"

    def raise_if_denied(self):
        """Raise GovernanceError if the decision is DENY."""
        if self.denied:
            raise GovernanceError(self.explanation, self)

    def raise_if_not_allowed(self):
        """Raise GovernanceError unless the decision is ALLOW."""
        if not self.allowed:
            raise GovernanceError(
                f"Action not allowed: {self.decision} — {self.explanation}", self
            )


@dataclass
class ActionEvent:
    """Normalised contract for all agent tool calls."""
    tenant_id:   str
    agent_id:    str
    action_type: str                        # http_request | send_message | query_db
    tool_name:   str
    target:      Dict[str, Any] = field(default_factory=dict)
    request:     Dict[str, Any] = field(default_factory=dict)
    context:     Dict[str, Any] = field(default_factory=dict)
    session_id:  str = "sdk-session"
    environment: str = "prod"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tenant_id":   self.tenant_id,
            "agent_id":    self.agent_id,
            "session_id":  self.session_id,
            "environment": self.environment,
            "action_type": self.action_type,
            "tool": {
                "name":     self.tool_name,
                "category": "runtime",
            },
            "target":  self.target,
            "request": self.request,
            "context": self.context,
        }


class GovernanceError(Exception):
    """Raised when an action is blocked by governance."""
    def __init__(self, message: str, decision: Decision):
        super().__init__(message)
        self.decision = decision
