"""
GIM SDK Test Suite — all decision types and fail-closed behavior.
"""

import os
import json
import pytest
import responses

from gim_sdk import GIMAgent, Decision, ActionEvent, GovernanceError

GW = "http://test-gateway:8001"


def make_agent(**kwargs):
    defaults = {
        "gateway_url": GW,
        "agent_id": "test-agent",
        "tenant_id": "00000000-0000-0000-0000-000000000001",
        "environment": "dev",
        "retries": 0,
    }
    defaults.update(kwargs)
    return GIMAgent(**defaults)


# ═══════════════════════════════════════════════════════════════
# Category A: Constructor
# ═══════════════════════════════════════════════════════════════

class TestConstructor:
    def test_explicit_params(self):
        agent = make_agent()
        assert agent.gateway_url == GW
        assert agent.agent_id == "test-agent"
        assert agent.tenant_id == "00000000-0000-0000-0000-000000000001"
        assert agent.environment == "dev"

    def test_defaults(self):
        agent = GIMAgent()
        assert agent.gateway_url == "http://localhost:8001"
        assert agent.environment == "prod"
        assert agent.data_class == "public"
        assert agent.tags == []
        assert agent.timeout == 5.0

    def test_env_vars(self, monkeypatch):
        monkeypatch.setenv("GIM_GATEWAY_URL", "http://env-gw:8001")
        monkeypatch.setenv("GIM_AGENT_ID", "env-agent")
        monkeypatch.setenv("GIM_TENANT_ID", "env-tenant-123")
        agent = GIMAgent()
        assert agent.gateway_url == "http://env-gw:8001"
        assert agent.agent_id == "env-agent"
        assert agent.tenant_id == "env-tenant-123"

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("GIM_GATEWAY_URL", "http://env-gw:8001")
        agent = GIMAgent(gateway_url="http://explicit:8001")
        assert agent.gateway_url == "http://explicit:8001"


# ═══════════════════════════════════════════════════════════════
# Category B: Decision properties
# ═══════════════════════════════════════════════════════════════

class TestDecisionProperties:
    def test_allowed(self):
        d = Decision(decision="ALLOW", explanation="ok")
        assert d.allowed is True
        assert d.denied is False
        assert d.requires_approval is False
        assert d.redacted is False

    def test_denied(self):
        d = Decision(decision="DENY", explanation="blocked")
        assert d.allowed is False
        assert d.denied is True

    def test_requires_approval(self):
        d = Decision(decision="REQUIRE_APPROVAL", explanation="needs review")
        assert d.requires_approval is True
        assert d.allowed is False

    def test_redacted(self):
        d = Decision(decision="REDACT", explanation="fields masked",
                     redacted_fields=["request.body"])
        assert d.redacted is True
        assert "request.body" in d.redacted_fields

    def test_str(self):
        d = Decision(decision="DENY", explanation="no way")
        assert "DENY" in str(d)
        assert "no way" in str(d)


# ═══════════════════════════════════════════════════════════════
# Category C: raise_if_denied and raise_if_not_allowed
# ═══════════════════════════════════════════════════════════════

class TestRaiseHelpers:
    def test_raise_if_denied_on_deny(self):
        d = Decision(decision="DENY", explanation="blocked")
        with pytest.raises(GovernanceError) as exc_info:
            d.raise_if_denied()
        assert exc_info.value.decision is d

    def test_raise_if_denied_on_allow(self):
        d = Decision(decision="ALLOW", explanation="ok")
        d.raise_if_denied()  # should not raise

    def test_raise_if_not_allowed_on_deny(self):
        d = Decision(decision="DENY", explanation="nope")
        with pytest.raises(GovernanceError):
            d.raise_if_not_allowed()

    def test_raise_if_not_allowed_on_require_approval(self):
        d = Decision(decision="REQUIRE_APPROVAL", explanation="wait")
        with pytest.raises(GovernanceError):
            d.raise_if_not_allowed()

    def test_raise_if_not_allowed_on_allow(self):
        d = Decision(decision="ALLOW", explanation="ok")
        d.raise_if_not_allowed()  # should not raise


# ═══════════════════════════════════════════════════════════════
# Category D: HTTP calls — mock all 4 decision types
# ═══════════════════════════════════════════════════════════════

class TestHTTPCalls:
    @responses.activate
    def test_allow_decision(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            json={"decision": "ALLOW", "explanation": "Default allow"},
            status=200)
        agent = make_agent()
        d = agent.check("http_request", domain="api.example.com")
        assert d.allowed is True
        assert d.explanation == "Default allow"

    @responses.activate
    def test_deny_decision(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            json={"decision": "DENY", "explanation": "Blocked by policy",
                  "policy_id": "pol-1", "rule_name": "block-ext"},
            status=200)
        agent = make_agent()
        d = agent.check("http_request", domain="evil.com")
        assert d.denied is True
        assert d.policy_id == "pol-1"

    @responses.activate
    def test_require_approval_decision(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            json={"decision": "REQUIRE_APPROVAL", "explanation": "Needs review",
                  "approval_id": "apr-123"},
            status=200)
        agent = make_agent()
        d = agent.check("http_request", domain="sensitive.com")
        assert d.requires_approval is True
        assert d.approval_id == "apr-123"

    @responses.activate
    def test_redact_decision(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            json={"decision": "REDACT", "explanation": "Fields masked",
                  "redacted_fields": ["request.headers.authorization"]},
            status=200)
        agent = make_agent()
        d = agent.check("http_request", domain="api.example.com")
        assert d.redacted is True
        assert "request.headers.authorization" in d.redacted_fields

    @responses.activate
    def test_custom_tool_name(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/my_custom_tool",
            json={"decision": "ALLOW", "explanation": "ok"},
            status=200)
        agent = make_agent()
        d = agent.check("http_request", tool_name="my_custom_tool",
                         domain="api.example.com")
        assert d.allowed is True

    @responses.activate
    def test_send_message_action(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/send_message_tool",
            json={"decision": "ALLOW", "explanation": "ok"},
            status=200)
        agent = make_agent()
        d = agent.check("send_message", recipient="user@example.com")
        assert d.allowed is True

    @responses.activate
    def test_query_db_action(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/query_db_tool",
            json={"decision": "ALLOW", "explanation": "ok"},
            status=200)
        agent = make_agent()
        d = agent.check("query_db", db="production", table="users")
        assert d.allowed is True


# ═══════════════════════════════════════════════════════════════
# Category E: Fail-closed — connection error, timeout, HTTP 5xx
# ═══════════════════════════════════════════════════════════════

class TestFailClosed:
    @responses.activate
    def test_connection_error(self):
        # No mock registered → ConnectionError
        agent = make_agent()
        d = agent.check("http_request", domain="api.example.com")
        assert d.denied is True
        assert "unreachable" in d.explanation.lower()

    @responses.activate
    def test_http_500(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            json={"error": "internal"}, status=500)
        agent = make_agent()
        d = agent.check("http_request", domain="api.example.com")
        assert d.denied is True
        assert "500" in d.explanation

    @responses.activate
    def test_http_422(self):
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            json={"detail": "validation error"}, status=422)
        agent = make_agent()
        d = agent.check("http_request", domain="api.example.com")
        assert d.denied is True
        assert "422" in d.explanation


# ═══════════════════════════════════════════════════════════════
# Category F: ActionEvent.to_dict()
# ═══════════════════════════════════════════════════════════════

class TestActionEvent:
    def test_to_dict_required_fields(self):
        event = ActionEvent(
            tenant_id="t1", agent_id="a1", action_type="http_request",
            tool_name="curl", target={"domain": "example.com"},
            environment="dev",
        )
        d = event.to_dict()
        assert d["tenant_id"] == "t1"
        assert d["agent_id"] == "a1"
        assert d["action_type"] == "http_request"
        assert d["tool"]["name"] == "curl"
        assert d["target"]["domain"] == "example.com"
        assert d["environment"] == "dev"
        assert "session_id" in d

    def test_to_dict_context_and_request(self):
        event = ActionEvent(
            tenant_id="t1", agent_id="a1", action_type="query_db",
            tool_name="pg", target={"db": "prod"},
            request={"body": {"query": "SELECT 1"}},
            context={"tags": ["sensitive"]},
        )
        d = event.to_dict()
        assert d["request"]["body"]["query"] == "SELECT 1"
        assert "sensitive" in d["context"]["tags"]


# ═══════════════════════════════════════════════════════════════
# Category G: GovernanceError
# ═══════════════════════════════════════════════════════════════

class TestGovernanceError:
    def test_has_decision_attribute(self):
        d = Decision(decision="DENY", explanation="no")
        err = GovernanceError("blocked", d)
        assert err.decision is d
        assert str(err) == "blocked"

    def test_is_exception(self):
        d = Decision(decision="DENY", explanation="no")
        with pytest.raises(GovernanceError):
            raise GovernanceError("test", d)


# ═══════════════════════════════════════════════════════════════
# Category H: LangChain adapters (no langchain installed)
# ═══════════════════════════════════════════════════════════════

class TestLangChainAdapters:
    def test_as_langchain_tool_import_error(self):
        agent = make_agent()
        with pytest.raises(ImportError, match="langchain"):
            agent.as_langchain_tool(lambda x: x)

    def test_as_langchain_callback_import_error(self):
        agent = make_agent()
        with pytest.raises(ImportError, match="langchain"):
            agent.as_langchain_callback()


# ═══════════════════════════════════════════════════════════════
# Category I: Edge cases
# ═══════════════════════════════════════════════════════════════

class TestEdgeCases:
    @responses.activate
    def test_timeout(self):
        """Gateway timeout → fail-closed DENY."""
        import requests as req
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            body=req.exceptions.Timeout("read timed out"))
        agent = make_agent()
        d = agent.check("http_request", domain="slow.com")
        assert d.denied is True
        assert "timeout" in d.explanation.lower()

    @responses.activate
    def test_payload_contains_all_fields(self):
        """Verify the full ActionEvent payload is sent to the gateway."""
        responses.add(responses.POST, f"{GW}/v1/invoke/http_request_tool",
            json={"decision": "ALLOW", "explanation": "ok"}, status=200)
        agent = make_agent(data_class="confidential", tags=["pii"])
        agent.check("http_request", domain="api.example.com", method="POST",
                     body={"key": "val"}, headers={"X-Custom": "yes"})
        payload = json.loads(responses.calls[0].request.body)
        assert payload["tenant_id"] == "00000000-0000-0000-0000-000000000001"
        assert payload["agent_id"] == "test-agent"
        assert payload["action_type"] == "http_request"
        assert payload["target"]["domain"] == "api.example.com"
        assert payload["target"]["method"] == "POST"
        assert payload["request"]["body"] == {"key": "val"}
        assert payload["request"]["headers"]["X-Custom"] == "yes"
        assert payload["context"]["data_class"] == "confidential"
        assert "pii" in payload["context"]["tags"]

    def test_decision_defaults(self):
        """Decision with minimal fields has sane defaults."""
        d = Decision(decision="ALLOW", explanation="ok")
        assert d.policy_id is None
        assert d.rule_name is None
        assert d.approval_id is None
        assert d.redacted_fields == []
        assert d.raw == {}
