"""
Solari — The Deep Knowledge Engine

Turn anything into a searchable knowledge brain.
Make any LLM an expert. Zero hallucination on covered domains.

https://solarisystems.net
https://github.com/SolariResearch/solari
"""

__version__ = "0.2.0"
__author__ = "Solari Systems"
