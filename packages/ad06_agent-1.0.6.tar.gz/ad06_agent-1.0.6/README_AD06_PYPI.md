# ad06-agent

Agente de automação desktop (Windows): UI Automation, mapeamento de ambiente, relay **WebSocket** e bridge **HTTP** `POST /command` para integração com o painel Orb Logic (FastAPI + Playwright + visão xAI/Grok).

## Instalação

```bash
pip install -U ad06-agent
playwright install chromium
```

## CLI

- **`ad06-agent`** — Typer: `start`, `stop`, `status`, `config`, etc. (servidor WebSocket; não confundir com a porta do bridge HTTP).
- **`ad06-http-bridge`** — Servidor HTTP do Orb (`/command`, porta padrão 8765).

```bash
ad06-http-bridge --port 8765
# ou
python -m agente_ad06.http_bridge
```

Variável opcional: `ORB_LOGIC_PROJECT_ROOT` — pasta onde procurar `.env` (chaves `XAI_API_KEY` / `GROK_API_KEY` para computer use).

## Publicar nova versão (mantenedores)

Ver `docs/PUBLISH_AD06_AGENT_PYPI.md`.
