"""Bridge HTTP FastAPI (`POST /command`) para o painel Orb Logic."""
