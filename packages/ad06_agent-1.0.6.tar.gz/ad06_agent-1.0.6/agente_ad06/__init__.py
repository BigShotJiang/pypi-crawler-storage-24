# Ad06 Agent — Agente de Automacao Desktop
__version__ = "1.0.6"
__author__  = "Adielson Sousa"