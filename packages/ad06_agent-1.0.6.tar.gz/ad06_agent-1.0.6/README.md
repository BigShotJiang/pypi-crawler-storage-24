# Orb Logic (Ad06)

App web (**Vite + React + TypeScript + Supabase + shadcn/ui**). O **backend oficial** é o **Supabase**; a **voz** pode usar a integração **ElevenLabs** já ligada ao projeto.

O **agente de automação desktop** não roda dentro do Node: é um pacote **Python no PyPI**, instalado na máquina do usuário. Integração com o chat: o front envia `POST /command` para a URL configurada (ver abaixo).

- **Documentação do agente local:** [docs/AGENTE_LOCAL.md](./docs/AGENTE_LOCAL.md)
- **Tokens PyPI (publicar / índice privado):** [docs/PYPI_TOKENS.md](./docs/PYPI_TOKENS.md)
- **Agente PyPI:** `pip install -U ad06-agent` — inclui núcleo + bridge HTTP `POST /command` (Playwright, visão, etc.). Publicação: [docs/PUBLISH_AD06_AGENT_PYPI.md](./docs/PUBLISH_AD06_AGENT_PYPI.md).
- **Dev:** com o venv (`.venv-agent`), **`npm run dev`** sobe site + bridge (`scripts/ad06_http_command_server.py` → `agente_ad06.http_bridge`). Só interface: `npm run dev:web`. Ver [docs/AGENTE_LOCAL.md](./docs/AGENTE_LOCAL.md).
- **Instalação automatizada (venv):** `scripts/install-local-agent.ps1 -Package ad06-agent`.
- **Variável opcional no front:** `VITE_DESKTOP_AGENT_URL` (ex.: `http://localhost:8765`); modelo em [.env.example](./.env.example).

Pastas como `Ad06-VoiceAPI/` e o código em `desktop-agent/` são **opcionais** se você já usa apenas Supabase + ElevenLabs.

---

# Welcome to your Lovable project

## Project info

**URL**: https://lovable.dev/projects/REPLACE_WITH_PROJECT_ID

## How can I edit this code?

There are several ways of editing your application.

**Use Lovable**

Simply visit the [Lovable Project](https://lovable.dev/projects/REPLACE_WITH_PROJECT_ID) and start prompting.

Changes made via Lovable will be committed automatically to this repo.

**Use your preferred IDE**

If you want to work locally using your own IDE, you can clone this repo and push changes. Pushed changes will also be reflected in Lovable.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Install the local desktop agent (Python venv at project root — see docs/AGENTE_LOCAL.md), then start dev (site + agent together):
npm run dev
# Frontend only (no desktop agent): npm run dev:web
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

Simply open [Lovable](https://lovable.dev/projects/REPLACE_WITH_PROJECT_ID) and click on Share -> Publish.

## Can I connect a custom domain to my Lovable project?

Yes, you can!

To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.

Read more here: [Setting up a custom domain](https://docs.lovable.dev/features/custom-domain#custom-domain)
