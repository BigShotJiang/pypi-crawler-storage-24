from setuptools import find_packages, setup


setup(
    name="beyond_accuracy",
    version="0.1.0",
    description="Ethical risk evaluation for machine learning models.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Beyond Accuracy",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "numpy>=1.26.0",
        "pandas>=2.2.0",
        "scikit-learn>=1.5.0",
        "streamlit>=1.40.0",
        "plotly>=5.24.0",
        "reportlab>=4.2.0",
    ],
    entry_points={
        "console_scripts": [
            "beyond-audit=beyond_accuracy.cli:main",
        ]
    },
    python_requires=">=3.10",
)
