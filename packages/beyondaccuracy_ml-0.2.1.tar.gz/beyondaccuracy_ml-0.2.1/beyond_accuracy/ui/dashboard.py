"""Streamlit dashboard for beyond_accuracy."""

from __future__ import annotations

import argparse
import json
import pickle
import subprocess
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from beyond_accuracy import evaluate


DECISION_STYLES = {
    "APPROVE": ("success", "Low ethical risk. Deployment can proceed with standard monitoring."),
    "CAUTION": ("warning", "Moderate ethical risk. Review the highlighted modules before deployment."),
    "BLOCK": ("error", "High ethical risk. Resolve the highlighted issues before deployment."),
}


def load_report(path: str | Path = "report.json") -> dict[str, Any]:
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle)


def _build_baseline_model(data: pd.DataFrame, target: str) -> Any:
    feature_frame = data.drop(columns=[target])
    numeric_columns = feature_frame.select_dtypes(include=["number"]).columns.tolist()
    categorical_columns = [col for col in feature_frame.columns if col not in numeric_columns]

    preprocessor = ColumnTransformer(
        transformers=[
            (
                "num",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="median")),
                        ("scaler", StandardScaler()),
                    ]
                ),
                numeric_columns,
            ),
            (
                "cat",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("encoder", OneHotEncoder(handle_unknown="ignore")),
                    ]
                ),
                categorical_columns,
            ),
        ]
    )

    model = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("classifier", LogisticRegression(max_iter=1000)),
        ]
    )
    model.fit(feature_frame, data[target])
    return model


def _load_pickled_model(uploaded_model) -> Any:
    if uploaded_model is None:
        return None
    return pickle.loads(uploaded_model.read())


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--data")
    parser.add_argument("--target")
    parser.add_argument("--sensitive", nargs="*")
    parser.add_argument("--model")
    parser.add_argument("--report-json")
    args, _ = parser.parse_known_args()
    return args


def _read_prefill_dataset(args: argparse.Namespace) -> pd.DataFrame | None:
    if args.data and Path(args.data).exists():
        return pd.read_csv(args.data)
    return None


def _load_prefill_report(args: argparse.Namespace) -> dict[str, Any] | None:
    if args.report_json and Path(args.report_json).exists():
        return load_report(args.report_json)
    return None


def _decision_banner(decision: str) -> None:
    banner_type, message = DECISION_STYLES.get(decision, ("info", decision))
    if banner_type == "success":
        st.success(f"{decision}: {message}")
    elif banner_type == "warning":
        st.warning(f"{decision}: {message}")
    elif banner_type == "error":
        st.error(f"{decision}: {message}")
    else:
        st.info(decision)


def _build_module_dataframe(report: dict[str, Any]) -> pd.DataFrame:
    scores = report.get("module_scores", {})
    return pd.DataFrame(scores.items(), columns=["Module", "Score"])


def _render_risk_gauge(risk_score: float) -> go.Figure:
    figure = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=float(risk_score),
            number={"valueformat": ".3f"},
            gauge={
                "axis": {"range": [0, 1]},
                "bar": {"color": "#0f172a"},
                "steps": [
                    {"range": [0, 0.3], "color": "#bbf7d0"},
                    {"range": [0.3, 0.6], "color": "#fde68a"},
                    {"range": [0.6, 1.0], "color": "#fecaca"},
                ],
            },
            title={"text": "Ethical Risk Score"},
        )
    )
    figure.update_layout(height=320, margin=dict(l=20, r=20, t=60, b=20))
    return figure


def _render_report(report: dict[str, Any], report_path: str | None = None) -> None:
    risk_score = float(report.get("risk_score", 0.0))
    decision = str(report.get("decision", "UNKNOWN"))
    module_df = _build_module_dataframe(report)

    st.subheader("Risk Summary")
    top_left, top_middle, top_right = st.columns([1, 1, 1.2])
    top_left.metric("Ethical Risk Score", f"{risk_score:.3f}")
    top_middle.metric("Decision", decision)
    with top_right:
        if report_path:
            st.caption(f"Loaded from: {Path(report_path).resolve()}")
        _decision_banner(decision)

    st.divider()

    chart_left, chart_right = st.columns(2)
    with chart_left:
        st.plotly_chart(_render_risk_gauge(risk_score), use_container_width=True)
    with chart_right:
        pie_figure = px.pie(
            module_df,
            names="Module",
            values="Score",
            title="Risk Distribution by Module",
            hole=0.45,
        )
        pie_figure.update_layout(height=320, margin=dict(l=20, r=20, t=60, b=20))
        st.plotly_chart(pie_figure, use_container_width=True)

    st.subheader("Module Scores")
    bar_figure = px.bar(
        module_df,
        x="Module",
        y="Score",
        text="Score",
        color="Score",
        color_continuous_scale="RdYlGn_r",
        range_y=[0, 1],
        title="Module-Level Ethical Risk",
    )
    bar_figure.update_layout(coloraxis_showscale=False, height=420)
    st.plotly_chart(bar_figure, use_container_width=True)

    bias_details = report.get("details", {}).get("bias", {}).get("attributes", {})
    if bias_details:
        st.subheader("Sensitive Attribute Comparison")
        bias_rows = []
        for attribute_name, values in bias_details.items():
            bias_rows.append(
                {
                    "Attribute": attribute_name,
                    "SPD": values.get("statistical_parity_difference", 0.0),
                    "EOD": values.get("equal_opportunity_difference", 0.0),
                    "Attribute Risk": values.get("attribute_risk", 0.0),
                }
            )
        bias_df = pd.DataFrame(bias_rows)
        bias_fig = px.bar(
            bias_df,
            x="Attribute",
            y=["SPD", "EOD", "Attribute Risk"],
            barmode="group",
            title="Bias Metrics Across Sensitive Attributes",
        )
        st.plotly_chart(bias_fig, use_container_width=True)

    detail_left, detail_right = st.columns([1.1, 0.9])
    with detail_left:
        st.subheader("Evaluation Details")
        st.json(report, expanded=False)
    with detail_right:
        st.subheader("Downloads")
        json_payload = json.dumps(report, indent=2, sort_keys=True)
        st.download_button(
            label="Download JSON Report",
            data=json_payload,
            file_name="ethical_report.json",
            mime="application/json",
            use_container_width=True,
        )

        pdf_source_path = report_path.replace(".json", ".pdf") if report_path and report_path.endswith(".json") else None
        if pdf_source_path and Path(pdf_source_path).exists():
            pdf_bytes = Path(pdf_source_path).read_bytes()
            st.download_button(
                label="Download PDF Report",
                data=pdf_bytes,
                file_name=Path(pdf_source_path).name,
                mime="application/pdf",
                use_container_width=True,
            )
        else:
            st.info("A saved PDF report was not found for this session. Run an evaluation to generate one.")


def launch_dashboard(
    report_json_path: str | Path | None = None,
    data_path: str | Path | None = None,
    target: str | None = None,
    sensitive: list[str] | None = None,
    model_path: str | Path | None = None,
) -> None:
    dashboard_path = Path(__file__).resolve()
    command = [sys.executable, "-m", "streamlit", "run", str(dashboard_path)]

    streamlit_args: list[str] = []
    if report_json_path:
        streamlit_args.extend(["--report-json", str(Path(report_json_path).resolve())])
    if data_path:
        streamlit_args.extend(["--data", str(Path(data_path).resolve())])
    if target:
        streamlit_args.extend(["--target", target])
    if sensitive:
        streamlit_args.extend(["--sensitive", *sensitive])
    if model_path:
        streamlit_args.extend(["--model", str(Path(model_path).resolve())])
    if streamlit_args:
        command.extend(["--", *streamlit_args])

    subprocess.run(command, check=False)


def render_dashboard() -> None:
    st.set_page_config(page_title="Beyond Accuracy - Ethical Risk Dashboard", layout="wide")
    st.title("Beyond Accuracy - Ethical Risk Dashboard")
    st.caption("Visualize ethical risk, fairness, privacy, robustness, and dataset health in one place.")

    args = _parse_args()
    prefill_df = _read_prefill_dataset(args)
    initial_report = _load_prefill_report(args)

    st.sidebar.header("Inputs")
    uploaded_report = st.sidebar.file_uploader("Upload report JSON", type=["json"])
    uploaded_file = st.sidebar.file_uploader("Upload dataset CSV", type=["csv"])
    uploaded_model = st.sidebar.file_uploader("Optional model pickle", type=["pkl", "pickle"])

    report_from_upload = None
    if uploaded_report is not None:
        report_from_upload = json.loads(uploaded_report.read().decode("utf-8"))

    report_to_render = report_from_upload or initial_report
    active_report_path = args.report_json if initial_report and not report_from_upload else None

    df = pd.read_csv(uploaded_file) if uploaded_file else prefill_df

    if report_to_render is not None:
        _render_report(report_to_render, report_path=active_report_path)
        st.divider()

    st.subheader("Run New Evaluation")
    if df is None:
        st.info("Upload a CSV dataset from the sidebar to run a new evaluation, or launch the dashboard with an existing report JSON.")
        return

    preview_col, input_col = st.columns([1.1, 0.9])
    with preview_col:
        st.markdown("**Dataset Preview**")
        st.dataframe(df.head(), use_container_width=True)

    default_target_index = 0
    if args.target and args.target in df.columns:
        default_target_index = list(df.columns).index(args.target)

    with input_col:
        target = st.selectbox("Target column", options=df.columns.tolist(), index=default_target_index)
        sensitive_default = [column for column in (args.sensitive or []) if column in df.columns and column != target]
        sensitive = st.multiselect(
            "Sensitive attributes",
            options=[column for column in df.columns if column != target],
            default=sensitive_default,
        )
        run_clicked = st.button("Run Ethical Evaluation", type="primary", use_container_width=True)

    if not run_clicked:
        return

    with st.spinner("Evaluating model and preparing dashboard visuals..."):
        model = _load_pickled_model(uploaded_model)
        if model is None and args.model and Path(args.model).exists():
            model = pickle.loads(Path(args.model).read_bytes())
        if model is None:
            model = _build_baseline_model(df, target)

        report = evaluate(model=model, data=df, target=target, sensitive=sensitive)
        report_dict = report.to_dict()
        if "report_output_path" in st.session_state:
            report_json_path = Path(st.session_state["report_output_path"])
        else:
            report_json_path = Path.cwd() / "ethical_report.json"
        report.save_json(report_json_path)
        report.save_pdf(report_json_path.with_suffix(".pdf"))

    st.success("Evaluation complete. The dashboard below reflects the latest report.")
    _render_report(report_dict, report_path=str(report_json_path))


if __name__ == "__main__":
    render_dashboard()
