"""PDF export helpers for ethical reports."""

from __future__ import annotations

from io import BytesIO


def render_pdf_bytes(report_payload: dict) -> bytes:
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "PDF export requires the 'reportlab' package. Install beyond_accuracy with its PDF dependencies."
        ) from exc

    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = [
        Paragraph("Beyond Accuracy Ethical Risk Report", styles["Title"]),
        Spacer(1, 12),
        Paragraph(
            f"Risk Score: {report_payload['risk_score']:.3f} | Decision: {report_payload['decision']}",
            styles["Heading2"],
        ),
        Spacer(1, 12),
    ]

    module_rows = [["Module", "Score"]]
    for module_name, score in report_payload["module_scores"].items():
        module_rows.append([module_name, f"{score:.3f}"])

    module_table = Table(module_rows, hAlign="LEFT")
    module_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0f172a")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
                ("PADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    elements.append(module_table)
    elements.append(Spacer(1, 16))

    details = report_payload.get("details", {})
    for section_name, section_body in details.items():
        elements.append(Paragraph(section_name.replace("_", " ").title(), styles["Heading3"]))
        if isinstance(section_body, dict):
            detail_rows = [["Metric", "Value"]]
            for key, value in section_body.items():
                detail_rows.append([str(key), str(value)])
            detail_table = Table(detail_rows, hAlign="LEFT")
            detail_table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                        ("PADDING", (0, 0), (-1, -1), 6),
                    ]
                )
            )
            elements.append(detail_table)
        else:
            elements.append(Paragraph(str(section_body), styles["BodyText"]))
        elements.append(Spacer(1, 12))

    document.build(elements)
    return buffer.getvalue()
