"""Report generation utilities."""

from __future__ import annotations

import json
from pathlib import Path

from .pdf_export import render_pdf_bytes


def report_to_json(report_payload: dict, indent: int = 2) -> str:
    return json.dumps(report_payload, indent=indent, sort_keys=True)


def save_json_report(report_payload: dict, path: str | Path, indent: int = 2) -> Path:
    destination = Path(path)
    destination.write_text(report_to_json(report_payload, indent=indent), encoding="utf-8")
    return destination


def save_pdf_report(report_payload: dict, path: str | Path) -> Path:
    destination = Path(path)
    destination.write_bytes(render_pdf_bytes(report_payload))
    return destination
