"""Core evaluator and public API."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .metrics.bias import bias_risk_score
from .metrics.dataset import dataset_health_score
from .metrics.explainability import explainability_risk
from .metrics.privacy import privacy_risk_score
from .metrics.robustness import robustness_risk
from .report.pdf_export import render_pdf_bytes
from .report.report_generator import report_to_json, save_json_report, save_pdf_report


def _validate_inputs(
    data: pd.DataFrame,
    target: str,
    sensitive: list[str],
) -> None:
    if not isinstance(data, pd.DataFrame):
        raise TypeError("data must be a pandas DataFrame.")
    if target not in data.columns:
        raise ValueError(f"Target column '{target}' does not exist in the dataset.")
    missing_sensitive = [column for column in sensitive if column not in data.columns]
    if missing_sensitive:
        raise ValueError(
            "Sensitive columns not found in dataset: " + ", ".join(missing_sensitive)
        )
    if target in sensitive:
        raise ValueError("Target column cannot also be listed as sensitive.")


def _normalize_predictions(predictions: Any, index: pd.Index) -> pd.Series:
    values = np.asarray(predictions)
    if values.ndim > 1:
        if values.shape[1] == 1:
            values = values[:, 0]
        else:
            values = np.argmax(values, axis=1)
    return pd.Series(values, index=index)


def _safe_predict(model: Any, features: pd.DataFrame) -> pd.Series:
    try:
        predictions = model.predict(features)
    except Exception as exc:
        raise ValueError(
            "Model prediction failed. Pass a fitted estimator or sklearn Pipeline "
            "that can predict on the provided feature frame."
        ) from exc
    return _normalize_predictions(predictions, features.index)


@dataclass
class EthicalReport:
    risk_score: float
    decision: str
    module_scores: dict[str, float]
    details: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "risk_score": round(float(self.risk_score), 6),
            "decision": self.decision,
            "module_scores": {
                key: round(float(value), 6) for key, value in self.module_scores.items()
            },
            "details": self.details,
            "metadata": self.metadata,
        }

    def to_json(self, indent: int = 2) -> str:
        return report_to_json(self.to_dict(), indent=indent)

    def save_json(self, path: str | Path, indent: int = 2) -> Path:
        return save_json_report(self.to_dict(), path, indent=indent)

    def save_pdf(self, path: str | Path) -> Path:
        return save_pdf_report(self.to_dict(), path)

    def to_pdf_bytes(self) -> bytes:
        return render_pdf_bytes(self.to_dict())


class EthicalEvaluator:
    def __init__(
        self,
        domain: str = "general",
        weights: dict[str, float] | None = None,
    ) -> None:
        self.domain = domain
        self.weights = weights or {
            "dataset": 0.2,
            "bias": 0.3,
            "explainability": 0.2,
            "privacy": 0.2,
            "robustness": 0.1,
        }

    def evaluate(
        self,
        model: Any,
        data: pd.DataFrame,
        target: str,
        sensitive: list[str],
        noise_level: float = 0.05,
        random_state: int = 42,
    ) -> EthicalReport:
        _validate_inputs(data=data, target=target, sensitive=sensitive)

        working_data = data.copy()
        y_true = working_data[target]
        feature_frame = working_data.drop(columns=[target])
        sensitive_attrs = {column: working_data[column] for column in sensitive}

        y_pred = _safe_predict(model, feature_frame)

        dataset_result = dataset_health_score(working_data, target)
        bias_result = bias_risk_score(y_true, y_pred, sensitive_attrs)
        explainability_result = explainability_risk(model)
        privacy_result = privacy_risk_score(working_data, target, sensitive)
        robustness_result = robustness_risk(
            model=model,
            features=feature_frame,
            y_true=y_true,
            noise_level=noise_level,
            random_state=random_state,
        )

        module_scores = {
            "Dataset": dataset_result.score,
            "Bias": bias_result.score,
            "Explainability": explainability_result.score,
            "Privacy": privacy_result.score,
            "Robustness": robustness_result.score,
        }

        weighted_risk = sum(
            module_scores[module_name] * self.weights[module_name.lower()]
            for module_name in module_scores
        )
        weighted_risk = float(np.clip(weighted_risk, 0.0, 1.0))

        if weighted_risk <= 0.3:
            decision = "APPROVE"
        elif weighted_risk <= 0.6:
            decision = "CAUTION"
        else:
            decision = "BLOCK"

        return EthicalReport(
            risk_score=weighted_risk,
            decision=decision,
            module_scores=module_scores,
            details={
                "dataset": dataset_result.details,
                "bias": bias_result.details,
                "explainability": explainability_result.details,
                "privacy": privacy_result.details,
                "robustness": robustness_result.details,
            },
            metadata={
                "domain": self.domain,
                "target": target,
                "sensitive_attributes": sensitive,
                "evaluated_at_utc": datetime.now(timezone.utc).isoformat(),
                "weights": json.loads(json.dumps(self.weights)),
            },
        )


def evaluate(
    model: Any,
    data: pd.DataFrame,
    target: str,
    sensitive: list[str],
    domain: str = "general",
    noise_level: float = 0.05,
    random_state: int = 42,
    launch_ui: bool = False,
    json_path: str | Path = "ethical_report.json",
    pdf_path: str | Path = "ethical_report.pdf",
    model_path: str | Path | None = None,
) -> EthicalReport:
    evaluator = EthicalEvaluator(domain=domain)
    report = evaluator.evaluate(
        model=model,
        data=data,
        target=target,
        sensitive=sensitive,
        noise_level=noise_level,
        random_state=random_state,
    )

    if launch_ui:
        saved_json_path = report.save_json(json_path)
        report.save_pdf(pdf_path)
        from .ui.dashboard import launch_dashboard

        launch_dashboard(
            report_json_path=saved_json_path,
            data_path=None,
            target=target,
            sensitive=sensitive,
            model_path=model_path,
        )

    return report
