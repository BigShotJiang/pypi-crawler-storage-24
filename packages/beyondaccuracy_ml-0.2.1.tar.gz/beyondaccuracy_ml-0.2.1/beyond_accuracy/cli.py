"""Command line interface for beyond_accuracy."""

from __future__ import annotations

import argparse
import pickle
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from . import evaluate
from .ui.dashboard import launch_dashboard


def _build_baseline_model(data: pd.DataFrame, target: str):
    feature_frame = data.drop(columns=[target])
    numeric_columns = feature_frame.select_dtypes(include=["number"]).columns.tolist()
    categorical_columns = [col for col in feature_frame.columns if col not in numeric_columns]

    preprocessor = ColumnTransformer(
        transformers=[
            (
                "num",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="median")),
                        ("scaler", StandardScaler()),
                    ]
                ),
                numeric_columns,
            ),
            (
                "cat",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("encoder", OneHotEncoder(handle_unknown="ignore")),
                    ]
                ),
                categorical_columns,
            ),
        ]
    )

    model = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("classifier", LogisticRegression(max_iter=1000)),
        ]
    )
    model.fit(feature_frame, data[target])
    return model


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="beyond-audit",
        description="Run an ethical risk evaluation and optionally launch the Streamlit dashboard.",
    )
    parser.add_argument("--data", required=True, help="Path to a CSV dataset.")
    parser.add_argument("--target", required=True, help="Target column name.")
    parser.add_argument(
        "--sensitive",
        nargs="+",
        default=[],
        help="One or more sensitive attribute columns.",
    )
    parser.add_argument(
        "--model",
        help="Optional pickle file containing a fitted estimator or sklearn Pipeline.",
    )
    parser.add_argument(
        "--json-out",
        default="ethical_report.json",
        help="Where to save the JSON report.",
    )
    parser.add_argument(
        "--pdf-out",
        default="ethical_report.pdf",
        help="Where to save the PDF report.",
    )
    parser.add_argument(
        "--ui",
        action="store_true",
        help="Launch the Streamlit dashboard after evaluation.",
    )
    parser.add_argument(
        "--no-ui",
        action="store_true",
        help="Skip launching the Streamlit dashboard.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    data = pd.read_csv(args.data)

    if args.model:
        model = pickle.loads(Path(args.model).read_bytes())
    else:
        model = _build_baseline_model(data, args.target)

    report = evaluate(
        model=model,
        data=data,
        target=args.target,
        sensitive=args.sensitive,
    )
    json_path = report.save_json(args.json_out)
    pdf_path = report.save_pdf(args.pdf_out)

    print(report.to_json(indent=2))
    print(f"JSON report saved to {Path(json_path).resolve()}")
    print(f"PDF report saved to {Path(pdf_path).resolve()}")

    should_launch_ui = args.ui or not args.no_ui
    if should_launch_ui:
        launch_dashboard(
            report_json_path=json_path,
            data_path=args.data,
            target=args.target,
            sensitive=args.sensitive,
            model_path=args.model,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
