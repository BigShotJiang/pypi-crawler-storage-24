"""Public package interface for beyond_accuracy."""

from .evaluator import EthicalEvaluator, EthicalReport, evaluate

__all__ = ["EthicalEvaluator", "EthicalReport", "evaluate"]

__version__ = "0.1.0"
