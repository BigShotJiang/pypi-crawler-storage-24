"""Bias and group fairness metrics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class BiasMetricResult:
    score: float
    details: dict[str, Any]


def _safe_rate(values: np.ndarray) -> float:
    if values.size == 0:
        return 0.0
    return float(np.mean(values))


def infer_positive_label(y_true: pd.Series) -> Any:
    unique_values = [value for value in pd.Series(y_true).dropna().unique().tolist()]
    if not unique_values:
        raise ValueError("Target column must contain at least one non-null value.")
    if len(unique_values) == 1:
        return unique_values[0]

    normalized_map = {str(value).strip().lower(): value for value in unique_values}
    for candidate in ("1", "true", "yes", "approved", "approve", "positive", "pass"):
        if candidate in normalized_map:
            return normalized_map[candidate]

    try:
        return sorted(unique_values)[-1]
    except TypeError:
        return unique_values[-1]


def statistical_parity_difference(y_pred: pd.Series, sensitive: pd.Series) -> float:
    frame = pd.DataFrame({"prediction": y_pred, "group": sensitive}).dropna()
    if frame.empty or frame["group"].nunique() < 2:
        return 0.0

    group_rates = frame.groupby("group")["prediction"].mean()
    return float(np.clip(group_rates.max() - group_rates.min(), 0.0, 1.0))


def equal_opportunity_difference(
    y_true: pd.Series,
    y_pred: pd.Series,
    sensitive: pd.Series,
    positive_label: Any,
) -> float:
    frame = pd.DataFrame(
        {"actual": y_true, "prediction": y_pred, "group": sensitive}
    ).dropna()
    if frame.empty or frame["group"].nunique() < 2:
        return 0.0

    frame = frame[frame["actual"] == positive_label]
    if frame.empty:
        return 0.0

    true_positive_rates = []
    for _, group_frame in frame.groupby("group"):
        true_positive_rates.append(
            _safe_rate((group_frame["prediction"] == positive_label).astype(float).to_numpy())
        )

    return float(np.clip(max(true_positive_rates) - min(true_positive_rates), 0.0, 1.0))


def bias_risk_score(
    y_true: pd.Series,
    y_pred: pd.Series,
    sensitive_attrs: dict[str, pd.Series],
    positive_label: Any | None = None,
) -> BiasMetricResult:
    positive = infer_positive_label(y_true) if positive_label is None else positive_label
    attribute_details: dict[str, dict[str, float]] = {}
    scores: list[float] = []

    for attribute_name, attribute_values in sensitive_attrs.items():
        spd = statistical_parity_difference(y_pred, attribute_values)
        eod = equal_opportunity_difference(y_true, y_pred, attribute_values, positive)
        combined = float(np.clip(np.mean([spd, eod]), 0.0, 1.0))
        attribute_details[attribute_name] = {
            "statistical_parity_difference": round(spd, 6),
            "equal_opportunity_difference": round(eod, 6),
            "attribute_risk": round(combined, 6),
        }
        scores.append(combined)

    overall = float(np.clip(np.mean(scores), 0.0, 1.0)) if scores else 0.0
    return BiasMetricResult(
        score=overall,
        details={
            "positive_label": positive,
            "attributes": attribute_details,
        },
    )
