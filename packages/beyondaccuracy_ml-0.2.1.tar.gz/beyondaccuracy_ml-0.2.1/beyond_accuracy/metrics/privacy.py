"""Privacy risk heuristics."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class PrivacyMetricResult:
    score: float
    details: dict[str, float]


def privacy_risk_score(
    data: pd.DataFrame,
    target: str,
    sensitive: list[str],
) -> PrivacyMetricResult:
    feature_frame = data.drop(columns=[target], errors="ignore")
    feature_count = max(feature_frame.shape[1], 1)
    sensitive_count = len(sensitive)
    sensitive_ratio = sensitive_count / feature_count

    if feature_frame.empty:
        unique_record_ratio = 1.0
    else:
        unique_record_ratio = float(feature_frame.drop_duplicates().shape[0] / len(feature_frame))

    risk = float(np.clip(0.7 * sensitive_ratio + 0.3 * unique_record_ratio, 0.0, 1.0))
    return PrivacyMetricResult(
        score=risk,
        details={
            "sensitive_feature_count": float(sensitive_count),
            "total_feature_count": float(feature_count),
            "sensitive_ratio": round(sensitive_ratio, 6),
            "unique_record_ratio": round(unique_record_ratio, 6),
        },
    )
