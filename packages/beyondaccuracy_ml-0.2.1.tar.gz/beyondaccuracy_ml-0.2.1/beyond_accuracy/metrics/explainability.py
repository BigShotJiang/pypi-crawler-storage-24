"""Explainability heuristics for fitted models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class ExplainabilityMetricResult:
    score: float
    details: dict[str, Any]


def _unwrap_estimator(model: Any) -> Any:
    if hasattr(model, "named_steps") and model.named_steps:
        return list(model.named_steps.values())[-1]
    if hasattr(model, "steps") and model.steps:
        return model.steps[-1][1]
    return model


def explainability_risk(model: Any) -> ExplainabilityMetricResult:
    estimator = _unwrap_estimator(model)
    has_linear_coefficients = hasattr(estimator, "coef_")
    has_feature_importance = hasattr(estimator, "feature_importances_")
    has_predict_proba = hasattr(model, "predict_proba")

    if has_linear_coefficients or has_feature_importance:
        base_risk = 0.2
    elif has_predict_proba:
        base_risk = 0.45
    else:
        base_risk = 0.8

    complexity_penalty = 0.0
    if hasattr(estimator, "n_estimators"):
        try:
            complexity_penalty = min(float(estimator.n_estimators) / 1000.0, 0.15)
        except (TypeError, ValueError):
            complexity_penalty = 0.0

    score = float(np.clip(base_risk + complexity_penalty, 0.0, 1.0))
    return ExplainabilityMetricResult(
        score=score,
        details={
            "estimator_type": type(estimator).__name__,
            "has_coefficients": has_linear_coefficients,
            "has_feature_importance": has_feature_importance,
            "has_predict_proba": has_predict_proba,
        },
    )
