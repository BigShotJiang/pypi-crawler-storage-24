"""Dataset quality and health metrics."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class DatasetMetricResult:
    score: float
    details: dict[str, float]


def dataset_health_score(data: pd.DataFrame, target: str) -> DatasetMetricResult:
    if target not in data.columns:
        raise ValueError(f"Target column '{target}' is not present in the dataset.")

    row_count = len(data)
    if row_count == 0:
        raise ValueError("Dataset must contain at least one row.")

    target_distribution = data[target].value_counts(normalize=True, dropna=False)
    class_imbalance = float(target_distribution.max()) if not target_distribution.empty else 1.0
    missing_ratio = float(data.isna().mean().mean())
    duplicate_ratio = float(data.duplicated().mean())

    risk = float(
        np.clip(
            0.5 * class_imbalance + 0.3 * missing_ratio + 0.2 * duplicate_ratio,
            0.0,
            1.0,
        )
    )

    return DatasetMetricResult(
        score=risk,
        details={
            "rows": float(row_count),
            "columns": float(data.shape[1]),
            "class_imbalance": round(class_imbalance, 6),
            "missing_ratio": round(missing_ratio, 6),
            "duplicate_ratio": round(duplicate_ratio, 6),
        },
    )
