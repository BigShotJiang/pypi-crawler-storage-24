"""Robustness checks for trained models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score


@dataclass
class RobustnessMetricResult:
    score: float
    details: dict[str, float]


def _perturb_numeric_features(
    features: pd.DataFrame,
    noise_level: float,
    random_state: int,
) -> pd.DataFrame:
    perturbed = features.copy()
    numeric_columns = perturbed.select_dtypes(include=[np.number]).columns.tolist()
    if not numeric_columns:
        return perturbed

    perturbed = perturbed.astype({column: float for column in numeric_columns})
    rng = np.random.default_rng(seed=random_state)
    noise = rng.normal(0.0, noise_level, size=(len(perturbed), len(numeric_columns)))
    perturbed.loc[:, numeric_columns] = perturbed.loc[:, numeric_columns].to_numpy() + noise
    return perturbed


def robustness_risk(
    model: Any,
    features: pd.DataFrame,
    y_true: pd.Series,
    noise_level: float = 0.05,
    random_state: int = 42,
) -> RobustnessMetricResult:
    predictions = model.predict(features)
    noisy_features = _perturb_numeric_features(features, noise_level, random_state)
    noisy_predictions = model.predict(noisy_features)

    clean_accuracy = float(accuracy_score(y_true, predictions))
    noisy_accuracy = float(accuracy_score(y_true, noisy_predictions))
    accuracy_drop = max(clean_accuracy - noisy_accuracy, 0.0)

    return RobustnessMetricResult(
        score=float(np.clip(accuracy_drop, 0.0, 1.0)),
        details={
            "clean_accuracy": round(clean_accuracy, 6),
            "noisy_accuracy": round(noisy_accuracy, 6),
            "accuracy_drop": round(accuracy_drop, 6),
            "noise_level": round(noise_level, 6),
        },
    )
