from __future__ import annotations

import sys
import unittest
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from beyond_accuracy import EthicalEvaluator, evaluate


SAMPLE_DATA = pd.DataFrame(
    {
        "income": [40000, 52000, 61000, 73000, 49000, 68000, 71000, 56000],
        "age": [25, 34, 29, 45, 31, 40, 37, 28],
        "gender": ["F", "M", "F", "M", "F", "M", "F", "M"],
        "region": ["North", "South", "East", "West", "North", "South", "East", "West"],
        "loan_status": [0, 1, 1, 1, 0, 1, 1, 0],
    }
)


def build_model(feature_frame: pd.DataFrame) -> Pipeline:
    numeric_columns = feature_frame.select_dtypes(include=["number"]).columns.tolist()
    categorical_columns = [column for column in feature_frame.columns if column not in numeric_columns]
    transformer = ColumnTransformer(
        transformers=[
            (
                "num",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="median")),
                        ("scaler", StandardScaler()),
                    ]
                ),
                numeric_columns,
            ),
            (
                "cat",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("encoder", OneHotEncoder(handle_unknown="ignore")),
                    ]
                ),
                categorical_columns,
            ),
        ]
    )
    model = Pipeline(
        steps=[
            ("preprocessor", transformer),
            ("classifier", LogisticRegression(max_iter=1000)),
        ]
    )
    model.fit(feature_frame, SAMPLE_DATA["loan_status"])
    return model


class EvaluatorTests(unittest.TestCase):
    def test_evaluate_returns_report_with_expected_fields(self) -> None:
        model = build_model(SAMPLE_DATA.drop(columns=["loan_status"]))
        report = evaluate(
            model=model,
            data=SAMPLE_DATA,
            target="loan_status",
            sensitive=["gender", "age"],
        )

        payload = report.to_dict()
        self.assertIn("risk_score", payload)
        self.assertIn("decision", payload)
        self.assertIn("module_scores", payload)
        self.assertEqual(set(payload["module_scores"].keys()), {
            "Dataset",
            "Bias",
            "Explainability",
            "Privacy",
            "Robustness",
        })

    def test_invalid_sensitive_column_raises(self) -> None:
        model = build_model(SAMPLE_DATA.drop(columns=["loan_status"]))
        evaluator = EthicalEvaluator()
        with self.assertRaises(ValueError):
            evaluator.evaluate(
                model=model,
                data=SAMPLE_DATA,
                target="loan_status",
                sensitive=["missing_column"],
            )


if __name__ == "__main__":
    unittest.main()
