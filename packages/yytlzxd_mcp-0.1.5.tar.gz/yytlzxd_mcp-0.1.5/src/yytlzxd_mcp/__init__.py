from mcp.server.fastmcp import FastMCP
from datetime import datetime
import pytz, httpx, os

mcp = FastMCP("YYTLZXD_MCP")
K, H = os.getenv("QWEATHER_KEY"), os.getenv("QWEATHER_HOST")

@mcp.tool()
def get_time() -> str:
    t = datetime.now(pytz.timezone('Asia/Shanghai'))
    return f"[时间] {t:%Y-%m-%d %H:%M:%S} 星期{'一二三四五六日'[t.weekday()]}"

@mcp.tool()
async def get_weather(city: str, adm: str = "", days: int = 1) -> str:
    if not city: return "[错误] city 不能为空"
    days = max(1, min(days, 7))
    
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(f"https://{H}/geo/v2/city/lookup",
                       params={"location": city, "number": 1, "key": K, **({"adm": adm} if adm else {})})
        d = r.json()
        if d.get("code") != "200": return f"[错误] 搜索失败: {d.get('code')}"
        loc = d.get("location", [{}])[0]
        if not loc: return f"[错误] 未找到 '{city}'"
        
        addr, lid = " - ".join(filter(None, [loc.get(k) for k in ["country", "adm1", "adm2"]])), loc["id"]
        
        rs = await c.get(f"https://{H}/v7/weather/now", params={"location": lid, "key": K}), \
             await c.get(f"https://{H}/v7/weather/{days}d", params={"location": lid, "key": K})
        d_now, d_day = rs[0].json(), rs[1].json()
        
        for code, name in [(d_now.get("code"), "实时"), (d_day.get("code"), "预报")]:
            if code != "200": return f"[错误] {name}失败: {code}"
        
        n, daily = d_now.get("now", {}), d_day.get("daily", [])
        g = lambda d, k, v='-': d.get(k, v)
        
        out = [f"[城市] {loc['name']} ({addr})",
               f"[实况]\n  天气: {g(n,'text')}\n  温度: {g(n,'temp')}C (体感{g(n,'feelsLike')}C)\n  湿度: {g(n,'humidity')}pct\n  气压: {g(n,'pressure')}hPa\n  风向: {g(n,'windDir')} {g(n,'windScale')}级 ({g(n,'windSpeed')}km/h)\n  能见度: {g(n,'vis')}km\n  降水量: {g(n,'precip')}mm",
               "[预报]"]
        
        for day in daily:
            date = day.get("fxDate", "")
            week = f"星期{'一二三四五六日'[datetime.strptime(date, '%Y-%m-%d').weekday()]}" if date else ""
            out.append(f"  [{date} {week}]\n    天气: 白天{g(day,'textDay')} 夜间{g(day,'textNight')}\n    温度: {g(day,'tempMin')}C ~ {g(day,'tempMax')}C\n    湿度: {g(day,'humidity')}pct\n    气压: {g(day,'pressure')}hPa\n    能见度: {g(day,'vis')}km\n    降水: {g(day,'precip')}mm\n    紫外线: {g(day,'uvIndex')}\n    风向: 白天{g(day,'windDirDay')}{g(day,'windScaleDay')}级 夜间{g(day,'windDirNight')}{g(day,'windScaleNight')}级\n    日出: {g(day,'sunrise','--:--')} 日落: {g(day,'sunset','--:--')}\n    月相: {g(day,'moonPhase')}")
        
        return "\n".join(out)

def main() -> None:
    mcp.run(transport="stdio")