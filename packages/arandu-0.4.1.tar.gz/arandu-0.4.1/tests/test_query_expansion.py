"""Tests for query expansion — entity priming (temporal anchoring removed)."""

from __future__ import annotations

from arandu.read.query_expansion import (
    ExpandedQuery,
    _extract_query_words,
)

# ---------------------------------------------------------------------------
# Word extraction tests
# ---------------------------------------------------------------------------


def test_extract_query_words_basic():
    """Basic word extraction."""
    words = _extract_query_words("como está o Kevin?")
    assert "kevin" in words
    assert "como" in words


def test_extract_query_words_short():
    """Words shorter than 2 chars should be excluded."""
    words = _extract_query_words("o a é")
    assert len(words) == 0


def test_extract_query_words_accents():
    """Words with accents should be extracted."""
    words = _extract_query_words("são Paulo é bonito")
    assert "são" in words or "paulo" in words


# ---------------------------------------------------------------------------
# ExpandedQuery dataclass
# ---------------------------------------------------------------------------


def test_expanded_query_defaults():
    """ExpandedQuery should have sane defaults."""
    eq = ExpandedQuery(primed_entities=[], temporal_range=None, expanded_terms=[])
    assert eq.primed_entities == []
    assert eq.temporal_range is None
    assert eq.expanded_terms == []
