import os
import urllib.request
from setuptools import setup, find_packages
from setuptools.command.install import install

GITHUB_RELEASE_URL = (
    "https://github.com/MarceloJay/lambda-dlq-reprocess-message"
    "/releases/latest/download/win-unpacked.zip"
)

class PostInstall(install):
    def run(self):
        install.run(self)
        dest = os.path.join(self.install_lib, 'dlqhandler', 'win-unpacked.zip')
        print("Downloading win-unpacked.zip from GitHub Releases...")
        try:
            urllib.request.urlretrieve(GITHUB_RELEASE_URL, dest)
            print(f"Downloaded to {dest}")
        except Exception as e:
            print(f"Warning: could not download win-unpacked.zip: {e}")

setup(
    name='dlqhandler',
    version="0.8.1",
    packages=['dlqhandler', 'dlqhandler.services', 'dlqhandler.dataprovider'],
    install_requires=[
        'boto3',
        'mock'
    ],
    cmdclass={'install': PostInstall},
    author="Marcelo Ferreira",
    author_email="jaytilangus@gmail.com",
    description="A library for handling DLQ messages in AWS SQS",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url="https://github.com/MarceloJay/lambda-dlq-reprocess-message",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
