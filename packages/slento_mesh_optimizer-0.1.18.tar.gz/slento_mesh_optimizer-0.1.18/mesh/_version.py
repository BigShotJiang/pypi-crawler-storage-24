"""Single source of truth for mesh-optimizer version."""
from __future__ import annotations

import sys
from datetime import datetime, timezone


try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("slento-mesh-optimizer")
except Exception:
    __version__ = "0.1.13"


def get_version_info() -> dict:
    """Return version metadata including build date and git SHA."""
    info = {
        "version": __version__,
        "build_date": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version,
        "git_sha": None,
    }
    try:
        import subprocess
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            info["git_sha"] = result.stdout.strip()
    except Exception:
        pass
    return info
