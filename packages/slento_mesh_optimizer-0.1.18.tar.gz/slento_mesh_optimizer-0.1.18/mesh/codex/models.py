"""Pydantic models for Codex AI agent tasks and results."""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ── Enums ────────────────────────────────────────────────────────────────────

class CodexTaskType(str, Enum):
    ANALYZE = "analyze"
    TUNE = "tune"
    DIAGNOSE = "diagnose"
    TEST_GEN = "test_gen"
    CUSTOM = "custom"


class CodexTaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class CodexAgentStatus(str, Enum):
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"


class FindingSeverity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


# ── Task Models ──────────────────────────────────────────────────────────────

class CodexTask(BaseModel):
    task_id: str = ""
    task_type: CodexTaskType = CodexTaskType.CUSTOM
    target: str = ""  # file path, node ID, or module name
    parameters: Dict[str, Any] = Field(default_factory=dict)
    status: CodexTaskStatus = CodexTaskStatus.PENDING
    result: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class CodexTaskResult(BaseModel):
    task_id: str
    success: bool = False
    findings: List[Dict[str, Any]] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    artifacts: Dict[str, str] = Field(default_factory=dict)  # name -> file path
    duration_s: float = 0.0
    error: Optional[str] = None


class CodexAgentInfo(BaseModel):
    agent_type: str = ""
    status: CodexAgentStatus = CodexAgentStatus.IDLE
    tasks_completed: int = 0
    tasks_failed: int = 0
    last_active: Optional[datetime] = None


# ── Request Models ───────────────────────────────────────────────────────────

class CodexTaskSubmission(BaseModel):
    task_type: CodexTaskType = CodexTaskType.ANALYZE
    target: str = ""
    parameters: Dict[str, Any] = Field(default_factory=dict)


class CodexFindingRow(BaseModel):
    finding_id: str = ""
    task_id: str = ""
    severity: FindingSeverity = FindingSeverity.INFO
    category: str = ""
    location: str = ""
    message: str = ""
    suggestion: str = ""
    created_at: Optional[datetime] = None
