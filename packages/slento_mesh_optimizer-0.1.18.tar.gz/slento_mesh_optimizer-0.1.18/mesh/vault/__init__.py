"""Mesh credential vault — encrypted at-rest storage with MCP server interface.

Provides AES-256-GCM encrypted credential storage, scoped access control,
audit logging, and an MCP-compatible HTTP API for AI agent integration.
"""
