"""RDNA3 Discovery Mesh — Distributed profiling and job routing."""
from mesh._version import __version__  # noqa: F401
