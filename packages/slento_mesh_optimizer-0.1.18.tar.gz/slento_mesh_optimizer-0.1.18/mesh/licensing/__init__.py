"""Mesh licensing subsystem."""
