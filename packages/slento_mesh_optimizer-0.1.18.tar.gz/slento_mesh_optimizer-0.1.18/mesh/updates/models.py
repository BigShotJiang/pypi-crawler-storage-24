"""Pydantic models for the update system."""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class UpdateChannel(str, Enum):
    STABLE = "stable"
    BETA = "beta"
    NIGHTLY = "nightly"


class UpdateStatus(str, Enum):
    AVAILABLE = "available"
    DOWNLOADING = "downloading"
    VERIFYING = "verifying"
    APPLYING = "applying"
    COMPLETE = "complete"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class UpdateInfo(BaseModel):
    """Metadata about an available update."""
    version: str
    channel: UpdateChannel = UpdateChannel.STABLE
    download_url: str = ""
    sha256: str = ""
    release_notes: str = ""
    size_bytes: int = 0
    min_python_version: str = "3.10"
    published_at: Optional[datetime] = None


class UpdateHistoryEntry(BaseModel):
    """Record of a single update attempt."""
    version: str
    channel: UpdateChannel = UpdateChannel.STABLE
    status: UpdateStatus = UpdateStatus.COMPLETE
    applied_at: Optional[datetime] = None
    rolled_back_at: Optional[datetime] = None
    error: Optional[str] = None
    backup_path: Optional[str] = None


class UpdateHistory(BaseModel):
    """Full update history."""
    entries: List[UpdateHistoryEntry] = Field(default_factory=list)
    current_version: str = "0.1.0"
