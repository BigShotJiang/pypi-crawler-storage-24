# Mesh Optimizer

Distributed hardware optimization agent by [Slento Systems](https://slentosystems.com).

JEPA-driven job routing, GPU/CPU/FPGA probing, and performance tuning across heterogeneous compute clusters.

## Quick Start

```bash
pip install slento-mesh-optimizer
mesh-optimizer start
```

## One-Line Install (Linux)

```bash
curl -fsSL https://mesh.slentosystems.com/install.sh | bash
```

## Features

- **Hardware Discovery** — Auto-detects GPUs (AMD, NVIDIA), CPUs, FPGAs, memory subsystems
- **Performance Probing** — Runs targeted benchmarks to map hardware capabilities
- **JEPA Optimization** — Joint Embedding Predictive Architecture learns your hardware's performance characteristics
- **Job Routing** — Automatically routes compute jobs to the best-suited hardware
- **NAT/WAN Support** — Works behind firewalls with outbound-only connections
- **Multi-Platform** — Linux, macOS, Windows

## Supported Hardware

- AMD Radeon RX 7000 (RDNA3), Instinct MI200/MI300 (CDNA)
- NVIDIA GeForce RTX 30/40/50, Quadro, Tesla, A100
- Intel/AMD CPUs (10th gen+, Ryzen/EPYC)
- Apple M1/M2/M3/M4
- Xilinx Alveo/UltraScale+ FPGAs

## Documentation

Full docs at [docs.slentosystems.com](https://docs.slentosystems.com)

## License

Proprietary. Free community tier available at [portal.slentosystems.com](https://portal.slentosystems.com).
