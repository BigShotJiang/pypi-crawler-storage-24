import requests


class MediaCCCApi:
    BASE_URL = "https://api.media.ccc.de/public"

    @classmethod
    def get_conferences(cls):
        return cls._request("conferences")

    @classmethod
    def get_conference(cls, conf_id):
        return cls._request(f"conferences/{conf_id}")

    @classmethod
    def get_recordings(cls, event_id):
        return cls._request(f"recordings/{event_id}")

    @classmethod
    def get_live(cls):
        return cls._request("live")

    @classmethod
    def get_relive_index(cls):
        return cls._request("relive")

    @classmethod
    def _request(cls, endpoint):
        url = f"{cls.BASE_URL}/{endpoint}"
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            raise FetchError(f"Failed to fetch {url}: {e}")


class FetchError(Exception):
    pass
