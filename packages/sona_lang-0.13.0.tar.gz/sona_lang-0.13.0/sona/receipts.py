from __future__ import annotations

import getpass
import hashlib
import hmac
import json
import os
import platform
import re
import socket
import subprocess
import time
import unicodedata
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .runtime.memory.enums import ClassificationTier
from .runtime.memory.models import MemoryReceiptRef

# ---------------------------------------------------------------------------
# Receipt context singleton — allows running Sona code to append events
# ---------------------------------------------------------------------------
_active_receipt: dict | None = None
_active_receipt_start_ns: int | None = None


def set_active_receipt(receipt_ctx: dict) -> None:
    """Activate a receipt context for the current execution."""
    global _active_receipt, _active_receipt_start_ns
    _active_receipt = receipt_ctx
    _active_receipt_start_ns = time.perf_counter_ns()


def clear_active_receipt() -> None:
    """Deactivate the receipt context."""
    global _active_receipt, _active_receipt_start_ns
    _active_receipt = None
    _active_receipt_start_ns = None


def get_active_receipt() -> dict | None:
    """Return the active receipt context, or *None*."""
    return _active_receipt


def receipt_classification_tier(
    classification: str | ClassificationTier | None,
) -> ClassificationTier:
    """Map receipt event classification text to memory classification tier."""
    if isinstance(classification, ClassificationTier):
        return classification
    text = str(classification or "").strip().lower()
    if text == ClassificationTier.PUBLIC.value:
        return ClassificationTier.PUBLIC
    if text == ClassificationTier.SENSITIVE.value:
        return ClassificationTier.SENSITIVE
    return ClassificationTier.INTERNAL


def build_memory_receipt_ref_from_active_context(
    *,
    event: dict[str, Any] | None = None,
) -> MemoryReceiptRef | None:
    """Build a memory receipt reference from the active receipt context."""
    ctx = get_active_receipt()
    if not isinstance(ctx, dict):
        return None

    events = ctx.get("execution", {}).get("events", [])
    if not isinstance(events, list) or not events:
        return None

    event_offset, resolved_event = _resolve_receipt_event_ref(events, event)
    if resolved_event is None:
        return None

    receipt_id = str(ctx.get("receipt_id", "") or "").strip()
    if not receipt_id:
        return None

    header = _receipt_header(ctx)
    event_kind = str(
        resolved_event.get("kind", "receipt_event") or "receipt_event"
    )
    return MemoryReceiptRef(
        receipt_id=receipt_id,
        event_kind_or_path=f"execution.events[{event_offset}]",
        receipt_hash=(
            _normalize_hash(ctx.get("receipt_hash"))
            or _normalize_hash(header.get("receipt_hash"))
        ),
        classification=receipt_classification_tier(
            resolved_event.get("classification"),
        ),
        policy_fingerprint=(
            str(header.get("policy_fingerprint") or "").strip() or None
        ),
        event_offset=event_offset,
        sealed_mode_ref=event_kind,
    )


def _resolve_receipt_event_ref(
    events: list[Any],
    event: dict[str, Any] | None,
) -> tuple[int, dict[str, Any] | None]:
    if event is not None:
        for idx, candidate in enumerate(events):
            if candidate is event:
                return idx, candidate

    for idx in range(len(events) - 1, -1, -1):
        candidate = events[idx]
        if not isinstance(candidate, dict):
            continue
        if str(candidate.get("kind", "")).strip().lower() == "end":
            continue
        return idx, candidate

    return -1, None


def append_receipt_event(
    event_type: str,
    payload: dict | None = None,
    classification: str = "internal",
) -> dict | None:
    """Append a structured event to the active receipt.

    Returns the event dict, or *None* if no receipt context is active.
    """
    ctx = _active_receipt
    if ctx is None:
        return None
    events: list = ctx["execution"]["events"]
    # Compute elapsed ms from activation
    elapsed_ms = 0
    if _active_receipt_start_ns is not None:
        elapsed_ms = int((time.perf_counter_ns() - _active_receipt_start_ns) / 1_000_000)
    event: dict[str, Any] = {
        "t": elapsed_ms,
        "kind": event_type,
        "classification": classification,
    }
    if payload:
        event["payload"] = payload
    # Insert before the end sentinel (last element), if present
    if events and events[-1].get("kind") == "end":
        events.insert(len(events) - 1, event)
    else:
        events.append(event)
    return event


DEFAULT_DIRECTORY_EXCLUDE_PATTERNS = (
    r"(^|/)\.git(/|$)",
    r"(^|/)\.sona(/|$)",
    r"(^|/)\.venv(/|$)",
    r"(^|/)__pycache__(/|$)",
    r"(^|/)node_modules(/|$)",
    r"(^|/)dist(/|$)",
)

VALID_RECEIPT_MODES = {"deterministic", "audit"}
SUPPORTED_RECEIPT_SIGNATURE_ALGORITHMS = {"hmac-sha256"}
SIGNED_FIELDS_VERSION = "0.1"
SUPPORTED_REDACTION_PROFILES = {"dev", "ci", "prod"}
REDACTED_TOKEN_PATTERN = re.compile(r"^\[REDACTED:sha256:[0-9a-f]{64}\]$")

DEFAULT_RECEIPT_REDACTION_CLASSIFICATION = {
    "public": (
        "header.receipt_hash",
        "header.prev_receipt_hash",
        "header.policy_fingerprint",
        "header.engine_policy_fingerprint",
        "receipt_hash",
        "receipt_id",
        "receipt_kind",
        "receipt_version",
        "mode",
        "summary.tree_sha256",
        "summary.total_files",
        "summary.total_bytes",
    ),
    "internal": (
        "header.env_fingerprint",
        "header.runtime_fingerprint",
        "header.graph_fingerprint",
        "root_path",
        "code.entry_file",
        "audit.hostname",
    ),
    "sensitive": (
        "events.*.tool.args",
        "events.*.tool.env",
        "events.*.model.prompt",
        "events.*.model.system_prompt",
        "events.*.model.messages",
        "events.*.model.output_raw",
        "events.*.io.stdin",
        "events.*.io.stdout",
        "events.*.io.stderr",
        "inputs.args.*",
        "inputs.env_allowlist.*",
        "execution.errors.*.text",
        "audit.username",
    ),
}

DEFAULT_REDACTION_PROFILE_ACTIONS = {
    "dev": {"internal": "keep", "sensitive": "redact"},
    "ci": {"internal": "keep", "sensitive": "redact"},
    "prod": {"internal": "redact", "sensitive": "redact"},
}


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def _sha256_hex_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _git_info(repo_root: Path) -> dict[str, Any]:
    # Best-effort; never fail execution if git is missing.
    try:
        commit = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=str(repo_root),
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()

        dirty = (
            subprocess.call(
                ["git", "diff", "--quiet"],
                cwd=str(repo_root),
                stderr=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
            )
            != 0
        )

        return {"git_commit": commit, "dirty": bool(dirty)}
    except Exception:
        return {"git_commit": None, "dirty": None}


def _utc_timestamp() -> str:
    # ISO-ish; not deterministic across runs (by design), but stable format.
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _compile_patterns(patterns: tuple[str, ...]) -> list[re.Pattern[str]]:
    compiled: list[re.Pattern[str]] = []
    for raw in patterns:
        try:
            compiled.append(re.compile(raw))
        except re.error as exc:
            raise ValueError(f"Invalid regex pattern '{raw}': {exc}") from exc
    return compiled


def _matches_any(value: str, compiled_patterns: list[re.Pattern[str]]) -> bool:
    return any(pattern.search(value) is not None for pattern in compiled_patterns)


def _should_include(
    rel_path: str,
    include_patterns: list[re.Pattern[str]],
    exclude_patterns: list[re.Pattern[str]],
) -> bool:
    if not include_patterns:
        return False
    if not _matches_any(rel_path, include_patterns):
        return False
    if _matches_any(rel_path, exclude_patterns):
        return False
    return True


def _tree_sha256(entries: list[dict[str, Any]]) -> str:
    hasher = hashlib.sha256()
    for entry in sorted(entries, key=lambda item: item["path"]):
        hasher.update(str(entry["path"]).encode("utf-8"))
        hasher.update(b"\n")
        hasher.update(str(entry["sha256"]).encode("utf-8"))
        hasher.update(b"\n")
        hasher.update(str(int(entry["size"])).encode("utf-8"))
        hasher.update(b"\n")
    return hasher.hexdigest()


def _entry_index(receipt: dict[str, Any]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    files = receipt.get("files", [])
    if not isinstance(files, list):
        return out

    for raw in files:
        if not isinstance(raw, dict):
            continue
        path = str(raw.get("path", "")).strip()
        if not path:
            continue
        out[path] = {
            "path": path,
            "size": int(raw.get("size", 0)),
            "sha256": str(raw.get("sha256", "")),
        }
    return out


def _policy_fingerprint(policy: dict[str, Any]) -> str:
    payload = json.dumps(policy, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _engine_policy_fingerprint() -> str | None:
    try:
        from .policy import policy_fingerprint as _policy_engine_fingerprint

        return str(_policy_engine_fingerprint())
    except Exception:
        return None


def _normalize_hash(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip().lower()
    if len(text) != 64:
        return None
    if re.fullmatch(r"[0-9a-f]{64}", text) is None:
        return None
    return text


def _normalize_profile(profile: str) -> str:
    normalized = str(profile or "").strip().lower()
    if normalized not in SUPPORTED_REDACTION_PROFILES:
        raise ValueError(
            f"Unsupported redaction profile '{profile}'. "
            f"Expected one of: {sorted(SUPPORTED_REDACTION_PROFILES)}"
        )
    return normalized


def _normalize_action(value: Any) -> str:
    text = str(value or "").strip().lower()
    if text not in {"keep", "redact"}:
        return "keep"
    return text


def _normalize_path_list(values: Any, fallback: tuple[str, ...]) -> tuple[str, ...]:
    if not isinstance(values, (list, tuple)):
        return tuple(str(item) for item in fallback)
    out: list[str] = []
    for raw in values:
        text = str(raw or "").strip()
        if not text:
            continue
        out.append(text)
    return tuple(out) if out else tuple(str(item) for item in fallback)


def _normalize_redaction_classification(data: Any) -> dict[str, tuple[str, ...]]:
    source = data if isinstance(data, dict) else {}
    return {
        "public": _normalize_path_list(
            source.get("public"),
            tuple(DEFAULT_RECEIPT_REDACTION_CLASSIFICATION["public"]),
        ),
        "internal": _normalize_path_list(
            source.get("internal"),
            tuple(DEFAULT_RECEIPT_REDACTION_CLASSIFICATION["internal"]),
        ),
        "sensitive": _normalize_path_list(
            source.get("sensitive"),
            tuple(DEFAULT_RECEIPT_REDACTION_CLASSIFICATION["sensitive"]),
        ),
    }


def _normalize_profile_actions(data: Any) -> dict[str, dict[str, str]]:
    source = data if isinstance(data, dict) else {}
    out: dict[str, dict[str, str]] = {}
    for profile in sorted(SUPPORTED_REDACTION_PROFILES):
        base = DEFAULT_REDACTION_PROFILE_ACTIONS[profile]
        profile_data = source.get(profile, {})
        profile_obj = profile_data if isinstance(profile_data, dict) else {}
        out[profile] = {
            "internal": _normalize_action(profile_obj.get("internal", base["internal"])),
            "sensitive": _normalize_action(profile_obj.get("sensitive", base["sensitive"])),
        }
    return out


def default_receipt_redaction_policy(profile: str = "prod") -> dict[str, Any]:
    normalized_profile = _normalize_profile(profile)
    return {
        "policy_version": "0.1",
        "profile": normalized_profile,
        "classification": {
            "public": list(DEFAULT_RECEIPT_REDACTION_CLASSIFICATION["public"]),
            "internal": list(DEFAULT_RECEIPT_REDACTION_CLASSIFICATION["internal"]),
            "sensitive": list(DEFAULT_RECEIPT_REDACTION_CLASSIFICATION["sensitive"]),
        },
        "profile_actions": {
            key: dict(value) for key, value in DEFAULT_REDACTION_PROFILE_ACTIONS.items()
        },
    }


def resolve_receipt_redaction_policy(
    profile: str,
    policy_override: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized_profile = _normalize_profile(profile)
    baseline = default_receipt_redaction_policy(normalized_profile)
    override = policy_override if isinstance(policy_override, dict) else {}

    redaction_block = override.get("redaction")
    redaction_obj = redaction_block if isinstance(redaction_block, dict) else {}

    classification_source = override.get("classification")
    if classification_source is None:
        classification_source = redaction_obj.get("classification")
    classification = _normalize_redaction_classification(classification_source)

    profile_actions_source = override.get("profile_actions")
    if profile_actions_source is None:
        profile_actions_source = redaction_obj.get("profile_actions")
    profile_actions = _normalize_profile_actions(profile_actions_source)

    profile_from_override = override.get("profile")
    if profile_from_override is None:
        profile_from_override = redaction_obj.get("profile")
    effective_profile = _normalize_profile(profile_from_override or normalized_profile)

    baseline["profile"] = effective_profile
    baseline["classification"] = {
        "public": list(classification["public"]),
        "internal": list(classification["internal"]),
        "sensitive": list(classification["sensitive"]),
    }
    baseline["profile_actions"] = {
        key: dict(value) for key, value in profile_actions.items()
    }
    return baseline


def load_receipt_redaction_policy(
    profile: str,
    policy_path: Path | None = None,
) -> dict[str, Any]:
    if policy_path is None:
        return resolve_receipt_redaction_policy(profile, None)

    source_path = policy_path.resolve()
    if not source_path.exists():
        raise FileNotFoundError(f"Redaction policy not found: {source_path}")
    payload = json.loads(source_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Redaction policy must be an object: {source_path}")
    return resolve_receipt_redaction_policy(profile, payload)


def _split_path(path: str) -> tuple[str, ...]:
    return tuple(part for part in str(path).split(".") if part)


def _path_matches(path_parts: tuple[str, ...], pattern: str) -> bool:
    pattern_parts = _split_path(pattern)
    if not pattern_parts:
        return False

    def _walk(path_idx: int, pattern_idx: int) -> bool:
        if pattern_idx >= len(pattern_parts):
            return path_idx >= len(path_parts)

        token = pattern_parts[pattern_idx]
        if token == "**":
            if pattern_idx == len(pattern_parts) - 1:
                return True
            for cursor in range(path_idx, len(path_parts) + 1):
                if _walk(cursor, pattern_idx + 1):
                    return True
            return False

        if path_idx >= len(path_parts):
            return False
        if token != "*" and token != path_parts[path_idx]:
            return False
        return _walk(path_idx + 1, pattern_idx + 1)

    return _walk(0, 0)


def _classify_field_path(
    path_parts: tuple[str, ...],
    classification: dict[str, tuple[str, ...]],
) -> str | None:
    public_patterns = classification.get("public", ())
    if any(_path_matches(path_parts, pattern) for pattern in public_patterns):
        return "public"

    sensitive_patterns = classification.get("sensitive", ())
    if any(_path_matches(path_parts, pattern) for pattern in sensitive_patterns):
        return "sensitive"

    internal_patterns = classification.get("internal", ())
    if any(_path_matches(path_parts, pattern) for pattern in internal_patterns):
        return "internal"

    return None


def _should_redact_tier(
    tier: str | None,
    *,
    profile: str,
    policy: dict[str, Any],
) -> bool:
    if tier is None or tier == "public":
        return False

    actions = policy.get("profile_actions")
    action_map = actions.get(profile, {}) if isinstance(actions, dict) else {}
    if not isinstance(action_map, dict):
        return False

    return _normalize_action(action_map.get(tier, "keep")) == "redact"


def _normalize_text_for_redaction(value: str) -> str:
    """Normalize a string for deterministic redaction: NFC Unicode + LF newlines."""
    normalized = unicodedata.normalize("NFC", value)
    return normalized.replace("\r\n", "\n").replace("\r", "\n")


def _canonical_scalar_for_redaction(value: Any) -> str:
    if isinstance(value, str):
        value = _normalize_text_for_redaction(value)
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    except Exception:
        return str(value)


def _redacted_token(value: Any, *, receipt_id: str, policy_fingerprint: str) -> str:
    canonical_value = _canonical_scalar_for_redaction(value)
    seed = f"{receipt_id}\n{policy_fingerprint}\n{canonical_value}"
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return f"[REDACTED:sha256:{digest}]"


def _apply_redacted_tokens(
    value: Any,
    *,
    receipt_id: str,
    policy_fingerprint: str,
) -> tuple[Any, int]:
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        count = 0
        for key in sorted(value.keys(), key=lambda item: str(item)):
            redacted_value, redacted_count = _apply_redacted_tokens(
                value[key],
                receipt_id=receipt_id,
                policy_fingerprint=policy_fingerprint,
            )
            out[str(key)] = redacted_value
            count += redacted_count
        return out, count

    if isinstance(value, list):
        out_list: list[Any] = []
        count = 0
        for item in value:
            redacted_item, redacted_count = _apply_redacted_tokens(
                item,
                receipt_id=receipt_id,
                policy_fingerprint=policy_fingerprint,
            )
            out_list.append(redacted_item)
            count += redacted_count
        return out_list, count

    if isinstance(value, str) and REDACTED_TOKEN_PATTERN.fullmatch(value):
        return value, 0

    return _redacted_token(
        value,
        receipt_id=receipt_id,
        policy_fingerprint=policy_fingerprint,
    ), 1

def _clone_json_object(payload: dict[str, Any]) -> dict[str, Any]:
    return json.loads(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
        )
    )


def _strip_receipt_envelope_fields(
    payload: dict[str, Any],
    *,
    strip_hash: bool,
    strip_signature: bool,
) -> None:
    if strip_hash:
        payload.pop("receipt_hash", None)
    if strip_signature:
        payload.pop("signature", None)

    header = payload.get("header")
    if isinstance(header, dict):
        if strip_hash:
            header.pop("receipt_hash", None)
        if strip_signature:
            header.pop("signature", None)


def canonical_receipt_payload(receipt: dict[str, Any]) -> str:
    """
    Canonical JSON payload used for receipt hashing.

    The canonical form excludes `receipt_hash` fields so hashes are stable and
    self-referential cycles are avoided. Signature envelopes are also excluded
    so signed/unsigned receipts retain the same `receipt_hash`.
    """
    data = _clone_json_object(receipt)
    if isinstance(data, dict):
        _strip_receipt_envelope_fields(data, strip_hash=True, strip_signature=True)
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def receipt_sha256(receipt: dict[str, Any]) -> str:
    payload = canonical_receipt_payload(receipt)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def canonical_receipt_signing_payload(receipt: dict[str, Any]) -> str:
    """
    Canonical payload used for signature generation/verification.

    Signatures cover the full receipt body including embedded `receipt_hash`,
    while excluding signature envelope fields to avoid self-reference.
    """
    data = _clone_json_object(receipt)
    if isinstance(data, dict):
        _strip_receipt_envelope_fields(data, strip_hash=False, strip_signature=True)
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _attach_receipt_hash(receipt: dict[str, Any]) -> str:
    digest = receipt_sha256(receipt)
    receipt["receipt_hash"] = digest
    header = receipt.get("header")
    if isinstance(header, dict):
        header["receipt_hash"] = digest
    return digest


def _normalize_signature_algorithm(value: Any) -> str:
    return str(value or "").strip().lower()


def _coerce_signing_key(signing_key: str | bytes) -> bytes:
    key_bytes = signing_key if isinstance(signing_key, bytes) else str(signing_key).encode("utf-8")
    if not key_bytes:
        raise ValueError("Signing key must not be empty.")
    return key_bytes


def _hmac_sha256_hex(payload: bytes, signing_key: bytes) -> str:
    return hmac.new(signing_key, payload, hashlib.sha256).hexdigest()


def sign_receipt_payload(
    receipt: dict[str, Any],
    *,
    signing_key: str | bytes,
    key_id: str | None = None,
    algorithm: str = "hmac-sha256",
    signed_at_utc: str | None = None,
) -> dict[str, Any]:
    normalized_algorithm = _normalize_signature_algorithm(algorithm)
    if normalized_algorithm not in SUPPORTED_RECEIPT_SIGNATURE_ALGORITHMS:
        raise ValueError(
            f"Unsupported signature algorithm '{algorithm}'. "
            f"Expected one of: {sorted(SUPPORTED_RECEIPT_SIGNATURE_ALGORITHMS)}"
        )

    payload = _clone_json_object(receipt)
    if not isinstance(payload, dict):
        raise ValueError("Receipt payload must be an object.")

    _strip_receipt_envelope_fields(payload, strip_hash=False, strip_signature=True)
    _attach_receipt_hash(payload)
    signable = canonical_receipt_signing_payload(payload).encode("utf-8")

    key_bytes = _coerce_signing_key(signing_key)
    signature_value = _hmac_sha256_hex(signable, key_bytes)
    payload_hash = hashlib.sha256(signable).hexdigest()

    header = payload.get("header")
    if not isinstance(header, dict):
        header = {}
        payload["header"] = header

    header["signature"] = {
        "algorithm": normalized_algorithm,
        "value": signature_value,
        "key_id": str(key_id or "").strip(),
        "signed_at_utc": str(signed_at_utc) if signed_at_utc is not None else _utc_timestamp(),
        "payload_hash": payload_hash,
        "signed_fields_version": SIGNED_FIELDS_VERSION,
    }

    return payload


def verify_receipt_signature(
    receipt: dict[str, Any],
    *,
    signing_key: str | bytes,
    expected_key_id: str | None = None,
) -> dict[str, Any]:
    payload = _clone_json_object(receipt)
    if not isinstance(payload, dict):
        raise ValueError("Receipt payload must be an object.")

    embedded_hash = _receipt_embedded_hash(payload) or ""
    canonical_hash = receipt_sha256(payload)
    receipt_hash_match = bool(embedded_hash) and embedded_hash == canonical_hash

    header = _receipt_header(payload)
    raw_signature = header.get("signature")
    if not isinstance(raw_signature, dict):
        return {
            "ok": False,
            "reason": "missing_signature",
            "signature_present": False,
            "signature_algorithm": "",
            "key_id": "",
            "receipt_hash_match": receipt_hash_match,
            "embedded_receipt_hash": embedded_hash,
            "canonical_receipt_hash": canonical_hash,
            "signature_match": False,
            "payload_hash_matches": None,
            "signed_fields_version": "",
        }

    signature_algorithm = _normalize_signature_algorithm(raw_signature.get("algorithm"))
    signature_value = str(raw_signature.get("value", "")).strip().lower()
    signature_key_id = str(raw_signature.get("key_id", "")).strip()
    expected_key_id_text = str(expected_key_id or "").strip()

    if signature_algorithm not in SUPPORTED_RECEIPT_SIGNATURE_ALGORITHMS:
        return {
            "ok": False,
            "reason": "unsupported_signature_algorithm",
            "signature_present": True,
            "signature_algorithm": signature_algorithm,
            "key_id": signature_key_id,
            "receipt_hash_match": receipt_hash_match,
            "embedded_receipt_hash": embedded_hash,
            "canonical_receipt_hash": canonical_hash,
            "signature_match": False,
            "payload_hash_matches": None,
            "signed_fields_version": "",
        }

    if re.fullmatch(r"[0-9a-f]{64}", signature_value) is None:
        return {
            "ok": False,
            "reason": "invalid_signature_format",
            "signature_present": True,
            "signature_algorithm": signature_algorithm,
            "key_id": signature_key_id,
            "receipt_hash_match": receipt_hash_match,
            "embedded_receipt_hash": embedded_hash,
            "canonical_receipt_hash": canonical_hash,
            "signature_match": False,
            "payload_hash_matches": None,
            "signed_fields_version": "",
        }

    if expected_key_id_text and signature_key_id != expected_key_id_text:
        return {
            "ok": False,
            "reason": "key_id_mismatch",
            "signature_present": True,
            "signature_algorithm": signature_algorithm,
            "key_id": signature_key_id,
            "expected_key_id": expected_key_id_text,
            "receipt_hash_match": receipt_hash_match,
            "embedded_receipt_hash": embedded_hash,
            "canonical_receipt_hash": canonical_hash,
            "signature_match": False,
            "payload_hash_matches": None,
            "signed_fields_version": "",
        }

    signable = canonical_receipt_signing_payload(payload).encode("utf-8")
    key_bytes = _coerce_signing_key(signing_key)
    expected_signature = _hmac_sha256_hex(signable, key_bytes)
    signature_match = hmac.compare_digest(signature_value, expected_signature)

    # payload_hash verification (if present in envelope)
    stored_payload_hash = str(raw_signature.get("payload_hash", "")).strip().lower()
    recomputed_payload_hash = hashlib.sha256(signable).hexdigest()
    if stored_payload_hash:
        payload_hash_matches = hmac.compare_digest(stored_payload_hash, recomputed_payload_hash)
    else:
        payload_hash_matches = None  # legacy receipt without payload_hash

    stored_signed_fields_version = str(raw_signature.get("signed_fields_version", "")).strip()

    reason = "ok"
    ok = True
    if not receipt_hash_match:
        reason = "receipt_hash_mismatch" if embedded_hash else "missing_receipt_hash"
        ok = False
    elif payload_hash_matches is False:
        reason = "payload_hash_mismatch"
        ok = False
    elif not signature_match:
        reason = "signature_mismatch"
        ok = False

    return {
        "ok": ok,
        "reason": reason,
        "signature_present": True,
        "signature_algorithm": signature_algorithm,
        "key_id": signature_key_id,
        "receipt_hash_match": receipt_hash_match,
        "embedded_receipt_hash": embedded_hash,
        "canonical_receipt_hash": canonical_hash,
        "signature_match": signature_match,
        "payload_hash_matches": payload_hash_matches,
        "signed_fields_version": stored_signed_fields_version,
    }


def redact_receipt_payload(
    receipt: dict[str, Any],
    *,
    profile: str = "prod",
    policy: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    effective_policy = resolve_receipt_redaction_policy(profile, policy)
    effective_profile = _normalize_profile(str(effective_policy.get("profile", profile)))
    classification = _normalize_redaction_classification(effective_policy.get("classification"))

    payload = _clone_json_object(receipt)
    if not isinstance(payload, dict):
        raise ValueError("Receipt payload must be an object.")

    _strip_receipt_envelope_fields(payload, strip_hash=False, strip_signature=True)
    source_receipt_hash = _receipt_embedded_hash(payload) or receipt_sha256(payload)

    header = _receipt_header(payload)
    receipt_id = str(payload.get("receipt_id", "") or "").strip()
    if not receipt_id:
        receipt_id = source_receipt_hash[:16]

    receipt_policy_fingerprint = str(header.get("policy_fingerprint", "") or "").strip()
    if not receipt_policy_fingerprint:
        policy_raw = payload.get("policy")
        if isinstance(policy_raw, dict):
            receipt_policy_fingerprint = _policy_fingerprint(policy_raw)
    if not receipt_policy_fingerprint:
        receipt_policy_fingerprint = "no-policy"

    def _walk(value: Any, path_parts: tuple[str, ...]) -> tuple[Any, int, list[str]]:
        tier = _classify_field_path(path_parts, classification) if path_parts else None
        if _should_redact_tier(tier, profile=effective_profile, policy=effective_policy):
            redacted_value, redacted_values = _apply_redacted_tokens(
                value,
                receipt_id=receipt_id,
                policy_fingerprint=receipt_policy_fingerprint,
            )
            redacted_path = ".".join(path_parts)
            redacted_paths = [redacted_path] if redacted_values > 0 and redacted_path else []
            return redacted_value, redacted_values, redacted_paths

        if isinstance(value, dict):
            out: dict[str, Any] = {}
            count = 0
            paths: list[str] = []
            for key, child in value.items():
                child_value, child_count, child_paths = _walk(child, path_parts + (str(key),))
                out[str(key)] = child_value
                count += child_count
                paths.extend(child_paths)
            return out, count, paths

        if isinstance(value, list):
            out_list: list[Any] = []
            count = 0
            paths: list[str] = []
            for idx, child in enumerate(value):
                child_value, child_count, child_paths = _walk(child, path_parts + (str(idx),))
                out_list.append(child_value)
                count += child_count
                paths.extend(child_paths)
            return out_list, count, paths

        return value, 0, []

    redacted_payload, redacted_values, redacted_paths = _walk(payload, ())
    if not isinstance(redacted_payload, dict):
        raise ValueError("Redaction produced invalid receipt payload.")

    redaction_policy_fingerprint = _policy_fingerprint(effective_policy)
    redacted_unique_paths = sorted(set(redacted_paths))

    redacted_header = redacted_payload.get("header")
    if not isinstance(redacted_header, dict):
        redacted_header = {}
        redacted_payload["header"] = redacted_header

    redacted_header.pop("signature", None)
    redacted_header["redaction"] = {
        "profile": effective_profile,
        "policy_fingerprint": redaction_policy_fingerprint,
        "transform": "sha256-token-v1",
        "redacted_fields": len(redacted_unique_paths),
        "redacted_values": int(redacted_values),
        "source_receipt_hash": source_receipt_hash,
    }

    redacted_receipt_hash = _attach_receipt_hash(redacted_payload)
    report = {
        "profile": effective_profile,
        "policy_fingerprint": redaction_policy_fingerprint,
        "source_receipt_hash": source_receipt_hash,
        "receipt_hash": redacted_receipt_hash,
        "redacted_fields": len(redacted_unique_paths),
        "redacted_values": int(redacted_values),
        "redacted_paths": redacted_unique_paths,
    }
    return redacted_payload, report


def redact_receipts_in_dir(
    receipts_dir: Path,
    out_dir: Path,
    *,
    profile: str = "prod",
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    source_dir = receipts_dir.resolve()
    target_dir = out_dir.resolve()
    if not source_dir.exists():
        raise FileNotFoundError(f"Receipt directory not found: {source_dir}")
    if not source_dir.is_dir():
        raise NotADirectoryError(f"Expected receipt directory path: {source_dir}")
    target_dir.mkdir(parents=True, exist_ok=True)

    receipt_files = sorted(path for path in source_dir.glob("*.receipt.json") if path.is_file())
    entries: list[dict[str, Any]] = []
    policy_fingerprint = ""
    for src_path in receipt_files:
        payload = load_receipt_json(src_path)
        redacted_payload, report = redact_receipt_payload(
            payload,
            profile=profile,
            policy=policy,
        )
        if not policy_fingerprint:
            policy_fingerprint = str(report.get("policy_fingerprint", ""))
        dst_path = target_dir / src_path.name
        write_receipt_json(redacted_payload, dst_path)
        entries.append(
            {
                "input_path": src_path.resolve().as_posix(),
                "output_path": dst_path.resolve().as_posix(),
                "source_receipt_hash": str(report["source_receipt_hash"]),
                "receipt_hash": str(report["receipt_hash"]),
                "redacted_fields": int(report["redacted_fields"]),
                "redacted_values": int(report["redacted_values"]),
            }
        )

    return {
        "ok": True,
        "profile": _normalize_profile(profile),
        "policy_fingerprint": policy_fingerprint,
        "source_dir": source_dir.as_posix(),
        "output_dir": target_dir.as_posix(),
        "processed_count": len(entries),
        "entries": entries,
    }


@dataclass(frozen=True)
class ReceiptConfig:
    receipt_version: str = "0.1"
    env_allowlist: tuple[str, ...] = ()
    include_lockfile: bool = True
    include_git: bool = True


@dataclass(frozen=True)
class DirectoryReceiptConfig:
    mode: str = "deterministic"
    include_patterns: tuple[str, ...] = (r".*",)
    exclude_patterns: tuple[str, ...] = DEFAULT_DIRECTORY_EXCLUDE_PATTERNS
    follow_symlinks: bool = False
    receipt_version: str = "0.2"


def default_directory_receipt_policy(mode: str = "deterministic") -> dict[str, Any]:
    mode = str(mode)
    if mode not in VALID_RECEIPT_MODES:
        raise ValueError(f"Unsupported receipt mode '{mode}'. Expected one of: {sorted(VALID_RECEIPT_MODES)}")
    return {
        "policy_version": "1",
        "mode": mode,
        "include": [r".*"],
        "exclude": list(DEFAULT_DIRECTORY_EXCLUDE_PATTERNS),
        "follow_symlinks": False,
    }


def _collect_directory_entries(root_path: Path, config: DirectoryReceiptConfig) -> list[dict[str, Any]]:
    include_patterns = _compile_patterns(tuple(config.include_patterns))
    exclude_patterns = _compile_patterns(tuple(config.exclude_patterns))

    files: list[dict[str, Any]] = []
    for current_root, dir_names, file_names in os.walk(
        root_path,
        topdown=True,
        followlinks=config.follow_symlinks,
    ):
        base = Path(current_root)

        keep_dirs: list[str] = []
        for dir_name in sorted(dir_names):
            rel_dir = (base / dir_name).relative_to(root_path).as_posix()
            if _matches_any(rel_dir, exclude_patterns):
                continue
            keep_dirs.append(dir_name)
        dir_names[:] = keep_dirs

        for file_name in sorted(file_names):
            candidate = base / file_name
            if candidate.is_symlink() and not config.follow_symlinks:
                continue
            if not candidate.is_file():
                continue

            rel_path = candidate.relative_to(root_path).as_posix()
            if not _should_include(rel_path, include_patterns, exclude_patterns):
                continue

            files.append(
                {
                    "path": rel_path,
                    "size": int(candidate.stat().st_size),
                    "sha256": _sha256_hex_file(candidate),
                }
            )

    files.sort(key=lambda item: item["path"])
    return files


def _build_events_list(
    duration_ms: int,
    pre_events: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Merge pre-collected events with start/end sentinels.

    If *pre_events* is provided the list is assumed to already contain
    a ``{"t": 0, "kind": "start"}`` sentinel.  An ``end`` sentinel is
    always appended.
    """
    end_event = {"t": int(duration_ms), "kind": "end"}
    if pre_events is not None:
        merged = list(pre_events)
        # Strip any existing end sentinel so we can re-add with final duration
        merged = [e for e in merged if e.get("kind") != "end"]
        merged.append(end_event)
        return merged
    return [{"t": 0, "kind": "start"}, end_event]


def build_receipt(
    *,
    sona_version: str,
    entry_file: Path,
    project_root: Path,
    argv: list[str],
    exit_code: int,
    duration_ms: int,
    error_text: Optional[str],
    config: ReceiptConfig,
    pre_events: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    entry_file = entry_file.resolve()
    project_root = project_root.resolve()

    code_hash = _sha256_file(entry_file) if entry_file.exists() else None

    lock_path = project_root / "sona.lock.json"
    lock_exists = config.include_lockfile and lock_path.exists()
    lock_hash = _sha256_file(lock_path) if lock_exists else None

    env_out: dict[str, str] = {}
    for key in config.env_allowlist:
        if key in os.environ:
            env_out[key] = os.environ[key]

    git = _git_info(project_root) if config.include_git else {"git_commit": None, "dirty": None}

    receipt: dict[str, Any] = {
        "sona_version": str(sona_version),
        "receipt_version": str(config.receipt_version),
        "timestamp_utc": _utc_timestamp(),
        "header": {
            "policy_fingerprint": None,
            "engine_policy_fingerprint": _engine_policy_fingerprint(),
            "prev_receipt_hash": None,
        },
        "code": {
            "entry_file": str(entry_file),
            "file_hash": code_hash,
            **git,
        },
        "dependencies": {
            "lockfile": str(lock_path) if lock_exists else None,
            "lock_hash": lock_hash,
        },
        "inputs": {
            "args": list(argv),
            "env_allowlist": env_out,
        },
        "execution": {
            "exit_code": int(exit_code),
            "duration_ms": int(duration_ms),
            "errors": [] if not error_text else [{"kind": "error", "text": str(error_text)}],
            "events": _build_events_list(duration_ms, pre_events),
        },
        "reproduce": {
            "command": f"sona run {entry_file.name}",
            "contract": None,
        },
    }
    _attach_receipt_hash(receipt)

    return receipt


def build_directory_receipt(
    *,
    root_path: Path,
    config: DirectoryReceiptConfig,
    prev_receipt_hash: str | None = None,
) -> dict[str, Any]:
    mode = str(config.mode)
    if mode not in VALID_RECEIPT_MODES:
        raise ValueError(f"Unsupported receipt mode '{mode}'. Expected one of: {sorted(VALID_RECEIPT_MODES)}")

    root = root_path.resolve()
    if not root.exists():
        raise FileNotFoundError(f"Directory not found: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"Expected directory path: {root}")

    entries = _collect_directory_entries(root, config)
    total_bytes = sum(int(entry["size"]) for entry in entries)
    tree_hash = _tree_sha256(entries)

    policy: dict[str, Any] = {
        "include": list(config.include_patterns),
        "exclude": list(config.exclude_patterns),
        "follow_symlinks": bool(config.follow_symlinks),
    }
    policy_fingerprint = _policy_fingerprint(policy)
    normalized_prev = _normalize_hash(prev_receipt_hash)

    if mode == "deterministic":
        receipt_id = str(
            uuid.uuid5(
                uuid.NAMESPACE_URL,
                f"{tree_hash}:{policy_fingerprint}",
            )
        )
    else:
        receipt_id = str(uuid.uuid4())

    receipt: dict[str, Any] = {
        "receipt_kind": "directory_integrity",
        "receipt_version": str(config.receipt_version),
        "mode": mode,
        "receipt_id": receipt_id,
        "root_path": root.as_posix(),
        "header": {
            "policy_fingerprint": policy_fingerprint,
            "engine_policy_fingerprint": _engine_policy_fingerprint(),
            "prev_receipt_hash": normalized_prev,
        },
        "policy": policy,
        "files": entries,
        "summary": {
            "total_files": len(entries),
            "total_bytes": int(total_bytes),
            "tree_sha256": tree_hash,
        },
    }

    if mode == "audit":
        receipt["created_at_utc"] = _utc_timestamp()
        receipt["audit"] = {
            "hostname": socket.gethostname(),
            "username": getpass.getuser(),
            "platform": platform.platform(),
        }

    _attach_receipt_hash(receipt)

    return receipt


def load_receipt_json(path: Path) -> dict[str, Any]:
    receipt_path = path.resolve()
    if not receipt_path.exists():
        raise FileNotFoundError(f"Receipt not found: {receipt_path}")
    try:
        payload = json.loads(receipt_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"Failed to parse receipt JSON at {receipt_path}: {exc}") from exc

    if not isinstance(payload, dict):
        raise ValueError(f"Receipt JSON must contain an object at root: {receipt_path}")
    return payload


def receipt_hash_from_file(path: Path) -> str:
    receipt = load_receipt_json(path)
    embedded = receipt.get("receipt_hash")
    normalized = _normalize_hash(embedded)
    if normalized:
        return normalized
    return receipt_sha256(receipt)


def _receipt_header(payload: dict[str, Any]) -> dict[str, Any]:
    header = payload.get("header", {})
    if isinstance(header, dict):
        return header
    return {}


def _receipt_embedded_hash(payload: dict[str, Any]) -> str | None:
    normalized = _normalize_hash(payload.get("receipt_hash"))
    if normalized:
        return normalized
    header = _receipt_header(payload)
    return _normalize_hash(header.get("receipt_hash"))


def _receipt_prev_hash(payload: dict[str, Any]) -> str | None:
    header = _receipt_header(payload)
    return _normalize_hash(header.get("prev_receipt_hash"))


def verify_receipt_chain(
    receipt_files: list[Path],
    *,
    head: str | None = None,
    max_depth: int | None = None,
) -> dict[str, Any]:
    """
    Verify receipt hash-chain integrity.

    - validates each receipt's canonical hash against embedded `receipt_hash`
    - validates `prev_receipt_hash` linkage
    - returns first divergence index and reason when broken
    """
    records: list[dict[str, Any]] = []
    for path in sorted(receipt_files, key=lambda item: item.resolve().as_posix()):
        payload = load_receipt_json(path)
        embedded_hash = _receipt_embedded_hash(payload)
        if embedded_hash is None:
            # Skip non-receipt JSON files.
            continue
        canonical_hash = receipt_sha256(payload)
        prev_hash = _receipt_prev_hash(payload)
        records.append(
            {
                "path": path.resolve().as_posix(),
                "receipt_id": str(payload.get("receipt_id", "")),
                "canonical_hash": canonical_hash,
                "embedded_hash": embedded_hash,
                "prev_receipt_hash": prev_hash,
                "hash_match": embedded_hash == canonical_hash,
            }
        )

    if not records:
        empty_certificate = {
            "chain_length": 0,
            "head_hash": "",
            "tail_hash": "",
            "head_receipt_id": "",
            "tail_receipt_id": "",
            "truncated": False,
        }
        return {
            "ok": False,
            "reason": "no_receipts",
            "available_receipts": 0,
            "chain_length": 0,
            "head_path": "",
            "tail_path": "",
            "head_receipt_hash": "",
            "tail_receipt_hash": "",
            "checked_paths": [],
            "disconnected_count": 0,
            "disconnected_paths": [],
            "certificate": empty_certificate,
            "divergence": {"index": 0, "reason": "no_receipts"},
        }

    by_hash: dict[str, list[dict[str, Any]]] = {}
    for record in records:
        for key in {record["canonical_hash"], record["embedded_hash"]}:
            if not key:
                continue
            by_hash.setdefault(key, []).append(record)

    selected_head: dict[str, Any] | None = None
    head_selector = str(head or "").strip()
    if head_selector:
        head_path = Path(head_selector)
        if head_path.exists():
            resolved = head_path.resolve().as_posix()
            for record in records:
                if record["path"] == resolved:
                    selected_head = record
                    break
        normalized_head = _normalize_hash(head_selector)
        if selected_head is None and normalized_head:
            candidates = by_hash.get(normalized_head, [])
            if candidates:
                selected_head = sorted(candidates, key=lambda item: str(item["path"]))[0]
        if selected_head is None:
            for record in records:
                if str(record["receipt_id"]) == head_selector:
                    selected_head = record
                    break
        if selected_head is None:
            empty_certificate = {
                "chain_length": 0,
                "head_hash": "",
                "tail_hash": "",
                "head_receipt_id": "",
                "tail_receipt_id": "",
                "truncated": False,
            }
            return {
                "ok": False,
                "reason": "head_not_found",
                "available_receipts": len(records),
                "chain_length": 0,
                "head_path": "",
                "tail_path": "",
                "head_receipt_hash": "",
                "tail_receipt_hash": "",
                "checked_paths": [],
                "disconnected_count": len(records),
                "disconnected_paths": sorted(str(item["path"]) for item in records),
                "certificate": empty_certificate,
                "divergence": {
                    "index": 0,
                    "reason": "head_not_found",
                    "head": head_selector,
                },
            }
    else:
        prev_hashes = {str(item["prev_receipt_hash"]) for item in records if item.get("prev_receipt_hash")}
        candidates: list[dict[str, Any]] = []
        for record in records:
            identities = {record["canonical_hash"], record["embedded_hash"]}
            if any(identity in prev_hashes for identity in identities if identity):
                continue
            candidates.append(record)
        if not candidates:
            candidates = list(records)
        selected_head = sorted(candidates, key=lambda item: str(item["path"]))[-1]

    max_depth_value = int(max_depth) if max_depth is not None and int(max_depth) > 0 else None
    chain: list[dict[str, Any]] = []
    visited_hashes: set[str] = set()
    divergence: dict[str, Any] | None = None
    truncated = False
    current = selected_head

    while current is not None:
        index = len(chain)
        chain.append(current)

        canonical_hash = str(current["canonical_hash"])
        if canonical_hash in visited_hashes:
            divergence = {
                "index": index,
                "reason": "cycle_detected",
                "path": current["path"],
                "receipt_hash": canonical_hash,
            }
            break
        visited_hashes.add(canonical_hash)

        if not bool(current["hash_match"]):
            divergence = {
                "index": index,
                "reason": "receipt_hash_mismatch",
                "path": current["path"],
                "embedded_hash": current["embedded_hash"],
                "canonical_hash": canonical_hash,
            }
            break

        prev_hash = current.get("prev_receipt_hash")
        if not prev_hash:
            break

        if max_depth_value is not None and len(chain) >= max_depth_value:
            truncated = True
            break

        prev_candidates = by_hash.get(str(prev_hash), [])
        unique_candidates: dict[str, dict[str, Any]] = {}
        for candidate in prev_candidates:
            unique_candidates[str(candidate["canonical_hash"])] = candidate
        normalized_candidates = list(unique_candidates.values())

        if not normalized_candidates:
            divergence = {
                "index": index,
                "reason": "missing_prev_receipt",
                "path": current["path"],
                "expected_prev_hash": prev_hash,
            }
            break
        if len(normalized_candidates) > 1:
            divergence = {
                "index": index,
                "reason": "ambiguous_prev_receipt",
                "path": current["path"],
                "expected_prev_hash": prev_hash,
                "candidate_paths": sorted(str(item["path"]) for item in normalized_candidates),
            }
            break

        previous = normalized_candidates[0]
        if str(prev_hash) != str(previous["canonical_hash"]):
            divergence = {
                "index": index,
                "reason": "prev_hash_not_canonical",
                "path": current["path"],
                "expected_prev_hash": prev_hash,
                "actual_prev_canonical_hash": previous["canonical_hash"],
                "prev_path": previous["path"],
            }
            break

        current = previous

    chain_hashes = {str(item["canonical_hash"]) for item in chain}
    disconnected_paths = sorted(
        str(item["path"]) for item in records if str(item["canonical_hash"]) not in chain_hashes
    )

    head_record = chain[0] if chain else None
    tail_record = chain[-1] if chain else None
    certificate = {
        "chain_length": len(chain),
        "head_hash": str(head_record["canonical_hash"]) if head_record else "",
        "tail_hash": str(tail_record["canonical_hash"]) if tail_record else "",
        "head_receipt_id": str(head_record.get("receipt_id", "")) if head_record else "",
        "tail_receipt_id": str(tail_record.get("receipt_id", "")) if tail_record else "",
        "truncated": bool(truncated),
    }

    ok = divergence is None
    return {
        "ok": ok,
        "reason": "ok" if ok else str(divergence.get("reason", "invalid_chain")),
        "available_receipts": len(records),
        "chain_length": len(chain),
        "head_path": str(head_record["path"]) if head_record else "",
        "tail_path": str(tail_record["path"]) if tail_record else "",
        "head_receipt_hash": str(certificate["head_hash"]),
        "tail_receipt_hash": str(certificate["tail_hash"]),
        "checked_paths": [str(item["path"]) for item in chain],
        "disconnected_count": len(disconnected_paths),
        "disconnected_paths": disconnected_paths,
        "certificate": certificate,
        "divergence": divergence,
    }


def verify_receipt_chain_in_dir(
    receipts_dir: Path,
    *,
    head: str | None = None,
    max_depth: int | None = None,
) -> dict[str, Any]:
    directory = receipts_dir.resolve()
    if not directory.exists():
        raise FileNotFoundError(f"Receipt directory not found: {directory}")
    if not directory.is_dir():
        raise NotADirectoryError(f"Expected receipt directory path: {directory}")
    files = sorted(path for path in directory.glob("*.receipt.json") if path.is_file())
    return verify_receipt_chain(files, head=head, max_depth=max_depth)


def enrich_chain_certificate(
    chain_result: dict[str, Any],
    receipt_files: list[Path] | None = None,
) -> dict[str, Any]:
    """
    Enrich a chain verification result with:
    - integrity_score: fraction of chain members with valid hashes (0.0-1.0)
    - signature_coverage: count and list of signed receipts in the chain
    - chain_anchors: trust anchor points (tail, first signed receipt)
    """
    certificate = dict(chain_result.get("certificate", {}))
    checked_paths = chain_result.get("checked_paths", [])
    chain_length = int(chain_result.get("chain_length", 0))

    # --- integrity_score ---
    valid_hash_count = 0
    chain_records: list[dict[str, Any]] = []
    for checked_path in checked_paths:
        path = Path(checked_path)
        try:
            payload = load_receipt_json(path)
        except Exception:
            chain_records.append({"path": checked_path, "hash_valid": False, "signed": False})
            continue
        embedded = _receipt_embedded_hash(payload)
        canonical = receipt_sha256(payload)
        hash_valid = bool(embedded) and embedded == canonical
        if hash_valid:
            valid_hash_count += 1

        header = _receipt_header(payload)
        sig = header.get("signature")
        signed = isinstance(sig, dict) and bool(sig.get("value"))

        chain_records.append({"path": checked_path, "hash_valid": hash_valid, "signed": signed})

    integrity_score = (valid_hash_count / chain_length) if chain_length > 0 else 0.0

    # --- signature_coverage ---
    signed_paths = [rec["path"] for rec in chain_records if rec["signed"]]
    signature_coverage = {
        "signed_count": len(signed_paths),
        "total_count": chain_length,
        "signed_ratio": (len(signed_paths) / chain_length) if chain_length > 0 else 0.0,
        "signed_paths": signed_paths,
    }

    # --- chain_anchors ---
    anchors: list[dict[str, str]] = []
    if chain_records:
        anchors.append({"role": "tail", "path": chain_records[-1]["path"]})
    for rec in chain_records:
        if rec["signed"]:
            anchors.append({"role": "first_signed", "path": rec["path"]})
            break

    certificate["integrity_score"] = round(integrity_score, 4)
    certificate["signature_coverage"] = signature_coverage
    certificate["chain_anchors"] = anchors

    enriched = dict(chain_result)
    enriched["certificate"] = certificate
    return enriched


def _canonical_json_bytes(data: Any) -> bytes:
    """Single canonical JSON byte encoder for all governance hashing.

    Rule set: sort_keys, compact separators, ensure_ascii=False, UTF-8.
    Used for: manifest entry hashes, manifest hash, bundle hash.
    Matches the canonicalization used by receipt signing (ensure_ascii=False).
    """
    return json.dumps(
        data, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
    ).encode("utf-8")


def _build_bundle_manifest(
    receipts_data: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build a manifest of receipt entries with stable hashes.

    Each entry sha256 = receipt_sha256(receipt), aligning with the receipt's
    own hash contract (canonical receipt payload bytes).
    """
    entries: list[dict[str, Any]] = []
    for item in receipts_data:
        receipt = item.get("receipt")
        if receipt is None:
            # errored receipt — no manifest entry
            continue
        entry_hash = receipt_sha256(receipt)
        canonical_bytes = canonical_receipt_payload(receipt).encode("utf-8")
        entries.append({
            "path": item["path"],
            "sha256": entry_hash,
            "size": len(canonical_bytes),
        })
    manifest_payload = {"entries": entries}
    manifest_hash = hashlib.sha256(_canonical_json_bytes(manifest_payload)).hexdigest()
    manifest_payload["manifest_hash"] = manifest_hash
    return manifest_payload


def _build_chain_directory(
    receipts_data: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build a lookup directory for receipts by hash and by receipt_id.

    Raises ValueError on hash or id collisions (governance invariant).
    """
    by_hash: dict[str, str] = {}
    by_id: dict[str, str] = {}
    for item in receipts_data:
        receipt = item.get("receipt")
        if receipt is None:
            continue
        path = item["path"]
        entry_hash = receipt_sha256(receipt)
        if entry_hash in by_hash:
            raise ValueError(
                f"Receipt hash collision: {entry_hash} appears in "
                f"'{by_hash[entry_hash]}' and '{path}'"
            )
        by_hash[entry_hash] = path

        receipt_id = str(receipt.get("receipt_id", "")).strip()
        if receipt_id:
            if receipt_id in by_id:
                raise ValueError(
                    f"Receipt ID collision: {receipt_id} appears in "
                    f"'{by_id[receipt_id]}' and '{path}'"
                )
            by_id[receipt_id] = path

    return {"by_hash": by_hash, "by_id": by_id}


def export_receipt_bundle(
    receipts_dir: Path,
    out_path: Path,
    *,
    include_policy_snapshot: bool = True,
    include_lockfile: bool = False,
    workspace_dir: Path | None = None,
) -> dict[str, Any]:
    """
    Export a portable receipt bundle v0.2: manifest + chain directory +
    chain verification + all receipts + optional policy snapshot + optional lockfile.
    The bundle is a single JSON file suitable for external audit or archival.
    """
    directory = receipts_dir.resolve()
    if not directory.exists():
        raise FileNotFoundError(f"Receipt directory not found: {directory}")
    if not directory.is_dir():
        raise NotADirectoryError(f"Expected receipt directory path: {directory}")

    receipt_files = sorted(path for path in directory.glob("*.receipt.json") if path.is_file())
    chain_result = verify_receipt_chain(receipt_files)
    enriched = enrich_chain_certificate(chain_result, receipt_files)

    receipts_data: list[dict[str, Any]] = []
    for path in receipt_files:
        try:
            payload = load_receipt_json(path)
            receipts_data.append({"path": path.name, "receipt": payload})
        except Exception as exc:
            receipts_data.append({"path": path.name, "error": str(exc)})

    manifest = _build_bundle_manifest(receipts_data)
    chain_directory = _build_chain_directory(receipts_data)

    bundle: dict[str, Any] = {
        "bundle_version": "0.2",
        "bundle_kind": "receipt_export",
        "created_at_utc": _utc_timestamp(),
        "source_dir": directory.as_posix(),
        "manifest": manifest,
        "chain_directory": chain_directory,
        "chain_verification": enriched,
        "receipts": receipts_data,
        "receipt_count": len(receipts_data),
    }

    if include_policy_snapshot:
        try:
            from .policy import policy_snapshot

            bundle["policy_snapshot"] = policy_snapshot()
        except Exception:
            bundle["policy_snapshot"] = None

    if include_lockfile and workspace_dir is not None:
        try:
            from .lockfile_manager import lockfile_payload

            bundle["lockfile"] = lockfile_payload(workspace_dir)
        except Exception:
            bundle["lockfile"] = None

    # Compute bundle hash over everything except bundle_hash itself
    bundle_hash = hashlib.sha256(_canonical_json_bytes(bundle)).hexdigest()
    bundle["bundle_hash"] = bundle_hash

    out_path = out_path.resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    payload_text = json.dumps(bundle, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    tmp_path = out_path.with_suffix(out_path.suffix + ".tmp")
    tmp_path.write_text(payload_text, encoding="utf-8", newline="\n")
    tmp_path.replace(out_path)

    return {
        "ok": True,
        "bundle_path": out_path.as_posix(),
        "bundle_hash": bundle_hash,
        "receipt_count": len(receipts_data),
        "chain_ok": bool(enriched.get("ok")),
        "chain_length": int(enriched.get("chain_length", 0)),
        "manifest_hash": manifest.get("manifest_hash", ""),
    }


def verify_receipt_bundle(bundle: dict[str, Any] | str | Path) -> dict[str, Any]:
    """Verify a receipt bundle's integrity: bundle hash, manifest hashes, receipt count.

    Accepts a bundle dict, a JSON string, or a path to a bundle file.
    """
    if isinstance(bundle, (str, Path)):
        bundle_path = Path(bundle).resolve()
        bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
    if not isinstance(bundle, dict):
        raise ValueError("Bundle must be a JSON object.")

    stored_bundle_hash = str(bundle.get("bundle_hash", "")).strip().lower()

    # Recompute bundle hash (exclude bundle_hash field itself)
    bundle_copy = {k: v for k, v in bundle.items() if k != "bundle_hash"}
    recomputed_bundle_hash = hashlib.sha256(_canonical_json_bytes(bundle_copy)).hexdigest()
    bundle_hash_ok = hmac.compare_digest(stored_bundle_hash, recomputed_bundle_hash)

    # Verify manifest entries
    manifest = bundle.get("manifest", {})
    manifest_entries = manifest.get("entries", [])
    stored_manifest_hash = str(manifest.get("manifest_hash", "")).strip().lower()

    # Recompute manifest hash (over entries only, not manifest_hash itself)
    manifest_for_hash = {"entries": manifest_entries}
    recomputed_manifest_hash = hashlib.sha256(
        _canonical_json_bytes(manifest_for_hash)
    ).hexdigest()
    manifest_hash_ok = hmac.compare_digest(stored_manifest_hash, recomputed_manifest_hash)

    # Verify each receipt entry hash matches manifest
    receipts_data = bundle.get("receipts", [])
    entry_index = {e["path"]: e for e in manifest_entries}
    entry_mismatches: list[dict[str, str]] = []
    for item in receipts_data:
        receipt = item.get("receipt")
        if receipt is None:
            continue
        path = item["path"]
        expected_entry = entry_index.get(path)
        if expected_entry is None:
            entry_mismatches.append({"path": path, "reason": "missing_from_manifest"})
            continue
        actual_hash = receipt_sha256(receipt)
        if actual_hash != expected_entry["sha256"]:
            entry_mismatches.append({
                "path": path,
                "reason": "hash_mismatch",
                "expected": expected_entry["sha256"],
                "actual": actual_hash,
            })

    manifest_ok = manifest_hash_ok and len(entry_mismatches) == 0
    ok = bundle_hash_ok and manifest_ok

    reason = "ok"
    if not bundle_hash_ok:
        reason = "bundle_hash_mismatch"
    elif not manifest_hash_ok:
        reason = "manifest_hash_mismatch"
    elif entry_mismatches:
        reason = "entry_hash_mismatch"

    return {
        "ok": ok,
        "reason": reason,
        "bundle_hash_ok": bundle_hash_ok,
        "manifest_ok": manifest_ok,
        "manifest_hash_ok": manifest_hash_ok,
        "receipt_count": len(receipts_data),
        "entry_mismatches": entry_mismatches,
        "stored_bundle_hash": stored_bundle_hash,
        "recomputed_bundle_hash": recomputed_bundle_hash,
    }


@dataclass(frozen=True)
class ReplayContract:
    """
    Replay contract: defines expectations for deterministic replay of a receipt.
    A receipt can declare what inputs/outputs should remain stable on replay.
    """
    command: str = ""
    expected_tree_sha256: str = ""
    expected_receipt_hash: str = ""
    mode: str = "deterministic"
    tolerance: str = "exact"

    def to_dict(self) -> dict[str, Any]:
        return {
            "command": self.command,
            "expected_tree_sha256": self.expected_tree_sha256,
            "expected_receipt_hash": self.expected_receipt_hash,
            "mode": self.mode,
            "tolerance": self.tolerance,
        }


def verify_replay_contract(
    receipt: dict[str, Any],
    current_receipt: dict[str, Any],
) -> dict[str, Any]:
    """
    Verify that a replayed receipt matches the original's contract expectations.
    Compares tree_sha256, receipt_hash, and mode stability.
    """
    original_summary = receipt.get("summary", {})
    current_summary = current_receipt.get("summary", {})

    original_tree = str(original_summary.get("tree_sha256", ""))
    current_tree = str(current_summary.get("tree_sha256", ""))
    tree_match = bool(original_tree) and original_tree == current_tree

    original_hash = receipt_sha256(receipt)
    current_hash = receipt_sha256(current_receipt)
    hash_match = original_hash == current_hash

    original_mode = str(receipt.get("mode", ""))
    current_mode = str(current_receipt.get("mode", ""))
    mode_match = original_mode == current_mode

    original_policy_fp = str(receipt.get("header", {}).get("policy_fingerprint", ""))
    current_policy_fp = str(current_receipt.get("header", {}).get("policy_fingerprint", ""))
    policy_match = bool(original_policy_fp) and original_policy_fp == current_policy_fp

    ok = tree_match and hash_match and mode_match and policy_match

    return {
        "ok": ok,
        "tree_sha256_match": tree_match,
        "receipt_hash_match": hash_match,
        "mode_match": mode_match,
        "policy_fingerprint_match": policy_match,
        "original_tree_sha256": original_tree,
        "current_tree_sha256": current_tree,
        "original_receipt_hash": original_hash,
        "current_receipt_hash": current_hash,
    }


def diff_directory_receipts(
    receipt_a: dict[str, Any],
    receipt_b: dict[str, Any],
) -> dict[str, Any]:
    index_a = _entry_index(receipt_a)
    index_b = _entry_index(receipt_b)

    paths_a = set(index_a.keys())
    paths_b = set(index_b.keys())

    added = sorted(paths_b - paths_a)
    removed = sorted(paths_a - paths_b)

    changed: list[dict[str, Any]] = []
    for path in sorted(paths_a & paths_b):
        entry_a = index_a[path]
        entry_b = index_b[path]
        if (entry_a["sha256"], entry_a["size"]) != (entry_b["sha256"], entry_b["size"]):
            changed.append(
                {
                    "path": path,
                    "sha256_a": entry_a["sha256"],
                    "sha256_b": entry_b["sha256"],
                    "size_a": int(entry_a["size"]),
                    "size_b": int(entry_b["size"]),
                }
            )

    summary_a = receipt_a.get("summary", {})
    summary_b = receipt_b.get("summary", {})
    tree_a = str(summary_a.get("tree_sha256", ""))
    tree_b = str(summary_b.get("tree_sha256", ""))

    return {
        "same_tree_hash": bool(tree_a and tree_a == tree_b),
        "tree_sha256_a": tree_a,
        "tree_sha256_b": tree_b,
        "added": added,
        "removed": removed,
        "changed": changed,
        "added_count": len(added),
        "removed_count": len(removed),
        "changed_count": len(changed),
    }


def verify_directory_receipt(
    receipt: dict[str, Any],
    root_path: Path,
) -> dict[str, Any]:
    policy_raw = receipt.get("policy", {})
    policy = policy_raw if isinstance(policy_raw, dict) else {}
    include_patterns_raw = policy.get("include", (r".*",))
    exclude_patterns_raw = policy.get("exclude", DEFAULT_DIRECTORY_EXCLUDE_PATTERNS)

    include_patterns = tuple(str(item) for item in (include_patterns_raw or (r".*",)))
    exclude_patterns = tuple(str(item) for item in (exclude_patterns_raw or ()))

    config = DirectoryReceiptConfig(
        mode="deterministic",
        include_patterns=include_patterns,
        exclude_patterns=exclude_patterns,
        follow_symlinks=bool(policy.get("follow_symlinks", False)),
        receipt_version=str(receipt.get("receipt_version", "0.2")),
    )

    current = build_directory_receipt(root_path=root_path, config=config)
    diff = diff_directory_receipts(receipt, current)

    expected_summary = receipt.get("summary", {})
    expected_tree = str(expected_summary.get("tree_sha256", ""))
    actual_tree = str(current.get("summary", {}).get("tree_sha256", ""))
    expected_header = receipt.get("header", {})
    actual_header = current.get("header", {})
    expected_policy_fingerprint = ""
    actual_policy_fingerprint = ""
    expected_engine_policy_fingerprint = ""
    actual_engine_policy_fingerprint = ""
    if isinstance(expected_header, dict):
        expected_policy_fingerprint = str(expected_header.get("policy_fingerprint", ""))
        expected_engine_policy_fingerprint = str(expected_header.get("engine_policy_fingerprint", ""))
    if isinstance(actual_header, dict):
        actual_policy_fingerprint = str(actual_header.get("policy_fingerprint", ""))
        actual_engine_policy_fingerprint = str(actual_header.get("engine_policy_fingerprint", ""))

    structural_match = (
        diff["added_count"] == 0
        and diff["removed_count"] == 0
        and diff["changed_count"] == 0
    )
    tree_match = (expected_tree == actual_tree) if expected_tree else structural_match
    policy_match = True
    if expected_policy_fingerprint:
        policy_match = expected_policy_fingerprint == actual_policy_fingerprint
    engine_policy_match = True
    if expected_engine_policy_fingerprint:
        engine_policy_match = expected_engine_policy_fingerprint == actual_engine_policy_fingerprint

    return {
        "ok": bool(structural_match and tree_match and policy_match and engine_policy_match),
        "root_path": root_path.resolve().as_posix(),
        "expected_tree_sha256": expected_tree,
        "actual_tree_sha256": actual_tree,
        "expected_policy_fingerprint": expected_policy_fingerprint,
        "actual_policy_fingerprint": actual_policy_fingerprint,
        "policy_match": policy_match,
        "expected_engine_policy_fingerprint": expected_engine_policy_fingerprint,
        "actual_engine_policy_fingerprint": actual_engine_policy_fingerprint,
        "engine_policy_match": engine_policy_match,
        "added": diff["added"],
        "removed": diff["removed"],
        "changed": diff["changed"],
        "added_count": diff["added_count"],
        "removed_count": diff["removed_count"],
        "changed_count": diff["changed_count"],
    }


def write_receipt_json(receipt: dict[str, Any], out_path: Path) -> None:
    """
    Deterministic JSON serialization:
    - sorted keys
    - fixed indentation
    - LF newlines

    Atomic write to avoid partial receipts.
    """
    out_path = out_path.resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    payload = (
        json.dumps(
            receipt,
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
        )
        + "\n"
    )

    tmp_path = out_path.with_suffix(out_path.suffix + ".tmp")
    tmp_path.write_text(payload, encoding="utf-8", newline="\n")
    tmp_path.replace(out_path)
