use std::collections::HashMap;
use std::sync::Arc;

use infojenn::TermPair;
use ontolius::ontology::HierarchyQueries;
use ontolius::{Identified, TermId};
use phenotypes::Observable;

use super::SimilarityMeasure;

pub struct PrecomputedIcMicaSimilarityMeasure<O> {
    hpo: Arc<O>,
    mica_dict: Arc<HashMap<TermPair, f64>>,
    ic_dict: HashMap<TermId, f64>,
}

impl<O> PrecomputedIcMicaSimilarityMeasure<O> {
    pub fn new(mica_dict: Arc<HashMap<TermPair, f64>>, hpo: Arc<O>) -> Self {
        let mut ic_dict = HashMap::with_capacity(mica_dict.len());
        for (term_id, ic) in mica_dict.iter() {
            if term_id.left() == term_id.right() {
                ic_dict.insert(Clone::clone(term_id.left()), *ic);
            }
        }
        ic_dict.shrink_to_fit();

        PrecomputedIcMicaSimilarityMeasure {
            hpo,
            mica_dict,
            ic_dict,
        }
    }
}

impl<O, A> SimilarityMeasure<A> for PrecomputedIcMicaSimilarityMeasure<O>
where
    O: HierarchyQueries,
    A: Identified + Observable,
{
    type Value = f64;

    fn compute_similarity(&self, a: &A, b: &A) -> anyhow::Result<Self::Value> {
        // This similarity measure only works for present/observed terms.
        let tp = TermPair::from((a.identifier(), b.identifier()));
        if a.is_present() && b.is_present() {
            Ok(compute_present(self.mica_dict.as_ref(), &tp))
        } else if a.is_excluded() && b.is_excluded() {
            Ok(compute_excluded(self.hpo.as_ref(), &self.ic_dict, a, b))
        } else {
            // Cannot compute similarity between present and excluded terms.
            anyhow::bail!("Cannot compute similarity between present and excluded feature")
        }
    }

    fn is_symmetric(&self) -> bool {
        true
    }
}

pub(crate) fn compute_present(mica_dict: &HashMap<TermPair, f64>, tp: &TermPair) -> f64
{
    // Assume both phenotypic features are present.
    if let Some(val) = mica_dict.get(tp) {
        return *val;
    }
    0.
}

pub(crate) fn compute_excluded<Q, A>(hpo: &Q, ic_dict: &HashMap<TermId, f64>, a: &A, b: &A) -> f64
where
    Q: HierarchyQueries,
    A: Identified,
{
    // Assume both phenotypic features are excluded.
    if let Some(chosen) = choose_priority_term_id(hpo, a, b) {
        ic_dict
            .get(chosen)
            .copied()
            .expect("Term should be in `ic_dict`")
    } else {
        0.
    }
}

pub(crate) fn choose_priority_term_id<'a, Q, A>(hpo: &Q, a: &'a A, b: &'a A) -> Option<&'a TermId>
where
    Q: HierarchyQueries,
    A: Identified,
{
    if hpo.is_equal_or_ancestor_of(b, a) {
        Some(b.identifier())
    } else if hpo.is_ancestor_of(a, b) {
        Some(a.identifier())
    } else {
        None
    }
}
