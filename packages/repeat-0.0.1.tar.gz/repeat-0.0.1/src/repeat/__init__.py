def main() -> None:
    print("Hello from repeat!")
