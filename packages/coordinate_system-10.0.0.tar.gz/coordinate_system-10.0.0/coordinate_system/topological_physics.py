"""
Topological-physics application module (public API).

This module intentionally exposes only application-oriented interfaces
for practical workflows (fluid, boundary-stall, particle-mass, DM shell scans,
friction, velocity-decay, non-Newtonian viscosity, sunspot cycle, and
geomagnetic reversal).

Low-level unified field equations and raw coupling internals are NOT part of
this public surface.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List

# Internal constants (not exported)
_ALPHA_FS = 1.0 / 137.036
_THETA = 1.0
_E0_EV = 0.026
_BETA_MASS = 0.5

# CFUT coupling constants (first-principles, from alpha = 1/137.036)
_LAMBDA0_BASE = 4.0 * math.pi * _ALPHA_FS  # lambda_0 = 4*pi*alpha ≈ 0.09170
_E_REF_EV = 0.40            # E_ref energy scale (eV)

# Internal effective coefficients for application-level closures.
# These are intentionally kept internal and may be recalibrated in future releases.
_STALL_GAIN_COEFF = 0.0425
_NON_NEWTONIAN_COEFF = 0.085

# Observational sunspot-cycle statistics (SILSO monthly data, 1749–present)
# Source: solar_sunspot_minima_cycles_2026-03-05.csv, n=20 identified cycles
_SUNSPOT_N_CYCLES = 20
_SUNSPOT_MEDIAN_MONTHS = 136.0    # ~11.33 years
_SUNSPOT_MIN_MONTHS = 120.0       # ~10.0 years
_SUNSPOT_MAX_MONTHS = 274.0       # ~22.83 years
_MONTHS_PER_YEAR = 12.0


def _lambda0() -> float:
    return 4.0 * math.pi * _ALPHA_FS * _THETA


def _lambda_energy(energy_ev: float) -> float:
    """Energy-dependent CFUT coupling: lambda(E) = lambda_0 * exp(-E / E_ref)."""
    return _LAMBDA0_BASE * math.exp(-energy_ev / _E_REF_EV)


def _mass_unit_beta_half_eV() -> float:
    lam0 = _lambda0()
    return (lam0 * lam0) / _E0_EV


def _mass_from_winding_eV(winding_n: int) -> float:
    if winding_n <= 0:
        raise ValueError("winding_n must be positive")
    m_unit = _mass_unit_beta_half_eV()
    return m_unit * float(winding_n) ** 2


def _winding_from_mass(mass_eV: float, rounded: bool = True) -> int | float:
    if mass_eV <= 0:
        raise ValueError("mass_eV must be positive")
    m_unit = _mass_unit_beta_half_eV()
    n_real = math.sqrt(mass_eV / m_unit)
    return int(round(n_real)) if rounded else n_real


# ============================================================
# Existing dataclasses
# ============================================================

@dataclass(frozen=True)
class StallPrediction:
    """Boundary-flow dynamic-stall application output."""

    n_ceiling: float
    gain_factor: float
    cl_max_pred: float


@dataclass(frozen=True)
class NonNewtonianResult:
    """Non-Newtonian application output (topology-index model)."""

    n_effective: float
    viscosity_ratio: float
    mu_effective_pa_s: float


@dataclass(frozen=True)
class MassResult:
    """Particle-mass application output."""

    winding_n: int
    mass_eV: float
    mass_MeV: float


@dataclass(frozen=True)
class DMShellResult:
    """Dark-matter nearest-shell result."""

    target_mass_GeV: float
    winding_n: int
    shell_mass_GeV: float
    rel_error_pct: float
    shell_spacing_MeV: float


# ============================================================
# New dataclasses (v8.2)
# ============================================================

@dataclass(frozen=True)
class FrictionResult:
    """
    CFUT unified friction force at a given sliding velocity.

    Formula (from CFUT first-principles derivation):
        F_f(v) = [mu_k + (mu_s - mu_k) / (1 + (v/v_c)^p)] * N

    Limits:
        v -> 0  : F_f -> mu_s * N   (maximum static friction)
        v -> inf: F_f -> mu_k * N   (kinetic friction plateau)
    """

    velocity_m_s: float
    normal_force_n: float
    friction_force_n: float
    mu_effective: float


@dataclass(frozen=True)
class VelocityDecayResult:
    """
    Stopping analysis for a body decelerating under CFUT friction.

    Uses the velocity-dependent friction force to estimate
    approximate deceleration, stopping time, and stopping distance
    at the given initial velocity (first-order linear approximation).
    """

    initial_velocity_m_s: float
    mass_kg: float
    deceleration_m_s2: float      # |a| at initial velocity
    approx_stopping_time_s: float  # v0 / |a(v0)|  (upper-bound estimate)
    approx_stopping_dist_m: float  # v0^2 / (2*|a(v0)|)  (upper-bound estimate)


@dataclass(frozen=True)
class VelocityViscosityResult:
    """
    CFUT velocity-dependent viscosity for non-Newtonian fluids.

    Formula (from CFUT fluid application framework):
        mu(v) = mu_0 * [1 + lambda(E) * N_topo * (1 - exp(-v / v_char))] + mu_basic

    where lambda(E) = lambda_0 * exp(-E / E_ref) is the energy-dependent coupling.
    """

    velocity_m_s: float
    viscosity_pa_s: float
    lambda_coupling: float
    topology_index: float


@dataclass(frozen=True)
class SunspotCycleStats:
    """
    Observational sunspot-cycle statistics derived from SILSO monthly data.

    Source: SILSO Sunspot Number v2.0, 1749-present.
    Method: 13-month moving average, minima < 15, spacing >= 100 months.
    Evidence level: medium-strong observational constraint (CFUT compatibility).
    """

    n_cycles_observed: int
    median_months: float
    min_months: float
    max_months: float
    median_years: float
    min_years: float
    max_years: float


@dataclass(frozen=True)
class GeomagneticReversalResult:
    """
    CFUT geomagnetic reversal period estimate.

    Formula:
        tau_rev = (2*pi / alpha) * 1 / sqrt(1 - beta*(B_tor/B_pol)^2)

        alpha = (Q_CMB - Q_cond) / (beta * E_m)
        Q_CMB = Q0 * (v_sub/v_sub0)^3 * (1 + A_LIP/A_ref)

    Note: The raw formula yields ~4 kyr without beta calibration.
    Matching the observed ~0.25 Myr median requires beta ~ 5-7e-5.
    Evidence level: structural compatibility; beta requires calibration.
    """

    period_s: float
    period_kyr: float
    period_myr: float
    alpha_rate_per_s: float
    q_cmb_w: float
    beta_used: float


# ============================================================
# Existing functions
# ============================================================

def predict_dynamic_stall(cl_max_static: float, delta_alpha_deg: float) -> StallPrediction:
    """
    Predict dynamic-stall peak lift from static peak lift and pitch amplitude.

    Args:
        cl_max_static: Static Cl,max baseline.
        delta_alpha_deg: Pitch amplitude in degrees.
    """
    if cl_max_static <= 0:
        raise ValueError("cl_max_static must be positive")
    if delta_alpha_deg <= 0:
        raise ValueError("delta_alpha_deg must be positive")

    n_ceiling = math.pi * math.radians(delta_alpha_deg) / _lambda0()
    gain = 1.0 + _STALL_GAIN_COEFF * n_ceiling
    return StallPrediction(n_ceiling=n_ceiling, gain_factor=gain, cl_max_pred=cl_max_static * gain)


def estimate_non_newtonian(mu_reference_pa_s: float, mu_observed_pa_s: float) -> NonNewtonianResult:
    """
    Estimate effective topology index from non-Newtonian viscosity shift.

    Args:
        mu_reference_pa_s: Reference/base viscosity.
        mu_observed_pa_s: Observed effective viscosity.
    """
    if mu_reference_pa_s <= 0:
        raise ValueError("mu_reference_pa_s must be positive")
    if mu_observed_pa_s <= 0:
        raise ValueError("mu_observed_pa_s must be positive")

    ratio = mu_observed_pa_s / mu_reference_pa_s
    n_eff = max(0.0, (ratio - 1.0) / _NON_NEWTONIAN_COEFF)
    return NonNewtonianResult(n_effective=n_eff, viscosity_ratio=ratio, mu_effective_pa_s=mu_observed_pa_s)


def predict_non_newtonian_viscosity(mu_reference_pa_s: float, n_effective: float) -> NonNewtonianResult:
    """Forward prediction of effective viscosity from reference viscosity and topology index."""
    if mu_reference_pa_s <= 0:
        raise ValueError("mu_reference_pa_s must be positive")
    if n_effective < 0:
        raise ValueError("n_effective must be non-negative")

    ratio = 1.0 + _NON_NEWTONIAN_COEFF * n_effective
    mu_eff = mu_reference_pa_s * ratio
    return NonNewtonianResult(n_effective=n_effective, viscosity_ratio=ratio, mu_effective_pa_s=mu_eff)


def mass_from_winding(winding_n: int) -> MassResult:
    """Application-level particle mass calculation from winding number."""
    mass_eV = _mass_from_winding_eV(winding_n)
    return MassResult(winding_n=winding_n, mass_eV=mass_eV, mass_MeV=mass_eV / 1e6)


def infer_winding_from_mass(mass_eV: float, rounded: bool = True) -> int | float:
    """Infer winding number from particle rest mass."""
    return _winding_from_mass(mass_eV, rounded=rounded)


def proton_neutron_split(n_proton: int, n_neutron: int) -> float:
    """Return (m_n - m_p) in MeV using shared shell mass unit."""
    mp = _mass_from_winding_eV(n_proton)
    mn = _mass_from_winding_eV(n_neutron)
    return (mn - mp) / 1e6


def compute_particle_masses(winding_map: Dict[str, int]) -> Dict[str, MassResult]:
    """Batch particle-mass calculation by winding-number map."""
    out: Dict[str, MassResult] = {}
    for name, n in winding_map.items():
        out[name] = mass_from_winding(int(n))
    return out


def nearest_dm_shell(target_mass_GeV: float) -> DMShellResult:
    """Find nearest dark-matter shell for a target mass scale."""
    if target_mass_GeV <= 0:
        raise ValueError("target_mass_GeV must be positive")

    target_eV = target_mass_GeV * 1e9
    n = int(_winding_from_mass(target_eV, rounded=True))
    shell_eV = _mass_from_winding_eV(n)
    shell_next_eV = _mass_from_winding_eV(n + 1)
    rel = abs(shell_eV - target_eV) / target_eV * 100.0
    spacing_mev = (shell_next_eV - shell_eV) / 1e6
    return DMShellResult(
        target_mass_GeV=target_mass_GeV,
        winding_n=n,
        shell_mass_GeV=shell_eV / 1e9,
        rel_error_pct=rel,
        shell_spacing_MeV=spacing_mev,
    )


def dm_shell_scan(target_masses_GeV: list) -> list:
    """Batch nearest-shell scan for DM target masses."""
    return [nearest_dm_shell(v) for v in target_masses_GeV]


# ============================================================
# New functions (v8.2) — Friction, Velocity, Non-Newtonian,
#                        Sunspot Cycle, Geomagnetic Reversal
# ============================================================

def predict_friction_force(
    normal_force_n: float,
    mu_static: float,
    mu_kinetic: float,
    velocity_m_s: float,
    v_char_m_s: float = 0.01,
    power: float = 1.0,
) -> FrictionResult:
    """
    CFUT unified friction force at a given sliding velocity.

    Formula:
        F_f(v) = [mu_k + (mu_s - mu_k) / (1 + (v/v_c)^p)] * N

    Args:
        normal_force_n:  Normal force N (e.g. m*g) in Newtons.
        mu_static:       Static friction coefficient mu_s.
        mu_kinetic:      Kinetic friction coefficient mu_k.
        velocity_m_s:    Current sliding velocity (m/s); 0 gives max static friction.
        v_char_m_s:      Characteristic velocity v_c for the static-to-kinetic
                         transition (default 0.01 m/s).
        power:           Nonlinear exponent p (default 1.0 = linear transition).

    Returns:
        FrictionResult with effective friction force and coefficient.
    """
    if normal_force_n <= 0:
        raise ValueError("normal_force_n must be positive")
    if mu_static < 0 or mu_kinetic < 0:
        raise ValueError("friction coefficients must be non-negative")
    if mu_static < mu_kinetic:
        raise ValueError("mu_static should be >= mu_kinetic")
    if v_char_m_s <= 0:
        raise ValueError("v_char_m_s must be positive")
    if power <= 0:
        raise ValueError("power must be positive")

    v = abs(velocity_m_s)
    ratio = (v / v_char_m_s) ** power
    mu_eff = mu_kinetic + (mu_static - mu_kinetic) / (1.0 + ratio)
    f_friction = mu_eff * normal_force_n
    return FrictionResult(
        velocity_m_s=velocity_m_s,
        normal_force_n=normal_force_n,
        friction_force_n=f_friction,
        mu_effective=mu_eff,
    )


def predict_velocity_decay(
    mass_kg: float,
    initial_velocity_m_s: float,
    mu_static: float,
    mu_kinetic: float,
    g_m_s2: float = 9.81,
    v_char_m_s: float = 0.01,
    power: float = 1.0,
) -> VelocityDecayResult:
    """
    First-order stopping analysis for a body decelerating under CFUT friction.

    Computes the instantaneous deceleration at the initial velocity and derives
    conservative (upper-bound) estimates for stopping time and distance.

    Args:
        mass_kg:               Mass of the body (kg).
        initial_velocity_m_s:  Initial sliding velocity (m/s).
        mu_static:             Static friction coefficient.
        mu_kinetic:            Kinetic friction coefficient.
        g_m_s2:                Gravitational acceleration (default 9.81 m/s²).
        v_char_m_s:            Characteristic velocity v_c (m/s).
        power:                 Nonlinear exponent p.

    Returns:
        VelocityDecayResult with deceleration and stopping estimates.
    """
    if mass_kg <= 0:
        raise ValueError("mass_kg must be positive")
    if initial_velocity_m_s < 0:
        raise ValueError("initial_velocity_m_s must be non-negative")

    normal_force = mass_kg * g_m_s2
    fr = predict_friction_force(
        normal_force_n=normal_force,
        mu_static=mu_static,
        mu_kinetic=mu_kinetic,
        velocity_m_s=initial_velocity_m_s,
        v_char_m_s=v_char_m_s,
        power=power,
    )
    decel = fr.friction_force_n / mass_kg  # |a| = F_f / m
    v0 = initial_velocity_m_s
    if decel > 0:
        t_stop = v0 / decel
        d_stop = v0 * v0 / (2.0 * decel)
    else:
        t_stop = float("inf")
        d_stop = float("inf")

    return VelocityDecayResult(
        initial_velocity_m_s=v0,
        mass_kg=mass_kg,
        deceleration_m_s2=decel,
        approx_stopping_time_s=t_stop,
        approx_stopping_dist_m=d_stop,
    )


def predict_viscosity_vs_velocity(
    mu_base_pa_s: float,
    n_topology: float,
    velocity_m_s: float,
    v_char_m_s: float,
    mu_basic_pa_s: float = 0.0,
    energy_ev: float = 0.026,
) -> VelocityViscosityResult:
    """
    CFUT velocity-dependent viscosity for non-Newtonian fluids.

    Formula:
        mu(v) = mu_0 * [1 + lambda(E) * N * (1 - exp(-v / v_char))] + mu_basic

    where lambda(E) = lambda_0 * exp(-E / E_ref),
    lambda_0 = 4*pi*alpha ≈ 0.09170, E_ref = 0.40 eV.

    Args:
        mu_base_pa_s:   Base viscosity mu_0 at zero velocity (Pa·s).
        n_topology:     Topological index N (winding-number proxy).
        velocity_m_s:   Flow velocity (m/s).
        v_char_m_s:     Characteristic velocity v_0 for the saturation scale (m/s).
        mu_basic_pa_s:  Additive background viscosity (Pa·s); default 0.
        energy_ev:      Local energy scale E (eV); default 0.026 eV (thermal ~300 K).

    Returns:
        VelocityViscosityResult with effective viscosity and coupling coefficient.
    """
    if mu_base_pa_s <= 0:
        raise ValueError("mu_base_pa_s must be positive")
    if n_topology < 0:
        raise ValueError("n_topology must be non-negative")
    if v_char_m_s <= 0:
        raise ValueError("v_char_m_s must be positive")

    lam = _lambda_energy(energy_ev)
    saturation = 1.0 - math.exp(-abs(velocity_m_s) / v_char_m_s)
    mu_eff = mu_base_pa_s * (1.0 + lam * n_topology * saturation) + mu_basic_pa_s
    return VelocityViscosityResult(
        velocity_m_s=velocity_m_s,
        viscosity_pa_s=mu_eff,
        lambda_coupling=lam,
        topology_index=n_topology,
    )


def sunspot_cycle_stats() -> SunspotCycleStats:
    """
    Return SILSO-derived sunspot cycle observational statistics.

    Source: SILSO Sunspot Number v2.0, 1749-present.
    Method: 13-month moving average, local minima < 15, spacing >= 100 months.
    n = 20 identified cycles.

    Evidence level: medium-strong observational constraint.
    Note: results are compatibility constraints, not direct confirmation of CFUT.
    """
    return SunspotCycleStats(
        n_cycles_observed=_SUNSPOT_N_CYCLES,
        median_months=_SUNSPOT_MEDIAN_MONTHS,
        min_months=_SUNSPOT_MIN_MONTHS,
        max_months=_SUNSPOT_MAX_MONTHS,
        median_years=_SUNSPOT_MEDIAN_MONTHS / _MONTHS_PER_YEAR,
        min_years=_SUNSPOT_MIN_MONTHS / _MONTHS_PER_YEAR,
        max_years=_SUNSPOT_MAX_MONTHS / _MONTHS_PER_YEAR,
    )


def is_sunspot_period_compatible(period_years: float, tolerance_pct: float = 20.0) -> bool:
    """
    Check whether a predicted period is compatible with the observed sunspot range.

    The observed range (SILSO) is 10.0 – 22.83 years (median 11.33 yr).
    An additional tolerance band is applied to the observed min/max.

    Args:
        period_years:    Predicted period in years.
        tolerance_pct:   Extra tolerance as percentage of median (default 20 %).

    Returns:
        True if the period falls within [min*(1-tol), max*(1+tol)].
    """
    stats = sunspot_cycle_stats()
    tol = tolerance_pct / 100.0
    lower = stats.min_years * (1.0 - tol)
    upper = stats.max_years * (1.0 + tol)
    return lower <= period_years <= upper


def predict_geomagnetic_reversal_period(
    v_sub_cm_per_yr: float,
    area_lip_km2_per_yr: float,
    beta: float,
    b_tor_pol_ratio: float,
    q0_w: float = 1.8e12,
    v_sub0_cm_per_yr: float = 1.0,
    area_ref_km2_per_yr: float = 1.0e4,
    e_mag_j: float = 1.0e28,
    q_cond_w: float = 5.0e11,
) -> GeomagneticReversalResult:
    """
    CFUT geomagnetic reversal period estimate.

    Formula:
        Q_CMB = Q0 * (v_sub/v_sub0)^3 * (1 + A_LIP/A_ref)
        alpha  = (Q_CMB - Q_cond) / (beta * E_m)
        tau    = (2*pi / alpha) / sqrt(1 - beta*(B_tor/B_pol)^2)

    Args:
        v_sub_cm_per_yr:       Subduction velocity (cm/yr).
        area_lip_km2_per_yr:   Large Igneous Province eruption rate (km²/yr).
        beta:                  Coupling coefficient beta.  Use ~5e-5 to match
                               the observed ~0.25 Myr median reversal period.
        b_tor_pol_ratio:       Toroidal-to-poloidal field ratio B_tor/B_pol.
        q0_w:                  Base CMB heat flux Q_0 (W); default 1.8e12 W.
        v_sub0_cm_per_yr:      Reference subduction velocity; default 1.0 cm/yr.
        area_ref_km2_per_yr:   Reference LIP area rate; default 1e4 km²/yr.
        e_mag_j:               Magnetic energy scale E_m (J); default 1e28 J.
        q_cond_w:              Conductive heat flux Q_cond (W); default 5e11 W.

    Returns:
        GeomagneticReversalResult.

    Notes:
        - The raw formula (uncalibrated beta) yields ~4 kyr.
        - Matching the observed ~0.25 Myr median requires beta ~ 5–7e-5.
        - Evidence level: structural compatibility; beta calibration required.
    """
    if v_sub_cm_per_yr <= 0:
        raise ValueError("v_sub_cm_per_yr must be positive")
    if beta <= 0:
        raise ValueError("beta must be positive")
    if e_mag_j <= 0:
        raise ValueError("e_mag_j must be positive")

    vel_ratio = v_sub_cm_per_yr / v_sub0_cm_per_yr
    q_cmb = q0_w * (vel_ratio ** 3) * (1.0 + area_lip_km2_per_yr / area_ref_km2_per_yr)
    q_net = q_cmb - q_cond_w
    if q_net <= 0:
        raise ValueError(
            f"Q_CMB ({q_cmb:.3e} W) <= Q_cond ({q_cond_w:.3e} W): "
            "net heat flux is non-positive; reversal driven by excess heat flux only"
        )

    alpha = q_net / (beta * e_mag_j)
    spin_factor = beta * (b_tor_pol_ratio ** 2)
    if spin_factor >= 1.0:
        raise ValueError(
            f"beta*(B_tor/B_pol)^2 = {spin_factor:.4f} >= 1; "
            "relativistic-like spin factor exceeds unity"
        )

    tau_s = (2.0 * math.pi / alpha) / math.sqrt(1.0 - spin_factor)
    _S_PER_YR = 3.15576e7
    _S_PER_KYR = _S_PER_YR * 1.0e3
    _S_PER_MYR = _S_PER_YR * 1.0e6

    return GeomagneticReversalResult(
        period_s=tau_s,
        period_kyr=tau_s / _S_PER_KYR,
        period_myr=tau_s / _S_PER_MYR,
        alpha_rate_per_s=alpha,
        q_cmb_w=q_cmb,
        beta_used=beta,
    )


__all__ = [
    # Dataclasses
    "StallPrediction",
    "NonNewtonianResult",
    "MassResult",
    "DMShellResult",
    "FrictionResult",
    "VelocityDecayResult",
    "VelocityViscosityResult",
    "SunspotCycleStats",
    "GeomagneticReversalResult",
    # Functions (original)
    "predict_dynamic_stall",
    "estimate_non_newtonian",
    "predict_non_newtonian_viscosity",
    "mass_from_winding",
    "infer_winding_from_mass",
    "proton_neutron_split",
    "compute_particle_masses",
    "nearest_dm_shell",
    "dm_shell_scan",
    # Functions (v8.2)
    "predict_friction_force",
    "predict_velocity_decay",
    "predict_viscosity_vs_velocity",
    "sunspot_cycle_stats",
    "is_sunspot_period_compatible",
    "predict_geomagnetic_reversal_period",
]
