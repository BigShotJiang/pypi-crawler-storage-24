"""
Numerical interfaces for ComplexFrame geometric/topological observables.

This module does not claim a maximal theorem that a bare internal complex frame alone
generates the full CFUT closure. Instead, it provides computable numerical interfaces
that are useful for local experiments and regression tests:

- metric tensor from the real part of a sampled ComplexFrame
- Christoffel symbols, Ricci tensor, scalar curvature, Einstein tensor
- conformally normalized Einstein tensor proxy
- symmetric gauge-curvature encoding tensor
- complex Einstein tensor with real geometric part and imaginary gauge-curvature part
- Chern-Simons current proxy and its symmetric gradient tensor
- CFUT unified field equation left-side proxy
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Sequence

import numpy as np

from .complex_frame import ComplexFrame, GaugeConnection


ArrayLike = np.ndarray
FrameSampler = Callable[[ArrayLike], ComplexFrame]
GaugeSampler = Callable[[ArrayLike], Sequence[GaugeConnection]]


def _as_point(x: Iterable[float]) -> np.ndarray:
    arr = np.asarray(list(x), dtype=float)
    if arr.shape != (3,):
        raise ValueError(f"Expected a 3-vector point, got shape {arr.shape}")
    return arr


def _eps_3(i: int, j: int, k: int) -> int:
    if len({i, j, k}) < 3:
        return 0
    perm = (i, j, k)
    if perm in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
        return 1
    return -1


@dataclass
class ComplexFrameField:
    """
    Numerical field wrapper for ComplexFrame.

    Parameters
    ----------
    frame_sampler:
        Callable mapping x ∈ R^3 to a ComplexFrame sample.
    gauge_sampler:
        Optional callable mapping x ∈ R^3 to three GaugeConnection objects
        corresponding to internal gauge directions A_1, A_2, A_3.
    step:
        Central-difference step for all numerical derivatives.
    metric_regularization:
        Small diagonal regularizer added before metric inversion.
    """

    frame_sampler: FrameSampler
    gauge_sampler: GaugeSampler | None = None
    step: float = 1.0e-3
    metric_regularization: float = 1.0e-9

    def frame(self, x: Iterable[float]) -> ComplexFrame:
        return self.frame_sampler(_as_point(x))

    def metric_tensor(self, x: Iterable[float]) -> np.ndarray:
        """
        Metric proxy induced from the real part of the ComplexFrame matrix.

        The construction uses the real column vectors as a local frame carrier:
            g = Re(U)^T Re(U) + eps * I.
        """
        U = self.frame(x).matrix
        basis = np.real(U)
        g = basis.T @ basis
        return g + self.metric_regularization * np.eye(3)

    def conformal_factor(self, x: Iterable[float]) -> float:
        g = self.metric_tensor(x)
        return float(np.linalg.det(g) ** (1.0 / 6.0))

    def _partial_metric(self, x: np.ndarray, axis: int) -> np.ndarray:
        delta = np.zeros(3)
        delta[axis] = self.step
        return (self.metric_tensor(x + delta) - self.metric_tensor(x - delta)) / (2.0 * self.step)

    def christoffel_symbols(self, x: Iterable[float]) -> np.ndarray:
        """
        Christoffel symbols Γ^k_{ij} computed from the metric by finite differences.
        """
        point = _as_point(x)
        g = self.metric_tensor(point)
        g_inv = np.linalg.inv(g)
        dg = [self._partial_metric(point, axis) for axis in range(3)]

        gamma = np.zeros((3, 3, 3), dtype=float)
        for k in range(3):
            for i in range(3):
                for j in range(3):
                    total = 0.0
                    for l in range(3):
                        total += g_inv[k, l] * (
                            dg[i][j, l] + dg[j][i, l] - dg[l][i, j]
                        )
                    gamma[k, i, j] = 0.5 * total
        return gamma

    def _partial_gamma(self, x: np.ndarray, axis: int) -> np.ndarray:
        delta = np.zeros(3)
        delta[axis] = self.step
        return (self.christoffel_symbols(x + delta) - self.christoffel_symbols(x - delta)) / (2.0 * self.step)

    def ricci_tensor(self, x: Iterable[float]) -> np.ndarray:
        """
        Ricci tensor R_ij from numerical Christoffel symbols.
        """
        point = _as_point(x)
        gamma = self.christoffel_symbols(point)
        dgamma = [self._partial_gamma(point, axis) for axis in range(3)]

        ricci = np.zeros((3, 3), dtype=float)
        for i in range(3):
            for j in range(3):
                total = 0.0
                for k in range(3):
                    total += dgamma[k][k, i, j] - dgamma[j][k, i, k]
                    for l in range(3):
                        total += gamma[k, i, j] * gamma[l, k, l]
                        total -= gamma[k, i, l] * gamma[l, j, k]
                ricci[i, j] = total
        return ricci

    def scalar_curvature(self, x: Iterable[float]) -> float:
        g = self.metric_tensor(x)
        g_inv = np.linalg.inv(g)
        ricci = self.ricci_tensor(x)
        return float(np.trace(g_inv @ ricci))

    def einstein_tensor(self, x: Iterable[float]) -> np.ndarray:
        g = self.metric_tensor(x)
        ricci = self.ricci_tensor(x)
        scalar = self.scalar_curvature(x)
        return ricci - 0.5 * g * scalar

    def einstein_conformal_tensor(self, x: Iterable[float]) -> np.ndarray:
        """
        Conformally normalized Einstein tensor proxy:
            G_conf = G / Omega^2,  Omega = det(g)^(1/6).
        """
        omega = max(self.conformal_factor(x), self.metric_regularization)
        return self.einstein_tensor(x) / (omega * omega)

    def gauge_connections(self, x: Iterable[float]) -> Sequence[GaugeConnection]:
        if self.gauge_sampler is None:
            raise ValueError("gauge_sampler is required for Chern-Simons observables")
        connections = self.gauge_sampler(_as_point(x))
        if len(connections) != 3:
            raise ValueError("gauge_sampler must return exactly 3 GaugeConnection objects")
        return connections

    def gauge_field_strength_tensor(self, x: Iterable[float]) -> np.ndarray:
        """
        Internal gauge curvature proxy F_ij = [A_i, A_j].
        """
        A = [conn.connection_matrix() for conn in self.gauge_connections(x)]
        F = np.zeros((3, 3, 3, 3), dtype=complex)
        for i in range(3):
            for j in range(3):
                F[i, j] = A[i] @ A[j] - A[j] @ A[i]
        return F

    def gauge_curvature_encoding_tensor(self, x: Iterable[float]) -> np.ndarray:
        """
        Symmetric second-rank tensor built from gauge curvature.

        This is the local computable proxy for the imaginary part of the CFUT
        complex Einstein tensor. The antisymmetric curvature F_ij itself is not
        inserted directly into the Einstein tensor; instead we use the natural
        lowest-order symmetric contraction Q(F).
        """
        point = _as_point(x)
        g = self.metric_tensor(point)
        g_inv = np.linalg.inv(g)
        F = self.gauge_field_strength_tensor(point)

        scalar_term = 0.0 + 0.0j
        for a in range(3):
            for b in range(3):
                F_ab_raised = sum(g_inv[b, c] * F[a, c] for c in range(3))
                scalar_term += np.trace(F[a, b] @ F_ab_raised)

        Q = np.zeros((3, 3), dtype=float)
        for i in range(3):
            for j in range(3):
                total = 0.0 + 0.0j
                for k in range(3):
                    F_jk_raised = sum(g_inv[k, l] * F[j, l] for l in range(3))
                    total += np.trace(F[i, k] @ F_jk_raised)
                Q[i, j] = float(np.real(total - 0.25 * g[i, j] * scalar_term))

        return 0.5 * (Q + Q.T)

    def complex_einstein_tensor(self, x: Iterable[float], gauge_weight: float = 1.0) -> np.ndarray:
        """
        Complex Einstein tensor proxy:

            G_CF = G_conf + i * gauge_weight * Q(F)

        The real part is geometric. The imaginary part encodes gauge curvature.
        Topological flow remains independent and is not part of this object.
        """
        geom = self.einstein_conformal_tensor(x)
        gauge = gauge_weight * self.gauge_curvature_encoding_tensor(x)
        return geom + 1j * gauge

    def chern_simons_current(self, x: Iterable[float]) -> np.ndarray:
        """
        Spatial Chern-Simons current proxy.

        We use the computable numerical proxy
            K_i = sum_{j,k} eps_{ijk} Re Tr(A_j F_{jk})
        which vanishes in trivial flat/internal-abelian limits and is suitable
        for regression tests of the topological sector.
        """
        A = [conn.connection_matrix() for conn in self.gauge_connections(x)]
        F = self.gauge_field_strength_tensor(x)
        K = np.zeros(3, dtype=float)
        for i in range(3):
            total = 0.0
            for j in range(3):
                for k in range(3):
                    eps = _eps_3(i, j, k)
                    if eps == 0:
                        continue
                    total += eps * np.trace(A[j] @ F[j, k]).real
            K[i] = total
        return K

    def _partial_cs_current(self, x: np.ndarray, axis: int) -> np.ndarray:
        delta = np.zeros(3)
        delta[axis] = self.step
        return (self.chern_simons_current(x + delta) - self.chern_simons_current(x - delta)) / (2.0 * self.step)

    def cs_gradient_tensor(self, x: Iterable[float]) -> np.ndarray:
        """
        Symmetric gradient tensor proxy:
            (∇_(i K_j))_proxy = 1/2 (∂_i K_j + ∂_j K_i).
        """
        point = _as_point(x)
        dK = [self._partial_cs_current(point, axis) for axis in range(3)]
        tensor = np.zeros((3, 3), dtype=float)
        for i in range(3):
            for j in range(3):
                tensor[i, j] = 0.5 * (dK[i][j] + dK[j][i])
        return tensor

    def unified_field_equation_lhs(
        self,
        x: Iterable[float],
        planck_mass: float = 1.0,
        topo_lambda: float = 1.0,
        gauge_weight: float = 1.0,
    ) -> np.ndarray:
        """
        Numerical proxy for the spatial left side of the CFUT unified field equation:

            (M_P^2 / 2) G^{CF}_{μν}[E,A] + (λ / 32π²) ∇_(μ K_ν)[A]
        """
        complex_einstein = 0.5 * (planck_mass ** 2) * self.complex_einstein_tensor(
            x,
            gauge_weight=gauge_weight,
        )
        topo = (topo_lambda / (32.0 * np.pi**2)) * self.cs_gradient_tensor(x)
        return complex_einstein + topo


    # Backward-compatible alias (deprecated; use unified_field_equation_lhs)
    christmas_equation_lhs = unified_field_equation_lhs


__all__ = [
    "ComplexFrameField",
]
