#!/usr/bin/env python3

"""This script is used to save and load the downloaded CMIP6 data dictionaries.

save_dictionary_entries_to_nectdf : Saves each entry of a CMIP6 dictionary to a netcdf file at save_path.

netcdf_to_dictionary_for_given_experiment_id : Converts the generated netcdf files back to a dictionary of CMIP6 datasets for a given experiment_id.

netcdf_to_dictionary : Converts the generated netcdf files back to a dictionary of CMIP6 datasets.

Author : GIBONI Lucas

Feel free to copy, adapt and modify it under the provided license.
"""

##################################
### IMPORTATION OF THE MODULES ###
##################################

### HANDLE PATHS AND DIRECTORIES FROM THE NOTEBOOK ###

from glob import glob  # To handle unix like '*' paths
from os import (
    listdir,  # It is used to list of the folders' names present at a given path.
)
from os.path import (
    basename,  # It is to get the name of a file or folder at the end of a path.
    dirname,  # To get the path of a directory holding a given folder.
    join,  # It is used to connect two paths without caring about "/".
)

### DATA OBJECTS AND ASSOCIATED COMPUTATION ###
import numpy as np  # It is imported to work on the pandas arrays.
import pandas as pd  # It is used to create and handle tables.
import xarray as xr  # It is imported manage the CMIP6 data.

### PROJECT MODULES ###
## Handle CMIP6 keys ##
from import_cmip6_data_utils.tools.cmip6_dictionary_keys import (
    find_facet_index,  # It is used to find the index associated to a provided facet within a splitted CMIP6 key.
    remove_facet_name_at_facet_index,  # It is used to remove a facet present at the provided index in a CMIP6 key.
)

## Creating a folder ##
from import_cmip6_data_utils.tools.folders import (
    create_dir,  # This function creates directories at the provided path and may clean them before.
)

###################################
### DEFINITION OF THE FUNCTIONS ###
###################################

#########################################
### SAVE_DICTIONARY_ENTRIES_TO_NETCDF ###
#########################################


def save_dictionary_entries_to_nectdf(
    cmip6_dictionary: dict[str, xr.Dataset],
    save_path: str,
    clear: bool,
    verbose: bool = False,
):
    """Saves each entry of a CMIP6 dictionary to a netcdf file at save_path.

    Parameters
    ----------
    cmip6_dictionary : dict[str, xr.Dataset]

        Dictionary of the CMIP6 entries to save.

    save_path : str

        Path leading to the folder in which the entries will be stored.

    clear : bool, optional

        Whether we clear the path or not, by default True.

    verbose : bool, optional

        Bool defining if the function needs to print information, by default False.
    """
    ### LOOP THROUGH THE ENTRIES OF THE DICTIONARY ##

    for ii, entry_key in enumerate(cmip6_dictionary.keys()):
        # If wanted it prints the entry that is being saved.

        if verbose:
            print("\nSaving {} in a netcdf file.\n".format(entry_key))

        ## Generate a filename with the key ##

        # Split the key into a list of keywords #

        splitted_key = entry_key.split(".")

        # Connect them with a "_" to make a filename that is not broken #

        full_name = "_".join(splitted_key)

        # Define the filename #

        filename = full_name + ".nc"

        ## Create the directory associated to the entry and keep its path ##

        saving_path_given_entry = create_dir(
            parent_path=save_path,
            name=full_name,
            clear=clear,
        )

        ## Generate the full path with the filename ##

        path_to_nc = saving_path_given_entry + "/" + filename

        ## Save the dataset linked to the entry ##

        cmip6_dictionary[entry_key].to_netcdf(path=path_to_nc)

    return


####################################################
### NETCDF_TO_DICTIONARY_FOR_GIVEN_EXPERIMENT_ID ###
####################################################


def netcdf_to_dictionary_for_given_experiment_id(
    save_path_for_experiment_id: str,
) -> dict[str, xr.Dataset]:
    """Converts the generated netcdf files back to a dictionary of CMIP6 datasets for a given experiment_id.

    Parameters
    ----------
    save_path_for_experiment_id : str

        Path leading to the folder in which the entries are stored for a given experiment_id

    Returns
    -------
    cmip6_dictionary_for_experiment_id : dict[str, xr.Dataset]

        Dictionary of the different CMIP6 entries for the given experiment_id.
    """

    ### INITIALISE ###

    ## Generate the CMIP6 dictionary ##

    cmip6_dictionary_for_experiment_id = {}

    ## List the paths leading to a .nc file ##

    # Generate what the path would look like if the folder holds a .nc file #

    pattern_of_paths_where_netcdf = save_path_for_experiment_id + "/*/*.nc"

    # Look for all the folders corresponding to that pattern #

    # We therefore get all the paths to source_id_member_id folders holding .nc files

    list_of_paths_leading_to_netcdf_file = glob(pattern_of_paths_where_netcdf)

    # We reduce the paths leading to .nc files to their parent folders

    list_of_paths_to_folders_where_netcdf_for_experiment_id = [
        dirname(path_leading_to_netcdf_file)
        for path_leading_to_netcdf_file in list_of_paths_leading_to_netcdf_file
    ]

    # Extract the associated keys for the dictionary #

    list_of_source_member_id = [
        ".".join(basename(source_member_id).split("_"))
        for source_member_id in list_of_paths_to_folders_where_netcdf_for_experiment_id
    ]

    ### LOOP THROUGH THE KEYS OF THE ENTRIES ###

    for ii, key in enumerate(list_of_source_member_id):
        ## Retrieve the path associated to the key ##

        path_to_nc = list_of_paths_leading_to_netcdf_file[ii]

        ## Load the netcdf file into the dictionary ##

        cmip6_dictionary_for_experiment_id[key] = xr.open_dataset(path_to_nc)

    return cmip6_dictionary_for_experiment_id


############################
### NETCDF_TO_DICTIONARY ###
############################


def netcdf_to_dictionary(preprocessed_data_path: str) -> dict[str, xr.Dataset]:
    """Converts the generated netcdf files back to a dictionary of CMIP6 datasets.

    Parameters
    ----------
    preprocessed_data_path : str

        Path leading to the /preprocessed folder in which the entries are stored.

    Returns
    -------
    cmip6_dictionary : dict[str, xr.Dataset]

        Dictionary of the different CMIP6 entries.
    """

    ### INITIALISE ###

    ## Generate the CMIP6 dictionary ##

    cmip6_dictionary = {}

    ## Get the list of experiment_ids to retrieve ##

    list_of_experiment_ids = listdir(preprocessed_data_path)

    ### LOOP THROUGH THE EXPERIMENT_IDS ###

    for experiment_id in list_of_experiment_ids:
        ## Get the path of the folder for this experiment_id ##

        save_path_for_experiment_id = join(preprocessed_data_path, experiment_id)

        ## Generate the associated dictionary ##

        cmip6_dictionary_for_experiment_id = (
            netcdf_to_dictionary_for_given_experiment_id(
                save_path_for_experiment_id=save_path_for_experiment_id
            )
        )

        ## Store it into the full dictionary ##

        cmip6_dictionary[experiment_id] = cmip6_dictionary_for_experiment_id

    return cmip6_dictionary


######################
### USED FOR TESTS ###
######################

if __name__ == "__main__":
    pass
