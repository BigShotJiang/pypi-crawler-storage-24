from setuptools import setup, find_packages

setup(
    name="botcall-print",
    version="0.4.2",
    description="Print daemon for botcall - receive print jobs from the cloud",
    author="botcall.io",
    url="https://botcall.io",
    py_modules=["botcall_print"],
    install_requires=[
        "python-escpos>=3.0",
        "websockets>=12.0",
        "click>=8.0",
        "requests>=2.31",
    ],
    entry_points={
        "console_scripts": [
            "botcall-print=botcall_print:cli",
        ],
    },
    python_requires=">=3.9",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
