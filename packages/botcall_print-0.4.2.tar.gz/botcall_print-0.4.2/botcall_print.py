#!/usr/bin/env python3
"""
botcall print daemon

Connects to botcall cloud and prints jobs to local USB printer.
"""

import asyncio
import json
import base64
import platform
import sys
import os
import click
from pathlib import Path

API_URL = os.getenv("BOTCALL_API_URL", "https://botcall-api-production.up.railway.app")
WS_URL = os.getenv("BOTCALL_WS_URL", "wss://botcall-api-production.up.railway.app/ws/print")
API_KEY = os.getenv("BOTCALL_API_KEY")

VERSION = "0.4.2"

# Printer connection (lazy loaded)
_printer = None


def detect_usb_printers():
    """Scan USB devices and return list of potential printers."""
    try:
        import usb.core
        import usb.util
    except ImportError:
        return []
    
    printers = []
    for dev in usb.core.find(find_all=True):
        if dev.bDeviceClass == 9:  # Skip hubs
            continue
        if dev.idVendor == 0x1d6b:  # Skip Linux Foundation root hubs
            continue
        
        vid_pid = f"{dev.idVendor:04x}:{dev.idProduct:04x}"
        try:
            manufacturer = usb.util.get_string(dev, dev.iManufacturer) if dev.iManufacturer else "Unknown"
            product = usb.util.get_string(dev, dev.iProduct) if dev.iProduct else "Unknown"
            name = f"{manufacturer} {product}".strip()
        except Exception:
            name = "Unknown Device"
        
        printers.append((vid_pid, name))
    
    return printers


def get_printer():
    """Get or create printer connection. Auto-detects if only one USB device."""
    global _printer
    if _printer is None:
        from escpos.printer import Usb
        
        printer_id = os.getenv("BOTCALL_PRINTER")
        
        if not printer_id:
            devices = detect_usb_printers()
            if not devices:
                raise RuntimeError("No USB printer found")
            elif len(devices) == 1:
                printer_id = devices[0][0]
                click.echo(f"✓ Auto-detected: {devices[0][1]} ({printer_id})")
            else:
                raise RuntimeError(f"Multiple USB devices found. Set BOTCALL_PRINTER env var.")
        
        try:
            vid, pid = printer_id.split(":")
            vid = int(vid, 16)
            pid = int(pid, 16)
        except ValueError:
            raise RuntimeError(f"Invalid printer ID format: {printer_id}. Expected xxxx:xxxx")
        
        try:
            _printer = Usb(vid, pid)
            _printer.open()
            click.echo(f"✓ Connected to printer: {printer_id}")
        except Exception as e:
            raise RuntimeError(f"Failed to connect to printer {printer_id}: {e}")
    
    return _printer


async def print_raw_async(data: bytes) -> None:
    """Send raw ESC/POS data to printer. Handles delay markers for chunked printing."""
    printer = get_printer()
    
    DELAY_MARKER = b'\x1b\x5f'  # ESC _
    chunks = []
    delays = []
    pos = 0
    
    while pos < len(data):
        marker_pos = data.find(DELAY_MARKER, pos)
        if marker_pos == -1:
            chunks.append(data[pos:])
            delays.append(0)
            break
        else:
            if marker_pos > pos:
                chunks.append(data[pos:marker_pos])
            if marker_pos + 4 <= len(data):
                delay_ms = data[marker_pos + 2] | (data[marker_pos + 3] << 8)
                delays.append(delay_ms)
                pos = marker_pos + 4
            else:
                pos = len(data)
    
    for i, chunk in enumerate(chunks):
        if len(chunk) == 0:
            continue
        
        if platform.system() == "Darwin":
            # macOS needs smaller chunks
            for j in range(0, len(chunk), 256):
                printer._raw(chunk[j:j + 256])
                await asyncio.sleep(0.01)
        else:
            printer._raw(chunk)
        
        if i < len(delays) and delays[i] > 0:
            click.echo(f"  ⏱ Cooling delay: {delays[i]}ms")
            await asyncio.sleep(delays[i] / 1000.0)


async def connect_and_listen():
    """Connect to server and listen for print jobs."""
    import websockets
    
    if not API_KEY:
        click.echo("✗ BOTCALL_API_KEY not set", err=True)
        click.echo("  Run: sudo botcall-print install --api-key <key>", err=True)
        sys.exit(1)
    
    click.echo(f"Connecting to {WS_URL}...")
    
    async for websocket in websockets.connect(
        WS_URL,
        additional_headers={"Authorization": f"Bearer {API_KEY}"},
        ping_interval=20,
        ping_timeout=30,
        close_timeout=10,
    ):
        try:
            click.echo("✓ Connected. Waiting for print jobs...")
            
            await websocket.send(json.dumps({
                "type": "register",
                "platform": platform.system(),
                "version": VERSION,
                "machineId": platform.node(),
            }))
            
            async for message in websocket:
                await handle_message(websocket, message)
                
        except websockets.ConnectionClosed:
            click.echo("Connection lost. Reconnecting in 5s...")
            await asyncio.sleep(5)
            continue


async def handle_message(ws, message: str):
    """Handle incoming message from server."""
    try:
        msg = json.loads(message)
        
        if msg["type"] == "print":
            job_id = msg["jobId"]
            data = base64.b64decode(msg["data"])
            
            click.echo(f"Printing job {job_id[:8]}...")
            
            await ws.send(json.dumps({"type": "job_started", "jobId": job_id}))
            
            try:
                await print_raw_async(data)
                await ws.send(json.dumps({"type": "job_completed", "jobId": job_id}))
                click.echo(f"✓ Job {job_id[:8]} complete")
            except Exception as e:
                await ws.send(json.dumps({"type": "job_failed", "jobId": job_id, "error": str(e)}))
                click.echo(f"✗ Job {job_id[:8]} failed: {e}", err=True)
        
        elif msg["type"] == "ping":
            await ws.send(json.dumps({"type": "pong"}))
        
        elif msg["type"] == "registered":
            click.echo(f"✓ Registered with server (user: {msg.get('userId', 'unknown')[:8]}...)")
        
        elif msg["type"] == "error":
            click.echo(f"⚠ Server error: {msg.get('message', 'unknown')}", err=True)
            
    except Exception as e:
        click.echo(f"Error handling message: {e}", err=True)


@click.group()
def cli():
    """botcall print daemon"""
    pass


@cli.command()
@click.option("--api-key", prompt="API key", help="Your botcall API key")
@click.option("--printer", default=None, help="Printer vendor:product ID (auto-detects if omitted)")
def install(api_key: str, printer: str):
    """Install systemd service and start daemon."""
    import subprocess
    import shutil
    import re
    
    # Auto-detect printer if not specified
    if not printer:
        devices = detect_usb_printers()
        if not devices:
            click.echo("✗ No USB devices found. Specify --printer manually.", err=True)
            sys.exit(1)
        elif len(devices) == 1:
            printer = devices[0][0]
            click.echo(f"✓ Found printer: {devices[0][1]} ({printer})")
        else:
            click.echo("Multiple USB devices found:")
            for i, (vid_pid, name) in enumerate(devices, 1):
                click.echo(f"  {i}. {name} ({vid_pid})")
            choice = click.prompt("Select printer", type=int, default=1)
            if 1 <= choice <= len(devices):
                printer = devices[choice - 1][0]
            else:
                click.echo("✗ Invalid choice", err=True)
                sys.exit(1)
    
    # Find executable
    botcall_bin = shutil.which("botcall-print")
    if not botcall_bin:
        for path in [Path.home() / ".local" / "bin" / "botcall-print", Path("/usr/local/bin/botcall-print")]:
            if path.exists():
                botcall_bin = str(path)
                break
    
    if not botcall_bin:
        click.echo("✗ Could not find botcall-print executable", err=True)
        sys.exit(1)
    
    click.echo(f"✓ Found executable: {botcall_bin}")
    
    # Validate printer ID
    if not re.match(r'^[0-9a-fA-F]{4}:[0-9a-fA-F]{4}$', printer):
        click.echo(f"✗ Invalid printer ID: {printer}. Expected xxxx:xxxx", err=True)
        sys.exit(1)
    
    user = os.environ.get("USER", "pi")
    home = str(Path.home())
    
    service_content = f"""[Unit]
Description=botcall print daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
Environment=HOME={home}
Environment=BOTCALL_API_KEY={api_key}
Environment=BOTCALL_PRINTER={printer}
ExecStart={botcall_bin} daemon
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
"""
    
    service_path = "/etc/systemd/system/botcall-print.service"
    
    try:
        result = subprocess.run(["sudo", "tee", service_path], input=service_content.encode(), capture_output=True)
        if result.returncode != 0:
            click.echo(f"✗ Failed to create service: {result.stderr.decode()}", err=True)
            sys.exit(1)
        click.echo(f"✓ Created {service_path}")
        
        subprocess.run(["sudo", "systemctl", "daemon-reload"], check=True)
        subprocess.run(["sudo", "systemctl", "enable", "botcall-print"], check=True)
        subprocess.run(["sudo", "systemctl", "restart", "botcall-print"], check=True)
        
        click.echo("✓ Service installed and started")
        click.echo("\nCheck status: sudo systemctl status botcall-print")
        
    except Exception as e:
        click.echo(f"✗ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
def uninstall():
    """Stop and remove the systemd service."""
    import subprocess
    
    try:
        subprocess.run(["sudo", "systemctl", "stop", "botcall-print"], check=False)
        subprocess.run(["sudo", "systemctl", "disable", "botcall-print"], check=False)
        subprocess.run(["sudo", "rm", "-f", "/etc/systemd/system/botcall-print.service"], check=False)
        subprocess.run(["sudo", "systemctl", "daemon-reload"], check=True)
        click.echo("✓ Uninstalled")
    except Exception as e:
        click.echo(f"✗ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
def daemon():
    """Start the print daemon (called by systemd)."""
    click.echo(f"botcall print daemon v{VERSION}")
    
    try:
        get_printer()
    except Exception as e:
        click.echo(f"✗ Printer error: {e}", err=True)
        sys.exit(1)
    
    asyncio.run(connect_and_listen())


@cli.command()
@click.argument("text")
def test(text: str):
    """Test print some text."""
    try:
        p = get_printer()
        p.text(text + "\n")
        p.cut()
        click.echo("✓ Printed!")
    except Exception as e:
        click.echo(f"✗ Error: {e}", err=True)
        sys.exit(1)


@cli.command()
def status():
    """Show service and printer status."""
    import subprocess
    
    if platform.system() != "Linux":
        click.echo("Status command only supported on Linux")
        return
    
    result = subprocess.run(["systemctl", "is-active", "botcall-print"], capture_output=True, text=True)
    if result.stdout.strip() == "active":
        click.echo("✓ Service: Running")
    else:
        click.echo("○ Service: Not running")
        click.echo("  Run: sudo botcall-print install --api-key <key>")
        return
    
    devices = detect_usb_printers()
    if devices:
        click.echo(f"✓ USB devices: {len(devices)} found")
        for vid_pid, name in devices:
            click.echo(f"    {vid_pid} - {name}")
    else:
        click.echo("✗ USB devices: None found")


if __name__ == "__main__":
    cli()
