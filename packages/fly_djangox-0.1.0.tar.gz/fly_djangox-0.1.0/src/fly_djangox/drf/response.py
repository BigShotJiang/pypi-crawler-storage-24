import time
from rest_framework.response import Response


class JSONResponse(Response):
    """
    统一响应结构
    """

    def __init__(self, data=None, code=0, msg="success", status=200, **kwargs):
        super().__init__(None, status=status, **kwargs)

        self.data = {
            "code": code,
            "msg": msg,
            "data": data if data is not None else {},
            "ts": int(time.time() * 1000),
        }
