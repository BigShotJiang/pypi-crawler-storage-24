from django.conf import settings

settings.INSTALLED_APPS += ["corsheaders"]

try:
    idx = settings.MIDDLEWARE.index("django.middleware.security.SecurityMiddleware")  # 找到指定值的位置
    settings.MIDDLEWARE.insert(idx + 1, "corsheaders.middleware.CorsMiddleware")  # 插入到后面
except ValueError:
    settings.MIDDLEWARE.insert(0, "corsheaders.middleware.CorsMiddleware")

# 必须关闭全开放
settings.CORS_ALLOW_ALL_ORIGINS = False

# 指定白名单（前端域名）
CORS_ALLOWED_ORIGINS = []

# 如果有子域名很多，可以用：
# CORS_ALLOWED_ORIGIN_REGEXES = [
#     r"^https://.*\.your-frontend\.com$",
# ]

#  允许携带 Cookie（如果你用 session 登录）, jwt直接false
CORS_ALLOW_CREDENTIALS = False

# 方法（标准即可）
CORS_ALLOW_METHODS = [
    "GET",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "OPTIONS",
]

# 精简 Header
CORS_ALLOW_HEADERS = [
    "authorization",
    "content-type",
    "x-csrftoken",
]

# 可选：暴露响应头（如果前端需要读）
CORS_EXPOSE_HEADERS = [
    "Content-Type",
    "Authorization",
]

# 预检缓存（减少 OPTIONS 请求）
CORS_PREFLIGHT_MAX_AGE = 86400  # 24小时
