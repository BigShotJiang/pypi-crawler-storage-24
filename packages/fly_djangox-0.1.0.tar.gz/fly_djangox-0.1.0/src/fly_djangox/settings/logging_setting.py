LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,  # 保留第三方日志

    "formatters": {
        "standard": {
            "format": "[%(asctime)s] %(levelname)-8s %(name)s:%(lineno)d - %(message)s"
        },
        "verbose": {
            "format": "[%(asctime)s] %(levelname)-8s %(module)s.%(funcName)s:%(lineno)d - %(message)s"
        },
    },

    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "standard",
            "level": "INFO",  # 生产环境默认 INFO 以上
        },
    },

    "loggers": {
        # 根 logger 保底打印 WARNING 及以上
        "": {
            "handlers": ["console"],
            "level": "WARNING",
            "propagate": False,
        },

        # Django 框架日志
        "django": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": True,
        },

        # 数据库日志，只打印 WARNING+，避免终端被 SQL 填满
        "django.db.backends": {
            "handlers": ["console"],
            "level": "WARNING",
            "propagate": False,
        },

        # 自定义应用日志示例
        "myapp": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": False,
        },
    },
}
