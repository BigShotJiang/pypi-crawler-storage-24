from django.conf import settings

settings.INSTALLED_APPS += ["rest_framework"]

REST_FRAMEWORK = {
    # django 请求逻辑 请求 → 认证 → 权限 → 查询数据 → 过滤 → 排序 → 分页 → 返回

    # 统一所有序列化日期时间字段的格式（ISO 8601标准），确保API返回时间格式一致
    "DATETIME_FORMAT": "%Y-%m-%d %H:%M:%S",

    # 默认权限
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],

    # 认证方式
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework.authentication.SessionAuthentication",
        "rest_framework.authentication.TokenAuthentication",
    ],

    # 分页
    "DEFAULT_PAGINATION_CLASS": "fly_django.drf.pagination.Pagination",
    "PAGE_SIZE": 20,

    # 渲染格式
    "DEFAULT_RENDERER_CLASSES": [
        # 根据请求头 Accept（如 application/json），
        # 将 Response(data) 渲染成 JSON 字符串返回给客户端
        "fly_django.drf.response.JSONRenderer",
    ],

    # 异常处理，自定义全局异常处理逻辑，可统一封装错误码、错误信息，替代DRF默认处理
    "EXCEPTION_HANDLER": "fly_django.drf.exceptions.exception_handler",

    # 解析器
    "DEFAULT_PARSER_CLASSES": [
        # application/json → request.data
        "rest_framework.parsers.JSONParser",

        # application/x-www-form-urlencoded → request.data
        "rest_framework.parsers.FormParser",

        # multipart/form-data → request.data + request.FILES
        "rest_framework.parsers.MultiPartParser",
    ],

    # Schema（建议新版）
    "DEFAULT_SCHEMA_CLASS": "rest_framework.schemas.openapi.AutoSchema",

}
