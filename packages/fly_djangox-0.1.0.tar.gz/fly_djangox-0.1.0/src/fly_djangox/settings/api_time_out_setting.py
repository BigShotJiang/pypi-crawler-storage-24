from django.conf import settings

try:
    idx = settings.MIDDLEWARE.index("django.middleware.common.CommonMiddleware")
    settings.MIDDLEWARE.insert(idx + 1, "fly_djangox.middlewares.timing_api_middlewares.RequestTimingMiddleware")
    idx += 1
except ValueError:
    idx = 1
    settings.MIDDLEWARE.insert(0, "fly_djangox.middlewares.timing_api_middlewares.RequestTimingMiddleware")

settings.MIDDLEWARE.insert(idx + 1, "fly_djangox.middlewares.timing_sql_middlewares.SQLTimingMiddleware")
