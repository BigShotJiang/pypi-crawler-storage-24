"""Stats-related CLI commands: handicap, clubs, stats, bests, overview, courses, trends."""

from __future__ import annotations

import builtins as _builtins
import sys

import click
from rich import box
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from ._helpers import _get_client, _output_json, console, err_console

builtins_list = _builtins.list


def register(cli: click.Group) -> None:
    cli.add_command(handicap)
    cli.add_command(clubs)
    cli.add_command(club_shots)
    cli.add_command(stats)
    cli.add_command(bests)
    cli.add_command(overview)
    cli.add_command(trends)
    cli.add_command(courses)
    cli.add_command(up_and_down)


# ---------------------------------------------------------------------------
# handicap
# ---------------------------------------------------------------------------

@click.command()
@click.option("--history", "-H", is_flag=True,    help="Show handicap history instead of current.")
@click.option("--rounds", "-n", default=20, show_default=True,
              help="Rounds to include in history.")
@click.option("--json",   "as_json", is_flag=True, help="Output raw JSON.")
def handicap(history: bool, rounds: int, as_json: bool):
    """Show your current handicap index (or revision history)."""
    client = _get_client()

    with console.status("Fetching handicap\u2026"):
        data = (
            client.handicap.history(rounds=rounds)
            if history
            else client.handicap.current()
        )

    if as_json:
        _output_json(data)
        return

    if not history:
        # The API returns SGA-style handicap breakdown
        HCP_LABELS = {
            "userHcp": "Overall",
            "driveHcp": "Driving",
            "approachHcp": "Approach",
            "chipHcp": "Short Game",
            "sandHcp": "Sand",
            "puttHcp": "Putting",
        }
        if isinstance(data, dict) and "userHcp" in data:
            table = Table(
                box=box.ROUNDED,
                header_style="bold cyan",
                title="[bold]Handicap Breakdown[/bold]",
            )
            table.add_column("Category", style="white bold")
            table.add_column("HCP", justify="right", style="bold")
            for key, label in HCP_LABELS.items():
                val = data.get(key)
                if val is None:
                    continue
                # Arccos uses negative = better (lower handicap)
                color = "green" if val < -15 else "yellow" if val < -10 else "red"
                table.add_row(label, f"[{color}]{val:.1f}[/{color}]")
            console.print(table)
        else:
            console.print(Panel(
                Text(str(data), justify="center"),
                title="[bold cyan]Handicap Index[/bold cyan]",
                expand=False,
            ))
    else:
        if not data:
            console.print("[dim]No handicap history found.[/dim]")
            return
        table = Table(
            box=box.ROUNDED, header_style="bold cyan",
            title="[bold]Handicap History[/bold]",
        )
        first = data[0] if isinstance(data, list) else data
        if isinstance(first, dict):
            for key in first:
                table.add_column(key)
            for row in data:
                table.add_row(*[str(v) for v in row.values()])
        else:
            table.add_column("Entry")
            for row in data:
                table.add_row(str(row))
        console.print(table)


# ---------------------------------------------------------------------------
# clubs
# ---------------------------------------------------------------------------

@click.command()
@click.option("--after",  "-a", default=None,      help="Filter shots after date (YYYY-MM-DD).")
@click.option("--before", "-b", default=None,      help="Filter shots before date (YYYY-MM-DD).")
@click.option("--min-shots", default=None, type=int, help="Minimum shots required for a distance.")
@click.option("--json",   "as_json", is_flag=True, help="Output raw JSON.")
def clubs(after: str, before: str, min_shots: int, as_json: bool):
    """Show smart club distances (AI-filtered carry distances per club)."""
    client = _get_client()

    with console.status("Fetching club distances\u2026"):
        data = client.clubs.smart_distances(
            num_shots=min_shots,
            start_date=after,
            end_date=before,
        )
        # Fetch the user's bag to map clubId → clubType + make/model.
        bag_clubs: dict[int, dict] = {}
        try:
            profile = client._http.get(f"/users/{client.user_id}")
            bag_id = profile.get("bagId")
            if bag_id:
                bag = client.clubs.bag(str(bag_id))
                for bc in bag.get("clubs", []):
                    bag_clubs[bc["clubId"]] = bc
        except Exception:
            pass

    if as_json:
        _output_json(data)
        return

    # Filter out deleted clubs (old clubs replaced in the bag)
    if bag_clubs:
        data = [
            c for c in data
            if bag_clubs.get(c.get("clubId"), {}).get("isDeleted") != "T"
        ]

    if not data:
        console.print("[dim]No club data found.[/dim]")
        return

    from arccos.resources.clubs import CLUB_TYPE_NAMES

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]Smart Club Distances[/bold]",
    )
    table.add_column("Club", style="white bold")
    table.add_column("Model", style="dim")
    table.add_column("Smart", justify="right", style="green bold")
    table.add_column("Longest", justify="right")
    table.add_column("Range", justify="right", style="dim")
    table.add_column("Shots", justify="right", style="dim")

    for c in data:
        # Resolve: clubId (bag slot) → clubType → display name
        club_id = c.get("clubId")
        bag_club = bag_clubs.get(club_id, {})
        club_type = bag_club.get("clubType", club_id)
        name = CLUB_TYPE_NAMES.get(club_type, f"#{club_id}")

        # Make + model from bag data
        make = bag_club.get("clubMakeOther", "")
        model_name = bag_club.get("clubModelOther", "")
        club_model = f"{make} {model_name}".strip() if make or model_name else ""

        # Smart distance: may be a dict {"distance": X, "unit": "yd"}
        smart_raw = c.get("smartDistance")
        if isinstance(smart_raw, dict):
            smart = f"{smart_raw['distance']:.0f}y"
        elif smart_raw is not None:
            smart = f"{smart_raw}y"
        else:
            smart = "\u2014"

        # Longest
        longest_raw = c.get("longest")
        longest = f"{longest_raw['distance']:.0f}y" if isinstance(longest_raw, dict) else "\u2014"

        # Range
        range_raw = c.get("range")
        if isinstance(range_raw, dict):
            rng = (
                f"{range_raw['low']:.0f}"
                f"\u2013{range_raw['high']:.0f}y"
            )
        else:
            rng = "\u2014"

        # Shot count
        usage = c.get("usage", {})
        shots = str(usage.get("count", "\u2014")) if isinstance(usage, dict) else "\u2014"

        table.add_row(name, club_model, smart, longest, rng, shots)

    console.print(table)
    console.print("[dim]Smart distance = average with outlier shots removed.[/dim]")


# ---------------------------------------------------------------------------
# stats (strokes gained)
# ---------------------------------------------------------------------------

@click.command()
@click.argument("round_ids", nargs=-1, type=int, required=False)
@click.option("--latest", "-l", is_flag=True, help="Use your most recent round (default).")
@click.option("--json",   "as_json", is_flag=True, help="Output raw JSON.")
def stats(round_ids: tuple, latest: bool, as_json: bool):
    """
    Show strokes gained (SGA) analysis.

    Defaults to your most recent round if no ROUND_IDs are given.

    \b
    Examples:
      arccos stats                    (latest round)
      arccos stats 26685289
      arccos stats 26685289 26627133
    """
    client = _get_client()

    if not round_ids:
        # Default to latest round when no IDs given
        with console.status("Fetching latest round\u2026"):
            rd = client.rounds.list(limit=1)
        if not rd:
            err_console.print("[red]No rounds found.[/red]")
            sys.exit(1)
        round_ids = (rd[0]["roundId"],)
        date = rd[0].get("startTime", "")[:10]
        console.print(f"Using latest round [dim]{round_ids[0]}[/dim] ({date})")

    from arccos.exceptions import ArccosError

    try:
        with console.status(f"Fetching strokes gained for {len(round_ids)} round(s)\u2026"):
            data = client.stats.strokes_gained(list(round_ids))
    except ArccosError as e:
        err_console.print(f"[red]SGA fetch failed:[/red] {e}")
        err_console.print("[dim]The SGA endpoint may not be available for all accounts.[/dim]")
        sys.exit(1)

    if as_json:
        _output_json(data)
        return

    # Pretty print known SGA fields
    SGA_LABELS = {
        "overallSga":  ("Overall",      "Total strokes gained vs. scratch"),
        "drivingSga":  ("Driving",      "Off the tee"),
        "approachSga": ("Approach",     "Approach shots to the green"),
        "shortSga":    ("Short Game",   "Chipping and pitching"),
        "puttingSga":  ("Putting",      "On the green"),
    }

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]Strokes Gained Analysis[/bold]",
    )
    table.add_column("Category",    style="white bold")
    table.add_column("SG",          justify="right", style="bold", no_wrap=True)
    table.add_column("Description", style="dim")

    for key, (label, desc) in SGA_LABELS.items():
        val = data.get(key)
        if val is None:
            continue
        color = "green" if val >= 0 else "red"
        table.add_row(label, f"[{color}]{val:+.2f}[/{color}]", desc)

    console.print(table)
    console.print("[dim]Positive = better than scratch. Negative = worse.[/dim]")

    # Dump any extra keys not in our label map
    extras = {k: v for k, v in data.items() if k not in SGA_LABELS and isinstance(v, (int, float))}
    if extras:
        console.print("\n[dim]Other data:[/dim]")
        for k, v in extras.items():
            console.print(f"  [dim]{k}:[/dim] {v}")


# ---------------------------------------------------------------------------
# bests
# ---------------------------------------------------------------------------

@click.command()
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def bests(as_json: bool):
    """Show your all-time personal bests."""
    client = _get_client()

    with console.status("Fetching personal bests\u2026"):
        data = client.stats.personal_bests()

    if as_json:
        _output_json(data)
        return

    # The API returns {"achievements": [...]} where each has name, stats, course, round
    achievements = data.get("achievements", []) if isinstance(data, dict) else data
    if not achievements:
        console.print("[dim]No personal bests found.[/dim]")
        return

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]Personal Bests[/bold]",
    )
    table.add_column("Record", style="white bold")
    table.add_column("Value", justify="right", style="green bold")
    table.add_column("Course", style="dim")
    table.add_column("Date", style="dim")

    # Map achievement names to display labels and value extractors
    BEST_LABELS: dict[str, tuple[str, ...]] = {
        "lowestScore":        ("Lowest Score",        "noOfShots"),
        "longestDrive":       ("Longest Drive",       "driveDistance", "y"),
        "bestRoundPutting":   ("Fewest Putts",        "noOfPutts"),
        "highestOnePutts":    ("Most 1-Putts",        "noOfOnePutts"),
        "lowestThreePlusPutts": ("Fewest 3-Putts",    "noOfThreePlusPutts"),
        "mostBirdies":        ("Most Birdies",        "noOfBirdies"),
        "mostPars":           ("Most Pars",           "noOfPars"),
        "fewestBogies":       ("Fewest Bogeys",       "noOfBogies"),
        "fewestDoubleBogies": ("Fewest Doubles",      "noOfDoubleBogies"),
        "fairwayPct":         ("Best Fairway %",      "fairwayPct", "%"),
        "girPct":             ("Best GIR %",          "girPct", "%"),
        "puttsPerGir":        ("Best Putts/GIR",      "noOfPuttsPerGir"),
        "mostUpDowns":        ("Most Up & Downs",     "noOfUpDownSuccesses"),
        "mostSandSaves":      ("Most Sand Saves",     "noOfSandSaveSuccesses"),
        "fastestRound":       ("Fastest Round",       "roundTime", "ms"),
        "userHcp":            ("Best Handicap",       "userHcp", "hcp"),
        "driveHcp":           ("Best Drive HCP",      "driveHcp", "hcp"),
        "approachHcp":        ("Best Approach HCP",   "approachHcp", "hcp"),
        "chipHcp":            ("Best Short Game HCP", "chipHcp", "hcp"),
        "sandHcp":            ("Best Sand HCP",       "sandHcp", "hcp"),
        "puttHcp":            ("Best Putt HCP",       "puttHcp", "hcp"),
    }

    for ach in achievements:
        if not isinstance(ach, dict):
            continue
        name = ach.get("name", "")
        ach_stats = ach.get("stats", {})
        info = BEST_LABELS.get(name)
        if info:
            label = info[0]
            stat_key = info[1]
            unit = info[2] if len(info) > 2 else ""
            val = ach_stats.get(stat_key)
            if val is None:
                continue
            if unit == "y":
                display = f"{val:.0f}y"
            elif unit == "%":
                display = f"{val * 100:.1f}%"
            elif unit == "ms":
                mins = int(val / 1000 / 60)
                display = f"{mins // 60}h {mins % 60}m"
            elif unit == "hcp":
                display = f"{val:.1f}"
            else:
                display = str(int(val)) if isinstance(val, float) and val == int(val) else str(val)
        else:
            # Unknown achievement — show raw
            label = name
            first_val = next(iter(ach_stats.values()), None) if ach_stats else None
            display = str(first_val) if first_val is not None else "\u2014"

        course_name = ach.get("course", {}).get("name", "")
        date = ach.get("timestamp", "")[:10]
        table.add_row(label, display, course_name, date)

    if table.row_count == 0:
        console.print("[dim]No personal bests data available.[/dim]")
        return

    console.print(table)


# ---------------------------------------------------------------------------
# overview
# ---------------------------------------------------------------------------

@click.command()
@click.option("--limit", "-n", default=20, show_default=True,
              help="Number of recent rounds to compute averages from.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def overview(limit: int, as_json: bool):
    """Show overall performance summary from recent rounds and handicap."""
    client = _get_client()

    with console.status("Fetching stats\u2026"):
        hcp_data = client.handicap.current()
        rounds_data = client.rounds.list(limit=limit)

    # Compute scoring stats from rounds
    scored = [r for r in rounds_data if r.get("noOfShots") and r.get("noOfHoles") == 18]
    computed_stats: dict = {}
    if scored:
        scores = [r["noOfShots"] for r in scored]
        computed_stats["scoringAvg"] = sum(scores) / len(scores)
        computed_stats["bestScore"] = min(scores)
        computed_stats["worstScore"] = max(scores)
        computed_stats["roundsPlayed"] = len(scored)

    # Add handicap breakdown
    if isinstance(hcp_data, dict):
        computed_stats["handicap"] = hcp_data

    if as_json:
        _output_json(computed_stats)
        return

    if not computed_stats:
        console.print("[dim]No stats available.[/dim]")
        return

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title=f"[bold]Performance Overview[/bold] [dim](last {len(scored)} rounds)[/dim]",
    )
    table.add_column("Stat", style="white bold")
    table.add_column("Value", justify="right", style="bold")

    if "scoringAvg" in computed_stats:
        table.add_row("Scoring Average", f"{computed_stats['scoringAvg']:.1f}")
        table.add_row("Best Score", str(computed_stats["bestScore"]))
        table.add_row("Worst Score", str(computed_stats["worstScore"]))
        table.add_row("Rounds Played", str(computed_stats["roundsPlayed"]))

    # Handicap section
    if "handicap" in computed_stats:
        h = computed_stats["handicap"]
        HCP_FIELDS = [
            ("userHcp", "Overall HCP"),
            ("driveHcp", "Driving HCP"),
            ("approachHcp", "Approach HCP"),
            ("chipHcp", "Short Game HCP"),
            ("sandHcp", "Sand HCP"),
            ("puttHcp", "Putting HCP"),
        ]
        for key, label in HCP_FIELDS:
            val = h.get(key)
            if val is not None:
                table.add_row(label, f"{val:+.1f}" if isinstance(val, float) else str(val))

    console.print(table)


# ---------------------------------------------------------------------------
# courses
# ---------------------------------------------------------------------------

@click.command()
@click.option("--search", "-s", default=None, help="Search for a course by name.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def courses(search: str, as_json: bool):
    """List courses you have played, or search for any course."""
    client = _get_client()

    with console.status("Fetching courses\u2026"):
        data = client.courses.played()

    if search:
        needle = search.lower()
        data = [
            c for c in data
            if needle in (c.get("name") or c.get("courseName") or "").lower()
            or needle in (c.get("city") or "").lower()
        ]

    if as_json:
        _output_json(data)
        return

    if not data:
        console.print("[dim]No courses found.[/dim]")
        return

    table = Table(
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
        title=f"[bold]Courses Played[/bold] [dim]({len(data)} total)[/dim]",
    )
    table.add_column("Course Name",   style="white bold")
    table.add_column("City")
    table.add_column("State")
    table.add_column("Rounds Played", justify="right")
    table.add_column("Course ID",     justify="right", style="dim")

    for c in data:
        name   = c.get("courseName") or c.get("name") or "\u2014"
        city   = c.get("city") or c.get("courseCity") or "\u2014"
        state  = c.get("state") or c.get("courseState") or "\u2014"
        played = str(
            c.get("roundsPlayed") or c.get("roundCount")
            or c.get("noOfTimesPlayed") or "\u2014"
        )
        cid    = str(c.get("courseId") or c.get("id") or "\u2014")
        table.add_row(name, city, state, played, cid)

    console.print(table)


# ---------------------------------------------------------------------------
# club-shots
# ---------------------------------------------------------------------------

@click.command(name="club-shots")
@click.argument("club_id", type=int)
@click.option("--limit", "-n", default=20, show_default=True, help="Number of shots to show.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def club_shots(club_id: int, limit: int, as_json: bool):
    """Show individual shot history for a specific club.

    CLUB_ID is the bag-specific club ID (shown in `arccos clubs --json`).
    """
    client = _get_client()

    with console.status("Fetching shots\u2026"):
        profile = client._http.get(f"/users/{client.user_id}")
        bag_id = profile.get("bagId")
        if not bag_id:
            err_console.print("[red]Could not determine bag ID.[/red]")
            sys.exit(1)
        data = client.clubs.club_shots(str(bag_id), club_id, limit=limit)

    if as_json:
        _output_json(data)
        return

    if not data:
        console.print("[dim]No shots found for this club.[/dim]")
        return

    from arccos.resources.clubs import CLUB_TYPE_NAMES

    # Try to resolve club name
    try:
        bag = client.clubs.bag(str(bag_id))
        bag_club: dict = next(
            (c for c in bag.get("clubs", []) if c["clubId"] == club_id), {}
        )
        club_type = bag_club.get("clubType", club_id)
        club_name = CLUB_TYPE_NAMES.get(club_type, f"Club {club_id}")
    except Exception:
        club_name = f"Club {club_id}"

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title=f"[bold]Shot History — {club_name}[/bold] [dim]({len(data)} shots)[/dim]",
    )
    table.add_column("Date", style="white", no_wrap=True)
    table.add_column("Distance", justify="right", style="green bold")
    table.add_column("Terrain", style="dim")

    for shot in data:
        date = shot.get("shotTime", shot.get("startTime", ""))[:10]
        dist = shot.get("distance")
        dist_s = f"{dist:.0f}y" if dist else "\u2014"
        terrain = str(shot.get("userStartTerrainOverride", ""))
        table.add_row(date, dist_s, terrain)

    console.print(table)


# ---------------------------------------------------------------------------
# up-and-down
# ---------------------------------------------------------------------------

@click.command(name="up-and-down")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def up_and_down(as_json: bool):
    """Show strokes-to-get-down (up-and-down / scramble) stats."""
    client = _get_client()

    from arccos.exceptions import ArccosError

    try:
        with console.status("Fetching up-and-down stats\u2026"):
            data = client.stats.strokes_to_get_down()
    except ArccosError as e:
        err_console.print(f"[red]Failed:[/red] {e}")
        err_console.print(
            "[dim]This endpoint may not be available for all accounts.[/dim]"
        )
        sys.exit(1)

    if as_json:
        _output_json(data)
        return

    if not data:
        console.print("[dim]No up-and-down data available.[/dim]")
        return

    # Display whatever the API returns as a key-value table
    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]Strokes to Get Down[/bold]",
    )
    table.add_column("Stat", style="white bold")
    table.add_column("Value", justify="right", style="bold")

    for key, val in data.items():
        if isinstance(val, (int, float)):
            display = f"{val:.1f}" if isinstance(val, float) else str(val)
            table.add_row(key, display)

    if table.row_count == 0:
        # Nested structure — try one level deeper
        for section, vals in data.items():
            if isinstance(vals, dict):
                for k, v in vals.items():
                    if isinstance(v, (int, float)):
                        display = f"{v:.1f}" if isinstance(v, float) else str(v)
                        table.add_row(f"{section}.{k}", display)

    console.print(table)


# ---------------------------------------------------------------------------
# trends
# ---------------------------------------------------------------------------

@click.command()
@click.option("--rounds", "-n", default=20, show_default=True,
              help="Number of rounds to include.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def trends(rounds: int, as_json: bool):
    """Show handicap trend over recent rounds."""
    client = _get_client()

    with console.status("Fetching handicap history\u2026"):
        data = client.handicap.history(rounds=rounds)

    if as_json:
        _output_json(data)
        return

    if not data or not isinstance(data, builtins_list):
        console.print("[dim]No handicap history available.[/dim]")
        return

    # Extract HCP values
    entries = []
    for entry in data:
        if isinstance(entry, dict) and "userHcp" in entry:
            entries.append(entry)

    if not entries:
        console.print("[dim]No handicap data found in history.[/dim]")
        return

    hcps = [e["userHcp"] for e in entries]
    best = min(hcps)
    worst = max(hcps)
    current = hcps[0]
    change = hcps[0] - hcps[-1] if len(hcps) > 1 else 0.0

    # Summary
    change_color = "green" if change < 0 else "red" if change > 0 else "dim"
    console.print(
        f"\n[bold]Handicap Trend[/bold] [dim]({len(entries)} rounds)[/dim]\n"
        f"  Current: [bold cyan]{current:.1f}[/bold cyan]    "
        f"Best: [bold green]{best:.1f}[/bold green]    "
        f"Worst: [bold red]{worst:.1f}[/bold red]    "
        f"Change: [{change_color}]{change:+.1f}[/{change_color}]\n"
    )

    # Sparkline chart
    hcp_min = min(hcps) - 1
    hcp_max = max(hcps) + 1
    hcp_range = hcp_max - hcp_min if hcp_max != hcp_min else 1

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]HCP Over Time[/bold] (newest first)",
    )
    table.add_column("Round", justify="right", style="dim")
    table.add_column("HCP", justify="right", style="bold")
    table.add_column("", width=20)

    for i, entry in enumerate(entries):
        hcp = entry["userHcp"]
        rid = str(entry.get("roundId", i + 1))
        # Normalized bar position (lower = better for golf)
        bar_len = int((hcp - hcp_min) / hcp_range * 18) + 1
        color = "green" if hcp <= best + 1 else "red" if hcp >= worst - 1 else "yellow"
        bar = f"[{color}]{'█' * bar_len}[/{color}]"
        table.add_row(rid, f"{hcp:.1f}", bar)

    console.print(table)
    console.print("[dim]Lower = better. Green = near best, red = near worst.[/dim]")
