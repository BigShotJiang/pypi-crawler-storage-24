"""Rounds-related CLI commands: rounds, round, export, pace, scoring."""

from __future__ import annotations

import csv
import json
import os
import sys

import click
from rich import box
from rich.panel import Panel
from rich.table import Table

from ._helpers import (
    _build_course_map,
    _flag,
    _get_client,
    _output_json,
    _score_color,
    console,
    err_console,
)


def register(cli: click.Group) -> None:
    cli.add_command(rounds)
    cli.add_command(round_detail)
    cli.add_command(compare)
    cli.add_command(export)
    cli.add_command(pace)
    cli.add_command(scoring)


# ---------------------------------------------------------------------------
# rounds
# ---------------------------------------------------------------------------

@click.command(name="rounds")
@click.option("--limit", "-n", default=20, show_default=True,
              help="Number of rounds to show.")
@click.option("--offset", "-o", default=0,         show_default=True, help="Pagination offset.")
@click.option("--after",  "-a", default=None,      help="Show rounds after date (YYYY-MM-DD).")
@click.option("--before", "-b", default=None,      help="Show rounds before date (YYYY-MM-DD).")
@click.option("--course", "-c", default=None,      help="Filter by course name (substring match).")
@click.option("--json",   "as_json", is_flag=True, help="Output raw JSON.")
def rounds(limit: int, offset: int, after: str, before: str, course: str, as_json: bool):
    """List your recent golf rounds."""
    client = _get_client()

    with console.status("Fetching rounds\u2026"):
        data = client.rounds.list(
            limit=limit, offset=offset,
            after_date=after, before_date=before,
        )
        course_map, par_map = _build_course_map(client)

    if as_json:
        _output_json(data)
        return

    if not data:
        console.print("[dim]No rounds found.[/dim]")
        return

    # Client-side course name filter (case-insensitive substring)
    if course:
        needle = course.lower()
        data = [
            r for r in data
            if needle in (course_map.get(r.get("courseId"), "")).lower()
        ]
        if not data:
            console.print(f"[dim]No rounds found matching \"{course}\".[/dim]")
            return

    table = Table(
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
        title=f"[bold]Rounds[/bold] [dim]({len(data)} shown)[/dim]",
    )
    table.add_column("Date",    style="white",  no_wrap=True)
    table.add_column("Score",   style="bold",   justify="right")
    table.add_column("+/-",     justify="right")
    table.add_column("Holes",   justify="right")
    table.add_column("Course")
    table.add_column("ID",      justify="right", style="dim")

    for r in data:
        date  = r.get("startTime", "")[:10]
        shots = r.get("noOfShots")
        score = str(shots) if shots else "\u2014"
        par   = par_map.get(r.get("courseId"))
        n_holes = r.get("noOfHoles", 0)
        # Compute +/- from score and course par (only for 18-hole rounds)
        if shots and par and n_holes == 18:
            diff = shots - par
            ou_s = f"{diff:+d}"
        else:
            ou_s = ""
        holes = str(n_holes) if n_holes else "\u2014"
        cname = course_map.get(r.get("courseId"), str(r.get("courseId", "\u2014")))
        rid   = str(r.get("roundId", "\u2014"))
        table.add_row(date, score, ou_s, holes, cname, rid)

    console.print(table)


# ---------------------------------------------------------------------------
# round (detail)
# ---------------------------------------------------------------------------

@click.command(name="round")
@click.argument("round_id", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def round_detail(round_id: int, as_json: bool):
    """Show hole-by-hole detail for a single round."""
    client = _get_client()

    with console.status(f"Fetching round {round_id}\u2026"):
        meta = client.rounds.get(round_id)
        # Try to get par data from the course
        par_map: dict[int, int] = {}
        course_id = meta.get("courseId")
        if course_id:
            try:
                course_data = client.courses.get(course_id)
                for h in course_data.get("holes", []):
                    par_map[h["holeId"]] = h.get("par", 0)
            except Exception:
                pass

    if as_json:
        _output_json(meta)
        return

    # --- Summary panel ---
    date = meta.get("startTime", "\u2014")[:10] if meta.get("startTime") else "\u2014"
    score = meta.get("noOfShots", "\u2014")
    n_holes = meta.get("noOfHoles", "\u2014")

    # Resolve course name and par from played courses
    course_map, course_par_map = _build_course_map(client)
    cid = meta.get("courseId")
    course_name = course_map.get(cid) or meta.get("courseName") or str(cid or "\u2014")
    course_par = course_par_map.get(cid)

    # Compute +/- from score and course par
    if isinstance(score, int) and course_par and n_holes == 18:
        ou_str = f" ({score - course_par:+d})"
    else:
        ou_str = ""

    summary = (
        f"[bold]Date:[/bold]   {date}\n"
        f"[bold]Course:[/bold] {course_name}\n"
        f"[bold]Score:[/bold]  {score}{ou_str}\n"
        f"[bold]Holes:[/bold]  {n_holes}"
    )
    console.print(Panel(
        summary,
        title=f"[bold cyan]Round {round_id}[/bold cyan]",
        expand=False,
    ))

    # Holes are embedded in the round response
    holes = meta.get("holes", [])
    if not holes:
        console.print("[dim]No hole data available.[/dim]")
        return

    has_par = bool(par_map)
    table = Table(
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
        title="[bold]Hole-by-Hole[/bold]",
    )
    table.add_column("Hole", justify="right")
    if has_par:
        table.add_column("Par", justify="right", style="dim")
    table.add_column("Score", justify="right", style="bold")
    table.add_column("Putts", justify="right")
    table.add_column("FIR", justify="center")
    table.add_column("GIR", justify="center")

    total_score = 0
    total_putts = 0
    total_par = 0
    for h in holes:
        hole_num = h.get("holeId", 0)
        sc = h.get("noOfShots")
        putts = h.get("putts")
        fir = h.get("isFairWay", "\u2014")
        gir = h.get("isGir", "\u2014")
        par = par_map.get(hole_num)

        if sc is not None:
            color = _score_color(sc, par)
            score_str = f"[{color}]{sc}[/{color}]"
            total_score += sc
        else:
            score_str = "\u2014"

        putts_str = str(putts) if putts is not None else "\u2014"
        if putts is not None:
            total_putts += putts
        if par is not None:
            total_par += par

        # Color FIR/GIR: T=green, F=red
        if fir == "T":
            fir = "[green]T[/green]"
        elif fir == "F":
            fir = "[red]F[/red]"
        if gir == "T":
            gir = "[green]T[/green]"
        elif gir == "F":
            gir = "[red]F[/red]"

        row = [str(hole_num)]
        if has_par:
            row.append(str(par) if par else "\u2014")
        row.extend([score_str, putts_str, fir, gir])
        table.add_row(*row)

    # Totals row
    table.add_section()
    tot_row = ["[bold]Tot[/bold]"]
    if has_par:
        tot_row.append(f"[bold]{total_par}[/bold]" if total_par else "")
    tot_row.extend([
        f"[bold]{total_score}[/bold]",
        f"[bold]{total_putts}[/bold]",
        "", "",
    ])
    table.add_row(*tot_row)

    console.print(table)


# ---------------------------------------------------------------------------
# compare
# ---------------------------------------------------------------------------

@click.command()
@click.argument("round_a", type=int)
@click.argument("round_b", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def compare(round_a: int, round_b: int, as_json: bool):
    """Compare two rounds side-by-side, hole by hole.

    \b
    Examples:
      arccos compare 26685289 26762935
    """
    client = _get_client()

    with console.status("Fetching rounds\u2026"):
        meta_a = client.rounds.get(round_a)
        meta_b = client.rounds.get(round_b)
        course_map, par_map = _build_course_map(client)

    if as_json:
        _output_json({"round_a": meta_a, "round_b": meta_b})
        return

    def _course_name(meta: dict) -> str:
        cid: int = meta.get("courseId", 0)
        return course_map.get(cid) or meta.get("courseName") or str(cid or "\u2014")

    def _ou(meta: dict) -> str:
        shots = meta.get("noOfShots")
        cid: int = meta.get("courseId", 0)
        par = par_map.get(cid)
        if shots and par and meta.get("noOfHoles") == 18:
            return f" ({shots - par:+d})"
        return ""

    # Summary panel
    date_a = (meta_a.get("startTime") or "")[:10]
    date_b = (meta_b.get("startTime") or "")[:10]
    score_a = meta_a.get("noOfShots", "\u2014")
    score_b = meta_b.get("noOfShots", "\u2014")

    summary = (
        f"[bold cyan]Round A:[/bold cyan] {date_a}  {_course_name(meta_a)}  "
        f"[bold]{score_a}{_ou(meta_a)}[/bold]\n"
        f"[bold cyan]Round B:[/bold cyan] {date_b}  {_course_name(meta_b)}  "
        f"[bold]{score_b}{_ou(meta_b)}[/bold]"
    )
    console.print(Panel(summary, title="[bold]Round Comparison[/bold]", expand=False))

    holes_a = {h["holeId"]: h for h in meta_a.get("holes", [])}
    holes_b = {h["holeId"]: h for h in meta_b.get("holes", [])}

    if not holes_a and not holes_b:
        console.print("[dim]No hole data available for either round.[/dim]")
        return

    all_holes = sorted(set(holes_a.keys()) | set(holes_b.keys()))

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]Hole-by-Hole Comparison[/bold]",
    )
    table.add_column("Hole", justify="right")
    table.add_column("A", justify="right", style="bold")
    table.add_column("B", justify="right", style="bold")
    table.add_column("Diff", justify="right")
    table.add_column("A Putts", justify="right", style="dim")
    table.add_column("B Putts", justify="right", style="dim")

    total_a = total_b = total_putts_a = total_putts_b = 0
    for h_id in all_holes:
        ha = holes_a.get(h_id, {})
        hb = holes_b.get(h_id, {})
        sa = ha.get("noOfShots")
        sb = hb.get("noOfShots")
        pa = ha.get("putts")
        pb = hb.get("putts")

        sa_s = str(sa) if sa is not None else "\u2014"
        sb_s = str(sb) if sb is not None else "\u2014"
        pa_s = str(pa) if pa is not None else "\u2014"
        pb_s = str(pb) if pb is not None else "\u2014"

        if sa is not None and sb is not None:
            diff = sb - sa
            color = "green" if diff < 0 else "red" if diff > 0 else "dim"
            diff_s = f"[{color}]{diff:+d}[/{color}]"
        else:
            diff_s = ""

        if sa:
            total_a += sa
        if sb:
            total_b += sb
        if pa:
            total_putts_a += pa
        if pb:
            total_putts_b += pb

        table.add_row(str(h_id), sa_s, sb_s, diff_s, pa_s, pb_s)

    # Totals
    table.add_section()
    total_diff = total_b - total_a
    diff_color = "green" if total_diff < 0 else "red" if total_diff > 0 else "dim"
    table.add_row(
        "[bold]Tot[/bold]",
        f"[bold]{total_a}[/bold]",
        f"[bold]{total_b}[/bold]",
        f"[{diff_color}][bold]{total_diff:+d}[/bold][/{diff_color}]",
        f"[bold]{total_putts_a}[/bold]",
        f"[bold]{total_putts_b}[/bold]",
    )

    console.print(table)


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------

@click.command()
@click.option("--limit",  "-n",  default=200,     show_default=True, help="Max rounds to export.")
@click.option("--format", "-f",  "fmt",
              type=click.Choice(["json", "csv", "ndjson"]), default="json",
              show_default=True, help="Output format.")
@click.option("--output", "-o",  default="-",     help="Output file path (default: stdout).")
@click.option("--detail", "-d",  is_flag=True,    help="Include hole-by-hole data per round.")
def export(limit: int, fmt: str, output: str, detail: bool):
    """Export round data to JSON or CSV."""
    client = _get_client()

    with console.status(f"Fetching up to {limit} rounds\u2026"):
        data = client.rounds.list(limit=limit)

    if not data:
        err_console.print("[red]No rounds found.[/red]")
        sys.exit(1)

    if detail:
        from rich.progress import Progress

        with Progress(console=err_console) as progress:
            task = progress.add_task("Fetching hole data\u2026", total=len(data))
            for r in data:
                try:
                    full = client.rounds.get(r["roundId"])
                    r["holes"] = full.get("holes", [])
                except Exception:
                    r["holes"] = []
                progress.advance(task)

    def _write(out):
        if fmt == "json":
            json.dump(data, out, indent=2)
            out.write("\n")
        elif fmt == "ndjson":
            for r in data:
                out.write(json.dumps(r) + "\n")
        else:
            if not data:
                return
            keys = list(data[0].keys())
            # Exclude nested 'holes' from CSV (not tabular)
            keys = [k for k in keys if k != "holes"]
            writer = csv.DictWriter(
                out, fieldnames=keys, extrasaction="ignore",
            )
            writer.writeheader()
            writer.writerows(data)

    if output == "-":
        _write(sys.stdout)
    else:
        out_path = os.path.realpath(output)
        with open(out_path, "w", newline="") as out:
            _write(out)
        console.print(
            f"[green]\u2713[/green] Exported {len(data)} rounds to [bold]{output}[/bold]"
        )


# ---------------------------------------------------------------------------
# pace
# ---------------------------------------------------------------------------

@click.command()
@click.option("--limit", "-n", default=200, show_default=True, help="Max rounds to analyse.")
@click.option("--json",  "as_json", is_flag=True, help="Output raw JSON.")
def pace(limit: int, as_json: bool):
    """Show pace of play (round duration) by course."""
    client = _get_client()

    with console.status(f"Fetching up to {limit} rounds and course names\u2026"):
        data = client.rounds.pace_of_play(
            rounds=client.rounds.list(limit=limit)
        )

    if as_json:
        _output_json(data)
        return

    n_rounds  = len(data["rounds"])
    n_courses = len(data["course_averages"])

    avg = data['overall_avg_display']
    console.print(
        f"\n[bold]Pace of Play[/bold] \u2014 "
        f"[dim]{n_rounds} rounds across {n_courses} courses[/dim]"
        f"   Overall avg: [bold cyan]{avg}[/bold cyan]\n"
    )

    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]By Course[/bold] (slowest first)",
    )
    table.add_column("",        width=2)
    table.add_column("Avg Time", justify="right", style="bold")
    table.add_column("Course",   style="white")
    table.add_column("Rounds",   justify="right", style="dim")

    for c in data["course_averages"]:
        flag = _flag(c["avg_minutes"])
        table.add_row(flag, c["avg_display"], c["course"], str(c["rounds"]))

    console.print(table)

    console.print("\n[bold]Recent Rounds:[/bold]")
    recent_table = Table(box=box.SIMPLE, show_header=True, header_style="dim")
    recent_table.add_column("",       width=2)
    recent_table.add_column("Date",   style="dim")
    recent_table.add_column("Time",   justify="right", style="bold")
    recent_table.add_column("Score",  justify="right")
    recent_table.add_column("Course")

    for r in data["rounds"][:10]:
        flag = _flag(r["duration_minutes"])
        recent_table.add_row(
            flag, r["date"], r["duration_display"],
            str(r["score"] or "\u2014"), r["course"],
        )

    console.print(recent_table)
    console.print("[dim]\U0001f534 >5h  \U0001f7e1 4.5\u20135h  \U0001f7e2 <4.5h[/dim]")


# ---------------------------------------------------------------------------
# scoring
# ---------------------------------------------------------------------------

@click.command()
@click.option("--limit", "-n", default=20, show_default=True,
              help="Number of recent rounds to include.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
def scoring(limit: int, as_json: bool):
    """Show scoring trend over recent rounds."""
    client = _get_client()

    with console.status(f"Fetching last {limit} rounds\u2026"):
        data = client.rounds.list(limit=limit)
        course_map, par_map = _build_course_map(client)

    if as_json:
        _output_json(data)
        return

    # Filter to 18-hole rounds with valid scores
    scored = [
        r for r in data
        if r.get("noOfShots") and r.get("noOfHoles") == 18
    ]

    if not scored:
        console.print("[dim]No 18-hole rounds found.[/dim]")
        return

    scores = [r["noOfShots"] for r in scored]
    avg = sum(scores) / len(scores)
    best = min(scores)
    worst = max(scores)

    # Summary
    console.print(
        f"\n[bold]Scoring Trend[/bold] [dim]({len(scored)} rounds)[/dim]\n"
        f"  Average: [bold cyan]{avg:.1f}[/bold cyan]    "
        f"Best: [bold green]{best}[/bold green]    "
        f"Worst: [bold red]{worst}[/bold red]\n"
    )

    # Sparkline-style trend table
    table = Table(
        box=box.ROUNDED,
        header_style="bold cyan",
        title="[bold]Recent Scores[/bold] (newest first)",
    )
    table.add_column("Date", style="white", no_wrap=True)
    table.add_column("Score", justify="right", style="bold")
    table.add_column("+/-", justify="right")
    table.add_column("Course")
    table.add_column("", width=12)  # bar

    for r in scored:
        date = r.get("startTime", "")[:10]
        sc = r["noOfShots"]
        par = par_map.get(r.get("courseId"))
        ou_s = f"{sc - par:+d}" if par else ""
        cname = course_map.get(r.get("courseId"), "")

        # Visual bar: green below avg, red above
        bar_len = min(abs(sc - int(avg)), 10)
        color = "green" if sc <= avg else "red"
        bar = f"[{color}]{'█' * bar_len}[/{color}]"

        table.add_row(date, str(sc), ou_s, cname, bar)

    console.print(table)
