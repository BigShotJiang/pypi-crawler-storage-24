"""
arccos CLI — pull your Arccos Golf data from the terminal.

Uses the reverse-engineered Arccos Golf API. Not affiliated with Arccos Golf LLC.
"""

from __future__ import annotations

import click
from rich import box
from rich.console import Console
from rich.table import Table

from . import auth, rounds, stats

_console = Console(stderr=True)


class RichGroup(click.Group):
    """Click group that renders help with Rich formatting."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        _console.print(
            "\n[bold cyan]arccos[/bold cyan] — Your Arccos Golf data in the terminal.\n"
        )

        table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        table.add_column(style="bold green", no_wrap=True)
        table.add_column(style="dim")

        cmds = [
            ("login", "Authenticate and save credentials"),
            ("rounds", "List recent rounds with +/- and course names"),
            ("round <id>", "Hole-by-hole detail for a round"),
            ("compare <a> <b>", "Side-by-side round comparison"),
            ("handicap", "Current handicap index breakdown"),
            ("clubs", "Smart club distances with make/model"),
            ("club-shots <id>", "Shot history for a specific club"),
            ("courses", "Courses you've played (--search to filter)"),
            ("bests", "All-time personal bests"),
            ("overview", "Scoring avg + handicap breakdown"),
            ("scoring", "Scoring trend with bar chart"),
            ("trends", "Handicap trend over time"),
            ("pace", "Pace of play by course"),
            ("stats", "Strokes gained analysis"),
            ("up-and-down", "Scramble / strokes-to-get-down stats"),
            ("export", "Export rounds to JSON/CSV/NDJSON"),
            ("completions", "Generate shell completion script"),
            ("logout", "Clear cached credentials"),
        ]
        for cmd, desc in cmds:
            table.add_row(f"arccos {cmd}", desc)

        _console.print(table)
        _console.print(
            "\n[dim]All commands support [bold]--json[/bold] and [bold]--help[/bold]. "
            "Credentials cached in ~/.arccos_creds.json.[/dim]\n"
        )


@click.group(cls=RichGroup)
@click.version_option(package_name="arccos-api", prog_name="arccos")
def cli():
    """arccos — Your Arccos Golf data in the terminal."""


# Register all command submodules
auth.register(cli)
rounds.register(cli)
stats.register(cli)


def main():
    cli()


if __name__ == "__main__":
    main()
