"""
Tests for arccos.cli — CLI commands via Click's CliRunner.

These tests mock the ArccosClient so no real API calls are made.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from arccos.cli import cli

# Patch targets — commands import _get_client from their own modules
_ROUNDS_GET_CLIENT = "arccos.cli.rounds._get_client"
_STATS_GET_CLIENT = "arccos.cli.stats._get_client"


@pytest.fixture
def runner():
    return CliRunner()


def _mock_client():
    """Create a fully mocked ArccosClient with all resource attributes."""
    client = MagicMock()
    client.email = "test@example.com"
    client.user_id = "user-123"
    # Default: courses.played returns empty (used by _build_course_map)
    client.courses.played.return_value = []
    return client


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------

class TestLoginCommand:
    @patch("arccos.ArccosClient")
    def test_login_success(self, MockClient, runner):
        client = _mock_client()
        MockClient.return_value = client

        result = runner.invoke(cli, ["login", "--email", "a@b.com", "--password", "pass"])
        assert result.exit_code == 0
        assert "Logged in" in result.output

    @patch("arccos.ArccosClient")
    def test_login_failure(self, MockClient, runner):
        from arccos.exceptions import ArccosAuthError
        MockClient.side_effect = ArccosAuthError("Bad creds", status_code=401)

        result = runner.invoke(cli, ["login", "--email", "a@b.com", "--password", "wrong"])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# rounds
# ---------------------------------------------------------------------------

class TestRoundsCommand:
    @patch(_ROUNDS_GET_CLIENT)
    def test_rounds_table_output(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {
                "roundId": 1,
                "courseId": 100,
                "startTime": "2025-06-01T08:00:00.000Z",
                "noOfShots": 85,
                "noOfHoles": 18,
            }
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["rounds"])
        assert result.exit_code == 0
        assert "2025-06-01" in result.output
        assert "85" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_rounds_json_output(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [{"roundId": 1}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["rounds", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data[0]["roundId"] == 1

    @patch(_ROUNDS_GET_CLIENT)
    def test_rounds_empty(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = []
        mock_get.return_value = client

        result = runner.invoke(cli, ["rounds"])
        assert result.exit_code == 0
        assert "No rounds found" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_rounds_passes_options(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = []
        mock_get.return_value = client

        runner.invoke(
            cli, ["rounds", "-n", "5", "-o", "10", "-a", "2025-01-01", "-b", "2025-06-01"]
        )
        client.rounds.list.assert_called_once_with(
            limit=5, offset=10, after_date="2025-01-01", before_date="2025-06-01"
        )


# ---------------------------------------------------------------------------
# handicap
# ---------------------------------------------------------------------------

class TestHandicapCommand:
    @patch(_STATS_GET_CLIENT)
    def test_handicap_current(self, mock_get, runner):
        client = _mock_client()
        client.handicap.current.return_value = {"handicapIndex": 18.2}
        mock_get.return_value = client

        result = runner.invoke(cli, ["handicap"])
        assert result.exit_code == 0
        assert "18.2" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_handicap_history(self, mock_get, runner):
        client = _mock_client()
        client.handicap.history.return_value = [
            {"date": "2025-01-01", "index": 18.2},
            {"date": "2025-02-01", "index": 17.5},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["handicap", "--history"])
        assert result.exit_code == 0
        assert "18.2" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_handicap_json(self, mock_get, runner):
        client = _mock_client()
        client.handicap.current.return_value = {"handicapIndex": 18.2}
        mock_get.return_value = client

        result = runner.invoke(cli, ["handicap", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["handicapIndex"] == 18.2


# ---------------------------------------------------------------------------
# clubs
# ---------------------------------------------------------------------------

class TestClubsCommand:
    @patch(_STATS_GET_CLIENT)
    def test_clubs_table_output(self, mock_get, runner):
        client = _mock_client()
        client.clubs.smart_distances.return_value = [
            {
                "clubId": 1,
                "smartDistance": {"distance": 240.5, "unit": "yd"},
                "longest": {"distance": 285.0, "unit": "yd"},
                "range": {"low": 230.0, "high": 250.0, "unit": "yd"},
                "usage": {"count": 50},
            },
            {
                "clubId": 9,
                "smartDistance": {"distance": 155.0, "unit": "yd"},
                "longest": {"distance": 170.0, "unit": "yd"},
                "range": {"low": 145.0, "high": 165.0, "unit": "yd"},
                "usage": {"count": 80},
            },
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["clubs"])
        assert result.exit_code == 0
        assert "Dr" in result.output
        assert "240y" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_clubs_empty(self, mock_get, runner):
        client = _mock_client()
        client.clubs.smart_distances.return_value = []
        mock_get.return_value = client

        result = runner.invoke(cli, ["clubs"])
        assert "No club data" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_clubs_json(self, mock_get, runner):
        client = _mock_client()
        client.clubs.smart_distances.return_value = [{"clubType": "PW"}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["clubs", "--json"])
        data = json.loads(result.output)
        assert data[0]["clubType"] == "PW"


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------

class TestStatsCommand:
    @patch(_STATS_GET_CLIENT)
    def test_stats_with_round_id(self, mock_get, runner):
        client = _mock_client()
        client.stats.strokes_gained.return_value = {
            "overallSga": -2.1,
            "drivingSga": 0.4,
            "approachSga": -1.8,
            "shortSga": -0.3,
            "puttingSga": -0.4,
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["stats", "12345"])
        assert result.exit_code == 0
        assert "Overall" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_stats_latest(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 999, "startTime": "2025-06-01T08:00:00Z"}
        ]
        client.stats.strokes_gained.return_value = {"overallSga": 1.5}
        mock_get.return_value = client

        result = runner.invoke(cli, ["stats", "--latest"])
        assert result.exit_code == 0
        client.stats.strokes_gained.assert_called_once_with([999])

    @patch(_STATS_GET_CLIENT)
    def test_stats_no_args_defaults_latest(self, mock_get, runner):
        """When no round IDs given, stats defaults to the latest round."""
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 999, "startTime": "2025-06-01T08:00:00Z"}
        ]
        client.stats.strokes_gained.return_value = {"overallSga": 1.5}
        mock_get.return_value = client

        result = runner.invoke(cli, ["stats"])
        assert result.exit_code == 0
        client.stats.strokes_gained.assert_called_once_with([999])

    @patch(_STATS_GET_CLIENT)
    def test_stats_json(self, mock_get, runner):
        client = _mock_client()
        client.stats.strokes_gained.return_value = {"overallSga": -2.1}
        mock_get.return_value = client

        result = runner.invoke(cli, ["stats", "--json", "12345"])
        data = json.loads(result.output)
        assert data["overallSga"] == -2.1


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------

class TestExportCommand:
    @patch(_ROUNDS_GET_CLIENT)
    def test_export_json_stdout(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [{"roundId": 1, "noOfShots": 85}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["export"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data[0]["roundId"] == 1

    @patch(_ROUNDS_GET_CLIENT)
    def test_export_csv_stdout(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [{"roundId": 1, "noOfShots": 85}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["export", "-f", "csv"])
        assert result.exit_code == 0
        assert "roundId" in result.output
        assert "85" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_export_ndjson_stdout(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 1},
            {"roundId": 2},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["export", "-f", "ndjson"])
        assert result.exit_code == 0
        lines = result.output.strip().split("\n")
        assert len(lines) == 2

    @patch(_ROUNDS_GET_CLIENT)
    def test_export_to_file(self, mock_get, runner, tmp_path):
        client = _mock_client()
        client.rounds.list.return_value = [{"roundId": 1}]
        mock_get.return_value = client

        outfile = str(tmp_path / "out.json")
        result = runner.invoke(cli, ["export", "-o", outfile])
        assert result.exit_code == 0
        data = json.loads((tmp_path / "out.json").read_text())
        assert data[0]["roundId"] == 1

    @patch(_ROUNDS_GET_CLIENT)
    def test_export_empty_rounds(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = []
        mock_get.return_value = client

        result = runner.invoke(cli, ["export"])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# pace
# ---------------------------------------------------------------------------

class TestPaceCommand:
    @patch(_ROUNDS_GET_CLIENT)
    def test_pace_output(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = []
        client.rounds.pace_of_play.return_value = {
            "rounds": [
                {
                    "date": "2025-06-01",
                    "course": "Test GC",
                    "score": 85,
                    "duration_minutes": 270,
                    "duration_display": "4h 30m",
                    "round_id": 1,
                }
            ],
            "course_averages": [
                {"course": "Test GC", "avg_minutes": 270, "avg_display": "4h 30m", "rounds": 1}
            ],
            "overall_avg_minutes": 270,
            "overall_avg_display": "4h 30m",
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["pace"])
        assert result.exit_code == 0
        assert "4h 30m" in result.output
        assert "Test GC" in result.output


# ---------------------------------------------------------------------------
# courses
# ---------------------------------------------------------------------------

class TestCoursesCommand:
    @patch(_STATS_GET_CLIENT)
    def test_courses_table_output(self, mock_get, runner):
        client = _mock_client()
        client.courses.played.return_value = [
            {"courseName": "Augusta National", "city": "Augusta", "state": "GA",
             "roundsPlayed": 3, "courseId": 100},
            {"courseName": "Pebble Beach", "city": "Pebble Beach", "state": "CA",
             "roundsPlayed": 1, "courseId": 200},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["courses"])
        assert result.exit_code == 0
        assert "Augusta National" in result.output
        assert "Pebble Beach" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_courses_empty(self, mock_get, runner):
        client = _mock_client()
        client.courses.played.return_value = []
        mock_get.return_value = client

        result = runner.invoke(cli, ["courses"])
        assert result.exit_code == 0
        assert "No courses found" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_courses_json(self, mock_get, runner):
        client = _mock_client()
        client.courses.played.return_value = [{"courseName": "Test GC"}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["courses", "--json"])
        data = json.loads(result.output)
        assert data[0]["courseName"] == "Test GC"


# ---------------------------------------------------------------------------
# round (detail)
# ---------------------------------------------------------------------------

class TestRoundDetailCommand:
    @patch(_ROUNDS_GET_CLIENT)
    def test_round_detail_output(self, mock_get, runner):
        client = _mock_client()
        client.rounds.get.return_value = {
            "roundId": 12345,
            "courseId": 100,
            "courseName": "Test GC",
            "startTime": "2025-06-01T08:00:00.000Z",
            "noOfShots": 85,
            "noOfHoles": 18,
            "holes": [
                {"holeId": 1, "noOfShots": 5, "putts": 2, "isFairWay": "T", "isGir": "F"},
                {"holeId": 2, "noOfShots": 3, "putts": 1, "isFairWay": None, "isGir": "T"},
                {"holeId": 3, "noOfShots": 4, "putts": 2, "isFairWay": "T", "isGir": "T"},
            ],
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["round", "12345"])
        assert result.exit_code == 0
        assert "2025-06-01" in result.output
        assert "85" in result.output
        assert "Test GC" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_round_detail_no_holes(self, mock_get, runner):
        client = _mock_client()
        client.rounds.get.return_value = {
            "roundId": 12345,
            "startTime": "2025-06-01T08:00:00.000Z",
            "noOfShots": 85,
            "noOfHoles": 18,
            "holes": [],
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["round", "12345"])
        assert result.exit_code == 0
        assert "No hole data" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_round_detail_json(self, mock_get, runner):
        client = _mock_client()
        client.rounds.get.return_value = {
            "roundId": 12345,
            "holes": [{"holeId": 1}],
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["round", "--json", "12345"])
        data = json.loads(result.output)
        assert data["roundId"] == 12345


# ---------------------------------------------------------------------------
# logout
# ---------------------------------------------------------------------------

class TestLogoutCommand:
    def test_logout_with_existing_creds(self, runner, tmp_path):
        creds_file = tmp_path / ".arccos_creds.json"
        creds_file.write_text('{"test": true}')

        with patch("arccos.auth.DEFAULT_CREDS_PATH", creds_file):
            result = runner.invoke(cli, ["logout"])

        assert result.exit_code == 0
        assert "removed" in result.output
        assert not creds_file.exists()
        assert "tokens are not revoked" in result.output

    def test_logout_no_creds(self, runner, tmp_path):
        creds_file = tmp_path / ".arccos_creds.json"

        with patch("arccos.auth.DEFAULT_CREDS_PATH", creds_file):
            result = runner.invoke(cli, ["logout"])

        assert result.exit_code == 0
        assert "No cached" in result.output


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------

class TestVersionCommand:
    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "arccos" in result.output


# ---------------------------------------------------------------------------
# help
# ---------------------------------------------------------------------------

class TestHelpCommand:
    def test_help(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "arccos" in result.output


# ---------------------------------------------------------------------------
# rounds with course names
# ---------------------------------------------------------------------------

class TestRoundsWithCourseNames:
    @patch(_ROUNDS_GET_CLIENT)
    def test_rounds_show_course_name(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 1, "courseId": 100, "startTime": "2025-06-01T08:00:00.000Z",
             "noOfShots": 85, "noOfHoles": 18},
        ]
        client.courses.played.return_value = [
            {"courseId": 100, "courseName": "Pebble Beach", "mensPar": 72},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["rounds"])
        assert result.exit_code == 0
        assert "Pebble Beach" in result.output
        assert "+13" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_rounds_course_filter(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 1, "courseId": 100, "startTime": "2025-06-01T08:00:00.000Z",
             "noOfShots": 85, "noOfHoles": 18},
            {"roundId": 2, "courseId": 200, "startTime": "2025-06-02T08:00:00.000Z",
             "noOfShots": 78, "noOfHoles": 18},
        ]
        client.courses.played.return_value = [
            {"courseId": 100, "courseName": "Pebble Beach", "mensPar": 72},
            {"courseId": 200, "courseName": "Augusta National", "mensPar": 72},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["rounds", "--course", "pebble"])
        assert result.exit_code == 0
        assert "Pebble Beach" in result.output
        assert "Augusta" not in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_rounds_course_filter_no_match(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 1, "courseId": 100, "startTime": "2025-06-01T08:00:00.000Z",
             "noOfShots": 85, "noOfHoles": 18},
        ]
        client.courses.played.return_value = [
            {"courseId": 100, "courseName": "Pebble Beach", "mensPar": 72},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["rounds", "--course", "xyz"])
        assert result.exit_code == 0
        assert "No rounds found matching" in result.output


# ---------------------------------------------------------------------------
# bests
# ---------------------------------------------------------------------------

class TestBestsCommand:
    @patch(_STATS_GET_CLIENT)
    def test_bests_table(self, mock_get, runner):
        client = _mock_client()
        client.stats.personal_bests.return_value = {
            "achievements": [
                {"name": "lowestScore", "stats": {"noOfShots": 72, "par": 72},
                 "course": {"name": "Pebble Beach"}, "timestamp": "2025-06-01T00:00:00.000Z"},
                {"name": "longestDrive", "stats": {"driveDistance": 305.4},
                 "course": {"name": "Augusta"}, "timestamp": "2025-07-01T00:00:00.000Z"},
                {"name": "bestRoundPutting", "stats": {"noOfPutts": 28},
                 "course": {"name": "TPC"}, "timestamp": "2025-08-01T00:00:00.000Z"},
            ],
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["bests"])
        assert result.exit_code == 0
        assert "72" in result.output
        assert "305y" in result.output
        assert "28" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_bests_json(self, mock_get, runner):
        client = _mock_client()
        client.stats.personal_bests.return_value = {"achievements": [{"name": "lowestScore"}]}
        mock_get.return_value = client

        result = runner.invoke(cli, ["bests", "--json"])
        data = json.loads(result.output)
        assert "achievements" in data

    @patch(_STATS_GET_CLIENT)
    def test_bests_empty(self, mock_get, runner):
        client = _mock_client()
        client.stats.personal_bests.return_value = {"achievements": []}
        mock_get.return_value = client

        result = runner.invoke(cli, ["bests"])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# overview
# ---------------------------------------------------------------------------

class TestOverviewCommand:
    @patch(_STATS_GET_CLIENT)
    def test_overview_table(self, mock_get, runner):
        client = _mock_client()
        client.handicap.current.return_value = {
            "userHcp": -15.2, "driveHcp": -10.1, "approachHcp": -20.3,
            "chipHcp": -12.0, "sandHcp": -5.5, "puttHcp": -8.0,
        }
        client.rounds.list.return_value = [
            {"roundId": 1, "noOfShots": 85, "noOfHoles": 18},
            {"roundId": 2, "noOfShots": 80, "noOfHoles": 18},
            {"roundId": 3, "noOfShots": 78, "noOfHoles": 18},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["overview"])
        assert result.exit_code == 0
        assert "81.0" in result.output  # scoring avg
        assert "78" in result.output    # best
        assert "85" in result.output    # worst

    @patch(_STATS_GET_CLIENT)
    def test_overview_json(self, mock_get, runner):
        client = _mock_client()
        client.handicap.current.return_value = {"userHcp": -15.2}
        client.rounds.list.return_value = [
            {"roundId": 1, "noOfShots": 85, "noOfHoles": 18},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["overview", "--json"])
        data = json.loads(result.output)
        assert data["scoringAvg"] == 85.0


# ---------------------------------------------------------------------------
# scoring
# ---------------------------------------------------------------------------

class TestScoringCommand:
    @patch(_ROUNDS_GET_CLIENT)
    def test_scoring_trend(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 1, "courseId": 100, "startTime": "2025-06-01T08:00:00.000Z",
             "noOfShots": 85, "noOfHoles": 18},
            {"roundId": 2, "courseId": 100, "startTime": "2025-06-02T08:00:00.000Z",
             "noOfShots": 80, "noOfHoles": 18},
            {"roundId": 3, "courseId": 100, "startTime": "2025-06-03T08:00:00.000Z",
             "noOfShots": 78, "noOfHoles": 18},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["scoring"])
        assert result.exit_code == 0
        assert "81.0" in result.output  # avg of 85+80+78
        assert "78" in result.output    # best
        assert "85" in result.output    # worst

    @patch(_ROUNDS_GET_CLIENT)
    def test_scoring_no_18_hole_rounds(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [
            {"roundId": 1, "courseId": 100, "startTime": "2025-06-01T08:00:00.000Z",
             "noOfShots": 42, "noOfHoles": 9},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["scoring"])
        assert result.exit_code == 0
        assert "No 18-hole rounds" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_scoring_json(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [{"roundId": 1}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["scoring", "--json"])
        data = json.loads(result.output)
        assert data[0]["roundId"] == 1


# ---------------------------------------------------------------------------
# export with --detail
# ---------------------------------------------------------------------------

class TestExportDetailFlag:
    @patch(_ROUNDS_GET_CLIENT)
    def test_export_detail_json(self, mock_get, runner):
        client = _mock_client()
        client.rounds.list.return_value = [{"roundId": 1, "noOfShots": 85}]
        client.rounds.get.return_value = {
            "roundId": 1,
            "holes": [{"holeId": 1, "noOfShots": 4}],
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["export", "--detail"])
        assert result.exit_code == 0
        # Strip progress bar output (written to stderr but may bleed into output)
        output = result.output
        json_start = output.find("[")
        data = json.loads(output[json_start:])
        assert "holes" in data[0]
        assert data[0]["holes"][0]["holeId"] == 1


# ---------------------------------------------------------------------------
# course search
# ---------------------------------------------------------------------------

class TestCourseSearchCommand:
    @patch(_STATS_GET_CLIENT)
    def test_courses_search(self, mock_get, runner):
        client = _mock_client()
        client.courses.played.return_value = [
            {"courseId": 100, "name": "Torrey Pines South", "city": "San Diego",
             "state": "CA"},
            {"courseId": 101, "name": "Torrey Pines North", "city": "San Diego",
             "state": "CA"},
            {"courseId": 200, "name": "Augusta National", "city": "Augusta",
             "state": "GA"},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["courses", "--search", "torrey"])
        assert result.exit_code == 0
        assert "Torrey Pines South" in result.output
        assert "Torrey Pines North" in result.output
        assert "Augusta" not in result.output

    @patch(_STATS_GET_CLIENT)
    def test_courses_search_empty(self, mock_get, runner):
        client = _mock_client()
        client.courses.played.return_value = [
            {"courseId": 100, "name": "Augusta National"},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["courses", "--search", "xyznotfound"])
        assert result.exit_code == 0
        assert "No courses found" in result.output


# ---------------------------------------------------------------------------
# club-shots
# ---------------------------------------------------------------------------

class TestClubShotsCommand:
    @patch(_STATS_GET_CLIENT)
    def test_club_shots_table(self, mock_get, runner):
        client = _mock_client()
        client._http.get.return_value = {"bagId": "bag-1"}
        client.clubs.club_shots.return_value = [
            {"shotTime": "2025-06-01T12:00:00Z", "distance": 255.3,
             "userStartTerrainOverride": 0},
            {"shotTime": "2025-06-02T14:00:00Z", "distance": 248.1,
             "userStartTerrainOverride": 0},
        ]
        client.clubs.bag.return_value = {
            "clubs": [{"clubId": 1, "clubType": 1, "isDeleted": "F"}],
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["club-shots", "1"])
        assert result.exit_code == 0
        assert "255y" in result.output
        assert "248y" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_club_shots_json(self, mock_get, runner):
        client = _mock_client()
        client._http.get.return_value = {"bagId": "bag-1"}
        client.clubs.club_shots.return_value = [{"distance": 255.3}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["club-shots", "--json", "1"])
        data = json.loads(result.output)
        assert data[0]["distance"] == 255.3

    @patch(_STATS_GET_CLIENT)
    def test_club_shots_empty(self, mock_get, runner):
        client = _mock_client()
        client._http.get.return_value = {"bagId": "bag-1"}
        client.clubs.club_shots.return_value = []
        mock_get.return_value = client

        result = runner.invoke(cli, ["club-shots", "99"])
        assert result.exit_code == 0
        assert "No shots found" in result.output


# ---------------------------------------------------------------------------
# up-and-down
# ---------------------------------------------------------------------------

class TestUpAndDownCommand:
    @patch(_STATS_GET_CLIENT)
    def test_up_and_down_table(self, mock_get, runner):
        client = _mock_client()
        client.stats.strokes_to_get_down.return_value = {
            "totalAttempts": 50,
            "successRate": 0.42,
            "avgProximity": 15.3,
        }
        mock_get.return_value = client

        result = runner.invoke(cli, ["up-and-down"])
        assert result.exit_code == 0
        assert "50" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_up_and_down_json(self, mock_get, runner):
        client = _mock_client()
        client.stats.strokes_to_get_down.return_value = {"totalAttempts": 50}
        mock_get.return_value = client

        result = runner.invoke(cli, ["up-and-down", "--json"])
        data = json.loads(result.output)
        assert data["totalAttempts"] == 50


# ---------------------------------------------------------------------------
# compare
# ---------------------------------------------------------------------------

class TestCompareCommand:
    @patch(_ROUNDS_GET_CLIENT)
    def test_compare_table(self, mock_get, runner):
        client = _mock_client()
        client.rounds.get.side_effect = [
            {
                "roundId": 1, "courseId": 100, "noOfShots": 85, "noOfHoles": 18,
                "startTime": "2025-06-01T08:00:00Z",
                "holes": [
                    {"holeId": 1, "noOfShots": 5, "putts": 2},
                    {"holeId": 2, "noOfShots": 4, "putts": 2},
                    {"holeId": 3, "noOfShots": 3, "putts": 1},
                ],
            },
            {
                "roundId": 2, "courseId": 100, "noOfShots": 82, "noOfHoles": 18,
                "startTime": "2025-07-01T08:00:00Z",
                "holes": [
                    {"holeId": 1, "noOfShots": 4, "putts": 1},
                    {"holeId": 2, "noOfShots": 4, "putts": 2},
                    {"holeId": 3, "noOfShots": 4, "putts": 2},
                ],
            },
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["compare", "1", "2"])
        assert result.exit_code == 0
        assert "Round A" in result.output
        assert "Round B" in result.output
        assert "Comparison" in result.output

    @patch(_ROUNDS_GET_CLIENT)
    def test_compare_json(self, mock_get, runner):
        client = _mock_client()
        client.rounds.get.side_effect = [
            {"roundId": 1, "holes": []},
            {"roundId": 2, "holes": []},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["compare", "--json", "1", "2"])
        data = json.loads(result.output)
        assert "round_a" in data
        assert "round_b" in data


# ---------------------------------------------------------------------------
# trends
# ---------------------------------------------------------------------------

class TestTrendsCommand:
    @patch(_STATS_GET_CLIENT)
    def test_trends_chart(self, mock_get, runner):
        client = _mock_client()
        client.handicap.history.return_value = [
            {"roundId": 1, "userHcp": -15.0, "driveHcp": -10.0},
            {"roundId": 2, "userHcp": -16.0, "driveHcp": -11.0},
            {"roundId": 3, "userHcp": -14.5, "driveHcp": -9.5},
        ]
        mock_get.return_value = client

        result = runner.invoke(cli, ["trends"])
        assert result.exit_code == 0
        assert "Handicap Trend" in result.output
        assert "-15.0" in result.output
        assert "-16.0" in result.output

    @patch(_STATS_GET_CLIENT)
    def test_trends_json(self, mock_get, runner):
        client = _mock_client()
        client.handicap.history.return_value = [{"userHcp": -15.0}]
        mock_get.return_value = client

        result = runner.invoke(cli, ["trends", "--json"])
        data = json.loads(result.output)
        assert data[0]["userHcp"] == -15.0

    @patch(_STATS_GET_CLIENT)
    def test_trends_empty(self, mock_get, runner):
        client = _mock_client()
        client.handicap.history.return_value = []
        mock_get.return_value = client

        result = runner.invoke(cli, ["trends"])
        assert result.exit_code == 0
        assert "No handicap history" in result.output


# ---------------------------------------------------------------------------
# completions
# ---------------------------------------------------------------------------

class TestCompletionsCommand:
    def test_completions_bash(self, runner):
        result = runner.invoke(cli, ["completions", "bash"])
        assert result.exit_code == 0

    def test_completions_invalid(self, runner):
        result = runner.invoke(cli, ["completions", "powershell"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# rich help
# ---------------------------------------------------------------------------

class TestRichHelp:
    def test_help_renders(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "arccos" in result.output
