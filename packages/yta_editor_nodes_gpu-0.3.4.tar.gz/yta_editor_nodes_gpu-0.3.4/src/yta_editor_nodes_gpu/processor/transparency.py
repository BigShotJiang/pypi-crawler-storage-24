from yta_editor_nodes_gpu.processor.abstract import _NodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline
from typing import Union

import moderngl


class _TransparencyPipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to modify transparency of the
    textures we receive as input by transforming
    them into more or less transparent outputs.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            '''
            #version 330

            uniform sampler2D base_texture;
            uniform float transparency; // 1.0=full transparent, 0.0=full opaque

            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                vec4 color = texture(base_texture, v_uv);
                color.a *= (1.0 - transparency);
                output_color = color;
            }
            '''
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'base_texture': 0
        }
    
class TransparencyNodeProcessorGPU(_NodeProcessorGPU):
    """
    A node to modify the transparency of the textures we
    receive as input by transforming them into more or
    less transparent outputs.
    """

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None] = None
    ):
        # TODO: Validate context (?)
        super().__init__(
            opengl_pipeline = _TransparencyPipelineGPU(
                opengl_context = opengl_context
            )
        )

    def process(
        self,
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None] = None,
        transparency: float = 1.0,
        **kwargs
    ) -> moderngl.Texture:
        """
        Process the `inputs` provided and get an output
        of the given `output_size` by using the
        `**dynamic_uniforms` if needed.
        """
        return super().process(
            inputs = inputs,
            output_size = output_size,
            transparency = transparency
        )