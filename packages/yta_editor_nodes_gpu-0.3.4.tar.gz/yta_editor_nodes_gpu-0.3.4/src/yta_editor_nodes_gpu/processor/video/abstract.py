from yta_editor_nodes_gpu.processor.abstract import _NodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from typing import Union

import moderngl


class _VideoNodeProcessorGPU(_NodeProcessorGPU):
    """
    *Abstract class*

    *Singleton class*

    *For internal use only*

    Class to represent a node processor that uses GPU
    to transform the input but it is meant to video
    processing, so it implements a `t` parameter to
    manipulate the frames according to that time
    moment.

    This class must be implemented by any processor
    that uses GPU to modify an input.
    """

    def process(
        self,
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `inputs` provided and get an output of
        the given `output_size` and for the 
        `evaluation_context` provided, by using the
        `**dynamic_uniforms` if needed.
        """
        return super().process(
            inputs = inputs,
            output_size = output_size,
            t = float(evaluation_context.t),
            **dynamic_uniforms
        )
