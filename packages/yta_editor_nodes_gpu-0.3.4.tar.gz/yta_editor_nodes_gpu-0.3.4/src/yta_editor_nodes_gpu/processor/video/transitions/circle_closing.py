from yta_editor_nodes_gpu.processor.video.transitions.abstract import _TransitionNodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline
from typing import Union

import moderngl


class _CircleClosingTransitionPipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to transition between the frames
    of 2 videos in which the frames are mixed by
    generating a decreasing from the middle to end
    disappearing.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            """
            #version 330

            uniform sampler2D first_texture;
            uniform sampler2D second_texture;
            uniform float progress;  // 0.0 → full A, 1.0 → full B
            uniform float border_smoothness; // 0.02 is a good value

            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                // Obtain the size automatically from the texture
                vec2 output_size = vec2(textureSize(first_texture, 0));

                vec2 pos = v_uv * output_size;
                vec2 center = output_size * 0.5;

                // Distance from center
                float dist = distance(pos, center);

                // Radius of current circle
                float max_radius = length(center);
                float radius = (1.0 - progress) * max_radius;

                vec4 first_color = texture(first_texture, v_uv);
                vec4 second_color = texture(second_texture, v_uv);

                // With smooth circle
                // TODO: Make this customizable
                float mask = smoothstep(radius - border_smoothness * max_radius, radius + border_smoothness * max_radius, dist);
                output_color = mix(first_color, second_color, mask);
            }
            """
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'first_texture': 0,
            'second_texture': 1
        }
    
class CircleClosingTransitionNodeProcessorGPU(_TransitionNodeProcessorGPU):
    """
    A transition between the frames of 2 videos in
    which the frames are mixed by generating a
    decreasing from the middle to end disappearing.
    """

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None] = None
    ):
        # TODO: Validate context (?)
        super().__init__(
            opengl_pipeline = _CircleClosingTransitionPipelineGPU(
                opengl_context = opengl_context
            )
        )

    def process(
        self,
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None] = None,
        border_smoothness: float = 0.02,
        **kwargs
    ) -> moderngl.Texture:
        """
        Validate the parameters, set the textures map,
        process it and return the result according to the
        `evaluation_context` provided.

        We use and return textures to maintain the
        process in GPU and optimize it.
        """
        return super().process(
            inputs = inputs,
            evaluation_context = evaluation_context,
            output_size = output_size,
            border_smoothness = border_smoothness
        )