from yta_editor_nodes_gpu.processor.video.transitions.abstract import _TransitionNodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline
from typing import Union

import moderngl


class _AlphaPediaMaskRevealPipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to transition between the frames
    of a video and a custom video mask. This mask is
    specifically obtained from the AlphaPediaYT channel
    in which we upload specific masking videos.

    The video will be placed ocuppying the whole scene
    and then be revealed by using the transition video
    mask.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            """
            #version 330

            uniform sampler2D base_texture;
            uniform sampler2D mask_texture;

            uniform float progress;           // 0.0 → invisible, 1.0 → fully revealed
            uniform bool use_alpha_channel;

            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                vec4 video_color = texture(base_texture, v_uv);
                vec4 mask_color  = texture(mask_texture, v_uv);

                // Mask alpha or red?
                float mask_value = use_alpha_channel ? mask_color.a : mask_color.r;

                // Clamp safety
                mask_value = clamp(mask_value, 0.0, 1.0);

                // Reveal function
                float t = smoothstep(
                    0.0,
                    1.0,
                    mask_value + progress - 0.5
                );

                // OUTPUT:
                // - RGB intact
                // - Alpha controlled by mask+progress
                output_color = vec4(
                    video_color.rgb,
                    video_color.a * t
                );
            }
            """
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'base_texture': 0,
            'mask_texture': 1
        }
    
class AlphaPediaMaskRevealVideoNodeProcessorGPU(_TransitionNodeProcessorGPU):
    """
    A node to transition between the frames of a video,
    using a custom video mask to reveal it progressively.
    
    This mask is specifically obtained from the
    AlphaPediaYT channel in which we upload specific
    masking videos.
    """

    mandatory_inputs = ['base_input', 'mask_input']

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None] = None
    ):
        # TODO: Validate context (?)
        super().__init__(
            opengl_pipeline = _AlphaPediaMaskRevealPipelineGPU(
                opengl_context = opengl_context
            )
        )

    def process(
        self,
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None] = None,
        **kwargs
    ) -> moderngl.Texture:
        """
        Mix the `first_input` with the `second_input`
        based on the `evaluation_context` given and
        using the `mask_input` provided.

        We use and return textures to maintain the
        process in GPU and optimize it.
        """
        # TODO: There is a 'use_alpha_channel' uniform to use
        # the alpha instead of the red color of the frame value,
        # but the red is working for our AlphaPedia videos, so...

        return super().process(
            inputs = inputs,
            evaluation_context = evaluation_context,
            output_size = output_size
        )