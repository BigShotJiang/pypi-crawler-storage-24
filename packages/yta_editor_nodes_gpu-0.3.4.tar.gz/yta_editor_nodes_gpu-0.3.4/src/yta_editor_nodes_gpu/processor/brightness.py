from yta_editor_nodes_gpu.processor.abstract import _NodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline
from typing import Union

import moderngl


class _BrightnessPipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to modify the brightness of the
    textures we receive as input by multiplying the
    color by a factor.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            '''
            #version 330

            uniform sampler2D base_texture;
            uniform float factor; // 1.0 = no change, >1.0 lighter, <1.0 darker
            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                vec4 color = texture(base_texture, v_uv);
                color.rgb *= factor;
                output_color = color;
            }
            '''
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'base_texture': 0
        }
    
class BrightnessNodeProcessorGPU(_NodeProcessorGPU):
    """
    A node to modify the brightness of the textures
    we receive as input by multiplying the color by a
    factor.
    """

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None] = None
    ):
        # TODO: Validate context (?)
        super().__init__(
            opengl_pipeline = _BrightnessPipelineGPU(
                opengl_context = opengl_context
            )
        )

    def process(
        self,
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None] = None,
        factor: float = 1.5,
        **kwargs
    ) -> moderngl.Texture:
        """
        Process the `inputs` provided and get an output
        of the given `output_size` by using the `factor`
        given.
        """
        return super().process(
            inputs = inputs,
            output_size = output_size,
            factor = factor
        )