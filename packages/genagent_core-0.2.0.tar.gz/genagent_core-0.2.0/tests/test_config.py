"""
Tests for AgentConfig and GenAgent initialization.
"""
import pytest
from genagent_core import AgentConfig, GenAgent


class TestAgentConfig:
    def test_default_config(self):
        config = AgentConfig()
        assert config.llm.default_provider == "openai"
        assert config.sandbox.enabled is False
        assert config.memory.enabled is False
        assert config.storage_dir == "./.genagent"

    def test_custom_llm_config(self):
        config = AgentConfig(
            llm={
                "default_provider": "anthropic",
                "providers": {
                    "anthropic": {"api_keys": ["sk-ant-test"]}
                }
            }
        )
        assert config.llm.default_provider == "anthropic"
        assert "anthropic" in config.llm.providers

    def test_sandbox_config(self):
        config = AgentConfig(
            sandbox={
                "enabled": True,
                "provider": "e2b",
                "api_key": "e2b_test_key",
            }
        )
        assert config.sandbox.enabled is True
        assert config.sandbox.provider == "e2b"
        assert config.sandbox.api_key == "e2b_test_key"

    def test_model_routing_config(self):
        config = AgentConfig(
            model_routing={
                "default": "openai:gpt-4o",
                "by_role": {
                    "planner": "openai:gpt-4o",
                    "executor": "openai:gpt-4o-mini",
                }
            }
        )
        assert config.model_routing.default == "openai:gpt-4o"
        assert config.model_routing.by_role["planner"] == "openai:gpt-4o"

    def test_storage_dir_config(self):
        config = AgentConfig(storage_dir="/tmp/my_agent_data")
        assert config.storage_dir == "/tmp/my_agent_data"


class TestGenAgentInit:
    def test_init_without_sandbox(self):
        config = AgentConfig(
            llm={
                "default_provider": "openai",
                "providers": {"openai": {"api_keys": ["sk-test"]}}
            }
        )
        agent = GenAgent(config)
        assert agent.sandbox_provider is None

    def test_init_creates_storage(self, tmp_path):
        config = AgentConfig(storage_dir=str(tmp_path / "agent_data"))
        agent = GenAgent(config)
        assert agent.storage is not None

    def test_init_creates_event_bus(self, tmp_path):
        config = AgentConfig(storage_dir=str(tmp_path / "agent_data"))
        agent = GenAgent(config)
        assert agent.event_bus is not None
