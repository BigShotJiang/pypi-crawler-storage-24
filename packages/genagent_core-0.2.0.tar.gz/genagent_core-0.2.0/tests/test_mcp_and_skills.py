"""Tests for MCP client and Skills loader."""
import asyncio
import os
import shutil
import tempfile
from contextlib import AsyncExitStack
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from genagent_core.config import AgentConfig, MCPServerConfig, SkillsConfig
from genagent_core.skills.loader import SkillsLoader


# ─────────────────────────────────────────────────────────────────────────────
# Skills tests
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture
def skills_dir(tmp_path):
    """Create a temporary skills directory with two test skills."""
    # Skill 1: always=false, no requirements
    skill1 = tmp_path / "my-skill"
    skill1.mkdir()
    (skill1 / "SKILL.md").write_text(
        "---\nname: my-skill\ndescription: A test skill.\n---\n# My Skill\nDo stuff."
    )
    # Skill 2: always=true
    skill2 = tmp_path / "always-skill"
    skill2.mkdir()
    (skill2 / "SKILL.md").write_text(
        '---\nname: always-skill\ndescription: Always injected.\nmetadata: {"always": true}\n---\n# Always Skill\nAlways here.'
    )
    # Skill 3: missing bin requirement
    skill3 = tmp_path / "needs-bin"
    skill3.mkdir()
    (skill3 / "SKILL.md").write_text(
        '---\nname: needs-bin\ndescription: Needs a binary.\nmetadata: {"requires": {"bins": ["__nonexistent_binary__"]}}\n---\n# Needs Bin'
    )
    return tmp_path


def test_list_skills_filters_unavailable(skills_dir):
    loader = SkillsLoader(skills_dirs=[str(skills_dir)])
    available = loader.list_skills(filter_unavailable=True)
    names = [s["name"] for s in available]
    assert "my-skill" in names
    assert "always-skill" in names
    assert "needs-bin" not in names


def test_list_skills_all(skills_dir):
    loader = SkillsLoader(skills_dirs=[str(skills_dir)])
    all_skills = loader.list_skills(filter_unavailable=False)
    names = [s["name"] for s in all_skills]
    assert "needs-bin" in names


def test_load_skill(skills_dir):
    loader = SkillsLoader(skills_dirs=[str(skills_dir)])
    content = loader.load_skill("my-skill")
    assert content is not None
    assert "My Skill" in content


def test_load_skill_not_found(skills_dir):
    loader = SkillsLoader(skills_dirs=[str(skills_dir)])
    assert loader.load_skill("nonexistent") is None


def test_build_system_prompt_section_contains_index(skills_dir):
    loader = SkillsLoader(skills_dirs=[str(skills_dir)])
    section = loader.build_system_prompt_section()
    assert "<skills>" in section
    assert "my-skill" in section
    assert "always-skill" in section


def test_build_system_prompt_section_injects_always_skill(skills_dir):
    loader = SkillsLoader(skills_dirs=[str(skills_dir)])
    section = loader.build_system_prompt_section()
    # always-skill content should be fully embedded
    assert "Always here." in section


def test_always_load_config_overrides(skills_dir):
    loader = SkillsLoader(
        skills_dirs=[str(skills_dir)],
        always_load=["my-skill"],
    )
    section = loader.build_system_prompt_section()
    # my-skill content should be fully embedded because of always_load
    assert "Do stuff." in section


def test_unavailable_skill_marked_in_index(skills_dir):
    loader = SkillsLoader(skills_dirs=[str(skills_dir)])
    section = loader.build_system_prompt_section()
    assert 'available="false"' in section


def test_skills_config_in_agent_config():
    cfg = AgentConfig(
        skills=SkillsConfig(
            enabled=True,
            skills_dirs=["./skills"],
            always_load=["coding-style"],
        )
    )
    assert cfg.skills.enabled is True
    assert cfg.skills.always_load == ["coding-style"]


def test_skills_disabled_by_default_creates_no_loader():
    """When skills.enabled=False, GenAgent should not create a SkillsLoader."""
    cfg = AgentConfig(skills=SkillsConfig(enabled=False))
    # Simulate what GenAgent.__init__ does
    loader = None
    if cfg.skills.enabled:
        loader = SkillsLoader(skills_dirs=cfg.skills.skills_dirs)
    assert loader is None


# ─────────────────────────────────────────────────────────────────────────────
# MCP config tests
# ─────────────────────────────────────────────────────────────────────────────

def test_mcp_server_config_defaults():
    cfg = MCPServerConfig(command="npx", args=["-y", "some-server"])
    assert cfg.tool_timeout == 30
    assert cfg.enabled_tools == ["*"]
    assert cfg.type is None  # auto-detect


def test_mcp_server_config_http():
    cfg = MCPServerConfig(
        url="https://example.com/mcp",
        headers={"Authorization": "Bearer sk-test"},
        enabled_tools=["search", "fetch"],
    )
    assert cfg.url == "https://example.com/mcp"
    assert cfg.headers["Authorization"] == "Bearer sk-test"
    assert "search" in cfg.enabled_tools


def test_agent_config_mcp_servers():
    cfg = AgentConfig(
        mcp_servers={
            "filesystem": MCPServerConfig(
                command="npx",
                args=["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
            )
        }
    )
    assert "filesystem" in cfg.mcp_servers
    assert cfg.mcp_servers["filesystem"].command == "npx"


# ─────────────────────────────────────────────────────────────────────────────
# MCP schema normalization tests
# ─────────────────────────────────────────────────────────────────────────────

def test_normalize_schema_nullable_list():
    from genagent_core.mcp.client import _normalize_schema_for_openai
    schema = {"type": ["string", "null"], "description": "A nullable string"}
    result = _normalize_schema_for_openai(schema)
    assert result["type"] == "string"
    assert result.get("nullable") is True


def test_normalize_schema_anyof_nullable():
    from genagent_core.mcp.client import _normalize_schema_for_openai
    schema = {
        "anyOf": [{"type": "null"}, {"type": "integer"}],
        "description": "nullable int",
    }
    result = _normalize_schema_for_openai(schema)
    assert result["type"] == "integer"
    assert result.get("nullable") is True


def test_normalize_schema_plain_object():
    from genagent_core.mcp.client import _normalize_schema_for_openai
    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "required": ["name"],
    }
    result = _normalize_schema_for_openai(schema)
    assert result["type"] == "object"
    assert "name" in result["properties"]
