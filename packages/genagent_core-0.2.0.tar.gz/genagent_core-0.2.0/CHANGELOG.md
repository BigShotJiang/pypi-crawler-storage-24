# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-03-22

### Added
- **Modular Prompt System**: New `PromptLoader` class (`prompts/prompt_loader.py`) that assembles the system prompt from four independent Markdown files — `SOUL.md`, `AGENTS.md`, `TOOLS.md`, and `USER.md`. Prompts can now be overridden per-deployment without touching Python code.
- **Prompt Files**: Added `AGENTS.md`, `SOUL.md`, `TOOLS.md`, and `USER.md` to `src/genagent_core/prompts/` as the canonical prompt source of truth.
- **Enhanced `SkillLoader`**: Fully rewritten `skills/loader.py` with `SkillFrontmatter` dataclass, `strategy` field (`always` / `on_demand`), `requires` field for dependency checking, and `build_prompt_blocks()` for structured injection. Full backward compatibility with old `SkillsLoader` alias.
- **`mcp` optional dependency group**: `pip install genagent-core[mcp]` now installs `mcp` and `httpx` for MCP server integration.
- **`dev` optional dependency group**: `pip install genagent-core[dev]` installs all development and testing tools.
- **PyPI classifiers and project URLs**: Package is now properly classified for PyPI discovery.
- **GitHub Actions CI/CD**: Added `.github/workflows/ci.yml` (test on push) and `.github/workflows/publish.yml` (auto-publish to PyPI on version tag).

### Changed
- Bumped version to `0.2.0`.
- `AgentFactory._build_fresh_context()` now uses `PromptLoader` to build the system prompt, replacing the previous hardcoded string concatenation.
- `SkillLoader` now supports both new-style (`strategy: always`) and legacy-style (`metadata: {"always": true}`) frontmatter.
- `_step_trim_cb` closure in `agent_factory.py` refactored to avoid function redefinition warning.

### Fixed
- Removed unused imports across 8 files (`agent.py`, `system_tools.py`, `mcp/client.py`, `orchestrator.py`, `event_bus.py`, `command_queue.py`, `search_service.py`, `agent_factory.py`).
- Fixed `AgentConfig` undefined name in `orchestrator.py:from_config`.
- Fixed missing `json` import in `event_bus.py`.
- Fixed `ArtifactRef` unused import in `event_bus.py:rebuild_workspace_state`.

## [0.1.0] - 2026-03-01

### Added
- Initial release of `genagent-core`.
- Two-tier architecture: Planner Agent + Executor Sub-agents.
- `GenAgent` high-level API with `async with` context manager support.
- `AgentConfig` with `LLMConfig`, `ModelRoutingConfig`, `SandboxConfig`, `MemoryConfig`, `ContextConfig`, `SkillsConfig`, `MCPServerConfig`.
- Built-in tools: filesystem (`fs_read`, `fs_write`, `fs_edit`, `fs_list`), system tools (`spawn_subagent`, `spawn_parallel`, `submit_plan`, `submit_results`), workflow tools (web search, browser automation).
- MCP integration via `stdio`, `sse`, and `streamableHttp` transports.
- Skills system with `SKILL.md` frontmatter and two-tier injection strategy.
- Two-phase context compression (Compact → Summarize).
- `EventBus` with typed `EventKind` enum and `subscribe` / `subscribe_all` API.
- `CommandQueue` with per-workspace serialization and graceful drain on shutdown.
