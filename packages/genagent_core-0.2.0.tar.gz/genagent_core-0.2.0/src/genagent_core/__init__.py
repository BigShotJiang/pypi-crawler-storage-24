"""
GenAgent Core: A generic autonomous AI agent framework.
"""

__version__ = "0.2.0"

from .config import AgentConfig
from .api_wrapper import GenAgent
from .orchestration.orchestrator import Orchestrator
from .agent.manus_agent import ManusAgent as PlannerAgent
from .agent.manus_agent import ManusAgent as ExecutorAgent

__all__ = [
    "AgentConfig",
    "GenAgent",
    "Orchestrator",
    "PlannerAgent",
    "ExecutorAgent",
]
