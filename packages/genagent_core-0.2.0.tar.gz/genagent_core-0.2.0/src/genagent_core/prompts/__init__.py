"""Modular prompt system for GenAgent-Core.

Exports the PromptLoader class and UserProfile dataclass for assembling
role-specific system prompts from modular Markdown files.
"""
from genagent_core.prompts.prompt_loader import (
    PromptLoader,
    UserProfile,
    get_default_loader,
)

__all__ = [
    "PromptLoader",
    "UserProfile",
    "get_default_loader",
]
