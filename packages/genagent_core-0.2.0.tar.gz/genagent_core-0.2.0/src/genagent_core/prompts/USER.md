# User Profile

<!--
  MULTI-TENANT EXTENSION GUIDE
  ============================
  This file is the per-user / per-tenant customisation point.

  How to extend for multi-tenancy
  --------------------------------
  1. Per-tenant static override
     Place a tenant-specific file at:
         src/prompts/tenants/{tenant_id}/USER.md
     The PromptLoader checks this path first and falls back to this default.

  2. Programmatic override (from database)
     Pass a UserProfile dataclass to PromptLoader.build():
         loader.build(role=..., user_profile=UserProfile(
             name="Alice",
             language="zh-CN",
             timezone="Asia/Shanghai",
             custom_instructions="Always respond in bullet points.",
         ))
     Fields in UserProfile are appended to (or override) this file's content.

  3. Fields to add when scaling to SaaS
     - subscription_tier  : controls which skills / tools are available
     - custom_instructions: free-form user-supplied instructions (like ChatGPT's "Custom Instructions")
     - tool_restrictions  : disallow certain tools per user (e.g. no sandbox for free tier)
     - data_residency     : e.g. "EU" for GDPR-scoped storage routing

  Keep this file's static content minimal — it is the fallback for users
  who have not customised their profile.
-->

<user_profile>
- **Language**: Chinese (Simplified) — respond in zh-CN unless the task explicitly specifies otherwise
- **Timezone**: Asia/Shanghai (UTC+8)
</user_profile>

<output_rules>
- Default working language: Chinese (simplified)
- Use the language specified in the task instruction when explicitly provided
- Write content in continuous paragraphs with varied sentence lengths for engaging prose
- Avoid pure list and bullet point format unless the task explicitly requires it
- Be concise by default; do not expand into long reports unless explicitly requested
- All data claims must be backed by artifacts or search results; never fabricate data
</output_rules>
