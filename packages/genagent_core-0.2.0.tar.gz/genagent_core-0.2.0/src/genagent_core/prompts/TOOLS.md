# Tool Usage Guidelines

<!--
  This file documents tool-specific rules, gotchas, and best practices.
  Keep it factual and concise — it is injected into every agent's context.

  To add tenant-specific tool overrides, place a file at:
      src/prompts/tenants/{tenant_id}/TOOLS.md
-->

<sandbox_rules>
- Each workspace session has its own reusable sandbox environment (Linux VM)
- Use `sandbox_exec` to run shell commands (python, pip, node, git, curl, etc.)
- Use `sandbox_write_file` / `fs_write` to create files in the sandbox
- Use `sandbox_read_file` / `fs_read` to read file contents from the sandbox
- Use `sandbox_browse` to fetch URLs from within the sandbox (returns raw HTML/text)
- The sandbox is reused across tasks in the same session and is destroyed only after an idle timeout
- Important results from sandbox should be saved as artifacts via `file_write`
</sandbox_rules>

<filesystem_rules>
- Prefer `fs_read` over `sandbox_read_file` for new code — it supports pagination (offset/limit) and image-aware reading
- Use `fs_edit` for targeted string replacements; it provides fuzzy-match fallback and diff diagnostics on failure
- Use `fs_list` to explore directory trees; it filters out noise dirs (.git, node_modules, __pycache__) automatically
- For large files, always use `fs_read` with `offset` + `limit` to avoid context overflow
</filesystem_rules>

<python_exec_rules>
- `python_exec` provides a stateful Jupyter-style kernel; variables persist across calls within the same phase
- Use `python_exec` for: data processing (pandas/numpy), visualisation (matplotlib/seaborn), multi-step calculations
- Use `sandbox_exec` for: installing packages, git operations, running external programs, curl downloads
- Do NOT re-import or reload data in every `python_exec` call — the kernel retains state
- If kernel state is uncertain, use `sandbox_exec` to restart the kernel before re-running
</python_exec_rules>

<browser_rules>
- Use browser tools (`browser_navigate`, `browser_click`, `browser_type`) for interactive web sessions
- Use `web_search` + `browser_navigate` for research; avoid scraping search-engine result pages directly
- Search result snippets are not valid sources — always follow through to the original page
- For bulk URL fetching, prefer `sandbox_browse` (faster, no JS rendering) over the interactive browser
</browser_rules>

<artifact_rules>
- Save intermediate outputs as artifacts (`file_write`) rather than keeping large content in context
- Reference artifacts by `artifact_id` when passing data between Planner phases
- Artifacts persist for the lifetime of the workspace session
</artifact_rules>

<memory_rules>
- Use `memory_query` to retrieve semantically similar historical task results before starting a research-heavy task
- Write a compact memory entry after completing a significant task so future tasks can reuse the findings
- Memory is workspace-scoped — it is shared across all tasks in the same workspace
</memory_rules>
