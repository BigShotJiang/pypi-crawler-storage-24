"""Modular system prompt loader for GenAgent-Core.

This module assembles the agent system prompt from a set of Markdown
"modules" (AGENTS, USER, SOUL, TOOLS) plus the Skills system and
long-term workspace memory.

Directory layout
----------------
::

    prompts/
    ├── AGENTS.md   — Agent behaviour contract (role, loop, tool rules).
    │                 Always included.
    ├── USER.md     — User profile and output rules.
    │                 Planner only.
    ├── SOUL.md     — Agent personality, values, and communication style.
    │                 Planner only.
    ├── TOOLS.md    — Tool-usage guidelines: when to use which tool, gotchas,
    │                 sandbox rules, browser rules, etc.
    └── tenants/
        └── {tenant_id}/
            ├── AGENTS.md  (optional override)
            └── ...

Skills
------
Skills are loaded via :class:`genagent_core.skills.loader.SkillLoader`.
Each skill is a directory under ``skills/`` containing:
::

    {skill_name}/
    ├── SKILL.md          frontmatter + instructions (injected into prompt)
    ├── scripts/          executable scripts (copied to sandbox at agent creation)
    ├── references/       docs loaded on demand by the agent via fs_read
    └── templates/        output assets (not injected)

Three-level progressive disclosure:

1. Metadata (description from frontmatter) — always in context via metadata_summary()
2. SKILL.md body — injected when skill is activated (always / on_demand triggers)
3. scripts/ & references/ — available in sandbox / readable on demand

Memory
------
Long-term workspace memory is injected as a dedicated section after the core
modules.  The caller supplies the recalled text; this module formats it.

Multi-tenant extension
----------------------
To support multiple tenants / users:

1. Store per-tenant MODULE.md files under:
       prompts/tenants/{tenant_id}/{MODULE}.md
   The loader checks this path first, falling back to the default.
2. Pass a UserProfile dataclass to PromptLoader.build() to override any
   USER.md field programmatically (e.g. from a database row).
3. Skills can be tenant-scoped by placing them under:
       skills/tenants/{tenant_id}/{skill_name}/

Example
-------
::

    loader = PromptLoader(prompts_dir=Path("src/genagent_core/prompts"))
    system_prompt = loader.build(
        role="planner",
        task_instruction="分析竞品定价",
        historical_memory="...",
        user_profile=UserProfile(name="Alice", language="zh-CN"),
        tenant_id="acme",
    )
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# UserProfile
# ---------------------------------------------------------------------------

@dataclass
class UserProfile:
    """Per-user / per-tenant overrides for USER.md content.

    All fields are optional.  Fields set here take precedence over the
    static USER.md file content.

    Multi-tenant usage
    ------------------
    Populate this from your user/tenant database and pass it to
    ``PromptLoader.build()``.  The loader merges these values into the
    rendered USER section.

    Future fields to add when scaling to multi-tenant SaaS
    -------------------------------------------------------
    - ``subscription_tier: str``   — controls which skills are available
    - ``custom_instructions: str`` — free-form user-supplied instructions
    - ``tool_restrictions: list[str]`` — disallow certain tools per user
    - ``data_residency: str``      — e.g. "EU" for GDPR-scoped deployments
    """

    name: str = ""
    language: str = ""           # e.g. "zh-CN", "en-US"
    timezone: str = ""           # e.g. "Asia/Shanghai"
    custom_instructions: str = ""  # free-form user-supplied instructions


# ---------------------------------------------------------------------------
# PromptLoader
# ---------------------------------------------------------------------------

class PromptLoader:
    """Assemble the system prompt from modular Markdown files + skills.

    Parameters
    ----------
    prompts_dir:
        Root directory that contains AGENTS.md, USER.md, SOUL.md, TOOLS.md,
        and a ``tenants/`` subdirectory for per-tenant overrides.
    skills_dirs:
        Optional list of directories to search for skill packages.
        If not provided, defaults to the built-in skills directory.
    tenant_id:
        Optional default tenant identifier.  Can be overridden per-call in
        ``build()``.
    """

    _MODULE_ORDER = ["AGENTS", "USER", "SOUL", "TOOLS"]

    # Modules that are loaded for each role.
    # Executor (subagent) runs in an isolated context and only needs the
    # behaviour contract (AGENTS) and tool guidelines (TOOLS).  It does NOT
    # receive USER / SOUL / identity / heartbeat modules — those are reserved
    # for the Planner (the user-facing agent).
    _ROLE_MODULES: dict[str, list[str]] = {
        "planner": ["AGENTS", "USER", "SOUL", "TOOLS"],
        "executor": ["AGENTS", "TOOLS"],
    }

    def __init__(
        self,
        prompts_dir: "Path | str",
        skills_dirs: "list[str] | None" = None,
        tenant_id: str = "",
    ) -> None:
        self._root = Path(prompts_dir)
        self._tenant_id = tenant_id
        self._cache: dict[str, str] = {}

        # Lazy-import SkillLoader to avoid circular imports at module load time
        from genagent_core.skills.loader import SkillLoader

        # Default skills directory: built-in skills in the package
        default_skills_dir = Path(__file__).parent.parent / "skills" / "builtin"
        effective_skills_dirs: list[str] = skills_dirs or []
        if not effective_skills_dirs:
            effective_skills_dirs = [str(default_skills_dir)]

        self._skill_loader = SkillLoader(
            skills_dirs=effective_skills_dirs,
            tenant_id=tenant_id,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build(
        self,
        role: str,
        task_instruction: str = "",
        historical_memory: str = "",
        user_profile: "UserProfile | None" = None,
        tenant_id: str = "",
    ) -> str:
        """Assemble and return the full system prompt string.

        Parameters
        ----------
        role:
            Agent role (``"planner"`` or ``"executor"``).  Used to filter
            role-scoped modules and skills.
        task_instruction:
            The task text given to the agent.  Used for ``on_demand`` skill
            trigger matching.
        historical_memory:
            Recalled workspace memory text.  Injected as a dedicated section
            after the core modules.
        user_profile:
            Optional per-user overrides.  If provided, the USER section is
            augmented with these values.
        tenant_id:
            Optional tenant identifier.  When set, the loader first looks for
            tenant-scoped overrides under
            ``prompts/tenants/{tenant_id}/{MODULE}.md``.
        """
        effective_tenant = tenant_id or self._tenant_id
        sections: list[str] = []

        # 1. Core modules — filtered by role.
        # Planner: AGENTS → USER → SOUL → TOOLS
        # Executor: AGENTS → TOOLS  (no USER / SOUL — isolated subagent context)
        role_modules = self._ROLE_MODULES.get(role, self._ROLE_MODULES["executor"])
        for module in role_modules:
            content = self._load_module(module, tenant_id=effective_tenant)
            if not content:
                continue
            if module == "USER" and user_profile:
                content = self._merge_user_profile(content, user_profile)
            sections.append(content)

        # 2. Skills — Level 1: metadata summary (always in context)
        #             Level 2a: ``always`` skills pre-injected here
        #             Level 2b: ``on_demand`` skills returned by skill_load tool at runtime
        # Level 3 (scripts/references) is handled by agent_factory at sandbox setup.
        meta = self._skill_loader.metadata_summary()
        if meta.strip():
            sections.append(meta)

        # Only pre-inject ``always`` skills; ``on_demand`` body is fetched
        # by the agent at runtime via the ``skill_load`` tool.
        always_blocks = self._skill_loader.build_prompt_blocks(role=role)
        if always_blocks.strip():
            sections.append(always_blocks)

        # 3. Long-term memory (injected last so it's closest to the task)
        if historical_memory and historical_memory.strip():
            sections.append(self._format_memory(historical_memory))

        return "\n\n".join(s.strip() for s in sections if s.strip())

    def get_sandbox_scripts(
        self,
        role: str = "executor",
    ) -> "list[tuple[str, str | bytes]]":
        """Return ``[(sandbox_path, content), ...]`` for all skill scripts.

        All skills' scripts are copied to the sandbox at agent creation time
        regardless of strategy, so they are ready when the agent calls
        ``skill_load`` and decides to run them.  This is Level-3 disclosure.
        """
        return self._skill_loader.get_sandbox_scripts(role=role)

    def reload(self) -> None:
        """Clear all caches, forcing a fresh read on the next build().

        Useful in development when prompt files or SKILL.md files are edited
        without restarting the process.
        """
        self._cache.clear()
        self._skill_loader.reload()

    # ------------------------------------------------------------------
    # Module loading
    # ------------------------------------------------------------------

    def _load_module(self, name: str, *, tenant_id: str = "") -> str:
        """Load a core module (AGENTS / USER / SOUL / TOOLS).

        Lookup order:
        1. ``prompts/tenants/{tenant_id}/{name}.md``  (tenant override)
        2. ``prompts/{name}.md``                       (default)
        """
        candidates: list[Path] = []
        if tenant_id:
            candidates.append(self._root / "tenants" / tenant_id / f"{name}.md")
        candidates.append(self._root / f"{name}.md")

        for path in candidates:
            if path.exists():
                return self._read_cached(path)

        logger.debug("prompt module %s not found (tenant=%r), skipping", name, tenant_id)
        return ""

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _read_cached(self, path: Path) -> str:
        key = str(path)
        if key not in self._cache:
            try:
                self._cache[key] = path.read_text(encoding="utf-8")
            except OSError as exc:
                logger.error("Failed to read prompt file %s: %s", path, exc)
                self._cache[key] = ""
        return self._cache[key]

    @staticmethod
    def _merge_user_profile(base_content: str, profile: "UserProfile") -> str:
        """Append non-empty UserProfile fields to the USER section."""
        extras: list[str] = []
        if profile.name:
            extras.append(f"- **Name**: {profile.name}")
        if profile.language:
            extras.append(f"- **Language**: {profile.language}")
        if profile.timezone:
            extras.append(f"- **Timezone**: {profile.timezone}")
        if profile.custom_instructions:
            extras.append(
                f"\n**Custom Instructions**:\n{profile.custom_instructions}"
            )
        if not extras:
            return base_content
        return base_content.rstrip() + "\n\n" + "\n".join(extras)

    @staticmethod
    def _format_memory(memory_text: str) -> str:
        """Wrap recalled memory in a labelled section."""
        clipped = memory_text.strip()
        # Hard cap: keep memory compact to avoid bloating the prompt.
        if len(clipped) > 6000:
            clipped = clipped[-6000:]
        return (
            "<workspace_memory>\n"
            "以下是该工作区历史任务沉淀，可用于复用结论、术语、来源与结构。\n\n"
            f"{clipped}\n"
            "</workspace_memory>"
        )


# ---------------------------------------------------------------------------
# Module-level singleton (convenience accessor)
# ---------------------------------------------------------------------------

_DEFAULT_PROMPTS_DIR = Path(__file__).parent

# Lazily initialised; call get_default_loader() to access.
_default_loader: "PromptLoader | None" = None


def get_default_loader() -> PromptLoader:
    """Return (or create) the module-level default :class:`PromptLoader`.

    The loader is initialised with ``genagent_core/prompts/`` as the root
    directory and the built-in skills directory.
    """
    global _default_loader
    if _default_loader is None:
        _default_loader = PromptLoader(prompts_dir=_DEFAULT_PROMPTS_DIR)
    return _default_loader
