"""Skill Loader — Manus-style modular skill system for GenAgent-Core.

A skill is a self-contained capability package stored as a directory::

    skills/
    └── {skill_name}/
        ├── SKILL.md          (required) frontmatter + instructions
        ├── scripts/          (optional) executable Python/Bash scripts
        ├── references/       (optional) domain docs loaded on demand
        └── templates/        (optional) output assets, not injected

Three-level progressive disclosure
-----------------------------------
1. **Metadata** (~100 words, always in context)
   The YAML frontmatter ``description`` field.  Always injected into the
   system prompt via ``metadata_summary()``.  The agent reads this and
   decides whether to call ``skill_load`` to get the full instructions.

2. **SKILL.md body** (loaded on demand by the agent)
   The full instruction body.  Kept under 500 lines.
   Returned by the ``skill_load`` tool when the agent explicitly requests it.
   NOT pre-injected into the system prompt (except for ``always`` skills).

3. **Bundled resources** (loaded on demand during execution)
   ``scripts/`` and ``references/`` files are NOT injected automatically.
   The agent reads them via ``fs_read`` when the SKILL.md body instructs it.
   ``scripts/`` files are copied into the sandbox at agent creation time so
   the executor can run them with ``sandbox_exec`` / ``python_exec``.

Activation strategies
---------------------
- ``always``   — SKILL.md body is pre-injected into the system prompt on
                 every agent creation (for universal rules / style guides).
- ``on_demand``— Only the description is in context.  The agent calls
                 ``skill_load(skill_name)`` when it judges the skill relevant.
                 No keyword matching in Python code.  LLM decides.

Directory layout
----------------
Skills live under a configurable root (default: ``skills/builtin/``).
Tenant-scoped overrides can be placed under:
    ``skills/tenants/{tenant_id}/{skill_name}/``
The loader checks the tenant path first and falls back to the default.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

try:
    import yaml
    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False

logger = logging.getLogger(__name__)

SkillStrategy = Literal["always", "on_demand"]

# Maximum SKILL.md body length (chars) before a warning is emitted.
# ~5 000 tokens
_MAX_SKILL_BODY_CHARS = 20_000

# Built-in skills shipped with the package
BUILTIN_SKILLS_DIR = Path(__file__).parent / "builtin"


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class SkillFrontmatter:
    """Parsed YAML frontmatter from a SKILL.md file.

    Attributes
    ----------
    name:
        Unique skill identifier (used as directory name).
    description:
        Primary trigger text.  Must describe *what* the skill does AND
        *when* to use it.  This is the only field always in context.
    strategy:
        Activation strategy:
        - ``"always"``    — body pre-injected into system prompt every time.
        - ``"on_demand"`` — only description in context; agent calls
          ``skill_load`` to retrieve full body when relevant.
    roles:
        If non-empty, skill is only activated for the listed agent roles.
        Empty list means "all roles".
    scripts_sandbox_path:
        Destination directory inside the sandbox where ``scripts/`` files
        are copied.  Defaults to ``/workspace/skills/{name}/scripts``.
    """

    name: str
    description: str
    strategy: SkillStrategy = "on_demand"
    roles: list[str] = field(default_factory=list)
    scripts_sandbox_path: str = ""
    requires: list[str] = field(default_factory=list)
    """Optional list of binary names that must be present in PATH for this skill to be available."""

    def __post_init__(self) -> None:
        if not self.scripts_sandbox_path:
            self.scripts_sandbox_path = f"/workspace/skills/{self.name}/scripts"


@dataclass
class LoadedSkill:
    """A fully resolved skill ready for injection.

    Attributes
    ----------
    frontmatter:
        Parsed metadata from the SKILL.md frontmatter.
    body:
        The Markdown body of SKILL.md (everything after the frontmatter).
    scripts:
        Mapping of ``{relative_path: content}`` for all files under
        ``scripts/``.  These are copied to the sandbox at agent creation.
    references_dir:
        Absolute path to the ``references/`` directory (if it exists).
        The agent reads individual files from here on demand via ``fs_read``.
    templates_dir:
        Absolute path to the ``templates/`` directory (if it exists).
    """

    frontmatter: SkillFrontmatter
    body: str
    scripts: dict[str, "str | bytes"] = field(default_factory=dict)
    references_dir: "Path | None" = None
    templates_dir: "Path | None" = None

    @property
    def name(self) -> str:
        return self.frontmatter.name

    @property
    def prompt_block(self) -> str:
        """Return the text block to inject into the system prompt."""
        tag = f"skill_{self.name}"
        refs_hint = ""
        if self.references_dir and any(self.references_dir.iterdir()):
            ref_files = sorted(self.references_dir.iterdir())
            refs_hint = (
                "\n\n**Reference files** (read on demand via `fs_read`):\n"
                + "\n".join(
                    f"- `{self.frontmatter.scripts_sandbox_path.replace('/scripts', '/references')}"
                    f"/{f.name}` — {f.stem.replace('_', ' ').replace('-', ' ')}"
                    for f in ref_files
                    if f.is_file()
                )
            )
        scripts_hint = ""
        if self.scripts:
            scripts_hint = (
                "\n\n**Scripts** (already copied to sandbox, run with `sandbox_exec` or `python_exec`):\n"
                + "\n".join(
                    f"- `{self.frontmatter.scripts_sandbox_path}/{name}`"
                    for name in sorted(self.scripts)
                )
            )
        return f"<{tag}>\n{self.body}{scripts_hint}{refs_hint}\n</{tag}>"


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def _parse_skill_md(path: Path) -> "tuple[SkillFrontmatter, str]":
    """Parse a SKILL.md file into frontmatter + body.

    Returns
    -------
    (SkillFrontmatter, body_text)

    Raises
    ------
    ValueError
        If the file is missing required frontmatter fields.
    """
    raw = path.read_text(encoding="utf-8")
    m = _FRONTMATTER_RE.match(raw)
    if not m:
        raise ValueError(f"SKILL.md at {path} is missing YAML frontmatter (--- ... ---)")

    if _YAML_AVAILABLE:
        fm_raw = yaml.safe_load(m.group(1)) or {}
    else:
        # Fallback: simple key: value parser
        fm_raw: dict = {}
        for line in m.group(1).splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                fm_raw[k.strip()] = v.strip().strip("\"'")

    body = raw[m.end():].strip()

    if "name" not in fm_raw:
        raise ValueError(f"SKILL.md at {path} is missing required frontmatter field: name")
    if "description" not in fm_raw:
        raise ValueError(f"SKILL.md at {path} is missing required frontmatter field: description")

    # Support legacy "always: true" boolean flag as well as new "strategy: always"
    strategy: SkillStrategy = fm_raw.get("strategy", "on_demand")
    if fm_raw.get("always") is True and strategy == "on_demand":
        strategy = "always"
    # Also support legacy metadata: {"always": true} format
    if strategy == "on_demand":
        _meta = fm_raw.get("metadata", {})
        if isinstance(_meta, str):
            import json as _json
            try:
                _meta = _json.loads(_meta)
            except Exception:
                _meta = {}
        if isinstance(_meta, dict) and _meta.get("always") is True:
            strategy = "always"

    # Parse requires: list of binary names required for this skill
    # Supports two formats:
    #   1. New: ``requires: [binary1, binary2]`` (top-level list)
    #   2. Legacy: ``metadata: {"requires": {"bins": [...]}}`` (nested dict)
    raw_requires = fm_raw.get("requires", [])
    if not raw_requires:
        # Check legacy metadata.requires.bins format
        metadata = fm_raw.get("metadata", {})
        if isinstance(metadata, str):
            import json as _json
            try:
                metadata = _json.loads(metadata)
            except Exception:
                metadata = {}
        if isinstance(metadata, dict):
            raw_requires = metadata.get("requires", {}).get("bins", [])
    if isinstance(raw_requires, str):
        requires = [r.strip() for r in raw_requires.split(",") if r.strip()]
    else:
        requires = [str(r) for r in raw_requires]

    fm = SkillFrontmatter(
        name=str(fm_raw["name"]),
        description=str(fm_raw["description"]),
        strategy=strategy,
        roles=[str(r) for r in fm_raw.get("roles", [])],
        scripts_sandbox_path=fm_raw.get("scripts_sandbox_path", ""),
        requires=requires,
    )

    if len(body) > _MAX_SKILL_BODY_CHARS:
        logger.warning(
            "[skill_loader] skill=%s body is %d chars (limit %d); "
            "consider moving verbose content to references/.",
            fm.name, len(body), _MAX_SKILL_BODY_CHARS,
        )

    return fm, body


def _load_scripts(scripts_dir: Path) -> "dict[str, str | bytes]":
    """Load all files from a scripts/ directory.

    Returns a mapping of ``{filename: content}``.
    Binary files (non-UTF-8) are returned as bytes.
    """
    result: dict[str, "str | bytes"] = {}
    if not scripts_dir.is_dir():
        return result
    for f in sorted(scripts_dir.rglob("*")):
        if not f.is_file():
            continue
        rel = str(f.relative_to(scripts_dir))
        try:
            result[rel] = f.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            result[rel] = f.read_bytes()
    return result


# ---------------------------------------------------------------------------
# SkillLoader
# ---------------------------------------------------------------------------

class SkillLoader:
    """Loads and activates skills for a given agent role and task.

    Parameters
    ----------
    skills_dirs:
        List of directories to search for skill sub-directories.
        Earlier directories take priority (workspace-local overrides built-in).
        Defaults to the built-in skills directory.
    tenant_id:
        Optional tenant identifier.  If set, the loader checks
        ``skills_dir/tenants/{tenant_id}/{skill_name}/`` first.
    """

    def __init__(
        self,
        skills_dirs: "list[str] | None" = None,
        tenant_id: str = "",
        always_load: "list[str] | None" = None,
    ) -> None:
        if skills_dirs:
            self._roots: list[Path] = [Path(d) for d in skills_dirs if Path(d).exists()]
        else:
            self._roots = [BUILTIN_SKILLS_DIR] if BUILTIN_SKILLS_DIR.exists() else []

        self._tenant_id = tenant_id
        self._cache: dict[str, LoadedSkill] = {}
        # always_load: list of skill names that should be pre-injected regardless of strategy
        self._always_load: list[str] = always_load or []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def list_available(self) -> list[str]:
        """Return names of all discoverable skills (first match wins)."""
        seen: set[str] = set()
        names: list[str] = []
        for root in self._roots:
            if not root.exists():
                continue
            for d in sorted(root.iterdir()):
                if d.is_dir() and (d / "SKILL.md").exists() and d.name != "tenants":
                    if d.name not in seen:
                        seen.add(d.name)
                        names.append(d.name)
        return names

    def load(self, skill_name: str) -> "LoadedSkill | None":
        """Load a single skill by name (with caching).

        Returns ``None`` if the skill directory or SKILL.md does not exist.
        """
        if skill_name in self._cache:
            return self._cache[skill_name]

        skill_dir = self._resolve_skill_dir(skill_name)
        if skill_dir is None:
            logger.warning("[skill_loader] skill=%s not found", skill_name)
            return None

        skill_md = skill_dir / "SKILL.md"
        try:
            fm, body = _parse_skill_md(skill_md)
        except (ValueError, Exception) as exc:
            logger.error("[skill_loader] Failed to parse skill=%s: %s", skill_name, exc)
            return None

        scripts = _load_scripts(skill_dir / "scripts")
        refs_dir = skill_dir / "references"
        tmpl_dir = skill_dir / "templates"

        skill = LoadedSkill(
            frontmatter=fm,
            body=body,
            scripts=scripts,
            references_dir=refs_dir if refs_dir.is_dir() else None,
            templates_dir=tmpl_dir if tmpl_dir.is_dir() else None,
        )
        self._cache[skill_name] = skill
        logger.debug(
            "[skill_loader] Loaded skill=%s strategy=%s scripts=%d refs=%s",
            skill_name, fm.strategy, len(scripts),
            refs_dir.exists() if refs_dir else False,
        )
        return skill

    def activate_for_task(
        self,
        role: str = "executor",
    ) -> list[LoadedSkill]:
        """Return skills that should be pre-injected into the system prompt.

        Only ``always`` skills are returned here.  ``on_demand`` skills are
        NOT pre-activated — their descriptions appear in ``metadata_summary()``
        and the agent calls ``skill_load(skill_name)`` at runtime when it
        judges the skill relevant.

        Parameters
        ----------
        role:
            Agent role (e.g. ``"planner"``, ``"executor"``).
        """
        activated: list[LoadedSkill] = []
        for skill_name in self.list_available():
            skill = self.load(skill_name)
            if skill is None:
                continue
            fm = skill.frontmatter
            # Role filter
            if fm.roles and role not in fm.roles:
                continue
            if fm.strategy == "always":
                activated.append(skill)
            # on_demand — agent calls skill_load at runtime; no pre-activation here
        return activated

    def build_prompt_blocks(
        self,
        role: str = "executor",
    ) -> str:
        """Return the combined prompt text for ``always`` skills only.

        This is the text pre-injected into the system prompt (Level-2
        disclosure for ``always`` skills).  ``on_demand`` skills are NOT
        included here — their body is returned by the ``skill_load`` tool
        when the agent explicitly requests it.

        Scripts and references are NOT included here — they are handled
        separately via ``get_sandbox_scripts()``.
        """
        skills = self.activate_for_task(role=role)
        if not skills:
            return ""
        blocks = [s.prompt_block for s in skills]
        header = f"<!-- {len(skills)} always-skill(s) pre-injected -->"
        return header + "\n\n" + "\n\n".join(blocks)

    def get_sandbox_scripts(
        self,
        role: str = "executor",
    ) -> "list[tuple[str, str | bytes]]":
        """Return ``[(sandbox_path, content), ...]`` for all skills' scripts.

        All skills' scripts are copied to the sandbox at agent creation time
        (regardless of strategy), so the executor can run them immediately
        after calling ``skill_load`` without waiting for another copy step.

        The sandbox path is:
            ``{skill.frontmatter.scripts_sandbox_path}/{relative_filename}``
        """
        result: list[tuple[str, "str | bytes"]] = []
        for skill_name in self.list_available():
            skill = self.load(skill_name)
            if skill is None:
                continue
            fm = skill.frontmatter
            # Role filter
            if fm.roles and role not in fm.roles:
                continue
            base = fm.scripts_sandbox_path
            for rel_path, content in skill.scripts.items():
                sandbox_path = f"{base}/{rel_path}"
                result.append((sandbox_path, content))
        return result

    # ------------------------------------------------------------------
    # Backward-compatible API (legacy SkillsLoader interface)
    # ------------------------------------------------------------------

    def list_skills(
        self,
        filter_unavailable: bool = True,
    ) -> "list[dict]":
        """Return skill metadata dicts for all discoverable skills.

        Backward-compatible with the old ``SkillsLoader.list_skills()`` API.

        Parameters
        ----------
        filter_unavailable:
            When ``True`` (default), skills whose ``requires`` binaries are
            not present in PATH are excluded.  When ``False``, all skills
            are returned regardless of availability.
        """
        import shutil

        result: list[dict] = []
        for name in self.list_available():
            skill = self.load(name)
            if skill is None:
                continue
            fm = skill.frontmatter
            # Check binary requirements
            if filter_unavailable and fm.requires:
                missing = [r for r in fm.requires if not shutil.which(r)]
                if missing:
                    continue
            result.append({
                "name": fm.name,
                "description": fm.description,
                "strategy": fm.strategy,
                "roles": fm.roles,
                "requires": fm.requires,
            })
        return result

    def load_skill(self, skill_name: str) -> "str | None":
        """Return the raw SKILL.md text for *skill_name*.

        Backward-compatible with the old ``SkillsLoader.load_skill()`` API.
        Returns ``None`` if the skill is not found.
        """
        skill = self.load(skill_name)
        if skill is None:
            return None
        fm = skill.frontmatter
        # Reconstruct YAML frontmatter + body
        fm_lines = ["---"]
        fm_lines.append(f"name: {fm.name}")
        fm_lines.append(f"description: {fm.description}")
        fm_lines.append(f"strategy: {fm.strategy}")
        if fm.roles:
            fm_lines.append(f"roles: {fm.roles}")
        if fm.requires:
            fm_lines.append(f"requires: {fm.requires}")
        fm_lines.append("---")
        return "\n".join(fm_lines) + "\n" + skill.body

    def build_system_prompt_section(self) -> str:
        """Return the skills section for injection into the system prompt.

        Backward-compatible with the old ``SkillsLoader.build_system_prompt_section()``
        API.  Returns a combined block containing:
        - A metadata index (Level-1 disclosure) for all available skills
        - Full bodies (Level-2 disclosure) for ``always`` skills or skills
          in ``always_load``
        """
        available = self.list_available()
        if not available:
            return ""

        # Build index
        index_lines: list[str] = ["<skills>"]
        always_blocks: list[str] = []

        for name in available:
            skill = self.load(name)
            if skill is None:
                continue
            fm = skill.frontmatter

            # Check if skill is available (binary requirements)
            import shutil
            is_available = True
            if fm.requires:
                missing = [r for r in fm.requires if not shutil.which(r)]
                if missing:
                    is_available = False

            avail_attr = 'available="true"' if is_available else 'available="false"'
            index_lines.append(f'  <skill name="{fm.name}" {avail_attr}>{fm.description}</skill>')

            # Pre-inject always skills or explicitly always_load skills
            if is_available and (fm.strategy == "always" or fm.name in self._always_load):
                always_blocks.append(skill.prompt_block)

        index_lines.append("</skills>")
        section = "\n".join(index_lines)

        if always_blocks:
            section += "\n\n" + "\n\n".join(always_blocks)

        return section

    def reload(self) -> None:
        """Clear the skill cache, forcing a fresh load on next access.

        Useful in development when SKILL.md files are edited without
        restarting the process.
        """
        self._cache.clear()
        logger.info("[skill_loader] Cache cleared — skills will be reloaded on next access.")

    def metadata_summary(self) -> str:
        """Return a compact metadata listing for all available skills.

        This is the Level-1 disclosure text: always in context.
        Each entry contains the skill name and description so the agent
        can judge whether to call ``skill_load(skill_name)`` to get the
        full instructions.
        """
        available = self.list_available()
        if not available:
            return ""

        lines: list[str] = [
            "<available_skills>",
            "If any skill below is relevant to the current task, call "
            "``skill_load(skill_name)`` BEFORE starting execution to get "
            "the full instructions.",
            "",
        ]
        for name in available:
            skill = self.load(name)
            if skill is None:
                continue
            fm = skill.frontmatter
            lines.append(f"- **{fm.name}**: {fm.description}")
        lines.append("</available_skills>")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_skill_dir(self, skill_name: str) -> "Path | None":
        """Resolve the skill directory, checking tenant override first."""
        for root in self._roots:
            if self._tenant_id:
                tenant_path = root / "tenants" / self._tenant_id / skill_name
                if (tenant_path / "SKILL.md").exists():
                    return tenant_path
            default_path = root / skill_name
            if (default_path / "SKILL.md").exists():
                return default_path
        return None


# ---------------------------------------------------------------------------
# Backward-compatible alias
# ---------------------------------------------------------------------------

# genagent-core previously exported SkillsLoader; keep the alias so existing
# code that imports SkillsLoader continues to work.
SkillsLoader = SkillLoader
