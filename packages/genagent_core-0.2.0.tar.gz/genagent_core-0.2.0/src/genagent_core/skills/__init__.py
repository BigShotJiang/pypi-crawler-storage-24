"""Skills system for genagent-core.

Provides the SkillLoader (and backward-compatible SkillsLoader alias) for
loading and activating agent skills from SKILL.md packages.
"""
from .loader import (
    SkillLoader,
    SkillsLoader,  # backward-compat alias
    LoadedSkill,
    SkillFrontmatter,
    BUILTIN_SKILLS_DIR,
)

__all__ = [
    "SkillLoader",
    "SkillsLoader",
    "LoadedSkill",
    "SkillFrontmatter",
    "BUILTIN_SKILLS_DIR",
]
