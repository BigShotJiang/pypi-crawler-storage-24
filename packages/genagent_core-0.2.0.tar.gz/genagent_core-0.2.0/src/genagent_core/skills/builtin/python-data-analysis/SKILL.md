---
name: python-data-analysis
description: Best practices for data analysis, visualization, and statistical computation using python_exec.
always: false
---
# Python Data Analysis Skill

Use `python_exec` for all data analysis, visualization, and numerical computation tasks.
The kernel is stateful — variables persist across calls within the same Executor session.

## Workflow

1. **Load data** in the first cell; subsequent cells can reference the same variables.
2. **Explore** with `df.head()`, `df.describe()`, `df.info()` before transforming.
3. **Visualize** with matplotlib/seaborn; always call `plt.savefig("artifacts/chart.png")` and `plt.close()`.
4. **Save results** to files in `artifacts/` so the Planner can reference them.

## Code Patterns

```python
# Load CSV
import pandas as pd
df = pd.read_csv("data.csv")
print(df.shape, df.dtypes)
```

```python
# Plot and save
import matplotlib.pyplot as plt
fig, ax = plt.subplots()
df["value"].plot(ax=ax, title="Value over time")
plt.savefig("artifacts/value_chart.png", dpi=150, bbox_inches="tight")
plt.close()
print("Chart saved to artifacts/value_chart.png")
```

```python
# Statistical summary
summary = df.describe().to_markdown()
with open("artifacts/summary.md", "w") as f:
    f.write(summary)
```

## Tips

- Prefer `pandas` over raw loops for tabular data.
- Use `pathlib.Path("artifacts").mkdir(exist_ok=True)` before writing files.
- For large datasets, sample first: `df.sample(1000)`.
