---
name: web-research
description: Structured workflow for web research tasks — search, fetch, extract, and synthesize information.
always: false
---
# Web Research Skill

## Search Strategy

1. Start with 2–3 broad queries to map the topic landscape.
2. Identify authoritative sources (official docs, academic papers, reputable news).
3. Use targeted queries to fill specific gaps.
4. Cross-validate key facts across at least two independent sources.

## Fetching Pages

- Use `web_fetch` for full page content when search snippets are insufficient.
- Prefer official documentation URLs over third-party summaries.
- For paywalled content, look for cached versions or official PDFs.

## Extracting Information

- Save raw extracts to `artifacts/research_raw.md` as you go.
- Record source URLs alongside every fact.
- Note publication dates — prefer sources from the last 12 months for fast-moving topics.

## Synthesizing Results

- Write findings to `artifacts/findings.md` in structured Markdown.
- Use tables to compare options or specifications.
- Cite sources inline: `[Source: URL]`.
- Flag uncertain or conflicting information explicitly.

## Output Template

```markdown
# Research Findings: {topic}

## Summary
{2–3 sentence executive summary}

## Key Findings
| Finding | Source | Date |
|---------|--------|------|
| ...     | [URL]  | ...  |

## Detailed Analysis
{section per sub-topic}

## Sources
1. [Title](URL) — {brief description}
```
