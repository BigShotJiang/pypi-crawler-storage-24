from __future__ import annotations

import os
from typing import Any

from genagent_core.infra.object_store.base import ObjectMetadata, ObjectStore


class S3CompatibleObjectStore(ObjectStore):
    """S3 protocol compatible object store adapter.

    Works with:
    - AWS S3
    - Alibaba OSS (S3 compatible endpoint)
    - Tencent COS (S3 compatible endpoint)
    - MinIO
    """

    def __init__(
        self,
        *,
        bucket: str,
        endpoint_url: str = "",
        region: str = "",
        access_key_id: str = "",
        secret_access_key: str = "",
        session_token: str = "",
        use_ssl: bool = True,
        addressing_style: str = "auto",
        connect_timeout_seconds: float = 3.0,
        read_timeout_seconds: float = 8.0,
        max_attempts: int = 2,
        disable_proxy: bool = True,
        extra_client_kwargs: dict[str, Any] | None = None,
    ):
        if not bucket:
            raise ValueError("object_store.bucket is required")

        self.bucket = bucket
        self.endpoint_url = endpoint_url or None
        self.region = region or None

        try:
            import boto3
            from botocore.client import Config
        except Exception as exc:  # pragma: no cover - import guard
            raise RuntimeError(
                "boto3 is required for s3-compatible object store. "
                "Install it with: pip install boto3"
            ) from exc

        client_kwargs: dict[str, Any] = {
            "service_name": "s3",
            "endpoint_url": self.endpoint_url,
            "region_name": self.region,
        }
        if access_key_id:
            client_kwargs["aws_access_key_id"] = access_key_id
        if secret_access_key:
            client_kwargs["aws_secret_access_key"] = secret_access_key
        if session_token:
            client_kwargs["aws_session_token"] = session_token

        config_kwargs: dict[str, Any] = {
            "s3": {"addressing_style": addressing_style},
            "signature_version": "s3v4",
            "connect_timeout": connect_timeout_seconds,
            "read_timeout": read_timeout_seconds,
            "retries": {"max_attempts": max_attempts, "mode": "standard"},
        }
        if disable_proxy:
            config_kwargs["proxies"] = {}
        config = Config(**config_kwargs)
        client_kwargs["config"] = config
        if not use_ssl:
            client_kwargs["use_ssl"] = False

        if extra_client_kwargs:
            client_kwargs.update(extra_client_kwargs)

        if disable_proxy:
            # Ensure botocore does not inherit broken local HTTP(S)_PROXY when talking to object storage.
            os.environ.setdefault("NO_PROXY", "*")
            os.environ.setdefault("no_proxy", "*")

        self._client = boto3.client(**client_kwargs)

    def put_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
        metadata: dict[str, str] | None = None,
    ) -> ObjectMetadata:
        payload = {
            "Bucket": self.bucket,
            "Key": key,
            "Body": data,
            "ContentType": content_type,
        }
        if metadata:
            payload["Metadata"] = metadata
        resp = self._client.put_object(**payload)
        etag = str(resp.get("ETag", "")).strip("\"")
        return ObjectMetadata(
            key=key,
            size=len(data),
            etag=etag,
            content_type=content_type,
            metadata=metadata or {},
        )

    def get_bytes(self, key: str) -> bytes:
        resp = self._client.get_object(Bucket=self.bucket, Key=key)
        return resp["Body"].read()

    def head(self, key: str) -> ObjectMetadata | None:
        try:
            resp = self._client.head_object(Bucket=self.bucket, Key=key)
        except Exception:
            return None
        metadata = {str(k): str(v) for k, v in (resp.get("Metadata") or {}).items()}
        return ObjectMetadata(
            key=key,
            size=int(resp.get("ContentLength", 0) or 0),
            etag=str(resp.get("ETag", "")).strip("\""),
            content_type=str(resp.get("ContentType", "") or ""),
            metadata=metadata,
        )

    def delete(self, key: str) -> None:
        self._client.delete_object(Bucket=self.bucket, Key=key)

    def list_prefix(self, prefix: str, *, limit: int = 1000) -> list[ObjectMetadata]:
        paginator = self._client.get_paginator("list_objects_v2")
        result: list[ObjectMetadata] = []
        for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
            for row in page.get("Contents") or []:
                key = str(row.get("Key", ""))
                if not key:
                    continue
                result.append(ObjectMetadata(
                    key=key,
                    size=int(row.get("Size", 0) or 0),
                    etag=str(row.get("ETag", "")).strip("\""),
                ))
                if len(result) >= limit:
                    return result
        return result
