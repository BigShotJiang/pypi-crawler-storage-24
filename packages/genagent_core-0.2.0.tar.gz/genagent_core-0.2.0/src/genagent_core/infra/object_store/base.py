from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ObjectMetadata:
    key: str
    size: int = 0
    etag: str = ""
    content_type: str = ""
    metadata: dict[str, str] = field(default_factory=dict)


class ObjectStore(abc.ABC):
    """Abstract object storage interface.

    Design goal:
    - Keep business code provider-agnostic.
    - Support S3 protocol compatible backends (AWS S3 / OSS / COS / MinIO).
    """

    @abc.abstractmethod
    def put_bytes(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
        metadata: dict[str, str] | None = None,
    ) -> ObjectMetadata:
        pass

    @abc.abstractmethod
    def get_bytes(self, key: str) -> bytes:
        pass

    @abc.abstractmethod
    def head(self, key: str) -> ObjectMetadata | None:
        pass

    @abc.abstractmethod
    def delete(self, key: str) -> None:
        pass

    @abc.abstractmethod
    def list_prefix(self, prefix: str, *, limit: int = 1000) -> list[ObjectMetadata]:
        pass

    def put_text(
        self,
        key: str,
        content: str,
        *,
        content_type: str = "text/plain; charset=utf-8",
        metadata: dict[str, str] | None = None,
    ) -> ObjectMetadata:
        return self.put_bytes(
            key=key,
            data=content.encode("utf-8"),
            content_type=content_type,
            metadata=metadata,
        )

    def get_text(self, key: str, *, encoding: str = "utf-8") -> str:
        return self.get_bytes(key).decode(encoding)

    def put_json(self, key: str, payload: dict[str, Any]) -> ObjectMetadata:
        import json

        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        return self.put_bytes(
            key=key,
            data=data,
            content_type="application/json; charset=utf-8",
        )

