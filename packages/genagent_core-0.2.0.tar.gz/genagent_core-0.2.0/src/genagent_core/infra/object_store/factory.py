from __future__ import annotations

import os
from typing import Any

from genagent_core.infra.object_store.base import ObjectStore
from genagent_core.infra.object_store.s3_compatible import S3CompatibleObjectStore


def _cfg_value(cfg: dict[str, Any], key: str, env_key: str = "") -> str:
    raw = cfg.get(key, "")
    if raw:
        return str(raw)
    if env_key:
        return os.getenv(env_key, "")
    return ""


def create_object_store(config: dict[str, Any] | None = None) -> ObjectStore:
    cfg = config or {}
    provider = str(cfg.get("provider", "s3")).strip().lower()

    # All these providers are handled via one S3-compatible adapter.
    if provider in {"s3", "oss", "cos", "minio"}:
        endpoint_url = _cfg_value(cfg, "endpoint_url", "OBJECT_STORE_ENDPOINT_URL")
        region = _cfg_value(cfg, "region", "OBJECT_STORE_REGION")
        bucket = _cfg_value(cfg, "bucket", "OBJECT_STORE_BUCKET")
        access_key_id = _cfg_value(cfg, "access_key_id", "OBJECT_STORE_ACCESS_KEY_ID")
        secret_access_key = _cfg_value(cfg, "secret_access_key", "OBJECT_STORE_SECRET_ACCESS_KEY")
        session_token = _cfg_value(cfg, "session_token", "OBJECT_STORE_SESSION_TOKEN")
        addressing_style = _cfg_value(cfg, "addressing_style", "OBJECT_STORE_ADDRESSING_STYLE") or "auto"
        use_ssl_raw = str(cfg.get("use_ssl", "true")).lower()
        use_ssl = use_ssl_raw not in {"0", "false", "no"}
        connect_timeout_seconds = float(str(cfg.get("connect_timeout_seconds", "3") or "3"))
        read_timeout_seconds = float(str(cfg.get("read_timeout_seconds", "8") or "8"))
        max_attempts = int(str(cfg.get("max_attempts", "2") or "2"))
        disable_proxy_raw = str(cfg.get("disable_proxy", "true")).lower()
        disable_proxy = disable_proxy_raw not in {"0", "false", "no"}
        return S3CompatibleObjectStore(
            bucket=bucket,
            endpoint_url=endpoint_url,
            region=region,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            session_token=session_token,
            use_ssl=use_ssl,
            addressing_style=addressing_style,
            connect_timeout_seconds=connect_timeout_seconds,
            read_timeout_seconds=read_timeout_seconds,
            max_attempts=max_attempts,
            disable_proxy=disable_proxy,
        )

    raise ValueError(
        f"Unknown object_store.provider={provider!r}. "
        "Supported: s3, oss, cos, minio"
    )
