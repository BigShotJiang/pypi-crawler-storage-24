from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Any

from genagent_core.infra.object_store.base import ObjectStore
from genagent_core.infra.storage import StorageBackend
from genagent_core.sandbox.base import SandboxProvider


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class CriticalFileManager:
    """Persist and restore key sandbox files via object storage."""

    def __init__(self, *, storage: StorageBackend, object_store: ObjectStore):
        self.storage = storage
        self.object_store = object_store

    @staticmethod
    def _manifest_path(workspace_id: str, session_id: str) -> str:
        return f"workspaces/{workspace_id}/critical_files/{session_id}.json"

    def _load_manifest(self, workspace_id: str, session_id: str) -> dict[str, Any]:
        data = self.storage.read_json(self._manifest_path(workspace_id, session_id))
        if not isinstance(data, dict):
            return {"items": []}
        if not isinstance(data.get("items"), list):
            data["items"] = []
        return data

    def _save_manifest(self, workspace_id: str, session_id: str, data: dict[str, Any]) -> None:
        self.storage.write_json(self._manifest_path(workspace_id, session_id), data)

    def backup_bytes(
        self,
        *,
        workspace_id: str,
        session_id: str,
        task_id: str,
        logical_path: str,
        content: bytes,
        content_type: str = "application/octet-stream",
        source: str = "sandbox_write_file",
        metadata: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        payload = content
        checksum = hashlib.sha256(payload).hexdigest()
        filename = PurePosixPath(logical_path).name or "file.txt"
        object_key = (
            f"workspaces/{workspace_id}/sessions/{session_id}/critical/"
            f"{task_id}/{checksum[:12]}_{filename}"
        )

        object_meta = self.object_store.put_bytes(
            key=object_key,
            data=payload,
            content_type=content_type,
            metadata={
                "workspace_id": workspace_id,
                "session_id": session_id,
                "task_id": task_id,
                "logical_path": logical_path,
                **(metadata or {}),
            },
        )

        manifest = self._load_manifest(workspace_id, session_id)
        items = manifest["items"]
        now = _now_iso()
        row = {
            "logical_path": logical_path,
            "object_key": object_key,
            "checksum": checksum,
            "size": len(payload),
            "task_id": task_id,
            "source": source,
            "updated_at": now,
            "etag": object_meta.etag,
        }

        replaced = False
        for idx, item in enumerate(items):
            if str(item.get("logical_path", "")) == logical_path:
                items[idx] = row
                replaced = True
                break
        if not replaced:
            items.append(row)

        manifest["updated_at"] = now
        self._save_manifest(workspace_id, session_id, manifest)
        return row

    def backup_text(
        self,
        *,
        workspace_id: str,
        session_id: str,
        task_id: str,
        logical_path: str,
        content: str,
        source: str = "sandbox_write_file",
        metadata: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self.backup_bytes(
            workspace_id=workspace_id,
            session_id=session_id,
            task_id=task_id,
            logical_path=logical_path,
            content=content.encode("utf-8"),
            content_type="text/plain; charset=utf-8",
            source=source,
            metadata=metadata,
        )

    def list_critical_files(self, *, workspace_id: str, session_id: str) -> list[dict[str, Any]]:
        manifest = self._load_manifest(workspace_id, session_id)
        rows = manifest.get("items", [])
        if not isinstance(rows, list):
            return []
        return [r for r in rows if isinstance(r, dict)]

    async def restore_to_sandbox(
        self,
        *,
        workspace_id: str,
        session_id: str,
        sandbox_provider: SandboxProvider,
    ) -> dict[str, int]:
        rows = self.list_critical_files(workspace_id=workspace_id, session_id=session_id)
        restored = 0
        failed = 0
        for row in rows:
            logical_path = str(row.get("logical_path", "")).strip()
            object_key = str(row.get("object_key", "")).strip()
            if not logical_path or not object_key:
                continue
            try:
                content = self.object_store.get_bytes(object_key)
                await sandbox_provider.write_file(
                    session_id=session_id,
                    path=logical_path,
                    content=content,
                )
                restored += 1
            except Exception:
                failed += 1
        return {"restored": restored, "failed": failed}
