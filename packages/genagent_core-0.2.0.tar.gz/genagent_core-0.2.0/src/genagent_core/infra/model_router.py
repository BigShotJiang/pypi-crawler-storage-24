from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


class ModelRouter:
    def __init__(self, config: dict):
        self.default_model = config.get("default", "fake-planner")
        self.map = config.get("by_role", {})
        self.fallback_map = config.get("fallback", {})

    def route(self, role: str) -> str:
        return self.map.get(role, self.default_model)

    def get_fallback(self, role: str) -> str | None:
        return self.fallback_map.get(role)
