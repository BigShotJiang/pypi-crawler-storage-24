from __future__ import annotations

import json
import logging
import os
import re
import time
from itertools import cycle
from uuid import uuid4

import httpx

logger = logging.getLogger(__name__)
_IMAGE_TAG_PATTERN = re.compile(r"<image_data_url>(.*?)</image_data_url>", re.DOTALL)

def _sanitize_schema_node(node):
    """Make JSON schema more compatible with stricter OpenAI-compatible providers."""
    if isinstance(node, dict):
        out = {}
        for k, v in node.items():
            # Some providers reject default/nullable/oneOf/anyOf in tool schema.
            if k in {"default", "nullable", "oneOf"}:
                continue
            if k == "anyOf":
                # Fallback to a permissive string type.
                out["type"] = "string"
                continue
            out[k] = _sanitize_schema_node(v)
        return out
    if isinstance(node, list):
        return [_sanitize_schema_node(x) for x in node]
    return node


def _sanitize_tool_schema(tool: dict) -> dict:
    t = dict(tool)
    params = t.get("parameters")
    if not isinstance(params, dict) or not params:
        t["parameters"] = {"type": "object", "properties": {}}
        return t
    sanitized = _sanitize_schema_node(params)
    if not isinstance(sanitized, dict):
        sanitized = {"type": "object", "properties": {}}
    if "type" not in sanitized:
        sanitized["type"] = "object"
    if "properties" not in sanitized or not isinstance(sanitized["properties"], dict):
        sanitized["properties"] = {}
    t["parameters"] = sanitized
    return t


def _sanitize_messages(messages: list[dict]) -> list[dict]:
    """Normalize messages for stricter providers (e.g. disallow tool-first payloads)."""
    if not messages:
        return [{"role": "user", "content": "请继续。"}]
    sanitized = [dict(m) for m in messages]
    first_role = str(sanitized[0].get("role", ""))
    if first_role not in {"system", "user"}:
        sanitized.insert(0, {"role": "user", "content": "[上下文已压缩，请继续当前任务]"})

    # Convert inline image tags in user text into OpenAI multimodal content parts.
    for idx, msg in enumerate(sanitized):
        if msg.get("role") != "user":
            continue
        content = msg.get("content")
        if not isinstance(content, str) or "<image_data_url>" not in content:
            continue
        urls = [u.strip() for u in _IMAGE_TAG_PATTERN.findall(content) if u.strip().startswith("data:image/")]
        if not urls:
            continue
        text = _IMAGE_TAG_PATTERN.sub("", content).strip()
        parts: list[dict] = []
        if text:
            parts.append({"type": "text", "text": text})
        for url in urls[:3]:
            parts.append({"type": "image_url", "image_url": {"url": url}})
        sanitized[idx] = {**msg, "content": parts}
    return sanitized


class BaseLLMProvider:
    async def chat_completion(
        self,
        model: str,
        messages: list[dict],
        tools: list[dict],
        tool_choice: str = "auto",
        *,
        stream: bool = False,
        on_delta: object | None = None,
    ) -> dict:
        raise NotImplementedError


class KeyPool:
    """Intelligent API key pool with per-key cooldown on 429 rate-limit errors.

    Behavior:
    - Round-robin across all keys by default.
    - When a key triggers a 429, it is marked as cooling down for `cooldown_seconds`.
    - Subsequent calls skip cooling-down keys automatically.
    - If ALL keys are cooling down, the least-recently-cooled key is returned with a warning
      (better to retry than to block indefinitely).
    """

    def __init__(self, keys: list[str], cooldown_seconds: float = 60.0):
        if not keys:
            raise ValueError("KeyPool requires at least one key")
        self._keys = keys
        self._pool = cycle(keys)
        self._cooldowns: dict[str, float] = {}  # key → cooldown_until (monotonic)
        self._cooldown_seconds = cooldown_seconds

    def next_key(self) -> str:
        """Return the next available (non-cooling) key."""
        now = time.monotonic()
        for _ in range(len(self._keys)):
            key = next(self._pool)
            if now >= self._cooldowns.get(key, 0.0):
                return key
        # All keys are cooling — pick the one whose cooldown expires soonest
        key = min(self._keys, key=lambda k: self._cooldowns.get(k, 0.0))
        remaining = max(0.0, self._cooldowns.get(key, 0.0) - now)
        logger.warning(
            "KeyPool: all %d keys are cooling down (shortest remaining: %.1fs), using %s...%s",
            len(self._keys), remaining, key[:8], key[-4:],
        )
        return key

    def mark_rate_limited(self, key: str) -> None:
        """Mark a key as rate-limited; it will be skipped for `cooldown_seconds`."""
        self._cooldowns[key] = time.monotonic() + self._cooldown_seconds
        logger.warning(
            "KeyPool: key %s...%s rate-limited, cooling for %.0fs (%d/%d keys available)",
            key[:8], key[-4:], self._cooldown_seconds,
            sum(1 for k in self._keys if time.monotonic() >= self._cooldowns.get(k, 0.0)),
            len(self._keys),
        )

    @property
    def total(self) -> int:
        return len(self._keys)

    @property
    def available(self) -> int:
        now = time.monotonic()
        return sum(1 for k in self._keys if now >= self._cooldowns.get(k, 0.0))


class OpenAICompatibleProvider(BaseLLMProvider):
    """Universal OpenAI-compatible endpoint adapter.

    Works with any provider that implements the OpenAI Chat Completions API:
    - OpenAI (gpt-4o, o1, ...)
    - 阿里云百炼 / Qwen (qwen-plus, qwen-max, qwen-long, ...)
    - 月之暗面 / Kimi (moonshot-v1-8k, moonshot-v1-128k, ...)
    - DeepSeek (deepseek-chat, deepseek-reasoner, ...)
    - 智谱 AI / GLM (glm-4, glm-4-flash, ...)
    - 字节豆包 / Doubao (doubao-pro-32k, doubao-lite-32k, ...)
    - 腾讯混元 / Hunyuan (hunyuan-turbo, hunyuan-standard, ...)
    - MiniMax (abab6.5s-chat, abab6-chat, ...)
    - Ollama (llama3, qwen2.5, ...)
    - Any other OpenAI-compatible endpoint

    Key pool features:
    - Multiple keys supported via `api_keys` list or comma-separated env var
    - Automatic round-robin rotation across keys
    - 429 rate-limit triggers per-key cooldown (configurable via `key_cooldown_seconds`)
    - Skips cooling keys; falls back gracefully when all keys are cooling
    """

    def __init__(self, name: str, config: dict):
        self.name = name

        # ── Key pool setup ──────────────────────────────────────────────────
        raw_keys = config.get("api_keys", [])
        if not raw_keys:
            env_key = os.getenv(config.get("api_key_env", ""), "")
            if env_key:
                raw_keys = [k.strip() for k in env_key.split(",") if k.strip()]
        if not raw_keys:
            raise ValueError(
                f"Provider [{name}]: no API keys. "
                f"Set env {config.get('api_key_env', '???')} or providers.{name}.api_keys in config.json"
            )
        cooldown = float(config.get("key_cooldown_seconds", 60))
        self._key_pool = KeyPool(raw_keys, cooldown_seconds=cooldown)

        # ── Endpoint config ─────────────────────────────────────────────────
        self._base_url = config.get("base_url", "https://api.openai.com/v1").rstrip("/")
        self._timeout = config.get("timeout", 120)

        # ── Per-provider quirks ─────────────────────────────────────────────
        # Some domestic providers need extra headers or body fields.
        self._extra_headers: dict[str, str] = config.get("extra_headers", {})
        self._extra_body: dict = config.get("extra_body", {})

        logger.info(
            "Provider [%s] ready — %d key(s), base_url=%s",
            self.name, self._key_pool.total, self._base_url,
        )

    # ── Internal helpers ────────────────────────────────────────────────────

    def _build_headers(self, api_key: str) -> dict[str, str]:
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        headers.update(self._extra_headers)
        return headers

    def _build_body(self, model: str, messages: list[dict], tools: list[dict], tool_choice: str) -> dict:
        body: dict = {
            "model": model,
            "messages": _sanitize_messages(messages),
            **self._extra_body,
        }
        if tools:
            safe_tools = [_sanitize_tool_schema(t) for t in tools]
            openai_tools = [{"type": "function", "function": t} for t in safe_tools]
            body["tools"] = openai_tools
            body["tool_choice"] = tool_choice
        return body

    @staticmethod
    def _is_rate_limit_error(status_code: int, response_text: str) -> bool:
        if status_code == 429:
            return True
        # Some providers (e.g. Kimi) return 200 with error body on quota exceeded
        if "rate_limit" in response_text.lower() or "too many requests" in response_text.lower():
            return True
        return False

    @staticmethod
    def _parse_non_stream_result(data: dict) -> dict:
        choice = data["choices"][0]
        message = choice["message"]
        result: dict = {"message": {}}
        if message.get("content"):
            result["message"]["content"] = message["content"]
        if message.get("tool_calls"):
            result["message"]["tool_calls"] = [
                {
                    "id": tc["id"],
                    "type": tc["type"],
                    "function": {
                        "name": tc["function"]["name"],
                        "arguments": tc["function"]["arguments"],
                    },
                }
                for tc in message["tool_calls"]
            ]
        return result

    # ── Public interface ────────────────────────────────────────────────────

    async def chat_completion(
        self,
        model: str,
        messages: list[dict],
        tools: list[dict],
        tool_choice: str = "auto",
        *,
        stream: bool = False,
        on_delta: object | None = None,
    ) -> dict:
        api_key = self._key_pool.next_key()
        headers = self._build_headers(api_key)
        body = self._build_body(model, messages, tools, tool_choice)
        url = f"{self._base_url}/chat/completions"

        logger.debug(
            "LLM request [%s] model=%s url=%s keys=%d/%d",
            self.name, model, url,
            self._key_pool.available, self._key_pool.total,
        )

        timeout = httpx.Timeout(
            timeout=float(self._timeout),
            connect=min(20.0, float(self._timeout)),
            read=float(self._timeout),
            write=min(30.0, float(self._timeout)),
            pool=min(30.0, float(self._timeout)),
        )

        if not stream:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(url, headers=headers, json=body)
                if resp.status_code >= 400:
                    snippet = (resp.text or "")[:800]
                    logger.error(
                        "LLM HTTP %s from %s (provider=%s model=%s). response=%s",
                        resp.status_code, url, self.name, model, snippet,
                    )
                    if self._is_rate_limit_error(resp.status_code, resp.text or ""):
                        self._key_pool.mark_rate_limited(api_key)
                resp.raise_for_status()
                data = resp.json()
            return self._parse_non_stream_result(data)

        # ── Streaming path ──────────────────────────────────────────────────
        body["stream"] = True
        content_parts: list[str] = []
        tool_calls_acc: dict[int, dict] = {}

        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, headers=headers, json=body) as resp:
                if resp.status_code >= 400:
                    snippet = (await resp.aread()).decode("utf-8", errors="ignore")[:800]
                    logger.error(
                        "LLM HTTP %s from %s (provider=%s model=%s, stream). response=%s",
                        resp.status_code, url, self.name, model, snippet,
                    )
                    if self._is_rate_limit_error(resp.status_code, snippet):
                        self._key_pool.mark_rate_limited(api_key)
                resp.raise_for_status()
                async for raw_line in resp.aiter_lines():
                    line = (raw_line or "").strip()
                    if not line.startswith("data:"):
                        continue
                    payload = line[5:].strip()
                    if not payload or payload == "[DONE]":
                        continue
                    try:
                        data = json.loads(payload)
                    except Exception:
                        continue
                    choices = data.get("choices") or []
                    if not choices:
                        continue
                    delta = (choices[0] or {}).get("delta") or {}
                    delta_content = delta.get("content")
                    if isinstance(delta_content, str) and delta_content:
                        content_parts.append(delta_content)
                        if callable(on_delta):
                            maybe = on_delta(delta_content)
                            if hasattr(maybe, "__await__"):
                                await maybe

                    delta_tool_calls = delta.get("tool_calls") or []
                    if isinstance(delta_tool_calls, list):
                        for tc in delta_tool_calls:
                            if not isinstance(tc, dict):
                                continue
                            idx = int(tc.get("index", 0) or 0)
                            slot = tool_calls_acc.setdefault(
                                idx,
                                {
                                    "id": "",
                                    "type": "function",
                                    "function": {"name": "", "arguments": ""},
                                },
                            )
                            if tc.get("id"):
                                slot["id"] = str(tc["id"])
                            if tc.get("type"):
                                slot["type"] = str(tc["type"])
                            fn = tc.get("function") or {}
                            if isinstance(fn, dict):
                                if fn.get("name"):
                                    slot["function"]["name"] = str(fn["name"])
                                if fn.get("arguments"):
                                    slot["function"]["arguments"] += str(fn["arguments"])

        result: dict = {"message": {}}
        if content_parts:
            result["message"]["content"] = "".join(content_parts)
        if tool_calls_acc:
            normalized = []
            for idx in sorted(tool_calls_acc.keys()):
                tc = tool_calls_acc[idx]
                if not tc["id"]:
                    tc["id"] = f"tc_{uuid4().hex[:8]}"
                normalized.append(tc)
            result["message"]["tool_calls"] = normalized
        return result


class FakeLLMProvider(BaseLLMProvider):
    """Deterministic mock provider for testing without real API calls."""

    async def chat_completion(
        self,
        model: str,
        messages: list[dict],
        tools: list[dict],
        tool_choice: str = "auto",
        *,
        stream: bool = False,
        on_delta: object | None = None,
    ) -> dict:
        tool_names = [t["name"] for t in tools]
        tool_results = [m for m in messages if m.get("role") == "tool"]
        user_messages = [m.get("content", "") for m in messages if m.get("role") == "user"]
        latest_instruction = user_messages[-1] if user_messages else ""

        def call(name: str, args: dict) -> dict:
            return {
                "id": f"tc_{uuid4().hex[:8]}",
                "type": "function",
                "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
            }

        # Sandbox-first for coding/debug tasks in fake mode.
        if "sandbox_info" in tool_names and not any("sandbox_info" in str(r) for r in tool_results):
            return {"message": {"tool_calls": [call("sandbox_info", {})]}}

        if "web_search" in tool_names and not any("web_search" in str(r) for r in tool_results):
            return {
                "message": {
                    "tool_calls": [
                        call("web_search", {"query": latest_instruction or "market pricing"})
                    ]
                }
            }

        if "browser_navigate" in tool_names and not any("browser_navigate" in str(r) for r in tool_results):
            return {"message": {"tool_calls": [call("browser_navigate", {"url": "https://example.com"})]}}

        if "browser_view" in tool_names and not any("browser_view" in str(r) for r in tool_results):
            return {"message": {"tool_calls": [call("browser_view", {})]}}

        if "file_read" in tool_names and not any("file_read" in str(r) for r in tool_results):
            return {"message": {"tool_calls": [call("file_read", {"task_id": "", "step_id": ""})]}}

        if "file_write" in tool_names and not any("file_write" in str(r) for r in tool_results):
            content = "Deterministic MVP artifact generated by FakeLLMProvider."
            artifact_type = "document"
            if "research" in model:
                artifact_type = "dataset"
                content = '[{"name":"Sample AI Product","monthly":20}]'
            if "analyze" in model:
                content = "Analysis: pricing tiers differentiated by seat limits and automation features."
            if "write" in model:
                artifact_type = "report"
                content = "Final report: recommend transparent tiering with annual discount and enterprise path."
            return {
                "message": {
                    "tool_calls": [
                        call(
                            "file_write",
                            {"artifact_type": artifact_type, "content": content, "metadata": {"source": "fake-llm"}},
                        )
                    ]
                }
            }

        # submit_results: Executor Agent's result submission (before idle)
        if "submit_results" in tool_names and not any("submit_results" in str(r) for r in tool_results):
            return {"message": {"tool_calls": [call("submit_results", {
                "payload": {"summary": "Fake task completed", "artifact_id": ""},
                "status": "success",
                "summary": "Fake executor completed task",
            })]}}

        # spawn_subagent: Planner Agent's executor dispatch
        if "spawn_subagent" in tool_names and not any("spawn_subagent" in str(r) for r in tool_results):
            return {"message": {"tool_calls": [call("spawn_subagent", {
                "goal": latest_instruction or "execute research task",
                "role": "research",
                "output_schema": {"type": "object", "properties": {"findings": {"type": "array"}}},
            })]}}

        if "idle" in tool_names:
            return {"message": {"tool_calls": [call("idle", {"reason": "task_completed"})]}}

        return {"message": {"content": "No action."}}


class LLMProvider(BaseLLMProvider):
    """Multi-provider router.

    model string format: "provider_name:actual_model"
      e.g. "openai:gpt-4.1", "kimi:moonshot-v1-128k", "qwen:qwen-plus"
    If no ":" prefix, uses default_provider.
    If provider is "fake", uses FakeLLMProvider for all calls.

    On 429/5xx errors, automatically retries with exponential backoff.
    The underlying OpenAICompatibleProvider handles per-key cooldown rotation,
    so retries will naturally use a different (non-cooling) key when available.
    """

    def __init__(self, config: dict):
        self.config = config
        self._backends: dict[str, BaseLLMProvider] = {}
        self._default_provider = config.get("default_provider", "")
        self._fake = FakeLLMProvider()

        providers_cfg = config.get("providers", {})
        for name, pcfg in providers_cfg.items():
            try:
                self._backends[name] = OpenAICompatibleProvider(name, pcfg)
                logger.info("Registered LLM provider: %s → %s", name, pcfg.get("base_url"))
            except ValueError as e:
                logger.warning("Skipped provider [%s]: %s", name, e)

        if not self._default_provider and self._backends:
            self._default_provider = next(iter(self._backends))

        if self._backends:
            logger.info(
                "LLMProvider ready — providers: %s, default: %s",
                list(self._backends.keys()),
                self._default_provider,
            )
        else:
            logger.info("LLMProvider ready — no real providers configured, using Fake fallback")

    def _resolve(self, model: str) -> tuple[BaseLLMProvider, str]:
        """Parse 'provider:model' → (backend, actual_model).
        Falls back to fake if provider not found."""
        if ":" in model:
            provider_name, actual_model = model.split(":", 1)
        else:
            provider_name = self._default_provider
            actual_model = model

        if provider_name == "fake" or provider_name not in self._backends:
            if provider_name != "fake" and provider_name not in self._backends:
                logger.warning("Provider [%s] not found, falling back to Fake", provider_name)
            return self._fake, actual_model

        return self._backends[provider_name], actual_model

    async def chat_completion(
        self, model: str, messages: list[dict], tools: list[dict], tool_choice: str = "auto",
        *, max_retries: int = 3, stream: bool = False, on_delta: object | None = None,
    ) -> dict:
        import asyncio
        backend, actual_model = self._resolve(model)
        logger.debug("Routing model=%s → backend=%s actual_model=%s", model, type(backend).__name__, actual_model)

        last_exc: Exception | None = None
        for attempt in range(max_retries):
            try:
                result = await backend.chat_completion(
                    model=actual_model,
                    messages=messages,
                    tools=tools,
                    tool_choice=tool_choice,
                    stream=stream,
                    on_delta=on_delta,
                )
                return result
            except Exception as e:
                last_exc = e
                err_str = str(e) or repr(e)
                is_retryable_http = any(code in err_str for code in ("429", "500", "502", "503", "504", "529"))
                is_retryable_timeout = isinstance(e, (httpx.TimeoutException, httpx.TransportError))
                is_retryable = is_retryable_http or is_retryable_timeout
                if not is_retryable:
                    raise
                # On 429, the key pool already marked the key as cooling.
                # Use shorter wait since key rotation handles the rate-limit.
                is_rate_limit = "429" in err_str
                wait = 1.0 if is_rate_limit else min(2 ** attempt, 16)
                logger.warning(
                    "LLM request failed (attempt %d/%d), retrying in %.1fs: %s [%s]",
                    attempt + 1, max_retries, wait, err_str[:200],
                    type(e).__name__,
                )
                await asyncio.sleep(wait)

        raise last_exc  # type: ignore[misc]
