from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class StorageBackend:
    def __init__(self, config: dict[str, Any] | None = None):
        cfg = config or {}
        base_dir = cfg.get("base_dir", "runtime_data")
        self.base_dir = Path(base_dir).resolve()
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def resolve(self, relative_path: str) -> Path:
        path = self.base_dir / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def write(self, relative_path: str, content: str) -> str:
        path = self.resolve(relative_path)
        path.write_text(content, encoding="utf-8")
        return str(path)

    def read(self, relative_path: str) -> str:
        path = self.resolve(relative_path)
        if not path.exists():
            return ""
        return path.read_text(encoding="utf-8")

    def write_json(self, relative_path: str, data: dict[str, Any]) -> str:
        path = self.resolve(relative_path)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def read_json(self, relative_path: str) -> dict[str, Any]:
        path = self.resolve(relative_path)
        if not path.exists():
            return {}
        return json.loads(path.read_text(encoding="utf-8"))

    def exists(self, relative_path: str) -> bool:
        return self.resolve(relative_path).exists()
