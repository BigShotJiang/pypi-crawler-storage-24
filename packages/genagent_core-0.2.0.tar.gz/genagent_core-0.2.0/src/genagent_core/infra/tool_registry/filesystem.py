"""Generic filesystem tools: fs_read, fs_write, fs_edit, fs_list.

Design philosophy
-----------------
All four tools are **backend-agnostic**: they delegate actual I/O to a
:class:`FilesystemBackend` abstraction, which currently ships with two
concrete implementations:

* :class:`LocalFilesystemBackend`  — reads/writes the host process's
  local filesystem (useful for local development, testing, and future
  local-agent deployments).
* :class:`SandboxFilesystemBackend` — proxies all I/O through a
  :class:`SandboxProvider` RPC, keeping files inside the isolated
  sandbox environment.

Adding a third backend (e.g. S3, SFTP, in-memory) requires only
implementing the four abstract methods; the tool logic stays unchanged.

Tool capabilities vs. the old sandbox_read_file / sandbox_write_file
---------------------------------------------------------------------
* ``fs_read``  — line-based pagination (offset + limit), image detection,
  line-numbered output, char-limit guard, end-of-file hint.
* ``fs_write`` — creates parent directories automatically.
* ``fs_edit``  — fuzzy whitespace-tolerant matching with unified-diff
  diagnostics when the target text is not found.
* ``fs_list``  — recursive directory listing with noise-dir filtering.
"""

from __future__ import annotations

import abc
import difflib
import json
import logging
import mimetypes
import posixpath
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Backend abstraction
# ---------------------------------------------------------------------------

class FilesystemBackend(abc.ABC):
    """Minimal I/O interface that concrete backends must implement."""

    @abc.abstractmethod
    async def read(self, path: str) -> bytes:
        """Return the raw bytes of *path*."""

    @abc.abstractmethod
    async def write(self, path: str, content: str) -> None:
        """Write UTF-8 *content* to *path*, creating parent dirs as needed."""

    @abc.abstractmethod
    async def list_dir(self, path: str) -> list[str]:
        """Return a flat list of entry names directly under *path*.

        Each name is suffixed with ``/`` if it is a directory.
        """

    @abc.abstractmethod
    async def list_dir_recursive(self, path: str) -> list[str]:
        """Return relative paths of all entries under *path* recursively.

        Directories are suffixed with ``/``.
        """

    @abc.abstractmethod
    async def is_dir(self, path: str) -> bool:
        """Return True if *path* is a directory."""

    @abc.abstractmethod
    async def exists(self, path: str) -> bool:
        """Return True if *path* exists."""


# ---------------------------------------------------------------------------
# Local filesystem backend
# ---------------------------------------------------------------------------

class LocalFilesystemBackend(FilesystemBackend):
    """Backend that operates on the host's local filesystem.

    Parameters
    ----------
    workspace:
        Optional root directory. Relative paths are resolved against it.
    allowed_dir:
        If set, all resolved paths must be under this directory (security
        guard). Defaults to *workspace* when *workspace* is provided.
    """

    _IGNORE_DIRS = {
        ".git", "node_modules", "__pycache__", ".venv", "venv",
        "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
        ".ruff_cache", ".coverage", "htmlcov",
    }

    def __init__(
        self,
        workspace: Path | str | None = None,
        allowed_dir: Path | str | None = None,
    ) -> None:
        self._workspace = Path(workspace).resolve() if workspace else None
        self._allowed_dir = (
            Path(allowed_dir).resolve()
            if allowed_dir
            else self._workspace
        )

    def _resolve(self, path: str) -> Path:
        p = Path(path).expanduser()
        if not p.is_absolute() and self._workspace:
            p = self._workspace / p
        resolved = p.resolve()
        if self._allowed_dir:
            try:
                resolved.relative_to(self._allowed_dir)
            except ValueError:
                raise PermissionError(
                    f"Path '{path}' is outside allowed directory '{self._allowed_dir}'"
                )
        return resolved

    async def read(self, path: str) -> bytes:
        return self._resolve(path).read_bytes()

    async def write(self, path: str, content: str) -> None:
        fp = self._resolve(path)
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content, encoding="utf-8")

    async def list_dir(self, path: str) -> list[str]:
        dp = self._resolve(path)
        entries = []
        for item in sorted(dp.iterdir()):
            if item.name in self._IGNORE_DIRS:
                continue
            entries.append(f"{item.name}/" if item.is_dir() else item.name)
        return entries

    async def list_dir_recursive(self, path: str) -> list[str]:
        dp = self._resolve(path)
        entries = []
        for item in sorted(dp.rglob("*")):
            if any(p in self._IGNORE_DIRS for p in item.parts):
                continue
            rel = item.relative_to(dp)
            entries.append(f"{rel}/" if item.is_dir() else str(rel))
        return entries

    async def is_dir(self, path: str) -> bool:
        return self._resolve(path).is_dir()

    async def exists(self, path: str) -> bool:
        try:
            return self._resolve(path).exists()
        except PermissionError:
            return False


# ---------------------------------------------------------------------------
# Sandbox filesystem backend
# ---------------------------------------------------------------------------

class SandboxFilesystemBackend(FilesystemBackend):
    """Backend that proxies I/O through a :class:`SandboxProvider` RPC.

    Parameters
    ----------
    sandbox_provider:
        A concrete SandboxProvider (Daytona, E2B, …).
    session_id:
        The sandbox session to operate on.
    workdir:
        Default working directory inside the sandbox (default ``/workspace``).
    """

    _WORKDIR = "/workspace"
    _IGNORE_DIRS = {
        ".git", "node_modules", "__pycache__", ".venv", "venv",
        "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
    }

    def __init__(self, sandbox_provider: Any, session_id: str, workdir: str = "/workspace") -> None:
        self._provider = sandbox_provider
        self._session_id = session_id
        self._workdir = workdir

    def _normalize(self, path: str) -> str:
        """Resolve relative paths against workdir; normalise absolute paths."""
        raw = str(path or "").strip()
        if not raw:
            return self._workdir
        if not raw.startswith("/"):
            return posixpath.normpath(f"{self._workdir}/{raw}")
        if raw == "/":
            return self._workdir
        # Bare single-component absolute path like "/foo.py" → "/workspace/foo.py"
        if raw.count("/") == 1:
            return f"{self._workdir}/{raw.lstrip('/')}"
        return posixpath.normpath(raw)

    async def read(self, path: str) -> bytes:
        content: str = await self._provider.read_file(
            session_id=self._session_id,
            path=self._normalize(path),
        )
        return content.encode("utf-8") if isinstance(content, str) else content

    async def write(self, path: str, content: str) -> None:
        await self._provider.write_file(
            session_id=self._session_id,
            path=self._normalize(path),
            content=content,
        )

    async def _run_ls(self, path: str, recursive: bool) -> list[str]:
        flag = "-1aR" if recursive else "-1a"
        result = await self._provider.run_command(
            session_id=self._session_id,
            command=f"ls {flag} -- {self._normalize(path)!r}",
        )
        raw = result.get("output", "") if isinstance(result, dict) else str(result)
        lines = [l for l in raw.splitlines() if l and not l.startswith(".")]
        return lines

    async def list_dir(self, path: str) -> list[str]:
        return await self._run_ls(path, recursive=False)

    async def list_dir_recursive(self, path: str) -> list[str]:
        return await self._run_ls(path, recursive=True)

    async def is_dir(self, path: str) -> bool:
        result = await self._provider.run_command(
            session_id=self._session_id,
            command=f"test -d {self._normalize(path)!r} && echo dir || echo file",
        )
        out = result.get("output", "") if isinstance(result, dict) else str(result)
        return out.strip() == "dir"

    async def exists(self, path: str) -> bool:
        result = await self._provider.run_command(
            session_id=self._session_id,
            command=f"test -e {self._normalize(path)!r} && echo yes || echo no",
        )
        out = result.get("output", "") if isinstance(result, dict) else str(result)
        return out.strip() == "yes"


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

_MAX_CHARS = 128_000
_DEFAULT_LIMIT = 2000
_DEFAULT_MAX_ENTRIES = 200


def _detect_image_mime(raw: bytes) -> str | None:
    """Detect common image MIME types from magic bytes."""
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if raw[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if raw[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "image/webp"
    return None


def _find_match(content: str, old_text: str) -> tuple[str | None, int]:
    """Locate *old_text* in *content* with whitespace-tolerant fallback.

    Strategy:
    1. Exact substring match.
    2. Line-level strip sliding window (tolerates leading/trailing whitespace
       differences per line, e.g. mixed indentation from model output).

    Returns ``(matched_fragment, occurrence_count)`` or ``(None, 0)``.
    """
    if old_text in content:
        return old_text, content.count(old_text)

    old_lines = old_text.splitlines()
    if not old_lines:
        return None, 0

    stripped_old = [l.strip() for l in old_lines]
    content_lines = content.splitlines()
    candidates: list[str] = []

    for i in range(len(content_lines) - len(stripped_old) + 1):
        window = content_lines[i: i + len(stripped_old)]
        if [l.strip() for l in window] == stripped_old:
            candidates.append("\n".join(window))

    if candidates:
        return candidates[0], len(candidates)
    return None, 0


def _not_found_msg(old_text: str, content: str, path: str) -> str:
    """Build a diagnostic message when *old_text* is not found in *content*."""
    lines = content.splitlines(keepends=True)
    old_lines = old_text.splitlines(keepends=True)
    window = len(old_lines)

    best_ratio, best_start = 0.0, 0
    for i in range(max(1, len(lines) - window + 1)):
        ratio = difflib.SequenceMatcher(None, old_lines, lines[i: i + window]).ratio()
        if ratio > best_ratio:
            best_ratio, best_start = ratio, i

    if best_ratio > 0.5:
        diff = "\n".join(difflib.unified_diff(
            old_lines,
            lines[best_start: best_start + window],
            fromfile="old_text (provided)",
            tofile=f"{path} (actual, line {best_start + 1})",
            lineterm="",
        ))
        return (
            f"Error: old_text not found in {path}.\n"
            f"Best match ({best_ratio:.0%} similar) at line {best_start + 1}:\n{diff}"
        )
    return f"Error: old_text not found in {path}. No similar text found. Verify the file content."


# ---------------------------------------------------------------------------
# Tool schemas
# ---------------------------------------------------------------------------

FS_READ_SCHEMA: dict[str, Any] = {
    "name": "fs_read",
    "description": (
        "Read a file from the filesystem. Returns numbered lines. "
        "Use offset and limit to paginate through large files. "
        "Images are returned as inline content blocks."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File path to read."},
            "offset": {
                "type": "integer",
                "description": "Line number to start reading from (1-indexed, default 1).",
                "minimum": 1,
            },
            "limit": {
                "type": "integer",
                "description": f"Maximum number of lines to return (default {_DEFAULT_LIMIT}).",
                "minimum": 1,
            },
        },
        "required": ["path"],
    },
}

FS_WRITE_SCHEMA: dict[str, Any] = {
    "name": "fs_write",
    "description": "Write content to a file. Creates parent directories if needed.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File path to write to."},
            "content": {"type": "string", "description": "UTF-8 content to write."},
        },
        "required": ["path", "content"],
    },
}

FS_EDIT_SCHEMA: dict[str, Any] = {
    "name": "fs_edit",
    "description": (
        "Edit a file by replacing old_text with new_text. "
        "Supports minor whitespace/indentation differences. "
        "When old_text is not found, returns a unified diff of the closest match to help you correct it. "
        "Set replace_all=true to replace every occurrence."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File path to edit."},
            "old_text": {"type": "string", "description": "The text to find and replace."},
            "new_text": {"type": "string", "description": "The replacement text."},
            "replace_all": {
                "type": "boolean",
                "description": "Replace all occurrences instead of just the first (default false).",
            },
        },
        "required": ["path", "old_text", "new_text"],
    },
}

FS_LIST_SCHEMA: dict[str, Any] = {
    "name": "fs_list",
    "description": (
        "List directory contents. "
        "Set recursive=true to explore nested structure. "
        "Common noise directories (.git, node_modules, __pycache__, etc.) are auto-ignored."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Directory path to list."},
            "recursive": {
                "type": "boolean",
                "description": "Recursively list all entries (default false).",
            },
            "max_entries": {
                "type": "integer",
                "description": f"Maximum entries to return (default {_DEFAULT_MAX_ENTRIES}).",
                "minimum": 1,
            },
        },
        "required": ["path"],
    },
}


# ---------------------------------------------------------------------------
# Tool executor factories
# ---------------------------------------------------------------------------

def make_fs_read(backend: FilesystemBackend):
    """Return an async ``fs_read`` executor bound to *backend*."""

    async def fs_read(path: str, offset: int = 1, limit: int | None = None) -> Any:
        try:
            if not await backend.exists(path):
                return f"Error: File not found: {path}"
            if await backend.is_dir(path):
                return f"Error: '{path}' is a directory, not a file. Use fs_list to explore it."

            raw = await backend.read(path)
            if not raw:
                return f"(Empty file: {path})"

            # Image detection — return multimodal content block
            import base64 as _b64
            mime = _detect_image_mime(raw) or mimetypes.guess_type(path)[0]
            if mime and mime.startswith("image/"):
                encoded = _b64.b64encode(raw).decode()
                return [
                    {"type": "text", "text": f"(Image file: {path}, MIME: {mime})"},
                    {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{encoded}"}},
                ]

            try:
                text_content = raw.decode("utf-8")
            except UnicodeDecodeError:
                return (
                    f"Error: Cannot read binary file '{path}' (MIME: {mime or 'unknown'}). "
                    "Only UTF-8 text and images are supported."
                )

            all_lines = text_content.splitlines()
            total = len(all_lines)

            if offset < 1:
                offset = 1
            if offset > total:
                return f"Error: offset {offset} is beyond end of file ({total} lines)."

            start = offset - 1
            end = min(start + (limit or _DEFAULT_LIMIT), total)
            numbered = [f"{start + i + 1}| {line}" for i, line in enumerate(all_lines[start:end])]
            result = "\n".join(numbered)

            # Hard char limit guard
            if len(result) > _MAX_CHARS:
                trimmed, chars = [], 0
                for line in numbered:
                    chars += len(line) + 1
                    if chars > _MAX_CHARS:
                        break
                    trimmed.append(line)
                end = start + len(trimmed)
                result = "\n".join(trimmed)

            if end < total:
                result += f"\n\n(Showing lines {offset}–{end} of {total}. Use offset={end + 1} to continue.)"
            else:
                result += f"\n\n(End of file — {total} lines total)"
            return result

        except PermissionError as exc:
            return f"Error: {exc}"
        except Exception as exc:
            logger.exception("fs_read failed: path=%s", path)
            return f"Error reading file: {exc}"

    return fs_read


def make_fs_write(backend: FilesystemBackend):
    """Return an async ``fs_write`` executor bound to *backend*."""

    async def fs_write(path: str, content: str) -> str:
        try:
            await backend.write(path, content)
            return json.dumps({"status": "ok", "path": path, "bytes": len(content.encode())}, ensure_ascii=False)
        except PermissionError as exc:
            return f"Error: {exc}"
        except Exception as exc:
            logger.exception("fs_write failed: path=%s", path)
            return f"Error writing file: {exc}"

    return fs_write


def make_fs_edit(backend: FilesystemBackend):
    """Return an async ``fs_edit`` executor bound to *backend*."""

    async def fs_edit(path: str, old_text: str, new_text: str, replace_all: bool = False) -> str:
        try:
            if not await backend.exists(path):
                return f"Error: File not found: {path}"

            raw = await backend.read(path)
            uses_crlf = b"\r\n" in raw
            content = raw.decode("utf-8").replace("\r\n", "\n")

            match, count = _find_match(content, old_text.replace("\r\n", "\n"))

            if match is None:
                return _not_found_msg(old_text, content, path)

            if count > 1 and not replace_all:
                return (
                    f"Warning: old_text appears {count} times in '{path}'. "
                    "Provide more surrounding context to make it unique, or set replace_all=true."
                )

            norm_new = new_text.replace("\r\n", "\n")
            if replace_all:
                new_content = content.replace(match, norm_new)
            else:
                new_content = content.replace(match, norm_new, 1)

            if uses_crlf:
                new_content = new_content.replace("\n", "\r\n")

            await backend.write(path, new_content)
            replaced = content.count(match) if replace_all else 1
            return json.dumps({"status": "ok", "path": path, "replacements": replaced}, ensure_ascii=False)

        except PermissionError as exc:
            return f"Error: {exc}"
        except Exception as exc:
            logger.exception("fs_edit failed: path=%s", path)
            return f"Error editing file: {exc}"

    return fs_edit


def make_fs_list(backend: FilesystemBackend):
    """Return an async ``fs_list`` executor bound to *backend*."""

    async def fs_list(path: str, recursive: bool = False, max_entries: int | None = None) -> str:
        try:
            if not await backend.exists(path):
                return f"Error: Directory not found: {path}"
            if not await backend.is_dir(path):
                return f"Error: '{path}' is not a directory."

            cap = max_entries or _DEFAULT_MAX_ENTRIES

            if recursive:
                all_entries = await backend.list_dir_recursive(path)
            else:
                all_entries = await backend.list_dir(path)

            total = len(all_entries)
            shown = all_entries[:cap]

            if not shown:
                return f"(Directory '{path}' is empty)"

            result = "\n".join(shown)
            if total > cap:
                result += f"\n\n(Truncated — showing first {cap} of {total} entries)"
            return result

        except PermissionError as exc:
            return f"Error: {exc}"
        except Exception as exc:
            logger.exception("fs_list failed: path=%s", path)
            return f"Error listing directory: {exc}"

    return fs_list


# ---------------------------------------------------------------------------
# Registration helper
# ---------------------------------------------------------------------------

def register_filesystem_tools(
    registry: Any,
    backend: FilesystemBackend,
) -> None:
    """Register fs_read / fs_write / fs_edit / fs_list into *registry*.

    Parameters
    ----------
    registry:
        A :class:`ToolRegistry` instance.
    backend:
        Any :class:`FilesystemBackend` implementation — local or sandbox.
    """
    registry.register("fs_read",  FS_READ_SCHEMA,  make_fs_read(backend))
    registry.register("fs_write", FS_WRITE_SCHEMA, make_fs_write(backend))
    registry.register("fs_edit",  FS_EDIT_SCHEMA,  make_fs_edit(backend))
    registry.register("fs_list",  FS_LIST_SCHEMA,  make_fs_list(backend))
