from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

from genagent_core.artifacts.artifact_tools import artifact_read, artifact_write
from genagent_core.memory.memory_manager import MemoryManager
from genagent_core.artifacts.artifact_store import ArtifactStore
from genagent_core.infra.tool_registry.registry import ToolRegistry
from genagent_core.runtime.event_bus import EventBus
from genagent_core.runtime.events import Event, EventKind
from genagent_core.orchestration.plan_schema import Phase, Plan
logger = logging.getLogger(__name__)


def _normalize_attachments(attachments: "str | list[str] | None") -> list[str]:
    """Normalize attachments to a clean list of non-empty strings.

    Accepts a JSON string, a plain string, or a list.  Returns a deduplicated
    list of non-empty stripped strings.
    """
    if not attachments:
        return []
    if isinstance(attachments, list):
        return [str(x).strip() for x in attachments if str(x).strip()]
    raw = attachments.strip()
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return [str(x).strip() for x in parsed if str(x).strip()]
        if isinstance(parsed, str) and parsed.strip():
            return [parsed.strip()]
        return [raw]
    except Exception:
        return [raw]


FILE_WRITE_SCHEMA = {
    "name": "file_write",
    "description": "Write a work artifact (dataset/document/report/code/context_snapshot/result) into workspace storage.",
    "parameters": {
        "type": "object",
        "properties": {
            "artifact_type": {"type": "string", "enum": ["dataset", "document", "report", "code", "context_snapshot", "result"]},
            "content": {"type": "string", "description": "Content to save. For datasets use JSON string."},
            "metadata": {"type": "object", "description": "Optional metadata (e.g. dataset_type, source_url)"},
        },
        "required": ["artifact_type", "content"],
    },
}

FILE_READ_SCHEMA = {
    "name": "file_read",
    "description": (
        "Read artifacts from workspace store. task_id is optional and defaults to current task. "
        "By default returns metadata + first 2000 chars of content. "
        "Set full=true to get complete content (use sparingly to avoid context overflow)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "task_id": {"type": "string"},
            "step_id": {"type": "string"},
            "artifact_type": {"type": "string"},
            "max_content_length": {
                "type": "integer",
                "description": "Max chars of content to return per artifact (default 2000).",
            },
            "full": {
                "type": "boolean",
                "description": "If true, return full content without truncation. Use with caution.",
            },
        },
    },
}

MEMORY_QUERY_SCHEMA = {
    "name": "memory_query",
    "description": "Query workspace long-term memory for historical research data.",
    "parameters": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search keyword for memory entries"},
            "limit": {"type": "integer", "default": 5},
        },
        "required": ["query"],
    },
}


MESSAGE_NOTIFY_SCHEMA = {
    "name": "message_notify",
    "description": "Send a message to the user. Non-blocking. Two distinct use cases:\n"
                   "  progress     — Planner/Lead speaking TO the user. Tone: commitment ('I will...', '\u6211\u5c06\u4e3a\u60a8...'). Use at task start and phase milestones.\n"
                   "  status_update — Executor narrating its own internal state. Tone: process ('Currently...', '\u76ee\u524d\u6b63\u5728...'). Rendered as grey background in UI.\n"
                   "  final_reply  — Planner delivering the completed result to the user.\n"
                   "  agent_note   — Low-priority internal annotation.",
    "parameters": {
        "type": "object",
        "properties": {
            "text": {"type": "string", "description": "Message text to display to user"},
            "message_type": {
                "type": "string",
                "enum": ["progress", "status_update", "final_reply", "agent_note"],
                "description": (
                    "progress: Planner/Lead → user, commitment tone ('\u6211\u5c06\u4e3a\u60a8...'). "
                    "status_update: Executor internal narration, process tone ('\u76ee\u524d\u6b63\u5728...'). "
                    "final_reply: task completion delivery. "
                    "agent_note: low-priority annotation."
                ),
            },
            "attachments": {
                "anyOf": [
                    {"type": "string"},
                    {"type": "array", "items": {"type": "string"}},
                ],
                "description": "Optional deliverable references (artifact ids, file paths, or URLs).",
            },
        },
        "required": ["text"],
    },
}

MESSAGE_ASK_SCHEMA = {
    "name": "message_ask",
    "description": "Ask user for clarification. This is blocking and should be used only when essential.",
    "parameters": {
        "type": "object",
        "properties": {
            "text": {"type": "string", "description": "Question text to present to user"},
            "attachments": {
                "anyOf": [
                    {"type": "string"},
                    {"type": "array", "items": {"type": "string"}},
                ],
                "description": "Optional references attached to the question.",
            },
        },
        "required": ["text"],
    },
}

IDLE_SCHEMA = {
    "name": "idle",
    "description": "Signal that current task is complete. Call this when all work is done.",
    "parameters": {
        "type": "object",
        "properties": {
            "reason": {"type": "string", "description": "Brief explanation of completion"},
        },
    },
}

# ──# ─────────────────────────────────────────────────────────────────────────
# NEW: submit_plan — Planner's first tool call, creates the active Plan
# ─────────────────────────────────────────────────────────────────────────
SUBMIT_PLAN_SCHEMA = {
    "name": "submit_plan",
    "description": (
        "Planner MUST call this as the very first tool call to produce a structured Plan. "
        "Defines the phases the Planner intends to execute. "
        "After calling submit_plan, proceed to execute phases one by one using spawn_subagent."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "phases": {
                "type": "array",
                "description": "Ordered list of phases. 2\u20136 phases recommended.",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "description": "Short unique id, e.g. 'p1', 'p2'"},
                        "title": {"type": "string", "description": "User-visible phase title (\u226450 chars)"},
                        "role": {"type": "string", "description": "Optional label for logging/observability only. e.g. 'executor', 'research', 'analyze'"},
                        "description": {"type": "string", "description": "Detailed goal for the Executor"},
                    },
                    "required": ["id", "title"],
                },
            },
        },
        "required": ["phases"],
    },
}

UPDATE_PLAN_SCHEMA = {
    "name": "update_plan",
    "description": (
        "Dynamically modify the active Plan during execution. "
        "Use when: (1) an Executor's next_suggestions reveal new necessary steps, "
        "(2) a phase turns out to be unnecessary, "
        "(3) the goal has been clarified and phases need adjustment. "
        "Can only modify PENDING phases."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["add_phase", "remove_phase", "update_title"],
                "description": "Type of modification",
            },
            "phase_id": {
                "type": "string",
                "description": "Target phase id (required for remove_phase and update_title)",
            },
            "after_id": {
                "type": "string",
                "description": "Insert new phase after this phase id (for add_phase, null = append)",
            },
            "phase": {
                "type": "object",
                "description": "New phase definition (required for add_phase)",
                "properties": {
                    "id": {"type": "string"},
                    "title": {"type": "string"},
                    "role": {"type": "string", "description": "Optional label for logging/observability only."},
                    "description": {"type": "string"},
                },
            },
            "new_title": {
                "type": "string",
                "description": "New title for the phase (required for update_title)",
            },
            "reason": {
                "type": "string",
                "description": "Why this modification is needed",
            },
        },
        "required": ["action"],
    },
}

# ─────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# NEW: submit_results — Executor Agent's standard result submission tool
# ─────────────────────────────────────────────────────────────────────────────
SUBMIT_RESULTS_SCHEMA = {
    "name": "submit_results",
    "description": (
        "Submit the structured results of this sub-task back to the Planner. "
        "This is the ONLY way to return results from an Executor Agent. "
        "Call this BEFORE idle to ensure results are captured. "
        "The payload must conform to the output_schema defined by the Planner."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "payload": {
                "type": "object",
                "description": "Structured result data conforming to the output_schema defined by the Planner.",
            },
            "status": {
                "type": "string",
                "enum": ["success", "partial", "failure"],
                "description": "Execution status: success (all done), partial (some done), failure (blocked).",
            },
            "summary": {
                "type": "string",
                "description": "Brief human-readable summary of what was accomplished.",
            },
            "step_results": {
                "type": "array",
                "description": (
                    "REQUIRED when the Planner provided steps[] in spawn_subagent. "
                    "Report back one entry per step with matching id. "
                    "This enables per-step observability, retry, and progress tracking. "
                    "Example: [{\"id\": \"s1\", \"status\": \"done\", \"output\": \"Found 15 price points\"}]"
                ),
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "string",
                            "description": "Must match the step id from spawn_subagent steps[]."
                        },
                        "status": {
                            "type": "string",
                            "enum": ["done", "failed", "skipped"],
                            "description": "Final status of this step."
                        },
                        "output": {
                            "type": "string",
                            "description": "Brief summary of what this step produced or found."
                        },
                        "reason": {
                            "type": "string",
                            "description": "Reason for failure or skip, if applicable."
                        },
                    },
                    "required": ["id", "status"]
                },
                "minItems": 1,
            },
        },
        "required": ["payload", "status"],
    },
}

# ─────────────────────────────────────────────────────────────────────────────
# spawn_subagent — Planner dispatches Executor Sub-agents
# ─────────────────────────────────────────────────────────────────────────────
SPAWN_SUBAGENT_SCHEMA = {
    "name": "spawn_subagent",
    "description": (
        "Fork a generic Executor Sub-agent to handle a specific phase of the plan. "
        "The sub-agent runs to completion, writes results via submit_results, and returns. "
        "All Executors are generic Manus instances with a full toolbox — no specialist roles. "
        "ARCHITECTURE: This implements the LOCAL (micro) layer of the two-tier planning model. "
        "  - GLOBAL (macro): submit_plan produces phases[] + todo[] for the full task. "
        "  - LOCAL (micro): spawn_subagent produces steps[] for each individual sub-agent. "
        "STRONGLY RECOMMENDED: Always provide steps[] with id/action/status=pending. "
        "The Executor will report step_results[] in submit_results, enabling per-step "
        "observability, retry, and progress tracking. "
        "NOTE: This tool is for Planner Agent use only."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "goal": {
                "type": "string",
                "description": "Specific goal for the Executor Sub-agent. Be as detailed as possible.",
            },
            "role": {
                "type": "string",
                "description": (
                    "Executor role label — used for logging and observability only. "
                    "All executors are generic Manus instances with a full toolbox. "
                    "Suggested values: 'executor', 'research', 'analyze', 'write', 'scrape'."
                ),
            },
            "parallel": {
                "type": "boolean",
                "description": (
                    "If true, this spawn call is part of a parallel batch. "
                    "Use spawn_parallel() to dispatch multiple executors concurrently. "
                    "When false (default), this executor runs sequentially."
                ),
            },
            "output_schema": {
                "type": "object",
                "description": "Required output contract. Executor must call submit_results with payload matching this schema.",
            },

            "steps": {
                "type": "array",
                "description": (
                    "Structured micro-steps for the sub-agent to execute. Each step has a unique id, "
                    "a concrete action description, and an initial status of 'pending'. "
                    "The Executor MUST report back step_results[] in submit_results with matching ids. "
                    "Example: [{\"id\": \"s1\", \"action\": \"Search Xiaohongshu pricing\", \"status\": \"pending\"}]"
                ),
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "string",
                            "description": "Unique step identifier, e.g. 's1', 's2'. Used to match step_results."
                        },
                        "action": {
                            "type": "string",
                            "description": "Concrete action description for this step."
                        },
                        "status": {
                            "type": "string",
                            "enum": ["pending", "running", "done", "failed"],
                            "description": "Initial value MUST be 'pending'. Executor updates to done/failed in step_results."
                        }
                    },
                    "required": ["id", "action", "status"]
                },
                "minItems": 1,
            },
        },
        "required": ["goal", "role", "steps"],
    },
}



# ─────────────────────────────────────────────────────────────────────────────
# spawn_parallel — dispatch multiple Executors concurrently
# ─────────────────────────────────────────────────────────────────────────────
SPAWN_PARALLEL_SCHEMA = {
    "name": "spawn_parallel",
    "description": (
        "Dispatch multiple Executor Sub-agents concurrently using asyncio.gather. "
        "All executors start at the same time and results are returned when all complete. "
        "Use this when phases are independent and can run in parallel. "
        "Each item in 'agents' is a spawn_subagent call spec (goal, role, steps, output_schema). "
        "Returns a list of results in the same order as the input agents array."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "agents": {
                "type": "array",
                "description": "List of executor specs to run in parallel. Each item has goal, role, steps, output_schema.",
                "items": {
                    "type": "object",
                    "properties": {
                        "goal": {"type": "string", "description": "Goal for this executor."},
                        "role": {"type": "string", "description": "Role label for logging."},
                        "steps": {
                            "type": "array",
                            "description": "Micro-steps for this executor.",
                            "items": {"type": "object"},
                        },
                        "output_schema": {"type": "object", "description": "Expected output schema."},
                    },
                    "required": ["goal", "role", "steps"],
                },
                "minItems": 2,
            },
        },
        "required": ["agents"],
    },
}
def _validate_schema(value: Any, schema: dict[str, Any], path: str = "$") -> list[str]:
    errors: list[str] = []
    expected_type = schema.get("type")
    if expected_type == "object":
        if not isinstance(value, dict):
            return [f"{path}: expected object"]
        required = schema.get("required", [])
        for key in required:
            if key not in value:
                errors.append(f"{path}.{key}: missing required field")
        props = schema.get("properties", {})
        if isinstance(props, dict):
            for key, sub in props.items():
                if key in value and isinstance(sub, dict):
                    errors.extend(_validate_schema(value[key], sub, f"{path}.{key}"))
    elif expected_type == "array":
        if not isinstance(value, list):
            return [f"{path}: expected array"]
        min_items = schema.get("minItems")
        if isinstance(min_items, int) and len(value) < min_items:
            errors.append(f"{path}: expected at least {min_items} items")
        max_items = schema.get("maxItems")
        if isinstance(max_items, int) and len(value) > max_items:
            errors.append(f"{path}: expected at most {max_items} items")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for i, item in enumerate(value):
                errors.extend(_validate_schema(item, item_schema, f"{path}[{i}]"))
    elif expected_type == "string":
        if not isinstance(value, str):
            errors.append(f"{path}: expected string")
        else:
            min_len = schema.get("minLength")
            if isinstance(min_len, int) and len(value) < min_len:
                errors.append(f"{path}: expected length >= {min_len}")
            max_len = schema.get("maxLength")
            if isinstance(max_len, int) and len(value) > max_len:
                errors.append(f"{path}: expected length <= {max_len}")
    elif expected_type == "number":
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            errors.append(f"{path}: expected number")
        else:
            minimum = schema.get("minimum")
            if isinstance(minimum, (int, float)) and value < minimum:
                errors.append(f"{path}: expected >= {minimum}")
            maximum = schema.get("maximum")
            if isinstance(maximum, (int, float)) and value > maximum:
                errors.append(f"{path}: expected <= {maximum}")
    elif expected_type == "integer":
        if not isinstance(value, int) or isinstance(value, bool):
            errors.append(f"{path}: expected integer")
        else:
            minimum = schema.get("minimum")
            if isinstance(minimum, int) and value < minimum:
                errors.append(f"{path}: expected >= {minimum}")
            maximum = schema.get("maximum")
            if isinstance(maximum, int) and value > maximum:
                errors.append(f"{path}: expected <= {maximum}")
    elif expected_type == "boolean":
        if not isinstance(value, bool):
            errors.append(f"{path}: expected boolean")
    enum_vals = schema.get("enum")
    if isinstance(enum_vals, list) and value not in enum_vals:
        errors.append(f"{path}: value {value!r} not in enum")
    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: expected const value {schema['const']!r}")
    return errors
def register_system_tools(
    registry: ToolRegistry,
    artifact_store: ArtifactStore,
    memory_manager: MemoryManager,
    workspace_id: str,
    task_id: str,
    step_id: str,
    producer: str,
    notify_callback: Callable[[str, str, str, list[str] | None, str], None] | None = None,
    event_bus: EventBus | None = None,
    spawn_callback: Callable | None = None,
    expected_output_schema: dict | None = None,
    submit_state: dict | None = None,
    plan_state: dict | None = None,  # NEW: holds the active Plan for Planner agents
    workspace_state: "Any | None" = None,  # WorkspaceState 引用，用于 Artifact Memory 自动注册
    todo_writer: Callable[[str], None] | None = None,  # NEW: 回调用于写入 task_plan.md
    todo_updater: Callable[[str, str, dict | None], None] | None = None,  # NEW: 回调用于更新 task_plan.md 中的 step 状态
    step_marker_writer: Callable[[str], None] | None = None,  # NEW: 回调用于写入 step 标记文件
) -> None:
    current_task_id = task_id
    submit_state_ref = submit_state if submit_state is not None else {}
    submit_state_ref.setdefault("submitted", False)
    submit_state_ref.setdefault("payload", None)
    submit_state_ref.setdefault("errors", [])
    plan_state_ref = plan_state if plan_state is not None else {}

    async def file_write_fn(artifact_type: str, content: str, metadata: dict | None = None) -> str:
        result_json = artifact_write(
            artifact_store=artifact_store,
            workspace_id=workspace_id,
            task_id=task_id,
            step_id=step_id,
            producer=producer,
            artifact_type=artifact_type,
            content=content,
            metadata=metadata,
        )
        result_data = json.loads(result_json)
        artifact_id = result_data.get("artifact_id", "")

        # ── Artifact Memory 自动注册 ───────────────────────────────────────────
        # When a WorkspaceState is provided (Executor context), automatically
        # register the new artifact so the Planner snapshot reflects it
        # immediately — without waiting for the _spawn_callback to do so.
        if workspace_state is not None and artifact_id:
            try:
                workspace_state.register_artifact(
                    artifact_id=artifact_id,
                    artifact_type=artifact_type,
                    producer=producer,
                    summary=(
                        (metadata or {}).get("summary")
                        or content[:120].replace("\n", " ")
                    ),
                    step_id=step_id,
                )
            except Exception:
                logger.debug(
                    "workspace_state.register_artifact failed for %s", artifact_id,
                    exc_info=True,
                )
        # ──────────────────────────────────────────────────────────────────────

        if event_bus:
            await event_bus.emit(Event(
                kind=EventKind.ARTIFACT_PRODUCED,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "artifact_id": artifact_id,
                    "step_id": step_id,
                    "artifact_type": artifact_type,
                    "producer": producer,
                },
                source=producer,
            ))
        return result_json

    async def file_read_fn(
        task_id: str = "", step_id: str = "", artifact_type: str = "",
        max_content_length: int = 2000, full: bool = False,
    ) -> str:
        resolved_task_id = (task_id or "").strip()
        if not resolved_task_id:
            resolved_task_id = current_task_id
        # Security: reject task_ids that don't look like real task IDs to
        # prevent prompt-injection attempts at reading arbitrary artifacts
        if not resolved_task_id.startswith("task_"):
            resolved_task_id = current_task_id
        return artifact_read(
            artifact_store=artifact_store,
            task_id=resolved_task_id or None,
            step_id=step_id or None,
            artifact_type=artifact_type or None,
            max_content_length=max_content_length,
            full=full,
            workspace_id=workspace_id,  # enforce workspace isolation
        )

    async def memory_query(query: str, limit: int = 5) -> str:
        return await memory_manager.query(query=query, limit=limit)

    async def message_notify(
        text: str,
        message_type: str = "progress",
        attachments: str | list[str] | None = None,
    ) -> str:
        logger.info("[%s/%s] Agent notify: %s", workspace_id, step_id, text[:200])
        normalized_attachments = _normalize_attachments(attachments)
        if notify_callback:
            try:
                await notify_callback(
                    workspace_id,
                    task_id,
                    text,
                    normalized_attachments or None,
                    message_type,
                )
            except Exception:
                pass
        return json.dumps(
            {"status": "notified", "attachments": normalized_attachments, "message_type": message_type},
            ensure_ascii=False,
        )

    async def message_ask(text: str, attachments: str | list[str] | None = None) -> str:
        logger.info("[%s/%s] Agent ask: %s", workspace_id, step_id, text[:200])
        normalized_attachments = _normalize_attachments(attachments)
        if notify_callback:
            try:
                await notify_callback(workspace_id, task_id, text, normalized_attachments or None, "progress")
            except Exception:
                pass
        return json.dumps({"status": "asked", "attachments": normalized_attachments}, ensure_ascii=False)

    async def idle(reason: str = "") -> str:
        return json.dumps({"status": "idle", "reason": reason}, ensure_ascii=False)

    # ─────────────────────────────────────────────────────────────────────────
    # NEW: submit_plan — Planner's first tool call, creates the active Plan
    # ─────────────────────────────────────────────────────────────────────────

    async def submit_plan_fn(phases: list) -> str:
        """Planner 第一轮调用：产出结构化 Plan，存入 plan_state_ref。"""
        if not phases:
            return json.dumps({"error": "phases must not be empty"}, ensure_ascii=False)

        phase_objects = [
            Phase(
                id=p.get("id", f"p{i+1}"),
                title=p.get("title", p.get("description", f"Phase {i+1}"))[:100],
                description=p.get("description", ""),
                role=p.get("role", "research"),
            )
            for i, p in enumerate(phases)
        ]
        plan_goal = plan_state_ref.get("goal", step_id)
        plan_obj = Plan(goal=plan_goal, phases=phase_objects)
        plan_state_ref["plan"] = plan_obj
        plan_state_ref["submitted"] = True

        logger.info(
            "[%s/%s] submit_plan: %d phases created",
            workspace_id, step_id, len(phase_objects),
        )

        if event_bus:
            await event_bus.emit(Event(
                kind=EventKind.PLAN_PROPOSED,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "plan": plan_obj.to_dict(),
                    "phase_count": len(phase_objects),
                    "progress_panel": plan_obj.render_progress(),
                },
                source=producer,
            ))

        # 写入初始 task_plan.md
        if todo_writer:
            todo_lines = [
                f"# Task Plan: {plan_goal}",
                "",
                "## Goal",
                plan_goal,
                "",
                "## Current Phase",
                "Phase 1",
                "",
                "## Phases",
                ""
            ]
            for i, p in enumerate(phase_objects):
                # 写入 Phase 标题，不带打勾，隐藏内部 ID
                todo_lines.append(f"### Phase {i+1}: {p.title} <!-- id:{p.id} -->")
                todo_lines.append("- **Status:** pending")
                todo_lines.append("")
            
            todo_lines.extend([
                "## Errors Encountered",
                "| Error | Attempt | Resolution |",
                "|-------|---------|------------|",
                ""
            ])
            
            todo_content = "\n".join(todo_lines)
            try:
                if asyncio.iscoroutinefunction(todo_writer):
                    await todo_writer(todo_content)
                else:
                    todo_writer(todo_content)
            except Exception as e:
                logger.warning("Failed to write task_plan.md: %s", e)

        return json.dumps({
            "status": "plan_created",
            "phase_count": len(phase_objects),
            "phases": [{"id": p.id, "title": p.title, "role": p.role} for p in phase_objects],
            "message": "Plan created. Now execute phases in order using spawn_subagent. After each phase completes, call update_plan if adjustments are needed.",
        }, ensure_ascii=False)

    # ─────────────────────────────────────────────────────────────────────────
    # NEW: update_plan — dynamically modify the active Plan
    # ─────────────────────────────────────────────────────────────────────────

    async def update_plan_fn(
        action: str,
        phase_id: str = "",
        after_id: str | None = None,
        phase: dict | None = None,
        new_title: str = "",
        reason: str = "",
    ) -> str:
        """Planner 执行中动态修改活 Plan。"""
        active_plan: Plan | None = plan_state_ref.get("plan")
        if active_plan is None:
            return json.dumps({"error": "No active plan. Call submit_plan first."}, ensure_ascii=False)

        if action == "add_phase":
            if not phase:
                return json.dumps({"error": "phase dict required for add_phase"}, ensure_ascii=False)
            new_phase = Phase(
                id=phase.get("id", f"p_extra_{len(active_plan.phases)+1}"),
                title=phase.get("title", phase.get("description", "New Phase"))[:100],
                description=phase.get("description", ""),
                role=phase.get("role", "research"),
            )
            active_plan.add_phase(new_phase, after_id=after_id or None)
            op_result = {"status": "added", "phase_id": new_phase.id, "title": new_phase.title}

        elif action == "remove_phase":
            if not phase_id:
                return json.dumps({"error": "phase_id required for remove_phase"}, ensure_ascii=False)
            ok = active_plan.remove_phase(phase_id)
            op_result = {
                "status": "removed" if ok else "failed",
                "phase_id": phase_id,
                "message": "" if ok else "Phase not found or not in pending status",
            }

        elif action == "update_title":
            if not phase_id or not new_title:
                return json.dumps({"error": "phase_id and new_title required"}, ensure_ascii=False)
            ok = active_plan.update_phase_title(phase_id, new_title)
            op_result = {"status": "updated" if ok else "failed", "phase_id": phase_id}

        else:
            return json.dumps({"error": f"Unknown action: {action}"}, ensure_ascii=False)

        done, total = active_plan.progress()
        op_result["progress"] = f"{done}/{total}"
        op_result["reason"] = reason

        logger.info(
            "[%s/%s] update_plan: action=%s phase_id=%s reason=%s",
            workspace_id, step_id, action, phase_id, reason[:60],
        )

        if event_bus:
            await event_bus.emit(Event(
                kind=EventKind.PLAN_ACCEPTED,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "action": action,
                    "phase_id": phase_id,
                    "reason": reason[:200],
                    "progress_panel": active_plan.render_progress(),
                    "plan": active_plan.to_dict(),
                },
                source=producer,
            ))

        return json.dumps(op_result, ensure_ascii=False)



    # ─────────────────────────────────────────────────────────────────────────
    # NEW: submit_results — Executor Agent's standard result submission
    # ─────────────────────────────────────────────────────────────────────────
    async def submit_results_fn(
        payload,
        status: str = "success",
        summary: str = "",
        step_results: list | None = None,
    ) -> str:
        # Coerce payload to dict: model sometimes emits Python dict literals
        # (single-quoted strings) instead of valid JSON objects.
        import ast as _ast
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except (json.JSONDecodeError, ValueError):
                try:
                    payload = _ast.literal_eval(payload)
                except Exception:
                    payload = {"_raw": payload}
        if not isinstance(payload, dict):
            payload = {"_raw": str(payload)}

        # Normalise step_results: coerce string items to structured dicts
        normalised_step_results: list[dict] = []
        if step_results:
            for i, sr in enumerate(step_results):
                if isinstance(sr, str):
                    normalised_step_results.append({"id": f"s{i+1}", "status": "done", "output": sr})
                elif isinstance(sr, dict):
                    sr.setdefault("id", f"s{i+1}")
                    sr.setdefault("status", "done")
                    normalised_step_results.append(sr)

        logger.info(
            "[%s/%s] submit_results: status=%s steps=%d summary=%s",
            workspace_id, step_id, status, len(normalised_step_results), summary[:100],
        )
        # Validate against expected_output_schema if provided
        errors: list[str] = []
        if expected_output_schema:
            errors = _validate_schema(payload, expected_output_schema)
            if errors:
                logger.warning(
                    "[%s/%s] submit_results schema validation failed: %s",
                    workspace_id, step_id, errors,
                )

        # Persist result as a RESULT artifact so Planner can retrieve it via file_read
        result_record = {
            "status": status,
            "summary": summary,
            "payload": payload,
            "schema_errors": errors,
            "step_id": step_id,
            "producer": producer,
            # Two-tier model: micro-level step results for observability & retry
            "step_results": normalised_step_results,
        }
        result_content = json.dumps(result_record, ensure_ascii=False, indent=2)
        result_json = artifact_write(
            artifact_store=artifact_store,
            workspace_id=workspace_id,
            task_id=task_id,
            step_id=step_id,
            producer=producer,
            artifact_type="result",
            content=result_content,
            metadata={
                "submit_status": status,
                "summary": summary[:200],
                "has_schema_errors": bool(errors),
                "step_count": len(normalised_step_results),
                "steps_done": sum(1 for sr in normalised_step_results if sr.get("status") == "done"),
                "steps_failed": sum(1 for sr in normalised_step_results if sr.get("status") == "failed"),
            },
        )
        result_data = json.loads(result_json)
        artifact_id = result_data.get("artifact_id", "")

        # Do not mark as submitted if validation failed

        if errors:
            submit_state_ref["submitted"] = False
        else:
            submit_state_ref["submitted"] = True
        submit_state_ref["payload"] = payload
        submit_state_ref["errors"] = errors
        submit_state_ref["artifact_id"] = artifact_id
        submit_state_ref["status"] = status
        submit_state_ref["step_results"] = normalised_step_results

        # 写入 step 标记文件，用于 Executor 级别的断点续跑
        if step_marker_writer:
            for sr in normalised_step_results:
                if sr.get("status") == "done":
                    sid = sr.get("id")
                    if sid:
                        try:
                            if asyncio.iscoroutinefunction(step_marker_writer):
                                await step_marker_writer(sid)
                            else:
                                step_marker_writer(sid)
                        except Exception as e:
                            logger.warning("Failed to write step marker for %s: %s", sid, e)
                            
        # 更新 task_plan.md 中的 step 状态
        if todo_updater:
            for sr in normalised_step_results:
                status = sr.get("status")
                if status in ("done", "failed"):
                    sid = sr.get("id")
                    if sid:
                        try:
                            if asyncio.iscoroutinefunction(todo_updater):
                                await todo_updater(sid, status, sr)
                            else:
                                todo_updater(sid, status, sr)
                        except Exception as e:
                            logger.warning("Failed to update task_plan.md step status for %s: %s", sid, e)


        if event_bus:
            # Emit aggregate result event
            await event_bus.emit(Event(
                kind=EventKind.ARTIFACT_PRODUCED,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "artifact_id": artifact_id,
                    "step_id": step_id,
                    "artifact_type": "result",
                    "producer": producer,
                    "submit_status": status,
                    "step_count": len(normalised_step_results),
                },
                source=producer,
            ))
            # Emit individual step_done / step_failed events for per-step observability
            for sr in normalised_step_results:
                await event_bus.emit(Event(
                    kind=EventKind.TOOL_RESULT,
                    task_id=task_id,
                    workspace_id=workspace_id,
                    payload={
                        "step_id": sr.get("id", ""),
                        "status": sr.get("status", "unknown"),
                        "output": sr.get("output", "")[:200],
                        "reason": sr.get("reason", ""),
                        "producer": producer,
                    },
                    source=f"step_result:{producer}",
                ))

        if errors:
            return json.dumps({
                "error": "schema_validation_failed",
                "details": errors,
                "hint": "Result not submitted. The provided payload does not match the expected output schema. Please correct the payload and call submit_results again.",
            }, ensure_ascii=False)

        # Build step summary for return value
        steps_summary = ""
        if normalised_step_results:
            done_ids = [sr["id"] for sr in normalised_step_results if sr.get("status") == "done"]
            failed_ids = [sr["id"] for sr in normalised_step_results if sr.get("status") == "failed"]
            skipped_ids = [sr["id"] for sr in normalised_step_results if sr.get("status") == "skipped"]
            steps_summary = f"{len(done_ids)} done, {len(failed_ids)} failed, {len(skipped_ids)} skipped"

        return json.dumps({
            "status": "submitted",
            "artifact_id": artifact_id,
            "steps_summary": steps_summary,
            "message": "Results successfully submitted. Call idle() to complete this sub-task.",
        }, ensure_ascii=False)

    # ─────────────────────────────────────────────────────────────────────────
    # spawn_subagent — Planner dispatches a single Executor sequentially
    # ─────────────────────────────────────────────────────────────────────────
    async def spawn_subagent_fn(
        goal: str,
        role: str,
        steps: list | None = None,
        output_schema: dict | None = None,
    ) -> str:
        # Normalise steps: coerce string items to structured dicts
        normalised_steps: list[dict] = []
        if steps:
            for i, s in enumerate(steps):
                if isinstance(s, str):
                    normalised_steps.append({"id": f"s{i+1}", "action": s, "status": "pending"})
                elif isinstance(s, dict):
                    s.setdefault("id", f"s{i+1}")
                    s.setdefault("status", "pending")
                    normalised_steps.append(s)

        logger.info(
            "[%s/%s] Spawning executor subagent: role=%s goal=%s steps=%d",
            workspace_id, step_id, role, goal[:100], len(normalised_steps),
        )

        # Emit step-level observability events (one per step, status=pending)
        if event_bus and normalised_steps:
            for s in normalised_steps:
                await event_bus.emit(Event(
                    kind=EventKind.TOOL_CALLED,
                    task_id=task_id,
                    workspace_id=workspace_id,
                    payload={
                        "step_id": s["id"],
                        "action": s.get("action", ""),
                        "status": "pending",
                        "role": role,
                        "parent_phase": step_id,
                    },
                    source=f"planner_steps:{producer}",
                ))

        effective_schema = output_schema or None
        if spawn_callback:
            result = await spawn_callback(
                workspace_id, task_id, goal, role, effective_schema,
                steps=normalised_steps or None,
            )
            # Emit step_done events from step_results returned by executor
            if event_bus and isinstance(result, dict):
                for sr in result.get("step_results", []):
                    if not isinstance(sr, dict):
                        continue
                    await event_bus.emit(Event(
                        kind=EventKind.TOOL_RESULT,
                        task_id=task_id,
                        workspace_id=workspace_id,
                        payload={
                            "step_id": sr.get("id", ""),
                            "status": sr.get("status", "unknown"),
                            "output": sr.get("output", "")[:200],
                            "reason": sr.get("reason", ""),
                            "role": role,
                        },
                        source=f"planner_steps:{producer}",
                    ))
            return json.dumps(result, ensure_ascii=False)
        return json.dumps({"error": "spawn not available"}, ensure_ascii=False)

    # ─────────────────────────────────────────────────────────────────────────
    # spawn_parallel — concurrent Executor dispatch
    # ─────────────────────────────────────────────────────────────────────────
    async def spawn_parallel_fn(agents: list) -> str:
        """Dispatch multiple Executors concurrently via asyncio.gather."""
        if not agents or not spawn_callback:
            return json.dumps({"error": "no agents or spawn not available"}, ensure_ascii=False)

        async def _one(spec: dict) -> dict:
            goal_i = spec.get("goal", "")
            role_i = spec.get("role", "executor")
            steps_i = spec.get("steps") or []
            schema_i = spec.get("output_schema")
            # Normalise steps
            normalised: list[dict] = []
            for idx, s in enumerate(steps_i):
                if isinstance(s, str):
                    normalised.append({"id": f"s{idx+1}", "action": s, "status": "pending"})
                elif isinstance(s, dict):
                    s.setdefault("id", f"s{idx+1}")
                    s.setdefault("status", "pending")
                    normalised.append(s)
            logger.info(
                "[%s/%s] spawn_parallel: role=%s goal=%s",
                workspace_id, step_id, role_i, goal_i[:80],
            )
            return await spawn_callback(
                workspace_id, task_id, goal_i, role_i, schema_i,
                steps=normalised or None,
            )

        results = await asyncio.gather(*[_one(spec) for spec in agents], return_exceptions=True)
        output = []
        for i, r in enumerate(results):
            if isinstance(r, Exception):
                output.append({
                    "index": i,
                    "status": "error",
                    "error": str(r),
                })
            else:
                output.append({"index": i, **r})
        return json.dumps(output, ensure_ascii=False)

    # ─────────────────────────────────────────────────────────────────────────
    # Register all tools
    # ─────────────────────────────────────────────────────────────────────────
    registry.register("submit_results", SUBMIT_RESULTS_SCHEMA, submit_results_fn)
    registry.register("submit_plan", SUBMIT_PLAN_SCHEMA, submit_plan_fn)
    registry.register("update_plan", UPDATE_PLAN_SCHEMA, update_plan_fn)
    registry.register("spawn_subagent", SPAWN_SUBAGENT_SCHEMA, spawn_subagent_fn)
    registry.register("spawn_parallel", SPAWN_PARALLEL_SCHEMA, spawn_parallel_fn)
    registry.register("file_write", FILE_WRITE_SCHEMA, file_write_fn)
    registry.register("file_read", FILE_READ_SCHEMA, file_read_fn)
    registry.register("memory_query", MEMORY_QUERY_SCHEMA, memory_query)
    registry.register("message_notify", MESSAGE_NOTIFY_SCHEMA, message_notify)
    registry.register("message_ask", MESSAGE_ASK_SCHEMA, message_ask)
    registry.register("idle", IDLE_SCHEMA, idle)
