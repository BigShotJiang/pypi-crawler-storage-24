"""Workflow tool registration — pure adapter layer.

This module is responsible **only** for:
1. Defining the JSON schemas that describe each tool to the LLM.
2. Parsing the arguments supplied by the LLM.
3. Delegating to the injected :class:`~src.services.search_service.SearchService`
   or :class:`~src.sandbox.e2b_desktop_provider.DesktopSandboxProvider`.
4. Serialising results to JSON strings.

**No business logic lives here.**  All search provider selection, HTTP
calls, result normalisation, and deduplication are handled by
:mod:`src.services.search_service`.  All desktop interactions are handled
by :mod:`src.sandbox.e2b_desktop_provider`.

Dependency flow
---------------
::

    config.json
        └─► SearchService (src/services/search_service.py)
        └─► DesktopSandboxProvider (src/sandbox/e2b_desktop_provider.py)
                └─► register_workflow_tools()
                        └─► ToolRegistry
                                └─► ManusAgent / LLM
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Optional

from genagent_core.infra.tool_registry.registry import ToolRegistry
from genagent_core.services.search_service import SearchService, _dedupe_keep_order

if TYPE_CHECKING:
    from genagent_core.sandbox.e2b_desktop_provider import DesktopSandboxProvider

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tool JSON schemas (LLM-facing contracts — no logic, just shape)
# ---------------------------------------------------------------------------

WEB_SEARCH_SCHEMA = {
    "name": "web_search",
    "description": (
        "Search public web for information. "
        "Use `query` for a single search (returns up to 5 results by default), "
        "or `queries` for multiple parallel keyword searches."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query string"},
            "queries": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional parallel search queries with different keywords.",
            },
        },
    },
}

BROWSER_NAVIGATE_SCHEMA = {
    "name": "browser_navigate",
    "description": "Open a URL in the desktop browser.",
    "parameters": {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "URL to open"},
        },
        "required": ["url"],
    },
}

BROWSER_VIEW_SCHEMA = {
    "name": "browser_view",
    "description": "Take a screenshot of the current desktop state and return it as base64 PNG.",
    "parameters": {
        "type": "object",
        "properties": {
            "full": {"type": "boolean", "description": "Unused; kept for compatibility."},
        },
    },
}

BROWSER_CLICK_SCHEMA = {
    "name": "browser_click",
    "description": "Left-click at the given (x, y) pixel coordinates on the desktop.",
    "parameters": {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "Horizontal pixel coordinate"},
            "y": {"type": "integer", "description": "Vertical pixel coordinate"},
        },
        "required": ["x", "y"],
    },
}

BROWSER_TYPE_SCHEMA = {
    "name": "browser_type",
    "description": "Type text at the current cursor position on the desktop.",
    "parameters": {
        "type": "object",
        "properties": {
            "text": {"type": "string", "description": "Text to type"},
        },
        "required": ["text"],
    },
}

BROWSER_SCROLL_SCHEMA = {
    "name": "browser_scroll",
    "description": "Scroll the mouse wheel on the desktop.",
    "parameters": {
        "type": "object",
        "properties": {
            "direction": {
                "type": "string",
                "enum": ["up", "down"],
                "description": "Scroll direction",
            },
            "amount": {
                "type": "integer",
                "description": "Number of scroll steps (default 3)",
            },
        },
    },
}

BROWSER_SCREENSHOT_SCHEMA = {
    "name": "browser_screenshot",
    "description": "Take a screenshot of the current desktop and return base64-encoded PNG.",
    "parameters": {"type": "object", "properties": {}},
}

BROWSER_CLOSE_SCHEMA = {
    "name": "browser_close",
    "description": "Close the active window on the desktop.",
    "parameters": {"type": "object", "properties": {}},
}

BROWSER_KEY_SCHEMA = {
    "name": "browser_key",
    "description": (
        "Press a key or key combination on the desktop. "
        "Examples: 'enter', 'ctrl+c', 'alt+F4', 'escape'."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "key": {"type": "string", "description": "Key or combination to press"},
        },
        "required": ["key"],
    },
}

BROWSER_DRAG_SCHEMA = {
    "name": "browser_drag",
    "description": "Drag the mouse from (from_x, from_y) to (to_x, to_y) on the desktop.",
    "parameters": {
        "type": "object",
        "properties": {
            "from_x": {"type": "integer"},
            "from_y": {"type": "integer"},
            "to_x":   {"type": "integer"},
            "to_y":   {"type": "integer"},
        },
        "required": ["from_x", "from_y", "to_x", "to_y"],
    },
}


# ---------------------------------------------------------------------------
# Registration function — adapter only, zero business logic
# ---------------------------------------------------------------------------

def register_workflow_tools(
    registry: ToolRegistry,
    search_service: SearchService | None = None,
    # Kept for backward compatibility; ignored when search_service is provided
    search_config: dict | None = None,
    # Desktop sandbox provider for computer-use / browser automation
    desktop_provider: Optional["DesktopSandboxProvider"] = None,
    session_id: str = "",
) -> None:
    """Register workflow tools into *registry*.

    Parameters
    ----------
    registry:
        The tool registry to add tools to.
    search_service:
        A pre-constructed :class:`~src.services.search_service.SearchService`
        instance.  Preferred injection point.
    search_config:
        Raw config dict used **only** when *search_service* is not provided.
        Deprecated: prefer passing a ``SearchService`` directly.
    desktop_provider:
        An optional :class:`~src.sandbox.e2b_desktop_provider.DesktopSandboxProvider`
        instance.  When provided, all ``browser_*`` tools delegate to the live
        E2B Desktop sandbox.  When ``None``, browser tools return a
        ``not_enabled`` stub response.
    session_id:
        The sandbox session ID to use for desktop operations.  Required when
        *desktop_provider* is provided.
    """
    # Backward-compatible fallback: build service from raw config dict
    if search_service is None:
        search_service = SearchService.from_config(search_config)

    _has_desktop = desktop_provider is not None and bool(session_id)

    # ------------------------------------------------------------------
    # web_search — argument parsing only; all logic in SearchService
    # ------------------------------------------------------------------

    async def web_search(query: str = "", queries: list[str] | None = None) -> str:
        # Normalise: handle case where LLM passes queries as a JSON string
        if isinstance(queries, str):
            try:
                parsed = json.loads(queries)
                queries = parsed if isinstance(parsed, list) else [queries]
            except (json.JSONDecodeError, ValueError):
                queries = [queries] if queries.strip() else None

        qlist: list[str] = []
        if query.strip():
            qlist.append(query.strip())
        if queries:
            qlist.extend(q.strip() for q in queries if isinstance(q, str) and q.strip())
        qlist = _dedupe_keep_order(qlist)[: search_service.max_queries]

        if not qlist:
            return json.dumps({"error": "query or queries is required"}, ensure_ascii=False)

        try:
            if len(qlist) == 1:
                results = await search_service.search(qlist[0])
                return json.dumps([r.to_dict() for r in results], ensure_ascii=False)

            batch = await search_service.search_batch(qlist)
            merged = [
                {"query": q, "results": [r.to_dict() for r in rs]}
                for q, rs in batch
            ]
            return json.dumps({"batch": merged}, ensure_ascii=False)

        except Exception as exc:
            logger.exception(
                "web_search failed: provider=%s queries=%s",
                search_service.provider,
                qlist[:3],
            )
            return json.dumps(
                {"error": f"search_failed: {type(exc).__name__}: {exc}"},
                ensure_ascii=False,
            )

    # ------------------------------------------------------------------
    # Browser tools — delegate to DesktopSandboxProvider when available
    # ------------------------------------------------------------------

    def _no_desktop(tool: str) -> str:
        return json.dumps({
            "status": "not_enabled",
            "message": (
                f"'{tool}' requires a Desktop sandbox (provider='e2b_desktop'). "
                "Configure the sandbox provider or use web_search instead."
            ),
        }, ensure_ascii=False)

    async def browser_navigate(url: str) -> str:
        if not _has_desktop:
            return _no_desktop("browser_navigate")
        try:
            desktop_provider.open_url(session_id, url)
            return json.dumps({"status": "ok", "url": url}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_view(_full: bool = False) -> str:
        if not _has_desktop:
            return _no_desktop("browser_view")
        try:
            b64 = desktop_provider.screenshot_base64(session_id)
            size = desktop_provider.get_screen_size(session_id)
            return json.dumps({
                "status": "ok",
                "screenshot": b64,
                "width": size[0],
                "height": size[1],
            }, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_click(x: int = 0, y: int = 0) -> str:
        if not _has_desktop:
            return _no_desktop("browser_click")
        try:
            desktop_provider.left_click(session_id, x, y)
            return json.dumps({"status": "ok", "x": x, "y": y}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_type(text: str = "") -> str:
        if not _has_desktop:
            return _no_desktop("browser_type")
        try:
            desktop_provider.write_text(session_id, text)
            return json.dumps({"status": "ok"}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_scroll(direction: str = "down", amount: int = 3) -> str:
        if not _has_desktop:
            return _no_desktop("browser_scroll")
        try:
            desktop_provider.scroll(session_id, direction=direction, amount=amount)
            return json.dumps({"status": "ok"}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_screenshot() -> str:
        if not _has_desktop:
            return _no_desktop("browser_screenshot")
        try:
            b64 = desktop_provider.screenshot_base64(session_id)
            return json.dumps({"status": "ok", "screenshot": b64}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_close() -> str:
        if not _has_desktop:
            return _no_desktop("browser_close")
        try:
            # Close the active window with Alt+F4
            desktop_provider.press_key(session_id, "alt+F4")
            return json.dumps({"status": "ok"}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_key(key: str = "") -> str:
        if not _has_desktop:
            return _no_desktop("browser_key")
        try:
            desktop_provider.press_key(session_id, key)
            return json.dumps({"status": "ok", "key": key}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    async def browser_drag(
        from_x: int = 0,
        from_y: int = 0,
        to_x: int = 0,
        to_y: int = 0,
    ) -> str:
        if not _has_desktop:
            return _no_desktop("browser_drag")
        try:
            desktop_provider.drag(session_id, from_x, from_y, to_x, to_y)
            return json.dumps({"status": "ok"}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False)

    # ------------------------------------------------------------------
    # Register all tools
    # ------------------------------------------------------------------

    registry.register(name="web_search",         schema=WEB_SEARCH_SCHEMA,         executor=web_search)
    registry.register(name="browser_navigate",   schema=BROWSER_NAVIGATE_SCHEMA,   executor=browser_navigate)
    registry.register(name="browser_view",       schema=BROWSER_VIEW_SCHEMA,       executor=browser_view)
    registry.register(name="browser_click",      schema=BROWSER_CLICK_SCHEMA,      executor=browser_click)
    registry.register(name="browser_type",       schema=BROWSER_TYPE_SCHEMA,       executor=browser_type)
    registry.register(name="browser_scroll",     schema=BROWSER_SCROLL_SCHEMA,     executor=browser_scroll)
    registry.register(name="browser_screenshot", schema=BROWSER_SCREENSHOT_SCHEMA, executor=browser_screenshot)
    registry.register(name="browser_close",      schema=BROWSER_CLOSE_SCHEMA,      executor=browser_close)
    registry.register(name="browser_key",        schema=BROWSER_KEY_SCHEMA,        executor=browser_key)
    registry.register(name="browser_drag",       schema=BROWSER_DRAG_SCHEMA,       executor=browser_drag)
