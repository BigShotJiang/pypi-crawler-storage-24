"""Sandbox tools – expose sandbox operations as agent-callable tools.

These tools allow the agent to execute commands, read/write files, and
browse URLs inside an isolated Daytona sandbox associated with the
current session.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import posixpath
from uuid import uuid4
from typing import Optional

from genagent_core.infra.critical_file_manager import CriticalFileManager
from genagent_core.infra.tool_registry.registry import ToolRegistry
from genagent_core.sandbox.base import SandboxProvider

logger = logging.getLogger(__name__)
_SANDBOX_WORKDIR = "/workspace"


def _normalize_sandbox_path(path: str) -> str:
    """Normalize potentially invalid sandbox paths to a stable workdir."""
    raw = str(path or "").strip()
    if not raw:
        return _SANDBOX_WORKDIR

    if not raw.startswith("/"):
        normalized = posixpath.normpath(f"{_SANDBOX_WORKDIR}/{raw}")
        if not normalized.startswith(f"{_SANDBOX_WORKDIR}/") and normalized != _SANDBOX_WORKDIR:
            return f"{_SANDBOX_WORKDIR}/{posixpath.basename(normalized)}"
        return normalized

    if raw == "/":
        return _SANDBOX_WORKDIR
    if raw.count("/") == 1:
        # "/foo.py" -> "/workspace/foo.py"
        return f"{_SANDBOX_WORKDIR}/{raw.lstrip('/')}"

    return posixpath.normpath(raw)

def _get_write_path_candidates(path: str) -> list[str]:
    """Generate primary and fallback paths for writing files."""
    primary = _normalize_sandbox_path(path)
    if primary.startswith('/tmp/'):
        return [primary]
    # Fallback: use /tmp with a unique name to avoid collisions
    fallback_name = f"{posixpath.basename(primary)}.{uuid4().hex[:6]}"
    return [primary, f"/tmp/{fallback_name}"]

def _is_bad_request_error(e: Exception) -> bool:
    """Check if an exception string looks like a 400 Bad Request."""
    return "400" in str(e) and "bad request" in str(e).lower()

# ---------------------------------------------------------------------------
# Tool schemas (OpenAI function-calling format)
# ---------------------------------------------------------------------------

PYTHON_EXEC_SCHEMA = {
    "name": "python_exec",
    "description": (
        "Execute Python code in a stateful Jupyter kernel. "
        "Variables, imports, and functions persist across calls. "
        "Use this instead of sandbox_exec for data analysis, visualization, "
        "and multi-step computation."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "code": {"type": "string", "description": "Python code to execute."},
            "timeout": {"type": "integer", "description": "Max seconds to wait (default 30)."},
        },
        "required": ["code"],
    },
}

SANDBOX_EXEC_SCHEMA = {
    "name": "sandbox_exec",
    "description": (
        "Execute a shell command inside the isolated sandbox environment. "
        "Use this for running code, installing packages, compiling, testing, "
        "or any system-level operation. Returns stdout, stderr, and exit code."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "Shell command to execute (e.g. 'python3 main.py', 'ls -la').",
            },
            "cwd": {
                "type": "string",
                "description": "Working directory inside the sandbox (optional).",
            },
            "timeout": {
                "type": "integer",
                "description": "Max seconds to wait for the command (optional, default 60).",
            },
        },
        "required": ["command"],
    },
}

SANDBOX_WRITE_FILE_SCHEMA = {
    "name": "sandbox_write_file",
    "description": (
        "Write content to a file inside the sandbox. "
        "Parent directories are created automatically. "
        "Use this to create scripts, config files, or any text file."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute or relative file path inside the sandbox.",
            },
            "content": {
                "type": "string",
                "description": "File content to write.",
            },
            "file_class": {
                "type": "string",
                "enum": ["critical", "temp"],
                "description": "critical files are backed up to object storage; temp files are sandbox-only.",
            },
        },
        "required": ["path", "content"],
    },
}

SANDBOX_READ_FILE_SCHEMA = {
    "name": "sandbox_read_file",
    "description": (
        "Read the content of a file inside the sandbox. "
        "Returns the file content as a string."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute or relative file path inside the sandbox.",
            },
        },
        "required": ["path"],
    },
}

SANDBOX_BROWSE_SCHEMA = {
    "name": "sandbox_browse",
    "description": (
        "Fetch a URL from inside the sandbox using curl and return the response body. "
        "Useful for testing web services running in the sandbox or fetching external resources."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "URL to fetch.",
            },
        },
        "required": ["url"],
    },
}

SANDBOX_INFO_SCHEMA = {
    "name": "sandbox_info",
    "description": (
        "Get information about the current sandbox environment, "
        "including its ID, state, and provider."
    ),
    "parameters": {
        "type": "object",
        "properties": {},
    },
}

SHELL_EXEC_SCHEMA = {
    "name": "shell_exec",
    "description": "Execute a command in sandbox shell session. wait=true returns output immediately.",
    "parameters": {
        "type": "object",
        "properties": {
            "command": {"type": "string"},
            "cwd": {"type": "string"},
            "timeout": {"type": "integer"},
            "wait": {"type": "boolean"},
        },
        "required": ["command"],
    },
}

SHELL_VIEW_SCHEMA = {
    "name": "shell_view",
    "description": "View shell session output/status.",
    "parameters": {
        "type": "object",
        "properties": {"shell_id": {"type": "string"}},
        "required": ["shell_id"],
    },
}

SHELL_WAIT_SCHEMA = {
    "name": "shell_wait",
    "description": "Wait for a running shell session to finish.",
    "parameters": {
        "type": "object",
        "properties": {"shell_id": {"type": "string"}, "timeout": {"type": "integer"}},
        "required": ["shell_id"],
    },
}

SHELL_WRITE_STDIN_SCHEMA = {
    "name": "shell_write_stdin",
    "description": "Write stdin to a running shell session (interactive mode).",
    "parameters": {
        "type": "object",
        "properties": {"shell_id": {"type": "string"}, "input": {"type": "string"}},
        "required": ["shell_id", "input"],
    },
}

SHELL_KILL_SCHEMA = {
    "name": "shell_kill",
    "description": "Stop a running shell session.",
    "parameters": {
        "type": "object",
        "properties": {"shell_id": {"type": "string"}},
        "required": ["shell_id"],
    },
}

FILE_STR_REPLACE_SCHEMA = {
    "name": "file_str_replace",
    "description": "Replace target string in a sandbox file.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "old": {"type": "string"},
            "new": {"type": "string"},
            "replace_all": {"type": "boolean"},
        },
        "required": ["path", "old", "new"],
    },
}


# ---------------------------------------------------------------------------
# Registration function
# ---------------------------------------------------------------------------

def register_sandbox_tools(
    registry: ToolRegistry,
    sandbox_provider: SandboxProvider,
    session_id: str,
    workspace_id: str = "",
    task_id: str = "",
    critical_file_manager: CriticalFileManager | None = None,
) -> None:
    """Register sandbox tools into the given :class:`ToolRegistry`.

    Parameters
    ----------
    registry:
        The tool registry to add tools to.
    sandbox_provider:
        A concrete :class:`SandboxProvider` instance (e.g. Daytona).
    session_id:
        The session/task identifier that maps to a specific sandbox.
    """
    shell_runs: dict[str, asyncio.Task] = {}
    # Maps shell_id → pid for interactive processes started via start_process
    interactive_processes: dict[str, int] = {}

    async def _run_command_raw(command: str, cwd: str = "", timeout: int = 60) -> dict:
        try:
            result = await asyncio.wait_for(
                sandbox_provider.run_command(
                    session_id=session_id,
                    command=command,
                    cwd=cwd or None,
                    timeout=timeout,
                ),
                timeout=max(5, int(timeout) + 8),
            )
        except asyncio.TimeoutError:
            return {
                "exit_code": 124,
                "stdout": "",
                "stderr": f"Command timed out after {timeout}s",
                "success": False,
            }
        return {
            "exit_code": result.exit_code,
            "stdout": result.stdout[:8000] if result.stdout else "",
            "stderr": result.stderr[:4000] if result.stderr else "",
            "success": result.success,
        }

    async def python_exec(code: str, timeout: int = 30) -> str:
        """Execute Python code in a stateful Jupyter kernel."""
        if not sandbox_provider:
            return json.dumps({"error": "Sandbox provider is not available."}, ensure_ascii=False)
            
        try:
            # Check if provider supports run_code (e.g., E2B Code Interpreter)
            run_code_fn = getattr(sandbox_provider, "run_code", None)
            if not run_code_fn:
                return json.dumps({"error": "The current sandbox provider does not support stateful Python execution (run_code)."}, ensure_ascii=False)
                
            result = await run_code_fn(session_id=session_id, code=code, timeout=timeout)
            
            # Save images as artifacts
            images_saved = []
            for i, img in enumerate(result.get("images", [])):
                if img.get("type") == "image/png" and img.get("data"):
                    # Generate a unique filename
                    img_id = uuid4().hex[:8]
                    path = f"/workspace/artifacts/chart_{img_id}_{i}.png"
                    
                    # Ensure artifacts directory exists
                    await sandbox_provider.run_command(session_id, "mkdir -p /workspace/artifacts")
                    
                    # Write the base64 decoded image to the sandbox
                    img_bytes = base64.b64decode(img["data"])
                    await sandbox_provider.write_file(session_id, path, img_bytes)
                    images_saved.append(path)
            
            # Remove raw image data from result to avoid cluttering the context
            if "images" in result:
                del result["images"]
                
            if images_saved:
                result["saved_images"] = images_saved
                
            return json.dumps(result, ensure_ascii=False, indent=2)
            
        except Exception as exc:
            logger.exception("python_exec failed")
            return json.dumps({"error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False)

    async def sandbox_exec(
        command: str,
        cwd: str = "",
        timeout: int = 60,
    ) -> str:
        try:
            return json.dumps(await _run_command_raw(command=command, cwd=cwd, timeout=timeout), ensure_ascii=False)
        except KeyError:
            return json.dumps(
                {"error": "Sandbox not ready. The sandbox may not have been created yet."},
                ensure_ascii=False,
            )
        except Exception as exc:
            logger.exception("sandbox_exec failed: %s", command[:120])
            return json.dumps(
                {"error": f"{type(exc).__name__}: {exc}"},
                ensure_ascii=False,
            )

    async def shell_exec(command: str, cwd: str = "", timeout: int = 60, wait: bool = True) -> str:
        if wait:
            return await sandbox_exec(command=command, cwd=cwd, timeout=timeout)
        # Check if the provider supports interactive processes (e.g. E2B)
        if hasattr(sandbox_provider, "start_process"):
            try:
                stdout_buf: list[str] = []
                stderr_buf: list[str] = []
                handle = await sandbox_provider.start_process(
                    session_id,
                    command,
                    cwd=cwd or None,
                    on_stdout=lambda line: stdout_buf.append(line),
                    on_stderr=lambda line: stderr_buf.append(line),
                    timeout=0,  # unlimited connection timeout for interactive use
                )
                shell_id = f"sh_{uuid4().hex[:8]}"
                interactive_processes[shell_id] = handle.pid
                return json.dumps({"status": "running", "shell_id": shell_id, "pid": handle.pid}, ensure_ascii=False)
            except NotImplementedError:
                pass
        shell_id = f"sh_{uuid4().hex[:8]}"
        shell_runs[shell_id] = asyncio.create_task(_run_command_raw(command=command, cwd=cwd, timeout=timeout))
        return json.dumps({"status": "running", "shell_id": shell_id}, ensure_ascii=False)

    async def shell_view(shell_id: str) -> str:
        task = shell_runs.get(shell_id)
        if not task:
            return json.dumps({"status": "not_found", "shell_id": shell_id}, ensure_ascii=False)
        if task.done():
            try:
                data = task.result()
            except Exception as exc:
                data = {"error": f"{type(exc).__name__}: {exc}"}
            return json.dumps({"status": "done", "shell_id": shell_id, **data}, ensure_ascii=False)
        return json.dumps({"status": "running", "shell_id": shell_id}, ensure_ascii=False)

    async def shell_wait(shell_id: str, timeout: int = 60) -> str:
        task = shell_runs.get(shell_id)
        if not task:
            return json.dumps({"status": "not_found", "shell_id": shell_id}, ensure_ascii=False)
        try:
            data = await asyncio.wait_for(task, timeout=max(1, timeout))
            return json.dumps({"status": "done", "shell_id": shell_id, **data}, ensure_ascii=False)
        except asyncio.TimeoutError:
            return json.dumps({"status": "running", "shell_id": shell_id}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "shell_id": shell_id, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False)

    async def shell_write_stdin(shell_id: str, input: str) -> str:
        """Send *input* to the stdin of a running interactive process.

        For E2B sandboxes this calls ``sandbox.commands.send_stdin(pid, data)``.
        For providers that do not support interactive processes the tool
        returns ``{"status": "not_supported"}`` so the agent can decide how
        to proceed rather than silently failing.
        """
        pid = interactive_processes.get(shell_id)
        if pid is None:
            return json.dumps(
                {"status": "not_found", "shell_id": shell_id,
                 "detail": "No interactive process found for this shell_id. "
                            "Use shell_exec with wait=false to start one."},
                ensure_ascii=False,
            )
        try:
            await sandbox_provider.send_stdin(session_id, pid, input)
            return json.dumps({"status": "ok", "shell_id": shell_id, "pid": pid}, ensure_ascii=False)
        except NotImplementedError:
            return json.dumps(
                {"status": "not_supported",
                 "detail": f"{type(sandbox_provider).__name__} does not support send_stdin."},
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps(
                {"status": "error", "shell_id": shell_id, "pid": pid,
                 "error": f"{type(exc).__name__}: {exc}"},
                ensure_ascii=False,
            )

    async def shell_kill(shell_id: str) -> str:
        # Handle interactive processes (E2B start_process)
        pid = interactive_processes.pop(shell_id, None)
        if pid is not None:
            try:
                killed = await sandbox_provider.kill_process(session_id, pid)
                return json.dumps({"status": "killed" if killed else "not_found", "shell_id": shell_id, "pid": pid}, ensure_ascii=False)
            except NotImplementedError:
                return json.dumps({"status": "not_supported", "shell_id": shell_id}, ensure_ascii=False)
            except Exception as exc:
                return json.dumps({"status": "error", "shell_id": shell_id, "pid": pid, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False)
        # Handle background asyncio tasks (fallback for non-interactive providers)
        task = shell_runs.get(shell_id)
        if not task:
            return json.dumps({"status": "not_found", "shell_id": shell_id}, ensure_ascii=False)
        if task.done():
            return json.dumps({"status": "already_done", "shell_id": shell_id}, ensure_ascii=False)
        task.cancel()
        return json.dumps({"status": "killed", "shell_id": shell_id}, ensure_ascii=False)

    async def file_str_replace(path: str, old: str, new: str, replace_all: bool = False) -> str:
        normalized_path = _normalize_sandbox_path(path)
        try:
            content = await sandbox_provider.read_file(session_id=session_id, path=normalized_path)
            count = -1 if replace_all else 1
            new_content = content.replace(old, new, count)
            await sandbox_provider.write_file(session_id=session_id, path=normalized_path, content=new_content)
            return json.dumps({"status": "ok", "path": normalized_path, "replacements": content.count(old) if replace_all else 1}, ensure_ascii=False)
        except Exception as exc:
            return json.dumps({"status": "error", "path": normalized_path, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False)

    async def sandbox_write_file(path: str, content: str, file_class: str = "temp") -> str:
        candidates = _get_write_path_candidates(path)
        last_exc: Optional[Exception] = None

        for i, p in enumerate(candidates):
            max_retries = 1 if i > 0 else 3  # More retries for primary path
            for attempt in range(max_retries):
                try:
                    await sandbox_provider.write_file(
                        session_id=session_id,
                        path=p,
                        content=content,
                    )
                    if (
                        file_class == "critical"
                        and critical_file_manager is not None
                        and workspace_id
                    ):
                        try:
                            critical_file_manager.backup_text(
                                workspace_id=workspace_id,
                                session_id=session_id,
                                task_id=task_id or session_id,
                                logical_path=p,
                                content=content,
                                metadata={"file_class": "critical"},
                            )
                        except Exception:
                            logger.exception(
                                "critical backup failed for %s (session=%s task=%s)",
                                p,
                                session_id,
                                task_id or session_id,
                            )
                    return json.dumps({"status": "ok", "path": p}, ensure_ascii=False)
                except Exception as e:
                    last_exc = e
                    if _is_bad_request_error(e) and i == 0:
                        logger.warning(
                            "sandbox_write_file failed on primary path %s with 400 Bad Request, switching to fallback path",
                            p,
                        )
                        break  # Stop retrying primary path, move to fallback
                    
                    delay = 0.8 * (2 ** attempt)
                    logger.warning(
                        "sandbox_write_file attempt %d/%d for %s failed, retrying in %.1fs",
                        attempt + 1, max_retries, p, delay,
                    )
                    await asyncio.sleep(delay)
            
        return json.dumps(
            {"error": f"{type(last_exc).__name__}: {last_exc}"},
            ensure_ascii=False,
        )

    async def sandbox_read_file(path: str) -> str:
        normalized_path = _normalize_sandbox_path(path)
        try:
            if normalized_path != path:
                logger.info("sandbox path normalized for read: %s -> %s", path, normalized_path)
            content = await sandbox_provider.read_file(
                session_id=session_id,
                path=normalized_path,
            )
            return content
        except KeyError:
            return json.dumps(
                {"error": "Sandbox not ready. The sandbox may not have been created yet."},
                ensure_ascii=False,
            )
        except Exception as exc:
            logger.exception("sandbox_read_file failed: %s", normalized_path)
            return json.dumps(
                {"error": f"{type(exc).__name__}: {exc}"},
                ensure_ascii=False,
            )

    async def sandbox_browse(url: str) -> str:
        return await sandbox_exec(command=f"curl -s -L \"{url}\"")

    async def sandbox_info() -> str:
        try:
            info = await sandbox_provider.get_info(session_id=session_id)
            return json.dumps(info, ensure_ascii=False)
        except KeyError:
            return json.dumps(
                {"error": "Sandbox not ready. The sandbox may not have been created yet."},
                ensure_ascii=False,
            )
        except Exception as exc:
            return json.dumps(
                {"error": f"{type(exc).__name__}: {exc}"},
                ensure_ascii=False,
            )

    registry.register(
        name="python_exec",
        schema=PYTHON_EXEC_SCHEMA,
        executor=python_exec,
    )
    registry.register(
        name="sandbox_exec",
        schema=SANDBOX_EXEC_SCHEMA,
        executor=sandbox_exec,
    )
    registry.register(
        name="sandbox_write_file",
        schema=SANDBOX_WRITE_FILE_SCHEMA,
        executor=sandbox_write_file,
    )
    registry.register(
        name="sandbox_read_file",
        schema=SANDBOX_READ_FILE_SCHEMA,
        executor=sandbox_read_file,
    )
    registry.register(
        name="sandbox_browse",
        schema=SANDBOX_BROWSE_SCHEMA,
        executor=sandbox_browse,
    )
    registry.register(
        name="sandbox_info",
        schema=SANDBOX_INFO_SCHEMA,
        executor=sandbox_info,
    )
    registry.register(
        name="shell_exec",
        schema=SHELL_EXEC_SCHEMA,
        executor=shell_exec,
    )
    registry.register(
        name="shell_view",
        schema=SHELL_VIEW_SCHEMA,
        executor=shell_view,
    )
    registry.register(
        name="shell_wait",
        schema=SHELL_WAIT_SCHEMA,
        executor=shell_wait,
    )
    registry.register(
        name="shell_write_stdin",
        schema=SHELL_WRITE_STDIN_SCHEMA,
        executor=shell_write_stdin,
    )
    registry.register(
        name="shell_kill",
        schema=SHELL_KILL_SCHEMA,
        executor=shell_kill,
    )
    registry.register(
        name="file_str_replace",
        schema=FILE_STR_REPLACE_SCHEMA,
        executor=file_str_replace,
    )
