"""Skill tools — runtime skill loading for GenAgent-Core.

Provides the ``skill_load`` tool that agents call at runtime to retrieve
the full instruction body of a skill.

Design
------
Level-1 disclosure (metadata_summary) is always in the system prompt.
When the agent judges a skill relevant, it calls ``skill_load(skill_name)``
to get the Level-2 disclosure (SKILL.md body + scripts/references hints).
No keyword matching happens in Python code — the LLM decides.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from genagent_core.infra.tool_registry.registry import ToolRegistry

if TYPE_CHECKING:
    from genagent_core.skills.loader import SkillLoader

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tool schema
# ---------------------------------------------------------------------------

SKILL_LOAD_SCHEMA = {
    "name": "skill_load",
    "description": (
        "Load the full instructions for a skill listed in <available_skills>. "
        "Call this BEFORE starting a task if a skill's description indicates it "
        "is relevant. Returns the complete SKILL.md body including usage "
        "guidelines, scripts available in the sandbox, and reference file paths."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "skill_name": {
                "type": "string",
                "description": (
                    "The skill name to load, exactly as listed in "
                    "<available_skills> (e.g. \"data_analysis\")."
                ),
            },
        },
        "required": ["skill_name"],
    },
}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register_skill_tools(
    registry: ToolRegistry,
    skill_loader: "SkillLoader | None" = None,
) -> None:
    """Register the ``skill_load`` tool into *registry*.

    Parameters
    ----------
    registry:
        The tool registry to register into.
    skill_loader:
        Optional pre-built :class:`SkillLoader`.  If ``None``, a default
        loader pointing at the built-in skills directory is used.
    """
    from genagent_core.skills.loader import SkillLoader

    loader: SkillLoader = skill_loader or SkillLoader()

    async def skill_load_fn(skill_name: str) -> str:
        """Return the full SKILL.md body for *skill_name*."""
        skill = loader.load(skill_name)
        if skill is None:
            available = loader.list_available()
            return (
                f"Error: skill '{skill_name}' not found. "
                f"Available skills: {available}"
            )
        logger.info(
            "[skill_load] agent loaded skill=%s strategy=%s",
            skill_name,
            skill.frontmatter.strategy,
        )
        return skill.prompt_block

    registry.register(
        name="skill_load",
        schema=SKILL_LOAD_SCHEMA,
        executor=skill_load_fn,
    )
    logger.debug("[skill_tools] registered skill_load (skills=%s)", loader.list_available())
