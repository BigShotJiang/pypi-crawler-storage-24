from __future__ import annotations

from dataclasses import dataclass
from typing import Awaitable, Callable


ToolFn = Callable[..., Awaitable[str]]


@dataclass
class ToolSpec:
    name: str
    schema: dict
    executor: ToolFn


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, ToolSpec] = {}

    def register(self, name: str, schema: dict, executor: ToolFn) -> None:
        self._tools[name] = ToolSpec(name=name, schema=schema, executor=executor)

    def get_schemas(self, allowed_tools: list[str]) -> list[dict]:
        return [self._tools[name].schema for name in allowed_tools if name in self._tools]

    def get_executor(self, tool_name: str) -> ToolFn:
        if tool_name not in self._tools:
            raise KeyError(f"Unknown tool: {tool_name}")
        return self._tools[tool_name].executor

    def names(self) -> list[str]:
        return sorted(self._tools.keys())
