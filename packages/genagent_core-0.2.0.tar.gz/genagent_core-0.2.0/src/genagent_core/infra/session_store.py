from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from genagent_core.infra.storage import StorageBackend

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class SessionStore:
    """File-backed session + timeline store for frontend chat persistence."""

    def __init__(self, storage: StorageBackend):
        self.storage = storage
        self._lock = asyncio.Lock()

    @staticmethod
    def _workspace_dir(workspace_id: str) -> str:
        return f"workspaces/{workspace_id}/sessions"

    @classmethod
    def _session_path(cls, workspace_id: str, session_id: str) -> str:
        return f"{cls._workspace_dir(workspace_id)}/{session_id}.json"

    @classmethod
    def _index_path(cls, workspace_id: str) -> str:
        return f"{cls._workspace_dir(workspace_id)}/task_index.json"

    def _default_session(self, session_id: str, title: str) -> dict[str, Any]:
        now = _now_iso()
        return {
            "session_id": session_id,
            "title": title,
            "created_at": now,
            "updated_at": now,
            "status": "idle",
            "last_task_id": "",
            "timeline": [],
            "seq": 0,
            "seen_event_ids": [],
        }

    @staticmethod
    def _repair_session(session: dict[str, Any]) -> dict[str, Any]:
        timeline = session.get("timeline")
        if not isinstance(timeline, list):
            timeline = []
        seq = 0
        repaired: list[dict[str, Any]] = []
        for item in timeline:
            if not isinstance(item, dict):
                continue
            raw = item.get("seq")
            if isinstance(raw, int) and raw > seq:
                seq = raw
            else:
                seq += 1
                item["seq"] = seq
            repaired.append(item)
        session["timeline"] = repaired
        session["seq"] = max(int(session.get("seq", 0)), seq)
        seen = session.get("seen_event_ids")
        if not isinstance(seen, list):
            seen = []
        session["seen_event_ids"] = [str(v) for v in seen if v]
        return session

    def _read_session(self, workspace_id: str, session_id: str) -> dict[str, Any] | None:
        path = self._session_path(workspace_id, session_id)
        if not self.storage.exists(path):
            return None
        raw = self.storage.read_json(path)
        raw = self._repair_session(raw)
        raw.setdefault("status", "idle")
        raw.setdefault("last_task_id", "")
        raw.setdefault("updated_at", raw.get("created_at", _now_iso()))
        return raw

    def _write_session(self, workspace_id: str, session: dict[str, Any]) -> None:
        self.storage.write_json(self._session_path(workspace_id, session["session_id"]), session)

    def _read_index(self, workspace_id: str) -> dict[str, Any]:
        path = self._index_path(workspace_id)
        if not self.storage.exists(path):
            return {"task_to_session": {}}
        raw = self.storage.read_json(path)
        raw.setdefault("task_to_session", {})
        return raw

    def _write_index(self, workspace_id: str, idx: dict[str, Any]) -> None:
        self.storage.write_json(self._index_path(workspace_id), idx)

    @staticmethod
    def _cleanup_index(idx: dict[str, Any], max_entries: int = 3000) -> dict[str, Any]:
        mapping = idx.get("task_to_session")
        if not isinstance(mapping, dict):
            idx["task_to_session"] = {}
            return idx
        # Keep newest bindings only; bounds memory + file size for long-running instances.
        rows: list[tuple[str, dict[str, Any]]] = []
        for task_id, binding in mapping.items():
            if not isinstance(binding, dict):
                continue
            rows.append((task_id, binding))
        rows.sort(key=lambda r: str(r[1].get("updated_at", "")), reverse=True)
        trimmed = rows[:max(100, max_entries)]
        idx["task_to_session"] = {task_id: binding for task_id, binding in trimmed}
        return idx

    @staticmethod
    def _session_summary(session: dict[str, Any]) -> dict[str, Any]:
        preview = ""
        for item in reversed(session.get("timeline", [])):
            if item.get("kind") == "USER_MESSAGE":
                preview = str(item.get("content", ""))[:120]
                break
            if item.get("kind") == "WS_EVENT" and item.get("event") == "AGENT_MESSAGE":
                payload = item.get("payload", {}) or {}
                text = payload.get("text")
                if isinstance(text, str) and text.strip():
                    preview = text.strip()[:120]
                    break
        return {
            "session_id": session["session_id"],
            "title": session.get("title", "新任务"),
            "created_at": session.get("created_at", _now_iso()),
            "updated_at": session.get("updated_at", _now_iso()),
            "status": session.get("status", "idle"),
            "last_task_id": session.get("last_task_id", ""),
            "last_preview": preview,
        }

    async def ensure_session(
        self,
        workspace_id: str,
        session_id: str | None = None,
        title: str | None = None,
    ) -> dict[str, Any]:
        async with self._lock:
            sid = session_id or f"session_{uuid4().hex[:12]}"
            existing = self._read_session(workspace_id, sid)
            if existing:
                if title and (not existing.get("title") or existing.get("title") == "新任务"):
                    existing["title"] = title
                    existing["updated_at"] = _now_iso()
                    self._write_session(workspace_id, existing)
                return self._session_summary(existing)

            session = self._default_session(sid, title or "新任务")
            self._write_session(workspace_id, session)
            return self._session_summary(session)

    async def bind_task(self, workspace_id: str, session_id: str, task_id: str, turn_id: str) -> None:
        async with self._lock:
            idx = self._read_index(workspace_id)
            idx["task_to_session"][task_id] = {
                "session_id": session_id,
                "turn_id": turn_id,
                "updated_at": _now_iso(),
            }
            idx = self._cleanup_index(idx)
            self._write_index(workspace_id, idx)

            session = self._read_session(workspace_id, session_id)
            if not session:
                session = self._default_session(session_id, "新任务")
            session["last_task_id"] = task_id
            session["updated_at"] = _now_iso()
            self._write_session(workspace_id, session)

    async def append_user_message(
        self,
        workspace_id: str,
        session_id: str,
        task_id: str,
        turn_id: str,
        content: str,
        attachments: list[str] | None = None,
    ) -> None:
        async with self._lock:
            session = self._read_session(workspace_id, session_id)
            if not session:
                session = self._default_session(session_id, content[:28] or "新任务")

            session["seq"] = int(session.get("seq", 0)) + 1
            if session.get("title") in {"", "新任务"}:
                session["title"] = content[:28] or "新任务"
            now = _now_iso()
            session["updated_at"] = now
            session["last_task_id"] = task_id
            row = {
                "seq": session["seq"],
                "kind": "USER_MESSAGE",
                "task_id": task_id,
                "turn_id": turn_id,
                "role": "user",
                "content": content,
                "message_type": "user",
                "created_at": now,
            }
            if attachments:
                row["attachments"] = [str(v) for v in attachments if str(v).strip()]
            session["timeline"].append(row)
            self._write_session(workspace_id, session)

    async def append_ws_event(
        self,
        workspace_id: str,
        task_id: str,
        ws_event: str,
        payload: dict[str, Any],
        timestamp: str,
        event_id: str = "",
    ) -> None:
        async with self._lock:
            idx = self._read_index(workspace_id)
            binding = idx.get("task_to_session", {}).get(task_id)
            if not binding:
                logger.warning(
                    "timeline_binding_missing workspace=%s task=%s event=%s",
                    workspace_id,
                    task_id,
                    ws_event,
                )
                return
            session_id = str(binding.get("session_id", ""))
            turn_id = str(binding.get("turn_id", ""))
            if not session_id:
                return

            session = self._read_session(workspace_id, session_id)
            if not session:
                session = self._default_session(session_id, "新任务")

            # Idempotency for re-delivery/replay from event bus.
            if event_id:
                seen_list = [str(v) for v in session.get("seen_event_ids", []) if v]
                seen_set = set(seen_list)
                if event_id in seen_set:
                    return
                seen_list.append(event_id)
                # Cap history to avoid unbounded growth.
                session["seen_event_ids"] = seen_list[-5000:]

            session["seq"] = int(session.get("seq", 0)) + 1
            session["updated_at"] = timestamp or _now_iso()
            session["last_task_id"] = task_id
            if ws_event in {"TASK_CREATED", "NODE_STARTED"}:
                session["status"] = "running"
            if ws_event == "TASK_COMPLETED":
                status = str((payload or {}).get("status", "")).lower()
                session["status"] = status or "completed"

            session["timeline"].append(
                {
                    "seq": session["seq"],
                    "kind": "WS_EVENT",
                    "task_id": task_id,
                    "turn_id": turn_id,
                    "event": ws_event,
                    "payload": payload or {},
                    "created_at": timestamp or _now_iso(),
                    "event_id": event_id,
                }
            )
            self._write_session(workspace_id, session)

    async def list_sessions(self, workspace_id: str, limit: int = 20) -> list[dict[str, Any]]:
        async with self._lock:
            files = self.storage.resolve(self._workspace_dir(workspace_id)).glob("*.json")
            summaries: list[dict[str, Any]] = []
            for path in files:
                if path.name == "task_index.json":
                    continue
                try:
                    session = self.storage.read_json(f"{self._workspace_dir(workspace_id)}/{path.name}")
                except Exception:
                    continue
                if not session:
                    continue
                summaries.append(self._session_summary(session))

            summaries.sort(key=lambda s: s.get("updated_at", ""), reverse=True)
            return summaries[: max(1, min(limit, 100))]

    async def get_timeline(self, workspace_id: str, session_id: str, limit: int = 1000) -> dict[str, Any]:
        async with self._lock:
            session = self._read_session(workspace_id, session_id)
            if not session:
                raise KeyError(session_id)
            timeline = session.get("timeline", [])
            max_limit = max(1, min(limit, 5000))
            items = timeline[-max_limit:]
            return {
                "session": self._session_summary(session),
                "items": items,
            }

    async def import_session(
        self,
        workspace_id: str,
        session_id: str,
        title: str,
        status: str,
        last_task_id: str,
        items: list[dict[str, Any]],
        overwrite: bool = False,
    ) -> dict[str, Any]:
        async with self._lock:
            existing = self._read_session(workspace_id, session_id)
            if existing and existing.get("timeline") and not overwrite:
                return {"session": self._session_summary(existing), "imported": False}

            base = existing or self._default_session(session_id, title or "新任务")
            cleaned: list[dict[str, Any]] = []
            seq = 0
            for raw in items:
                if not isinstance(raw, dict):
                    continue
                seq += 1
                item = dict(raw)
                item["seq"] = seq
                item.setdefault("created_at", _now_iso())
                item.setdefault("kind", "WS_EVENT")
                cleaned.append(item)

            base["title"] = title or base.get("title") or "新任务"
            base["status"] = (status or base.get("status") or "idle").lower()
            base["last_task_id"] = last_task_id or base.get("last_task_id", "")
            base["timeline"] = cleaned
            base["seq"] = seq
            base["updated_at"] = cleaned[-1]["created_at"] if cleaned else _now_iso()
            self._write_session(workspace_id, self._repair_session(base))
            return {"session": self._session_summary(base), "imported": True}

    async def delete_session(self, workspace_id: str, session_id: str) -> dict[str, Any]:
        async with self._lock:
            existing = self._read_session(workspace_id, session_id)
            if not existing:
                raise KeyError(session_id)

            session_path = self.storage.resolve(self._session_path(workspace_id, session_id))
            if session_path.exists():
                session_path.unlink()

            idx = self._read_index(workspace_id)
            mapping = idx.get("task_to_session")
            if isinstance(mapping, dict):
                idx["task_to_session"] = {
                    task_id: binding
                    for task_id, binding in mapping.items()
                    if str((binding or {}).get("session_id", "")) != session_id
                }
                self._write_index(workspace_id, idx)

            return {"session_id": session_id, "deleted": True}
