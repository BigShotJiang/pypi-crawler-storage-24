"""
command_queue.py — asyncio-native CommandQueue / LaneQueue

Design mirrors the threading-based CommandQueue described in the concurrency
architecture document, but uses asyncio primitives throughout so it integrates
naturally with the FastAPI / asyncio stack.

Key concepts
------------
LaneQueue
    A named FIFO queue with a max_concurrency cap and a generation counter.
    Tasks are coroutine callables (async def fn() -> Any).
    Each enqueue() returns an asyncio.Future; callers can await it or attach
    callbacks.

CommandQueue
    Holds a dict of LaneQueue instances (lazily created on first use).
    Standard lanes:
        "main:{workspace_id}"  — per-workspace user request queue, max=1
        "heartbeat"            — background heartbeat lane, max=1

Generation tracking
    Every LaneQueue has an integer generation counter.  reset_all() increments
    all generations.  When a task completes, it checks whether its generation
    still matches the lane's current generation before pumping the next task.
    This prevents stale callbacks from draining the queue after a restart.

Graceful shutdown
    wait_for_idle() returns when every lane has zero active and zero queued
    tasks.  The Container calls this before destroying sandboxes.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Callable, Coroutine

logger = logging.getLogger(__name__)

# Type alias: a zero-argument async callable that returns Any
CoroFactory = Callable[[], Coroutine[Any, Any, Any]]


@dataclass
class LaneStats:
    name: str
    active: int
    queued: int
    max_concurrency: int
    generation: int


class AsyncLaneQueue:
    """A single named FIFO lane backed by asyncio primitives.

    All public methods are coroutine-safe; they may be called from any
    asyncio task running in the same event loop.
    """

    def __init__(self, name: str, max_concurrency: int = 1) -> None:
        self.name = name
        self.max_concurrency = max(1, max_concurrency)
        self._queue: asyncio.Queue[tuple[CoroFactory, asyncio.Future, int]] = asyncio.Queue()
        self._active_count = 0
        self._generation = 0
        self._idle_event = asyncio.Event()
        self._idle_event.set()  # starts idle
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def enqueue(self, coro_fn: CoroFactory, generation: int | None = None) -> asyncio.Future:
        """Enqueue a coroutine factory and return a Future for its result.

        The factory is called with no arguments when the task is dequeued.
        """
        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        gen = generation if generation is not None else self._generation
        await self._queue.put((coro_fn, future, gen))
        self._idle_event.clear()
        asyncio.create_task(self._maybe_pump())
        return future

    async def wait_for_idle(self) -> None:
        """Block until this lane has no active or queued tasks."""
        await self._idle_event.wait()

    def stats(self) -> LaneStats:
        return LaneStats(
            name=self.name,
            active=self._active_count,
            queued=self._queue.qsize(),
            max_concurrency=self.max_concurrency,
            generation=self._generation,
        )

    def increment_generation(self) -> None:
        """Invalidate all in-flight and queued tasks (restart recovery)."""
        self._generation += 1
        logger.debug("lane %s generation → %d", self.name, self._generation)

    # ------------------------------------------------------------------
    # Internal pump
    # ------------------------------------------------------------------

    async def _maybe_pump(self) -> None:
        """Dequeue and start tasks while active < max_concurrency."""
        async with self._lock:
            while self._active_count < self.max_concurrency and not self._queue.empty():
                coro_fn, future, gen = await self._queue.get()
                if gen != self._generation:
                    # Stale task from a previous generation — discard silently.
                    future.cancel()
                    logger.debug(
                        "lane %s: discarding stale task (gen %d != current %d)",
                        self.name, gen, self._generation,
                    )
                    continue
                self._active_count += 1
                asyncio.create_task(self._run_task(coro_fn, future, gen))

    async def _run_task(self, coro_fn: CoroFactory, future: asyncio.Future, gen: int) -> None:
        try:
            result = await coro_fn()
            if not future.cancelled():
                future.set_result(result)
        except Exception as exc:  # noqa: BLE001
            if not future.cancelled():
                future.set_exception(exc)
        finally:
            await self._task_done(gen)

    async def _task_done(self, gen: int) -> None:
        async with self._lock:
            self._active_count -= 1
            if gen == self._generation:
                # Current generation: pump next task if available.
                while self._active_count < self.max_concurrency and not self._queue.empty():
                    coro_fn, future, next_gen = await self._queue.get()
                    if next_gen != self._generation:
                        future.cancel()
                        continue
                    self._active_count += 1
                    asyncio.create_task(self._run_task(coro_fn, future, next_gen))
            # else: stale generation — do NOT pump, let it die quietly.

            # Signal idle if nothing is running or queued.
            if self._active_count == 0 and self._queue.empty():
                self._idle_event.set()


class CommandQueue:
    """Dispatcher that routes work to named AsyncLaneQueue instances.

    Lanes are created lazily on first use.

    Standard lane names
    -------------------
    "main:{workspace_id}"       per-workspace user request lane (max_concurrency=1)
    "background:{workspace_id}" per-workspace async write lane (max_concurrency=1)
    "heartbeat"                 background heartbeat lane (max_concurrency=1)
    """

    # Default max_concurrency per lane name prefix.
    _DEFAULT_MAX: dict[str, int] = {
        "main": 1,
        "background": 1,  # per-workspace async writes (memory distill, etc.)
        "heartbeat": 1,
    }

    def __init__(self) -> None:
        self._lanes: dict[str, AsyncLaneQueue] = {}
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def get_or_create_lane(self, name: str, max_concurrency: int | None = None) -> AsyncLaneQueue:
        """Return the named lane, creating it if it does not exist."""
        async with self._lock:
            if name not in self._lanes:
                # Infer default max_concurrency from name prefix.
                if max_concurrency is None:
                    prefix = name.split(":")[0]
                    max_concurrency = self._DEFAULT_MAX.get(prefix, 1)
                self._lanes[name] = AsyncLaneQueue(name, max_concurrency)
                logger.debug("CommandQueue: created lane '%s' max=%d", name, max_concurrency)
            return self._lanes[name]

    async def enqueue(
        self,
        lane_name: str,
        coro_fn: CoroFactory,
        max_concurrency: int | None = None,
    ) -> asyncio.Future:
        """Enqueue a coroutine factory onto the named lane.

        Returns an asyncio.Future that resolves to the coroutine's return value.
        """
        lane = await self.get_or_create_lane(lane_name, max_concurrency)
        return await lane.enqueue(coro_fn)

    async def wait_for_idle(self) -> None:
        """Wait until ALL lanes are idle (no active or queued tasks).

        Used by graceful shutdown to drain work before destroying resources.
        """
        async with self._lock:
            lanes = list(self._lanes.values())
        await asyncio.gather(*[lane.wait_for_idle() for lane in lanes])

    def reset_all(self) -> None:
        """Increment generation on all lanes (restart / session reset).

        In-flight tasks from the old generation will complete but will NOT
        pump the next task — preventing zombie tasks from draining the queue
        with stale state.
        """
        for lane in self._lanes.values():
            lane.increment_generation()
        logger.info("CommandQueue: reset_all — all lane generations incremented")

    def stats(self) -> list[LaneStats]:
        """Return a snapshot of all lane statistics."""
        return [lane.stats() for lane in self._lanes.values()]

    def lane_names(self) -> list[str]:
        return list(self._lanes.keys())
