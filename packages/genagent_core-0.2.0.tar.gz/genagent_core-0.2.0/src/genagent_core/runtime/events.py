"""Typed event definitions — the system's source of truth.

Every meaningful state change in the system emits an event.  The event log
is append-only and fully replayable: task state, DAG, artifact index, and
planner triggers are all *derived* from the event stream.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import uuid4


class EventKind(str, Enum):
    TASK_CREATED = "task_created"
    TASK_STATUS_CHANGED = "task_status_changed"

    PLAN_PROPOSED = "plan_proposed"
    PLAN_ACCEPTED = "plan_accepted"

    NODE_ENQUEUED = "node_enqueued"
    NODE_STARTED = "node_started"
    NODE_COMPLETED = "node_completed"
    NODE_FAILED = "node_failed"
    NODE_BLOCKED = "node_blocked"

    ARTIFACT_PRODUCED = "artifact_produced"

    TOOL_CALLED = "tool_called"
    TOOL_RESULT = "tool_result"

    USER_MESSAGE = "user_message"
    AGENT_MESSAGE = "agent_message"
    AGENT_THINKING = "agent_thinking"

    TASK_COMPLETED = "task_completed"

    # Plan phase lifecycle events (for progress panel rendering)
    PHASE_START = "phase_start"       # Planner begins executing a phase
    PHASE_DONE = "phase_done"         # A phase completed (done / failed / skipped)
    PLAN_UPDATED = "plan_updated"     # Plan dynamically modified via update_plan

    # Sandbox lifecycle events
    SANDBOX_CREATED = "sandbox_created"
    SANDBOX_DESTROYED = "sandbox_destroyed"
    SANDBOX_ERROR = "sandbox_error"


@dataclass
class Event:
    kind: EventKind
    task_id: str
    workspace_id: str
    payload: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: uuid4().hex[:12])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    source: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["kind"] = self.kind.value
        return d
