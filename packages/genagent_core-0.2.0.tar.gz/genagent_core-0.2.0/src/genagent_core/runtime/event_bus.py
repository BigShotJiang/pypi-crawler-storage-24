"""Append-only event bus with persistent log and async subscriptions.

The EventBus is the system's single source of truth.  All state changes
(task lifecycle, DAG mutations, artifact production)
flow through here as typed events.

Consumers subscribe to event kinds and react asynchronously — the
TaskRuntime, Planner capability, and WebSocket broadcaster are all
event consumers.

Checkpoint / Replay
-------------------
``rebuild_workspace_state(task_id, workspace_id)`` replays the persisted
event log for a task and reconstructs a ``WorkspaceState`` that mirrors
the last known runtime state.  The reconstruction logic covers:

  * ``PLAN_PROPOSED``  — creates the initial ``Plan`` from the serialised
    plan dict embedded in the event payload.
  * ``PLAN_UPDATED``   — applies the updated plan dict (add/remove/rename
    phases) from the payload, replacing the in-memory Plan wholesale.
  * ``PHASE_DONE``     — marks the corresponding phase done/failed and
    registers its artifact if present.
  * ``ARTIFACT_PRODUCED`` — registers a produced artifact into the
    WorkspaceState artifact index.

This is intentionally a *best-effort* reconstruction: it is cheaper and
more reliable than re-running completed phases, and it gives the Planner
enough context to skip already-done work on resume.
"""

from __future__ import annotations

import asyncio
import logging
import json
from collections import defaultdict
from typing import Callable, Awaitable, Any

from genagent_core.infra.storage import StorageBackend
from genagent_core.runtime.events import Event, EventKind

logger = logging.getLogger(__name__)

Subscriber = Callable[[Event], Awaitable[None]]


class EventBus:
    def __init__(self, storage: StorageBackend | None = None):
        self._storage = storage
        self._subscribers: dict[EventKind, list[Subscriber]] = defaultdict(list)
        self._global_subscribers: list[Subscriber] = []
        self._log: list[Event] = []
        self._lock = asyncio.Lock()

    def subscribe(self, kind: EventKind, handler: Subscriber) -> None:
        self._subscribers[kind].append(handler)

    def subscribe_all(self, handler: Subscriber) -> None:
        self._global_subscribers.append(handler)

    async def emit(self, event: Event) -> None:
        async with self._lock:
            self._log.append(event)
        self._persist(event)
        logger.info(
            "[event] %s  task=%s  source=%s  %s",
            event.kind.value,
            event.task_id,
            event.source or "-",
            _summarize_payload(event.payload),
        )
        handlers = list(self._subscribers.get(event.kind, []))
        handlers.extend(self._global_subscribers)
        await asyncio.gather(
            *(self._safe_call(h, event) for h in handlers),
            return_exceptions=True,
        )

    async def _safe_call(self, handler: Subscriber, event: Event) -> None:
        try:
            await handler(event)
        except Exception:
            logger.exception("Event handler %s failed for %s", handler, event.kind)

    def query(
        self,
        task_id: str | None = None,
        kinds: list[EventKind] | None = None,
        limit: int = 100,
    ) -> list[Event]:
        result = list(self._log)
        if task_id:
            result = [e for e in result if e.task_id == task_id]
        if kinds:
            kind_set = set(kinds)
            result = [e for e in result if e.kind in kind_set]
        return result[-limit:]

    def _persist(self, event: Event) -> None:
        if not self._storage:
            return
        try:
            path = f"events/{event.task_id}.jsonl"
            line = json.dumps(event.to_dict(), ensure_ascii=False) + "\n"
            existing = self._storage.read(path) if self._storage.exists(path) else ""
            self._storage.write(path, existing + line)
        except Exception:
            logger.exception("Failed to persist event %s", event.event_id)

    def replay(self, task_id: str) -> list[Event]:
        """Replay events from persisted log for crash recovery."""
        if not self._storage:
            return []
        path = f"events/{task_id}.jsonl"
        if not self._storage.exists(path):
            return []
        raw = self._storage.read(path)
        events: list[Event] = []
        for line in raw.strip().split("\n"):
            if not line:
                continue
            d = json.loads(line)
            events.append(Event(
                kind=EventKind(d["kind"]),
                task_id=d["task_id"],
                workspace_id=d["workspace_id"],
                payload=d.get("payload", {}),
                event_id=d.get("event_id", ""),
                timestamp=d.get("timestamp", ""),
                source=d.get("source", ""),
            ))
        return events

    def rebuild_workspace_state(
        self,
        task_id: str,
        workspace_id: str,
        goal: str = "",
    ) -> "Any":
        """Reconstruct a WorkspaceState by replaying the persisted event log.

        This is the fallback path when no Checkpoint file exists.  It
        replays key events to rebuild the Plan status, Artifact index, and
        Executor history so that ``Orchestrator.resume_task`` can inject
        the recovered context into the new Planner agent.

        Covered event kinds (in chronological order):
          TASK_CREATED      — extracts the original user goal (``message``).
          PLAN_PROPOSED     — creates the initial Plan from ``plan`` dict.
          PLAN_UPDATED      — replaces the in-memory Plan with the updated one.
          PHASE_DONE        — marks the phase done/failed; registers artifact.
          ARTIFACT_PRODUCED — registers a produced artifact into the index.

        Returns:
            A partially-reconstructed WorkspaceState, or None if no events
            exist for this task.
        """
        from genagent_core.orchestration.workspace_state import WorkspaceState, ExecutorRecord
        from genagent_core.orchestration.plan_schema import Plan

        events = self.replay(task_id)
        if not events:
            logger.debug("rebuild_workspace_state: no events found for task=%s", task_id)
            return None

        # Derive goal from TASK_CREATED event if not provided
        effective_goal = goal
        if not effective_goal:
            for ev in events:
                if ev.kind == EventKind.TASK_CREATED:
                    effective_goal = ev.payload.get("message", "")[:500]
                    break

        ws = WorkspaceState(task_id=task_id, goal=effective_goal or task_id)
        active_plan: Plan | None = None

        for ev in events:
            try:
                if ev.kind == EventKind.PLAN_PROPOSED:
                    # payload contains serialised plan dict under "plan" key
                    plan_data = ev.payload.get("plan")
                    if isinstance(plan_data, dict):
                        active_plan = Plan.from_dict(plan_data)
                        ws.active_plan = active_plan
                        ws.plan_state["plan"] = active_plan
                        ws.plan_state["submitted"] = True
                        logger.debug(
                            "rebuild: PLAN_PROPOSED → plan with %d phases",
                            len(active_plan.phases),
                        )

                elif ev.kind == EventKind.PLAN_UPDATED:
                    # payload contains the full updated plan dict
                    plan_data = ev.payload.get("plan")
                    if isinstance(plan_data, dict) and active_plan is not None:
                        active_plan = Plan.from_dict(plan_data)
                        ws.active_plan = active_plan
                        ws.plan_state["plan"] = active_plan
                        logger.debug(
                            "rebuild: PLAN_UPDATED → plan now has %d phases",
                            len(active_plan.phases),
                        )

                elif ev.kind == EventKind.PHASE_DONE:
                    phase_id = ev.payload.get("phase_id", "")
                    success = ev.payload.get("success", True)
                    artifact_id = ev.payload.get("artifact_id", "")
                    executor_id = ev.payload.get("executor_id", "")
                    role = ev.payload.get("role", "executor")
                    phase_title = ev.payload.get("phase_title", "")

                    # Update Plan phase status
                    if active_plan and phase_id:
                        phase = active_plan.get_phase(phase_id)
                        if phase and phase.status not in ("done", "failed", "skipped"):
                            if phase.status == "pending":
                                # Transition pending → in_progress → done/failed
                                # (start() requires pending status)
                                try:
                                    phase.start()
                                except ValueError:
                                    pass
                            if success:
                                phase.complete(artifact_id=artifact_id)
                            else:
                                phase.fail()

                    # Register artifact into workspace index
                    if artifact_id:
                        ws.register_artifact(
                            artifact_id=artifact_id,
                            artifact_type="result",
                            step_id=executor_id or phase_id or "unknown",
                            producer=executor_id or "unknown",
                            summary=phase_title[:100],
                        )

                    # Register executor record
                    if executor_id:
                        ws.record_executor(ExecutorRecord(
                            executor_id=executor_id,
                            role=role,
                            goal=phase_title[:120],
                            status="success" if success else "failed",
                            result_artifact_id=artifact_id,
                            result_summary=phase_title[:200],
                        ))

                elif ev.kind == EventKind.ARTIFACT_PRODUCED:
                    artifact_id = ev.payload.get("artifact_id", "")
                    artifact_type = ev.payload.get("artifact_type", "result")
                    step_id = ev.payload.get("step_id", "")
                    producer = ev.payload.get("producer", ev.source or "unknown")
                    summary = ev.payload.get("summary", "")
                    if artifact_id:
                        # Avoid duplicates from PHASE_DONE registration
                        existing_ids = {a.artifact_id for a in ws.artifacts}
                        if artifact_id not in existing_ids:
                            ws.register_artifact(
                                artifact_id=artifact_id,
                                artifact_type=artifact_type,
                                step_id=step_id,
                                producer=producer,
                                summary=summary[:100],
                            )

            except Exception:
                logger.warning(
                    "rebuild_workspace_state: failed to process event %s (%s), skipping",
                    ev.event_id, ev.kind.value,
                    exc_info=True,
                )
                continue

        done_count = sum(1 for p in active_plan.phases if p.status in ("done", "skipped")) if active_plan else 0
        total_count = len(active_plan.phases) if active_plan else 0
        logger.info(
            "rebuild_workspace_state complete: task=%s plan=%d/%d phases done "
            "artifacts=%d executors=%d",
            task_id, done_count, total_count,
            len(ws.artifacts), len(ws.executor_history),
        )
        return ws


def _summarize_payload(payload: dict) -> str:
    parts = []
    for k, v in payload.items():
        s = str(v)
        parts.append(f"{k}={s[:80]}")
    return " ".join(parts[:4])
