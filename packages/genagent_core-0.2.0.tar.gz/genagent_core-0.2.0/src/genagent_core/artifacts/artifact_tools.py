from __future__ import annotations

import json

from genagent_core.artifacts.artifact_store import ArtifactStore
from genagent_core.artifacts.schemas import ArtifactType


def artifact_write(
    artifact_store: ArtifactStore,
    workspace_id: str,
    task_id: str,
    step_id: str,
    producer: str,
    artifact_type: str,
    content: str,
    metadata: dict | None = None,
) -> str:
    atype = ArtifactType(artifact_type)
    record = artifact_store.create(
        task_id=task_id,
        step_id=step_id,
        artifact_type=atype,
        content=content,
        producer=producer,
        metadata=metadata,
    )
    return json.dumps(record.model_dump(), ensure_ascii=False)


DEFAULT_MAX_CONTENT_LENGTH = 2000


def artifact_read(
    artifact_store: ArtifactStore,
    task_id: str | None = None,
    step_id: str | None = None,
    artifact_type: str | None = None,
    max_content_length: int = DEFAULT_MAX_CONTENT_LENGTH,
    full: bool = False,
    *,
    workspace_id: str | None = None,
) -> str:
    """Read artifacts with content summarisation and workspace isolation.

    By default returns metadata + first ``max_content_length`` chars of content.
    Pass ``full=True`` to retrieve untruncated content (use sparingly).

    ``workspace_id`` is passed through to ``ArtifactStore.list()`` to enforce
    the workspace boundary.  Omitting it uses the store's own workspace_id.
    """
    parsed_type = ArtifactType(artifact_type) if artifact_type else None
    rows = artifact_store.list(
        task_id=task_id,
        step_id=step_id,
        artifact_type=parsed_type,
        workspace_id=workspace_id,
    )
    payload: list[dict] = []
    for row in rows:
        # read_content also enforces workspace isolation via get()
        raw_content = artifact_store.read_content(row.artifact_id, workspace_id=workspace_id)
        if full or len(raw_content) <= max_content_length:
            content = raw_content
        else:
            content = (
                raw_content[:max_content_length]
                + f"\n...[truncated, total {len(raw_content)} chars. "
                f"Use file_read(task_id=\"{row.task_id}\", step_id=\"{row.step_id}\", "
                f"artifact_type=\"{row.artifact_type.value}\", full=true) to get full content]"
            )
        payload.append({**row.model_dump(), "content": content})
    return json.dumps(payload, ensure_ascii=False)


def artifact_read_cross_task(
    artifact_store: ArtifactStore,
    workspace_id: str,
    semantic_type: str,
    artifact_type: str | None = None,
    max_content_length: int = DEFAULT_MAX_CONTENT_LENGTH,
    full: bool = False,
) -> str:
    """Explicit opt-in cross-task knowledge sharing within the same workspace.

    Use this when an Agent needs to reuse high-confidence artifacts produced
    by other tasks in the same workspace (e.g. a cached research dataset).
    This function is intentionally NOT wired to the default ``file_read`` tool
    to prevent accidental cross-task reads.
    """
    parsed_type = ArtifactType(artifact_type) if artifact_type else None
    rows = artifact_store.list(
        artifact_type=parsed_type,
        workspace_id=workspace_id,
        cross_task=True,
    )
    payload: list[dict] = []
    for row in rows:
        raw_content = artifact_store.read_content(row.artifact_id, workspace_id=workspace_id)
        if full or len(raw_content) <= max_content_length:
            content = raw_content
        else:
            content = raw_content[:max_content_length] + f"\n...[truncated, total {len(raw_content)} chars]"
        payload.append({**row.model_dump(), "content": content})
    return json.dumps(payload, ensure_ascii=False)
