"""Artifact Semantic Layer — not just file storage, but typed work products
with lineage, versioning, confidence, and reusability detection.

Multi-tenant isolation model
────────────────────────────
Every ArtifactStore instance is bound to a single ``workspace_id`` at
construction time.  All read/write operations are scoped to that workspace by
default, preventing cross-workspace data leakage.

Within the same workspace, tasks are also isolated by default:
  - ``list(task_id=...)``  → only returns artifacts owned by that task
  - ``get(artifact_id)``   → validates the artifact's workspace_id matches the
                              store's workspace_id before returning
  - ``read_content(...)``  → delegates to ``get()``, inherits the same guard

Opt-in cross-task knowledge sharing (same workspace only):
  - ``find_reusable(workspace_id, semantic_type)`` → explicitly queries across
    all tasks in the workspace for reusable artifacts
  - ``list(..., cross_task=True)``                 → allows listing artifacts
    from multiple tasks in the same workspace
"""

from __future__ import annotations

import hashlib
import logging
from typing import Any
from uuid import uuid4

from genagent_core.artifacts.schemas import ArtifactRecord, ArtifactType, Confidence
from genagent_core.infra.storage import StorageBackend

logger = logging.getLogger(__name__)


class ArtifactStore:
    def __init__(self, storage: StorageBackend, workspace_id: str):
        self.storage = storage
        self.workspace_id = workspace_id
        self.index_path = f"workspaces/{workspace_id}/artifacts/index.json"

    async def initialize(self) -> None:
        if not self.storage.read_json(self.index_path):
            self.storage.write_json(self.index_path, {"artifacts": []})

    # ── write ──────────────────────────────────────────────────────────────

    def create(
        self,
        task_id: str,
        step_id: str,
        artifact_type: ArtifactType,
        content: str,
        producer: str,
        metadata: dict[str, Any] | None = None,
        *,
        semantic_type: str = "",
        based_on: list[str] | None = None,
        confidence: Confidence = Confidence.UNKNOWN,
        freshness_hint: str = "",
    ) -> ArtifactRecord:
        metadata = metadata or {}
        content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        artifacts = self._load_index()

        # Dedup: return existing record if identical content already stored
        for item in artifacts:
            if (
                item["task_id"] == task_id
                and item["step_id"] == step_id
                and item["artifact_type"] == artifact_type.value
                and item["content_hash"] == content_hash
            ):
                return ArtifactRecord.model_validate(item)

        artifact_id = f"a_{uuid4().hex[:12]}"
        content_path = f"workspaces/{self.workspace_id}/artifacts/{artifact_id}.txt"
        self.storage.write(content_path, content)

        sem_type = (
            semantic_type
            or metadata.get("dataset_type", "")
            or metadata.get("document_type", "")
            or metadata.get("report_type", "")
        )

        lineage = list(based_on or [])
        if not lineage:
            deps = self._find_upstream(task_id, step_id, artifacts)
            lineage = [d["artifact_id"] for d in deps]

        version = 1
        for item in artifacts:
            if (
                item["task_id"] == task_id
                and item["step_id"] == step_id
                and item["artifact_type"] == artifact_type.value
                and item.get("superseded_by") is None
            ):
                item["superseded_by"] = artifact_id
                version = item.get("version", 1) + 1

        record = ArtifactRecord(
            artifact_id=artifact_id,
            workspace_id=self.workspace_id,
            task_id=task_id,
            step_id=step_id,
            artifact_type=artifact_type,
            content_path=content_path,
            content_hash=content_hash,
            producer=producer,
            semantic_type=sem_type,
            based_on=based_on or [],
            confidence=confidence,
            version=version,
            lineage=lineage,
            freshness_hint=freshness_hint,
            metadata=metadata,
        )
        artifacts.append(record.model_dump())
        self._save_index(artifacts)
        return record

    # ── read / query ────────────────────────────────────────────────────────

    def list(
        self,
        task_id: str | None = None,
        step_id: str | None = None,
        artifact_type: ArtifactType | None = None,
        *,
        workspace_id: str | None = None,
        cross_task: bool = False,
    ) -> list[ArtifactRecord]:
        """List artifacts with multi-tenant isolation.

        Workspace isolation is always enforced: only artifacts whose
        ``workspace_id`` matches ``self.workspace_id`` are returned.

        Parameters
        ----------
        task_id:
            When provided, restricts results to this task (default behaviour).
        cross_task:
            When ``True``, the ``task_id`` filter is relaxed so that artifacts
            from multiple tasks within the same workspace can be returned.
            Intended for explicit knowledge-sharing queries such as
            ``find_reusable()``.  NOT for general Agent use.
        workspace_id:
            Must equal ``self.workspace_id`` if provided; any other value is
            rejected and an empty list is returned with a WARNING log.
        """
        # ── workspace guard ──────────────────────────────────────────────
        effective_ws = workspace_id or self.workspace_id
        if effective_ws != self.workspace_id:
            logger.warning(
                "[ArtifactStore] Cross-workspace list denied: "
                "requested=%s store=%s",
                effective_ws,
                self.workspace_id,
            )
            return []

        artifacts = [ArtifactRecord.model_validate(a) for a in self._load_index()]
        # Always scope to this workspace (defence-in-depth even though the
        # index file is already workspace-scoped via its path)
        artifacts = [a for a in artifacts if a.workspace_id == self.workspace_id]

        # ── task scoping ─────────────────────────────────────────────────
        if task_id and not cross_task:
            artifacts = [a for a in artifacts if a.task_id == task_id]

        if step_id:
            artifacts = [a for a in artifacts if a.step_id == step_id]
        if artifact_type:
            artifacts = [a for a in artifacts if a.artifact_type == artifact_type]
        return artifacts

    def get(self, artifact_id: str, *, workspace_id: str | None = None) -> ArtifactRecord | None:
        """Fetch a single artifact by ID, enforcing workspace isolation.

        Parameters
        ----------
        artifact_id:
            The artifact to retrieve.
        workspace_id:
            Must equal ``self.workspace_id`` if provided; any other value
            causes an immediate denial with a WARNING log.
        """
        effective_ws = workspace_id or self.workspace_id
        if effective_ws != self.workspace_id:
            logger.warning(
                "[ArtifactStore] Cross-workspace get denied: "
                "artifact=%s requested_ws=%s store_ws=%s",
                artifact_id,
                effective_ws,
                self.workspace_id,
            )
            return None

        for item in self._load_index():
            if item["artifact_id"] == artifact_id:
                record = ArtifactRecord.model_validate(item)
                # Hard check: the stored record must belong to this workspace
                if record.workspace_id != self.workspace_id:
                    logger.warning(
                        "[ArtifactStore] Workspace mismatch on get: "
                        "artifact=%s artifact_ws=%s store_ws=%s — access denied",
                        artifact_id,
                        record.workspace_id,
                        self.workspace_id,
                    )
                    return None
                return record
        return None

    def query_by_step(self, task_id: str, step_id: str) -> list[ArtifactRecord]:
        return self.list(task_id=task_id, step_id=step_id)

    def read_content(self, artifact_id: str, *, workspace_id: str | None = None) -> str:
        """Read artifact content, enforcing workspace isolation via ``get()``."""
        record = self.get(artifact_id, workspace_id=workspace_id)
        if not record:
            return ""
        return self.storage.read(record.content_path)

    # ── semantic queries ────────────────────────────────────────────────────

    def get_latest(
        self,
        task_id: str | None = None,
        semantic_type: str = "",
        artifact_type: ArtifactType | None = None,
        current_only: bool = True,
    ) -> list[ArtifactRecord]:
        """Return the latest (non-superseded) artifacts matching criteria."""
        all_arts = self.list(
            task_id=task_id,
            artifact_type=artifact_type,
            workspace_id=self.workspace_id,
        )
        if semantic_type:
            all_arts = [a for a in all_arts if a.semantic_type == semantic_type]
        if current_only:
            all_arts = [a for a in all_arts if a.is_current]
        all_arts.sort(key=lambda a: a.created_at, reverse=True)
        return all_arts

    def trace_lineage(self, artifact_id: str) -> list[ArtifactRecord]:
        """Walk back through lineage to find all upstream artifacts.

        Lineage traversal is workspace-scoped: cross-workspace artifact IDs
        that somehow appear in ``lineage`` or ``based_on`` are silently skipped
        because ``get()`` enforces the workspace boundary.
        """
        visited: set[str] = set()
        result: list[ArtifactRecord] = []
        stack = [artifact_id]
        while stack:
            aid = stack.pop()
            if aid in visited:
                continue
            visited.add(aid)
            rec = self.get(aid)  # workspace isolation enforced inside get()
            if rec:
                result.append(rec)
                stack.extend(rec.lineage)
                stack.extend(rec.based_on)
        return result

    def find_reusable(
        self,
        workspace_id: str,
        semantic_type: str,
        min_confidence: Confidence = Confidence.MEDIUM,
    ) -> list[ArtifactRecord]:
        """Find artifacts from any task in this workspace that are
        current, not stale, and meet minimum confidence for reuse.

        This is an explicit opt-in cross-task query.  The caller must pass
        the correct ``workspace_id`` (must match ``self.workspace_id``).
        """
        if workspace_id != self.workspace_id:
            logger.warning(
                "[ArtifactStore] find_reusable: workspace_id mismatch "
                "requested=%s store=%s — returning empty",
                workspace_id,
                self.workspace_id,
            )
            return []

        confidence_rank = {
            Confidence.HIGH: 3,
            Confidence.MEDIUM: 2,
            Confidence.LOW: 1,
            Confidence.UNKNOWN: 0,
        }
        min_rank = confidence_rank[min_confidence]
        # Use cross_task=True — this is the intentional knowledge-sharing path
        all_arts = self.list(workspace_id=workspace_id, cross_task=True)
        return [
            a
            for a in all_arts
            if a.semantic_type == semantic_type
            and a.is_current
            and not a.is_stale
            and confidence_rank.get(a.confidence, 0) >= min_rank
        ]

    def finalize_delivery_roles(self, task_id: str) -> dict[str, str]:
        """Mark one artifact as final deliverable; mark others as intermediate.

        Selection priority: latest report > latest document > latest code > latest non-snapshot artifact.
        Returns {'final_artifact_id': '...'} when available.
        """
        artifacts = self._load_index()
        # Scope to this workspace + task
        task_rows = [
            a for a in artifacts
            if a.get("task_id") == task_id
            and a.get("workspace_id", self.workspace_id) == self.workspace_id
        ]
        if not task_rows:
            return {}

        eligible = [a for a in task_rows if a.get("artifact_type") != ArtifactType.CONTEXT_SNAPSHOT.value]
        if not eligible:
            return {}

        def _latest(rows: list[dict]) -> dict | None:
            if not rows:
                return None
            return sorted(rows, key=lambda x: x.get("created_at", ""), reverse=True)[0]

        final_row = (
            _latest([a for a in eligible if a.get("artifact_type") == ArtifactType.REPORT.value])
            or _latest([a for a in eligible if a.get("artifact_type") == ArtifactType.DOCUMENT.value])
            or _latest([a for a in eligible if a.get("artifact_type") == ArtifactType.CODE.value])
            or _latest(eligible)
        )
        if not final_row:
            return {}
        final_id = final_row.get("artifact_id", "")
        if not final_id:
            return {}

        for row in task_rows:
            if row.get("artifact_type") == ArtifactType.CONTEXT_SNAPSHOT.value:
                continue
            metadata = row.get("metadata") or {}
            if not isinstance(metadata, dict):
                metadata = {}
            metadata["delivery_role"] = "final" if row.get("artifact_id") == final_id else "intermediate"
            row["metadata"] = metadata

        self._save_index(artifacts)
        return {"final_artifact_id": final_id}

    # ── internals ───────────────────────────────────────────────────────────

    def _load_index(self) -> list[dict]:
        data = self.storage.read_json(self.index_path)
        return data.get("artifacts", []) if data else []

    def _save_index(self, artifacts: list[dict]) -> None:
        self.storage.write_json(self.index_path, {"artifacts": artifacts})

    def _find_upstream(self, task_id: str, step_id: str, artifacts: list[dict]) -> list[dict]:
        """Heuristic: find artifacts from earlier steps in the same task."""
        return [
            a for a in artifacts
            if a["task_id"] == task_id
            and a["step_id"] != step_id
            and a.get("superseded_by") is None
            and a.get("artifact_type") != "context_snapshot"
        ]
