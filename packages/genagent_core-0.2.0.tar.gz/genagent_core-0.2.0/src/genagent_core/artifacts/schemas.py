from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class ArtifactType(str, Enum):
    DATASET = "dataset"
    DOCUMENT = "document"
    REPORT = "report"
    CODE = "code"
    CONTEXT_SNAPSHOT = "context_snapshot"
    RESULT = "result"  # Structured result from Executor Agent via submit_results


class Confidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"


class ArtifactRecord(BaseModel):
    artifact_id: str
    workspace_id: str
    task_id: str
    step_id: str
    artifact_type: ArtifactType
    content_path: str
    content_hash: str

    # --- semantic layer fields ---
    producer: str = ""
    semantic_type: str = ""
    based_on: list[str] = Field(default_factory=list)
    confidence: Confidence = Confidence.UNKNOWN
    version: int = 1
    superseded_by: Optional[str] = None
    lineage: list[str] = Field(default_factory=list)
    freshness_hint: str = ""

    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def is_current(self) -> bool:
        return self.superseded_by is None

    @property
    def is_stale(self) -> bool:
        if not self.freshness_hint:
            return False
        try:
            ts = datetime.fromisoformat(self.freshness_hint)
            return datetime.now(timezone.utc) > ts
        except (ValueError, TypeError):
            return False
