from __future__ import annotations

from dataclasses import dataclass
import logging

from genagent_core.agent.manus_agent import ManusAgent
from genagent_core.artifacts.artifact_store import ArtifactStore
from genagent_core.artifacts.schemas import ArtifactType
from genagent_core.infra.storage import StorageBackend

logger = logging.getLogger(__name__)


@dataclass
class AgentResult:
    success: bool
    snapshot_path: str
    completion_reason: str
    error: str | None = None


class AgentRuntime:
    def __init__(self, artifact_store: ArtifactStore, storage: StorageBackend):
        self.artifact_store = artifact_store
        self.storage = storage

    async def run_agent(self, agent: ManusAgent) -> AgentResult:
        try:
            completion_reason = await agent.run()
            success = completion_reason.startswith("completed")
            snapshot_path = agent.context.snapshot(self.storage, reason=completion_reason)
            self.artifact_store.create(
                task_id=agent.context.task_id,
                step_id=f"snapshot_{agent.context.agent_id}",
                artifact_type=ArtifactType.CONTEXT_SNAPSHOT,
                content=self.storage.read(snapshot_path),
                producer=agent.context.agent_id,
                metadata={"reason": completion_reason},
            )
            return AgentResult(
                success=success,
                snapshot_path=snapshot_path,
                completion_reason=completion_reason,
            )
        except Exception as exc:
            logger.exception("Agent runtime failed: task=%s agent=%s", agent.context.task_id, agent.context.agent_id)
            snapshot_path = agent.context.snapshot(self.storage, reason=f"exception_{type(exc).__name__}")
            return AgentResult(
                success=False,
                snapshot_path=snapshot_path,
                completion_reason="exception",
                error=str(exc),
            )
