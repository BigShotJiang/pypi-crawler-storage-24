from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum

from genagent_core.infra.storage import StorageBackend


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL_SUCCESS = "partial_success"
    CANCELLED = "cancelled"


class TaskState:
    def __init__(self, workspace_id: str, task_id: str, storage: StorageBackend):
        self.workspace_id = workspace_id
        self.task_id = task_id
        self.storage = storage
        self.path = f"workspaces/{workspace_id}/tasks/{task_id}.json"
        now = datetime.now(timezone.utc).isoformat()
        self.created_at = now
        self.updated_at = now
        self.status = TaskStatus.PENDING.value

    @classmethod
    def load(cls, workspace_id: str, task_id: str, storage: StorageBackend) -> TaskState:
        state = cls(workspace_id=workspace_id, task_id=task_id, storage=storage)
        raw = storage.read_json(state.path)
        if raw:
            state.created_at = raw.get("created_at", state.created_at)
            state.updated_at = raw.get("updated_at", state.updated_at)
            state.status = raw.get("status", state.status)
        return state

    def save(self) -> None:
        self.updated_at = datetime.now(timezone.utc).isoformat()
        self.storage.write_json(self.path, self.to_dict())

    def to_dict(self) -> dict:
        return {
            "workspace_id": self.workspace_id,
            "task_id": self.task_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "status": self.status,
        }
