"""WorkspaceState — 统一任务状态层

替代 context_json 字符串传递。Planner 和所有 Executor 共享同一个
WorkspaceState 实例，通过 artifact 引用和事件摘要衔接，而不是
把整个 Context 序列化成字符串塞进 prompt。

设计原则：
- Planner 每轮调用 workspace.snapshot() 获取当前状态摘要，注入 prompt
- Executor 完成后写入 artifact，WorkspaceState 自动更新索引
- 上下游靠 artifact_id 衔接，不靠 prompt 复制粘贴

Checkpoint 机制：
- save_checkpoint(storage, workspace_id, task_id) 将完整状态（含活 Plan）
  持久化到 StorageBackend，路径为
  workspaces/{workspace_id}/checkpoints/{task_id}.json
- load_checkpoint(storage, workspace_id, task_id) 从持久化文件恢复
  WorkspaceState，包括 Plan 和所有 Artifact/Executor 历史
- Orchestrator.resume_task 调用 load_checkpoint 后，将恢复的状态注入
  新 Planner 的 context，使 Planner 看到已完成的 Phase 并自然跳过它们
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from genagent_core.infra.storage import StorageBackend
    from genagent_core.orchestration.plan_schema import Plan

logger = logging.getLogger(__name__)


@dataclass
class ArtifactRef:
    """对一个已产出 artifact 的轻量引用。"""
    artifact_id: str
    artifact_type: str
    step_id: str
    producer: str
    summary: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "artifact_id": self.artifact_id,
            "artifact_type": self.artifact_type,
            "step_id": self.step_id,
            "producer": self.producer,
            "summary": self.summary,
            "timestamp": self.timestamp,
        }


@dataclass
class ExecutorRecord:
    """记录一次 Executor 执行的结果摘要。"""
    executor_id: str
    role: str
    goal: str
    status: str          # "success" | "failed" | "running"
    result_artifact_id: str = ""
    result_summary: str = ""
    next_suggestions: list[str] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "executor_id": self.executor_id,
            "role": self.role,
            "goal": self.goal[:120],
            "status": self.status,
            "result_artifact_id": self.result_artifact_id,
            "result_summary": self.result_summary[:200],
            "next_suggestions": self.next_suggestions[:3],
            "timestamp": self.timestamp,
        }


class WorkspaceState:
    """任务运行期间的共享状态，由 Planner 持有，Executor 通过 artifact 写入。

    Planner 每轮决策前调用 snapshot_for_planner() 获取结构化摘要，
    注入到自己的 context 中，实现"inspect workspace → decide next_action"。
    """

    def __init__(self, task_id: str, goal: str):
        self.task_id = task_id
        self.goal = goal
        self.artifacts: list[ArtifactRef] = []
        self.executor_history: list[ExecutorRecord] = []
        self.shared_kv: dict[str, Any] = {}   # Planner 可写入的任意 KV
        self.active_plan: "Plan | None" = None  # 活 Plan，由 submit_plan 工具写入
        self.plan_state: dict = {}              # 共享 plan_state 字典引用
        self._created_at = datetime.now(timezone.utc).isoformat()
        # Step trimming history: list of compact summaries of removed context rounds
        self._step_trim_summaries: list[str] = []

    # ──────────────────────────────────────────────────────────────────────
    # Artifact 索引
    # ──────────────────────────────────────────────────────────────────────

    def register_artifact(
        self,
        artifact_id: str,
        artifact_type: str,
        step_id: str,
        producer: str,
        summary: str = "",
    ) -> None:
        """Executor 完成后，由 _spawn_callback 调用，将产出登记到 Workspace。"""
        ref = ArtifactRef(
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            step_id=step_id,
            producer=producer,
            summary=summary,
        )
        self.artifacts.append(ref)
        logger.debug(
            "WorkspaceState[%s] artifact registered: %s (%s)",
            self.task_id, artifact_id, artifact_type,
        )

    def get_artifacts_by_type(self, artifact_type: str) -> list[ArtifactRef]:
        return [a for a in self.artifacts if a.artifact_type == artifact_type]

    def latest_artifact(self, artifact_type: str | None = None) -> ArtifactRef | None:
        pool = self.artifacts if artifact_type is None else self.get_artifacts_by_type(artifact_type)
        return pool[-1] if pool else None

    # ──────────────────────────────────────────────────────────────────────
    # Executor 历史
    # ──────────────────────────────────────────────────────────────────────

    def record_executor(self, record: ExecutorRecord) -> None:
        self.executor_history.append(record)

    # ──────────────────────────────────────────────────────────────────────
    # Step trimming history
    # ──────────────────────────────────────────────────────────────────────

    def record_step_trim(self, summary: str) -> None:
        """Persist a summary of trimmed context steps.

        Called by ManusAgent._maybe_trim_steps() via step_trim_callback.
        The summaries are surfaced in snapshot_for_planner() so the Planner
        always knows what work has already been done even after old rounds
        were removed from the LLM context.
        """
        if summary and summary.strip():
            self._step_trim_summaries.append(summary.strip())
            logger.debug(
                "WorkspaceState[%s] step_trim recorded (%d total)",
                self.task_id, len(self._step_trim_summaries),
            )

    def last_executor(self) -> ExecutorRecord | None:
        return self.executor_history[-1] if self.executor_history else None

    # ──────────────────────────────────────────────────────────────────────
    # Planner 每轮决策注入的状态快照
    # ──────────────────────────────────────────────────────────────────────

    def sync_active_plan(self) -> None:
        """从 plan_state 字典同步 active_plan 引用（submit_plan 工具写入后自动感知）。"""
        plan_obj = self.plan_state.get("plan")
        if plan_obj is not None:
            self.active_plan = plan_obj

    def snapshot_for_planner(self) -> str:
        """生成结构化文本摘要，供 Planner 注入 context，驱动 next_action 决策。

        格式设计原则：
        - 简洁，不超过 800 tokens
        - 突出"已完成什么"和"还缺什么"
        - 包含可直接引用的 artifact_id
        - 如果有活 Plan，优先展示 Plan 进度面板
        """
        # 同步 active_plan（submit_plan 工具写入 plan_state 后，这里自动感知）
        self.sync_active_plan()

        lines: list[str] = [
            f"[Workspace 状态快照]  task_id={self.task_id}",
            f"目标：{self.goal[:200]}",
            "",
        ]

        # Step trim history — show the most recent 2 summaries so the Planner
        # knows what was already done before the context was trimmed.
        if self._step_trim_summaries:
            recent = self._step_trim_summaries[-2:]
            lines.append(f"[已压缩历史步骤摘要（最近 {len(recent)} 批）]")
            for s in recent:
                lines.append(s[:600])
            lines.append("")

        # 如果有活 Plan，优先展示进度面板
        if self.active_plan is not None:
            done, total = self.active_plan.progress()
            lines.append(f"[活 Plan 状态]  进度: {done}/{total}")
            lines.append(self.active_plan.render_progress())
            lines.append("")
            lines.append("提示：按 Plan 顺序执行 pending 阶段，每个阶段完成后检查 next_suggestions 决定是否 update_plan。")
            lines.append("")

        # Executor 执行历史
        if self.executor_history:
            lines.append(f"已执行 Executor（{len(self.executor_history)} 个）：")
            for rec in self.executor_history:
                status_icon = "✓" if rec.status == "success" else "✗"
                lines.append(
                    f"  {status_icon} [{rec.role}] {rec.goal[:80]}"
                )
                if rec.result_artifact_id:
                    lines.append(
                        f"      → artifact_id={rec.result_artifact_id}  {rec.result_summary[:80]}"
                    )
                if rec.next_suggestions:
                    lines.append(
                        f"      → 建议后续：{'; '.join(rec.next_suggestions[:2])}"
                    )
        else:
            lines.append("尚未执行任何 Executor。")

        lines.append("")

        # Artifact 索引（按类型分组）
        if self.artifacts:
            by_type: dict[str, list[ArtifactRef]] = {}
            for a in self.artifacts:
                by_type.setdefault(a.artifact_type, []).append(a)
            lines.append("可用 Artifacts：")
            for atype, refs in by_type.items():
                for ref in refs[-3:]:   # 每类最多展示最近 3 个
                    lines.append(
                        f"  [{atype}] id={ref.artifact_id}  by={ref.producer}  {ref.summary[:60]}"
                    )
        else:
            lines.append("暂无 Artifacts。")

        lines.append("")

        # 共享 KV（Planner 自己写入的状态）
        if self.shared_kv:
            lines.append("共享状态：")
            for k, v in list(self.shared_kv.items())[:5]:
                lines.append(f"  {k}: {str(v)[:80]}")

        return "\n".join(lines)

    # ──────────────────────────────────────────────────────────────────────
    # 序列化（用于持久化，不再用于 Agent 间传递）
    # ──────────────────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        d: dict[str, Any] = {
            "task_id": self.task_id,
            "goal": self.goal,
            "artifacts": [a.to_dict() for a in self.artifacts],
            "executor_history": [r.to_dict() for r in self.executor_history],
            "shared_kv": self.shared_kv,
            "step_trim_summaries": self._step_trim_summaries,
            "created_at": self._created_at,
        }
        # 将活 Plan 一并序列化（Checkpoint 核心）
        if self.active_plan is not None:
            d["active_plan"] = self.active_plan.to_dict()
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    @classmethod
    def from_dict(cls, d: dict) -> "WorkspaceState":
        from genagent_core.orchestration.plan_schema import Plan  # 避免循环导入
        ws = cls(task_id=d["task_id"], goal=d["goal"])
        ws.artifacts = [
            ArtifactRef(**a) for a in d.get("artifacts", [])
        ]
        ws.executor_history = [
            ExecutorRecord(**r) for r in d.get("executor_history", [])
        ]
        ws.shared_kv = d.get("shared_kv", {})
        ws._step_trim_summaries = d.get("step_trim_summaries", [])
        ws._created_at = d.get("created_at", ws._created_at)
        # 恢复活 Plan（如果存在）
        plan_data = d.get("active_plan")
        if plan_data:
            ws.active_plan = Plan.from_dict(plan_data)
            # 同步到 plan_state，让 submit_plan 工具感知到已有 Plan
            ws.plan_state["plan"] = ws.active_plan
            ws.plan_state["submitted"] = True
        return ws

    # ──────────────────────────────────────────────────────────────────────
    # Checkpoint 持久化与恢复
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _checkpoint_path(workspace_id: str, task_id: str) -> str:
        return f"workspaces/{workspace_id}/checkpoints/{task_id}.json"

    def save_checkpoint(self, storage: "StorageBackend", workspace_id: str) -> str:
        """将当前 WorkspaceState（含活 Plan）持久化到 StorageBackend。

        Returns:
            持久化路径，供日志记录。
        """
        path = self._checkpoint_path(workspace_id, self.task_id)
        data = self.to_dict()
        data["checkpoint_saved_at"] = datetime.now(timezone.utc).isoformat()
        storage.write_json(path, data)
        logger.info(
            "WorkspaceState checkpoint saved: task=%s path=%s "
            "phases=%d artifacts=%d executors=%d",
            self.task_id,
            path,
            len(self.active_plan.phases) if self.active_plan else 0,
            len(self.artifacts),
            len(self.executor_history),
        )
        return path

    @classmethod
    def load_checkpoint(
        cls,
        storage: "StorageBackend",
        workspace_id: str,
        task_id: str,
    ) -> "WorkspaceState | None":
        """从 StorageBackend 加载 Checkpoint，恢复 WorkspaceState。

        Returns:
            恢复的 WorkspaceState，若 Checkpoint 不存在则返回 None。
        """
        import json as _json
        path = cls._checkpoint_path(workspace_id, task_id)
        try:
            data = storage.read_json(path)
        except _json.JSONDecodeError:
            logger.warning(
                "Checkpoint file is corrupt (invalid JSON) for task=%s path=%s; "
                "will start fresh.",
                task_id, path,
            )
            return None
        if not data:
            logger.debug("No checkpoint found for task=%s path=%s", task_id, path)
            return None
        try:
            ws = cls.from_dict(data)
            logger.info(
                "WorkspaceState checkpoint loaded: task=%s "
                "phases=%d artifacts=%d executors=%d",
                task_id,
                len(ws.active_plan.phases) if ws.active_plan else 0,
                len(ws.artifacts),
                len(ws.executor_history),
            )
            return ws
        except Exception:
            logger.exception(
                "Failed to deserialize checkpoint for task=%s path=%s; "
                "will start fresh.",
                task_id, path,
            )
            return None

    def completed_phase_ids(self) -> list[str]:
        """返回活 Plan 中所有已完成（done / skipped）阶段的 ID 列表。

        供 Orchestrator.resume_task 使用，用于构建"跳过已完成阶段"的提示。
        """
        if self.active_plan is None:
            return []
        return [
            p.id for p in self.active_plan.phases
            if p.status in ("done", "skipped")
        ]

    def resume_context_hint(self) -> str:
        """生成断点续跑的 context 注入提示，供 Planner 理解当前进度并跳过已完成阶段。

        格式设计：
        - 展示完整 Plan 进度（含已完成阶段的 artifact_id）
        - 明确指示 Planner 从第一个 pending 阶段继续执行
        - 不重复已完成的工作
        """
        lines: list[str] = [
            "[断点续跑] 检测到此任务之前已部分完成，以下是恢复状态：",
            "",
        ]

        if self.active_plan is not None:
            done, total = self.active_plan.progress()
            lines.append(f"Plan 进度：{done}/{total} 阶段已完成")
            lines.append("")
            lines.append(self.active_plan.snapshot_for_planner())
            lines.append("")

            pending = self.active_plan.get_pending_phases()
            if pending:
                lines.append(f"请从阶段 [{pending[0].id}] 「{pending[0].title}」继续执行。")
                lines.append("已完成的阶段请勿重复执行，直接跳过。")
            else:
                lines.append("所有阶段均已完成，请汇总结果并调用 idle 结束任务。")
        else:
            lines.append("未找到活 Plan，请重新规划并继续执行。")

        lines.append("")
        lines.append(self.snapshot_for_planner())

        return "\n".join(lines)
