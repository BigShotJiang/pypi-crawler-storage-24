"""Plan 数据结构 — 方案 A + 动态修改能力

设计原则（对齐 Manus 架构）：
- Plan 是 Planner 第一轮产出的结构化对象，不是静态 DAG
- Plan 在执行中可以被动态修改（增加阶段、跳过阶段、修改标题）
- WorkspaceState 持有活 Plan，Planner 每轮决策后可调用 update_plan 修改
- render_progress() 输出用户可见的进度面板文本
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal


# 阶段状态的合法流转：
#   pending → in_progress → done
#                         → failed
#   pending → skipped
PhaseStatus = Literal["pending", "in_progress", "done", "skipped", "failed"]

STATUS_ICON: dict[str, str] = {
    "pending":     "○",
    "in_progress": "⟳",
    "done":        "✓",
    "skipped":     "—",
    "failed":      "✗",
}


@dataclass
class Phase:
    """Plan 中的单个可执行阶段。"""
    id: str
    title: str                          # 用户可见的阶段标题（简短）
    description: str = ""               # 详细描述（可选，供 Executor 参考）
    role: str = "executor"  # logging/observability label only
    status: PhaseStatus = "pending"
    input_artifacts: list[str] = field(default_factory=list)   # 依赖的 artifact_id
    output_artifact_id: str = ""        # 完成后产出的 artifact_id
    result_summary: str = ""            # 完成后的简短摘要
    next_suggestions: list[str] = field(default_factory=list)  # Executor 的后续建议
    started_at: str = ""
    completed_at: str = ""

    # ── 状态流转 ──────────────────────────────────────────────────────────

    def start(self) -> None:
        if self.status != "pending":
            raise ValueError(f"Phase {self.id} cannot start from status={self.status}")
        self.status = "in_progress"
        self.started_at = datetime.now(timezone.utc).isoformat()

    def complete(
        self,
        artifact_id: str = "",
        summary: str = "",
        next_suggestions: list[str] | None = None,
    ) -> None:
        self.status = "done"
        self.output_artifact_id = artifact_id
        self.result_summary = summary[:200]
        if next_suggestions:
            self.next_suggestions = next_suggestions[:3]
        self.completed_at = datetime.now(timezone.utc).isoformat()

    def fail(self, reason: str = "") -> None:
        self.status = "failed"
        self.result_summary = reason[:200]
        self.completed_at = datetime.now(timezone.utc).isoformat()

    def skip(self, reason: str = "") -> None:
        self.status = "skipped"
        self.result_summary = reason[:200]

    # ── 序列化 ────────────────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "role": self.role,
            "status": self.status,
            "input_artifacts": self.input_artifacts,
            "output_artifact_id": self.output_artifact_id,
            "result_summary": self.result_summary,
            "next_suggestions": self.next_suggestions,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Phase":
        # 向后兼容旧格式（description 字段）
        title = data.get("title") or data.get("description", "")
        return cls(
            id=data.get("id", ""),
            title=title,
            description=data.get("description", ""),
            role=data.get("role", "executor"),
            status=data.get("status", "pending"),
            input_artifacts=data.get("input_artifacts", []),
            output_artifact_id=data.get("output_artifact_id", ""),
            result_summary=data.get("result_summary", ""),
            next_suggestions=data.get("next_suggestions", []),
            started_at=data.get("started_at", ""),
            completed_at=data.get("completed_at", ""),
        )


@dataclass
class Plan:
    """Planner 第一轮产出的结构化执行计划（活文档）。

    Plan 是活文档：
    - 初始由 Planner 通过 submit_plan 工具创建
    - 执行中 Planner 可通过 update_plan 工具动态修改阶段
    - WorkspaceState 持有 Plan 引用，render_progress() 供前端渲染
    """
    goal: str
    phases: list[Phase] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # ── 阶段查询 ──────────────────────────────────────────────────────────

    def get_phase(self, phase_id: str) -> Phase | None:
        for p in self.phases:
            if p.id == phase_id:
                return p
        return None

    def get_pending_phases(self) -> list[Phase]:
        return [p for p in self.phases if p.status == "pending"]

    def get_next_pending(self) -> Phase | None:
        pending = self.get_pending_phases()
        return pending[0] if pending else None

    def get_current(self) -> Phase | None:
        for p in self.phases:
            if p.status == "in_progress":
                return p
        return None

    def is_complete(self) -> bool:
        return bool(self.phases) and all(
            p.status in ("done", "skipped") for p in self.phases
        )

    def progress(self) -> tuple[int, int]:
        """返回 (已完成数, 总阶段数)"""
        done = sum(1 for p in self.phases if p.status in ("done", "skipped"))
        return done, len(self.phases)

    # ── 动态修改 ──────────────────────────────────────────────────────────

    def add_phase(self, phase: Phase, after_id: str | None = None) -> None:
        """在指定阶段之后插入新阶段（after_id=None 则追加到末尾）。"""
        self.updated_at = datetime.now(timezone.utc).isoformat()
        if after_id is None:
            self.phases.append(phase)
            return
        for i, p in enumerate(self.phases):
            if p.id == after_id:
                self.phases.insert(i + 1, phase)
                return
        self.phases.append(phase)  # fallback: 未找到则追加

    def remove_phase(self, phase_id: str) -> bool:
        """删除指定阶段（仅允许删除 pending 阶段）。"""
        for i, p in enumerate(self.phases):
            if p.id == phase_id:
                if p.status != "pending":
                    return False  # 不允许删除已开始/完成的阶段
                self.phases.pop(i)
                self.updated_at = datetime.now(timezone.utc).isoformat()
                return True
        return False

    def update_phase_title(self, phase_id: str, new_title: str) -> bool:
        """修改阶段标题（仅允许修改 pending 阶段）。"""
        phase = self.get_phase(phase_id)
        if phase and phase.status == "pending":
            phase.title = new_title[:100]
            self.updated_at = datetime.now(timezone.utc).isoformat()
            return True
        return False

    # ── 渲染 ──────────────────────────────────────────────────────────────

    def render_progress(self) -> str:
        """渲染用户可见的任务进度面板。

        输出格式（对齐 Manus 风格）：
            任务进度                                    2 / 5
            ✓ 搜索竞品定价数据
            ✓ 抓取 Cursor 定价页面
            ⟳ 分析定价对比矩阵
            ○ 撰写对比报告
            ○ 可能：补充欧洲区数据      ← 来自 next_suggestions
        """
        done, total = self.progress()
        lines = [f"任务进度  {done} / {total}", ""]

        for phase in self.phases:
            icon = STATUS_ICON.get(phase.status, "○")
            line = f"  {icon}  {phase.title}"
            lines.append(line)

            if phase.status == "done" and phase.result_summary:
                lines.append(f"       └─ {phase.result_summary[:60]}")
            elif phase.status == "failed" and phase.result_summary:
                lines.append(f"       └─ 失败: {phase.result_summary[:60]}")

            # 已完成阶段的 next_suggestions 渲染为"可能的后续"
            if phase.status == "done" and phase.next_suggestions:
                for suggestion in phase.next_suggestions[:2]:
                    lines.append(f"       ↳ 可能：{suggestion[:60]}")

        return "\n".join(lines)

    def snapshot_for_planner(self) -> str:
        """供 Planner 注入 context 的结构化摘要（比 render_progress 更详细）。"""
        done, total = self.progress()
        lines = [
            f"[活 Plan 状态]  goal={self.goal[:80]}",
            f"进度: {done}/{total}  updated={self.updated_at[:19]}",
            "",
        ]
        for phase in self.phases:
            icon = STATUS_ICON.get(phase.status, "○")
            lines.append(f"  {icon} [{phase.id}] [{phase.role}] {phase.title}")
            if phase.status == "done":
                if phase.output_artifact_id:
                    lines.append(f"      artifact_id={phase.output_artifact_id}")
                if phase.next_suggestions:
                    lines.append(f"      建议: {'; '.join(phase.next_suggestions[:2])}")
            elif phase.status == "failed":
                lines.append(f"      失败原因: {phase.result_summary[:80]}")
        return "\n".join(lines)

    # ── 序列化 ────────────────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "phases": [p.to_dict() for p in self.phases],
            "metadata": self.metadata,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Plan":
        phases = [Phase.from_dict(p) for p in data.get("phases", [])]
        return cls(
            goal=data.get("goal", ""),
            phases=phases,
            metadata=data.get("metadata", {}),
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
        )

    @classmethod
    def from_json(cls, json_str: str) -> "Plan":
        return cls.from_dict(json.loads(json_str))

    def summary(self) -> str:
        done, total = self.progress()
        failed = sum(1 for p in self.phases if p.status == "failed")
        return (
            f"Plan: {self.goal[:80]}\n"
            f"Progress: {done}/{total} done"
            + (f", {failed} failed" if failed else "")
        )
