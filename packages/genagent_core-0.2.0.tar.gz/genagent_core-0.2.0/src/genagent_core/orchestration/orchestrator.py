from __future__ import annotations

import asyncio
import logging
import re
from typing import Optional, Any
from uuid import uuid4

from genagent_core.orchestration.agent_factory import AgentFactory
from genagent_core.orchestration.agent_runtime import AgentRuntime
from genagent_core.orchestration.task_state import TaskState, TaskStatus
from genagent_core.orchestration.workspace_state import WorkspaceState
from genagent_core.infra.critical_file_manager import CriticalFileManager
from genagent_core.runtime.command_queue import CommandQueue
from genagent_core.runtime.event_bus import EventBus
from genagent_core.runtime.events import Event, EventKind
from genagent_core.sandbox.base import SandboxProvider

logger = logging.getLogger(__name__)


class Orchestrator:
    """v6 Orchestrator: three-tier architecture (Lead → Planner → Executor).

    Architecture overview:
    - Planner: single entry point, receives user request directly,
      decomposes goal, spawns Executor sub-agents, integrates results.
      Decomposes goal into phases, spawns Executor Sub-agents, aggregates results.
    - Executor Sub-agents: spawned by Planner via spawn_subagent
      Execute specific phases (research/scrape/analyze/write), return via submit_results.

    The Orchestrator:
    1. Creates a sandbox for the task (if sandbox provider is available)
    2. Emits task_created
    3. Creates a Lead Agent with the minimal tool set
    4. Lets the Planner drive the task directly (Lead Agent merged in)
    5. Destroys the sandbox when the task completes
    """

    def __init__(
        self,
        agent_factory: AgentFactory,
        agent_runtime: AgentRuntime,
        task_state: TaskState,
        event_bus: EventBus,
        sandbox_provider: Optional[SandboxProvider] = None,
        critical_file_manager: CriticalFileManager | None = None,
        sandbox_idle_timeout_seconds: int = 900,
        command_queue: CommandQueue | None = None,
    ):
        self.agent_factory = agent_factory
        self.agent_runtime = agent_runtime
        self.task_state = task_state
        self.event_bus = event_bus
        self.sandbox_provider = sandbox_provider
        self.critical_file_manager = critical_file_manager
        self.sandbox_idle_timeout_seconds = max(60, int(sandbox_idle_timeout_seconds))
        self._running: dict[str, asyncio.Future] = {}
        # Accept an externally managed CommandQueue (shared across all Orchestrator
        # instances in the same process) or fall back to a private one for tests.
        self._command_queue = command_queue if command_queue is not None else CommandQueue()
    # session_id -> running task count
    _session_active_counts: dict[str, int] = {}
    # session_id -> delayed destroy task
    _session_idle_destroy_tasks: dict[str, asyncio.Task] = {}

    @classmethod
    def from_config(cls, config: "Any") -> "Orchestrator":
        # from_config is a convenience factory for standalone usage.
        # Full orchestrator construction (with AgentFactory, TaskState, etc.) is
        # handled by GenAgent.run() or AppContainer.create_task_components().
        raise NotImplementedError(
            "from_config is not yet fully implemented; use GenAgent.run() instead."
        )

    @staticmethod
    def _sandbox_session_id(workspace_id: str) -> str:
        # Session-scoped sandbox key: reuse across tasks in the same workspace.
        return f"workspace:{workspace_id}"

    def _cancel_idle_destroy(self, session_id: str) -> None:
        timer = self._session_idle_destroy_tasks.pop(session_id, None)
        if timer and not timer.done():
            timer.cancel()

    def _inc_active(self, session_id: str) -> None:
        self._session_active_counts[session_id] = self._session_active_counts.get(session_id, 0) + 1

    def _dec_active(self, session_id: str) -> int:
        current = self._session_active_counts.get(session_id, 0)
        next_count = max(0, current - 1)
        if next_count == 0:
            self._session_active_counts.pop(session_id, None)
        else:
            self._session_active_counts[session_id] = next_count
        return next_count

    @staticmethod
    def _route_task_profile(message: str) -> str:
        text = (message or "").strip()
        if not text:
            return "standard"
        lowered = text.lower()
        deep_keywords = [
            "深度", "全面", "详细", "调研报告", "完整方案", "架构设计",
            "benchmark", "comprehensive", "in-depth", "full report",
        ]
        quick_keywords = [
            "简要", "快速", "一句话", "总结一下", "what is", "who is", "quick",
        ]
        if len(text) > 220 or any(k in lowered for k in deep_keywords):
            return "deep"
        if len(text) <= 90 and any(k in lowered for k in quick_keywords):
            return "quick"
        if len(text) <= 70 and text.count("\n") == 0 and text.count("，") <= 1 and text.count(",") <= 1:
            return "quick"
        return "standard"

    async def _recall_workspace_memory(self, task_instruction: str = "") -> str:
        """Mixed-recall long-term memory and format it for Planner context injection.

        Uses recall_for_task() which combines:
        - Semantic bucket: entries most similar to the current task instruction
        - Recency bucket: the N most recent entries
        Deduplicates and returns semantic hits first.
        """
        try:
            raw = await self.agent_factory.memory_manager.recall_for_task(
                task_instruction=task_instruction,
                recent_limit=5,
                semantic_limit=5,
            )
        except Exception:
            logger.exception("Failed to recall workspace memory")
            return ""
        if not raw or not raw.strip():
            return ""
        clipped = raw.strip()
        if len(clipped) > 6000:
            clipped = clipped[-6000:]
        return (
            "[Workspace Long-term Memory]\n"
            "以下是该工作区历史任务沉淀，可用于复用结论、术语、来源与结构。\n"
            f"{clipped}"
        )

    async def _distill_memory(self, user_goal: str, raw_output: str) -> str:
        """Use LLM to compress task output into a structured memory entry.

        The distilled entry is structured for fast future retrieval:
        - goal: what the user wanted
        - key_findings: the most important conclusions / results
        - reusable_assets: artifact IDs, URLs, file paths worth remembering
        """
        try:
            prompt = (
                "You are a memory distiller. Given a completed task's goal and its raw output, "
                "produce a concise structured summary (max 300 words) with three sections:\n"
                "1. goal: restate the user's goal in one sentence\n"
                "2. key_findings: 3-5 bullet points of the most important conclusions\n"
                "3. reusable_assets: any artifact IDs, URLs, or file paths worth keeping\n\n"
                f"User goal: {user_goal[:500]}\n\n"
                f"Raw output (truncated):\n{raw_output[:2000]}"
            )
            response = await self.agent_factory.llm_provider.complete(
                messages=[{"role": "user", "content": prompt}],
                model=self.agent_factory.model_router.get_model("planner"),
                max_tokens=400,
            )
            return response.strip()
        except Exception:
            logger.warning("Memory distillation LLM call failed for task; falling back to raw summary")
            return raw_output[:600]

    async def _write_task_memory(
        self,
        *,
        task_id: str,
        user_message: str,
        completion_reason: str,
        final_artifact_id: str = "",
    ) -> None:
        """Distil and persist a compact task memory after task completion.

        Flow:
        1. Collect raw output from the final artifact (up to 2400 chars)
        2. Call _distill_memory() to produce a structured, noise-free summary via LLM
        3. Write the distilled entry to the memory backend with metadata
        """
        try:
            raw_output = ""
            if final_artifact_id:
                content = self.agent_runtime.artifact_store.read_content(final_artifact_id)
                if content:
                    raw_output = content[:2400]
            if not raw_output:
                latest = self.agent_runtime.artifact_store.get_latest(task_id=task_id)
                if latest:
                    raw_output = self.agent_runtime.artifact_store.read_content(latest[0].artifact_id)[:2400]

            distilled = await self._distill_memory(
                user_goal=user_message,
                raw_output=raw_output or "No artifact output available.",
            )

            memory_text = (
                f"[task_id] {task_id}\n"
                f"[user_goal] {user_message[:500]}\n"
                f"[completion] {completion_reason}\n"
                f"[final_artifact_id] {final_artifact_id or 'N/A'}\n"
                f"[distilled_memory]\n{distilled}"
            )
            await self.agent_factory.memory_manager.write(
                content=memory_text,
                metadata={
                    "task_id": task_id,
                    "completion_reason": completion_reason,
                    "final_artifact_id": final_artifact_id,
                },
            )
        except Exception:
            logger.exception("Failed to persist task memory for task %s", task_id)

    async def _create_sandbox(self, workspace_id: str, task_id: str, session_id: str) -> bool:
        """Create (or reuse) a sandbox for the workspace session. Returns True on success."""
        if not self.sandbox_provider:
            return False
        try:
            info = await self.sandbox_provider.create(
                session_id=session_id,
                labels={
                    "workspace_id": workspace_id,
                    "task_id": task_id,
                    "sandbox_scope": "workspace_session",
                },
                timeout=120,
            )
            logger.info(
                "Sandbox ready for session %s (task=%s): id=%s provider=%s state=%s",
                session_id,
                task_id,
                info.sandbox_id,
                info.provider,
                info.state,
            )
            restore_stats = {"restored": 0, "failed": 0}
            # TODO(qyx): Re-enable critical file restore after adding strict
            # timeout/circuit-breaker controls. Current restore path can
            # introduce large startup latency when object storage is slow.
            # if self.critical_file_manager is not None:
            #     restore_stats = await self.critical_file_manager.restore_to_sandbox(
            #         workspace_id=workspace_id,
            #         session_id=session_id,
            #         sandbox_provider=self.sandbox_provider,
            #     )
            await self.event_bus.emit(Event(
                kind=EventKind.SANDBOX_CREATED,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "sandbox_id": info.sandbox_id,
                    "provider": info.provider,
                    "state": info.state,
                    "restored_critical_files": restore_stats.get("restored", 0),
                    "restore_failed_files": restore_stats.get("failed", 0),
                },
                source="orchestrator",
            ))
            return True
        except Exception as e:
            logger.exception("Failed to create sandbox for session %s (task=%s)", session_id, task_id)
            detail = str(e).strip()
            if len(detail) > 300:
                detail = detail[:300] + "..."
            await self.event_bus.emit(Event(
                kind=EventKind.SANDBOX_ERROR,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "error": "sandbox_creation_failed",
                    "detail": detail or "unknown_sandbox_error",
                },
                source="orchestrator",
            ))
            return False

    async def _destroy_sandbox(self, workspace_id: str, task_id: str, session_id: str) -> None:
        """Destroy the sandbox for the workspace session."""
        if not self.sandbox_provider:
            return
        try:
            await self.sandbox_provider.destroy(session_id=session_id)
            logger.info("Sandbox destroyed for session %s (task=%s)", session_id, task_id)
            await self.event_bus.emit(Event(
                kind=EventKind.SANDBOX_DESTROYED,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={},
                source="orchestrator",
            ))
        except Exception:
            logger.exception("Failed to destroy sandbox for session %s (task=%s)", session_id, task_id)

    def _schedule_idle_destroy(self, workspace_id: str, task_id: str, session_id: str) -> None:
        """Destroy sandbox after idle timeout when no active tasks remain in this session."""
        if not self.sandbox_provider:
            return

        async def _delayed_destroy() -> None:
            try:
                await asyncio.sleep(self.sandbox_idle_timeout_seconds)
                # New tasks may have started while waiting.
                if self._session_active_counts.get(session_id, 0) > 0:
                    return
                await self._destroy_sandbox(workspace_id, task_id, session_id)
            except asyncio.CancelledError:
                return
            except Exception:
                logger.exception("Idle destroy failed for sandbox session %s", session_id)

        self._cancel_idle_destroy(session_id)
        self._session_idle_destroy_tasks[session_id] = asyncio.create_task(_delayed_destroy())

    async def handle_task(
        self,
        workspace_id: str,
        message: str,
        task_id: str | None = None,
        *,
        resume_workspace_state: "WorkspaceState | None" = None,
        todo_hint: str = "",
    ) -> str:
        """Start (or resume) a task.

        Args:
            workspace_id: Workspace identifier.
            message: User instruction or resume hint.
            task_id: Optional explicit task ID; defaults to a new UUID.
            resume_workspace_state: Pre-loaded WorkspaceState from a previous
                run.  When provided, the Planner receives a resume context hint
                that describes already-completed phases so it can skip them.
        """
        task_id = task_id or f"task_{uuid4().hex[:10]}"
        if self.task_state.task_id != task_id:
            raise ValueError("Orchestrator is bound to a single task state instance")
        session_id = self._sandbox_session_id(workspace_id)
        self._cancel_idle_destroy(session_id)
        self._inc_active(session_id)
        task_profile = self._route_task_profile(message)
        self.agent_factory.set_task_profile(task_profile)
        budget_summary = self.agent_factory.get_task_budget_summary()

        # --- Create sandbox for this task ---
        sandbox_ready = await self._create_sandbox(workspace_id, task_id, session_id)

        await self.event_bus.emit(Event(
            kind=EventKind.TASK_CREATED,
            task_id=task_id,
            workspace_id=workspace_id,
            payload={
                "message": message[:500],
                "sandbox_enabled": sandbox_ready,
                "task_profile": task_profile,
                "budget": budget_summary,
                "is_resume": resume_workspace_state is not None,
            },
            source="orchestrator",
        ))

        self.task_state.status = TaskStatus.RUNNING.value
        self.task_state.save()
        historical_memory = await self._recall_workspace_memory(task_instruction=message)

        # Build the task instruction for the Planner.
        # On resume, prepend the checkpoint context hint so the Planner
        # immediately sees which phases are already done and skips them.
        if todo_hint:
            # task_plan.md 提示已被前置到 message 中，直接使用
            task_instruction = message
            logger.info("handle_task(resume): task=%s injecting task_plan.md context", task_id)
        elif resume_workspace_state is not None:
            resume_hint = resume_workspace_state.resume_context_hint()
            task_instruction = (
                f"{resume_hint}\n\n"
                f"[原始任务指令]\n{message}"
            )
            logger.info(
                "handle_task(resume): task=%s injecting checkpoint context "
                "(phases_done=%d artifacts=%d)",
                task_id,
                len(resume_workspace_state.completed_phase_ids()),
                len(resume_workspace_state.artifacts),
            )
        else:
            task_instruction = message

        # Pass session_id (= task_id) so sandbox tools are bound to this task's sandbox
        planner_agent = self.agent_factory.create_agent(
            role="planner",
            workspace_id=workspace_id,
            task_id=task_id,
            task_instruction=task_instruction,
            historical_memory=historical_memory,
            step_id="planner",
            session_id=session_id if sandbox_ready else "",
            workspace_state=resume_workspace_state,
        )

        async def _run_planner() -> None:
            try:
                result = await self.agent_runtime.run_agent(planner_agent)
                delivery_info = self.agent_runtime.artifact_store.finalize_delivery_roles(task_id=task_id)
                final_artifact_id = delivery_info.get("final_artifact_id", "")

                # Fire-and-forget: enqueue memory distillation onto the per-workspace
                # background lane so it does not block the main lane from accepting the
                # next user request.  The background lane is still drained during graceful
                # shutdown, so memories are never silently lost on clean exit.
                _mem_task_id = task_id
                _mem_message = message
                _mem_reason = result.completion_reason
                _mem_artifact_id = final_artifact_id

                async def _do_write_memory() -> None:
                    await self._write_task_memory(
                        task_id=_mem_task_id,
                        user_message=_mem_message,
                        completion_reason=_mem_reason,
                        final_artifact_id=_mem_artifact_id,
                    )

                await self._command_queue.enqueue(
                    f"background:{workspace_id}",
                    _do_write_memory,
                )
                logger.debug(
                    "task %s: memory write enqueued on background lane",
                    task_id,
                )

                self.task_state.status = TaskStatus.COMPLETED.value if result.success else TaskStatus.FAILED.value
                self.task_state.save()
                await self.event_bus.emit(Event(
                    kind=EventKind.TASK_COMPLETED,
                    task_id=task_id,
                    workspace_id=workspace_id,
                    payload={
                        "status": self.task_state.status,
                        "reason": result.completion_reason,
                        "error": result.error or "",
                        "final_artifact_id": final_artifact_id,
                    },
                    source="planner",
                ))
            except Exception:
                logger.exception("Planner failed for task %s", task_id)
                self.task_state.status = TaskStatus.FAILED.value
                self.task_state.save()
                await self.event_bus.emit(Event(
                    kind=EventKind.TASK_COMPLETED,
                    task_id=task_id,
                    workspace_id=workspace_id,
                    payload={"status": "failed", "reason": "planner_exception"},
                    source="planner",
                ))
            finally:
                # Session-level sandbox lifecycle:
                # do NOT destroy immediately; start idle timer when session becomes inactive.
                remaining = self._dec_active(session_id)
                if sandbox_ready and remaining == 0:
                    self._schedule_idle_destroy(workspace_id, task_id, session_id)

        # Enqueue onto the per-workspace main lane (max_concurrency=1).
        # This serialises concurrent requests for the same workspace,
        # preventing race conditions on the shared sandbox and artifact store.
        lane_name = f"main:{workspace_id}"
        future = await self._command_queue.enqueue(lane_name, _run_planner)
        self._running[task_id] = future
        return task_id

    async def resume_task(self, workspace_id: str) -> str:
        """Resume a previously interrupted task.

        Recovery strategy (in priority order):

        1. **Already running** — if the task's asyncio.Task is still alive,
           return immediately without spawning a duplicate.

        2. **Sandbox task_plan.md** — read `/home/ubuntu/task_plan.md` from the sandbox.
           This is the ultimate source of truth for task progress.

        3. **Checkpoint file** — load WorkspaceState from the persisted
           checkpoint (``workspaces/{workspace_id}/checkpoints/{task_id}.json``).
           This is the fallback path if sandbox is lost.

        4. **Event replay** — if no checkpoint file exists, reconstruct the
           WorkspaceState by replaying the persisted event log.

        5. **Cold restart** — if no source is available, fall back to a
           plain ``handle_task`` call with a generic resume message.
        """
        task_id = self.task_state.task_id

        # ── 1. Already running ────────────────────────────────────────────
        if task_id in self._running and not self._running[task_id].done():
            logger.info("resume_task: task=%s already running, skipping", task_id)
            return task_id

        storage = self.task_state.storage
        session_id = self._sandbox_session_id(workspace_id)
        
        # ── 2. Try Sandbox task_plan.md ────────────────────────────────────────
        todo_hint = ""
        if self.sandbox_provider:
            try:
                todo_content = await self.sandbox_provider.read_file(session_id, "/home/ubuntu/task_plan.md")
                if todo_content:
                    current_phase = None
                    phase_status = {}  # phase_title -> {"done_steps": [], "pending_steps": []}
                    
                    for line in todo_content.splitlines():
                        # 匹配 Phase 标题：### Phase 1: 搜索竞品官网数据 <!-- id:p1 -->
                        match_phase = re.match(r"^### Phase \d+: (.*?)\s*<!-- id:(.*?) -->", line)
                        if match_phase:
                            current_phase = match_phase.group(1).strip()
                            phase_status[current_phase] = {"done_steps": [], "pending_steps": []}
                            continue
                            
                        if current_phase:
                            # 匹配已完成 step：- [x] 访问竞品 A 官网 <!-- sid:s1 -->
                            match_done = re.match(r"^- \[x\] (.*?)\s*<!-- sid:(.*?) -->", line)
                            if match_done:
                                phase_status[current_phase]["done_steps"].append(match_done.group(1).strip())
                                continue
                                
                            # 匹配未完成 step：- [ ] 访问竞品 B 官网 <!-- sid:s2 -->
                            match_pending = re.match(r"^- \[[ ~]\] (.*?)\s*<!-- sid:(.*?) -->", line)
                            if match_pending:
                                phase_status[current_phase]["pending_steps"].append(match_pending.group(1).strip())
                                continue
                    
                    if phase_status:
                        hint_lines = ["[断点续跑提示]", "系统从沙盒的 task_plan.md 中恢复了任务进度。\n"]
                        
                        first_pending_phase = None
                        for phase, status in phase_status.items():
                            done = status["done_steps"]
                            pending = status["pending_steps"]
                            
                            if not done and not pending:
                                # 还没开始执行任何 step 的 Phase
                                hint_lines.append(f"待执行阶段：{phase} (尚未开始)")
                                if not first_pending_phase:
                                    first_pending_phase = phase
                            elif pending:
                                # 进行中的 Phase
                                hint_lines.append(f"进行中阶段：{phase}")
                                if done:
                                    hint_lines.append(f"  已完成步骤：{', '.join(done)}")
                                hint_lines.append(f"  待完成步骤：{', '.join(pending)}")
                                if not first_pending_phase:
                                    first_pending_phase = phase
                            else:
                                # 已完成的 Phase
                                hint_lines.append(f"已完成阶段：{phase}")
                                hint_lines.append(f"  包含步骤：{', '.join(done)}")
                            hint_lines.append("")
                            
                        todo_hint = "\n".join(hint_lines)
                        
                        if first_pending_phase:
                            todo_hint += f"请直接从「{first_pending_phase}」的待完成步骤开始执行，不要重复已完成的工作。\n"
                        else:
                            todo_hint += "所有阶段均已完成，请汇总结果并调用 idle 结束任务。\n"
                            
                        # 尝试读取 findings.md 补充上下文
                        try:
                            findings_content = await self.sandbox_provider.read_file(session_id, "/home/ubuntu/findings.md")
                            if findings_content and len(findings_content) > 20:
                                todo_hint += "\n[已发现的信息 (Findings)]\n"
                                # 截断过长的 findings
                                if len(findings_content) > 1000:
                                    todo_hint += findings_content[:1000] + "\n... (更多内容请读取 /home/ubuntu/findings.md)\n"
                                else:
                                    todo_hint += findings_content + "\n"
                        except Exception:
                            pass
                            
                        logger.info("resume_task: task=%s restored from sandbox task_plan.md", task_id)
            except Exception as e:
                logger.info("resume_task: failed to read task_plan.md from sandbox: %s", e)

        # ── 3. Try Checkpoint file ────────────────────────────────────────
        recovered_ws: WorkspaceState | None = WorkspaceState.load_checkpoint(
            storage=storage,
            workspace_id=workspace_id,
            task_id=task_id,
        )
        if recovered_ws is not None:
            logger.info(
                "resume_task: task=%s restored from checkpoint "
                "(phases_done=%d artifacts=%d)",
                task_id,
                len(recovered_ws.completed_phase_ids()),
                len(recovered_ws.artifacts),
            )
        else:
            # ── 4. Fallback: Event replay ─────────────────────────────────
            logger.info(
                "resume_task: task=%s no checkpoint found, attempting event replay",
                task_id,
            )
            recovered_ws = self.event_bus.rebuild_workspace_state(
                task_id=task_id,
                workspace_id=workspace_id,
            )
            if recovered_ws is not None:
                logger.info(
                    "resume_task: task=%s restored from event replay "
                    "(phases_done=%d artifacts=%d)",
                    task_id,
                    len(recovered_ws.completed_phase_ids()),
                    len(recovered_ws.artifacts),
                )

        # ── 5. Cold restart (no recovery data) ───────────────────────────
        if recovered_ws is None and not todo_hint:
            logger.warning(
                "resume_task: task=%s no recovery data found, cold restart",
                task_id,
            )
            return await self.handle_task(
                workspace_id=workspace_id,
                message="继续之前的任务",
                task_id=task_id,
            )

        # Derive the original user goal from the recovered workspace
        original_goal = "继续之前的任务"
        if recovered_ws:
            original_goal = recovered_ws.goal or original_goal

        # 若有 task_plan.md 提示，将其前置到任务指令中，让 Planner 直接感知进度
        if todo_hint:
            original_goal = f"{todo_hint}\n\n[原始任务指令]\n{original_goal}"

        return await self.handle_task(
            workspace_id=workspace_id,
            message=original_goal,
            task_id=task_id,
            resume_workspace_state=recovered_ws,
            todo_hint=todo_hint,
        )

    def _save_checkpoint(self, workspace_id: str, workspace_state: WorkspaceState) -> None:
        """Persist a WorkspaceState checkpoint.  Called by AgentFactory after
        each Executor completes so that the checkpoint is always up-to-date.

        Failures are swallowed to avoid disrupting the main execution path.
        """
        try:
            workspace_state.save_checkpoint(
                storage=self.task_state.storage,
                workspace_id=workspace_id,
            )
        except Exception:
            logger.exception(
                "_save_checkpoint failed for workspace=%s task=%s",
                workspace_id, workspace_state.task_id,
            )
