"""AgentFactory — 创建和协调 Agent 实例

两层架构：
- Planner（Tier 1）：唯一入口，负责任务分解、调度 Executor、整合结果
- Executor（Tier 2）：通用 Manus 实例，完整工具箱，自主决定如何完成子任务

关键机制：
- WorkspaceState 作为 Planner 和所有 Executor 的共享状态层
- Executor 之间通过 artifact_id 引用数据，不通过 context 复制内容
- Planner 的 event_summary_fn 返回 workspace.snapshot_for_planner()
"""
from __future__ import annotations
import logging
import re
from typing import Callable, Optional
from uuid import uuid4

from genagent_core.agent.context import Context
from genagent_core.agent.manus_agent import ManusAgent
from genagent_core.artifacts.artifact_store import ArtifactStore
from genagent_core.infra.llm_provider import LLMProvider
from genagent_core.infra.model_router import ModelRouter
from genagent_core.infra.critical_file_manager import CriticalFileManager
from genagent_core.infra.tool_registry.registry import ToolRegistry
from genagent_core.infra.tool_registry.system_tools import register_system_tools
from genagent_core.infra.tool_registry.workflow_tools import register_workflow_tools
from genagent_core.services.search_service import SearchService
from genagent_core.memory.memory_manager import MemoryManager
from genagent_core.orchestration.task_state import TaskState
from genagent_core.orchestration.workspace_state import ExecutorRecord, WorkspaceState
from genagent_core.config import ContextConfig
from genagent_core.skills.loader import SkillsLoader  # SkillsLoader is a backward-compat alias
from genagent_core.prompts.prompt_loader import PromptLoader, UserProfile, get_default_loader
from genagent_core.runtime.event_bus import EventBus
from genagent_core.sandbox.base import SandboxProvider
from genagent_core.prompts.executor import EXECUTOR_IDENTITY
from genagent_core.prompts.planner_agent import PLANNER_AGENT_IDENTITY
from genagent_core.prompts.system_prompt import SYSTEM_PROMPT_PREFIX
from genagent_core.agent.context_engineering import (
    assert_stable_prefix,
    strip_timestamp_from_system_prompt,
    verify_prefix_unchanged,
)

logger = logging.getLogger(__name__)

# KV-cache health: strip any timestamps from system prompt prefix and log fingerprint.
# Manus blog: 'A common mistake is to include a timestamp at the beginning of the
# system prompt — it degrades your cache hit rate.'
_CLEAN_SYSTEM_PREFIX = strip_timestamp_from_system_prompt(SYSTEM_PROMPT_PREFIX)
_SYSTEM_PREFIX_FINGERPRINT = assert_stable_prefix(_CLEAN_SYSTEM_PREFIX)
logger.debug(
    "[kv_cache] system_prompt_prefix fingerprint=%s (must be stable across requests)",
    _SYSTEM_PREFIX_FINGERPRINT,
)

# Sandbox tool names
SANDBOX_TOOLS = [
    "sandbox_exec",
    "sandbox_write_file",
    "sandbox_read_file",
    "sandbox_browse",
    "sandbox_info",
    "shell_exec",
    "shell_view",
    "shell_wait",
    "shell_write_stdin",
    "shell_kill",
    "file_str_replace",
    "python_exec",
    # Generic filesystem tools (backend-agnostic, preferred over sandbox_* above)
    "fs_read",
    "fs_write",
    "fs_edit",
    "fs_list",
]


def _sandbox_session_id(workspace_id: str) -> str:
    """Session-scoped sandbox key: reuse across tasks in same workspace."""
    return f"workspace:{workspace_id}"


def _format_events_summary(events: list) -> str:
    if not events:
        return ""
    lines: list[str] = []
    for e in events[-10:]:
        payload_summary = ", ".join(
            f"{k}={str(v)[:60]}" for k, v in list(e.payload.items())[:3]
        )
        lines.append(f"  [{e.kind.value}] source={e.source} {payload_summary}")
    return "\n".join(lines)


class AgentFactory:
    TASK_BUDGETS = {
        "quick": {
            "planner": {"max_iterations": 7, "max_tool_calls": 10, "max_runtime_seconds": 60},
            "executor": {"max_iterations": 6, "max_tool_calls": 8, "max_runtime_seconds": 50},
        },
        "standard": {
            "planner": {"max_iterations": 14, "max_tool_calls": 22, "max_runtime_seconds": 180},
            "executor": {"max_iterations": 10, "max_tool_calls": 16, "max_runtime_seconds": 150},
        },
        "deep": {
            "planner": {"max_iterations": 20, "max_tool_calls": 32, "max_runtime_seconds": 320},
            "executor": {"max_iterations": 14, "max_tool_calls": 24, "max_runtime_seconds": 260},
        },
    }

    ROLE_IDENTITY_MAP = {
        "planner": PLANNER_AGENT_IDENTITY,
        "executor": EXECUTOR_IDENTITY,
    }
    # ─────────────────────────────────────────────────────────────────────────
    # Tool sets per role — two-tier architecture:
    #
    #   Planner:  single entry point, orchestrates Executors
    #             tools: submit_plan, update_plan, spawn_subagent, file_*, message_*, idle
    #   Executor: generic Manus instance with full toolbox, self-decides how to complete goal
    #             tools: web_search, browser_*, file_*, submit_results, message_notify, idle
    # ─────────────────────────────────────────────────────────────────────────
    ROLE_TOOLS_MAP = {
        "planner": [
            # Planner: single entry point, decomposes goals, coordinates Executors
            "submit_plan",       # Round 1: produce structured Plan (MUST be first call)
            "update_plan",       # Execution rounds: dynamically modify active Plan
            "spawn_subagent",    # Sequential: dispatch one Executor Sub-agent
            "spawn_parallel",    # Parallel: dispatch multiple Executors concurrently
            "file_write", "file_read",
            "message_notify", "message_ask",
            "memory_query",      # Query workspace long-term memory for historical context
            "skill_load",        # Load full skill instructions on demand (LLM decides)
            "idle",
        ],
        "executor": [
            # Generic Executor: full toolbox, self-decides how to complete the goal
            "web_search",
            "browser_navigate", "browser_read", "browser_click", "browser_type",
            "file_read", "file_write",
            "submit_results",
            "message_notify",
            "skill_load",        # Load full skill instructions on demand (LLM decides)
            "idle",
        ],
    }

    # Roles that should have access to sandbox tools.
    SANDBOX_ENABLED_ROLES = {"planner", "executor"}

    def __init__(
        self,
        llm_provider: LLMProvider,
        model_router: ModelRouter,
        task_state: TaskState,
        artifact_store: ArtifactStore,
        memory_manager: MemoryManager,
        workspace_id: str,
        search_service: SearchService | None = None,
        # Deprecated: use search_service instead
        search_config: dict | None = None,
        notify_callback: Callable[[str, str, str, list[str] | None, str], None] | None = None,
        event_bus: EventBus | None = None,
        sandbox_provider: Optional[SandboxProvider] = None,
        critical_file_manager: CriticalFileManager | None = None,
        custom_tools: list[dict] | None = None,
        context_config: ContextConfig | None = None,
        skills_loader: SkillsLoader | None = None,
    ):
        self.llm_provider = llm_provider
        self.model_router = model_router
        self.task_state = task_state
        self.artifact_store = artifact_store
        self.memory_manager = memory_manager
        self.workspace_id = workspace_id
        # Prefer the injected SearchService; fall back to building one from raw config
        self.search_service = search_service or SearchService.from_config(search_config or {})
        self.notify_callback = notify_callback
        self.event_bus = event_bus
        self.sandbox_provider = sandbox_provider
        self.critical_file_manager = critical_file_manager
        self.custom_tools = custom_tools or []
        self.context_config = context_config or ContextConfig()
        self.skills_loader = skills_loader
        self.task_profile = "standard"
        # Module-level PromptLoader — reads AGENTS/USER/SOUL/TOOLS.md from prompts dir
        self._prompt_loader: PromptLoader = get_default_loader()

    def set_task_profile(self, profile: str) -> None:
        if profile in self.TASK_BUDGETS:
            self.task_profile = profile
        else:
            self.task_profile = "standard"

    def _budget_for_role(self, role: str) -> dict[str, int]:
        profile = self.TASK_BUDGETS.get(self.task_profile, self.TASK_BUDGETS["standard"])
        if role in profile:
            return dict(profile[role])
        return dict(self.TASK_BUDGETS["standard"]["executor"])

    def get_task_budget_summary(self) -> dict[str, object]:
        profile = self.TASK_BUDGETS.get(self.task_profile, self.TASK_BUDGETS["standard"])
        return {
            "profile": self.task_profile,
            "planner": profile["planner"],
            "executor": profile["executor"],
        }

    def _make_step_event_fn(
        self,
        workspace_id: str,
        task_id: str,
        source: str,
    ):
        """Build a step_event_fn closure that emits events to the event bus.

        Extracted to avoid duplicating the same 12-line closure in both
        _create_planner_agent and create_agent.
        """
        if not self.event_bus:
            return None
        from genagent_core.runtime.events import Event, EventKind
        _bus = self.event_bus
        _ws_id = workspace_id
        _KIND_MAP = {
            "tool_called": EventKind.TOOL_CALLED,
            "tool_result": EventKind.TOOL_RESULT,
            "agent_thinking": EventKind.AGENT_THINKING,
            "agent_message": EventKind.AGENT_MESSAGE,
        }

        async def _step_event(event_type: str, payload: dict) -> None:
            kind = _KIND_MAP.get(event_type)
            if not kind:
                return
            await _bus.emit(Event(
                kind=kind,
                task_id=task_id,
                workspace_id=_ws_id,
                payload=payload,
                source=source,
            ))

        return _step_event

    def _build_registry(
        self,
        task_id: str,
        step_id: str,
        producer: str,
        expected_output_schema: dict | None = None,
        submit_state: dict | None = None,
        session_id: str = "",
        enable_sandbox: bool = False,
        workspace_state: "WorkspaceState | None" = None,
        phase_id: str = "",  # phase_id for step marker path
    ) -> ToolRegistry:
        registry = ToolRegistry()

        async def _todo_writer(content: str) -> None:
            if self.sandbox_provider and session_id:
                try:
                    await self.sandbox_provider.write_file(session_id, "/home/ubuntu/task_plan.md", content)
                    # 初始化 findings.md 和 progress.md
                    await self.sandbox_provider.write_file(session_id, "/home/ubuntu/findings.md", "# Findings\n\n")
                    await self.sandbox_provider.write_file(session_id, "/home/ubuntu/progress.md", "# Progress Log\n\n")
                except Exception as e:
                    logger.warning("Failed to write planning files to sandbox: %s", e)

        async def _step_marker_writer(step_id_val: str) -> None:
            """Write a step-done marker file to sandbox for Executor step-level resume."""
            if self.sandbox_provider and session_id and phase_id:
                try:
                    marker_path = f"/home/ubuntu/artifacts/phase_{phase_id}/.step_{step_id_val}_done"
                    await self.sandbox_provider.write_file(session_id, marker_path, "done")
                    logger.info("Wrote step marker: %s", marker_path)
                except Exception as e:
                    logger.warning("Failed to write step marker to sandbox: %s", e)

        async def _todo_updater(sid: str, status: str, payload: dict | None = None) -> None:
            """Update the status of a specific step in task_plan.md and log to findings/progress."""
            if self.sandbox_provider and session_id:
                try:
                    todo_content = await self.sandbox_provider.read_file(session_id, "/home/ubuntu/task_plan.md")
                    if todo_content:
                        if status == "done":
                            # 将对应的 step 打勾
                            pattern = re.compile(r"^- \[ \] (.*?)\s*<!-- sid:" + re.escape(sid) + r" -->", re.MULTILINE)
                            new_todo_content = pattern.sub(r"- [x] \1 <!-- sid:" + sid + r" -->", todo_content)
                            if new_todo_content != todo_content:
                                await self.sandbox_provider.write_file(session_id, "/home/ubuntu/task_plan.md", new_todo_content)
                                
                            # 写入 progress.md
                            from datetime import datetime
                            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            progress_log = f"- {now_str} 完成步骤：{sid}\n"
                            await self.sandbox_provider.write_file(session_id, "/home/ubuntu/progress.md", progress_log, append=True)
                            
                            # 如果有产出，写入 findings.md
                            if payload and payload.get("output"):
                                output_summary = str(payload.get("output"))[:500]
                                findings_log = f"## Step {sid} Findings\n{output_summary}\n\n"
                                await self.sandbox_provider.write_file(session_id, "/home/ubuntu/findings.md", findings_log, append=True)
                                
                        elif status == "failed":
                            # 写入 Errors 表格
                            error_msg = payload.get("reason", "Unknown error") if payload else "Unknown error"
                            error_msg = error_msg.replace("\n", " ").replace("|", " ")[:100]
                            
                            # 查找 Errors 表格并追加
                            pattern = re.compile(r"(## Errors Encountered\n\| Error \| Attempt \| Resolution \|\n\|-------\|---------\|------------\|\n)", re.MULTILINE)
                            match = pattern.search(todo_content)
                            if match:
                                replacement = match.group(1) + f"| {error_msg} | 1 | 待重试 |\n"
                                new_todo_content = todo_content[:match.start()] + replacement + todo_content[match.end():]
                                await self.sandbox_provider.write_file(session_id, "/home/ubuntu/task_plan.md", new_todo_content)
                                
                            # 写入 progress.md
                            from datetime import datetime
                            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            progress_log = f"- {now_str} 步骤失败：{sid}，原因：{error_msg}\n"
                            await self.sandbox_provider.write_file(session_id, "/home/ubuntu/progress.md", progress_log, append=True)
                except Exception as e:
                    logger.warning("Failed to update task_plan.md step status: %s", e)


        register_system_tools(
            registry=registry,
            artifact_store=self.artifact_store,
            memory_manager=self.memory_manager,
            workspace_id=self.workspace_id,
            task_id=task_id,
            step_id=step_id,
            producer=producer,
            notify_callback=self.notify_callback,
            event_bus=self.event_bus,
            spawn_callback=self._spawn_callback,
            expected_output_schema=expected_output_schema,
            submit_state=submit_state,
            workspace_state=workspace_state,
            todo_writer=_todo_writer,
            todo_updater=_todo_updater,
            step_marker_writer=_step_marker_writer,
        )
        # Pass desktop_provider when the sandbox backend supports GUI operations
        _desktop_provider = None
        try:
            from genagent_core.sandbox.e2b_desktop_provider import DesktopSandboxProvider
            if isinstance(self.sandbox_provider, DesktopSandboxProvider):
                _desktop_provider = self.sandbox_provider
        except ImportError:
            pass

        register_workflow_tools(
            registry=registry,
            search_service=self.search_service,
            desktop_provider=_desktop_provider,
            session_id=session_id or "",
        )

        # Register skill_load tool — agent calls this at runtime to get full skill body
        try:
            from genagent_core.infra.tool_registry.skill_tools import register_skill_tools
            register_skill_tools(registry=registry)
        except Exception:
            logger.warning("Failed to register skill_tools", exc_info=True)

        # Register filesystem tools (fs_read / fs_write / fs_edit / fs_list)
        try:
            from genagent_core.infra.tool_registry.filesystem import register_filesystem_tools
            register_filesystem_tools(registry=registry)
        except Exception:
            logger.warning("Failed to register filesystem_tools", exc_info=True)

        # Register sandbox tools if provider is available and role supports it
        if enable_sandbox and self.sandbox_provider and session_id:
            try:
                from genagent_core.infra.tool_registry.sandbox_tools import register_sandbox_tools
                register_sandbox_tools(
                    registry=registry,
                    sandbox_provider=self.sandbox_provider,
                    session_id=session_id,
                    workspace_id=self.workspace_id,
                    task_id=task_id,
                    critical_file_manager=self.critical_file_manager,
                )
                logger.info(
                    "Sandbox tools registered for session %s (task=%s)",
                    session_id,
                    task_id,
                )
            except Exception:
                logger.warning(
                    "Failed to register sandbox tools for session %s",
                    session_id,
                    exc_info=True,
                )

        return registry


    async def _spawn_callback(
        self,
        workspace_id: str,
        task_id: str,
        goal: str,
        role: str,
        output_schema: dict | None = None,
        workspace: WorkspaceState | None = None,
        steps: list | None = None,  # micro-level steps from spawn_subagent
    ) -> dict:
        """Fork an Executor Sub-agent: create it, run it, return summary.

        改造点：
        - Executor 只接收 goal（自包含的任务描述）
        - Executor 完成后，将结果登记到 WorkspaceState
        - Workspace 状态由 Planner 持有，通过 snapshot 注入 Planner context
        """
        from genagent_core.orchestration.agent_runtime import AgentRuntime
        from genagent_core.runtime.events import Event, EventKind

        executor_id = f"sub_{role}_{uuid4().hex[:4]}"

        # 从 workspace 中找到对应的 plan phase（如果有活 Plan）
        # 必须在 event_bus 块外初始化，以便 step 标记读取逻辑也能使用
        phase_title = goal[:80]
        phase_id = ""
        if workspace is not None and workspace.active_plan is not None:
            pending = workspace.active_plan.get_next_pending()
            if pending:
                phase_title = pending.title
                phase_id = pending.id
                pending.start()  # 状态流转：pending → running

        # 发射 PHASE_START 事件（进度面板：当前阶段变为 ⟳ 运行中）
        if self.event_bus:
            await self.event_bus.emit(Event(
                kind=EventKind.PHASE_START,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "executor_id": executor_id,
                    "role": role,
                    "phase_id": phase_id,
                    "phase_title": phase_title,
                    "goal": goal[:200],
                    "progress_panel": workspace.active_plan.render_progress() if workspace and workspace.active_plan else "",
                },
                source="planner",
            ))

        # 更新沙盒中的 task_plan.md，将 steps 追加到对应的 Phase 下，并更新状态
        if phase_id and self.sandbox_provider and steps:
            session_id = _sandbox_session_id(workspace_id)
            try:
                todo_content = await self.sandbox_provider.read_file(session_id, "/home/ubuntu/task_plan.md")
                if todo_content:
                    # 更新 Current Phase
                    todo_content = re.sub(
                        r"(## Current Phase\n)(.*?)(?=\n\n)",
                        rf"\g<1>{phase_title}",
                        todo_content,
                        count=1
                    )
                    
                    # 查找对应的 Phase 标题行
                    pattern = re.compile(r"^(### Phase \d+: .*? <!-- id:" + re.escape(phase_id) + r" -->\n- \*\*Status:\*\* )pending$", re.MULTILINE)
                    match = pattern.search(todo_content)
                    if match:
                        # 构造要追加的 steps 列表
                        steps_lines = []
                        for s in steps:
                            sid = s.get("id", "")
                            action = s.get("action", "执行步骤")
                            steps_lines.append(f"- [ ] {action} <!-- sid:{sid} -->")
                        
                        # 替换：更新状态为 in_progress，并插入 steps
                        replacement = match.group(1) + "in_progress\n" + "\n".join(steps_lines)
                        new_todo_content = todo_content[:match.start()] + replacement + todo_content[match.end():]
                        
                        if new_todo_content != todo_content:
                            await self.sandbox_provider.write_file(session_id, "/home/ubuntu/task_plan.md", new_todo_content)
                            
                # 写入 progress.md 日志
                from datetime import datetime
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                progress_log = f"- {now_str} 开始执行阶段：{phase_title}\n"
                await self.sandbox_provider.write_file(session_id, "/home/ubuntu/progress.md", progress_log, append=True)
            except Exception as e:
                logger.warning("Failed to update task_plan.md or progress.md: %s", e)


        # ── 检查 Executor step 级别的断点续跑标记 ──
        done_steps = []
        if self.sandbox_provider and phase_id:
            session_id = _sandbox_session_id(workspace_id)
            if steps:
                for s in steps:
                    sid = s.get("id")
                    if sid:
                        marker_path = f"/home/ubuntu/artifacts/phase_{phase_id}/.step_{sid}_done"
                        try:
                            # If file exists, read_file will succeed
                            await self.sandbox_provider.read_file(session_id, marker_path)
                            done_steps.append(sid)
                            s["status"] = "done"  # Update status in steps list
                        except Exception:
                            pass

        # 如果有已完成的 step，注入到 goal 中
        if done_steps:
            done_list = ', '.join(done_steps)
            goal = (
                f"[断点续跑提示]\n"
                f"已完成步骤: {done_list} (见 artifacts/phase_{phase_id}/.step_*_done)\n"
                f"请直接从下一个未完成的步骤开始执行，不要重复已完成的工作。\n\n"
                f"[原始任务指令]\n"
                f"{goal}"
            )
            logger.info("Injected step resume hint for phase %s: %s", phase_id, done_steps)

        sub_agent = self.create_agent(
            role=role,
            workspace_id=workspace_id,
            task_id=task_id,
            task_instruction=goal,
            step_id=executor_id,
            expected_output_schema=output_schema,
            session_id=_sandbox_session_id(workspace_id),
            workspace_state=workspace,  # Artifact Memory: Executor 产物实时注册到 WorkspaceState
            executor_steps=steps,  # micro-level steps for mini-todo recitation
            phase_id=phase_id,  # step marker path prefix
        )
        runtime = AgentRuntime(artifact_store=self.artifact_store, storage=self.task_state.storage)
        result = await runtime.run_agent(sub_agent)

        # Extract submit_results payload if the executor called it
        submit_payload = sub_agent.submit_state.get("payload") or {}
        submit_status = sub_agent.submit_state.get("status", "not_submitted")
        submit_artifact_id = sub_agent.submit_state.get("artifact_id", "")
        submit_step_results = sub_agent.submit_state.get("step_results", [])

        # 将 Executor 结果登记到 WorkspaceState（如果 Planner 提供了 workspace）
        if workspace is not None:
            # 登记 artifact
            if submit_artifact_id:
                workspace.register_artifact(
                    artifact_id=submit_artifact_id,
                    artifact_type="result",
                    step_id=executor_id,
                    producer=executor_id,
                    summary=submit_payload.get("summary", "")[:100],
                )

            # 登记 Executor 执行记录
            next_suggestions = submit_payload.get("next_suggestions", [])
            if isinstance(next_suggestions, list):
                next_suggestions = [str(s) for s in next_suggestions[:3]]
            else:
                next_suggestions = []

            record = ExecutorRecord(
                executor_id=executor_id,
                role=role,
                goal=goal,
                status="success" if result.success else "failed",
                result_artifact_id=submit_artifact_id,
                result_summary=submit_payload.get("summary", "")[:200],
                next_suggestions=next_suggestions,
            )
            workspace.record_executor(record)
            logger.info(
                "WorkspaceState[%s] executor recorded: %s (%s) → artifact=%s",
                task_id, executor_id, role, submit_artifact_id or "none",
            )

            # 完成后将 running phase 标记为 done/failed
            if workspace.active_plan is not None:
                running_phases = [
                    p for p in workspace.active_plan.phases
                    if p.status == "in_progress"
                ]
                for p in running_phases:
                    if result.success:
                        p.complete(
                            artifact_id=submit_artifact_id,
                            summary=submit_payload.get("summary", "")[:200],
                            next_suggestions=next_suggestions,
                        )
                    else:
                        p.fail(submit_payload.get("summary", "")[:200] or result.error or "")

        # 发射 PHASE_DONE 事件（进度面板：当前阶段变为 ✓ 或 ✗）
        phase_title = goal[:80]
        phase_id = ""
        if workspace is not None and workspace.active_plan is not None:
            # 找刚刚完成的 phase（最后一个 done/failed）
            completed = [
                p for p in workspace.active_plan.phases
                if p.status in ("done", "failed")
            ]
            if completed:
                last = completed[-1]
                phase_title = last.title
                phase_id = last.id

        if self.event_bus:
            await self.event_bus.emit(Event(
                kind=EventKind.PHASE_DONE,
                task_id=task_id,
                workspace_id=workspace_id,
                payload={
                    "executor_id": executor_id,
                    "role": role,
                    "phase_id": phase_id,
                    "phase_title": phase_title,
                    "success": result.success,
                    "artifact_id": submit_artifact_id,
                    "progress_panel": workspace.active_plan.render_progress() if workspace and workspace.active_plan else "",
                },
                source="planner",
            ))

        # 注意：Phase 级别的打勾逻辑已移除，改为在 submit_results 中进行 step 级别的打勾。
        # 如果整个 Phase 失败，可以选择将该 Phase 下的所有 step 恢复为未开始，但为了保留现场，这里暂不回滚。

        # Build step_results: merge planned steps with executor's reported results
        merged_step_results: list[dict] = []
        if steps:
            reported = {sr["id"]: sr for sr in submit_step_results if isinstance(sr, dict) and "id" in sr}
            for s in steps:
                sid = s.get("id", "")
                if sid in reported:
                    merged_step_results.append(reported[sid])
                else:
                    # Step was planned but not reported — mark as skipped
                    merged_step_results.append({
                        "id": sid,
                        "action": s.get("action", ""),
                        "status": "skipped",
                        "reason": "Executor did not report this step.",
                    })
        else:
            merged_step_results = submit_step_results

        # ── Auto-save Checkpoint after each Executor completes ──────────────
        # This ensures that resume_task can always restore the latest Plan
        # state even if the process crashes before the task finishes.
        if workspace is not None:
            try:
                workspace.save_checkpoint(
                    storage=self.task_state.storage,
                    workspace_id=workspace_id,
                )
            except Exception:
                logger.warning(
                    "_spawn_callback: checkpoint save failed for task=%s (non-fatal)",
                    task_id,
                    exc_info=True,
                )

        return {
            "status": "completed" if result.success else "failed",
            "submit_status": submit_status,
            "completion_reason": result.completion_reason,
            "error": result.error or "",
            "result_artifact_id": submit_artifact_id,
            "result_payload": submit_payload,
            # Two-tier model: return micro-level step results for Planner observability
            "step_results": merged_step_results,
            "steps_summary": (
                f"{sum(1 for s in merged_step_results if s.get('status') == 'done')} done, "
                f"{sum(1 for s in merged_step_results if s.get('status') == 'failed')} failed, "
                f"{sum(1 for s in merged_step_results if s.get('status') == 'skipped')} skipped"
            ) if merged_step_results else "",
            "hint": "Use file_read(artifact_type='result') to retrieve full structured results.",
        }

    def create_agent(
        self,
        role: str,
        workspace_id: str,
        task_id: str,
        task_instruction: str,
        historical_memory: str = "",
        allowed_tools: "list[str] | None" = None,
        step_id: str = "",
        expected_output_schema: "dict | None" = None,
        session_id: str = "",
        workspace_state: "WorkspaceState | None" = None,
        executor_steps: "list[dict] | None" = None,
        phase_id: str = "",
        user_profile: "UserProfile | None" = None,
        tenant_id: str = "",
    ) -> ManusAgent:
        """Create a ManusAgent for the given role.

        Parameters
        ----------
        role:
            Agent role (``"planner"`` or ``"executor"``).  Any non-planner
            role resolves to the generic executor identity and toolset.
        workspace_id:
            Workspace identifier used for sandbox session scoping.
        task_id:
            Unique task identifier.
        task_instruction:
            The task text given to the agent.
        historical_memory:
            Recalled workspace memory text injected into the system prompt.
        allowed_tools:
            Optional override for the allowed tool list.  When ``None``,
            the role-default tool set from ``ROLE_TOOLS_MAP`` is used.
        step_id:
            Optional step identifier for artifact scoping.
        expected_output_schema:
            JSON schema that the agent's ``submit_results`` call must satisfy.
        session_id:
            Sandbox session identifier.  When empty, sandbox tools are disabled.
        workspace_state:
            Shared workspace state for Planner/Executor coordination.
        executor_steps:
            Micro-level steps for mini-todo recitation inside the agent loop.
        phase_id:
            Plan phase identifier for step marker path.
        user_profile:
            Optional per-user overrides for the USER.md prompt section.
        tenant_id:
            Optional tenant identifier for multi-tenant prompt overrides.
        """
        # Any role string is accepted as a logging/observability label.
        # Non-planner roles all resolve to the generic "executor" identity and toolset.
        canonical_role = role if role in self.ROLE_IDENTITY_MAP else "executor"
        agent_id = f"{role}_{uuid4().hex[:6]}"

        context = self._build_fresh_context(
            agent_id=agent_id,
            task_id=task_id,
            role=canonical_role,
            task_instruction=task_instruction,
            historical_memory=historical_memory,
            allowed_tools=allowed_tools,
            user_profile=user_profile,
            tenant_id=tenant_id,
        )
        model_string = self.model_router.route(canonical_role)

        # Determine if sandbox tools should be enabled for this role
        enable_sandbox = (
            self.sandbox_provider is not None
            and canonical_role in self.SANDBOX_ENABLED_ROLES
            and bool(session_id)
        )
        _allowed_tools = list(self.ROLE_TOOLS_MAP.get(canonical_role, self.ROLE_TOOLS_MAP["executor"]))
        if enable_sandbox:
            _allowed_tools.extend(SANDBOX_TOOLS)
        # If caller explicitly passed allowed_tools, merge them
        if allowed_tools:
            for t in allowed_tools:
                if t not in _allowed_tools:
                    _allowed_tools.append(t)

        submit_state: dict = {}
        registry = self._build_registry(
            task_id=task_id,
            step_id=step_id or role,
            producer=agent_id,
            expected_output_schema=expected_output_schema,
            submit_state=submit_state,
            session_id=session_id or task_id,
            enable_sandbox=enable_sandbox,
            workspace_state=workspace_state,
            phase_id=phase_id,
        )

        # Register custom tools
        for tool in self.custom_tools:
            registry.register(tool["name"], tool["schema"], tool["executor"])
            if role == "executor" and tool["name"] not in _allowed_tools:
                _allowed_tools.append(tool["name"])

        event_summary_fn = None
        if self.event_bus:
            def _build_summary() -> str:
                events = self.event_bus.query(task_id=task_id, limit=10)
                if not events:
                    return ""
                arts = self.artifact_store.get_latest(task_id=task_id) if hasattr(self.artifact_store, "get_latest") else []
                parts = [f"[事件流摘要 (最近 {len(events)} 条)]", _format_events_summary(events)]
                if arts:
                    art_lines = [f"  {a.artifact_type.value}/{a.step_id}: {a.artifact_id}" for a in arts[:5]]
                    parts.append("\n[已产出 Artifacts]\n" + "\n".join(art_lines))
                if enable_sandbox:
                    parts.append("\n[Sandbox] 沙盒环境已就绪，可使用 sandbox_exec / sandbox_write_file / sandbox_read_file 工具")
                return "\n".join(parts)
            event_summary_fn = _build_summary

        step_event_fn = self._make_step_event_fn(workspace_id, task_id, agent_id)
        budget = self._budget_for_role(role)

        # Build step_trim_callback if workspace_state is provided
        _step_trim_cb = None
        if workspace_state is not None:
            _ws = workspace_state
            def _trim_cb(summary: str) -> None:
                _ws.record_step_trim(summary)
            _step_trim_cb = _trim_cb

        ctx_cfg = self.context_config
        agent = ManusAgent(
            context=context,
            tool_registry=registry,
            llm_provider=self.llm_provider,
            model_string=model_string,
            allowed_tools=_allowed_tools,
            expected_output_schema=expected_output_schema,
            submit_state=submit_state,
            event_summary_fn=event_summary_fn,
            step_event_fn=step_event_fn,
            step_trim_callback=_step_trim_cb,
            executor_steps=executor_steps,
            model_token_limit=ctx_cfg.model_token_limit,
            compact_threshold_ratio=ctx_cfg.compact_threshold,
            summarize_threshold_ratio=ctx_cfg.summarize_threshold,
            max_tool_result_chars=ctx_cfg.max_tool_result_chars,
            step_trim_keep_recent=ctx_cfg.step_trim_keep_recent,
            max_iterations=budget["max_iterations"],
            max_tool_calls=budget["max_tool_calls"],
            max_runtime_seconds=budget["max_runtime_seconds"],
            allow_early_stop=True,
        )
        agent.submit_state = submit_state

        # ── Copy activated skill scripts into the sandbox (Level-3 skill disclosure) ──
        if enable_sandbox and session_id:
            sandbox_scripts = self._prompt_loader.get_sandbox_scripts(role=canonical_role)
            if sandbox_scripts:
                import asyncio
                _sp = self.sandbox_provider
                _sid = session_id

                async def _copy_skill_scripts() -> None:
                    for _path, _content in sandbox_scripts:
                        try:
                            await _sp.write_file(_sid, _path, _content)
                        except Exception as _exc:
                            logger.warning("[skill_scripts] failed to copy %s: %s", _path, _exc)

                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        asyncio.ensure_future(_copy_skill_scripts())
                    else:
                        loop.run_until_complete(_copy_skill_scripts())
                except Exception as _exc:
                    logger.warning("[skill_scripts] failed to schedule script copy: %s", _exc)

        return agent

    def _build_fresh_context(
        self,
        agent_id: str,
        task_id: str,
        role: str,
        task_instruction: str,
        historical_memory: str = "",
        allowed_tools: "list[str] | None" = None,
        user_profile: "UserProfile | None" = None,
        tenant_id: str = "",
    ) -> Context:
        """Build a fresh Context with system prompt and task instruction.

        Uses the timestamp-stripped system prefix to maintain a stable KV-cache key.
        The stable prefix ensures that all requests sharing the same system prompt
        can reuse cached KV states, reducing TTFT and inference cost.

        KV-cache health check:
        Every call verifies that the system prompt fingerprint has not drifted
        since the first call for this role.  A fingerprint change means the
        KV-cache will be invalidated on every request, which degrades latency
        and increases inference cost.
        """
        context = Context(agent_id=agent_id, task_id=task_id)

        # ── Assemble system prompt from modular Markdown files via PromptLoader ──────
        # PromptLoader handles:
        #   1. Role-scoped module selection (planner vs executor)
        #      - Planner: AGENTS.md + USER.md + SOUL.md + TOOLS.md
        #      - Executor: AGENTS.md + TOOLS.md (no USER/SOUL)
        #   2. Skill injection:
        #      - metadata_summary (all skills' descriptions, always in context)
        #      - ``always`` skills pre-injected here
        #      - ``on_demand`` skills fetched at runtime via skill_load tool
        #   3. Memory formatting and injection
        modular_system_prompt = self._prompt_loader.build(
            role=role,
            task_instruction=task_instruction,
            historical_memory=historical_memory,
            user_profile=user_profile,
            tenant_id=tenant_id,
        )

        # Append the role-specific identity (Planner / Executor behavioural contract)
        identity = self.ROLE_IDENTITY_MAP.get(role, self.ROLE_IDENTITY_MAP["executor"])
        system_prompt = f"{modular_system_prompt}\n\n{identity}" if modular_system_prompt else identity

        if allowed_tools:
            tool_contract = f'''\n<tool_contract>\nYou are only allowed to use the following tools: {sorted(allowed_tools)}\n</tool_contract>'''
            system_prompt += tool_contract

        # ── KV-cache health: verify prefix fingerprint on every agent creation ─────────
        # Manus blog: 'A common mistake is to include a timestamp at the beginning
        # of the system prompt — it degrades your cache hit rate.'
        clean_prompt = strip_timestamp_from_system_prompt(system_prompt)
        verify_prefix_unchanged(clean_prompt, role=role)
        # ────────────────────────────────────────────────────────────────────────

        context.add_system(clean_prompt)
        # Note: historical_memory is now injected via PromptLoader (formatted
        # inside the system prompt), so we do NOT call context.inject_memory()
        # here to avoid double-injection.

        # Inject executor focus for sub-agents
        if role != "planner":
            executor_focus = '''
<executor_focus>
- You are an executor sub-agent. Your goal is to complete the given task and submit the results.
- The `todo_*` tools are not available to you. The Planner is responsible for maintaining the overall task list.
- You MUST directly satisfy the `submit_results` schema provided in the goal.
</executor_focus>
'''
            context.add_user(executor_focus)

        context.add_user(task_instruction)
        return context
