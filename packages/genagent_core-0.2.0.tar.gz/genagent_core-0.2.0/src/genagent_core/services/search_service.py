"""Search service — encapsulates all web-search business logic.

This module is the single source of truth for how web searches are
performed.  It is intentionally decoupled from the Tool Registry so that:

- The service can be unit-tested without instantiating a ToolRegistry.
- The search provider can be swapped (Tavily → SerpAPI → mock) without
  touching any tool-registration code.
- The same service instance can be reused across multiple tool registries
  or called directly from other services (e.g. a future RAG pipeline).

Usage
-----
Instantiate once (e.g. in AppContainer) and inject into AgentFactory::

    service = SearchService.from_config(config.get("search", {}))
    factory = AgentFactory(..., search_service=service)

Then in workflow_tools.py the registration function receives the service
and wraps its methods as LLM-callable tools.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Literal

import httpx

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class SearchResult:
    """A single search result item."""

    title: str = ""
    url: str = ""
    snippet: str = ""
    content: str = ""

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "content": self.content,
        }


@dataclass
class SearchConfig:
    """Validated configuration for SearchService."""

    provider: Literal["tavily", "serpapi", "mock"] = "mock"
    max_queries: int = 3
    max_results_per_query: int = 5
    tavily_api_key: str = ""
    serpapi_api_key: str = ""

    @classmethod
    def from_dict(cls, cfg: dict) -> "SearchConfig":
        """Build a SearchConfig from a raw config dict (e.g. from config.json)."""
        provider = cfg.get("provider", "mock")
        if provider not in ("tavily", "serpapi", "mock"):
            logger.warning("Unknown search provider %r, falling back to mock", provider)
            provider = "mock"

        tavily_key = (
            cfg.get("tavily_api_key")
            or os.getenv(cfg.get("tavily_api_key_env", "TAVILY_API_KEY"), "")
        )
        serpapi_key = (
            cfg.get("serpapi_key")
            or os.getenv(cfg.get("serpapi_key_env", "SERPAPI_KEY"), "")
        )

        return cls(
            provider=provider,  # type: ignore[arg-type]
            max_queries=int(cfg.get("max_queries", 3)),
            max_results_per_query=int(cfg.get("max_results_per_query", 5)),
            tavily_api_key=tavily_key,
            serpapi_api_key=serpapi_key,
        )


# ---------------------------------------------------------------------------
# Provider implementations (pure functions, no registry coupling)
# ---------------------------------------------------------------------------

async def _tavily_search(
    query: str,
    api_key: str,
    max_results: int,
) -> list[SearchResult]:
    """Call the Tavily Search API and return normalised results."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.tavily.com/search",
            json={
                "query": query,
                "search_depth": "basic",
                "max_results": max_results,
                "api_key": api_key,
            },
        )
        resp.raise_for_status()
        data = resp.json()

    return [
        SearchResult(
            title=item.get("title", ""),
            url=item.get("url", ""),
            snippet=item.get("content", "")[:500],
            content=item.get("content", ""),
        )
        for item in data.get("results", [])
    ]


async def _serpapi_search(
    query: str,
    api_key: str,
    max_results: int,
) -> list[SearchResult]:
    """Call the SerpAPI Google Search endpoint and return normalised results."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            "https://serpapi.com/search",
            params={
                "q": query,
                "api_key": api_key,
                "engine": "google",
                "num": max_results,
            },
        )
        resp.raise_for_status()
        data = resp.json()

    return [
        SearchResult(
            title=item.get("title", ""),
            url=item.get("link", ""),
            snippet=item.get("snippet", "")[:500],
        )
        for item in data.get("organic_results", [])
    ]


def _mock_search(query: str) -> list[SearchResult]:
    """Return deterministic mock results for local development / testing."""
    return [
        SearchResult(
            title=f"Mock result 1 for '{query}'",
            url="https://example.com/1",
            snippet=f"Mock snippet for '{query}' #1",
        ),
        SearchResult(
            title=f"Mock result 2 for '{query}'",
            url="https://example.com/2",
            snippet=f"Mock snippet for '{query}' #2",
        ),
    ]


# ---------------------------------------------------------------------------
# SearchService — the public API consumed by workflow_tools.py
# ---------------------------------------------------------------------------

class SearchService:
    """Stateless search service that dispatches to the configured provider.

    This class owns **all** search business logic:
    - Provider selection and credential validation.
    - HTTP calls to external search APIs.
    - Result normalisation into :class:`SearchResult` objects.
    - Query deduplication.

    The Tool Registry layer (``workflow_tools.py``) is responsible only for:
    - Parsing LLM-supplied arguments.
    - Calling :meth:`search` or :meth:`search_batch`.
    - Serialising the returned results to JSON.
    """

    def __init__(self, config: SearchConfig) -> None:
        self._config = config

    @classmethod
    def from_config(cls, cfg: dict | None = None) -> "SearchService":
        """Convenience factory that accepts a raw config dict."""
        return cls(SearchConfig.from_dict(cfg or {}))

    @property
    def provider(self) -> str:
        return self._config.provider

    @property
    def max_queries(self) -> int:
        return self._config.max_queries

    async def search(self, query: str) -> list[SearchResult]:
        """Execute a single search query and return results.

        Parameters
        ----------
        query:
            The search query string.

        Returns
        -------
        list[SearchResult]
            Normalised results from the configured provider.

        Raises
        ------
        RuntimeError
            If the required API key is missing for the configured provider.
        """
        cfg = self._config

        if cfg.provider == "tavily":
            if not cfg.tavily_api_key:
                raise RuntimeError(
                    "Search provider=tavily but TAVILY_API_KEY is missing. "
                    "Set it in config.json or as an environment variable."
                )
            return await _tavily_search(query, cfg.tavily_api_key, cfg.max_results_per_query)

        if cfg.provider == "serpapi":
            if not cfg.serpapi_api_key:
                raise RuntimeError(
                    "Search provider=serpapi but SERPAPI_KEY is missing. "
                    "Set it in config.json or as an environment variable."
                )
            return await _serpapi_search(query, cfg.serpapi_api_key, cfg.max_results_per_query)

        # Default: mock
        logger.info("SearchService: using mock results for query=%r", query)
        return _mock_search(query)

    async def search_batch(self, queries: list[str]) -> list[tuple[str, list[SearchResult]]]:
        """Execute multiple queries in parallel.

        Parameters
        ----------
        queries:
            List of query strings.  Duplicates are removed while preserving
            order.  At most :attr:`max_queries` queries are executed.

        Returns
        -------
        list[tuple[str, list[SearchResult]]]
            Ordered list of ``(query, results)`` pairs.
        """
        import asyncio

        deduped = _dedupe_keep_order(queries)[: self._config.max_queries]
        results = await asyncio.gather(*[self.search(q) for q in deduped])
        return list(zip(deduped, results))


# ---------------------------------------------------------------------------
# Utility helpers (kept here so workflow_tools.py needs zero business logic)
# ---------------------------------------------------------------------------

def _dedupe_keep_order(values: list[str]) -> list[str]:
    """Remove duplicates from *values* while preserving insertion order."""
    seen: set[str] = set()
    out: list[str] = []
    for v in values:
        vv = v.strip()
        if not vv or vv in seen:
            continue
        seen.add(vv)
        out.append(vv)
    return out
