"""MCP (Model Context Protocol) integration for genagent-core."""
from .client import connect_mcp_servers, MCPToolWrapper

__all__ = ["connect_mcp_servers", "MCPToolWrapper"]
