"""MCP (Model Context Protocol) client for genagent-core.

Connects to MCP servers and registers their tools into the ToolRegistry.
Supports three transport types:
  - stdio: spawn a local subprocess (e.g. npx @modelcontextprotocol/server-filesystem)
  - sse: HTTP + Server-Sent Events endpoint
  - streamableHttp: HTTP streaming endpoint (default for plain URLs)

Transport type is auto-detected when not specified:
  - command present → stdio
  - url ending with /sse → sse
  - url present → streamableHttp

Usage::

    from genagent_core.mcp.client import connect_mcp_servers
    from contextlib import AsyncExitStack

    async with AsyncExitStack() as stack:
        await connect_mcp_servers(mcp_servers_config, tool_registry, stack)
        # tools are now registered and ready to use
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import AsyncExitStack
from typing import Any

import httpx

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schema normalization helpers (ported from nanobot)
# ---------------------------------------------------------------------------

def _extract_nullable_branch(options: Any) -> tuple[dict[str, Any], bool] | None:
    """Return the single non-null branch for nullable unions."""
    if not isinstance(options, list):
        return None
    non_null: list[dict[str, Any]] = []
    saw_null = False
    for option in options:
        if not isinstance(option, dict):
            return None
        if option.get("type") == "null":
            saw_null = True
            continue
        non_null.append(option)
    if saw_null and len(non_null) == 1:
        return non_null[0], True
    return None


def _normalize_schema_for_openai(schema: Any) -> dict[str, Any]:
    """Normalize nullable JSON Schema patterns for OpenAI Function Calling format."""
    if not isinstance(schema, dict):
        return {"type": "object", "properties": {}}
    normalized = dict(schema)
    raw_type = normalized.get("type")
    if isinstance(raw_type, list):
        non_null = [item for item in raw_type if item != "null"]
        if "null" in raw_type and len(non_null) == 1:
            normalized["type"] = non_null[0]
            normalized["nullable"] = True
    for key in ("oneOf", "anyOf"):
        nullable_branch = _extract_nullable_branch(normalized.get(key))
        if nullable_branch is not None:
            branch, _ = nullable_branch
            merged = {k: v for k, v in normalized.items() if k != key}
            merged.update(branch)
            normalized = merged
            normalized["nullable"] = True
            break
    if "properties" in normalized and isinstance(normalized["properties"], dict):
        normalized["properties"] = {
            name: _normalize_schema_for_openai(prop) if isinstance(prop, dict) else prop
            for name, prop in normalized["properties"].items()
        }
    if "items" in normalized and isinstance(normalized["items"], dict):
        normalized["items"] = _normalize_schema_for_openai(normalized["items"])
    if normalized.get("type") != "object":
        return normalized
    normalized.setdefault("properties", {})
    normalized.setdefault("required", [])
    return normalized


# ---------------------------------------------------------------------------
# MCP tool wrapper — adapts MCP tool to genagent-core ToolRegistry format
# ---------------------------------------------------------------------------

class MCPToolWrapper:
    """Wraps a single MCP server tool as a genagent-core async tool executor.

    The wrapper exposes:
      - ``name``: prefixed as ``mcp_{server_name}_{original_name}``
      - ``schema``: OpenAI Function Calling format dict
      - ``executor``: async callable returning a string result
    """

    def __init__(self, session: Any, server_name: str, tool_def: Any, tool_timeout: int = 30):
        self._session = session
        self._original_name = tool_def.name
        self._server_name = server_name
        self._tool_timeout = tool_timeout

        self.name = f"mcp_{server_name}_{tool_def.name}"
        raw_schema = tool_def.inputSchema or {"type": "object", "properties": {}}
        parameters = _normalize_schema_for_openai(raw_schema)

        self.schema = {
            "type": "function",
            "function": {
                "name": self.name,
                "description": tool_def.description or tool_def.name,
                "parameters": parameters,
            },
        }

    async def execute(self, **kwargs: Any) -> str:
        """Call the MCP tool and return a string result."""
        from mcp import types  # lazy import to keep mcp as optional dep

        try:
            result = await asyncio.wait_for(
                self._session.call_tool(self._original_name, arguments=kwargs),
                timeout=self._tool_timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("MCP tool '%s' timed out after %ds", self.name, self._tool_timeout)
            return f"(MCP tool call timed out after {self._tool_timeout}s)"
        except asyncio.CancelledError:
            task = asyncio.current_task()
            if task is not None and task.cancelling() > 0:
                raise
            logger.warning("MCP tool '%s' was cancelled by server/SDK", self.name)
            return "(MCP tool call was cancelled)"
        except Exception as exc:
            logger.exception("MCP tool '%s' failed: %s: %s", self.name, type(exc).__name__, exc)
            return f"(MCP tool call failed: {type(exc).__name__}: {exc})"

        parts = []
        for block in result.content:
            if isinstance(block, types.TextContent):
                parts.append(block.text)
            else:
                parts.append(str(block))
        return "\n".join(parts) or "(no output)"


# ---------------------------------------------------------------------------
# connect_mcp_servers — main entry point
# ---------------------------------------------------------------------------

async def connect_mcp_servers(
    mcp_servers: dict,  # dict[str, MCPServerConfig]
    registry: Any,     # ToolRegistry
    stack: AsyncExitStack,
) -> None:
    """Connect to all configured MCP servers and register their tools.

    Args:
        mcp_servers: Mapping of server name → MCPServerConfig.
        registry: genagent-core ToolRegistry to register tools into.
        stack: AsyncExitStack that owns the MCP transport lifetimes.
            The caller must keep this stack open for as long as the tools
            are in use.
    """
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    from mcp.client.sse import sse_client
    from mcp.client.streamable_http import streamable_http_client

    for name, cfg in mcp_servers.items():
        try:
            transport_type = cfg.type
            if not transport_type:
                if cfg.command:
                    transport_type = "stdio"
                elif cfg.url:
                    transport_type = "sse" if cfg.url.rstrip("/").endswith("/sse") else "streamableHttp"
                else:
                    logger.warning("MCP server '%s': no command or url configured, skipping", name)
                    continue

            if transport_type == "stdio":
                params = StdioServerParameters(
                    command=cfg.command,
                    args=cfg.args,
                    env=cfg.env or None,
                )
                read, write = await stack.enter_async_context(stdio_client(params))

            elif transport_type == "sse":
                def _httpx_factory(
                    headers: dict[str, str] | None = None,
                    timeout: httpx.Timeout | None = None,
                    auth: httpx.Auth | None = None,
                    _cfg=cfg,
                ) -> httpx.AsyncClient:
                    merged = {**(_cfg.headers or {}), **(headers or {})}
                    return httpx.AsyncClient(
                        headers=merged or None,
                        follow_redirects=True,
                        timeout=timeout,
                        auth=auth,
                    )
                read, write = await stack.enter_async_context(
                    sse_client(cfg.url, httpx_client_factory=_httpx_factory)
                )

            elif transport_type == "streamableHttp":
                http_client = await stack.enter_async_context(
                    httpx.AsyncClient(
                        headers=cfg.headers or None,
                        follow_redirects=True,
                        timeout=None,
                    )
                )
                read, write, _ = await stack.enter_async_context(
                    streamable_http_client(cfg.url, http_client=http_client)
                )
            else:
                logger.warning("MCP server '%s': unknown transport type '%s'", name, transport_type)
                continue

            session = await stack.enter_async_context(ClientSession(read, write))
            await session.initialize()
            tools_result = await session.list_tools()

            enabled_tools = set(cfg.enabled_tools)
            allow_all = "*" in enabled_tools
            registered_count = 0

            for tool_def in tools_result.tools:
                wrapped_name = f"mcp_{name}_{tool_def.name}"
                if (
                    not allow_all
                    and tool_def.name not in enabled_tools
                    and wrapped_name not in enabled_tools
                ):
                    logger.debug(
                        "MCP: skipping tool '%s' from server '%s' (not in enabled_tools)",
                        wrapped_name, name,
                    )
                    continue

                wrapper = MCPToolWrapper(session, name, tool_def, tool_timeout=cfg.tool_timeout)
                registry.register(wrapper.name, wrapper.schema, wrapper.execute)
                logger.debug("MCP: registered tool '%s' from server '%s'", wrapper.name, name)
                registered_count += 1

            logger.info(
                "MCP server '%s': connected, %d tools registered", name, registered_count
            )

        except Exception as exc:
            logger.error("MCP server '%s': failed to connect: %s", name, exc)
