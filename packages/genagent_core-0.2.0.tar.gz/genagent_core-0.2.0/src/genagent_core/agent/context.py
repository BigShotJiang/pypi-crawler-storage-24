from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from genagent_core.infra.storage import StorageBackend

# Lazy import to avoid circular dependency
def _format_todo(items: list[str], phase_title: str = "") -> str:
    try:
        from genagent_core.agent.context_engineering import format_todo_for_context
        return format_todo_for_context(items, phase_title=phase_title)
    except ImportError:
        lines = []
        for item in items:
            is_done = item.startswith("[x]") or item.startswith("✓")
            clean = item.lstrip("[x] ").lstrip("[ ] ").strip()
            marker = "✓" if is_done else "○"
            lines.append(f"  {marker} {clean}")
        return "\n".join(lines)


class EventType(str, Enum):
    SYSTEM = "system"
    INSTRUCTION = "instruction"
    ACTION = "action"
    OBSERVATION = "observation"
    PLAN = "plan"
    MEMORY = "memory"
    TODO = "todo"
    WORKSPACE = "workspace"  # Workspace state snapshot, injected before each Planner turn


class Context:
    """Event-stream-based context for Agent cognition.

    Internally wraps OpenAI-compatible messages format while providing
    a typed event stream interface aligned with Manus architecture.
    """

    def __init__(self, agent_id: str = "", task_id: str = ""):
        self.messages: list[dict[str, Any]] = []
        self.agent_id = agent_id
        self.task_id = task_id
        self._todo_items: list[str] = []

    def add_system(self, content: str) -> None:
        self.messages.append({"role": "system", "content": content})

    def add_user(self, content: str) -> None:
        self.messages.append({"role": "user", "content": content})

    def add_assistant_text(self, content: str) -> None:
        self.messages.append({"role": "assistant", "content": content})

    def add_assistant_tool_call(self, tool_calls: list[dict]) -> None:
        self.messages.append({"role": "assistant", "tool_calls": tool_calls})

    def add_tool_result(self, tool_call_id: str, content: str) -> None:
        self.messages.append({"role": "tool", "tool_call_id": tool_call_id, "content": content})

    def inject_event(self, event_type: EventType, content: str) -> None:
        """Inject a typed event into the stream as a user message with XML tags."""
        tagged = f"<{event_type.value}>\n{content}\n</{event_type.value}>"
        self.messages.append({"role": "user", "content": tagged})

    def inject_plan(self, plan_text: str) -> None:
        self.inject_event(EventType.PLAN, plan_text)

    def inject_memory(self, memory_text: str) -> None:
        self.inject_event(EventType.MEMORY, memory_text)

    def inject_workspace(self, snapshot_text: str) -> None:
        """Inject a Workspace state snapshot before each Planner decision turn.

        Unlike inject_memory (one-time), workspace snapshots are pushed every
        iteration so the Planner always sees the latest state.
        """
        self.inject_event(EventType.WORKSPACE, snapshot_text)

    def update_todo(self, items: list[str], phase_title: str = "") -> None:
        """Rewrite todo list into the most recent position in context.

        Manus pattern: continuously push the todo list to the end of context
        to keep global objectives in the model's recent attention window,
        avoiding the 'lost-in-the-middle' problem.

        The format uses context_engineering.format_todo_for_context which
        applies controlled variation to prevent few-shot pattern fixation.
        """
        self._todo_items = items
        self._todo_phase_title = phase_title
        todo_text = _format_todo(items, phase_title=phase_title)
        self.inject_event(EventType.TODO, todo_text)

    def get_todo_items(self) -> list[str]:
        return list(self._todo_items)

    def snapshot(self, storage: StorageBackend, reason: str = "") -> str:
        snapshot_data = {
            "agent_id": self.agent_id,
            "task_id": self.task_id,
            "messages": self.messages,
            "todo_items": self._todo_items,
            "reason": reason,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        safe_reason = reason.replace(":", "_").replace("/", "_")[:50]
        path = f"tasks/{self.task_id}/snapshots/{self.agent_id}_{safe_reason}.json"
        storage.write_json(path, snapshot_data)
        return path

    @classmethod
    def from_snapshot(cls, storage: StorageBackend, snapshot_path: str) -> "Context":
        data = storage.read_json(snapshot_path)
        ctx = cls(agent_id=data.get("agent_id", ""), task_id=data.get("task_id", ""))
        ctx.messages = data.get("messages", [])
        ctx._todo_items = data.get("todo_items", [])
        return ctx

    def to_json(self, max_messages: int = 0) -> str:
        """Serialize context to JSON string for sharing with sub-agents.

        Args:
            max_messages: If > 0, only include the last N messages to limit size.
        """
        import json
        messages = self.messages
        if max_messages > 0 and len(messages) > max_messages:
            # Always keep system message (index 0) + last N messages
            system_msgs = [m for m in messages if m.get("role") == "system"]
            recent_msgs = messages[-max_messages:]
            # Merge without duplicates
            merged = system_msgs + [
                m for m in recent_msgs if m not in system_msgs
            ]
            messages = merged
        return json.dumps(
            {
                "agent_id": self.agent_id,
                "task_id": self.task_id,
                "messages": messages,
                "todo_items": self._todo_items,
            },
            ensure_ascii=False,
        )

    @classmethod
    def from_json(cls, json_str: str) -> "Context":
        """Deserialize context from JSON string (for sub-agent context sharing)."""
        import json
        data = json.loads(json_str)
        ctx = cls(agent_id=data.get("agent_id", ""), task_id=data.get("task_id", ""))
        ctx.messages = data.get("messages", [])
        ctx._todo_items = data.get("todo_items", [])
        return ctx
