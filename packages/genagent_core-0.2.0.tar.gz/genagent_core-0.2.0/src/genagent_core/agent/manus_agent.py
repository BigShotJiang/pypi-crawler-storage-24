from __future__ import annotations

import json
import logging
import time
from enum import Enum
from typing import Any

from genagent_core.agent.context import Context, EventType
from genagent_core.agent.context_engineering import (
    compact_messages_recoverable,
    compact_then_summarize,
    format_error_observation,
    inject_variation_noise,
    summarise_removed_steps,
    validate_append_only,
)
from genagent_core.infra.llm_provider import LLMProvider
from genagent_core.infra.tool_registry.registry import ToolRegistry

logger = logging.getLogger(__name__)

def _s(text: Any, limit: int = 80) -> str:
    v = str(text).replace("\n", " ").strip()
    if len(v) <= limit:
        return v
    return v[:limit] + "..."


def _describe_tool_call(tool_name: str, args: dict[str, Any]) -> str:
    if tool_name == "web_search":
        queries = args.get("queries")
        if isinstance(queries, list) and queries:
            return f"并行检索 {len(args['queries'])} 组关键词"
        if isinstance(queries, str) and queries.strip():
            return "检索相关信息"
        if args.get("query"):
            return "检索相关信息"
        return "检索相关信息"
    if tool_name == "browser_navigate":
        return f"访问页面：{_s(args.get('url', ''), 90)}"
    if tool_name == "browser_view":
        return "读取当前网页正文内容"
    if tool_name == "file_write":
        artifact_type = _s(args.get("artifact_type", "artifact"), 24)
        content = str(args.get("content", ""))
        size_hint = f"{len(content)}字" if content else "未提供正文"
        return f"写入{artifact_type}产物（{size_hint}）"
    if tool_name == "file_read":
        task_id = _s(args.get("task_id", ""), 18)
        artifact_type = _s(args.get("artifact_type", ""), 20)
        if task_id and artifact_type:
            return f"读取产物（task={task_id}, type={artifact_type}）"
        if artifact_type:
            return f"读取{artifact_type}产物"
        return "读取已有产物"
    if tool_name == "spawn_subagent":
        role = _s(args.get("role", "agent"), 16)
        goal = _s(args.get("goal", ""), 80)
        return f"派发{role}执行子任务：{goal}" if goal else f"派发{role}执行子任务"
    if tool_name == "submit_results":
        status = _s(args.get("status", "success"), 16)
        summary = _s(args.get("summary", ""), 60)
        return f"提交执行结果（{status}）：{summary}" if summary else f"提交执行结果（{status}）"
    if tool_name == "message_notify":
        return f"给用户同步进展：{_s(args.get('text', ''), 80)}"
    if tool_name == "message_ask":
        return f"向用户提问：{_s(args.get('text', ''), 80)}"
    if tool_name == "memory_query":
        return f"查询历史记忆：{_s(args.get('query', ''), 80)}"
    if tool_name == "idle":
        return "声明任务完成"
    # Sandbox tools
    if tool_name == "sandbox_exec":
        cmd = _s(args.get("command", ""), 100)
        return f"在沙盒中执行命令：{cmd}"
    if tool_name == "sandbox_write_file":
        path = _s(args.get("path", ""), 60)
        return f"在沙盒中写入文件：{path}"
    if tool_name == "sandbox_read_file":
        path = _s(args.get("path", ""), 60)
        return f"在沙盒中读取文件：{path}"
    if tool_name == "sandbox_browse":
        url = _s(args.get("url", ""), 90)
        return f"在沙盒中访问URL：{url}"
    if tool_name == "sandbox_info":
        return "查询沙盒环境信息"
    return f"{tool_name}({', '.join(f'{k}={_s(v, 36)}' for k, v in list(args.items())[:2])})"


def _describe_tool_result(tool_name: str, args: dict[str, Any], result: str) -> str:
    if tool_name == "web_search":
        try:
            parsed = json.loads(result)
            if isinstance(parsed, dict) and isinstance(parsed.get("batch"), list):
                batches = parsed["batch"]
                total = sum(len((b or {}).get("results", [])) for b in batches if isinstance(b, dict))
                return f"检索完成：{len(batches)}组关键词，共返回约{total}条结果。"
            if isinstance(parsed, list):
                return f"检索完成：返回{len(parsed)}条结果。"
        except Exception:
            pass
        return "检索完成，已得到搜索结果。"
    if tool_name == "browser_navigate":
        return f"页面已打开：{_s(args.get('url', ''), 90)}"
    if tool_name == "browser_view":
        return "网页正文已读取，可用于抽取价格与条款信息。"
    if tool_name == "file_write":
        artifact_type = _s(args.get("artifact_type", "artifact"), 24)
        return f"{artifact_type}产物已保存。"
    if tool_name == "file_read":
        if "[]" in result:
            return "未读取到匹配产物，准备调整读取条件。"
        return "已读取到历史产物，进入下一步整理。"
    if tool_name == "spawn_subagent":
        return "执行子任务已派发，等待其产出并回收结果。"
    if tool_name == "submit_results":
        try:
            parsed = json.loads(result)
            if isinstance(parsed, dict):
                artifact_id = parsed.get("artifact_id", "")
                if artifact_id:
                    return f"结果已提交，artifact_id={artifact_id}。"
        except Exception:
            pass
        return "结果已成功提交给 Planner。"
    if tool_name == "message_notify":
        return "已向用户同步当前进度。"
    if tool_name == "message_ask":
        return "已向用户发起问题，等待回复。"
    # Sandbox tools
    if tool_name == "sandbox_exec":
        try:
            parsed = json.loads(result)
            if isinstance(parsed, dict):
                exit_code = parsed.get("exit_code", "?")
                return f"沙盒命令执行完成（exit_code={exit_code}）。"
        except Exception:
            pass
        return "沙盒命令执行完成。"
    if tool_name == "sandbox_write_file":
        return f"沙盒文件已写入：{_s(args.get('path', ''), 60)}"
    if tool_name == "sandbox_read_file":
        return f"沙盒文件已读取：{_s(args.get('path', ''), 60)}"
    if tool_name == "sandbox_browse":
        return "沙盒URL访问完成。"
    if tool_name == "sandbox_info":
        return "沙盒信息已获取。"
    return "工具执行完成。"


class ToolChoiceMode(str, Enum):
    AUTO = "auto"
    REQUIRED = "required"
    SPECIFIED = "specified"


class ManusAgent:
    """Manus-style agent: autonomous multi-tool loop, event-stream driven."""

    def __init__(
        self,
        context: Context,
        tool_registry: ToolRegistry,
        llm_provider: LLMProvider,
        model_string: str,
        allowed_tools: list[str],
        expected_output_schema: dict | None = None,
        submit_state: dict | None = None,
        enable_reflection: bool = True,
        tool_choice: ToolChoiceMode = ToolChoiceMode.AUTO,
        event_summary_fn: object | None = None,
        step_event_fn: object | None = None,
        model_token_limit: int = 128_000,
        compact_threshold_ratio: float = 0.75,
        summarize_threshold_ratio: float = 0.90,
        max_tool_result_chars: int = 3000,
        step_trim_keep_recent: int = 8,
        step_trim_callback: "object | None" = None,
        executor_steps: "list[dict] | None" = None,
        max_iterations: int = 25,
        max_tool_calls: int = 40,
        max_runtime_seconds: int = 180,
        allow_early_stop: bool = True,
    ):
        self.context = context
        self.tool_registry = tool_registry
        self.llm_provider = llm_provider
        self.model_string = model_string
        self.allowed_tools = allowed_tools
        self.expected_output_schema = expected_output_schema
        self.submit_state = submit_state if submit_state is not None else {}
        self.enable_reflection = enable_reflection
        self.tool_choice = tool_choice
        self._event_summary_fn = event_summary_fn
        self._step_event_fn = step_event_fn
        # Context management settings
        self._model_token_limit = model_token_limit
        self._compact_threshold_ratio = compact_threshold_ratio
        self._summarize_threshold_ratio = summarize_threshold_ratio
        self._max_tool_result_chars = max_tool_result_chars
        self._step_trim_keep_recent = step_trim_keep_recent
        # Optional callback: (summary_text: str) -> None
        # Called after step trimming so callers (e.g. WorkspaceState) can
        # persist the summary of removed steps.
        self._step_trim_callback = step_trim_callback
        self._trimmed_steps_count: int = 0
        # Track per-tool error counts for structured error observations.
        # Initialized here (not lazily in run()) to avoid hasattr anti-pattern.
        self._error_counts: dict[str, int] = {}
        # ── Executor steps mini-todo ──────────────────────────────────────────
        # Manus pattern: Planner injects micro-level steps[] via spawn_subagent.
        # We store a mutable copy so the run loop can track per-step status
        # and rewrite pending steps to the tail of context every iteration,
        # keeping the Executor's local objective in the recent attention window.
        # This mirrors the global todo-recitation mechanism but scoped to the
        # current sub-task — preventing goal drift in long Executor loops.
        self._executor_steps: list[dict] = [
            dict(s) for s in (executor_steps or [])
        ]
        self._max_iterations = max(1, int(max_iterations))
        self._max_tool_calls = max(1, int(max_tool_calls))
        self._max_runtime_seconds = max(10, int(max_runtime_seconds))
        self._allow_early_stop = bool(allow_early_stop)
        self._streamed_delta_in_iteration = False

    async def run(self, max_iterations: int | None = None) -> str:
        """Manus-style agent loop: exactly one tool call per iteration."""
        max_iters = max(1, int(max_iterations or self._max_iterations))
        started_at = time.monotonic()
        tool_calls_used = 0
        no_tool_rounds = 0
        repeated_action_count = 0
        last_action_signature = ""
        unresolved_retry_injected = False
        for i in range(max_iters):
            if time.monotonic() - started_at >= self._max_runtime_seconds:
                return "completed:budget_runtime_seconds"
            self._inject_event_summary()
            # ── Compact-first → Summarize-last compression hierarchy ───────────────
            # Manus blog: 'We apply Compact first.  Summarization is a last
            # resort because any irreversible compression carries risk.'
            #
            # Phase 1 (Compact, reversible): truncate long tool results while
            #   keeping all recovery anchors (URLs, paths, artifact_ids).
            # Phase 2 (Summarize, last resort): only when Compact alone is
            #   insufficient (≥ 90% of model limit after Phase 1).
            #   Old rounds are removed; error messages are always preserved.
            new_msgs, action = compact_then_summarize(
                self.context.messages,
                model_token_limit=self._model_token_limit,
                compact_threshold_ratio=self._compact_threshold_ratio,
                summarize_threshold_ratio=self._summarize_threshold_ratio,
                keep_recent=self._step_trim_keep_recent,
                max_tool_result_chars=self._max_tool_result_chars,
            )
            if action != "none":
                if action == "compact+summarize":
                    # Summarize phase: extract what was removed and persist summary
                    removed = [
                        m for m in self.context.messages
                        if m not in new_msgs
                        and m.get("role") != "system"
                    ]
                    if removed:
                        summary = summarise_removed_steps(removed)
                        self._trimmed_steps_count += len(removed)
                        logger.info(
                            "[compact_then_summarize] agent=%s removed=%d messages "
                            "(total_trimmed=%d)",
                            self.context.agent_id, len(removed), self._trimmed_steps_count,
                        )
                        # Inject trim summary note into context
                        trim_note = (
                            f"<step_trim_summary>\n"
                            f"已压缩 {len(removed)} 条历史消息（共累计 {self._trimmed_steps_count} 条）。\n"
                            f"压缩摘要：\n{summary}\n"
                            f"</step_trim_summary>"
                        )
                        new_msgs.append({"role": "user", "content": trim_note})
                        if self._step_trim_callback is not None:
                            try:
                                self._step_trim_callback(summary)
                            except Exception:
                                logger.debug("step_trim_callback failed", exc_info=True)
                self.context.messages = new_msgs
            # ────────────────────────────────────────────────────────────────
            self._streamed_delta_in_iteration = False
            response = await self._think(iteration=i + 1)
            message = response.get("message", {})
            tool_calls = message.get("tool_calls", [])

            if message.get("content"):
                await self._emit_thinking(message["content"], iteration=i + 1)

            if not tool_calls:
                no_tool_rounds += 1
                if message.get("content"):
                    content_text = str(message["content"])
                    if (
                        not unresolved_retry_injected
                        and self._should_force_tool_retry(content_text)
                    ):
                        unresolved_retry_injected = True
                        self.context.add_user(
                            "<runtime_guard>\n"
                            "你刚才给出的答复仍是未完成状态（例如“无法获取/请用户自行查看”），"
                            "且当前可用工具足以继续执行。请不要结束，下一步必须调用至少一个可用工具，"
                            "基于工具观测结果给出可验证答案；仅在工具失败且已尝试替代方案后再说明阻塞。\n"
                            "</runtime_guard>"
                        )
                        continue
                    self.context.add_assistant_text(message["content"])
                    await self._emit_agent_message(message["content"], iteration=i + 1)
                if self._allow_early_stop and no_tool_rounds >= 2:
                    return "completed:early_stop_no_tool_progress"
                return "completed:no_tool_call"
            if self._streamed_delta_in_iteration:
                await self._emit_agent_delta_clear(iteration=i + 1)
            no_tool_rounds = 0

            selected_tc: dict | None = None
            for tc in tool_calls:
                if not self._is_idle(tc):
                    selected_tc = tc
                    break
            if selected_tc is None:
                # If model returns only `idle` tool_call plus content, treat content as final answer.
                if message.get("content"):
                    self.context.add_assistant_text(message["content"])
                    await self._emit_agent_message(message["content"], iteration=i + 1)
                return "completed:idle"

            tool_name = selected_tc["function"]["name"]
            raw_args = selected_tc["function"].get("arguments", "{}")
            try:
                tool_args = json.loads(raw_args)
            except json.JSONDecodeError:
                tool_args = {}

            action_signature = f"{tool_name}:{json.dumps(tool_args, ensure_ascii=False, sort_keys=True)[:240]}"
            if action_signature == last_action_signature:
                repeated_action_count += 1
            else:
                last_action_signature = action_signature
                repeated_action_count = 1
            if self._allow_early_stop and repeated_action_count >= 3:
                return "completed:early_stop_repeated_action"
            if tool_calls_used >= self._max_tool_calls:
                return "completed:budget_tool_calls"

            await self._emit_tool_called(selected_tc, tool_args, iteration=i + 1)
            try:
                result_str = str(await self._act_parsed(tool_name, tool_args))
            except Exception as exc:
                # Preserve error in context — never erase failed attempts.
                # Manus blog: 'Keep failed attempts in context. When the model
                # sees a failed action it implicitly updates its internal beliefs.'
                self._error_counts[tool_name] = self._error_counts.get(tool_name, 0) + 1
                result_str = format_error_observation(
                    tool_name=tool_name,
                    args=tool_args,
                    error=f"{type(exc).__name__}: {exc}",
                    attempt=self._error_counts[tool_name],
                )

            self.context.add_assistant_tool_call([selected_tc])
            self.context.add_tool_result(selected_tc["id"], result_str)

            # Push structured tool results needed by UI panels.
            if tool_name in {
                "submit_results",
                "web_search",
                "browser_navigate",
                "browser_view",
                "sandbox_exec",
                "sandbox_write_file",
                "sandbox_read_file",
                "sandbox_browse",
                "sandbox_info",
            }:
                await self._emit_tool_result(selected_tc, tool_args, result_str, iteration=i + 1)
            tool_calls_used += 1

            # ── Attention management: todo recitation ───────────────────────────────
            # Manus blog: 'By continuously rewriting the todo list, Manus
            # recites its objectives to the end of the context — avoiding
            # the lost-in-the-middle problem.'
            #
            # Two-tier recitation:
            #   Tier 1 (Executor): if Planner provided steps[], rewrite pending
            #     steps to context tail every iteration as a micro-level todo.
            #     This prevents goal drift in long Executor loops.
            #   Tier 2 (Planner / fallback): the existing todo_items mechanism.

            # Tier 1: Executor steps mini-todo
            # When submit_results is called with step_results, sync statuses first.
            if tool_name == "submit_results" and self._executor_steps:
                reported = {}
                try:
                    result_parsed = json.loads(result_str)
                    if isinstance(result_parsed, dict):
                        # submit_results succeeded — pull step_results from the
                        # payload that was passed in (tool_args), not the response.
                        for sr in tool_args.get("step_results") or []:
                            if isinstance(sr, dict) and sr.get("id"):
                                reported[sr["id"]] = sr.get("status", "done")
                except Exception:
                    pass
                for s in self._executor_steps:
                    sid = s.get("id", "")
                    if sid in reported:
                        s["status"] = reported[sid]

            if self._executor_steps:
                # Build pending-step mini-todo and push to context tail
                pending_text = self._pending_steps_text()
                if pending_text:
                    self.context.inject_event(EventType.TODO, pending_text)
                # All steps done: fall through to Tier 2 (goal-reminder)
                elif i > 0:
                    self._inject_goal_reminder()
            # Tier 2: goal-reminder fallback
            else:
                # Recite existing todo list unconditionally every iteration
                todo_items = self.context.get_todo_items()
                if todo_items:
                    self.context.update_todo(todo_items)
                # If no todo list yet, inject a lightweight goal-reminder so the
                # model always has its objective in the recent attention window.
                elif i > 0:
                    self._inject_goal_reminder()
            # ────────────────────────────────────────────────────────────────

            # Anti few-shot fixation: inject minor structural variation into recent
            # tool result messages to prevent the model from pattern-matching on
            # repetitive action-observation pairs.
            # Manus blog: 'The more homogeneous your context, the more brittle your agent.'
            if i > 0 and i % 3 == 0:
                task_id = self.context.task_id or ""
                self.context.messages = inject_variation_noise(
                    self.context.messages, task_id=task_id, max_vary=2
                )

            if self.enable_reflection and i > 0 and i % 5 == 0:
                self._reflect(i)

        return "terminated:max_iterations"

    def _latest_user_text(self) -> str:
        for msg in reversed(self.context.messages):
            if msg.get("role") != "user":
                continue
            c = str(msg.get("content", ""))
            if c.startswith("<"):
                continue
            return c
        return ""

    def _has_actionable_tools(self) -> bool:
        non_actionable = {"message_notify", "message_ask", "idle"}
        return any(t not in non_actionable for t in self.allowed_tools)

    def _is_smalltalk(self, text: str) -> bool:
        s = text.strip().lower()
        if not s:
            return True
        smalltalk_tokens = {
            "hi", "hello", "hey", "你好", "在吗", "谢谢", "thank you", "thx", "ok", "好的",
        }
        if s in smalltalk_tokens:
            return True
        return len(s) <= 4 and s in {"嗯", "哦", "好", "在"}

    def _looks_unresolved_response(self, content: str) -> bool:
        text = content.strip().lower()
        if not text:
            return True
        unresolved_signals = [
            "无法直接获取", "我无法获取", "不能获取", "无法确认", "请查看手机", "请查看电脑", "请看日历",
            "你可以查看", "你可以自己", "我不能访问", "我无法访问", "我无法浏览", "无法联网",
            "i can't access", "i cannot access", "as an ai", "please check your",
            "cannot retrieve", "unable to access",
        ]
        return any(s in text for s in unresolved_signals)

    def _should_force_tool_retry(self, content: str) -> bool:
        if not self._has_actionable_tools():
            return False
        if not content:
            return False
        latest_user = self._latest_user_text()
        if not latest_user:
            return False
        if self._is_smalltalk(latest_user):
            return False
        return self._looks_unresolved_response(content)

    async def _think(self, iteration: int) -> dict:
        tools_schema = self.tool_registry.get_schemas(self.allowed_tools)
        async def _on_delta(delta: str) -> None:
            if not delta or not delta.strip():
                return
            self._streamed_delta_in_iteration = True
            await self._emit_agent_delta(delta, iteration=iteration)

        async def _call(messages: list[dict], tools: list[dict]) -> dict:
            return await self.llm_provider.chat_completion(
                model=self.model_string,
                messages=messages,
                tools=tools,
                tool_choice=self.tool_choice.value,
                stream=True,
                on_delta=_on_delta,
            )
        try:
            return await _call(self.context.messages, tools_schema)
        except Exception as e:
            err_str = str(e)
            if "400" in err_str and len(self.context.messages) > 4:
                logger.warning("LLM 400 error, attempting context compaction: %s", err_str[:200])
                self._compact_context()
                try:
                    return await _call(self.context.messages, tools_schema)
                except Exception as e2:
                    err2 = str(e2)
                    if "400" not in err2:
                        raise
                    # Some OpenAI-compatible providers are sensitive to large tool schema sets.
                    # Retry with a smaller subset, then (last resort) no tools.
                    if len(tools_schema) > 8:
                        reduced_tools = tools_schema[:8]
                        logger.warning(
                            "LLM 400 persists after compaction; retry with reduced tools (%d -> %d)",
                            len(tools_schema),
                            len(reduced_tools),
                        )
                        try:
                            return await _call(self.context.messages, reduced_tools)
                        except Exception as e3:
                            if "400" not in str(e3):
                                raise
                    logger.warning("LLM 400 persists after compaction; retry once without tools as last resort")
                    return await _call(self.context.messages, [])
            raise

    def _compact_context(self) -> None:
        """Recoverable context compaction — preserves URLs, paths, and artifact_ids.

        Manus blog: 'Our compression strategy is always designed to be recoverable.
        Any irreversible compression carries risk.'
        """
        before = list(self.context.messages)
        self.context.messages = compact_messages_recoverable(
            self.context.messages, max_tool_result_chars=3000
        )
        violations = validate_append_only(before, self.context.messages)
        for v in violations:
            logger.warning("[context_engineering] append-only violation: %s", v)

    def _maybe_trim_steps(self) -> None:
        """Deprecated — superseded by compact_then_summarize() in the main run() loop.

        The Compact-first → Summarize-last hierarchy in run() now handles all
        context compression.  This stub is kept only so that any external code
        that calls it does not raise AttributeError.
        """

    async def _act_parsed(self, tool_name: str, tool_args: dict) -> str:
        # Hard whitelist enforcement: reject any tool not in allowed_tools.
        # This is the execution-layer guard that complements the schema-layer
        # filtering in _think(). It prevents the model from calling tools that
        # are registered in the registry but not allowed for this role.
        if tool_name not in self.allowed_tools:
            logger.warning(
                "[tool_contract] BLOCKED tool=%s (not in allowed_tools=%s) agent=%s",
                tool_name,
                sorted(self.allowed_tools),
                self.context.agent_id,
            )
            return json.dumps({
                "error": "tool_not_allowed",
                "tool": tool_name,
                "message": (
                    f"Tool '{tool_name}' is not in your allowed tool list. "
                    f"You may only call: {sorted(self.allowed_tools)}. "
                    "Please use only the tools listed in your <tool_contract>."
                ),
            }, ensure_ascii=False)
        executor = self.tool_registry.get_executor(tool_name)
        return await executor(**tool_args)

    def _reflect(self, iteration: int) -> None:
        todo_items = self.context.get_todo_items()
        if todo_items:
            self.context.update_todo(todo_items)
        else:
            self.context.add_user(
                "<reflection>Review your progress. Have you gathered enough information? "
                "Should you adjust your approach? Remember to call `idle` when done.</reflection>"
            )

    def _pending_steps_text(self) -> str:
        """Format pending executor steps as a mini-todo block for context injection.

        Returns an empty string when all steps are done (or no steps exist),
        so the caller can fall back to the goal-reminder.

        Format mirrors format_todo_for_context for visual consistency:
          [Executor steps — pending]
            ✓ step-1: collect pricing data
            ○ step-2: analyse tiers          ← pending
            ○ step-3: write summary          ← pending
          Progress: 1/3
        """
        if not self._executor_steps:
            return ""
        lines = ["[Executor steps — pending]"]
        done = 0
        total = len(self._executor_steps)
        for s in self._executor_steps:
            status = s.get("status", "pending")
            action = s.get("action", s.get("id", ""))
            sid = s.get("id", "")
            label = f"{sid}: {action}" if sid and action != sid else action
            if status == "done":
                lines.append(f"  \u2713 {label}")
                done += 1
            elif status == "failed":
                lines.append(f"  \u2717 {label}  [failed]")
            else:
                lines.append(f"  \u25cb {label}")
        lines.append(f"Progress: {done}/{total}")
        # Return empty string when all steps are done
        if done == total:
            return ""
        return "\n".join(lines)

    def _inject_goal_reminder(self) -> None:
        """Inject a lightweight goal-reminder at the tail of the context.

        Called when no todo list exists, to ensure the model always has its
        primary objective in the recent attention window.

        Manus blog: 'By continuously rewriting the todo list, Manus recites
        its objectives to the end of the context — avoiding the
        lost-in-the-middle problem.'
        """
        # Extract the original task instruction from the first user message
        task_instruction = ""
        for msg in self.context.messages:
            if msg.get("role") == "user":
                content = msg.get("content") or ""
                # Skip injected event/system messages
                if not content.startswith("<"):
                    task_instruction = content[:200]
                    break
        if task_instruction:
            self.context.inject_event(
                EventType.TODO,
                f"[目标提醒] {task_instruction}",
            )

    def _inject_event_summary(self) -> None:
        if not self._event_summary_fn:
            return
        try:
            summary = self._event_summary_fn()
            if summary:
                self.context.inject_event(EventType.SYSTEM, summary)
        except Exception:
            logger.debug("Event summary injection skipped", exc_info=True)

    def _is_idle(self, tc: dict) -> bool:
        return (tc.get("function") or {}).get("name") == "idle"

    async def _emit_tool_called(self, tc: dict, args: dict, iteration: int) -> None:
        if not self._step_event_fn:
            return
        tool_name = tc["function"]["name"]
        desc = _describe_tool_call(tool_name, args)
        try:
            await self._step_event_fn("tool_called", {
                "tool": tool_name,
                "description": desc,
                "args_summary": {k: str(v)[:100] for k, v in list(args.items())[:3]},
                "iteration": iteration,
            })
        except Exception:
            logger.debug("Step event emit failed", exc_info=True)

    async def _emit_tool_result(self, tc: dict, args: dict, result: str, iteration: int) -> None:
        if not self._step_event_fn:
            return
        tool_name = tc["function"]["name"]
        desc = _describe_tool_call(tool_name, args)
        preview_limit = 200
        if tool_name == "browser_view":
            preview_limit = 16000
        elif tool_name == "browser_navigate":
            preview_limit = 1200
        elif tool_name == "submit_results":
            preview_limit = 1000
        result_preview = result[:preview_limit] if len(result) <= preview_limit else result[:preview_limit] + "..."
        payload: dict[str, Any] = {
            "tool": tool_name,
            "description": desc,
            "result_text": _describe_tool_result(tool_name, args, result),
            "result_preview": result_preview,
            "iteration": iteration,
        }
        if tool_name == "web_search":
            try:
                parsed = json.loads(result)
                if isinstance(parsed, dict) and isinstance(parsed.get("batch"), list):
                    limited_batch = []
                    for batch in parsed["batch"][:3]:
                        if not isinstance(batch, dict):
                            continue
                        query = batch.get("query", "")
                        results = batch.get("results", [])
                        if isinstance(results, list):
                            results = results[:3]
                        else:
                            results = []
                        limited_batch.append({"query": query, "results": results})
                    payload["search_batch"] = limited_batch
                elif isinstance(parsed, list):
                    query_text = ""
                    if isinstance(args.get("query"), str):
                        query_text = args["query"]
                    elif isinstance(args.get("queries"), list) and args["queries"]:
                        query_text = str(args["queries"][0])
                    payload["search_batch"] = [{"query": query_text, "results": parsed[:3]}]
            except Exception:
                pass
        elif tool_name == "submit_results":
            try:
                parsed = json.loads(result)
                if isinstance(parsed, dict):
                    payload["submit_result"] = parsed
            except Exception:
                pass
        try:
            await self._step_event_fn("tool_result", payload)
        except Exception:
            logger.debug("Step event emit failed", exc_info=True)

    async def _emit_thinking(self, content: str, iteration: int) -> None:
        if not self._step_event_fn:
            return
        try:
            await self._step_event_fn("agent_thinking", {
                "text": content[:300],
                "iteration": iteration,
            })
        except Exception:
            logger.debug("Thinking event emit failed", exc_info=True)

    async def _emit_agent_message(self, content: str, iteration: int) -> None:
        if not self._step_event_fn:
            return
        try:
            await self._step_event_fn("agent_message", {
                "text": content,
                "message_type": "final_reply",
                "iteration": iteration,
            })
        except Exception:
            logger.debug("Agent message emit failed", exc_info=True)

    async def _emit_agent_delta(self, content: str, iteration: int) -> None:
        if not self._step_event_fn:
            return
        try:
            await self._step_event_fn("agent_message", {
                "text": content,
                "message_type": "delta",
                "iteration": iteration,
            })
        except Exception:
            logger.debug("Agent delta emit failed", exc_info=True)

    async def _emit_agent_delta_clear(self, iteration: int) -> None:
        if not self._step_event_fn:
            return
        try:
            await self._step_event_fn("agent_message", {
                "text": "",
                "message_type": "delta_clear",
                "iteration": iteration,
            })
        except Exception:
            logger.debug("Agent delta clear emit failed", exc_info=True)
