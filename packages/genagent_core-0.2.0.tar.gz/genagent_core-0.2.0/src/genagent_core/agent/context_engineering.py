"""Context Engineering utilities for GenAgent.

Implements the seven principles from Manus's Context Engineering blog post:
1. KV-cache friendly design  — stable prefix, deterministic serialization, no timestamp pollution
2. File system as context    — recoverable truncation (keep URL/path, drop body)
3. Todo recitation           — continuously push todo to recent attention window
4. Preserve errors           — never erase failed attempts from context
5. Anti few-shot fixation    — inject structural variation to break repetition patterns
6. Append-only context       — never mutate past messages; only append new ones
7. CodeAct                   — Executable Python as Actions
"""

from __future__ import annotations

import hashlib
import json
import logging
import random
import re
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 1. KV-Cache: Deterministic JSON serialization
# ---------------------------------------------------------------------------

def stable_json(obj: Any) -> str:
    """Serialize to JSON with sorted keys and no timestamp variance.

    Guarantees that the same logical object always produces the same byte
    sequence, which is critical for KV-cache prefix matching.

    Manus blog: "Many programming languages and libraries do not guarantee
    key order stability when serializing JSON objects, which can silently
    break caching."
    """
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def strip_timestamp_from_system_prompt(system_prompt: str) -> str:
    """Remove any timestamp-like strings from the system prompt.

    A timestamp at the start of the system prompt invalidates the entire
    KV-cache on every request. This function strips common patterns.

    Manus blog: "A common mistake is to include a timestamp at the beginning
    of the system prompt — especially one precise to the second."
    """
    # Remove ISO-8601 timestamps (e.g. 2025-03-10T04:00:00Z or 2025-03-10 04:00:00)
    cleaned = re.sub(
        r"\b\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b",
        "",
        system_prompt,
    )
    # Remove Unix epoch timestamps (10-digit numbers that look like timestamps)
    cleaned = re.sub(r"\b1[6-9]\d{8}\b", "", cleaned)
    # Remove "当前时间: ..." or "Current time: ..." lines
    cleaned = re.sub(r"(?m)^.*(?:当前时间|current time|generated at)[^\n]*\n?", "", cleaned, flags=re.IGNORECASE)
    return cleaned.strip()


def assert_stable_prefix(system_prompt: str) -> str:
    """Return a fingerprint of the system prompt for cache monitoring.

    Call this once at startup and log/alert if the fingerprint changes
    between requests — it means the KV-cache is being invalidated.

    Manus blog: 'A common mistake is to include a timestamp at the beginning
    of the system prompt — it degrades your cache hit rate.'
    """
    return hashlib.sha256(system_prompt.encode("utf-8")).hexdigest()[:16]


# Module-level registry: role → first-seen fingerprint
# Used by verify_prefix_unchanged() to detect per-request drift.
_PREFIX_FINGERPRINT_REGISTRY: dict[str, str] = {}


def verify_prefix_unchanged(system_prompt: str, role: str = "default") -> None:
    """Verify that the system prompt prefix has not changed since first use.

    This function is designed to be called on **every** agent creation, not
    just at module load time.  If the fingerprint drifts between requests
    (e.g. because a timestamp was accidentally re-introduced), a WARNING is
    emitted so the issue is caught immediately rather than silently degrading
    KV-cache hit rates.

    Manus blog: 'Make sure your system prompt is deterministic.  Any change
    — even a single character — invalidates the entire KV-cache prefix.'

    Args:
        system_prompt: The full system prompt string (should already have
            timestamps stripped via ``strip_timestamp_from_system_prompt``).
        role: Agent role name, used to namespace the registry so each role
            tracks its own stable prefix independently.
    """
    fp = assert_stable_prefix(system_prompt)
    known = _PREFIX_FINGERPRINT_REGISTRY.get(role)
    if known is None:
        # First time we see this role — register the fingerprint
        _PREFIX_FINGERPRINT_REGISTRY[role] = fp
        logger.debug(
            "[kv_cache] role=%s registered prefix fingerprint=%s",
            role, fp,
        )
    elif known != fp:
        logger.warning(
            "[kv_cache] ⚠️  role=%s system prompt fingerprint CHANGED: "
            "expected=%s got=%s — KV-cache will be INVALIDATED on every request! "
            "Check for timestamps or dynamic content in the system prompt.",
            role, known, fp,
        )


# ---------------------------------------------------------------------------
# 2. File system as context: Recoverable truncation
# ---------------------------------------------------------------------------

# Patterns that indicate a message contains recoverable content
_URL_PATTERN = re.compile(r"https?://\S+")
_SANDBOX_PATH_PATTERN = re.compile(r"/(?:workspace|sandbox|tmp|home)/\S+")
_ARTIFACT_ID_PATTERN = re.compile(r"\bartifact_id[=:]\s*['\"]?([a-zA-Z0-9_\-]+)['\"]?")


def recoverable_truncate(content: str, max_chars: int = 3000) -> str:
    """Truncate content while preserving all recovery anchors.

    Instead of a hard cut, this function:
    1. Keeps all URLs (can be re-fetched)
    2. Keeps all sandbox file paths (can be re-read)
    3. Keeps all artifact_id references (can be re-loaded via file_read)
    4. Truncates the body text

    Manus blog: "Our compression strategy is always designed to be recoverable.
    For example, web page content can be removed from context as long as the
    URL is retained; document content can be omitted as long as the document
    path in the sandbox is still present."
    """
    if len(content) <= max_chars:
        return content

    # Extract all recovery anchors before truncating
    urls = _URL_PATTERN.findall(content)
    paths = _SANDBOX_PATH_PATTERN.findall(content)
    artifact_ids = _ARTIFACT_ID_PATTERN.findall(content)

    truncated = content[:max_chars]
    suffix_parts = [f"\n...[truncated from {len(content)} chars]"]

    if urls:
        unique_urls = list(dict.fromkeys(urls))[:5]  # dedupe, keep order, cap at 5
        suffix_parts.append("[recoverable URLs: " + " | ".join(unique_urls) + "]")
    if paths:
        unique_paths = list(dict.fromkeys(paths))[:5]
        suffix_parts.append("[recoverable paths: " + " | ".join(unique_paths) + "]")
    if artifact_ids:
        unique_ids = list(dict.fromkeys(artifact_ids))[:5]
        suffix_parts.append("[recoverable artifact_ids: " + ", ".join(unique_ids) + "]")

    return truncated + "\n".join(suffix_parts)


def compact_messages_recoverable(
    messages: list[dict[str, Any]],
    max_tool_result_chars: int = 3000,
) -> list[dict[str, Any]]:
    """Apply recoverable truncation to all tool result messages.

    This is the replacement for the destructive _compact_context() in
    ManusAgent. It never removes messages — only shortens their bodies
    while preserving recovery anchors.

    Manus blog: "Any irreversible compression carries risk."
    """
    compacted = []
    for msg in messages:
        if msg.get("role") == "tool":
            content = msg.get("content", "")
            if len(content) > max_tool_result_chars:
                msg = {**msg, "content": recoverable_truncate(content, max_tool_result_chars)}
        compacted.append(msg)
    return compacted


# ---------------------------------------------------------------------------
# 3. Todo recitation: push global plan to recent attention window
# ---------------------------------------------------------------------------

def format_todo_for_context(items: list[str], phase_title: str = "") -> str:
    """Format todo items for injection into context.

    Manus blog: "By continuously rewriting the todo list, Manus recites its
    objectives to the end of the context. This pushes the global plan into
    the model's recent attention window."

    The format is intentionally varied (see principle 5) to avoid few-shot
    pattern fixation.
    """
    lines = []
    if phase_title:
        lines.append(f"[Current phase: {phase_title}]")
    for item in items:
        is_done = item.startswith("[x]") or item.startswith("✓")
        clean = item.lstrip("[x] ").lstrip("[ ] ").lstrip("✓ ").lstrip("○ ").strip()
        marker = "✓" if is_done else "○"
        lines.append(f"  {marker} {clean}")
    done = sum(1 for i in items if i.startswith("[x]") or i.startswith("✓"))
    lines.append(f"Progress: {done}/{len(items)}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 4. Preserve errors: keep failed attempts in context
# ---------------------------------------------------------------------------

def format_error_observation(
    tool_name: str,
    args: dict[str, Any],
    error: str,
    attempt: int = 1,
) -> str:
    """Format a tool error as a structured observation to keep in context.

    Manus blog: "One of the most effective ways to improve agent behavior is
    surprisingly simple: keep failed attempts in context. When the model sees
    a failed action — along with the resulting observation or stack trace —
    it implicitly updates its internal beliefs."

    This function produces a consistent format that the model can learn from,
    rather than a raw exception dump.
    """
    args_summary = stable_json({k: str(v)[:80] for k, v in list(args.items())[:3]})
    return (
        f"[TOOL_ERROR attempt={attempt}]\n"
        f"tool: {tool_name}\n"
        f"args: {args_summary}\n"
        f"error: {error}\n"
        f"[/TOOL_ERROR]\n"
        f"Note: This error is preserved in context. Adjust your approach before retrying."
    )


# ---------------------------------------------------------------------------
# 5. Anti few-shot fixation: structural variation injection
# ---------------------------------------------------------------------------

# Variation pools for different structural elements
_OBSERVATION_PREFIXES = [
    "Result:",
    "Output:",
    "Response:",
    "Observation:",
    "Execution result:",
    "Tool output:",
]


def varied_observation_prefix(seed: str = "") -> str:
    """Return a varied prefix for tool result observations.

    Manus blog: "Manus introduces a small amount of structured variation in
    actions and observations — different serialization templates, alternative
    phrasing, minor noise in ordering or format. This controlled randomness
    helps break patterns and recalibrate the model's attention."
    """
    if seed:
        idx = int(hashlib.md5(seed.encode()).hexdigest(), 16) % len(_OBSERVATION_PREFIXES)
        return _OBSERVATION_PREFIXES[idx]
    return random.choice(_OBSERVATION_PREFIXES)


def inject_variation_noise(
    messages: list[dict[str, Any]],
    task_id: str = "",
    max_vary: int = 3,
) -> list[dict[str, Any]]:
    """Inject minor structural variation into recent tool result messages.

    Only modifies the last `max_vary` tool result messages to avoid
    disrupting the stable prefix (which would break KV-cache).

    This is a light-touch operation: it only changes cosmetic formatting
    (prefix labels), never the actual content.
    """
    tool_msgs = [(i, m) for i, m in enumerate(messages) if m.get("role") == "tool"]
    recent_tool_msgs = tool_msgs[-max_vary:]

    result = list(messages)
    for i, (idx, msg) in enumerate(recent_tool_msgs):
        content = msg.get("content", "")
        # Only vary messages that don't already start with a varied prefix
        if not any(content.startswith(p) for p in _OBSERVATION_PREFIXES):
            seed = f"{task_id}:{idx}:{i}"
            prefix = varied_observation_prefix(seed)
            result[idx] = {**msg, "content": f"{prefix}\n{content}"}

    return result


# ---------------------------------------------------------------------------
# 7. Proactive context management: token estimation & step trimming
# ---------------------------------------------------------------------------

# Rough chars-per-token ratio for multilingual content (conservative estimate).
# GPT-4 / Claude average ~3.5 chars/token for mixed Chinese+English.
_CHARS_PER_TOKEN: float = 3.5


def estimate_tokens(messages: list[dict[str, Any]]) -> int:
    """Estimate total token count of a messages list.

    Uses a conservative chars-per-token ratio rather than a full tokenizer
    to avoid heavy dependencies.  Accurate enough for threshold decisions.
    """
    total_chars = 0
    for msg in messages:
        content = msg.get("content") or ""
        if isinstance(content, list):
            # Multi-part content (vision messages etc.)
            for part in content:
                if isinstance(part, dict):
                    total_chars += len(part.get("text", ""))
        else:
            total_chars += len(content)
        # Tool call arguments also consume tokens
        for tc in msg.get("tool_calls") or []:
            fn = tc.get("function") or {}
            total_chars += len(fn.get("name", "")) + len(fn.get("arguments", ""))
    return int(total_chars / _CHARS_PER_TOKEN)



def _contains_error(msg: dict[str, Any]) -> bool:
    """Return True if a message contains a preserved tool error record.

    Manus blog: 'Keep failed attempts in context. When the model sees a
    failed action it implicitly updates its internal beliefs.'

    Error messages must never be silently discarded during Step Trimming.
    """
    content = msg.get("content") or ""
    if "[TOOL_ERROR" in content:
        return True
    # Also check tool call arguments for error-related content
    for tc in msg.get("tool_calls") or []:
        fn = tc.get("function") or {}
        if "[TOOL_ERROR" in fn.get("arguments", ""):
            return True
    return False


def trim_old_steps(
    messages: list[dict[str, Any]],
    keep_recent: int = 6,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Split messages into (trimmed_context, removed_messages).

    Strategy:
    - Always keep the system message(s) at the front.
    - Keep the most recent ``keep_recent`` *interaction rounds*.
      An interaction round = one assistant turn + its tool results.
    - **Never remove messages containing [TOOL_ERROR] records.**
      Manus principle: preserve failed attempts so the model can learn from them.
    - Return the removed messages so the caller can summarise them.

    This function is the *last-resort* Summarize step in the Compact-first
    → Summarize-last compression hierarchy.  It should only be called after
    compact_messages_recoverable() has already been applied and the token
    count is still above the hard threshold.
    """
    # Separate system messages (stable prefix) from the rest
    system_msgs = [m for m in messages if m.get("role") == "system"]
    non_system = [m for m in messages if m.get("role") != "system"]

    # Identify assistant turns (each assistant message starts a round)
    assistant_indices = [
        i for i, m in enumerate(non_system) if m.get("role") == "assistant"
    ]

    if len(assistant_indices) <= keep_recent:
        # Not enough rounds to trim — nothing to do
        return messages, []

    # Cut point: keep only the last `keep_recent` assistant turns
    cut_idx = assistant_indices[-keep_recent]
    candidate_removed = non_system[:cut_idx]
    candidate_kept = non_system[cut_idx:]

    # ── Error protection: never discard [TOOL_ERROR] messages ───────────────────────
    # Scan candidate_removed for error messages and rescue them.
    # We rescue the error message AND the assistant turn that triggered it
    # (the turn immediately before the tool result) so the model sees the
    # full action-error pair.
    rescued: list[dict[str, Any]] = []
    i = 0
    while i < len(candidate_removed):
        msg = candidate_removed[i]
        if _contains_error(msg):
            # Rescue this message
            rescued.append(msg)
            # Also rescue the immediately preceding assistant turn if present
            if i > 0 and candidate_removed[i - 1].get("role") == "assistant":
                if candidate_removed[i - 1] not in rescued:
                    rescued.insert(-1, candidate_removed[i - 1])
        i += 1

    removed = [m for m in candidate_removed if m not in rescued]
    kept = rescued + candidate_kept

    return system_msgs + kept, removed


def compact_then_summarize(
    messages: list[dict[str, Any]],
    model_token_limit: int = 128_000,
    compact_threshold_ratio: float = 0.75,
    summarize_threshold_ratio: float = 0.90,
    keep_recent: int = 8,
    max_tool_result_chars: int = 3000,
) -> tuple[list[dict[str, Any]], str]:
    """Two-phase compression following Manus's Compact-first → Summarize-last hierarchy.

    Phase 1 — Compact (preferred, reversible):
        Truncate long tool result bodies while keeping all recovery anchors
        (URLs, file paths, artifact_ids).  This is always tried first because
        it is fully reversible: the agent can re-fetch any URL or re-read any
        file path that was preserved.

    Phase 2 — Summarize (last resort, irreversible):
        Only triggered when Compact alone is insufficient (token count still
        above ``summarize_threshold_ratio`` after Phase 1).  Old interaction
        rounds are removed from context and replaced with a compact summary.
        Error messages are always preserved (see ``trim_old_steps``).

    Manus blog:
        'We apply Compact first.  Summarization is a last resort because any
        irreversible compression carries risk.'

    Returns:
        (new_messages, action_taken)
        action_taken is one of: 'none', 'compact', 'compact+summarize'
    """
    estimated = estimate_tokens(messages)
    compact_limit = int(model_token_limit * compact_threshold_ratio)
    summarize_limit = int(model_token_limit * summarize_threshold_ratio)

    if estimated < compact_limit:
        return messages, "none"

    # ── Phase 1: Compact ──────────────────────────────────────────────────────────────
    logger.debug(
        "[compact_then_summarize] Phase 1 (Compact): estimated=%d tokens, threshold=%d",
        estimated, compact_limit,
    )
    compacted = compact_messages_recoverable(messages, max_tool_result_chars=max_tool_result_chars)
    after_compact = estimate_tokens(compacted)

    if after_compact < summarize_limit:
        # Compact was sufficient — no need for destructive summarization
        return compacted, "compact"

    # ── Phase 2: Summarize (last resort) ───────────────────────────────────────────
    logger.warning(
        "[compact_then_summarize] Phase 2 (Summarize): compact insufficient, "
        "estimated=%d tokens after compact, summarize_threshold=%d. "
        "Removing old rounds (last-resort, irreversible).",
        after_compact, summarize_limit,
    )
    trimmed, removed = trim_old_steps(compacted, keep_recent=keep_recent)
    return trimmed, "compact+summarize"


def summarise_removed_steps(removed: list[dict[str, Any]]) -> str:
    """Produce a compact natural-language summary of removed context messages.

    This is a lightweight, deterministic summary (no LLM call required).
    It extracts tool names and brief descriptions from the removed messages
    so the WorkspaceState can record what was trimmed.
    """
    lines: list[str] = []
    for msg in removed:
        role = msg.get("role", "")
        content = msg.get("content") or ""
        if role == "assistant":
            # Assistant thinking text
            if content and not msg.get("tool_calls"):
                lines.append(f"[思考] {content[:120]}")
            # Tool calls
            for tc in msg.get("tool_calls") or []:
                fn = tc.get("function") or {}
                name = fn.get("name", "unknown")
                try:
                    args = json.loads(fn.get("arguments", "{}"))
                    arg_hint = ", ".join(f"{k}={str(v)[:40]}" for k, v in list(args.items())[:2])
                except Exception:
                    arg_hint = ""
                lines.append(f"[工具] {name}({arg_hint})")
        elif role == "tool":
            snippet = content[:100].replace("\n", " ")
            lines.append(f"[结果] {snippet}")
    if not lines:
        return "(no steps to summarise)"
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6. Append-only context validation
# ---------------------------------------------------------------------------

def validate_append_only(
    old_messages: list[dict[str, Any]],
    new_messages: list[dict[str, Any]],
) -> list[str]:
    """Validate that new_messages is a strict append of old_messages.

    Returns a list of violation descriptions (empty = valid).

    Manus blog: "Make your context append-only. Avoid modifying previous
    actions or observations. Ensure your serialization is deterministic."
    """
    violations = []
    if len(new_messages) < len(old_messages):
        violations.append(
            f"Context shrank: {len(old_messages)} → {len(new_messages)} messages. "
            "Messages were removed, which breaks append-only invariant."
        )
        return violations

    for i, (old, new) in enumerate(zip(old_messages, new_messages)):
        old_role = old.get("role")
        new_role = new.get("role")
        if old_role != new_role:
            violations.append(f"Message[{i}] role changed: {old_role!r} → {new_role!r}")
            continue

        old_content = old.get("content", "")
        new_content = new.get("content", "")
        if old_content and new_content and old_content != new_content:
            # Allow truncation (new is a prefix of old + truncation marker)
            if not new_content.startswith(old_content[:100]):
                violations.append(
                    f"Message[{i}] content mutated (role={old_role!r}). "
                    f"Old prefix: {old_content[:60]!r}, New prefix: {new_content[:60]!r}"
                )

    return violations
