from __future__ import annotations

import asyncio
import logging
import uuid
from contextlib import AsyncExitStack
from typing import Optional

from .config import AgentConfig
from .orchestration.task_state import TaskState
from .orchestration.agent_factory import AgentFactory
from .orchestration.agent_runtime import AgentRuntime
from .orchestration.orchestrator import Orchestrator
from .infra.storage import StorageBackend
from .infra.llm_provider import LLMProvider
from .infra.model_router import ModelRouter
from .runtime.command_queue import CommandQueue
from .runtime.event_bus import EventBus
from .sandbox.factory import create_sandbox_provider
from .services.search_service import SearchService
from .artifacts.artifact_store import ArtifactStore
from .memory.memory_manager import MemoryManager
from .memory.backends.vector_backend import VectorMemoryBackend
from .skills.loader import SkillsLoader

logger = logging.getLogger(__name__)


class GenAgent:
    """High-level API for running GenAgent tasks.

    A single ``GenAgent`` instance is designed to be long-lived (e.g. for the
    lifetime of a server process).  It owns a shared ``CommandQueue`` that
    serialises concurrent requests per workspace, preventing race conditions on
    the shared sandbox and artifact store.

    Usage::

        agent = GenAgent(config)
        state = await agent.run("Research AI pricing", workspace_id="ws-1")
        await agent.aclose()   # drain pending background writes, close MCP

    Or as an async context manager::

        async with GenAgent(config) as agent:
            state = await agent.run("...")
    """

    def __init__(self, config: AgentConfig):
        self.custom_tools: list[dict] = []
        self.config = config
        self.storage = StorageBackend({"base_dir": config.storage_dir})
        self.llm_provider = LLMProvider(config.llm.model_dump())
        self.model_router = ModelRouter(config.model_routing.model_dump())
        self.event_bus = EventBus(storage=self.storage)

        # Single CommandQueue shared across all tasks — serialises per-workspace
        # requests and provides graceful drain on shutdown.
        self._command_queue = CommandQueue()

        self.sandbox_provider = None
        if config.sandbox.enabled:
            self.sandbox_provider = create_sandbox_provider(
                provider_name=config.sandbox.provider,
                api_key=config.sandbox.api_key,
            )

        self.search_service = SearchService.from_config({})

        # Skills loader — built once, reused across all tasks
        self.skills_loader: SkillsLoader | None = None
        if config.skills.enabled:
            self.skills_loader = SkillsLoader(
                skills_dirs=config.skills.skills_dirs,
                # always_load is handled by PromptLoader via SkillLoader.activate_for_task
            )

        # MCP exit stack — keeps transport connections alive for the lifetime of GenAgent
        self._mcp_stack: AsyncExitStack | None = None
        self._mcp_initialized = False

    # ------------------------------------------------------------------
    # Async context manager support
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "GenAgent":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    # ------------------------------------------------------------------
    # Tool registration
    # ------------------------------------------------------------------

    def register_tool(self, name: str, schema: dict, executor: object) -> None:
        """Register a custom tool available to all agents in this instance."""
        self.custom_tools.append({"name": name, "schema": schema, "executor": executor})

    # ------------------------------------------------------------------
    # MCP
    # ------------------------------------------------------------------

    async def _ensure_mcp_connected(self) -> None:
        """Lazily connect to MCP servers on first run."""
        if self._mcp_initialized:
            return
        self._mcp_initialized = True
        if not self.config.mcp_servers:
            return
        try:
            from .mcp.client import connect_mcp_servers
            from .infra.tool_registry.registry import ToolRegistry
            # Temporary registry to collect MCP tool schemas; they will be
            # merged into the factory's custom_tools list.
            mcp_registry = ToolRegistry()
            self._mcp_stack = AsyncExitStack()
            await self._mcp_stack.__aenter__()
            await connect_mcp_servers(self.config.mcp_servers, mcp_registry, self._mcp_stack)
            # Convert registered MCP tools to custom_tools format
            for tool_name in mcp_registry.names():
                spec = mcp_registry._tools[tool_name]
                self.custom_tools.append({
                    "name": spec.name,
                    "schema": spec.schema,
                    "executor": spec.executor,
                })
        except ImportError:
            logger.warning(
                "MCP support requires the 'mcp' package: pip install mcp"
            )

    # ------------------------------------------------------------------
    # Graceful shutdown
    # ------------------------------------------------------------------

    async def aclose(self) -> None:
        """Drain pending background writes then close MCP transport connections.

        Always call this (or use ``async with GenAgent(...) as agent``) to
        ensure background memory writes are flushed before the process exits.
        A 10-second timeout guards against stuck writes.
        """
        try:
            logger.info("GenAgent.aclose: waiting for CommandQueue to drain…")
            await asyncio.wait_for(self._command_queue.wait_for_idle(), timeout=10.0)
            logger.info("GenAgent.aclose: CommandQueue drained.")
        except asyncio.TimeoutError:
            logger.warning(
                "GenAgent.aclose: CommandQueue drain timed out after 10 s; "
                "some background memory writes may be lost."
            )
        except Exception:
            logger.exception("GenAgent.aclose: unexpected error while draining CommandQueue.")

        if self._mcp_stack is not None:
            await self._mcp_stack.__aexit__(None, None, None)
            self._mcp_stack = None

    # ------------------------------------------------------------------
    # Task execution
    # ------------------------------------------------------------------

    async def run(
        self,
        instruction: str,
        workspace_id: str = "default",
        task_id: Optional[str] = None,
    ) -> TaskState:
        """Run a task and return its final TaskState.

        The task is enqueued onto the ``main:{workspace_id}`` lane of the
        shared CommandQueue, so concurrent calls for the same workspace are
        automatically serialised.
        """
        await self._ensure_mcp_connected()
        if not task_id:
            task_id = f"task_{uuid.uuid4().hex[:8]}"

        artifact_store = ArtifactStore(storage=self.storage, workspace_id=workspace_id)
        await artifact_store.initialize()

        memory_manager = None
        if self.config.memory.enabled:
            memory_backend = VectorMemoryBackend(
                storage_root=self.config.storage_dir,
                workspace_id=workspace_id,
            )
            memory_manager = MemoryManager(memory_backend)
            await memory_manager.initialize()

        task_state = TaskState.load(
            workspace_id=workspace_id,
            task_id=task_id,
            storage=self.storage,
        )
        task_state.save()

        agent_factory = AgentFactory(
            llm_provider=self.llm_provider,
            model_router=self.model_router,
            task_state=task_state,
            artifact_store=artifact_store,
            memory_manager=memory_manager,
            workspace_id=workspace_id,
            search_service=self.search_service,
            event_bus=self.event_bus,
            sandbox_provider=self.sandbox_provider,
            custom_tools=self.custom_tools,
            context_config=self.config.context,
            skills_loader=self.skills_loader,
        )

        agent_runtime = AgentRuntime(artifact_store=artifact_store, storage=self.storage)

        orchestrator = Orchestrator(
            agent_factory=agent_factory,
            agent_runtime=agent_runtime,
            task_state=task_state,
            event_bus=self.event_bus,
            sandbox_provider=self.sandbox_provider,
            command_queue=self._command_queue,
        )

        # handle_task() enqueues work onto the CommandQueue lane internally;
        # it returns immediately after enqueuing (non-blocking for the caller).
        # We await the returned future so run() blocks until the task completes.
        task_id_returned = await orchestrator.handle_task(workspace_id, task_id, instruction)
        future = orchestrator._running.get(task_id_returned)
        if future is not None:
            await future
        return task_state
