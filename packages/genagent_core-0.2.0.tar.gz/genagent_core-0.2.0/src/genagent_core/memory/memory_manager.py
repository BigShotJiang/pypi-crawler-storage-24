from __future__ import annotations

import json
from typing import Union

from genagent_core.memory.backends.json_backend import JSONMemoryBackend
from genagent_core.memory.backends.vector_backend import VectorMemoryBackend

AnyBackend = Union[VectorMemoryBackend, JSONMemoryBackend]


class MemoryManager:
    """Manages long-term memory for a workspace.

    Supports two backends:
    - VectorMemoryBackend: semantic similarity search via ChromaDB (default)
    - JSONMemoryBackend: keyword matching (legacy fallback)
    """

    def __init__(self, backend: AnyBackend):
        self.backend = backend

    async def initialize(self) -> None:
        await self.backend.initialize()

    async def write(self, content: str, metadata: dict | None = None) -> dict:
        return await self.backend.append(content=content, metadata=metadata)

    async def query(self, query: str, limit: int = 5) -> str:
        """Semantic similarity search (vector backend) or keyword match (json backend)."""
        rows = await self.backend.query(query, limit=limit)
        return json.dumps(rows, ensure_ascii=False)

    async def stats(self) -> dict:
        return await self.backend.stats()

    async def recall(self, _workspace_id: str | None = None) -> str:
        """Return recent memories as plain text for context injection at task start."""
        return await self.backend.recall()

    async def recall_for_task(
        self,
        task_instruction: str,
        recent_limit: int = 5,
        semantic_limit: int = 5,
    ) -> str:
        """Mixed recall: recent + semantic dedup, ranked by relevance.

        Strategy:
        1. Fetch the M most semantically similar entries for the task instruction (semantic bucket)
        2. Fetch the N most recent entries (recency bucket)
        3. Merge and deduplicate by content; semantic hits are listed first
        4. Return as plain text for context injection

        Falls back to plain recall() if the backend does not support semantic search
        (e.g. JSONMemoryBackend when query returns only keyword matches).
        """
        # Semantic bucket
        semantic_rows: list[dict] = []
        if task_instruction.strip():
            try:
                semantic_rows = await self.backend.query(task_instruction, limit=semantic_limit)
            except Exception:
                pass

        # Recent bucket (empty query → recency order)
        recent_rows: list[dict] = []
        try:
            recent_rows = await self.backend.query("", limit=recent_limit)
        except Exception:
            pass

        # Merge: semantic first, then recent; deduplicate by content
        seen: set[str] = set()
        merged: list[str] = []
        for row in semantic_rows + recent_rows:
            content = row.get("content", "").strip()
            if content and content not in seen:
                seen.add(content)
                merged.append(content)

        if not merged:
            # Final fallback to plain recency recall
            return await self.backend.recall()

        return "\n\n".join(merged)
