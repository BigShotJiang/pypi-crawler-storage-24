"""Vector Memory Backend

Uses ChromaDB for local persistent vector storage and sentence-transformers
for semantic embedding. Replaces the keyword-matching JSONMemoryBackend
with true semantic similarity search.

Design:
- Each workspace gets its own ChromaDB collection
- Entries are embedded on write, retrieved by cosine similarity on query
- Falls back to recency-based recall when query is empty
- Data persists in {storage_root}/workspaces/{workspace_id}/memory/chroma/
"""
from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_EMBED_MODEL = "all-MiniLM-L6-v2"  # 22MB, fast, good quality for short texts


class VectorMemoryBackend:
    """Semantic vector memory backend backed by ChromaDB + sentence-transformers."""

    def __init__(self, storage_root: str, workspace_id: str):
        self.storage_root = storage_root
        self.workspace_id = workspace_id
        self._chroma_path = str(
            Path(storage_root) / "workspaces" / workspace_id / "memory" / "chroma"
        )
        self._client: Any = None
        self._collection: Any = None
        self._embed_fn: Any = None

    async def initialize(self) -> None:
        """Lazy-initialize ChromaDB client and embedding function."""
        try:
            import chromadb
            from chromadb.utils import embedding_functions

            Path(self._chroma_path).mkdir(parents=True, exist_ok=True)
            self._client = chromadb.PersistentClient(path=self._chroma_path)
            self._embed_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
                model_name=_EMBED_MODEL
            )
            self._collection = self._client.get_or_create_collection(
                name=f"memory_{self.workspace_id[:16]}",
                embedding_function=self._embed_fn,
                metadata={"hnsw:space": "cosine"},
            )
            logger.info(
                "VectorMemoryBackend initialized: workspace=%s, path=%s, entries=%d",
                self.workspace_id,
                self._chroma_path,
                self._collection.count(),
            )
        except ImportError as e:
            logger.warning("chromadb/sentence-transformers not available: %s. Falling back to no-op.", e)
            self._collection = None

    def _is_ready(self) -> bool:
        return self._collection is not None

    async def append(self, content: str, metadata: dict | None = None) -> dict:
        """Embed and store a memory entry."""
        entry: dict[str, Any] = {
            "content": content,
            "metadata": metadata or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        if not self._is_ready():
            return entry

        # Stable ID based on content hash + timestamp to avoid duplicates
        entry_id = hashlib.sha256(
            f"{content}{entry['created_at']}".encode()
        ).hexdigest()[:16]

        meta = {
            "created_at": entry["created_at"],
            **(metadata or {}),
        }
        # ChromaDB metadata values must be str/int/float/bool
        meta = {k: (v if isinstance(v, (str, int, float, bool)) else json.dumps(v, ensure_ascii=False))
                for k, v in meta.items()}

        self._collection.add(
            documents=[content],
            metadatas=[meta],
            ids=[entry_id],
        )
        return entry

    async def query(self, query: str, limit: int = 5) -> list[dict]:
        """Semantic similarity search. Falls back to recency if query is empty."""
        if not self._is_ready():
            return []
        if not query.strip():
            return await self._recent(limit)

        results = self._collection.query(
            query_texts=[query],
            n_results=min(limit, max(1, self._collection.count())),
            include=["documents", "metadatas", "distances"],
        )
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]

        return [
            {
                "content": doc,
                "metadata": meta,
                "score": round(1.0 - dist, 4),  # cosine similarity
            }
            for doc, meta, dist in zip(docs, metas, distances)
        ]

    async def _recent(self, limit: int) -> list[dict]:
        """Return most recent entries by created_at."""
        if not self._is_ready() or self._collection.count() == 0:
            return []
        results = self._collection.get(
            include=["documents", "metadatas"],
            limit=limit,
        )
        docs = results.get("documents", [])
        metas = results.get("metadatas", [])
        # Sort by created_at descending
        pairs = sorted(
            zip(docs, metas),
            key=lambda x: x[1].get("created_at", ""),
            reverse=True,
        )
        return [{"content": d, "metadata": m} for d, m in pairs[:limit]]

    async def stats(self) -> dict:
        if not self._is_ready():
            return {"count": 0, "backend": "vector (not initialized)"}
        return {
            "count": self._collection.count(),
            "backend": "vector",
            "model": _EMBED_MODEL,
            "path": self._chroma_path,
        }

    async def recall(self, limit: int = 20) -> str:
        """Return recent memories as plain text for context injection."""
        rows = await self._recent(limit)
        return "\n".join(r["content"] for r in rows)
