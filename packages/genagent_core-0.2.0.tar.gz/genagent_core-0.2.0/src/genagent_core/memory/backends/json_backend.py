from __future__ import annotations

from datetime import datetime, timezone

from genagent_core.infra.storage import StorageBackend


class JSONMemoryBackend:
    def __init__(self, storage: StorageBackend, workspace_id: str):
        self.storage = storage
        self.workspace_id = workspace_id
        self.path = f"workspaces/{workspace_id}/memory/memories.json"

    async def initialize(self) -> None:
        if not self.storage.read_json(self.path):
            self.storage.write_json(self.path, {"entries": []})

    def _load(self) -> list[dict]:
        return self.storage.read_json(self.path).get("entries", [])

    def _save(self, rows: list[dict]) -> None:
        self.storage.write_json(self.path, {"entries": rows})

    async def append(self, content: str, metadata: dict | None = None) -> dict:
        rows = self._load()
        entry = {
            "content": content,
            "metadata": metadata or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        rows.append(entry)
        self._save(rows)
        return entry

    async def query(self, query: str, limit: int = 5) -> list[dict]:
        rows = self._load()
        if not query.strip():
            return rows[-limit:]
        matched = [r for r in rows if query.lower() in r["content"].lower()]
        return matched[-limit:]

    async def stats(self) -> dict:
        rows = self._load()
        return {"count": len(rows)}

    async def recall(self, limit: int = 20) -> str:
        rows = self._load()[-limit:]
        return "\n".join(r["content"] for r in rows)
