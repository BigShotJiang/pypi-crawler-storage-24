from pydantic import BaseModel, Field, field_validator
from typing import Optional, Dict, List, Literal, Any


class LLMConfig(BaseModel):
    default_provider: str = "openai"
    providers: Dict[str, Any] = Field(default_factory=dict)


class ModelRoutingConfig(BaseModel):
    default: str = "openai:gpt-4o"
    by_role: Dict[str, str] = Field(default_factory=dict)


class SandboxConfig(BaseModel):
    enabled: bool = False
    provider: str = "e2b"
    api_key: Optional[str] = None
    api_key_env: Optional[str] = "E2B_API_KEY"
    idle_timeout_seconds: int = 900


class MemoryConfig(BaseModel):
    enabled: bool = False
    provider: str = "vector"


class ContextConfig(BaseModel):
    """Configuration for the in-context compression mechanism.

    genagent-core uses a two-phase strategy inspired by the Manus blog:

    - **Phase 1 — Compact** (reversible): When the estimated token count
      exceeds ``compact_threshold`` x ``model_token_limit``, long tool
      results are truncated to ``max_tool_result_chars`` characters while
      keeping all recovery anchors (URLs, file paths, artifact IDs).

    - **Phase 2 — Summarize** (last resort, irreversible): Only triggered
      when Compact alone is insufficient and the token count still exceeds
      ``summarize_threshold`` x ``model_token_limit``.  Old interaction
      rounds are removed from context and replaced with a compact summary.
      Error messages are always preserved.

    Example::

        from genagent_core import AgentConfig
        from genagent_core.config import ContextConfig

        config = AgentConfig(
            context=ContextConfig(
                model_token_limit=128_000,
                compact_threshold=0.70,   # start compacting at 70% full
                summarize_threshold=0.85, # start summarizing at 85% full
            )
        )
    """

    model_token_limit: int = Field(
        default=128_000,
        ge=4_096,
        description="Total context window size of the model in tokens.",
    )
    compact_threshold: float = Field(
        default=0.75,
        ge=0.1,
        le=1.0,
        description=(
            "Fraction of model_token_limit at which Phase-1 Compact is triggered. "
            "E.g. 0.75 means compact when context reaches 75% of the window."
        ),
    )
    summarize_threshold: float = Field(
        default=0.90,
        ge=0.1,
        le=1.0,
        description=(
            "Fraction of model_token_limit at which Phase-2 Summarize is triggered "
            "(only if Compact alone was insufficient). Must be > compact_threshold."
        ),
    )
    max_tool_result_chars: int = Field(
        default=3_000,
        ge=100,
        description="Maximum characters kept per tool result during Phase-1 Compact.",
    )
    step_trim_keep_recent: int = Field(
        default=8,
        ge=1,
        description="Number of most-recent interaction rounds to keep during Phase-2 Summarize.",
    )

    @field_validator("summarize_threshold")
    @classmethod
    def summarize_must_exceed_compact(cls, v: float, info: Any) -> float:
        compact = (info.data or {}).get("compact_threshold", 0.75)
        if v <= compact:
            raise ValueError(
                f"summarize_threshold ({v}) must be greater than "
                f"compact_threshold ({compact})"
            )
        return v


class MCPServerConfig(BaseModel):
    """MCP server connection configuration.

    Supports three transport types (auto-detected when ``type`` is omitted):

    - **stdio**: Spawn a local subprocess (e.g. ``npx @modelcontextprotocol/server-filesystem``).
      Auto-detected when ``command`` is set.
    - **sse**: HTTP + Server-Sent Events endpoint.
      Auto-detected when ``url`` ends with ``/sse``.
    - **streamableHttp**: HTTP streaming endpoint.
      Auto-detected when ``url`` is set and does not end with ``/sse``.

    Example — filesystem MCP server via stdio::

        from genagent_core.config import MCPServerConfig

        MCPServerConfig(
            command="npx",
            args=["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
        )

    Example — remote MCP server via HTTP::

        MCPServerConfig(
            url="https://my-mcp-server.example.com/mcp",
            headers={"Authorization": "Bearer sk-..."},
            enabled_tools=["search", "fetch"],  # only register these two tools
        )
    """

    type: Optional[Literal["stdio", "sse", "streamableHttp"]] = Field(
        default=None,
        description="Transport type. Auto-detected when omitted.",
    )
    command: str = Field(
        default="",
        description="Stdio: command to run (e.g. 'npx').",
    )
    args: List[str] = Field(
        default_factory=list,
        description="Stdio: command arguments.",
    )
    env: Dict[str, str] = Field(
        default_factory=dict,
        description="Stdio: extra environment variables.",
    )
    url: str = Field(
        default="",
        description="HTTP/SSE: endpoint URL.",
    )
    headers: Dict[str, str] = Field(
        default_factory=dict,
        description="HTTP/SSE: custom request headers (e.g. Authorization).",
    )
    tool_timeout: int = Field(
        default=30,
        ge=1,
        description="Seconds before a tool call is cancelled.",
    )
    enabled_tools: List[str] = Field(
        default_factory=lambda: ["*"],
        description=(
            "Which tools to register from this server. "
            "Accepts raw MCP tool names or prefixed 'mcp_{server}_{tool}' names. "
            "Use ['*'] to register all tools (default)."
        ),
    )


class SkillsConfig(BaseModel):
    """Configuration for the Skills system.

    Skills are Markdown files (``SKILL.md``) that teach the Executor agent
    how to use specific tools or follow domain-specific workflows.  They are
    injected into the Executor's system prompt at task start.

    Directory layout::

        skills/
          my-skill/
            SKILL.md        ← required
            scripts/        ← optional helper scripts
          another-skill/
            SKILL.md

    Example::

        from genagent_core.config import SkillsConfig

        SkillsConfig(
            skills_dirs=["./skills", "/opt/company-skills"],
            always_load=["coding-style", "api-conventions"],
        )
    """

    enabled: bool = Field(
        default=True,
        description="Whether to enable the Skills system.",
    )
    skills_dirs: List[str] = Field(
        default_factory=list,
        description=(
            "List of directories to search for skill packages (each containing SKILL.md). "
            "Searched in order; workspace-local skills take priority over built-in ones."
        ),
    )
    always_load: List[str] = Field(
        default_factory=list,
        description=(
            "Skill names to always inject into every Executor's system prompt. "
            "If empty, only the skills summary index is injected (agent reads full "
            "content on demand via file_read)."
        ),
    )
    inject_summary: bool = Field(
        default=True,
        description=(
            "Whether to inject a <skills> XML summary listing all available skills "
            "into the Executor's system prompt. The agent can then read individual "
            "SKILL.md files on demand."
        ),
    )


class AgentConfig(BaseModel):
    llm: LLMConfig = Field(default_factory=LLMConfig)
    model_routing: ModelRoutingConfig = Field(default_factory=ModelRoutingConfig)
    sandbox: SandboxConfig = Field(default_factory=SandboxConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    context: ContextConfig = Field(default_factory=ContextConfig)
    mcp_servers: Dict[str, MCPServerConfig] = Field(
        default_factory=dict,
        description="MCP server configurations keyed by server name.",
    )
    skills: SkillsConfig = Field(default_factory=SkillsConfig)
    storage_dir: str = "./.genagent"
