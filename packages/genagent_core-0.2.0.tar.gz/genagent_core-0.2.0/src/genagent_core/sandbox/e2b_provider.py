"""E2B sandbox provider implementation."""

from __future__ import annotations

import inspect
import logging
import os
from typing import Callable, Optional

from genagent_core.sandbox.base import CommandResult, ProcessHandle, SandboxInfo, SandboxProvider

logger = logging.getLogger(__name__)


def _coerce_exit_code(value: object) -> int:
    if isinstance(value, bool):
        return 0 if value else 1
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return 0


class E2BSandboxProvider(SandboxProvider):
    """Concrete :class:`SandboxProvider` backed by E2B.

    Interactive process support
    ---------------------------
    E2B's ``commands.run(background=True)`` returns an ``AsyncCommandHandle``
    that exposes a ``pid`` attribute.  The provider stores these handles in
    ``_processes`` keyed by ``(session_id, pid)`` so that subsequent
    ``send_stdin`` / ``kill_process`` calls can locate them.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        default_template: Optional[str] = None,
        **_: object,
    ) -> None:
        self._api_key = api_key or os.getenv("E2B_API_KEY", "")
        self._default_template = default_template or os.getenv("E2B_TEMPLATE", "")
        if not self._api_key:
            raise ValueError(
                "E2B API key is required. "
                "Pass it via constructor or set E2B_API_KEY env var."
            )

        os.environ["E2B_API_KEY"] = self._api_key

        try:
            from e2b_code_interpreter import Sandbox as AsyncSandbox  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "e2b/e2b-code-interpreter package is required for E2B sandbox provider. "
                "Install dependency and retry."
            ) from exc
        self._sandbox_cls = AsyncSandbox

        self._sandboxes: dict[str, object] = {}
        self._labels: dict[str, dict[str, str]] = {}
        self._session_create_opts: dict[str, dict[str, object]] = {}
        # Maps (session_id, pid) → AsyncCommandHandle for interactive processes
        self._processes: dict[tuple[str, int], object] = {}

    async def _call(self, obj: object, method: str, *args: object, **kwargs: object):
        fn = getattr(obj, method, None)
        if fn is None:
            raise AttributeError(f"{type(obj).__name__}.{method} is not available")
        result = fn(*args, **kwargs)
        if inspect.isawaitable(result):
            return await result
        return result

    @staticmethod
    def _sandbox_id(sandbox: object) -> str:
        for name in ("sandbox_id", "id", "sandboxId"):
            value = getattr(sandbox, name, "")
            if value:
                return str(value)
        return ""

    @staticmethod
    def _sandbox_state(sandbox: object) -> str:
        value = getattr(sandbox, "state", "")
        return str(value) if value else "running"

    async def create(
        self,
        session_id: str,
        *,
        env_vars: Optional[dict[str, str]] = None,
        labels: Optional[dict[str, str]] = None,
        timeout: float = 120,
    ) -> SandboxInfo:
        if session_id in self._sandboxes:
            info = await self.get_info(session_id)
            if info:
                return info

        logger.info("Creating E2B sandbox for session %s ...", session_id)
        create_kwargs: dict[str, object] = {}
        if self._default_template:
            create_kwargs["template"] = self._default_template
        if env_vars:
            create_kwargs["envs"] = env_vars
        if timeout:
            create_kwargs["timeout"] = timeout

        sandbox = await self._call(self._sandbox_cls, "create", **create_kwargs)
        self._sandboxes[session_id] = sandbox
        self._labels[session_id] = dict(labels or {})
        self._session_create_opts[session_id] = {
            "env_vars": dict(env_vars or {}),
            "labels": dict(labels or {}),
            "timeout": timeout,
        }
        return SandboxInfo(
            sandbox_id=self._sandbox_id(sandbox),
            provider="e2b",
            state=self._sandbox_state(sandbox),
            labels=self._labels.get(session_id, {}),
        )

    async def destroy(self, session_id: str) -> None:
        # Clean up any tracked interactive processes for this session
        for key in [k for k in self._processes if k[0] == session_id]:
            self._processes.pop(key, None)

        sandbox = self._sandboxes.pop(session_id, None)
        self._labels.pop(session_id, None)
        self._session_create_opts.pop(session_id, None)
        if sandbox is None:
            return
        for method in ("kill", "close", "shutdown"):
            fn = getattr(sandbox, method, None)
            if fn is None:
                continue
            try:
                result = fn()
                if inspect.isawaitable(result):
                    await result
                return
            except Exception:
                logger.exception("Failed to %s E2B sandbox for session %s", method, session_id)

    async def destroy_all(self) -> None:
        for session_id in list(self._sandboxes.keys()):
            try:
                await self.destroy(session_id)
            except Exception:
                logger.exception("Error destroying E2B sandbox for session %s", session_id)

    async def get_info(self, session_id: str) -> Optional[SandboxInfo]:
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            return None
        return SandboxInfo(
            sandbox_id=self._sandbox_id(sandbox),
            provider="e2b",
            state=self._sandbox_state(sandbox),
            labels=self._labels.get(session_id, {}),
        )

    async def run_command(
        self,
        session_id: str,
        command: str,
        *,
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> CommandResult:
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            raise KeyError(f"No sandbox found for session '{session_id}'. Call create() first.")

        commands = getattr(sandbox, "commands", None)
        if commands is None:
            raise RuntimeError("E2B sandbox missing commands API")

        run_kwargs: dict[str, object] = {}
        if cwd:
            run_kwargs["cwd"] = cwd
        if timeout is not None:
            run_kwargs["timeout"] = timeout

        try:
            result = await self._call(commands, "run", command, **run_kwargs)
        except TypeError:
            run_kwargs.pop("cwd", None)
            result = await self._call(commands, "run", command, **run_kwargs)

        stdout = str(getattr(result, "stdout", "") or getattr(result, "output", "") or "")
        stderr = str(getattr(result, "stderr", "") or "")
        exit_code = _coerce_exit_code(
            getattr(result, "exit_code", getattr(result, "exitCode", getattr(result, "code", 0)))
        )
        return CommandResult(exit_code=exit_code, stdout=stdout, stderr=stderr)

    async def write_file(
        self,
        session_id: str,
        path: str,
        content: str | bytes,
    ) -> None:
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            raise KeyError(f"No sandbox found for session '{session_id}'. Call create() first.")

        files = getattr(sandbox, "files", None)
        if files is None:
            raise RuntimeError("E2B sandbox missing files API")

        data = content.decode("utf-8", errors="replace") if isinstance(content, bytes) else content
        await self._call(files, "write", path, data)

    async def read_file(
        self,
        session_id: str,
        path: str,
    ) -> str:
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            raise KeyError(f"No sandbox found for session '{session_id}'. Call create() first.")

        files = getattr(sandbox, "files", None)
        if files is None:
            raise RuntimeError("E2B sandbox missing files API")

        data = await self._call(files, "read", path)
        if isinstance(data, bytes):
            return data.decode("utf-8", errors="replace")
        return str(data or "")

    # ------------------------------------------------------------------
    # Interactive process support (E2B commands.run background=True)
    # ------------------------------------------------------------------

    async def start_process(
        self,
        session_id: str,
        command: str,
        *,
        cwd: Optional[str] = None,
        env_vars: Optional[dict[str, str]] = None,
        on_stdout: Optional[Callable[[str], None]] = None,
        on_stderr: Optional[Callable[[str], None]] = None,
        timeout: Optional[float] = None,
    ) -> ProcessHandle:
        """Start a background process and return a :class:`ProcessHandle`.

        Uses ``sandbox.commands.run(background=True)`` which returns an
        ``AsyncCommandHandle`` with a ``pid`` attribute.  The handle is
        stored internally so that ``send_stdin`` and ``kill_process`` can
        reference it later.

        Parameters
        ----------
        session_id:
            Identifies the sandbox.
        command:
            Shell command to run (e.g. ``"python3 -i"``).
        cwd:
            Working directory inside the sandbox.
        env_vars:
            Extra environment variables for this process.
        on_stdout:
            Optional callback receiving each stdout chunk as a ``str``.
        on_stderr:
            Optional callback receiving each stderr chunk as a ``str``.
        timeout:
            Connection timeout in seconds (``None`` or ``0`` = unlimited).

        Returns
        -------
        ProcessHandle
            Contains the ``pid`` needed for ``send_stdin`` / ``kill_process``.
        """
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            raise KeyError(f"No sandbox found for session '{session_id}'. Call create() first.")

        commands = getattr(sandbox, "commands", None)
        if commands is None:
            raise RuntimeError("E2B sandbox missing commands API")

        run_kwargs: dict[str, object] = {"background": True}
        if cwd:
            run_kwargs["cwd"] = cwd
        if env_vars:
            run_kwargs["envs"] = env_vars
        if on_stdout is not None:
            run_kwargs["on_stdout"] = lambda chunk: on_stdout(
                getattr(chunk, "line", str(chunk))
            )
        if on_stderr is not None:
            run_kwargs["on_stderr"] = lambda chunk: on_stderr(
                getattr(chunk, "line", str(chunk))
            )
        if timeout is not None:
            run_kwargs["timeout"] = timeout

        handle = await self._call(commands, "run", command, **run_kwargs)

        pid = int(getattr(handle, "pid", 0))
        if pid == 0:
            raise RuntimeError(
                "E2B returned a command handle with pid=0. "
                "The process may have failed to start."
            )

        self._processes[(session_id, pid)] = handle
        logger.info(
            "E2B start_process: session=%s pid=%d cmd=%s",
            session_id, pid, command[:80],
        )
        return ProcessHandle(pid=pid, session_id=session_id, provider="e2b")

    async def send_stdin(
        self,
        session_id: str,
        pid: int,
        data: str,
    ) -> None:
        """Send *data* to the stdin of a running process.

        Delegates to ``sandbox.commands.send_stdin(pid, data)`` which is
        part of the E2B Python SDK v1.x.

        Parameters
        ----------
        session_id:
            Identifies the sandbox.
        pid:
            Process ID returned by :meth:`start_process`.
        data:
            String to write to stdin.  Append ``"\\n"`` to simulate Enter.
        """
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            raise KeyError(f"No sandbox found for session '{session_id}'. Call create() first.")

        commands = getattr(sandbox, "commands", None)
        if commands is None:
            raise RuntimeError("E2B sandbox missing commands API")

        send_fn = getattr(commands, "send_stdin", None)
        if send_fn is None:
            raise RuntimeError(
                "E2B sandbox.commands does not expose send_stdin. "
                "Upgrade the e2b package to v1.x."
            )

        result = send_fn(pid, data)
        if inspect.isawaitable(result):
            await result

        logger.debug(
            "E2B send_stdin: session=%s pid=%d data=%r",
            session_id, pid, data[:80],
        )

    async def run_code(
        self,
        session_id: str,
        code: str,
        *,
        language: str = "python",
        timeout: int = 30,
    ) -> dict:
        """Execute code in the stateful Jupyter kernel.
        
        Returns a dict containing stdout, stderr, text, error, and images.
        """
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            raise KeyError(f"No sandbox found for session '{session_id}'. Call create() first.")
            
        # e2b_code_interpreter.Sandbox has run_code method
        run_fn = getattr(sandbox, "run_code", None)
        if run_fn is None:
            raise RuntimeError("E2B sandbox does not expose run_code. Are you using e2b_code_interpreter?")
            
        execution = await run_fn(code, language=language, timeout=timeout)
        
        result = {
            "stdout": "\n".join(execution.logs.stdout) if execution.logs and execution.logs.stdout else "",
            "stderr": "\n".join(execution.logs.stderr) if execution.logs and execution.logs.stderr else "",
            "text": execution.text or "",
            "error": None,
            "images": [],
        }
        
        if execution.error:
            result["error"] = {
                "name": execution.error.name,
                "value": execution.error.value,
                "traceback": execution.error.traceback,
            }
            
        if execution.results:
            for r in execution.results:
                # Check if the result has a PNG representation
                png_fn = getattr(r, "_repr_png_", None)
                if png_fn:
                    png_data = png_fn()
                    if png_data:
                        result["images"].append({"type": "image/png", "data": png_data})
                        
        return result

    async def kill_process(
        self,
        session_id: str,
        pid: int,
    ) -> bool:
        """Kill a running process by PID.

        Tries the stored ``AsyncCommandHandle.kill()`` first; falls back to
        ``sandbox.commands.kill(pid)`` if the handle is not found.

        Returns
        -------
        bool
            ``True`` if the process was successfully killed.
        """
        handle = self._processes.pop((session_id, pid), None)
        if handle is not None:
            try:
                kill_fn = getattr(handle, "kill", None)
                if kill_fn is not None:
                    result = kill_fn()
                    if inspect.isawaitable(result):
                        await result
                    logger.info(
                        "E2B kill_process (via handle): session=%s pid=%d",
                        session_id, pid,
                    )
                    return True
            except Exception:
                logger.exception(
                    "E2B kill_process via handle failed: session=%s pid=%d", session_id, pid
                )

        # Fallback: use sandbox.commands.kill(pid)
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            return False

        commands = getattr(sandbox, "commands", None)
        if commands is None:
            return False

        try:
            result = await self._call(commands, "kill", pid)
            killed = bool(result) if result is not None else True
            logger.info(
                "E2B kill_process (via commands.kill): session=%s pid=%d result=%s",
                session_id, pid, killed,
            )
            return killed
        except Exception:
            logger.exception(
                "E2B kill_process via commands.kill failed: session=%s pid=%d", session_id, pid
            )
            return False
