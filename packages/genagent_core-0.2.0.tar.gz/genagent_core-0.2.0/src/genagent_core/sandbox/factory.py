"""Factory for sandbox providers.

The factory reads ``SANDBOX_PROVIDER`` (default ``"daytona"``) from the
environment and instantiates the corresponding concrete provider.

Usage::

    from genagent_core.sandbox.factory import create_sandbox_provider, get_sandbox_provider

    # Explicit creation
    provider = create_sandbox_provider()

    # Singleton access (lazy-init)
    provider = get_sandbox_provider()
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from genagent_core.sandbox.base import SandboxProvider

logger = logging.getLogger(__name__)

_singleton: Optional[SandboxProvider] = None


def create_sandbox_provider(
    provider_name: Optional[str] = None,
    **kwargs,
) -> SandboxProvider:
    """Instantiate a sandbox provider by name.

    Parameters
    ----------
    provider_name:
        ``"daytona"``, ``"e2b"``, or ``"e2b_desktop"``.  Falls back to the
        ``SANDBOX_PROVIDER`` environment variable, then ``"daytona"``.
    **kwargs:
        Extra keyword arguments forwarded to the provider constructor
        (e.g. ``api_key``, ``api_url``).
    """
    name = (provider_name or os.getenv("SANDBOX_PROVIDER", "daytona")).lower().strip()

    if name == "daytona":
        from genagent_core.sandbox.daytona_provider import DaytonaSandboxProvider
        return DaytonaSandboxProvider(**kwargs)
    elif name == "e2b":
        from genagent_core.sandbox.e2b_provider import E2BSandboxProvider
        return E2BSandboxProvider(**kwargs)
    elif name in ("e2b_desktop", "e2b-desktop"):
        from genagent_core.sandbox.e2b_desktop_provider import DesktopSandboxProvider
        return DesktopSandboxProvider(**kwargs)
    else:
        raise ValueError(
            f"Unknown sandbox provider: '{name}'. "
            "Supported values: 'daytona', 'e2b', 'e2b_desktop'."
        )


def get_sandbox_provider(**kwargs) -> SandboxProvider:
    """Return a module-level singleton :class:`SandboxProvider`.

    The instance is created lazily on first call.  Subsequent calls
    return the same object.
    """
    global _singleton
    if _singleton is None:
        _singleton = create_sandbox_provider(**kwargs)
        logger.info("Sandbox provider initialised: %s", type(_singleton).__name__)
    return _singleton


def reset_sandbox_provider() -> None:
    """Reset the singleton (useful for tests)."""
    global _singleton
    _singleton = None
