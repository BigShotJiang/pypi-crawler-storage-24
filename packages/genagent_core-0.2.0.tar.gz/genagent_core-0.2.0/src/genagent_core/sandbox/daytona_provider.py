"""Daytona sandbox provider implementation.

Uses the official ``daytona`` Python SDK (both sync and async flavours)
to manage sandboxes on the Daytona platform.

Because the genagent application is fully async, we use ``asyncio.to_thread``
to wrap the synchronous Daytona SDK calls.  When the SDK ships a stable
async client we can swap in ``AsyncDaytona`` directly.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Optional

from daytona_sdk import Daytona, DaytonaConfig, CreateSandboxFromSnapshotParams

from genagent_core.sandbox.base import CommandResult, SandboxInfo, SandboxProvider

logger = logging.getLogger(__name__)


class DaytonaSandboxProvider(SandboxProvider):
    """Concrete :class:`SandboxProvider` backed by Daytona."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        target: Optional[str] = None,
        default_language: str = "python",
    ) -> None:
        self._api_key = api_key or os.getenv("DAYTONA_API_KEY", "")
        self._api_url = api_url or os.getenv("DAYTONA_API_URL", "https://app.daytona.io/api")
        self._target = target or os.getenv("DAYTONA_TARGET", "eu")
        self._default_language = default_language

        if not self._api_key:
            raise ValueError(
                "Daytona API key is required. "
                "Pass it via constructor or set DAYTONA_API_KEY env var."
            )

        self._config = DaytonaConfig(
            api_key=self._api_key,
            api_url=self._api_url,
            target=self._target,
        )

        # session_id → Daytona Sandbox object mapping
        self._sandboxes: dict[str, object] = {}
        # session_id → sandbox_id mapping
        self._sandbox_ids: dict[str, str] = {}
        # session_id → create() kwargs for transparent auto-recreate
        self._session_create_opts: dict[str, dict] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_client(self) -> Daytona:
        """Create a fresh Daytona client (thread-safe, short-lived)."""
        return Daytona(self._config)

    def _get_sandbox(self, session_id: str):
        """Return the cached Daytona Sandbox object for *session_id*."""
        sb = self._sandboxes.get(session_id)
        if sb is None:
            raise KeyError(
                f"No sandbox found for session '{session_id}'. "
                "Call create() first."
            )
        return sb

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def create(
        self,
        session_id: str,
        *,
        env_vars: Optional[dict[str, str]] = None,
        labels: Optional[dict[str, str]] = None,
        timeout: float = 120,
    ) -> SandboxInfo:
        if session_id in self._sandboxes:
            logger.warning("Sandbox for session %s already exists, returning existing info", session_id)
            return await self.get_info(session_id)  # type: ignore[return-value]

        def _create():
            client = self._get_client()
            params = CreateSandboxFromSnapshotParams(
                language=self._default_language,
                env_vars=env_vars or {},
                auto_stop_interval=0,  # 不自动停止
            )
            sandbox = client.create(params, timeout=timeout)
            if labels:
                sandbox.set_labels({
                    **labels,
                    "genagent_session_id": session_id,
                })
            else:
                sandbox.set_labels({"genagent_session_id": session_id})
            return sandbox

        logger.info("Creating Daytona sandbox for session %s …", session_id)
        sandbox = await asyncio.to_thread(_create)

        self._sandboxes[session_id] = sandbox
        self._sandbox_ids[session_id] = sandbox.id
        self._session_create_opts[session_id] = {
            "env_vars": dict(env_vars or {}),
            "labels": dict(labels or {}),
            "timeout": timeout,
        }
        logger.info(
            "Sandbox %s created for session %s (state=%s)",
            sandbox.id,
            session_id,
            sandbox.state,
        )
        return SandboxInfo(
            sandbox_id=sandbox.id,
            provider="daytona",
            state=str(sandbox.state),
            labels=getattr(sandbox, "labels", {}),
        )

    async def destroy(self, session_id: str) -> None:
        sandbox = self._sandboxes.pop(session_id, None)
        self._sandbox_ids.pop(session_id, None)
        self._session_create_opts.pop(session_id, None)
        if sandbox is None:
            logger.warning("No sandbox to destroy for session %s", session_id)
            return

        def _destroy():
            try:
                sandbox.delete(timeout=60)
            except Exception:
                logger.exception("Failed to delete sandbox for session %s", session_id)

        logger.info("Destroying sandbox for session %s …", session_id)
        await asyncio.to_thread(_destroy)

    async def get_info(self, session_id: str) -> Optional[SandboxInfo]:
        sandbox = self._sandboxes.get(session_id)
        if sandbox is None:
            return None

        def _refresh():
            try:
                sandbox.refresh_data()
            except Exception:
                logger.exception("Failed to refresh sandbox data for session %s", session_id)

        await asyncio.to_thread(_refresh)
        return SandboxInfo(
            sandbox_id=sandbox.id,
            provider="daytona",
            state=str(sandbox.state),
            labels=getattr(sandbox, "labels", {}),
        )

    # ------------------------------------------------------------------
    # Command execution
    # ------------------------------------------------------------------

    @staticmethod
    def _is_missing_container_error(exc: Exception) -> bool:
        msg = str(exc).lower()
        return (
            "container not found" in msg
            or "no such container" in msg
            or "sandbox container not found" in msg
        )

    async def _recreate_and_get(self, session_id: str):
        opts = self._session_create_opts.get(session_id, {})
        # Clear stale handles first.
        self._sandboxes.pop(session_id, None)
        self._sandbox_ids.pop(session_id, None)
        await self.create(
            session_id=session_id,
            env_vars=opts.get("env_vars"),
            labels=opts.get("labels"),
            timeout=opts.get("timeout", 120),
        )
        return self._get_sandbox(session_id)

    async def run_command(
        self,
        session_id: str,
        command: str,
        *,
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> CommandResult:
        sandbox = self._get_sandbox(session_id)

        def _exec():
            kwargs: dict = {"cwd": cwd} if cwd else {}
            if timeout is not None:
                kwargs["timeout"] = timeout
            return sandbox.process.exec(command, **kwargs)

        logger.debug("Executing command in sandbox %s: %s", session_id, command[:120])
        try:
            response = await asyncio.to_thread(_exec)
        except Exception as e:
            if not self._is_missing_container_error(e):
                raise
            logger.warning(
                "Sandbox container missing for session %s; recreating and retrying once",
                session_id,
            )
            sandbox = await self._recreate_and_get(session_id)

            def _exec_retry():
                kwargs: dict = {"cwd": cwd} if cwd else {}
                if timeout is not None:
                    kwargs["timeout"] = timeout
                return sandbox.process.exec(command, **kwargs)

            response = await asyncio.to_thread(_exec_retry)
        return CommandResult(
            exit_code=response.exit_code,
            stdout=response.result or "",
            stderr="",  # Daytona SDK 将 stderr 合并到 result 中
        )

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    async def write_file(
        self,
        session_id: str,
        path: str,
        content: str | bytes,
    ) -> None:
        sandbox = self._get_sandbox(session_id)
        if isinstance(content, str):
            content_bytes = content.encode("utf-8")
        else:
            content_bytes = content

        def _write():
            # 确保父目录存在
            parent_dir = "/".join(path.split("/")[:-1])
            if parent_dir:
                try:
                    sandbox.fs.create_folder(parent_dir, "755")
                except Exception:
                    pass  # 目录可能已存在

            # SDK upload_file(src, dst) — src can be bytes or local path
            sandbox.fs.upload_file(content_bytes, path)

        logger.debug("Writing file %s in sandbox %s", path, session_id)
        await asyncio.to_thread(_write)

    async def read_file(
        self,
        session_id: str,
        path: str,
    ) -> str:
        sandbox = self._get_sandbox(session_id)

        def _read():
            data = sandbox.fs.download_file(path)
            if isinstance(data, bytes):
                return data.decode("utf-8")
            return str(data)

        logger.debug("Reading file %s from sandbox %s", path, session_id)
        return await asyncio.to_thread(_read)

    # ------------------------------------------------------------------
    # Web browsing
    # ------------------------------------------------------------------

    async def browse(
        self,
        session_id: str,
        url: str,
    ) -> str:
        """Fetch a URL from inside the sandbox using curl."""
        result = await self.run_command(
            session_id,
            f'curl -sL --max-time 30 "{url}"',
            timeout=35,
        )
        return result.stdout

    # ------------------------------------------------------------------
    # Cleanup all sandboxes (for graceful shutdown)
    # ------------------------------------------------------------------

    async def destroy_all(self) -> None:
        """Destroy all tracked sandboxes. Useful during application shutdown."""
        session_ids = list(self._sandboxes.keys())
        for sid in session_ids:
            try:
                await self.destroy(sid)
            except Exception:
                logger.exception("Error destroying sandbox for session %s", sid)
