"""Abstract base class for sandbox providers.

Every concrete provider (Daytona, E2B, Docker, …) MUST implement this
interface so that the rest of the application can work with any backend
without modification.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass
class CommandResult:
    """Unified result returned by ``run_command``."""

    exit_code: int = 0
    stdout: str = ""
    stderr: str = ""

    @property
    def success(self) -> bool:
        return self.exit_code == 0


@dataclass
class ProcessHandle:
    """Handle to a background process started via ``start_process``.

    Attributes
    ----------
    pid:
        Process ID inside the sandbox.
    session_id:
        Logical session this process belongs to.
    provider:
        Name of the sandbox provider (e.g. ``"e2b"``).
    """

    pid: int
    session_id: str
    provider: str = ""


@dataclass
class SandboxInfo:
    """Metadata about a running sandbox instance."""

    sandbox_id: str = ""
    provider: str = ""
    state: str = ""  # "running", "stopped", "error", …
    labels: dict[str, str] = field(default_factory=dict)


class SandboxProvider(abc.ABC):
    """Unified sandbox interface (adapter pattern).

    Lifecycle
    ---------
    1. ``create()``   – provision a new sandbox
    2. use ``run_command`` / ``write_file`` / ``read_file`` / ``browse``
    3. ``destroy()``  – tear down the sandbox

    Interactive processes (optional)
    ---------------------------------
    For commands that require stdin interaction (e.g. ``python``, ``node``,
    interactive CLIs), use the three-method interactive API:

    1. ``start_process()``  – launch the command in the background and get a
                              :class:`ProcessHandle` with the process PID.
    2. ``send_stdin()``     – write data to the process stdin at any time.
    3. ``kill_process()``   – terminate the process when done.

    Not every provider implements this; the default methods raise
    ``NotImplementedError``.  Currently supported: **E2B**.
    """

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @abc.abstractmethod
    async def create(
        self,
        session_id: str,
        *,
        env_vars: Optional[dict[str, str]] = None,
        labels: Optional[dict[str, str]] = None,
        timeout: float = 120,
    ) -> SandboxInfo:
        """Create and start a new sandbox for *session_id*.

        Parameters
        ----------
        session_id:
            Logical identifier that ties the sandbox to a conversation /
            task session.
        env_vars:
            Extra environment variables injected into the sandbox.
        labels:
            Key-value metadata attached to the sandbox.
        timeout:
            Maximum seconds to wait for the sandbox to become ready.

        Returns
        -------
        SandboxInfo with at least ``sandbox_id`` populated.
        """

    @abc.abstractmethod
    async def destroy(self, session_id: str) -> None:
        """Destroy the sandbox associated with *session_id*."""

    @abc.abstractmethod
    async def get_info(self, session_id: str) -> Optional[SandboxInfo]:
        """Return metadata for the sandbox, or *None* if it doesn't exist."""

    # ------------------------------------------------------------------
    # Command execution
    # ------------------------------------------------------------------

    @abc.abstractmethod
    async def run_command(
        self,
        session_id: str,
        command: str,
        *,
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> CommandResult:
        """Execute a shell command inside the sandbox.

        Parameters
        ----------
        session_id:
            Identifies the sandbox.
        command:
            Shell command string.
        cwd:
            Working directory (sandbox-relative).
        timeout:
            Maximum seconds to wait for the command.
        """

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    @abc.abstractmethod
    async def write_file(
        self,
        session_id: str,
        path: str,
        content: str | bytes,
    ) -> None:
        """Write *content* to *path* inside the sandbox.

        If *content* is ``str`` it will be encoded as UTF-8.
        Parent directories are created automatically.
        """

    @abc.abstractmethod
    async def read_file(
        self,
        session_id: str,
        path: str,
    ) -> str:
        """Read the file at *path* and return its content as a string."""

    # ------------------------------------------------------------------
    # Interactive process (optional – E2B supported, others raise)
    # ------------------------------------------------------------------

    async def start_process(
        self,
        session_id: str,
        command: str,
        *,
        cwd: Optional[str] = None,
        env_vars: Optional[dict[str, str]] = None,
        on_stdout: Optional[Callable[[str], None]] = None,
        on_stderr: Optional[Callable[[str], None]] = None,
        timeout: Optional[float] = None,
    ) -> ProcessHandle:
        """Start a long-running background process and return a handle.

        Unlike ``run_command``, this does **not** wait for the process to
        finish.  Use ``send_stdin`` to write to the process stdin and
        ``kill_process`` to terminate it.

        Parameters
        ----------
        session_id:
            Identifies the sandbox.
        command:
            Shell command string to execute.
        cwd:
            Working directory (sandbox-relative).
        env_vars:
            Extra environment variables for this process.
        on_stdout:
            Optional callback invoked for each stdout line.
        on_stderr:
            Optional callback invoked for each stderr line.
        timeout:
            Connection timeout in seconds (0 = unlimited).

        Returns
        -------
        ProcessHandle with the process PID.

        Raises
        ------
        NotImplementedError
            If the provider does not support interactive processes.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support start_process. "
            "Use E2BProvider for interactive process support."
        )

    async def send_stdin(
        self,
        session_id: str,
        pid: int,
        data: str,
    ) -> None:
        """Send *data* to the stdin of a running process identified by *pid*.

        Parameters
        ----------
        session_id:
            Identifies the sandbox.
        pid:
            Process ID returned by ``start_process``.
        data:
            String data to write to stdin.  Append ``"\\n"`` to simulate
            pressing Enter.

        Raises
        ------
        NotImplementedError
            If the provider does not support interactive processes.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support send_stdin. "
            "Use E2BProvider for interactive process support."
        )

    async def kill_process(
        self,
        session_id: str,
        pid: int,
    ) -> bool:
        """Kill the process identified by *pid*.

        Parameters
        ----------
        session_id:
            Identifies the sandbox.
        pid:
            Process ID returned by ``start_process``.

        Returns
        -------
        ``True`` if the process was found and killed, ``False`` otherwise.

        Raises
        ------
        NotImplementedError
            If the provider does not support interactive processes.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support kill_process. "
            "Use E2BProvider for interactive process support."
        )

    # ------------------------------------------------------------------
    # Web browsing (optional – default raises NotImplementedError)
    # ------------------------------------------------------------------

    async def browse(
        self,
        session_id: str,
        url: str,
    ) -> str:
        """Fetch *url* from inside the sandbox and return the body text.

        Not every provider supports this; the default implementation
        falls back to ``run_command("curl …")``.
        """
        result = await self.run_command(
            session_id,
            f'curl -sL "{url}"',
            timeout=30,
        )
        return result.stdout

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    async def is_alive(self, session_id: str) -> bool:
        """Return ``True`` if the sandbox is running."""
        info = await self.get_info(session_id)
        return info is not None and info.state in ("running", "started")
