"""Sandbox provider abstraction layer.

Adapter pattern: all sandbox implementations share a common interface
defined in ``base.py``.  The ``factory`` module selects the concrete
provider at runtime based on configuration / environment variables.
"""

from genagent_core.sandbox.base import SandboxProvider, SandboxInfo, CommandResult
from genagent_core.sandbox.factory import create_sandbox_provider, get_sandbox_provider

__all__ = [
    "SandboxProvider",
    "SandboxInfo",
    "CommandResult",
    "create_sandbox_provider",
    "get_sandbox_provider",
]
