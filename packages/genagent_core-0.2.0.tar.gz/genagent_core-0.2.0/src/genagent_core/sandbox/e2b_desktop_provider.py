"""E2B Desktop Sandbox provider — full GUI / computer-use backend.

This provider wraps the ``e2b-desktop`` Python SDK and exposes:

1. All standard :class:`~src.sandbox.base.SandboxProvider` lifecycle methods
   (``create``, ``destroy``, ``run_command``, ``write_file``, ``read_file``).
2. Desktop-specific extensions via :class:`DesktopSandboxProvider`:
   - ``get_stream_url()``   — noVNC URL for embedding in the frontend
   - ``screenshot()``       — PNG bytes of the current desktop
   - ``left_click(x, y)``  — mouse click
   - ``right_click(x, y)``
   - ``double_click(x, y)``
   - ``move_mouse(x, y)``
   - ``scroll(direction, amount)``
   - ``drag(fr, to)``
   - ``write_text(text)``   — keyboard text input
   - ``press_key(key)``     — single key / hotkey (e.g. "ctrl+c")
   - ``open_url(url)``      — open URL in default browser
   - ``get_screen_size()``  — (width, height) tuple

SDK version compatibility
--------------------------
The E2B Desktop Python SDK has gone through two major API generations:

* **v1.x** (``e2b_desktop.Sandbox``): constructor-based init,
  ``get_video_stream_url()``, ``take_screenshot()``.
* **v2.x** (``e2b_desktop.Sandbox``): class-method ``Sandbox.create()``,
  ``screenshot()``, stream managed via ``sandbox.stream.start()`` /
  ``sandbox.stream.getUrl()``.

This module detects the installed version at runtime and adapts accordingly
so you can use either SDK generation without code changes.
"""
from __future__ import annotations

import base64
import logging
import os
from typing import Optional

from genagent_core.sandbox.base import CommandResult, SandboxInfo, SandboxProvider

logger = logging.getLogger(__name__)


def _detect_sdk_version() -> str:
    """Return ``"v1"`` or ``"v2"`` based on the installed e2b-desktop SDK."""
    try:
        import importlib.metadata
        ver = importlib.metadata.version("e2b-desktop")
        major = int(ver.split(".")[0])
        return "v2" if major >= 2 else "v1"
    except Exception:
        return "v1"


class DesktopSandboxProvider(SandboxProvider):
    """Concrete :class:`SandboxProvider` backed by E2B Desktop Sandbox.

    This provider supports the full computer-use loop:
    1. Create a Desktop sandbox (Ubuntu 22.04 + XFCE).
    2. Expose a noVNC stream URL so the frontend can render the live desktop.
    3. Execute mouse / keyboard actions via the E2B Desktop SDK.
    4. Take screenshots so the LLM can observe the current state.
    5. Run shell commands inside the sandbox.

    Configuration
    -------------
    Pass ``provider: "e2b_desktop"`` in ``config.json``:

    .. code-block:: json

        {
          "sandbox": {
            "provider": "e2b_desktop",
            "api_key_env": "E2B_API_KEY",
            "resolution": [1280, 800],
            "dpi": 96,
            "timeout": 1800
          }
        }
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        resolution: Optional[tuple[int, int]] = None,
        dpi: int = 96,
        timeout: int = 1800,
        template: Optional[str] = None,
        **_: object,
    ) -> None:
        self._api_key = api_key or os.getenv("E2B_API_KEY", "")
        if not self._api_key:
            raise ValueError(
                "E2B API key is required. "
                "Pass it via constructor or set E2B_API_KEY env var."
            )
        os.environ["E2B_API_KEY"] = self._api_key

        self._resolution = resolution or (1280, 800)
        self._dpi = dpi
        self._timeout = timeout
        self._template = template  # None → use default "desktop" template

        self._sdk_version = _detect_sdk_version()
        logger.info("E2B Desktop SDK version detected: %s", self._sdk_version)

        # session_id → desktop sandbox instance
        self._desktops: dict[str, object] = {}

        try:
            import e2b_desktop  # type: ignore  # noqa: F401
        except ImportError as exc:
            raise RuntimeError(
                "e2b-desktop package is required for DesktopSandboxProvider. "
                "Install it with: pip install e2b-desktop"
            ) from exc

    # ------------------------------------------------------------------
    # SandboxProvider lifecycle
    # ------------------------------------------------------------------

    async def create(self, session_id: str, **_: object) -> SandboxInfo:
        """Create a new E2B Desktop sandbox for the given session."""
        import e2b_desktop  # type: ignore

        logger.info("Creating E2B Desktop sandbox for session %s", session_id)

        if self._sdk_version == "v2":
            sandbox = e2b_desktop.Sandbox.create(
                template=self._template,
                resolution=self._resolution,
                dpi=self._dpi,
                timeout=self._timeout,
            )
            # Start VNC stream so the URL is immediately available
            try:
                sandbox.stream.start()
            except Exception:
                logger.warning("stream.start() failed — VNC URL may be unavailable")
        else:
            # v1 API: constructor-based
            sandbox = e2b_desktop.Sandbox(
                template=self._template,
                resolution=self._resolution,
                dpi=self._dpi,
                timeout=self._timeout,
            )

        self._desktops[session_id] = sandbox
        sandbox_id = getattr(sandbox, "sandbox_id", session_id)
        logger.info(
            "E2B Desktop sandbox created: session=%s sandbox_id=%s",
            session_id,
            sandbox_id,
        )
        return SandboxInfo(
            sandbox_id=sandbox_id,
            provider="e2b_desktop",
            state="running",
        )

    async def destroy(self, session_id: str) -> None:
        """Shut down the desktop sandbox for the given session."""
        sandbox = self._desktops.pop(session_id, None)
        if sandbox is None:
            return
        try:
            if hasattr(sandbox, "kill"):
                sandbox.kill()
            elif hasattr(sandbox, "close"):
                sandbox.close()
        except Exception:
            logger.warning("Error destroying E2B Desktop sandbox for session %s", session_id)

    async def run_command(
        self,
        session_id: str,
        command: str,
        timeout: int = 30,
        **_: object,
    ) -> CommandResult:
        """Run a shell command inside the desktop sandbox."""
        sandbox = self._desktops.get(session_id)
        if sandbox is None:
            return CommandResult(exit_code=1, stderr=f"No desktop sandbox for session {session_id}")

        try:
            # E2B Desktop SDK exposes the same commands API as the base SDK
            result = sandbox.commands.run(command, timeout=timeout)
            exit_code = getattr(result, "exit_code", 0)
            stdout = getattr(result, "stdout", "") or ""
            stderr = getattr(result, "stderr", "") or ""
            return CommandResult(exit_code=exit_code, stdout=stdout, stderr=stderr)
        except Exception as exc:
            return CommandResult(exit_code=1, stderr=str(exc))

    async def write_file(self, session_id: str, path: str, content: str) -> None:
        """Write a text file inside the desktop sandbox."""
        sandbox = self._desktops.get(session_id)
        if sandbox is None:
            raise RuntimeError(f"No desktop sandbox for session {session_id}")
        sandbox.files.write(path, content)

    async def read_file(self, session_id: str, path: str) -> str:
        """Read a text file from inside the desktop sandbox."""
        sandbox = self._desktops.get(session_id)
        if sandbox is None:
            raise RuntimeError(f"No desktop sandbox for session {session_id}")
        return sandbox.files.read(path)

    # ------------------------------------------------------------------
    # Desktop-specific extensions
    # ------------------------------------------------------------------

    def get_stream_url(self, session_id: str) -> str:
        """Return the noVNC stream URL for the given session.

        The URL can be embedded in the frontend as an ``<iframe>`` or passed
        to the ``DesktopPanel`` component for live rendering.

        Returns an empty string if the sandbox does not exist or the stream
        URL is unavailable.
        """
        sandbox = self._desktops.get(session_id)
        if sandbox is None:
            return ""

        # v2 API: sandbox.stream.getUrl()
        if self._sdk_version == "v2":
            try:
                return sandbox.stream.getUrl()
            except Exception:
                pass

        # v1 API: sandbox.get_video_stream_url()
        if hasattr(sandbox, "get_video_stream_url"):
            try:
                return sandbox.get_video_stream_url()
            except Exception:
                pass

        return ""

    def screenshot(self, session_id: str) -> bytes:
        """Take a screenshot of the current desktop state.

        Returns raw PNG bytes.  Returns an empty bytes object if the sandbox
        does not exist.
        """
        sandbox = self._desktops.get(session_id)
        if sandbox is None:
            return b""

        try:
            # v2 API: sandbox.screenshot() → bytearray
            if hasattr(sandbox, "screenshot"):
                data = sandbox.screenshot(format="bytes")
                return bytes(data)
            # v1 API: sandbox.take_screenshot() → bytearray
            if hasattr(sandbox, "take_screenshot"):
                data = sandbox.take_screenshot(format="bytes")
                return bytes(data)
        except Exception as exc:
            logger.warning("screenshot() failed for session %s: %s", session_id, exc)
        return b""

    def screenshot_base64(self, session_id: str) -> str:
        """Return a base64-encoded PNG screenshot (data URI ready)."""
        raw = self.screenshot(session_id)
        if not raw:
            return ""
        return "data:image/png;base64," + base64.b64encode(raw).decode()

    def left_click(self, session_id: str, x: int, y: int) -> None:
        sandbox = self._get_sandbox(session_id)
        sandbox.move_mouse(x, y)
        sandbox.left_click(x, y)

    def right_click(self, session_id: str, x: int, y: int) -> None:
        sandbox = self._get_sandbox(session_id)
        sandbox.move_mouse(x, y)
        # v1 uses right_click(); v2 uses right_click(x, y)
        if self._sdk_version == "v2":
            sandbox.right_click(x, y)
        else:
            sandbox.right_click()

    def double_click(self, session_id: str, x: int, y: int) -> None:
        sandbox = self._get_sandbox(session_id)
        sandbox.double_click(x, y)

    def move_mouse(self, session_id: str, x: int, y: int) -> None:
        sandbox = self._get_sandbox(session_id)
        sandbox.move_mouse(x, y)

    def scroll(self, session_id: str, direction: str = "down", amount: int = 3) -> None:
        sandbox = self._get_sandbox(session_id)
        sandbox.scroll(direction=direction, amount=amount)

    def drag(
        self,
        session_id: str,
        from_x: int,
        from_y: int,
        to_x: int,
        to_y: int,
    ) -> None:
        sandbox = self._get_sandbox(session_id)
        sandbox.drag((from_x, from_y), (to_x, to_y))

    def write_text(self, session_id: str, text: str) -> None:
        """Type text at the current cursor position."""
        sandbox = self._get_sandbox(session_id)
        sandbox.write(text)

    def press_key(self, session_id: str, key: str) -> None:
        """Press a key or key combination.

        Examples: ``"enter"``, ``"ctrl+c"``, ``"alt+F4"``.
        """
        sandbox = self._get_sandbox(session_id)
        if "+" in key:
            # Hotkey combination
            parts = [k.strip() for k in key.split("+")]
            if hasattr(sandbox, "hotkey"):
                sandbox.hotkey(*parts)
            else:
                sandbox.press(parts)
        else:
            sandbox.press(key)

    def open_url(self, session_id: str, url: str) -> None:
        """Open a URL in the default browser inside the sandbox."""
        sandbox = self._get_sandbox(session_id)
        sandbox.open(url)

    def get_screen_size(self, session_id: str) -> tuple[int, int]:
        """Return the (width, height) of the sandbox desktop."""
        sandbox = self._desktops.get(session_id)
        if sandbox is None:
            return self._resolution
        try:
            return sandbox.get_screen_size()
        except Exception:
            return self._resolution

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_sandbox(self, session_id: str) -> object:
        sandbox = self._desktops.get(session_id)
        if sandbox is None:
            raise RuntimeError(
                f"No desktop sandbox found for session '{session_id}'. "
                "Call create() first."
            )
        return sandbox
