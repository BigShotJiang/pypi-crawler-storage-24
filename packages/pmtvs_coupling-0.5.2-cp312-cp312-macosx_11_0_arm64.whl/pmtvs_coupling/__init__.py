"""
pmtvs-coupling — Rolling Spearman correlation primitives.

numpy in, numpy out.
Rust backend (_core) required.
"""

__version__ = "0.5.1"

import numpy as np

try:
    from pmtvs_coupling._core import (
        rolling_spearman as _rs_rolling_spearman,
        batch_rolling_spearman as _rs_batch_rolling_spearman,
    )
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-coupling && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

BACKEND = "rust"


def rolling_spearman(x, y, window):
    """Rolling Spearman ρ (Rust-accelerated). Handles non-contiguous arrays."""
    return _rs_rolling_spearman(
        np.ascontiguousarray(x, dtype=np.float64),
        np.ascontiguousarray(y, dtype=np.float64),
        window,
    )


def batch_rolling_spearman(x_batch, y_batch, window):
    """Batch rolling Spearman ρ — Rayon parallel across pairs."""
    return _rs_batch_rolling_spearman(
        np.ascontiguousarray(x_batch, dtype=np.float64),
        np.ascontiguousarray(y_batch, dtype=np.float64),
        window,
    )


__all__ = [
    "__version__",
    "BACKEND",
    "rolling_spearman",
    "batch_rolling_spearman",
]
