# StyloBridge

**Enterprise-grade MCP document converter -- Markdown and PDF to professionally styled Word documents.**

[![License: Proprietary](https://img.shields.io/badge/license-Proprietary-blue.svg)](https://github.com/blockpal1/Stylobridge)
[![CI](https://github.com/blockpal1/Stylobridge/actions/workflows/ci.yml/badge.svg)](https://github.com/blockpal1/Stylobridge/actions)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)

<!-- mcp-name: io.github.blockpal1/stylobridge -->

---

## What It Does

StyloBridge is an MCP server that converts Markdown and PDF files to professionally styled Word documents. It integrates with Claude Desktop, Cursor, and VS Code, applying your corporate brand templates automatically while enforcing licensing and logging every conversion for audit compliance.

---

## Features

- **Markdown to DOCX** -- Convert Markdown files to branded Word documents with optional table of contents
- **PDF to DOCX** -- Extract and re-style PDF content into editable Word format
- **Style Guard Preprocessor** -- Normalizes AI-generated Markdown (indentation, table captions, formatting) before conversion
- **Corporate Brand Templates** -- Apply organization-wide fonts, colors, logos, and layouts automatically
- **Tier-Based Licensing** -- RS256 JWT-based access control with seat management and hot rotation
- **Audit Logging** -- Structured JSON-lines logs for every conversion, ready for Splunk, ELK, or Datadog

---

## Installation

### Individual (Developers)

**Requires:** Python 3.10+, [uv](https://docs.astral.sh/uv/)

```bash
git clone https://github.com/blockpal1/Stylobridge.git
cd Stylobridge
```

Add StyloBridge to your Claude Desktop configuration:

**Windows** (`%APPDATA%/Claude/claude_desktop_config.json`):

**macOS** (`~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "stylobridge": {
      "command": "uv",
      "args": ["--directory", "/path/to/Stylobridge", "run", "python", "main.py"],
      "env": {
        "STYLOBRIDGE_LICENSE": "<your-license-token>",
        "TEMPLATE_DIR": "/path/to/Stylobridge/src/templates",
        "WORKSPACE_ROOT": "/path/to/your/documents"
      }
    }
  }
}
```

### Team / Enterprise (Docker)

**Requires:** Docker

```json
{
  "mcpServers": {
    "stylobridge": {
      "command": "docker",
      "args": [
        "run", "--rm", "-i",
        "-e", "STYLOBRIDGE_LICENSE=<your-license-token>",
        "-v", "/path/to/documents:/app/data",
        "-v", "/path/to/templates:/app/src/templates",
        "ghcr.io/blockpal1/stylobridge:latest"
      ]
    }
  }
}
```

---

## Configuration

| Variable | Required | Description |
|---|---|---|
| `STYLOBRIDGE_LICENSE` | Yes | RS256-signed JWT license token |
| `TEMPLATE_DIR` | No | Path to corporate `.docx` brand templates (default: `src/templates/`) |
| `WORKSPACE_ROOT` | No | Root directory for all file I/O; paths outside this are rejected |
| `LOG_LEVEL` | No | Logging verbosity: `DEBUG`, `INFO`, `WARNING`, `ERROR` (default: `INFO`) |

---

## MCP Tools

| Tool | Description |
|---|---|
| `convert_to_docx` | Convert a Markdown or PDF file to a styled `.docx` document, with optional brand template and table of contents |
| `list_templates` | List all available corporate brand templates in the configured template directory |
| `analyze_and_create_template` | Analyze an existing branded `.docx` file and extract its styles into a reusable Pandoc reference template |

---

## Pricing

| Plan | Price | Includes |
|---|---|---|
| **Individual** | $199/year | Document conversion (Markdown and PDF to DOCX) |
| **Team** | $1,495/year | Everything -- up to 25 users, brand templates, audit logging |
| **Enterprise** | $4,995/year | Everything -- unlimited users |

Visit [github.com/blockpal1/Stylobridge](https://github.com/blockpal1/Stylobridge) for details.

---

## License

Proprietary. A valid license token is required to use StyloBridge. See the [Pricing](#pricing) section for available plans.
