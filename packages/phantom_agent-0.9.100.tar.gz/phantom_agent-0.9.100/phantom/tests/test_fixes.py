"""
Verification script for Phantom v2 token optimization fixes.

Run with:
    python -m phantom.tests.test_fixes

Environment variables to enable fixes:
    PHANTOM_USE_CONDENSED_PROMPT=true
    PHANTOM_USE_CHAIN_SUMMARIZER=true
    PHANTOM_USE_REFLECTOR=true
    PHANTOM_USE_AUTO_SUMMARIZE=true
    PHANTOM_USE_TOOL_DELEGATION=true
"""

import os
import sys

def test_imports():
    """Test that all new modules can be imported."""
    print("Testing imports...")
    
    # Test ChainSummarizer
    try:
        from phantom.llm.pentager import ChainSummarizer, ChainAST, create_chain_summarizer
        print("  [OK] ChainSummarizer imports")
    except Exception as e:
        print(f"  [FAIL] ChainSummarizer: {e}")
        return False
    
    # Test Reflector
    try:
        from phantom.llm.pentager.reflector import Reflector, get_reflector
        print("  [OK] Reflector imports")
    except Exception as e:
        print(f"  [FAIL] Reflector: {e}")
        return False
    
    # Test VectorMemory
    try:
        from phantom.memory.vector_store import VectorMemory, get_memory
        print("  [OK] VectorMemory imports")
    except Exception as e:
        print(f"  [FAIL] VectorMemory: {e}")
        return False
    
    return True


def test_chain_ast():
    """Test ChainAST parsing."""
    print("\nTesting ChainAST...")
    
    from phantom.llm.pentager import ChainAST
    
    messages = [
        {"role": "system", "content": "You are a security agent"},
        {"role": "user", "content": "Test the endpoint /api/login"},
        {"role": "assistant", "content": "I'll test for SQL injection"},
        {"role": "user", "content": "<tool_result>SQL injection detected</tool_result>"},
        {"role": "assistant", "content": "I'll create a report"},
    ]
    
    ast = ChainAST.parse(messages)
    
    if len(ast.sections) < 1:
        print(f"  [FAIL] Expected sections, got {len(ast.sections)}")
        return False
    
    print(f"  [OK] ChainAST parsed {len(messages)} messages into {len(ast.sections)} sections")
    return True


def test_chain_summarizer():
    """Test ChainSummarizer threshold detection."""
    print("\nTesting ChainSummarizer...")
    
    from phantom.llm.pentager import create_chain_summarizer
    
    summarizer = create_chain_summarizer()
    
    # Create a small message list
    small_messages = [
        {"role": "system", "content": "You are a security agent"},
        {"role": "user", "content": "Test the endpoint"},
    ]
    
    if summarizer.should_summarize(small_messages):
        print("  [WARN] Small messages triggering summarize (expected at high load)")
    else:
        print("  [OK] Small messages don't trigger summarize")
    
    print("  [OK] ChainSummarizer initialized correctly")
    return True


def test_reflector():
    """Test Reflector initialization."""
    print("\nTesting Reflector...")
    
    from phantom.llm.pentager.reflector import Reflector
    
    reflector = Reflector()
    
    if reflector.reflector_model:
        print(f"  [OK] Reflector uses model: {reflector.reflector_model}")
    else:
        print("  [FAIL] Reflector model not set")
        return False
    
    return True


def test_vector_memory():
    """Test VectorMemory storage and retrieval."""
    print("\nTesting VectorMemory...")
    
    from phantom.memory.vector_store import VectorMemory
    import tempfile
    import os
    
    # Use temp directory for testing
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test_memory.db")
        memory = VectorMemory(scan_id="test-scan", db_path=db_path)
        
        # Store a finding
        memory_id = memory.store(
            doc_type="finding",
            content="SQL injection in /api/login",
            metadata={"severity": "high"}
        )
        
        if not memory_id:
            print("  [FAIL] Failed to store memory")
            return False
        
        # Search for it
        results = memory.search("SQL injection")
        
        if len(results) == 0:
            print("  [FAIL] Memory search returned no results")
            return False
        
        print(f"  [OK] Stored and retrieved memory: {len(results)} result(s)")
        
        # Test count
        count = memory.count()
        if count < 1:
            print("  [FAIL] Memory count incorrect")
            return False
        
        print(f"  [OK] Memory count: {count}")
    
    return True


def test_executor_auto_summarize():
    """Test executor auto-summarize threshold."""
    print("\nTesting executor auto-summarize...")
    
    from phantom.tools.executor import AUTO_SUMMARIZE_THRESHOLD, SUMMARIZE_MODEL
    
    if AUTO_SUMMARIZE_THRESHOLD != 16000:
        print(f"  [WARN] Expected threshold 16000, got {AUTO_SUMMARIZE_THRESHOLD}")
    else:
        print(f"  [OK] Auto-summarize threshold: {AUTO_SUMMARIZE_THRESHOLD}")
    
    print(f"  [OK] Summarize model: {SUMMARIZE_MODEL}")
    return True


def test_agents_graph_delegation():
    """Test agents_graph delegation limits."""
    print("\nTesting agents_graph delegation limits...")
    
    # Check the code was modified
    try:
        from phantom.tools.agents_graph import agents_graph_actions
        import inspect
        
        source = inspect.getsource(agents_graph_actions.create_agent)
        
        if "PHANTOM_USE_TOOL_DELEGATION" in source:
            print("  [OK] Tool delegation env var check present in create_agent")
        else:
            print("  [WARN] Tool delegation env var check not found")
        
        if "use_tool_delegation" in source:
            print("  [OK] Tool delegation logic present")
        else:
            print("  [WARN] Tool delegation logic not found")
        
    except Exception as e:
        print(f"  [FAIL] Error checking agents_graph: {e}")
        return False
    
    return True


def test_base_agent_reflector():
    """Test base_agent Reflector integration."""
    print("\nTesting base_agent Reflector integration...")
    
    try:
        from phantom.agents.base_agent import BaseAgent
        import inspect
        
        source = inspect.getsource(BaseAgent._process_iteration)
        
        if "PHANTOM_USE_REFLECTOR" in source:
            print("  [OK] Reflector env var check present in _process_iteration")
        else:
            print("  [WARN] Reflector env var check not found")
        
        if "get_reflector" in source:
            print("  [OK] Reflector integration present")
        else:
            print("  [WARN] Reflector integration not found")
        
    except Exception as e:
        print(f"  [FAIL] Error checking base_agent: {e}")
        return False
    
    return True


def main():
    """Run all tests."""
    print("=" * 60)
    print("Phantom v2 Token Optimization - Fix Verification")
    print("=" * 60)
    
    os.environ["PHANTOM_USE_CONDENSED_PROMPT"] = "true"
    os.environ["PHANTOM_USE_CHAIN_SUMMARIZER"] = "true"
    os.environ["PHANTOM_USE_REFLECTOR"] = "true"
    os.environ["PHANTOM_USE_AUTO_SUMMARIZE"] = "true"
    os.environ["PHANTOM_USE_TOOL_DELEGATION"] = "true"
    
    results = []
    
    results.append(("Imports", test_imports()))
    results.append(("ChainAST", test_chain_ast()))
    results.append(("ChainSummarizer", test_chain_summarizer()))
    results.append(("Reflector", test_reflector()))
    results.append(("VectorMemory", test_vector_memory()))
    results.append(("Executor Auto-Summarize", test_executor_auto_summarize()))
    results.append(("Agents Graph Delegation", test_agents_graph_delegation()))
    results.append(("Base Agent Reflector", test_base_agent_reflector()))
    
    print("\n" + "=" * 60)
    print("RESULTS SUMMARY")
    print("=" * 60)
    
    all_passed = True
    for name, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"  {status}: {name}")
        if not passed:
            all_passed = False
    
    print("=" * 60)
    
    if all_passed:
        print("\n[SUCCESS] All verification tests passed!")
        return 0
    else:
        print("\n[FAILURE] Some tests failed!")
        return 1


if __name__ == "__main__":
    sys.exit(main())
