"""conftest.py — set up mock stubs before any Phantom modules are imported."""
import sys
from unittest.mock import MagicMock

if "libtmux" not in sys.modules:
    _mock_tmux = MagicMock()
    _mock_session = MagicMock()
    _mock_server = MagicMock()
    _mock_tmux.Server.return_value = _mock_server
    _mock_server.new_session.return_value = _mock_session
    sys.modules["libtmux"] = _mock_tmux
    sys.modules["libtmux.server"] = _mock_server
    sys.modules["libtmux.session"] = _mock_session
