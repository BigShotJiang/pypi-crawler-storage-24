"""
ATTACK YOUR FIX - Comprehensive verification script.
Tests edge cases, integration, and actual behavior.
"""

import os
import sys
import asyncio
import tempfile
import time
import json

# Set environment variables for testing
os.environ["PHANTOM_USE_CONDENSED_PROMPT"] = "true"
os.environ["PHANTOM_USE_CHAIN_SUMMARIZER"] = "true"
os.environ["PHANTOM_USE_REFLECTOR"] = "true"
os.environ["PHANTOM_USE_AUTO_SUMMARIZE"] = "true"
os.environ["PHANTOM_USE_TOOL_DELEGATION"] = "true"

print("=" * 70)
print("ATTACK YOUR FIX - COMPREHENSIVE VERIFICATION")
print("=" * 70)


def test_f1_condensed_prompt():
    """ATTACK Fix 1: Condensed Prompt"""
    print("\n" + "=" * 70)
    print("FIX 1: CONDENSED PROMPT - ATTACK TEST")
    print("=" * 70)
    
    try:
        # Test 1: Can we actually LOAD the template?
        from jinja2 import Environment, FileSystemLoader
        from phantom.utils.resource_paths import get_phantom_resource_path
        
        prompt_dir = get_phantom_resource_path("agents", "PhantomAgent")
        env = Environment(
            loader=FileSystemLoader([prompt_dir]),
            autoescape=lambda x: False,
        )
        
        template = env.get_template("system_prompt_condensed.jinja")
        print(f"  [TEST] Template loaded successfully")
        
        # Render with minimal context - provide get_skill function
        def mock_get_skill(name):
            return f"Mock skill content for {name}"
        
        rendered = template.render(
            get_tools_prompt=lambda: "TOOLS: terminal_execute, send_request",
            loaded_skill_names=["test_skill"],
            scan_mode="standard",
            phantom_port_range="",
            is_subagent=False,
            get_skill=mock_get_skill,
        )
        
        print(f"  [TEST] Rendered chars: {len(rendered)}")
        print(f"  [TEST] Rendered lines: {len(rendered.splitlines())}")
        
        # Check it has critical sections
        assert "<reporting>" in rendered, "Missing <reporting> section"
        assert "<rules>" in rendered, "Missing <rules> section"
        assert "<multi_agent>" in rendered, "Missing <multi_agent> section"
        print(f"  [PASS] Contains all critical sections")
        
        # Test 2: Is it actually smaller than original?
        original_template = env.get_template("system_prompt.jinja")
        
        def mock_get_skill(name):
            return f"Mock skill content for {name}"
        
        original_rendered = original_template.render(
            get_tools_prompt=lambda: "TOOLS: terminal_execute, send_request",
            loaded_skill_names=["test_skill"],
            scan_mode="standard",
            phantom_port_range="",
            is_subagent=False,
            get_skill=mock_get_skill,
        )
        
        reduction = (1 - len(rendered) / len(original_rendered)) * 100
        print(f"  [RESULT] Condensed: {len(rendered)} vs Original: {len(original_rendered)} chars")
        print(f"  [RESULT] Reduction: {reduction:.1f}%")
        
        if reduction < 20:
            print(f"  [WARN] Reduction only {reduction:.1f}% - might need more work")
        
        # Test 3: Does Condensed prompt have delegation guidance?
        assert "DELEGATION" in rendered or "delegation" in rendered.lower(), \
            "Missing delegation guidance!"
        print(f"  [PASS] Has delegation guidance")
        
        return True
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        import traceback
        traceback.print_exc()
        return False


def test_f2_chain_ast():
    """ATTACK Fix 2: ChainAST"""
    print("\n" + "=" * 70)
    print("FIX 2: CHAINAST - ATTACK TEST")
    print("=" * 70)
    
    try:
        from phantom.llm.pentager import ChainAST, ChainSummarizer, create_chain_summarizer
        
        # Test 1: Parse real-looking messages
        verbose_messages = [
            {"role": "system", "content": "You are a security agent. Your goal is to find vulnerabilities."},
        ]
        
        # Add 20 realistic conversation turns
        for i in range(20):
            verbose_messages.append({
                "role": "user", 
                "content": f"<tool_result>\nTool: nmap\nResult: Port 22 open, Port 80 open, Port 443 open\n</tool_result>"
            })
            verbose_messages.append({
                "role": "assistant",
                "content": f"<function=send_request>\n<parameter=url>https://target.com/api/v1/users</parameter>\n<parameter=method>GET</parameter>\n</function>"
            })
            verbose_messages.append({
                "role": "user",
                "content": f"<tool_result>\nTool: send_request\nResult: {{'id': 1, 'username': 'admin', 'email': 'admin@target.com'}}</tool_result>"
            })
            verbose_messages.append({
                "role": "assistant",
                "content": f"Found API endpoint with user data. Testing for IDOR vulnerability by changing ID parameter..."
            })
        
        print(f"  [TEST] Parsing {len(verbose_messages)} messages...")
        ast = ChainAST.parse(verbose_messages)
        
        print(f"  [RESULT] Parsed into {len(ast.sections)} sections")
        print(f"  [RESULT] Total tokens estimate: {ast.total_tokens}")
        
        # Test 2: Does it correctly identify sections?
        assert len(ast.sections) > 0, "No sections parsed!"
        print(f"  [PASS] Parsed sections correctly")
        
        # Test 3: Test summarization threshold
        summarizer = create_chain_summarizer()
        print(f"  [TEST] Threshold: {summarizer.threshold} tokens")
        
        should_sum = summarizer.should_summarize(verbose_messages)
        print(f"  [RESULT] Should summarize: {should_sum}")
        
        if should_sum:
            compressed = summarizer.summarize(verbose_messages)
            print(f"  [RESULT] Compressed from {len(verbose_messages)} to {len(compressed)} messages")
            
            # Verify we didn't lose the most recent messages
            assert len(compressed) < len(verbose_messages), "No compression happened!"
            assert any("system" in str(m).lower() for m in compressed), "Lost system message!"
            print(f"  [PASS] Compression working correctly")
        
        # Test 4: Edge case - empty messages
        empty_ast = ChainAST.parse([])
        assert empty_ast.sections == [], "Empty messages should produce empty sections"
        print(f"  [PASS] Empty messages handled")
        
        # Test 5: Edge case - single message
        single_ast = ChainAST.parse([{"role": "user", "content": "test"}])
        print(f"  [PASS] Single message handled: {len(single_ast.sections)} sections")
        
        return True
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        import traceback
        traceback.print_exc()
        return False


def test_f3_vector_memory():
    """ATTACK Fix 3: VectorMemory"""
    print("\n" + "=" * 70)
    print("FIX 3: VECTOR MEMORY - ATTACK TEST")
    print("=" * 70)
    
    try:
        from phantom.memory.vector_store import VectorMemory, get_memory
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test_memory.db")
            memory = VectorMemory(scan_id="attack-test", db_path=db_path, ttl_days=30)
            
            # Test 1: Store multiple types of data
            fid1 = memory.store("finding", "SQL Injection in /api/login - parameter 'username'")
            fid2 = memory.store("tool_result", "Nmap scan: 3 open ports found", 
                               metadata={"tool": "nmap", "ports": 3})
            fid3 = memory.store("hypothesis", "Testing for SSRF in /api/fetch")
            fid4 = memory.store("note", "Admin panel found at /admin")
            
            print(f"  [TEST] Stored 4 memories")
            print(f"  [RESULT] Finding ID: {fid1}")
            
            # Test 2: Search functionality
            results = memory.search("SQL injection")
            print(f"  [RESULT] Search 'SQL injection': {len(results)} results")
            assert len(results) >= 1, "Should find SQL injection"
            print(f"  [PASS] Found SQL injection finding")
            assert len(results) >= 1, "Should find SQL injection"
            print(f"  [PASS] Found SQL injection finding")
            
            # Test 3: Search with different query
            results = memory.search("nmap ports")
            print(f"  [RESULT] Search 'nmap ports': {len(results)} results")
            assert len(results) >= 1, "Should find nmap result"
            print(f"  [PASS] Found nmap result")
            
            # Test 4: Search with no results
            results = memory.search("nonexistent vulnerability xyz123")
            print(f"  [RESULT] Search 'nonexistent': {len(results)} results")
            assert len(results) == 0, "Should not find anything"
            print(f"  [PASS] Correctly returns empty for no matches")
            
            # Test 5: Filter by doc_type
            findings = memory.search("SQL", doc_type="finding")
            print(f"  [RESULT] Filter by type 'finding' with query 'SQL': {len(findings)} results")
            assert len(findings) == 1, "Should find exactly 1 finding"
            print(f"  [PASS] Type filtering works")
            
            # Test 6: Get specific memory
            entry = memory.get(fid2)
            assert entry is not None, "Should retrieve specific memory"
            assert entry.doc_type == "tool_result", "Wrong doc_type"
            print(f"  [PASS] Get specific memory works")
            
            # Test 7: Delete memory
            deleted = memory.delete(fid4)
            assert deleted, "Should delete successfully"
            remaining = memory.search("Admin panel")
            assert len(remaining) == 0, "Should be deleted"
            print(f"  [PASS] Delete works")
            
            # Test 8: to_prompt_context
            context = memory.to_prompt_context("injection")
            print(f"  [RESULT] Prompt context length: {len(context)} chars")
            assert len(context) > 0, "Should generate context"
            print(f"  [PASS] to_prompt_context works")
            
            # Test 9: Count
            count = memory.count()
            print(f"  [RESULT] Memory count: {count}")
            assert count == 3, f"Should have 3 memories, got {count}"
            print(f"  [PASS] Count works")
            
            # Test 10: Edge case - empty search
            empty_memory = VectorMemory(scan_id="empty-test", db_path=db_path)
            results = empty_memory.search("anything")
            assert len(results) == 0, "Empty memory should return no results"
            print(f"  [PASS] Empty memory handled")
            
            return True
            
    except Exception as e:
        print(f"  [FAIL] {e}")
        import traceback
        traceback.print_exc()
        return False


def test_f4_reflector():
    """ATTACK Fix 4: Reflector"""
    print("\n" + "=" * 70)
    print("FIX 4: REFLECTOR - ATTACK TEST")
    print("=" * 70)
    
    try:
        from phantom.llm.pentager.reflector import Reflector, REFLECTOR_PROMPT
        
        # Test 1: Reflector initialization
        reflector = Reflector(reflector_model="gpt-4o-mini")
        print(f"  [TEST] Reflector model: {reflector.reflector_model}")
        assert reflector.reflector_model == "gpt-4o-mini"
        print(f"  [PASS] Initialization works")
        
        # Test 2: Check prompt template
        assert "{context}" in REFLECTOR_PROMPT, "Missing context placeholder"
        print(f"  [PASS] Prompt template correct")
        
        # Test 3: Mock the actual reflection (don't make real API calls)
        # We'll test the prompt generation logic
        test_context = "The agent was testing /api/login for SQL injection"
        prompt = REFLECTOR_PROMPT.format(context=test_context)
        
        assert test_context in prompt, "Context not in prompt"
        print(f"  [RESULT] Generated prompt length: {len(prompt)} chars")
        print(f"  [PASS] Prompt generation works")
        
        # Test 4: Empty context handling
        reflector2 = Reflector()
        # The actual reflect() would make API call, but we can test initialization
        print(f"  [PASS] Empty initialization handled")
        
        # Test 5: Integration check - is it in base_agent?
        from phantom.agents.base_agent import BaseAgent
        import inspect
        
        source = inspect.getsource(BaseAgent._process_iteration)
        assert "get_reflector" in source, "Reflector not integrated in _process_iteration"
        assert "PHANTOM_USE_REFLECTOR" in source, "PHANTOM_USE_REFLECTOR check not in code"
        print(f"  [PASS] Reflector integrated in BaseAgent")
        
        # Test 6: Verify env var check logic
        assert "PHANTOM_USE_REFLECTOR" in os.environ, "Env var should be set"
        print(f"  [PASS] Environment variable configured")
        
        return True
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        import traceback
        traceback.print_exc()
        return False


def test_f5_auto_summarize():
    """ATTACK Fix 5: Auto-Summarize"""
    print("\n" + "=" * 70)
    print("FIX 5: AUTO-SUMMARIZE - ATTACK TEST")
    print("=" * 70)
    
    try:
        from phantom.tools.executor import (
            AUTO_SUMMARIZE_THRESHOLD, 
            SUMMARIZE_MODEL,
            _auto_summarize_result
        )
        
        # Test 1: Threshold check
        print(f"  [TEST] AUTO_SUMMARIZE_THRESHOLD: {AUTO_SUMMARIZE_THRESHOLD}")
        assert AUTO_SUMMARIZE_THRESHOLD == 16000, f"Expected 16000, got {AUTO_SUMMARIZE_THRESHOLD}"
        print(f"  [PASS] Threshold is 16000")
        
        # Test 2: Model check
        print(f"  [TEST] SUMMARIZE_MODEL: {SUMMARIZE_MODEL}")
        assert SUMMARIZE_MODEL == "gpt-4o-mini", f"Expected gpt-4o-mini, got {SUMMARIZE_MODEL}"
        print(f"  [PASS] Model is gpt-4o-mini")
        
        # Test 3: Check function exists and is async
        import inspect
        assert asyncio.iscoroutinefunction(_auto_summarize_result), "Should be async function"
        print(f"  [PASS] Function is async")
        
        # Test 4: Test with small text (should NOT summarize)
        small_text = "This is a small result with only a few characters."
        loop = asyncio.new_event_loop()
        result = loop.run_until_complete(
            _auto_summarize_result(small_text, "test_tool")
        )
        loop.close()
        
        # Small text should pass through unchanged
        assert result == small_text, "Small text should not be modified"
        print(f"  [PASS] Small text passes through unchanged")
        
        # Test 5: Check integration in _execute_single_tool
        from phantom.tools import executor
        source = inspect.getsource(executor._execute_single_tool)
        assert "needs_llm_summary" in source or "auto_summarize" in source, \
            "Auto-summarize not integrated!"
        print(f"  [PASS] Auto-summarize integrated in _execute_single_tool")
        
        # Test 6: Verify meta tags are added
        source = inspect.getsource(executor._format_tool_result_with_meta)
        assert "AUTO_SUMMARIZE_THRESHOLD" in source, \
            "Threshold check not in formatting!"
        print(f"  [PASS] Threshold check in formatter")
        
        return True
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        import traceback
        traceback.print_exc()
        return False


def test_f6_tool_delegation():
    """ATTACK Fix 6: Tool Delegation"""
    print("\n" + "=" * 70)
    print("FIX 6: TOOL DELEGATION - ATTACK TEST")
    print("=" * 70)
    
    try:
        from phantom.tools.agents_graph import agents_graph_actions
        import inspect
        
        # Test 1: Check create_agent has delegation logic
        source = inspect.getsource(agents_graph_actions.create_agent)
        
        assert "PHANTOM_USE_TOOL_DELEGATION" in source, \
            "Tool delegation env var check missing!"
        print(f"  [PASS] Env var check present")
        
        assert "use_tool_delegation" in source, \
            "use_tool_delegation variable missing!"
        print(f"  [PASS] Delegation logic present")
        
        # Test 2: Check stricter limits
        # The code should reduce max_total and max_concurrent when enabled
        assert "_max_total = min" in source or "min(_max_total" in source, \
            "Stricter total limit not implemented!"
        assert "_max_concurrent = min" in source or "min(_max_concurrent" in source, \
            "Stricter concurrent limit not implemented!"
        print(f"  [PASS] Stricter limits implemented")
        
        # Test 3: Verify env var is set
        assert os.environ.get("PHANTOM_USE_TOOL_DELEGATION") == "true", \
            "Env var not set correctly"
        print(f"  [PASS] Environment variable correct")
        
        # Test 4: Check system prompt has delegation hierarchy
        from jinja2 import Environment, FileSystemLoader
        from phantom.utils.resource_paths import get_phantom_resource_path
        
        prompt_dir = get_phantom_resource_path("agents", "PhantomAgent")
        env = Environment(
            loader=FileSystemLoader([prompt_dir]),
            autoescape=lambda x: False,
        )
        
        template = env.get_template("system_prompt_condensed.jinja")
        rendered = template.render(
            get_tools_prompt=lambda: "TOOLS",
            loaded_skill_names=[],
            scan_mode="standard",
            phantom_port_range="",
            is_subagent=False,
        )
        
        # Check for delegation hierarchy
        assert "TOOLS FIRST" in rendered or "tools first" in rendered.lower(), \
            "Delegation hierarchy missing from prompt!"
        assert "sqlmap" in rendered or "nuclei" in rendered or "ffuf" in rendered, \
            "Specific tools not mentioned!"
        print(f"  [PASS] System prompt has delegation hierarchy")
        
        return True
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        import traceback
        traceback.print_exc()
        return False


def test_integration():
    """End-to-end integration test"""
    print("\n" + "=" * 70)
    print("INTEGRATION TEST - ALL FIXES WORKING TOGETHER")
    print("=" * 70)
    
    try:
        # Test 1: Can we import everything together?
        from phantom.llm.pentager import ChainSummarizer, create_chain_summarizer
        from phantom.llm.pentager.reflector import Reflector, get_reflector
        from phantom.memory.vector_store import VectorMemory, get_memory
        print(f"  [PASS] All imports work together")
        
        # Test 2: Can we use ChainSummarizer?
        summarizer = create_chain_summarizer()
        messages = [
            {"role": "system", "content": "You are a security agent"},
            {"role": "user", "content": "Test this endpoint"},
        ]
        result = summarizer.should_summarize(messages)
        print(f"  [PASS] ChainSummarizer integrated")
        
        # Test 3: Can we use VectorMemory?
        with tempfile.TemporaryDirectory() as tmpdir:
            memory = VectorMemory(scan_id="integration-test", db_path=os.path.join(tmpdir, "test.db"))
            memory.store("test", "Integration test data")
            results = memory.search("integration")
            assert len(results) >= 1
            print(f"  [PASS] VectorMemory integrated")
        
        # Test 4: Verify all env vars are set
        required_vars = [
            "PHANTOM_USE_CONDENSED_PROMPT",
            "PHANTOM_USE_CHAIN_SUMMARIZER",
            "PHANTOM_USE_REFLECTOR",
            "PHANTOM_USE_AUTO_SUMMARIZE",
            "PHANTOM_USE_TOOL_DELEGATION",
        ]
        
        for var in required_vars:
            assert os.environ.get(var) == "true", f"Missing or wrong: {var}"
            print(f"  [PASS] {var}=true")
        
        return True
        
    except Exception as e:
        print(f"  [FAIL] {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    results = []
    
    results.append(("Fix 1: Condensed Prompt", test_f1_condensed_prompt()))
    results.append(("Fix 2: ChainAST", test_f2_chain_ast()))
    results.append(("Fix 3: VectorMemory", test_f3_vector_memory()))
    results.append(("Fix 4: Reflector", test_f4_reflector()))
    results.append(("Fix 5: Auto-Summarize", test_f5_auto_summarize()))
    results.append(("Fix 6: Tool Delegation", test_f6_tool_delegation()))
    results.append(("Integration", test_integration()))
    
    print("\n" + "=" * 70)
    print("FINAL RESULTS")
    print("=" * 70)
    
    all_passed = True
    for name, passed in results:
        status = "[PASS]" if passed else "[FAIL]"
        print(f"  {status}: {name}")
        if not passed:
            all_passed = False
    
    print("=" * 70)
    
    if all_passed:
        print("\nALL TESTS PASSED - Fixes verified and working!")
        return 0
    else:
        print("\nSOME TESTS FAILED - Review output above")
        return 1


if __name__ == "__main__":
    sys.exit(main())
