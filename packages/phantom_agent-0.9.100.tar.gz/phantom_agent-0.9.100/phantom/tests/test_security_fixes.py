"""Security fix verification tests — attack your own fixes.

Run with: python -m pytest phantom/tests/test_security_fixes.py -v
"""
import os
import re
import sys
import threading
import time
from pathlib import Path

import pytest

PHANTOM_SRC = Path(__file__).parent.parent


class TestC1SkillInjection:
    """C-1: Skill descriptions prompt injection."""

    def test_sanitize_removes_jinja2(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.skills import _sanitize_skill_content, _INJECTION_REPLACEMENT

        cases = [
            ("{{INJECT}}", _INJECTION_REPLACEMENT),
            ("{% if admin %}EVIL{% endif %}", _INJECTION_REPLACEMENT),
            ("<script>alert(1)</script>", _INJECTION_REPLACEMENT),
            ("onerror=alert(1)", _INJECTION_REPLACEMENT),
            ("javascript:alert(1)", _INJECTION_REPLACEMENT),
            ("Normal skill content is safe", "Normal skill content is safe"),
            ("Click [[here]] for details", "Click [[here]] for details"),
        ]
        for input_text, expected in cases:
            result = _sanitize_skill_content(input_text)
            assert _INJECTION_REPLACEMENT in result or result == expected, \
                f"Input: {input_text!r} → {result!r} (expected {_INJECTION_REPLACEMENT!r} or {expected!r})"

    def test_sanitize_preserves_normal_content(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.skills import _sanitize_skill_content
        normal = "# SQL Injection Testing\n\nThis skill tests for SQL injection vulnerabilities."
        result = _sanitize_skill_content(normal)
        assert "SQL Injection Testing" in result
        assert "<script>" not in result.lower()
        assert "{{" not in result


class TestC2PythonASTBypass:
    """C-2: AST bypass in python_action."""

    def test_blocks_dangerous_imports(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.tools.python.python_instance import _validate_code_safety
        blocked = [
            "import os",
            "from sys import path",
            "import subprocess",
            "import pty",
        ]
        for code in blocked:
            err = _validate_code_safety(code)
            assert err is not None, f"Should block: {code}"

    def test_blocks_dangerous_calls(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.tools.python.python_instance import _validate_code_safety
        blocked = [
            "eval('1+1')",
            "exec('import os')",
            "compile('x','','exec')",
            "__import__('os')",
            "open('/etc/passwd')",
        ]
        for code in blocked:
            err = _validate_code_safety(code)
            assert err is not None, f"Should block: {code}"

    def test_blocks_attribute_chains(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.tools.python.python_instance import _validate_code_safety
        blocked = [
            "getattr(object, 'system')",
            "setattr(object, 'x', 1)",
            "hasattr(object, 'x')",
            "().__class__.__bases__[0].__subclasses__()",
            "object.__class__.__bases__[0].__subclasses__()",
            "{}.__class__.__bases__[0].__subclasses__",
        ]
        for code in blocked:
            err = _validate_code_safety(code)
            assert err is not None, f"Should block: {code}"

    def test_allows_safe_code(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.tools.python.python_instance import _validate_code_safety
        safe = [
            "x = 1 + 2",
            "print('hello')",
            "result = [i*2 for i in range(10)]",
            "def foo(): return 42",
            "import json; json.loads('{}')",
        ]
        for code in safe:
            err = _validate_code_safety(code)
            assert err is None, f"Should allow: {code} → {err}"

    def test_blocks_magic_commands(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.tools.python.python_instance import _validate_code_safety
        blocked = ["%pip install requests", "x = 1\n%ls"]
        for code in blocked:
            err = _validate_code_safety(code)
            assert err is not None, f"Magic commands should be blocked: {code}"


class TestC3TerminalQuarantine:
    """C-3: Terminal metacharacter blocklist bypass."""

    def test_all_metacharacters_blocked(self):
        from phantom.tools.terminal.terminal_session import TerminalSession
        qs = TerminalSession._QUARANTINE_METACHARACTERS
        must_block = list(";&$`#!\n\r%")
        for char in must_block:
            assert char in qs, f"'{char}' must be in quarantine set"


class TestH1AuditSanitizer:
    """H-1: Audit log unsanitized data."""

    def test_sanitizes_tool_args_credentials(self):
        from phantom.logging.audit import AuditLogger
        logger = AuditLogger(run_id="test", run_dir=Path("/tmp/test_audit"))
        record = {
            "event_type": "tool.start",
            "payload": {
                "args": {
                    "session_id": "admin_login",
                    "Authorization": "Bearer sk-1234567890abcdef",
                    "cookies": "session=abc123",
                }
            },
        }
        sanitized = logger._sanitize_record(record)
        args = sanitized["payload"]["args"]
        assert "[REDACTED]" in str(args["Authorization"])
        assert "[REDACTED]" in str(args["cookies"])

    def test_sanitizes_llm_messages(self):
        from phantom.logging.audit import AuditLogger
        logger = AuditLogger(run_id="test", run_dir=Path("/tmp/test_audit"))
        record = {
            "event_type": "llm.request",
            "payload": {
                "messages": [
                    {"role": "user", "content": "api_key=sk-abcdefgh123"},
                ]
            },
        }
        sanitized = logger._sanitize_record(record)
        msgs = sanitized["payload"]["messages"]
        assert "[REDACTED]" in str(msgs)


class TestH2HMACKeyDerivation:
    """H-2: Weak HMAC key on Windows."""

    def test_uses_secrets_module(self):
        from phantom.checkpoint import checkpoint
        key = checkpoint._get_hmac_key()
        assert isinstance(key, bytes)
        assert len(key) >= 32


class TestH3SessionMasking:
    """H-3: Session tokens in plaintext dict."""

    def test_safe_session_repr_exists(self):
        from phantom.tools.session.session_actions import _safe_session_repr
        session = {
            "session_id": "test",
            "cookies": {"session": "secret123", "csrf": "token456"},
            "headers": {"Authorization": "Bearer tok789"},
            "tokens": {"access": "acc999"},
        }
        safe = _safe_session_repr(session)
        for v in safe["cookies"].values():
            assert "secret123" not in str(v), f"Cookie not masked: {v}"
        for v in safe["headers"].values():
            assert "tok789" not in str(v), f"Header not masked: {v}"


class TestH4SSRFProtection:
    """H-4: SSRF URL validation bypass."""

    def test_blocks_credential_injection(self):
        from phantom.tools.proxy.proxy_manager import _is_ssrf_safe
        assert not _is_ssrf_safe("http://169.254.169.254/latest/meta-data/")
        assert not _is_ssrf_safe("http://user:pass@127.0.0.1/")
        assert not _is_ssrf_safe("http://user:pass@[::ffff:169.254.169.254]/")

    def test_blocks_ipv6_mapped(self):
        from phantom.tools.proxy.proxy_manager import _is_ssrf_safe
        assert not _is_ssrf_safe("http://[::ffff:169.254.169.254]/")

    def test_blocks_unresolvable_hostnames(self):
        from phantom.tools.proxy.proxy_manager import _is_ssrf_safe
        result = _is_ssrf_safe("http://definitelynotarealhostname.local/")
        assert result is False

    def test_allows_safe_urls(self):
        from phantom.tools.proxy.proxy_manager import _is_ssrf_safe
        assert _is_ssrf_safe("http://example.com/")
        assert _is_ssrf_safe("https://api.github.com/")


class TestH5WebSearchAPIKey:
    """H-5: Web search API key exposure."""

    def test_error_messages_no_key_leak(self):
        from phantom.tools.web_search import web_search_actions as ws
        lines = [l.strip() for l in open(ws.__file__) if "Bearer" in l or "api_key" in l]
        for line in lines:
            assert "Bearer" not in line or "api_key" not in line, \
                f"API key may be in error message: {line}"

    def test_result_query_redacted(self):
        sys.path.insert(0, str(PHANTOM_SRC.parent))
        from phantom.tools.web_search import web_search_actions
        assert hasattr(web_search_actions, "httpx")


class TestH6SQLitePermissions:
    """H-6: SQLite world-readable."""

    def test_lock_db_permissions_method_exists(self):
        from phantom.memory.vector_store import VectorMemory
        assert hasattr(VectorMemory, "_lock_db_permissions")

    def test_chmod_called_after_init(self, tmp_path):
        from phantom.memory.vector_store import VectorMemory
        db_path = tmp_path / "test.db"
        vm = VectorMemory(db_path=str(db_path))
        assert db_path.exists()
        if os.name != "nt":
            mode = db_path.stat().st_mode & 0o777
            assert mode == 0o600, f"DB should be 0600, got {oct(mode)}"


class TestH7PathTraversal:
    """H-7: Path traversal in file_edit."""

    def test_validate_blocks_escape(self):
        from phantom.tools.file_edit.file_edit_actions import _validate_workspace_path
        for bad in ["../../etc/passwd", "/etc/passwd", "foo/../../../etc/passwd"]:
            with pytest.raises(ValueError, match="outside /workspace|traversal"):
                _validate_workspace_path(bad)

    def test_validate_allows_workspace_paths(self):
        from phantom.tools.file_edit.file_edit_actions import _validate_workspace_path
        result = _validate_workspace_path("/workspace/src/app.py")
        assert "workspace" in result.lower()

    def test_search_files_max_count(self):
        from phantom.tools.file_edit import file_edit_actions
        src = file_edit_actions.__file__
        with open(src) as f:
            content = f.read()
        assert "max-count" in content or "max_count" in content, \
            "rg should use --max-count to prevent DoS"


class TestM1RateLimiter:
    """M-1: No LLM rate limiting."""

    def test_rate_limiter_class_exists(self):
        from phantom.llm.llm import _TokenRateLimiter
        limiter = _TokenRateLimiter()
        for i in range(10):
            assert limiter.check_and_record("gpt-4o"), f"Should allow call {i}"

    def test_rate_limiter_enforced(self):
        os.environ["PHANTOM_LLM_RATE_LIMIT_PER_MINUTE"] = "5"
        from phantom.llm.llm import _TokenRateLimiter
        limiter = _TokenRateLimiter()
        allowed = 0
        for i in range(20):
            if limiter.check_and_record("gpt-4o-mini"):
                allowed += 1
        assert allowed <= 5, f"Rate limit not enforced: {allowed} allowed"


class TestM4TUIInternalPaths:
    """M-4: TUI leaks internal paths."""

    def test_strip_internal_paths_exists(self):
        from phantom.interface.utils import _strip_internal_paths
        cases = [
            ("/workspace/src/app.py", "/workspace"),
            ("Model: phantom/gpt-4o", "phantom/"),
        ]
        for input_text, pattern in cases:
            result = _strip_internal_paths(input_text)
            assert pattern not in result or "[REDACTED]" in result or "workspace" in result.lower()

    def test_strip_removes_workspace_paths(self):
        from phantom.interface.utils import _strip_internal_paths
        text = "/workspace/myapp/routes/api.py contains the bug"
        result = _strip_internal_paths(text)
        assert "/workspace/" not in result, f"Workspace path leaked: {result}"


class TestM5ConfigPermissions:
    """M-5: Config file permissions not enforced."""

    def test_auto_fix_on_load(self, tmp_path, monkeypatch):
        from phantom.config.config import Config
        monkeypatch.setattr(Config, "_config_file_override", tmp_path / "cli-config.json")
        cfg_file = tmp_path / "cli-config.json"
        import json, stat
        cfg_file.write_text(json.dumps({"env": {}}))
        if os.name != "nt":
            cfg_file.chmod(0o644)
            mode_before = cfg_file.stat().st_mode & 0o777
            Config.load()
            mode_after = cfg_file.stat().st_mode & 0o777
            assert mode_after == 0o600, \
                f"Config chmod failed: {oct(mode_before)} → {oct(mode_after)}"


class TestM6Scrubadub:
    """M-6: Scrubadub placeholder collision."""

    def test_no_placeholder_pattern_in_module(self):
        from phantom.telemetry import utils
        assert not hasattr(utils, "_SCRUBADUB_PLACEHOLDER_PATTERN")

    def test_sanitizer_redacts_key_hint_sensitive(self):
        from phantom.telemetry.utils import TelemetrySanitizer
        san = TelemetrySanitizer()
        result = san.sanitize({"Authorization": "Bearer sk-1234567890abcdef"})
        assert "[REDACTED]" in str(result), f"Sanitizer should redact, got: {result}"

    def test_scrubber_initializes_without_replace_with_kwarg(self):
        from scrubadub import Scrubber
        from phantom.telemetry.utils import _SecretTokenDetector
        Scrubber(detector_list=[_SecretTokenDetector])


class TestM7SARIFValidation:
    """M-7: SARIF formatter no input validation."""

    def test_cvss_clamped_to_range(self):
        from phantom.interface.formatters.sarif_formatter import _safe_cvss
        assert _safe_cvss(15.0) is None
        assert _safe_cvss(-1.0) is None
        assert _safe_cvss(8.5) == 8.5
        assert _safe_cvss("invalid") is None

    def test_uri_strips_control_chars(self):
        from phantom.interface.formatters.sarif_formatter import _safe_uri
        assert "\x00" not in _safe_uri("http://example.com\x00evil")
        assert "\x1f" not in _safe_uri("http://evil\x1f.com")

    def test_invalid_severity_defaults_to_info(self):
        from phantom.interface.formatters.sarif_formatter import (
            SARIFFormatter, _SEV_MAP
        )
        sf = SARIFFormatter()
        result = sf.format({
            "vulnerabilities": [
                {"title": "Test", "severity": "invalid_severity", "description": "x"}
            ]
        })
        level = result["runs"][0]["results"][0]["level"]
        assert level == _SEV_MAP["info"][0]


class TestL3TerminalExceptions:
    """L-3: Terminal thread exceptions silently swallowed."""

    def test_cleanup_handles_exceptions_gracefully(self):
        from phantom.tools.terminal.terminal_manager import TerminalManager
        import logging
        tm = TerminalManager()
        tm.cleanup_dead_sessions()


class TestL5ScreenshotCleanup:
    """L-5: Screenshots persisted to disk."""

    def test_auto_cleanup_helper_exists(self):
        from phantom.tools.executor import _cleanup_screenshot_artifacts
        assert callable(_cleanup_screenshot_artifacts)


class TestL7ReflectorAsync:
    """L-7: Reflector coroutine not awaited."""

    def test_reflector_uses_await(self):
        from phantom.llm.pentager import reflector
        src = reflector.__file__
        with open(src) as f:
            content = f.read()
        assert "await litellm.acompletion" in content, \
            "Reflector must await litellm.acompletion"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])


# ═══════════════════════════════════════════════════════════════════
# NEW VULNERABILITY TESTS (P1–P7) — Comprehensive Audit Round 2
# ═══════════════════════════════════════════════════════════════════


class TestP1UserInstructionInjection:
    """P1 (HIGH): User instructions injected into agent task without sanitization.

    The scan config's user_instructions field is appended directly to the
    task_description string that becomes the agent's initial user message.
    Without sanitization, Jinja2 templates, script tags, EL expressions, etc.
    could be embedded.
    """

    def test_sanitize_imported_in_phantom_agent(self):
        from phantom.agents.PhantomAgent.phantom_agent import PhantomAgent
        import inspect
        src = inspect.getsource(PhantomAgent)
        assert "_sanitize_skill_content" in src, \
            "phantom_agent.py must import _sanitize_skill_content"

    def test_user_instructions_sanitized(self):
        from phantom.skills import _sanitize_skill_content

        payloads = [
            "{{ .* }}",
            "{% raw %}{{ flag }}{% endraw %}",
            "<script>alert(1)</script>",
            "${env.FLAG}",
            "#{system('id')}",
            "<style>* { color: red }</style>",
            "data:text/html,<h1>phishing</h1>",
        ]
        for payload in payloads:
            result = _sanitize_skill_content(payload)
            assert "{{" not in result, f"Jinja2 open not stripped: {payload!r} -> {result!r}"
            assert "{%" not in result, f"Jinja2 tag not stripped: {payload!r} -> {result!r}"
            assert "<script" not in result.lower(), f"Script tag not stripped: {payload!r} -> {result!r}"
            assert "${" not in result, f"EL expression not stripped: {payload!r} -> {result!r}"
            assert "#{*" not in result, f"Hash expression not stripped: {payload!r} -> {result!r}"
            assert "<style" not in result.lower(), f"Style tag not stripped: {payload!r} -> {result!r}"

    def test_task_description_uses_sanitized_instructions(self):
        import os
        from phantom.agents.state import AgentState
        from phantom.agents.PhantomAgent.phantom_agent import PhantomAgent
        import unittest.mock

        os.environ.setdefault("PHANTOM_LLM", "gpt-4o-mini")
        state = AgentState(
            agent_id="test-agent",
            agent_name="TestAgent",
            parent_id=None,
            task="",
        )
        agent = PhantomAgent(config={"state": state})

        scan_config = {
            "user_instructions": "{{ 7*7 }}<script>alert('xss')</script>",
            "targets": [],
        }
        with unittest.mock.patch.object(agent, "agent_loop", return_value={}) as mock_loop:
            import asyncio
            asyncio.run(agent.execute_scan(scan_config))

        args, kwargs = mock_loop.call_args
        task_arg = kwargs.get("task") if kwargs else (args[0] if args else None)
        assert task_arg is not None, f"agent_loop was not called correctly: args={args}, kwargs={kwargs}"
        assert "{{" not in task_arg, \
            f"Jinja2 template leaked into task: {task_arg!r}"
        assert "<script" not in task_arg.lower(), \
            f"Script tag leaked into task: {task_arg!r}"


class TestP2HtmlInjectionInReports:
    """P2 (MEDIUM): Severity field in HTML report not escaped.

    The sev variable was injected directly into HTML without escaping.
    An attacker-controlled severity value could break out of the span
    badge element and inject arbitrary HTML.
    """

    def test_severity_escaped_in_html_report(self):
        from phantom.interface.cli_app import _render_html_report

        data = {
            "target": "http://test.example.com",
            "vulnerabilities": [
                {
                    "name": "Test Vuln",
                    "severity": '"><script>alert(1)</script><span class="',
                    "endpoint": "http://test.example.com/api",
                    "description": "Test description",
                    "payload": "",
                    "remediation": "",
                }
            ],
        }
        html = _render_html_report("test-run", data)
        assert "<script>" not in html.lower(), \
            "Script tag found in HTML report output"
        assert '"><script>' not in html, \
            "Unescaped severity broke out of badge span"

    def test_severity_null_handled(self):
        from phantom.interface.cli_app import _render_html_report

        data = {
            "target": "http://test.example.com",
            "vulnerabilities": [
                {
                    "name": "Test Vuln",
                    "severity": None,
                    "endpoint": "/api",
                    "description": "Test",
                    "payload": "",
                    "remediation": "",
                }
            ],
        }
        html = _render_html_report("test-run", data)
        assert "AttributeError" not in html, "Null severity must not raise AttributeError"
        assert "</div>" in html or "finding" in html, "Report must render even with null severity"

    def test_severity_int_type_handled(self):
        from phantom.interface.cli_app import _render_html_report

        data = {
            "target": "http://test.example.com",
            "vulnerabilities": [
                {
                    "name": "Test Vuln",
                    "severity": 5,
                    "endpoint": "/api",
                    "description": "Test",
                    "payload": "",
                    "remediation": "",
                }
            ],
        }
        html = _render_html_report("test-run", data)
        assert "AttributeError" not in html, "Integer severity must not raise AttributeError"


class TestP3SeveritySortingKeyError:
    """P3 (MEDIUM): Severity sorting crashes on non-string severity values.

    sev_order.get(str(v.get("severity", "info")).lower(), 5) would crash
    with AttributeError if severity is an integer or other non-string type,
    because int.lower() doesn't exist.
    """

    def test_markdown_report_non_string_severity(self):
        from phantom.interface.cli_app import _render_markdown_report

        data = {
            "target": "http://test.example.com",
            "vulnerabilities": [
                {"name": "Vuln 1", "severity": 5, "endpoint": "/a", "description": "D", "payload": "", "remediation": ""},
                {"name": "Vuln 2", "severity": ["high"], "endpoint": "/b", "description": "D", "payload": "", "remediation": ""},
                {"name": "Vuln 3", "severity": None, "endpoint": "/c", "description": "D", "payload": "", "remediation": ""},
                {"name": "Vuln 4", "severity": {"level": "high"}, "endpoint": "/d", "description": "D", "payload": "", "remediation": ""},
                {"name": "Vuln 5", "severity": "CRITICAL", "endpoint": "/e", "description": "D", "payload": "", "remediation": ""},
            ],
        }
        md = _render_markdown_report("test-run", data)
        assert "Vuln 1" in md
        assert "Vuln 5" in md

    def test_html_report_non_string_severity(self):
        from phantom.interface.cli_app import _render_html_report

        data = {
            "target": "http://test.example.com",
            "vulnerabilities": [
                {"name": "V1", "severity": 99, "endpoint": "/x", "description": "D", "payload": "", "remediation": ""},
                {"name": "V2", "severity": [], "endpoint": "/y", "description": "D", "payload": "", "remediation": ""},
                {"name": "V3", "severity": None, "endpoint": "/z", "description": "D", "payload": "", "remediation": ""},
            ],
        }
        html = _render_html_report("test-run", data)
        assert "V1" in html
        assert "V2" in html
        assert "V3" in html


class TestP4PoCResultInjection:
    """P4 (MEDIUM): PoC script output stored in tracer without sanitization.

    The background replay task captures PoC script output and stores the
    replay_status (PASSED/FAILED/SKIPPED) in the tracer.
    The actual output is only used for status determination and not persisted.
    No direct injection path found, but defense-in-depth sanitization on
    replay_status ensures no future injection vectors emerge.
    """

    def test_replay_status_uses_stripped_values_only(self):
        from phantom.tools.reporting.reporting_actions import (
            _background_tasks,
        )
        assert isinstance(_background_tasks, set)

    def test_replay_out_not_persisted(self):
        import ast
        src = (PHANTOM_SRC / "tools" / "reporting" / "reporting_actions.py").read_text()
        tree = ast.parse(src)
        update_calls = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                fn = node.func
                if isinstance(fn, ast.Attribute) and fn.attr == "update_vulnerability_replay":
                    update_calls.append(ast.unparse(node))

        for call in update_calls:
            assert "replay_out" not in call, \
                f"replay_out (raw PoC output) must not be passed to update_vulnerability_replay: {call}"


class TestP5ToolNameValidation:
    """P5 (LOW): Tool name stripping doesn't validate resulting name.

    executor.py strips module prefixes (e.g., "tools.terminal" from tool names)
    but only uses the stripped name if it matches a registered tool.
    If it doesn't match, the original name is used and validate_tool_availability
    catches it as invalid. No allowlist bypass.
    """

    def test_stripped_name_returns_error_on_unknown_tool(self):
        from phantom.tools.executor import validate_tool_availability

        is_valid, error_msg = validate_tool_availability("nonexistent_tool.execute")
        assert not is_valid, "Unknown tool name must be rejected"
        assert error_msg and len(error_msg) > 0

    def test_stripped_name_no_rce(self):
        from phantom.tools.executor import validate_tool_availability

        dangerous = [
            "os.system",
            "subprocess.popen",
            "__import__('os').system",
            "eval",
            "exec",
        ]
        for name in dangerous:
            is_valid, error_msg = validate_tool_availability(name)
            assert not is_valid, \
                f"Dangerous tool name must be rejected: {name!r} -> {error_msg!r}"

    def test_module_prefix_stripping_uses_registered_tool_check(self):
        src = (PHANTOM_SRC / "tools" / "executor.py").read_text()
        func_start = src.find("def execute_tool_with_validation")
        func_end = src.find("\ndef ", func_start + 1)
        func_body = src[func_start:func_end]

        has_strip = '.split(".")' in func_body or ".split('.')" in func_body
        has_check = "get_tool_names()" in func_body
        has_validate = "validate_tool_availability" in func_body

        assert has_strip, "execute_tool_with_validation must strip module prefix using .split('.')"
        assert has_check, "execute_tool_with_validation must check stripped name against registered tools"
        assert has_validate, "execute_tool_with_validation must validate after stripping"


class TestP6HtmlInjectionInMarkdown:
    """P6 (LOW): Markdown report renderer may output unsanitized HTML.

    The markdown renderer uses backtick code spans for structured data.
    While markdown itself escapes content within code fences, an attacker
    controlling vulnerability data could craft payloads that break out of
    the fenced code block when rendered by a vulnerable markdown viewer.
    """

    def test_payload_in_code_fence_in_markdown(self):
        from phantom.interface.cli_app import _render_markdown_report

        xss_payload = '<script>alert(1)</script>'
        data = {
            "target": "http://test.example.com",
            "vulnerabilities": [
                {
                    "name": "XSS",
                    "severity": "high",
                    "endpoint": "/api",
                    "description": "Test",
                    "payload": xss_payload,
                    "remediation": "",
                }
            ],
        }
        md = _render_markdown_report("test-run", data)
        assert xss_payload in md, "Payload must appear in report"
        lines = md.split("\n")
        in_code_fence = False
        for line in lines:
            if "```" in line:
                in_code_fence = not in_code_fence
            if in_code_fence and xss_payload in line:
                break
            if not in_code_fence and xss_payload in line:
                pytest.fail(f"Payload found OUTSIDE code fence: {line!r}")


class TestP7GlobTraversal:
    """P7 (LOW): Report export uses recursive glob, could traverse symlinks.

    cli_app.py used runs_dir.glob("**/*.json") which recursively walks
    the entire directory tree, potentially following symlinks outside
    the runs directory.
    """

    def test_export_glob_is_non_recursive(self):
        src = (PHANTOM_SRC / "interface" / "cli_app.py").read_text()
        recursive_glob_pattern = re.compile(r'\.glob\(\s*["\']\*\*.*?\.json["\']')
        matches = recursive_glob_pattern.findall(src)
        assert not matches, \
            f"Recursive glob (**) pattern found in glob() calls — use non-recursive glob: {matches}"

