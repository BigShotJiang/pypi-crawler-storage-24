"""
COMPREHENSIVE END-TO-END VERIFICATION - FINAL ATTACK
Tests the ENTIRE system working together.
"""

import os
import sys
import asyncio
import tempfile
import time
import inspect
from pathlib import Path

# Set ALL environment variables
os.environ["PHANTOM_USE_CONDENSED_PROMPT"] = "true"
os.environ["PHANTOM_USE_CHAIN_SUMMARIZER"] = "true"
os.environ["PHANTOM_USE_REFLECTOR"] = "true"
os.environ["PHANTOM_USE_AUTO_SUMMARIZE"] = "true"
os.environ["PHANTOM_USE_TOOL_DELEGATION"] = "true"

print("=" * 80)
print("COMPREHENSIVE END-TO-END VERIFICATION - FINAL ATTACK")
print("=" * 80)
print("\nEnvironment Variables Set:")
for key in ["PHANTOM_USE_CONDENSED_PROMPT", "PHANTOM_USE_CHAIN_SUMMARIZER", 
            "PHANTOM_USE_REFLECTOR", "PHANTOM_USE_AUTO_SUMMARIZE", "PHANTOM_USE_TOOL_DELEGATION"]:
    print(f"  {key}={os.environ.get(key)}")


def test_1_imports():
    """TEST 1: All critical imports work"""
    print("\n" + "=" * 80)
    print("TEST 1: CRITICAL IMPORTS")
    print("=" * 80)
    
    errors = []
    
    # Core LLM imports
    try:
        from phantom.llm.llm import LLM, LLMConfig, LLMResponse
        print("  [OK] phantom.llm.llm")
    except Exception as e:
        errors.append(f"phantom.llm.llm: {e}")
        print(f"  [FAIL] phantom.llm.llm: {e}")
    
    try:
        from phantom.llm.memory_compressor import MemoryCompressor
        print("  [OK] phantom.llm.memory_compressor")
    except Exception as e:
        errors.append(f"phantom.llm.memory_compressor: {e}")
        print(f"  [FAIL] phantom.llm.memory_compressor: {e}")
    
    # Pentager imports
    try:
        from phantom.llm.pentager import ChainSummarizer, ChainAST, create_chain_summarizer
        print("  [OK] phantom.llm.pentager (ChainSummarizer, ChainAST)")
    except Exception as e:
        errors.append(f"phantom.llm.pentager: {e}")
        print(f"  [FAIL] phantom.llm.pentager: {e}")
    
    try:
        from phantom.llm.pentager.reflector import Reflector, get_reflector
        print("  [OK] phantom.llm.pentager.reflector")
    except Exception as e:
        errors.append(f"phantom.llm.pentager.reflector: {e}")
        print(f"  [FAIL] phantom.llm.pentager.reflector: {e}")
    
    # Memory imports
    try:
        from phantom.memory.vector_store import VectorMemory, get_memory
        print("  [OK] phantom.memory.vector_store")
    except Exception as e:
        errors.append(f"phantom.memory.vector_store: {e}")
        print(f"  [FAIL] phantom.memory.vector_store: {e}")
    
    # Agent imports
    try:
        from phantom.agents.base_agent import BaseAgent
        print("  [OK] phantom.agents.base_agent")
    except Exception as e:
        errors.append(f"phantom.agents.base_agent: {e}")
        print(f"  [FAIL] phantom.agents.base_agent: {e}")
    
    try:
        from phantom.agents.state import AgentState
        print("  [OK] phantom.agents.state")
    except Exception as e:
        errors.append(f"phantom.agents.state: {e}")
        print(f"  [FAIL] phantom.agents.state: {e}")
    
    try:
        from phantom.agents.hypothesis_ledger import HypothesisLedger
        print("  [OK] phantom.agents.hypothesis_ledger")
    except Exception as e:
        errors.append(f"phantom.agents.hypothesis_ledger: {e}")
        print(f"  [FAIL] phantom.agents.hypothesis_ledger: {e}")
    
    # Tool imports
    try:
        from phantom.tools.executor import execute_tool, process_tool_invocations
        print("  [OK] phantom.tools.executor")
    except Exception as e:
        errors.append(f"phantom.tools.executor: {e}")
        print(f"  [FAIL] phantom.tools.executor: {e}")
    
    try:
        from phantom.tools.agents_graph.agents_graph_actions import create_agent
        print("  [OK] phantom.tools.agents_graph.agents_graph_actions")
    except Exception as e:
        errors.append(f"phantom.tools.agents_graph.agents_graph_actions: {e}")
        print(f"  [FAIL] phantom.tools.agents_graph.agents_graph_actions: {e}")
    
    # Config imports
    try:
        from phantom.config import Config
        print("  [OK] phantom.config")
    except Exception as e:
        errors.append(f"phantom.config: {e}")
        print(f"  [FAIL] phantom.config: {e}")
    
    return len(errors) == 0, errors


def test_2_integration_chain():
    """TEST 2: Integration chain - LLM -> Memory -> Agent -> Tools"""
    print("\n" + "=" * 80)
    print("TEST 2: INTEGRATION CHAIN")
    print("=" * 80)
    
    errors = []
    
    # Test 2.1: ChainSummarizer integrates with LLM
    try:
        from phantom.llm.pentager import create_chain_summarizer
        from phantom.llm.llm import LLM, LLMConfig
        
        summarizer = create_chain_summarizer()
        print(f"  [OK] ChainSummarizer created: threshold={summarizer.threshold}")
        
        # Test messages
        messages = [
            {"role": "system", "content": "You are a security agent"},
            {"role": "user", "content": "Test the endpoint"},
        ]
        
        should_sum = summarizer.should_summarize(messages)
        print(f"  [OK] ChainSummarizer.should_summarize() works: {should_sum}")
        
    except Exception as e:
        errors.append(f"ChainSummarizer integration: {e}")
        print(f"  [FAIL] ChainSummarizer integration: {e}")
    
    # Test 2.2: VectorMemory can store findings that persist
    try:
        from phantom.memory.vector_store import VectorMemory
        
        with tempfile.TemporaryDirectory() as tmpdir:
            memory = VectorMemory(
                scan_id="integration-test", 
                db_path=os.path.join(tmpdir, "test.db")
            )
            
            # Store a finding
            fid = memory.store("finding", "SQL Injection in /api/login", 
                            metadata={"severity": "high"})
            print(f"  [OK] VectorMemory.store() works: {fid}")
            
            # Retrieve it
            entry = memory.get(fid)
            assert entry is not None
            assert "SQL Injection" in entry.content
            print(f"  [OK] VectorMemory.get() works")
            
            # Search it
            results = memory.search("SQL Injection")
            assert len(results) >= 1
            print(f"  [OK] VectorMemory.search() works: {len(results)} results")
            
    except Exception as e:
        errors.append(f"VectorMemory integration: {e}")
        print(f"  [FAIL] VectorMemory integration: {e}")
    
    # Test 2.3: Reflector integrates with BaseAgent
    try:
        from phantom.llm.pentager.reflector import Reflector
        from phantom.agents.base_agent import BaseAgent
        
        reflector = Reflector()
        print(f"  [OK] Reflector created: model={reflector.reflector_model}")
        
        # Check BaseAgent source has Reflector
        source = inspect.getsource(BaseAgent._process_iteration)
        assert "get_reflector" in source
        print(f"  [OK] Reflector integrated in BaseAgent._process_iteration")
        
    except Exception as e:
        errors.append(f"Reflector integration: {e}")
        print(f"  [FAIL] Reflector integration: {e}")
    
    # Test 2.4: Tool delegation limits in create_agent
    try:
        from phantom.tools.agents_graph.agents_graph_actions import create_agent
        
        source = inspect.getsource(create_agent)
        assert "PHANTOM_USE_TOOL_DELEGATION" in source
        print(f"  [OK] Tool delegation check in create_agent")
        
    except Exception as e:
        errors.append(f"Tool delegation integration: {e}")
        print(f"  [FAIL] Tool delegation integration: {e}")
    
    # Test 2.5: Auto-summarize in executor
    try:
        from phantom.tools.executor import (
            AUTO_SUMMARIZE_THRESHOLD, 
            SUMMARIZE_MODEL,
            _auto_summarize_result
        )
        
        print(f"  [OK] Auto-summarize threshold: {AUTO_SUMMARIZE_THRESHOLD}")
        print(f"  [OK] Summarize model: {SUMMARIZE_MODEL}")
        
        # Test small text (should not summarize)
        small = "small result"
        # Don't call actual API, just verify function exists
        assert asyncio.iscoroutinefunction(_auto_summarize_result)
        print(f"  [OK] _auto_summarize_result is async")
        
    except Exception as e:
        errors.append(f"Auto-summarize integration: {e}")
        print(f"  [FAIL] Auto-summarize integration: {e}")
    
    return len(errors) == 0, errors


def test_3_no_circular_deps():
    """TEST 3: No circular dependencies"""
    print("\n" + "=" * 80)
    print("TEST 3: NO CIRCULAR DEPENDENCIES")
    print("=" * 80)
    
    errors = []
    
    # Try to import in specific order to detect cycles
    try:
        # Phase 1: Core
        from phantom.config import Config
        print("  [OK] Phase 1: Config loaded")
        
        # Phase 2: LLM (depends on Config)
        from phantom.llm.llm import LLM, LLMConfig
        print("  [OK] Phase 2: LLM loaded")
        
        # Phase 3: Memory (standalone)
        from phantom.memory.vector_store import VectorMemory
        print("  [OK] Phase 3: Memory loaded")
        
        # Phase 4: Pentager (depends on LLM components)
        from phantom.llm.pentager import ChainSummarizer
        print("  [OK] Phase 4: Pentager loaded")
        
        # Phase 5: Agent (depends on LLM, Memory)
        from phantom.agents.base_agent import BaseAgent
        print("  [OK] Phase 5: BaseAgent loaded")
        
        # Phase 6: Tools (depends on Agent)
        from phantom.tools.executor import execute_tool
        print("  [OK] Phase 6: Tools loaded")
        
        print("  [OK] No circular dependencies detected")
        
    except Exception as e:
        errors.append(f"Circular dependency: {e}")
        print(f"  [FAIL] Circular dependency: {e}")
    
    return len(errors) == 0, errors


def test_4_env_vars():
    """TEST 4: Environment variables work correctly"""
    print("\n" + "=" * 80)
    print("TEST 4: ENVIRONMENT VARIABLES")
    print("=" * 80)
    
    errors = []
    
    # Test that env vars are read correctly
    test_cases = [
        ("PHANTOM_USE_CONDENSED_PROMPT", "true", "Condensed Prompt"),
        ("PHANTOM_USE_CHAIN_SUMMARIZER", "true", "Chain Summarizer"),
        ("PHANTOM_USE_REFLECTOR", "true", "Reflector"),
        ("PHANTOM_USE_AUTO_SUMMARIZE", "true", "Auto Summarize"),
        ("PHANTOM_USE_TOOL_DELEGATION", "true", "Tool Delegation"),
    ]
    
    for env_var, expected, name in test_cases:
        actual = os.environ.get(env_var, "").lower()
        if actual == expected:
            print(f"  [OK] {name}: {env_var}={actual}")
        else:
            errors.append(f"{name}: {env_var}={actual} (expected {expected})")
            print(f"  [FAIL] {name}: {env_var}={actual} (expected {expected})")
    
    return len(errors) == 0, errors


def test_5_system_prompt():
    """TEST 5: System prompt loads correctly"""
    print("\n" + "=" * 80)
    print("TEST 5: SYSTEM PROMPT")
    print("=" * 80)
    
    errors = []
    
    try:
        from jinja2 import Environment, FileSystemLoader
        from phantom.utils.resource_paths import get_phantom_resource_path
        
        prompt_dir = get_phantom_resource_path("agents", "PhantomAgent")
        env = Environment(
            loader=FileSystemLoader([prompt_dir]),
            autoescape=lambda x: False,
        )
        
        # Load condensed template
        template = env.get_template("system_prompt_condensed.jinja")
        print(f"  [OK] Condensed template loaded")
        
        # Render with minimal context
        def mock_get_skill(name):
            return f"Skill: {name}"
        
        rendered = template.render(
            get_tools_prompt=lambda: "TOOLS: terminal_execute, send_request",
            loaded_skill_names=["test"],
            scan_mode="standard",
            phantom_port_range="",
            is_subagent=False,
            get_skill=mock_get_skill,
        )
        
        # Check critical sections
        critical = [
            "<reporting>",
            "<rules>",
            "<multi_agent>",
            "DELEGATION",
            "create_vulnerability_report",
        ]
        
        for section in critical:
            if section in rendered:
                print(f"  [OK] Contains: {section}")
            else:
                errors.append(f"Missing section: {section}")
                print(f"  [FAIL] Missing section: {section}")
        
        print(f"  [RESULT] Condensed prompt size: {len(rendered)} chars, {len(rendered.splitlines())} lines")
        
    except Exception as e:
        errors.append(f"System prompt: {e}")
        print(f"  [FAIL] System prompt: {e}")
    
    return len(errors) == 0, errors


def test_6_agent_state():
    """TEST 6: AgentState works correctly"""
    print("\n" + "=" * 80)
    print("TEST 6: AGENT STATE")
    print("=" * 80)
    
    errors = []
    
    try:
        from phantom.agents.state import AgentState
        
        state = AgentState(
            agent_name="Test Agent",
            max_iterations=100,
        )
        
        # Test basic operations
        state.add_message("user", "Test message")
        assert len(state.messages) > 0
        print(f"  [OK] add_message works: {len(state.messages)} messages")
        
        # Test conversation history
        history = state.get_conversation_history()
        assert len(history) > 0
        print(f"  [OK] get_conversation_history works: {len(history)} messages")
        
        # Test iteration tracking
        state.increment_iteration()
        assert state.iteration == 1
        print(f"  [OK] increment_iteration works: iter={state.iteration}")
        
        # Test max iterations check
        state.max_iterations = 5
        state.iteration = 5
        assert state.should_stop()
        print(f"  [OK] should_stop works")
        
    except Exception as e:
        errors.append(f"AgentState: {e}")
        print(f"  [FAIL] AgentState: {e}")
    
    return len(errors) == 0, errors


def test_7_llm_config():
    """TEST 7: LLM Config works"""
    print("\n" + "=" * 80)
    print("TEST 7: LLM CONFIG")
    print("=" * 80)
    
    errors = []
    
    try:
        from phantom.llm.llm import LLM, LLMConfig
        
        config = LLMConfig(
            model_name="gpt-4o",
            scan_mode="standard",
        )
        
        llm = LLM(config, agent_name="TestAgent")
        
        print(f"  [OK] LLM created: agent_name={llm.agent_name}")
        print(f"  [OK] System prompt loaded: {len(llm.system_prompt)} chars")
        
        # Check if condensed prompt was used
        if os.environ.get("PHANTOM_USE_CONDENSED_PROMPT") == "true":
            assert len(llm.system_prompt) < 10000  # Should be much smaller with condensed
            print(f"  [OK] Condensed prompt enabled: {len(llm.system_prompt)} chars")
        
    except Exception as e:
        errors.append(f"LLM Config: {e}")
        print(f"  [FAIL] LLM Config: {e}")
    
    return len(errors) == 0, errors


def test_8_vector_memory_full():
    """TEST 8: Full VectorMemory workflow"""
    print("\n" + "=" * 80)
    print("TEST 8: VECTOR MEMORY FULL WORKFLOW")
    print("=" * 80)
    
    errors = []
    
    try:
        from phantom.memory.vector_store import VectorMemory
        
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "full_test.db")
            memory = VectorMemory(scan_id="full-workflow-test", db_path=db_path)
            
            # Simulate a penetration test workflow
            
            # 1. Store reconnaissance results
            memory.store("tool_result", "Nmap scan: 3 open ports (22, 80, 443)",
                       metadata={"tool": "nmap", "duration": "45s"})
            print(f"  [OK] Stored nmap results")
            
            # 2. Store a finding
            fid = memory.store("finding", "SQL Injection in /api/login - parameter 'username'",
                             metadata={"severity": "high", "confidence": "confirmed"})
            print(f"  [OK] Stored SQL injection finding")
            
            # 3. Store a hypothesis
            memory.store("hypothesis", "Testing for SSRF in /api/fetch endpoint",
                        metadata={"status": "testing"})
            print(f"  [OK] Stored hypothesis")
            
            # 4. Store notes
            memory.store("note", "Admin panel found at /admin - weak creds admin:admin",
                        metadata={"priority": "info"})
            print(f"  [OK] Stored note")
            
            # 5. Generate prompt context
            context = memory.to_prompt_context("SQL injection vulnerabilities")
            assert len(context) > 0
            print(f"  [OK] Generated prompt context: {len(context)} chars")
            
            # 6. Count memories
            count = memory.count()
            assert count == 4
            print(f"  [OK] Memory count: {count}")
            
            # 7. Delete a memory (delete the note, keep the finding)
            all_before = memory.search("test", scan_id=None)
            for m in all_before:
                if m.doc_type == "note":
                    deleted = memory.delete(m.id)
                    break
            else:
                # No note found, delete anything that's not the finding
                for m in all_before:
                    if m.id != fid:
                        deleted = memory.delete(m.id)
                        break
            
            count_after = memory.count()
            print(f"  [OK] Delete works: {count_after} memories remain")
            
            # 8. Search for specific finding (should still exist)
            results = memory.search("SQL injection")
            assert len(results) >= 1, f"Expected finding to exist, got {len(results)}"
            assert results[0].doc_type == "finding"
            print(f"  [OK] Found SQL injection after delete: {results[0].content[:50]}...")
            
            # 9. Filter by type (should still work)
            findings = memory.search("SQL", doc_type="finding")
            assert len(findings) == 1, f"Expected 1 finding, got {len(findings)}"
            print(f"  [OK] Type filter works after delete")
            
            print(f"  [OK] Full VectorMemory workflow completed")
            
    except Exception as e:
        errors.append(f"VectorMemory workflow: {e}")
        print(f"  [FAIL] VectorMemory workflow: {e}")
        import traceback
        traceback.print_exc()
    
    return len(errors) == 0, errors


def test_9_chain_ast_full():
    """TEST 9: Full ChainAST workflow"""
    print("\n" + "=" * 80)
    print("TEST 9: CHAIN AST FULL WORKFLOW")
    print("=" * 80)
    
    errors = []
    
    try:
        from phantom.llm.pentager import ChainAST, ChainSummarizer, create_chain_summarizer
        
        # Simulate a conversation with 50+ messages
        messages = [
            {"role": "system", "content": "You are Phantom, a security agent."},
        ]
        
        # Add 60 realistic conversation turns
        for i in range(60):
            messages.append({
                "role": "user",
                "content": f"<tool_result>Tool output {i}: Found interesting data...</tool_result>"
            })
            messages.append({
                "role": "assistant",
                "content": f"<function=send_request><parameter=url>https://target.com/api/{i}</parameter></function>"
            })
        
        print(f"  [OK] Created {len(messages)} messages")
        
        # Parse into ChainAST
        ast = ChainAST.parse(messages)
        print(f"  [OK] Parsed into {len(ast.sections)} sections")
        
        # Test summarization
        summarizer = create_chain_summarizer()
        should_sum = summarizer.should_summarize(messages)
        print(f"  [OK] should_summarize: {should_sum}")
        
        if should_sum:
            compressed = summarizer.summarize(messages)
            print(f"  [OK] Summarized: {len(messages)} -> {len(compressed)} messages")
            
            # Verify compression
            assert len(compressed) < len(messages)
            
            # Verify system message preserved
            assert any(m.get("role") == "system" for m in compressed)
            print(f"  [OK] System message preserved")
        
        # Test empty messages
        empty_ast = ChainAST.parse([])
        assert empty_ast.sections == []
        print(f"  [OK] Empty messages handled")
        
        # Test to_messages round-trip
        ast = ChainAST.parse(messages)
        roundtrip = ast.to_messages()
        # Should preserve the structure (system + user + assistant pairs)
        assert len(roundtrip) >= 2  # at least system + user
        print(f"  [OK] to_messages round-trip works: {len(messages)} -> {len(roundtrip)}")
        
        print(f"  [OK] Full ChainAST workflow completed")
        
    except Exception as e:
        errors.append(f"ChainAST workflow: {e}")
        print(f"  [FAIL] ChainAST workflow: {e}")
        import traceback
        traceback.print_exc()
    
    return len(errors) == 0, errors


def test_10_code_quality():
    """TEST 10: Code quality checks"""
    print("\n" + "=" * 80)
    print("TEST 10: CODE QUALITY")
    print("=" * 80)
    
    errors = []
    
    # Check that critical functions exist
    checks = [
        ("phantom.llm.llm", "LLM"),
        ("phantom.llm.pentager.chain_summarizer", "ChainSummarizer"),
        ("phantom.llm.pentager.reflector", "Reflector"),
        ("phantom.memory.vector_store", "VectorMemory"),
        ("phantom.agents.base_agent", "BaseAgent"),
        ("phantom.tools.executor", "execute_tool"),
    ]
    
    for module_name, name in checks:
        try:
            __import__(module_name)
            print(f"  [OK] {name} exists")
        except Exception as e:
            errors.append(f"{name} import failed: {e}")
            print(f"  [FAIL] {name} import failed: {e}")
    
    # Check syntax of all modified files
    files_to_check = [
        "phantom/phantom/llm/llm.py",
        "phantom/phantom/agents/base_agent.py",
        "phantom/phantom/tools/executor.py",
        "phantom/phantom/tools/agents_graph/agents_graph_actions.py",
        "phantom/phantom/memory/vector_store.py",
        "phantom/phantom/llm/pentager/chain_summarizer.py",
        "phantom/phantom/llm/pentager/reflector.py",
    ]
    
    for filepath in files_to_check:
        try:
            full_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), 
                                    filepath.replace("/", os.sep))
            if os.path.exists(full_path):
                import py_compile
                py_compile.compile(full_path, doraise=True)
                print(f"  [OK] Syntax: {filepath}")
            else:
                print(f"  [WARN] Not found: {filepath}")
        except Exception as e:
            errors.append(f"Syntax error in {filepath}: {e}")
            print(f"  [FAIL] Syntax error in {filepath}: {e}")
    
    return len(errors) == 0, errors


def main():
    """Run all tests"""
    print("\n")
    print("=" * 80)
    print("STARTING COMPREHENSIVE VERIFICATION")
    print("=" * 80)
    
    results = []
    
    tests = [
        ("1. Critical Imports", test_1_imports),
        ("2. Integration Chain", test_2_integration_chain),
        ("3. No Circular Dependencies", test_3_no_circular_deps),
        ("4. Environment Variables", test_4_env_vars),
        ("5. System Prompt", test_5_system_prompt),
        ("6. Agent State", test_6_agent_state),
        ("7. LLM Config", test_7_llm_config),
        ("8. VectorMemory Full Workflow", test_8_vector_memory_full),
        ("9. ChainAST Full Workflow", test_9_chain_ast_full),
        ("10. Code Quality", test_10_code_quality),
    ]
    
    all_passed = True
    for name, test_func in tests:
        try:
            passed, errors = test_func()
            results.append((name, passed, errors))
            if not passed:
                all_passed = False
        except Exception as e:
            print(f"\n  [FATAL ERROR] {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False, [str(e)]))
            all_passed = False
    
    # Final Summary
    print("\n" + "=" * 80)
    print("FINAL SUMMARY")
    print("=" * 80)
    
    passed_count = 0
    failed_count = 0
    
    for name, passed, errors in results:
        status = "[PASS]" if passed else "[FAIL]"
        print(f"\n{status} {name}")
        if not passed:
            failed_count += 1
            for error in errors:
                print(f"       - {error}")
        else:
            passed_count += 1
    
    print("\n" + "=" * 80)
    print(f"TOTAL: {passed_count} passed, {failed_count} failed out of {len(results)} tests")
    print("=" * 80)
    
    if all_passed:
        print("\n*** ALL TESTS PASSED - SYSTEM VERIFIED ***")
        return 0
    else:
        print("\n*** SOME TESTS FAILED - REVIEW OUTPUT ABOVE ***")
        return 1


if __name__ == "__main__":
    sys.exit(main())
