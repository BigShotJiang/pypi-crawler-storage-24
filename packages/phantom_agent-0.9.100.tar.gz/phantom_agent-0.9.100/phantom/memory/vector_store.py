"""
Vector Memory Store - Pentager-style persistent tool result storage.

Import from: Pentager's pgvector-backed memory tool

KEY DIFFERENCE from HypothesisLedger:
- HypothesisLedger: In-memory only, wiped on restart
- VectorMemory: Persistent storage with semantic search

This module provides:
- Persistent storage of tool results and findings
- Semantic search across stored memories
- Automatic cleanup of old entries
"""
import json
import logging
import os
import sqlite3
import stat
import threading
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from phantom.config.config import Config


logger = logging.getLogger(__name__)

# Default thresholds
MEMORY_SEARCH_THRESHOLD = 0.2
MEMORY_SEARCH_RESULT_LIMIT = 3
MEMORY_TTL_DAYS = 30
MEMORY_TABLE = "vector_memory"


@dataclass
class MemoryEntry:
    """A stored memory entry."""
    id: str
    content: str
    doc_type: str  # "finding", "tool_result", "hypothesis", "note"
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    agent_id: str | None = None
    scan_id: str | None = None
    tags: list[str] = field(default_factory=list)


class VectorMemory:
    """
    Pentager-style persistent vector memory store.
    
    KEY FEATURES:
    - SQLite-backed persistent storage
    - Semantic search via keyword matching
    - TTL-based automatic cleanup
    - Thread-safe operations
    
    Import from: Pentager's pgvector memory tool
    
    Usage:
        memory = VectorMemory(scan_id="scan-123")
        
        # Store a finding
        memory.store("finding", "SQL injection detected in /api/login", 
                    metadata={"severity": "high", "url": "..."})
        
        # Search for related memories
        results = memory.search("SQL injection authentication")
    """
    
    def __init__(
        self,
        scan_id: str | None = None,
        agent_id: str | None = None,
        db_path: str | None = None,
        ttl_days: int = MEMORY_TTL_DAYS,
    ):
        self.scan_id = scan_id
        self.agent_id = agent_id
        self.ttl_days = ttl_days
        self._lock = threading.RLock()
        
        # Database path
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = self._get_default_db_path()
        
        self._init_db()
        
        logger.info(
            "VectorMemory initialized: scan_id=%s db=%s",
            scan_id, self.db_path
        )
    
    def _get_default_db_path(self) -> Path:
        """Get default database path."""
        base_dir = Path(Config.get("phantom_memory_dir") or "./phantom_memory")
        base_dir.mkdir(parents=True, exist_ok=True)
        return base_dir / "vector_memory.db"
    
    def _init_db(self) -> None:
        """Initialize SQLite database."""
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {MEMORY_TABLE} (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                doc_type TEXT NOT NULL,
                metadata TEXT,
                agent_id TEXT,
                scan_id TEXT,
                tags TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        
        cursor.execute(f"""
            CREATE INDEX IF NOT EXISTS idx_scan_id ON {MEMORY_TABLE}(scan_id)
        """)
        
        cursor.execute(f"""
            CREATE INDEX IF NOT EXISTS idx_doc_type ON {MEMORY_TABLE}(doc_type)
        """)
        
        cursor.execute(f"""
            CREATE INDEX IF NOT EXISTS idx_created_at ON {MEMORY_TABLE}(created_at)
        """)
        
        conn.commit()
        conn.close()
        
        self._lock_db_permissions()

    def _lock_db_permissions(self) -> None:
        """Restrict DB file to owner-only to prevent world-readable exposure."""
        try:
            self.db_path.chmod(0o600)
            # Also lock the WAL and shm files if they exist
            for suffix in ("-wal", "-shm", ".journal"):
                extra = self.db_path.with_suffix(self.db_path.suffix + suffix)
                if extra.exists():
                    extra.chmod(0o600)
        except OSError:
            pass
    
    def store(
        self,
        doc_type: str,
        content: str,
        metadata: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        memory_id: str | None = None,
    ) -> str:
        """
        Store a new memory entry.
        
        Returns the memory ID.
        """
        with self._lock:
            if memory_id is None:
                memory_id = f"mem-{int(time.time() * 1000)}"
            
            now = datetime.now(UTC).isoformat()
            
            conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            cursor = conn.cursor()
            
            cursor.execute(f"""
                INSERT OR REPLACE INTO {MEMORY_TABLE}
                (id, content, doc_type, metadata, agent_id, scan_id, tags, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                memory_id,
                content,
                doc_type,
                json.dumps(metadata or {}),
                self.agent_id,
                self.scan_id,
                json.dumps(tags or []),
                now,
                now,
            ))
            
            conn.commit()
            conn.close()
            
            logger.debug(
                "Memory stored: id=%s type=%s len=%d",
                memory_id, doc_type, len(content)
            )
            
            return memory_id
    
    def search(
        self,
        query: str,
        doc_type: str | None = None,
        limit: int = MEMORY_SEARCH_RESULT_LIMIT,
        scan_id: str | None = None,
    ) -> list[MemoryEntry]:
        """
        Search for memories matching the query.
        
        Uses simple keyword matching (no LLM embeddings).
        For production, use pgvector with actual embeddings.
        """
        with self._lock:
            conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            cursor = conn.cursor()
            
            # Build query
            query_lower = query.lower()
            query_words = query_lower.split()
            
            # SQL with keyword matching
            sql = f"""
                SELECT id, content, doc_type, metadata, agent_id, scan_id, tags, created_at, updated_at
                FROM {MEMORY_TABLE}
                WHERE 1=1
            """
            params: list[Any] = []
            
            if doc_type:
                sql += " AND doc_type = ?"
                params.append(doc_type)
            
            # Filter by scan_id only if explicitly provided
            # If scan_id=None, don't filter by scan_id (return all)
            if scan_id is not None:
                sql += " AND scan_id = ?"
                params.append(scan_id)
            elif self.scan_id is not None:
                sql += " AND scan_id = ?"
                params.append(self.scan_id)
            
            # Filter by TTL
            if self.ttl_days > 0:
                cutoff = datetime.now(UTC)
                from datetime import timedelta
                cutoff = cutoff - timedelta(days=self.ttl_days)
                sql += " AND created_at >= ?"
                params.append(cutoff.isoformat())
            
            # Use higher limit to get more candidates before scoring
            # The LIMIT is applied BEFORE scoring, so we need enough candidates
            sql += " ORDER BY updated_at DESC LIMIT ?"
            params.append(limit * 10)  # Get more results before scoring filter
            
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            conn.close()
            
            # Score and rank results
            results: list[tuple[float, MemoryEntry]] = []
            for row in rows:
                entry = MemoryEntry(
                    id=row[0],
                    content=row[1],
                    doc_type=row[2],
                    metadata=json.loads(row[3]) if row[3] else {},
                    agent_id=row[4],
                    scan_id=row[5],
                    tags=json.loads(row[6]) if row[6] else [],
                    created_at=row[7],
                    updated_at=row[8],
                )
                
                # Simple keyword scoring
                content_lower = entry.content.lower()
                score = sum(1 for word in query_words if word in content_lower)
                
                # Boost for exact phrase match
                if query_lower in content_lower:
                    score += 10
                
                if score > 0:
                    results.append((score, entry))
            
            # Sort by score descending
            results.sort(key=lambda x: x[0], reverse=True)
            
            return [entry for _, entry in results[:limit]]
    
    def get(self, memory_id: str) -> MemoryEntry | None:
        """Get a specific memory entry by ID."""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            cursor = conn.cursor()
            
            cursor.execute(f"""
                SELECT id, content, doc_type, metadata, agent_id, scan_id, tags, created_at, updated_at
                FROM {MEMORY_TABLE}
                WHERE id = ?
            """, (memory_id,))
            
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return MemoryEntry(
                    id=row[0],
                    content=row[1],
                    doc_type=row[2],
                    metadata=json.loads(row[3]) if row[3] else {},
                    agent_id=row[4],
                    scan_id=row[5],
                    tags=json.loads(row[6]) if row[6] else [],
                    created_at=row[7],
                    updated_at=row[8],
                )
            return None
    
    def delete(self, memory_id: str) -> bool:
        """Delete a memory entry."""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            cursor = conn.cursor()
            
            cursor.execute(f"DELETE FROM {MEMORY_TABLE} WHERE id = ?", (memory_id,))
            deleted = cursor.rowcount > 0
            
            conn.commit()
            conn.close()
            
            return deleted
    
    def cleanup_old(self) -> int:
        """Remove memories older than TTL. Returns count of deleted entries."""
        if self.ttl_days <= 0:
            return 0
        
        with self._lock:
            conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            cursor = conn.cursor()
            
            cutoff = datetime.now(UTC)
            from datetime import timedelta
            cutoff = cutoff - timedelta(days=self.ttl_days)
            
            cursor.execute(f"""
                DELETE FROM {MEMORY_TABLE}
                WHERE created_at < ?
            """, (cutoff.isoformat(),))
            
            deleted = cursor.rowcount
            conn.commit()
            conn.close()
            
            if deleted > 0:
                logger.info("Cleanup: removed %d old memories", deleted)
            
            return deleted
    
    def count(self, doc_type: str | None = None) -> int:
        """Count total memories, optionally filtered by type."""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            cursor = conn.cursor()
            
            if doc_type:
                cursor.execute(f"""
                    SELECT COUNT(*) FROM {MEMORY_TABLE}
                    WHERE doc_type = ?
                """, (doc_type,))
            else:
                cursor.execute(f"SELECT COUNT(*) FROM {MEMORY_TABLE}")
            
            count = cursor.fetchone()[0]
            conn.close()
            
            return count
    
    def to_prompt_context(self, query: str, limit: int = 3) -> str:
        """
        Convert search results to a prompt-friendly context string.
        
        This is injected into the LLM context to provide memory context
        without bloating the conversation history.
        """
        results = self.search(query, limit=limit)
        
        if not results:
            return ""
        
        parts = ["<memory_context>"]
        for entry in results:
            parts.append(f"## [{entry.doc_type}] {entry.created_at[:10]}")
            parts.append(entry.content[:500])  # Truncate for token savings
            parts.append("")
        
        parts.append("</memory_context>")
        
        return "\n".join(parts)


# Global memory instance (lazy initialization)
_global_memories: dict[str, VectorMemory] = {}
_memories_lock = threading.RLock()


def get_memory(scan_id: str, agent_id: str | None = None) -> VectorMemory:
    """Get or create a VectorMemory instance for a scan."""
    key = scan_id or "default"
    
    with _memories_lock:
        if key not in _global_memories:
            _global_memories[key] = VectorMemory(scan_id=scan_id, agent_id=agent_id)
        return _global_memories[key]


def cleanup_all_memories() -> int:
    """Cleanup old entries in all memory stores."""
    total = 0
    with _memories_lock:
        for memory in _global_memories.values():
            total += memory.cleanup_old()
    return total
