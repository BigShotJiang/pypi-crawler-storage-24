# rigol1000z-tools

`rigol1000z-tools` is a repackaged and extended Rigol DS1000Z Python driver.

It is based on the original `rigol1000z` package, with additional helpers for:

- bounded, safer screenshot capture
- PNG repair fallback for malformed screenshot payloads
- labeled screenshot generation using Pillow

## Install

From a local checkout:

```bash
pip install .
```

With image labeling support:

```bash
pip install .[images]
```

After publishing to an index such as PyPI or GitHub Packages:

```bash
pip install rigol1000z-tools
```

## Usage

```python
import pyvisa as visa
from rigol1000z_tools import Rigol1000z

rm = visa.ResourceManager()
osc_resource = rm.open_resource(rm.list_resources()[0])

osc = Rigol1000z(osc_resource)
osc.get_screenshot_safe("scope.png")
osc.get_labeled_screenshot(
    "scope.png",
    {1: "CH1: VIN", 2: "CH2: VOUT"},
    labeled_filename="scope_labeled.png",
)
```

## Build

```bash
python -m build
```

Build artifacts will be written to `dist/`.

## Publish

Typical PyPI flow:

```bash
python -m pip install build twine
python -m build
python -m twine upload dist/*
```

If you prefer installation directly from GitHub, users can run:

```bash
pip install git+https://github.com/M-Y-chen/Library.git#subdirectory=packages/instrumentation/rigol1000z_tools_package
```