#!/usr/bin/env python3
"""
MCP Keep Feedback - 主程序入口
==============================

此档案允许套件通过 `python -m mcp_keep_feedback` 执行。
"""

import argparse
import asyncio
import os
import sys
import warnings


# 抑制 Windows 上的 asyncio ResourceWarning
if sys.platform == "win32":
    warnings.filterwarnings(
        "ignore", category=ResourceWarning, message=".*unclosed transport.*"
    )
    warnings.filterwarnings("ignore", category=ResourceWarning, message=".*unclosed.*")

    # 设置 asyncio 事件循环策略以减少警告
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    except AttributeError:
        pass


def main():
    """主程序入口点"""
    parser = argparse.ArgumentParser(
        description="MCP Keep Feedback - 互动式反馈收集 MCP 服务器"
    )

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # 服务器命令（默认）
    subparsers.add_parser("server", help="启动 MCP 服务器（默认）")

    # 测试命令
    test_parser = subparsers.add_parser("test", help="执行测试")
    test_parser.add_argument(
        "--web", action="store_true", help="测试 Web UI (自动持续运行)"
    )
    test_parser.add_argument(
        "--desktop", action="store_true", help="启动桌面应用程序模式"
    )
    test_parser.add_argument(
        "--timeout", type=int, default=60, help="测试超时时间 (秒)"
    )

    # 版本命令
    subparsers.add_parser("version", help="显示版本信息")

    # Web UI 命令
    web_parser = subparsers.add_parser("web", help="启动独立的 Web UI 服务器")
    web_parser.add_argument(
        "--host",
        type=str,
        help="指定监听主机 (默认为 127.0.0.1，可设为 0.0.0.0 允许远程访问)",
    )
    web_parser.add_argument(
        "--port", "-p", type=int, help="指定 Web UI 端口 (默认为 8765)"
    )

    # 停止服务器命令
    stop_parser = subparsers.add_parser("stop", help="停止正在运行的 Web UI 服务器")
    stop_parser.add_argument("--host", type=str, help="指定服务器主机地址")
    stop_parser.add_argument(
        "--port", "-p", type=int, help="指定 Web UI 端口 (默认为 8765)"
    )

    # 反馈命令 (CLI 触发)
    feedback_parser = subparsers.add_parser("feedback", help="触发互动式反馈界面")
    feedback_parser.add_argument(
        "--project-directory", "-d", help="项目目录路径 (默认为当前目录)", default="."
    )
    feedback_parser.add_argument(
        "--report", "-r", "--summary", "-s", help="完整的任务汇报内容"
    )
    feedback_parser.add_argument("--file", "-f", help="从指定文件读取汇报内容")
    feedback_parser.add_argument(
        "--json", action="store_true", help="以 JSON 格式输出完整结果"
    )
    feedback_parser.add_argument("--host", type=str, help="指定服务器主机地址")
    feedback_parser.add_argument(
        "--port", "-p", type=int, help="指定 Web UI 端口 (默认为 8765)"
    )

    args = parser.parse_args()

    if args.command == "test":
        run_tests(args)
    elif args.command == "version":
        show_version()
    elif args.command == "web":
        run_web_server(args)
    elif args.command == "feedback":
        run_feedback_cli(args)
    elif args.command == "stop":
        run_stop_server(args)
    elif args.command == "server" or args.command is None:
        run_server()
    else:
        parser.print_help()
        sys.exit(1)


def run_feedback_cli(args):
    """执行命令行触发反馈"""
    from .utils.cli_client import run_trigger_sync

    # 0. 检查必须指定端口
    if not args.port:
        print("❌ 错误: 必须通过 --port 或 -p 参数指定端口。")
        print(
            '💡 示例: uv run python -m mcp_keep_feedback feedback --port 8765 -r "汇报内容"'
        )
        sys.exit(1)

    # 1. 确定项目目录
    project_dir = args.project_directory or os.getcwd()

    # 2. 确定汇报内容 (report)
    report_content = args.report

    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as f:
                report_content = f.read()
        except Exception as e:
            print(f"❌ 错误: 无法读取文件 {args.file} - {e}")
            sys.exit(1)
    elif not report_content:
        # 只有在没有通过参数提供内容时，才尝试从 stdin 读取
        if not sys.stdin.isatty():
            # 这种方式最适合 AI 传递超长、带换行的完整汇报
            report_content = sys.stdin.read()

        if not report_content:
            print("❌ 错误: 必须提供汇报内容 (full_report_and_output)。")
            print('💡 方式 1: uv run python -m mcp_keep_feedback feedback . "汇报内容"')
            print(
                '💡 方式 2: echo "汇报内容" | uv run python -m mcp_keep_feedback feedback'
            )
            print(
                "💡 方式 3: uv run python -m mcp_keep_feedback feedback --file report.md"
            )
            sys.exit(1)

    # 3. 执行触发（CLI 模式下必须指定端口，使用严格模式）
    port_str = str(args.port)
    host_str = args.host

    success = run_trigger_sync(
        summary=report_content,
        project_dir=project_dir,
        json_output=args.json,
        port=port_str,
        host=host_str,
        strict_port=True,
    )
    if not success:
        sys.exit(1)


def run_stop_server(args):
    """停止正在运行的服务器"""
    from .utils.cli_client import shutdown_server

    port_str = str(args.port) if args.port else None
    host_str = args.host
    success = asyncio.run(shutdown_server(port=port_str, host=host_str))
    if not success:
        sys.exit(1)


def run_web_server(args):
    """启动独立的 Web UI 服务器"""
    import time
    from .web.main import WebUIManager

    # 设置环境变量（如果通过参数指定）
    if args.host:
        os.environ["MCP_WEB_HOST"] = args.host

    print(f"🚀 启动独立 Web UI 服务器...")
    manager = WebUIManager(port=args.port)
    manager.start_server()

    time.sleep(2)
    if manager.server_thread and manager.server_thread.is_alive():
        url = manager.get_server_url()
        print(f"✅ Web UI 服务器已启动: {url}")
        print("💡 您现在可以通过 'mcp-keep-feedback feedback' 命令触发界面")
        print("💡 按 Ctrl+C 停止服务器")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 停止服务器...")
            manager.stop()
    else:
        print("❌ 服务器启动失败")


def run_server():
    """启动 MCP 服务器"""
    from .server import main as server_main

    return server_main()


def run_tests(args):
    """执行测试"""
    os.environ["MCP_DEBUG"] = "true"
    if sys.platform == "win32":
        import warnings

        os.environ["PYTHONWARNINGS"] = (
            "ignore::ResourceWarning,ignore::DeprecationWarning"
        )
        warnings.filterwarnings("ignore", category=ResourceWarning)
        warnings.filterwarnings("ignore", message=".*unclosed.*")

    if args.web:
        print("🧪 执行 Web UI 测试...")
        success = test_web_ui_simple()
        if not success:
            sys.exit(1)
    elif args.desktop:
        print("🖥️ 启动桌面应用程序...")
        success = test_desktop_app()
        if not success:
            sys.exit(1)
    else:
        print("❌ 测试功能已简化")
        sys.exit(1)


def test_web_ui_simple():
    """简单的 Web UI 测试"""
    try:
        import tempfile
        import time
        import webbrowser
        from .web.main import WebUIManager

        os.environ["MCP_TEST_MODE"] = "true"
        os.environ["MCP_WEB_HOST"] = "127.0.0.1"
        os.environ["MCP_WEB_PORT"] = "9765"

        manager = WebUIManager()
        manager.start_server()
        time.sleep(5)

        if manager.server_thread and manager.server_thread.is_alive():
            url = manager.get_server_url()
            webbrowser.open(url)
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                return True
        return False
    except Exception as e:
        print(f"❌ Web UI 测试失败: {e}")
        return False


def test_desktop_app():
    """测试桌面应用程序"""
    print("🚀 启动桌面应用程序...")
    os.environ["MCP_DESKTOP_MODE"] = "true"

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        from .web.main import get_web_ui_manager

        # 这里需要导入桌面启动函数
        print("💡 桌面模式正在运行...")
        return True
    except Exception as e:
        print(f"❌ 桌面应用程序测试失败: {e}")
        return False


def show_version():
    """显示版本信息"""
    from . import __author__, __version__

    print(f"MCP Keep Feedback v{__version__}")
    print(f"作者: {__author__}")


if __name__ == "__main__":
    # 在 Windows 上强制禁用输出缓冲
    if sys.platform == "win32":
        import io

        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", line_buffering=True
        )
    main()
