#!/bin/bash
# PyPI 发布脚本
# 使用方法: ./scripts/publish.sh [--test]

set -e  # 遇到错误立即退出

# 获取脚本所在目录的项目根目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# 加载 .env 文件
load_env() {
    local env_file="$PROJECT_ROOT/.env"
    if [ -f "$env_file" ]; then
        set -a
        source "$env_file"
        set +a
    fi
}

# 加载环境变量
load_env

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查环境变量
check_token() {
    if [ -z "$PYPI_TOKEN" ]; then
        print_error "PYPI_TOKEN 环境变量未设置"
        print_info "请在 .env 文件中设置: PYPI_TOKEN=pypi-xxx"
        print_info "或设置环境变量: export PYPI_TOKEN='pypi-xxx'"
        exit 1
    fi
}

# 获取版本号
get_version() {
    grep -Po '(?<=^version = ")[^"]*' pyproject.toml || echo "unknown"
}

# 清理旧的构建产物
clean_build() {
    print_info "清理旧的构建产物..."
    rm -rf build/ dist/ *.egg-info src/*.egg-info
    print_success "清理完成"
}

# 构建分发包
build_package() {
    print_info "构建分发包..."
    uv build
    print_success "构建完成"
    
    # 显示构建产物
    echo ""
    print_info "构建产物:"
    ls -lh dist/
    echo ""
}

# 上传到 PyPI
upload_pypi() {
    local test_mode=$1
    
    print_info "上传到 PyPI..."
    
    if [ "$test_mode" = true ]; then
        print_warning "测试模式：上传到 TestPyPI"
        uv run twine upload dist/* -u __token__ -p "$PYPI_TOKEN" --repository testpypi
    else
        uv run twine upload dist/* -u __token__ -p "$PYPI_TOKEN"
    fi
    
    local version=$(get_version)
    
    echo ""
    print_success "发布成功！"
    echo ""
    
    if [ "$test_mode" = true ]; then
        echo -e "🌐 TestPyPI 地址: ${GREEN}https://test.pypi.org/project/mcp-keep-feedback/${version}/${NC}"
    else
        echo -e "🌐 PyPI 地址: ${GREEN}https://pypi.org/project/mcp-keep-feedback/${version}/${NC}"
    fi
    echo ""
}

# 主流程
main() {
    local test_mode=false
    
    # 解析参数
    if [ "$1" = "--test" ]; then
        test_mode=true
    fi
    
    echo ""
    echo "========================================"
    echo "  PyPI 发布脚本"
    echo "========================================"
    echo ""
    
    # 显示版本信息
    local version=$(get_version)
    print_info "当前版本: v${version}"
    echo ""
    
    # 检查环境
    check_token
    
    # 清理
    clean_build
    
    # 构建
    build_package
    
    # 上传
    upload_pypi $test_mode
}

# 执行主流程
main "$@"
