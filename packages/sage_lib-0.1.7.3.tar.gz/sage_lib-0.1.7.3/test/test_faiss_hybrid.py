import os
import shutil
import numpy as np
import sys

sys.path.append("/Users/dimitry/Documents/Code/SAGE/src")
from sage_lib.IO.storage.hybrid import HybridStorage

class DummyAPM:
    def __init__(self):
        self.metadata = {}
        self.atomLabelsList = ['H', 'O']

class MockObj:
    def __init__(self, e=0.0):
        self.E = e
        self.hash = str(e)
        self.AtomPositionManager = DummyAPM()

def test_faiss():
    store_dir = "/Users/dimitry/Documents/Code/SAGE/test_faiss_store"
    if os.path.exists(store_dir):
        shutil.rmtree(store_dir)
        
    store = HybridStorage(store_dir, use_faiss=True, faiss_dim=3)
    
    vec1 = np.array([1.0, 0.0, 0.0])
    vec2 = np.array([0.0, 1.0, 0.0])
    vec3 = np.array([1.0, 0.0, 0.1])
    
    id1 = store.add(MockObj(1.0))
    store.add_vector(id1, vec1)
    
    id2 = store.add(MockObj(2.0))
    store.add_vector(id2, vec2)
    
    id3 = store.add(MockObj(3.0))
    store.add_vector(id3, vec3)

    # vec1 should be close to vec3. Distance is 0.1 in the z-axis. 
    # FAISS IndexFlatL2 uses squared Euclidean distance. 0.1^2 = 0.01.
    matched = store.search_vector(vec1, threshold=0.005)
    assert set(matched) == {id1}
    
    matched2 = store.search_vector(vec1, threshold=0.02)
    assert set(matched2) == {id1, id3}
    
    groups = store.find_duplicate_groups(threshold=0.02)
    assert len(groups) == 1
    assert set(groups[0]) == {id1, id3}
    
    store.close()
    
    store2 = HybridStorage(store_dir, use_faiss=True)
    assert store2.faiss_index.ntotal == 3
    
    store2.remove([id1])
    assert store2.faiss_index.ntotal == 2
    
    # Add dummy object
    id4 = store2.add(MockObj(4.0))
    # rebuild passing a mocked vec_fn
    store2.rebuild_faiss_index(lambda obj: np.array([0.0, 0.0, obj.E]))
    assert store2.faiss_index.ntotal == 3
    
    store2.close()

if __name__ == "__main__":
    test_faiss()

# ==============================================================================
# Practical Examples
# ==============================================================================

def example_convert_db(db_path: str):
    """
    Example: How to take an old database that did NOT use FAISS
    and build the fast search index for the first time.
    """
    print(f"\n--- Example: Converting DB {db_path} ---")
    # 1. Open the database indicating we NOW want to use FAISS.
    # We must provide the dimension (faiss_dim) because the index doesn't exist yet.
    # Let's assume our mathematical descriptor returns vectors of size 100.
    store = HybridStorage(db_path, use_faiss=True, faiss_dim=100)
    
    # 2. Define our mathematical function that extracts the vector from a structure.
    def my_vectorizer_function(structure):
        # This function receives a deserialized object from the DB.
        # Here we use the structure's API to create the vector (e.g., SOAP, Fingerprint, etc)
        # For now, we return fixed random vectors of size 100.
        np.random.seed(int(structure.E * 1000)) # dummy seed
        return np.random.rand(100).astype(np.float32)

    # 3. Call rebuild_faiss_index
    # This will iterate through the whole DB, apply the function, and save the `.faiss` to disk automatically.
    store.rebuild_faiss_index(my_vectorizer_function)
    
    # 4. Done, the DB now has an active FAISS index.
    print(f"The old database now has {store.faiss_index.ntotal} mapped vectors!")
    store.close()

def example_find_duplicate_groups(db_path: str):
    """
    Example: How to automatically detect groups of duplicate structures
    across the entire global database.
    """
    print(f"\n--- Example: Finding Global Duplicates in {db_path} ---")
    
    # 1. Open the DB (no need for faiss_dim if converted previously, loads from disk)
    store = HybridStorage(db_path, use_faiss=True)
    
    # 2. Define our "similarity" threshold to consider them duplicates.
    # Important: Default FAISS (IndexFlatL2) measures Euclidean distance SQUARED.
    # If we consider a delta of 0.05 to be a duplicate, the threshold is 0.05^2 = 0.0025
    threshold = 0.0025 
    
    # 3. Call the function
    duplicate_groups = store.find_duplicate_groups(threshold=threshold)
    
    print(f"Found {len(duplicate_groups)} groups of nearly identical crystals.")
    for idx, group in enumerate(duplicate_groups[:3]): # Show the first 3
        print(f"  Group #{idx+1}: Database IDs -> {group}")
        
    store.close()

def example_find_top_m(db_path: str):
    """
    Example: How to find the top 'M' structures most similar to MY structure 
    within the database.
    """
    print(f"\n--- Example: Searching Top M Similar in {db_path} ---")
    store = HybridStorage(db_path, use_faiss=True)
    
    # 1. I have a new generated structure in memory (my_new_structure)
    # Extract its mathematical features (vector size: 100)
    my_query_vector = np.random.rand(100).astype(np.float32) 
    
    # 2. I ask the database for the 5 MOST similar structures.
    M = 5
    
    # IMPORTANT: search_vector filters by threshold. 
    # If we want the top 5 regardless of how far they are, we set an enormous threshold
    # (e.g., infinity) so it doesn't filter by distance, only by the K nearest neighbors.
    infinite_threshold = float('inf') 
    
    similar_ids = store.search_vector(my_query_vector, threshold=infinite_threshold, k=M)
    
    print(f"The {M} structures most similar to my query in the DB are IDs: {similar_ids}")
    store.close()

# Uncomment to run the examples:
# if __name__ == "__main__":
#     example_convert_db("/Users/dimitry/Documents/Code/SAGE/test_faiss_store")
#     example_find_duplicate_groups("/Users/dimitry/Documents/Code/SAGE/test_faiss_store")
#     example_find_top_m("/Users/dimitry/Documents/Code/SAGE/test_faiss_store")
