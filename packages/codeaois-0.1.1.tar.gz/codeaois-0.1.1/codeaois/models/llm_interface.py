# codeaois/models/llm_interface.py
import requests
import json

# ⚠️ PASTE YOUR VERCEL DOMAIN HERE! KEEP THE "https://" AND THE "/api/chat" AT THE END!
PROXY_URL = "https://codeaois-proxy.vercel.app/api/chat"

def call_openrouter(system_prompt: str, user_prompt: str, intent: str = "chat", history: list = None) -> str:
    """Handles API calls securely through the CodeAOIS Cloud Proxy."""
    
    if intent in ["code", "data_science"]:
        models_to_try = [
            "openai/gpt-oss-120b:free",
            "stepfun/step-3.5-flash:free",
            "qwen/qwen3-vl-30b-a3b-thinking:free",
            "meta-llama/llama-3.1-8b-instruct:free",
            "mistralai/mistral-7b-instruct:free",
            "openrouter/auto" 
        ]
    else:
        models_to_try = [
            "liquid/lfm-2.5-1.2b-thinking:free",
            "arcee-ai/trinity-large-preview:free",
            "liquid/lfm-2.5-1.2b-instruct:free",
            "meta-llama/llama-3.1-8b-instruct:free",
            "qwen/qwen2.5-7b-instruct:free",
            "mistralai/mistral-7b-instruct:free",
            "openrouter/auto"
        ]

    messages = [{"role": "system", "content": system_prompt}]
    if history:
        messages.extend(history)
    messages.append({"role": "user", "content": user_prompt})

    for model in models_to_try:
        print(f"📡 [LLM Interface] Routing {model} securely via Cloud Proxy...")
        
        payload = {"model": model, "messages": messages}

        try:
            # We send the request to YOUR server, not OpenRouter!
            response = requests.post(
                url=PROXY_URL,
                json=payload,
                timeout=45
            )
            
            # 503 means your server tried all its keys and they all failed
            if response.status_code == 503:
                print(f"   -> ⚠️ Cloud proxy overloaded. Trying next free model...")
                continue 
                
            response.raise_for_status()
            
            # We get the exact same OpenRouter JSON back from our proxy
            return response.json()["choices"][0]["message"]["content"]
            
        except requests.exceptions.RequestException as e:
            # --- NEW: Print the exact error so we can see what went wrong! ---
            print(f"   -> 🛑 DEBUG ERROR: {e}")
            print(f"   -> ⚠️ Cloud Proxy network error. Trying fallback model...")
            continue
            

    return "[API Error]: The CodeAOIS Cloud Proxy is currently overloaded. Please try again later."