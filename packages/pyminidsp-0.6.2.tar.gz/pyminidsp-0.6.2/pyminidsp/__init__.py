"""
pyminidsp - Python bindings to the miniDSP C library.

A comprehensive DSP toolkit providing signal generation, spectral analysis,
filtering, effects, and more. All functions accept and return NumPy arrays.

Example:
    >>> import pyminidsp as md
    >>> signal = md.sine_wave(1024, amplitude=1.0, freq=440.0, sample_rate=44100.0)
    >>> mag = md.magnitude_spectrum(signal)
    >>> md.shutdown()
"""

from pyminidsp._core import *  # noqa: F401, F403
from pyminidsp._core import (
    # Re-export everything explicitly for documentation
    # Error handling
    MiniDSPError,
    ERR_NULL_POINTER, ERR_INVALID_SIZE, ERR_INVALID_RANGE, ERR_ALLOC_FAILED,
    # Math utilities
    bessel_i0, sinc,
    # Signal measurement
    dot, entropy, energy, power, power_db,
    # Signal analysis
    rms, zero_crossing_rate, autocorrelation, peak_detect,
    f0_autocorrelation, f0_fft, mix,
    # Effects
    delay_echo, tremolo, comb_reverb,
    # FIR / Convolution
    convolution_num_samples, convolution_time, moving_average,
    fir_filter, design_lowpass_fir, convolution_fft_ola,
    # Scaling
    scale, scale_vec, fit_within_range, adjust_dblevel,
    # Spectrum
    lowpass_brickwall,
    magnitude_spectrum, power_spectral_density, phase_spectrum,
    stft_num_frames, stft, mel_filterbank, mel_energies, mfcc,
    # Windows
    hann_window, hamming_window, blackman_window, rect_window, kaiser_window,
    # Generators
    sine_wave, white_noise, impulse, chirp_linear, chirp_log,
    square_wave, sawtooth_wave, shepard_tone,
    # DTMF
    dtmf_detect, dtmf_generate, dtmf_signal_length,
    # Cleanup
    shutdown,
    # GCC
    get_delay, get_multiple_delays, gcc,
    # Spectrogram text
    spectrogram_text,
    # Steganography
    steg_capacity, steg_encode, steg_decode,
    steg_encode_bytes, steg_decode_bytes, steg_detect,
    # Resampling
    resample_output_len, resample,
    # Biquad
    BiquadFilter,
    # Constants
    LPF, HPF, BPF, NOTCH, PEQ, LSH, HSH,
    STEG_LSB, STEG_FREQ_BAND, STEG_SPECTEXT, STEG_TYPE_TEXT, STEG_TYPE_BINARY,
    GCC_SIMP, GCC_PHAT,
    # VAD
    VAD, VAD_NUM_FEATURES,
)

from importlib.metadata import version as _version, PackageNotFoundError as _PNF

try:
    __version__ = _version("pyminidsp")
except _PNF:
    __version__ = "0.0.0"  # not installed via pip (e.g. editable dev checkout)
__all__ = [
    # Error handling
    "MiniDSPError",
    "ERR_NULL_POINTER", "ERR_INVALID_SIZE", "ERR_INVALID_RANGE", "ERR_ALLOC_FAILED",
    # Math utilities
    "bessel_i0", "sinc",
    # Signal measurement
    "dot", "entropy", "energy", "power", "power_db",
    # Signal analysis
    "rms", "zero_crossing_rate", "autocorrelation", "peak_detect",
    "f0_autocorrelation", "f0_fft", "mix",
    # Effects
    "delay_echo", "tremolo", "comb_reverb",
    # FIR / Convolution
    "convolution_num_samples", "convolution_time", "moving_average",
    "fir_filter", "design_lowpass_fir", "convolution_fft_ola",
    # Scaling
    "scale", "scale_vec", "fit_within_range", "adjust_dblevel",
    # Spectrum
    "lowpass_brickwall",
    "magnitude_spectrum", "power_spectral_density", "phase_spectrum",
    "stft_num_frames", "stft", "mel_filterbank", "mel_energies", "mfcc",
    # Windows
    "hann_window", "hamming_window", "blackman_window", "rect_window",
    "kaiser_window",
    # Generators
    "sine_wave", "white_noise", "impulse", "chirp_linear", "chirp_log",
    "square_wave", "sawtooth_wave", "shepard_tone",
    # DTMF
    "dtmf_detect", "dtmf_generate", "dtmf_signal_length",
    # Cleanup
    "shutdown",
    # GCC
    "get_delay", "get_multiple_delays", "gcc",
    # Spectrogram text
    "spectrogram_text",
    # Steganography
    "steg_capacity", "steg_encode", "steg_decode",
    "steg_encode_bytes", "steg_decode_bytes", "steg_detect",
    # Resampling
    "resample_output_len", "resample",
    # Biquad
    "BiquadFilter",
    # Constants
    "LPF", "HPF", "BPF", "NOTCH", "PEQ", "LSH", "HSH",
    "STEG_LSB", "STEG_FREQ_BAND", "STEG_SPECTEXT", "STEG_TYPE_TEXT", "STEG_TYPE_BINARY",
    "GCC_SIMP", "GCC_PHAT",
    # VAD
    "VAD", "VAD_NUM_FEATURES",
]
