"""Signal measurement, analysis, and scaling functions."""

from __future__ import annotations

import numpy as np
import numpy.typing as npt

from pyminidsp._minidsp_cffi import ffi, lib
from pyminidsp._helpers import _as_double_ptr, _new_double_array, _check_error

# ---------------------------------------------------------------------------
# Signal measurement
# ---------------------------------------------------------------------------

def dot(a: npt.ArrayLike, b: npt.ArrayLike) -> float:
    """Compute the dot product of two vectors."""
    a_ptr, a = _as_double_ptr(a)
    b_ptr, b = _as_double_ptr(b)
    n = min(len(a), len(b))
    result = lib.MD_dot(a_ptr, b_ptr, n)
    _check_error()
    return result


def entropy(a: npt.ArrayLike, clip: bool = False) -> float:
    """Compute the normalized entropy of a distribution."""
    a_ptr, a = _as_double_ptr(a)
    result = lib.MD_entropy(a_ptr, len(a), clip)
    _check_error()
    return result


def energy(a: npt.ArrayLike) -> float:
    """Compute signal energy: sum of squared samples."""
    a_ptr, a = _as_double_ptr(a)
    result = lib.MD_energy(a_ptr, len(a))
    _check_error()
    return result


def power(a: npt.ArrayLike) -> float:
    """Compute signal power: energy / N."""
    a_ptr, a = _as_double_ptr(a)
    result = lib.MD_power(a_ptr, len(a))
    _check_error()
    return result


def power_db(a: npt.ArrayLike) -> float:
    """Compute signal power in decibels."""
    a_ptr, a = _as_double_ptr(a)
    result = lib.MD_power_db(a_ptr, len(a))
    _check_error()
    return result


# ---------------------------------------------------------------------------
# Math utilities
# ---------------------------------------------------------------------------

def bessel_i0(x: float) -> float:
    """Compute the zeroth-order modified Bessel function of the first kind."""
    result = lib.MD_bessel_i0(float(x))
    _check_error()
    return result


def sinc(x: float) -> float:
    """Compute the normalized sinc function: sin(pi*x) / (pi*x), with sinc(0) = 1."""
    result = lib.MD_sinc(float(x))
    _check_error()
    return result


# ---------------------------------------------------------------------------
# Signal analysis
# ---------------------------------------------------------------------------

def rms(a: npt.ArrayLike) -> float:
    """Compute the root mean square (RMS) of a signal."""
    a_ptr, a = _as_double_ptr(a)
    result = lib.MD_rms(a_ptr, len(a))
    _check_error()
    return result


def zero_crossing_rate(a: npt.ArrayLike) -> float:
    """Compute the zero-crossing rate of a signal."""
    a_ptr, a = _as_double_ptr(a)
    result = lib.MD_zero_crossing_rate(a_ptr, len(a))
    _check_error()
    return result


def autocorrelation(a: npt.ArrayLike, max_lag: int) -> npt.NDArray[np.float64]:
    """
    Compute the normalised autocorrelation of a signal.

    Args:
        a: Input signal.
        max_lag: Number of lag values to compute.

    Returns:
        numpy array of autocorrelation values, length max_lag.
    """
    a_ptr, a = _as_double_ptr(a)
    out, out_ptr = _new_double_array(max_lag)
    lib.MD_autocorrelation(a_ptr, len(a), out_ptr, max_lag)
    _check_error()
    return out


def peak_detect(a: npt.ArrayLike, threshold: float = 0.0, min_distance: int = 1) -> npt.NDArray[np.uint32]:
    """
    Detect peaks (local maxima) in a signal.

    Args:
        a: Input signal.
        threshold: Minimum value for a peak.
        min_distance: Minimum index gap between peaks.

    Returns:
        numpy array of peak indices.
    """
    a_ptr, a = _as_double_ptr(a)
    n = len(a)
    peaks = np.zeros(n, dtype=np.uint32)
    num_peaks = ffi.new("unsigned *")
    lib.MD_peak_detect(
        a_ptr, n, threshold, min_distance,
        ffi.cast("unsigned *", peaks.ctypes.data), num_peaks,
    )
    _check_error()
    return peaks[: num_peaks[0]].copy()


def f0_autocorrelation(signal: npt.ArrayLike, sample_rate: float, min_freq_hz: float = 80.0, max_freq_hz: float = 400.0) -> float:
    """Estimate F0 using autocorrelation."""
    s_ptr, signal = _as_double_ptr(signal)
    result = lib.MD_f0_autocorrelation(s_ptr, len(signal), sample_rate, min_freq_hz, max_freq_hz)
    _check_error()
    return result


def f0_fft(signal: npt.ArrayLike, sample_rate: float, min_freq_hz: float = 80.0, max_freq_hz: float = 400.0) -> float:
    """Estimate F0 using FFT peak picking."""
    s_ptr, signal = _as_double_ptr(signal)
    result = lib.MD_f0_fft(s_ptr, len(signal), sample_rate, min_freq_hz, max_freq_hz)
    _check_error()
    return result


def mix(a: npt.ArrayLike, b: npt.ArrayLike, w_a: float = 0.5, w_b: float = 0.5) -> npt.NDArray[np.float64]:
    """
    Mix (weighted sum) two signals.

    Args:
        a, b: Input signals of the same length.
        w_a, w_b: Weights for signals a and b.

    Returns:
        numpy array of the mixed signal.
    """
    a_ptr, a = _as_double_ptr(a)
    b_ptr, b = _as_double_ptr(b)
    n = min(len(a), len(b))
    out, out_ptr = _new_double_array(n)
    lib.MD_mix(a_ptr, b_ptr, out_ptr, n, w_a, w_b)
    _check_error()
    return out


# ---------------------------------------------------------------------------
# Signal scaling
# ---------------------------------------------------------------------------

def scale(value: float, oldmin: float, oldmax: float, newmin: float, newmax: float) -> float:
    """Map a single value from one range to another."""
    result = lib.MD_scale(value, oldmin, oldmax, newmin, newmax)
    _check_error()
    return result


def scale_vec(a: npt.ArrayLike, oldmin: float, oldmax: float, newmin: float, newmax: float) -> npt.NDArray[np.float64]:
    """Map every element of a vector from one range to another."""
    a_ptr, a_arr = _as_double_ptr(a)
    n = len(a_arr)
    out, out_ptr = _new_double_array(n)
    # MD_scale_vec takes non-const input pointer
    in_copy = np.array(a_arr, dtype=np.float64, copy=True)
    in_ptr = ffi.cast("double *", in_copy.ctypes.data)
    lib.MD_scale_vec(in_ptr, out_ptr, n, oldmin, oldmax, newmin, newmax)
    _check_error()
    return out


def fit_within_range(a: npt.ArrayLike, newmin: float, newmax: float) -> npt.NDArray[np.float64]:
    """Fit values within [newmin, newmax]."""
    a_arr = np.ascontiguousarray(a, dtype=np.float64)
    n = len(a_arr)
    in_copy = np.array(a_arr, copy=True)
    in_ptr = ffi.cast("double *", in_copy.ctypes.data)
    out, out_ptr = _new_double_array(n)
    lib.MD_fit_within_range(in_ptr, out_ptr, n, newmin, newmax)
    _check_error()
    return out


def adjust_dblevel(signal: npt.ArrayLike, dblevel: float) -> npt.NDArray[np.float64]:
    """Automatic Gain Control: scale signal to target dB level, clip to [-1, 1]."""
    s_ptr, signal = _as_double_ptr(signal)
    n = len(signal)
    out, out_ptr = _new_double_array(n)
    lib.MD_adjust_dblevel(s_ptr, out_ptr, n, dblevel)
    _check_error()
    return out
