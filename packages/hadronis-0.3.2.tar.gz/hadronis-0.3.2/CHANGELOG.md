# Changelog

<!--next-version-placeholder-->

## v0.3.2 (2026-03-08)

### Fix

* Update version to 0.3.0 and correct dist_glob_patterns in pyproject.toml ([`a0eb63b`](https://github.com/louischereau/Hadronis/commit/a0eb63bcfe0cbce0a3ba0e786649391538cdfb57))
