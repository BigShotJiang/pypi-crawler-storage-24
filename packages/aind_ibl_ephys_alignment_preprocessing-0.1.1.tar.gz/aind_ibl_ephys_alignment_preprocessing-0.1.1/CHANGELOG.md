# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v0.1.1 (2026-03-24)

### Fix

- publish to pypi, use published aind-ephys-ibl-gui-conversion

## v0.1.0 (2026-03-23)

### Fix

- Add Manifest (#1)
