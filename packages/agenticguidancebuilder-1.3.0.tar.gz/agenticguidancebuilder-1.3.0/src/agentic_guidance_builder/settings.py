import tomllib
from pathlib import Path

SETTINGS_FILE_NAME = 'agd-settings.toml'


def load_guidance_settings(target: Path) -> dict[str, object]:
	settings_path = target / SETTINGS_FILE_NAME
	if not settings_path.exists():
		return {}

	loaded = tomllib.loads(settings_path.read_text())
	if not isinstance(loaded, dict):
		message = f'Expected {SETTINGS_FILE_NAME} to contain a TOML table'
		raise ValueError(message)

	return loaded


def resolve_project_name(settings: dict[str, object]) -> str | None:
	project_settings = settings.get('project', {})
	if not isinstance(project_settings, dict):
		message = f'Expected [{"project"}] in {SETTINGS_FILE_NAME} to be a table'
		raise ValueError(message)

	project_name = project_settings.get('name')
	if project_name is None:
		return None
	if not isinstance(project_name, str) or not project_name.strip():
		message = f'Expected project.name in {SETTINGS_FILE_NAME} to be a non-empty string'
		raise ValueError(message)

	return project_name.strip()


def resolve_build_output(settings: dict[str, object]) -> Path | None:
	build_settings = settings.get('build', {})
	if not isinstance(build_settings, dict):
		message = f'Expected [build] in {SETTINGS_FILE_NAME} to be a table'
		raise ValueError(message)

	default_output = build_settings.get('default_output')
	if default_output is None:
		return None
	if not isinstance(default_output, str) or not default_output.strip():
		message = f'Expected build.default_output in {SETTINGS_FILE_NAME} to be a non-empty string'
		raise ValueError(message)

	return Path(default_output.strip())


def resolve_include_examples(settings: dict[str, object]) -> bool | None:
	build_settings = settings.get('build', {})
	if not isinstance(build_settings, dict):
		message = f'Expected [build] in {SETTINGS_FILE_NAME} to be a table'
		raise ValueError(message)

	include_examples = build_settings.get('include_examples_by_default')
	if include_examples is None:
		return None
	if not isinstance(include_examples, bool):
		message = f'Expected build.include_examples_by_default in {SETTINGS_FILE_NAME} to be a boolean'
		raise ValueError(message)

	return include_examples


def resolve_vars(settings: dict[str, object]) -> dict[str, object]:
	settings_vars = settings.get('vars', {})
	if not isinstance(settings_vars, dict):
		message = f'Expected [vars] in {SETTINGS_FILE_NAME} to be a table'
		raise ValueError(message)

	return dict(settings_vars)
