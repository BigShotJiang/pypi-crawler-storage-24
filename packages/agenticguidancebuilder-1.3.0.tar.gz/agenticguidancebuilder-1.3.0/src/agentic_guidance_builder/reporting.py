from pathlib import Path

from agentic_guidance_builder.models import LoadedContent, ScopePackage, SourceDocument
from agentic_guidance_builder.validation import ValidationReport


def format_validation_report(report: ValidationReport) -> str:
	if report.ok:
		return 'Validation passed.'

	lines = ['Validation failed.', f'Errors ({len(report.errors)}):']
	for error in report.errors:
		lines.append(f'- {error}')

	return '\n'.join(lines)


def format_loaded_content(loaded_content: LoadedContent, root: Path) -> str:
	lines: list[str] = []

	if loaded_content.global_guidance is not None:
		lines.append('Global:')
		lines.append(_document_line(loaded_content.global_guidance, root))

	_append_package_group(lines, 'Languages:', loaded_content.language_packages, root)
	_append_package_group(lines, 'Frameworks:', loaded_content.framework_packages, root)

	if loaded_content.project_package is not None:
		_append_package_group(lines, 'Project:', [loaded_content.project_package], root)

	if not lines:
		return 'No guidance content found.'

	return '\n'.join(lines)


def _append_package_group(lines: list[str], heading: str, packages: list[ScopePackage], root: Path) -> None:
	if not packages:
		return

	lines.append(heading)
	for package in packages:
		lines.append(f'- package: {package.name} ({package.root.relative_to(root).as_posix()})')
		if package.guidance is not None:
			lines.append(_document_line(package.guidance, root, indent='  '))
		for example in package.examples:
			lines.append(_document_line(example, root, indent='  '))


def _document_line(document: SourceDocument, root: Path, indent: str = '') -> str:
	order = 'none'
	if document.order is not None:
		order = str(document.order)

	return f'{indent}- {document.kind.value}: id={document.id}, scope={document.scope.value}, name={document.name}, order={order}, path={document.path.relative_to(root).as_posix()}'
