from agentic_guidance_builder.parsing import FrontmatterParser


def body_without_frontmatter(raw_text: str) -> str:
	return FrontmatterParser().parse(raw_text).body.lstrip('\n')


def render_opencode_subagent(raw_text: str) -> str:
	body = body_without_frontmatter(raw_text).rstrip()
	return '\n'.join(
		[
			'---',
			'description: Systematically gathers codebase context for a scoped topic, feature, or area.',
			'mode: subagent',
			'temperature: 0.1',
			'permission:',
			'  edit: deny',
			'  bash:',
			'    "*": deny',
			'---',
			'',
			body,
			'',
		]
	)


def render_copilot_agent(raw_text: str) -> str:
	body = body_without_frontmatter(raw_text).rstrip()
	return '\n'.join(
		[
			'---',
			'name: context-gatherer',
			'description: Gather structured context about a code area before implementation or review.',
			'tools: ["read", "search"]',
			'---',
			'',
			body,
			'',
		]
	)
