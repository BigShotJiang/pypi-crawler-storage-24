from dataclasses import dataclass
from pathlib import Path

from agentic_guidance_builder.discovery import ContentDiscoveryService
from agentic_guidance_builder.loading import PackageLoader


@dataclass(frozen=True)
class ValidationReport:
	errors: tuple[str, ...]

	@property
	def ok(self) -> bool:
		return not self.errors


class ValidationService:
	def __init__(self, target: Path):
		self.target = target
		self.discovery = ContentDiscoveryService(target)
		self.loader = PackageLoader(target)

	def validate(self) -> ValidationReport:
		errors: list[str] = []

		if not self.discovery.global_guidance_path().exists():
			errors.append('Missing required guidance file: agents/guidance/guidance.md')

		loaded_content = None
		try:
			loaded_content = self.loader.load()
		except ValueError as error:
			errors.append(str(error))

		self._validate_package_guidance(self.discovery.language_package_roots(), errors)
		self._validate_package_guidance(self.discovery.framework_package_roots(), errors)

		project_root = self.discovery.project_package_root()
		if project_root.exists() and not (project_root / 'guidance.md').exists():
			errors.append('Missing required guidance file: agents/guidance/project/guidance.md')

		if loaded_content is not None:
			self._validate_duplicate_ids(loaded_content, errors)
			self._validate_document_order(loaded_content, errors)

		return ValidationReport(errors=tuple(errors))

	def _validate_package_guidance(self, package_roots: list[Path], errors: list[str]) -> None:
		for package_root in package_roots:
			if not (package_root / 'guidance.md').exists():
				relative_package = package_root.relative_to(self.target).as_posix()
				errors.append(f'Missing required guidance file: {relative_package}/guidance.md')

	@staticmethod
	def _validate_duplicate_ids(loaded_content, errors: list[str]) -> None:
		seen_ids: set[str] = set()
		for document in _iter_documents(loaded_content):
			if document.id in seen_ids:
				errors.append(f'Duplicate document id: {document.id}')
				continue
			seen_ids.add(document.id)

	@staticmethod
	def _validate_document_order(loaded_content, errors: list[str]) -> None:
		for document in _iter_documents(loaded_content):
			if document.order is not None and document.order < 0:
				errors.append(f'Frontmatter order must be non-negative: {document.path.as_posix()}')


def _iter_documents(loaded_content):
	if loaded_content.global_guidance is not None:
		yield loaded_content.global_guidance

	for package in loaded_content.language_packages + loaded_content.framework_packages:
		if package.guidance is not None:
			yield package.guidance
		for example in package.examples:
			yield example

	if loaded_content.project_package is not None:
		if loaded_content.project_package.guidance is not None:
			yield loaded_content.project_package.guidance
		for example in loaded_content.project_package.examples:
			yield example
