from agentic_guidance_builder.models import BuildContext, BuildPlan, LoadedContent, ScopePackage


class BuildPlanner:
	def create_plan(self, loaded_content: LoadedContent, context: BuildContext) -> BuildPlan:
		language_packages = self._select_packages(loaded_content.language_packages, context.selected_languages)
		framework_packages = self._select_packages(loaded_content.framework_packages, context.selected_frameworks)

		return BuildPlan(
			adapter_name=context.adapter_name,
			output_path=context.output_path,
			global_guidance=loaded_content.global_guidance,
			language_packages=language_packages,
			framework_packages=framework_packages,
			project_package=loaded_content.project_package,
			include_examples=context.include_examples,
		)

	def _select_packages(self, packages: list[ScopePackage], selected_names: list[str]) -> list[ScopePackage]:
		selected = packages
		if selected_names:
			selected = [package for package in packages if package.name in selected_names]

		return sort_scope_packages(selected)

	@staticmethod
	def _package_sort_key(package: ScopePackage) -> tuple[bool, int, str]:
		guidance_order = None
		if package.guidance is not None:
			guidance_order = package.guidance.order

		return _document_sort_key(guidance_order, package.root.as_posix())


def sort_scope_packages(packages: list[ScopePackage]) -> list[ScopePackage]:
	return sorted(packages, key=BuildPlanner._package_sort_key)


def sort_documents(documents) -> list:
	return sorted(documents, key=lambda document: _document_sort_key(document.order, document.path.as_posix()))


def _document_sort_key(order: int | None, path: str) -> tuple[bool, int, str]:
	return (order is None, order or 0, path)
