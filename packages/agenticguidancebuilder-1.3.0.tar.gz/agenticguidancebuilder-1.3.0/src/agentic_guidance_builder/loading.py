from pathlib import Path
from typing import Any, Optional

from agentic_guidance_builder.discovery import ContentDiscoveryService, GUIDANCE_ROOT
from agentic_guidance_builder.enums import ContentKind, ScopeType
from agentic_guidance_builder.models import LoadedContent, ScopePackage, SourceDocument
from agentic_guidance_builder.parsing import FrontmatterParser

ALLOWED_STATUSES = ('active', 'draft', 'deprecated')
SUPPORTED_FRONTMATTER_FIELDS = {
	'id',
	'title',
	'description',
	'kind',
	'scope',
	'name',
	'tags',
	'applies_to',
	'status',
	'order',
}


class DocumentLoader:
	def __init__(self, target: Path, parser: Optional[FrontmatterParser] = None):
		self.target = target
		self.parser = parser or FrontmatterParser()

	def load_document(self, path: Path, scope: ScopeType, name: str, kind: ContentKind) -> SourceDocument:
		raw_text = path.read_text()
		parsed = self.parser.parse(raw_text)
		frontmatter = parsed.frontmatter
		self._validate_frontmatter(frontmatter, path, scope, name, kind)

		return SourceDocument(
			id=self._document_id(path, frontmatter),
			title=self._title(parsed.body, path, frontmatter),
			description=self._description(frontmatter),
			kind=kind,
			scope=scope,
			name=name,
			tags=self._string_list(frontmatter.get('tags')),
			applies_to=self._string_list(frontmatter.get('applies_to')),
			path=path,
			frontmatter=frontmatter,
			raw_text=raw_text,
			body=parsed.body,
			order=self._order(frontmatter),
		)

	def _document_id(self, path: Path, frontmatter: dict[str, Any]) -> str:
		if 'id' in frontmatter and isinstance(frontmatter.get('id'), str) and frontmatter['id'].strip():
			return frontmatter['id'].strip()

		relative_path = path.relative_to(self.target / GUIDANCE_ROOT).with_suffix('')
		return '-'.join(relative_path.parts)

	def _title(self, body: str, path: Path, frontmatter: dict[str, Any]) -> str:
		if 'title' in frontmatter and isinstance(frontmatter.get('title'), str) and frontmatter['title'].strip():
			return frontmatter['title'].strip()

		for line in body.splitlines():
			stripped = line.strip()
			if stripped.startswith('# '):
				return stripped[2:].strip()

		return path.stem.replace('_', ' ').replace('-', ' ').title()

	@staticmethod
	def _description(frontmatter: dict[str, Any]) -> str:
		if 'description' in frontmatter and isinstance(frontmatter.get('description'), str):
			return frontmatter['description']
		return ''

	@staticmethod
	def _string_list(value: Any) -> list[str]:
		if value is None:
			return []
		if not isinstance(value, list):
			message = 'Expected a list value in frontmatter'
			raise ValueError(message)

		items: list[str] = []
		for item in value:
			if not isinstance(item, str):
				message = 'Expected frontmatter list items to be strings'
				raise ValueError(message)
			items.append(item)
		return items

	@staticmethod
	def _order(frontmatter: dict[str, Any]) -> Optional[int]:
		value = frontmatter.get('order')
		if value is None:
			return None
		if isinstance(value, int):
			return value

		message = 'Expected frontmatter order to be an integer'
		raise ValueError(message)

	def _validate_frontmatter(
		self,
		frontmatter: dict[str, Any],
		path: Path,
		scope: ScopeType,
		name: str,
		kind: ContentKind,
	) -> None:
		for key in frontmatter:
			if key not in SUPPORTED_FRONTMATTER_FIELDS:
				message = f'Unsupported frontmatter field in {self._relative_path(path)}: {key}'
				raise ValueError(message)

		self._validate_optional_string(frontmatter, path, 'id', allow_empty=False)
		self._validate_optional_string(frontmatter, path, 'title', allow_empty=False)
		self._validate_optional_string(frontmatter, path, 'description')
		self._validate_optional_string(frontmatter, path, 'status', allow_empty=False)

		if 'kind' in frontmatter:
			value = frontmatter['kind']
			if not isinstance(value, str):
				message = f'Expected frontmatter kind to be a string in {self._relative_path(path)}'
				raise ValueError(message)

			try:
				resolved_kind = ContentKind(value)
			except ValueError as error:
				message = f'Unsupported frontmatter kind in {self._relative_path(path)}: {value}'
				raise ValueError(message) from error

			if resolved_kind != kind:
				message = f'Frontmatter kind does not match file location in {self._relative_path(path)}: expected {kind.value}'
				raise ValueError(message)

		if 'scope' in frontmatter:
			value = frontmatter['scope']
			if not isinstance(value, str):
				message = f'Expected frontmatter scope to be a string in {self._relative_path(path)}'
				raise ValueError(message)

			try:
				resolved_scope = ScopeType(value)
			except ValueError as error:
				message = f'Unsupported frontmatter scope in {self._relative_path(path)}: {value}'
				raise ValueError(message) from error

			if resolved_scope != scope:
				message = f'Frontmatter scope does not match file location in {self._relative_path(path)}: expected {scope.value}'
				raise ValueError(message)

		if 'name' in frontmatter:
			value = frontmatter['name']
			if not isinstance(value, str) or not value.strip():
				message = f'Expected frontmatter name to be a non-empty string in {self._relative_path(path)}'
				raise ValueError(message)
			if value.strip() != name:
				message = f'Frontmatter name does not match file location in {self._relative_path(path)}: expected {name}'
				raise ValueError(message)

		if 'status' in frontmatter and frontmatter['status'] not in ALLOWED_STATUSES:
			message = f'Unsupported frontmatter status in {self._relative_path(path)}: {frontmatter["status"]}'
			raise ValueError(message)

		if 'tags' in frontmatter:
			self._string_list(frontmatter['tags'])
		if 'applies_to' in frontmatter:
			self._string_list(frontmatter['applies_to'])
		if 'order' in frontmatter:
			self._order(frontmatter)

	def _validate_optional_string(self, frontmatter: dict[str, Any], path: Path, field_name: str, allow_empty: bool = True) -> None:
		if field_name not in frontmatter:
			return

		value = frontmatter[field_name]
		if not isinstance(value, str):
			message = f'Expected frontmatter {field_name} to be a string in {self._relative_path(path)}'
			raise ValueError(message)
		if not allow_empty and not value.strip():
			message = f'Expected frontmatter {field_name} to be a non-empty string in {self._relative_path(path)}'
			raise ValueError(message)

	def _relative_path(self, path: Path) -> str:
		return path.relative_to(self.target).as_posix()


class PackageLoader:
	def __init__(self, target: Path, document_loader: Optional[DocumentLoader] = None):
		self.target = target
		self.discovery = ContentDiscoveryService(target)
		self.document_loader = document_loader or DocumentLoader(target)

	def load(self) -> LoadedContent:
		global_guidance = None
		global_path = self.discovery.global_guidance_path()
		if global_path.exists():
			global_guidance = self.document_loader.load_document(global_path, ScopeType.GLOBAL, 'global', ContentKind.GUIDANCE)

		language_packages = [self._load_package(root, ScopeType.LANGUAGE) for root in self.discovery.language_package_roots()]
		framework_packages = [self._load_package(root, ScopeType.FRAMEWORK) for root in self.discovery.framework_package_roots()]

		project_package = None
		project_root = self.discovery.project_package_root()
		if project_root.exists():
			project_package = self._load_package(project_root, ScopeType.PROJECT)

		return LoadedContent(
			global_guidance=global_guidance,
			language_packages=language_packages,
			framework_packages=framework_packages,
			project_package=project_package,
		)

	def _load_package(self, package_root: Path, scope: ScopeType) -> ScopePackage:
		name = package_root.name
		guidance = None
		guidance_path = package_root / 'guidance.md'
		if guidance_path.exists():
			guidance = self.document_loader.load_document(guidance_path, scope, name, ContentKind.GUIDANCE)

		examples = [self.document_loader.load_document(path, scope, name, ContentKind.EXAMPLE) for path in self.discovery.examples_for_package(package_root)]

		return ScopePackage(scope=scope, name=name, root=package_root, guidance=guidance, examples=examples)
