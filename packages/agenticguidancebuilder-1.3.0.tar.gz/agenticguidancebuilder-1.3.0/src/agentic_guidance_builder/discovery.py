from pathlib import Path

GUIDANCE_ROOT = Path('agents/guidance')
CONTENT_ROOT = Path('agents/content')
TOOLS_ROOT = Path('agents/tools')


class ContentDiscoveryService:
	def __init__(self, target: Path):
		self.target = target
		self.guidance_root = target / GUIDANCE_ROOT

	def global_guidance_path(self) -> Path:
		return self.guidance_root / 'guidance.md'

	def language_package_roots(self) -> list[Path]:
		return self._package_roots(self.guidance_root / 'languages')

	def framework_package_roots(self) -> list[Path]:
		return self._package_roots(self.guidance_root / 'frameworks')

	def project_package_root(self) -> Path:
		return self.guidance_root / 'project'

	def examples_for_package(self, package_root: Path) -> list[Path]:
		examples_root = package_root / 'examples'
		if not examples_root.exists():
			return []

		return sorted(path for path in examples_root.glob('*.md') if path.is_file())

	@staticmethod
	def _package_roots(base_directory: Path) -> list[Path]:
		if not base_directory.exists():
			return []

		return sorted(path for path in base_directory.iterdir() if path.is_dir())
