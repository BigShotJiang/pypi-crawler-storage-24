from dataclasses import dataclass
from typing import Any

import yaml


@dataclass(frozen=True)
class ParsedDocument:
	frontmatter: dict[str, Any]
	body: str


class FrontmatterParser:
	def parse(self, raw_text: str) -> ParsedDocument:
		if not raw_text.startswith('---\n'):
			return ParsedDocument(frontmatter={}, body=raw_text)

		closing_index = raw_text.find('\n---\n', 4)
		if closing_index == -1:
			return ParsedDocument(frontmatter={}, body=raw_text)

		frontmatter_text = raw_text[4:closing_index]
		body = raw_text[closing_index + 5 :]
		parsed = yaml.safe_load(frontmatter_text) or {}
		if not isinstance(parsed, dict):
			message = 'Frontmatter must be a YAML mapping'
			raise ValueError(message)

		return ParsedDocument(frontmatter=parsed, body=body)
