from pathlib import Path

from agentic_guidance_builder.adapter_rendering import render_opencode_subagent
from agentic_guidance_builder.adapters.base import BaseCodingAgentAdapter
from agentic_guidance_builder.content_projection import CanonicalContentLoader, skill_artifact
from agentic_guidance_builder.enums import ArtifactKind
from agentic_guidance_builder.models import RenderedArtifact


class OpenCodeAdapter(BaseCodingAgentAdapter):
	name = 'opencode'

	def build_artifacts(self, plan, context, renderer) -> list[RenderedArtifact]:
		guidance_artifact = renderer.render_agents_md(plan, context)
		loader = CanonicalContentLoader(renderer.target)
		artifacts: list[RenderedArtifact] = [RenderedArtifact(kind=ArtifactKind.GUIDANCE_OUTPUT, path=Path('AGENTS.md'), content=guidance_artifact.content)]
		artifacts.extend(skill_artifact(Path('.opencode/skills'), asset.name, asset.content) for asset in loader.skills() if asset.kind == 'skill')
		for asset in loader.commands():
			role = asset.frontmatter.get('role')
			if role not in {'opencode-command', 'shared-command'}:
				continue
			artifacts.append(
				RenderedArtifact(
					kind=ArtifactKind.COMMANDS_OUTPUT,
					path=Path('.opencode/commands') / f'{asset.name}.md',
					content=asset.content,
				)
			)
		agent_asset = loader.agent_by_name('context-gatherer')
		if agent_asset is not None:
			artifacts.append(
				RenderedArtifact(
					kind=ArtifactKind.AGENT_PROFILE_OUTPUT,
					path=Path('.opencode/agents/context-gatherer.md'),
					content=render_opencode_subagent(agent_asset.content),
				)
			)
		artifacts.append(
			RenderedArtifact(
				kind=ArtifactKind.AGENT_PROFILE_OUTPUT,
				path=Path('opencode.json'),
				content=loader.tool_asset_path('opencode', 'opencode.json').read_text(),
			)
		)
		return artifacts
