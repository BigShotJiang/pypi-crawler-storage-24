from abc import ABC, abstractmethod

from agentic_guidance_builder.models import RenderedArtifact


class BaseCodingAgentAdapter(ABC):
	name: str

	def validate(self, plan, context) -> list[str]:
		return []

	@abstractmethod
	def build_artifacts(self, plan, context, renderer) -> list[RenderedArtifact]:
		pass
