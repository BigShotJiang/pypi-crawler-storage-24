from pathlib import Path

from agentic_guidance_builder.adapter_rendering import body_without_frontmatter, render_copilot_agent
from agentic_guidance_builder.adapters.base import BaseCodingAgentAdapter
from agentic_guidance_builder.content_projection import CanonicalContentLoader, skill_artifact
from agentic_guidance_builder.enums import ArtifactKind
from agentic_guidance_builder.models import RenderedArtifact


class CopilotAdapter(BaseCodingAgentAdapter):
	name = 'copilot'

	def build_artifacts(self, plan, context, renderer) -> list[RenderedArtifact]:
		guidance_artifact = renderer.render_agents_md(plan, context)
		loader = CanonicalContentLoader(renderer.target)
		repository_instructions = loader.command_by_role('copilot-repository-instructions')
		python_instructions = loader.command_by_role('copilot-path-instructions')
		artifacts = [
			RenderedArtifact(
				kind=ArtifactKind.GUIDANCE_OUTPUT,
				path=Path('AGENTS.md'),
				content=guidance_artifact.content,
			),
			RenderedArtifact(
				kind=ArtifactKind.GUIDANCE_OUTPUT,
				path=Path('.github/copilot-instructions.md'),
				content=body_without_frontmatter(repository_instructions.content) if repository_instructions is not None else guidance_artifact.content,
			),
		]
		artifacts.extend(skill_artifact(Path('.github/skills'), asset.name, asset.content) for asset in loader.skills() if asset.kind == 'skill')

		if python_instructions is not None:
			artifacts.append(
				RenderedArtifact(
					kind=ArtifactKind.GUIDANCE_OUTPUT,
					path=Path('.github/instructions/python.instructions.md'),
					content=python_instructions.content,
				)
			)

		agent_asset = loader.agent_by_name('context-gatherer')
		if agent_asset is not None:
			artifacts.append(
				RenderedArtifact(
					kind=ArtifactKind.AGENT_PROFILE_OUTPUT,
					path=Path('.github/agents/context-gatherer.agent.md'),
					content=render_copilot_agent(agent_asset.content),
				)
			)

		return artifacts
