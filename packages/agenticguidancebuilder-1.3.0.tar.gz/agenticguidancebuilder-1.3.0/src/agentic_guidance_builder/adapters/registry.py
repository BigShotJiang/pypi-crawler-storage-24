from agentic_guidance_builder.adapters.agents_md import AgentsMdAdapter
from agentic_guidance_builder.adapters.base import BaseCodingAgentAdapter
from agentic_guidance_builder.adapters.copilot import CopilotAdapter
from agentic_guidance_builder.adapters.opencode import OpenCodeAdapter

_ADAPTERS: dict[str, type[BaseCodingAgentAdapter]] = {
	AgentsMdAdapter.name: AgentsMdAdapter,
	CopilotAdapter.name: CopilotAdapter,
	OpenCodeAdapter.name: OpenCodeAdapter,
}


def get_adapter(name: str) -> BaseCodingAgentAdapter:
	if name not in _ADAPTERS:
		message = f'Unsupported adapter: {name}'
		raise ValueError(message)

	return _ADAPTERS[name]()


def list_adapter_names() -> tuple[str, ...]:
	return tuple(sorted(_ADAPTERS))
