from agentic_guidance_builder.adapters.base import BaseCodingAgentAdapter


class AgentsMdAdapter(BaseCodingAgentAdapter):
	name = 'agents-md'

	def build_artifacts(self, plan, context, renderer) -> list:
		return [renderer.render_agents_md(plan, context)]
