from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from agentic_guidance_builder.enums import ArtifactKind, ContentKind, ScopeType


@dataclass(frozen=True)
class SourceDocument:
	id: str
	title: str
	description: str
	kind: ContentKind
	scope: ScopeType
	name: str
	tags: list[str]
	applies_to: list[str]
	path: Path
	frontmatter: dict[str, Any]
	raw_text: str
	body: str
	order: Optional[int] = None


@dataclass(frozen=True)
class ScopePackage:
	scope: ScopeType
	name: str
	root: Path
	guidance: Optional[SourceDocument] = None
	examples: list[SourceDocument] = field(default_factory=list)


@dataclass(frozen=True)
class BuildContext:
	project_name: str
	adapter_name: str
	output_path: Path
	include_examples: bool
	selected_languages: list[str] = field(default_factory=list)
	selected_frameworks: list[str] = field(default_factory=list)
	settings: dict[str, Any] = field(default_factory=dict)
	extra_vars: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RenderedDocument:
	source: SourceDocument
	rendered_body: str


@dataclass(frozen=True)
class RenderedScopePackage:
	scope: ScopeType
	name: str
	root: Path
	guidance: Optional[RenderedDocument] = None
	examples: list[RenderedDocument] = field(default_factory=list)


@dataclass(frozen=True)
class RenderedArtifact:
	kind: ArtifactKind
	path: Path
	content: str


@dataclass(frozen=True)
class BuildPlan:
	adapter_name: str
	output_path: Path
	global_guidance: Optional[SourceDocument]
	language_packages: list[ScopePackage]
	framework_packages: list[ScopePackage]
	project_package: Optional[ScopePackage]
	include_examples: bool


@dataclass(frozen=True)
class LoadedContent:
	global_guidance: Optional[SourceDocument]
	language_packages: list[ScopePackage]
	framework_packages: list[ScopePackage]
	project_package: Optional[ScopePackage]
