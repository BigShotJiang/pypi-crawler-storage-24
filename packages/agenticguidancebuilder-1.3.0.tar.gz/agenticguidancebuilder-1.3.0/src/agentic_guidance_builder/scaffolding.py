from pathlib import Path

from agentic_guidance_builder.discovery import CONTENT_ROOT, GUIDANCE_ROOT, TOOLS_ROOT
from agentic_guidance_builder.files import ensure_directory, FileOperation, write_optional_packaged_text_file, write_packaged_text_file, write_text_file
from agentic_guidance_builder.packaged_assets import render_packaged_text_asset
from agentic_guidance_builder.settings import SETTINGS_FILE_NAME


def _titleize(value: str) -> str:
	return value.replace('_', ' ').replace('-', ' ').title()


def _slugify(value: str) -> str:
	return value.strip().lower().replace(' ', '-').replace('_', '-')


def _render_simple_template(template: str, **values: str) -> str:
	return render_packaged_text_asset(template, values)


def _scaffold_directories(languages: tuple[str, ...], frameworks: tuple[str, ...]) -> list[Path]:
	directories = [
		Path('agents'),
		GUIDANCE_ROOT,
		GUIDANCE_ROOT / 'languages',
		GUIDANCE_ROOT / 'frameworks',
		GUIDANCE_ROOT / 'project',
		GUIDANCE_ROOT / 'project/examples',
		GUIDANCE_ROOT / 'templates',
		GUIDANCE_ROOT / 'templates/base',
		CONTENT_ROOT,
		CONTENT_ROOT / 'skills',
		CONTENT_ROOT / 'commands',
		CONTENT_ROOT / 'agents',
		TOOLS_ROOT,
		TOOLS_ROOT / 'opencode',
	]

	for language in languages:
		directories.append(GUIDANCE_ROOT / 'languages' / language)
		directories.append(GUIDANCE_ROOT / 'languages' / language / 'examples')

	for framework in frameworks:
		directories.append(GUIDANCE_ROOT / 'frameworks' / framework)
		directories.append(GUIDANCE_ROOT / 'frameworks' / framework / 'examples')

	return directories


def scaffold_repo(
	target: Path,
	project_name: str,
	languages: tuple[str, ...],
	frameworks: tuple[str, ...],
	force: bool = False,
	dry_run: bool = False,
) -> list[FileOperation]:
	operations: list[FileOperation] = []

	for directory in _scaffold_directories(languages, frameworks):
		directory_operation = ensure_directory(target / directory, dry_run=dry_run)
		if directory_operation is not None:
			operations.append(directory_operation)

	project_slug = _slugify(project_name)
	operations.append(
		write_text_file(
			target / SETTINGS_FILE_NAME,
			_render_simple_template('authored/settings/agd-settings.toml', project_name=project_name, project_slug=project_slug),
			force=force,
			dry_run=dry_run,
		)
	)
	operations.append(
		write_text_file(
			target / GUIDANCE_ROOT / 'guidance.md',
			_render_simple_template('authored/guidance/global/guidance.md'),
			force=force,
			dry_run=dry_run,
		)
	)
	_optional_packaged_operations(
		operations,
		[
			('content/skills/code-change-review.md', target / CONTENT_ROOT / 'skills/code-change-review.md'),
			('content/skills/guidance-layout-migration.md', target / CONTENT_ROOT / 'skills/guidance-layout-migration.md'),
			('content/commands/review-git-diff.md', target / CONTENT_ROOT / 'commands/review-git-diff.md'),
			('tools/opencode/opencode.json', target / TOOLS_ROOT / 'opencode/opencode.json'),
		],
		force=force,
		dry_run=dry_run,
	)

	for index, language in enumerate(languages, start=1):
		language_title = _titleize(language)
		operations.append(
			write_text_file(
				target / GUIDANCE_ROOT / 'languages' / language / 'guidance.md',
				_render_simple_template(
					'authored/guidance/package/guidance.md',
					scope='language',
					name=language,
					title=language_title,
					label=f'the {language_title} language',
					order=str(index),
				),
				force=force,
				dry_run=dry_run,
			)
		)
		operations.append(
			write_text_file(
				target / GUIDANCE_ROOT / 'languages' / language / 'examples' / 'example.md',
				_render_simple_template(
					'authored/guidance/example/example.md',
					scope='language',
					name=language,
					title=language_title,
					label=f'the {language_title} language',
					order='1',
				),
				force=force,
				dry_run=dry_run,
			)
		)

	for index, framework in enumerate(frameworks, start=1):
		framework_title = _titleize(framework)
		operations.append(
			write_text_file(
				target / GUIDANCE_ROOT / 'frameworks' / framework / 'guidance.md',
				_render_simple_template(
					'authored/guidance/package/guidance.md',
					scope='framework',
					name=framework,
					title=framework_title,
					label=f'the {framework_title} framework',
					order=str(index),
				),
				force=force,
				dry_run=dry_run,
			)
		)
		operations.append(
			write_text_file(
				target / GUIDANCE_ROOT / 'frameworks' / framework / 'examples' / 'example.md',
				_render_simple_template(
					'authored/guidance/example/example.md',
					scope='framework',
					name=framework,
					title=framework_title,
					label=f'the {framework_title} framework',
					order='1',
				),
				force=force,
				dry_run=dry_run,
			)
		)

	operations.append(
		write_text_file(
			target / GUIDANCE_ROOT / 'project/guidance.md',
			_render_simple_template('authored/guidance/project/guidance.md', project_name=project_name),
			force=force,
			dry_run=dry_run,
		)
	)
	operations.append(
		write_text_file(
			target / GUIDANCE_ROOT / 'project/examples/example.md',
			_render_simple_template(
				'authored/guidance/example/example.md',
				scope='project',
				name='project',
				title=project_name,
				label=f'the {project_name} project',
				order='1',
			),
			force=force,
			dry_run=dry_run,
		)
	)
	operations.extend(_template_operations(target, force=force, dry_run=dry_run))

	return operations


def upgrade_repo_templates(target: Path, dry_run: bool = False) -> list[FileOperation]:
	guidance_root = target / GUIDANCE_ROOT
	if not guidance_root.exists():
		message = f'Missing guidance root: {GUIDANCE_ROOT.as_posix()}. Run init first.'
		raise ValueError(message)

	operations: list[FileOperation] = []
	for directory in [guidance_root / 'templates', guidance_root / 'templates/base']:
		directory_operation = ensure_directory(directory, dry_run=dry_run)
		if directory_operation is not None:
			operations.append(directory_operation)

	operations.extend(_template_operations(target, force=True, dry_run=dry_run))
	return operations


def upgrade_repo_starter_content(target: Path, dry_run: bool = False) -> list[FileOperation]:
	content_root = target / CONTENT_ROOT
	if not content_root.exists():
		message = f'Missing content root: {CONTENT_ROOT.as_posix()}. Run init first.'
		raise ValueError(message)

	operations: list[FileOperation] = []
	for directory in [content_root / 'skills', content_root / 'commands']:
		directory_operation = ensure_directory(directory, dry_run=dry_run)
		if directory_operation is not None:
			operations.append(directory_operation)

	_optional_packaged_operations(
		operations,
		[
			('content/skills/code-change-review.md', target / CONTENT_ROOT / 'skills/code-change-review.md'),
			('content/skills/guidance-layout-migration.md', target / CONTENT_ROOT / 'skills/guidance-layout-migration.md'),
			('content/commands/review-git-diff.md', target / CONTENT_ROOT / 'commands/review-git-diff.md'),
		],
		force=True,
		dry_run=dry_run,
	)
	return operations


def upgrade_repo_tool_assets(target: Path, dry_run: bool = False) -> list[FileOperation]:
	tools_root = target / TOOLS_ROOT
	if not tools_root.exists():
		message = f'Missing tools root: {TOOLS_ROOT.as_posix()}. Run init first.'
		raise ValueError(message)

	operations: list[FileOperation] = []
	for directory in [tools_root / 'opencode']:
		directory_operation = ensure_directory(directory, dry_run=dry_run)
		if directory_operation is not None:
			operations.append(directory_operation)

	_optional_packaged_operations(
		operations,
		[
			('tools/opencode/opencode.json', target / TOOLS_ROOT / 'opencode/opencode.json'),
		],
		force=True,
		dry_run=dry_run,
	)
	return operations


def upgrade_repo_packaged_assets(target: Path, dry_run: bool = False) -> list[FileOperation]:
	operations: list[FileOperation] = []
	operations.extend(upgrade_repo_templates(target, dry_run=dry_run))
	operations.extend(upgrade_repo_starter_content(target, dry_run=dry_run))
	operations.extend(upgrade_repo_tool_assets(target, dry_run=dry_run))
	return operations


def _optional_packaged_operations(
	operations: list[FileOperation],
	resource_mappings: list[tuple[str, Path]],
	*,
	force: bool,
	dry_run: bool,
) -> None:
	for resource_path, target_path in resource_mappings:
		operation = write_optional_packaged_text_file(
			'agentic_guidance_builder.template_data',
			resource_path,
			target_path,
			force=force,
			dry_run=dry_run,
		)
		if operation is not None:
			operations.append(operation)


def _template_operations(target: Path, *, force: bool, dry_run: bool) -> list[FileOperation]:
	resource_mappings = [
		('base/agents.md.j2', target / GUIDANCE_ROOT / 'templates/base/agents.md.j2'),
		('base/macros.j2', target / GUIDANCE_ROOT / 'templates/base/macros.j2'),
		('base/section.guidance.md.j2', target / GUIDANCE_ROOT / 'templates/base/section.guidance.md.j2'),
		('base/section.examples.md.j2', target / GUIDANCE_ROOT / 'templates/base/section.examples.md.j2'),
	]
	return [
		write_packaged_text_file(
			'agentic_guidance_builder.template_data',
			resource_path,
			target_path,
			force=force,
			dry_run=dry_run,
		)
		for resource_path, target_path in resource_mappings
	]
