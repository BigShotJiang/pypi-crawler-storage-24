---
kind: skill
name: guidance-layout-migration
description: >
  Migrate legacy repository guidance into the modular guidance layout
  thoroughly, including rule classification, example extraction, gap analysis,
  and validation.
---

# Guidance Layout Migration

## When to use
- Migrating a repository from legacy guidance such as `AGENTS.md`, `agents/AGENTS.md`, or stack-specific guide files into the modular `agents/guidance/` layout
- Replacing placeholder guidance packages with real content
- Converting inline code examples into named example docs under `examples/`
- Auditing whether a prior migration dropped, duplicated, or misplaced rules
- Preparing to retire legacy guidance files without losing anything important

## What this skill should produce
- A complete inventory of legacy guidance sources and current modular guidance files
- A migration matrix showing where every legacy section, checklist item, caveat, and example will go
- Updated authored guidance files under the modular layout
- High-quality named example docs extracted from legacy inline examples
- A completeness report showing what is fully covered, partially covered, missing, or misfiled
- Validation results and an explicit list of anything intentionally deferred

## Core principles

### Completeness over speed
- Do not summarize away nuance.
- Every legacy bullet, warning, caveat, checklist item, example, and reference must end up in exactly one of these states:
  - migrated
  - intentionally archived
  - explicitly deferred with a written reason
- Silence is not acceptable. If something is not migrated, call it out.

### Classify before editing
- Build the migration map first.
- Do not start rewriting guidance until you know where each legacy section belongs.
- Most migration mistakes happen when content is moved by feel instead of by inventory.

### Keep the authored/generated boundary clear
- Treat generated `AGENTS.md` output as a build artifact.
- Update authored guidance files, not generated output.
- If the repo uses a staging area such as `new-agents/`, treat that authored tree as the source of truth until cutover.

### Separate rules from examples
- Guidance files should contain durable rules, principles, and structure.
- Example files should contain concrete code shapes, snippets, route patterns, component shapes, and test patterns.
- If a legacy section mixes both, split it.

### Keep top-level guidance generic
- Top-level guidance is for cross-stack development rules.
- Repository layout, product architecture, local tool commands, and design-system decisions belong in project guidance.
- Language and framework specifics belong in their own packages.

### Be honest about migration state
- If the repo is mid-transition, say so.
- Explicitly note which legacy docs are still source of truth.
- Update references so future migrations do not guess.

## Preflight

### Step 0: Define the scope
Before editing anything, answer these questions:
- Are you migrating the whole guidance corpus or only selected stacks?
- What authored root is the target: `agents/guidance/`, `new-agents/agents/guidance/`, or another modular tree?
- Which languages and frameworks does this repo actually use?
- Are you creating new package folders or only filling existing placeholders?
- Is the goal full cutover or an incremental migration pass?

Record the answers in one short scope statement.

Example:

```text
Scope: Migrate all legacy guidance from `agents/*.md` into `new-agents/agents/guidance/`.
Stacks in scope: Python, Django, Vue.
Deliverables: global guidance, python guidance, django guidance, vue guidance, project guidance, named example docs, coverage report.
Out of scope for this pass: .NET, Rust, and special reference docs beyond inventory and destination planning.
```

## Read First

### Legacy sources to inspect
Legacy sources vary by repo. Look for all of these, not just the obvious ones:
- Top-level guidance such as `AGENTS.md` or `agents/AGENTS.md`
- Stack guides such as `agents/django.md`, `agents/frontend.md`, `agents/rust.md`, `docs/backend-guidance.md`, or similar
- Secondary guidance such as anti-pattern catalogs, review rubrics, preserved notes, archived guidance, onboarding docs, or architecture notes
- Skill and command docs that still reference legacy guidance paths
- Any README or internal docs that effectively function as guidance, even if they are not named that way

### New-layout sources to inspect
- `agents/guidance/guidance.md`
- `agents/guidance/languages/<name>/guidance.md`
- `agents/guidance/frameworks/<name>/guidance.md`
- `agents/guidance/project/guidance.md`
- All `examples/` directories under the new guidance tree
- `agd-settings.toml` if the repo uses `agd`
- Templates or other build inputs if the repo compiles authored guidance into generated output

## Classification Rules

Use this decision model for every migrated item.

### `global`
Use for cross-stack rules that should apply broadly across the repository.

Examples:
- run relevant lint before finishing
- match existing patterns before inventing new ones
- keep control flow shallow
- never commit secrets

### `language`
Use for language-level rules that would usually apply across frameworks in that language.

Examples:
- Python import order
- Python typing conventions
- C# nullable reference type rules
- Rust logging conventions

### `framework`
Use for framework-level conventions that are reusable across repositories using that framework.

Examples:
- DRF serializer split rules
- Vue store patterns
- React Query usage conventions
- Celery task structure

### `project`
Use for repository-specific or product-specific rules.

Examples:
- local command names and validation workflows
- repository layout
- repo-specific base classes such as `ProjectBaseAPIView`
- tenant architecture, domain modeling, shell design, or product theming decisions

### `example`
Use for concrete reusable shapes.

Examples:
- `django-view.md`
- `django-testing.md`
- `vue-api-client.md`
- `react-form-dialog.md`

### `reference`
Use for audit rubrics, anti-pattern catalogs, archived guidance, or other materials that may need their own package or archive destination.

## Step-by-step migration workflow

### Step 1: Inventory the legacy corpus
Create a complete source list before migrating anything.

What to do:
1. List every legacy guidance file.
2. Group them into:
   - top-level guides
   - language or framework guides
   - project-specific notes
   - special reference docs
   - skills and commands with embedded guidance assumptions
3. Mark which files contain inline code examples.
4. Mark which files are clearly generic versus clearly repo-specific.

What to capture:
- path
- guessed scope
- notes on example density
- whether the file still looks authoritative

Example inventory table:

```markdown
| Source | Type | Scope Guess | Has Examples | Notes |
|---|---|---|---|---|
| agents/AGENTS.md | top-level | global + project mix | low | needs splitting |
| agents/django.md | stack guide | framework + project mix | high | heavy example extraction needed |
| agents/frontend.md | stack guide | framework + project mix | high | many inline examples |
| agents/antipatterns.md | reference | reference | medium | needs explicit destination |
| agents/opencode/commands/full-review.md | command | reference | no | update paths after migration |
```

### Step 2: Inventory the target tree
Understand what already exists so you do not overwrite structure blindly.

What to do:
1. List all current guidance packages and example directories.
2. Identify placeholder guidance files.
3. Identify placeholder example files such as `example.md`.
4. Note missing packages that need to be created.
5. Note validation or build tooling such as `agd`.

What to capture:
- existing package paths
- placeholder files
- packages that are still skeletal
- build or validation commands

Example target table:

```markdown
| Destination | Status | Needs Work |
|---|---|---|
| agents/guidance/guidance.md | placeholder | replace with real cross-stack rules |
| agents/guidance/languages/python/guidance.md | placeholder | migrate python rules |
| agents/guidance/frameworks/django/examples/example.md | placeholder | replace with named example docs |
| agents/guidance/project/guidance.md | partial | add repo-specific layout and architecture |
```

### Step 3: Build the migration matrix
This is the most important step. Do not skip it.

For every legacy section or example, record:
- source file
- source heading
- content type: `rule`, `example`, `checklist`, or `reference`
- generic or project-specific
- destination file
- destination section
- action: `move`, `split`, `convert-to-example`, `archive`, or `defer`

Example migration matrix:

```markdown
| Source | Section | Type | Generic? | Destination | Action |
|---|---|---|---|---|---|
| agents/AGENTS.md | Verification Required | rule | generic | agents/guidance/guidance.md -> Verification Required | move |
| agents/django.md | Example Create/List/Detail Trio | example | framework | agents/guidance/frameworks/django/examples/django-view.md | convert-to-example |
| agents/frontend.md | shared light/dark theme rule | rule | project | agents/guidance/project/guidance.md -> Frontend Product Patterns | move |
| agents/frontend.md | API client example | example | framework | agents/guidance/frameworks/vue/examples/vue-api-client.md | convert-to-example |
| agents/antipatterns.md | Generic Status Updates For Lifecycle Objects | reference/example | mixed | explicit reference destination or example set | split |
```

### Step 4: Classify mixed sections precisely
Most legacy docs are mixed. Split them instead of forcing them into one destination.

Use this question sequence:
1. Would this rule make sense in another repository using the same stack?
2. Does this rule depend on this repo's product, folder layout, brand, or domain model?
3. Is this mostly a code shape or mostly a durable rule?
4. Is the item really a reference document rather than guidance?

Example split:

```markdown
Legacy section: "Admin pages"

- "Reuse shared PrimeVue dialogs" -> framework/vue guidance
- "Use one tenant selector store for this product shell" -> project guidance
- Inline dialog submit snippet -> vue-dialog-form example
```

### Step 5: Migrate top-level guidance first
Top-level guidance sets the tone for the whole tree.

What belongs here:
- cross-stack review rules
- verification expectations
- simplicity/readability principles
- security and dependency hygiene
- general architecture and control-flow expectations

What does not belong here:
- repository layout details
- local command names unless they are the only repo-wide verification contract and clearly project-specific
- framework-specific rules such as DRF serializers or Vue stores
- product architecture such as tenant rules or shell design

What to do:
1. Replace placeholder content.
2. Keep the file rule-focused.
3. Remove project-specific details and move them to project guidance.
4. Remove inline example-heavy sections and convert them into example docs where appropriate.

### Step 6: Migrate language guidance
Move only language-level rules here.

Good candidates:
- import organization
- typing conventions
- syntax or readability conventions
- language linting and formatting rules

Bad candidates:
- Django model ordering
- Vue component patterns
- repo-specific task frameworks

What to do:
1. Gather all legacy language rules from mixed docs.
2. Move them into the correct language package.
3. Keep framework and project rules out.
4. If a rule turns out to be global rather than language-specific, move it to top-level guidance instead.

### Step 7: Migrate framework guidance
Framework guidance should explain repeatable framework patterns, not carry the whole product.

Good candidates:
- view patterns
- serializer patterns
- component patterns
- store patterns
- framework-specific testing patterns
- framework-specific error handling

Bad candidates:
- repo-specific base class names that only make sense in this one codebase
- project shell architecture
- tenant or product domain decisions

What to do:
1. Move reusable framework rules into the framework package.
2. Keep the file focused on durable patterns.
3. Extract concrete code blocks into named example docs.
4. Leave project-only caveats in the project guide.

### Step 8: Extract and upgrade examples
Do not merely move examples. Improve them.

#### Naming rules for example files
- Name by reusable concept, not by source section title.
- Prefer filenames such as:
  - `django-model.md`
  - `django-view.md`
  - `django-testing.md`
  - `vue-api-client.md`
  - `vue-dialog-form.md`
  - `python-imports.md`
- Avoid low-signal filenames such as:
  - `example.md`
  - `framework-example-02.md`
  - `misc-patterns.md`

#### Example quality bar
Every example should:
- teach one primary pattern
- explain when to use it
- show a realistic recommended shape
- call out the specific details worth noticing
- explain why the pattern helps
- avoid toy filler code when a more realistic snippet exists

#### Example structure
Use a structure like this:

```markdown
# <Example Title>

## Scenario
- What situation this example is for

## Recommended Shape

### Good Example
```<language>
<code>
```

### Things To Notice
- Specific pattern 1
- Specific pattern 2

## Why It Helps
- What this teaches and why it is reusable
```

#### Example extraction rules
- One example file per primary concern.
- If a legacy block demonstrates three different patterns, split it into multiple example docs.
- Preserve important comments and callouts when they explain why the pattern matters.
- Remove placeholder example files once real examples replace them.

#### Example split illustration

```markdown
Legacy section:
- Rule: "input and output serializers should be separate"
- Code block: input/output serializer pair
- Test snippet: serializer tests

Migration result:
- Rule -> framework django guidance
- Serializer pair -> `django-serializer.md`
- Test snippet -> `django-testing.md`
```

### Step 9: Move repository-specific rules into project guidance
Project guidance is the home for anything tied to this repo rather than the broader stack.

Common project candidates:
- repository layout
- local verification commands
- migration-state notes
- repo-specific base views or base models
- product domain rules
- shell or theming decisions
- repo-specific settings chains
- repo-specific background-task framework details

Important nuance:
- A rule can look framework-specific but still be project guidance if it depends on repo-specific names or architecture.

Example:

```markdown
"All API views inherit CompanyBaseAPIView" -> project guidance
"Output serializers set read_only_fields = fields" -> framework guidance
```

### Step 10: Handle special legacy docs explicitly
Special docs are where migrations often lose important material.

Examples of special docs:
- anti-pattern catalogs
- architecture review rubrics
- archived project notes
- preserved guidance
- review checklists

What to do:
1. Inventory them explicitly.
2. Decide whether each should become:
   - a reference document in the new tree
   - a skill
   - a set of example docs
   - archived project guidance
3. If the new layout lacks the right destination, create one or document the required follow-up.

Do not leave these out just because they are inconvenient.

### Step 11: Update references and consumers
Once the new guidance tree is more complete, update anything that still points at the old paths.

Check:
- skills
- slash commands
- review prompts
- templates
- README references
- validation or build configuration

What to do:
1. Search for legacy path references.
2. Replace them with new guidance paths where the new tree is now authoritative.
3. If a path cannot be switched yet, note that in project guidance or migration notes.

### Step 12: Run a completeness audit
This step is mandatory.

Compare every legacy source against the new tree and bucket the results into:
- fully covered
- partially covered
- missing
- probably misfiled

What to check carefully:
- dropped caveats
- warnings and exceptions
- detailed checklist items
- minor but important wording around permissions or validation
- example blocks that never made it into `examples/`
- repo-specific details that accidentally stayed in global or framework guidance

Example coverage report:

```markdown
## Coverage Check

### Fully Covered
- `agents/frontend.md` -> API client rules, stores, casing discipline

### Partially Covered
- `agents/django.md` -> testing guidance migrated, but cron scheduling note still missing

### Missing
- `agents/antipatterns.md` -> no destination created yet

### Probably Misfiled
- repo-specific base-view rule currently sits in framework guidance but belongs in project guidance
```

Do not mark the migration complete until the missing and misfiled buckets are either resolved or explicitly deferred.

### Step 13: Validate the new tree
If the repo uses `agd`, run:
- `agd list`
- `agd validate`
- `agd build --dry-run --adapter agents-md`

If the repo uses different tooling, run the equivalent discovery, validation, and dry-run build checks.

Also do these manual checks:
- review the diff for accidental deletions
- confirm new example files are discovered
- confirm placeholder example files were removed or intentionally kept
- search for stale old-path references

## Generic examples of good classification

### Example 1: top-level versus project

```markdown
Legacy rule: "Always run the relevant linter before finishing work."
Destination: global guidance
Why: this is a cross-stack development rule.

Legacy rule: "Use `make api-test` and `pnpm lint:web` in this repository."
Destination: project guidance
Why: command names are repo-specific.
```

### Example 2: language versus framework

```markdown
Legacy rule: "Python imports should be standard library, third-party, framework, project-local."
Destination: language/python guidance
Why: this is a Python convention, not a Django convention.

Legacy rule: "Split DRF input and output serializers when read and write concerns differ."
Destination: framework/django guidance
Why: this is a Django/DRF pattern.
```

### Example 3: framework versus project

```markdown
Legacy rule: "Use a shared API client as the only place Axios is imported."
Destination: framework/vue guidance
Why: this is a reusable frontend framework pattern.

Legacy rule: "The operator shell in this product uses a neutral palette and supports only light/dark themes."
Destination: project guidance
Why: this is a repository product decision.
```

### Example 4: guidance versus example

```markdown
Legacy rule: "Use focused self-contained form dialogs."
Destination: framework guidance

Legacy code block showing a complete dialog submit pattern.
Destination: `vue-dialog-form.md`
Why: the rule and the code shape should not stay fused.
```

### Example 5: mixed section split

```markdown
Legacy section: "Django API Views"

- "All endpoints must scope data to the current tenant" -> project or framework, depending on whether tenancy is repo-specific
- "Use `get_object_or_404` for detail lookups" -> framework/django guidance
- CRUD code block -> `django-view.md`
- API test code block -> `django-testing.md`
```

## Common failure modes
- Copying `AGENTS.md` wholesale into top-level guidance
- Leaving project-specific content in global guidance
- Leaving framework-specific rules in language guidance
- Dropping small caveats during summarization
- Leaving examples embedded inline in rule docs
- Replacing placeholder `example.md` with one generic example instead of several real ones
- Forgetting special legacy docs such as anti-pattern catalogs or review rubrics
- Updating guidance but not the skills and commands that read it
- Declaring the migration complete without a legacy-versus-new comparison
- Declaring the migration complete without validation and dry-run build checks

## Deterministic checklist
- [ ] Scope defined
- [ ] Legacy guidance corpus inventoried
- [ ] New guidance tree inventoried
- [ ] Placeholder guidance and example files identified
- [ ] Migration matrix created
- [ ] Global guidance migrated and kept generic
- [ ] Language guidance packages migrated
- [ ] Framework guidance packages migrated
- [ ] Named example docs created for inline legacy examples
- [ ] Placeholder example files removed or intentionally retained
- [ ] Project-specific rules moved into project guidance
- [ ] Special legacy docs handled explicitly
- [ ] Skills, commands, and references reviewed for old-path usage
- [ ] Coverage audit completed
- [ ] Validation commands run
- [ ] Remaining unmigrated items listed explicitly

## Output format

### Scope
- authored root and legacy root
- languages and frameworks in scope
- full versus partial migration

### Inventory
- legacy docs reviewed
- new docs reviewed
- placeholder files found

### Migration map
For each major legacy file include:
- source path
- destination paths
- examples created
- project-specific content moved out
- anything deferred

### Coverage check
- fully covered
- partially covered
- missing
- probably misfiled

### Validation
- commands run
- results
- unresolved issues

### Remaining work
- next packages to migrate
- references still pointing to legacy guidance
- legacy docs still acting as source of truth

## Success criteria
A migration is successful when:
- the top-level guide is generic and clean
- language and framework rules live in the right packages
- project-specific rules are gathered in project guidance
- inline legacy examples have been converted into named example docs
- no legacy section is silently lost
- stale placeholder example files are gone or explicitly justified
- validation passes
- future contributors can tell exactly which docs are authoritative

## Living document note
- If you discover better heuristics for classifying rules, splitting examples, or validating completeness, update this skill so future guidance migrations get more reliable over time.
