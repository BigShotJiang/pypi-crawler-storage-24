---
kind: skill
name: code-change-review
description: >
  Review a diff or scoped code area against repository guidance, examples,
  and established implementation patterns.
---

# Code Change Review

## When to use
- Reviewing a branch diff, PR, file list, feature folder, or full repository
- Checking whether code matches the rules in `agents/guidance/`
- Verifying that new code follows the examples and established patterns already in the repo

## Goals
- Read the relevant guidance before judging the code
- Cross-check changed code against both rules and examples
- Compare the implementation to the closest existing in-repo pattern
- Report only concrete, verifiable findings with the simplest fix

## Required scope handling
- State the exact scope first: diff, files, folder, feature, or full repo
- If the scope is a diff, read adjacent files when needed to understand layering and behavior
- If anything is skipped, list it explicitly in the final output

## Review workflow

### 1. Gather the rules
Read the guidance source of truth before making claims:
- `agents/guidance/guidance.md`
- relevant `agents/guidance/languages/<name>/guidance.md`
- relevant `agents/guidance/frameworks/<name>/guidance.md`
- `agents/guidance/project/guidance.md`
- relevant files in nearby `examples/`

### 2. Build a review map
For every relevant guidance or example file, record:
- file path
- why it applies
- one verdict: `matched`, `partially_matched`, `not_matched`, or `not_applicable`

### 3. Inspect the code
- Review all in-scope changed files
- Read related modules when responsibilities, layering, or behavior are unclear
- Compare the implementation to the closest existing in-repo pattern before flagging a mismatch

### 4. Run the checklist
Check the code for:
- correctness and obvious bugs
- guidance compliance
- example alignment
- architecture and layering
- simplicity and readability
- missing verification or weak test coverage

### 5. Verify each finding
- Tie every finding to a specific file
- Tie every finding to a guidance rule, example, or established pattern
- Suggest the simplest fix that would resolve it
- Prefer 3-7 strong findings over a long list of weak ones

## Deterministic checklist
- [ ] Scope stated clearly
- [ ] Relevant guidance docs reviewed
- [ ] Relevant example docs reviewed
- [ ] Existing implementation patterns compared
- [ ] Findings tied to file references
- [ ] Findings tied to a rule, example, or pattern
- [ ] Verification status reported
- [ ] Blind spots reported

## Output format

### Scope
- What was reviewed
- What was skipped or only lightly checked

### Guidance And Examples Reviewed
For each relevant file include:
- file path
- applicability
- verdict

### Findings
For each finding include:
- severity
- file reference
- issue
- violated rule, example, or pattern
- simplest fix

### Verification
- What was checked
- What was not verified

### Blind Spots
- Anything that might affect confidence in the review
