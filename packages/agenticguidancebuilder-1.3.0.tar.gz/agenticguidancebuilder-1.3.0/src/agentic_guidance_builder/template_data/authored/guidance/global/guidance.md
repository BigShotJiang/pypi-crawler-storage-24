---
id: global-guidance
title: Global Guidance
description: Repository-wide rules that apply across all work.
kind: guidance
scope: global
name: global
tags:
  - global
applies_to: []
status: active
order: 0
---

# Global Guidance

## Purpose

- Capture durable rules that apply across the repository.
- Keep this file short, stable, and easy to scan.

## Expectations & Best Practices

### Match Existing Patterns

- Add high-signal guidance that should affect future work.
- Prefer direct, explicit code over clever abstractions.

### Verification

- Note the default verification steps contributors should run.
- Call out required lint, test, or typecheck commands when they are stable.

### Living Notes

- Add short bullets for active repository conventions.
- Remove outdated rules instead of layering conflicting notes.

## Consistency Checklist

### Repository

- Guidance is durable, direct, and easy to scan.
- Verification expectations are explicit.
- Repository-specific rules live here instead of scattered across files.
