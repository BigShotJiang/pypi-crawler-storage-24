---
id: {{ scope }}-{{ name }}-guidance
title: {{ title }} Guidance
description: Durable guidance for {{ label }}.
kind: guidance
scope: {{ scope }}
name: {{ name }}
tags:
  - {{ scope }}
  - {{ name }}
applies_to:
  - {{ name }}
status: active
order: {{ order }}
---

# {{ title }} Guidance

## Purpose

- Explain how work in this area should be structured.
- Keep the guidance focused on repeated patterns and defaults.

## Key Patterns

### Organization

- Add a few bullets describing the preferred structure.
- Call out naming, data flow, or layering conventions that matter.

### Implementation

- Add concise rules that future changes should follow.
- Include only the guidance that is specific to this package.

### Verification

- Add the small set of checks that usually matter for this area.
- Keep verification concrete and easy to run.

## Consistency Checklist

### {{ title }}

- Structure matches similar work already in the repository.
- Rules are specific to this package and not duplicated from global guidance.
- Verification expectations are clear.
