---
id: {{ scope }}-{{ name }}-example-01
title: {{ title }} Example
description: Concrete example content for {{ label }}.
kind: example
scope: {{ scope }}
name: {{ name }}
tags:
  - example
  - {{ name }}
applies_to:
  - {{ name }}
status: active
order: {{ order }}
---

# {{ title }} Example

## Scenario

- Describe the situation this example is meant to clarify.

## Recommended Shape

### Good Example

- Add a small before/after snippet, outline, or example structure.
- Keep the example minimal and easy to copy from.

### Things To Notice

- Call out the specific pattern the reader should reuse.
- Keep the notes short and tied to the example above.

## Why It Helps

- Explain what this example is teaching or reinforcing.
