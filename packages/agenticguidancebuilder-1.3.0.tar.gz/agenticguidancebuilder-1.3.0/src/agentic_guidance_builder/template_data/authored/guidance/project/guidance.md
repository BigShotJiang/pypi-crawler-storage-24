---
id: project-guidance
title: {{ project_name }} Guidance
description: Project-specific guidance for this repository.
kind: guidance
scope: project
name: project
tags:
  - project
applies_to:
  - project
status: active
order: 0
---

# {{ project_name }} Guidance

## Purpose

- Capture the project-specific rules that do not belong in a shared stack guide.
- Keep this focused on repository decisions, not general language advice.

## Local Conventions

### Organization

- Add bullets for naming, folders, generated files, and runtime expectations.
- Note any conventions that differ from the defaults in global guidance.

### Verification

- Record project-specific checks or workflows that should run before completion.

## Open Questions

- Track unresolved structural questions until they become stable enough for a rule.

## Consistency Checklist

### Project

- Project-specific rules are captured here instead of in stack-specific guides.
- Generated files, runtime assets, and repository layout decisions are explicit.
