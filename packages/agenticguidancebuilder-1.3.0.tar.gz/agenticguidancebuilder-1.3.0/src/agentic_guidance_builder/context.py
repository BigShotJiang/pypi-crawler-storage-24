from pathlib import Path
from typing import Optional


def split_csv(values: Optional[str]) -> list[str]:
	if values is None:
		return []

	items: list[str] = []
	for value in values.split(','):
		normalized_value = value.strip().lower()
		if normalized_value:
			items.append(normalized_value)

	return items


def normalize_choices(values: Optional[str]) -> tuple[str, ...]:
	split_values = split_csv(values)
	if not split_values:
		return ()

	normalized_values: list[str] = []
	for value in split_values:
		if value not in normalized_values:
			normalized_values.append(value)

	return tuple(normalized_values)


def default_project_name(target: Path) -> str:
	project_name = target.resolve().name.strip()
	if project_name:
		return project_name
	return 'project'
