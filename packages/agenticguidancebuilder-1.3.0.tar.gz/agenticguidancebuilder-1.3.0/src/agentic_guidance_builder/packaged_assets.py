from importlib import resources

ASSET_PACKAGE = 'agentic_guidance_builder.template_data'


def render_packaged_text_asset(resource_path: str, replacements: dict[str, str]) -> str:
	content = resources.files(ASSET_PACKAGE).joinpath(resource_path).read_text()
	for key, value in replacements.items():
		content = content.replace(f'{{{{ {key} }}}}', value)
	return content
