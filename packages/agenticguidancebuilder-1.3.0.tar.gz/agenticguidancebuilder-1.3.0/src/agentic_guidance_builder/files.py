from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class FileOperation:
	action: str
	path: Path


def ensure_directory(path: Path, dry_run: bool = False) -> Optional[FileOperation]:
	if path.exists():
		return None

	if dry_run:
		return FileOperation(action='would_create_dir', path=path)

	path.mkdir(parents=True, exist_ok=True)
	return FileOperation(action='created_dir', path=path)


def write_text_file(path: Path, content: str, force: bool = False, dry_run: bool = False) -> FileOperation:
	if path.exists():
		existing_content = path.read_text()
		if existing_content == content:
			return FileOperation(action='unchanged', path=path)
		if not force:
			return FileOperation(action='skipped', path=path)
		if dry_run:
			return FileOperation(action='would_update', path=path)

		path.write_text(content)
		return FileOperation(action='updated', path=path)

	if dry_run:
		return FileOperation(action='would_create', path=path)

	path.parent.mkdir(parents=True, exist_ok=True)
	path.write_text(content)
	return FileOperation(action='created', path=path)


def display_path(path: Path, root: Path) -> str:
	try:
		return path.relative_to(root).as_posix()
	except ValueError:
		return path.as_posix()


def write_packaged_text_file(package: str, resource_path: str, target_path: Path, force: bool = False, dry_run: bool = False) -> FileOperation:
	content = resources.files(package).joinpath(resource_path).read_text()
	return write_text_file(target_path, content, force=force, dry_run=dry_run)


def write_optional_packaged_text_file(package: str, resource_path: str, target_path: Path, force: bool = False, dry_run: bool = False) -> Optional[FileOperation]:
	resource = resources.files(package).joinpath(resource_path)
	if not resource.is_file():
		return None

	content = resource.read_text()
	return write_text_file(target_path, content, force=force, dry_run=dry_run)


def write_rendered_artifact(artifact, target: Path, dry_run: bool = False) -> list[FileOperation]:
	output_path = artifact.path
	if not output_path.is_absolute():
		output_path = target / output_path

	return [write_text_file(output_path, artifact.content, force=True, dry_run=dry_run)]
