def info(message: str) -> None:
	print(f'INFO: {message}')


def success(message: str) -> None:
	print(f'OK: {message}')


def warning(message: str) -> None:
	print(f'WARN: {message}')


def error(message: str) -> None:
	print(f'ERROR: {message}')
