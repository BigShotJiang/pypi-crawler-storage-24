from pathlib import Path
from typing import Optional

from agentic_guidance_builder.adapters.registry import get_adapter
from agentic_guidance_builder.context import default_project_name
from agentic_guidance_builder.files import FileOperation, write_rendered_artifact
from agentic_guidance_builder.loading import PackageLoader
from agentic_guidance_builder.models import BuildContext
from agentic_guidance_builder.planning import BuildPlanner
from agentic_guidance_builder.rendering import TemplateRenderer
from agentic_guidance_builder.settings import (
	load_guidance_settings,
	resolve_build_output,
	resolve_include_examples,
	resolve_project_name,
	resolve_vars,
)


def build_target(
	target: Path,
	adapter_name: str,
	project_name: Optional[str],
	output_path: Optional[Path],
	include_examples: Optional[bool],
	selected_languages: list[str],
	selected_frameworks: list[str],
	dry_run: bool = False,
) -> list[FileOperation]:
	loaded_content = PackageLoader(target).load()
	settings = load_guidance_settings(target)
	resolved_project_name = project_name or _resolve_project_name(target, loaded_content.project_package, settings)
	resolved_output_path = output_path or resolve_build_output(settings) or Path('AGENTS.md')
	default_include_examples = resolve_include_examples(settings)
	resolved_include_examples = include_examples
	if resolved_include_examples is None:
		resolved_include_examples = default_include_examples
	if resolved_include_examples is None:
		resolved_include_examples = False
	settings_vars = resolve_vars(settings)

	context = BuildContext(
		project_name=resolved_project_name,
		adapter_name=adapter_name,
		output_path=resolved_output_path,
		include_examples=resolved_include_examples,
		selected_languages=selected_languages,
		selected_frameworks=selected_frameworks,
		settings=settings,
		extra_vars={key: value for key, value in settings_vars.items()},
	)
	plan = BuildPlanner().create_plan(loaded_content, context)
	renderer = TemplateRenderer(target)
	adapter = get_adapter(adapter_name)
	adapter_errors = adapter.validate(plan, context)
	if adapter_errors:
		message = '; '.join(adapter_errors)
		raise ValueError(message)

	operations = []
	for artifact in adapter.build_artifacts(plan, context, renderer):
		operations.extend(write_rendered_artifact(artifact, target, dry_run=dry_run))

	return operations


def _resolve_project_name(target: Path, project_package, settings: dict[str, object]) -> str:
	settings_project_name = resolve_project_name(settings)
	if settings_project_name is not None:
		return settings_project_name

	if project_package is not None and project_package.guidance is not None:
		title = project_package.guidance.title.strip()
		if title.endswith(' Guidance'):
			return title.removesuffix(' Guidance').strip()
		if title:
			return title

	return default_project_name(target)
