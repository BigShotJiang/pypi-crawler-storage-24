from enum import StrEnum


class ScopeType(StrEnum):
	GLOBAL = 'global'
	LANGUAGE = 'language'
	FRAMEWORK = 'framework'
	PROJECT = 'project'


class ContentKind(StrEnum):
	GUIDANCE = 'guidance'
	EXAMPLE = 'example'


class ArtifactKind(StrEnum):
	GUIDANCE_OUTPUT = 'guidance_output'
	SKILLS_OUTPUT = 'skills_output'
	COMMANDS_OUTPUT = 'commands_output'
	AGENT_PROFILE_OUTPUT = 'agent_profile_output'
