from agentic_guidance_builder.cli import main

if __name__ == '__main__':
	raise SystemExit(main())
