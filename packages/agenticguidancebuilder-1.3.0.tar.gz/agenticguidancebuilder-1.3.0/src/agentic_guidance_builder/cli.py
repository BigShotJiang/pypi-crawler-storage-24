import argparse
from pathlib import Path
from typing import Optional, Sequence

from agentic_guidance_builder.adapters.registry import list_adapter_names
from agentic_guidance_builder.building import build_target
from agentic_guidance_builder.console import error, info, success, warning
from agentic_guidance_builder.context import default_project_name, normalize_choices
from agentic_guidance_builder.files import display_path, FileOperation
from agentic_guidance_builder.loading import PackageLoader
from agentic_guidance_builder.reporting import format_loaded_content, format_validation_report
from agentic_guidance_builder.scaffolding import (
	scaffold_repo,
	upgrade_repo_packaged_assets,
	upgrade_repo_starter_content,
	upgrade_repo_templates,
	upgrade_repo_tool_assets,
)
from agentic_guidance_builder.validation import ValidationService


def _build_parser() -> argparse.ArgumentParser:
	parser = argparse.ArgumentParser(description='Scaffold and compile modular agent guidance into AGENTS.md.')
	subparsers = parser.add_subparsers(dest='command', required=True)

	init_parser = subparsers.add_parser('init', help='Create canonical agents guidance files.')
	init_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to initialize.')
	init_parser.add_argument('--project-name', help='Human-readable project name for seeded templates.')
	init_parser.add_argument('--languages', help='Comma-separated language packages to scaffold.')
	init_parser.add_argument('--frameworks', help='Comma-separated framework packages to scaffold.')
	init_parser.add_argument('--force', action='store_true', help='Overwrite scaffolded canonical files when they already exist.')
	init_parser.add_argument('--dry-run', action='store_true', help='Preview file changes without writing them.')

	build_parser = subparsers.add_parser('build', help='Build AGENTS.md from authored guidance content.')
	build_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to build.')
	build_parser.add_argument('--adapter', choices=list_adapter_names(), default='agents-md', help='Output adapter to build.')
	build_parser.add_argument('--project-name', help='Human-readable project name for compiled output.')
	build_parser.add_argument('--output', type=Path, help='Output file path relative to the target root.')
	build_parser.add_argument('--include-examples', action='store_true', default=None, help='Include example documents in the compiled output.')
	build_parser.add_argument('--dry-run', action='store_true', help='Preview build work without writing files.')
	build_parser.add_argument('--languages', help='Comma-separated language packages to include in the build.')
	build_parser.add_argument('--frameworks', help='Comma-separated framework packages to include in the build.')

	validate_parser = subparsers.add_parser('validate', help='Validate authored guidance content.')
	validate_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to validate.')

	list_parser = subparsers.add_parser('list', help='List discovered guidance content.')
	list_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to inspect.')

	upgrade_parser = subparsers.add_parser('upgrade', help='Refresh packaged templates and starter assets in an existing agents tree.')
	upgrade_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to upgrade.')
	upgrade_parser.add_argument('--dry-run', action='store_true', help='Preview upgrade changes without writing them.')
	upgrade_parser.add_argument('--templates', action='store_true', help='Refresh packaged base templates.')
	upgrade_parser.add_argument('--content', action='store_true', help='Refresh packaged starter skills and commands.')
	upgrade_parser.add_argument('--tools', action='store_true', help='Refresh packaged tool bootstrap assets.')

	upgrade_templates_parser = subparsers.add_parser('upgrade-templates', help='Refresh packaged base templates in an existing agents tree.')
	upgrade_templates_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to upgrade.')
	upgrade_templates_parser.add_argument('--dry-run', action='store_true', help='Preview template changes without writing them.')

	upgrade_content_parser = subparsers.add_parser('upgrade-content', help='Refresh packaged starter skills and commands in an existing agents tree.')
	upgrade_content_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to upgrade.')
	upgrade_content_parser.add_argument('--dry-run', action='store_true', help='Preview starter content changes without writing them.')

	upgrade_tools_parser = subparsers.add_parser('upgrade-tools', help='Refresh packaged tool bootstrap assets in an existing agents tree.')
	upgrade_tools_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to upgrade.')
	upgrade_tools_parser.add_argument('--dry-run', action='store_true', help='Preview tool asset changes without writing them.')

	upgrade_all_parser = subparsers.add_parser('upgrade-all', help='Refresh all packaged templates and starter assets in an existing agents tree.')
	upgrade_all_parser.add_argument('--target', type=Path, default=Path.cwd(), help='Repository root to upgrade.')
	upgrade_all_parser.add_argument('--dry-run', action='store_true', help='Preview all packaged asset changes without writing them.')

	return parser


def _print_operations(operations: Sequence[FileOperation], target: Path) -> None:
	if not operations:
		info('No changes required.')
		return

	for operation in operations:
		message = f'{operation.action}: {display_path(operation.path, target)}'
		if operation.action.startswith('would_'):
			info(message)
			continue
		if operation.action in ('skipped', 'unchanged'):
			warning(message)
			continue
		success(message)


def _handle_init(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Initializing guidance scaffold in {target.as_posix()}')
	project_name = args.project_name or default_project_name(target)
	languages = normalize_choices(args.languages)
	frameworks = normalize_choices(args.frameworks)
	operations = scaffold_repo(
		target,
		project_name=project_name,
		languages=languages,
		frameworks=frameworks,
		force=args.force,
		dry_run=args.dry_run,
	)
	_print_operations(operations, target)
	success('Init complete.')
	return 0


def _handle_build(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Building guidance artifacts in {target.as_posix()}')
	languages = list(normalize_choices(args.languages))
	frameworks = list(normalize_choices(args.frameworks))
	operations = build_target(
		target=target,
		adapter_name=args.adapter,
		project_name=args.project_name,
		output_path=args.output,
		include_examples=args.include_examples,
		selected_languages=languages,
		selected_frameworks=frameworks,
		dry_run=args.dry_run,
	)
	_print_operations(operations, target)
	success('Build complete.')
	return 0


def _handle_validate(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Validating guidance in {target.as_posix()}')
	report = ValidationService(target).validate()
	print(format_validation_report(report))
	if report.ok:
		success('Validation complete.')
		return 0
	error('Validation failed.')
	return 1


def _handle_list(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Listing guidance content in {target.as_posix()}')
	loaded_content = PackageLoader(target).load()
	print(format_loaded_content(loaded_content, target))
	success('List complete.')
	return 0


def _handle_upgrade(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	selected_scopes = _selected_upgrade_scopes(args)
	info(f'Upgrading packaged assets in {target.as_posix()}')
	operations: list[FileOperation] = []
	for scope_name in selected_scopes:
		operations.extend(_upgrade_operations_for_scope(scope_name, target, dry_run=args.dry_run))
	_print_operations(operations, target)
	success('Packaged asset upgrade complete.')
	return 0


def _handle_upgrade_templates(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Upgrading guidance templates in {target.as_posix()}')
	operations = upgrade_repo_templates(target, dry_run=args.dry_run)
	_print_operations(operations, target)
	success('Template upgrade complete.')
	return 0


def _handle_upgrade_content(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Upgrading starter content in {target.as_posix()}')
	operations = upgrade_repo_starter_content(target, dry_run=args.dry_run)
	_print_operations(operations, target)
	success('Starter content upgrade complete.')
	return 0


def _handle_upgrade_tools(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Upgrading tool assets in {target.as_posix()}')
	operations = upgrade_repo_tool_assets(target, dry_run=args.dry_run)
	_print_operations(operations, target)
	success('Tool asset upgrade complete.')
	return 0


def _handle_upgrade_all(args: argparse.Namespace) -> int:
	target = args.target.resolve()
	info(f'Upgrading packaged assets in {target.as_posix()}')
	operations = upgrade_repo_packaged_assets(target, dry_run=args.dry_run)
	_print_operations(operations, target)
	success('Packaged asset upgrade complete.')
	return 0


def _selected_upgrade_scopes(args: argparse.Namespace) -> list[str]:
	selected_scopes: list[str] = []
	if args.templates:
		selected_scopes.append('templates')
	if args.content:
		selected_scopes.append('content')
	if args.tools:
		selected_scopes.append('tools')
	if selected_scopes:
		return selected_scopes
	return ['templates', 'content', 'tools']


def _upgrade_operations_for_scope(scope_name: str, target: Path, *, dry_run: bool) -> list[FileOperation]:
	if scope_name == 'templates':
		return upgrade_repo_templates(target, dry_run=dry_run)
	if scope_name == 'content':
		return upgrade_repo_starter_content(target, dry_run=dry_run)
	if scope_name == 'tools':
		return upgrade_repo_tool_assets(target, dry_run=dry_run)

	message = f'Unsupported upgrade scope: {scope_name}'
	raise ValueError(message)


def main(argv: Optional[Sequence[str]] = None) -> int:
	try:
		args = _build_parser().parse_args(argv)
		if args.command == 'init':
			return _handle_init(args)
		if args.command == 'build':
			return _handle_build(args)
		if args.command == 'validate':
			return _handle_validate(args)
		if args.command == 'list':
			return _handle_list(args)
		if args.command == 'upgrade':
			return _handle_upgrade(args)
		if args.command == 'upgrade-templates':
			return _handle_upgrade_templates(args)
		if args.command == 'upgrade-content':
			return _handle_upgrade_content(args)
		if args.command == 'upgrade-tools':
			return _handle_upgrade_tools(args)
		if args.command == 'upgrade-all':
			return _handle_upgrade_all(args)

		message = 'Unsupported command'
		raise ValueError(message)
	except ValueError as exc:
		error(str(exc))
		return 1
