from dataclasses import dataclass
from pathlib import Path
from typing import Any

from agentic_guidance_builder.discovery import CONTENT_ROOT, TOOLS_ROOT
from agentic_guidance_builder.enums import ArtifactKind
from agentic_guidance_builder.models import RenderedArtifact
from agentic_guidance_builder.parsing import FrontmatterParser


@dataclass(frozen=True)
class CanonicalAsset:
	kind: str
	name: str
	description: str
	path: Path
	content: str
	body: str
	frontmatter: dict[str, Any]


class CanonicalContentLoader:
	def __init__(self, target: Path):
		self.target = target
		self.skills_root = target / CONTENT_ROOT / 'skills'
		self.commands_root = target / CONTENT_ROOT / 'commands'
		self.agents_root = target / CONTENT_ROOT / 'agents'
		self.frontmatter_parser = FrontmatterParser()

	def skills(self) -> list[CanonicalAsset]:
		return [self._load(path, default_kind='skill') for path in self._files(self.skills_root)]

	def commands(self) -> list[CanonicalAsset]:
		return [self._load(path, default_kind='command') for path in self._files(self.commands_root)]

	def agents(self) -> list[CanonicalAsset]:
		return [self._load(path, default_kind='agent') for path in self._files(self.agents_root)]

	def agent_by_name(self, name: str) -> CanonicalAsset | None:
		for asset in self.agents():
			if asset.name == name:
				return asset
		return None

	def command_by_role(self, role: str) -> CanonicalAsset | None:
		for asset in self.commands():
			if asset.frontmatter.get('role') == role:
				return asset
		return None

	def _load(self, path: Path, default_kind: str) -> CanonicalAsset:
		content = path.read_text()
		parsed = self.frontmatter_parser.parse(content)
		frontmatter = parsed.frontmatter
		kind = str(frontmatter.get('kind') or default_kind)
		name = str(frontmatter.get('name') or path.stem)
		description = str(frontmatter.get('description') or '')
		body = parsed.body.lstrip('\n')

		return CanonicalAsset(
			kind=kind,
			name=name,
			description=description,
			path=path,
			content=content,
			body=body,
			frontmatter=frontmatter,
		)

	@staticmethod
	def _files(root: Path) -> list[Path]:
		if not root.exists():
			return []

		return sorted(path for path in root.glob('*.md') if path.is_file())

	def tool_asset_path(self, *parts: str) -> Path:
		return self.target / TOOLS_ROOT.joinpath(*parts)


def skill_artifact(destination_root: Path, source_name: str, content: str) -> RenderedArtifact:
	return RenderedArtifact(
		kind=ArtifactKind.SKILLS_OUTPUT,
		path=destination_root / source_name / 'SKILL.md',
		content=content,
	)
