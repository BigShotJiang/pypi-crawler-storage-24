from agentic_guidance_builder.cli import main
from agentic_guidance_builder.validation import ValidationService


def test_validation_detects_duplicate_ids(tmp_path):
	(tmp_path / 'agents/guidance/languages/python').mkdir(parents=True)
	(tmp_path / 'agents/guidance/frameworks/django').mkdir(parents=True)
	(tmp_path / 'agents/guidance/guidance.md').write_text('---\nid: duplicate\n---\n# Global Guidance\n')
	(tmp_path / 'agents/guidance/languages/python/guidance.md').write_text('---\nid: duplicate\n---\n# Python Guidance\n')
	(tmp_path / 'agents/guidance/frameworks/django/guidance.md').write_text('# Django Guidance\n')

	report = ValidationService(tmp_path).validate()

	assert report.ok is False
	assert 'Duplicate document id: duplicate' in report.errors


def test_validation_detects_negative_order(tmp_path):
	(tmp_path / 'agents/guidance/project').mkdir(parents=True)
	(tmp_path / 'agents/guidance/guidance.md').write_text('# Global Guidance\n')
	(tmp_path / 'agents/guidance/project/guidance.md').write_text('---\norder: -1\n---\n# Project Guidance\n')

	report = ValidationService(tmp_path).validate()

	assert report.ok is False
	assert any('Frontmatter order must be non-negative' in error for error in report.errors)


def test_validate_cli_groups_errors(tmp_path, capsys):
	(tmp_path / 'agents/guidance/languages/python').mkdir(parents=True)

	result = main(['validate', '--target', str(tmp_path)])
	output = capsys.readouterr().out

	assert result == 1
	assert 'Validation failed.' in output
	assert 'Errors (' in output
