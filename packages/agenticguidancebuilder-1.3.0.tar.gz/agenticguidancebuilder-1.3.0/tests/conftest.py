import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = PROJECT_ROOT / 'src'

if str(SOURCE_ROOT) not in sys.path:
	sys.path.insert(0, str(SOURCE_ROOT))


@pytest.fixture
def scaffolded_repo(tmp_path):
	root = tmp_path
	(root / 'agents/guidance/languages/python/examples').mkdir(parents=True)
	(root / 'agents/guidance/frameworks/django/examples').mkdir(parents=True)
	(root / 'agents/guidance/project/examples').mkdir(parents=True)
	(root / 'agents/guidance/templates/base').mkdir(parents=True)
	(root / 'agents/content/skills').mkdir(parents=True)
	(root / 'agents/content/commands').mkdir(parents=True)
	(root / 'agents/content/agents').mkdir(parents=True)
	(root / 'agents/tools/opencode').mkdir(parents=True)
	(root / 'agents/guidance/guidance.md').write_text('# Global Guidance\n')
	(root / 'agents/guidance/languages/python/guidance.md').write_text('# Python Guidance\n')
	(root / 'agents/guidance/languages/python/examples/example.md').write_text('# Python Example\n')
	(root / 'agents/guidance/frameworks/django/guidance.md').write_text('# Django Guidance\n')
	(root / 'agents/guidance/frameworks/django/examples/example.md').write_text('# Django Example\n')
	(root / 'agents/guidance/project/guidance.md').write_text('# Project Guidance\n')
	(root / 'agents/guidance/project/examples/example.md').write_text('# Project Example\n')
	(root / 'agents/content/skills/code-change-review.md').write_text('---\nkind: skill\nname: code-change-review\ndescription: Review code changes.\n---\n')
	(root / 'agents/content/agents/context-gatherer.md').write_text('---\nkind: agent\nname: context-gatherer\ndescription: Gather context.\n---\nGather context.\n')
	(root / 'agents/content/commands/full-review.md').write_text('---\nkind: command\nrole: shared-command\ndescription: Full review\n---\nReview changes.\n')
	(root / 'agents/content/commands/review-git-diff.md').write_text('---\nkind: command\nrole: opencode-command\ndescription: Review diff\nagent: build\n---\nReview diff.\n')
	(root / 'agents/content/commands/create-command.md').write_text('---\nkind: command\nrole: opencode-command\ndescription: Create command\n---\nCreate command.\n')
	(root / 'agents/content/commands/copilot-review.md').write_text('---\nkind: command\nrole: opencode-command\ndescription: Copilot review\n---\nReview Copilot comments.\n')
	(root / 'agents/content/commands/repository-instructions.md').write_text('---\nkind: command\nrole: copilot-repository-instructions\ndescription: Repository instructions\n---\n\n# Repository Instructions\n')
	(root / 'agents/content/commands/python-instructions.md').write_text('---\nkind: command\nrole: copilot-path-instructions\napplyTo: "src/**/*.py"\n---\nUse Python rules.\n')
	(root / 'agents/tools/opencode/opencode.json').write_text('{\n  "$schema": "https://opencode.ai/config.json",\n  "instructions": [\n    "AGENTS.md"\n  ]\n}\n')
	return root
