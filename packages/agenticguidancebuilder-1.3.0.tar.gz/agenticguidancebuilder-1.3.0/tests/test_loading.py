import pytest

from agentic_guidance_builder.enums import ContentKind, ScopeType
from agentic_guidance_builder.loading import DocumentLoader, PackageLoader
from agentic_guidance_builder.parsing import FrontmatterParser
from agentic_guidance_builder.settings import load_guidance_settings


def test_frontmatter_parser_supports_optional_frontmatter():
	parsed = FrontmatterParser().parse('---\ntitle: Example\ntags:\n  - python\n---\n# Body\n')

	assert parsed.frontmatter == {'title': 'Example', 'tags': ['python']}
	assert parsed.body == '# Body\n'


def test_document_loader_derives_defaults(tmp_path):
	agents_root = tmp_path / 'agents/guidance/languages/python'
	agents_root.mkdir(parents=True)
	document_path = agents_root / 'guidance.md'
	document_path.write_text('# Python Guidance\n\nUse clear names.\n')

	document = DocumentLoader(tmp_path).load_document(document_path, ScopeType.LANGUAGE, 'python', ContentKind.GUIDANCE)

	assert document.id == 'languages-python-guidance'
	assert document.title == 'Python Guidance'
	assert document.description == ''
	assert document.kind == ContentKind.GUIDANCE
	assert document.scope == ScopeType.LANGUAGE
	assert document.name == 'python'
	assert document.tags == []
	assert document.applies_to == []


def test_package_loader_loads_scaffolded_content(tmp_path):
	(tmp_path / 'agents/guidance/languages/python/examples').mkdir(parents=True)
	(tmp_path / 'agents/guidance/project/examples').mkdir(parents=True)
	(tmp_path / 'agents/guidance/guidance.md').write_text('# Global Guidance\n')
	(tmp_path / 'agents/guidance/languages/python/guidance.md').write_text('# Python Guidance\n')
	(tmp_path / 'agents/guidance/languages/python/examples/example.md').write_text('# Python Example\n')
	(tmp_path / 'agents/guidance/project/guidance.md').write_text('# Project Guidance\n')
	(tmp_path / 'agents/guidance/project/examples/example.md').write_text('# Project Example\n')

	loaded_content = PackageLoader(tmp_path).load()

	assert loaded_content.global_guidance is not None
	assert len(loaded_content.language_packages) == 1
	assert loaded_content.language_packages[0].guidance is not None
	assert len(loaded_content.language_packages[0].examples) == 1
	assert loaded_content.project_package is not None
	assert len(loaded_content.project_package.examples) == 1


def test_document_loader_rejects_invalid_frontmatter_types(tmp_path):
	document_path = tmp_path / 'agents/guidance/guidance.md'
	document_path.parent.mkdir(parents=True)
	document_path.write_text('---\ntags: nope\n---\n# Global Guidance\n')

	with pytest.raises(ValueError):
		DocumentLoader(tmp_path).load_document(document_path, ScopeType.GLOBAL, 'global', ContentKind.GUIDANCE)


def test_document_loader_rejects_mismatched_kind_scope_and_name(tmp_path):
	document_path = tmp_path / 'agents/guidance/languages/python/guidance.md'
	document_path.parent.mkdir(parents=True)
	document_path.write_text('---\nkind: example\nscope: framework\nname: django\nstatus: active\n---\n# Python Guidance\n')

	with pytest.raises(ValueError):
		DocumentLoader(tmp_path).load_document(document_path, ScopeType.LANGUAGE, 'python', ContentKind.GUIDANCE)


def test_document_loader_rejects_unknown_frontmatter_field(tmp_path):
	document_path = tmp_path / 'agents/guidance/guidance.md'
	document_path.parent.mkdir(parents=True)
	document_path.write_text('---\nowner: team-a\n---\n# Global Guidance\n')

	with pytest.raises(ValueError):
		DocumentLoader(tmp_path).load_document(document_path, ScopeType.GLOBAL, 'global', ContentKind.GUIDANCE)


def test_load_guidance_settings_reads_toml_mapping(tmp_path):
	settings_path = tmp_path / 'agd-settings.toml'
	settings_path.write_text('[project]\nname = "Example Repo"\n\n[vars]\nproduct_name = "Example Repo"\n')

	settings = load_guidance_settings(tmp_path)
	project_settings = settings['project']
	vars_settings = settings['vars']

	assert isinstance(project_settings, dict)
	assert isinstance(vars_settings, dict)
	assert project_settings['name'] == 'Example Repo'
	assert vars_settings['product_name'] == 'Example Repo'
