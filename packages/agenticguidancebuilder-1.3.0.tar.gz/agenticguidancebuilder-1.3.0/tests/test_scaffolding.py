from pathlib import Path

from agentic_guidance_builder.cli import main


def test_init_dry_run_reports_changes_without_writing(tmp_path, capsys):
	result = main(
		[
			'init',
			'--target',
			str(tmp_path),
			'--project-name',
			'Dry Run Repo',
			'--languages',
			'python',
			'--frameworks',
			'django',
			'--dry-run',
		]
	)

	output = capsys.readouterr().out

	assert result == 0
	assert 'would_create' in output or 'would_create_dir' in output
	assert not (tmp_path / 'agents/guidance/guidance.md').exists()


def test_build_generates_agents_md(tmp_path):
	init_result = main(
		[
			'init',
			'--target',
			str(tmp_path),
			'--project-name',
			'Build Repo',
			'--languages',
			'python',
			'--frameworks',
			'django',
		]
	)

	build_result = main(['build', '--target', str(tmp_path), '--project-name', 'Build Repo', '--include-examples'])

	assert init_result == 0
	assert build_result == 0
	output = (tmp_path / 'AGENTS.md').read_text()
	assert '# Build Repo Agent Guidance' in output
	assert '# Global Guidance' in output
	assert '## Languages' in output
	assert '## Frameworks' in output
	assert '## Project' in output
	assert '# Python Guidance' in output
	assert '# Django Guidance' in output
	assert '### Examples For Python' in output
	assert '## Example: Python Example' in output
	assert '\n\n\n' not in output


def test_build_uses_settings_file_project_name_and_vars(tmp_path):
	init_result = main(['init', '--target', str(tmp_path), '--project-name', 'Settings Repo'])
	settings_path = tmp_path / 'agd-settings.toml'
	settings_path.write_text('[project]\nname = "Settings Driven Repo"\n\n[build]\ndefault_output = "AGENTS.md"\ninclude_examples_by_default = false\n\n[vars]\nproduct_name = "Settings Driven Repo"\nrepository_name = "settings-repo"\n')
	template_path = tmp_path / 'agents/guidance/templates/base/agents.md.j2'
	template_path.write_text('# {{ project.name }}\n\nProduct: {{ vars.product_name }}\n')

	build_result = main(['build', '--target', str(tmp_path)])

	assert init_result == 0
	assert build_result == 0
	assert (tmp_path / 'AGENTS.md').read_text() == '# Settings Driven Repo\n\nProduct: Settings Driven Repo\n'


def test_build_uses_settings_defaults_for_output_and_examples(tmp_path):
	init_result = main(['init', '--target', str(tmp_path), '--project-name', 'Defaults Repo', '--languages', 'python'])
	settings_path = tmp_path / 'agd-settings.toml'
	settings_path.write_text('[project]\nname = "Defaults Repo"\n\n[build]\ndefault_output = "compiled/TEAM_AGENTS.md"\ninclude_examples_by_default = true\n\n[vars]\nproduct_name = "Defaults Repo"\nrepository_name = "defaults-repo"\n')

	build_result = main(['build', '--target', str(tmp_path)])

	assert init_result == 0
	assert build_result == 0
	output = (tmp_path / 'compiled/TEAM_AGENTS.md').read_text()
	assert '## Example: Python Example' in output


def test_build_lists_example_metadata_when_examples_are_not_included(tmp_path):
	init_result = main(['init', '--target', str(tmp_path), '--project-name', 'Metadata Repo', '--languages', 'python'])
	example_path = tmp_path / 'agents/guidance/languages/python/examples/example.md'
	example_path.write_text(
		"""---
id: language-python-example-01
title: Python Example
description: Concrete example metadata.
kind: example
scope: language
name: python
tags:
  - example
  - api-client
status: active
order: 1
---

# Python Example

Example body that should stay out of the compiled file by default.
"""
	)

	build_result = main(['build', '--target', str(tmp_path), '--project-name', 'Metadata Repo'])

	assert init_result == 0
	assert build_result == 0
	output = (tmp_path / 'AGENTS.md').read_text()
	assert '### Examples For Python' in output
	assert '## Example: Python Example' not in output
	assert 'path: `agents/guidance/languages/python/examples/example.md`' in output
	assert 'name: `python`' in output
	assert 'title: Python Example' in output
	assert 'description: Concrete example metadata.' in output
	assert 'tags: `example`, `api-client`' in output
	assert 'Example body that should stay out of the compiled file by default.' not in output


def test_agd_shorthand_entrypoint_is_registered():
	pyproject_text = Path(__file__).resolve().parents[1].joinpath('pyproject.toml').read_text()

	assert 'agd = "agentic_guidance_builder.__main__:main"' in pyproject_text


def test_validate_reports_missing_required_guidance(tmp_path, capsys):
	(tmp_path / 'agents/guidance/languages/python').mkdir(parents=True)

	result = main(['validate', '--target', str(tmp_path)])
	output = capsys.readouterr().out

	assert result == 1
	assert 'Missing required guidance file: agents/guidance/guidance.md' in output
	assert 'Missing required guidance file: agents/guidance/languages/python/guidance.md' in output


def test_list_reports_discovered_content(tmp_path, capsys):
	main(
		[
			'init',
			'--target',
			str(tmp_path),
			'--project-name',
			'List Repo',
			'--languages',
			'python',
		]
	)

	result = main(['list', '--target', str(tmp_path)])
	output = capsys.readouterr().out

	assert result == 0
	assert 'INFO: Listing guidance content' in output
	assert 'Global:' in output
	assert 'Languages:' in output
	assert 'Project:' in output
	assert 'id=language-python-guidance' in output


def test_build_respects_ordering_from_frontmatter(scaffolded_repo):
	(scaffolded_repo / 'agents/guidance/languages/rust/examples').mkdir(parents=True)
	(scaffolded_repo / 'agents/guidance/languages/python/guidance.md').write_text('---\norder: 2\n---\n# Python Guidance\n')
	(scaffolded_repo / 'agents/guidance/languages/rust/guidance.md').write_text('---\norder: 1\n---\n# Rust Guidance\n')
	(scaffolded_repo / 'agents/guidance/frameworks/django/guidance.md').write_text('---\norder: 1\n---\n# Django Guidance\n')
	(scaffolded_repo / 'agents/guidance/project/guidance.md').write_text('---\norder: 0\n---\n# Project Guidance\n')

	result = main(['build', '--target', str(scaffolded_repo), '--project-name', 'Ordered Repo'])

	assert result == 0
	output = (scaffolded_repo / 'AGENTS.md').read_text()
	assert output.index('# Rust Guidance') < output.index('# Python Guidance')
	assert output.index('# Python Guidance') < output.index('# Django Guidance')


def test_build_uses_project_template_override(scaffolded_repo):
	(scaffolded_repo / 'agents/guidance/templates/base/agents.md.j2').write_text('Custom output for {{ project.name }}\n')

	result = main(['build', '--target', str(scaffolded_repo), '--project-name', 'Override Repo'])

	assert result == 0
	assert (scaffolded_repo / 'AGENTS.md').read_text() == 'Custom output for Override Repo\n'


def test_upgrade_templates_refreshes_existing_base_templates(tmp_path):
	init_result = main(['init', '--target', str(tmp_path), '--project-name', 'Upgrade Repo'])
	template_path = tmp_path / 'agents/guidance/templates/base/macros.j2'
	template_path.write_text('stale template\n')

	result = main(['upgrade-templates', '--target', str(tmp_path)])

	assert init_result == 0
	assert result == 0
	assert 'render_examples' in template_path.read_text()


def test_upgrade_templates_dry_run_reports_pending_updates(tmp_path, capsys):
	main(['init', '--target', str(tmp_path), '--project-name', 'Upgrade Repo'])
	template_path = tmp_path / 'agents/guidance/templates/base/macros.j2'
	template_path.write_text('stale template\n')

	result = main(['upgrade-templates', '--target', str(tmp_path), '--dry-run'])
	output = capsys.readouterr().out

	assert result == 0
	assert 'would_update: agents/guidance/templates/base/macros.j2' in output
	assert template_path.read_text() == 'stale template\n'


def test_upgrade_content_refreshes_packaged_skills_and_commands(tmp_path):
	main(['init', '--target', str(tmp_path), '--project-name', 'Upgrade Repo'])
	skill_path = tmp_path / 'agents/content/skills/code-change-review.md'
	command_path = tmp_path / 'agents/content/commands/review-git-diff.md'
	skill_path.write_text('stale skill\n')
	command_path.write_text('stale command\n')

	result = main(['upgrade-content', '--target', str(tmp_path)])

	assert result == 0
	assert 'name: code-change-review' in skill_path.read_text()
	assert 'role: opencode-command' in command_path.read_text()


def test_upgrade_tools_refreshes_packaged_tool_assets(tmp_path):
	main(['init', '--target', str(tmp_path), '--project-name', 'Upgrade Repo'])
	tool_path = tmp_path / 'agents/tools/opencode/opencode.json'
	tool_path.write_text('{"stale": true}\n')

	result = main(['upgrade-tools', '--target', str(tmp_path)])

	assert result == 0
	assert 'AGENTS.md' in tool_path.read_text()


def test_upgrade_all_refreshes_templates_content_and_tools(tmp_path):
	main(['init', '--target', str(tmp_path), '--project-name', 'Upgrade Repo'])
	template_path = tmp_path / 'agents/guidance/templates/base/macros.j2'
	skill_path = tmp_path / 'agents/content/skills/guidance-layout-migration.md'
	tool_path = tmp_path / 'agents/tools/opencode/opencode.json'
	template_path.write_text('stale template\n')
	skill_path.write_text('stale skill\n')
	tool_path.write_text('{"stale": true}\n')

	result = main(['upgrade-all', '--target', str(tmp_path)])

	assert result == 0
	assert 'render_examples' in template_path.read_text()
	assert 'name: guidance-layout-migration' in skill_path.read_text()
	assert 'AGENTS.md' in tool_path.read_text()


def test_upgrade_defaults_to_all_scopes(tmp_path):
	main(['init', '--target', str(tmp_path), '--project-name', 'Upgrade Repo'])
	template_path = tmp_path / 'agents/guidance/templates/base/macros.j2'
	skill_path = tmp_path / 'agents/content/skills/guidance-layout-migration.md'
	tool_path = tmp_path / 'agents/tools/opencode/opencode.json'
	template_path.write_text('stale template\n')
	skill_path.write_text('stale skill\n')
	tool_path.write_text('{"stale": true}\n')

	result = main(['upgrade', '--target', str(tmp_path)])

	assert result == 0
	assert 'render_examples' in template_path.read_text()
	assert 'name: guidance-layout-migration' in skill_path.read_text()
	assert 'AGENTS.md' in tool_path.read_text()


def test_upgrade_scope_flags_limit_which_assets_refresh(tmp_path):
	main(['init', '--target', str(tmp_path), '--project-name', 'Upgrade Repo'])
	template_path = tmp_path / 'agents/guidance/templates/base/macros.j2'
	skill_path = tmp_path / 'agents/content/skills/guidance-layout-migration.md'
	tool_path = tmp_path / 'agents/tools/opencode/opencode.json'
	template_path.write_text('stale template\n')
	skill_path.write_text('stale skill\n')
	tool_path.write_text('{"stale": true}\n')

	result = main(['upgrade', '--target', str(tmp_path), '--content'])

	assert result == 0
	assert template_path.read_text() == 'stale template\n'
	assert 'name: guidance-layout-migration' in skill_path.read_text()
	assert tool_path.read_text() == '{"stale": true}\n'


def test_build_opencode_writes_runtime_exports(scaffolded_repo):
	result = main(['build', '--target', str(scaffolded_repo), '--project-name', 'OpenCode Repo', '--adapter', 'opencode'])

	assert result == 0
	assert (scaffolded_repo / 'AGENTS.md').exists()
	assert (scaffolded_repo / 'opencode.json').exists()
	assert (scaffolded_repo / '.opencode/skills/code-change-review/SKILL.md').exists()
	assert (scaffolded_repo / '.opencode/commands/full-review.md').exists()
	assert (scaffolded_repo / '.opencode/commands/review-git-diff.md').exists()
	assert (scaffolded_repo / '.opencode/agents/context-gatherer.md').exists()
	assert 'mode: subagent' in (scaffolded_repo / '.opencode/agents/context-gatherer.md').read_text()


def test_build_copilot_writes_runtime_exports(scaffolded_repo):
	result = main(['build', '--target', str(scaffolded_repo), '--project-name', 'Copilot Repo', '--adapter', 'copilot'])

	assert result == 0
	assert (scaffolded_repo / 'AGENTS.md').exists()
	assert (scaffolded_repo / '.github/copilot-instructions.md').exists()
	assert (scaffolded_repo / '.github/instructions/python.instructions.md').exists()
	assert (scaffolded_repo / '.github/skills/code-change-review/SKILL.md').exists()
	assert (scaffolded_repo / '.github/agents/context-gatherer.agent.md').exists()
	assert 'tools: ["read", "search"]' in (scaffolded_repo / '.github/agents/context-gatherer.agent.md').read_text()


def test_build_filters_arbitrary_language_names(scaffolded_repo):
	(scaffolded_repo / 'agents/guidance/languages/go/examples').mkdir(parents=True)
	(scaffolded_repo / 'agents/guidance/languages/go/guidance.md').write_text('# Go Guidance\n')

	result = main(['build', '--target', str(scaffolded_repo), '--project-name', 'Filtered Repo', '--languages', 'go'])

	assert result == 0
	output = (scaffolded_repo / 'AGENTS.md').read_text()
	assert '# Go Guidance' in output
	assert '# Python Guidance' not in output
