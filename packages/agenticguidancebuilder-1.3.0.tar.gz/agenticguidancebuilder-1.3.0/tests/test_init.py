from agentic_guidance_builder.cli import main


def test_init_creates_v1_scaffold(tmp_path):
	result = main(
		[
			'init',
			'--target',
			str(tmp_path),
			'--project-name',
			'Sample Repo',
			'--languages',
			'python,rust',
			'--frameworks',
			'django,vue',
		]
	)

	assert result == 0
	assert (tmp_path / 'agents/guidance/guidance.md').exists()
	assert (tmp_path / 'agd-settings.toml').exists()
	assert (tmp_path / 'agents/guidance/languages/python/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/languages/python/examples/example.md').exists()
	assert (tmp_path / 'agents/guidance/languages/rust/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/frameworks/django/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/frameworks/vue/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/project/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/project/examples/example.md').exists()
	assert (tmp_path / 'agents/guidance/templates/base/agents.md.j2').exists()
	assert (tmp_path / 'agents/guidance/templates/base/macros.j2').exists()
	assert (tmp_path / 'agents/content/skills').is_dir()
	assert (tmp_path / 'agents/content/skills/code-change-review.md').exists()
	assert (tmp_path / 'agents/content/skills/guidance-layout-migration.md').exists()
	assert (tmp_path / 'agents/content/agents').is_dir()
	assert (tmp_path / 'agents/content/commands').is_dir()
	assert (tmp_path / 'agents/content/commands/review-git-diff.md').exists()
	assert not (tmp_path / 'agents/content/commands/review-git-diff').exists()

	global_text = (tmp_path / 'agents/guidance/guidance.md').read_text()
	project_text = (tmp_path / 'agents/guidance/project/guidance.md').read_text()
	settings_text = (tmp_path / 'agd-settings.toml').read_text()

	assert 'id: global-guidance' in global_text
	assert '## Expectations & Best Practices' in global_text
	assert '## Consistency Checklist' in global_text
	assert 'id: project-guidance' in project_text
	assert '## Local Conventions' in project_text
	assert '## Consistency Checklist' in project_text
	assert '[project]' in settings_text
	assert 'product_name = "Sample Repo"' in settings_text
	assert 'name: code-change-review' in (tmp_path / 'agents/content/skills/code-change-review.md').read_text()
	assert 'name: guidance-layout-migration' in (tmp_path / 'agents/content/skills/guidance-layout-migration.md').read_text()
	assert 'role: opencode-command' in (tmp_path / 'agents/content/commands/review-git-diff.md').read_text()
	assert 'Review git diff compared to origin/main' in (tmp_path / 'agents/content/commands/review-git-diff.md').read_text()
	assert not (tmp_path / 'agents/tools/copilot').exists()


def test_init_accepts_arbitrary_language_and_framework_names(tmp_path):
	result = main(
		[
			'init',
			'--target',
			str(tmp_path),
			'--languages',
			'go,typescript',
			'--frameworks',
			'fastapi,sveltekit',
		]
	)

	assert result == 0
	assert (tmp_path / 'agents/guidance/languages/go/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/languages/typescript/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/frameworks/fastapi/guidance.md').exists()
	assert (tmp_path / 'agents/guidance/frameworks/sveltekit/guidance.md').exists()
	assert 'id: language-go-guidance' in (tmp_path / 'agents/guidance/languages/go/guidance.md').read_text()
	assert 'id: framework-fastapi-guidance' in (tmp_path / 'agents/guidance/frameworks/fastapi/guidance.md').read_text()


def test_init_does_not_overwrite_authored_files_without_force(tmp_path):
	guidance_path = tmp_path / 'agents/guidance/guidance.md'
	guidance_path.parent.mkdir(parents=True)
	guidance_path.write_text('# Custom Guidance\n')

	result = main(['init', '--target', str(tmp_path)])

	assert result == 0
	assert guidance_path.read_text() == '# Custom Guidance\n'
