from pydantic import Field
from typing import Annotated, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from nexo.types.any import ManyAny
from nexo.types.string import ManyStrs
from ..enums.principal import IdentifierType
from ..types.principal import (
    PersonalCompositeIdentifierValueType,
    SystemCompositeIdentifierValueType,
    TenantCompositeIdentifierValueType,
    IdentifierValueType,
)


class PrincipalIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def columns_and_values(self) -> tuple[ManyStrs, ManyAny]:
        values = self.value if isinstance(self.value, tuple) else (self.value,)
        return self.type.columns, values


class IdPrincipalIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class UUIDPrincipalIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier's type"),
    ] = IdentifierType.UUID


class PersonalCompositePrincipalIdentifier(
    Identifier[
        Literal[IdentifierType.PERSONAL_COMPOSITE], PersonalCompositeIdentifierValueType
    ]
):
    type: Annotated[
        Literal[IdentifierType.PERSONAL_COMPOSITE],
        Field(IdentifierType.PERSONAL_COMPOSITE, description="Identifier's type"),
    ] = IdentifierType.PERSONAL_COMPOSITE
    value: Annotated[
        PersonalCompositeIdentifierValueType,
        Field(..., description="Identifier's value"),
    ]


class SystemCompositePrincipalIdentifier(
    Identifier[
        Literal[IdentifierType.SYSTEM_COMPOSITE], SystemCompositeIdentifierValueType
    ]
):
    type: Annotated[
        Literal[IdentifierType.SYSTEM_COMPOSITE],
        Field(IdentifierType.SYSTEM_COMPOSITE, description="Identifier's type"),
    ] = IdentifierType.SYSTEM_COMPOSITE
    value: Annotated[
        SystemCompositeIdentifierValueType, Field(..., description="Identifier's value")
    ]


class TenantCompositePrincipalIdentifier(
    Identifier[
        Literal[IdentifierType.TENANT_COMPOSITE], TenantCompositeIdentifierValueType
    ]
):
    type: Annotated[
        Literal[IdentifierType.TENANT_COMPOSITE],
        Field(IdentifierType.TENANT_COMPOSITE, description="Identifier's type"),
    ] = IdentifierType.TENANT_COMPOSITE
    value: Annotated[
        TenantCompositeIdentifierValueType, Field(..., description="Identifier's value")
    ]


AnyPrincipalIdentifier = (
    PrincipalIdentifier
    | IdPrincipalIdentifier
    | UUIDPrincipalIdentifier
    | PersonalCompositePrincipalIdentifier
    | SystemCompositePrincipalIdentifier
    | TenantCompositePrincipalIdentifier
)


def is_id_identifier(
    identifier: AnyPrincipalIdentifier,
) -> TypeGuard[IdPrincipalIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnyPrincipalIdentifier,
) -> TypeGuard[UUIDPrincipalIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)


def is_personal_composite_identifier(
    identifier: AnyPrincipalIdentifier,
) -> TypeGuard[PersonalCompositePrincipalIdentifier]:
    return identifier.type is IdentifierType.PERSONAL_COMPOSITE and isinstance(
        identifier.value, tuple
    )


def is_system_composite_identifier(
    identifier: AnyPrincipalIdentifier,
) -> TypeGuard[SystemCompositePrincipalIdentifier]:
    return identifier.type is IdentifierType.SYSTEM_COMPOSITE and isinstance(
        identifier.value, tuple
    )


def is_tenant_composite_identifier(
    identifier: AnyPrincipalIdentifier,
) -> TypeGuard[TenantCompositePrincipalIdentifier]:
    return identifier.type is IdentifierType.TENANT_COMPOSITE and isinstance(
        identifier.value, tuple
    )
