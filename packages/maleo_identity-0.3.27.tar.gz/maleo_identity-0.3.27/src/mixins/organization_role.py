from pydantic import BaseModel, Field
from typing import Annotated, Generic, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from nexo.types.integer import OptIntT, OptListOfIntsT
from nexo.types.string import OptStrT
from ..enums.organization_role import IdentifierType
from ..types.organization_role import IdentifierValueType


class OrganizationRoleId(BaseModel, Generic[OptIntT]):
    organization_role_id: Annotated[
        OptIntT, Field(..., description="Organization Role's ID", ge=1)
    ]


class OrganizationRoleIds(BaseModel, Generic[OptListOfIntsT]):
    organization_role_ids: Annotated[
        OptListOfIntsT, Field(..., description="Organization Role's IDs", min_length=1)
    ]


class Key(BaseModel):
    key: str = Field(..., max_length=20, description="Organization role's key")


class Name(BaseModel, Generic[OptStrT]):
    name: OptStrT = Field(..., max_length=20, description="Organization role's name")


class OrganizationRoleIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdOrganizationRoleIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class UUIDOrganizationRoleIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier's type"),
    ] = IdentifierType.UUID


class KeyOrganizationRoleIdentifier(Identifier[Literal[IdentifierType.KEY], str]):
    type: Annotated[
        Literal[IdentifierType.KEY],
        Field(IdentifierType.KEY, description="Identifier's type"),
    ] = IdentifierType.KEY
    value: Annotated[str, Field(..., description="Identifier's value", max_length=20)]


class NameOrganizationRoleIdentifier(Identifier[Literal[IdentifierType.NAME], str]):
    type: Annotated[
        Literal[IdentifierType.NAME],
        Field(IdentifierType.NAME, description="Identifier's type"),
    ] = IdentifierType.NAME
    value: Annotated[str, Field(..., description="Identifier's value", max_length=20)]


AnyOrganizationRoleIdentifier = (
    OrganizationRoleIdentifier
    | IdOrganizationRoleIdentifier
    | UUIDOrganizationRoleIdentifier
    | KeyOrganizationRoleIdentifier
    | NameOrganizationRoleIdentifier
)


def is_id_identifier(
    identifier: AnyOrganizationRoleIdentifier,
) -> TypeGuard[IdOrganizationRoleIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnyOrganizationRoleIdentifier,
) -> TypeGuard[UUIDOrganizationRoleIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)


def is_key_identifier(
    identifier: AnyOrganizationRoleIdentifier,
) -> TypeGuard[KeyOrganizationRoleIdentifier]:
    return identifier.type is IdentifierType.KEY and isinstance(identifier.value, str)


def is_name_identifier(
    identifier: AnyOrganizationRoleIdentifier,
) -> TypeGuard[NameOrganizationRoleIdentifier]:
    return identifier.type is IdentifierType.NAME and isinstance(identifier.value, str)
