from nexo.schemas.resource import Resource, ResourceIdentifier


PRINCIPAL_MEDICAL_ROLE_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="principal_medical_role",
            name="Principal Medical Role",
            slug="principal-medical-roles",
        )
    ],
    details=None,
)
