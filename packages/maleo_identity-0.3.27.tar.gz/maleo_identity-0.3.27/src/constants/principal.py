from nexo.schemas.resource import Resource, ResourceIdentifier


PRINCIPAL_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(key="principal", name="Principal", slug="principals")
    ],
    details=None,
)
