from typing import Literal
from uuid import UUID
from nexo.schemas.security.enums import Domain


BasicIdentifierValueType = int | UUID
PersonalCompositeIdentifierValueType = tuple[Literal[Domain.PERSONAL], int]
SystemCompositeIdentifierValueType = tuple[Literal[Domain.SYSTEM], int]
TenantCompositeIdentifierValueType = tuple[Literal[Domain.TENANT], int, int]
IdentifierValueType = (
    BasicIdentifierValueType
    | PersonalCompositeIdentifierValueType
    | SystemCompositeIdentifierValueType
    | TenantCompositeIdentifierValueType
)
