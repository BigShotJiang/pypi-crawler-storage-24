from uuid import UUID
from nexo.enums.organization import OrganizationRelation

BasicIdentifierType = int | UUID
CompositeIdentifierType = tuple[int, int, OrganizationRelation]
IdentifierValueType = BasicIdentifierType | CompositeIdentifierType
