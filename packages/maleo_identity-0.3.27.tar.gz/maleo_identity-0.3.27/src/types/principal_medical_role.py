from uuid import UUID


BasicIdentifierValueType = int | UUID
CompositeIdentifierValueType = tuple[int, int]
IdentifierValueType = BasicIdentifierValueType | CompositeIdentifierValueType
