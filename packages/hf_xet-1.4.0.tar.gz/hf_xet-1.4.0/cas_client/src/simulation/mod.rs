//! Simulation module for local testing and development.
//!
//! This module provides clients and servers for testing CAS operations
//! without requiring a remote server:
//!
//! - [`LocalClient`]: A disk-backed client for testing (not available in WASM)
//! - [`MemoryClient`]: An in-memory client for testing
//! - [`local_server`]: An HTTP server wrapping a DirectAccessClient for integration testing (not available in WASM)
//! - [`DirectAccessClient`]: Trait for clients with direct XORB/file access
//! - [`client_testing_utils`]: Testing utilities for Client implementations (not available in WASM)
//! - [`client_unit_testing`]: Common unit tests for Client implementations (not available in WASM)
//! - [`network_simulation`]: Bandwidth-limit proxy and network profiles (not available in WASM)

pub mod client_testing_utils;
#[cfg(all(test, not(target_family = "wasm")))]
pub mod client_unit_testing;
#[cfg(not(target_family = "wasm"))]
mod deletion_controls;
#[cfg(all(test, not(target_family = "wasm")))]
pub mod deletion_unit_testing;
mod direct_access_client;
#[cfg(not(target_family = "wasm"))]
mod local_client;
#[cfg(not(target_family = "wasm"))]
pub mod local_server;
mod memory_client;
#[cfg(not(target_family = "wasm"))]
pub mod network_simulation;
mod random_xorb;
#[cfg(not(target_family = "wasm"))]
mod simulation_client;
#[cfg(not(target_family = "wasm"))]
mod simulation_server;
#[cfg(unix)]
#[cfg(not(target_family = "wasm"))]
pub mod socket_proxy;

pub use client_testing_utils::{ClientTestingUtils, RandomFileContents};
#[cfg(not(target_family = "wasm"))]
pub use deletion_controls::DeletionControlableClient;
pub use direct_access_client::DirectAccessClient;
#[cfg(not(target_family = "wasm"))]
pub use local_client::LocalClient;
#[cfg(not(target_family = "wasm"))]
pub use local_server::{LocalServer, LocalServerConfig, SimulationControlClient};
pub use memory_client::MemoryClient;
#[cfg(not(target_family = "wasm"))]
pub use network_simulation::{NetworkConfig, NetworkProfile, NetworkProfileOptions, NetworkSimulationProxy};
pub use random_xorb::RandomXorb;
#[cfg(not(target_family = "wasm"))]
pub use simulation_client::RemoteSimulationClient;
#[cfg(not(target_family = "wasm"))]
pub use simulation_server::{LocalTestServer, LocalTestServerBuilder};
#[cfg(unix)]
#[cfg(not(target_family = "wasm"))]
pub use socket_proxy::UnixSocketProxy;
