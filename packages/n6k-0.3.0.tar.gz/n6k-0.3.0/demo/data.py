import pandas as pd

from n6k_server.registry import action, data

# app = create_app()


@action
def greet(name: str):
    return {"message": f"Hello, {name}!"}


@data()
def demo():
    return pd.DataFrame(
        {
            "id": [1, 2, 3],
            "name": ["alice", "bob", "charlie"],
            "score": [95.5, 87.3, 91.8],
        }
    )


# @data(app)
# def iris():
#     return sns.load_dataset("iris")


# page(
#     app,
#     "/",
#     """
#     <div className="p-6">
#      <div>Hello2</div>
#       <N6KDataTable table="db.demo" />
#     </div>
# """,
# )
# page(
#     app,
#     "/debug",
#     """
#     <N6KPage>
#       <N6KQuery query="select * from db.demo" />
#     </N6KPage>
# """,
# )

# page(
#     app,
#     "/form",
#     """
#     <div className="flex gap-2 p-8">
#       <Checkbox id="terms" />
#       <Label htmlFor="terms">Accept terms and conditions</Label>
#     </div>
# """,
# )


# @app.get("/health")
# async def health() -> PlainTextResponse:
#     return PlainTextResponse("ok")
