from n6k_server.app import create_app

__all__ = ["create_app"]
