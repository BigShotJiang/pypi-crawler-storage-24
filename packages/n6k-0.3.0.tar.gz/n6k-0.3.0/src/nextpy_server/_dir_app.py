"""Thin entry point for uvicorn in directory-based mode.

The CLI sets N6K_APP_DIR and points uvicorn at this module.
On each reload, this re-discovers the app from the directory.
"""

import os

from nextpy_server.discover import discover_app

app_dir = os.environ.get("N6K_APP_DIR", "src/app")
app = discover_app(app_dir)
