"""Module-level registry for file-based bind/action definitions.

Used by data.py files in directory-based apps. Decorators register
into a thread-local registry which is collected after each file import.
"""

from __future__ import annotations

from typing import Any, Callable


class _Registry:
    def __init__(self):
        self.bindings: dict[str, Any] = {}
        self.actions: dict[str, Callable] = {}

    def clear(self):
        self.bindings.clear()
        self.actions.clear()


_current = _Registry()


def defaults(**kwargs: Any):
    """Register default values for client-side state."""
    _current.bindings.update(kwargs)


def action(fn: Callable | None = None, *, name: str | None = None):
    """Register a server action. Supports @action and @action(name="...")."""
    if fn is not None:
        _current.actions[fn.__name__] = fn
        return fn

    def decorator(f: Callable) -> Callable:
        _current.actions[name if name is not None else f.__name__] = f
        return f

    return decorator


def collect() -> dict:
    """Collect all registered items and reset the registry."""
    result = {
        "bindings": dict(_current.bindings),
        "actions": dict(_current.actions),
    }
    _current.clear()
    return result
